# JCI notes — 0000833444-16-000216


## jci:AssetsandLiabilitiesHeldforSalePolicyTextBlock

[0000833444-16-000216:notes:1]
Assets and Liabilities Held for Sale

[0000833444-16-000216:notes:2]
The Company classifies assets and liabilities (disposal groups) to be sold as held for sale in the period in which all of the following criteria are met: management, having the authority to approve the action, commits to a plan to sell the disposal group; the disposal group is available for immediate sale in its present condition subject only to terms that are usual and customary for sales of such disposal groups; an active program to locate a buyer and other actions required to complete the plan to sell the disposal group have been initiated; the sale of the disposal group is probable, and transfer of the disposal group is expected to qualify for recognition as a completed sale within one year, except if events or circumstances beyond the Company's control extend the period of time required to sell the disposal group beyond one year; the disposal group is being actively marketed for sale at a price that is reasonable in relation to its current fair value; and actions required to complete the plan indicate that it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn.

[0000833444-16-000216:notes:3]
The Company initially measures a disposal group that is classified as held for sale at the lower of its carrying value or fair value less any costs to sell. Any loss resulting from this measurement is recognized in the period in which the held for sale criteria are met. Conversely, gains are not recognized on the sale of a disposal group until the date of sale. The Company assesses the fair value of a disposal group less any costs to sell each reporting period it remains classified as held for sale and reports any subsequent changes as an adjustment to the carrying value of the disposal group, as long as the new carrying value does not exceed the carrying value of the disposal group at the time it was initially classified as held for sale.

[0000833444-16-000216:notes:4]
Upon determining that a disposal group meets the criteria to be classified as held for sale, the Company reports the assets and liabilities of the disposal group, if material, in the line items assets held for sale and liabilities held for sale in the consolidated statements of financial position. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information.


## jci:AssetsandLiabilitiesHeldforSaleSpecificTransactionsTableTextBlock

[0000833444-16-000216:notes:5]
The following table summarizes the carrying value of the Tyco assets and liabilities held for sale at September 30, 2016 (in millions):

[0000833444-16-000216:notes:6]
| Accounts receivable - net | $ | 9 |  |
| Inventories | 7 |  |
| Other current assets | 3 |  |
| Property, plant and equipment - net | 15 |  |
| Goodwill | 89 |  |
| Other intangible assets - net | 30 |  |
| Other noncurrent assets | 4 |  |
| Assets held for sale | $ | 157 |  |
| Accounts payable | $ | 9 |  |
| Other current liabilities | 19 |  |
| Liabilities held for sale | $ | 28 |  |


## jci:ComponentsOfNetFinancingChargesTableTextBlock

[0000833444-16-000216:notes:7]
The Company's net financing charges line item in the consolidated statements of income for the years ended September 30, 2016, 2015 and 2014 contained the following components (in millions):

[0000833444-16-000216:notes:8]
|  | Year Ended September 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Interest expense, net of capitalized interest costs | $ | 309 |  |  | $ | 288 |  |  | $ | 254 |  |
| Banking fees and bond cost amortization | 34 |  |  | 23 |  |  | 18 |  |
| Interest income | (14 | ) |  | (9 | ) |  | (10 | ) |
| Net foreign exchange results for financing activities | (15 | ) |  | (14 | ) |  | (18 | ) |
| Net financing charges | $ | 314 |  |  | $ | 288 |  |  | $ | 244 |  |


## jci:DeferredTaxesClassifiedInConsolidatedStatementsOfFinancialPositionTableTextBlock

[0000833444-16-000216:notes:9]
Deferred taxes were classified in the consolidated statements of financial position as follows (in millions):

[0000833444-16-000216:notes:10]
|  | September 30, |
|  | 2016 |  | 2015 |
| Other noncurrent assets | 2,905 |  |  | 1,873 |  |
| Other noncurrent liabilities | (1,597 | ) |  | (391 | ) |
| Net deferred tax asset | $ | 1,308 |  |  | $ | 1,482 |  |


## jci:DerivativeAssetsandLiabilitiesEligibleforOffsettingTableTextBlock

[0000833444-16-000216:notes:11]
The gross and net amounts of derivative assets and liabilities were as follows (in millions):

[0000833444-16-000216:notes:12]
|  | Fair Value of Assets |  | Fair Value of Liabilities |
|  | September 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |  |
| Gross amount recognized | $ | 95 |  |  | $ | 233 |  |  | $ | 2,980 |  |  | $ | 1,727 |  |  |
| Gross amount eligible for offsetting | (21 | ) |  | (8 | ) |  | (21 | ) |  | (8 | ) |  |
| Net amount | $ | 74 |  |  | $ | 225 |  |  | $ | 2,959 |  |  | $ | 1,719 |  |  |


## jci:EquityAttributableToParentAndNoncontrollingInterestsTableTextBlock

[0000833444-16-000216:notes:13]
The following schedules present changes in consolidated equity attributable to Johnson Controls and noncontrolling interests (in millions, net of tax):

[0000833444-16-000216:notes:14]
|  | Equity Attributable to Johnson ControlsInternational plc |  | Equity Attributable to Noncontrolling Interests |  | Total Equity |
| At September 30, 2013 | $ | 12,273 |  |  | $ | 260 |  |  | $ | 12,533 |  |
| Total comprehensive income: |  |  |  |  |  |
| Net income | 1,215 |  |  | 90 |  |  | 1,305 |  |
| Foreign currency translation adjustments | (640 | ) |  | (2 | ) |  | (642 | ) |
| Realized and unrealized losses on derivatives | (3 | ) |  | — |  |  | (3 | ) |
| Realized and unrealized losses on marketable common stock | (7 | ) |  | — |  |  | (7 | ) |
| Pension and postretirement plans | (5 | ) |  | — |  |  | (5 | ) |
| Other comprehensive loss | (655 | ) |  | (2 | ) |  | (657 | ) |
| Comprehensive income | 560 |  |  | 88 |  |  | 648 |  |
| Other changes in equity: |  |  |  |  |  |
| Cash dividends - common stock ($0.88 per share) | (586 | ) |  | — |  |  | (586 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (59 | ) |  | (59 | ) |
| Repurchases of common stock | (1,249 | ) |  | — |  |  | (1,249 | ) |
| Change in noncontrolling interest share | — |  |  | (32 | ) |  | (32 | ) |
| Other, including options exercised | 272 |  |  | (6 | ) |  | 266 |  |
| At September 30, 2014 | 11,270 |  |  | 251 |  |  | 11,521 |  |
| Total comprehensive income: |  |  |  |  |  |
| Net income | 1,563 |  |  | 65 |  |  | 1,628 |  |
| Foreign currency translation adjustments | (799 | ) |  | (3 | ) |  | (802 | ) |
| Realized and unrealized losses on derivatives | (11 | ) |  | — |  |  | (11 | ) |
| Pension and postretirement plans | (10 | ) |  | — |  |  | (10 | ) |
| Other comprehensive loss | (820 | ) |  | (3 | ) |  | (823 | ) |
| Comprehensive income | 743 |  |  | 62 |  |  | 805 |  |
| Other changes in equity: |  |  |  |  |  |
| Cash dividends - common stock ($1.04 per share) | (681 | ) |  | — |  |  | (681 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (57 | ) |  | (57 | ) |
| Repurchases of common stock | (1,362 | ) |  | — |  |  | (1,362 | ) |
| Change in noncontrolling interest share | — |  |  | (93 | ) |  | (93 | ) |
| Other, including options exercised | 365 |  |  | — |  |  | 365 |  |
| At September 30, 2015 | 10,335 |  |  | 163 |  |  | 10,498 |  |
| Total comprehensive income (loss): |  |  |  |  |  |
| Net income (loss) | (868 | ) |  | 168 |  |  | (700 | ) |
| Foreign currency translation adjustments | (105 | ) |  | 9 |  |  | (96 | ) |
| Realized and unrealized gains (losses) on derivatives | 11 |  |  | (1 | ) |  | 10 |  |
| Unrealized losses on marketable common stock | (1 | ) |  | — |  |  | (1 | ) |
| Pension and postretirement plans | (1 | ) |  | — |  |  | (1 | ) |
| Other comprehensive income (loss) | (96 | ) |  | 8 |  |  | (88 | ) |
| Comprehensive income (loss) | (964 | ) |  | 176 |  |  | (788 | ) |
| Other changes in equity: |  |  |  |  |  |
| Result of contribution of Johnson Controls, Inc. to Johnson Controls International plc | 15,808 |  |  | — |  |  | 15,808 |  |
| Cash dividends - common stock ($1.16 per share) | (752 | ) |  | — |  |  | (752 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (93 | ) |  | (93 | ) |
| Repurchases of common stock | (501 | ) |  | — |  |  | (501 | ) |
| Change in noncontrolling interest share | — |  |  | 726 |  |  | 726 |  |
| Other, including options exercised | 192 |  |  | — |  |  | 192 |  |
| At September 30, 2016 | $ | 24,118 |  |  | $ | 972 |  |  | $ | 25,090 |  |


## jci:FutureMinimumCapitalAndOperatingLeasePaymentsAndRelatedPresentValueOfCapitalLeasePaymentsTableTextBlock

[0000833444-16-000216:notes:15]
Future minimum capital and operating lease payments and the related present value of capital lease payments at September 30, 2016 were as follows (in millions):

[0000833444-16-000216:notes:16]
|  | CapitalLeases |  | OperatingLeases |
| 2017 | $ | 5 |  |  | $ | 406 |  |
| 2018 | 4 |  |  | 310 |  |
| 2019 | 3 |  |  | 227 |  |
| 2020 | 3 |  |  | 156 |  |
| 2021 | 3 |  |  | 98 |  |
| After 2021 | 12 |  |  | 155 |  |
| Total minimum lease payments | 30 |  |  | $ | 1,352 |  |
| Interest | (6 | ) |  |  |
| Present value of net minimum lease payments | $ | 24 |  |  |  |


## jci:HedgeForecastedPurchasesTableTextBlock

[0000833444-16-000216:notes:17]
The Company had the following outstanding contracts to hedge forecasted commodity purchases:

[0000833444-16-000216:notes:18]
|  |  |  |  | Volume Outstanding as of |
| Commodity |  | Units |  | September 30, 2016 |  | September 30, 2015 |
| Copper |  | Pounds |  | 5,849,000 |  |  | 14,648,000 |  |
| Lead |  | Metric Tons |  | 5,185 |  |  | 6,785 |  |
| Aluminum |  | Metric Tons |  | 2,620 |  |  | 5,700 |  |
| Tin |  | Metric Tons |  | 185 |  |  | 2,080 |  |


## jci:RetrospectiveChangesPolicyTextBlock

[0000833444-16-000216:notes:19]
Retrospective Changes

[0000833444-16-000216:notes:20]
In the fourth quarter of fiscal 2016, the Company changed its accounting policy for accruing for defense costs related to asbestos claims on a discounted basis. The Company’s historical accounting treatment for asbestos claim defense costs was to accrue as incurred. The new policy is to record an accrual for all future asbestos related defense costs which are determined to be probable and estimable of being incurred. The Company believes this new policy is preferable as it better reflects the economics of settlement of the Company's asbestos claims, improves comparability among the Company’s peer group and provides greater transparency to on-going operating results. These changes have been reported through retrospective application of the new policy to all periods presented. These changes did not have an impact to any period presented on the consolidated statements of income. The financial statement impact of this change for all periods presented was an increase to other noncurrent liabilities of $68 million, an increase to other noncurrent assets of $27 million and a decrease to retained earnings of $41 million.

[0000833444-16-000216:notes:21]
In September 2016, as a result of the Tyco merger and further discussed within Note 2, "Merger Transaction," of the notes to consolidated financial statements, each outstanding share of common stock, par value $1.00 per share, of JCI Inc. common stock (other than shares held by JCI Inc., Tyco and certain of their subsidiaries) was converted into the right to receive either a cash consideration or a share consideration. As a result, the par value of the Company’s ordinary shares is $0.01. This change resulted in a decrease to ordinary shares and corresponding increase in capital in excess of par value in the consolidated statements of financial position and is reported through retrospective application of the new par value for all periods presented.


## jci:ScheduleOfIntangibleAssetsTableTextBlock

[0000833444-16-000216:notes:22]
The Company’s other intangible assets, primarily from business acquisitions valued based on independent appraisals, consisted of (in millions):

[0000833444-16-000216:notes:23]
|  | September 30, 2016 |  | September 30, 2015 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Amortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,556 |  |  | $ | (37 | ) |  | $ | 1,519 |  |  | $ | 80 |  |  | $ | (59 | ) |  | $ | 21 |  |
| Customer relationships | 3,268 |  |  | (274 | ) |  | 2,994 |  |  | 975 |  |  | (206 | ) |  | 769 |  |
| Miscellaneous | 590 |  |  | (155 | ) |  | 435 |  |  | 307 |  |  | (123 | ) |  | 184 |  |
| Total amortized intangible assets | 5,414 |  |  | (466 | ) |  | 4,948 |  |  | 1,362 |  |  | (388 | ) |  | 974 |  |
| Unamortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,555 |  |  | — |  |  | 2,555 |  |  | 542 |  |  | — |  |  | 542 |  |
| Miscellaneous | 150 |  |  | — |  |  | 150 |  |  | — |  |  | — |  |  | — |  |
|  | 2,705 |  |  | — |  |  | 2,705 |  |  | 542 |  |  | — |  |  | 542 |  |
| Total intangible assets | $ | 8,119 |  |  | $ | (466 | ) |  | $ | 7,653 |  |  | $ | 1,904 |  |  | $ | (388 | ) |  | $ | 1,516 |  |


## jci:ScheduleofFairValueofConsiderationTransferredTableTextBlock

[0000833444-16-000216:notes:24]
The following table summarizes the total fair value of consideration transferred:

[0000833444-16-000216:notes:25]
| (in millions, except for share consolidation ratio and share data) |  |  |
| Number of Tyco shares outstanding at September 2, 2016 |  | 427,181,743 |  |
| Tyco share consolidation ratio |  | 0.955 |  |
| Tyco ordinary shares outstanding following the share consolidation and immediately prior to the merger |  | 407,958,565 |  |
| JCI Inc. converted share price (1) |  | $ | 47.67 |  |
| Fair value of equity portion of the merger consideration |  | $ | 19,447 |  |
| Fair value of Tyco equity awards |  | 224 |  |
| Total fair value of consideration transferred |  | $ | 19,671 |  |

[0000833444-16-000216:notes:26]
| (1) | Amount equals JCI Inc. closing share price and market capitalization at September 2, 2016 ($45.45 and $29,012 million, respectively) adjusted for the Tyco $3,864 million cash contribution used to purchase 110.8 million shares of JCI Inc. common stock for $34.88 per share. |


## jci:ShareBasedCompensationArrangementByShareBasedPaymentAwardFairValueAssumptionsInStockAppreciationRightsTableTextBlock

[0000833444-16-000216:notes:27]
The assumptions used to determine the fair value of the SAR awards at September 30, 2016 were as follows:

[0000833444-16-000216:notes:28]
| Expected life of SAR (years) | 0.5 - 4.2 |
| Risk-free interest rate | 0.45% - 1.04% |
| Expected volatility of the Company’s stock | 36.00% |
| Expected dividend yield on the Company’s stock | 2.11% |


## jci:SubscriberSystemAssetsDealerIntangiblesandRelatedDeferredRevenueAccountsPolicyTextBlock

[0000833444-16-000216:notes:29]
Subscriber System Assets, Dealer Intangibles and Related Deferred Revenue Accounts

[0000833444-16-000216:notes:30]
The Tyco portion of the Buildings business considers assets related to the acquisition of new customers in its electronic security business in three asset categories: internally generated residential subscriber systems outside of North America, internally generated commercial subscriber systems (collectively referred to as subscriber system assets) and customer accounts acquired through the ADT dealer program, primarily outside of North America (referred to as dealer intangibles). Subscriber system assets include installed property, plant and equipment for which the Company retains ownership and deferred costs directly related to the customer acquisition and system installation. Subscriber system assets represent capitalized equipment (e.g. security control panels, touchpad, motion detectors, window sensors, and other equipment) and installation costs associated with electronic security monitoring arrangements under which the Company retains ownership of the security system assets in a customer's place of business, or outside of North America, residence. Installation costs represent costs incurred to prepare the asset for its intended use. The Company pays property taxes on the subscriber system assets and upon customer termination, may retrieve such assets. These assets embody a probable future economic benefit as they generate future monitoring revenue for the Company.

[0000833444-16-000216:notes:31]
Costs related to the subscriber system equipment and installation are categorized as property, plant and equipment rather than deferred costs. Deferred costs associated with subscriber system assets represent direct and incremental selling expenses (such as commissions) related to acquiring the customer. Commissions related to up-front consideration paid by customers in connection with the establishment of the monitoring arrangement are determined based on a percentage of the up-front fees and do not exceed deferred revenue. Such deferred costs are recorded as other current and noncurrent assets within the consolidated statements of financial position.

[0000833444-16-000216:notes:32]
Subscriber system assets and any deferred revenue resulting from the customer acquisition are accounted for over the expected life of the subscriber. In certain geographical areas where the Company has a large number of customers that behave in a similar manner over time, the Company accounts for subscriber system assets and related deferred revenue using pools, with separate pools for the components of subscriber system assets and any related deferred revenue based on the same month and year of acquisition. The Company depreciates its pooled subscriber system assets and related deferred revenue using a straight-line method with lives up to 15 years and considering customer attrition. The Company uses a straight-line method with a 15-year life for non-pooled subscriber system assets (primarily in Europe, Latin America and Asia) and related deferred revenue, with remaining balances written off upon customer termination.

[0000833444-16-000216:notes:33]
Certain contracts and related customer relationships result from purchasing residential security monitoring contracts from an external network of independent dealers who operate under the ADT dealer program, primarily outside of North America. Acquired contracts and related customer relationships are recorded at their contractually determined purchase price.

[0000833444-16-000216:notes:34]
During the first 6 months (12 months in certain circumstances) after the purchase of the customer contract, any cancellation of monitoring service, including those that result from customer payment delinquencies, results in a chargeback by the Company to the dealer for the full amount of the contract purchase price. The Company records the amount charged back to the dealer as a reduction of the previously recorded intangible asset.

[0000833444-16-000216:notes:35]
Intangible assets arising from the ADT dealer program described above are amortized in pools determined by the same month and year of contract acquisition on a straight-line basis over the period of the customer relationship. The estimated useful life of dealer intangibles ranges from 12 to 15 years.


## jci:SummarizedBalanceSheetInformationNonConsolidatedPartiallyOwnedAffiliatesTableTextBlock

[0000833444-16-000216:notes:36]
Summarized balance sheet data as of September 30 is as follows (in millions):

[0000833444-16-000216:notes:37]
|  | 2016 |  | 2015 |
| Current assets | $ | 9,117 |  |  | $ | 7,083 |  |
| Noncurrent assets | 4,164 |  |  | 3,294 |  |
| Total assets | $ | 13,281 |  |  | $ | 10,377 |  |
| Current liabilities | $ | 7,689 |  |  | $ | 6,268 |  |
| Noncurrent liabilities | 754 |  |  | 604 |  |
| Noncontrolling interests | 78 |  |  | 20 |  |
| Shareholders’ equity | 4,760 |  |  | 3,485 |  |
| Total liabilities and shareholders’ equity | $ | 13,281 |  |  | $ | 10,377 |  |


## jci:SummarizedIncomeStatementInformationNonConsolidatedPartiallyOwnedAffiliatesTableTextBlock

[0000833444-16-000216:notes:38]
Summarized income statement data for the years ended September 30 is as follows (in millions):

[0000833444-16-000216:notes:39]
|  | 2016 |  | 2015 |  | 2014 |
| Net sales | $ | 21,456 |  |  | $ | 12,922 |  |  | $ | 10,820 |  |
| Gross profit | 3,119 |  |  | 1,911 |  |  | 1,638 |  |
| Net income | 1,569 |  |  | 890 |  |  | 790 |  |
| Income attributable to noncontrolling interests | 26 |  |  | 10 |  |  | 3 |  |
| Net income attributable to the entity | 1,543 |  |  | 880 |  |  | 787 |  |


## us-gaap:AssetImpairmentChargesTextBlock

[0000833444-16-000216:notes:40]
IMPAIRMENT OF LONG-LIVED ASSETS

[0000833444-16-000216:notes:41]
The Company reviews long-lived assets, including property, plant and equipment and other intangible assets with definite lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets." ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals.

[0000833444-16-000216:notes:42]
In the second, third and fourth quarters of fiscal 2016, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2016. As a result, the Company reviewed the long-lived assets for impairment and recorded $190 million of asset impairment charges within restructuring and impairment costs on the consolidated statements of income, of which $29 million was recorded in the second quarter, $51 million was recorded in the third quarter and $110 million was recorded in the fourth quarter. Of the total impairment charges, $64 million related to the Power Solutions segment, $55 million related to Corporate assets, $55 million related to the Automotive Experience Seating segment, $8 million related to the Building Efficiency Products North America segment, $4 million related to the Building Efficiency Asia segment, $3 million related to the Building Efficiency Rest of World segment and $1 million related to the Automotive Experience Interiors segment. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-16-000216:notes:43]
In the fourth quarter of fiscal 2015, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its announced restructuring actions and the intention to spin-off the Automotive Experience business. As a result, the Company reviewed the long-lived assets for impairment and recorded a $183 million impairment charge within restructuring and impairment costs on the consolidated statements of income. Of the total impairment charge, $139 million related to Corporate assets, $27 million related to the Automotive Experience Seating segment, $16 million related to the Building Efficiency Rest of World segment and $1 million related to the Building Efficiency Systems and Service North America  segment. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairment was measured, depending on the asset, either under an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-16-000216:notes:44]
In the third and fourth quarters of fiscal 2014, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2014. In addition, in the fourth quarter of fiscal 2014, the Company concluded that it had a triggering event requiring assessment of impairment of long-lived assets held by the Building Efficiency Rest of World - Latin America reporting unit due to the impairment of goodwill in the quarter. As a result, the Company reviewed the long-lived assets for impairment and recorded a $91 million impairment charge within restructuring and impairment costs on the consolidated statements of income, of which $45 million was recorded in the third quarter and $46 million in the fourth quarter of fiscal 2014. Of the total impairment charge, $45 million related to the Automotive Experience Interiors segment, $34 million related to the Building Efficiency Rest of World segment, $7 million related to the Automotive Experience Seating segment and $5 million related to Corporate assets. In addition, the Company recorded $43 million of asset and investment impairments within discontinued operations in the third quarter of fiscal 2014 related to the divestiture of the Automotive Experience Electronics business. Refer to Note 4, "Discontinued Operations," and Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairment was measured, depending on the asset, either under an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-16-000216:notes:45]
At September 30, 2016,  2015 and 2014, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets. Refer to Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements for discussion of the Company’s goodwill impairment testing. Refer to Note 7, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for further information regarding the goodwill impairment charges recorded in the fourth quarter of fiscal 2014.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000833444-16-000216:notes:46]
The following unaudited pro forma information assumes the acquisition had occurred on October 1, 2014, and had been included in the Company's consolidated statements of income for fiscal years 2016 and 2015.

[0000833444-16-000216:notes:47]
|  |  | Year Ended September 30, |
| (in millions) |  | 2016 |  | 2015 |
| Pro forma net sales |  | $ | 46,484 |  |  | $ | 46,987 |  |
| Pro forma net income (loss) from continuing operations |  | (457 | ) |  | 1,473 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000833444-16-000216:notes:48]
Cash and Cash Equivalents

[0000833444-16-000216:notes:49]
The Company considers all highly liquid investments with an original maturity of three months or less when purchased to be cash equivalents.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-16-000216:notes:50]
COMMITMENTS AND CONTINGENCIES

[0000833444-16-000216:notes:51]
Environmental Matters

[0000833444-16-000216:notes:52]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of September 30, 2016, reserves for environmental liabilities totaled $55 million, of which $15 million was recorded within other current liabilities and $40 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities totaled $23 million at  September 30, 2015. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities, primarily in the Power Solutions and Buildings businesses. At September 30, 2016 and 2015, the Company recorded conditional asset retirement obligations of $74 million and $59 million, respectively.

[0000833444-16-000216:notes:53]
Asbestos Matters

[0000833444-16-000216:notes:54]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-16-000216:notes:55]
As of September 30, 2016, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position is $148 million. The net liability within the consolidated statements of financial position is comprised of a liability for pending and future claims and related defense costs of $548 million, of which $35 million is recorded in other current liabilities and $513 million is recorded in other noncurrent liabilities. The Company also maintains separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $400 million, of which $41 million is recorded in other current assets, and $359 million is recorded in other noncurrent assets. Assets include $16 million of cash and $264 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2016 is $120 million. The Company believes that the asbestos related liabilities and insurance related receivables recorded as of September 30, 2016 are appropriate. As of September 30, 2015, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position is comprised of a liability for pending and future claims and related defense costs of $136 million and is primarily recorded in other noncurrent liabilities. There were no assets recorded related to the Company's asbestos obligations at September 30, 2015. The assets recorded in fiscal 2016 were as a result of assets acquired as part of the Tyco Merger.

[0000833444-16-000216:notes:56]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from  2069 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2069. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-16-000216:notes:57]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-16-000216:notes:58]
Insurable Liabilities

[0000833444-16-000216:notes:59]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At September 30, 2016 and 2015, the insurable liabilities totaled  $473 million and $194 million, respectively, of which $70 million and $28 million was recorded within other current liabilities, $36 million and $25 million was recorded within accrued compensation and benefits, and $367 million and $141 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The Company maintains captive insurance companies to manage certain of its insurable liabilities.

[0000833444-16-000216:notes:60]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000833444-16-000216:notes:61]
Loss Contingencies

[0000833444-16-000216:notes:62]
Accruals are recorded for various contingencies including legal proceedings, environmental matters, self-insurance and other claims that arise in the normal course of business. The accruals are based on judgment, the probability of losses and, where applicable, the consideration of opinions of internal and/or external legal counsel and actuarially determined estimates. Additionally, the Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-16-000216:notes:63]
The Company is subject to laws and regulations relating to protecting the environment. The Company provides for expenses associated with environmental remediation obligations when such amounts are probable and can be reasonably estimated. Refer to Note 23, "Commitments and Contingencies," of the notes to consolidated financial statements.

[0000833444-16-000216:notes:64]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company records receivables from third party insurers when recovery has been determined to be probable. The Company maintains captive insurance companies to manage certain of its insurable liabilities.

[0000833444-16-000216:notes:65]
Asbestos-Related Contingencies and Insurance Receivables

[0000833444-16-000216:notes:66]
The Company and certain of its subsidiaries along with numerous other companies are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from  2069 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2069. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-16-000216:notes:67]
In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable. The Company's estimate of asbestos-related insurance recoveries represents estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims discounted to present value. In determining the amount of insurance recoverable, the Company considers available insurance, allocation methodologies, solvency and creditworthiness of the insurers. Refer to Note 23, "Commitments and Contingencies," of the notes to consolidated financial statements for a discussion on management's judgments applied in the recognition and measurement of asbestos-related assets and liabilities.


## us-gaap:CondensedFinancialStatementsTextBlock

[0000833444-16-000216:notes:68]
TYCO INTERNATIONAL FINANCE S.A.

[0000833444-16-000216:notes:69]
Tyco International Finance S.A. ("TIFSA"), a 100% owned subsidiary of the Company, has public debt securities outstanding which are fully and unconditionally guaranteed by Johnson Controls and by Tyco Fire & Security Finance S.C.A. ("TIFSCA"), a wholly owned subsidiary of the Company and parent company TIFSA. The following tables present condensed consolidating financial information for Johnson Controls, TIFSCA, TIFSA and all other subsidiaries. Condensed financial information for the Company, TIFSCA and TIFSA on a stand-alone basis is presented using the equity method of accounting for subsidiaries.

[0000833444-16-000216:notes:70]
The TIFSA public debt securities were assumed as part of the Tyco acquisition.  Therefore, no consolidating financial information for the years ended September 30, 2015 and September 30, 2014 is presented related to the guarantee of the TIFSA public debt securities. Additional information regarding TIFSA and TIFSCA for the fiscal year ended September 25, 2015 and the period ended June 24, 2016 can be found in Tyco's Annual Report on Form 10-K filed with the SEC on November 13, 2015 (as recast in part in Tyco's Current Report on Form 8-K filed with the SEC on March 11, 2016) and Tyco's Quarterly report on Form 10-Q filed with the SEC on July 29, 2016, respectively.

[0000833444-16-000216:notes:71]
CONDENSED CONSOLIDATING STATEMENT OF OPERATIONS

[0000833444-16-000216:notes:72]
For the Year Ended September 30, 2016

[0000833444-16-000216:notes:73]
($ in millions)

[0000833444-16-000216:notes:74]
|  | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net sales | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 37,674 |  |  | $ | — |  |  | $ | 37,674 |  |
| Cost of sales | — |  |  | — |  |  | — |  |  | 30,360 |  |  | — |  |  | 30,360 |  |
| Gross profit | — |  |  | — |  |  | — |  |  | 7,314 |  |  | — |  |  | 7,314 |  |
| Selling, general and administrative expenses | (2 | ) |  | (2 | ) |  | (1 | ) |  | (5,320 | ) |  | — |  |  | (5,325 | ) |
| Restructuring and impairment costs | — |  |  | — |  |  | — |  |  | (620 | ) |  | — |  |  | (620 | ) |
| Net financing charges | — |  |  | — |  |  | (6 | ) |  | (308 | ) |  | — |  |  | (314 | ) |
| Equity income (loss) | (894 | ) |  | (1,527 | ) |  | (313 | ) |  | 531 |  |  | 2,734 |  |  | 531 |  |
| Intercompany interest and fees | 28 |  |  | — |  |  | 7 |  |  | (35 | ) |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes | (868 | ) |  | (1,529 | ) |  | (313 | ) |  | 1,562 |  |  | 2,734 |  |  | 1,586 |  |
| Income tax provision | — |  |  | — |  |  | — |  |  | 2,238 |  |  | — |  |  | 2,238 |  |
| Income (loss) from continuing operations | (868 | ) |  | (1,529 | ) |  | (313 | ) |  | (676 | ) |  | 2,734 |  |  | (652 | ) |
| Net income (loss) | (868 | ) |  | (1,529 | ) |  | (313 | ) |  | (676 | ) |  | 2,734 |  |  | (652 | ) |
| Income from continuing operations attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 216 |  |  | — |  |  | 216 |  |
| Net income (loss) attributable to Johnson Controls | $ | (868 | ) |  | $ | (1,529 | ) |  | $ | (313 | ) |  | $ | (892 | ) |  | $ | 2,734 |  |  | $ | (868 | ) |

[0000833444-16-000216:notes:75]
CONDENSED CONSOLIDATING STATEMENT OF COMPREHENSIVE INCOME

[0000833444-16-000216:notes:76]
| (in millions) | Johnson ControlsInternationalplc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net Income (loss) | $ | (868 | ) |  | $ | (1,529 | ) |  | $ | (313 | ) |  | $ | (676 | ) |  | $ | 2,734 |  |  | $ | (652 | ) |
| Other comprehensive income (loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments | (105 | ) |  | — |  |  | — |  |  | (83 | ) |  | 94 |  |  | (94 | ) |
| Realized and unrealized gains on derivatives | 11 |  |  | — |  |  | — |  |  | 7 |  |  | (9 | ) |  | 9 |  |
| Realized and unrealized losses on marketable common stock | (1 | ) |  | — |  |  | — |  |  | (1 | ) |  | 1 |  |  | (1 | ) |
| Pension and postretirement plans | (1 | ) |  | — |  |  | — |  |  | (1 | ) |  | 1 |  |  | (1 | ) |
| Other comprehensive loss | (96 | ) |  | — |  |  | — |  |  | (78 | ) |  | 87 |  |  | (87 | ) |
| Total comprehensive loss | (964 | ) |  | (1,529 | ) |  | (313 | ) |  | (754 | ) |  | 2,821 |  |  | (739 | ) |
| Comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 225 |  |  | — |  |  | 225 |  |
| Comprehensive loss attributable to Johnson Controls | $ | (964 | ) |  | $ | (1,529 | ) |  | $ | (313 | ) |  | $ | (979 | ) |  | $ | 2,821 |  |  | $ | (964 | ) |

[0000833444-16-000216:notes:77]
CONDENSED CONSOLIDATING STATEMENT OF FINANCIAL POSITION

[0000833444-16-000216:notes:78]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 11 |  |  | $ | — |  |  | $ | 244 |  |  | $ | 429 |  |  | $ | — |  |  | $ | 684 |  |
| Cash in escrow related to Adient debt | — |  |  | — |  |  | — |  |  | 2,034 |  |  | — |  |  | 2,034 |  |
| Accounts receivable, net | — |  |  | — |  |  | — |  |  | 8,018 |  |  | — |  |  | 8,018 |  |
| Inventories | — |  |  | — |  |  | — |  |  | 3,560 |  |  | — |  |  | 3,560 |  |
| Intercompany receivables | 16 |  |  | — |  |  | 2 |  |  | 6,188 |  |  | (6,206 | ) |  | — |  |
| Assets held for sale | — |  |  | — |  |  | — |  |  | 174 |  |  | — |  |  | 174 |  |
| Other current assets | 6 |  |  | — |  |  | 1 |  |  | 2,632 |  |  | — |  |  | 2,639 |  |
| Current assets | $ | 33 |  |  | $ | — |  |  | $ | 247 |  |  | $ | 23,035 |  |  | $ | (6,206 | ) |  | $ | 17,109 |  |
| Property, plant and equipment - net | — |  |  | — |  |  | — |  |  | 7,872 |  |  | — |  |  | 7,872 |  |
| Goodwill | — |  |  | — |  |  | 274 |  |  | 23,135 |  |  | — |  |  | 23,409 |  |
| Other intangible assets - net | — |  |  | — |  |  | — |  |  | 7,653 |  |  | — |  |  | 7,653 |  |
| Investments in partially-owned affiliates | — |  |  | — |  |  | — |  |  | 2,735 |  |  | — |  |  | 2,735 |  |
| Investments in affiliates | 12,460 |  |  | 31,405 |  |  | 27,906 |  |  | — |  |  | (71,771 | ) |  | — |  |
| Intercompany loans receivable | 18,680 |  |  | — |  |  | 13,336 |  |  | 15,631 |  |  | (47,647 | ) |  | — |  |
| Other noncurrent assets | — |  |  | — |  |  | — |  |  | 4,475 |  |  | — |  |  | 4,475 |  |
| Total assets | $ | 31,173 |  |  | $ | 31,405 |  |  | $ | 41,763 |  |  | $ | 84,536 |  |  | $ | (125,624 | ) |  | $ | 63,253 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,119 |  |  | $ | — |  |  | $ | 1,119 |  |
| Current portion of long-term debt | — |  |  | — |  |  | — |  |  | 628 |  |  | — |  |  | 628 |  |
| Accounts payable | 1 |  |  | — |  |  | — |  |  | 6,763 |  |  | — |  |  | 6,764 |  |
| Accrued compensation and benefits | — |  |  | — |  |  | — |  |  | 1,763 |  |  | — |  |  | 1,763 |  |
| Liabilities held for sale | — |  |  | — |  |  | — |  |  | 28 |  |  | — |  |  | 28 |  |
| Intercompany payables | 3,873 |  |  | — |  |  | 2,315 |  |  | 18 |  |  | (6,206 | ) |  | — |  |
| Other current liabilities | 3 |  |  | 2 |  |  | 32 |  |  | 5,954 |  |  | — |  |  | 5,991 |  |
| Current liabilities | 3,877 |  |  | 2 |  |  | 2,347 |  |  | 16,273 |  |  | (6,206 | ) |  | 16,293 |  |
| Long-term debt | — |  |  | — |  |  | 2,413 |  |  | 12,193 |  |  | — |  |  | 14,606 |  |
| Pension and postretirement benefits | — |  |  | — |  |  | — |  |  | 1,738 |  |  | — |  |  | 1,738 |  |
| Intercompany loans payable | 3,178 |  |  | 18,680 |  |  | 12,453 |  |  | 13,336 |  |  | (47,647 | ) |  | — |  |
| Other noncurrent liabilities | — |  |  | — |  |  | 22 |  |  | 5,270 |  |  | — |  |  | 5,292 |  |
| Long-term liabilities | 3,178 |  |  | 18,680 |  |  | 14,888 |  |  | 32,537 |  |  | (47,647 | ) |  | 21,636 |  |
| Redeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 234 |  |  | — |  |  | 234 |  |
| Ordinary shares | 9 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 9 |  |
| Ordinary shares held in treasury | (20 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (20 | ) |
| Other shareholders' equity | 24,129 |  |  | 12,723 |  |  | 24,528 |  |  | 34,520 |  |  | (71,771 | ) |  | 24,129 |  |
| Shareholders’ equity attributable to Johnson Controls | 24,118 |  |  | 12,723 |  |  | 24,528 |  |  | 34,520 |  |  | (71,771 | ) |  | 24,118 |  |
| Nonredeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 972 |  |  | — |  |  | 972 |  |
| Total equity | 24,118 |  |  | 12,723 |  |  | 24,528 |  |  | 35,492 |  |  | (71,771 | ) |  | 25,090 |  |
| Total liabilities, redeemable noncontrolling interest and equity | $ | 31,173 |  |  | $ | 31,405 |  |  | $ | 41,763 |  |  | $ | 84,536 |  |  | $ | (125,624 | ) |  | $ | 63,253 |  |

[0000833444-16-000216:notes:79]
CONDENSED CONSOLIDATING STATEMENT OF CASH FLOWS

[0000833444-16-000216:notes:80]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Operating Activities |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities | $ | 11 |  |  | $ | — |  |  | $ | 639 |  |  | $ | 1,245 |  |  | $ | — |  |  | $ | 1,895 |  |
| Investing Activities |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | — |  |  | (1,249 | ) |  | — |  |  | (1,249 | ) |
| Sale of property, plant and equipment | — |  |  | — |  |  | — |  |  | 32 |  |  | — |  |  | 32 |  |
| Acquisition of business, net of cash acquired | — |  |  | — |  |  | — |  |  | 353 |  |  | — |  |  | 353 |  |
| Business divestitures | — |  |  | — |  |  | — |  |  | 32 |  |  | — |  |  | 32 |  |
| Changes in long-term investments | — |  |  | — |  |  | 57 |  |  | (105 | ) |  | — |  |  | (48 | ) |
| Net change in intercompany loans | — |  |  | — |  |  | 10 |  |  | — |  |  | (10 | ) |  | — |  |
| Other | — |  |  | — |  |  | — |  |  | (7 | ) |  | — |  |  | (7 | ) |
| Net cash provided (used) by investing activities | — |  |  | — |  |  | 67 |  |  | (944 | ) |  | (10 | ) |  | (887 | ) |
| Financing Activities |  |  |  |  |  |  |  |  |  |  |  |
| Increase (decrease) in short-term debt - net | — |  |  | — |  |  | (462 | ) |  | 1,018 |  |  | — |  |  | 556 |  |
| Increase in long-term debt | — |  |  | — |  |  | — |  |  | 1,501 |  |  | — |  |  | 1,501 |  |
| Repayment of long-term debt | — |  |  | — |  |  | — |  |  | (1,299 | ) |  | — |  |  | (1,299 | ) |
| Debt financing costs | — |  |  | — |  |  | — |  |  | (45 | ) |  | — |  |  | (45 | ) |
| Stock repurchases | — |  |  | — |  |  | — |  |  | (501 | ) |  | — |  |  | (501 | ) |
| Payment of cash dividends | — |  |  | — |  |  | — |  |  | (915 | ) |  | — |  |  | (915 | ) |
| Proceeds from the exercise of stock options | 3 |  |  | — |  |  | — |  |  | 67 |  |  | — |  |  | 70 |  |
| Net intercompany loan borrowings (repayments) | — |  |  | — |  |  | — |  |  | (10 | ) |  | 10 |  |  | — |  |
| Cash paid to acquire a noncontrolling interest | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Dividends paid to noncontrolling interests | — |  |  | — |  |  | — |  |  | (306 | ) |  | — |  |  | (306 | ) |
| Other | (3 | ) |  | — |  |  | — |  |  | 11 |  |  | — |  |  | 8 |  |
| Net cash provided (used) in financing activities | — |  |  | — |  |  | (462 | ) |  | (481 | ) |  | 10 |  |  | (933 | ) |
| Effect of currency translation on cash | — |  |  | — |  |  | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Increase (decrease) in cash and cash equivalents | 11 |  |  | — |  |  | 244 |  |  | (168 | ) |  | — |  |  | 87 |  |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | — |  |  | 597 |  |  | — |  |  | 597 |  |
| Cash and cash equivalents at end of period | $ | 11 |  |  | $ | — |  |  | $ | 244 |  |  | $ | 429 |  |  | $ | — |  |  | $ | 684 |  |


## us-gaap:ConsolidationPolicyTextBlock

[0000833444-16-000216:notes:81]
Principles of Consolidation

[0000833444-16-000216:notes:82]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc., a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). The financial statements have been prepared in United States dollars ("USD") and in accordance with generally accepted accounting principles in the United States (U.S. GAAP). All significant intercompany transactions have been eliminated. The results of companies acquired or disposed of during the year are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company’s interest exceeds 20% and the Company does not have a controlling interest.

[0000833444-16-000216:notes:83]
Under certain criteria as provided for in Financial Accounting Standards Board (FASB) Accounting Standards Codification (ASC) 810, "Consolidation," the Company may consolidate a partially-owned affiliate. To determine whether to consolidate a partially-owned affiliate, the Company first determines if the entity is a variable interest entity (VIE). An entity is considered to be a VIE if it has one of the following characteristics: 1) the entity is thinly capitalized; 2) residual equity holders do not control the entity; 3) equity holders are shielded from economic losses or do not participate fully in the entity’s residual economics; or 4) the entity was established with non-substantive voting. If the entity meets one of these characteristics, the Company then determines if it is the primary beneficiary of the VIE. The party with the power to direct activities of the VIE that most significantly impact the VIE’s economic performance and the potential to absorb benefits or losses that could be significant to the VIE is considered the primary beneficiary and consolidates the VIE. If the entity is not considered a VIE, then the Company applies the voting interest model to determine whether or not the Company shall consolidate the partially-owned affiliate.

[0000833444-16-000216:notes:84]
Consolidated VIEs

[0000833444-16-000216:notes:85]
Based upon the criteria set forth in ASC 810, the Company has determined that it was the primary beneficiary in three VIEs for the reporting periods ended September 30, 2016 and 2015, as the Company absorbs significant economics of the entities and has the power to direct the activities that are considered most significant to the entities.

[0000833444-16-000216:notes:86]
Two of the VIEs manufacture products in North America for the automotive industry. The Company funds the entities’ short-term liquidity needs through revolving credit facilities and has the power to direct the activities that are considered most significant to the entities through its key customer supply relationships.

[0000833444-16-000216:notes:87]
In fiscal 2012, a pre-existing VIE accounted for under the equity method was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The Company acquired additional interests in two of the reorganized group entities. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is considered the primary beneficiary of one of the entities due to the Company’s power pertaining to decisions over significant activities of the entity. As such, this VIE has been consolidated within the Company’s consolidated statements of financial position. The impact of consolidation of the entity on the Company’s consolidated statements of income for the years ended September 30, 2016, 2015 and 2014 was not material. The VIE is named as a co-obligor under a third party debt agreement of $170 million, maturing in fiscal 2020, under which it could become subject to paying more than its allocated share of the third party debt in the event of bankruptcy of one or more of the other co-obligors. The other co-obligors, all related parties in which the Company is an equity investor, consist of the remaining group entities involved in the reorganization. As part of the overall reorganization transaction, the Company has also provided financial support to the group entities in the form of loans totaling $37 million, which are subordinate to the third party debt agreement. The Company is a significant customer of certain co-obligors, resulting in a remote possibility of loss. Additionally, the Company is subject to a floor guaranty expiring in fiscal 2022; in the event that the other owner party no longer owns any part of the group entities due to sale or transfer, the Company has guaranteed that the proceeds received from the sale or transfer will not be less than $25 million. The Company has partnered with the group entities to design and manufacture battery components for the Power Solutions business.

[0000833444-16-000216:notes:88]
The carrying amounts and classification of assets (none of which are restricted) and liabilities included in the Company’s consolidated statements of financial position for the consolidated VIEs are as follows (in millions):

[0000833444-16-000216:notes:89]
|  | September 30, |
|  | 2016 |  | 2015 |
| Current assets | $ | 284 |  |  | $ | 281 |  |
| Noncurrent assets | 98 |  |  | 128 |  |
| Total assets | $ | 382 |  |  | $ | 409 |  |
| Current liabilities | $ | 230 |  |  | $ | 232 |  |
| Noncurrent liabilities | 29 |  |  | 34 |  |
| Total liabilities | $ | 259 |  |  | $ | 266 |  |

[0000833444-16-000216:notes:90]
The Company did not have a significant variable interest in any other consolidated VIEs for the presented reporting periods.

[0000833444-16-000216:notes:91]
Nonconsolidated VIEs

[0000833444-16-000216:notes:92]
As mentioned previously within the "Consolidated VIEs" section above, in fiscal 2012, a pre-existing VIE was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is not considered to be the primary beneficiary of two of the entities as the Company cannot make key operating decisions considered to be most significant to the VIEs. Therefore, the entities are accounted for under the equity method of accounting as the Company’s interest exceeds 20% and the Company does not have a controlling interest. The Company’s maximum exposure to loss includes the partially-owned affiliate investment balance of $59 million and $62 million at September 30, 2016 and 2015, respectively, as well as the subordinated loan from the Company, third party debt agreement and floor guaranty mentioned previously within the "Consolidated VIEs" section above. Current liabilities due to the VIEs are not material and represent normal course of business trade payables for all presented periods.

[0000833444-16-000216:notes:93]
The Company did not have a significant variable interest in any other nonconsolidated VIEs for the presented reporting periods.


## us-gaap:DebtDisclosureTextBlock

[0000833444-16-000216:notes:94]
DEBT AND FINANCING ARRANGEMENTS

[0000833444-16-000216:notes:95]
Short-term debt consisted of the following (in millions):

[0000833444-16-000216:notes:96]
|  | September 30, |
|  | 2016 |  | 2015 |
| Bank borrowings and commercial paper | $ | 1,119 |  |  | $ | 52 |  |
| Weighted average interest rate on short-term debt outstanding | 1.3 | % |  | 7.2 | % |

[0000833444-16-000216:notes:97]
In connection with the Tyco merger, JCI Inc. replaced its $2.5 billion committed five-year credit facility scheduled to mature in August 2018 with a $2.0 billion committed four-year credit facility scheduled to mature in August 2020. Additionally, Tyco International Holding S.a.r.L. ("TSarl"), a wholly-owned subsidiary of Johnson Controls, entered into a $1.0 billion committed four-year credit facility scheduled to mature in August 2020. The facilities are used to support the Company's outstanding commercial paper. There were no draws on either committed credit facilities during the fiscal years ended September 30, 2016 and 2015. Average outstanding commercial paper for the fiscal year ended September 30, 2016 was $1,418 million, and there was $440 million outstanding as of September 30, 2016. Average outstanding commercial paper for the fiscal year ended September 30, 2015 was $1,537 million and there was none outstanding at September 30, 2015.

[0000833444-16-000216:notes:98]
In February 2016, the Company entered into a nine-month, $100 million floating rate term loan scheduled to mature in November 2016. Proceeds from the term loan were used for general corporate purposes.

[0000833444-16-000216:notes:99]
In February 2016, the Company terminated a 37 million euro committed revolving credit facility scheduled to mature in September 2016, and subsequently entered into a nine-month, 100 million euro, floating rate term loan scheduled to mature in October 2016. Proceeds from the term loan were used for general corporate purposes.

[0000833444-16-000216:notes:100]
In January 2016, the Company entered into a ten-month, $200 million, floating rate term loan scheduled to mature in October 2016. Proceeds from the term loan were used for general corporate purposes.

[0000833444-16-000216:notes:101]
In January 2016, the Company entered into a ten-month, $125 million, floating rate term loan scheduled to mature in October 2016. Proceeds from the term loan were used for general corporate purposes.

[0000833444-16-000216:notes:102]
Long-term debt consisted of the following (in millions; due dates by fiscal year):

[0000833444-16-000216:notes:103]
|  | September 30, |
|  | 2016 |  | 2015 |
| Unsecured notes |  |  |  |
| JCI Inc. - 5.5% due in 2016 ($800 million par value) | — |  |  | 800 |  |
| JCI Inc. - 7.125% due in 2017 ($150 million par value) | 149 |  |  | 153 |  |
| JCI Inc. - 2.6% due in 2017 ($400 million par value) | 404 |  |  | 404 |  |
| JCI Inc. - 2.355% due in 2017 ($46 million par value) | 46 |  |  | 46 |  |
| JCI Inc. - 1.4% due in 2018 ($300 million par value) | 301 |  |  | 303 |  |
| JCI Inc. - 5.0% due in 2020 ($500 million par value) | 499 |  |  | 499 |  |
| JCI Inc. - 4.25% due 2021 ($500 million par value) | 498 |  |  | 498 |  |
| JCI Inc. - 3.75% due in 2022 ($450 million par value) | 448 |  |  | 448 |  |
| JCI Inc. - 3.625% due in 2024 ($500 million par value) | 500 |  |  | 500 |  |
| JCI Inc. - 6.0% due in 2036 ($400 million par value) | 396 |  |  | 395 |  |
| JCI Inc. - 5.7% due in 2041 ($300 million par value) | 299 |  |  | 299 |  |
| JCI Inc. - 5.25% due in 2042 ($250 million par value) | 250 |  |  | 250 |  |
| JCI Inc. - 4.625% due in 2044 ($450 million par value) | 447 |  |  | 447 |  |
| JCI Inc. - 6.95% due in 2046 ($125 million par value) | 125 |  |  | 125 |  |
| JCI Inc. - 4.95% due in 2064 ($450 million par value) | 449 |  |  | 449 |  |
| Tyco International Finance S.A. ("TIFSA") - 3.75% due in 2018 ($67 million par value) | 69 |  |  | — |  |
| TIFSA - 4.625% due in 2023 ($42 million par value) | 46 |  |  | — |  |
| TIFSA - 1.375% due in 2025 (EUR 500 million par value) | 571 |  |  | — |  |
| TIFSA - 3.90% due in 2026 ($750 million par value) | 824 |  |  | — |  |
| TIFSA - 5.125% due in 2045 ($750 million par value) | 903 |  |  | — |  |
| Adient - 3.5% due in 2024 (EUR 1,000 million par value) | 1,119 |  |  | — |  |
| Adient - 4.875% due in 2026 ($900 million par value) | 900 |  |  | — |  |
| TSarl - Term Loan A - LIBOR plus 1.50% due in 2020 | 4,000 |  |  | — |  |
| Adient - Term Loan A - LIBOR plus 1.005% due in 2021 | 1,500 |  |  | — |  |
| Capital lease obligations | 24 |  |  | 48 |  |
| Other foreign-denominated debt |  |  |  |
| Euro | 61 |  |  | 529 |  |
| Japanese Yen | 367 |  |  | 308 |  |
| Other | 39 |  |  | 57 |  |
| Gross long-term debt | 15,234 |  |  | 6,558 |  |
| Less: current portion | 628 |  |  | 813 |  |
| Net long-term debt | $ | 14,606 |  |  | $ | 5,745 |  |

[0000833444-16-000216:notes:104]
At September 30, 2016, the Company’s other foreign-denominated long-term debt was at fixed and floating rates with a weighted-average interest rate of 1.3%. At September 30, 2015, the Company’s other foreign-denominated long-term debt was at fixed and floating rates with a weighted-average interest rate of 1.1%.

[0000833444-16-000216:notes:105]
The installments of long-term debt maturing in subsequent fiscal years are: 2017 - $628 million; 2018 - $379 million; 2019 - $0 million; 2020 - $4,906 million; 2021 - $1,999 million; 2022 and thereafter - $7,322 million. The Company’s long-term debt includes various financial covenants, none of which are expected to restrict future operations.

[0000833444-16-000216:notes:106]
Total interest paid on both short and long-term debt for the fiscal years ended September 30, 2016, 2015 and 2014 was $319 million, $373 million and $314 million, respectively. The Company uses financial instruments to manage its interest rate exposure (see Note 10, "Derivative Instruments and Hedging Activities," and Note 11, "Fair Value Measurements," of the notes to consolidated financial statements). These instruments affect the weighted average interest rate of the Company’s debt and interest expense.

[0000833444-16-000216:notes:107]
Financing Arrangements

[0000833444-16-000216:notes:108]
Financing in connection with Tyco Merger

[0000833444-16-000216:notes:109]
Simultaneously with the closing of the Tyco merger on September 2, 2016, TSarl borrowed $4,000 million under the Term Loan Credit Agreement dated as of March 10, 2016 with a syndicate of lenders, providing for a three and a half year senior unsecured term loan facility to finance the cash consideration for, and fees, expenses and costs incurred in connection with the Merger.

[0000833444-16-000216:notes:110]
Financing in connection with Adient spin-off

[0000833444-16-000216:notes:111]
In August 2016, Adient Global Holdings, Ltd. (AGH), a wholly-owned subsidiary of the Company, issued a one billion euro,3.5% fixed rate, 8-year senior unsecured note scheduled to mature in August 2024. AGH also issued a $900 million, 4.875%, 10-year senior unsecured note scheduled to mature in August 2026. The proceeds from the notes were deposited into escrow and are expected to be released in connection with the spin-off. The notes have not been, and are not expected to be, guaranteed by the Company or any of its subsidiaries that will not be subsidiaries of Adient following the spin-off. Approximately $1,500 million of the proceeds will be distributed to the Company in connection with the spin-off and approximately $500 million of the proceeds will be used for Adient's general corporate purposes.

[0000833444-16-000216:notes:112]
In July 2016, AGH entered into a 5-year, $1,500 million Term A loan facility and a 5-year, $1,500 million revolving credit facility scheduled to mature in July 2021. The term loan was fully drawn in August 2016. As of September 30, 2016, there were no draws on the facility. Upon completion of the spin-off of Adient, AGH will become a wholly-owned subsidiary of Adient. On the date of the spin-off, Adient and certain of its wholly-owned subsidiaries will guarantee the debt, and the guarantees of the Company will automatically be released. The Company used the proceeds of the term loan to early repay its four tranches of euro-denominated floating rate credit facilities, totaling 390 million euro, that were outstanding as of September 30, 2015; three term loans of $500 million, $200 million and $125 million that were entered into during fiscal 2016, plus accrued interest, and a $90 million outstanding credit facility.  The remainder of the proceeds were used for general corporate purposes.

[0000833444-16-000216:notes:113]
Other financing arrangements

[0000833444-16-000216:notes:114]
At September 30, 2016, the Company had committed bilateral U.S. dollar denominated revolving credit facilities totaling $135 million, which are scheduled to expire in fiscal 2017. There were no draws on any of these revolving facilities in fiscal 2016.

[0000833444-16-000216:notes:115]
In January 2016, the Company retired $800 million in principal amount, plus accrued interest, of its 5.5% fixed rate notes that matured in January 2016.

[0000833444-16-000216:notes:116]
In September 2015, the Company retired, at maturity, $500 million, $150 million and $100 million floating rate term loans plus accrued interest that were entered into during fiscal 2015.

[0000833444-16-000216:notes:117]
In June 2015, the Company entered into a five-year, 37 billion yen floating rate syndicated term loan scheduled to mature in June 2020. Proceeds from the syndicated term loan were used for general corporate purposes.

[0000833444-16-000216:notes:118]
In May 2015, the Company made a partial repayment of 32 million euro in principal amount, plus accrued interest, of its 70 million euro floating rate credit facility scheduled to mature in November 2017. The remaining outstanding portion as of September 30, 2015 was repaid during fiscal 2016.

[0000833444-16-000216:notes:119]
In March 2015, the Company retired $125 million in principal amount, plus accrued interest, of its 7.7%fixed rate notes that matured in March 2015.

[0000833444-16-000216:notes:120]
In January 2015, the Company entered into a one-year, $90 million, committed revolving credit facility scheduled to mature in January 2016. The Company drew on the full credit facility during the quarter ended March 31, 2015. Proceeds from the revolving credit facility were used for general corporate purposes. The $90 million was repaid in September 2015.

[0000833444-16-000216:notes:121]
Net Financing Charges


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-16-000216:notes:122]
DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES

[0000833444-16-000216:notes:123]
The Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities, stock-based compensation liabilities and interest rates. Under Company policy, the use of derivatives is restricted to those intended for hedging purposes; the use of any derivative instrument for speculative purposes is strictly prohibited. A description of each type of derivative utilized by the Company to manage risk is included in the following paragraphs. In addition, refer to Note 11, "Fair Value Measurements," of the notes to consolidated financial statements for information related to the fair value measurements and valuation methods utilized by the Company for each derivative type.

[0000833444-16-000216:notes:124]
Cash Flow Hedges

[0000833444-16-000216:notes:125]
The Company has global operations and participates in the foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange hedge contracts. The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. As cash flow hedges under ASC 815, "Derivatives and Hedging," the effective portion of the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. Any ineffective portion of the hedge is reflected in the consolidated statements of income. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates at September 30, 2016 and 2015.

[0000833444-16-000216:notes:126]
The Company selectively hedges anticipated transactions that are subject to commodity price risk, primarily using commodity hedge contracts, to minimize overall price risk associated with the Company’s purchases of lead, copper, tin and aluminum in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. As cash flow hedges, the effective portion of the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions, typically sales, occur and affect earnings. Any ineffective portion of the hedge is reflected in the consolidated statements of income. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in commodity prices at September 30, 2016 and 2015.

[0000833444-16-000216:notes:127]
In September 2005, the Company entered into three forward treasury lock agreements to reduce the market risk associated with changes in interest rates associated with the Company’s anticipated fixed-rate note issuance to finance the acquisition of York International Corp. (cash flow hedge). The three forward treasury lock agreements, which had a combined notional amount of $1.3 billion, fixed a portion of the future interest cost for 5-year, 10-year and 30-year notes. The fair value of each treasury lock agreement, or the difference between the treasury lock reference rate and the fixed rate at time of note issuance, is amortized to interest expense over the life of the respective note issuance. In January 2006, in connection with the Company’s debt refinancing, the three forward treasury lock agreements were terminated.

[0000833444-16-000216:notes:128]
Fair Value Hedges

[0000833444-16-000216:notes:129]
The Company selectively uses interest rate swaps to reduce market risk associated with changes in interest rates for its fixed-rate bonds. Changes in the fair value of the swap and hedged portion of the debt are recorded in the consolidated statements of income. In the fourth quarter of fiscal 2013, the Company entered into four fixed to floating interest rate swaps totaling $800 million to hedge the coupon of its 5.5% notes that matured in January 2016. In the third quarter of fiscal 2014, the Company entered into four fixed to floating interest rate swaps totaling $400 million to hedge the coupon of its 2.6% notes maturing December 2016, three fixed to floating interest rate swaps totaling $300 million to hedge the coupon of its 1.4% notes maturing November 2017 and one fixed to floating interest rate swap totaling $150 million to hedge the coupon of its 7.125% notes maturing July 2017. There were eight and twelve interest rate swaps outstanding as of September 30, 2016 and 2015, respectively.

[0000833444-16-000216:notes:130]
Net Investment Hedges

[0000833444-16-000216:notes:131]
The Company enters into cross-currency interest rate swaps and foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the cross-currency interest rate swaps and debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally. At September 30, 2016, the Company had 37 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan and a one billion euro and 500 million euro bonds designated as net investment hedges in the Company's net investment in Europe. The Company had no cross-currency interest rate swaps outstanding at September 30, 2016. At September 30, 2015, the Company had four cross-currency interest rate swaps outstanding totaling 20 billion yen. The Company did not have any foreign denominated debt outstanding designated as a net investment hedge at September 30, 2015.

[0000833444-16-000216:notes:132]
Derivatives Not Designated as Hedging Instruments

[0000833444-16-000216:notes:133]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount. As of September 30, 2016 the Company had no equity swaps outstanding as a result of the Tyco Merger and proposed spin-off. As of September 30, 2015, the Company had hedged approximately 4.0 million shares of its common stock.

[0000833444-16-000216:notes:134]
The Company also holds certain foreign currency forward contracts which do not qualify for hedge accounting treatment. The change in fair value of foreign currency exchange derivatives not designated as hedging instruments under ASC 815 are recorded in the consolidated statements of income.

[0000833444-16-000216:notes:135]
Fair Value of Derivative Instruments

[0000833444-16-000216:notes:136]
The following table presents the location and fair values of derivative instruments and hedging activities included in the Company’s consolidated statements of financial position (in millions):

[0000833444-16-000216:notes:137]
|  | Derivatives and Hedging ActivitiesDesignated as Hedging Instrumentsunder ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instrumentsunder ASC 815 |
|  | September 30, 2016 |  | September 30, 2015 |  | September 30, 2016 |  | September 30, 2015 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 41 |  |  | $ | 31 |  |  | $ | 49 |  |  | $ | 27 |  |
| Commodity derivatives | 4 |  |  | — |  |  | — |  |  | — |  |
| Interest rate swaps | — |  |  | 1 |  |  | — |  |  | — |  |
| Cross-currency interest rate swaps | — |  |  | 5 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Interest rate swaps | 1 |  |  | 5 |  |  | — |  |  | — |  |
| Equity swap | — |  |  | — |  |  | — |  |  | 164 |  |
| Total assets | $ | 46 |  |  | $ | 42 |  |  | $ | 49 |  |  | $ | 191 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 48 |  |  | $ | 37 |  |  | $ | 23 |  |  | $ | 26 |  |
| Commodity derivatives | — |  |  | 7 |  |  | — |  |  | — |  |
| Cross-currency interest rate swaps | — |  |  | 1 |  |  | — |  |  | — |  |
| Current portion of long-term debt |  |  |  |  |  |  |  |
| Fixed rate debt swapped to floating | 551 |  |  | 801 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 2,057 |  |  | — |  |  | — |  |  | — |  |
| Fixed rate debt swapped to floating | 301 |  |  | 855 |  |  | — |  |  | — |  |
| Total liabilities | $ | 2,957 |  |  | $ | 1,701 |  |  | $ | 23 |  |  | $ | 26 |  |

[0000833444-16-000216:notes:138]
Counterparty Credit Risk

[0000833444-16-000216:notes:139]
The use of derivative financial instruments exposes the Company to counterparty credit risk. The Company has established policies and procedures to limit the potential for counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association (ISDA) master netting agreements with substantially all of its counterparties. The Company's derivative contracts do not contain any credit risk related contingent features and do not require collateral or other security to be furnished by the Company or the counterparties. The Company's exposure to credit risk associated with its derivative instruments is measured on an individual counterparty basis, as well as by groups of counterparties that share similar attributes. The Company does not anticipate any non-performance by any of its counterparties, and the concentration of risk with financial institutions does not present significant credit risk to the Company.

[0000833444-16-000216:notes:140]
The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position. Collateral is generally not required of the Company or the counterparties under the master netting agreements. As of September 30, 2016 and September 30, 2015, no cash collateral was received or pledged under the master netting agreements.

[0000833444-16-000216:notes:141]
Derivatives Impact on the Statements of Income and Statements of Comprehensive Income

[0000833444-16-000216:notes:142]
The following table presents the effective portion of pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges for the fiscal years ended September 30, 2016, 2015 and 2014 (in millions):

[0000833444-16-000216:notes:143]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Year Ended September 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Foreign currency exchange derivatives |  | $ | (18 | ) |  | $ | (5 | ) |  | $ | 1 |  |
| Commodity derivatives |  | 3 |  |  | (19 | ) |  | (7 | ) |
| Total |  | $ | (15 | ) |  | $ | (24 | ) |  | $ | (6 | ) |

[0000833444-16-000216:notes:144]
The following tables presents the location and amount of the effective portion of pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income for the fiscal years ended September 30, 2016, 2015 and 2014 (in millions):

[0000833444-16-000216:notes:145]
| Derivatives in ASC 815 Cash FlowHedging Relationships |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Year Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (21 | ) |  | $ | 1 |  |  | $ | (2 | ) |
| Commodity derivatives |  | Cost of sales |  | (12 | ) |  | (11 | ) |  | 1 |  |
| Forward treasury locks |  | Net financing charges |  | 1 |  |  | 1 |  |  | 1 |  |
| Total |  |  |  | $ | (32 | ) |  | $ | (9 | ) |  | $ | — |  |

[0000833444-16-000216:notes:146]
The following table presents the location and amount of pre-tax gains (losses) on fair value hedges recognized in the Company’s consolidated statements of income for the fiscal years ended September 30, 2016, 2015 and 2014 (in millions):

[0000833444-16-000216:notes:147]
| Derivatives in ASC 815 Fair Value Hedging Relationships |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Year Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Interest rate swap |  | Net financing charges |  | $ | (5 | ) |  | $ | 7 |  |  | $ | 5 |  |
| Fixed rate debt swapped to floating |  | Net financing charges |  | 5 |  |  | (7 | ) |  | (5 | ) |
| Total |  |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000833444-16-000216:notes:148]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income for the fiscal years ended September 30, 2016, 2015 and 2014 (in millions):

[0000833444-16-000216:notes:149]
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Year Ended September 30, |
|  |  | 2016 |  | 2015 |  | 2014 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (18 | ) |  | $ | (3 | ) |  | $ | 1 |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | (11 | ) |  | (12 | ) |  | 18 |  |
| Foreign currency exchange derivatives |  | Income tax provision |  | 4 |  |  | — |  |  | — |  |
| Equity swap |  | Selling, general and administrative |  | 14 |  |  | (9 | ) |  | (1 | ) |
| Total |  |  |  | $ | (11 | ) |  | $ | (24 | ) |  | $ | 18 |  |

[0000833444-16-000216:notes:150]
The effective portion of pre-tax gains (losses) recorded in foreign currency translation adjustment within other comprehensive income (loss) related to net investment hedges were $(82) million, $16 million and $24 million for the years ended September 30, 2016, 2015 and 2014, respectively. For the years ended September 30, 2016, 2015 and 2014, no gains or losses were reclassified from CTA into income for the Company’s outstanding net investment hedges, and no gains or losses were recognized in income for the ineffective portion of cash flow hedges.


## us-gaap:DerivativesPolicyTextBlock

[0000833444-16-000216:notes:151]
Derivative Financial Instruments

[0000833444-16-000216:notes:152]
The Company has written policies and procedures that place all financial instruments under the direction of Corporate treasury and restrict all derivative transactions to those intended for hedging purposes. The use of financial instruments for speculative purposes is strictly prohibited. The Company selectively uses financial instruments to manage the market risk from changes in foreign exchange rates, commodity prices, stock-based compensation liabilities and interest rates.

[0000833444-16-000216:notes:153]
The fair values of all derivatives are recorded in the consolidated statements of financial position. The change in a derivative’s fair value is recorded each period in current earnings or accumulated other comprehensive income (AOCI), depending on whether the derivative is designated as part of a hedge transaction and if so, the type of hedge transaction. See Note 10, "Derivative Instruments and Hedging Activities," and Note 11, "Fair Value Measurements," of the notes to consolidated financial statements for disclosure of the Company’s derivative instruments and hedging activities.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-16-000216:notes:154]
STOCK-BASED COMPENSATION

[0000833444-16-000216:notes:155]
On September 2, 2016, the shareholders of the Company approved the Johnson Controls International plc 2012 Share and Incentive Plan (the "Plan"). The original effective date of this Plan was October 1, 2012. The Plan was amended and restated as of November 17, 2014 and was amended and restated again in connection with the Merger that was consummated on September 2, 2016 (the “Amendment Effective Date”). The amendment and restatement is intended to reflect the assumption into this Plan of the remaining share reserves under the Johnson Controls, Inc. 2012 Omnibus Incentive Plan and the Johnson Controls, Inc. 2003 Stock Plan for Outside Directors (the “Legacy Johnson Controls Plans”) as of the Amendment Effective Date. Following the Amendment Effective Date, no further awards may be made under the Legacy Johnson Controls Plans. The types of awards authorized by the Plan comprise of stock options, stock appreciation rights, performance shares, performance units and other stock-based awards. The Compensation Committee of the Company's Board of Directors will determine the types of awards to be granted to individual participants and the terms and conditions of the awards. The Plan provides that 76 million shares of the Company's common stock are reserved for issuance under the 2012 Plan, and 46 million shares remain available for issuance at September 30, 2016.

[0000833444-16-000216:notes:156]
Pursuant to the Merger Agreement, outstanding stock options held by Tyco employees on September 2, 2016 (the “Merger Date”) were converted into options to acquire the Company's shares using a 0.955-for-one share consolidation ratio in a manner designed to preserve the intrinsic value of such awards. In addition, pursuant to the Merger Agreement, nonvested restricted stock held by Tyco employees on the Merger Date were converted into nonvested restricted stock of the Company using the 0.955-for-one share consolidation ratio in a manner designed to preserve the intrinsic value of such awards. Outstanding performance share awards held by Tyco employees on the Merger Date were converted to nonvested restricted stock of the Company at the target performance level, and adjusted to reflect the 0.955-for-one consolidation ratio. Except for the conversion of stock options, nonvested restricted stock and performance share awards discussed herein, the material terms of the awards remained unchanged. The modifications made to the awards upon the Merger Date constituted modifications under the authoritative guidance for accounting for stock compensation. This guidance requires the Company to revalue the awards upon the Merger close and allocate the revised fair value between purchase consideration and continuing expense based on the ratio of service performed through the Merger Date over the total service period of the awards. The revised fair value allocated to post-merger services resulted in incremental expense which is recognized over the remaining service period of the awards. The portion of Tyco awards earned as of the Merger Date included as purchase consideration was $224 million. The total value of Tyco awards not earned as of the Merger Date was $101 million, which will be expensed over the remaining future vesting period. Of this amount, $10 million was recorded in selling, general and administrative expenses and $23 million was recorded in restructuring and impairment costs in the consolidated statement of income for the fiscal year ended September 30, 2016 as a result of change-in-control provisions for current and former employees. Refer to Note 2, “Merger Transaction,” of the notes to consolidated financial statements for further information regarding the Merger.

[0000833444-16-000216:notes:157]
Pursuant to the Merger Agreement, outstanding stock options held by JCI Inc. employees on the Merger Date were converted one-for-one into options to acquire the Company's shares in a manner designed to preserve the intrinsic value of such awards. In addition, pursuant to the Merger Agreement, nonvested restricted stock held by JCI Inc. employees on the Merger Date was converted one-for-one into nonvested restricted stock of the Company in a manner designed to preserve the intrinsic value of such awards. Outstanding performance share awards held by JCI Inc. employees on the Merger Date were converted to nonvested restricted stock of the Company based on certain performance factors. Except for the conversion of stock options, nonvested restricted stock and performance share awards discussed herein, the material terms of the awards remained unchanged, and no incremental fair value resulted from the conversion. References to the Company’s stock throughout Note 12 refer to stock of JCI Inc. prior to the Merger Date and to stock of the Company subsequent to the Merger Date.

[0000833444-16-000216:notes:158]
The Company has four share-based compensation plans, which are described below. For the fiscal year ended September 30, 2016, compensation cost charged against income, excluding the offsetting impact of outstanding equity swaps, for those plans was approximately $176 million, of which $137 million was recorded in selling, general and administrative expenses and $39 million was recorded in restructuring and impairment costs.  For the fiscal years ended September 30, 2015 and 2014, compensation cost charged against income, excluding the offsetting impact of outstanding equity swaps, for those plans was approximately $85 million and $81 million, respectively, all of which was recorded in selling, general and administrative expenses. The total income tax benefit recognized in the consolidated statements of income for share-based compensation arrangements was approximately $62 million, $34 million and $32 million for the fiscal years ended September 30, 2016, 2015 and 2014, respectively. The Company applies a non-substantive vesting period approach whereby expense is accelerated for those employees that receive awards and are eligible to retire prior to the award vesting.

[0000833444-16-000216:notes:159]
Stock Options

[0000833444-16-000216:notes:160]
Stock options are granted with an exercise price equal to the market price of the Company’s stock at the date of grant. Stock option awards typically vest between two and three years after the grant date and expire ten years from the grant date.

[0000833444-16-000216:notes:161]
The fair value of each option is estimated on the date of grant using a Black-Scholes option valuation model that uses the assumptions noted in the following table. Expected volatilities are based on the historical volatility of the Company’s stock and other factors. The Company uses historical data to estimate option exercises and employee terminations within the valuation model. The expected term of options represents the period of time that options granted are expected to be outstanding. The risk-free rate for periods during the contractual life of the option is based on the U.S. Treasury yield curve in effect at the time of grant.

[0000833444-16-000216:notes:162]
|  | Year Ended September 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Expected life of option (years) | 6.4 |  | 6.6 |  | 6.7 |
| Risk-free interest rate | 1.64% - 1.70% |  | 1.61% - 1.93% |  | 1.92% |
| Expected volatility of the Company’s stock | 36.00% |  | 36.00% |  | 36.00% |
| Expected dividend yield on the Company’s stock | 2.11% |  | 2.02% |  | 2.17% |

[0000833444-16-000216:notes:163]
A summary of stock option activity at September 30, 2016, and changes for the year then ended, is presented below:

[0000833444-16-000216:notes:164]
|  | WeightedAverageOption Price |  | SharesSubject toOption |  | WeightedAverageRemainingContractualLife (years) |  | AggregateIntrinsicValue(in millions) |
| Outstanding, September 30, 2015 | $ | 31.17 |  |  | 13,039,240 |  |  |  |  |  |
| Granted | 43.83 |  |  | 961,705 |  |  |  |  |  |
| Acquired Tyco awards | 31.37 |  |  | 10,895,381 |  |  |  |  |  |
| Exercised | 27.93 |  |  | (2,393,703 | ) |  |  |  |  |
| Forfeited or expired | 42.90 |  |  | (170,390 | ) |  |  |  |  |
| Outstanding, September 30, 2016 | $ | 32.07 |  |  | 22,332,233 |  |  | 5.3 |  | $ | 327 |  |
| Exercisable, September 30, 2016 | $ | 28.30 |  |  | 15,745,714 |  |  | 4.4 |  | $ | 288 |  |

[0000833444-16-000216:notes:165]
The weighted-average grant-date fair value of options granted during the fiscal years ended September 30, 2016, 2015 and 2014 was $13.14, $15.51 and $14.70, respectively.

[0000833444-16-000216:notes:166]
The total intrinsic value of options exercised during the fiscal years ended September 30, 2016, 2015 and 2014 was approximately $39 million, $227 million and $135 million, respectively.

[0000833444-16-000216:notes:167]
In conjunction with the exercise of stock options granted, the Company received cash payments for the fiscal years ended September 30, 2016, 2015 and 2014 of approximately $70 million, $275 million and $186 million, respectively.

[0000833444-16-000216:notes:168]
The Company has elected to utilize the alternative transition method for calculating the tax effects of stock-based compensation. The alternative transition method includes computational guidance to establish the beginning balance of the additional paid-in capital pool (APIC Pool) related to the tax effects of employee stock-based compensation, and a simplified method to determine the subsequent impact on the APIC Pool for employee stock-based compensation awards that are vested and outstanding upon adoption of ASC 718, "Compensation - Stock Compensation." The tax benefit from the exercise of stock options, which is recorded in capital in excess of par value, was $11 million, $59 million and $34 million for the fiscal years ended September 30, 2016, 2015 and 2014, respectively. The Company does not settle stock options granted under share-based payment arrangements for cash.

[0000833444-16-000216:notes:169]
At September 30, 2016, the Company had approximately $26 million of total unrecognized compensation cost related to nonvested stock options granted. That cost is expected to be recognized over a weighted-average period of 1.2 years.

[0000833444-16-000216:notes:170]
Stock Appreciation Rights (SARs)

[0000833444-16-000216:notes:171]
SARs vest under the same terms and conditions as stock option awards; however, they are settled in cash for the difference between the market price on the date of exercise and the exercise price. As a result, SARs are recorded in the Company’s consolidated statements of financial position as a liability until the date of exercise.

[0000833444-16-000216:notes:172]
The fair value of each SAR award is estimated using a similar method described for stock options. The fair value of each SAR award is recalculated at the end of each reporting period and the liability and expense are adjusted based on the new fair value.

[0000833444-16-000216:notes:173]
A summary of SAR activity at September 30, 2016, and changes for the year then ended, is presented below:

[0000833444-16-000216:notes:174]
|  | WeightedAverageSAR Price |  | SharesSubject toSAR |  | WeightedAverageRemainingContractualLife (years) |  | AggregateIntrinsicValue(in millions) |
| Outstanding, September 30, 2015 | $ | 29.53 |  |  | 1,740,100 |  |  |  |  |  |
| Granted | 43.86 |  |  | 54,749 |  |  |  |  |  |
| Exercised | 27.41 |  |  | (494,480 | ) |  |  |  |  |
| Forfeited or expired | 36.33 |  |  | (99,204 | ) |  |  |  |  |
| Outstanding, September 30, 2016 | $ | 30.49 |  |  | 1,201,165 |  |  | 4.6 |  | $ | 19 |  |
| Exercisable, September 30, 2016 | $ | 29.23 |  |  | 1,114,543 |  |  | 4.3 |  | $ | 19 |  |

[0000833444-16-000216:notes:175]
In conjunction with the exercise of SARs granted, the Company made payments of $8 million, $19 million and $21 million during the fiscal years ended September 30, 2016, 2015 and 2014, respectively.

[0000833444-16-000216:notes:176]
Restricted (Nonvested) Stock

[0000833444-16-000216:notes:177]
The Plan provides for the award of restricted stock or restricted stock units to certain employees. These awards are typically share settled unless the employee is a non-U.S. employee or elects to defer settlement until retirement at which point the award would be settled in cash. Restricted awards typically vest after three years from the grant date. The Plan allows for different vesting terms on specific grants with approval by the Board of Directors.

[0000833444-16-000216:notes:178]
A summary of the status of the Company’s nonvested restricted stock awards at September 30, 2016, and changes for the fiscal year then ended, is presented below:

[0000833444-16-000216:notes:179]
|  | WeightedAveragePrice |  | Shares/UnitsSubject toRestriction |
| Nonvested, September 30, 2015 | $ | 45.75 |  |  | 2,370,155 |  |
| Granted | 45.49 |  |  | 4,052,020 |  |
| Acquired Tyco awards | 47.74 |  |  | 2,916,471 |  |
| Converted performance share awards * | 49.20 |  |  | 1,108,036 |  |
| Vested | 34.45 |  |  | (527,017 | ) |
| Forfeited | 45.83 |  |  | (353,621 | ) |
| Nonvested, September 30, 2016 | $ | 47.27 |  |  | 9,566,044 |  |

[0000833444-16-000216:notes:180]
* As of the Amendment Effective Date, performance share awards were converted to nonvested restricted stock based on certain performance factors.

[0000833444-16-000216:notes:181]
At September 30, 2016, the Company had approximately $182 million of total unrecognized compensation cost related to nonvested restricted stock arrangements granted. That cost is expected to be recognized over a weighted-average period of 2.0 years.

[0000833444-16-000216:notes:182]
Performance Share Awards

[0000833444-16-000216:notes:183]
The Plan permits the grant of performance-based share unit ("PSU") awards. The number of PSUs granted is equal to the PSU award value divided by the closing price of the Company's common stock at the grant date. The PSUs are generally contingent on the achievement of pre-determined performance goals over a three-year performance period as well as on the award holder's continuous employment until the vesting date. Each PSU that is earned will be settled with a share of the Company's common stock following the completion of the performance period, unless the award holder elected to defer a portion or all of the award until retirement which would then be settled in cash.

[0000833444-16-000216:notes:184]
A summary of the status of the Company’s nonvested PSUs at September 30, 2016, and changes for the fiscal year then ended, is presented below:

[0000833444-16-000216:notes:185]
|  | WeightedAveragePrice |  | Shares/UnitsSubject toPSU |
| Nonvested, September 30, 2015 | $ | 42.33 |  |  | 924,388 |  |
| Vested | 30.73 |  |  | (344,318 | ) |
| Forfeited | 49.73 |  |  | (21,305 | ) |
| Nonvested, September 02, 2016 | $ | 49.20 |  |  | 558,765 |  |
| Conversion to nonvested restricted stock * | 49.20 |  |  | (558,765 | ) |
| Nonvested, September 30, 2016 | $ | — |  |  | — |  |

[0000833444-16-000216:notes:186]
* As of the Amendment Effective Date, PSUs were converted to nonvested restricted stock.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-16-000216:notes:187]
DISCONTINUED OPERATIONS

[0000833444-16-000216:notes:188]
On March 31, 2015, the Company announced that it had reached a definitive agreement to sell the remainder of the GWS business to CBRE Group Inc. (CBRE), subject to regulatory and other approvals. The sale closed on September 1, 2015. The agreement includes a 10-year strategic relationship between the Company and CBRE. The Company is the preferred provider of HVAC equipment, building automation systems and related services to the portfolio of real estate and corporate facilities managed globally by CBRE and GWS. The Company also engages GWS for facility management services. The annual cash flows resulting from these activities with the legacy GWS business are not currently significant nor are they expected to become significant in the future.

[0000833444-16-000216:notes:189]
At March 31, 2015, the Company determined that its GWS segment met the criteria to be classified as a discontinued operation, The Company did not allocate any general corporate overhead to discontinued operations.

[0000833444-16-000216:notes:190]
There were no amounts related to the GWS business classified as discontinued operations for the fiscal year ended September 30, 2016. The following table summarizes the results of GWS, reclassified as discontinued operations for the fiscal years ended September 30, 2015 and 2014 (in millions):

[0000833444-16-000216:notes:191]
|  | Year Ended September 30, |
|  | 2015 |  | 2014 |
| Net sales | $ | 3,025 |  |  | $ | 4,079 |  |
| Income from discontinued operations before income taxes | 1,203 |  |  | 119 |  |
| Provision for income taxes on discontinued operations | 1,075 |  |  | 75 |  |
| Income from discontinued operations attributable to noncontrolling interests, net of tax | 4 |  |  | 15 |  |
| Income from discontinued operations | $ | 124 |  |  | $ | 29 |  |

[0000833444-16-000216:notes:192]
For the fiscal year ended September 30, 2015, the income from discontinued operations before income taxes included a $940 million gain on divestiture for the remainder of the GWS business, a $200 million gain on divestiture of the Company's interest in two GWS joint ventures and current year transaction costs of $87 million. For the fiscal year ended September 30, 2014, the income from discontinued operations before income taxes included a $25 million charge related to the indemnification of certain costs associated with a divested GWS business in 2004.

[0000833444-16-000216:notes:193]
The effective tax rate is different than the U.S. statutory rate for fiscal 2015 primarily due to $680 million tax expense for repatriation of cash and other tax reserves, and the tax consequences of the sale of the GWS joint ventures ($73 million) and the remaining business ($297 million).

[0000833444-16-000216:notes:194]
The effective tax rate is different than the U.S. statutory rate for fiscal 2014 primarily due to a tax charge of $35 million related to the change in the Company's assertion over reinvestment of foreign undistributed earnings as well as a non-benefited loss related to the indemnification of certain costs associated with a divested business in 2004, partially offset by foreign tax rate differentials.

[0000833444-16-000216:notes:195]
In the second quarter of fiscal 2014, the Company announced that it had reached a definitive agreement to sell the remainder of the Automotive Experience Electronics business to Visteon Corporation, subject to regulatory and other approvals. The sale closed on July 1, 2014. At March 31, 2014, the Company determined that the Automotive Experience Electronics segment met the criteria to be classified as a discontinued operation, which required retrospective application to financial information for all periods presented. The Company did not allocate any general corporate overhead to discontinued operations.

[0000833444-16-000216:notes:196]
There were no amounts related to the Automotive Experience Electronics business classified as discontinued operations for the fiscal years ended September 30, 2016 and 2015. The following table summarizes the results of the Automotive Experience Electronics business, classified as discontinued operations for the fiscal years ended September 30, 2014 (in millions):

[0000833444-16-000216:notes:197]
|  |  | Year Ended September 30, |
|  |  | 2014 |
| Net sales |  | $ | 1,027 |  |
| Loss from discontinued operations before income taxes |  | (8 | ) |
| Provision for income taxes on discontinued operations |  | 202 |  |
| Income from discontinued operations attributable to noncontrolling interests, net of tax |  | 8 |  |
| Loss from discontinued operations |  | $ | (218 | ) |

[0000833444-16-000216:notes:198]
For the year ended September 30, 2014, the discontinued operations before income taxes included divestiture-related losses of $80 million comprised of asset and investment impairment charges of $43 million, transaction costs of $27 million and severance obligations of $10 million.

[0000833444-16-000216:notes:199]
For the year ended September 30, 2014, the Company's effective tax rate for discontinued operations was different than the U.S. federal statutory rate primarily due to a second quarter discrete non-cash tax charge of $180 million related to the repatriation of foreign cash associated with the divestiture of the Electronics business and unbenefited foreign losses.

[0000833444-16-000216:notes:200]
At September 30, 2016, $157 million of assets and $28 million of liabilities related to the security business in South Africa of the Buildings Tyco segment were classified as held for sale. There is also $17 million of certain Corporate assets that were classified as held for sale.

[0000833444-16-000216:notes:201]
At September 30, 2015, $55 million of assets and $42 million of liabilities related to certain product lines of the Automotive Experience Interiors segment were classified as held for sale. At September 30, 2016, these product lines no longer met the criteria to be classified as held for sale.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000833444-16-000216:notes:202]
Earnings Per Share

[0000833444-16-000216:notes:203]
The Company presents both basic and diluted earnings per share (EPS) amounts. Basic EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of common shares outstanding during the reporting period. Diluted EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of common shares and common equivalent shares outstanding during the reporting period that are calculated using the treasury stock method for stock options and unvested restricted stock. See Note 13, "Earnings per Share," of the notes to consolidated financial statements for the calculation of earnings per share.


## us-gaap:EarningsPerShareTextBlock

[0000833444-16-000216:notes:204]
EARNINGS PER SHARE

[0000833444-16-000216:notes:205]
The Company presents both basic and diluted earnings per share (EPS) amounts. Basic EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares outstanding during the reporting period. Diluted EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares and ordinary equivalent shares outstanding during the reporting period that are calculated using the treasury stock method for stock options, unvested restricted stock and unvested performance share awards. The treasury stock method assumes that the Company uses the proceeds from the exercise of stock option awards to repurchase ordinary shares at the average market price during the period. The assumed proceeds under the treasury stock method include the purchase price that the grantee will pay in the future, compensation cost for future service that the Company has not yet recognized and any windfall tax benefits that would be credited to capital in excess of par value when the award generates a tax deduction. If there would be a shortfall resulting in a charge to capital in excess of par value, such an amount would be a reduction of the proceeds. For unvested restricted stock and unvested performance share awards, assumed proceeds under the treasury stock method would include unamortized compensation cost and windfall tax benefits or shortfalls.

[0000833444-16-000216:notes:206]
The following table reconciles the numerators and denominators used to calculate basic and diluted earnings per share (in millions):

[0000833444-16-000216:notes:207]
|  | Year Ended September 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Income (Loss) Available to Common Shareholders |  |  |  |  |  |
| Income (loss) from continuing operations | $ | (868 | ) |  | $ | 1,439 |  |  | $ | 1,404 |  |
| Income (loss) from discontinued operations | — |  |  | 124 |  |  | (189 | ) |
| Basic and diluted income (loss) available to common shareholders | $ | (868 | ) |  | $ | 1,563 |  |  | $ | 1,215 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |
| Basic weighted average shares outstanding | 667.4 |  |  | 655.2 |  |  | 666.9 |  |
| Effect of dilutive securities: |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | — |  |  | 6.3 |  |  | 7.9 |  |
| Diluted weighted average shares outstanding | 667.4 |  |  | 661.5 |  |  | 674.8 |  |
| Antidilutive Securities |  |  |  |  |  |
| Options to purchase common shares | — |  |  | 0.4 |  |  | 0.1 |  |

[0000833444-16-000216:notes:208]
For the twelve months ended September 30, 2016, the total number of potential dilutive shares due to stock options, unvested restricted stock and unvested performance share awards was 5.2 million. However, these items were not included in the computation of diluted loss per share for the twelve months ended September 30, 2016, since to do so would decrease the loss per share.

[0000833444-16-000216:notes:209]
During the three months ended September 30, 2016 and 2015, the Company declared a dividend of $0.29 and $0.26, respectively, per common share. During the twelve months ended September 30, 2016 and 2015, the Company declared four quarterly dividends totaling $1.16 and $1.04, respectively, per common share.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0000833444-16-000216:notes:210]
NONCONSOLIDATED PARTIALLY-OWNED AFFILIATES

[0000833444-16-000216:notes:211]
Investments in the net assets of nonconsolidated partially-owned affiliates are stated in the "Investments in partially-owned affiliates" line in the consolidated statements of financial position as of September 30, 2016 and 2015. Equity in the net income of nonconsolidated partially-owned affiliates is stated in the "Equity income" line in the consolidated statements of income for the years ended September 30, 2016, 2015 and 2014.

[0000833444-16-000216:notes:212]
The following table presents summarized financial data for the Company’s nonconsolidated partially-owned affiliates. The amounts included in the table below represent 100% of the results of operations of such nonconsolidated partially-owned affiliates accounted for under the equity method.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-16-000216:notes:213]
FAIR VALUE MEASUREMENTS

[0000833444-16-000216:notes:214]
ASC 820, "Fair Value Measurement," defines fair value as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. ASC 820 also establishes a three-level fair value hierarchy that prioritizes information used in developing assumptions when pricing an asset or liability as follows:

[0000833444-16-000216:notes:215]
Level 1: Observable inputs such as quoted prices in active markets;

[0000833444-16-000216:notes:216]
Level 2: Inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and

[0000833444-16-000216:notes:217]
Level 3: Unobservable inputs where there is little or no market data, which requires the reporting entity to develop its own assumptions.

[0000833444-16-000216:notes:218]
ASC 820 requires the use of observable market data, when available, in making fair value measurements. When inputs used to measure fair value fall within different levels of the hierarchy, the level within which the fair value measurement is categorized is based on the lowest level input that is significant to the fair value measurement.

[0000833444-16-000216:notes:219]
Recurring Fair Value Measurements

[0000833444-16-000216:notes:220]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value as of September 30, 2016 and 2015 (in millions):

[0000833444-16-000216:notes:221]
|  | Fair Value Measurements Using: |
|  | Total as ofSeptember 30, 2016 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 90 |  |  | $ | — |  |  | $ | 90 |  |  | $ | — |  |
| Commodity derivatives | 4 |  |  | — |  |  | 4 |  |  | — |  |
| Exchange traded funds (fixed income)1 | 15 |  |  | 15 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Interest rate swaps | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Investments in marketable common stock | 3 |  |  | 3 |  |  | — |  |  | — |  |
| Deferred compensation plan assets | 81 |  |  | 81 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 163 |  |  | 163 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 86 |  |  | 86 |  |  | — |  |  | — |  |
| Total assets | $ | 443 |  |  | $ | 348 |  |  | $ | 95 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 71 |  |  | $ | — |  |  | $ | 71 |  |  | $ | — |  |
| Current portion of long-term debt |  |  |  |  |  |  |  |
| Fixed rate debt swapped to floating | 551 |  |  | — |  |  | 551 |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 2,057 |  |  | 2,057 |  |  | — |  |  | — |  |
| Fixed rate debt swapped to floating | 301 |  |  | — |  |  | 301 |  |  | — |  |
| Total liabilities | $ | 2,980 |  |  | $ | 2,057 |  |  | $ | 923 |  |  | $ | — |  |

[0000833444-16-000216:notes:222]
1Classified as restricted investments for payment of asbestos liabilities. See Note 23, "Commitments and Contingencies" of the notes to consolidated financial statements for further details.

[0000833444-16-000216:notes:223]
|  | Fair Value Measurements Using: |
|  | Total as ofSeptember 30, 2015 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 58 |  |  | $ | — |  |  | $ | 58 |  |  | $ | — |  |
| Interest rate swaps | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Cross-currency interest rate swaps | 5 |  |  | — |  |  | 5 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Interest rate swaps | 5 |  |  | — |  |  | 5 |  |  | — |  |
| Investments in marketable common stock | 4 |  |  | 4 |  |  | — |  |  | — |  |
| Equity swap | 164 |  |  | 164 |  |  | — |  |  | — |  |
| Total assets | $ | 237 |  |  | $ | 168 |  |  | $ | 69 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 63 |  |  | $ | — |  |  | $ | 63 |  |  | $ | — |  |
| Commodity derivatives | 7 |  |  | — |  |  | 7 |  |  | — |  |
| Cross-currency interest rate swaps | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Current portion of long-term debt |  |  |  |  |  |  |  |
| Fixed rate debt swapped to floating | 801 |  |  | — |  |  | 801 |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Fixed rate debt swapped to floating | 855 |  |  | — |  |  | 855 |  |  | — |  |
| Total liabilities | $ | 1,727 |  |  | $ | — |  |  | $ | 1,727 |  |  | $ | — |  |

[0000833444-16-000216:notes:224]
Valuation Methods

[0000833444-16-000216:notes:225]
Foreign currency exchange derivatives: The foreign currency exchange derivatives are valued under a market approach using publicized spot and forward prices.

[0000833444-16-000216:notes:226]
Commodity derivatives: The commodity derivatives are valued under a market approach using publicized prices, where available, or dealer quotes.

[0000833444-16-000216:notes:227]
Interest rate swaps and related debt: The interest rate swaps and related debt balances are valued under a market approach using publicized swap curves.

[0000833444-16-000216:notes:228]
Equity swaps: The equity swaps are valued under a market approach as the fair value of the swaps is equal to the Company’s stock price at the reporting period date.

[0000833444-16-000216:notes:229]
Cross-currency interest rate swaps: The cross-currency interest rate swaps are valued using observable market data.

[0000833444-16-000216:notes:230]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices.

[0000833444-16-000216:notes:231]
Investments in marketable common stock and exchange traded funds: Investments in marketable common stock and exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. There was an unrealized loss recorded on these investments of $1 million for the year ended September 30, 2016 within AOCI in the consolidated statements of financial position. There were no unrealized gains or losses recorded on these investments for the year ended September 30, 2015. The Company did not hold the exchange traded funds during the year ended September 30, 2015.

[0000833444-16-000216:notes:232]
Foreign currency denominated debt: The Company had entered into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally. The foreign denominated debt obligation is remeasured to current exchange rates under a market approach using publicized spot prices. At September 30, 2016, the Company had 37 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan and one billion euro and 500 million euro bonds designated as net investment hedges in the Company's net investment in Europe. The Company did not have any foreign denominated debt outstanding designated as a net investment hedge at September 30, 2015.

[0000833444-16-000216:notes:233]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. The fair value of long-term debt, which was $15.7 billion and $6.7 billion at September 30, 2016 and 2015, respectively, was determined primarily using market quotes classified as Level 1 inputs within the ASC 820 fair value hierarchy.


## us-gaap:FiniteLivedAndIndefiniteLivedIntangibleAssetsAcquiredAsPartOfBusinessCombinationTableTextBlock

[0000833444-16-000216:notes:234]
The preliminary purchase price allocation to identifiable intangible assets acquired are as follows:

[0000833444-16-000216:notes:235]
|  |  | Preliminary Fair Value (in millions) |  | Weighted Average Life (in years) |
| Customer relationships |  | $ | 2,280 |  |  | 11 |
| Completed technology |  | 1,530 |  |  | 10 |
| Other definite-lived intangibles |  | 223 |  |  | 8 |
| Indefinite-lived trademarks |  | 2,020 |  |  |  |
| Other indefinite-lived intangibles |  | 90 |  |  |  |
| In-process research and development |  | 60 |  |  |  |
| Total identifiable intangible assets |  | $ | 6,203 |  |  |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000833444-16-000216:notes:236]
Foreign Currency Translation

[0000833444-16-000216:notes:237]
Substantially all of the Company’s international operations use the respective local currency as the functional currency. Assets and liabilities of international entities have been translated at period-end exchange rates, and income and expenses have been translated using average exchange rates for the period. Monetary assets and liabilities denominated in non-functional currencies are adjusted to reflect period-end exchange rates. The aggregate transaction losses, net of the impact of foreign currency hedges, included in net income for the years ended September 30, 2016, 2015 and 2014 were $95 million, $119 million and $8 million, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-16-000216:notes:238]
GOODWILL AND OTHER INTANGIBLE ASSETS

[0000833444-16-000216:notes:239]
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the fiscal years ended September 30, 2016 and 2015 were as follows (in millions):

[0000833444-16-000216:notes:240]
|  | September 30, 2014 |  | BusinessAcquisitions |  | BusinessDivestitures |  | Currency Translation and Other |  | September 30, 2015 |
| Building Efficiency |  |  |  |  |  |  |  |  |  |
| Systems and Service North America | $ | 982 |  |  | $ | — |  |  | $ | (2 | ) |  | $ | (2 | ) |  | $ | 978 |  |
| Products North America | 1,688 |  |  | 34 |  |  | (14 | ) |  | (7 | ) |  | 1,701 |  |
| Asia | 414 |  |  | — |  |  | — |  |  | (25 | ) |  | 389 |  |
| Rest of World | 345 |  |  | — |  |  | — |  |  | (35 | ) |  | 310 |  |
| Automotive Experience |  |  |  |  |  |  |  |  |  |
| Seating | 2,556 |  |  | — |  |  | (4 | ) |  | (188 | ) |  | 2,364 |  |
| Interiors | — |  |  | 9 |  |  | (9 | ) |  | — |  |  | — |  |
| Power Solutions | 1,142 |  |  | — |  |  | — |  |  | (60 | ) |  | 1,082 |  |
| Total | $ | 7,127 |  |  | $ | 43 |  |  | $ | (29 | ) |  | $ | (317 | ) |  | $ | 6,824 |  |
|  | September 30, 2015 |  | BusinessAcquisitions |  | BusinessDivestitures |  | Currency Translation and Other |  | September 30, 2016 |
| Buildings |  |  |  |  |  |  |  |  |  |
| Building Efficiency |  |  |  |  |  |  |  |  |  |
| Systems and Service North America | $ | 978 |  |  | $ | — |  |  | $ | (3 | ) |  | $ | — |  |  | $ | 975 |  |
| Products North America | 1,701 |  |  | — |  |  | (3 | ) |  | (1 | ) |  | 1,697 |  |
| Asia | 389 |  |  | 253 |  |  | — |  |  | 15 |  |  | 657 |  |
| Rest of World | 310 |  |  | 5 |  |  | (13 | ) |  | (1 | ) |  | 301 |  |
| Tyco | — |  |  | 16,364 |  |  | — |  |  | (56 | ) |  | 16,308 |  |
| Automotive Experience |  |  |  |  |  |  |  |  |  |
| Seating | 2,364 |  |  | — |  |  | — |  |  | 21 |  |  | 2,385 |  |
| Power Solutions | 1,082 |  |  | — |  |  | — |  |  | 4 |  |  | 1,086 |  |
| Total | $ | 6,824 |  |  | $ | 16,622 |  |  | $ | (19 | ) |  | $ | (18 | ) |  | $ | 23,409 |  |

[0000833444-16-000216:notes:241]
In connection with the Tyco merger, the Company recorded goodwill of $16,363 million based on the preliminary purchase price allocation. Refer to Note 2, "Merger Transaction," of the notes to consolidated financial statements for additional information.

[0000833444-16-000216:notes:242]
At September 30, 2014, accumulated goodwill impairment charges included $430 million and $47 million related to the Automotive Experience Interiors and Building Efficiency Rest of World - Latin America reporting units, respectively. There were no goodwill impairments resulting from fiscal 2016 and 2015 annual impairment tests. Except for recent acquisitions which are recorded at fair value, no reporting unit was determined to be at risk of failing step one of the goodwill impairment test.

[0000833444-16-000216:notes:243]
At October 1, 2015, the Company assessed goodwill for impairment in the Building Efficiency business due to the change in reportable segments as described in Note 19, "Segment Information," of the notes to consolidated financial statements. As a result, the Company performed impairment testing for goodwill under the new segments and determined that the estimated fair value of each reporting unit substantially exceeded its corresponding carrying amount including recorded goodwill, and as such, no impairment existed at October 1, 2015. No reporting unit was determined to be at risk of failing step one of the goodwill impairment test.

[0000833444-16-000216:notes:244]
During fiscal 2014, as a result of operating results, restructuring actions and expected future profitability, the Company's forecasted cash flow estimates used in the goodwill assessment were negatively impacted as of September 30, 2014 for the Building Efficiency Rest of World - Latin America reporting unit. As a result, the Company concluded that the carrying value of the Building Efficiency Rest of World - Latin America reporting unit exceeded its fair value as of September 30, 2014. The Company recorded a goodwill impairment charge of $47 million in the fourth quarter of fiscal 2014, which was determined by comparing the carrying value of the reporting unit's goodwill with the implied fair value of goodwill for the reporting unit. The Building Efficiency Rest of World - Latin America reporting unit has no remaining goodwill at September 30, 2016 and 2015.

[0000833444-16-000216:notes:245]
The assumptions included in the impairment tests require judgment, and changes to these inputs could impact the results of the calculations. Other than management's projections of future cash flows, the primary assumptions used in the impairment tests were the weighted-average cost of capital and long-term growth rates. Although the Company's cash flow forecasts are based on assumptions that are considered reasonable by management and consistent with the plans and estimates management is using to operate the underlying businesses, there are significant judgments in determining the expected future cash flows attributable to a reporting unit. The impairment charges are non-cash expenses recorded within restructuring and impairment costs on the consolidated statements of income and did not adversely affect the Company's debt position, cash flow, liquidity or compliance with financial covenants.

[0000833444-16-000216:notes:246]
Refer to Note 2, "Merger Transaction," of the notes to consolidated financial statements for additional information of intangibles recorded as a result of the Tyco merger.

[0000833444-16-000216:notes:247]
Amortization of intangible assets for the fiscal years ended September 30, 2016, 2015 and 2014 was $133 million, $92 million and $86 million, respectively. Excluding the impact of any future acquisitions, the Company anticipates amortization for fiscal 2017, 2018, 2019, 2020 and 2021 will be approximately $465 million, $440 million, $424 million, $414 million and $405 million, respectively. Excluding the amortization expense of Automotive Experience and the nonrecurring impact of select Tyco intangible assets, the Company expects its fiscal 2017 amortization expense to be $430 million. There were no indefinite lived intangible asset impairments resulting from fiscal 2016, 2015 and 2014 annual impairment tests.


## us-gaap:GuaranteesTextBlock

[0000833444-16-000216:notes:248]
GUARANTEES

[0000833444-16-000216:notes:249]
Certain of the Company's subsidiaries at the business segment level have guaranteed the performance of third-parties and provided financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from the current fiscal year through the completion of such transactions and would typically be triggered in the event of nonperformance. Performance under the guarantees, if required, would not have a material effect on the Company's financial position, results of operations or cash flows.

[0000833444-16-000216:notes:250]
As a result of the Tyco Merger in the fourth quarter of fiscal 2016, the Company recorded as part of the acquired liabilities of Tyco $290 million of post sale contingent tax indemnification liabilities within other noncurrent liabilities in the consolidated statements of financial position. The liabilities are recorded at fair value and relate to certain tax related matters borne by the buyer of previously divested subsidiaries of Tyco which Tyco has indemnified certain parties and the amounts are probable of being paid. Of the $290 million recorded as of September 30, 2016, $255 million is related to prior divested businesses and the remainder relates to Tyco’s tax sharing agreements from its 2007 and 2012 spin-off transactions. These are certain guarantees or indemnifications extended among Tyco, Medtronic, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 separation and tax sharing agreements.

[0000833444-16-000216:notes:251]
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. A typical warranty program requires that the Company replace defective products within a specified time period from the date of sale. The Company records an estimate for future warranty-related costs based on actual historical return rates and other known factors. Based on analysis of return rates and other factors, the Company’s warranty provisions are adjusted as necessary. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different than those estimates.

[0000833444-16-000216:notes:252]
The Company’s product warranty liability is recorded in the consolidated statements of financial position in other current liabilities if the warranty is less than one year and in other noncurrent liabilities if the warranty extends longer than one year.

[0000833444-16-000216:notes:253]
The changes in the carrying amount of the Company’s total product warranty liability, including extended warranties for which deferred revenue is recorded, for the fiscal years ended September 30, 2016 and 2015 were as follows (in millions):

[0000833444-16-000216:notes:254]
|  | Year EndedSeptember 30, |
|  | 2016 |  | 2015 |
| Balance at beginning of period | $ | 300 |  |  | $ | 319 |  |
| Accruals for warranties issued during the period | 324 |  |  | 280 |  |
| Accruals from acquisitions and divestitures | 83 |  |  | — |  |
| Accruals related to pre-existing warranties (including changes in estimates) | (13 | ) |  | (11 | ) |
| Settlements made (in cash or in kind) during the period | (301 | ) |  | (282 | ) |
| Currency translation | 3 |  |  | (6 | ) |
| Balance at end of period | $ | 396 |  |  | $ | 300 |  |


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0000833444-16-000216:notes:255]
Goodwill and Indefinite-Lived Intangible Assets

[0000833444-16-000216:notes:256]
Goodwill reflects the cost of an acquisition in excess of the fair values assigned to identifiable net assets acquired. The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s reportable segments or one level below the reportable segments in certain instances, using a fair value method based on management’s judgments and assumptions or third party valuations. The fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. In estimating the fair value, the Company uses multiples of earnings based on the average of historical, published multiples of earnings of comparable entities with similar operations and economic characteristics. In certain instances, the Company uses discounted cash flow analyses or estimated sales price to further support the fair value estimates. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The estimated fair value is then compared with the carrying amount of the reporting unit, including recorded goodwill. The Company is subject to financial statement risk to the extent that the carrying amount exceeds the estimated fair value. Refer to Note 7, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for information regarding the goodwill impairment testing performed in the fourth quarters of fiscal years 2016, 2015 and 2014.

[0000833444-16-000216:notes:257]
Indefinite-lived intangible assets are also subject to at least annual impairment testing. Indefinite-lived intangible assets consist of trademarks and tradenames and are tested for impairment using a relief-from-royalty method. A considerable amount of management judgment and assumptions are required in performing the impairment tests.

[0000833444-16-000216:notes:258]
Impairment of Long-Lived Assets

[0000833444-16-000216:notes:259]
The Company reviews long-lived assets, including property, plant and equipment and other intangible assets with definite lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets." ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. Refer to Note 17, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for information regarding the impairment testing performed in fiscal years 2016, 2015 and 2014.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-16-000216:notes:260]
INCOME TAXES

[0000833444-16-000216:notes:261]
The more significant components of the Company’s income tax provision from continuing operations are as follows (in millions):

[0000833444-16-000216:notes:262]
|  | Year Ended September 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Tax expense at federal statutory rate | $ | 555 |  |  | $ | 753 |  |  | $ | 671 |  |
| State income taxes, net of federal benefit | 3 |  |  | (23 | ) |  | 7 |  |
| Foreign income tax expense at different rates and foreign losses without tax benefits | (190 | ) |  | (198 | ) |  | (196 | ) |
| U.S. tax on foreign income | (354 | ) |  | (203 | ) |  | (222 | ) |
| Reserve and valuation allowance adjustments | — |  |  | (99 | ) |  | 34 |  |
| U.S. credits and incentives | (20 | ) |  | (12 | ) |  | (9 | ) |
| Impact of transactions and business divestitures | 2,149 |  |  | 354 |  |  | 71 |  |
| Restructuring and impairment costs | 126 |  |  | 52 |  |  | 75 |  |
| Other | (31 | ) |  | (24 | ) |  | (24 | ) |
| Income tax provision | $ | 2,238 |  |  | $ | 600 |  |  | $ | 407 |  |

[0000833444-16-000216:notes:263]
The U.S. federal statutory tax rate is being used as a comparison since the Company was a U.S. domiciled company in fiscal 2014, 2015 and 11 months of 2016. The effective rate is above the U.S. statutory rate for fiscal 2016 primarily due to the tax consequences surrounding the planned spin-off of the Automotive Experience business and related expenses, the jurisdictional mix of restructuring and impairment costs, and the tax impacts of the merger and integration related costs, partially offset by the benefits of continuing global tax planning initiatives and foreign tax rate differentials. The effective rate is below the U.S. statutory rate for fiscal 2015 primarily due to the benefits of continuing global tax planning initiatives, income in certain non-U.S. jurisdictions with a tax rate lower than the U.S. statutory tax rate and adjustments due to tax audit resolutions, partially offset by the tax consequences of business divestitures, and significant restructuring and impairment costs. The effective rate is below the U.S. statutory rate for fiscal 2014 primarily due to the benefits of continuing global tax planning initiatives and income in certain non-U.S. jurisdictions with a tax rate lower than the U.S. statutory tax rate partially offset by the tax consequences of business divestitures, significant restructuring and impairment costs, and valuation allowance adjustments.

[0000833444-16-000216:notes:264]
Valuation Allowances

[0000833444-16-000216:notes:265]
The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary.

[0000833444-16-000216:notes:266]
As a result of the Tyco Merger in the fourth quarter of fiscal 2016, the Company recorded as part of the acquired liabilities of Tyco $2.4 billion of valuation allowances. Also in the fourth quarter of fiscal 2016, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering tax planning initiatives and other positive and negative evidence, the Company determined that no other material changes were needed to its valuation allowances. Therefore, there was no impact to income tax expense due to valuation allowance changes in the three month period or year ended September 30, 2016.

[0000833444-16-000216:notes:267]
In the fourth quarter of fiscal 2015, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering tax planning initiatives and other positive and negative evidence, the Company determined that it was more likely than not that certain deferred tax assets primarily within Spain, Germany, and the United Kingdom would not be realized, and it is more likely than not that certain deferred tax assets of Poland and Germany will be realized. The impact of the net valuation allowance provision offset the benefit of valuation allowance releases and, as such, there was no net impact to income tax expense in the three month period ended September 30, 2015.

[0000833444-16-000216:notes:268]
In the fourth quarter of fiscal 2014, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering tax planning initiatives and other positive and negative evidence, the Company determined that it was more likely than not that deferred tax assets within Italy would not be realized. Therefore, the Company recorded $34 million of net valuation allowances as income tax expense in the three month period ended September 30, 2014.

[0000833444-16-000216:notes:269]
In the first quarter of fiscal 2014, the Company determined that it was more likely than not that the deferred tax asset associated with a capital loss in Mexico would not be utilized. Therefore, the Company recorded a $21 million valuation allowance as income tax expense.

[0000833444-16-000216:notes:270]
Uncertain Tax Positions

[0000833444-16-000216:notes:271]
The Company is subject to income taxes in the U.S. and numerous foreign jurisdictions. Judgment is required in determining its worldwide provision for income taxes and recording the related assets and liabilities. In the ordinary course of the Company’s business, there are many transactions and calculations where the ultimate tax determination is uncertain. The Company is regularly under audit by tax authorities.

[0000833444-16-000216:notes:272]
At September 30, 2016, the Company had gross tax effected unrecognized tax benefits of $1,836 million of which $1,734 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2016 was approximately $67 million (net of tax benefit).

[0000833444-16-000216:notes:273]
At September 30, 2015, the Company had gross tax effected unrecognized tax benefits of $1,159 million of which $1,104 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2015 was approximately $41 million (net of tax benefit).

[0000833444-16-000216:notes:274]
At September 30, 2014, the Company had gross tax effected unrecognized tax benefits of $1,607 million of which $1,457 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2014 was approximately $106 million (net of tax benefit).

[0000833444-16-000216:notes:275]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0000833444-16-000216:notes:276]
|  | Year Ended September 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Beginning balance, October 1 | $ | 1,159 |  |  | $ | 1,607 |  |  | $ | 1,302 |  |
| Additions for tax positions related to the current year | 465 |  |  | 329 |  |  | 315 |  |
| Additions for tax positions of prior years | 15 |  |  | 23 |  |  | 31 |  |
| Reductions for tax positions of prior years | (66 | ) |  | (118 | ) |  | (27 | ) |
| Settlements with taxing authorities | (104 | ) |  | (541 | ) |  | (9 | ) |
| Statute closings | (30 | ) |  | (18 | ) |  | (5 | ) |
| Audit resolutions | — |  |  | (123 | ) |  | — |  |
| Acquisition of business | 397 |  |  | — |  |  | — |  |
| Ending balance, September 30 | $ | 1,836 |  |  | $ | 1,159 |  |  | $ | 1,607 |  |

[0000833444-16-000216:notes:277]
During fiscal 2015, the Company settled a significant number of tax examinations in Germany, Mexico and the U.S., impacting fiscal years 1998 to fiscal 2012. The settlement of unrecognized tax benefits included cash payments for approximately $440 million and the loss of various tax attributes. The reduction for tax positions of prior years is substantially related to foreign exchange rates. In the fourth quarter of fiscal 2015, income tax audit resolutions resulted in a net $99 million benefit to income tax expense.

[0000833444-16-000216:notes:278]
In the U.S., fiscal years 2010 through 2014 are currently under exam by the Internal Revenue Service ("IRS") and 2008 through 2009 are currently under IRS appeals. Additionally, the Company is currently under exam in the following major foreign jurisdictions:

[0000833444-16-000216:notes:279]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2011 - 2014 |
| Brazil |  | 2004 - 2008, 2011 - 2012 |
| Canada |  | 2012 - 2015 |
| France |  | 2010 - 2015 |
| Germany |  | 2007 - 2013 |
| Italy |  | 2006, 2011 |
| Korea |  | 2012 - 2015 |
| Mexico |  | 2009 - 2015 |
| Poland |  | 2015 |
| Spain |  | 2008 - 2014 |
| United Kingdom |  | 2011 - 2014 |

[0000833444-16-000216:notes:280]
It is reasonably possible that certain tax examinations, tax appeals and /or tax litigation will conclude within the next twelve months, of which could be up to a $100 million impact to tax expense.

[0000833444-16-000216:notes:281]
Other Tax Matters

[0000833444-16-000216:notes:282]
During fiscal 2016, 2015 and 2014, the Company incurred significant charges for restructuring and impairment costs. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. A substantial portion of these charges cannot be benefited for tax purposes due to the Company's current tax position in these jurisdictions and the underlying tax basis in the impaired assets, resulting in $126 million, $52 million and $75 million incremental tax expense in fiscal 2016, 2015 and 2014, respectively.

[0000833444-16-000216:notes:283]
During the fourth quarter of fiscal 2016, the Company completed its merger with Tyco. As a result of that transaction, the Company incurred incremental tax expense of $137 million. In preparation for the spin-off of the Automotive Experience business in the first quarter of fiscal 2017, the Company incurred incremental tax expense of $121 million in fiscal 2016. The Company also completed substantial business reorganizations which resulted in total tax charges of $1,891 million in fiscal 2016. Included in this amount is the tax charge provided for in the third quarter of fiscal 2016 of $85 million for changes in entity tax status and the charge provided for in the second quarter of fiscal 2016 of $780 million for income tax expense on foreign undistributed earnings of certain non-U.S. subsidiaries.

[0000833444-16-000216:notes:284]
In the fourth quarter of fiscal 2015, the Company completed its global automotive interiors joint venture with Yanfeng Automotive Trim Systems. Refer to Note 3, "Acquisitions and Divestitures," of the notes to consolidated financial statements for additional information. In connection with the divestiture of the Interiors business, the Company recorded a pre-tax gain on divestiture of $145 million, $38 million net of tax. The tax impact of the gain is due to the jurisdictional mix of gains and losses on the divestiture, which resulted in non-benefited expenses in certain countries and taxable gains in other countries. In addition, in the third and fourth quarters of fiscal 2015, the Company provided income tax expense for repatriation of cash and other tax reserves associated with the Automotive Experience Interiors joint venture transaction, which resulted in a tax charge of $75 million and $223 million, respectively.

[0000833444-16-000216:notes:285]
During the fourth quarter of fiscal 2014, the Company recorded a discrete tax benefit of $51 million due to change in entity status.

[0000833444-16-000216:notes:286]
In the third quarter of fiscal 2014, the Company disposed of its Automotive Experience Interiors headliner and sun visor product lines. Refer to Note 3, "Acquisitions and Divestitures," of the notes to consolidated financial statements for additional information. As a result, the Company recorded a pre-tax loss on divestiture of $95 million and income tax expense of $38 million. The income tax expense is due to the jurisdictional mix of gains and losses on the sale, which resulted in non-benefited losses in certain countries and taxable gains in other countries.

[0000833444-16-000216:notes:287]
Impacts of Tax Legislation and Change in Statutory Tax Rates

[0000833444-16-000216:notes:288]
After the fourth quarter of fiscal 2016, on October 13, 2016, the U.S. Treasury and the IRS released final and temporary Section 385 regulations. These regulations address whether certain instruments between related parties are treated as debt or equity. The Company does not expect that the regulations will have a material impact on its consolidated financial statements.

[0000833444-16-000216:notes:289]
The "look-through rule," under subpart F of the U.S. Internal Revenue Code, expired for the Company on September 30, 2015. The "look-through rule" had provided an exception to the U.S. taxation of certain income generated by foreign subsidiaries. The rule was extended in December 2015 retroactive to the beginning of the Company’s 2016 fiscal year. The retroactive extension was signed into legislation and was made permanent through the Company's 2020 fiscal year.

[0000833444-16-000216:notes:290]
In the second quarter of fiscal 2015, tax legislation was adopted in Japan which reduced its statutory income tax rate. As a result of the law change, the Company recorded income tax expense of $17 million in the second quarter of fiscal 2015.

[0000833444-16-000216:notes:291]
As a result of changes to Mexican tax law in the first quarter of fiscal 2014, the Company recorded a benefit to income tax expense of $25 million.

[0000833444-16-000216:notes:292]
During the fiscal years ended 2016, 2015 and 2014, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-16-000216:notes:293]
Continuing Operations

[0000833444-16-000216:notes:294]
Components of the provision for income taxes on continuing operations were as follows (in millions):

[0000833444-16-000216:notes:295]
|  | Year Ended September 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Current |  |  |  |  |  |
| Federal | $ | 1,975 |  |  | $ | (477 | ) |  | $ | 109 |  |
| State | 101 |  |  | (21 | ) |  | 15 |  |
| Foreign | 1,403 |  |  | 906 |  |  | 585 |  |
|  | 3,479 |  |  | 408 |  |  | 709 |  |
| Deferred |  |  |  |  |  |
| Federal | (523 | ) |  | 201 |  |  | (175 | ) |
| State | (51 | ) |  | (31 | ) |  | (6 | ) |
| Foreign | (667 | ) |  | 22 |  |  | (121 | ) |
|  | (1,241 | ) |  | 192 |  |  | (302 | ) |
| Income tax provision | $ | 2,238 |  |  | $ | 600 |  |  | $ | 407 |  |

[0000833444-16-000216:notes:296]
Consolidated U.S. income from continuing operations before income taxes and noncontrolling interests for the fiscal years ended September 30, 2016, 2015 and 2014 was income of $1,155 million, $1,051 million and $1,370 million, respectively. Consolidated foreign income from continuing operations before income taxes and noncontrolling interests for the fiscal years ended September 30, 2016, 2015 and 2014 was income of $431 million, $1,100 million and $546 million, respectively.

[0000833444-16-000216:notes:297]
Income taxes paid for the fiscal years ended September 30, 2016, 2015 and 2014 were $1,388 million, $1,163 million and $782 million, respectively. At September 30, 2016 and 2015, the Company recorded within the consolidated statements of financial position in other current liabilities approximately $1,538 million and $337 million, respectively, of accrued income tax liabilities.

[0000833444-16-000216:notes:298]
The Company has not provided U.S. or non-U.S. income taxes on approximately $5.5 billion of outside basis differences of Johnson Controls, Inc. consolidated subsidiaries of the Company. The reduction of the outside basis differences via the sale or liquidation of these consolidated subsidiaries and/or distributions could create taxable income.  The Company has also not provided U.S. or non-U.S. income taxes on additional outside basis differences relating to the Tyco Merger.  The Company is currently finalizing the purchase price allocation by legal entity to the assets acquired and liabilities assumed which will be used to calculate the outside basis differences of certain of its consolidated subsidiaries of the Company.  This purchase price allocation, by legal entity, will be completed within the measurement period in fiscal 2017. The Company’s intent is to reduce the outside basis differences only when it would be tax efficient. It is not practicable to estimate the amount of unrecognized withholding taxes and deferred tax liability on the outside basis differences.

[0000833444-16-000216:notes:299]
In fiscal 2016, the Company did provide U.S. income tax expense related to the restructuring and repatriation of cash for certain non-U.S. subsidiaries in connection with the Automotive Experience planned spin-off. The Company needs to complete the final steps of Automotive Experience restructuring and, as a result, the Company provided deferred taxes of $24 million for the U.S. income tax expense on outside basis differences that will reverse upon the completion of the restructuring. Refer to "Capitalization" within the "Liquidity and Capital Resources" section of Item 7 for discussion of domestic and foreign cash projections.

[0000833444-16-000216:notes:300]
Temporary differences and carryforwards which gave rise to deferred tax assets and liabilities included (in millions):

[0000833444-16-000216:notes:301]
|  | September 30, |
|  | 2016 |  | 2015 |
| Deferred tax assets |  |  |  |
| Accrued expenses and reserves | $ | 1,404 |  |  | $ | 210 |  |
| Employee and retiree benefits | 515 |  |  | 270 |  |
| Net operating loss and other credit carryforwards | 4,668 |  |  | 2,471 |  |
| Research and development | 94 |  |  | 64 |  |
| Joint ventures and partnerships | 279 |  |  | 231 |  |
| Other | 35 |  |  | 16 |  |
|  | 6,995 |  |  | 3,262 |  |
| Valuation allowances | (3,564 | ) |  | (1,256 | ) |
|  | 3,431 |  |  | 2,006 |  |
| Deferred tax liabilities |  |  |  |
| Property, plant and equipment | 113 |  |  | 124 |  |
| Intangible assets | 2,010 |  |  | 400 |  |
|  | 2,123 |  |  | 524 |  |
| Net deferred tax asset | $ | 1,308 |  |  | $ | 1,482 |  |

[0000833444-16-000216:notes:302]
At September 30, 2016, the Company had available net operating loss carryforwards of approximately $15.3 billion, of which $4.6 billion will expire at various dates between 2017 and 2036, and the remainder has an indefinite carryforward period. The Company had available U.S. foreign tax credit carryforwards at September 30, 2016 of $80 million, which will expire at various dates between 2020 and 2024. The valuation allowance, generally, is for loss carryforwards for which realization is uncertain because it is unlikely that the losses will be realized given the lack of sustained profitability and/or limited carryforward periods in certain countries.

[0000833444-16-000216:notes:303]
As of September 30, 2016, deferred tax assets of approximately $180 million relate to certain operating loss carryforwards resulting from the exercise of employee stock options and restricted stock vestings, the tax benefit of which, when recognized, will be accounted for as a credit to additional paid-in capital rather than a reduction of income tax provision. Such amount has been presented within the tax loss and carryforwards line in the table above.


## us-gaap:IncomeTaxPolicyTextBlock

[0000833444-16-000216:notes:304]
Income Taxes

[0000833444-16-000216:notes:305]
Deferred tax liabilities and assets are recognized for the expected future tax consequences of events that have been reflected in the consolidated financial statements. Deferred tax liabilities and assets are determined based on the differences between the book and tax bases of particular assets and liabilities and operating loss carryforwards, using tax rates in effect for the years in which the differences are expected to reverse. A valuation allowance is provided to offset deferred tax assets if, based upon the available evidence, including consideration of tax planning strategies, it is more-likely-than-not that some or all of the deferred tax assets will not be realized. Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-16-000216:notes:306]
INVENTORIES

[0000833444-16-000216:notes:307]
Inventories consisted of the following (in millions):

[0000833444-16-000216:notes:308]
|  | September 30, |
|  | 2016 |  | 2015 |
| Raw materials and supplies | $ | 1,365 |  |  | $ | 1,084 |  |
| Work-in-process | 538 |  |  | 369 |  |
| Finished goods | 1,657 |  |  | 924 |  |
| Inventories | $ | 3,560 |  |  | $ | 2,377 |  |


## us-gaap:InventoryPolicyTextBlock

[0000833444-16-000216:notes:309]
Inventories

[0000833444-16-000216:notes:310]
Inventories are stated at the lower of cost or market using the first-in, first-out (FIFO) method. Finished goods and work-in-process inventories include material, labor and manufacturing overhead costs.


## us-gaap:LeasesOfLesseeDisclosureTextBlock

[0000833444-16-000216:notes:311]
LEASES

[0000833444-16-000216:notes:312]
Certain administrative and production facilities and equipment are leased under long-term agreements. Most leases contain renewal options for varying periods, and certain leases include options to purchase the leased property during or at the end of the lease term. Leases generally require the Company to pay for insurance, taxes and maintenance of the property. Leased capital assets included in net property, plant and equipment, primarily buildings and improvements, were $44 million and $46 million at September 30, 2016 and 2015, respectively.

[0000833444-16-000216:notes:313]
Other facilities and equipment are leased under arrangements that are accounted for as operating leases. Total rental expense for the fiscal years ended September 30, 2016, 2015 and 2014 was $402 million, $413 million and $459 million, respectively.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-16-000216:notes:314]
MERGER TRANSACTION

[0000833444-16-000216:notes:315]
As discussed in Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements, JCI Inc. and Tyco completed the Merger on September 2, 2016. The Merger was accounted for as a reverse acquisition using the acquisition method of accounting in accordance with ASC 805, "Business Combinations." Based on the structure of the Merger and other activities contemplated by the Merger Agreement, relative outstanding share ownership, the composition of the Company's board of directors and the designation of certain senior management positions of the Company, JCI Inc. was the accounting acquirer for financial reporting purposes.

[0000833444-16-000216:notes:316]
Immediately prior to the Merger and in connection therewith, Tyco shareholders received 0.955 ordinary shares of Tyco (which shares are now referred to as shares of the Company, or “Company ordinary shares”) for each Tyco ordinary share they held by virtue of a 0.955-for-one share consolidation. In the Merger, each outstanding share of common stock, par value $1.00 per share, of JCI Inc. (“JCI Inc. common stock”) (other than shares held by JCI Inc., Tyco and certain of their subsidiaries) was converted into the right to receive either the cash consideration or the share consideration (each as described below), at the election of the holder, subject to proration procedures described in the Merger Agreement and applicable withholding taxes.  The election to receive the cash consideration was undersubscribed. As a result, holders of shares of JCI Inc. common stock that elected to receive the share consideration and holders of shares of JCI Inc. common stock that made no election (or failed to properly make an election) became entitled to receive, for each such share of JCI Inc. common stock, $5.7293 in cash, without interest, and 0.8357 Company ordinary shares, subject to applicable withholding taxes.  Holders of shares of JCI Inc. common stock that elected to receive the cash consideration became entitled to receive, for each such share of JCI Inc. common stock, $34.88 in cash, without interest, subject to applicable withholding taxes.  In the merger, JCI Inc. shareholders received, in the aggregate, approximately $3.864 billion in cash. Immediately after the closing of, and giving effect to, the Merger, former JCI Inc. shareholders owned approximately 56% of the issued and outstanding Company ordinary shares and former Tyco stockholders owned approximately 44% of the issued and outstanding Company ordinary shares.

[0000833444-16-000216:notes:317]
Tyco is a leading global provider of security products and services, fire detection and suppression products and services, and life safety products. The acquisition of Tyco brings together best-in-class product, technology and service capabilities across controls, fire, security, HVAC, power solutions and energy storage, to serve various end-markets including large institutions, commercial buildings, retail, industrial, small business and residential.  The combination of the Tyco and JCI Inc. buildings platforms is expected to create immediate opportunities for near-term growth through cross-selling, complementary branch and channel networks, and expanded global reach for established businesses. The new Company is also expected to benefit by combining innovation capabilities and pipelines involving new products, advanced solutions for smart buildings and cities, value-added services driven by advanced data and analytics and connectivity between buildings and energy storage through infrastructure integration.

[0000833444-16-000216:notes:318]
Fair Value of Consideration Transferred

[0000833444-16-000216:notes:319]
The total fair value of consideration transferred was approximately $19.7 billion. Total consideration is comprised of the equity value of the Tyco shares that were outstanding as of September 2, 2016 and the portion of Tyco's share awards and share options earned as of September 2, 2016 ($224 million). Share awards and share options not earned ($101 million) as of September 2, 2016 will be expensed over the remaining future vesting period, including $10 million and $23 million recognized in selling, general and administrative expenses and restructuring and impairment costs, respectively, for the fiscal year ended September 30, 2016 as a result of change-in-control provisions for current and former employees.

[0000833444-16-000216:notes:320]
Fair Value of Assets Acquired and Liabilities Assumed

[0000833444-16-000216:notes:321]
The Company accounted for the merger with Tyco as a business combination using the acquisition method of accounting. The assets acquired and liabilities assumed were recorded at their respective fair values as of the acquisition date.

[0000833444-16-000216:notes:322]
As the Company finalizes the fair value of assets acquired and liabilities assumed, additional purchase price adjustments may be recorded during the measurement period in fiscal 2017. Fair value estimates are based on a complex series of judgments about future events and uncertainties and rely heavily on estimates and assumptions. The judgments used to determine the estimated fair value assigned to each class of assets acquired and liabilities assumed, as well as asset lives, can materially impact the Company's results of operations. The finalization of the purchase accounting assessment may result in a change in the valuation of assets acquired and liabilities assumed and may have a material impact on the Company's results of operations and financial position.

[0000833444-16-000216:notes:323]
The preliminary fair values of the assets acquired and liabilities assumed are as follows (in millions):

[0000833444-16-000216:notes:324]
| Cash and cash equivalents |  | $ | 489 |  |
| Accounts receivable |  | 1,648 |  |
| Inventories |  | 829 |  |
| Other current assets |  | 1,062 |  |
| Property, plant, and equipment - net |  | 1,224 |  |
| Goodwill |  | 16,363 |  |
| Intangible assets - net |  | 6,203 |  |
| Other noncurrent assets |  | 560 |  |
| Total assets acquired |  | $ | 28,378 |  |
| Short-term debt |  | $ | 462 |  |
| Accounts payable |  | 711 |  |
| Accrued compensation and benefits |  | 305 |  |
| Other current liabilities |  | 1,608 |  |
| Long-term debt |  | 6,416 |  |
| Long-term deferred tax liabilities |  | 1,173 |  |
| Long-term pension and postretirement benefits |  | 774 |  |
| Other noncurrent liabilities |  | 1,088 |  |
| Total liabilities acquired |  | $ | 12,537 |  |
| Noncontrolling interests |  | 34 |  |
| Net assets acquired |  | $ | 15,807 |  |
| Cash consideration paid to JCI Inc. shareholders |  | 3,864 |  |
| Total fair value of consideration transferred |  | $ | 19,671 |  |

[0000833444-16-000216:notes:325]
In connection with the merger, the Company recorded goodwill of $16.4 billion, which is attributable primarily to expected synergies, expanded market opportunities, and other benefits that the Company believes will result from combining its operations with the operations of Tyco. The goodwill created in the merger is not expected to be deductible for tax purposes and is subject to potential significant changes as the purchase price allocation is completed. Goodwill has preliminarily been allocated to the Tyco segment based on how the business was reviewed by the Company's Chief Operating Decision Maker in the fourth quarter of fiscal 2016 as shown in Note 7, "Goodwill and Other Intangible Assets."

[0000833444-16-000216:notes:326]
Actual and Pro Forma Impact

[0000833444-16-000216:notes:327]
The Company's consolidated financial statements for the fiscal year ended September 30, 2016 include Tyco's results of operations from the acquisition date of September 2, 2016 through September 30, 2016. Net sales, segment earnings before interest and taxes (EBIT), and net income (loss) from continuing operations attributable to Tyco during this period and included in the Company's consolidated financial statements for the fiscal year ended September 30, 2016 total $808 million, ($17) million and ($48) million, respectively. The ($17) million segment EBIT includes $74 million of losses for nonrecurring purchasing accounting adjustments including the amortization from the step-up in fair value of inventory acquired and deferred revenue fair value adjustments, $29 million of acquisition costs and $21 million of incremental recurring intangible asset amortization, all of which relate to the Tyco acquisition.

[0000833444-16-000216:notes:328]
In order to reflect the occurrence of the acquisition on October 1, 2014 as required, the unaudited pro forma results include adjustments to reflect, among other things, the amortization of the inventory step-up, the incremental intangible asset amortization to be incurred based on the preliminary values of each identifiable intangible asset,  the change in timing of defined benefit plans' mark-to-market gain or loss recognition, the change in timing of transaction and restructuring costs, and interest expense from debt financing obtained to fund the cash consideration paid to JCI Inc. shareholders. These pro forma amounts are not necessarily indicative of the results that would have been obtained if the acquisition had occurred as of the beginning of the period presented or that may occur in the future, and does not reflect future synergies, integration costs, or other such costs or savings. Additional information regarding fiscal 2016 pro forma information can be found in the Form 8-K filed by the Company with the SEC on November 8, 2016 under Item 7.01, “Regulation FD Disclosure.”

[0000833444-16-000216:notes:329]
ACQUISITIONS AND DIVESTITURES

[0000833444-16-000216:notes:330]
Fiscal Year 2016

[0000833444-16-000216:notes:331]
On October 1, 2015, the Company formed a joint venture with Hitachi to expand its Building Efficiency product offerings. The Company acquired a 60 percent ownership interest in the new entity for approximately $133 million ($563 million purchase price less cash acquired of $430 million). The purchase price, net of cash acquired, was paid as of September 30, 2016. In connection with the acquisition, the Company recorded goodwill of $253 million related to purchase price allocations.

[0000833444-16-000216:notes:332]
Also during fiscal 2016, the Company completed two additional acquisitions for a combined purchase price, net of cash acquired, of $6 million, $3 million of which was paid as of September 30, 2016. The acquisitions in aggregate were not material to the Company's consolidated financial statements. In connection with the acquisitions, the Company recorded goodwill of $6 million. One of the acquisitions increased the Company's ownership from a noncontrolling to controlling interest. As a result, the Company recorded a non-cash gain of $4 million in equity income for the Building Efficiency Rest of World segment to adjust the Company's existing equity investment in the partially-owned affiliate to fair value.

[0000833444-16-000216:notes:333]
In the fourth quarter of fiscal 2016, the Company completed two divestitures for a combined sales price of $39 million, exclusive of net cash divested of $13 million. None of the sales proceeds were received as of September 30, 2016. The divestitures were not material to the Company's consolidated financial statements. In connection with the divestitures, the Company recorded a gain of $12 million within selling, general and administrative expenses on the consolidated statements of income and reduced goodwill by $13 million and $3 million in the Building Efficiency Rest of World segment and Building Efficiency Products North America segment, respectively.

[0000833444-16-000216:notes:334]
In the third quarter of fiscal 2016, the Company completed a divestiture for a sales price of $16 million, all of which was received as of September 30, 2016. The divestiture was not material to the Company's consolidated financial statements. In connection with the divestiture, the Company recorded a gain of $14 million within selling, general and administrative expenses on the consolidated statements of income and reduced goodwill by $3 million in the Building Efficiency Systems and Service North America segment.

[0000833444-16-000216:notes:335]
During fiscal 2016, the Company received $29 million in net cash proceeds related to prior year business divestitures.

[0000833444-16-000216:notes:336]
Fiscal Year 2015

[0000833444-16-000216:notes:337]
During fiscal 2015, the Company completed three acquisitions for a combined purchase price, net of cash acquired, of $47 million, $18 million of which was paid as of September 30, 2015. The acquisitions in the aggregate were not material to the Company’s consolidated financial statements. In connection with the acquisitions, the Company recorded goodwill of $9 million.

[0000833444-16-000216:notes:338]
In the fourth quarter of fiscal 2015, the Company completed the sale of its GWS business to CBRE Group, Inc. The selling price, net of cash divested, was $1.4 billion, all of which was received as of September 30, 2015. In connection with the sale, the Company recorded a $940 million gain, $643 million net of tax, within income (loss) from discontinued operations, net of tax, on the consolidated statements of income and reduced goodwill in assets held for sale by $220 million. At March 31, 2015, the Company determined that the GWS segment met the criteria to be classified as a discontinued operation. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further disclosure related to the Company's discontinued operations.

[0000833444-16-000216:notes:339]
In the fourth quarter of fiscal 2015, the Company completed its global automotive interiors joint venture with Yanfeng Automotive Trim Systems. In connection with the divestiture of the Interiors business, the Company recorded a $145 million gain, $38 million net of tax. The pre-tax gain is recorded within selling, general and administrative expenses on the consolidated statements of income and reduced goodwill in assets held for sale by $21 million.

[0000833444-16-000216:notes:340]
Also during fiscal 2015, the Company completed four additional divestitures for a combined sales price of $119 million, $86 million of which was received as of September 30, 2015. The divestitures were not material to the Company's consolidated financial statements. In connection with the divestitures, the Company recorded a gain of $38 million within selling, general and administrative expenses on the consolidated statements of income and reduced goodwill by $14 million in the Building Efficiency Products North America segment, recorded a gain of $10 million within selling, general and administrative expenses on the consolidated statements of income and reduced goodwill by $4 million in the Automotive Experience Seating segment and recorded a gain of $7 million within selling, general and administrative expenses on the consolidated statements of income and reduced goodwill by $2 million in the Building Efficiency Systems and Service North America segment.

[0000833444-16-000216:notes:341]
In the first nine months of fiscal 2015, the Company adjusted the purchase price allocation of the fiscal 2014 acquisition of Air Distribution Technologies Inc. (ADTi). The adjustment was made as a result of a true-up to the purchase price in the amount of $4 million, all of which was paid as of September 30, 2015. Also, in connection with this acquisition, the Company recorded additional goodwill of $34 million in fiscal 2015 related to the final purchase price allocations.

[0000833444-16-000216:notes:342]
In the second quarter of fiscal 2015, the Company completed the sale of its interests in two GWS joint ventures to Brookfield Asset Management, Inc. The selling price, net of cash divested, was $141 million, all of which was received as of September 30, 2015. In connection with the sale, the Company recorded a $200 million gain, $127 million net of tax, within income (loss) from discontinued operations, net of tax, on the consolidated statements of income and reduced goodwill in assets held for sale by $20 million.

[0000833444-16-000216:notes:343]
Fiscal Year 2014

[0000833444-16-000216:notes:344]
In the third quarter of fiscal 2014, the Company completed its purchase of ADTi for approximately $1.6 billion, net of cash acquired, all of which was paid as of June 30, 2014. ADTi is one of the largest independent providers of air distribution and ventilation products in North America. In the third quarter of fiscal 2014, the Company completed a public offering of $1.7 billion aggregate principal amount of fixed rate senior notes to finance the purchase of ADTi. In fiscal 2014, the Company recorded goodwill of $837 million in the Building Efficiency Products North America segment as a result of the ADTi acquisition. The Company also recorded approximately $477 million of intangible assets that are subject to amortization, of which approximately $475 million was assigned to customer relationships with useful lives between 18 and 20 years. In addition, the Company recorded approximately $230 million of trade names that are not subject to amortization.

[0000833444-16-000216:notes:345]
Also during fiscal 2014, the Company completed four additional acquisitions for a combined purchase price, net of cash acquired, of $144 million, all of which was paid as of September 30, 2014. The acquisitions in the aggregate were not material to the Company's consolidated financial statements. In connection with the acquisitions, the Company recorded goodwill of $140 million. Three of the acquisitions increased the Company's ownership from a noncontrolling to controlling interest. As a result, the Company recorded a combined non-cash gain of $38 million in equity income to adjust the Company's existing equity investments in the partially-owned affiliates to fair value. The $38 million gain includes $19 million for the Power Solutions business and $19 million for the Building Efficiency Asia business.

[0000833444-16-000216:notes:346]
In the third quarter of fiscal 2014, the Company completed the divestiture of the Automotive Experience Interiors headliner and sun visor product lines. As part of this divestiture, the Company made a cash payment of $54 million to the buyer to fund future operational improvement initiatives. The Company recorded a pre-tax loss on divestiture, including transaction costs, of $95 million within selling, general and administrative expenses on the consolidated statements of income. The tax impact of the divestiture was income tax expense of $38 million due to the jurisdictional mix of gains and losses on the sale, which resulted in non-benefited losses in certain countries and taxable gains in other countries. There was no change in goodwill as a result of this transaction.

[0000833444-16-000216:notes:347]
In the third quarter of fiscal 2014, the Company recorded a $25 million charge within income (loss) from discontinued operations, net of tax, on the consolidated statements of income related to the indemnification of certain costs associated with a divested GWS business in 2004.

[0000833444-16-000216:notes:348]
In the second quarter of fiscal 2014, the Company announced that it had reached an agreement to sell the remainder of its Automotive Experience Electronics business to Visteon Corporation, subject to regulatory and other approvals. The sale closed on July 1, 2014. The cash proceeds from the sale were $266 million, all of which was received as of September 30, 2014. At March 31, 2014, the Company determined that the Automotive Experience Electronics segment met the criteria to be classified as a discontinued operation. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further disclosure related to the Company's discontinued operations.

[0000833444-16-000216:notes:349]
In the first quarter of fiscal 2014, the Company completed one additional divestiture for a sales price of $13 million, all of which was received as of September 30, 2014. The divestiture was not material to the Company’s consolidated financial statements. In connection with the divestiture, the Company recorded a gain, net of transaction costs, of $9 million in the Automotive Experience Interiors segment within selling, general and administrative expenses on the consolidated statements of income. There was no change in goodwill as a result of this transaction.

[0000833444-16-000216:notes:350]
During fiscal 2014, the Company adjusted the purchase price allocation of certain fiscal 2013 acquisitions and recorded additional goodwill of $2 million.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000833444-16-000216:notes:351]
New Accounting Pronouncements

[0000833444-16-000216:notes:352]
Recently Adopted Accounting Pronouncements

[0000833444-16-000216:notes:353]
In November 2015, the FASB issued ASU No. 2015-17, "Income Taxes (Topic 740): Balance Sheet Classification of Deferred Taxes." ASU No. 2015-17 requires that deferred tax liabilities and assets be classified as noncurrent in the consolidated statements of financial position. During the quarter ended December 31, 2015, the Company early adopted ASU No. 2015-17 and applied the change retrospectively to all periods presented.  Historical information was already revised throughout these financial statements to reflect the adoption of ASU No. 2015-17 within the Company's recasted consolidated financial statements and notes to consolidated financial statement for the year ended September 30, 2015 in the Company's Current Report on Form 8-K filed with the Securities and Exchange Commission (the "SEC") on March 3, 2016.

[0000833444-16-000216:notes:354]
In April 2014, the FASB issued ASU No. 2014-08, "Presentation of Financial Statements (Topic 205) and Property, Plant and Equipment (Topic 360): Reporting Discontinued Operations and Disclosures of Disposals of Components of an Entity." ASU No. 2014-08 limits discontinued operations reporting to situations where the disposal represents a strategic shift that has (or will have) a major effect on an entity’s operations and financial results, and requires expanded disclosures for discontinued operations. ASU No. 2014-08 was effective for the Company for the quarter ended December 31, 2015. The adoption of this guidance did not have any impact on the Company's consolidated financial statements as there were no dispositions or disposals during the quarter ended December 31, 2015.

[0000833444-16-000216:notes:355]
Recently Issued Accounting Pronouncements

[0000833444-16-000216:notes:356]
In October 2016, the FASB issued ASU No. 2016-17, "Consolidations (Topic 810): Interests Held through Related Parties that are under Common Control." The ASU changes how a single decision maker of a VIE that holds indirect interest in the entity through related parties that are under common control determines whether it is the primary beneficiary of the VIE. The new guidance amends ASU 2015-02, "Consolidation (Topic 810): Amendments to the Consolidation Analysis" issued in February 2015. The guidance should be applied coincidentally with the adoption of ASU 2015-02, which is effective for the Company for the quarter ending December 31, 2016. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements.

[0000833444-16-000216:notes:357]
In October 2016, the FASB issued ASU No. 2016-16, "Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory". The ASU requires the tax effects of all intra-entity sales of assets other than inventory to be recognized in the period in which the transaction occurs. The guidance will be effective for the Company for the quarter ending December 31, 2018 with early adoption permitted but only in the first interim period of a fiscal year. The changes are required to be applied by means of a cumulative-effect adjustment recorded in retained earnings as of the beginning of the fiscal year of adoption. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-16-000216:notes:358]
In August 2016, the FASB issued ASU No. 2016-15, "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments." ASU No. 2016-15 provides clarification guidance on eight specific cash flow presentation issues in order to reduce the diversity in practice. ASU No. 2016-15 will be effective for the Company for the quarter ending December 31, 2018, with early adoption permitted. The guidance should be applied retrospectively to all periods presented, unless deem impracticable, in which case prospective application is permitted. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-16-000216:notes:359]
In June 2016, the FASB issued ASU No. 2016-13, "Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments." ASU No. 2016-13 changes the impairment model for financial assets measured at amortized cost, requiring presentation at the net amount expected to be collected. The measurement of expected credit losses is based upon historical experience, current conditions, and reasonable and supportable forecasts. Available-for-sale debt securities with unrealized losses will now be recorded through an allowance for credit losses. ASU No. 2016-13 will be effective for the Company for the quarter ended December 31, 2020, with early adoption permitted for the quarter ended December 31, 2019. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements.

[0000833444-16-000216:notes:360]
In March 2016, the FASB issued ASU No. 2016-09, "Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting." ASU No. 2016-09 impacts certain aspects of the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the statements of cash flows. ASU No. 2016-09 will be effective for the Company for the quarter ending December 31, 2017, with early adoption permitted. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-16-000216:notes:361]
In March 2016, the FASB issued ASU No. 2016-07, "Investments - Equity Method and Joint Ventures (Topic 323): Simplifying the Transition to the Equity Method of Accounting." ASU No. 2016-07 eliminates the requirement for an investment that qualifies for the use of the equity method of accounting as a result of an increase in the level of ownership or degree of influence to adjust the investment, results of operations and retained earnings retrospectively. ASU No. 2016-07 will be effective prospectively for the Company for increases in the level of ownership interest or degree of influence that result in the adoption of the equity method that occur during or after the quarter ending December 31, 2017, with early adoption permitted. The impact of this guidance for the Company is dependent on any future increases in the level of ownership interest or degree of influence that result in the adoption of the equity method.

[0000833444-16-000216:notes:362]
In February 2016, the FASB issued ASU No. 2016-02, "Leases (Topic 842)." ASU No. 2016-02 requires recognition of operating leases as lease assets and liabilities on the balance sheet, and disclosure of key information about leasing arrangements. ASU No. 2016-02 will be effective retrospectively for the Company for the quarter ending December 31, 2019, with early adoption permitted. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-16-000216:notes:363]
In January 2016, the FASB issued ASU No. 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." ASU No. 2016-01 amends certain aspects of recognition, measurement, presentation and disclosure of financial instruments. ASU No. 2016-01 will be effective for the Company for the quarter ending December 31, 2018, and early adoption is not permitted, with certain exceptions. The changes are required to be applied by means of a cumulative-effect adjustment on the balance sheet as of the beginning of the fiscal year of adoption. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-16-000216:notes:364]
In July 2015, the FASB issued ASU No. 2015-11, "Simplifying the Measurement of Inventory." ASU No. 2015-11 requires inventory that is recorded using the first-in, first-out method to be measured at the lower of cost or net realizable value. ASU No. 2015-11 will be effective prospectively for the Company for the quarter ending December 31, 2017, with early adoption permitted. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements.

[0000833444-16-000216:notes:365]
In May 2015, the FASB issued ASU No. 2015-07, "Disclosures for Investments in Certain Entities That Calculate Net Asset Value per Share (or Its Equivalent)." ASU No. 2015-07 removes the requirement to categorize within the fair value hierarchy all investments for which fair value is measured using the net asset value per share practical expedient. Such investments should be disclosed separate from the fair value hierarchy. ASU No. 2015-07 will be effective retrospectively for the Company for the quarter ending December 31, 2016, with early adoption permitted. The adoption of this guidance is not expected to have an impact on the Company's consolidated financial statements but will impact pension asset disclosures.

[0000833444-16-000216:notes:366]
In April 2015, the FASB issued ASU No. 2015-03, "Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs." ASU No. 2015-03 requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the debt liability. ASU No. 2015-03 will be effective retrospectively for the Company for the quarter ending December 31, 2016, with early adoption permitted. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements.

[0000833444-16-000216:notes:367]
In February 2015, the FASB issued ASU No. 2015-02, "Consolidation (Topic 810): Amendments to the Consolidation Analysis." ASU No. 2015-02 amends the analysis performed to determine whether a reporting entity should consolidate certain types of legal entities. The ASU No. 2015-02 was amended by ASU No. 2016-17, "Consolidations (Topic 810): Interests Held through Related Parties that are under Common Control," issued in October 2016. ASU No. 2015-02 will be effective retrospectively for the Company for the quarter ending December 31, 2016, with early adoption permitted. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements.

[0000833444-16-000216:notes:368]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers (Topic 606)." ASU No. 2014-09 clarifies the principles for recognizing revenue when an entity either enters into a contract with customers to transfer goods or services or enters into a contract for the transfer of non-financial assets. The original standard was effective retrospectively for the Company for the quarter ending December 31, 2017; however in August 2015, the FASB issued ASU No. 2015-14, "Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date," which defers the effective date of ASU No. 2014-09 by one-year for all entities. The new standard will become effective retrospectively for the Company for the quarter ending December 31, 2018, with early adoption permitted, but not before the original effective date. Additionally, in March 2016, the FASB issued ASU No. 2016-08, "Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net)," in April 2016, the FASB issued ASU No. 2016-10, "Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing," and in May 2016, the FASB issued ASU No. 2016-12, "Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients," all of which provide additional clarification on certain topics addressed in ASU No. 2014-09. ASU No. 2016-08, ASU No. 2016-10 and ASU No. 2016-12 follow the same implementation guidelines as ASU No. 2014-09 and ASU No. 2015-14. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-16-000216:notes:369]
RETIREMENT PLANS

[0000833444-16-000216:notes:370]
Pension Benefits

[0000833444-16-000216:notes:371]
The Company has non-contributory defined benefit pension plans covering certain U.S. and non-U.S. employees. The benefits provided are primarily based on years of service and average compensation or a monthly retirement benefit amount. Effective January 1, 2006, certain of the Company’s U.S. pension plans were amended to prohibit new participants from entering the plans. Effective September 30, 2009, active participants continued to accrue benefits under the amended plans until December 31, 2014. Funding for U.S. pension plans equals or exceeds the minimum requirements of the Employee Retirement Income Security Act of 1974. Funding for non-U.S. plans observes the local legal and regulatory limits. Also, the Company makes contributions to union-trusteed pension funds for construction and service personnel.

[0000833444-16-000216:notes:372]
For pension plans with accumulated benefit obligations (ABO) that exceed plan assets, the projected benefit obligation (PBO), ABO and fair value of plan assets of those plans were $7,124 million, $6,966 million and $5,234 million, respectively, as of September 30, 2016 and $3,636 million, $3,581 million and $2,939 million, respectively, as of September 30, 2015.

[0000833444-16-000216:notes:373]
In fiscal 2016, total employer contributions to the defined benefit pension plans were $136 million, of which $34 million were voluntary contributions made by the Company. The Company expects to contribute approximately $326 million in cash to its defined benefit pension plans in fiscal 2017 including $247 million due to change-in-control provisions triggered by the Tyco merger. Projected benefit payments from the plans as of September 30, 2016 are estimated as follows (in millions):

[0000833444-16-000216:notes:374]
| 2017 | $ | 569 |  |
| 2018 | 321 |  |
| 2019 | 332 |  |
| 2020 | 337 |  |
| 2021 | 344 |  |
| 2022-2026 | 1,879 |  |

[0000833444-16-000216:notes:375]
Postretirement Benefits

[0000833444-16-000216:notes:376]
The Company provides certain health care and life insurance benefits for eligible retirees and their dependents primarily in the U.S., Canada and Brazil. Most non-U.S. employees are covered by government sponsored programs, and the cost to the Company is not significant.

[0000833444-16-000216:notes:377]
Eligibility for coverage is based on meeting certain years of service and retirement age qualifications. These benefits may be subject to deductibles, co-payment provisions and other limitations, and the Company has reserved the right to modify these benefits. Effective January 31, 1994, the Company modified certain salaried plans to place a limit on the Company’s cost of future annual retiree medical benefits at no more than 150% of the 1993 cost.

[0000833444-16-000216:notes:378]
The health care cost trend assumption does not have a significant effect on the amounts reported.

[0000833444-16-000216:notes:379]
In fiscal 2016, total employer and employee contributions to the postretirement plans were $7 million. The Company expects to contribute approximately $4 million in cash to its postretirement plans in fiscal 2017. Projected benefit payments from the plans as of September 30, 2016 are estimated as follows (in millions):

[0000833444-16-000216:notes:380]
| 2017 | $ | 21 |  |
| 2018 | 21 |  |
| 2019 | 21 |  |
| 2020 | 21 |  |
| 2021 | 20 |  |
| 2022-2026 | 86 |  |

[0000833444-16-000216:notes:381]
In December 2003, the U.S. Congress enacted the Medicare Prescription Drug, Improvement and Modernization Act of 2003 (Act) for employers sponsoring postretirement care plans that provide prescription drug benefits. The Act introduces a prescription drug benefit under Medicare as well as a federal subsidy to sponsors of retiree health care benefit plans providing a benefit that is at least actuarially equivalent to Medicare Part D.1. Under the Act, the Medicare subsidy amount is received directly by the plan sponsor and not the related plan. Further, the plan sponsor is not required to use the subsidy amount to fund postretirement benefits and may use the subsidy for any valid business purpose. Projected subsidy receipts are estimated to be approximately $2 million per year over the next ten years.

[0000833444-16-000216:notes:382]
Savings and Investment Plans

[0000833444-16-000216:notes:383]
The Company sponsors various defined contribution savings plans that allow employees to contribute a portion of their pre-tax and/or after-tax income in accordance with plan specified guidelines. Under specified conditions, the Company will contribute to certain savings plans based on the employees’ eligible pay and/or will match a percentage of the employee contributions up to certain limits. Matching contributions charged to expense amounted to $128 million, $123 million and $132 million for the fiscal years ended 2016, 2015 and 2014, respectively.

[0000833444-16-000216:notes:384]
Multiemployer Benefit Plans

[0000833444-16-000216:notes:385]
The Company contributes to multiemployer benefit plans based on obligations arising from collective bargaining agreements related to certain of its hourly employees in the U.S. These plans provide retirement benefits to participants based on their service to contributing employers. The benefits are paid from assets held in trust for that purpose. The trustees typically are responsible for determining the level of benefits to be provided to participants as well as for such matters as the investment of the assets and the administration of the plans.

[0000833444-16-000216:notes:386]
The risks of participating in these multiemployer benefit plans are different from single-employer benefit plans in the following aspects:

[0000833444-16-000216:notes:387]
| • | Assets contributed to the multiemployer benefit plan by one employer may be used to provide benefits to employees of other participating employers. |

[0000833444-16-000216:notes:388]
| • | If a participating employer stops contributing to the multiemployer benefit plan, the unfunded obligations of the plan may be borne by the remaining participating employers. |

[0000833444-16-000216:notes:389]
| • | If the Company stops participating in some of its multiemployer benefit plans, the Company may be required to pay those plans an amount based on its allocable share of the underfunded status of the plan, referred to as a withdrawal liability. |

[0000833444-16-000216:notes:390]
The Company participates in approximately 284 multiemployer benefit plans, primarily related to its Buildings business in the U.S., none of which are individually significant to the Company. The number of employees covered by the Company’s multiemployer benefit plans has remained consistent over the past three years, and there have been no significant changes that affect the comparability of fiscal 2016, 2015 and 2014 contributions. The Company recognizes expense for the contractually-required contribution for each period. The Company contributed $46 million, $45 million and $44 million to multiemployer benefit plans in fiscal 2016, 2015 and 2014, respectively.

[0000833444-16-000216:notes:391]
Based on the most recent information available, the Company believes that the present value of actuarial accrued liabilities in certain of these multiemployer benefit plans may exceed the value of the assets held in trust to pay benefits. Currently, the Company is not aware of any significant multiemployer benefits plans for which it is probable or reasonably possible that the Company will be obligated to make up any shortfall in funds. Moreover, if the Company were to exit certain markets or otherwise cease making contributions to these funds, the Company could trigger a withdrawal liability. Currently, the Company is not aware of any significant multiemployer benefit plans for which it is probable or reasonably possible that the Company will withdraw from the plan. Any accrual for a shortfall or withdrawal liability will be recorded when it is probable that a liability exists and it can be reasonably estimated.

[0000833444-16-000216:notes:392]
Plan Assets

[0000833444-16-000216:notes:393]
The Company’s investment policies employ an approach whereby a mix of equities, fixed income and alternative investments are used to maximize the long-term return of plan assets for a prudent level of risk. The investment portfolio primarily contains a diversified blend of equity and fixed income investments. Equity investments are diversified across U.S. and non-U.S. stocks, as well as growth, value and small to large capitalizations. Fixed income investments include corporate and government issues, with short-, mid- and long-term maturities, with a focus on investment grade when purchased and a target duration close to that of the plan liability. Investment and market risks are measured and monitored on an ongoing basis through regular investment portfolio reviews, annual liability measurements and periodic asset/liability studies. The majority of the real estate component of the portfolio is invested in a diversified portfolio of high-quality, operating properties with cash yields greater than the targeted appreciation. Investments in other alternative asset classes, including hedge funds and commodities, diversify the expected investment returns relative to the equity and fixed income investments. As a result of our diversification strategies, there are no significant concentrations of risk within the portfolio of investments.

[0000833444-16-000216:notes:394]
The Company’s actual asset allocations are in line with target allocations. The Company rebalances asset allocations as appropriate, in order to stay within a range of allocation for each asset category.

[0000833444-16-000216:notes:395]
The expected return on plan assets is based on the Company’s expectation of the long-term average rate of return of the capital markets in which the plans invest. The average market returns are adjusted, where appropriate, for active asset management returns. The expected return reflects the investment policy target asset mix and considers the historical returns earned for each asset category.

[0000833444-16-000216:notes:396]
The Company’s plan assets at September 30, 2016 and 2015, by asset category, are as follows (in millions):

[0000833444-16-000216:notes:397]
|  | Fair Value Measurements Using: |
| Asset Category | Total as ofSeptember 30, 2016 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| U.S. Pension |  |  |  |  |  |  |  |
| Cash | $ | 38 |  |  | $ | 38 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 692 |  |  | 499 |  |  | 193 |  |  | — |  |
| Small-Cap | 267 |  |  | 252 |  |  | 15 |  |  | — |  |
| International - Developed | 655 |  |  | 566 |  |  | 89 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 345 |  |  | 280 |  |  | 65 |  |  | — |  |
| Corporate/Other | 950 |  |  | 633 |  |  | 317 |  |  | — |  |
| Real Estate | 346 |  |  | — |  |  | — |  |  | 346 |  |
| Total | $ | 3,293 |  |  | $ | 2,268 |  |  | $ | 679 |  |  | $ | 346 |  |
| Non-U.S. Pension |  |  |  |  |  |  |  |
| Cash | $ | 90 |  |  | $ | 90 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 317 |  |  | 152 |  |  | 165 |  |  | — |  |
| International - Developed | 453 |  |  | 160 |  |  | 293 |  |  | — |  |
| International - Emerging | 19 |  |  | 19 |  |  | — |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 864 |  |  | 452 |  |  | 412 |  |  | — |  |
| Corporate/Other | 561 |  |  | 385 |  |  | 176 |  |  | — |  |
| Hedge Fund | 169 |  |  | — |  |  | 169 |  |  | — |  |
| Real Estate | 63 |  |  | 11 |  |  | — |  |  | 52 |  |
| Total | $ | 2,536 |  |  | $ | 1,269 |  |  | $ | 1,215 |  |  | $ | 52 |  |
| Postretirement |  |  |  |  |  |  |  |
| Cash | $ | 7 |  |  | $ | 7 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 31 |  |  | 31 |  |  | — |  |  | — |  |
| Small-Cap | 10 |  |  | 10 |  |  | — |  |  | — |  |
| International - Developed | 23 |  |  | 23 |  |  | — |  |  | — |  |
| International - Emerging | 12 |  |  | 12 |  |  | — |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 23 |  |  | 23 |  |  | — |  |  | — |  |
| Corporate/Other | 65 |  |  | 65 |  |  | — |  |  | — |  |
| Commodities | 12 |  |  | 12 |  |  | — |  |  | — |  |
| Real Estate | 13 |  |  | 13 |  |  | — |  |  | — |  |
| Total | $ | 196 |  |  | $ | 196 |  |  | $ | — |  |  | $ | — |  |

[0000833444-16-000216:notes:398]
|  | Fair Value Measurements Using: |
| Asset Category | Total as ofSeptember 30, 2015 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| U.S. Pension |  |  |  |  |  |  |  |
| Cash | $ | 75 |  |  | $ | 75 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 500 |  |  | 500 |  |  | — |  |  | — |  |
| Small-Cap | 235 |  |  | 235 |  |  | — |  |  | — |  |
| International - Developed | 472 |  |  | 472 |  |  | — |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 248 |  |  | 217 |  |  | 31 |  |  | — |  |
| Corporate/Other | 753 |  |  | 615 |  |  | 138 |  |  | — |  |
| Real Estate | 323 |  |  | — |  |  | — |  |  | 323 |  |
| Total | $ | 2,606 |  |  | $ | 2,114 |  |  | $ | 169 |  |  | $ | 323 |  |
| Non-U.S. Pension |  |  |  |  |  |  |  |
| Cash | $ | 98 |  |  | $ | 98 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 68 |  |  | 68 |  |  | — |  |  | — |  |
| International - Developed | 104 |  |  | 104 |  |  | — |  |  | — |  |
| International - Emerging | 16 |  |  | 16 |  |  | — |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 441 |  |  | 319 |  |  | 122 |  |  | — |  |
| Corporate/Other | 220 |  |  | 192 |  |  | 28 |  |  | — |  |
| Hedge Fund | 172 |  |  | — |  |  | 172 |  |  | — |  |
| Real Estate | 58 |  |  | 7 |  |  | — |  |  | 51 |  |
| Total | $ | 1,177 |  |  | $ | 804 |  |  | $ | 322 |  |  | $ | 51 |  |
| Postretirement |  |  |  |  |  |  |  |
| Cash | $ | 10 |  |  | $ | 10 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 30 |  |  | 30 |  |  | — |  |  | — |  |
| Small-Cap | 10 |  |  | 10 |  |  | — |  |  | — |  |
| International - Developed | 22 |  |  | 22 |  |  | — |  |  | — |  |
| International - Emerging | 10 |  |  | 10 |  |  | — |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 22 |  |  | 22 |  |  | — |  |  | — |  |
| Corporate/Other | 67 |  |  | 67 |  |  | — |  |  | — |  |
| Commodities | 12 |  |  | 12 |  |  | — |  |  | — |  |
| Real Estate | 11 |  |  | 11 |  |  | — |  |  | — |  |
| Total | $ | 194 |  |  | $ | 194 |  |  | $ | — |  |  | $ | — |  |

[0000833444-16-000216:notes:399]
The following is a description of the valuation methodologies used for assets measured at fair value.

[0000833444-16-000216:notes:400]
Cash: The fair value of cash is valued at cost.

[0000833444-16-000216:notes:401]
Equity Securities: The fair value of equity securities is determined by direct quoted market prices. The underlying holdings are direct quoted market prices on regulated financial exchanges. Certain equity securities are held within commingled funds which are valued at the unitized net asset value ("NAV") or percentage of the net asset value as determined by the custodian of the fund. These values are based on the fair value of the underlying net assets owned by the fund.

[0000833444-16-000216:notes:402]
Fixed Income Securities: The fair value of fixed income securities is determined by direct or indirect quoted market prices. If indirect quoted market prices are utilized, the value of assets held in separate accounts is not published, but the investment managers report daily the underlying holdings. The underlying holdings are direct quoted market prices on regulated financial exchanges.

[0000833444-16-000216:notes:403]
Commodities: The fair value of the commodities is determined by quoted market prices of the underlying holdings on regulated financial exchanges.

[0000833444-16-000216:notes:404]
Hedge Funds: The fair value of hedge funds is accounted for by the custodian. The custodian obtains valuations from underlying managers based on market quotes for the most liquid assets and alternative methods for assets that do not have sufficient trading activity to derive prices. The Company and custodian review the methods used by the underlying managers to value the assets. The Company believes this is an appropriate methodology to obtain the fair value of these assets.

[0000833444-16-000216:notes:405]
Real Estate: The fair value of Real Estate Investment Trusts (REITs) is recorded as Level 1 as these securities are traded on an open exchange. The fair value of other investments in real estate is deemed Level 3 since these investments do not have a readily determinable fair value and requires the fund managers independently to arrive at fair value by calculating NAV per share. In order to calculate NAV per share, the fund managers value the real estate investments using any one, or a combination of, the following methods: independent third party appraisals, discounted cash flow analysis of net cash flows projected to be generated by the investment and recent sales of comparable investments. Assumptions used to revalue the properties are updated every quarter. Due to the fact that the fund managers calculate NAV per share, the Company utilizes a practical expedient for measuring the fair value of its Level 3 real-estate investments, as provided for under ASC 820, "Fair Value Measurement." In applying the practical expedient, the Company is not required to further adjust the NAV provided by the fund manager in order to determine the fair value of its investment as the NAV per share is calculated in a manner consistent with the measurement principles of ASC 946, "Financial Services - Investment Companies," and as of the Company's measurement date. The Company believes this is an appropriate methodology to obtain the fair value of these assets. For the component of the real estate portfolio under development, the investments are carried at cost until they are completed and valued by a third party appraiser.

[0000833444-16-000216:notes:406]
The methods described above may produce a fair value calculation that may not be indicative of net realizable value or reflective of future fair values. Furthermore, while the Company believes its valuation methods are appropriate and consistent with other market participants, the use of different methodologies or assumptions to determine the fair value of certain financial instruments could result in a different fair value measurement at the reporting date.

[0000833444-16-000216:notes:407]
The following sets forth a summary of changes in the fair value of assets measured using significant unobservable inputs (Level 3) (in millions):

[0000833444-16-000216:notes:408]
|  | Total |  | Hedge Funds |  | Real Estate |
| U.S. Pension |  |  |  |  |  |
| Asset value as of September 30, 2014 | $ | 335 |  |  | $ | 4 |  |  | $ | 331 |  |
| Additions net of redemptions | (59 | ) |  | (3 | ) |  | (56 | ) |
| Realized gain (loss) | 28 |  |  | (1 | ) |  | 29 |  |
| Unrealized gain | 19 |  |  | — |  |  | 19 |  |
| Asset value as of September 30, 2015 | $ | 323 |  |  | $ | — |  |  | $ | 323 |  |
| Additions net of redemptions | (6 | ) |  | — |  |  | (6 | ) |
| Realized gain | 13 |  |  | — |  |  | 13 |  |
| Unrealized gain | 16 |  |  | — |  |  | 16 |  |
| Asset value as of September 30, 2016 | $ | 346 |  |  | $ | — |  |  | $ | 346 |  |
| Non-U.S. Pension |  |  |  |  |  |
| Asset value as of September 30, 2014 | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |
| Additions net of redemptions | 34 |  |  | — |  |  | 34 |  |
| Unrealized loss | (3 | ) |  | — |  |  | (3 | ) |
| Asset value as of September 30, 2015 | $ | 51 |  |  | $ | — |  |  | $ | 51 |  |
| Unrealized gain | 1 |  |  | — |  |  | 1 |  |
| Asset value as of September 30, 2016 | $ | 52 |  |  | $ | — |  |  | $ | 52 |  |

[0000833444-16-000216:notes:409]
Funded Status

[0000833444-16-000216:notes:410]
The table that follows contains the ABO and reconciliations of the changes in the PBO, the changes in plan assets and the funded status (in millions):

[0000833444-16-000216:notes:411]
|  | Pension Benefits |  | PostretirementBenefits |
|  | U.S. Plans |  | Non-U.S. Plans |  |
| September 30, | 2016 |  | 2015 |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Accumulated Benefit Obligation | $ | 4,118 |  |  | $ | 2,985 |  |  | $ | 3,359 |  |  | $ | 1,388 |  |  | $ | — |  |  | $ | — |  |
| Change in Projected Benefit Obligation |  |  |  |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of year | 3,022 |  |  | 2,875 |  |  | 1,447 |  |  | 1,572 |  |  | 211 |  |  | 224 |  |
| Service cost | 16 |  |  | 31 |  |  | 30 |  |  | 25 |  |  | 2 |  |  | 3 |  |
| Interest cost | 104 |  |  | 122 |  |  | 44 |  |  | 46 |  |  | 6 |  |  | 9 |  |
| Plan participant contributions | — |  |  | — |  |  | 1 |  |  | 1 |  |  | 6 |  |  | 6 |  |
| Benefit obligations assumed in Tyco acquisition | 974 |  |  | — |  |  | 1,635 |  |  | — |  |  | 30 |  |  | — |  |
| Other acquisitions | — |  |  | — |  |  | 279 |  |  | — |  |  | 2 |  |  | — |  |
| Divestitures | — |  |  | — |  |  | — |  |  | (18 | ) |  | — |  |  | — |  |
| Actuarial loss | 355 |  |  | 203 |  |  | 295 |  |  | 7 |  |  | 5 |  |  | — |  |
| Benefits and settlements paid | (301 | ) |  | (209 | ) |  | (116 | ) |  | (65 | ) |  | (22 | ) |  | (24 | ) |
| Estimated subsidy received | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Curtailment | — |  |  | — |  |  | — |  |  | (5 | ) |  | — |  |  | — |  |
| Other | (1 | ) |  | — |  |  | (1 | ) |  | 43 |  |  | 1 |  |  | (4 | ) |
| Currency translation adjustment | — |  |  | — |  |  | (92 | ) |  | (159 | ) |  | — |  |  | (4 | ) |
| Projected benefit obligation at end of year | $ | 4,169 |  |  | $ | 3,022 |  |  | $ | 3,522 |  |  | $ | 1,447 |  |  | $ | 242 |  |  | $ | 211 |  |
| Change in Plan Assets |  |  |  |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year | $ | 2,606 |  |  | $ | 2,504 |  |  | $ | 1,177 |  |  | $ | 1,201 |  |  | $ | 194 |  |  | $ | 219 |  |
| Actual return on plan assets | 267 |  |  | (4 | ) |  | 113 |  |  | 48 |  |  | 17 |  |  | (9 | ) |
| Plan assets acquired in Tyco acquisition | 705 |  |  | — |  |  | 1,149 |  |  | — |  |  | — |  |  | — |  |
| Other acquisitions | — |  |  | — |  |  | 180 |  |  | — |  |  | — |  |  | — |  |
| Divestitures | — |  |  | — |  |  | — |  |  | (10 | ) |  | — |  |  | — |  |
| Employer and employee contributions | 16 |  |  | 315 |  |  | 121 |  |  | 81 |  |  | 7 |  |  | 8 |  |
| Benefits paid | (124 | ) |  | (201 | ) |  | (59 | ) |  | (55 | ) |  | (22 | ) |  | (24 | ) |
| Settlement payments | (177 | ) |  | (8 | ) |  | (57 | ) |  | (10 | ) |  | — |  |  | — |  |
| Other | — |  |  | — |  |  | — |  |  | 39 |  |  | — |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | (88 | ) |  | (117 | ) |  | — |  |  | — |  |
| Fair value of plan assets at end of year | $ | 3,293 |  |  | $ | 2,606 |  |  | $ | 2,536 |  |  | $ | 1,177 |  |  | $ | 196 |  |  | $ | 194 |  |
| Funded status | $ | (876 | ) |  | $ | (416 | ) |  | $ | (986 | ) |  | $ | (270 | ) |  | $ | (46 | ) |  | $ | (17 | ) |
| Amounts recognized in the statement of financial position consist of: |
| Prepaid benefit cost | $ | 22 |  |  | $ | 17 |  |  | $ | 32 |  |  | $ | 30 |  |  | $ | 53 |  |  | $ | 37 |  |
| Accrued benefit liability | (898 | ) |  | (433 | ) |  | (1,018 | ) |  | (300 | ) |  | (99 | ) |  | (54 | ) |
| Net amount recognized | $ | (876 | ) |  | $ | (416 | ) |  | $ | (986 | ) |  | $ | (270 | ) |  | $ | (46 | ) |  | $ | (17 | ) |
| Weighted Average Assumptions (1) |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate (2) | 3.70 | % |  | 4.40 | % |  | 1.90 | % |  | 3.15 | % |  | 3.30 | % |  | 3.75 | % |
| Rate of compensation increase | 3.20 | % |  | 3.25 | % |  | 2.75 | % |  | 3.00 | % |  | NA |  |  | NA |  |

[0000833444-16-000216:notes:412]
| (1) | Plan assets and obligations are determined based on a September 30 measurement date at September 30, 2016 and 2015. |

[0000833444-16-000216:notes:413]
| (2) | The Company considers the expected benefit payments on a plan-by-plan basis when setting assumed discount rates. As a result, the Company uses different discount rates for each plan depending on the plan jurisdiction, the demographics of participants and the expected timing of benefit payments. For the U.S. pension and postretirement plans, the Company uses a discount rate provided by an independent third party calculated based on an appropriate mix of high quality bonds. For the non-U.S. pension and postretirement plans, the Company consistently uses the relevant country specific benchmark indices for determining the various discount rates. |

[0000833444-16-000216:notes:414]
At September 30, 2015, the Company changed the method used to estimate the service and interest components of net periodic benefit cost for pension and other postretirement benefits for plans that utilize a yield curve approach. This change compared to the previous method results in different service and interest components of net periodic benefit cost (credit). Historically, the Company estimated these service and interest cost components utilizing a single weighted-average discount rate derived from the yield curve used to measure the benefit obligation at the beginning of the period. The Company elected to utilize a full yield curve approach in the estimation of these components by applying the specific spot rates along the yield curve used in the determination of the benefit obligation to the relevant projected cash flows. The Company made this change to provide a more precise measurement of service and interest costs by improving the correlation between projected benefit cash flows to the corresponding spot yield curve rates. This change does not affect the measurement of the total benefit obligations or annual net periodic benefit cost (credit) as the change in the service and interest costs is completely offset in the net actuarial (gain) loss reported. The change in the service and interest costs  was not significant. The Company accounted for this change as a change in accounting estimate.

[0000833444-16-000216:notes:415]
Accumulated Other Comprehensive Income

[0000833444-16-000216:notes:416]
The amounts in AOCI on the consolidated statements of financial position, exclusive of tax impacts, that have not yet been recognized as components of net periodic benefit cost at September 30, 2016 are as follows (in millions):

[0000833444-16-000216:notes:417]
|  | PensionBenefits |  | Postretirement Benefits |
| Accumulated other comprehensive loss |  |  |  |
| Net transition asset | $ | 1 |  |  | $ | — |  |
| Net prior service cost | 4 |  |  | — |  |
| Total | $ | 5 |  |  | $ | — |  |

[0000833444-16-000216:notes:418]
The amounts in AOCI expected to be recognized as components of net periodic benefit cost over the next fiscal year are shown below (in millions):

[0000833444-16-000216:notes:419]
|  | PensionBenefits |  | Postretirement Benefits |
| Amortization of: |  |  |  |
| Net transition obligation | $ | — |  |  | $ | — |  |
| Net prior service cost | 1 |  |  | — |  |
| Total | $ | 1 |  |  | $ | — |  |

[0000833444-16-000216:notes:420]
Net Periodic Benefit Cost

[0000833444-16-000216:notes:421]
The table that follows contains the components of net periodic benefit cost (in millions):

[0000833444-16-000216:notes:422]
|  | Pension Benefits |  | Postretirement Benefits |
|  | U.S. Plans |  | Non-U.S. Plans |  |
| Year ended September 30, | 2016 |  | 2015 |  | 2014 |  | 2016 |  | 2015 |  | 2014 |  | 2016 |  | 2015 |  | 2014 |
| Components of Net Periodic Benefit Cost (Credit): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost | $ | 16 |  |  | $ | 31 |  |  | $ | 70 |  |  | $ | 30 |  |  | $ | 32 |  |  | $ | 38 |  |  | $ | 2 |  |  | $ | 3 |  |  | $ | 5 |  |
| Interest cost | 104 |  |  | 122 |  |  | 138 |  |  | 44 |  |  | 57 |  |  | 71 |  |  | 6 |  |  | 9 |  |  | 12 |  |
| Expected return on plan assets | (191 | ) |  | (181 | ) |  | (207 | ) |  | (61 | ) |  | (71 | ) |  | (75 | ) |  | (10 | ) |  | (12 | ) |  | (12 | ) |
| Net actuarial (gain) loss | 268 |  |  | 387 |  |  | 126 |  |  | 237 |  |  | 14 |  |  | 172 |  |  | (2 | ) |  | 21 |  |  | (24 | ) |
| Amortization of prior service cost (credit) | — |  |  | — |  |  | 1 |  |  | 1 |  |  | (1 | ) |  | (1 | ) |  | (1 | ) |  | (1 | ) |  | (7 | ) |
| Curtailment gain | — |  |  | — |  |  | — |  |  | — |  |  | (15 | ) |  | (2 | ) |  | — |  |  | — |  |  | — |  |
| Settlement loss | 11 |  |  | 1 |  |  | 15 |  |  | 6 |  |  | — |  |  | 1 |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (credit) | 208 |  |  | 360 |  |  | 143 |  |  | 257 |  |  | 16 |  |  | 204 |  |  | (5 | ) |  | 20 |  |  | (26 | ) |
| Net periodic benefit (cost) credit related to discontinued operations | — |  |  | — |  |  | — |  |  | — |  |  | 14 |  |  | (38 | ) |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (credit) included in continuing operations | $ | 208 |  |  | $ | 360 |  |  | $ | 143 |  |  | $ | 257 |  |  | $ | 30 |  |  | $ | 166 |  |  | $ | (5 | ) |  | $ | 20 |  |  | $ | (26 | ) |
| Expense Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate | 4.40 | % |  | 4.35 | % |  | 4.90 | % |  | 3.10 | % |  | 3.00 | % |  | 3.60 | % |  | 3.75 | % |  | 4.35 | % |  | 4.90 | % |
| Expected return on plan assets | 7.50 | % |  | 7.50 | % |  | 8.00 | % |  | 4.50 | % |  | 4.50 | % |  | 4.75 | % |  | 5.45 | % |  | 5.75 | % |  | 5.80 | % |
| Rate of compensation increase | 3.25 | % |  | 3.25 | % |  | 3.30 | % |  | 3.30 | % |  | 2.60 | % |  | 2.60 | % |  | NA |  |  | NA |  |  | NA |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000833444-16-000216:notes:423]
PROPERTY, PLANT AND EQUIPMENT

[0000833444-16-000216:notes:424]
Property, plant and equipment consisted of the following (in millions):

[0000833444-16-000216:notes:425]
|  | September 30, |
|  | 2016 |  | 2015 |
| Buildings and improvements | $ | 3,435 |  |  | $ | 3,091 |  |
| Subscriber systems | 448 |  |  | — |  |
| Machinery and equipment | 9,626 |  |  | 8,566 |  |
| Construction in progress | 1,441 |  |  | 1,006 |  |
| Land | 526 |  |  | 338 |  |
| Total property, plant and equipment | 15,476 |  |  | 13,001 |  |
| Less: accumulated depreciation | (7,604 | ) |  | (7,131 | ) |
| Property, plant and equipment - net | $ | 7,872 |  |  | $ | 5,870 |  |

[0000833444-16-000216:notes:426]
Interest costs capitalized during the fiscal years ended September 30, 2016, 2015 and 2014 were $19 million, $25 million and $28 million, respectively. Accumulated depreciation related to capital leases at September 30, 2016 and 2015 was $40 million and $54 million, respectively.

[0000833444-16-000216:notes:427]
At September 30, 2016, the Company is the lessor of properties included in land of $21 million, gross building and improvements of $187 million and accumulated depreciation of $126 million. At September 30, 2015, the Company is the lessor of properties included in land of $13 million, gross building and improvements of $177 million and accumulated depreciation of $131 million.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000833444-16-000216:notes:428]
Property, plant and equipment are recorded at cost. Depreciation is provided over the estimated useful lives of the respective assets using the straight-line method for financial reporting purposes and accelerated methods for income tax purposes. The estimated useful lives generally range from 3 to 40 years for buildings and improvements, subscriber systems up to 15 years, and from 3 to 15 years for machinery and equipment. The Company capitalizes interest on borrowings during the active construction period of major capital projects. Capitalized interest is added to the cost of the underlying assets and is amortized over the useful lives of the assets.


## us-gaap:ReceivablesPolicyTextBlock

[0000833444-16-000216:notes:429]
Receivables

[0000833444-16-000216:notes:430]
Receivables consist of amounts billed and currently due from customers and unbilled costs and accrued profits related to revenues on long-term contracts that have been recognized for accounting purposes but not yet billed to customers. The Company extends credit to customers in the normal course of business and maintains an allowance for doubtful accounts resulting from the inability or unwillingness of customers to make required payments. The allowance for doubtful accounts is based on historical experience, existing economic conditions and any specific customer collection issues the Company has identified. The Company enters into supply chain financing programs to sell certain accounts receivable without recourse to third-party financial institutions. Sales of accounts receivable are reflected as a reduction of accounts receivable on the consolidated statements of financial position and the proceeds are included in cash flows from operating activities in the consolidated statements of cash flows.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-16-000216:notes:431]
RELATED PARTY TRANSACTIONS

[0000833444-16-000216:notes:432]
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-16-000216:notes:433]
The net sales to and purchases from related parties included in the consolidated statements of income were $1.3 billion and $0.5 billion, respectively, for fiscal 2016; $1.3 billion and $0.4 billion, respectively, for fiscal 2015; and $1.2 billion and $0.4 billion, respectively, for fiscal 2014.

[0000833444-16-000216:notes:434]
The following table sets forth the amount of accounts receivable due from and payable to related parties in the consolidated statements of financial position (in millions):

[0000833444-16-000216:notes:435]
|  |  | September 30, |
|  |  | 2016 |  | 2015 |
| Receivable from related parties |  | $ | 239 |  |  | $ | 389 |  |
| Payable to related parties |  | 92 |  |  | 285 |  |

[0000833444-16-000216:notes:436]
The Company has also provided financial support to certain of its VIE's, see Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements for additional information.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-16-000216:notes:437]
SIGNIFICANT RESTRUCTURING AND IMPAIRMENT COSTS

[0000833444-16-000216:notes:438]
To better align its resources with its growth strategies and reduce the cost structure of its global operations to address the softness in certain underlying markets, the Company commits to restructuring plans as necessary.

[0000833444-16-000216:notes:439]
In fiscal 2016, the Company committed to a significant restructuring plan (2016 Plan) and recorded $620 million of restructuring and impairment costs in the consolidated statements of income, of which $229 million was recorded in the second quarter, $102 million was recorded in the third quarter and $289 million was recorded in the fourth quarter of fiscal 2016. This is the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Automotive Experience, Buildings and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments, change-in-control payments and immaterial changes in estimates to prior year plans. Of the restructuring and impairment costs recorded, $284 million related to the Automotive Experience Seating segment, $115 million related to Corporate, $85 million related to the Buildings Tyco segment, $66 million related to the Power Solutions segment, $26 million related to the Building Efficiency Asia segment, $17 million related to the Automotive Experience Interiors segment, $16 million related to the Building Efficiency Rest of World segment, $9 million related to the Building Efficiency Products North America segment, and $2 million related to the Building Efficiency Systems and Service North America segment. The restructuring actions are expected to be substantially complete in fiscal 2018. Included in the reserve is $78 million of committed restructuring actions taken by Tyco for liabilities assumed as part of the Tyco acquisition.

[0000833444-16-000216:notes:440]
The following table summarizes the changes in the Company’s 2016 Plan reserve, included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-16-000216:notes:441]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original Reserve | $ | 368 |  |  | $ | 190 |  |  | $ | 62 |  |  | $ | — |  |  | $ | 620 |  |
| Acquired Tyco restructuring reserves | 78 |  |  | — |  |  | — |  |  | — |  |  | 78 |  |
| Utilized—cash | (32 | ) |  | — |  |  | — |  |  | — |  |  | (32 | ) |
| Utilized—noncash | — |  |  | (190 | ) |  | (32 | ) |  | 1 |  |  | (221 | ) |
| Balance at September 30, 2016 | $ | 414 |  |  | $ | — |  |  | $ | 30 |  |  | $ | 1 |  |  | $ | 445 |  |

[0000833444-16-000216:notes:442]
In fiscal 2015, the Company committed to a significant restructuring plan (2015 Plan) and recorded $397 million of restructuring and impairment costs in the consolidated statements of income. This is the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Automotive Experience, Building Efficiency and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. Of the restructuring and impairment costs recorded, $182 million related to the Automotive Experience Seating segment, $166 million related to Corporate, $13 million related to the Building Efficiency Rest of World segment, $11 million related to the Power Solutions segment, $11 million related to the Building Efficiency Asia segment, $11 million related to the Building Efficiency Products North America segment, and $3 million related to the Building Efficiency Systems and Service North America segment. The restructuring actions are expected to be substantially complete in 2016.

[0000833444-16-000216:notes:443]
The following table summarizes the changes in the Company’s 2015 Plan reserve, included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-16-000216:notes:444]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | Total |
| Original Reserve | $ | 191 |  |  | $ | 183 |  |  | $ | 23 |  |  | $ | 397 |  |
| Utilized—noncash | — |  |  | (183 | ) |  | — |  |  | (183 | ) |
| Balance at September 30, 2015 | $ | 191 |  |  | $ | — |  |  | $ | 23 |  |  | $ | 214 |  |
| Utilized—cash | (74 | ) |  | — |  |  | (23 | ) |  | (97 | ) |
| Balance at September 30, 2016 | $ | 117 |  |  | $ | — |  |  | $ | — |  |  | $ | 117 |  |

[0000833444-16-000216:notes:445]
In fiscal 2014, the Company committed to a significant restructuring plan (2014 Plan) and recorded $324 million of restructuring and impairment costs in the consolidated statements of income. This is the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related primarily to cost reduction initiatives in the Company’s Automotive Experience, Building Efficiency and Power Solutions businesses and included workforce reductions, plant closures, and asset and goodwill impairments. Of the restructuring and impairment costs recorded, $130 million related to the Automotive Experience Interiors segment, $119 million related to the Building Efficiency Rest of World segment, $29 million related to the Automotive Experience Seating segment, $16 million related to the Power Solutions segment, $12 million related to the Building Efficiency Systems and Service North America segment, $7 million related to the Building Efficiency Products North America segment, $7 million related to Corporate and $4 million related to the Building Efficiency Asia segment. The restructuring actions are expected to be substantially complete in 2016.

[0000833444-16-000216:notes:446]
Additionally, the Company recorded $53 million of restructuring and impairment costs within discontinued operations related to the Automotive Experience Electronics business in fiscal 2014.

[0000833444-16-000216:notes:447]
The following table summarizes the changes in the Company’s 2014 Plan reserve, included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-16-000216:notes:448]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Goodwill Impairment |  | Other |  | CurrencyTranslation |  | Total |
| Original Reserve | $ | 191 |  |  | $ | 134 |  |  | $ | 47 |  |  | $ | 5 |  |  | $ | — |  |  | $ | 377 |  |
| Utilized—cash | (8 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (8 | ) |
| Utilized—noncash | — |  |  | (134 | ) |  | (47 | ) |  | — |  |  | (6 | ) |  | (187 | ) |
| Balance at September 30, 2014 | $ | 183 |  |  | $ | — |  |  | $ | — |  |  | $ | 5 |  |  | $ | (6 | ) |  | $ | 182 |  |
| Utilized—cash | (65 | ) |  | — |  |  | — |  |  | (5 | ) |  | — |  |  | (70 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | — |  |  | (13 | ) |  | (13 | ) |
| Balance at September 30, 2015 | $ | 118 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (19 | ) |  | $ | 99 |  |
| Utilized—cash | (74 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (74 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | — |  |  | (2 | ) |  | (2 | ) |
| Balance at September 30, 2016 | $ | 44 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (21 | ) |  | $ | 23 |  |

[0000833444-16-000216:notes:449]
In fiscal 2013, the Company committed to a significant restructuring plan (2013 Plan) and recorded $903 million of restructuring and impairment costs in the consolidated statements of income. This is the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Automotive Experience, Building Efficiency and Power Solutions businesses and included workforce reductions, plant closures, and asset and goodwill impairments. Of the restructuring and impairment costs recorded, $560 million related to the Automotive Experience Interiors segment, $152 million related to the Automotive Experience Seating segment, $70 million related to the Building Efficiency Rest of World segment, $36 million related to the Power Solutions segment,  $35 million related to the Building Efficiency Systems and Service North America segment, $28 million related to the Building Efficiency Products North America segment, $17 million related to Corporate and $5 million related to the Building Efficiency Asia segment. The restructuring actions are expected to be substantially complete in 2016.

[0000833444-16-000216:notes:450]
Additionally, the Company recorded $82 million of restructuring costs within discontinued operations, of which $54 million related to the GWS business and $28 million related to the Automotive Experience Electronics business in fiscal 2013.

[0000833444-16-000216:notes:451]
The following table summarizes the changes in the Company’s 2013 Plan reserve, included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-16-000216:notes:452]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Goodwill Impairment |  | Other |  | CurrencyTranslation |  | Total |
| Original Reserve | $ | 392 |  |  | $ | 156 |  |  | $ | 430 |  |  | $ | 7 |  |  | $ | — |  |  | $ | 985 |  |
| Utilized—cash | (26 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (26 | ) |
| Utilized—noncash | — |  |  | (156 | ) |  | (430 | ) |  | (4 | ) |  | 4 |  |  | (586 | ) |
| Transfer to liabilities held for sale | (31 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (31 | ) |
| Balance at September 30, 2013 | $ | 335 |  |  | $ | — |  |  | $ | — |  |  | $ | 3 |  |  | $ | 4 |  |  | $ | 342 |  |
| Utilized—cash | (144 | ) |  | — |  |  | — |  |  | (3 | ) |  | — |  |  | (147 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | — |  |  | (11 | ) |  | (11 | ) |
| Transfer from liabilities held for sale | 31 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 31 |  |
| Transfer to liabilities held for sale | (24 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (24 | ) |
| Balance at September 30, 2014 | $ | 198 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (7 | ) |  | $ | 191 |  |
| Utilized—cash | (113 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (113 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | — |  |  | (10 | ) |  | (10 | ) |
| Balance at September 30, 2015 | $ | 85 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (17 | ) |  | $ | 68 |  |
| Utilized—cash | (43 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (43 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Balance at September 30, 2016 | $ | 42 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (18 | ) |  | $ | 24 |  |

[0000833444-16-000216:notes:453]
The $31 million of transfers from liabilities held for sale represent restructuring reserves that were included in liabilities held for sale in the consolidated statements of financial position at September 30, 2013, but were excluded from liabilities held for sale at September 30, 2014 based on transaction negotiations. See Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's assets and liabilities held for sale.

[0000833444-16-000216:notes:454]
The Company's fiscal 2016, 2015, 2014 and 2013 restructuring plans included workforce reductions of approximately 18,900 employees (11,200 for the Automotive Experience business, 6,700 for the Buildings business, 900 for the Power Solutions business and 100 for Corporate). Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of September 30, 2016, approximately 11,800 of the employees have been separated from the Company pursuant to the restructuring plans. In addition, the restructuring plans included thirty plant closures (twenty-two for Automotive Experience and eight for Buildings. As of September 30, 2016, twelve of the thirty plants have been closed.

[0000833444-16-000216:notes:455]
Refer to Note 17, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for further information regarding the long-lived asset impairment charges recorded as part of the restructuring actions.

[0000833444-16-000216:notes:456]
Refer to Note 7, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for further information regarding the goodwill impairment charges recorded.

[0000833444-16-000216:notes:457]
Company management closely monitors its overall cost structure and continually analyzes each of its businesses for opportunities to consolidate current operations, improve operating efficiencies and locate facilities in low cost countries in close proximity to customers. This ongoing analysis includes a review of its manufacturing, engineering and purchasing operations, as well as the overall global footprint for all its businesses. Because of the importance of new vehicle sales by major automotive manufacturers to operations, the Company is affected by the general business conditions in this industry. Future adverse developments in the automotive industry could impact the Company’s liquidity position, lead to impairment charges and/or require additional restructuring of its operations.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000833444-16-000216:notes:458]
Percentage-of-Completion Contracts

[0000833444-16-000216:notes:459]
The Buildings business records certain long-term contracts under the percentage-of-completion (POC) method of accounting. Under this method, sales and gross profit are recognized as work is performed based on the relationship between actual costs incurred and total estimated costs at completion. The Company records costs and earnings in excess of billings on uncompleted contracts primarily within accounts receivable and billings in excess of costs and earnings on uncompleted contracts primarily within other current liabilities in the consolidated statements of financial position. Costs and earnings in excess of billings related to these contracts were $841 million and $453 million at September 30, 2016 and 2015, respectively. Billings in excess of costs and earnings related to these contracts were $431 million and $340 million at September 30, 2016 and 2015, respectively.

[0000833444-16-000216:notes:460]
Revenue Recognition

[0000833444-16-000216:notes:461]
The Buildings business recognizes revenue from certain long-term contracts over the contractual period under the POC method of accounting. This method of accounting recognizes sales and gross profit as work is performed based on the relationship between actual costs incurred and total estimated costs at completion. Recognized revenues that will not be billed under the terms of the contract until a later date are recorded primarily in accounts receivable. Likewise, contracts where billings to date have exceeded recognized revenues are recorded primarily in other current liabilities. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. Sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. Claims against customers are recognized as revenue upon settlement. The use of the POC method of accounting involves considerable use of estimates in determining revenues, costs and profits and in assigning the amounts to accounting periods. The periodic reviews have not resulted in adjustments that were significant to the Company’s results of operations. The Company continually evaluates all of the assumptions, risks and uncertainties inherent with the application of the POC method of accounting.

[0000833444-16-000216:notes:462]
The Buildings business enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized on a straight-line basis over the respective contract term.

[0000833444-16-000216:notes:463]
The Buildings business also sells certain heating, ventilating and air conditioning (HVAC) and refrigeration products and services in bundled arrangements, where multiple products and/or services are involved. Significant deliverables within these arrangements include equipment, commissioning, service labor and extended warranties. Approximately four to twelve months separate the timing of the first deliverable until the last piece of equipment is delivered, and there may be extended warranty arrangements with duration of one to five years commencing upon the end of the standard warranty period. In addition, the Building's business sells security monitoring systems that may have multiple elements, including equipment, installation, monitoring services and maintenance agreements. Revenues associated with sale of equipment and related installations are recognized once delivery, installation and customer acceptance is completed, while the revenue for monitoring and maintenance services are recognized as services are rendered. In accordance with ASU No. 2009-13, "Revenue Recognition (Topic 605): Multiple-Deliverable Revenue Arrangements - A Consensus of the FASB Emerging Issues Task Force," the Company divides bundled arrangements into separate deliverables and revenue is allocated to each deliverable based on the relative selling price method. In order to estimate relative selling price, market data and transfer price studies are utilized. Revenue recognized for security monitoring equipment and installation is limited to the lesser of their allocated amounts under the estimated selling price hierarchy or the non-contingent up-front consideration received at the time of installation, since collection of future amounts under the arrangement with the customer is contingent upon the delivery of monitoring and maintenance services. For transactions in which the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized on a straight-line basis over the contract term. Non-refundable fees received in connection with the initiation of a monitoring contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the customer relationship.

[0000833444-16-000216:notes:464]
In all other cases, the Company recognizes revenue at the time title passes to the customer or as services are performed.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000833444-16-000216:notes:465]
The following schedules present changes in AOCI attributable to Johnson Controls (in millions, net of tax):

[0000833444-16-000216:notes:466]
|  | Year Ended September 30, 2016 |  | Year Ended September 30, 2015 |  | Year Ended September 30, 2014 |
| Foreign currency translation adjustments |  |  |  |  |  |
| Balance at beginning of period | $ | (1,047 | ) |  | $ | (248 | ) |  | $ | 392 |  |
| Aggregate adjustment for the period (net of tax effect of $(43), $(44) and $7) * | (105 | ) |  | (799 | ) |  | (640 | ) |
| Balance at end of period | (1,152 | ) |  | (1,047 | ) |  | (248 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |  |  |
| Balance at beginning of period | (7 | ) |  | 4 |  |  | 7 |  |
| Current period changes in fair value (net of tax effect of $(5), $(7) and $(3)) | (10 | ) |  | (17 | ) |  | (3 | ) |
| Reclassification to income (net of tax effect of $11, $3 and $0) ** | 21 |  |  | 6 |  |  | — |  |
| Balance at end of period | 4 |  |  | (7 | ) |  | 4 |  |
| Realize and unrealized gains (losses) on marketable common stock |  |  |  |  |  |
| Balance at beginning of period | — |  |  | — |  |  | 7 |  |
| Current period changes in fair value (net of tax effect of $0) | (1 | ) |  | — |  |  | (1 | ) |
| Reclassifications to income (net of tax effect of $0, $0 and $(2)) *** | — |  |  | — |  |  | (6 | ) |
| Balance at end of period | (1 | ) |  | — |  |  | — |  |
| Pension and postretirement plans |  |  |  |  |  |
| Balance at beginning of period | (3 | ) |  | 7 |  |  | 12 |  |
| Reclassification to income (net of tax effect of $0, $(3) and $(3)) **** | (1 | ) |  | (11 | ) |  | (4 | ) |
| Other changes (net of tax effect of $0) | — |  |  | 1 |  |  | (1 | ) |
| Balance at end of period | (4 | ) |  | (3 | ) |  | 7 |  |
| Accumulated other comprehensive loss, end of period | $ | (1,153 | ) |  | $ | (1,057 | ) |  | $ | (237 | ) |

[0000833444-16-000216:notes:467]
*   During fiscal 2015, ($19) million of cumulative CTA were recognized as part of the divestiture-related gain recognized within discontinued operations as a result of the divestiture of GWS. During fiscal 2014, $203 million of cumulative CTA were recognized as part of the divestiture-related losses recognized within discontinued operations as a result of the divestiture of the Automotive Experience Electronics business.

[0000833444-16-000216:notes:468]
**   Refer to Note 10, "Derivative Instruments and Hedging Activities," of the notes to consolidated financial statements for disclosure of the line items on the consolidated statements of income affected by reclassifications from AOCI into income related to derivatives.

[0000833444-16-000216:notes:469]
***   During fiscal 2014, the Company sold certain marketable common stock for approximately $25 million. As as result, the Company recorded $8 million of realized gains within selling, general and administrative expenses in the Automotive Experience Seating segment.

[0000833444-16-000216:notes:470]
****   Refer to Note 15, "Retirement Plans," of the notes to consolidated financial statements for disclosure of the components of the Company's net periodic benefit costs associated with its defined benefit pension and postretirement plans.  For the year ended September 30, 2016, the amounts reclassified from AOCI into income for pension and postretirement plans were primarily recorded in selling, general and administrative expenses on the consolidated statements of income. For the year ended September 30, 2015 the amounts reclassified from AOCI into income for pension and postretirement plans were primarily recorded in selling, general and administrative expenses and income (loss) from discontinued operations, net of tax on the consolidated statements of income. For the year ended September 30, 2014, the amounts reclassified from AOCI into income for pension and postretirement plans were primarily recorded in cost of sales and income (loss) from discontinued operations, net of tax on the consolidated statements of income.


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000833444-16-000216:notes:471]
Financial information relating to the Company’s operations by geographic area is as follows (in millions):

[0000833444-16-000216:notes:472]
|  | Year Ended September 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Net Sales |  |  |  |  |  |
| United States | $ | 16,214 |  |  | $ | 16,841 |  |  | $ | 16,596 |  |
| Germany | 3,331 |  |  | 3,375 |  |  | 3,853 |  |
| Japan | 2,262 |  |  | 753 |  |  | 1,064 |  |
| Mexico | 1,637 |  |  | 1,933 |  |  | 2,001 |  |
| Other European countries | 6,860 |  |  | 7,320 |  |  | 8,913 |  |
| Other foreign | 7,370 |  |  | 6,957 |  |  | 6,322 |  |
| Total | $ | 37,674 |  |  | $ | 37,179 |  |  | $ | 38,749 |  |
| Long-Lived Assets (Year-end) |  |  |  |  |  |
| United States | $ | 3,500 |  |  | $ | 2,681 |  |  | $ | 2,762 |  |
| Germany | 650 |  |  | 680 |  |  | 910 |  |
| Japan | 253 |  |  | 74 |  |  | 77 |  |
| Mexico | 708 |  |  | 594 |  |  | 567 |  |
| Other European countries | 1,284 |  |  | 1,006 |  |  | 1,064 |  |
| Other foreign | 1,477 |  |  | 835 |  |  | 934 |  |
| Total | $ | 7,872 |  |  | $ | 5,870 |  |  | $ | 6,314 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000833444-16-000216:notes:473]
Financial information relating to the Company’s reportable segments is as follows (in millions):

[0000833444-16-000216:notes:474]
|  | Year Ended September 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Net Sales |  |  |  |  |  |
| Buildings |  |  |  |  |  |
| Building Efficiency |  |  |  |  |  |
| Systems and Service North America | $ | 4,292 |  |  | $ | 4,184 |  |  | $ | 4,098 |  |
| Products North America | 2,488 |  |  | 2,450 |  |  | 1,807 |  |
| Asia | 4,830 |  |  | 1,985 |  |  | 2,077 |  |
| Rest of World | 1,766 |  |  | 1,891 |  |  | 2,103 |  |
|  | 13,376 |  |  | 10,510 |  |  | 10,085 |  |
| Tyco | 808 |  |  | — |  |  | — |  |
|  | 14,184 |  |  | 10,510 |  |  | 10,085 |  |
| Automotive Experience |  |  |  |  |  |
| Seating | 16,355 |  |  | 16,539 |  |  | 17,531 |  |
| Interiors | 482 |  |  | 3,540 |  |  | 4,501 |  |
|  | 16,837 |  |  | 20,079 |  |  | 22,032 |  |
| Power Solutions | 6,653 |  |  | 6,590 |  |  | 6,632 |  |
| Total net sales | $ | 37,674 |  |  | $ | 37,179 |  |  | $ | 38,749 |  |

[0000833444-16-000216:notes:475]
|  | Year Ended September 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Segment EBIT |  |  |  |  |  |
| Buildings |  |  |  |  |  |
| Building Efficiency |  |  |  |  |  |
| Systems and Service North America (1) | $ | 412 |  |  | $ | 375 |  |  | $ | 354 |  |
| Products North America (2) | 173 |  |  | 306 |  |  | 238 |  |
| Asia (3) | 431 |  |  | 191 |  |  | 270 |  |
| Rest of World (4) | 20 |  |  | 51 |  |  | (45 | ) |
|  | 1,036 |  |  | 923 |  |  | 817 |  |
| Tyco (5) | (17 | ) |  | — |  |  | — |  |
|  | 1,019 |  |  | 923 |  |  | 817 |  |
| Automotive Experience |  |  |  |  |  |
| Seating (6) | 676 |  |  | 928 |  |  | 853 |  |
| Interiors (7) | 75 |  |  | 254 |  |  | (1 | ) |
|  | 751 |  |  | 1,182 |  |  | 852 |  |
| Power Solutions (8) | 1,253 |  |  | 1,153 |  |  | 1,052 |  |
| Total segment EBIT | $ | 3,023 |  |  | $ | 3,258 |  |  | $ | 2,721 |  |
| Net financing charges | (314 | ) |  | (288 | ) |  | (244 | ) |
| Restructuring and impairment costs | (620 | ) |  | (397 | ) |  | (324 | ) |
| Net mark-to-market adjustments on pension and postretirement plans | (503 | ) |  | (422 | ) |  | (237 | ) |
| Income from continuing operations before income taxes | $ | 1,586 |  |  | $ | 2,151 |  |  | $ | 1,916 |  |

[0000833444-16-000216:notes:476]
|  | September 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Assets |  |  |  |  |  |
| Buildings |  |  |  |  |  |
| Building Efficiency |  |  |  |  |  |
| Systems and Service North America | $ | 2,338 |  |  | $ | 2,332 |  |  | $ | 2,341 |  |
| Products North America | 4,236 |  |  | 4,193 |  |  | 4,157 |  |
| Asia | 3,668 |  |  | 1,387 |  |  | 1,418 |  |
| Rest of World | 1,416 |  |  | 1,471 |  |  | 1,642 |  |
|  | 11,658 |  |  | 9,383 |  |  | 9,558 |  |
| Tyco (9) | 28,097 |  |  | — |  |  | — |  |
|  | 39,755 |  |  | 9,383 |  |  | 9,558 |  |
| Automotive Experience |  |  |  |  |  |
| Seating | 8,888 |  |  | 8,611 |  |  | 8,969 |  |
| Interiors (9) | 1,264 |  |  | 1,265 |  |  | 321 |  |
|  | 10,152 |  |  | 9,876 |  |  | 9,290 |  |
| Power Solutions | 6,859 |  |  | 6,590 |  |  | 6,888 |  |
| Assets held for sale | 174 |  |  | 55 |  |  | 2,787 |  |
| Unallocated | 6,313 |  |  | 3,718 |  |  | 4,289 |  |
| Total | $ | 63,253 |  |  | $ | 29,622 |  |  | $ | 32,812 |  |

[0000833444-16-000216:notes:477]
|  | Year Ended September 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Depreciation/Amortization |  |  |  |  |  |
| Buildings |  |  |  |  |  |
| Building Efficiency |  |  |  |  |  |
| Systems and Service North America | $ | 38 |  |  | $ | 32 |  |  | $ | 32 |  |
| Products North America | 116 |  |  | 119 |  |  | 79 |  |
| Asia | 107 |  |  | 27 |  |  | 24 |  |
| Rest of World | 19 |  |  | 19 |  |  | 25 |  |
|  | 280 |  |  | 197 |  |  | 160 |  |
| Tyco | 53 |  |  | — |  |  | — |  |
|  | 333 |  |  | 197 |  |  | 160 |  |
| Automotive Experience |  |  |  |  |  |
| Seating | 355 |  |  | 345 |  |  | 328 |  |
| Interiors | 13 |  |  | 21 |  |  | 128 |  |
|  | 368 |  |  | 366 |  |  | 456 |  |
| Power Solutions | 252 |  |  | 297 |  |  | 315 |  |
| Discontinued Operations | — |  |  | — |  |  | 24 |  |
| Total | $ | 953 |  |  | $ | 860 |  |  | $ | 955 |  |

[0000833444-16-000216:notes:478]
|  | Year Ended September 30, |
|  | 2016 |  | 2015 |  | 2014 |
| Capital Expenditures |  |  |  |  |  |
| Buildings |  |  |  |  |  |
| Building Efficiency |  |  |  |  |  |
| Systems and Service North America | $ | 15 |  |  | $ | 22 |  |  | $ | 27 |  |
| Products North America | 217 |  |  | 160 |  |  | 123 |  |
| Global Workplace Solutions | — |  |  | 16 |  |  | 16 |  |
| Asia | 119 |  |  | 32 |  |  | 39 |  |
| Rest of World | 25 |  |  | 38 |  |  | 34 |  |
|  | 376 |  |  | 268 |  |  | 239 |  |
| Tyco | 22 |  |  | — |  |  | — |  |
|  | 398 |  |  | 268 |  |  | 239 |  |
| Automotive Experience |  |  |  |  |  |
| Seating | 444 |  |  | 437 |  |  | 420 |  |
| Interiors | 3 |  |  | 121 |  |  | 181 |  |
| Electronics | — |  |  | — |  |  | 31 |  |
|  | 447 |  |  | 558 |  |  | 632 |  |
| Power Solutions | 404 |  |  | 309 |  |  | 328 |  |
| Total | $ | 1,249 |  |  | $ | 1,135 |  |  | $ | 1,199 |  |

[0000833444-16-000216:notes:479]
| (1) | Building Efficiency - Systems and Service North America segment EBIT for the years ended September 30, 2016, 2015 and 2014 excludes $2 million, $3 million and $12 million, respectively, of restructuring and impairment costs. |

[0000833444-16-000216:notes:480]
| (2) | Building Efficiency - Products North America segment EBIT for the years ended September 30, 2016, 2015 and 2014 excludes $9 million, $11 million and $7 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2016, 2015 and 2014, Products North America segment EBIT includes $10 million, $9 million and $7 million, respectively, of equity income. |

[0000833444-16-000216:notes:481]
| (3) | Building Efficiency - Asia segment EBIT for the years ended September 30, 2016, 2015 and 2014 excludes $26 million,$11 million and $4 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2016 and 2014, Asia segment EBIT includes $100 million and $21 million, respectively, of equity income. |

[0000833444-16-000216:notes:482]
| (4) | Building Efficiency - Rest of World segment EBIT for the years ended September 30, 2016, 2015 and 2014 excludes $16 million, $13 million and $119 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2016, 2015 and 2014, Rest of World segment EBIT includes $15 million, $14 million and $7 million, respectively, of equity income. |

[0000833444-16-000216:notes:483]
| (5) | Tyco segment EBIT for the year ended September 30, 2016 excludes $85 million of restructuring and impairment costs. For the year ended September 30, 2016, Tyco segment EBIT includes $1 million of equity income. |

[0000833444-16-000216:notes:484]
| (6) | Automotive Experience - Seating segment EBIT for the years ended September 30, 2016, 2015 and 2014 excludes $284 million, $182 million and $29 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2016, 2015 and 2014, Seating segment EBIT includes $289 million, $264 million and $250 million, respectively, of equity income. |

[0000833444-16-000216:notes:485]
| (7) | Automotive Experience - Interiors segment EBIT for the years ended September 30, 2016 and 2014 excludes $17 million and $130 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2016, 2015 and 2014, Interiors segment EBIT includes $68 million, $31 million and $35 million, respectively, of equity income. |

[0000833444-16-000216:notes:486]
| (8) | Power Solutions segment EBIT for the years ended September 30, 2016, 2015 and 2014 excludes $66 million, $11 million and $16 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2016, 2015 and 2014, Power Solutions segment EBIT includes $48 million, $57 million and $75 million, respectively, of equity income. |

[0000833444-16-000216:notes:487]
| (9) | Current year and prior year amounts exclude assets held for sale. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's disposal groups classified as held for sale. |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000833444-16-000216:notes:488]
JOHNSON CONTROLS, INC. AND SUBSIDIARIES

[0000833444-16-000216:notes:489]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0000833444-16-000216:notes:490]
(In millions)

[0000833444-16-000216:notes:491]
| Year Ended September 30, | 2016 |  | 2015 |  | 2014 |
| Accounts Receivable - Allowance for Doubtful Accounts |  |  |  |  |  |
| Balance at beginning of period | $ | 82 |  |  | $ | 72 |  |  | $ | 68 |  |
| Provision charged to costs and expenses | 62 |  |  | 41 |  |  | 50 |  |
| Reserve adjustments | (16 | ) |  | (15 | ) |  | (22 | ) |
| Accounts charged off | (26 | ) |  | (16 | ) |  | (19 | ) |
| Acquisition of businesses | 92 |  |  | 1 |  |  | 1 |  |
| Currency translation | — |  |  | (1 | ) |  | (1 | ) |
| Transfers to held for sale | — |  |  | — |  |  | (5 | ) |
| Balance at end of period | $ | 194 |  |  | $ | 82 |  |  | $ | 72 |  |
| Deferred Tax Assets - Valuation Allowance |  |  |  |  |  |
| Balance at beginning of period | $ | 1,256 |  |  | $ | 1,285 |  |  | $ | 1,172 |  |
| Allowance provision for new operating and other loss carryforwards | 121 |  |  | 23 |  |  | 121 |  |
| Allowance provision benefits | (272 | ) |  | (52 | ) |  | (8 | ) |
| Acquisition of businesses | 2,459 |  |  | — |  |  | — |  |
| Balance at end of period | $ | 3,564 |  |  | $ | 1,256 |  |  | $ | 1,285 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-16-000216:notes:492]
SEGMENT INFORMATION

[0000833444-16-000216:notes:493]
ASC 280, "Segment Reporting," establishes the standards for reporting information about segments in financial statements. In applying the criteria set forth in ASC 280, the Company has determined that it has eight reportable segments for financial reporting purposes. The Company’s eight reportable segments are presented in the context of its three primary businesses - Buildings, Automotive Experience and Power Solutions.

[0000833444-16-000216:notes:494]
Buildings

[0000833444-16-000216:notes:495]
Building Efficiency

[0000833444-16-000216:notes:496]
Building Efficiency designs, produces, markets and installs HVAC and control systems that monitor, automate and integrate critical building segment equipment and conditions including HVAC, fire-safety and security in commercial buildings and in various industrial applications.

[0000833444-16-000216:notes:497]
| • | Systems and Service North America provides products and services to non-residential building and industrial applications in the North American marketplace. The products and services include HVAC and controls systems, energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and control systems. |

[0000833444-16-000216:notes:498]
| • | Products North America designs and produces heating and air conditioning solutions for residential and light commercial applications, and also markets products and refrigeration systems to the replacement and new construction markets in the North American marketplace. Products North America also includes HVAC products installed for Navy and Marine customers globally. |

[0000833444-16-000216:notes:499]
| • | Asia provides HVAC, controls and refrigeration systems and technical services to the Asian marketplace. Asia also includes the Johnson Controls-Hitachi Air Conditioning joint venture, which was formed October 1, 2015. |

[0000833444-16-000216:notes:500]
| • | Rest of World provides HVAC, controls and refrigeration systems and technical services to markets in Europe, the Middle East and Latin America. |

[0000833444-16-000216:notes:501]
Tyco

[0000833444-16-000216:notes:502]
Tyco designs, sells, installs, services and monitors integrated electronic security systems and integrated fire detection and suppression systems for commercial, industrial, retail, small business, institutional and governmental customers. The Tyco business also designs, manufactures and sells fire protection, security and life safety products, including intrusion security, anti-theft devices, breathing apparatus and access control and video management systems, for commercial, industrial, retail, residential, small business, institutional and governmental customers worldwide.

[0000833444-16-000216:notes:503]
Automotive Experience

[0000833444-16-000216:notes:504]
Automotive Experience designs and manufactures interior systems and products for passenger cars and light trucks, including vans, pick-up trucks and sport utility/crossover vehicles.

[0000833444-16-000216:notes:505]
| • | Seating produces automotive seat metal structures and mechanisms, foam, trim, fabric and complete seat systems. |

[0000833444-16-000216:notes:506]
| • | Interiors produces instrument panels, floor consoles and door panels. |

[0000833444-16-000216:notes:507]
Power Solutions

[0000833444-16-000216:notes:508]
Power Solutions services both automotive original equipment manufacturers and the battery aftermarket by providing advanced battery technology, coupled with systems engineering, marketing and service expertise.

[0000833444-16-000216:notes:509]
Management evaluates the performance of the segments based primarily on segment EBIT, which represents income from continuing operations before income taxes and noncontrolling interests excluding net financing charges, significant restructuring and impairment costs, and net mark-to-market adjustments on pension and postretirement plans. General corporate and other overhead expenses are allocated to the reportable segments in determining segment EBIT.

[0000833444-16-000216:notes:510]
The Company has significant sales to the automotive industry. In fiscal years 2016, 2015 and 2014, no customer exceeded 10% of consolidated net sales.

[0000833444-16-000216:notes:511]
Geographic Segments

[0000833444-16-000216:notes:512]
Net sales attributed to geographic locations are based on the location of the assets producing the sales. Long-lived assets by geographic location consist of net property, plant and equipment.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000833444-16-000216:notes:513]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0000833444-16-000216:notes:514]
Nature of Operations

[0000833444-16-000216:notes:515]
On September 2, 2016, Johnson Controls, Inc. ("JCI Inc.") and Tyco International plc (“Tyco”) completed their combination pursuant to the Agreement and Plan of Merger (the “Merger Agreement”), dated as of January 24, 2016, as amended by Amendment No. 1, dated as of July 1, 2016, by and among JCI Inc., Tyco and certain other parties named therein, including Jagara Merger Sub LLC, an indirect wholly owned subsidiary of Tyco (“Merger Sub”). Pursuant to the terms of the Merger Agreement, on September 2, 2016, Merger Sub merged with and into JCI Inc., with JCI Inc. being the surviving corporation in the merger and a wholly owned, indirect subsidiary of Tyco (the “Merger”). Following the Merger, Tyco changed its name to “Johnson Controls International plc.” The Merger changed the jurisdiction of organization from the United States to Ireland. The domicile to Ireland became effective on September 2, 2016.

[0000833444-16-000216:notes:516]
The merger was accounted for as a reverse acquisition using the acquisition method of accounting in accordance with Accounting Standards Codification ("ASC") 805, "Business Combinations." JCI Inc. was the accounting acquirer for financial reporting purposes. Accordingly, the historical consolidated financial statements of JCI Inc. for periods prior to this transaction are considered to be the historic financial statements of the Company. Refer to Note 2, "Merger Transaction," of the notes to consolidated financial statements for further information.

[0000833444-16-000216:notes:517]
Use of Estimates

[0000833444-16-000216:notes:518]
The preparation of consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0000833444-16-000216:notes:519]
Fair Value of Financial Instruments

[0000833444-16-000216:notes:520]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. See Note 10, "Derivative Instruments and Hedging Activities," and Note 11, "Fair Value Measurements," of the notes to consolidated financial statements for fair value of financial instruments, including derivative instruments, hedging activities and long-term debt.

[0000833444-16-000216:notes:521]
Cash in Escrow Related to Adient Debt

[0000833444-16-000216:notes:522]
At September 30, 2016, the Company held restricted cash of $2,034 million related to restricted proceeds deposited into escrow from the issuance of $2,000 million aggregate principal of unsecured, unsubordinated notes by Adient Global Holdings Ltd. ("AGH"), a wholly owned subsidiary of the Company, and are expected to be released upon the completion of the Adient spin-off. At September 30, 2015, there was no cash in escrow for this purpose. Approximately $1,500 million of the proceeds will be distributed to the Company in connection with the spin-off and approximately $500 million of the proceeds will be used for Adient's general corporate purposes.

[0000833444-16-000216:notes:523]
Restricted Cash

[0000833444-16-000216:notes:524]
At September 30, 2016, the Company held restricted cash of approximately $88 million, of which $79 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash held in escrow from business divestitures and cash restricted for payment of asbestos liabilities. As of September 30, 2015, the Company did not hold a material amount of restricted cash.

[0000833444-16-000216:notes:525]
Pre-Production Costs Related to Long-Term Supply Arrangements

[0000833444-16-000216:notes:526]
The Company’s policy for engineering, research and development, and other design and development costs related to products that will be sold under long-term supply arrangements requires such costs to be expensed as incurred or capitalized if reimbursement from the customer is contractually assured. Income related to recovery of these costs is recorded within selling, general and administrative expense in the consolidated statements of income. At September 30, 2016 and 2015, the Company recorded within the consolidated statements of financial position approximately $316 million and $299 million, respectively, of engineering and research and development costs for which customer reimbursement is contractually assured. The reimbursable costs are recorded in other current assets if reimbursement will occur in less than one year and in other noncurrent assets if reimbursement will occur beyond one year.

[0000833444-16-000216:notes:527]
Costs for molds, dies and other tools used to make products that will be sold under long-term supply arrangements are capitalized within property, plant and equipment if the Company has title to the assets or has the non-cancelable right to use the assets during the term of the supply arrangement. Capitalized items, if specifically designed for a supply arrangement, are amortized over the term of the arrangement; otherwise, amounts are amortized over the estimated useful lives of the assets. The carrying values of assets capitalized in accordance with the foregoing policy are periodically reviewed for impairment whenever events or changes in circumstances indicate that its carrying amount may not be recoverable. At September 30, 2016 and 2015, approximately $62 million and $60 million, respectively, of costs for molds, dies and other tools were capitalized within property, plant and equipment which represented assets to which the Company had title. In addition, at September 30, 2016 and 2015, the Company recorded within the consolidated statements of financial position in other current assets approximately $203 million and $149 million, respectively, of costs for molds, dies and other tools for which customer reimbursement is contractually assured.

[0000833444-16-000216:notes:528]
Property, Plant and Equipment

[0000833444-16-000216:notes:529]
Research and Development Costs

[0000833444-16-000216:notes:530]
Expenditures for research activities relating to product development and improvement are charged against income as incurred and included within selling, general and administrative expenses in the consolidated statements of income. Such expenditures for the years ended September 30, 2016, 2015 and 2014 were $618 million, $733 million and $792 million, respectively. A portion of the costs associated with these activities is reimbursed by customers and, for the fiscal years ended September 30, 2016, 2015 and 2014 were $308 million, $364 million and $352 million, respectively.

[0000833444-16-000216:notes:531]
Investments

[0000833444-16-000216:notes:532]
The Company invests in debt and equity securities which are classified as available for sale and are marked to market at the end of each accounting period. Unrealized gains and losses on these securities, other than the deferred compensation plan assets, are recognized in accumulated other comprehensive loss within the consolidated statement of shareholders' equity unless an unrealized loss is deemed to be other than temporary, in which case such loss is charged to earnings. The deferred compensation plan assets are marked to market at the end of each accounting period and all unrealized gains and losses are recorded in the consolidated statements of income.

[0000833444-16-000216:notes:533]
Pension and Postretirement Benefits

[0000833444-16-000216:notes:534]
The Company utilizes a mark-to-market approach for recognizing pension and postretirement benefit expenses, including measuring the market related value of plan assets at fair value and recognizing actuarial gains and losses in the fourth quarter of each fiscal year or at the date of a remeasurement event. Refer to Note 15, "Retirement Plans," of the notes to consolidated financial statements for disclosure of the Company's pension and postretirement benefit plans.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-16-000216:notes:535]
EQUITY AND NONCONTROLLING INTERESTS

[0000833444-16-000216:notes:536]
Share Capital

[0000833444-16-000216:notes:537]
In September 2016, as a result of the Tyco Merger and further discussed within Note 2, "Merger Transaction," of the notes to  consolidated financial statements, each outstanding share of common stock, par value $1.00 per share, of JCI Inc. common stock (other than shares held by JCI Inc., Tyco and certain of their subsidiaries) was converted into the right to receive either a cash consideration or a share consideration.

[0000833444-16-000216:notes:538]
The shares outstanding as of the merger date were calculated as follows (in millions, except share consolidation ratio and per share data):

[0000833444-16-000216:notes:539]
| Pre-merger Tyco shares outstanding |  | 427.2 |  |
| Share consolidation ratio |  | 0.955 |  |
| Post-share consolidation Tyco shares |  | 408.0 |  |
| Johnson Controls Inc. shares outstanding |  | 638.3 |  |
| Cash contributed by Tyco used to purchase shares of Johnson Controls Inc. |  | $ | 3,864 |  |
| Johnson Controls Inc. per share consideration |  | $ | 34.88 |  |
| Reduction in shares due to cash consideration paid by Tyco |  | (110.8 | ) |
| Adjusted Johnson Controls Inc. shares outstanding (1:1 exchange ratio) |  | 527.5 |  |
| Shares outstanding at September 2, 2016 |  | 935.5 |  |
| Par value |  | $ | 9 |  |

[0000833444-16-000216:notes:540]
Dividends

[0000833444-16-000216:notes:541]
The authority to declare and pay dividends is vested in the Board of Directors. The timing, declaration and payment of future dividends to holders of the Company's ordinary shares will be determined by the Company's Board of Directors and will depend upon many factors, including the Company's financial condition and results of operations, the capital requirements of the Company's businesses, industry practice and any other relevant factors.

[0000833444-16-000216:notes:542]
Under Irish law, dividends may only be paid (and share repurchases and redemptions must generally be funded) out of “distributable reserves.” The creation of distributable reserves was accomplished by way of a capital reduction, which the Irish High Court approved on December 18, 2014 and as acquired in conjunction with the Tyco Merger.

[0000833444-16-000216:notes:543]
Share Repurchase Program

[0000833444-16-000216:notes:544]
Following the Tyco Merger, the Company adopted, subject to the ongoing existence of sufficient distributable reserves, the existing Tyco International plc $1 billion share repurchase program in September 2016. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. There were no shares repurchased between the closing of the Merger and September 30, 2016. Prior to the Merger, the Company repurchased approximately $501 million of its shares under JCI Inc.'s $3.65 billion share repurchase program during fiscal year 2016. During fiscal years 2015 and 2014, the Company repurchased approximately $1.4 billion and $1.2 billion of its common stock, respectively.

[0000833444-16-000216:notes:545]
Other comprehensive income includes activity relating to discontinued operations. The following schedules present changes in consolidated equity attributable to Johnson Controls and noncontrolling interests (in millions, net of tax):

[0000833444-16-000216:notes:546]
The equity attributable to Johnson Controls International plc increased by $15.8 billion as a result of the Tyco Merger.  The increase is primarily due to an increase to equity of $19.7 billion resulting from the total fair value of consideration transferred, partially offset by a decrease of $3.9 billion resulting from cash contributed by Tyco used to purchase shares of Johnson Controls Inc.

[0000833444-16-000216:notes:547]
As previously disclosed, on October 1, 2015, the Company formed a joint venture with Hitachi. In connection with the acquisition, the Company recorded equity attributable to noncontrolling interests of $691 million. Also, in connection with the Tyco merger, the Company recorded equity attributable to noncontrolling interests of $34 million.

[0000833444-16-000216:notes:548]
The Company consolidates certain subsidiaries in which the noncontrolling interest party has within their control the right to require the Company to redeem all or a portion of its interest in the subsidiary. The redeemable noncontrolling interests are reported at their estimated redemption value. Any adjustment to the redemption value impacts retained earnings but does not impact net income. Redeemable noncontrolling interests which are redeemable only upon future events, the occurrence of which is not currently probable, are recorded at carrying value.

[0000833444-16-000216:notes:549]
The following schedules present changes in the redeemable noncontrolling interests (in millions):

[0000833444-16-000216:notes:550]
|  | Year Ended September 30, 2016 |  | Year Ended September 30, 2015 |  | Year Ended September 30, 2014 |
| Beginning balance, September 30 | $ | 212 |  |  | $ | 194 |  |  | $ | 157 |  |
| Net income | 48 |  |  | 51 |  |  | 38 |  |
| Foreign currency translation adjustments | 2 |  |  | (23 | ) |  | — |  |
| Realized and unrealized gains (losses) on derivatives | (1 | ) |  | 1 |  |  | — |  |
| Dividends | (27 | ) |  | (11 | ) |  | (7 | ) |
| Other | — |  |  | — |  |  | 6 |  |
| Ending balance, September 30 | $ | 234 |  |  | $ | 212 |  |  | $ | 194 |  |


## us-gaap:SubsequentEventsTextBlock

[0000833444-16-000216:notes:551]
SUBSEQUENT EVENT

[0000833444-16-000216:notes:552]
On October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience Business from Johnson Controls to Adient plc and the issuance of ordinary shares of Adient directly to holders of Johnson Controls ordinary shares on a pro rata basis. Prior to the open of business on October 31, 2016, each of the Company's shareholders received one ordinary share of Adient plc for every 10 ordinary shares of Johnson Controls held as of the close of business on October 19, 2016, the record date for the distribution. Company shareholders received cash in lieu of fractional shares of Adient, if any. Following the separation and distribution, Adient plc is now an independent public company trading on the New York Stock Exchange (NYSE) under the symbol "ADNT." The Company did not retain any equity interest in Adient plc.

[0000833444-16-000216:notes:553]
Beginning in the first quarter of fiscal 2017, Adient’s historical financial results will be reflected in the Company’s consolidated financial statements as a discontinued operation.
