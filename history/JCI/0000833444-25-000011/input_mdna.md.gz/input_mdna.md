# JCI MD&A — 0000833444-25-000011


## mdna

[0000833444-25-000011:mdna:1]
[same as prior period, unchanged from 0000833444-24-000052:mdna:1]

[0000833444-25-000011:mdna:2]
[same as prior period, unchanged from 0000833444-24-000052:mdna:2]

[0000833444-25-000011:mdna:3]
[same as prior period, unchanged from 0000833444-24-000052:mdna:3]

[0000833444-25-000011:mdna:4]
[same as prior period, unchanged from 0000833444-24-000052:mdna:4]

[0000833444-25-000011:mdna:5]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, healthy and sustainable buildings, serving a wide range of customers around the globe. The Company’s products, services, systems and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-25-000011:mdna:6]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including residential and commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space) and energy-management consulting. The Company's OpenBlue digital software platform enables enterprises to better manage their physical spaces by combining the Company's building products and services with cutting-edge technology and digital capabilities to enable data-driven “smart building” services and solutions. The Company partners with customers by leveraging its broad product portfolio and digital capabilities, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency, enhance security, create healthy environments and reduce greenhouse gas emissions.

[0000833444-25-000011:mdna:7]
The following information should be read in conjunction with the September 30, 2024 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in the Company's Annual Report on Form 10-K for the year ended September 30, 2024 filed with the SEC on November 19, 2024. References in the following discussion and analysis to "Three Months," "First Quarter" or similar language refer to the three months ended December 31, 2024 compared to the three months ended December 31, 2023.

[0000833444-25-000011:mdna:8]
[same as prior period, unchanged from 0000833444-24-000052:mdna:9]

[0000833444-25-000011:mdna:9]
Much of the demand for the Company’s products and solutions is heavily dependent on general economic conditions, localized demand for real estate and the availability of credit, public funding or other financing sources. Positive or negative fluctuations in these dependencies could have a corresponding impact on the Company’s financial condition, results of operations and cash flows. While economic conditions in China stabilized in the three months ended December 31, 2024, industrial growth remains tempered, impacting the performance of the Building Solutions Asia Pacific segment. The Company expects economic conditions in China to continue to stabilize in fiscal 2025, however, if conditions do not stabilize, results of the Building Solutions Asia Pacific segment could be negatively impacted.

[0000833444-25-000011:mdna:10]
As a result of the Company’s global presence, a significant portion of its revenues and expenses is denominated in currencies other than the U.S. dollar, which results in non-U.S. currency risks and exchange exposure. While the Company employs financial instruments to hedge some of its transactional foreign exchange exposure, these activities do not insulate it completely from those exposures. In addition, currency exposure from the translation of non-U.S. dollar functional currency subsidiaries cannot be hedged. Exchange rates can be volatile and a substantial weakening or strengthening of foreign currencies against the U.S. dollar could increase or reduce the Company’s profit margin, respectively, and impact the comparability of results from period to period. Revenue and profits were negatively impacted by movements in foreign exchange rates against the U.S. dollar during the three months ended December 31, 2024.

[0000833444-25-000011:mdna:11]
The Company continues to observe trends demonstrating increased interest and demand for its products and services that enable smart, safe, efficient and sustainable buildings, which are driven in part by government tax incentives, building performance standards and other regulations designed to limit emissions and combat climate change. In particular, legislative and regulatory initiatives such as the U.S. Climate Smart Buildings Initiative, U.S. Inflation Reduction Act and EU Energy Performance of Buildings Directive include provisions designed to fund and encourage investment in decarbonization and digital technologies for buildings. This demand is supplemented by an increase in commitments in both the public and private sectors to reduce emissions and/or achieve net zero emissions. Combined with its investment in digital and product capabilities, including its OpenBlue platform, the Company seeks to capitalize on these trends to enable delivery of sustainable, high-efficiency products and tailored services to enable customers to achieve their sustainability goals. The Company is leveraging its install base, together with data-driven products and services, to offer outcome-based solutions to customers with a focus on generating accelerated growth in services and recurring revenue.

[0000833444-25-000011:mdna:12]
The Company has experienced, and could again experience, increased material cost inflation and component shortages, as well as disruptions and delays in its supply chain, as a result of global macroeconomic trends, including increased global demand, the imposition of tariffs and other restrictive trade measures, geopolitical and economic tensions, including the conflict between Russia and Ukraine and Israel and Hamas, and labor shortages. Recently, the United States has announced tariffs on products manufactured in several jurisdictions, including, Mexico, China and Canada, and has made announcements regarding the potential imposition of tariffs on other jurisdictions, such as the European Union. The United States has and may in the future pause, reimpose or increase tariffs, and countries subject to such tariffs have and in the future may impose reciprocal tariffs or

[0000833444-25-000011:mdna:13]
other restrictive trade measures in response to the imposition of tariffs by the United States. The Company is actively monitoring and evaluating the development and potential impacts of tariffs on its supply chain and results of operations.

[0000833444-25-000011:mdna:14]
The Company maintains operations worldwide, including the jurisdictions impacted by the recently announced and contemplated tariffs. If the actual and potential tariffs and reciprocal tariffs are implemented as currently proposed, the Company expects that such actions will negatively impact its revenue growth and margins in future periods. The net effect of these events will depend on the Company’s ability to successfully mitigate and offset their impact. The Company has historically taken actions to mitigate trade restrictions, supply chain disruptions and inflation, including, price increases, expanding and redistributing its supplier network, supplier financing, accelerated purchasing and productivity improvements. These actions have generally been successful in offsetting some, but not all, of the impact of these trends.

[0000833444-25-000011:mdna:15]
The extent to which the Company’s results of operations and financial condition are impacted by these and other factors in the future will depend on developments that are highly uncertain and cannot be predicted. See the section entitled "Risk Factors" in Johnson Controls' Annual Report on Form 10-K for the year ended September 30, 2024 filed with the United States Securities and Exchange Commission ("SEC") on November 19, 2024.

[0000833444-25-000011:mdna:16]
[same as prior period, unchanged from 0000833444-24-000052:mdna:16]

[0000833444-25-000011:mdna:17]
The Company has been engaged in an ongoing evaluation of its non-core product lines in connection with its objective to be a pure-play provider of comprehensive solutions for commercial buildings. During the fourth quarter of fiscal 2024, the Company completed the sale of its Air Distribution Technologies business included within the Global Products segment. During the fourth quarter of fiscal 2024, the Company entered into a definitive agreement to sell its Residential and Light Commercial ("R&LC") HVAC business to Robert Bosch GmbH (“Bosch”) for approximately $8.1 billion in cash with the Company's portion of the aggregate consideration being approximately $6.7 billion, inclusive of an upfront royalty payment for the licensing of the York tradename. The R&LC HVAC business includes the Company's North America Ducted business and Johnson Controls-Hitachi Air Conditioning Holding (UK) Ltd., the Company’s global residential joint venture with Hitachi Global Life Solutions, Inc. (“Hitachi”), of which the Company owns 60% and Hitachi owns 40%. The R&LC HVAC business, which was previously reported in the Global Products segment, meets the criteria to be classified as a discontinued operation and, as a result, its historical financial results are reflected in the consolidated financial statements as a discontinued operation, and assets and liabilities were reclassified as held for sale for all periods presented. The Company expects that the sale of the R&LC HVAC business will close in the fourth quarter of fiscal 2025.

[0000833444-25-000011:mdna:18]
Restructuring and Cost Optimization Initiatives

[0000833444-25-000011:mdna:19]
During the fourth quarter of fiscal 2024, the Company committed to a multi-year restructuring plan to address stranded costs and further right-size its global operations as a result of previously announced portfolio simplification actions. It is expected that one-time restructuring costs, including severance and other employee termination benefits, contract termination costs, and certain other related cash and non-cash charges, of approximately $400 million will be incurred over the course of fiscal 2025, 2026 and 2027, resulting in expected annual cost savings of approximately $500 million upon full completion of the plan. The Company’s ability to execute the most significant aspects of the restructuring plan will be dependent on the timing of the close of the R&LC HVAC business divestiture transaction. Accordingly, the Company is unable to estimate the specific costs to be incurred and savings to be achieved in fiscal 2025; however, depending on the timing of the closing of the transaction and the ability to execute more significant aspects of the planned restructuring actions, the impact of costs on net income could be material in fiscal 2025. Restructuring costs will be incurred across all segments and Corporate functions.

[0000833444-25-000011:mdna:20]
[same as prior period, unchanged from 0000833444-24-000052:mdna:18]

[0000833444-25-000011:mdna:21]
During the weekend of September 23, 2023, the Company became aware of a cybersecurity incident impacting its internal information technology ("IT") infrastructure and applications. The overall impact of the cybersecurity incident did not have a material impact on net income, net of insurance recoveries, or cash flows from operations in the first quarter of fiscal 2024. A substantial portion of its direct costs incurred related to containing, investigating and remediating the incident, as well as business interruption losses, was reimbursed through insurance recoveries.

[0000833444-25-000011:mdna:22]
The Company is completing its analysis of the impacted data and believes based on its assessment to date that certain data, including employee, job applicant, consultant and other third party personally identifiable information and other related data, was impacted by the incident. The Company will, as determined appropriate, notify impacted individuals and regulatory authorities.

[0000833444-25-000011:mdna:23]
Based on the information reviewed to date, the Company has not observed evidence of any impact to its digital products, services and solutions, including OpenBlue and Metasys.

[0000833444-25-000011:mdna:24]
[same as prior period, unchanged from 0000833444-24-000052:mdna:26]

[0000833444-25-000011:mdna:25]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2024 |  | 2023 |  | Change |  |  |  |  |  |  |
| Net sales | $ | 5,426 |  |  | $ | 5,209 |  |  | 4 | % |  |  |  |  |  |  |

[0000833444-25-000011:mdna:26]
The increase in net sales for the three months ended December 31, 2024 was due to higher organic sales ($480 million), partially offset by the net impact of acquisitions and divestitures ($230 million) and the unfavorable impact of foreign currency translation ($33 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, net sales increased 10% over the prior year, driven by strong growth in Products and Systems in the Building Solutions North America and Global Products segments and growth in Services in all Building Solutions segments.

[0000833444-25-000011:mdna:27]
[same as prior period, unchanged from 0000833444-24-000052:mdna:30]

[0000833444-25-000011:mdna:28]
[same as prior period, unchanged from 0000833444-24-000052:mdna:31]

[0000833444-25-000011:mdna:29]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2024 |  | 2023 |  | Change |  |  |  |  |  |  |
| Cost of sales | $ | 3,500 |  |  | $ | 3,431 |  |  | 2 | % |  |  |  |  |  |  |
| Gross profit | 1,926 |  |  | 1,778 |  |  | 8 | % |  |  |  |  |  |  |
| % of sales | 35.5 | % |  | 34.1 | % |  |  |  |  |  |  |  |  |

[0000833444-25-000011:mdna:30]
The increase in gross profit for the three months ended December 31, 2024 was primarily due to margin improvements in the Building Solutions segments as a result of strategically building backlog with long-term, higher margin Systems projects.

[0000833444-25-000011:mdna:31]
[same as prior period, unchanged from 0000833444-24-000052:mdna:35]

[0000833444-25-000011:mdna:32]
[same as prior period, unchanged from 0000833444-24-000052:mdna:36]

[0000833444-25-000011:mdna:33]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2024 |  | 2023 |  | Change |  |  |  |  |  |  |
| SG&A | $ | 1,399 |  |  | $ | 1,334 |  |  | 5 | % |  |  |  |  |  |  |
| % of sales | 25.8 | % |  | 25.6 | % |  |  |  |  |  |  |  |  |

[0000833444-25-000011:mdna:34]
For the three months ended December 31, 2024, increases in SG&A were primarily due to transformation costs and transaction/separation costs.

[0000833444-25-000011:mdna:35]
Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA.

[0000833444-25-000011:mdna:36]
[same as prior period, unchanged from 0000833444-24-000052:mdna:41]

[0000833444-25-000011:mdna:37]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2024 |  | 2023 |  |  |  |  |  |  |  |
| Restructuring and impairment costs | $ | 33 |  |  | $ | 35 |  |  |  |  |  |  |  |  |

[0000833444-25-000011:mdna:38]
Refer to Note 14, "Restructuring and Related Costs," of the notes to the consolidated financial statements for further disclosure related to the Company's restructuring actions.

[0000833444-25-000011:mdna:39]
[same as prior period, unchanged from 0000833444-24-000052:mdna:44]

[0000833444-25-000011:mdna:40]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2024 |  | 2023 |  |  |  |  |  |  |  |  |
| Interest expense, net of capitalized interest costs | $ | 67 |  |  | $ | 85 |  |  |  |  |  |  |  |  |  |
| Other financing charges | 6 |  |  | 22 |  |  |  |  |  |  |  |  |  |
| Interest income, net of foreign exchange results | (3) |  |  | (5) |  |  |  |  |  |  |  |  |  |
| Net foreign exchange results for financing activities | 16 |  |  | (15) |  |  |  |  |  |  |  |  |  |
| Net financing charges | $ | 86 |  |  | $ | 87 |  |  |  |  |  |  |  |  |  |

[0000833444-25-000011:mdna:41]
Refer to Note 8, "Debt and Financing Arrangements," of the notes to the consolidated financial statements for further disclosure related to the Company's debt.

[0000833444-25-000011:mdna:42]
Income Tax Provision (Benefit)

[0000833444-25-000011:mdna:43]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2024 |  | 2023 |  |  |  |  |  |  |  |  |
| Income tax provision (benefit) | $ | 47 |  |  | $ | (20) |  |  |  |  |  |  |  |  |  |
| Effective tax rate | 11.5 | % |  | (6.3) | % |  |  |  |  |  |  |  |  |

[0000833444-25-000011:mdna:44]
Refer to Note 15, "Income Taxes" of the notes to the consolidated financial statements for further disclosure related to the Company's income taxes.

[0000833444-25-000011:mdna:45]
[same as prior period, unchanged from 0000833444-24-000052:mdna:52]

[0000833444-25-000011:mdna:46]
Management evaluates the performance of its segments primarily on segment earnings before interest, taxes and amortization ("EBITA"), which represents income from continuing operations before income taxes and noncontrolling interests, excluding corporate expenses, amortization of intangible assets, restructuring and impairment costs, the water systems AFFF settlement costs and insurance recoveries, net mark-to-market gains and losses related to pension and postretirement plans and restricted asbestos investments, and net financing charges.

[0000833444-25-000011:mdna:47]
[same as prior period, unchanged from 0000833444-24-000052:mdna:54]

[0000833444-25-000011:mdna:48]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2024 |  | 2023 |  | Change |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,744 |  |  | $ | 2,487 |  |  | 10 | % |  |  |  |  |  |  |
| Building Solutions EMEA/LA | 1,073 |  |  | 1,038 |  |  | 3 | % |  |  |  |  |  |  |
| Building Solutions Asia Pacific | 527 |  |  | 507 |  |  | 4 | % |  |  |  |  |  |  |
| Global Products | 1,082 |  |  | 1,177 |  |  | (8 | %) |  |  |  |  |  |  |
|  | $ | 5,426 |  |  | $ | 5,209 |  |  | 4 | % |  |  |  |  |  |  |

[0000833444-25-000011:mdna:49]
•The increase in Building Solutions North America was primarily due to organic growth ($260 million). Sales growth was led by high teens growth in Applied HVAC and Controls. Products and systems sales increased 12% and Services increased 9%.

[0000833444-25-000011:mdna:50]
•The increase in Building Solutions EMEA/LA was primarily due to organic growth ($57 million), partially offset by the unfavorable impact of foreign currency translation ($25 million). Excluding the impact of foreign currency translation, sales growth was primarily led by 10% growth in Services. Fire and Security sales increased high single digits.

[0000833444-25-000011:mdna:51]
•The increase in Building Solutions Asia Pacific was primarily due to organic growth ($23 million). Sales growth was led by 14% growth in Services.

[0000833444-25-000011:mdna:52]
•The decrease in Global Products was primarily due to the impact of business divestitures ($233 million), partially offset by organic growth ($140 million). Excluding the impact of business divestitures and foreign currency, sales increased 15%, led by over 30% growth in Applied HVAC.

[0000833444-25-000011:mdna:53]
[same as prior period, unchanged from 0000833444-24-000052:mdna:67]

[0000833444-25-000011:mdna:54]
|  | Three Months Ended December 31, |  |  |
| (in millions) | 2024 |  | 2023 |  | Change |  |  |  |  |  |  |
| Building Solutions North America | $ | 332 |  |  | $ | 285 |  |  | 16 | % |  |  |  |  |  |  |
| Building Solutions EMEA/LA | 108 |  |  | 80 |  |  | 35 | % |  |  |  |  |  |  |
| Building Solutions Asia Pacific | 49 |  |  | 46 |  |  | 7 | % |  |  |  |  |  |  |
| Global Products | 326 |  |  | 267 |  |  | 22 | % |  |  |  |  |  |  |

[0000833444-25-000011:mdna:55]
•The increase in Building Solutions North America was primarily due to higher margin backlog conversion, partially offset by impacts from ongoing growth investments.

[0000833444-25-000011:mdna:56]
•The increase in Building Solutions EMEA/LA was primarily driven by productivity improvements and positive mix from the growth in Services.

[0000833444-25-000011:mdna:57]
•The increase in Building Solutions Asia Pacific was primarily driven by positive mix from the Service business.

[0000833444-25-000011:mdna:58]
•The increase in Global Products was primarily due to increased volumes and enhanced operational efficiencies.

[0000833444-25-000011:mdna:59]
[same as prior period, unchanged from 0000833444-24-000052:mdna:79]

[0000833444-25-000011:mdna:60]
Backlog and orders are additional metrics that are meant to provide management with a deeper level of insight into the progress of specific strategic and growth initiatives. Backlog is applicable to sales of products and systems and services and totaled $15.3 billion at December 31, 2024, including both the Building Solutions and Global Products segments. Orders provide management with a signal of customer demand for the Company's products and services, as well as an indication of future

[0000833444-25-000011:mdna:61]
revenues and performance. However, the timing and conversion of backlog and orders are subject to numerous uncertainties and risks and are not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-25-000011:mdna:62]
[same as prior period, unchanged from 0000833444-24-000052:mdna:81]

[0000833444-25-000011:mdna:63]
|  | Backlog |  | Orders |
| (in billions) | December 31, 2024 |  |  |  | Year-over-Year Change (1) |  | Three months ended December 31, 2024 |  |  |  | Year-over-Year Change (1) |
| Building Solutions North America | $ | 9.3 |  |  |  |  | 12 | % |  | $ | 3.0 |  |  |  |  | 18 | % |
| Building Solutions EMEA/LA | 2.4 |  |  |  |  | 5 | % |  | 1.2 |  |  |  |  | 6 | % |
| Building Solutions Asia Pacific | 1.5 |  |  |  |  | 22 | % |  | 0.6 |  |  |  |  | 32 | % |
| Total Building Solutions | $ | 13.2 |  |  |  |  | 11 | % |  | $ | 4.8 |  |  |  |  | 16 | % |

[0000833444-25-000011:mdna:64]
(1) Change is compared to December 31, 2023 (backlog) and the three months ended December 31, 2023 (orders) and excludes the impact of mergers, acquisitions, dispositions and foreign currency.

[0000833444-25-000011:mdna:65]
Remaining performance obligations were $20.9 billion at December 31, 2024. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-25-000011:mdna:66]
[same as prior period, unchanged from 0000833444-24-000052:mdna:85]

[0000833444-25-000011:mdna:67]
[same as prior period, unchanged from 0000833444-24-000052:mdna:86]

[0000833444-25-000011:mdna:68]
[same as prior period, unchanged from 0000833444-24-000052:mdna:87]

[0000833444-25-000011:mdna:69]
[same as prior period, unchanged from 0000833444-24-000052:mdna:89]

[0000833444-25-000011:mdna:70]
[same as prior period, unchanged from 0000833444-24-000052:mdna:90]

[0000833444-25-000011:mdna:71]
| (in millions) | December 31, 2024 |  | September 30, 2024 |  | Change |
| Current assets | $ | 11,289 |  |  | $ | 11,179 |  |  |  |
| Current liabilities | 11,083 |  |  | 11,955 |  |  |  |
| Working capital | $ | 206 |  |  | $ | (776) |  |  | * |
| Accounts receivable - net | $ | 5,614 |  |  | $ | 6,051 |  |  | (7) | % |
| Inventories | 1,739 |  |  | 1,774 |  |  | (2) | % |
| Accounts payable | 3,214 |  |  | 3,389 |  |  | (5) | % |

[0000833444-25-000011:mdna:72]
[same as prior period, unchanged from 0000833444-24-000052:mdna:46]

[0000833444-25-000011:mdna:73]
•The increase in working capital at December 31, 2024 as compared to September 30, 2024 was primarily due to an increase in cash and cash equivalents, a decrease in other current liabilities due to a payment related to the AFFF settlement agreement and a decrease in accounts payable due to timing, which were partially offset by a decrease in accounts receivable.

[0000833444-25-000011:mdna:74]
[same as prior period, unchanged from 0000833444-24-000052:mdna:95]

[0000833444-25-000011:mdna:75]
|  |  | Three Months Ended December 31, |
| (in millions) |  | 2024 |  | 2023 |
| Cash provided (used) by operating activities |  | $ | 249 |  |  | $ | (111) |  |
| Cash used by investing activities |  | (105) |  |  | (64) |  |
| Cash provided by financing activities |  | 201 |  |  | 1,236 |  |

[0000833444-25-000011:mdna:76]
•The increase in cash provided by operating activities was primarily due to decreases in accounts receivable and higher cash used for inventory in the first quarter of fiscal 2024, partially offset by the timing of accounts payable and accrued liabilities payments.

[0000833444-25-000011:mdna:77]
•The increase in cash used by investing activities was primarily due to increased capital expenditures.

[0000833444-25-000011:mdna:78]
•The decrease in cash provided by financing activities was primarily due to changes in net debt activity and higher share repurchases, which were temporarily halted in the first quarter of fiscal 2024.

[0000833444-25-000011:mdna:79]
[same as prior period, unchanged from 0000833444-24-000052:mdna:100]

[0000833444-25-000011:mdna:80]
| (in millions) | December 31, 2024 |  | September 30, 2024 |  |  |
| Short-term debt | $ | 882 |  |  | $ | 953 |  |  |  |
| Current portion of long-term debt | 522 |  |  | 536 |  |  |  |
| Long-term debt | 8,589 |  |  | 8,004 |  |  |  |
| Total debt | 9,993 |  |  | 9,493 |  |  |  |
| Less: Cash and cash equivalents | 1,237 |  |  | 606 |  |  |  |
| Net debt | $ | 8,756 |  |  | $ | 8,887 |  |  |  |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders ("Equity") | $ | 15,900 |  |  | $ | 16,098 |  |  |  |
| Total capitalization (Total debt plus Equity) | 25,893 |  |  | 25,591 |  |  |  |
| Net capitalization (Net debt plus Equity) | 24,656 |  |  | 24,985 |  |  |  |
| Total debt as a % of Total capitalization | 38.6 | % |  | 37.1 | % |  |  |
| Net debt as a % of Net capitalization | 35.5 | % |  | 35.6 | % |  |  |

[0000833444-25-000011:mdna:81]
[same as prior period, unchanged from 0000833444-24-000052:mdna:102]

[0000833444-25-000011:mdna:82]
•As of December 31, 2024, approximately $1.4 billion remains available under the Company's share repurchase authorization, which does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. The Company expects to repurchase outstanding shares from time to time depending on market conditions, alternate uses of capital, liquidity, and the economic environment.

[0000833444-25-000011:mdna:83]
•The Company declared a dividend of $0.37 per common share in the quarter ended December 31, 2024 and intends to continue paying dividends throughout fiscal 2025.

[0000833444-25-000011:mdna:84]
•The Company expects to receive net cash proceeds related to the sale of its R&LC HVAC business of approximately $5.0 billion after tax and transaction-related expenses when the transaction closes, likely in the fourth quarter of fiscal 2025. Consistent with its capital allocation policy, the Company expects to use a portion of the proceeds to pay down debt to the extent required to retain its investment grade rating, with the remaining proceeds expected to be returned to shareholders through share repurchases.

[0000833444-25-000011:mdna:85]
•The Company believes its capital resources and liquidity position, including cash and cash equivalents of $1.2 billion at December 31, 2024, are adequate to fund operations and meet its cash obligations for the foreseeable future.

[0000833444-25-000011:mdna:86]
–The Company manages its short-term debt position in the U.S. and euro commercial paper and bank loan markets. Commercial paper outstanding totaled $309 million as of December 31, 2024 and $350 million as of September 30, 2024.

[0000833444-25-000011:mdna:87]
[same as prior period, unchanged from 0000833444-24-000052:mdna:108]

[0000833444-25-000011:mdna:88]
–The Company also has the ability to draw on its $2.5 billion revolving credit facility which is scheduled to expire in December 2028 or its $0.5 billion revolving credit facility which was renewed in December 2024 and is now scheduled to expire in December 2025. There were no draws on the revolving credit facilities as of December 31, 2024 and September 30, 2024.

[0000833444-25-000011:mdna:89]
•The Company's ability to access the global capital markets and the related cost of financing is dependent upon, among other factors, the Company's credit ratings. As of December 31, 2024, the Company's credit ratings and outlook were as follows:

[0000833444-25-000011:mdna:90]
[same as prior period, unchanged from 0000833444-24-000052:mdna:112]

[0000833444-25-000011:mdna:91]
[same as prior period, unchanged from 0000833444-24-000052:mdna:113]

[0000833444-25-000011:mdna:92]
•Financial covenants in the Company's revolving credit facilities require a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of December 31, 2024, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures governing its notes, and expects to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-25-000011:mdna:93]
•The Company earns a significant amount of its income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances. However, in the first quarter of fiscal 2024, the Company recorded income tax expense related to a change in the Company's assertion over the outside basis differences of the Company’s investment in certain consolidated subsidiaries as a result of the planned divestiture of its R&LC HVAC business. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. The Company's intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating

[0000833444-25-000011:mdna:94]
activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at its Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings.

[0000833444-25-000011:mdna:95]
[same as prior period, unchanged from 0000833444-24-000052:mdna:116]

[0000833444-25-000011:mdna:96]
•Refer to Note 8, "Debt and Financing Arrangements," of the notes to the consolidated financial statements for additional information on debt balances and items impacting capitalization.

[0000833444-25-000011:mdna:97]
[same as prior period, unchanged from 0000833444-24-000052:mdna:118]

[0000833444-25-000011:mdna:98]
[same as prior period, unchanged from 0000833444-24-000052:mdna:119]

[0000833444-25-000011:mdna:99]
•€500 million aggregate principal amount of 0.375% Senior Notes due 2027

[0000833444-25-000011:mdna:100]
•€600 million aggregate principal amount of 3.000% Senior Notes due 2028

[0000833444-25-000011:mdna:101]
•$700 million aggregate principal amount of 5.500% Senior Notes due 2029

[0000833444-25-000011:mdna:102]
•$625 million aggregate principal amount of 1.750% Senior Notes due 2030

[0000833444-25-000011:mdna:103]
•$500 million aggregate principal amount of 2.000% Sustainability-Linked Senior Notes due 2031

[0000833444-25-000011:mdna:104]
•€500 million aggregate principal amount of 1.000% Senior Notes due 2032

[0000833444-25-000011:mdna:105]
•$650 million aggregate principal amount of 4.900% Senior Notes due 2032

[0000833444-25-000011:mdna:106]
•€500 million aggregate principal amount of 3.125% Senior Notes due 2033

[0000833444-25-000011:mdna:107]
•€800 million aggregate principal amount of 4.250% Senior Notes due 2035

[0000833444-25-000011:mdna:108]
TFSCA is a corporate partnership limited by shares (société en commandite par actions) incorporated and organized under the laws of the Grand Duchy of Luxembourg (“Luxembourg”) and is a wholly-owned consolidated subsidiary of the Company that is 99.924% owned directly by the Parent Company and 0.076% owned by TFSCA’s sole general partner and manager, Tyco Fire & Security S.à r.l., which is itself wholly-owned by the Company. The Parent Company is incorporated and organized under the laws of Ireland. TFSCA is incorporated and organized under the laws of Luxembourg. The bankruptcy, insolvency, administrative, debtor relief and other laws of Luxembourg or Ireland, as applicable, may be materially different from, or in conflict with, those of the United States, including in the areas of rights of creditors, priority of governmental and other creditors, ability to obtain post-petition interest and duration of the proceeding. The application of these laws, or any conflict among them, could adversely affect noteholders’ ability to enforce their rights under the Notes in those jurisdictions or limit any amounts that they may receive.

[0000833444-25-000011:mdna:109]
[same as prior period, unchanged from 0000833444-24-000052:mdna:130]

[0000833444-25-000011:mdna:110]
|  |  | Three Months Ended December 31, 2024 |  | Year Ended September 30, 2024 |  |
| Net loss attributable to the Obligor Group |  | $ | 186 |  |  | $ | 609 |  |  |
| Net income (loss) attributable to intercompany transactions |  | (4) |  |  | 511 |  |  |

[0000833444-25-000011:mdna:111]
[same as prior period, unchanged from 0000833444-24-000052:mdna:132]

[0000833444-25-000011:mdna:112]
[same as prior period, unchanged from 0000833444-24-000052:mdna:133]

[0000833444-25-000011:mdna:113]
|  |  | Obligor Group |  | Intercompany Balances |
|  |  | December 31, 2024 |  | September 30, 2024 |  | December 31, 2024 |  | September 30, 2024 |
| Current assets |  | $ | 696 |  |  | $ | 1,339 |  |  | $ | 460 |  |  | $ | 823 |  |
| Noncurrent assets |  | 243 |  |  | 243 |  |  | 9,242 |  |  | 7,522 |  |
| Current liabilities |  | 7,536 |  |  | 6,726 |  |  | 999 |  |  | 2,789 |  |
| Noncurrent liabilities |  | 8,395 |  |  | 7,836 |  |  | 10,298 |  |  | 9,028 |  |

[0000833444-25-000011:mdna:114]
The same accounting policies as described in Note 1, "Summary of Significant Accounting Policies," of the Company's Annual Report on 10-K for the year ended September 30, 2024 are used by the Parent Company and each of its subsidiaries in connection with the summarized financial information presented above.

[0000833444-25-000011:mdna:115]
[same as prior period, unchanged from 0000833444-24-000052:mdna:136]

[0000833444-25-000011:mdna:116]
[same as prior period, unchanged from 0000833444-24-000052:mdna:137]

[0000833444-25-000011:mdna:117]
[same as prior period, unchanged from 0000833444-24-000052:mdna:138]

[0000833444-25-000011:mdna:118]
The Company prepares its consolidated financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). This requires management to make estimates and assumptions that affect reported amounts and related disclosures. Actual results could differ from those estimates. The Company’s critical accounting estimates requiring significant judgement that could materially impact the Company's results of operations, financial position and cash flows are described in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in the Company’s Annual Report on Form 10-K for the year ended September 30, 2024. Since the date of the Company’s most recent Annual Report, there have been no material changes in the Company’s critical accounting estimates or assumptions.
