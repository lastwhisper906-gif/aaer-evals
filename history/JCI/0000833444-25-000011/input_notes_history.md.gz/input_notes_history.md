# JCI note change history — 0000833444-24-000052 → 0000833444-25-000011


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-02-05):
[0000833444-25-000011:note_history:1]
|  | December 31, 2024 |  | September 30, 2024 |
| Other current liabilities | $ | 28 |  |  | $ | 32 |  |
| Other noncurrent liabilities | 175 |  |  | 179 |  |
| Total reserves for environmental liabilities | $ | 203 |  |  | $ | 211 |  |
  (was, 2024-07-31, similarity 0.9706):
[0000833444-24-000052:note_history:1]
|  | June 30, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 37 |  |  | $ | 31 |  |
| Other noncurrent liabilities | 180 |  |  | 211 |  |
| Total reserves for environmental liabilities | $ | 217 |  |  | $ | 242 |  |

- added (2025-02-05):
[0000833444-25-000011:note_history:2]
PFOA, PFOS, and other PFAS compounds are being studied by the U.S. Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. In March 2021, EPA published its final determination to regulate

- changed (2025-02-05):
[0000833444-25-000011:note_history:3]
PFOS and PFOA in drinking water. On April 10, 2024, EPA announced the final National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR established legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion ("ppt") for each of PFOA and PFOS, 10 ppt for each of PFHxS, PFNA, and HFPO-DA (commonly known as GenX Chemicals), and a Hazard Index of one for mixtures containing two or more of PFHxS, PFNA, HFPO-DA, and PFBA. In February 2024, EPA released two proposed rules relating to PFAS under the Resource Conservation and Recovery Act (“RCRA”): one rule proposes to list nine PFAS (including PFOA and PFOS) as “hazardous constituents,” and a second rule proposes to clarify that hazardous waste regulated under the rule includes not only substances listed or identified as hazardous waste in the regulations, but also any substances that meet the statutory definition of hazardous waste.
  (was, 2024-07-31, similarity 0.8929):
[0000833444-24-000052:note_history:3]
PFOA, PFOS, and other PFAS compounds are being studied by the U.S. Environmental Protection Agency ("EPA")  and other environmental and health agencies and researchers. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. On April 10, 2024, EPA announced the final National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR established legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion ("ppt") for each of PFOA and PFOS, 10 ppt for each of PFHxS, PFNA, and HFPO-DA (commonly known as GenX Chemicals), and a Hazard Index of one for mixtures containing two or more of PFHxS, PFNA, HFPO-DA, and PFBA. In February 2024, EPA released two proposed rules relating to PFAS under the Resource Conservation and Recovery Act (“RCRA”): one rule proposes to list nine PFAS (including PFOA and PFOS) as “hazardous constituents,” and a second rule proposes to clarify that hazardous waste regulated under the rule includes not only substances listed or identified as hazardous waste in the regulations, but also any substances that meet the statutory definition of hazardous waste.

- changed (2025-02-05):
[0000833444-25-000011:note_history:4]
It is not possible to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in soil, groundwater and drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.
  (was, 2024-07-31, similarity 0.6554):
[0000833444-24-000052:note_history:4]
It is not possible to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in soil, groundwater and drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the

- changed (2025-02-05):
[0000833444-25-000011:note_history:5]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $7 million at both December 31, 2024 and September 30, 2024.
  (was, 2024-07-31, similarity 0.8513):
[0000833444-24-000052:note_history:5]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $8 million and $13 million at June 30, 2024 and September 30, 2023, respectively.

- changed (2025-02-05):
[0000833444-25-000011:note_history:6]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the EPA to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and
  (was, 2024-07-31, similarity 0.8462):
[0000833444-24-000052:note_history:6]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with  EPA to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

- added (2025-02-05):
[0000833444-25-000011:note_history:7]
treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

- changed (2025-02-05):
[0000833444-25-000011:note_history:8]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water in February 2022, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. In August 2024, WDNR issued a new proposed rule to adopt the EPA Maximum Contaminant Levels for PFAS in drinking water. The WDNR initiated a rulemaking proceeding that would establish groundwater quality standards for PFOA, PFOS, perfluorobutane sulfonic acid and its potassium salt (“PFBS”) and hexafluoropropylene oxide dimer acid and its ammonium salt (“HFPO-DA”). Pursuant to state law, the WDNR has stopped work on the proposed rule and notified the state legislature that, following economic analysis, the proposed costs would exceed statutory thresholds. As a result, the state legislature is required to authorize the WDNR to allow the rulemaking to continue.
  (was, 2024-07-31, similarity 0.6724):
[0000833444-24-000052:note_history:8]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water in February 2022, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. The WDNR initiated a rulemaking proceeding that would establish groundwater quality standards for PFOA, PFOS,

- changed (2025-02-05):
[0000833444-25-000011:note_history:9]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR's requests. The parties are engaged in summary judgment and pretrial motions. The Court has continued the trial previously scheduled for March 3, 2025 and has not yet set a new trial date.
  (was, 2024-07-31, similarity 0.9161):
[0000833444-24-000052:note_history:9]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR's requests. The parties are engaged in summary judgment and pretrial motions and the court has set a trial date of December 3, 2024.

- changed (2025-02-05):
[0000833444-25-000011:note_history:10]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.
  (was, 2024-07-31, similarity 0.8963):
[0000833444-24-000052:note_history:10]
Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

- changed (2025-02-05):
[0000833444-25-000011:note_history:11]
On April 12, 2024, Tyco Fire Products agreed to a settlement with a nationwide class of public water systems that detected PFAS in their drinking water systems that they allege to be associated with the use of AFFF. Under the terms of the agreement, Tyco Fire Products agreed to contribute $750 million to resolve these PFAS claims. The settlement releases these claims against Tyco Fire Products, Chemguard, and other related corporate entities. On November 22, 2024, the Court entered final approval of the settlement agreement. In accordance with the terms of the settlement agreement, Tyco Fire Products made its final required payment of $415 million in December 2024 and has now paid the full settlement amount.
  (was, 2024-07-31, similarity 0.7067):
[0000833444-24-000052:note_history:11]
On April 12, 2024, Tyco Fire Products agreed to a settlement with a nationwide class of public water systems that detected PFAS in their drinking water systems that they allege to be associated with the use of AFFF. Under the terms of the agreement, Tyco Fire Products agreed to contribute $750 million to resolve these PFAS claims. The settlement releases these claims against Tyco Fire Products, Chemguard, and other related corporate entities. In connection with the settlement, a charge for $750 million was recorded in selling, general and administrative expenses in the consolidated statements of income in the three months ended March 31, 2024.

- changed (2025-02-05):
[0000833444-25-000011:note_history:12]
The class of public water systems included in this settlement broadly includes any public water system (as defined in the settlement agreement) that has detected PFAS in its drinking water sources as of May 15, 2024. The following systems are excluded from the settlement class: water systems owned and operated by a State or the United States government; systems that have not detected the presence of PFAS as of May 15, 2024; small transient water systems; privately-owned drinking water wells; and the water system in the city of Marinette, Wisconsin (which is included only if it so requests). The settlement does not resolve claims of public water systems that request exclusion from the class (“opt out”) pursuant to the process to be established by the MDL court. It also does not resolve potential future claims of public water systems that detect PFAS in their water systems for the first time after May 15, 2024, or certain claims not related to drinking water, such as separate alleged claims relating to real property damage or stormwater or wastewater treatment. Finally, this settlement does not affect the other categories of cases that remain at issue in the MDL, such as personal injury cases, property damage cases, other types of class actions, claims brought by state or territory attorneys general, or other types of damages alleged to be related to the historic use of AFFF manufactured and sold by Tyco Fire Products and Chemguard. While it is reasonably possible that the excluded systems or claims could result in additional future lawsuits, claims, assessments or proceedings, it is not possible to predict the outcome of any such matters, and as such, the Company is unable to develop an estimate of a possible loss or range of losses, if any, at this time.
  (was, 2024-07-31, similarity 0.8873):
[0000833444-24-000052:note_history:12]
that have not detected the presence of PFAS as of May 15, 2024; small transient water systems; privately-owned drinking water wells; and the water system in the city of Marinette, Wisconsin (which is included only if it so requests). The settlement does not resolve claims of public water systems that request exclusion from the class (“opt out”) pursuant to the process to be established by the MDL court. It also does not resolve potential future claims of public water systems that detect PFAS in their water systems for the first time after May 15, 2024, or certain claims not related to drinking water, such as separate alleged claims relating to real property damage or stormwater or wastewater treatment. Finally, this settlement does not affect the other categories of cases that remain at issue in the MDL, such as personal injury cases, property damage cases, other types of class actions, claims brought by state or territory attorneys general, or other types of damages alleged to be related to the historic use of AFFF manufactured and sold by Tyco Fire Products and Chemguard. While it is reasonably possible that the excluded systems or claims could result in additional future lawsuits, claims, assessments or proceedings, it is not possible to predict the outcome of any such matters, and as such, the Company is unable to develop an estimate of a possible loss or range of losses, if any, at this time.

- added (2025-02-05):
[0000833444-25-000011:note_history:13]
The settlement does not constitute an admission of liability or wrongdoing by Tyco Fire Products or Chemguard.

- added (2025-02-05):
[0000833444-25-000011:note_history:14]
Chemguard and Tyco Fire Products are named in 45 pending putative class actions in federal courts originating from 18 states and territories. All of these cases have been direct-filed in or transferred to the MDL. In addition, six proposed class actions were filed in Canada (British Columbia, Manitoba, Quebec and Ontario) in the past year, which name Tyco Fire Products and other manufacturers as defendants, on behalf of various classes of members (including individuals and government entities) who seek to recover for remediation (past and future) costs, claim property or other environmental damages, or claim personal injuries or other harms arising from alleged exposure to or contamination with PFAS or PFAS-containing products (including AFFF).

- changed (2025-02-05):
[0000833444-25-000011:note_history:15]
There are more than 8,800 individual or “mass” actions pending that were filed in state or federal courts originating from 52 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 8,800 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly-filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona, Illinois and Wisconsin.
  (was, 2024-07-31, similarity 0.99):
[0000833444-24-000052:note_history:15]
There are more than 7,800 individual or “mass” actions pending that were filed in state or federal courts originating from 52 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 7,800 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly-filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona, Illinois and Virginia.

- changed (2025-02-05):
[0000833444-25-000011:note_history:16]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.
  (was, 2024-07-31, similarity 0.6479):
[0000833444-24-000052:note_history:16]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including

- changed (2025-02-05):
[0000833444-25-000011:note_history:17]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and
  (was, 2024-07-31, similarity 0.8231):
[0000833444-24-000052:note_history:17]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

- added (2025-02-05):
[0000833444-25-000011:note_history:18]
disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

- changed (2025-02-05):
[0000833444-25-000011:note_history:19]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin and a federal district court in South Carolina. The insurance litigation involves numerous factual and legal issues. There are numerous factual and legal issues to be resolved in connection with these claims. The Company is presently unable to predict the outcome or ultimate financial exposure beyond the water systems AFFF settlement discussed above, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.
  (was, 2024-07-31, similarity 0.7536):
[0000833444-24-000052:note_history:19]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin and a federal district court in South Carolina. The insurance litigation

- added (2025-02-05):
[0000833444-25-000011:note_history:20]
|  | December 31, 2024 |  | September 30, 2024 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 344 |  |  | 350 |  |
| Total asbestos-related liabilities | 402 |  |  | 408 |  |
| Other current assets | 15 |  |  | 14 |  |
| Other noncurrent assets | 315 |  |  | 320 |  |
| Total asbestos-related assets | 330 |  |  | 334 |  |
| Net asbestos-related liabilities | $ | 72 |  |  | $ | 74 |  |

- added (2025-02-05):
[0000833444-25-000011:note_history:21]
|  | December 31, 2024 |  | September 30, 2024 |
| Restricted |  |  |  |
| Cash | $ | 7 |  |  | $ | 6 |  |
| Investments | 277 |  |  | 281 |  |
| Total restricted assets | 284 |  |  | 287 |  |
| Insurance receivables for asbestos-related liabilities | 46 |  |  | 47 |  |
| Total asbestos-related assets | $ | 330 |  |  | $ | 334 |  |

- changed (2025-02-05):
[0000833444-25-000011:note_history:22]
The amounts recorded for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.
  (was, 2024-07-31, similarity 0.7508):
[0000833444-24-000052:note_history:22]
The amounts recorded for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption may impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

- changed (2025-02-05):
[0000833444-25-000011:note_history:23]
|  | December 31, 2024 |  | September 30, 2024 |
| Other current liabilities | $ | 98 |  |  | $ | 92 |  |
| Accrued compensation and benefits | 20 |  |  | 20 |  |
| Other noncurrent liabilities | 247 |  |  | 239 |  |
| Total self-insured liabilities | $ | 365 |  |  | $ | 351 |  |
  (was, 2024-07-31, similarity 0.9752):
[0000833444-24-000052:note_history:23]
|  | June 30, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 98 |  |  | $ | 86 |  |
| Accrued compensation and benefits | 23 |  |  | 21 |  |
| Other noncurrent liabilities | 232 |  |  | 226 |  |
| Total self-insured liabilities | $ | 353 |  |  | $ | 333 |  |

- changed (2025-02-05):
[0000833444-25-000011:note_history:24]
|  | December 31, 2024 |  | September 30, 2024 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 13 |  |  | 13 |  |
| Total insurance receivables | $ | 18 |  |  | $ | 18 |  |
  (was, 2024-07-31, similarity 0.9718):
[0000833444-24-000052:note_history:24]
|  | June 30, 2024 |  | September 30, 2023 |
| Other current assets | $ | 6 |  |  | $ | 6 |  |
| Other noncurrent assets | 14 |  |  | 14 |  |
| Total insurance receivables | $ | 20 |  |  | $ | 20 |  |

- removed (2025-02-05):
[0000833444-24-000052:note_history:25]
various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- removed (2025-02-05):
[0000833444-24-000052:note_history:26]
perfluorobutane sulfonic acid and its potassium salt (“PFBS”) and hexafluoropropylene oxide dimer acid and its ammonium salt (“HFPO-DA”). Pursuant to state law, the WDNR has stopped work on the proposed rule and notified the state legislature that, following economic analysis, the proposed costs would exceed statutory thresholds. As a result, the state legislature is required to authorize the WDNR to allow the rulemaking to continue.

- removed (2025-02-05):
[0000833444-24-000052:note_history:27]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with

- removed (2025-02-05):
[0000833444-24-000052:note_history:28]
Tyco Fire Products contributed an initial payment of $250 million in June 2024, with the remaining $500 million due by the first quarter of fiscal 2025. Prior to the date of the final contribution, Tyco Fire Products has agreed to contribute any applicable insurance recoveries in excess of the initial $250 million payment, up to the remaining $500 million due, within a specified period following the receipt of such recovery. During the three months ended June 30, 2024, the Company recorded expected insurance recoveries of $351 million in selling, general and administrative expenses in the consolidated statements of income, substantially all of the proceeds of which are expected to be received in the fourth quarter of fiscal 2024. In accordance with its agreement and recent insurance recovery, Tyco Fire Products will make an additional payment during the fourth quarter of fiscal 2024 of approximately $90 million, reducing its final payment to approximately $410 million. The amounts and timing of any additional insurance recoveries are uncertain.

- removed (2025-02-05):
[0000833444-24-000052:note_history:29]
There are still several procedural and legal steps that must occur before the settlement is final and the remaining payment is made. The settlement is subject to final approval by the MDL court and other contingencies, and that process is expected to take several months.

- removed (2025-02-05):
[0000833444-24-000052:note_history:30]
The class of public water systems included in this settlement broadly includes any public water system (as defined in the settlement agreement) that has detected PFAS in its drinking water sources as of May 15, 2024. The following systems are excluded from the settlement class: water systems owned and operated by a State or the United States government; systems

- removed (2025-02-05):
[0000833444-24-000052:note_history:31]
The settlement does not constitute an admission of liability or wrongdoing by Tyco Fire Products or Chemguard. If the MDL court does not approve the agreement or certain terms are not fulfilled, Tyco Fire Products and Chemguard will continue to defend themselves in the litigation.

- removed (2025-02-05):
[0000833444-24-000052:note_history:32]
Chemguard and Tyco Fire Products are named in 46 pending putative class actions in federal courts originating from 18 states and territories. All of these cases have been direct-filed in or transferred to the MDL. It is anticipated that the remaining state-court action will be similarly tagged and transferred. Tyco Fire Products was also recently named in class actions in British Columbia and Quebec, Canada.

- removed (2025-02-05):
[0000833444-24-000052:note_history:33]
affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

- removed (2025-02-05):
[0000833444-24-000052:note_history:34]
involves numerous factual and legal issues. There are numerous factual and legal issues to be resolved in connection with these claims. The Company is presently unable to predict the outcome or ultimate financial exposure beyond the water systems AFFF settlement discussed above, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

- removed (2025-02-05):
[0000833444-24-000052:note_history:35]
|  | June 30, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 353 |  |  | 364 |  |
| Total asbestos-related liabilities | 411 |  |  | 422 |  |
| Other current assets | 18 |  |  | 28 |  |
| Other noncurrent assets | 310 |  |  | 273 |  |
| Total asbestos-related assets | 328 |  |  | 301 |  |
| Net asbestos-related liabilities | $ | 83 |  |  | $ | 121 |  |

- removed (2025-02-05):
[0000833444-24-000052:note_history:36]
|  | June 30, 2024 |  | September 30, 2023 |
| Restricted |  |  |  |
| Cash | $ | 10 |  |  | $ | 20 |  |
| Investments | 271 |  |  | 231 |  |
| Total restricted assets | 281 |  |  | 251 |  |
| Insurance receivables for asbestos-related liabilities | 47 |  |  | 50 |  |
| Total asbestos-related assets | $ | 328 |  |  | $ | 301 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-02-05):
[0000833444-25-000011:note_history:37]
|  | December 31, 2024 |  | September 30, 2024 |
| Other current liabilities | $ | 28 |  |  | $ | 32 |  |
| Other noncurrent liabilities | 175 |  |  | 179 |  |
| Total reserves for environmental liabilities | $ | 203 |  |  | $ | 211 |  |
  (was, 2024-07-31, similarity 0.9706):
[0000833444-24-000052:note_history:37]
|  | June 30, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 37 |  |  | $ | 31 |  |
| Other noncurrent liabilities | 180 |  |  | 211 |  |
| Total reserves for environmental liabilities | $ | 217 |  |  | $ | 242 |  |

- added (2025-02-05):
[0000833444-25-000011:note_history:38]
|  | December 31, 2024 |  | September 30, 2024 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 344 |  |  | 350 |  |
| Total asbestos-related liabilities | 402 |  |  | 408 |  |
| Other current assets | 15 |  |  | 14 |  |
| Other noncurrent assets | 315 |  |  | 320 |  |
| Total asbestos-related assets | 330 |  |  | 334 |  |
| Net asbestos-related liabilities | $ | 72 |  |  | $ | 74 |  |

- added (2025-02-05):
[0000833444-25-000011:note_history:39]
|  | December 31, 2024 |  | September 30, 2024 |
| Restricted |  |  |  |
| Cash | $ | 7 |  |  | $ | 6 |  |
| Investments | 277 |  |  | 281 |  |
| Total restricted assets | 284 |  |  | 287 |  |
| Insurance receivables for asbestos-related liabilities | 46 |  |  | 47 |  |
| Total asbestos-related assets | $ | 330 |  |  | $ | 334 |  |

- changed (2025-02-05):
[0000833444-25-000011:note_history:40]
|  | December 31, 2024 |  | September 30, 2024 |
| Other current liabilities | $ | 98 |  |  | $ | 92 |  |
| Accrued compensation and benefits | 20 |  |  | 20 |  |
| Other noncurrent liabilities | 247 |  |  | 239 |  |
| Total self-insured liabilities | $ | 365 |  |  | $ | 351 |  |
  (was, 2024-07-31, similarity 0.9752):
[0000833444-24-000052:note_history:40]
|  | June 30, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 98 |  |  | $ | 86 |  |
| Accrued compensation and benefits | 23 |  |  | 21 |  |
| Other noncurrent liabilities | 232 |  |  | 226 |  |
| Total self-insured liabilities | $ | 353 |  |  | $ | 333 |  |

- changed (2025-02-05):
[0000833444-25-000011:note_history:41]
|  | December 31, 2024 |  | September 30, 2024 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 13 |  |  | 13 |  |
| Total insurance receivables | $ | 18 |  |  | $ | 18 |  |
  (was, 2024-07-31, similarity 0.9718):
[0000833444-24-000052:note_history:41]
|  | June 30, 2024 |  | September 30, 2023 |
| Other current assets | $ | 6 |  |  | $ | 6 |  |
| Other noncurrent assets | 14 |  |  | 14 |  |
| Total insurance receivables | $ | 20 |  |  | $ | 20 |  |

- removed (2025-02-05):
[0000833444-24-000052:note_history:42]
|  | June 30, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 353 |  |  | 364 |  |
| Total asbestos-related liabilities | 411 |  |  | 422 |  |
| Other current assets | 18 |  |  | 28 |  |
| Other noncurrent assets | 310 |  |  | 273 |  |
| Total asbestos-related assets | 328 |  |  | 301 |  |
| Net asbestos-related liabilities | $ | 83 |  |  | $ | 121 |  |

- removed (2025-02-05):
[0000833444-24-000052:note_history:43]
|  | June 30, 2024 |  | September 30, 2023 |
| Restricted |  |  |  |
| Cash | $ | 10 |  |  | $ | 20 |  |
| Investments | 271 |  |  | 231 |  |
| Total restricted assets | 281 |  |  | 251 |  |
| Insurance receivables for asbestos-related liabilities | 47 |  |  | 50 |  |
| Total asbestos-related assets | $ | 328 |  |  | $ | 301 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-02-05):
[0000833444-25-000011:note_history:44]
BASIS OF PRESENTATION
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2024 filed with the SEC on November 19, 2024. The results of operations for the three month period ended December 31, 2024 are not necessarily indicative of results for the Company’s 2025 fiscal year because of seasonal and other factors.
  (was, 2024-07-31, similarity 0.9762):
[0000833444-24-000052:note_history:44]
BASIS OF PRESENTATION
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2023 filed with the SEC on December 14, 2023. The results of operations for the three and nine month periods ended June 30, 2024 are not necessarily indicative of results for the Company’s 2024 fiscal year because of seasonal and other factors.

- changed (2025-02-05):
[0000833444-25-000011:note_history:45]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, healthy and sustainable buildings, serving a wide range of customers around the globe. The Company’s products, services, systems and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.
  (was, 2024-07-31, similarity 0.9591):
[0000833444-24-000052:note_history:45]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, healthy and sustainable buildings, serving a wide range of customers in more than 150 countries. The Company’s products, services, systems and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

- added (2025-02-05):
[0000833444-25-000011:note_history:46]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including residential and commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space) and energy-management consulting. The Company's OpenBlue digital software platform enables enterprises to better manage their physical spaces by combining the Company's building products and services with cutting-edge technology and digital capabilities to enable data-driven “smart building” services and solutions. The Company partners with customers by leveraging its broad product portfolio and digital capabilities, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency, enhance security, create healthy environments and reduce greenhouse gas emissions.

- added (2025-02-05):
[0000833444-25-000011:note_history:47]
As discussed in more detail in Note 3, "Assets and Liabilities Held for Sale and Discontinued Operations", the Company has entered into a definitive agreement to sell its Residential and Light Commercial (“R&LC") HVAC business, including the North America Ducted business and the global Residential joint venture with Hitachi Global Life Solutions, Inc. (“Hitachi”), of which Johnson Controls owns 60% and Hitachi owns 40%. The R&LC HVAC business, which was previously reported in the Global Products segment, meets the criteria to be classified as a discontinued operation and, as a result, its historical financial results are reflected in the consolidated financial statements as a discontinued operation, and assets and liabilities are classified as held for sale for all periods presented. Unless otherwise noted, all activities and amounts reported in the following footnotes relate to the continuing operations of the Company and exclude activities and amounts related to the R&LC HVAC business.

- changed (2025-02-05):
[0000833444-25-000011:note_history:48]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries that are consolidated in conformity with U.S. GAAP. The results of companies acquired or disposed of during the reporting period are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company exercises significant influence, which typically occurs when its ownership interest exceeds 20%, and the Company does not have a controlling interest.
  (was, 2024-07-31, similarity 0.9517):
[0000833444-24-000052:note_history:48]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries that are consolidated in conformity with U.S. GAAP. All significant intercompany transactions have been eliminated. The results of companies acquired or disposed of during the reporting period are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company exercises significant influence, which typically occurs when its ownership interest exceeds 20%, and the Company does not have a controlling interest.

- removed (2025-02-05):
[0000833444-24-000052:note_history:49]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including residential and commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions powered by its OpenBlue software platform and capabilities. The Company partners with customers by leveraging its broad product portfolio and digital capabilities powered by OpenBlue, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency, enhance security, create healthy environments and reduce greenhouse gas emissions.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-02-05):
[0000833444-25-000011:note_history:50]
|  | December 31, |  | September 30, |
|  | 2024 |  | 2024 |
| Commercial paper | $ | 309 |  |  | $ | 350 |  |
| Term loans | 569 |  |  | 603 |  |
| Bank borrowings | 4 |  |  | — |  |
|  | $ | 882 |  |  | $ | 953 |  |
| Weighted average interest rate on short-term debt outstanding | 3.7 | % |  | 4.8 | % |

- changed (2025-02-05):
[0000833444-25-000011:note_history:51]
As of December 31, 2024, the Company had two syndicated committed revolving credit facilities, including $2.5 billion which is scheduled to expire in December 2028 and $500 million which is scheduled to expire in December 2025. There were no draws on the facilities as of December 31, 2024.
  (was, 2024-07-31, similarity 0.9027):
[0000833444-24-000052:note_history:51]
As of June 30, 2024, the Company had syndicated committed revolving credit facilities of $2.5 billion which is scheduled to expire in December 2028 and $500 million which is scheduled to expire in December 2024. There were no draws on the facilities as of June 30, 2024.

- added (2025-02-05):
[0000833444-25-000011:note_history:52]
In December 2024, the Company and its wholly-owned subsidiary, Tyco Fire & Security Finance S.C.A, co-issued the following unsecured, unsubordinated senior notes:

- added (2025-02-05):
[0000833444-25-000011:note_history:53]
•$250 million 4.900% Senior Notes due December 2032. These notes are a further issuance of the $400 million, 4.900% Senior Notes due 2032, which were originally issued in September 2022.

- added (2025-02-05):
[0000833444-25-000011:note_history:54]
•€500 million 3.125% Senior Notes due December 2033.

- removed (2025-02-05):
[0000833444-24-000052:note_history:55]
|  | June 30, |  | September 30, |
|  | 2024 |  | 2023 |
| Commercial paper | $ | 941 |  |  | $ | 200 |  |
| Term loans | 581 |  |  | 159 |  |
| Bank borrowings | 1 |  |  | 26 |  |
|  | $ | 1,523 |  |  | $ | 385 |  |
| Weighted average interest rate on short-term debt outstanding | 4.5 | % |  | 5.1 | % |

- removed (2025-02-05):
[0000833444-24-000052:note_history:56]
In June 2024, the Company completed the debt tender offer to purchase $119 million of its 5.125% Notes due 2045.
In April 2024, the Company and its wholly-owned subsidiary, Tyco Fire & Security Finance S.C.A, co-issued $700 million unsecured, unsubordinated senior notes with an interest rate of 5.50% which is due April 2029.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-02-05):
[0000833444-25-000011:note_history:57]
The fair value of long-term debt at December 31, 2024 and September 30, 2024 was as follows (in billions):
  (was, 2024-07-31, similarity 0.9468):
[0000833444-24-000052:note_history:57]
The fair value of long-term debt at June 30, 2024 and September 30, 2023 was as follows (in billions):

- changed (2025-02-05):
[0000833444-25-000011:note_history:58]
|  |  | December 31, |  | September 30, |  |
|  | 2024 |  | 2024 |  |
| Public debt |  | $ | 8.4 |  |  | $ | 8.1 |  |  |
| Other long-term debt |  | 0.2 |  |  | 0.2 |  |  |
| Total fair value of long-term debt |  | $ | 8.6 |  |  | $ | 8.3 |  |  |
  (was, 2024-07-31, similarity 0.975):
[0000833444-24-000052:note_history:58]
|  |  | June 30, |  | September 30, |  |
|  | 2024 |  | 2023 |  |
| Public debt |  | $ | 8.1 |  |  | $ | 7.1 |  |  |
| Other long-term debt |  | 0.2 |  |  | 0.4 |  |  |
| Total fair value of long-term debt |  | $ | 8.3 |  |  | $ | 7.5 |  |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-02-05):
[0000833444-25-000011:note_history:59]
|  | December 31, |  | September 30, |
|  | 2024 |  | 2024 |
| Commercial paper | $ | 309 |  |  | $ | 350 |  |
| Term loans | 569 |  |  | 603 |  |
| Bank borrowings | 4 |  |  | — |  |
|  | $ | 882 |  |  | $ | 953 |  |
| Weighted average interest rate on short-term debt outstanding | 3.7 | % |  | 4.8 | % |

- removed (2025-02-05):
[0000833444-24-000052:note_history:60]
|  | June 30, |  | September 30, |
|  | 2024 |  | 2023 |
| Commercial paper | $ | 941 |  |  | $ | 200 |  |
| Term loans | 581 |  |  | 159 |  |
| Bank borrowings | 1 |  |  | 26 |  |
|  | $ | 1,523 |  |  | $ | 385 |  |
| Weighted average interest rate on short-term debt outstanding | 4.5 | % |  | 5.1 | % |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-02-05):
[0000833444-25-000011:note_history:61]
|  |  | Three Months Ended December 31, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,695 |  |  | $ | 1,049 |  |  | $ | 2,744 |  |  | $ | 1,518 |  |  | $ | 969 |  |  | $ | 2,487 |  |
| Building Solutions EMEA/LA |  | 574 |  |  | 499 |  |  | 1,073 |  |  | 572 |  |  | 466 |  |  | 1,038 |  |
| Building Solutions Asia Pacific |  | 334 |  |  | 193 |  |  | 527 |  |  | 337 |  |  | 170 |  |  | 507 |  |
| Global Products |  | 1,082 |  |  | — |  |  | 1,082 |  |  | 1,177 |  |  | — |  |  | 1,177 |  |
| Total |  | $ | 3,685 |  |  | $ | 1,741 |  |  | $ | 5,426 |  |  | $ | 3,604 |  |  | $ | 1,605 |  |  | $ | 5,209 |  |

- changed (2025-02-05):
[0000833444-25-000011:note_history:62]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| HVAC |  | $ | 468 |  |  | $ | 533 |  |  |  |  |  |
| Fire & Security |  | 522 |  |  | 547 |  |  |  |  |  |
| Industrial Refrigeration |  | 92 |  |  | 97 |  |  |  |  |  |
| Total |  | $ | 1,082 |  |  | $ | 1,177 |  |  |  |  |  |
  (was, 2024-07-31, similarity 0.7105):
[0000833444-24-000052:note_history:62]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC |  | $ | 1,971 |  |  | $ | 1,973 |  |  | $ | 5,072 |  |  | $ | 5,170 |  |
| Fire & Security |  | 601 |  |  | 626 |  |  | 1,755 |  |  | 1,819 |  |
| Industrial Refrigeration |  | 104 |  |  | 88 |  |  | 316 |  |  | 246 |  |
| Total |  | $ | 2,676 |  |  | $ | 2,687 |  |  | $ | 7,143 |  |  | $ | 7,235 |  |

- removed (2025-02-05):
[0000833444-24-000052:note_history:63]
|  |  | Three Months Ended June 30, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,791 |  |  | $ | 1,108 |  |  | $ | 2,899 |  |  | $ | 1,636 |  |  | $ | 1,029 |  |  | $ | 2,665 |  |
| Building Solutions EMEA/LA |  | 574 |  |  | 507 |  |  | 1,081 |  |  | 571 |  |  | 474 |  |  | 1,045 |  |
| Building Solutions Asia Pacific |  | 381 |  |  | 194 |  |  | 575 |  |  | 537 |  |  | 199 |  |  | 736 |  |
| Global Products |  | 2,676 |  |  | — |  |  | 2,676 |  |  | 2,687 |  |  | — |  |  | 2,687 |  |
| Total |  | $ | 5,422 |  |  | $ | 1,809 |  |  | $ | 7,231 |  |  | $ | 5,431 |  |  | $ | 1,702 |  |  | $ | 7,133 |  |

- removed (2025-02-05):
[0000833444-24-000052:note_history:64]
|  |  | Nine Months Ended June 30, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 5,009 |  |  | $ | 3,116 |  |  | $ | 8,125 |  |  | $ | 4,641 |  |  | $ | 2,911 |  |  | $ | 7,552 |  |
| Building Solutions EMEA/LA |  | 1,718 |  |  | 1,465 |  |  | 3,183 |  |  | 1,705 |  |  | 1,346 |  |  | 3,051 |  |
| Building Solutions Asia Pacific |  | 1,026 |  |  | 547 |  |  | 1,573 |  |  | 1,489 |  |  | 560 |  |  | 2,049 |  |
| Global Products |  | 7,143 |  |  | — |  |  | 7,143 |  |  | 7,235 |  |  | — |  |  | 7,235 |  |
| Total |  | $ | 14,896 |  |  | $ | 5,128 |  |  | $ | 20,024 |  |  | $ | 15,070 |  |  | $ | 4,817 |  |  | $ | 19,887 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-02-05):
[0000833444-25-000011:note_history:65]
A performance obligation is a distinct good, service, or a bundle of goods and services promised in a contract. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When contracts with customers require significant and complex integration, contain

- changed (2025-02-05):
[0000833444-25-000011:note_history:66]
goods or services which are highly interdependent or interrelated, or are goods or services which significantly modify or customize other promises in the contracts and, therefore, are not distinct, then the entire contract is accounted for as a single performance obligation. For any contracts with multiple performance obligations, the contract’s transaction price is allocated to each performance obligation based on the estimated relative standalone selling price of each distinct good or service in the contract. For product sales, each product sold to a customer typically represents a distinct performance obligation.
  (was, 2024-07-31, similarity 0.7651):
[0000833444-24-000052:note_history:66]
A performance obligation is a distinct good, service, or a bundle of goods and services promised in a contract. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When contracts with customers require significant and complex integration, contain goods or services which are highly interdependent or interrelated, or are goods or services which significantly modify or customize other promises in the contracts and, therefore, are not distinct, then the entire contract is accounted for as a single performance obligation. For any contracts with multiple performance obligations, the contract’s transaction price is allocated to each performance obligation based on the estimated relative standalone selling price of each distinct good or service in the contract. For product sales, each product sold to a customer typically represents a distinct performance obligation.

- changed (2025-02-05):
[0000833444-25-000011:note_history:67]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of December 31, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $20.9 billion, of which approximately 64% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less and contracts that are cancellable without substantial penalty.
  (was, 2024-07-31, similarity 0.9183):
[0000833444-24-000052:note_history:67]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of June 30, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $21.4 billion, of which approximately 67% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-02-05):
[0000833444-25-000011:note_history:68]
|  |  | Three Months Ended December 31, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,695 |  |  | $ | 1,049 |  |  | $ | 2,744 |  |  | $ | 1,518 |  |  | $ | 969 |  |  | $ | 2,487 |  |
| Building Solutions EMEA/LA |  | 574 |  |  | 499 |  |  | 1,073 |  |  | 572 |  |  | 466 |  |  | 1,038 |  |
| Building Solutions Asia Pacific |  | 334 |  |  | 193 |  |  | 527 |  |  | 337 |  |  | 170 |  |  | 507 |  |
| Global Products |  | 1,082 |  |  | — |  |  | 1,082 |  |  | 1,177 |  |  | — |  |  | 1,177 |  |
| Total |  | $ | 3,685 |  |  | $ | 1,741 |  |  | $ | 5,426 |  |  | $ | 3,604 |  |  | $ | 1,605 |  |  | $ | 5,209 |  |

- changed (2025-02-05):
[0000833444-25-000011:note_history:69]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| HVAC |  | $ | 468 |  |  | $ | 533 |  |  |  |  |  |
| Fire & Security |  | 522 |  |  | 547 |  |  |  |  |  |
| Industrial Refrigeration |  | 92 |  |  | 97 |  |  |  |  |  |
| Total |  | $ | 1,082 |  |  | $ | 1,177 |  |  |  |  |  |
  (was, 2024-07-31, similarity 0.7105):
[0000833444-24-000052:note_history:69]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC |  | $ | 1,971 |  |  | $ | 1,973 |  |  | $ | 5,072 |  |  | $ | 5,170 |  |
| Fire & Security |  | 601 |  |  | 626 |  |  | 1,755 |  |  | 1,819 |  |
| Industrial Refrigeration |  | 104 |  |  | 88 |  |  | 316 |  |  | 246 |  |
| Total |  | $ | 2,676 |  |  | $ | 2,687 |  |  | $ | 7,143 |  |  | $ | 7,235 |  |

- added (2025-02-05):
[0000833444-25-000011:note_history:70]
|  |  | Location of contract balances |  | December 31, 2024 |  | September 30, 2024 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,917 |  |  | $ | 1,931 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 6 |  |  | 11 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,211 |  |  | 2,160 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 253 |  |  | 252 |  |  |  |

- changed (2025-02-05):
[0000833444-25-000011:note_history:71]
For the three months ended December 31, 2024 and 2023, the Company recognized revenue of $878 million and $839 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year.
  (was, 2024-07-31, similarity 0.6527):
[0000833444-24-000052:note_history:71]
For the three months ended June 30, 2024 and 2023, the Company recognized revenue of $269 million and $222 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year. For the nine months ended June 30, 2024 and 2023, the Company recognized revenue of $1,530 million and $1,387 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year.

- added (2025-02-05):
[0000833444-25-000011:note_history:72]
A performance obligation is a distinct good, service, or a bundle of goods and services promised in a contract. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When contracts with customers require significant and complex integration, contain

- changed (2025-02-05):
[0000833444-25-000011:note_history:73]
goods or services which are highly interdependent or interrelated, or are goods or services which significantly modify or customize other promises in the contracts and, therefore, are not distinct, then the entire contract is accounted for as a single performance obligation. For any contracts with multiple performance obligations, the contract’s transaction price is allocated to each performance obligation based on the estimated relative standalone selling price of each distinct good or service in the contract. For product sales, each product sold to a customer typically represents a distinct performance obligation.
  (was, 2024-07-31, similarity 0.7651):
[0000833444-24-000052:note_history:73]
A performance obligation is a distinct good, service, or a bundle of goods and services promised in a contract. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When contracts with customers require significant and complex integration, contain goods or services which are highly interdependent or interrelated, or are goods or services which significantly modify or customize other promises in the contracts and, therefore, are not distinct, then the entire contract is accounted for as a single performance obligation. For any contracts with multiple performance obligations, the contract’s transaction price is allocated to each performance obligation based on the estimated relative standalone selling price of each distinct good or service in the contract. For product sales, each product sold to a customer typically represents a distinct performance obligation.

- changed (2025-02-05):
[0000833444-25-000011:note_history:74]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of December 31, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $20.9 billion, of which approximately 64% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less and contracts that are cancellable without substantial penalty.
  (was, 2024-07-31, similarity 0.9183):
[0000833444-24-000052:note_history:74]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of June 30, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $21.4 billion, of which approximately 67% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.

- changed (2025-02-05):
[0000833444-25-000011:note_history:75]
|  |  | December 31, 2024 |  | September 30, 2024 |  |  |
| Other current assets |  | $ | 276 |  |  | $ | 265 |  |  |  |
| Other noncurrent assets |  | 284 |  |  | 291 |  |  |  |
| Total |  | $ | 560 |  |  | $ | 556 |  |  |  |
  (was, 2024-07-31, similarity 0.9721):
[0000833444-24-000052:note_history:75]
|  |  | June 30, 2024 |  | September 30, 2023 |  |  |
| Other current assets |  | $ | 247 |  |  | $ | 156 |  |  |  |
| Other noncurrent assets |  | 278 |  |  | 224 |  |  |  |
| Total |  | $ | 525 |  |  | $ | 380 |  |  |  |

- changed (2025-02-05):
[0000833444-25-000011:note_history:76]
During the three months ended December 31, 2024 and 2023, the Company recognized expense of $84 million and $57 million, respectively, related to costs to obtain or fulfill a contract.  There were no impairment losses recognized in the three months ended December 31, 2024 and 2023.
  (was, 2024-07-31, similarity 0.6184):
[0000833444-24-000052:note_history:76]
During the three months ended June 30, 2024 and 2023, the Company recognized amortization expense of $84 million and $66 million, respectively, related to costs to obtain or fulfill a contract. During the nine months ended June 30, 2024 and 2023, the Company recognized amortization expense of $218 million and $188 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and nine months ended June 30, 2024 and 2023.

- removed (2025-02-05):
[0000833444-24-000052:note_history:77]
|  |  | Three Months Ended June 30, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,791 |  |  | $ | 1,108 |  |  | $ | 2,899 |  |  | $ | 1,636 |  |  | $ | 1,029 |  |  | $ | 2,665 |  |
| Building Solutions EMEA/LA |  | 574 |  |  | 507 |  |  | 1,081 |  |  | 571 |  |  | 474 |  |  | 1,045 |  |
| Building Solutions Asia Pacific |  | 381 |  |  | 194 |  |  | 575 |  |  | 537 |  |  | 199 |  |  | 736 |  |
| Global Products |  | 2,676 |  |  | — |  |  | 2,676 |  |  | 2,687 |  |  | — |  |  | 2,687 |  |
| Total |  | $ | 5,422 |  |  | $ | 1,809 |  |  | $ | 7,231 |  |  | $ | 5,431 |  |  | $ | 1,702 |  |  | $ | 7,133 |  |

- removed (2025-02-05):
[0000833444-24-000052:note_history:78]
|  |  | Nine Months Ended June 30, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 5,009 |  |  | $ | 3,116 |  |  | $ | 8,125 |  |  | $ | 4,641 |  |  | $ | 2,911 |  |  | $ | 7,552 |  |
| Building Solutions EMEA/LA |  | 1,718 |  |  | 1,465 |  |  | 3,183 |  |  | 1,705 |  |  | 1,346 |  |  | 3,051 |  |
| Building Solutions Asia Pacific |  | 1,026 |  |  | 547 |  |  | 1,573 |  |  | 1,489 |  |  | 560 |  |  | 2,049 |  |
| Global Products |  | 7,143 |  |  | — |  |  | 7,143 |  |  | 7,235 |  |  | — |  |  | 7,235 |  |
| Total |  | $ | 14,896 |  |  | $ | 5,128 |  |  | $ | 20,024 |  |  | $ | 15,070 |  |  | $ | 4,817 |  |  | $ | 19,887 |  |

- removed (2025-02-05):
[0000833444-24-000052:note_history:79]
|  |  | Location of contract balances |  | June 30, 2024 |  | September 30, 2023 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,961 |  |  | $ | 2,370 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 9 |  |  | 12 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,143 |  |  | 1,996 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 314 |  |  | 297 |  |  |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2025-02-05):
[0000833444-24-000052:note_history:80]
SUBSEQUENT EVENT
On July 23, 2024, the Company entered into a Stock and Asset Purchase Agreement (“Purchase Agreement”) with Bosch GmbH, a Gesellschaft mit beschränkter Haftung (“Purchaser”). Pursuant to the Purchase Agreement, on the terms and subject to the conditions therein, the Company has agreed to sell, and Purchaser has agreed to acquire, the Company’s Residential and Light Commercial HVAC business (the “R&LC Business”), including the Company’s North America Ducted business and Johnson Controls-Hitachi Air Conditioning Holding (UK) Ltd., the Company’s global Residential joint venture with Hitachi Global Life Solutions, Inc. (“Hitachi”), of which the Company owns 60% and Hitachi owns 40%. The total consideration payable by Purchaser to the Company and Hitachi is approximately  $8.1 billion in cash, and the Company’s portion of the aggregate consideration is approximately $6.7 billion in cash, in each case, subject to adjustment, plus the assumption by Purchaser or its affiliates of certain liabilities of the R&LC Business specified in the Purchase Agreement. Net cash proceeds to the Company are expected to be approximately $5.0 billion after tax and transaction-related expenses. The transaction is expected to close in the fourth quarter of fiscal 2025, subject to required regulatory approvals and other customary closing conditions. The Company expects to report the operating results of the R&LC HVAC business, which is currently reported in the Global Products segment, in discontinued operations beginning in the fourth quarter of fiscal 2024.
