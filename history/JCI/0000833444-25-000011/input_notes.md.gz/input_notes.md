# JCI notes — 0000833444-25-000011


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-25-000011:notes:1]
BASIS OF PRESENTATION
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2024 filed with the SEC on November 19, 2024. The results of operations for the three month period ended December 31, 2024 are not necessarily indicative of results for the Company’s 2025 fiscal year because of seasonal and other factors.

[0000833444-25-000011:notes:2]
[same as prior period, unchanged from 0000833444-24-000052:notes:2]

[0000833444-25-000011:notes:3]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, healthy and sustainable buildings, serving a wide range of customers around the globe. The Company’s products, services, systems and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-25-000011:notes:4]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including residential and commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space) and energy-management consulting. The Company's OpenBlue digital software platform enables enterprises to better manage their physical spaces by combining the Company's building products and services with cutting-edge technology and digital capabilities to enable data-driven “smart building” services and solutions. The Company partners with customers by leveraging its broad product portfolio and digital capabilities, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency, enhance security, create healthy environments and reduce greenhouse gas emissions.

[0000833444-25-000011:notes:5]
As discussed in more detail in Note 3, "Assets and Liabilities Held for Sale and Discontinued Operations", the Company has entered into a definitive agreement to sell its Residential and Light Commercial (“R&LC") HVAC business, including the North America Ducted business and the global Residential joint venture with Hitachi Global Life Solutions, Inc. (“Hitachi”), of which Johnson Controls owns 60% and Hitachi owns 40%. The R&LC HVAC business, which was previously reported in the Global Products segment, meets the criteria to be classified as a discontinued operation and, as a result, its historical financial results are reflected in the consolidated financial statements as a discontinued operation, and assets and liabilities are classified as held for sale for all periods presented. Unless otherwise noted, all activities and amounts reported in the following footnotes relate to the continuing operations of the Company and exclude activities and amounts related to the R&LC HVAC business.

[0000833444-25-000011:notes:6]
[same as prior period, unchanged from 0000833444-24-000052:notes:5]

[0000833444-25-000011:notes:7]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries that are consolidated in conformity with U.S. GAAP. The results of companies acquired or disposed of during the reporting period are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company exercises significant influence, which typically occurs when its ownership interest exceeds 20%, and the Company does not have a controlling interest.

[0000833444-25-000011:notes:8]
[same as prior period, unchanged from 0000833444-24-000052:notes:7]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000833444-25-000011:notes:9]
NEW ACCOUNTING STANDARDS
Recently Adopted Accounting Pronouncements

[0000833444-25-000011:notes:10]
In September 2022, the FASB issued ASU 2022-04, "Disclosure of Supplier Finance Program Obligations," which is intended to enhance the transparency surrounding the use of supplier finance programs. Supplier finance programs may also be referred to as reverse factoring, payables finance, or structured payables arrangements. The amendments require a buyer that uses supplier finance programs to make annual disclosures about the program’s key terms, the balance sheet presentation of related amounts, the confirmed amount outstanding at the end of the period, and associated rollforward information. Only the amount outstanding at the end of the period must be disclosed in interim periods. The Company adopted the new disclosures, other than the rollforward disclosure, as required at the beginning of fiscal 2024. The rollforward disclosure will be adopted as required in fiscal 2025.

[0000833444-25-000011:notes:11]
Amounts outstanding related to supply chain financing ("SCF") programs are included in accounts payable in the consolidated statements of financial position. Accounts payable included in the SCF programs were approximately $733 million and $703 million as of December 31, 2024 and September 30, 2024, respectively.

[0000833444-25-000011:notes:12]
Recently Issued Accounting Pronouncements

[0000833444-25-000011:notes:13]
In November 2024, the FASB issued ASU 2024-03, "Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses," which is intended to enhance transparency into the nature and function of expenses. The amendments require that on an annual and interim basis, entities disclose disaggregated operating expense information about specific categories, including purchases of inventory, employee compensation, depreciation, amortization and depletion. The Company expects to adopt the new annual disclosures as required for fiscal 2028 and the interim disclosures as required beginning with the first quarter of fiscal 2029.

[0000833444-25-000011:notes:14]
In December 2023, the FASB issued ASU 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures," which is intended to enhance the transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. The amendments require that on an annual basis, entities disclose specific categories in the rate reconciliation and provide additional information for reconciling items that meet a quantitative threshold. In addition, the amendments require that entities disclose additional information about income taxes paid as well as additional disclosures of pretax income and income tax expense, and remove the requirement to disclose certain items that are no longer considered cost beneficial or relevant. The Company expects to adopt the new annual disclosures as required for fiscal 2026.

[0000833444-25-000011:notes:15]
In November 2023, the FASB issued ASU 2023-07, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures," which is intended to improve reportable segment disclosures, primarily through enhanced disclosures about significant segment expenses. In addition, the amendments enhance interim disclosure requirements, clarify circumstances in which an entity can disclose multiple segment measures of profit or loss, provide new segment disclosure requirements for entities with a single reportable segment and contain other disclosure requirements. The Company expects to adopt the new annual disclosures as required for fiscal 2025 and the interim disclosures as required beginning with the first quarter of fiscal 2026.

[0000833444-25-000011:notes:16]
Other recently issued accounting pronouncements are not expected to have a material impact on the Company's consolidated financial statements.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-25-000011:notes:17]
ASSETS AND LIABILITIES HELD FOR SALE AND DISCONTINUED OPERATIONS
In July 2024, the Company entered into a definitive agreement to sell its R&LC HVAC business, which includes the North America Ducted businesses and the global Residential joint venture with Hitachi, of which Johnson Controls owns 60% and Hitachi owns 40%, to Bosch Group for approximately $8.1 billion in cash with the Company’s portion of the aggregate consideration being approximately $6.7 billion, inclusive of an upfront royalty payment for the licensing of the York tradename. The transaction is expected to close in the fourth quarter of fiscal 2025, subject to required regulatory approvals and other customary closing conditions. The R&LC HVAC business, which was previously reported in the Global Products segment, meets the criteria to be classified as discontinued operations as it represents a strategic shift in the Company's operations and results in the exit of substantially all of its residential and light commercial HVAC businesses. Results of the business are presented in discontinued operations for all periods presented.

[0000833444-25-000011:notes:18]
The Company determined that the assets and liabilities for the R&LC HVAC business met the held for sale criteria during the fourth quarter of 2024. Accordingly, the businesses' assets and liabilities were reclassified in the consolidated balance sheets at December 31, 2024 and September 30, 2024 to held for sale, and the Company ceased recording depreciation and amortization for the held for sale assets.

[0000833444-25-000011:notes:19]
The following table summarizes the results of the R&LC HVAC business which are reported as discontinued operations (in millions):

[0000833444-25-000011:notes:20]
|  |  | Three Months Ended December 31, |  |
|  |  | 2024 |  | 2023 |  |
| Net sales |  | $ | 966 |  |  | $ | 885 |  |  |
| Cost of goods sold |  | 731 |  |  | 671 |  |  |
| Gross profit |  | 235 |  |  | 214 |  |  |
| Selling, general and administrative expenses |  | 183 |  |  | 180 |  |  |
| Restructuring and impairment costs |  | 4 |  |  | 4 |  |  |
| Net financing charges |  | (1) |  |  | 11 |  |  |
| Equity income |  | 65 |  |  | 64 |  |  |
| Income from discontinued operations before income taxes |  | 114 |  |  | 83 |  |  |
| Provision for income taxes on discontinued operations |  | 24 |  |  | 19 |  |  |
| Income from discontinued operations, net of tax |  | 90 |  |  | 64 |  |  |
| Income from discontinued operations attributable to noncontrolling interest, net of tax |  | 34 |  |  | 30 |  |  |
| Income from discontinued operations |  | $ | 56 |  |  | $ | 34 |  |  |

[0000833444-25-000011:notes:21]
The following table summarizes the assets and liabilities of the R&LC HVAC business which were classified as held for sale (in millions):

[0000833444-25-000011:notes:22]
|  |  | December 31, 2024 |  | September 30, 2024 |
| Cash |  | $ | 2 |  |  | $ | 5 |  |
| Accounts receivable - net |  | 539 |  |  | 592 |  |
| Inventories |  | 979 |  |  | 876 |  |
| Other current assets |  | 138 |  |  | 122 |  |
| Current assets held for sale |  | 1,658 |  |  | 1,595 |  |
| Property, plant and equipment - net |  | 743 |  |  | 793 |  |
| Goodwill |  | 1,130 |  |  | 1,182 |  |
| Other intangible assets - net |  | 94 |  |  | 96 |  |
| Investments in partially-owned affiliates |  | 833 |  |  | 949 |  |
| Other noncurrent assets |  | 186 |  |  | 190 |  |
| Noncurrent assets held for sale |  | 2,986 |  |  | 3,210 |  |
| Total assets classified as held for sale |  | $ | 4,644 |  |  | $ | 4,805 |  |
| Accounts payable |  | $ | 887 |  |  | $ | 917 |  |
| Accrued compensation and benefits |  | 99 |  |  | 113 |  |
| Deferred revenue |  | 112 |  |  | 84 |  |
| Other current liabilities |  | 224 |  |  | 317 |  |
| Current liabilities held for sale |  | 1,322 |  |  | 1,431 |  |
| Pension and postretirement benefit obligations |  | 25 |  |  | 28 |  |
| Other noncurrent liabilities |  | 382 |  |  | 377 |  |
| Noncurrent liabilities held for sale |  | 407 |  |  | 405 |  |
| Total liabilities classified as held for sale |  | $ | 1,729 |  |  | $ | 1,836 |  |

[0000833444-25-000011:notes:23]
Assets and liabilities classified as held for sale are required to be recorded at the lower of carrying value or fair value less costs to sell. As of December 31, 2024, the estimated fair value less costs to sell of the held for sale businesses exceeded their carrying value, and therefore, no adjustment was necessary.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-25-000011:notes:24]
[same as prior period, unchanged from 0000833444-24-000052:notes:25]

[0000833444-25-000011:notes:25]
[same as prior period, unchanged from 0000833444-24-000052:notes:26]

[0000833444-25-000011:notes:26]
|  |  | Three Months Ended December 31, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,695 |  |  | $ | 1,049 |  |  | $ | 2,744 |  |  | $ | 1,518 |  |  | $ | 969 |  |  | $ | 2,487 |  |
| Building Solutions EMEA/LA |  | 574 |  |  | 499 |  |  | 1,073 |  |  | 572 |  |  | 466 |  |  | 1,038 |  |
| Building Solutions Asia Pacific |  | 334 |  |  | 193 |  |  | 527 |  |  | 337 |  |  | 170 |  |  | 507 |  |
| Global Products |  | 1,082 |  |  | — |  |  | 1,082 |  |  | 1,177 |  |  | — |  |  | 1,177 |  |
| Total |  | $ | 3,685 |  |  | $ | 1,741 |  |  | $ | 5,426 |  |  | $ | 3,604 |  |  | $ | 1,605 |  |  | $ | 5,209 |  |

[0000833444-25-000011:notes:27]
[same as prior period, unchanged from 0000833444-24-000052:notes:29]

[0000833444-25-000011:notes:28]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| HVAC |  | $ | 468 |  |  | $ | 533 |  |  |  |  |  |
| Fire & Security |  | 522 |  |  | 547 |  |  |  |  |  |
| Industrial Refrigeration |  | 92 |  |  | 97 |  |  |  |  |  |
| Total |  | $ | 1,082 |  |  | $ | 1,177 |  |  |  |  |  |

[0000833444-25-000011:notes:29]
[same as prior period, unchanged from 0000833444-24-000052:notes:31]

[0000833444-25-000011:notes:30]
[same as prior period, unchanged from 0000833444-24-000052:notes:32]

[0000833444-25-000011:notes:31]
[same as prior period, unchanged from 0000833444-24-000052:notes:33]

[0000833444-25-000011:notes:32]
|  |  | Location of contract balances |  | December 31, 2024 |  | September 30, 2024 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,917 |  |  | $ | 1,931 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 6 |  |  | 11 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,211 |  |  | 2,160 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 253 |  |  | 252 |  |  |  |

[0000833444-25-000011:notes:33]
For the three months ended December 31, 2024 and 2023, the Company recognized revenue of $878 million and $839 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year.

[0000833444-25-000011:notes:34]
[same as prior period, unchanged from 0000833444-24-000052:notes:36]

[0000833444-25-000011:notes:35]
A performance obligation is a distinct good, service, or a bundle of goods and services promised in a contract. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When contracts with customers require significant and complex integration, contain

[0000833444-25-000011:notes:36]
goods or services which are highly interdependent or interrelated, or are goods or services which significantly modify or customize other promises in the contracts and, therefore, are not distinct, then the entire contract is accounted for as a single performance obligation. For any contracts with multiple performance obligations, the contract’s transaction price is allocated to each performance obligation based on the estimated relative standalone selling price of each distinct good or service in the contract. For product sales, each product sold to a customer typically represents a distinct performance obligation.

[0000833444-25-000011:notes:37]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of December 31, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $20.9 billion, of which approximately 64% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less and contracts that are cancellable without substantial penalty.

[0000833444-25-000011:notes:38]
[same as prior period, unchanged from 0000833444-24-000052:notes:39]

[0000833444-25-000011:notes:39]
[same as prior period, unchanged from 0000833444-24-000052:notes:40]

[0000833444-25-000011:notes:40]
[same as prior period, unchanged from 0000833444-24-000052:notes:41]

[0000833444-25-000011:notes:41]
|  |  | December 31, 2024 |  | September 30, 2024 |  |  |
| Other current assets |  | $ | 276 |  |  | $ | 265 |  |  |  |
| Other noncurrent assets |  | 284 |  |  | 291 |  |  |  |
| Total |  | $ | 560 |  |  | $ | 556 |  |  |  |

[0000833444-25-000011:notes:42]
During the three months ended December 31, 2024 and 2023, the Company recognized expense of $84 million and $57 million, respectively, related to costs to obtain or fulfill a contract.  There were no impairment losses recognized in the three months ended December 31, 2024 and 2023.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-25-000011:notes:43]
[same as prior period, unchanged from 0000833444-24-000052:notes:45]

[0000833444-25-000011:notes:44]
|  | December 31, 2024 |  | September 30, 2024 |
| Raw materials and supplies | $ | 693 |  |  | $ | 765 |  |
| Work-in-process | 140 |  |  | 130 |  |
| Finished goods | 906 |  |  | 879 |  |
| Inventories | $ | 1,739 |  |  | $ | 1,774 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-25-000011:notes:45]
[same as prior period, unchanged from 0000833444-24-000052:notes:47]

[0000833444-25-000011:notes:46]
|  |  | Three Months Ended December 31, 2024 |
|  |  | Building Solutions North America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | Total |
| Goodwill |  | $ | 10,050 |  |  | $ | 2,039 |  |  | $ | 1,227 |  |  | $ | 4,604 |  |  | 17,920 |  |
| Accumulated impairment loss |  | (659) |  |  | (277) |  |  | — |  |  | (259) |  |  | (1,195) |  |
| Balance at beginning of period |  | 9,391 |  |  | 1,762 |  |  | 1,227 |  |  | 4,345 |  |  | 16,725 |  |
| Foreign currency translation |  | (41) |  |  | (107) |  |  | (84) |  |  | (81) |  |  | (313) |  |
| Balance at end of period |  | $ | 9,350 |  |  | $ | 1,655 |  |  | $ | 1,143 |  |  | $ | 4,264 |  |  | $ | 16,412 |  |

[0000833444-25-000011:notes:47]
[same as prior period, unchanged from 0000833444-24-000052:notes:54]

[0000833444-25-000011:notes:48]
|  | December 31, 2024 |  | September 30, 2024 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Definite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,570 |  |  | $ | (973) |  |  | $ | 597 |  |  | $ | 1,592 |  |  | $ | (955) |  |  | $ | 637 |  |
| Customer relationships | 2,571 |  |  | (1,534) |  |  | 1,037 |  |  | 2,632 |  |  | (1,517) |  |  | 1,115 |  |
| Miscellaneous | 877 |  |  | (479) |  |  | 398 |  |  | 886 |  |  | (480) |  |  | 406 |  |
|  | 5,018 |  |  | (2,986) |  |  | 2,032 |  |  | 5,110 |  |  | (2,952) |  |  | 2,158 |  |
| Indefinite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 1,931 |  |  | — |  |  | 1,931 |  |  | 1,972 |  |  | — |  |  | 1,972 |  |
| Total intangible assets | $ | 6,949 |  |  | $ | (2,986) |  |  | $ | 3,963 |  |  | $ | 7,082 |  |  | $ | (2,952) |  |  | $ | 4,130 |  |

[0000833444-25-000011:notes:49]
Amortization of other intangible assets included within continuing operations for the three months ended December 31, 2024 and 2023 was $120 million and $119 million, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000833444-25-000011:notes:50]
[same as prior period, unchanged from 0000833444-24-000052:notes:57]

[0000833444-25-000011:notes:51]
|  | Location of lease balances |  | December 31, 2024 |  | September 30, 2024 |
| Operating lease right-of-use assets | Other noncurrent assets |  | $ | 1,164 |  | $ | 1,170 |  |
| Operating lease liabilities - current | Other current liabilities |  | 265 |  | 289 |  |
| Operating lease liabilities - noncurrent | Other noncurrent liabilities |  | 932 |  | 921 |  |

[0000833444-25-000011:notes:52]
[same as prior period, unchanged from 0000833444-24-000052:notes:59]

[0000833444-25-000011:notes:53]
|  |  |  |  | Three Months Ended December 31, |  |  |
|  |  |  |  |  |  | 2024 |  | 2023 |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  |  |  |  |  | $ | 130 |  |  | $ | 76 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-25-000011:notes:54]
DEBT AND FINANCING ARRANGEMENTS
Short-term debt consisted of the following (in millions):

[0000833444-25-000011:notes:55]
|  | December 31, |  | September 30, |
|  | 2024 |  | 2024 |
| Commercial paper | $ | 309 |  |  | $ | 350 |  |
| Term loans | 569 |  |  | 603 |  |
| Bank borrowings | 4 |  |  | — |  |
|  | $ | 882 |  |  | $ | 953 |  |
| Weighted average interest rate on short-term debt outstanding | 3.7 | % |  | 4.8 | % |

[0000833444-25-000011:notes:56]
As of December 31, 2024, the Company had two syndicated committed revolving credit facilities, including $2.5 billion which is scheduled to expire in December 2028 and $500 million which is scheduled to expire in December 2025. There were no draws on the facilities as of December 31, 2024.

[0000833444-25-000011:notes:57]
In December 2024, the Company and its wholly-owned subsidiary, Tyco Fire & Security Finance S.C.A, co-issued the following unsecured, unsubordinated senior notes:

[0000833444-25-000011:notes:58]
•$250 million 4.900% Senior Notes due December 2032. These notes are a further issuance of the $400 million, 4.900% Senior Notes due 2032, which were originally issued in September 2022.

[0000833444-25-000011:notes:59]
•€500 million 3.125% Senior Notes due December 2033.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-25-000011:notes:60]
DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES
Cash Flow Hedges

[0000833444-25-000011:notes:61]
[same as prior period, unchanged from 0000833444-24-000052:notes:67]

[0000833444-25-000011:notes:62]
[same as prior period, unchanged from 0000833444-24-000052:notes:70]

[0000833444-25-000011:notes:63]
As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of accumulated other comprehensive income ("AOCI") and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates and commodity prices during the three months ended December 31, 2024 and 2023.

[0000833444-25-000011:notes:64]
[same as prior period, unchanged from 0000833444-24-000052:notes:71]

[0000833444-25-000011:notes:65]
|  |  | Volume Outstanding as of |
| Commodity |  | December 31, 2024 |  | September 30, 2024 |
| Copper |  | 2,880 |  |  | 2,676 |  |
| Aluminum |  | 2,471 |  |  | 2,450 |  |

[0000833444-25-000011:notes:66]
The Company may enter into forward-starting interest rate swaps in conjunction with anticipated note issuances to manage exposure to interest rate changes. The forward-starting interest swaps are terminated when the anticipated notes are issued.

[0000833444-25-000011:notes:67]
As of December 31, 2023, $600 million of forward-starting interest swaps were outstanding on an $800 million anticipated note issuance which was subsequently terminated in fiscal 2024 once the note issuance was no longer highly likely to occur. Accumulated amounts previously recorded in AOCI were not material and were recognized as net financing charges in the consolidated statements of income when the swaps were terminated.

[0000833444-25-000011:notes:68]
[same as prior period, unchanged from 0000833444-24-000052:notes:74]

[0000833444-25-000011:notes:69]
[same as prior period, unchanged from 0000833444-24-000052:notes:75]

[0000833444-25-000011:notes:70]
[same as prior period, unchanged from 0000833444-24-000052:notes:76]

[0000833444-25-000011:notes:71]
|  |  | December 31, |  | September 30, |
|  | 2024 |  | 2024 |
| Euro-denominated bonds designated as net investment hedges in Europe |  | € | 2.9 |  |  | € | 2.9 |  |
| Yen-denominated debt designated as a net investment hedge in Japan |  | ¥ | 30 |  |  | ¥ | 30 |  |

[0000833444-25-000011:notes:72]
[same as prior period, unchanged from 0000833444-24-000052:notes:78]

[0000833444-25-000011:notes:73]
[same as prior period, unchanged from 0000833444-24-000052:notes:79]

[0000833444-25-000011:notes:74]
[same as prior period, unchanged from 0000833444-24-000052:notes:80]

[0000833444-25-000011:notes:75]
[same as prior period, unchanged from 0000833444-24-000052:notes:81]

[0000833444-25-000011:notes:76]
|  | Derivatives and Hedging Activities Designatedas Hedging Instruments |  | Derivatives and Hedging ActivitiesNot Designatedas Hedging Instruments |
|  | December 31, |  | September 30, |  | December 31, |  | September 30, |
|  | 2024 |  | 2024 |  | 2024 |  | 2024 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 42 |  |  | $ | 19 |  |  | $ | — |  |  | $ | 1 |  |
| Interest rate swaps | — |  |  | 2 |  |  | — |  |  | — |  |
| Total assets | $ | 42 |  |  | $ | 21 |  |  | $ | — |  |  | $ | 1 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 26 |  |  | $ | 24 |  |  | $ | 66 |  |  | $ | 1 |  |
| Commodity derivatives | 3 |  |  | 1 |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 3,186 |  |  | 3,424 |  |  | 521 |  |  | — |  |
| Total liabilities | $ | 3,215 |  |  | $ | 3,449 |  |  | $ | 587 |  |  | $ | 1 |  |

[0000833444-25-000011:notes:77]
[same as prior period, unchanged from 0000833444-24-000052:notes:83]

[0000833444-25-000011:notes:78]
[same as prior period, unchanged from 0000833444-24-000052:notes:84]

[0000833444-25-000011:notes:79]
[same as prior period, unchanged from 0000833444-24-000052:notes:85]

[0000833444-25-000011:notes:80]
[same as prior period, unchanged from 0000833444-24-000052:notes:86]

[0000833444-25-000011:notes:81]
|  |  | Fair Value of Assets |  |  |  | Fair Value of Liabilities |  |  |
|  |  | December 31, |  | September 30, |  |  |  | December 31, |  | September 30, |  |  |
|  |  | 2024 |  | 2024 |  |  |  | 2024 |  | 2024 |  |  |
| Gross amount recognized |  | $ | 42 |  |  | $ | 22 |  |  |  |  | $ | 3,802 |  |  | $ | 3,450 |  |  |  |
| Gross amount eligible for offsetting |  | (14) |  |  | (12) |  |  |  |  | (14) |  |  | (12) |  |  |  |
| Net amount |  | $ | 28 |  |  | $ | 10 |  |  |  |  | $ | 3,788 |  |  | $ | 3,438 |  |  |  |

[0000833444-25-000011:notes:82]
[same as prior period, unchanged from 0000833444-24-000052:notes:88]

[0000833444-25-000011:notes:83]
[same as prior period, unchanged from 0000833444-24-000052:notes:89]

[0000833444-25-000011:notes:84]
| Derivatives in Cash Flow Hedging Relationships |  | Three Months Ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Foreign currency exchange derivatives |  | $ | 17 |  |  | $ | (13) |  |  |  |  |  |
| Commodity derivatives |  | (3) |  |  | 1 |  |  |  |  |  |
| Interest rate swaps |  | — |  |  | (35) |  |  |  |  |  |
| Total |  | $ | 14 |  |  | $ | (47) |  |  |  |  |  |

[0000833444-25-000011:notes:85]
[same as prior period, unchanged from 0000833444-24-000052:notes:91]

[0000833444-25-000011:notes:86]
| Derivatives in Cash Flow Hedging Relationships |  | Location of Gain (Loss) Reclassified from AOCI into Income |  | Three Months Ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 1 |  |  | $ | (1) |  |  |  |  |  |
| Commodity derivatives |  | Cost of sales |  | — |  |  | (3) |  |  |  |  |  |
| Total |  |  |  | $ | 1 |  |  | $ | (4) |  |  |  |  |  |

[0000833444-25-000011:notes:87]
[same as prior period, unchanged from 0000833444-24-000052:notes:93]

[0000833444-25-000011:notes:88]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months Ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (7) |  |  | $ | (5) |  |  |  |  |  |
| Foreign currency exchange derivatives |  | SG&A |  | (2) |  |  | — |  |  |  |  |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | (144) |  |  | (43) |  |  |  |  |  |
| Total |  |  |  | $ | (153) |  |  | $ | (48) |  |  |  |  |  |

[0000833444-25-000011:notes:89]
The following table presents pre-tax gains on net investment hedges recorded as foreign currency translation adjustments ("CTA") within other comprehensive income (loss) (in millions):

[0000833444-25-000011:notes:90]
|  | Three Months Ended December 31, |  |  |
| 2024 |  | 2023 |  |  |  |  |
| Net investment hedges | $ | 238 |  |  | $ | 145 |  |  |  |  |  |

[0000833444-25-000011:notes:91]
No gains or losses were reclassified from CTA into income during the three months ended December 31, 2024 and 2023.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-25-000011:notes:92]
[same as prior period, unchanged from 0000833444-24-000052:notes:98]

[0000833444-25-000011:notes:93]
[same as prior period, unchanged from 0000833444-24-000052:notes:99]

[0000833444-25-000011:notes:94]
[same as prior period, unchanged from 0000833444-24-000052:notes:100]

[0000833444-25-000011:notes:95]
[same as prior period, unchanged from 0000833444-24-000052:notes:101]

[0000833444-25-000011:notes:96]
[same as prior period, unchanged from 0000833444-24-000052:notes:102]

[0000833444-25-000011:notes:97]
[same as prior period, unchanged from 0000833444-24-000052:notes:103]

[0000833444-25-000011:notes:98]
[same as prior period, unchanged from 0000833444-24-000052:notes:104]

[0000833444-25-000011:notes:99]
|  | Fair Value Measurements Using: |
|  | Total as of December 31, 2024 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 42 |  |  | $ | — |  |  | $ | 42 |  |  | $ | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 57 |  |  | 57 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)(1) | 76 |  |  | 76 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)(1) | 201 |  |  | 201 |  |  | — |  |  | — |  |
| Total assets | $ | 376 |  |  | $ | 334 |  |  | $ | 42 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 92 |  |  | $ | — |  |  | $ | 92 |  |  | $ | — |  |
| Commodity derivatives | 3 |  |  | — |  |  | 3 |  |  | — |  |
| Contingent earn-out liabilities | 13 |  |  | — |  |  | — |  |  | 13 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 14 |  |  | — |  |  | — |  |  | 14 |  |
| Total liabilities | $ | 122 |  |  | $ | — |  |  | $ | 95 |  |  | $ | 27 |  |

[0000833444-25-000011:notes:100]
(1)  Classified as restricted investments for payment of asbestos liabilities. See Note 18, "Commitments and Contingencies," of the notes to the consolidated financial statements for further details.

[0000833444-25-000011:notes:101]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2024 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |
| Commodity derivatives | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 56 |  |  | 56 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)(1) | 81 |  |  | 81 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)(1) | 200 |  |  | 200 |  |  | — |  |  | — |  |
| Total assets | $ | 359 |  |  | $ | 337 |  |  | $ | 22 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 25 |  |  | $ | — |  |  | $ | 25 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Contingent earn-out liabilities | 14 |  |  | — |  |  | — |  |  | 14 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 14 |  |  | — |  |  |  |  | 14 |  |
| Total liabilities | $ | 54 |  |  | $ | — |  |  | $ | 26 |  |  | $ | 28 |  |

[0000833444-25-000011:notes:102]
[same as prior period, unchanged from 0000833444-24-000052:notes:110]

[0000833444-25-000011:notes:103]
[same as prior period, unchanged from 0000833444-24-000052:notes:111]

[0000833444-25-000011:notes:104]
[same as prior period, unchanged from 0000833444-24-000052:notes:112]

[0000833444-25-000011:notes:105]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices. Unrealized gains (losses) on the deferred compensation plan assets are recognized in the consolidated statements of income where they offset unrealized gains and losses on the related deferred compensation plan liability.

[0000833444-25-000011:notes:106]
Exchange traded funds: Investments in exchange traded funds are valued using a market approach based on quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. Refer to Note 18, "Commitments and Contingencies," of the notes to the consolidated financial statements for further information.

[0000833444-25-000011:notes:107]
[same as prior period, unchanged from 0000833444-24-000052:notes:117]

[0000833444-25-000011:notes:108]
The following table presents the portion of unrealized gains (losses) recognized in the consolidated statements of income that relate to equity securities still held at December 31, 2024 and 2023 (in millions):

[0000833444-25-000011:notes:109]
|  |  | Three Months Ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Deferred compensation plan assets |  | $ | (1) |  |  | $ | 4 |  |  |  |  |  |
| Investments in exchange traded funds |  | (1) |  |  | 22 |  |  |  |  |  |

[0000833444-25-000011:notes:110]
[same as prior period, unchanged from 0000833444-24-000052:notes:121]

[0000833444-25-000011:notes:111]
The fair value of long-term debt at December 31, 2024 and September 30, 2024 was as follows (in billions):

[0000833444-25-000011:notes:112]
|  |  | December 31, |  | September 30, |  |
|  | 2024 |  | 2024 |  |
| Public debt |  | $ | 8.4 |  |  | $ | 8.1 |  |  |
| Other long-term debt |  | 0.2 |  |  | 0.2 |  |  |
| Total fair value of long-term debt |  | $ | 8.6 |  |  | $ | 8.3 |  |  |

[0000833444-25-000011:notes:113]
[same as prior period, unchanged from 0000833444-24-000052:notes:124]


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000833444-25-000011:notes:114]
[same as prior period, unchanged from 0000833444-24-000052:notes:125]

[0000833444-25-000011:notes:115]
Foreign currency exchange derivatives: The foreign currency exchange derivatives are valued under a market approach using publicized spot and forward prices. 
The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:EarningsPerShareTextBlock

[0000833444-25-000011:notes:116]
[same as prior period, unchanged from 0000833444-24-000052:notes:136]

[0000833444-25-000011:notes:117]
|  | Three Months Ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Income Available to Ordinary Shareholders |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 363 |  |  | $ | 340 |  |  |  |  |  |
| Income from discontinued operations | 56 |  |  | 34 |  |  |  |  |  |
| Basic and diluted income available to shareholders | $ | 419 |  |  | $ | 374 |  |  |  |  |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 662.0 |  |  | 680.7 |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 3.0 |  |  | 1.7 |  |  |  |  |  |
| Diluted weighted average shares outstanding | 665.0 |  |  | 682.4 |  |  |  |  |  |
| Antidilutive Securities |  |  |  |  |  |  |  |
| Stock options and unvested restricted stock | — |  |  | 0.6 |  |  |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000833444-25-000011:notes:118]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS) 
The following schedules present changes in AOCI attributable to Johnson Controls (in millions):

[0000833444-25-000011:notes:119]
|  | Three Months Ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Foreign currency translation adjustments |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (956) |  |  | $ | (970) |  |  |  |  |  |
| Aggregate adjustment for the period | (85) |  |  | 61 |  |  |  |  |  |
| Balance at end of period | (1,041) |  |  | (909) |  |  |  |  |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |  |  |  |  |
| Balance at beginning of period | (4) |  |  | 15 |  |  |  |  |  |
| Current period changes in fair value | 8 |  |  | (43) |  |  |  |  |  |
| Reclassification to income (1) | (1) |  |  | 4 |  |  |  |  |  |
| Net tax impact | (1) |  |  | 1 |  |  |  |  |  |
| Balance at end of period | 2 |  |  | (23) |  |  |  |  |  |
| Pension and postretirement plans |  |  |  |  |  |  |  |
| Balance at beginning of period | (4) |  |  | — |  |  |  |  |  |
| Reclassification to income | (1) |  |  | (1) |  |  |  |  |  |
| Balance at end of period | (5) |  |  | (1) |  |  |  |  |  |
| Accumulated other comprehensive loss, end of period | $ | (1,044) |  |  | $ | (933) |  |  |  |  |  |

[0000833444-25-000011:notes:120]
(1)  Refer to Note 9, "Derivative Instruments and Hedging Activities," of the notes to the consolidated financial statements for disclosure of the line items in the consolidated statements of income affected by reclassifications from AOCI into income related to derivatives.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-25-000011:notes:121]
PENSION AND RETIREMENT PLANS
Unless otherwise noted, all activities and amounts reported in this footnote include both continuing operations of the Company and activities and amounts related to the R&LC HVAC business. See Note 3, "Assets and Liabilities Held for Sale and Discontinued Operations" for additional details regarding divestiture of the R&LC HVAC business.

[0000833444-25-000011:notes:122]
The components of the Company’s net periodic benefit cost (credit) associated with its defined benefit pension and postretirement plans, which are primarily recorded in selling, general and administrative expenses in the consolidated statements of income, are shown in the tables below in accordance with ASC 715, "Compensation – Retirement Benefits" (in millions):

[0000833444-25-000011:notes:123]
|  | U.S. Pension Plans |
|  | Three Months Ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Interest cost | $ | 16 |  |  | $ | 20 |  |  |  |  |  |
| Expected return on plan assets | (24) |  |  | (30) |  |  |  |  |  |
| Net periodic benefit credit | $ | (8) |  |  | $ | (10) |  |  |  |  |  |

[0000833444-25-000011:notes:124]
|  | Non-U.S. Pension Plans |
|  | Three Months Ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Service cost | $ | 4 |  |  | $ | 4 |  |  |  |  |  |
| Interest cost | 16 |  |  | 17 |  |  |  |  |  |
| Expected return on plan assets | (19) |  |  | (18) |  |  |  |  |  |
| Net periodic benefit cost | $ | 1 |  |  | $ | 3 |  |  |  |  |  |

[0000833444-25-000011:notes:125]
|  | Postretirement Benefits |
|  | Three Months Ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Interest cost | $ | 1 |  |  | $ | 1 |  |  |  |  |  |
| Expected return on plan assets | (3) |  |  | (2) |  |  |  |  |  |
| Amortization of prior service credit | (1) |  |  | (1) |  |  |  |  |  |
| Net periodic benefit credit | $ | (3) |  |  | $ | (2) |  |  |  |  |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-25-000011:notes:126]
RESTRUCTURING AND RELATED COSTS
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company commits to restructuring plans as necessary. Restructuring activities generally result in charges for workforce reductions, plant closures, asset impairments and other related costs which are reported as restructuring and impairment costs in the Company’s consolidated statements of income. The Company expects the restructuring actions to reduce cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense.

[0000833444-25-000011:notes:127]
During the fourth quarter of fiscal 2024, the Company completed its previous restructuring plan and committed to a new multi-year restructuring plan to address stranded costs and further right-size its global operations as a result of previously announced portfolio simplification actions. It is expected that one-time restructuring costs, including severance and other employee termination benefits, contract termination costs, and certain other related cash and non-cash charges, of approximately $400 million will be incurred over the course of fiscal 2025, 2026 and 2027. Restructuring costs will be incurred across all segments and Corporate functions.

[0000833444-25-000011:notes:128]
[same as prior period, unchanged from 0000833444-24-000052:notes:152]

[0000833444-25-000011:notes:129]
|  | Three Months Ended December 31, 2024 |  |  |  |  |
| Building Solutions North America | $ | 6 |  |  |  |  |  |
| Building Solutions EMEA/LA | 11 |  |  |  |  |  |
| Building Solutions Asia Pacific | 2 |  |  |  |  |  |
| Global Products | 9 |  |  |  |  |  |
| Corporate | 5 |  |  |  |  |  |
| Total | $ | 33 |  |  |  |  |  |

[0000833444-25-000011:notes:130]
The following table summarizes changes in the current restructuring reserve, which is included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-25-000011:notes:131]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  |  |  |  |  | Total |
| Restructuring and related costs | $ | 25 |  |  | $ | 8 |  |  |  |  |  |  | $ | 33 |  |
| Utilized—cash | (4) |  |  | — |  |  |  |  |  |  | (4) |  |
| Utilized—noncash | — |  |  | (8) |  |  |  |  |  |  | (8) |  |
| Balance at December 31, 2024 | $ | 21 |  |  | $ | — |  |  |  |  |  |  | $ | 21 |  |

[0000833444-25-000011:notes:132]
The following table summarizes changes in the previous restructuring reserve, which is included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-25-000011:notes:133]
|  | Employee Severance and Termination Benefits |  |  |  | Other |  |  |  | Total |
| Balance at September 30, 2024 | $ | 58 |  |  |  |  | $ | 17 |  |  |  |  | $ | 75 |  |
| Utilized—cash | (27) |  |  |  |  | — |  |  |  |  | (27) |  |
| Other | — |  |  |  |  | 1 |  |  |  |  | 1 |  |
| Balance at December 31, 2024 | $ | 31 |  |  |  |  | $ | 18 |  |  |  |  | $ | 49 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-25-000011:notes:134]
[same as prior period, unchanged from 0000833444-24-000052:notes:156]

[0000833444-25-000011:notes:135]
[same as prior period, unchanged from 0000833444-24-000052:notes:157]

[0000833444-25-000011:notes:136]
For the three months ended December 31, 2024, the Company's effective tax rate for continuing operations was 11.5% and was lower than the statutory tax rate of 12.5% primarily due to the benefits of continuing global tax planning, partially offset by tax rate differentials.

[0000833444-25-000011:notes:137]
For the three months ended December 31, 2023, the Company's effective tax rate for continuing operations was (6.3)% and was lower than the statutory tax rate of 12.5% primarily due to Swiss tax reform and the benefits of continuing global tax planning, partially offset by the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain consolidated subsidiaries and tax rate differentials.

[0000833444-25-000011:notes:138]
[same as prior period, unchanged from 0000833444-24-000052:notes:163]

[0000833444-25-000011:notes:139]
At September 30, 2024, the Company had gross tax-effected unrecognized tax benefits of $2.1 billion, of which $1.5 billion, if recognized, would impact the effective tax rate. Accrued interest, net at September 30, 2024 was approximately $398 million (net of tax benefit). Interest accrued during the three months ended December 31, 2024 and 2023 was approximately $28 million and $30 million (both net of tax benefit), respectively. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-25-000011:notes:140]
In the U.S., fiscal years 2019 through 2020 are currently under audit and fiscal years 2017 through 2018 are currently under appeal with the Internal Revenue Service (“IRS”) for certain legal entities. In addition, fiscal years 2016 through 2019 are also under exam by the IRS in relation to a separate consolidated filing group. Additionally, the Company is currently under exam in the following major non-U.S. jurisdictions for continuing operations:

[0000833444-25-000011:notes:141]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2016 - 2017; 2019 - 2020; 2022 |
| Germany |  | 2007 - 2021 |
| Mexico |  | 2016 - 2019 |
| United Kingdom |  | 2014 - 2015; 2018; 2020 - 2021 |

[0000833444-25-000011:notes:142]
It is reasonably possible that tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense. Based upon the circumstances surrounding these examinations, the impact is not currently quantifiable.

[0000833444-25-000011:notes:143]
[same as prior period, unchanged from 0000833444-24-000052:notes:168]

[0000833444-25-000011:notes:144]
On December 18, 2023, the president of Ireland signed into law the Finance (No. 2) Bill 2023, which included legislation regarding the implementation of the Pillar Two global minimum tax. The Pillar Two legislation is effective for the Company’s fiscal year beginning October 1, 2024. The impact in the current fiscal year is not expected to be material, however, the Company is continuing to assess the future impact of the new legislation.

[0000833444-25-000011:notes:145]
On September 11, 2023, the Schaffhausen parliament approved a partial revision of the cantonal act on direct taxation: Immediate Minimum Taxation Measure (“IMTM”). On November 19, 2023, IMTM was approved in a public referendum in the canton of Schaffhausen, was published in the cantonal official gazette on December 8, 2023, and was effective starting January 1, 2024. The IMTM increased Switzerland's combined statutory income tax rate to approximately 15%. As a result, in the three months ended December 31, 2023, the Company recorded a noncash discrete net tax benefit of $80 million due to the remeasurement of deferred tax assets and liabilities related to Switzerland and the canton of Schaffhausen.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-25-000011:notes:146]
SEGMENT INFORMATION
The Company conducts its business through four operating segments, all of which are reportable segments:

[0000833444-25-000011:notes:147]
[same as prior period, unchanged from 0000833444-24-000052:notes:172]

[0000833444-25-000011:notes:148]
[same as prior period, unchanged from 0000833444-24-000052:notes:173]

[0000833444-25-000011:notes:149]
[same as prior period, unchanged from 0000833444-24-000052:notes:174]

[0000833444-25-000011:notes:150]
•Global Products which operates worldwide.

[0000833444-25-000011:notes:151]
[same as prior period, unchanged from 0000833444-24-000052:notes:176]

[0000833444-25-000011:notes:152]
[same as prior period, unchanged from 0000833444-24-000052:notes:177]

[0000833444-25-000011:notes:153]
[same as prior period, unchanged from 0000833444-24-000052:notes:178]

[0000833444-25-000011:notes:154]
[same as prior period, unchanged from 0000833444-24-000052:notes:179]

[0000833444-25-000011:notes:155]
•HVAC equipment, controls software and software services;

[0000833444-25-000011:notes:156]
[same as prior period, unchanged from 0000833444-24-000052:notes:181]

[0000833444-25-000011:notes:157]
[same as prior period, unchanged from 0000833444-24-000052:notes:182]

[0000833444-25-000011:notes:158]
[same as prior period, unchanged from 0000833444-24-000052:notes:183]

[0000833444-25-000011:notes:159]
The Company’s segments provide products and services primarily to commercial, institutional, industrial, data center, and governmental customers.

[0000833444-25-000011:notes:160]
Management evaluates the performance of its segments primarily on segment earnings before interest, taxes and amortization ("EBITA"), which represents income from continuing operations before income taxes and noncontrolling interests, excluding corporate expenses, amortization of intangible assets, restructuring and impairment costs, the water systems AFFF settlement costs and insurance recoveries, net mark-to-market gains and losses related to pension and postretirement plans and restricted asbestos investments, and net financing charges.

[0000833444-25-000011:notes:161]
[same as prior period, unchanged from 0000833444-24-000052:notes:186]

[0000833444-25-000011:notes:162]
|  | Net Sales |
|  | Three Months Ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Building Solutions North America | $ | 2,744 |  |  | $ | 2,487 |  |  |  |  |  |
| Building Solutions EMEA/LA | 1,073 |  |  | 1,038 |  |  |  |  |  |
| Building Solutions Asia Pacific | 527 |  |  | 507 |  |  |  |  |  |
| Global Products | 1,082 |  |  | 1,177 |  |  |  |  |  |
| Total net sales | $ | 5,426 |  |  | $ | 5,209 |  |  |  |  |  |

[0000833444-25-000011:notes:163]
|  | Segment EBITA |
|  | Three Months Ended December 31, |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Building Solutions North America | $ | 332 |  |  | $ | 285 |  |  |  |  |  |
| Building Solutions EMEA/LA | 108 |  |  | 80 |  |  |  |  |  |
| Building Solutions Asia Pacific | 49 |  |  | 46 |  |  |  |  |  |
| Global Products | 326 |  |  | 267 |  |  |  |  |  |
| Total segment EBITA | 815 |  |  | 678 |  |  |  |  |  |
| Corporate expenses | 171 |  |  | 139 |  |  |  |  |  |
| Amortization of intangible assets | 120 |  |  | 119 |  |  |  |  |  |
| Restructuring and impairment costs | 33 |  |  | 35 |  |  |  |  |  |
| Water systems AFFF insurance recoveries (1) | (4) |  |  | — |  |  |  |  |  |
| Net mark-to-market losses (gains) | 1 |  |  | (22) |  |  |  |  |  |
| Net financing charges | 86 |  |  | 87 |  |  |  |  |  |
| Income before income taxes | $ | 408 |  |  | $ | 320 |  |  |  |  |  |

[0000833444-25-000011:notes:164]
(1) Refer to Note 18, "Commitments and Contingencies," of the notes to the consolidated financial statements for further disclosure related to the water systems AFFF settlement.


## us-gaap:GuaranteesTextBlock

[0000833444-25-000011:notes:165]
GUARANTEES
Certain of the Company's subsidiaries at the business segment level guarantee the performance of third parties and provide financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from the current fiscal year through the completion of such transactions and would typically be triggered in the

[0000833444-25-000011:notes:166]
event of nonperformance. Performance under the guarantees, if required, would not have a material effect on the Company's financial position, results of operations or cash flows.

[0000833444-25-000011:notes:167]
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. Generally, the Company's warranties require the repair or replacement of defective products within a specified time period from the date of sale. The Company records an estimate for future warranty-related costs based on actual historical costs to repair or replace products and other known factors. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different than those estimates.

[0000833444-25-000011:notes:168]
[same as prior period, unchanged from 0000833444-24-000052:notes:192]

[0000833444-25-000011:notes:169]
[same as prior period, unchanged from 0000833444-24-000052:notes:193]

[0000833444-25-000011:notes:170]
| Balance at September 30, 2024 | $ | 122 |  |  |
| Accruals for warranties issued during the period | 16 |  |  |
| Settlements made during the period | (18) |  |  |
| Changes in estimates to pre-existing warranties | (2) |  |  |
| Currency translation | (3) |  |  |
| Balance at December 31, 2024 | $ | 115 |  |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-25-000011:notes:171]
COMMITMENTS AND CONTINGENCIES
Environmental Matters

[0000833444-25-000011:notes:172]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-25-000011:notes:173]
|  | December 31, 2024 |  | September 30, 2024 |
| Other current liabilities | $ | 28 |  |  | $ | 32 |  |
| Other noncurrent liabilities | 175 |  |  | 179 |  |
| Total reserves for environmental liabilities | $ | 203 |  |  | $ | 211 |  |

[0000833444-25-000011:notes:174]
The Company periodically examines whether the contingent liabilities related to the environmental matters described below are probable and reasonably estimable based on experience and ongoing developments in those matters, including continued study and analysis of ongoing remediation obligations. The Company expects that it will pay the amounts recorded over an estimated period of up to 20 years. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals for environmental liabilities at this time.

[0000833444-25-000011:notes:175]
A substantial portion of the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to Aqueous Film Forming Foam ("AFFF") containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).

[0000833444-25-000011:notes:176]
PFOA, PFOS, and other PFAS compounds are being studied by the U.S. Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. In March 2021, EPA published its final determination to regulate

[0000833444-25-000011:notes:177]
PFOS and PFOA in drinking water. On April 10, 2024, EPA announced the final National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR established legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion ("ppt") for each of PFOA and PFOS, 10 ppt for each of PFHxS, PFNA, and HFPO-DA (commonly known as GenX Chemicals), and a Hazard Index of one for mixtures containing two or more of PFHxS, PFNA, HFPO-DA, and PFBA. In February 2024, EPA released two proposed rules relating to PFAS under the Resource Conservation and Recovery Act (“RCRA”): one rule proposes to list nine PFAS (including PFOA and PFOS) as “hazardous constituents,” and a second rule proposes to clarify that hazardous waste regulated under the rule includes not only substances listed or identified as hazardous waste in the regulations, but also any substances that meet the statutory definition of hazardous waste.

[0000833444-25-000011:notes:178]
In August 2022, EPA published a proposed rule that would designate PFOA and PFOS as “hazardous substances” under Comprehensive Environmental Response, Compensation and Liability Act ("CERCLA"). In April 2023, EPA issued an Advanced Notice of Proposed Rulemaking ("ANPR") seeking input on whether it should expand the proposed rule to designate as "hazardous substances" under CERCLA: (1) seven additional PFAS; (2) the precursors to PFOA, PFOS, and the seven additional PFAS; or (3) entire categories of PFAS. On April 17, 2024, the EPA Administrator signed the final rule designating PFOA and PFOS, along with their salts and structural isomers, as “hazardous substances.”

[0000833444-25-000011:notes:179]
It is not possible to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in soil, groundwater and drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000833444-25-000011:notes:180]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $7 million at both December 31, 2024 and September 30, 2024.

[0000833444-25-000011:notes:181]
FTC-Related Matters

[0000833444-25-000011:notes:182]
FTC Remediation

[0000833444-25-000011:notes:183]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. During the three months ended June 30, 2024, Tyco Fire Products completed its previously announced plan to discontinue the production and sale of fluorinated firefighting foams, including AFFF products, and has transitioned to non-fluorinated foam alternatives.

[0000833444-25-000011:notes:184]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the EPA to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and

[0000833444-25-000011:notes:185]
treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

[0000833444-25-000011:notes:186]
Tyco Fire Products is operating and monitoring at the FTC a Groundwater Extraction and Treatment System ("GETS"), a permanent groundwater remediation system that extracts groundwater containing PFAS, treats it using advanced filtration systems, and returns the treated water to the environment. Tyco Fire Products has also completed the removal and disposal of PFAS-affected soil from the FTC. The Company's reserves for continued remediation of the FTC, the Stanton Street Facility and surrounding areas in Marinette and Peshtigo are based on estimates of costs associated with the long-term remediation actions, including the continued operation of the GETS, the implementation of long-term drinking water solutions for the area impacted by groundwater migrating from the FTC, continued monitoring and testing of groundwater monitoring wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

[0000833444-25-000011:notes:187]
FTC-Related Litigation

[0000833444-25-000011:notes:188]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water in February 2022, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. In August 2024, WDNR issued a new proposed rule to adopt the EPA Maximum Contaminant Levels for PFAS in drinking water. The WDNR initiated a rulemaking proceeding that would establish groundwater quality standards for PFOA, PFOS, perfluorobutane sulfonic acid and its potassium salt (“PFBS”) and hexafluoropropylene oxide dimer acid and its ammonium salt (“HFPO-DA”). Pursuant to state law, the WDNR has stopped work on the proposed rule and notified the state legislature that, following economic analysis, the proposed costs would exceed statutory thresholds. As a result, the state legislature is required to authorize the WDNR to allow the rulemaking to continue.

[0000833444-25-000011:notes:189]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. The WDNR issued a further letter regarding the issue on November 4, 2019. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to that date. On April 10, 2023, the WDNR issued a third “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids in the Marinette region. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions, including the potential assessment of penalties.

[0000833444-25-000011:notes:190]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR's requests. The parties are engaged in summary judgment and pretrial motions. The Court has continued the trial previously scheduled for March 3, 2025 and has not yet set a new trial date.

[0000833444-25-000011:notes:191]
In October 2022, the Town of Peshtigo filed a tort action in Wisconsin state court against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and ChemDesign, Inc. relating to environmental matters at the FTC (Town of Peshtigo v. Tyco Fire Products L.P. et al., Case No. 2022CV000234 (filed October 18, 2022 in Circuit Court in Marinette County, Wisconsin)). The Town alleges that use of AFFF products at the FTC caused contamination of water supplies in Peshtigo. The Town seeks monetary penalties and an injunction ordering abatement of PFAS contamination in Peshtigo. The case has been removed to federal court and transferred to a multi-district litigation ("MDL") before the United States District Court for the District of South Carolina.

[0000833444-25-000011:notes:192]
In November 2022, individuals filed six actions in Dane County, Wisconsin alleging personal injury and/or property damage against Tyco Fire Products, Johnson Controls Inc., Chemguard, and other unaffiliated defendants related to environmental matters at the FTC. Plaintiffs allege that use of AFFF products at the FTC and activities by third parties unrelated to the Company contaminated nearby drinking water sources, surface waters, and other natural resources and properties, including their personal properties. The individuals seek monetary damages for their personal injury and/or property damage. These lawsuits have been transferred to the MDL. Subsequently, several additional plaintiffs have direct-filed in the MDL complaints with similar allegations.

[0000833444-25-000011:notes:193]
The Company is vigorously defending each of these cases and believes that it has meritorious defenses, but it is presently unable to predict the duration, scope, or outcome of these actions.

[0000833444-25-000011:notes:194]
Aqueous Film-Forming Foam ("AFFF") Matters

[0000833444-25-000011:notes:195]
AFFF Litigation

[0000833444-25-000011:notes:196]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-25-000011:notes:197]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to the MDL. Additional cases have been identified for transfer to or are being directly filed in the MDL.

[0000833444-25-000011:notes:198]
AFFF Municipal and Water Provider Cases

[0000833444-25-000011:notes:199]
Chemguard and Tyco Fire Products have been named as defendants in more than 980 cases in federal and state courts involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 35 states and territories. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation.

[0000833444-25-000011:notes:200]
Tyco Fire Products and Chemguard are also periodically notified by other municipal entities that those entities may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-25-000011:notes:201]
Water Systems AFFF Settlement Agreement

[0000833444-25-000011:notes:202]
On April 12, 2024, Tyco Fire Products agreed to a settlement with a nationwide class of public water systems that detected PFAS in their drinking water systems that they allege to be associated with the use of AFFF. Under the terms of the agreement, Tyco Fire Products agreed to contribute $750 million to resolve these PFAS claims. The settlement releases these claims against Tyco Fire Products, Chemguard, and other related corporate entities. On November 22, 2024, the Court entered final approval of the settlement agreement. In accordance with the terms of the settlement agreement, Tyco Fire Products made its final required payment of $415 million in December 2024 and has now paid the full settlement amount.

[0000833444-25-000011:notes:203]
The class of public water systems included in this settlement broadly includes any public water system (as defined in the settlement agreement) that has detected PFAS in its drinking water sources as of May 15, 2024. The following systems are excluded from the settlement class: water systems owned and operated by a State or the United States government; systems that have not detected the presence of PFAS as of May 15, 2024; small transient water systems; privately-owned drinking water wells; and the water system in the city of Marinette, Wisconsin (which is included only if it so requests). The settlement does not resolve claims of public water systems that request exclusion from the class (“opt out”) pursuant to the process to be established by the MDL court. It also does not resolve potential future claims of public water systems that detect PFAS in their water systems for the first time after May 15, 2024, or certain claims not related to drinking water, such as separate alleged claims relating to real property damage or stormwater or wastewater treatment. Finally, this settlement does not affect the other categories of cases that remain at issue in the MDL, such as personal injury cases, property damage cases, other types of class actions, claims brought by state or territory attorneys general, or other types of damages alleged to be related to the historic use of AFFF manufactured and sold by Tyco Fire Products and Chemguard. While it is reasonably possible that the excluded systems or claims could result in additional future lawsuits, claims, assessments or proceedings, it is not possible to predict the outcome of any such matters, and as such, the Company is unable to develop an estimate of a possible loss or range of losses, if any, at this time.

[0000833444-25-000011:notes:204]
The settlement does not constitute an admission of liability or wrongdoing by Tyco Fire Products or Chemguard.

[0000833444-25-000011:notes:205]
AFFF Putative Class Actions

[0000833444-25-000011:notes:206]
Chemguard and Tyco Fire Products are named in 45 pending putative class actions in federal courts originating from 18 states and territories. All of these cases have been direct-filed in or transferred to the MDL. In addition, six proposed class actions were filed in Canada (British Columbia, Manitoba, Quebec and Ontario) in the past year, which name Tyco Fire Products and other manufacturers as defendants, on behalf of various classes of members (including individuals and government entities) who seek to recover for remediation (past and future) costs, claim property or other environmental damages, or claim personal injuries or other harms arising from alleged exposure to or contamination with PFAS or PFAS-containing products (including AFFF).

[0000833444-25-000011:notes:207]
AFFF Individual or Mass Actions

[0000833444-25-000011:notes:208]
There are more than 8,800 individual or “mass” actions pending that were filed in state or federal courts originating from 52 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 8,800 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly-filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona, Illinois and Wisconsin.

[0000833444-25-000011:notes:209]
Tyco and Chemguard are also periodically notified by other individuals that they may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-25-000011:notes:210]
AFFF State or U.S. Territory Attorneys General Litigation

[0000833444-25-000011:notes:211]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-25-000011:notes:212]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-25-000011:notes:213]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. The State’s case has been removed to federal court and transferred to the MDL. The State of Alaska has also named a number of manufacturers and other defendants, including affiliates of the Company, as third-party defendants in two cases brought by individuals against the State. These two cases have also been transferred to the MDL.

[0000833444-25-000011:notes:214]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL. In October 2022, the Attorney General filed two similar lawsuits in the superior courts of the State of North Carolina regarding alleged PFAS damages at two additional locations. These two cases have also been removed to federal court and transferred to the MDL.

[0000833444-25-000011:notes:215]
In addition, 33 other states and territories have filed 35 lawsuits against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of each of those State's environmental and natural resources allegedly resulting from the manufacture, storage, sale, distribution, marketing, and use of PFAS-containing AFFF within each respective State. The states and territories are: Arkansas, Arizona, California, Colorado, Connecticut, Delaware, the District of Columbia, Florida, Hawaii, Illinois, Indiana, Kentucky, Massachusetts, Maryland, Maine, Michigan, Mississippi, New Hampshire, New Jersey, New Mexico, Ohio, Oklahoma, Oregon, Rhode Island, South Carolina, Tennessee, Texas, Vermont, Washington, Wisconsin, Guam, the Northern Mariana Islands, and Puerto Rico. All of these complaints, if not filed directly in the MDL, have been removed to federal court and transferred to the MDL.

[0000833444-25-000011:notes:216]
Other AFFF Related Matters

[0000833444-25-000011:notes:217]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and

[0000833444-25-000011:notes:218]
disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

[0000833444-25-000011:notes:219]
In October 2022, the Red Cliff Band of Lake Superior Chippewa Indians (a federally recognized tribe) filed a lawsuit in the United States District Court for the Western District of Wisconsin against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota. This complaint has been transferred to the MDL.

[0000833444-25-000011:notes:220]
In July 2023, the Fond du Lac Band of Lake Superior Chippewa (a federally recognized tribe) direct-filed a lawsuit in the MDL against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota.

[0000833444-25-000011:notes:221]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin and a federal district court in South Carolina. The insurance litigation involves numerous factual and legal issues. There are numerous factual and legal issues to be resolved in connection with these claims. The Company is presently unable to predict the outcome or ultimate financial exposure beyond the water systems AFFF settlement discussed above, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

[0000833444-25-000011:notes:222]
Asbestos Matters

[0000833444-25-000011:notes:223]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-25-000011:notes:224]
The following table presents the location and amount of asbestos-related assets and liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-25-000011:notes:225]
|  | December 31, 2024 |  | September 30, 2024 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 344 |  |  | 350 |  |
| Total asbestos-related liabilities | 402 |  |  | 408 |  |
| Other current assets | 15 |  |  | 14 |  |
| Other noncurrent assets | 315 |  |  | 320 |  |
| Total asbestos-related assets | 330 |  |  | 334 |  |
| Net asbestos-related liabilities | $ | 72 |  |  | $ | 74 |  |

[0000833444-25-000011:notes:226]
The following table presents the components of asbestos-related assets (in millions):

[0000833444-25-000011:notes:227]
|  | December 31, 2024 |  | September 30, 2024 |
| Restricted |  |  |  |
| Cash | $ | 7 |  |  | $ | 6 |  |
| Investments | 277 |  |  | 281 |  |
| Total restricted assets | 284 |  |  | 287 |  |
| Insurance receivables for asbestos-related liabilities | 46 |  |  | 47 |  |
| Total asbestos-related assets | $ | 330 |  |  | $ | 334 |  |

[0000833444-25-000011:notes:228]
The amounts recorded for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-25-000011:notes:229]
Self-Insured Liabilities

[0000833444-25-000011:notes:230]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage a portion of its insurable liabilities.

[0000833444-25-000011:notes:231]
The following table presents the location and amount of self-insured liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-25-000011:notes:232]
|  | December 31, 2024 |  | September 30, 2024 |
| Other current liabilities | $ | 98 |  |  | $ | 92 |  |
| Accrued compensation and benefits | 20 |  |  | 20 |  |
| Other noncurrent liabilities | 247 |  |  | 239 |  |
| Total self-insured liabilities | $ | 365 |  |  | $ | 351 |  |

[0000833444-25-000011:notes:233]
The following table presents the location and amount of insurance receivables in the Company's consolidated statements of financial position (in millions):

[0000833444-25-000011:notes:234]
|  | December 31, 2024 |  | September 30, 2024 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 13 |  |  | 13 |  |
| Total insurance receivables | $ | 18 |  |  | $ | 18 |  |

[0000833444-25-000011:notes:235]
Other Matters

[0000833444-25-000011:notes:236]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to the Company, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock

[0000833444-25-000011:notes:237]
The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):
