# JCI 8-K — 0000833444-19-000046 filed 2019-11-07

## item codes, every 8-K on or before 2019-11-21

- 2019-11-07 0000833444-19-000048 — 5.02, 9.01
- 2019-11-07 0000833444-19-000046 — 2.02, 9.01
- 2019-08-21 0000833444-19-000043 — 8.01
- 2019-07-31 0000833444-19-000038 — 2.02, 9.01
- 2019-07-23 0000833444-19-000035 — 5.02, 8.01, 9.01
- 2019-07-02 0000833444-19-000033 — 1.02, 8.01
- 2019-06-05 0001193125-19-165565 — 8.01
- 2019-05-30 0001193125-19-160205 — 8.01, 9.01
- 2019-05-16 0001193125-19-148262 — 8.01, 9.01
- 2019-05-07 0001193125-19-139826 — 5.04, 9.01
- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2019-11-21

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-19-000046:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq4f.htm
EXHIBIT 99.1

[0000833444-19-000046:8k_2_02:2]
Exhibit

[0000833444-19-000046:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000833444-19-000046:8k_2_02:4]
| CONTACT: | Investors:Antonella Franzen(609) 720-4665Ryan Edelman(609) 720-4545Media:Fraser Engerman(414) 524-2733 | Exhibit 99.1 |

[0000833444-19-000046:8k_2_02:5]
Johnson Controls reports strong finish to fiscal 2019; Initiates fiscal 2020 guidance

[0000833444-19-000046:8k_2_02:6]
________________________________________________________________________________

[0000833444-19-000046:8k_2_02:7]
| ▪ | GAAP EPS from continuing operations of $0.77 per share in the quarter; $1.26 for the full year, including special items |

[0000833444-19-000046:8k_2_02:8]
| ▪ | Adjusted EPS from continuing operations of $0.78 in the quarter, up 37% versus prior year; full year adjusted EPS of $1.96, up 23% versus prior year |

[0000833444-19-000046:8k_2_02:9]
| ▪ | Sales in the quarter of $6.3 billion, up 1%, reflecting organic growth of 3%; full year sales of $24.0 billion grew 5% organically |

[0000833444-19-000046:8k_2_02:10]
| ▪ | Field orders up 5% organically in the quarter; up 5% for the full year; backlog up 8% organically versus prior year |

[0000833444-19-000046:8k_2_02:11]
| ▪ | Cash provided by operating activities from continuing operations and adjusted free cash flow of $1.0 billion in the quarter; cash provided by operating activities from continuing operations and adjusted free cash flow of $1.7 billion for the full year, representing 99% conversion |

[0000833444-19-000046:8k_2_02:12]
| ▪ | Initiates fiscal 2020 adjusted EPS guidance of $2.50 to $2.60, representing a year-over-year increase of 28% to 33% |

[0000833444-19-000046:8k_2_02:13]
________________________________________________________________________________

[0000833444-19-000046:8k_2_02:14]
CORK, Ireland, November 7, 2019 -- Johnson Controls International plc (NYSE: JCI) today reported fiscal fourth quarter 2019 GAAP earnings per share (“EPS”) from continuing operations, including special items, of $0.77.  Excluding special items, adjusted EPS from continuing operations was $0.78, up 37% versus the prior year period (see attached footnotes for non-GAAP reconciliation).

[0000833444-19-000046:8k_2_02:15]
Sales of $6.3 billion increased 1% compared to the prior year.  Excluding the impacts of M&A and foreign currency, sales grew 3% organically.

[0000833444-19-000046:8k_2_02:16]
GAAP earnings before interest and taxes (“EBIT”) was $75 million and EBIT margin was 1.2%, including a pre-tax net mark-to-market loss of $626 million. Adjusted EBIT was $812 million and adjusted EBIT margin

[0000833444-19-000046:8k_2_02:17]
Page 1 of 18

[0000833444-19-000046:8k_2_02:18]
was 12.9%, up 80 basis points over the prior year.  Excluding the impact of M&A and foreign currency, underlying adjusted EBIT grew 10% versus the prior year.

[0000833444-19-000046:8k_2_02:19]
“Our fourth quarter results cap off a solid fiscal 2019, having delivered on all of our financial and strategic commitments, with continued momentum in our Field businesses globally, as well as strong margin execution and cash generation as we exit the year,” said George Oliver, chairman & CEO.  “Looking ahead to fiscal 2020, we are well positioned to build upon the performance in 2019 by leveraging our strong backlog position, remaining focused on operational execution and continuing to redeploy capital to our shareholders.  Moving forward as a pure play buildings company, our unique portfolio of smart, sustainable products and solutions enables Johnson Controls to lead the evolution of smart buildings, infrastructure and cities,” Oliver added.

[0000833444-19-000046:8k_2_02:20]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-19-000046:8k_2_02:21]
($ millions, except per-share amounts)

[0000833444-19-000046:8k_2_02:22]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the fiscal fourth quarter and full year of 2018.  The results of Power Solutions are reported as discontinued operations in all periods presented.

[0000833444-19-000046:8k_2_02:23]
Organic sales growth, organic EBITA growth, adjusted segment EBITA, adjusted EBIT, adjusted EPS from continuing operations and adjusted free cash flow are non-GAAP financial measures. For a reconciliation of these non-GAAP measures and detail of the special items, refer to the attached footnotes.  A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-19-000046:8k_2_02:24]
SUMMARY RESULTS

[0000833444-19-000046:8k_2_02:25]
|  | Fiscal Q4 |  |  | Fiscal Year |
|  | GAAP | Adjusted |  |  | GAAP | Adjusted |
|  | 2018 | 2019 | 2018 | 2019 |  |  | 2018 | 2019 | 2018 | 2019 |
| Sales | $6,183 | $6,274 | $6,183 | $6,274 |  |  | $23,400 | $23,968 | $23,400 | $23,968 |
| Segment EBITA | 925 | 962 | 939 | 990 |  |  | 3,138 | 3,041 | 3,082 | 3,243 |
| EBIT | 612 | 75 | 750 | 812 |  |  | 1,947 | 1,406 | 2,290 | 2,490 |
| Net income from continuing operations | 592 | 612 | 534 | 615 |  |  | 1,175 | 1,100 | 1,486 | 1,710 |
| Diluted EPS from continuing operations | $0.64 | $0.77 | $0.57 | $0.78 |  |  | $1.26 | $1.26 | $1.59 | $1.96 |

[0000833444-19-000046:8k_2_02:26]
Page 2 of 18

[0000833444-19-000046:8k_2_02:27]
BUSINESS RESULTS

[0000833444-19-000046:8k_2_02:28]
Building Solutions North America

[0000833444-19-000046:8k_2_02:29]
|  | Fiscal Q4 |  | Fiscal Year |
|  | GAAP | Adjusted |  | GAAP | Adjusted |
|  | 2018 | 2019 | 2018 | 2019 |  | 2018 | 2019 | 2018 | 2019 |
| Sales | $2,324 | $2,401 | $2,324 | $2,401 |  | $8,679 | $9,031 | $8,679 | $9,031 |
| Segment EBITA | 329 | 346 | 336 | 357 |  | 1,109 | 1,153 | 1,134 | 1,179 |
| Segment EBITA Margin % | 14.2% | 14.4% | 14.5% | 14.9% |  | 12.8% | 12.8% | 13.1% | 13.1% |

[0000833444-19-000046:8k_2_02:30]
Sales in the quarter of $2.4 billion increased 3% versus the prior year.  Excluding M&A and foreign currency, organic sales also increased 3% versus the prior year driven by strong growth in HVAC & Controls and, to a lesser extent, growth in Fire & Security. This was partially offset by a decline in Performance Solutions due to the timing of projects.

[0000833444-19-000046:8k_2_02:31]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 7% year-over-year.  Backlog at the end of the quarter of $5.8 billion increased 8% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-19-000046:8k_2_02:32]
Adjusted segment EBITA was $357 million, up 6% versus the prior year. Adjusted segment EBITA margin of 14.9% expanded 40 basis points versus the prior year driven by favorable volume leverage as well as cost synergies and productivity savings.

[0000833444-19-000046:8k_2_02:33]
Sales for the full year were $9.0 billion, an increase of 4% versus the prior year on both a reported and organic basis.  Adjusted segment EBITA for the full year was $1.2 billion and adjusted segment EBITA margin was flat year-over-year, at 13.1%.

[0000833444-19-000046:8k_2_02:34]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-19-000046:8k_2_02:35]
|  | Fiscal Q4 |  | Fiscal Year |
|  | GAAP | Adjusted |  | GAAP | Adjusted |
|  | 2018 | 2019 | 2018 | 2019 |  | 2018 | 2019 | 2018 | 2019 |
| Sales | $948 | $948 | $948 | $948 |  | $3,696 | $3,655 | $3,696 | $3,655 |
| Segment EBITA | 102 | 110 | 103 | 111 |  | 344 | 368 | 350 | 372 |
| Segment EBITA Margin % | 10.8% | 11.6% | 10.9% | 11.7% |  | 9.3% | 10.1% | 9.5% | 10.2% |

[0000833444-19-000046:8k_2_02:36]
Page 3 of 18

[0000833444-19-000046:8k_2_02:37]
Sales in the quarter of $948 million were flat with the prior year.  Excluding M&A and foreign currency, organic sales grew 4% versus the prior year driven by strong growth in both service and project installations. Growth was positive across most regions, led by strength in Industrial Refrigeration in Europe and Fire & Security in Latin America.

[0000833444-19-000046:8k_2_02:38]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 3% year-over-year.  Backlog at the end of the quarter of $1.6 billion increased 10% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-19-000046:8k_2_02:39]
Adjusted segment EBITA was $111 million, up 8% versus the prior year. Adjusted segment EBITA margin of 11.7% expanded 80 basis points over the prior year, including a 40 basis point headwind related to foreign currency.  Adjusting for foreign currency, the underlying margin improved 120 basis points driven by favorable volume as well as the benefit from cost synergies and productivity savings, partially offset by run-rate salesforce additions.

[0000833444-19-000046:8k_2_02:40]
Sales for the full year were $3.7 billion, a decrease of 1% versus the prior year, with organic growth of 4%.  Adjusted segment EBITA for the full year was $372 million and adjusted segment EBITA margin expanded 70 basis points year-over-year, including a 30 basis point headwind related to foreign currency, to 10.2%.

[0000833444-19-000046:8k_2_02:41]
Building Solutions Asia Pacific

[0000833444-19-000046:8k_2_02:42]
|  | Fiscal Q4 |  | Fiscal Year |
|  | GAAP | Adjusted |  | GAAP | Adjusted |
|  | 2018 | 2019 | 2018 | 2019 |  | 2018 | 2019 | 2018 | 2019 |
| Sales | $689 | $726 | $689 | $726 |  | $2,553 | $2,658 | $2,553 | $2,658 |
| Segment EBITA | 105 | 101 | 105 | 103 |  | 347 | 341 | 347 | 343 |
| Segment EBITA Margin % | 15.2% | 13.9% | 15.2% | 14.2% |  | 13.6% | 12.8% | 13.6% | 12.9% |

[0000833444-19-000046:8k_2_02:43]
Sales in the quarter of $726 million increased 5% versus the prior year.  Excluding M&A and foreign currency, organic sales increased 7% versus the prior year driven primarily by strong growth in project installations and solid growth in China.

[0000833444-19-000046:8k_2_02:44]
Orders in the quarter, excluding M&A and adjusted for foreign currency, were flat year-over-year.  Backlog at the end of the quarter of $1.5 billion increased 4% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-19-000046:8k_2_02:45]
Adjusted segment EBITA was $103 million, down 2% versus the prior year. Adjusted segment EBITA margin of 14.2% was down 100 basis points versus the prior year as favorable volume was offset by unfavorable mix and expected underlying margin pressure.

[0000833444-19-000046:8k_2_02:46]
Sales for the full year were $2.7 billion, an increase of 4% versus the prior year, with organic growth of 7%.  Adjusted segment EBITA for the full year was $343 million and adjusted segment EBITA margin of 12.9% decreased 70 basis points year-over-year.

[0000833444-19-000046:8k_2_02:47]
Page 4 of 18

[0000833444-19-000046:8k_2_02:48]
Global Products

[0000833444-19-000046:8k_2_02:49]
|  | Fiscal Q4 |  | Fiscal Year |
|  | GAAP | Adjusted |  | GAAP | Adjusted |
|  | 2018 | 2019 | 2018 | 2019 |  | 2018 | 2019 | 2018 | 2019 |
| Sales | $2,222 | $2,199 | $2,222 | $2,199 |  | $8,472 | $8,624 | $8,472 | $8,624 |
| Segment EBITA | 389 | 405 | 395 | 419 |  | 1,338 | 1,179 | 1,251 | 1,349 |
| Segment EBITA Margin % | 17.5% | 18.4% | 17.8% | 19.1% |  | 15.8% | 13.7% | 14.8% | 15.6% |

[0000833444-19-000046:8k_2_02:50]
Sales in the quarter of $2.2 billion declined 1% versus the prior year. Excluding M&A and foreign currency, organic sales were flat with the prior year as solid growth in Building Management Systems and Specialty Products, was offset by a slight decline in HVAC & Refrigeration Equipment.

[0000833444-19-000046:8k_2_02:51]
Adjusted segment EBITA was $419 million, up 6% versus the prior year. Adjusted segment EBITA margin of 19.1% expanded 130 basis points over the prior year. This increase was driven by positive price/cost as well as the benefit of cost synergies and productivity savings, partially offset by volume de-leverage and investments.

[0000833444-19-000046:8k_2_02:52]
Sales for the full year were $8.6 billion, up 2% versus the prior year, with organic growth of 5%.  Adjusted segment EBITA for the full year was $1.3 billion and adjusted segment EBITA margin expanded 80 basis points year-over-year to 15.6%.

[0000833444-19-000046:8k_2_02:53]
Corporate

[0000833444-19-000046:8k_2_02:54]
|  | Fiscal Q4 |  | Fiscal Year |
|  | GAAP | Adjusted |  | GAAP | Adjusted |
|  | 2018 | 2019 | 2018 | 2019 |  | 2018 | 2019 | 2018 | 2019 |
| Corporate Expense | ($142) | ($172) | ($95) | ($89) |  | ($584) | ($405) | ($416) | ($376) |

[0000833444-19-000046:8k_2_02:55]
Adjusted Corporate expense was $89 million in the quarter, and $376 million for the full year, a decrease of 6% and 10%, respectively, when compared to the prior year.  The improvement in both periods was driven primarily by continued cost synergies and productivity savings and, to a lesser extent, cost reductions related to the Power Solutions sale.

[0000833444-19-000046:8k_2_02:56]
OTHER ITEMS

[0000833444-19-000046:8k_2_02:57]
| • | For the quarter, cash provided by operating activities from continuing operations was $1.0 billion and capital expenditures were $0.2 billion, resulting in free cash flow from continuing operations of $0.8 billion. Adjusted free cash flow was $1.0 billion, which excludes net cash outflows of $0.2 billion primarily related to integration costs and non-recurring tax payments. |

[0000833444-19-000046:8k_2_02:58]
Page 5 of 18

[0000833444-19-000046:8k_2_02:59]
| • | For the full year, cash provided by operating activities from continuing operations was $1.7 billion and capital expenditures were $0.6 billion, resulting in a free cash flow from continuing operations of $1.2 billion. Adjusted free cash flow was $1.7 billion, which excludes net cash outflows of $0.5 billion primarily related to restructuring and integration costs and non-recurring tax payments. |

[0000833444-19-000046:8k_2_02:60]
| • | During the quarter, the Company repurchased approximately 20 million shares for $861 million. Year-to-date, including the completion of the share tender on June 5, 2019, the Company repurchased approximately 155 million shares for $6.0 billion, representing ~17% of shares outstanding. |

[0000833444-19-000046:8k_2_02:61]
| • | During the quarter, the Company recorded net pre-tax mark-to-market losses of $626 million related primarily to year-end pension adjustments as a result of lower interest rates. |

[0000833444-19-000046:8k_2_02:62]
| • | During the quarter, the Company recorded a tax benefit of $586 million related to tax audit reserve adjustments. |

[0000833444-19-000046:8k_2_02:63]
FY20 GUIDANCE

[0000833444-19-000046:8k_2_02:64]
The Company also announced fiscal 2020 guidance:

[0000833444-19-000046:8k_2_02:65]
| ▪ | Organic revenue growth in the low to mid-single digits. |

[0000833444-19-000046:8k_2_02:66]
| ▪ | Incremental synergy and productivity savings of ~$150 million. |

[0000833444-19-000046:8k_2_02:67]
| ▪ | Adjusted EBIT margin expansion of 60 to 80 basis points, year-over-year. |

[0000833444-19-000046:8k_2_02:68]
| ▪ | Share repurchases of ~$2.2 billion. |

[0000833444-19-000046:8k_2_02:69]
| ▪ | Adjusted EPS before special items of $2.50 to $2.60, representing a 28% to 33% increase year-over-year. |

[0000833444-19-000046:8k_2_02:70]
| ▪ | Adjusted free cash flow conversion of approximately 95%, excluding special items. |

[0000833444-19-000046:8k_2_02:71]
###

[0000833444-19-000046:8k_2_02:72]
About Johnson Controls:

[0000833444-19-000046:8k_2_02:73]
At Johnson Controls, we transform the environments where people live, work, learn and play. From optimizing building performance to improving safety and enhancing comfort, we drive the outcomes that matter most. We deliver our promise in industries such as healthcare, education, data centers, and manufacturing. With a global team of 105,000 experts in more than 150 countries and over 130 years of innovation, we are the power behind our customers’ mission. Our leading portfolio of building technology and solutions includes some of the most trusted names in the industry, such as Tyco®, YORK®, Metasys®, Ruskin®, Titus®, Frick®, PENN®, Sabroe®, Simplex®, Ansul® and Grinnell®. For more information, visit www.johnsoncontrols.com or follow us @johnsoncontrols on Twitter

[0000833444-19-000046:8k_2_02:74]
###

[0000833444-19-000046:8k_2_02:75]
Page 6 of 18

[0000833444-19-000046:8k_2_02:76]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-19-000046:8k_2_02:77]
###

[0000833444-19-000046:8k_2_02:78]
Non-GAAP Financial Information

[0000833444-19-000046:8k_2_02:79]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include net mark-to-market adjustments, transaction/integration costs, restructuring and impairment costs, Scott Safety gain on sale, tax indemnification reserve release, environmental reserve, loss on extinguishment of debt, Power Solutions gain on sale (net of transaction and other costs), the impact of ceasing the depreciation/amortization expense for the Power Solutions business as the business is held for sale and discrete tax items. Financial information regarding organic sales, adjusted segment EBITA, adjusted organic segment EBITA, adjusted segment EBITA margin, adjusted free cash flow, adjusted free cash flow conversion and net debt are also presented, which are non-

[0000833444-19-000046:8k_2_02:80]
Page 7 of 18

[0000833444-19-000046:8k_2_02:81]
GAAP performance measures. Adjusted segment EBITA excludes special items such as transaction/integration costs, environmental reserve and Scott Safety gain on sale because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.

[0000833444-19-000046:8k_2_02:82]
Page 8 of 18

[0000833444-19-000046:8k_2_02:83]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Three Months Ended September 30, |
|  |  | 2019 |  |  | 2018 |
| Net sales | $ | 6,274 |  |  |  | $ | 6,183 |  |
| Cost of sales | 4,294 |  |  |  | 4,126 |  |
|  | Gross profit | 1,980 |  |  |  | 2,057 |  |
| Selling, general and administrative expenses | (1,960 | ) |  |  | (1,392 | ) |
| Restructuring and impairment costs | — |  |  |  | (101 | ) |
| Net financing charges | (48 | ) |  |  | (97 | ) |
| Equity income | 55 |  |  |  | 48 |  |
| Income from continuing operations before income taxes | 27 |  |  |  | 515 |  |
| Income tax benefit | (627 | ) |  |  | (117 | ) |
| Income from continuing operations | 654 |  |  |  | 632 |  |
| Income from discontinued operations, net of tax | — |  |  |  | 193 |  |
| Net income | 654 |  |  |  | 825 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 42 |  |  |  | 40 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | 14 |  |
| Net income attributable to JCI | $ | 612 |  |  |  | $ | 771 |  |
| Income from continuing operations | $ | 612 |  |  |  | $ | 592 |  |
| Income from discontinued operations | — |  |  |  | 179 |  |
| Net income attributable to JCI | $ | 612 |  |  |  | $ | 771 |  |
| Diluted earnings per share from continuing operations | $ | 0.77 |  |  |  | $ | 0.64 |  |
| Diluted earnings per share from discontinued operations | — |  |  |  | 0.19 |  |
| Diluted earnings per share | $ | 0.77 |  |  |  | $ | 0.83 |  |
| Diluted weighted average shares | 791.7 |  |  |  | 930.5 |  |
| Shares outstanding at period end | 777.6 |  |  |  | 925.0 |  |

[0000833444-19-000046:8k_2_02:84]
Page 9 of 18

[0000833444-19-000046:8k_2_02:85]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Twelve Months Ended September 30, |
|  |  | 2019 |  |  | 2018 |
| Net sales | $ | 23,968 |  |  |  | $ | 23,400 |  |
| Cost of sales | 16,275 |  |  |  | 15,733 |  |
|  | Gross profit | 7,693 |  |  |  | 7,667 |  |
| Selling, general and administrative expenses | (6,244 | ) |  |  | (5,642 | ) |
| Restructuring and impairment costs | (235 | ) |  |  | (255 | ) |
| Net financing charges | (350 | ) |  |  | (401 | ) |
| Equity income | 192 |  |  |  | 177 |  |
| Income from continuing operations before income taxes | 1,056 |  |  |  | 1,546 |  |
| Income tax provision (benefit) | (233 | ) |  |  | 197 |  |
| Income from continuing operations | 1,289 |  |  |  | 1,349 |  |
| Income from discontinued operations, net of tax | 4,598 |  |  |  | 1,034 |  |
| Net income | 5,887 |  |  |  | 2,383 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 189 |  |  |  | 174 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | 24 |  |  |  | 47 |  |
| Net income attributable to JCI | $ | 5,674 |  |  |  | $ | 2,162 |  |
| Income from continuing operations | $ | 1,100 |  |  |  | $ | 1,175 |  |
| Income from discontinued operations | 4,574 |  |  |  | 987 |  |
| Net income attributable to JCI | $ | 5,674 |  |  |  | $ | 2,162 |  |
| Diluted earnings per share from continuing operations | $ | 1.26 |  |  |  | $ | 1.26 |  |
| Diluted earnings per share from discontinued operations | 5.23 |  |  |  | 1.06 |  |
| Diluted earnings per share | $ | 6.49 |  |  |  | $ | 2.32 |  |
| Diluted weighted average shares | 874.3 |  |  |  | 931.7 |  |
| Shares outstanding at period end | 777.6 |  |  |  | 925.0 |  |

[0000833444-19-000046:8k_2_02:86]
Page 10 of 18

[0000833444-19-000046:8k_2_02:87]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | September 30,2019 |  | September 30,2018 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 2,805 |  |  | $ | 185 |  |
| Accounts receivable - net | 5,770 |  |  | 5,622 |  |
| Inventories | 1,814 |  |  | 1,819 |  |
| Assets held for sale | 98 |  |  | 3,015 |  |
| Other current assets | 1,906 |  |  | 1,182 |  |
|  | Current assets | 12,393 |  |  | 11,823 |  |
| Property, plant and equipment - net | 3,348 |  |  | 3,300 |  |
| Goodwill | 18,178 |  |  | 18,381 |  |
| Other intangible assets - net | 5,632 |  |  | 6,187 |  |
| Investments in partially-owned affiliates | 853 |  |  | 848 |  |
| Noncurrent assets held for sale | 60 |  |  | 5,188 |  |
| Other noncurrent assets | 1,823 |  |  | 3,070 |  |
|  | Total assets | $ | 42,287 |  |  | $ | 48,797 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 511 |  |  | $ | 1,307 |  |
| Accounts payable and accrued expenses | 4,535 |  |  | 4,428 |  |
| Liabilities held for sale | 44 |  |  | 1,791 |  |
| Other current liabilities | 3,980 |  |  | 3,724 |  |
|  | Current liabilities | 9,070 |  |  | 11,250 |  |
| Long-term debt | 6,708 |  |  | 9,623 |  |
| Other noncurrent liabilities | 5,680 |  |  | 5,259 |  |
| Noncurrent liabilities held for sale | — |  |  | 207 |  |
| Shareholders' equity attributable to JCI | 19,766 |  |  | 21,164 |  |
| Noncontrolling interests | 1,063 |  |  | 1,294 |  |
|  | Total liabilities and equity | $ | 42,287 |  |  | $ | 48,797 |  |

[0000833444-19-000046:8k_2_02:88]
Page 11 of 18

[0000833444-19-000046:8k_2_02:89]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Three Months Ended September 30, |
|  |  |  |  |  |  | 2019 |  |  | 2018 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI from continuing operations | $ | 612 |  |  |  | $ | 592 |  |
| Income from continuing operations attributable to noncontrolling interests | 42 |  |  |  | 40 |  |
| Net income from continuing operations | 654 |  |  |  | 632 |  |
| Adjustments to reconcile net income from continuing operations to cash provided by |  |  |  |  |
| operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 200 |  |  |  | 175 |  |
|  |  | Pension and postretirement benefit expense (income) | 600 |  |  |  | (62 | ) |
|  |  | Pension and postretirement contributions | (2 | ) |  |  | (3 | ) |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (40 | ) |  |  | (44 | ) |
|  |  | Deferred income taxes | 230 |  |  |  | (661 | ) |
|  |  | Non-cash restructuring and impairment costs | — |  |  |  | 8 |  |
|  |  | Other - net | 16 |  |  |  | — |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | 182 |  |  |  | (21 | ) |
|  |  |  |  | Inventories | 217 |  |  |  | 108 |  |
|  |  |  |  | Other assets | (37 | ) |  |  | 74 |  |
|  |  |  |  | Restructuring reserves | (37 | ) |  |  | 56 |  |
|  |  |  |  | Accounts payable and accrued liabilities | 92 |  |  |  | 72 |  |
|  |  |  |  | Accrued income taxes | (1,043 | ) |  |  | 489 |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 1,032 |  |  |  | 823 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (185 | ) |  |  | (164 | ) |
| Acquisition of businesses, net of cash acquired | (9 | ) |  |  | 3 |  |
| Business divestitures, net of cash divested | — |  |  |  | 101 |  |
| Other - net | 24 |  |  |  | 27 |  |
|  |  |  |  |  | Cash used in investing activities from continuing operations | (170 | ) |  |  | (33 | ) |
| Financing Activities |  |  |  |  |
| Decrease in short and long-term debt - net | (10 | ) |  |  | (962 | ) |
| Stock repurchases | (861 | ) |  |  | (45 | ) |
| Payment of cash dividends | (208 | ) |  |  | (240 | ) |
| Proceeds from the exercise of stock options | 60 |  |  |  | 27 |  |
| Employee equity-based compensation withholding | (5 | ) |  |  | (4 | ) |
| Other - net | 5 |  |  |  | — |  |
|  |  |  |  |  | Cash used in financing activities from continuing operations | (1,019 | ) |  |  | (1,224 | ) |
| Discontinued Operations |  |  |  |  |
| Net cash provided by (used in) operating activities | (658 | ) |  |  | 429 |  |
| Net cash provided by (used in) investing activities | 31 |  |  |  | (60 | ) |
| Net cash provided by financing activities | — |  |  |  | — |  |
|  |  |  |  |  | Net cash flows provided by (used in) discontinued operations | (627 | ) |  |  | 369 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (96 | ) |  |  | (22 | ) |
| Changes in cash held for sale | — |  |  |  | 1 |  |
| Decrease in cash, cash equivalents and restricted cash | $ | (880 | ) |  |  | $ | (86 | ) |

[0000833444-19-000046:8k_2_02:90]
Page 12 of 18

[0000833444-19-000046:8k_2_02:91]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Twelve Months Ended September 30, |
|  |  |  |  |  |  | 2019 |  |  | 2018 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI from continuing operations | $ | 1,100 |  |  |  | $ | 1,175 |  |
| Income from continuing operations attributable to noncontrolling interests | 189 |  |  |  | 174 |  |
| Net income from continuing operations | 1,289 |  |  |  | 1,349 |  |
| Adjustments to reconcile net income from continuing operations to cash provided by |  |  |  |  |
| operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 825 |  |  |  | 824 |  |
|  |  | Pension and postretirement benefit expense (income) | 515 |  |  |  | (170 | ) |
|  |  | Pension and postretirement contributions | (53 | ) |  |  | (56 | ) |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (34 | ) |  |  | (128 | ) |
|  |  | Deferred income taxes | 612 |  |  |  | (739 | ) |
|  |  | Non-cash restructuring and impairment costs | 235 |  |  |  | 36 |  |
|  |  | Gain on Scott Safety business divestiture | — |  |  |  | (114 | ) |
|  |  | Other - net | 124 |  |  |  | 71 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (312 | ) |  |  | (475 | ) |
|  |  |  |  | Inventories | (72 | ) |  |  | (103 | ) |
|  |  |  |  | Other assets | (99 | ) |  |  | (171 | ) |
|  |  |  |  | Restructuring reserves | (121 | ) |  |  | 1 |  |
|  |  |  |  | Accounts payable and accrued liabilities | 56 |  |  |  | 340 |  |
|  |  |  |  | Accrued income taxes | (1,222 | ) |  |  | 855 |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 1,743 |  |  |  | 1,520 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (586 | ) |  |  | (645 | ) |
| Acquisition of businesses, net of cash acquired | (25 | ) |  |  | (21 | ) |
| Business divestitures, net of cash divested | 12 |  |  |  | 2,202 |  |
| Other - net | 66 |  |  |  | 32 |  |
|  |  |  |  |  | Cash provided by (used in) investing activities from continuing operations | (533 | ) |  |  | 1,568 |  |
| Financing Activities |  |  |  |  |
| Decrease in short and long-term debt - net | (3,629 | ) |  |  | (2,472 | ) |
| Debt financing costs | — |  |  |  | (4 | ) |
| Stock repurchases | (5,983 | ) |  |  | (300 | ) |
| Payment of cash dividends | (920 | ) |  |  | (954 | ) |
| Proceeds from the exercise of stock options | 171 |  |  |  | 66 |  |
| Dividends paid to noncontrolling interests | (132 | ) |  |  | (43 | ) |
| Employee equity-based compensation withholding | (31 | ) |  |  | (42 | ) |
| Other - net | 5 |  |  |  | — |  |
|  |  |  |  |  | Cash used in financing activities from continuing operations | (10,519 | ) |  |  | (3,749 | ) |
| Discontinued Operations |  |  |  |  |
| Net cash provided by (used in) operating activities | (541 | ) |  |  | 996 |  |
| Net cash provided by (used in) investing activities | 12,611 |  |  |  | (372 | ) |
| Net cash used in financing activities | (35 | ) |  |  | (3 | ) |
|  |  |  |  |  | Net cash flows provided by discontinued operations | 12,035 |  |  |  | 621 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (120 | ) |  |  | (106 | ) |
| Changes in cash held for sale | 15 |  |  |  | 14 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | $ | 2,621 |  |  |  | $ | (132 | ) |

[0000833444-19-000046:8k_2_02:92]
Page 13 of 18

[0000833444-19-000046:8k_2_02:93]
FOOTNOTES

[0000833444-19-000046:8k_2_02:94]
1. Financial Summary

[0000833444-19-000046:8k_2_02:95]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and the net mark-to-market adjustments related to restricted asbestos investments and pension and postretirement plans. In the first quarter of fiscal 2019, the Company began reporting the Power Solutions business as a discontinued operation, which required retrospective application to previously reported financial information. As a result, the financial results shown below are for continuing operations and exclude the Power Solutions business.

[0000833444-19-000046:8k_2_02:96]
|  | Three Months Ended September 30, |
| (in millions; unaudited) | 2019 |  | 2018 |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,401 |  |  | $ | 2,401 |  |  | $ | 2,324 |  |  | $ | 2,324 |  |
| Building Solutions EMEA/LA | 948 |  |  | 948 |  |  | 948 |  |  | 948 |  |
| Building Solutions Asia Pacific | 726 |  |  | 726 |  |  | 689 |  |  | 689 |  |
| Global Products | 2,199 |  |  | 2,199 |  |  | 2,222 |  |  | 2,222 |  |
| Net sales | $ | 6,274 |  |  | $ | 6,274 |  |  | $ | 6,183 |  |  | $ | 6,183 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 346 |  |  | $ | 357 |  |  | $ | 329 |  |  | $ | 336 |  |
| Building Solutions EMEA/LA | 110 |  |  | 111 |  |  | 102 |  |  | 103 |  |
| Building Solutions Asia Pacific | 101 |  |  | 103 |  |  | 105 |  |  | 105 |  |
| Global Products | 405 |  |  | 419 |  |  | 389 |  |  | 395 |  |
| Segment EBITA | 962 |  |  | 990 |  |  | 925 |  |  | 939 |  |
| Corporate expenses (2) | (172 | ) |  | (89 | ) |  | (142 | ) |  | (95 | ) |
| Amortization of intangible assets | (89 | ) |  | (89 | ) |  | (94 | ) |  | (94 | ) |
| Net mark-to-market adjustments (3) | (626 | ) |  | — |  |  | 24 |  |  | — |  |
| Restructuring and impairment costs (4) | — |  |  | — |  |  | (101 | ) |  | — |  |
| EBIT (5) | 75 |  |  | 812 |  |  | 612 |  |  | 750 |  |
| EBIT margin | 1.2 | % |  | 12.9 | % |  | 9.9 | % |  | 12.1 | % |
| Net financing charges (6) | (48 | ) |  | (48 | ) |  | (97 | ) |  | (97 | ) |
| Income from continuing operations before income taxes | 27 |  |  | 764 |  |  | 515 |  |  | 653 |  |
| Income tax benefit (provision) (7) | 627 |  |  | (103 | ) |  | 117 |  |  | (79 | ) |
| Income from continuing operations | 654 |  |  | 661 |  |  | 632 |  |  | 574 |  |
| Income from continuing operations attributable to noncontrolling interests | (42 | ) |  | (46 | ) |  | (40 | ) |  | (40 | ) |
| Net income from continuing operations attributable to JCI | $ | 612 |  |  | $ | 615 |  |  | $ | 592 |  |  | $ | 534 |  |

[0000833444-19-000046:8k_2_02:97]
|  | Twelve Months Ended September 30, |
| (in millions; unaudited) | 2019 |  | 2018 |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 9,031 |  |  | $ | 9,031 |  |  | $ | 8,679 |  |  | $ | 8,679 |  |
| Building Solutions EMEA/LA | 3,655 |  |  | 3,655 |  |  | 3,696 |  |  | 3,696 |  |
| Building Solutions Asia Pacific | 2,658 |  |  | 2,658 |  |  | 2,553 |  |  | 2,553 |  |
| Global Products | 8,624 |  |  | 8,624 |  |  | 8,472 |  |  | 8,472 |  |
| Net sales | $ | 23,968 |  |  | $ | 23,968 |  |  | $ | 23,400 |  |  | $ | 23,400 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 1,153 |  |  | $ | 1,179 |  |  | $ | 1,109 |  |  | $ | 1,134 |  |
| Building Solutions EMEA/LA | 368 |  |  | 372 |  |  | 344 |  |  | 350 |  |
| Building Solutions Asia Pacific | 341 |  |  | 343 |  |  | 347 |  |  | 347 |  |
| Global Products | 1,179 |  |  | 1,349 |  |  | 1,338 |  |  | 1,251 |  |
| Segment EBITA | 3,041 |  |  | 3,243 |  |  | 3,138 |  |  | 3,082 |  |
| Corporate expenses (2) | (405 | ) |  | (376 | ) |  | (584 | ) |  | (416 | ) |
| Amortization of intangible assets | (377 | ) |  | (377 | ) |  | (376 | ) |  | (376 | ) |
| Net mark-to-market adjustments (3) | (618 | ) |  | — |  |  | 24 |  |  | — |  |
| Restructuring and impairment costs (4) | (235 | ) |  | — |  |  | (255 | ) |  | — |  |
| EBIT (5) | 1,406 |  |  | 2,490 |  |  | 1,947 |  |  | 2,290 |  |
| EBIT margin | 5.9 | % |  | 10.4 | % |  | 8.3 | % |  | 9.8 | % |
| Net financing charges (6) | (350 | ) |  | (290 | ) |  | (401 | ) |  | (401 | ) |
| Income from continuing operations before income taxes | 1,056 |  |  | 2,200 |  |  | 1,546 |  |  | 1,889 |  |
| Income tax benefit (provision) (7) | 233 |  |  | (297 | ) |  | (197 | ) |  | (229 | ) |
| Income from continuing operations | 1,289 |  |  | 1,903 |  |  | 1,349 |  |  | 1,660 |  |
| Income from continuing operations attributable to noncontrolling interests | (189 | ) |  | (193 | ) |  | (174 | ) |  | (174 | ) |
| Net income from continuing operations attributable to JCI | $ | 1,100 |  |  | $ | 1,710 |  |  | $ | 1,175 |  |  | $ | 1,486 |  |

[0000833444-19-000046:8k_2_02:98]
(1) The Company's press release contains financial information regarding adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures. The Company's definition of adjusted segment EBITA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its businesses. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-19-000046:8k_2_02:99]
The following is the three months ended September 30, 2019 and 2018 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-19-000046:8k_2_02:100]
| (in millions) | Building SolutionsNorth America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | ConsolidatedJCI plc |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Segment EBITA as reported | $ | 346 |  |  | $ | 329 |  |  | $ | 110 |  |  | $ | 102 |  |  | $ | 101 |  |  | $ | 105 |  |  | $ | 405 |  |  | $ | 389 |  |  | $ | 962 |  |  | $ | 925 |  |
| Segment EBITA margin as reported | 14.4 | % |  | 14.2 | % |  | 11.6 | % |  | 10.8 | % |  | 13.9 | % |  | 15.2 | % |  | 18.4 | % |  | 17.5 | % |  | 15.3 | % |  | 15.0 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Integration costs | 11 |  |  | 7 |  |  | 1 |  |  | 1 |  |  | 2 |  |  | — |  |  | 14 |  |  | 6 |  |  | 28 |  |  | 14 |  |
| Adjusted segment EBITA | $ | 357 |  |  | $ | 336 |  |  | $ | 111 |  |  | $ | 103 |  |  | $ | 103 |  |  | $ | 105 |  |  | $ | 419 |  |  | $ | 395 |  |  | $ | 990 |  |  | $ | 939 |  |
| Adjusted segment EBITA margin | 14.9 | % |  | 14.5 | % |  | 11.7 | % |  | 10.9 | % |  | 14.2 | % |  | 15.2 | % |  | 19.1 | % |  | 17.8 | % |  | 15.8 | % |  | 15.2 | % |

[0000833444-19-000046:8k_2_02:101]
Page 14 of 18

[0000833444-19-000046:8k_2_02:102]
The following is the twelve months ended September 30, 2019 and 2018 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-19-000046:8k_2_02:103]
| (in millions) | Building SolutionsNorth America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | ConsolidatedJCI plc |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Segment EBITA as reported | $ | 1,153 |  |  | $ | 1,109 |  |  | $ | 368 |  |  | $ | 344 |  |  | $ | 341 |  |  | $ | 347 |  |  | $ | 1,179 |  |  | $ | 1,338 |  |  | $ | 3,041 |  |  | $ | 3,138 |  |
| Segment EBITA margin as reported | 12.8 | % |  | 12.8 | % |  | 10.1 | % |  | 9.3 | % |  | 12.8 | % |  | 13.6 | % |  | 13.7 | % |  | 15.8 | % |  | 12.7 | % |  | 13.4 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Integration costs | 26 |  |  | 25 |  |  | 4 |  |  | 6 |  |  | 2 |  |  | — |  |  | 30 |  |  | 27 |  |  | 62 |  |  | 58 |  |
| Scott Safety gain on sale | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (114 | ) |  | — |  |  | (114 | ) |
| Environmental reserve (8) | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 140 |  |  | — |  |  | 140 |  |  | — |  |
| Adjusted segment EBITA | $ | 1,179 |  |  | $ | 1,134 |  |  | $ | 372 |  |  | $ | 350 |  |  | $ | 343 |  |  | $ | 347 |  |  | $ | 1,349 |  |  | $ | 1,251 |  |  | $ | 3,243 |  |  | $ | 3,082 |  |
| Adjusted segment EBITA margin | 13.1 | % |  | 13.1 | % |  | 10.2 | % |  | 9.5 | % |  | 12.9 | % |  | 13.6 | % |  | 15.6 | % |  | 14.8 | % |  | 13.5 | % |  | 13.2 | % |

[0000833444-19-000046:8k_2_02:104]
(2) Adjusted Corporate expenses for the three months ended September 30, 2019 excludes $79 million of integration costs and $4 million of transaction costs. Adjusted Corporate expenses for the twelve months ended September 30, 2019 excludes $244 million of integration costs and $11 million of transaction costs, partially offset by $226 million of income as a result of a tax indemnification reserve release. Adjusted Corporate expenses for the three months ended September 30, 2018 excludes $43 million of integration costs and $4 million of transaction costs.  Adjusted Corporate expenses for the twelve months ended September 30, 2018 excludes $154 million of integration costs and $14 million of transaction costs.

[0000833444-19-000046:8k_2_02:105]
(3) On October 1, 2018, the Company adopted Accounting Standards Update (ASU) No. 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." ASU No. 2016-01 amends certain aspects of recognition, measurement, presentation and disclosure of financial instruments, including marketable securities. The new standard requires the mark-to-market of marketable securities investments previously recorded within accumulated other comprehensive income on the statement of financial position be recorded in the statement of income on a prospective basis beginning as of the adoption date. As these restricted investments do not relate to the underlying operating performance of its businesses, the Company’s definition of adjusted segment EBITA and adjusted EBIT excludes the mark-to-market adjustments effective October 1, 2018. The three months ended September 30, 2019 exclude the net mark-to-market adjustments on restricted investments and pension and postretirement plans of $626 million. The twelve months ended September 30, 2019 exclude the net mark-to-market adjustments on restricted investments and pension and postretirement plans of $618 million.  The three and twelve months ended September 30, 2018 exclude the net mark-to-market adjustments on pension and postretirement plans of $24 million.

[0000833444-19-000046:8k_2_02:106]
(4) Restructuring and impairment costs for the twelve months ended September 30, 2019 of $235 million are excluded from the adjusted non-GAAP results. Restructuring and impairment costs for the three and twelve months ended September 30, 2018 of $101 million and $255 million, respectively, are excluded from the adjusted non-GAAP results. The restructuring actions and impairment costs for the twelve months ended September 30, 2019 result from the impairment of a Global Products business classified as held for sale.  The restructuring and impairment costs for the twelve months ended September 30, 2018 are related primarily to workforce reductions, plant closures and asset impairments in the Building Technologies & Solutions business and at Corporate.

[0000833444-19-000046:8k_2_02:107]
(5) Management defines earnings before interest and taxes (EBIT) as income from continuing operations before net financing charges, income taxes and noncontrolling interests.

[0000833444-19-000046:8k_2_02:108]
(6) Adjusted net financing charges for the twelve months ended September 30, 2019 exclude a loss on debt extinguishment of $60 million.

[0000833444-19-000046:8k_2_02:109]
(7) Adjusted income tax provision for the three months ended September 30, 2019 excludes tax benefits primarily related to tax audit reserve adjustments of $586 million, net mark-to-market adjustments of $132 million and integration costs of $12 million.  Adjusted income tax provision for the twelve months ended September 30, 2019 excludes the tax benefits primarily related to tax audit reserve adjustments of $586 million, net mark-to-market adjustments of $130 million, restructuring and impairment charges of $53 million, integration costs of $34 million, an environmental reserve of $28 million and transaction costs of $1 million, partially offset by tax provisions primarily related to new U.S. tax regulations of $226 million and valuation allowance adjustments of $76 million as a result of changes in U.S. tax law. Adjusted income tax provision for the three months ended September 30, 2018 excludes the tax benefits for changes in entity tax status of $139 million, net tax provision changes related to the U.S. Tax Reform legislation of $96 million, restructuring and impairment costs of $13 million, integration costs of $3 million and transaction costs of $2 million, partially offset by tax provisions related to valuation allowance adjustments of $56 million and net mark-to-market adjustments of $1 million.  Adjusted income tax provision for the twelve months ended September 30, 2018 excludes the tax benefits for changes in entity tax status of $139 million, restructuring and impairment costs of $36 million, tax audit settlements of $25 million, integration costs of $24 million and transaction costs of $3 million, partially offset by net tax provisions related to the U.S. Tax Reform legislation of $108 million, valuation allowance adjustments of $56 million, Scott Safety gain on sale of $30 million and net mark-to-market adjustments of $1 million.

[0000833444-19-000046:8k_2_02:110]
(8) An environmental charge for the twelve months ended September 30, 2019 of $140 million is excluded from the adjusted non-GAAP results.  The $140 million is related to remediation efforts to be undertaken to address contamination at our facilities in Marinette, Wisconsin.  A substantial portion of the reserve relates to the remediation of fire-fighting foams containing PFAS compounds at or near our Fire Technology Center in Marinette.

[0000833444-19-000046:8k_2_02:111]
Page 15 of 18

[0000833444-19-000046:8k_2_02:112]
2.  Diluted Earnings Per Share Reconciliation

[0000833444-19-000046:8k_2_02:113]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include transaction/integration costs, gain on sale of the Scott Safety business, net mark-to-market adjustments, restructuring and impairment costs, tax indemnification reserve release, environmental reserve, loss on extinguishment of debt, gain on sale of Power Solutions business, net of transaction and other costs, impact of ceasing the depreciation / amortization expense for the Power Solutions business as the business is held for sale and discrete tax items. The Company excludes these items because they are not considered to be directly related to the underlying operating performance of the Company. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-19-000046:8k_2_02:114]
A reconciliation of diluted earnings per share as reported to adjusted diluted earnings per share for the respective periods is shown below (unaudited):

[0000833444-19-000046:8k_2_02:115]
|  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc fromContinuing Operations |
|  | Three Months Ended |  | Three Months Ended |
|  | September 30, |  | September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Earnings per share as reported for JCI plc | $ | 0.77 |  |  | $ | 0.83 |  |  | $ | 0.77 |  |  | $ | 0.64 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction costs | 0.01 |  |  | 0.01 |  |  | 0.01 |  |  | — |  |
| Integration costs | 0.14 |  |  | 0.06 |  |  | 0.14 |  |  | 0.06 |  |
| Related tax impact | (0.02 | ) |  | — |  |  | (0.02 | ) |  | — |  |
| Scott Safety gain on sale | — |  |  | — |  |  | — |  |  | — |  |
| Related tax impact | — |  |  | — |  |  | — |  |  | — |  |
| Net mark-to-market adjustments | 0.79 |  |  | (0.01 | ) |  | 0.79 |  |  | (0.03 | ) |
| Related tax impact | (0.17 | ) |  | — |  |  | (0.17 | ) |  | — |  |
| Restructuring and impairment costs | — |  |  | 0.12 |  |  | — |  |  | 0.11 |  |
| Related tax impact | — |  |  | (0.02 | ) |  | — |  |  | (0.01 | ) |
| Tax indemnification reserve release | — |  |  | — |  |  | — |  |  | — |  |
| Environmental reserve | — |  |  | — |  |  | — |  |  | — |  |
| Related tax impact | — |  |  | — |  |  | — |  |  | — |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | — |  |  | — |  |
| Power Solutions gain on sale, net of |  |  |  |  |  |  |  |
| transaction and other costs | — |  |  | — |  |  | — |  |  | — |  |
| Related tax impact | — |  |  | — |  |  | — |  |  | — |  |
| Cease of Power Solutions |  |  |  |  |  |  |  |
| depreciation / amortization expense | — |  |  | — |  |  | — |  |  | — |  |
| Related tax impact | — |  |  | — |  |  | — |  |  | — |  |
| Discrete tax items | (0.74 | ) |  | (0.05 | ) |  | (0.74 | ) |  | (0.19 | ) |
| Adjusted earnings per share for JCI plc * | $ | 0.78 |  |  | $ | 0.93 |  |  | $ | 0.78 |  |  | $ | 0.57 |  |

[0000833444-19-000046:8k_2_02:116]
* May not sum due to rounding

[0000833444-19-000046:8k_2_02:117]
|  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc fromContinuing Operations |
|  | Twelve Months Ended |  | Twelve Months Ended |
|  | September 30, |  | September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Earnings per share as reported for JCI plc | $ | 6.49 |  |  | $ | 2.32 |  |  | $ | 1.26 |  |  | $ | 1.26 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction costs | 0.01 |  |  | 0.02 |  |  | 0.01 |  |  | 0.02 |  |
| Integration costs | 0.35 |  |  | 0.23 |  |  | 0.35 |  |  | 0.23 |  |
| Related tax impact | (0.04 | ) |  | (0.03 | ) |  | (0.04 | ) |  | (0.03 | ) |
| Scott Safety gain on sale | — |  |  | (0.12 | ) |  | — |  |  | (0.12 | ) |
| Related tax impact | — |  |  | 0.03 |  |  | — |  |  | 0.03 |  |
| Net mark-to-market adjustments | 0.71 |  |  | (0.01 | ) |  | 0.71 |  |  | (0.03 | ) |
| Related tax impact | (0.15 | ) |  | — |  |  | (0.15 | ) |  | — |  |
| Restructuring and impairment costs | 0.27 |  |  | 0.29 |  |  | 0.27 |  |  | 0.27 |  |
| Related tax impact | (0.06 | ) |  | (0.04 | ) |  | (0.06 | ) |  | (0.04 | ) |
| Tax indemnification reserve release | (0.26 | ) |  | — |  |  | (0.26 | ) |  | — |  |
| Environmental reserve | 0.16 |  |  | — |  |  | 0.16 |  |  | — |  |
| Related tax impact | (0.03 | ) |  | — |  |  | (0.03 | ) |  | — |  |
| Loss on extinguishment of debt | 0.07 |  |  | — |  |  | 0.07 |  |  | — |  |
| Power Solutions gain on sale, net of |  |  |  |  |  |  |  |
| transaction and other costs | (5.95 | ) |  | — |  |  | — |  |  | — |  |
| Related tax impact | 1.43 |  |  | — |  |  | — |  |  | — |  |
| Cease of Power Solutions |  |  |  |  |  |  |  |
| depreciation / amortization expense | (0.13 | ) |  | — |  |  | — |  |  | — |  |
| Related tax impact | 0.03 |  |  | — |  |  | — |  |  | — |  |
| Discrete tax items | (0.24 | ) |  | 0.14 |  |  | (0.32 | ) |  | — |  |
| Adjusted earnings per share for JCI plc * | $ | 2.65 |  |  | $ | 2.83 |  |  | $ | 1.96 |  |  | $ | 1.59 |  |

[0000833444-19-000046:8k_2_02:118]
* May not sum due to rounding

[0000833444-19-000046:8k_2_02:119]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-19-000046:8k_2_02:120]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 30, |  | September 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Weighted average shares outstanding for JCI plc |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 786.7 |  |  | 924.8 |  |  | 870.2 |  |  | 925.7 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock |  |  |  |  |  |  |  |
| and unvested performance share awards | 5.0 |  |  | 5.7 |  |  | 4.1 |  |  | 6.0 |  |
| Diluted weighted average shares outstanding | 791.7 |  |  | 930.5 |  |  | 874.3 |  |  | 931.7 |  |

[0000833444-19-000046:8k_2_02:121]
The Company has presented forward-looking statements regarding adjusted EPS from continuing operations, organic net sales growth, organic adjusted EBITA growth, organic adjusted EBIT growth, adjusted segment EBITA margin, adjusted EBIT margin and adjusted free cash flow conversion for the full fiscal year of 2020, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts, expenses, income or cash flows from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts that are excluded from these non-GAAP financial measures are a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period, including but not limited to the high variability of the net mark-to-market adjustments and the effect of foreign currency exchange fluctuations. Our fiscal 2020 outlook for organic net sales and adjusted EBITA and EBIT growth also excludes the effect of acquisitions, divestitures and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available and management cannot reliably predict all of the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s full year 2020 GAAP financial results.

[0000833444-19-000046:8k_2_02:122]
Page 16 of 18

[0000833444-19-000046:8k_2_02:123]
3. Organic Growth Reconciliation

[0000833444-19-000046:8k_2_02:124]
The components of the changes in net sales for the three months ended  September 30, 2019 versus the three months ended September 30, 2018, including organic growth, is shown below (unaudited):

[0000833444-19-000046:8k_2_02:125]
| (in millions) | Net Sales for the Three Months Ended September 30, 2018 |  | Base Year Adjustments - Acquisitions and Divestitures |  | Adjusted Base Net Sales for the Three Months Ended September 30, 2018 |  | Foreign Currency |  | Organic Growth |  | Net Sales for the Three Months EndedSeptember 30, 2019 |
| Building Solutions North America | $ | 2,324 |  |  | $ | — |  |  | — |  |  | $ | 2,324 |  |  | $ | (3 | ) |  | — |  |  | $ | 80 |  |  | 3 | % |  | $ | 2,401 |  |  | 3 | % |
| Building Solutions EMEA/LA | 948 |  |  | (1 | ) |  | — |  |  | 947 |  |  | (40 | ) |  | -4 | % |  | 41 |  |  | 4 | % |  | 948 |  |  | — |  |
| Building Solutions Asia Pacific | 689 |  |  | 1 |  |  | — |  |  | 690 |  |  | (11 | ) |  | -2 | % |  | 47 |  |  | 7 | % |  | 726 |  |  | 5 | % |
| Total field | 3,961 |  |  | — |  |  | — |  |  | 3,961 |  |  | (54 | ) |  | -1 | % |  | 168 |  |  | 4 | % |  | 4,075 |  |  | 3 | % |
| Global Products | 2,222 |  |  | (25 | ) |  | -1 | % |  | 2,197 |  |  | (3 | ) |  | — |  |  | 5 |  |  | — |  |  | 2,199 |  |  | — |  |
| Total net sales | $ | 6,183 |  |  | $ | (25 | ) |  | — |  |  | $ | 6,158 |  |  | $ | (57 | ) |  | -1 | % |  | $ | 173 |  |  | 3 | % |  | $ | 6,274 |  |  | 2 | % |

[0000833444-19-000046:8k_2_02:126]
The components of the changes in net sales for the twelve months ended September 30, 2019 versus the twelve months ended September 30, 2018, including organic growth, is shown below (unaudited):

[0000833444-19-000046:8k_2_02:127]
| (in millions) | Net Sales for the Twelve Months Ended September 30, 2018 |  | Base Year Adjustments -Acquisitions and Divestitures |  | Adjusted Base Net Sales for the Twelve Months Ended September 30, 2018 |  | Foreign Currency |  | Organic Growth |  | Net Sales for the Twelve Months EndedSeptember 30, 2019 |
| Building Solutions North America | $ | 8,679 |  |  | $ | — |  |  | — |  |  | $ | 8,679 |  |  | $ | (28 | ) |  | — |  |  | $ | 380 |  |  | 4 | % |  | $ | 9,031 |  |  | 4 | % |
| Building Solutions EMEA/LA | 3,696 |  |  | — |  |  | — |  |  | 3,696 |  |  | (206 | ) |  | -6 | % |  | 165 |  |  | 4 | % |  | 3,655 |  |  | -1 | % |
| Building Solutions Asia Pacific | 2,553 |  |  | 1 |  |  | — |  |  | 2,554 |  |  | (86 | ) |  | -3 | % |  | 190 |  |  | 7 | % |  | 2,658 |  |  | 4 | % |
| Total field | 14,928 |  |  | 1 |  |  | — |  |  | 14,929 |  |  | (320 | ) |  | -2 | % |  | 735 |  |  | 5 | % |  | 15,344 |  |  | 3 | % |
| Global Products | 8,472 |  |  | (151 | ) |  | -2 | % |  | 8,321 |  |  | (143 | ) |  | -2 | % |  | 446 |  |  | 5 | % |  | 8,624 |  |  | 4 | % |
| Total net sales | $ | 23,400 |  |  | $ | (150 | ) |  | -1 | % |  | $ | 23,250 |  |  | $ | (463 | ) |  | -2 | % |  | $ | 1,181 |  |  | 5 | % |  | $ | 23,968 |  |  | 3 | % |

[0000833444-19-000046:8k_2_02:128]
The components of the changes in segment EBITA and EBIT for the three months ended September 30, 2019 versus the three months ended September 30, 2018, including organic growth, is shown below (unaudited):

[0000833444-19-000046:8k_2_02:129]
| (in millions) | Adjusted Segment EBITA / EBIT for the Three Months Ended September 30, 2018 |  | Base Year Adjustments -Acquisitions and Divestitures |  | Adjusted Base Segment EBITA / EBIT for the Three Months Ended September 30, 2018 |  | Foreign Currency |  | Organic Growth |  | Adjusted SegmentEBITA / EBIT forthe ThreeMonths EndedSeptember 30, 2019 |
| Building Solutions North America | $ | 336 |  |  | $ | — |  |  | — |  |  | $ | 336 |  |  | $ | — |  |  | — |  |  | $ | 21 |  |  | 6 | % |  | $ | 357 |  |  | 6 | % |
| Building Solutions EMEA/LA | 103 |  |  | — |  |  | — |  |  | 103 |  |  | (9 | ) |  | -9 | % |  | 17 |  |  | 17 | % |  | 111 |  |  | 8 | % |
| Building Solutions Asia Pacific | 105 |  |  | — |  |  | — |  |  | 105 |  |  | (1 | ) |  | -1 | % |  | (1 | ) |  | -1 | % |  | 103 |  |  | -2 | % |
| Total field | 544 |  |  | — |  |  | — |  |  | 544 |  |  | (10 | ) |  | -2 | % |  | 37 |  |  | 7 | % |  | 571 |  |  | 5 | % |
| Global Products | 395 |  |  | (3 | ) |  | -1 | % |  | 392 |  |  | (1 | ) |  | — |  |  | 28 |  |  | 7 | % |  | 419 |  |  | 7 | % |
| Total adjusted segment EBITA | 939 |  |  | (3 | ) |  | — |  |  | 936 |  |  | $ | (11 | ) |  | -1 | % |  | $ | 65 |  |  | 7 | % |  | 990 |  |  | 6 | % |
| Corporate expenses | (95 | ) |  | — |  |  |  |  | (95 | ) |  |  |  |  |  |  |  |  |  | (89 | ) |  | 6 | % |
| Amortization of intangible assets | (94 | ) |  | — |  |  |  |  | (94 | ) |  |  |  |  |  |  |  |  |  | (89 | ) |  | 5 | % |
| Total adjusted EBIT | $ | 750 |  |  | $ | (3 | ) |  |  |  | $ | 747 |  |  |  |  |  |  |  |  |  |  | $ | 812 |  |  | 9 | % |

[0000833444-19-000046:8k_2_02:130]
The components of the changes in segment EBITA and EBIT for the twelve months ended September 30, 2019 versus the twelve months ended September 30, 2018, including organic growth, is shown below (unaudited):

[0000833444-19-000046:8k_2_02:131]
| (in millions) | Adjusted Segment EBITA / EBIT for the Twelve Months Ended September 30, 2018 |  | Base Year Adjustments -Acquisitions and Divestitures |  | Adjusted Base Segment EBITA / EBIT for the Twelve Months Ended September 30, 2018 |  | Foreign Currency |  | Organic Growth |  | Adjusted SegmentEBITA / EBIT forthe Twelve Months EndedSeptember 30, 2019 |
| Building Solutions North America | $ | 1,134 |  |  | $ | — |  |  | — |  |  | $ | 1,134 |  |  | $ | (2 | ) |  | — |  |  | $ | 47 |  |  | 4 | % |  | $ | 1,179 |  |  | 4 | % |
| Building Solutions EMEA/LA | 350 |  |  | 1 |  |  | — |  |  | 351 |  |  | (35 | ) |  | -10 | % |  | 56 |  |  | 16 | % |  | 372 |  |  | 6 | % |
| Building Solutions Asia Pacific | 347 |  |  | — |  |  | — |  |  | 347 |  |  | (8 | ) |  | -2 | % |  | 4 |  |  | 1 | % |  | 343 |  |  | -1 | % |
| Total field | 1,831 |  |  | 1 |  |  | — |  |  | 1,832 |  |  | (45 | ) |  | -2 | % |  | 107 |  |  | 6 | % |  | 1,894 |  |  | 3 | % |
| Global Products | 1,251 |  |  | (19 | ) |  | -2 | % |  | 1,232 |  |  | (20 | ) |  | -2 | % |  | 137 |  |  | 11 | % |  | 1,349 |  |  | 9 | % |
| Total adjusted segment EBITA | 3,082 |  |  | (18 | ) |  | -1 | % |  | 3,064 |  |  | $ | (65 | ) |  | -2 | % |  | $ | 244 |  |  | 8 | % |  | 3,243 |  |  | 6 | % |
| Corporate expenses | (416 | ) |  | — |  |  |  |  | (416 | ) |  |  |  |  |  |  |  |  |  | (376 | ) |  | 10 | % |
| Amortization of intangible assets | (376 | ) |  | 2 |  |  |  |  | (374 | ) |  |  |  |  |  |  |  |  |  | (377 | ) |  | -1 | % |
| Total adjusted EBIT | $ | 2,290 |  |  | $ | (16 | ) |  |  |  | $ | 2,274 |  |  |  |  |  |  |  |  |  |  | $ | 2,490 |  |  | 9 | % |

[0000833444-19-000046:8k_2_02:132]
Page 17 of 18

[0000833444-19-000046:8k_2_02:133]
4.  Adjusted Free Cash Flow Reconciliation

[0000833444-19-000046:8k_2_02:134]
The Company's press release contains financial information regarding free cash flow, adjusted free cash flow and adjusted free cash flow conversion, which are non-GAAP performance measures. Free cash flow is defined as cash provided by operating activities less capital expenditures. Adjusted free cash flow excludes special items, as included in the table below, because these cash flows are not considered to be directly related to its underlying businesses. Adjusted free cash flow conversion is defined as adjusted free cash flow divided by adjusted net income. Management believes these non-GAAP measures are useful to investors in understanding the strength of the Company and its ability to generate cash.

[0000833444-19-000046:8k_2_02:135]
The following is the three months and twelve months ended September 30, 2019 and 2018 reconciliation of free cash flow, adjusted free cash flow and adjusted free cash flow conversion for continuing operations (unaudited):

[0000833444-19-000046:8k_2_02:136]
| (in billions) | Three Months Ended September 30, 2019 |  | Three Months Ended September 30, 2018 |  | Twelve Months Ended September 30, 2019 |  | Twelve Months Ended September 30, 2018 |
| Cash provided by operating activities from continuing operations | $ | 1.0 |  |  | $ | 0.8 |  |  | $ | 1.7 |  |  | $ | 1.5 |  |
| Capital expenditures | (0.2 | ) |  | (0.2 | ) |  | (0.6 | ) |  | (0.6 | ) |
| Reported free cash flow * | 0.8 |  |  | 0.7 |  |  | 1.2 |  |  | 0.9 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction/integration costs | 0.1 |  |  | 0.1 |  |  | 0.3 |  |  | 0.3 |  |
| Restructuring payments | — |  |  | — |  |  | 0.1 |  |  | 0.2 |  |
| Nonrecurring tax payments, net of refunds | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | — |  |
| Total adjusting items | 0.2 |  |  | 0.2 |  |  | 0.5 |  |  | 0.5 |  |
| Adjusted free cash flow | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.7 |  |  | $ | 1.4 |  |
| Adjusted net income from continuing operations |  |  |  |  |  |  |  |
| attributable to JCI | $ | 0.6 |  |  | $ | 0.5 |  |  | $ | 1.7 |  |  | $ | 1.5 |  |
| Adjusted free cash flow conversion | 167 | % |  | 180 | % |  | 99 | % |  | 93 | % |

[0000833444-19-000046:8k_2_02:137]
* May not sum due to rounding

[0000833444-19-000046:8k_2_02:138]
5.  Net Debt to Capitalization

[0000833444-19-000046:8k_2_02:139]
The Company provides financial information regarding net debt as a percentage of total capitalization, which is a non-GAAP performance measure. The Company believes the percentage of total net debt to total capitalization is useful to understanding the Company's financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders. The following is the September 30, 2019 and September 30, 2018 calculation of net debt as a percentage of total capitalization (unaudited):

[0000833444-19-000046:8k_2_02:140]
| (in millions) | September 30, 2019 |  | September 30, 2018 |
| Short-term debt and current portion of long-term debt | $ | 511 |  |  | $ | 1,307 |  |
| Long-term debt | 6,708 |  |  | 9,623 |  |
| Total debt | 7,219 |  |  | 10,930 |  |
| Less: cash and cash equivalents | 2,805 |  |  | 185 |  |
| Total net debt | 4,414 |  |  | 10,745 |  |
| Shareholders' equity attributable to JCI | 19,766 |  |  | 21,164 |  |
| Total capitalization | $ | 24,180 |  |  | $ | 31,909 |  |
| Total net debt as a % of total capitalization | 18.3 | % |  | 33.7 | % |

[0000833444-19-000046:8k_2_02:141]
6.  Divestitures

[0000833444-19-000046:8k_2_02:142]
On November 13, 2018, the Company entered into a definitive agreement to sell its Power Solutions business to BCP Acquisitions LLC for approximately $13.2 billion. BCP Acquisitions LLC is a newly-formed entity controlled by investment funds managed by Brookfield Capital Partners LLC. The transaction closed on April 30, 2019 with net cash proceeds of $11.6 billion after tax and transaction-related expenses, and the Company recorded a gain, net of transaction and other costs, of $5.2 billion ($4.0 billion after tax).

[0000833444-19-000046:8k_2_02:143]
On March 16, 2017, the Company announced that it signed a definitive agreement to sell its Scott Safety business to 3M for approximately $2.0 billion.  The transaction closed on October 4, 2017. Net cash proceeds from the transaction approximated $1.9 billion and the Company recorded a net gain of $114 million ($84 million after tax). Scott Safety is a leader in the design, manufacture and sale of high performance respiratory protection, gas and flame detection, thermal imaging and other critical products for fire services, law enforcement, industrial, oil and gas, chemical, armed forces, and homeland defense end markets.

[0000833444-19-000046:8k_2_02:144]
7.  Income Taxes

[0000833444-19-000046:8k_2_02:145]
The Company's effective tax rate from continuing operations before consideration of transaction/integration costs, gain on sale of the Scott Safety business, net mark-to-market adjustments, environmental reserve, tax indemnification reserve release, restructuring and impairment costs, loss on extinguishment of debt and discrete tax items for the three and twelve months ending September 30, 2019 is approximately 13.5%, and for the three and twelve months ending September 30, 2018 is approximately 12.1%.

[0000833444-19-000046:8k_2_02:146]
8.  Restructuring and Impairment Costs

[0000833444-19-000046:8k_2_02:147]
The twelve months ended September 30, 2019 include restructuring and impairment costs of $235 million related to the impairment of a Global Products business classified as held for sale. The three and twelve months ended September 30, 2018 include restructuring and impairment costs of $101 million and $255 million, respectively, related primarily to workforce reductions, plant closures and asset impairments in the Building Technologies & Solutions business and at Corporate.

[0000833444-19-000046:8k_2_02:148]
Page 18 of 18
