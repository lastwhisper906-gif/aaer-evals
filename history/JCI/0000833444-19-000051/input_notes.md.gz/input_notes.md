# JCI notes — 0000833444-19-000051


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000833444-19-000051:notes:1]
Portions of the definitive Proxy Statement to be delivered to shareholders in connection with the annual general meeting of shareholders to be held on March 4, 2020 are incorporated by reference into Part III.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000833444-19-000051:notes:2]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0000833444-19-000051:notes:3]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company," "Johnson Controls" or "JCI plc").

[0000833444-19-000051:notes:4]
Nature of Operations

[0000833444-19-000051:notes:5]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global diversified technology and multi industrial leader serving a wide range of customers in more than 150 countries. The Company creates intelligent buildings, efficient energy solutions and integrated infrastructure that work seamlessly together to deliver on the promise of smart cities and communities. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-19-000051:notes:6]
In the fourth quarter of fiscal 2016, Johnson Controls, Inc. ("JCI Inc.") and Tyco International plc ("Tyco") completed their combination, with JCI Inc. merging with a wholly owned, indirect subsidiary of Tyco (the "Merger"). Following the Merger, Tyco changed its name to “Johnson Controls International plc” and JCI Inc. is a wholly-owned subsidiary of Johnson Controls International plc. The Merger was accounted for as a reverse acquisition using the acquisition method of accounting in accordance with Accounting Standards Codification ("ASC") 805, "Business Combinations." JCI Inc. was the accounting acquirer for financial reporting purposes. Accordingly, the historical consolidated financial statements of JCI Inc. for periods prior to this transaction are considered to be the historic financial statements of the Company.

[0000833444-19-000051:notes:7]
On November 13, 2018, the Company entered into a Stock and Asset Purchase Agreement (“Purchase Agreement”) with BCP Acquisitions LLC (“Purchaser”). The Purchaser is a newly-formed entity controlled by investment funds managed by Brookfield Capital Partners LLC. Pursuant to the Purchase Agreement, on the terms and subject to the conditions therein, the Company agreed to sell, and Purchaser agreed to acquire, the Company’s Power Solutions business for a purchase price of $13.2 billion. The transaction closed on April 30, 2019 with net cash proceeds of $11.6 billion after tax and transaction-related expenses.

[0000833444-19-000051:notes:8]
During the first quarter of fiscal 2019, the Company determined that its Power Solutions business met the criteria to be classified as a discontinued operation and, as a result, Power Solutions' historical financial results are reflected in the Company's consolidated financial statements as a discontinued operation, and assets and liabilities were retrospectively reclassified as assets and liabilities held for sale.  Refer to Note 3, "Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-19-000051:notes:9]
The Company is a global market leader in engineering, developing, manufacturing and installing building products and systems around the world, including heating, ventilating, air-conditioning ("HVAC") equipment, HVAC controls, energy-management systems, security systems, fire detection systems and fire suppression solutions. The Company further serves customers by providing technical services (in the HVAC, security and fire-protection space), energy-management consulting and data-driven solutions via its data-enabled business. Finally, the Company has a strong presence in the North American residential air conditioning and heating systems market and is a global market leader in industrial refrigeration products.

[0000833444-19-000051:notes:10]
Principles of Consolidation

[0000833444-19-000051:notes:11]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries that are consolidated in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). All significant intercompany transactions have been eliminated. The results of companies acquired or disposed of during the year are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company’s interest exceeds 20% and the Company does not have a controlling interest.

[0000833444-19-000051:notes:12]
The Company consolidates variable interest entities ("VIE") in which the Company has the power to direct the significant activities of the entity and the obligation to absorb losses or receive benefits from the entity that may be significant.  The Company did not have a significant variable interest in any consolidated or nonconsolidated VIEs in its continuing operations for the presented reporting periods.

[0000833444-19-000051:notes:13]
Use of Estimates

[0000833444-19-000051:notes:14]
The preparation of consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0000833444-19-000051:notes:15]
Fair Value of Financial Instruments

[0000833444-19-000051:notes:16]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. See Note 10, "Derivative Instruments and Hedging Activities," and Note 11, "Fair Value Measurements," of the notes to consolidated financial statements for fair value of financial instruments, including derivative instruments, hedging activities and long-term debt.

[0000833444-19-000051:notes:17]
Assets and Liabilities Held for Sale

[0000833444-19-000051:notes:18]
The Company classifies assets and liabilities (disposal groups) to be sold as held for sale in the period in which all of the following criteria are met: management, having the authority to approve the action, commits to a plan to sell the disposal group; the disposal group is available for immediate sale in its present condition subject only to terms that are usual and customary for sales of such disposal groups; an active program to locate a buyer and other actions required to complete the plan to sell the disposal group have been initiated; the sale of the disposal group is probable, and transfer of the disposal group is expected to qualify for recognition as a completed sale within one year, except if events or circumstances beyond the Company's control extend the period of time required to sell the disposal group beyond one year; the disposal group is being actively marketed for sale at a price that is reasonable in relation to its current fair value; and actions required to complete the plan indicate that it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn.

[0000833444-19-000051:notes:19]
In addition, the Company classifies disposal groups to be disposed of other than by sale (e.g. spin-off) as held for sale in the period the disposal occurs.

[0000833444-19-000051:notes:20]
The Company initially measures a disposal group that is classified as held for sale at the lower of its carrying value or fair value less any costs to sell. Any loss resulting from this measurement is recognized in the period in which the held for sale criteria are met. Conversely, gains are not recognized on the sale of a disposal group until the date of sale. The Company assesses the fair value of a disposal group, less any costs to sell, each reporting period it remains classified as held for sale and reports any subsequent changes as an adjustment to the carrying value of the disposal group, as long as the new carrying value does not exceed the carrying value of the disposal group at the time it was initially classified as held for sale.

[0000833444-19-000051:notes:21]
Upon determining that a disposal group meets the criteria to be classified as held for sale, the Company reports the assets and liabilities of the disposal group, if material, in the line items assets held for sale and liabilities held for sale in the consolidated statements of financial position. Refer to Note 3, "Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-19-000051:notes:22]
Cash and Cash Equivalents

[0000833444-19-000051:notes:23]
The Company considers all highly liquid investments with an original maturity of three months or less when purchased to be cash equivalents.

[0000833444-19-000051:notes:24]
Restricted Cash

[0000833444-19-000051:notes:25]
At September 30, 2019, the Company held restricted cash of approximately $16 million, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts related to cash restricted for payment of asbestos liabilities. At September 30, 2018, the Company held restricted cash of approximately $15 million, of which $6 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position.

[0000833444-19-000051:notes:26]
Receivables

[0000833444-19-000051:notes:27]
Receivables consist of amounts billed and currently due from customers and unbilled costs and accrued profits related to revenues on long-term contracts that have been recognized for accounting purposes but not yet billed to customers. The Company extends credit to customers in the normal course of business and maintains an allowance for doubtful accounts resulting from the inability

[0000833444-19-000051:notes:28]
or unwillingness of customers to make required payments. The allowance for doubtful accounts is based on historical experience, existing economic conditions and any specific customer collection issues the Company has identified. The Company enters into supply chain financing programs to sell certain accounts receivable without recourse to third-party financial institutions. Sales of accounts receivable are reflected as a reduction of accounts receivable on the consolidated statements of financial position and the proceeds are included in cash flows from operating activities in the consolidated statements of cash flows.

[0000833444-19-000051:notes:29]
Inventories

[0000833444-19-000051:notes:30]
Inventories are stated at the lower of cost or market using the first-in, first-out ("FIFO") method. Finished goods and work-in-process inventories include material, labor and manufacturing overhead costs.

[0000833444-19-000051:notes:31]
Property, Plant and Equipment

[0000833444-19-000051:notes:32]
Property, plant and equipment are recorded at cost. Depreciation is provided over the estimated useful lives of the respective assets using the straight-line method for financial reporting purposes and accelerated methods for income tax purposes. The estimated useful lives generally range from 3 to 40 years for buildings and improvements, subscriber systems up to 15 years, and from 3 to 15 years for machinery and equipment. The Company capitalizes interest on borrowings during the active construction period of major capital projects. Capitalized interest is added to the cost of the underlying assets and is amortized over the useful lives of the assets.

[0000833444-19-000051:notes:33]
Goodwill and Indefinite-Lived Intangible Assets

[0000833444-19-000051:notes:34]
Goodwill reflects the cost of an acquisition in excess of the fair values assigned to identifiable net assets acquired. The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s reportable segments or one level below the reportable segments in certain instances, using a fair value method based on management’s judgments and assumptions or third party valuations. The fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. In estimating the fair value, the Company uses multiples of earnings based on the average of published multiples of earnings of comparable entities with similar operations and economic characteristics and applies to the Company's average of historical and future financial results. In certain instances, the Company uses discounted cash flow analyses or estimated sales price to further support the fair value estimates. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The estimated fair value is then compared with the carrying amount of the reporting unit, including recorded goodwill. The Company is subject to financial statement risk to the extent that the carrying amount exceeds the estimated fair value. Refer to Note 7, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for information regarding the goodwill impairment testing performed in fiscal years 2019, 2018 and 2017.

[0000833444-19-000051:notes:35]
Indefinite-lived intangible assets are also subject to at least annual impairment testing. Indefinite-lived intangible assets primarily consist of trademarks and tradenames and are tested for impairment using a relief-from-royalty method. A considerable amount of management judgment and assumptions are required in performing the impairment tests.

[0000833444-19-000051:notes:36]
Impairment of Long-Lived Assets

[0000833444-19-000051:notes:37]
The Company reviews long-lived assets, including tangible assets and other intangible assets with definitive lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of Software to be Sold, Leased, or Marketed."  ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. ASC 350-30 requires intangible assets acquired in a business combination that are used in research and development activities to be considered indefinite lived until the completion or abandonment of the associated research and development efforts. During the period that those assets are considered indefinite lived, they shall not be amortized but shall be tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired.  If the carrying amount of an intangible asset exceeds its fair value, an entity shall recognize an impairment loss in an amount equal to that excess. ASC 985-20 requires the unamortized capitalized costs of a computer software product be compared to the net realizable value of that product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset shall be written off. Refer to Note 17, "Impairment of

[0000833444-19-000051:notes:38]
Long-Lived Assets," of the notes to consolidated financial statements for information regarding the impairment testing performed in fiscal years 2019, 2018 and 2017.

[0000833444-19-000051:notes:39]
Revenue Recognition

[0000833444-19-000051:notes:40]
The Company recognizes revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. The Company does not adjust the promised amount of consideration for the effects of a significant financing component as at contract inception the Company expects to receive the payment within twelve months of transfer of goods or services.

[0000833444-19-000051:notes:41]
The Company enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized over time on a straight-line basis over the respective contract term.

[0000833444-19-000051:notes:42]
The Company also sells certain HVAC and refrigeration products and services in bundled arrangements with multiple performance obligations, such as equipment, commissioning, service labor and extended warranties. Approximately four to twelve months separate the timing of the first deliverable until the last piece of equipment is delivered, and there may be extended warranty arrangements with duration of one to five years commencing upon the end of the standard warranty period. In addition, the Company sells security monitoring systems that may have multiple performance obligations, including equipment, installation, monitoring services and maintenance agreements. Revenues associated with sale of equipment and related installations are recognized over time on a cost-to-cost input method, while the revenue for monitoring and maintenance services are recognized over time as services are rendered. The transaction price is allocated to each performance obligation based on the relative selling price method. In order to estimate relative selling price, market data and transfer price studies are utilized. If the standalone selling price is not directly observable, the Company estimates the standalone selling price using an adjusted market assessment approach or expected cost plus margin approach. For transactions in which the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized over time on a straight-line basis over the contract term. Non-refundable fees received in connection with the initiation of a monitoring contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the contract.

[0000833444-19-000051:notes:43]
In all other cases, the Company recognizes revenue at the point in time when control over the goods or services transfers to the customer.

[0000833444-19-000051:notes:44]
The Company considers the contractual consideration payable by the customer and assesses variable consideration that may affect the total transaction price, including discounts, rebates, refunds, credits or other similar sources of variable consideration, when determining the transaction price of each contract. The Company includes variable consideration in the estimated transaction price when it is probable that significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. These estimates are based on the amount of consideration that the Company expects to be entitled to.

[0000833444-19-000051:notes:45]
Shipping and handling costs billed to customers are included in sales and the related costs are included in cost of sales when control transfers to the customer. The Company presents amounts collected from customers for sales and other taxes net of the related amounts remitted.

[0000833444-19-000051:notes:46]
Subscriber System Assets, Dealer Intangibles and Related Deferred Revenue Accounts

[0000833444-19-000051:notes:47]
The Company considers assets related to the acquisition of new customers in its electronic security business in three asset categories: internally generated residential subscriber systems outside of North America, internally generated commercial subscriber systems (collectively referred to as subscriber system assets) and customer accounts acquired through the ADT dealer program, primarily outside of North America (referred to as dealer intangibles). Subscriber system assets include installed property, plant and equipment for which the Company retains ownership and deferred costs directly related to the customer acquisition and system installation. Subscriber system assets represent capitalized equipment (e.g. security control panels, touchpad, motion detectors, window sensors, and other equipment) and installation costs associated with electronic security monitoring arrangements under which the Company retains ownership of the security system assets in a customer's place of business, or outside of North America, residence. Installation

[0000833444-19-000051:notes:48]
costs represent costs incurred to prepare the asset for its intended use. The Company pays property taxes on the subscriber system assets and upon customer termination, may retrieve such assets. These assets embody a probable future economic benefit as they generate future monitoring revenue for the Company.

[0000833444-19-000051:notes:49]
Costs related to the subscriber system equipment and installation are categorized as property, plant and equipment rather than deferred costs. Deferred costs associated with subscriber system assets represent direct and incremental selling expenses (such as commissions) related to acquiring the customer. Commissions related to up-front consideration paid by customers in connection with the establishment of the monitoring arrangement are determined based on a percentage of the up-front fees and do not exceed deferred revenue. Such deferred costs are recorded as other current and noncurrent assets within the consolidated statements of financial position.

[0000833444-19-000051:notes:50]
Subscriber system assets and any deferred revenue resulting from the customer acquisition are accounted for over the expected life of the subscriber. In certain geographical areas where the Company has a large number of customers that behave in a similar manner over time, the Company accounts for subscriber system assets and related deferred revenue using pools, with separate pools for the components of subscriber system assets and any related deferred revenue based on the same month and year of acquisition. The Company depreciates its pooled subscriber system assets and related deferred revenue using a straight-line method with lives up to 12 years and considering customer attrition. The Company uses a straight-line method with a 15-year life for non-pooled subscriber system assets (primarily in Europe, Latin America and Asia) and related deferred revenue, with remaining balances written off upon customer termination.

[0000833444-19-000051:notes:51]
Certain contracts and related customer relationships result from purchasing residential security monitoring contracts from an external network of independent dealers who operate under the ADT dealer program, primarily outside of North America. Acquired contracts and related customer relationships are recorded at their contractually determined purchase price.

[0000833444-19-000051:notes:52]
During the first 6 months (12 months in certain circumstances) after the purchase of the customer contract, any cancellation of monitoring service, including those that result from customer payment delinquencies, results in a chargeback by the Company to the dealer for the full amount of the contract purchase price. The Company records the amount charged back to the dealer as a reduction of the previously recorded intangible asset.

[0000833444-19-000051:notes:53]
Intangible assets arising from the ADT dealer program described above are amortized in pools determined by the same month and year of contract acquisition on a straight-line basis over the period of the customer relationship. The estimated useful life of dealer intangibles ranges from 12 to 15 years.

[0000833444-19-000051:notes:54]
Research and Development Costs

[0000833444-19-000051:notes:55]
Expenditures for research activities relating to product development and improvement are charged against income as incurred and included within selling, general and administrative expenses for continuing operations in the consolidated statements of income. Such expenditures for the years ended September 30, 2019, 2018 and 2017 were $319 million, $310 million and $307 million, respectively.

[0000833444-19-000051:notes:56]
Earnings Per Share

[0000833444-19-000051:notes:57]
The Company presents both basic and diluted earnings per share ("EPS") amounts. Basic EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of common shares outstanding during the reporting period. Diluted EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of common shares and common equivalent shares outstanding during the reporting period that are calculated using the treasury stock method for stock options, unvested restricted stock and unvested performance share awards. See Note 13, "Earnings per Share," of the notes to consolidated financial statements for the calculation of earnings per share.

[0000833444-19-000051:notes:58]
Foreign Currency Translation

[0000833444-19-000051:notes:59]
Substantially all of the Company’s international operations use the respective local currency as the functional currency. Assets and liabilities of international entities have been translated at period-end exchange rates, and income and expenses have been translated using average exchange rates for the period. Monetary assets and liabilities denominated in non-functional currencies are adjusted to reflect period-end exchange rates. The aggregate transaction gains (losses), net of the impact of foreign currency hedges, included in income from continuing operations for the years ended September 30, 2019, 2018 and 2017 were $(10) million, $1 million and $60 million, respectively.

[0000833444-19-000051:notes:60]
Derivative Financial Instruments

[0000833444-19-000051:notes:61]
The Company has written policies and procedures that place all financial instruments under the direction of Corporate treasury and restrict all derivative transactions to those intended for hedging purposes. The use of financial instruments for speculative purposes is strictly prohibited. The Company selectively uses financial instruments to manage the market risk from changes in foreign exchange rates, commodity prices, stock-based compensation liabilities and interest rates.

[0000833444-19-000051:notes:62]
The fair values of all derivatives are recorded in the consolidated statements of financial position. The change in a derivative’s fair value is recorded each period in current earnings or accumulated other comprehensive income ("AOCI"), depending on whether the derivative is designated as part of a hedge transaction and if so, the type of hedge transaction. See Note 10, "Derivative Instruments and Hedging Activities," and Note 11, "Fair Value Measurements," of the notes to consolidated financial statements for disclosure of the Company’s derivative instruments and hedging activities.

[0000833444-19-000051:notes:63]
Investments

[0000833444-19-000051:notes:64]
The Company invests in debt and equity securities which are marked to market at the end of each accounting period. For fiscal 2019, unrealized gains and losses on these securities are recognized in the Company's consolidated statements of income. For periods prior to fiscal 2019, the unrealized gains and losses on these securities, other than the deferred compensation plan assets, were recognized in AOCI within the consolidated statement of shareholders' equity unless an unrealized loss is deemed to be other than temporary, in which case such loss was charged to earnings. The deferred compensation plan assets are marked to market at the end of each accounting period and all unrealized gains and losses are recorded in the consolidated statements of income.

[0000833444-19-000051:notes:65]
Pension and Postretirement Benefits

[0000833444-19-000051:notes:66]
The Company utilizes a mark-to-market approach for recognizing pension and postretirement benefit expenses, including measuring the market related value of plan assets at fair value and recognizing actuarial gains and losses in the fourth quarter of each fiscal year or at the date of a remeasurement event. Refer to Note 15, "Retirement Plans," of the notes to consolidated financial statements for disclosure of the Company's pension and postretirement benefit plans.

[0000833444-19-000051:notes:67]
Loss Contingencies

[0000833444-19-000051:notes:68]
Accruals are recorded for various contingencies including legal proceedings, environmental matters, self-insurance and other claims that arise in the normal course of business. The accruals are based on judgment, the probability of losses and, where applicable, the consideration of opinions of internal and/or external legal counsel and actuarially determined estimates. Additionally, the Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-19-000051:notes:69]
The Company is subject to laws and regulations relating to protecting the environment. The Company provides for expenses associated with environmental remediation obligations when such amounts are probable and can be reasonably estimated. Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements.

[0000833444-19-000051:notes:70]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company records receivables from third party insurers when recovery has been determined to be probable. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-19-000051:notes:71]
Asbestos-Related Contingencies and Insurance Receivables

[0000833444-19-000051:notes:72]
The Company and certain of its subsidiaries along with numerous other companies are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-19-000051:notes:73]
In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable. The Company's estimate of asbestos-related insurance recoveries represents estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims discounted to present value. In determining the amount of insurance recoverable, the Company considers available insurance, allocation methodologies, solvency and creditworthiness of the insurers. Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements for a discussion on management's judgments applied in the recognition and measurement of asbestos-related assets and liabilities.

[0000833444-19-000051:notes:74]
Income Taxes

[0000833444-19-000051:notes:75]
Deferred tax liabilities and assets are recognized for the expected future tax consequences of events that have been reflected in the consolidated financial statements. Deferred tax liabilities and assets are determined based on the differences between the book and tax basis of particular assets and liabilities and operating loss carryforwards, using tax rates in effect for the years in which the differences are expected to reverse. A valuation allowance is provided to reduce the carrying or book value of deferred tax assets if, based upon the available evidence, including consideration of tax planning strategies, it is more-likely-than-not that some or all of the deferred tax assets will not be realized. Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements.

[0000833444-19-000051:notes:76]
Retrospective Changes

[0000833444-19-000051:notes:77]
During the first quarter of fiscal 2019, the Company determined that its Power Solutions business met the criteria to be classified as a discontinued operation, which required retrospective application to financial information for all periods presented. Refer to Note 3, "Discontinued Operations" of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

[0000833444-19-000051:notes:78]
In November 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force)." The ASU requires amounts generally described as restricted cash and restricted cash equivalents to be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. ASU No. 2016-18 was effective retrospectively for the quarter ended December 31, 2018. As of September 30, 2016, the Company had approximately $2.0 billion of restricted cash related to restricted proceeds deposited into escrow from the issuance of $2.0 billion aggregate principal of unsecured, unsubordinated notes by Adient Global Holdings Ltd., that were released upon the completion of the Adient spin-off in October 2016. Upon adoption of ASU 2016-18, the release of the restricted proceeds are presented in the fiscal 2017 consolidated statements of cash flow as a financing activity outflow from discontinued operations. The remaining impact of this guidance did not have a significant impact on the Company's consolidated financial statements for the periods presented, as the restricted cash balance for the fiscal years ended September 30, 2019 and 2018 was $16 million and $15 million, respectively.

[0000833444-19-000051:notes:79]
In August 2016, the FASB issued ASU No. 2016-15, "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments." ASU No. 2016-15 provides clarification guidance on eight specific cash flow presentation issues in order to reduce the diversity in practice. ASU No. 2016-15 was effective retrospectively for the Company for the quarter ending December

[0000833444-19-000051:notes:80]
31, 2018. The adoption of this guidance had an impact on the presentation of equity swap funding and settlement activities since the activity changed from an operating activity to an investing activity.

[0000833444-19-000051:notes:81]
New Accounting Pronouncements

[0000833444-19-000051:notes:82]
Recently Adopted Accounting Pronouncements

[0000833444-19-000051:notes:83]
In March 2018, the FASB issued ASU No. 2018-05, "Income Taxes (Topic 740): Amendments to SEC Paragraphs Pursuant to SEC Staff Accounting Bulletin No. 118," to add various SEC paragraphs pursuant to the issuance of SEC Staff Accounting Bulletin No. 118 ("SAB 118") to ASC 740 "Income Taxes." SAB 118 was issued by the SEC in December 2017 to provide immediate guidance for accounting implications of U.S. Tax Reform under the "Tax Cuts and Jobs Act" in the period of enactment. SAB 118 provides for a provisional one year measurement period for entities to finalize their accounting for certain income tax effects related to the "Tax Cuts and Jobs Act." The Company applied this guidance to its consolidated financial statements and related disclosures beginning in the first quarter of fiscal 2018. In the first quarter of fiscal 2019, the Company completed its analysis of all enactment-date income tax effects of the U.S. tax law change. Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements for further information.

[0000833444-19-000051:notes:84]
In March 2017, the FASB issued ASU No. 2017-07, "Compensation—Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost." The ASU requires the service cost component of net periodic benefit cost to be presented with other compensation costs. The other components of net periodic benefit cost are required to be presented in the income statement separately from the service cost component and outside a subtotal of income from operations, if one is presented. The ASU also allows only the service cost component of net periodic benefit cost to be eligible for capitalization. ASU No. 2017-07 was effective for the quarter ended December 31, 2018. The guidance was effective retrospectively except for the capitalization of the service cost component which was applied prospectively. The adoption of this guidance did not have a significant impact on the Company's consolidated financial statements as the Company does not present a subtotal of income from operations within its consolidated statements of income.

[0000833444-19-000051:notes:85]
In October 2016, the FASB issued ASU No. 2016-16, "Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory." The ASU requires the tax effects of all intra-entity sales of assets other than inventory to be recognized in the period in which the transaction occurs. The guidance was effective for the Company for the quarter ended December 31, 2018. The changes were applied by means of a cumulative-effect adjustment which resulted in a reduction to retained earnings and other noncurrent assets of $546 million.

[0000833444-19-000051:notes:86]
In January 2016, the FASB issued ASU No. 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." ASU No. 2016-01 amends certain aspects of recognition, measurement, presentation and disclosure of financial instruments, including marketable securities. Additionally in February 2018, the FASB issued ASU No. 2018-03, "Technical Corrections and Improvements to Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities," which provides additional clarification on certain topics addressed in ASU No. 2016-01. ASU No. 2016-01 and ASU No. 2018-03 were effective for the Company for the quarter ending December 31, 2018. The changes were applied by means of a cumulative-effect adjustment which resulted in an increase to retained earnings of $8 million. The new standard requires the mark-to-market of marketable securities investments previously recorded within accumulated other comprehensive income on the statement of financial position be recorded in the statement of income on a prospective basis beginning as of the adoption date. As these restricted investments do not relate to the underlying operating performance of its business, the Company’s definition of segment earnings excludes the mark-to-market adjustments beginning in the first quarter of fiscal 2019.  Refer to Note 19, "Segment Information," of the notes to consolidated financial statements for further information.

[0000833444-19-000051:notes:87]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers (Topic 606)." ASU No. 2014-09 and its related amendments (collectively, the “New Revenue Standard”) clarify the principles for recognizing revenue when an entity either enters into a contract with customers to transfer goods or services or enters into a contract for the transfer of non-financial assets. The Company adopted the New Revenue Standard on October 1, 2018 using a modified retrospective approach. Under the New Revenue Standard, revenue recognition is mostly consistent with the previous guidance, with the exception of the Power Solutions business, which is now reported as a discontinued operation beginning in the first quarter of fiscal 2019. Within the Power Solutions business, certain customers return battery cores which are now included in the transaction price as noncash consideration. The New Revenue Standard did not have a material impact on the Company’s consolidated statements of financial position, consolidated statements of income or its consolidated statements of cash flows. As of October 1, 2018, the Company applied the New Revenue Standard to contracts that were not completed as of this date and recognized a cumulative-effect adjustment of a reduction to retained earnings of $45 million, which relates primarily to deferred revenue recorded for certain battery core

[0000833444-19-000051:notes:88]
returns that represent a material right provided to customers. The prior period comparative information has not been revised and continues to be reported under the previous guidance.

[0000833444-19-000051:notes:89]
The impact of adoption of the New Revenue Standard to the Company's consolidated statement of income for the fiscal year ended September 30, 2019 for continuing operations was an increase to net sales of approximately $3 million, with the impact to income before taxes of less than $1 million. The impact of adoption of the New Revenue Standard to the Company's consolidated statement of income for the fiscal year ended September 30, 2019 for discontinued operations was an increase to net sales of $667 million, with the impact to income from discontinued operations, net of tax, of approximately $26 million.

[0000833444-19-000051:notes:90]
The impact of adoption of the New Revenue Standard to the Company's consolidated statement of financial position as of September 30, 2019 is as follows (in millions):

[0000833444-19-000051:notes:91]
|  | September 30, 2019 |
|  | As reported |  | Under previous accounting guidance |  | Impact from adopting the New Revenue Standard |
| Consolidated Statement of Financial Position |  |  |  |  |  |
| Assets |  |  |  |  |  |
| Accounts receivable - net | $ | 5,770 |  |  | $ | 5,802 |  |  | $ | (32 | ) |
| Inventories | 1,814 |  |  | 1,828 |  |  | (14 | ) |
| Other current assets | 1,906 |  |  | 1,931 |  |  | (25 | ) |
| Property, plant and equipment - net | 3,348 |  |  | 3,308 |  |  | 40 |  |
| Other noncurrent assets | 1,823 |  |  | 1,794 |  |  | 29 |  |
| Liabilities and Equity |  |  |  |  |  |
| Deferred revenue | 1,407 |  |  | 1,398 |  |  | 9 |  |
| Retained earnings | 4,827 |  |  | 4,838 |  |  | (11 | ) |

[0000833444-19-000051:notes:92]
Recently Issued Accounting Pronouncements

[0000833444-19-000051:notes:93]
In February 2016, the FASB issued ASU No. 2016-02, "Leases (Topic 842)." ASU No. 2016-02 requires recognition of operating leases as lease assets and liabilities on the balance sheet, and disclosure of key information about leasing arrangements. The original standard was effective retrospectively for the Company for the quarter ending December 31, 2019 with early adoption permitted; however, in July 2018 the FASB issued ASU No. 2018-11, "Leases (Topic 842): Targeted Improvements," which provides an additional transition method that permits changes to be applied by means of a cumulative-effect adjustment recorded in retained earnings as of the beginning of the fiscal year of adoption. The Company has elected this transition method at the adoption date of October 1, 2019. The FASB further amended Topic 842 by issuing ASU No. 2018-01, "Leases (Topic 842): Land Easement Practical Expedient for Transition to Topic 842," which provides an optional transition practical expedient for existing or expired land easements that were not previously recorded as leases, ASU No. 2018-10, "Codification Improvements to Topic 842, Leases," ASU No. 2018-20, "Leases (Topic 842): Narrow-Scope Improvements for Lessors," and ASU No. 2019-01, "Leases (Topic 842): Codification Improvements." The Company has populated its leases into new lease accounting software and is designing and implementing new processes and controls for the accounting for leases under the new guidance. The Company is the lessee under various agreements for facilities and equipment that are currently accounted for as operating leases. The new guidance will require the Company to record operating leases on the balance sheet with a right-of-use ("ROU") asset and corresponding lease liability for future payment obligations. The Company has elected to apply the package of transitional practical expedients, under which the Company will not reassess prior conclusions about lease identification, lease classification, and initial direct costs of existing leases as of the date of adoption. The Company expects the ROU asset and operating lease liability to be less than 3% of its total assets. However, the Company does not expect the new guidance to have a material impact on its consolidated statements of income and its consolidated statements of cash flows.

[0000833444-19-000051:notes:94]
Other recently issued accounting pronouncements are not expected to have a material impact on the Company's consolidated financial statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-19-000051:notes:95]
ACQUISITIONS AND DIVESTITURES

[0000833444-19-000051:notes:96]
Fiscal Year 2019

[0000833444-19-000051:notes:97]
On April 30, 2019, the Company completed the sale of its Power Solutions business to BCP Acquisitions LLC for a purchase price of $13.2 billion. The net cash proceeds after tax and transaction-related expenses were $11.6 billion. In connection with the sale, the Company recorded a gain, net of transaction and other costs, of $5.2 billion ($4.0 billion after tax), subject to post-closing working capital and net debt adjustments, within income from discontinued operations, net of tax, in the consolidated statements of income. During the first quarter of fiscal 2019, the Company determined that its Power Solutions business met the criteria to be classified as a discontinued operation and, as a result, Power Solutions' historical financial results are reflected in the Company's consolidated financial statements as a discontinued operation. Refer to Note 3, "Discontinued Operations," of the notes to consolidated financial statements for further disclosure related to the Company's discontinued operations.

[0000833444-19-000051:notes:98]
During fiscal 2019, the Company completed certain divestitures within the Global Products and Building Solutions EMEA/LA businesses. The combined selling price was $18 million, $16 million of which was received as of September 30, 2019. In connection with the sale, the Company reduced goodwill by $1 million within the Building Solutions EMEA/LA segment. The divestitures were not material to the Company's consolidated financial statements.

[0000833444-19-000051:notes:99]
During fiscal 2019, the Company completed certain acquisitions for a combined purchase price of $32 million, $25 million of which was paid as of September 30, 2019. The acquisitions were not material to the Company's consolidated financial statements. In connection with the acquisitions, the Company recorded goodwill of $11 million within the Global Products segment, $8 million within the Building Solutions Asia Pacific segment, and $6 million within the Building Solutions EMEA/LA segment.

[0000833444-19-000051:notes:100]
Fiscal Year 2018

[0000833444-19-000051:notes:101]
During fiscal 2018, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $21 million, all of which was paid as of September 30, 2018. The acquisitions in the aggregate were not material to the Company’s consolidated financial statements. In connection with the acquisitions, the Company recorded goodwill of $14 million within the Global Products segment and $1 million within the Building Solutions EMEA/LA segment.

[0000833444-19-000051:notes:102]
In the first quarter of fiscal 2018, the Company completed the sale of its Scott Safety business to 3M Company. The selling price, net of cash divested, was $2.0 billion, all of which was received as of September 30, 2018. In connection with the sale, the Company recorded a pre-tax gain of $114 million within selling, general and administrative expenses in the consolidated statements of income and reduced goodwill in assets held for sale by $1.2 billion. The gain, net of tax, recorded was $84 million. Net cash proceeds from the transaction of approximately $1.9 billion were used to repay a significant portion of the Tyco International Holding S.a.r.L.'s ("TSarl") $4.0 billion of merger-related debt.

[0000833444-19-000051:notes:103]
Also during fiscal 2018, the Company completed certain divestitures primarily within the Global Products business. The combined selling price was $204 million, all of which was received as of September 30, 2018. In connection with the divestitures, the Company reduced goodwill by $35 million. The divestitures were not material to the Company's consolidated financial statements.

[0000833444-19-000051:notes:104]
Fiscal Year 2017

[0000833444-19-000051:notes:105]
During fiscal 2017, the Company completed three acquisitions for a combined purchase price, net of cash acquired, of $9 million, $6 million of which was paid as of September 30, 2017. The acquisitions in the aggregate were not material to the Company’s consolidated financial statements. In connection with the acquisitions, the Company recorded goodwill of $2 million.

[0000833444-19-000051:notes:106]
In the second quarter of fiscal 2017, the Company completed the sale of its ADT security business in South Africa within the Building Solutions EMEA/LA segment. The selling price, net of cash divested, was $129 million, all of which was received as of September 30, 2017. In connection with the sale, the Company reduced goodwill in assets held for sale by $92 million. The divestiture was not material to the Company's consolidated financial statements.

[0000833444-19-000051:notes:107]
During fiscal 2017, the Company completed two divestitures for a combined selling price, net of cash divested, of $44 million, of which $40 million was received as of September 30, 2017. The divestitures were not material to the Company's consolidated financial statements. In connection with the divestitures, the Company reduced goodwill by $19 million and $2 million in the Global Products segment and in the Building Solutions Asia Pacific segment, respectively.

[0000833444-19-000051:notes:108]
During fiscal 2017, the Company completed one additional divestiture for a sales price of $4 million, all of which was received as of September 30, 2017. The divestiture decreased the Company's ownership from a controlling to noncontrolling interest, and

[0000833444-19-000051:notes:109]
as a result, the Company deconsolidated cash of $5 million. The divestiture was not material to the Company's consolidated financial statements.

[0000833444-19-000051:notes:110]
During fiscal 2017, the Company received $52 million in net cash proceeds related to prior year business divestitures and paid $75 million related to prior year business acquisitions.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-19-000051:notes:111]
DISCONTINUED OPERATIONS

[0000833444-19-000051:notes:112]
Power Solutions

[0000833444-19-000051:notes:113]
During the first quarter of fiscal 2019, the Company determined that its Power Solutions business met the criteria to be classified as a discontinued operation and, as a result, Power Solutions' historical financial results are reflected in the Company's consolidated financial statements as a discontinued operation, and assets and liabilities were retrospectively reclassified as assets and liabilities held for sale. The Company did not allocate any general corporate overhead to discontinued operations.

[0000833444-19-000051:notes:114]
The following table summarizes the results of Power Solutions reclassified as discontinued operations for the fiscal years ended September 30, 2019, 2018 and 2017 (in millions). As the Power Solutions sale occurred on April 30, 2019, there are only seven months of results included in the fiscal year ended September 30, 2019.

[0000833444-19-000051:notes:115]
|  |  | Year Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Net sales |  | $ | 5,001 |  |  | $ | 8,000 |  |  | $ | 7,337 |  |
| Income from discontinued operations before income taxes |  | 6,039 |  |  | 1,355 |  |  | 1,407 |  |
| Provision for income taxes on discontinued operations |  | (1,441 | ) |  | (321 | ) |  | (383 | ) |
| Income from discontinued operations attributable to noncontrolling interests, net of tax |  | (24 | ) |  | (47 | ) |  | (42 | ) |
| Income from discontinued operations |  | $ | 4,574 |  |  | $ | 987 |  |  | $ | 982 |  |

[0000833444-19-000051:notes:116]
For the fiscal year ended September 30, 2019, income from discontinued operations before income taxes included a gain on sale of the Power Solutions business, net of transaction and other costs, of $5.2 billion and a favorable impact of $117 million for ceasing depreciation and amortization expense as the business was held for sale.

[0000833444-19-000051:notes:117]
For the fiscal year ended September 30, 2019, the effective tax rate was more than the Irish statutory rate of 12.5% primarily due to the tax impacts of the divestiture of the Power Solutions business and tax rate differentials. For the fiscal year ended September 30, 2018, the effective tax rate was more than the Irish statutory rate of 12.5% primarily due to legal entity restructuring associated with the Power Solutions business and tax rate differentials. For the fiscal year ended September 30, 2017, the effective tax rate was more than the Irish statutory rate of 12.5% primarily due to a tax expense due to changes in entity tax status, the establishment of a deferred tax liability on the outside basis difference of certain nonconsolidated subsidiaries and tax rate differentials.

[0000833444-19-000051:notes:118]
Adient plc

[0000833444-19-000051:notes:119]
On October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience business from Johnson Controls to Adient plc. The Company did not retain any equity interest in Adient plc. During the first quarter of fiscal 2017, the Company determined that Adient met the criteria to be classified as a discontinued operation and, as a result, Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation. The Company did not allocate any general corporate overhead to discontinued operations.

[0000833444-19-000051:notes:120]
The following table summarizes the results of Adient, reclassified as discontinued operations for the fiscal year ended September 30, 2017 (in millions). As the Adient spin-off occurred on October 31, 2016, there is only one month of Adient results included in the year ended September 30, 2017.

[0000833444-19-000051:notes:121]
|  |  | Year Ended September 30, 2017 |
| Net sales |  | $ | 1,434 |  |
| Income from discontinued operations before income taxes |  | 1 |  |
| Provision for income taxes on discontinued operations |  | (35 | ) |
| Income from discontinued operations attributable to noncontrolling interests, net of tax |  | (9 | ) |
| Loss from discontinued operations |  | $ | (43 | ) |

[0000833444-19-000051:notes:122]
For the fiscal year ended September 30, 2017, the income from discontinued operations before income taxes included separation costs of $79 million.

[0000833444-19-000051:notes:123]
For the fiscal year ended September 30, 2017, the effective tax rate was more than the Irish statutory rate of 12.5% primarily due to the tax impacts of separation costs and Adient spin-off related tax expense, partially offset by non-U.S. tax rate differentials.

[0000833444-19-000051:notes:124]
The following table summarizes the carrying value of the Power Solutions assets and liabilities held for sale at September 30, 2018 (in millions):

[0000833444-19-000051:notes:125]
|  |  | September 30, 2018 |  |
| Cash |  | $ | 15 |  |
| Accounts receivable - net |  | 1,443 |  |
| Inventories |  | 1,405 |  |
| Other current assets |  | 152 |  |
| Assets held for sale |  | $ | 3,015 |  |
| Property, plant and equipment - net |  | $ | 2,871 |  |
| Goodwill |  | 1,092 |  |
| Other intangible assets - net |  | 161 |  |
| Investments in partially-owned affiliates |  | 453 |  |
| Other noncurrent assets |  | 611 |  |
| Noncurrent assets held for sale |  | $ | 5,188 |  |
| Short-term debt |  | $ | 9 |  |
| Current portion of long-term debt |  | 25 |  |
| Accounts payable |  | 1,237 |  |
| Accrued compensation and benefits |  | 125 |  |
| Other current liabilities |  | 395 |  |
| Liabilities held for sale |  | $ | 1,791 |  |
| Long-term debt |  | 31 |  |
| Pension and postretirement benefits |  | 101 |  |
| Other noncurrent liabilities |  | 75 |  |
| Noncurrent liabilities held for sale |  | $ | 207 |  |

[0000833444-19-000051:notes:126]
During the third quarter of fiscal 2019, the Company determined that a business within its Global Products segment met the criteria to be classified as held for sale. The assets and liabilities of this business are presented as held for sale in the consolidated statements of financial position as of September 30, 2019. Assets and liabilities held for sale are required to be recorded at the lower of carrying value or fair value less any costs to sell. Accordingly, the Company recorded an impairment charge of $235 million within restructuring and impairment costs in the consolidated statements of income in the third quarter of fiscal 2019 to write down the carrying value of the assets held for sale to fair value less any costs to sell. Refer to Note 17, "Impairment of Long-Lived Assets" of the notes to consolidated financial statements for further information regarding the impairment charge. The divestiture of the business held for sale could result in a gain or loss on sale to the extent the ultimate selling price differs from the current carrying value of the net assets recorded. The business did not meet the criteria to be classified as a discontinued operation as the divestiture of the business will not have a major effect on the Company's operations and financial results.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-19-000051:notes:127]
REVENUE RECOGNITION

[0000833444-19-000051:notes:128]
Disaggregated Revenue

[0000833444-19-000051:notes:129]
The following table presents the Company's revenues disaggregated by segment and by products and systems versus services revenue for the year ended September 30, 2019 (in millions):

[0000833444-19-000051:notes:130]
|  |  | Year EndedSeptember 30, 2019 |
|  |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 5,745 |  |  | $ | 3,286 |  |  | $ | 9,031 |  |
| Building Solutions EMEA/LA |  | 1,767 |  |  | 1,888 |  |  | 3,655 |  |
| Building Solutions Asia Pacific |  | 1,575 |  |  | 1,083 |  |  | 2,658 |  |
| Global Products |  | 8,624 |  |  | — |  |  | 8,624 |  |
| Total |  | $ | 17,711 |  |  | $ | 6,257 |  |  | $ | 23,968 |  |

[0000833444-19-000051:notes:131]
The following table presents further disaggregation of Global Products segment revenues by product type for the year ended September 30, 2019 (in millions):

[0000833444-19-000051:notes:132]
|  |  | Year EndedSeptember 30, 2019 |
| Building management systems |  | $ | 1,292 |  |
| HVAC & refrigeration equipment |  | 6,181 |  |
| Specialty products |  | 1,151 |  |
| Total |  | $ | 8,624 |  |

[0000833444-19-000051:notes:133]
Contract Balances

[0000833444-19-000051:notes:134]
Contract assets relate to the Company’s right to consideration for performance obligations satisfied but not billed and consist of unbilled receivables and costs in excess of billings. Contract liabilities relate to customer payments received in advance of satisfaction of performance obligations under the contract. Contract liabilities consist of deferred revenue. Contract balances are classified as assets or liabilities on a contract-by-contract basis at the end of each reporting period.

[0000833444-19-000051:notes:135]
The following table presents the location and amount of contract balances in the Company's consolidated statements of financial position (in millions):

[0000833444-19-000051:notes:136]
|  |  | Location of contract balances |  | September 30, 2019 |  | October 1, 2018 |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,389 |  |  | $ | 1,261 |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 90 |  |  | 85 |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,407 | ) |  | (1,335 | ) |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (117 | ) |  | (113 | ) |
| Total |  |  |  | $ | (45 | ) |  | $ | (102 | ) |

[0000833444-19-000051:notes:137]
For the year ended September 30, 2019, the Company recognized revenue of approximately $1.2 billion that was included in the beginning of period contract liability balance.

[0000833444-19-000051:notes:138]
Performance Obligations

[0000833444-19-000051:notes:139]
A performance obligation is a distinct good, service, or bundle of goods and services promised in a contract. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When contracts with customers require significant and complex integration, contain goods or services which are highly interdependent or interrelated, or are goods or services which significantly modify or customize other promises in the contracts and, therefore, are not distinct, then the entire contract is accounted for as a single performance obligation. For any contracts with multiple performance obligations, the contract’s transaction price is allocated to each performance obligation based on the estimated relative standalone selling price of each distinct good or service in the contract. For product sales, each product sold to a customer typically represents a distinct performance obligation.

[0000833444-19-000051:notes:140]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of September 30, 2019, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $14.4 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

[0000833444-19-000051:notes:141]
Costs to Obtain or Fulfill a Contract

[0000833444-19-000051:notes:142]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when these costs are recoverable. These costs consist primarily of sales commissions and bid/proposal costs. Costs to obtain or fulfill a contract are capitalized and amortized to revenue over the period of contract performance.

[0000833444-19-000051:notes:143]
As of September 30, 2019, the Company recorded the costs to obtain or fulfill a contract of $212 million, of which $110 million is recorded within other current assets and $102 million is recorded within other noncurrent assets in the consolidated statements of financial position.

[0000833444-19-000051:notes:144]
During the year ended September 30, 2019, the Company recognized amortization expense of $157 million related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the year ended September 30, 2019.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-19-000051:notes:145]
INVENTORIES

[0000833444-19-000051:notes:146]
Inventories consisted of the following (in millions):

[0000833444-19-000051:notes:147]
|  | September 30, |
|  | 2019 |  | 2018 |
| Raw materials and supplies | $ | 588 |  |  | $ | 606 |  |
| Work-in-process | 176 |  |  | 155 |  |
| Finished goods | 1,050 |  |  | 1,058 |  |
| Inventories | $ | 1,814 |  |  | $ | 1,819 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000833444-19-000051:notes:148]
PROPERTY, PLANT AND EQUIPMENT

[0000833444-19-000051:notes:149]
Property, plant and equipment consisted of the following (in millions):

[0000833444-19-000051:notes:150]
|  | September 30, |
|  | 2019 |  | 2018 |
| Buildings and improvements | $ | 1,499 |  |  | $ | 1,213 |  |
| Subscriber systems | 661 |  |  | 573 |  |
| Machinery and equipment | 2,969 |  |  | 2,715 |  |
| Construction in progress | 465 |  |  | 704 |  |
| Land | 250 |  |  | 258 |  |
| Total property, plant and equipment | 5,844 |  |  | 5,463 |  |
| Less: accumulated depreciation | (2,496 | ) |  | (2,163 | ) |
| Property, plant and equipment - net | $ | 3,348 |  |  | $ | 3,300 |  |

[0000833444-19-000051:notes:151]
Interest costs capitalized during the fiscal years ended September 30, 2019, 2018 and 2017 were $6 million, $17 million and $14 million, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-19-000051:notes:152]
GOODWILL AND OTHER INTANGIBLE ASSETS

[0000833444-19-000051:notes:153]
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the fiscal years ended September 30, 2019 and 2018 were as follows (in millions):

[0000833444-19-000051:notes:154]
|  | September 30, 2017 |  | BusinessAcquisitions |  | BusinessDivestitures |  | Currency Translation and Other |  | September 30, 2018 |
| Building Solutions North America | $ | 9,637 |  |  | $ | — |  |  | $ | — |  |  | $ | (34 | ) |  | $ | 9,603 |  |
| Building Solutions EMEA/LA | 2,012 |  |  | 1 |  |  | — |  |  | (63 | ) |  | 1,950 |  |
| Building Solutions Asia Pacific | 1,255 |  |  | — |  |  | — |  |  | (20 | ) |  | 1,235 |  |
| Global Products | 5,687 |  |  | 14 |  |  | (35 | ) |  | (73 | ) |  | 5,593 |  |
| Total | $ | 18,591 |  |  | $ | 15 |  |  | $ | (35 | ) |  | $ | (190 | ) |  | $ | 18,381 |  |
|  | September 30, 2018 |  | BusinessAcquisitions |  | BusinessDivestitures |  | Currency Translation and Other |  | September 30, 2019 |
| Building Solutions North America | $ | 9,603 |  |  | $ | — |  |  | $ | — |  |  | $ | (15 | ) |  | $ | 9,588 |  |
| Building Solutions EMEA/LA | 1,950 |  |  | 6 |  |  | (1 | ) |  | (106 | ) |  | 1,849 |  |
| Building Solutions Asia Pacific | 1,235 |  |  | 8 |  |  | — |  |  | (49 | ) |  | 1,194 |  |
| Global Products | 5,593 |  |  | 11 |  |  | (22 | ) |  | (35 | ) |  | 5,547 |  |
| Total | $ | 18,381 |  |  | $ | 25 |  |  | $ | (23 | ) |  | $ | (205 | ) |  | $ | 18,178 |  |

[0000833444-19-000051:notes:155]
The fiscal 2019 Global Products business divestiture amount includes $22 million of goodwill transferred to noncurrent assets held for sale on the consolidated statements of financial position related to plans to dispose of a business within the Global Products segment.

[0000833444-19-000051:notes:156]
At September 30, 2017, accumulated goodwill impairment charges included $47 million related to the Building Solutions EMEA/LA - Latin America reporting unit.

[0000833444-19-000051:notes:157]
There were no goodwill impairments resulting from fiscal 2019 and 2018 annual impairment tests. No reporting unit was determined to be at risk of failing step one of the goodwill impairment test. The Company continuously monitors for events and circumstances that could negatively impact the key assumptions in determining fair value, including long-term revenue growth projections, profitability, discount rates, recent market valuations from transactions by comparable companies, volatility in the Company's market capitalization, and general industry, market and macro-economic conditions. It is possible that future changes in such circumstances, or in the variables associated with the judgments, assumptions and estimates used in assessing the fair value of the reporting unit, would require the Company to record a non-cash impairment charge.

[0000833444-19-000051:notes:158]
The assumptions included in the impairment tests require judgment, and changes to these inputs could impact the results of the calculations. The primary assumptions used in the impairment tests were management's projections of future cash flows. Although the Company's cash flow forecasts are based on assumptions that are considered reasonable by management and consistent with the plans and estimates management is using to operate the underlying businesses, there are significant judgments in determining the expected future cash flows attributable to a reporting unit.

[0000833444-19-000051:notes:159]
The Company’s other intangible assets, primarily from business acquisitions valued based on independent appraisals, consisted of (in millions):

[0000833444-19-000051:notes:160]
|  | September 30, 2019 |  | September 30, 2018 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Amortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,307 |  |  | $ | (370 | ) |  | $ | 937 |  |  | $ | 1,317 |  |  | $ | (251 | ) |  | $ | 1,066 |  |
| Customer relationships | 2,722 |  |  | (759 | ) |  | 1,963 |  |  | 2,941 |  |  | (599 | ) |  | 2,342 |  |
| Miscellaneous | 584 |  |  | (224 | ) |  | 360 |  |  | 458 |  |  | (185 | ) |  | 273 |  |
| Total amortized intangible assets | 4,613 |  |  | (1,353 | ) |  | 3,260 |  |  | 4,716 |  |  | (1,035 | ) |  | 3,681 |  |
| Unamortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/tradenames | 2,282 |  |  | — |  |  | 2,282 |  |  | 2,386 |  |  | — |  |  | 2,386 |  |
| Miscellaneous | 90 |  |  | — |  |  | 90 |  |  | 120 |  |  | — |  |  | 120 |  |
|  | 2,372 |  |  | — |  |  | 2,372 |  |  | 2,506 |  |  | — |  |  | 2,506 |  |
| Total intangible assets | $ | 6,985 |  |  | $ | (1,353 | ) |  | $ | 5,632 |  |  | $ | 7,222 |  |  | $ | (1,035 | ) |  | $ | 6,187 |  |

[0000833444-19-000051:notes:161]
Amortization of other intangible assets included within continuing operations for the fiscal years ended September 30, 2019, 2018 and 2017 was $377 million, $376 million and $481 million, respectively. Excluding the impact of any future acquisitions, the Company anticipates amortization for fiscal 2020, 2021, 2022, 2023 and 2024 will be approximately $390 million, $389 million, $387 million, $374 million and $361 million, respectively. There were no indefinite-lived intangible asset impairments resulting from fiscal 2019, 2018 and 2017 annual impairment tests.


## us-gaap:LeasesOfLesseeDisclosureTextBlock

[0000833444-19-000051:notes:162]
LEASES

[0000833444-19-000051:notes:163]
Certain administrative, production and other facilities and equipment are leased under arrangements that are accounted for as operating leases. Most leases contain renewal options for varying periods, and leases generally require the Company to pay for insurance, taxes and maintenance of the property.

[0000833444-19-000051:notes:164]
Total rental expense for continuing operations for the fiscal years ended September 30, 2019, 2018 and 2017 was $452 million, $408 million and $432 million, respectively.

[0000833444-19-000051:notes:165]
Future minimum operating lease payments at September 30, 2019 were as follows (in millions):

[0000833444-19-000051:notes:166]
|  |  | September 30, 2019 |
| 2020 |  | $ | 352 |  |
| 2021 |  | 287 |  |
| 2022 |  | 200 |  |
| 2023 |  | 111 |  |
| 2024 |  | 71 |  |
| After 2024 |  | 172 |  |
| Total minimum lease payments |  | $ | 1,193 |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-19-000051:notes:167]
DEBT AND FINANCING ARRANGEMENTS

[0000833444-19-000051:notes:168]
Short-term debt consisted of the following (in millions):

[0000833444-19-000051:notes:169]
|  | September 30, |
|  | 2019 |  | 2018 |
| Bank borrowings and commercial paper | $ | 10 |  |  | $ | 1,306 |  |
| Weighted average interest rate on short-term debt outstanding | 2.0 | % |  | 2.8 | % |

[0000833444-19-000051:notes:170]
The Company had no commercial paper outstanding as of September 30, 2019 and $879 million as of September 30, 2018.

[0000833444-19-000051:notes:171]
In June 2019, TSarl, a subsidiary of the Company, terminated its $1.25 billion committed revolving credit facility scheduled to expire in August 2020. In connection with the termination, the Company repaid all of the outstanding obligations in respect of principal, interest and fees under the credit facility. In relation to the termination of the credit facility, TSarl completed all of its obligations under the Term Loan Credit Agreement, dated as of March 10, 2016 (the "Term Facility") by repaying all of the outstanding obligations under the Term Facility, which included $364 million term loan scheduled to mature in March 2020. Other debt held at TSarl was also repaid, including a 364-day $250 million floating rate term loan scheduled to mature in March 2020 and an 18-month 215 million euro floating rate euro term loan scheduled to mature in July 2019. No amounts remain outstanding on the $4.0 billion TSarl merger-related debt as of September 30, 2019.

[0000833444-19-000051:notes:172]
In March 2019, a 364-day $250 million committed revolving credit facility expired. The Company entered into a new $250 million committed revolving credit facility scheduled to expire in March 2020.  As of September 30, 2019 there were no draws on the facility.

[0000833444-19-000051:notes:173]
In February 2019, a 364-day $150 million committed revolving credit facility expired. The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2020.  As of September 30, 2019 there were no draws on the facility.

[0000833444-19-000051:notes:174]
In February 2019, a 364-day $150 million committed revolving credit facility expired.  The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2020. As of September 30, 2019 there were no draws on the facility.

[0000833444-19-000051:notes:175]
In January 2019, the Company entered into a $750 million term loan due the earlier of January 2020 or five business days from the closing on the sale of the Power Solutions business.  Proceeds from the term loan were used for general corporate purposes. Following the sale of the Power Solutions business, the loan was repaid in May 2019.

[0000833444-19-000051:notes:176]
In January 2019, a 364-day $200 million committed revolving credit facility expired. The Company entered into a new $350 million committed revolving credit facility scheduled to expire in January 2020.  Following the sale of the Power Solutions business, the facility was reduced to $200 million. As of September 30, 2019 there were no draws on the facility.

[0000833444-19-000051:notes:177]
Long-term debt consisted of the following (in millions; due dates by fiscal year):

[0000833444-19-000051:notes:178]
|  | September 30, |
|  | 2019 |  | 2018 |
| Unsecured notes |  |  |  |
| JCI plc - 5.00% due in 2020 ($453 million par value) | 453 |  |  | 452 |  |
| JCI Inc. - 5.00% due in 2020 ($47 million par value) | 47 |  |  | 47 |  |
| JCI plc - 0.00% due in 2021 (€750 million par value) | 818 |  |  | 868 |  |
| JCI plc - 4.25% due in 2021 ($204 million par value) | 204 |  |  | 446 |  |
| JCI Inc. - 4.25% due in 2021 ($53 million par value) | 53 |  |  | 53 |  |
| JCI plc - 3.75% due in 2022 ($171 million par value) | 171 |  |  | 427 |  |
| JCI Inc. - 3.75% due in 2022 ($22 million par value) | 22 |  |  | 22 |  |
| JCI plc - 4.625% due in 2023 ($25 million par value) | 26 |  |  | 37 |  |
| Tyco International Finance S.A. ("TIFSA") - 4.625% due in 2023 ($7 million par value) | 7 |  |  | 8 |  |
| JCI plc - 1.00% due in 2023 (€888 million par value) | 967 |  |  | 1,154 |  |
| JCI plc - 3.625% due in 2024 ($453 million par value) | 453 |  |  | 468 |  |
| JCI Inc. - 3.625% due in 2024 ($31 million par value) | 31 |  |  | 31 |  |
| JCI plc - 1.375% due in 2025 (€423 million par value) | 471 |  |  | 501 |  |
| TIFSA - 1.375% due in 2025 (€54 million par value) | 60 |  |  | 69 |  |
| JCI plc - 3.90% due in 2026 ($487 million par value) | 521 |  |  | 755 |  |
| TIFSA - 3.90% due in 2026 ($51 million par value) | 51 |  |  | 52 |  |
| JCI plc - 6.00% due in 2036 ($342 million par value) | 339 |  |  | 388 |  |
| JCI Inc. - 6.00% due in 2036 ($8 million par value) | 8 |  |  | 8 |  |
| JCI plc - 5.70% due in 2041 ($190 million par value) | 189 |  |  | 269 |  |
| JCI Inc. - 5.70% due in 2041 ($30 million par value) | 30 |  |  | 30 |  |
| JCI plc - 5.25% due in 2042 ($155 million par value) | 155 |  |  | 242 |  |
| JCI Inc. - 5.25% due in 2042 ($6 million par value) | 6 |  |  | 8 |  |
| JCI plc - 4.625% due in 2044 ($444 million par value) | 441 |  |  | 441 |  |
| JCI Inc. - 4.625% due in 2044 ($6 million par value) | 6 |  |  | 6 |  |
| JCI plc - 5.125% due in 2045 ($477 million par value) | 567 |  |  | 867 |  |
| TIFSA - 5.125% due in 2045 ($23 million par value) | 22 |  |  | 23 |  |
| JCI plc - 6.95% due in 2046 ($32 million par value) | 32 |  |  | 121 |  |
| JCI Inc. - 6.95% due in 2046 ($4 million par value) | 4 |  |  | 4 |  |
| JCI plc - 4.50% due in 2047 ($500 million par value) | 496 |  |  | 496 |  |
| JCI plc - 4.95% due in 2064 ($341 million par value) | 340 |  |  | 434 |  |
| JCI Inc. - 4.95% due in 2064 ($15 million par value) | 15 |  |  | 15 |  |
| TSarl - Term Loan A - LIBOR plus 1.25% due in 2020 | — |  |  | 364 |  |
| TSarl - Term Loan B - €215 million; EURIBOR plus 0.62% due in 2020 | — |  |  | 250 |  |
| JCI plc - Term Loan - 25 billion yen; LIBOR JPY plus 0.40% due in 2022 | 232 |  |  | 309 |  |
| Other | 3 |  |  | 3 |  |
| Gross long-term debt | 7,240 |  |  | 9,668 |  |
| Less: current portion | 501 |  |  | 1 |  |
| Less: debt issuance costs | 31 |  |  | 44 |  |
| Net long-term debt | $ | 6,708 |  |  | $ | 9,623 |  |

[0000833444-19-000051:notes:179]
The installments of long-term debt maturing in subsequent fiscal years are: 2020 - $501 million; 2021 - $1,075 million; 2022 - $425 million; 2023 - $1,001 million; 2024 - $485 million; 2025 and thereafter - $3,753 million. The Company’s long-term debt includes various financial covenants, none of which are expected to restrict future operations.

[0000833444-19-000051:notes:180]
Total interest paid on both short and long-term debt for continuing operations for the fiscal years ended September 30, 2019, 2018 and 2017 was $369 million, $401 million and $432 million, respectively.

[0000833444-19-000051:notes:181]
Financing Arrangements

[0000833444-19-000051:notes:182]
In June 2019, the Company repurchased at par, $2.5 million of its 5.25% fixed rate notes, plus accrued interest, scheduled to mature in 2041.

[0000833444-19-000051:notes:183]
In May 2019, the Company completed the debt tender offer to purchase up to $1.5 billion in aggregate principal amount of certain of its outstanding notes for $1.6 billion total consideration. The Company recognized a loss on the extinguishment of debt of $60 million, which was recorded within net financing charges in the consolidated statements of income.

[0000833444-19-000051:notes:184]
In May 2019, the Company repaid 10 billion yen of the 35 billion yen five-year syndicated floating rate term loan, plus accrued interest, scheduled to mature in September 2022.

[0000833444-19-000051:notes:185]
In April 2019, the Company repurchased at a discount, 4.7 million euro of its 1.375% fixed rate euro notes, plus accrued interest, scheduled to mature in 2025.

[0000833444-19-000051:notes:186]
In February 2019, the Company repurchased at a discount, $12 million of its 3.9% fixed rate notes, plus accrued interest, scheduled to mature in 2026.

[0000833444-19-000051:notes:187]
Net Financing Charges

[0000833444-19-000051:notes:188]
The Company's net financing charges line item in the consolidated statements of income for the years ended September 30, 2019, 2018 and 2017 contained the following components (in millions):

[0000833444-19-000051:notes:189]
|  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Interest expense, net of capitalized interest costs | $ | 335 |  |  | $ | 409 |  |  | $ | 446 |  |
| Banking fees and bond cost amortization | 28 |  |  | 30 |  |  | 49 |  |
| Loss on debt extinguishment | 60 |  |  | — |  |  | — |  |
| Interest income | (61 | ) |  | (13 | ) |  | (11 | ) |
| Net foreign exchange results for financing activities | (12 | ) |  | (25 | ) |  | (18 | ) |
| Net financing charges | $ | 350 |  |  | $ | 401 |  |  | $ | 466 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-19-000051:notes:190]
DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES

[0000833444-19-000051:notes:191]
The Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities, stock-based compensation liabilities and interest rates. Under Company policy, the use of derivatives is restricted to those intended for hedging purposes; the use of any derivative instrument for speculative purposes is strictly prohibited. A description of each type of derivative utilized by the Company to manage risk is included in the following paragraphs. In addition, refer to Note 11, "Fair Value Measurements," of the notes to consolidated financial statements for information related to the fair value measurements and valuation methods utilized by the Company for each derivative type.

[0000833444-19-000051:notes:192]
Cash Flow Hedges

[0000833444-19-000051:notes:193]
The Company has global operations and participates in the foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange hedge contracts. The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates at September 30, 2019 and 2018.

[0000833444-19-000051:notes:194]
The Company selectively hedges anticipated transactions that are subject to commodity price risk, primarily using commodity hedge contracts, to minimize overall price risk associated with the Company’s purchases of copper and aluminum in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Prior to the divestiture of Power Solutions, the Company also used commodity hedge contracts to minimize risk associated with purchases of lead, polypropylene and tin. Commodity risks are systematically managed pursuant to policy guidelines. As cash flow hedges, hedge

[0000833444-19-000051:notes:195]
gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in commodity prices at September 30, 2019 and 2018.

[0000833444-19-000051:notes:196]
The Company had the following outstanding contracts to hedge forecasted commodity purchases for continuing and discontinued operations (in metric tons):

[0000833444-19-000051:notes:197]
|  |  | Volume Outstanding as of |
| Commodity |  | September 30, 2019 |  | September 30, 2018 |
| Copper |  | 3,561 |  |  | 3,175 |  |
| Aluminum |  | 2,967 |  |  | 3,381 |  |
| Lead |  | — |  |  | 49,066 |  |
| Polypropylene |  | — |  |  | 15,868 |  |
| Tin |  | — |  |  | 3,076 |  |

[0000833444-19-000051:notes:198]
Net Investment Hedges

[0000833444-19-000051:notes:199]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company’s net investments globally. At September 30, 2019, the Company had 888 million euro, 750 million euro, 423 million euro and 54 million euro in bonds designated as net investment hedges in the Company's net investment in Europe and 25 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan. At September 30, 2018, the Company had one billion euro, 750 million euro, 423 million euro and 58 million euro in bonds and a 215 million euro term loan designated as net investment hedges in the Company's net investment in Europe and 35 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan.

[0000833444-19-000051:notes:200]
Derivatives Not Designated as Hedging Instruments

[0000833444-19-000051:notes:201]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount. As of September 30, 2019, the Company hedged approximately 1.4 million of its ordinary shares, which have a cost basis of $60 million. As of September 30, 2018 the Company hedged approximately 1.8 million of its ordinary shares, which have a cost basis of $73 million.

[0000833444-19-000051:notes:202]
The Company also holds certain foreign currency forward contracts which do not qualify for hedge accounting treatment. The change in fair value of foreign currency exchange derivatives not designated as hedging instruments under ASC 815 are recorded in the consolidated statements of income.

[0000833444-19-000051:notes:203]
Fair Value of Derivative Instruments

[0000833444-19-000051:notes:204]
The following table presents the location and fair values of derivative instruments and hedging activities included in the Company’s consolidated statements of financial position (in millions):

[0000833444-19-000051:notes:205]
|  | Derivatives and Hedging ActivitiesDesignated as Hedging Instrumentsunder ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instrumentsunder ASC 815 |
|  | September 30, 2019 |  | September 30, 2018 |  | September 30, 2019 |  | September 30, 2018 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 16 |  |  | $ | 6 |  |  | $ | 19 |  |  | $ | 10 |  |
| Commodity derivatives | — |  |  | 1 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Equity swap | — |  |  | — |  |  | 62 |  |  | 63 |  |
| Total assets | $ | 16 |  |  | $ | 7 |  |  | $ | 81 |  |  | $ | 73 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 23 |  |  | $ | 10 |  |  | $ | — |  |  | $ | 2 |  |
| Commodity derivatives | 1 |  |  | 2 |  |  | — |  |  | — |  |
| Liability held for sale |  |  |  |  |  |  |  |
| Commodity derivatives | — |  |  | 12 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 2,544 |  |  | 3,149 |  |  | — |  |  | — |  |
| Total liabilities | $ | 2,568 |  |  | $ | 3,173 |  |  | $ | — |  |  | $ | 2 |  |

[0000833444-19-000051:notes:206]
Counterparty Credit Risk

[0000833444-19-000051:notes:207]
The use of derivative financial instruments exposes the Company to counterparty credit risk. The Company has established policies and procedures to limit the potential for counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association ("ISDA") master netting agreements with substantially all of its counterparties. The Company's derivative contracts do not contain any credit risk related contingent features and do not require collateral or other security to be furnished by the Company or the counterparties. The Company's exposure to credit risk associated with its derivative instruments is measured on an individual counterparty basis, as well as by groups of counterparties that share similar attributes. The Company does not anticipate any non-performance by any of its counterparties, and the concentration of risk with financial institutions does not present significant credit risk to the Company.

[0000833444-19-000051:notes:208]
The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position. Collateral is generally not required of the Company or the counterparties under the master netting agreements. As of September 30, 2019 and 2018, no cash collateral was received or pledged under the master netting agreements.

[0000833444-19-000051:notes:209]
The gross and net amounts of derivative assets and liabilities were as follows (in millions):

[0000833444-19-000051:notes:210]
|  | Fair Value of Assets |  | Fair Value of Liabilities |
|  | September 30, 2019 |  | September 30, 2018 |  | September 30, 2019 |  | September 30, 2018 |  |
| Gross amount recognized | $ | 97 |  |  | $ | 80 |  |  | $ | 2,568 |  |  | $ | 3,175 |  |  |
| Gross amount eligible for offsetting | (11 | ) |  | (12 | ) |  | (11 | ) |  | (12 | ) |  |
| Net amount | $ | 86 |  |  | $ | 68 |  |  | $ | 2,557 |  |  | $ | 3,163 |  |  |

[0000833444-19-000051:notes:211]
Derivatives Impact on the Statements of Income and Statements of Comprehensive Income

[0000833444-19-000051:notes:212]
The following table presents the pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges for the fiscal years ended September 30, 2019, 2018 and 2017 (in millions):

[0000833444-19-000051:notes:213]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Foreign currency exchange derivatives |  | $ | 2 |  |  | $ | 2 |  |  | $ | (1 | ) |
| Commodity derivatives |  | (4 | ) |  | (14 | ) |  | 14 |  |
| Total |  | $ | (2 | ) |  | $ | (12 | ) |  | $ | 13 |  |

[0000833444-19-000051:notes:214]
The following table presents the location and amount of the pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income for the fiscal years ended September 30, 2019, 2018 and 2017 (in millions):

[0000833444-19-000051:notes:215]
| Derivatives in ASC 815 Cash FlowHedging Relationships |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Year Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 4 |  |  | $ | 2 |  |  | $ | (1 | ) |
| Foreign currency exchange derivatives |  | Income from discontinued operations |  | — |  |  | 2 |  |  | 26 |  |
| Commodity derivatives |  | Cost of sales |  | (4 | ) |  | 5 |  |  | 4 |  |
| Commodity derivatives |  | Income from discontinued operations |  | (10 | ) |  | 7 |  |  | 4 |  |
| Total |  |  |  | $ | (10 | ) |  | $ | 16 |  |  | $ | 33 |  |

[0000833444-19-000051:notes:216]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income for the fiscal years ended September 30, 2019, 2018 and 2017 (in millions):

[0000833444-19-000051:notes:217]
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Year Ended September 30, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (8 | ) |  | $ | 4 |  |  | $ | (1 | ) |
| Foreign currency exchange derivatives |  | Net financing charges |  | (60 | ) |  | 42 |  |  | 48 |  |
| Foreign currency exchange derivatives |  | Income tax provision |  | (1 | ) |  | (4 | ) |  | (1 | ) |
| Foreign currency exchange derivatives |  | Income from discontinued operations |  | 52 |  |  | (7 | ) |  | (1 | ) |
| Equity swap |  | Selling, general and administrative |  | 14 |  |  | (8 | ) |  | (3 | ) |
| Total |  |  |  | $ | (3 | ) |  | $ | 27 |  |  | $ | 42 |  |

[0000833444-19-000051:notes:218]
The pre-tax gains (losses) recorded in foreign currency translation adjustment ("CTA") within other comprehensive income (loss) related to net investment hedges were $145 million, $45 million and $(138) million for the years ended September 30, 2019, 2018 and 2017, respectively. For the years ended September 30, 2019, 2018 and 2017, no gains or losses were reclassified from CTA into income for the Company’s outstanding net investment hedges.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-19-000051:notes:219]
FAIR VALUE MEASUREMENTS

[0000833444-19-000051:notes:220]
ASC 820, "Fair Value Measurement," defines fair value as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. ASC 820 also establishes a three-level fair value hierarchy that prioritizes information used in developing assumptions when pricing an asset or liability as follows:

[0000833444-19-000051:notes:221]
Level 1: Observable inputs such as quoted prices in active markets for identical assets or liabilities;

[0000833444-19-000051:notes:222]
Level 2: Quoted prices in active markets for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active, or inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and

[0000833444-19-000051:notes:223]
Level 3: Unobservable inputs where there is little or no market data, which requires the reporting entity to develop its own assumptions.

[0000833444-19-000051:notes:224]
ASC 820 requires the use of observable market data, when available, in making fair value measurements. When inputs used to measure fair value fall within different levels of the hierarchy, the level within which the fair value measurement is categorized is based on the lowest level input that is significant to the fair value measurement.

[0000833444-19-000051:notes:225]
Recurring Fair Value Measurements

[0000833444-19-000051:notes:226]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value as of September 30, 2019 and 2018 (in millions):

[0000833444-19-000051:notes:227]
|  | Fair Value Measurements Using: |
|  | Total as ofSeptember 30, 2019 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 35 |  |  | $ | — |  |  | $ | 35 |  |  | $ | — |  |
| Exchange traded funds (fixed income)1 | 19 |  |  | 19 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 71 |  |  | 71 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 138 |  |  | 138 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 116 |  |  | 116 |  |  | — |  |  | — |  |
| Equity swap | 62 |  |  | — |  |  | 62 |  |  | — |  |
| Total assets | $ | 441 |  |  | $ | 344 |  |  | $ | 97 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Total liabilities | $ | 24 |  |  | $ | — |  |  | $ | 24 |  |  | $ | — |  |

[0000833444-19-000051:notes:228]
|  | Fair Value Measurements Using: |
|  | Total as ofSeptember 30, 2018 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 16 |  |  | $ | — |  |  | $ | 16 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Exchange traded funds (fixed income)1 | 14 |  |  | 14 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 100 |  |  | 100 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 148 |  |  | 148 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 119 |  |  | 119 |  |  | — |  |  | — |  |
| Equity swap | 63 |  |  | — |  |  | 63 |  |  | — |  |
| Noncurrent assets held for sale |  |  |  |  |  |  |  |
| Investments in marketable common stock | 3 |  |  | 3 |  |  | — |  |  | — |  |
| Total assets | $ | 464 |  |  | $ | 384 |  |  | $ | 80 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 12 |  |  | $ | — |  |  | $ | 12 |  |  | $ | — |  |
| Commodity derivatives | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Liabilities held for sale |  |  |  |  |  |  |  |
| Commodity derivatives | 12 |  |  | — |  |  | 12 |  |  | — |  |
| Total liabilities | $ | 26 |  |  | $ | — |  |  | $ | 26 |  |  | $ | — |  |

[0000833444-19-000051:notes:229]
1Classified as restricted investments for payment of asbestos liabilities. See Note 22, "Commitments and Contingencies" of the notes to consolidated financial statements for further details.

[0000833444-19-000051:notes:230]
Valuation Methods

[0000833444-19-000051:notes:231]
Foreign currency exchange derivatives: The foreign currency exchange derivatives are valued under a market approach using publicized spot and forward prices.

[0000833444-19-000051:notes:232]
Commodity derivatives: The commodity derivatives are valued under a market approach using publicized prices, where available, or dealer quotes.

[0000833444-19-000051:notes:233]
Equity swaps: The equity swaps are valued under a market approach as the fair value of the swaps is equal to the Company’s stock price at the reporting period date.

[0000833444-19-000051:notes:234]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices.

[0000833444-19-000051:notes:235]
Exchange traded funds: Exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. During the fiscal year ended September 30, 2019, the Company recognized unrealized gains of $12 million in the consolidated statements of income on these investments that were still held as of September 30, 2019, all of which related to restricted investments. Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements for further information.

[0000833444-19-000051:notes:236]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. The fair value of long-term debt was $7.6 billion and $9.6 billion at September 30, 2019 and 2018, respectively. The fair value of public debt was $7.4 billion and $8.6 billion at September 30, 2019 and 2018, respectively, which was determined primarily using market quotes classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt

[0000833444-19-000051:notes:237]
was $0.2 billion and $1.0 billion at September 30, 2019 and 2018 respectively, which was determined based on quoted market prices for similar instruments classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-19-000051:notes:238]
STOCK-BASED COMPENSATION

[0000833444-19-000051:notes:239]
On September 2, 2016, the shareholders of the Company approved amendments to the Johnson Controls International plc 2012 Share and Incentive Plan (the "Plan"). The types of awards authorized by the Plan comprise of stock options, stock appreciation rights, performance shares, performance units and other stock-based awards. The Compensation Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. The Plan provides that 76 million shares of the Company's common stock are reserved for issuance under the 2012 Plan, and 34 million shares remain available for issuance at September 30, 2019.

[0000833444-19-000051:notes:240]
The Company has four share-based compensation plans, which are described below. For the fiscal years ended September 30, 2019, 2018 and 2017, compensation cost charged against income for continuing operations, excluding the offsetting impact of outstanding equity swaps, for those plans was approximately $103 million, $89 million and $122 million, respectively, all of which was recorded in selling, general and administrative expenses.

[0000833444-19-000051:notes:241]
The Company has elected to utilize the alternative transition method for calculating the tax effects of stock-based compensation.  The total income tax benefit recognized for continuing operations in the consolidated statements of income for share-based compensation arrangements was approximately $26 million, $22 million and $48 million for the fiscal years ended September 30, 2019, 2018 and 2017, respectively.  The tax expense from the exercise and vesting of equity settled awards was $6 million and $3 million for the fiscal years ended September 30, 2019 and 2018, respectively, and recorded as part of the income tax provision upon adoption of ASU 2016-09 during the first quarter of fiscal 2018. The tax benefit from the exercise and vesting of equity settled awards was $4 million for the fiscal year ended September 30, 2017, and was recorded in capital in excess of par value.  The Company does not settle stock options granted under share-based payment arrangements to cash.

[0000833444-19-000051:notes:242]
Stock Options

[0000833444-19-000051:notes:243]
Stock options are granted with an exercise price equal to the market price of the Company’s stock at the date of grant. Stock option awards typically vest between two and three years after the grant date and expire ten years from the grant date.

[0000833444-19-000051:notes:244]
The fair value of each option is estimated on the date of grant using a Black-Scholes option valuation model that uses the assumptions noted in the following table. The expected life of options represents the period of time that options granted are expected to be outstanding, assessed separately for executives and non-executives. The risk-free interest rate for periods during the contractual life of the option is based on the U.S. Treasury yield curve in effect at the time of grant. For fiscal 2019 and 2018, the expected volatility is based on the historical volatility of the Company's stock since October 2016 blended with the historical volatility of certain peer companies' stock prior to October 2016 over the most recent period corresponding to the expected life as of the grant date. For fiscal 2017, the expected volatility is based on historical volatility of certain peer companies over the most recent period corresponding to the expected life as of the grant date. The expected dividend yield is based on the expected annual dividend as a percentage of the market value of the Company’s ordinary shares as of the grant date. The Company uses historical data to estimate option exercises and employee terminations within the valuation model.

[0000833444-19-000051:notes:245]
|  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Expected life of option (years) | 6.4 |  | 6.5 |  | 4.75 & 6.5 |
| Risk-free interest rate | 2.77% |  | 2.28% |  | 1.23% - 1.93% |
| Expected volatility of the Company’s stock | 21.80% |  | 23.70% |  | 24.60% |
| Expected dividend yield on the Company’s stock | 3.29% |  | 2.78% |  | 2.21% |

[0000833444-19-000051:notes:246]
A summary of stock option activity at September 30, 2019, and changes for the year then ended, is presented below:

[0000833444-19-000051:notes:247]
|  | WeightedAverageOption Price |  | SharesSubject toOption |  | WeightedAverageRemainingContractualLife (years) |  | AggregateIntrinsicValue(in millions) |
| Outstanding, September 30, 2018 | $ | 34.24 |  |  | 17,836,062 |  |  |  |  |  |
| Granted | 33.37 |  |  | 1,741,510 |  |  |  |  |  |
| Exercised | 27.54 |  |  | (6,234,755 | ) |  |  |  |  |
| Forfeited or expired | 37.49 |  |  | (973,068 | ) |  |  |  |  |
| Outstanding, September 30, 2019 | $ | 35.07 |  |  | 12,369,749 |  |  | 4.6 |  | $ | 111 |  |
| Exercisable, September 30, 2019 | $ | 34.74 |  |  | 9,295,813 |  |  | 3.4 |  | $ | 87 |  |

[0000833444-19-000051:notes:248]
The weighted-average grant-date fair value of options granted during the fiscal years ended September 30, 2019, 2018 and 2017 was $5.56, $7.04 and $7.81, respectively.

[0000833444-19-000051:notes:249]
The total intrinsic value of options exercised during the fiscal years ended September 30, 2019, 2018 and 2017 was approximately $73 million, $38 million and $81 million, respectively.

[0000833444-19-000051:notes:250]
In conjunction with the exercise of stock options granted, the Company received cash payments for the fiscal years ended September 30, 2019, 2018 and 2017 of approximately $171 million, $66 million and $157 million, respectively.

[0000833444-19-000051:notes:251]
At September 30, 2019, the Company had approximately $8 million of total unrecognized compensation cost related to nonvested stock options granted for continuing operations. That cost is expected to be recognized over a weighted-average period of 1.8 years.

[0000833444-19-000051:notes:252]
Stock Appreciation Rights ("SARs")

[0000833444-19-000051:notes:253]
SARs vest under the same terms and conditions as stock option awards; however, they are settled in cash for the difference between the market price on the date of exercise and the exercise price. As a result, SARs are recorded in the Company’s consolidated statements of financial position as a liability until the date of exercise.

[0000833444-19-000051:notes:254]
The fair value of each SAR award is estimated using a similar method described for stock options. The fair value of each SAR award is recalculated at the end of each reporting period and the liability and expense are adjusted based on the new fair value.

[0000833444-19-000051:notes:255]
The assumptions used to determine the fair value of the SAR awards at September 30, 2019 were as follows:

[0000833444-19-000051:notes:256]
| Expected life of SAR (years) | 0.4 - 3.5 |
| Risk-free interest rate | 1.55% - 1.85% |
| Expected volatility of the Company’s stock | 21.80% |
| Expected dividend yield on the Company’s stock | 3.29% |

[0000833444-19-000051:notes:257]
A summary of SAR activity at September 30, 2019, and changes for the year then ended, is presented below:

[0000833444-19-000051:notes:258]
|  | WeightedAverageSAR Price |  | SharesSubject toSAR |  | WeightedAverageRemainingContractualLife (years) |  | AggregateIntrinsicValue(in millions) |
| Outstanding, September 30, 2018 | $ | 27.39 |  |  | 626,701 |  |  |  |  |  |
| Exercised | 25.20 |  |  | (245,513 | ) |  |  |  |  |
| Forfeited or expired | 32.43 |  |  | (13,179 | ) |  |  |  |  |
| Outstanding, September 30, 2019 | $ | 28.67 |  |  | 368,009 |  |  | 2.4 |  | $ | 6 |  |
| Exercisable, September 30, 2019 | $ | 28.59 |  |  | 365,829 |  |  | 2.4 |  | $ | 6 |  |

[0000833444-19-000051:notes:259]
In conjunction with the exercise of SARs granted, the Company made payments of $3 million, $3 million and $4 million during the fiscal years ended September 30, 2019, 2018 and 2017, respectively.

[0000833444-19-000051:notes:260]
Restricted (Nonvested) Stock / Units

[0000833444-19-000051:notes:261]
The Plan provides for the award of restricted stock or restricted stock units to certain employees. These awards are typically share settled unless the employee is a non-U.S. employee or elects to defer settlement until retirement at which point the award would be settled in cash. Restricted awards typically vest over a period of three years from the grant date. The Plan allows for different vesting terms on specific grants with approval by the Board of Directors. The fair value of each share-settled restricted award is based on the closing market value of the Company’s ordinary shares on the date of grant. The fair value of each cash-settled restricted award is recalculated at the end of each reporting period based on the closing market value of the Company's ordinary shares at the end of the reporting period, and the liability and expense are adjusted based on the new fair value.

[0000833444-19-000051:notes:262]
A summary of the status of the Company’s nonvested restricted stock awards at September 30, 2019, and changes for the fiscal year then ended, is presented below:

[0000833444-19-000051:notes:263]
|  | WeightedAveragePrice |  | Shares/UnitsSubject toRestriction |
| Nonvested, September 30, 2018 | $ | 45.14 |  |  | 5,001,517 |  |
| Granted | 33.88 |  |  | 2,384,747 |  |
| Vested | 41.23 |  |  | (3,139,142 | ) |
| Forfeited | 37.83 |  |  | (914,046 | ) |
| Nonvested, September 30, 2019 | $ | 35.98 |  |  | 3,333,076 |  |

[0000833444-19-000051:notes:264]
At September 30, 2019, the Company had approximately $72 million of total unrecognized compensation cost related to nonvested restricted stock arrangements granted for continuing operations. That cost is expected to be recognized over a weighted-average period of 2.1 years.

[0000833444-19-000051:notes:265]
Performance Share Awards

[0000833444-19-000051:notes:266]
The Plan permits the grant of performance-based share unit ("PSU") awards. The PSUs are generally contingent on the achievement of pre-determined performance goals over a performance period of three years as well as on the award holder's continuous employment until the vesting date. The PSUs are also indexed to the achievement of specified levels of total shareholder return versus a peer group over the performance period. Each PSU that is earned will be settled with shares of the Company's ordinary shares following the completion of the performance period, unless the award holder elected to defer a portion or all of the award until retirement which would then be settled in cash.

[0000833444-19-000051:notes:267]
The fair value of each PSU is estimated on the date of grant with the use of a Monte Carlo simulation that uses the assumptions noted in the following table. The risk-free interest rate for periods during the contractual life of the PSU is based on the U.S. Treasury yield curve in effect at the time of grant. For fiscal 2019, 2018 and 2017, the expected volatility is based on the historical volatility of the Company's stock since October 2016 blended with the historical volatility of certain peer companies' stock prior to October 2016 over the most recent three-year period as of the grant date.

[0000833444-19-000051:notes:268]
|  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Risk-free interest rate | 2.76% |  | 1.92% |  | 1.40% |
| Expected volatility of the Company’s stock | 22.90% |  | 21.70% |  | 21.00% |

[0000833444-19-000051:notes:269]
A summary of the status of the Company’s nonvested PSUs at September 30, 2019, and changes for the fiscal year then ended, is presented below:

[0000833444-19-000051:notes:270]
|  | WeightedAveragePrice |  | Shares/UnitsSubject toPSU |
| Nonvested, September 30, 2018 | $ | 41.07 |  |  | 1,412,290 |  |
| Granted | 36.28 |  |  | 595,594 |  |
| Forfeited | 37.89 |  |  | (182,365 | ) |
| Nonvested, September 30, 2019 | $ | 39.82 |  |  | 1,825,519 |  |

[0000833444-19-000051:notes:271]
At September 30, 2019, the Company had approximately $31 million of total unrecognized compensation cost related to nonvested performance-based share unit awards granted for continuing operations. That cost is expected to be recognized over a weighted-average period of 1.8 years.


## us-gaap:EarningsPerShareTextBlock

[0000833444-19-000051:notes:272]
EARNINGS PER SHARE

[0000833444-19-000051:notes:273]
The Company presents both basic and diluted EPS amounts. Basic EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares outstanding during the reporting period. Diluted EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares and ordinary equivalent shares outstanding during the reporting period that are calculated using the treasury stock method for stock options, unvested restricted stock and unvested performance share awards. The treasury stock method assumes that the Company uses the proceeds from the exercise of stock option awards to repurchase ordinary shares at the average market price during the period. The assumed proceeds under the treasury stock method include the purchase price that the grantee will pay in the future and compensation cost for future service that the Company has not yet recognized.  For unvested restricted stock and unvested performance share awards, assumed proceeds under the treasury stock method would include unamortized compensation cost.

[0000833444-19-000051:notes:274]
The following table reconciles the numerators and denominators used to calculate basic and diluted earnings per share (in millions):

[0000833444-19-000051:notes:275]
|  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Income Available to Ordinary Shareholders |  |  |  |  |  |
| Income from continuing operations | $ | 1,100 |  |  | $ | 1,175 |  |  | $ | 672 |  |
| Income from discontinued operations | 4,574 |  |  | 987 |  |  | 939 |  |
| Basic and diluted income available to shareholders | $ | 5,674 |  |  | $ | 2,162 |  |  | $ | 1,611 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |
| Basic weighted average shares outstanding | 870.2 |  |  | 925.7 |  |  | 935.3 |  |
| Effect of dilutive securities: |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 4.1 |  |  | 6.0 |  |  | 9.3 |  |
| Diluted weighted average shares outstanding | 874.3 |  |  | 931.7 |  |  | 944.6 |  |
| Antidilutive Securities |  |  |  |  |  |
| Options to purchase shares | 1.4 |  |  | 1.5 |  |  | 0.2 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-19-000051:notes:276]
EQUITY AND NONCONTROLLING INTERESTS

[0000833444-19-000051:notes:277]
Dividends

[0000833444-19-000051:notes:278]
The authority to declare and pay dividends is vested in the Board of Directors. The timing, declaration and payment of future dividends to holders of the Company's ordinary shares is determined by the Company's Board of Directors and depends upon many factors, including the Company's financial condition and results of operations, the capital requirements of the Company's businesses, industry practice and any other relevant factors.

[0000833444-19-000051:notes:279]
Under Irish law, dividends may only be paid (and share repurchases and redemptions must generally be funded) out of "distributable reserves." The creation of distributable reserves was accomplished by way of a capital reduction, which the Irish High Court approved on December 18, 2014 and as acquired in conjunction with the Merger.

[0000833444-19-000051:notes:280]
Share Repurchase Program

[0000833444-19-000051:notes:281]
In November 2018, the Company's Board of Directors approved a $1 billion increase to its existing share repurchase authorization. In March 2019, the Company's Board of Directors approved an additional $8.5 billion increase to its existing share repurchase authorization, subject to the completion of the previously announced sale of the Company's Power Solutions business, which closed on April 30, 2019. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice.

[0000833444-19-000051:notes:282]
On May 1, 2019, the Company announced a "modified Dutch auction" tender offer for up to $4.0 billion of its ordinary shares with a price range between $36.00 and $40.00 per share. The tender offer expired on May 31, 2019. Through the tender offer, the Company accepted for payment 102 million shares at a purchase price of $39.25 per share, for a total of approximately $4,035 million, including fees and commissions. The shares purchased through the tender offer were immediately retired. Ordinary shares were reduced by the number of shares retired at $0.01 par value per share. The excess purchase price over par value was recorded in retained earnings in the consolidated statements of financial position.

[0000833444-19-000051:notes:283]
In addition to the equity tender offer described above, during fiscal year 2019, the Company repurchased and retired approximately $1,948 million of its ordinary shares. As of September 30, 2019, approximately $4.6 billion remains available under the share repurchase program. During fiscal years 2018 and 2017, the Company repurchased approximately $300 million and $651 million of its ordinary shares, respectively.

[0000833444-19-000051:notes:284]
Other comprehensive income includes activity relating to discontinued operations. The following schedules present changes in consolidated equity attributable to Johnson Controls and noncontrolling interests (in millions, net of tax):

[0000833444-19-000051:notes:285]
|  | Equity Attributable to Johnson ControlsInternational plc |  | Equity Attributable to Noncontrolling Interests |  | Total Equity |
| At September 30, 2016 | $ | 24,118 |  |  | $ | 972 |  |  | $ | 25,090 |  |
| Total comprehensive income (loss): |  |  |  |  |  |
| Net income | 1,611 |  |  | 164 |  |  | 1,775 |  |
| Foreign currency translation adjustments | 108 |  |  | (18 | ) |  | 90 |  |
| Realized and unrealized gains (losses) on derivatives | (14 | ) |  | 1 |  |  | (13 | ) |
| Realized and unrealized gains on marketable securities | 5 |  |  | — |  |  | 5 |  |
| Other comprehensive income (loss) | 99 |  |  | (17 | ) |  | 82 |  |
| Comprehensive income | 1,710 |  |  | 147 |  |  | 1,857 |  |
| Other changes in equity: |  |  |  |  |  |
| Cash dividends - ordinary shares ($1.00 per share) | (938 | ) |  | — |  |  | (938 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (56 | ) |  | (56 | ) |
| Repurchases of ordinary shares | (651 | ) |  | — |  |  | (651 | ) |
| Change in noncontrolling interest share | — |  |  | (5 | ) |  | (5 | ) |
| Spin-off of Adient | (4,038 | ) |  | (138 | ) |  | (4,176 | ) |
| Other, including options exercised | 246 |  |  | — |  |  | 246 |  |
| At September 30, 2017 | 20,447 |  |  | 920 |  |  | 21,367 |  |
| Total comprehensive income (loss): |  |  |  |  |  |
| Net income | 2,162 |  |  | 186 |  |  | 2,348 |  |
| Foreign currency translation adjustments | (458 | ) |  | (22 | ) |  | (480 | ) |
| Realized and unrealized losses on derivatives | (19 | ) |  | (1 | ) |  | (20 | ) |
| Realized and unrealized gains on marketable securities | 4 |  |  | — |  |  | 4 |  |
| Other comprehensive loss | (473 | ) |  | (23 | ) |  | (496 | ) |
| Comprehensive income | 1,689 |  |  | 163 |  |  | 1,852 |  |
| Other changes in equity: |  |  |  |  |  |
| Cash dividends - ordinary shares ($1.04 per share) | (968 | ) |  | — |  |  | (968 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (43 | ) |  | (43 | ) |
| Repurchases of ordinary shares | (300 | ) |  | — |  |  | (300 | ) |
| Change in noncontrolling interest share | — |  |  | 23 |  |  | 23 |  |
| Adoption of ASU 2016-09 | 179 |  |  | — |  |  | 179 |  |
| Reclassification from redeemable noncontrolling interest | — |  |  | 231 |  |  | 231 |  |
| Other, including options exercised | 117 |  |  | — |  |  | 117 |  |
| At September 30, 2018 | 21,164 |  |  | 1,294 |  |  | 22,458 |  |
| Total comprehensive income (loss): |  |  |  |  |  |
| Net income | 5,674 |  |  | 213 |  |  | 5,887 |  |
| Foreign currency translation adjustments | (325 | ) |  | (17 | ) |  | (342 | ) |
| Realized and unrealized gains (losses) on derivatives | 7 |  |  | (1 | ) |  | 6 |  |
| Pension and postretirement plans | (6 | ) |  | — |  |  | (6 | ) |
| Other comprehensive loss | (324 | ) |  | (18 | ) |  | (342 | ) |
| Comprehensive income | 5,350 |  |  | 195 |  |  | 5,545 |  |
| Other changes in equity: |  |  |  |  |  |
| Cash dividends - ordinary shares ($1.04 per share) | (887 | ) |  | — |  |  | (887 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (132 | ) |  | (132 | ) |
| Repurchases and retirements of ordinary shares | (5,983 | ) |  | — |  |  | (5,983 | ) |
| Divestiture of Power Solutions | 483 |  |  | (295 | ) |  | 188 |  |
| Adoption of ASC 606 | (45 | ) |  | — |  |  | (45 | ) |
| Adoption of ASU 2016-16 | (546 | ) |  | — |  |  | (546 | ) |
| Other, including options exercised | 230 |  |  | 1 |  |  | 231 |  |
| At September 30, 2019 | $ | 19,766 |  |  | $ | 1,063 |  |  | $ | 20,829 |  |

[0000833444-19-000051:notes:286]
As previously disclosed, during the quarter ended December 31, 2018, the Company adopted ASC 606, "Revenue from Contracts with Customers." As a result, the Company recorded $45 million to beginning retained earnings, which relates primarily to deferred

[0000833444-19-000051:notes:287]
revenue recorded for the Power Solutions business for certain battery core returns that represent a material right provided to customers.

[0000833444-19-000051:notes:288]
As previously disclosed, during the quarter ended December 31, 2018, the Company adopted ASU 2016-16, "Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other Than Inventory." As a result, the Company recognized deferred taxes of $546 million related to the tax effects of all intra-entity sales of assets other than inventory on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of October 1, 2018.

[0000833444-19-000051:notes:289]
As previously disclosed, during the quarter ended December 31, 2017, the Company adopted ASU No. 2016-09. As a result, the Company recognized deferred tax assets of $179 million related to certain operating loss carryforwards resulting from the exercise of employee stock options and restricted stock vestings on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of October 1, 2017.

[0000833444-19-000051:notes:290]
On October 31, 2016, the Company completed the Adient spin-off. As a result of the spin-off, the Company divested net assets of approximately $4.0 billion.

[0000833444-19-000051:notes:291]
The Company consolidates certain subsidiaries in which the noncontrolling interest party has within their control the right to require the Company to redeem all or a portion of its interest in the subsidiary. The redeemable noncontrolling interests are reported at their estimated redemption value. Any adjustment to the redemption value impacts retained earnings but does not impact net income. Redeemable noncontrolling interests which are redeemable only upon future events, the occurrence of which is not currently probable, are recorded at carrying value. As of September 30, 2019 and 2018, the Company does not have any subsidiaries for which the noncontrolling interest party has within their control the right to require the Company to redeem any portion of its interests.

[0000833444-19-000051:notes:292]
The following schedules present changes in the redeemable noncontrolling interests (in millions):

[0000833444-19-000051:notes:293]
|  | Year Ended September 30, 2018 |  | Year Ended September 30, 2017 |
| Beginning balance, September 30 | $ | 211 |  |  | $ | 234 |  |
| Net income | 35 |  |  | 44 |  |
| Foreign currency translation adjustments | (3 | ) |  | 13 |  |
| Realized and unrealized losses on derivatives | (9 | ) |  | (1 | ) |
| Dividends | (3 | ) |  | (43 | ) |
| Reclassification to noncontrolling interest | (231 | ) |  | — |  |
| Spin-off of Adient | — |  |  | (36 | ) |
| Ending balance, September 30 | $ | — |  |  | $ | 211 |  |

[0000833444-19-000051:notes:294]
The following schedules present changes in AOCI attributable to Johnson Controls (in millions, net of tax):

[0000833444-19-000051:notes:295]
|  | Year Ended September 30, 2019 |  | Year Ended September 30, 2018 |  | Year Ended September 30, 2017 |
| Foreign currency translation adjustments |  |  |  |  |  |
| Balance at beginning of period | $ | (939 | ) |  | $ | (481 | ) |  | $ | (1,152 | ) |
| Divestiture of Power Solutions | 479 |  |  | — |  |  | — |  |
| Aggregate adjustment for the period (net of tax effect of $0, $(3) and $1) * | (325 | ) |  | (458 | ) |  | 108 |  |
| Adient spin-off impact (net of tax effect of $0) | — |  |  | — |  |  | 563 |  |
| Balance at end of period | (785 | ) |  | (939 | ) |  | (481 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |  |  |
| Balance at beginning of period | (13 | ) |  | 6 |  |  | 4 |  |
| Divestiture of Power Solutions (net of tax effect of $1, $0 and $0) | 4 |  |  | — |  |  | — |  |
| Current period changes in fair value (net of tax effect of $(1), $(4) and $4) | (1 | ) |  | (8 | ) |  | 9 |  |
| Reclassification to income (net of tax effect of $2, $(5) and $(10)) ** | 8 |  |  | (11 | ) |  | (23 | ) |
| Adient spin-off impact (net of tax effect of $0, $0 and $6) | — |  |  | — |  |  | 16 |  |
| Balance at end of period | (2 | ) |  | (13 | ) |  | 6 |  |
| Realize and unrealized gains (losses) on marketable securities |  |  |  |  |  |
| Balance at beginning of period | 8 |  |  | 4 |  |  | (1 | ) |
| Adoption of ASU 2016-01 *** | (8 | ) |  | — |  |  | — |  |
| Current period changes in fair value (net of tax effect of $0, $1 and $1) | — |  |  | 5 |  |  | 5 |  |
| Reclassification to income (net of tax effect of $0, $(1) and $0) **** | — |  |  | (1 | ) |  | — |  |
| Balance at end of period | — |  |  | 8 |  |  | 4 |  |
| Pension and postretirement plans |  |  |  |  |  |
| Balance at beginning of period | (2 | ) |  | (2 | ) |  | (4 | ) |
| Other changes (net of tax effect of $0) | (6 | ) |  | — |  |  | — |  |
| Adient spin-off impact (net of tax effect of $0) | — |  |  | — |  |  | 2 |  |
| Balance at end of period | (8 | ) |  | (2 | ) |  | (2 | ) |
| Accumulated other comprehensive loss, end of period | $ | (795 | ) |  | $ | (946 | ) |  | $ | (473 | ) |

[0000833444-19-000051:notes:296]
*      During fiscal 2018, $12 million of cumulative CTA was recognized as part of the divestiture-related gain recognized as part of the divestiture of Scott Safety.

[0000833444-19-000051:notes:297]
**   Refer to Note 10, "Derivative Instruments and Hedging Activities," of the notes to consolidated financial statements for disclosure of the line items on the consolidated statements of income affected by reclassifications from AOCI into income related to derivatives.

[0000833444-19-000051:notes:298]
***   As previously disclosed, during the quarter ended December 31, 2018, the Company adopted ASU 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." As a result the Company reclassified $8 million of unrealized gains on marketable securities to retained earnings as of October 1, 2018.

[0000833444-19-000051:notes:299]
****  During fiscal 2018, the Company sold certain marketable common stock for approximately $3 million. As a result, the Company recorded $2 million of realized gains within selling, general and administrative expenses.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-19-000051:notes:300]
RETIREMENT PLANS

[0000833444-19-000051:notes:301]
Pension Benefits

[0000833444-19-000051:notes:302]
The Company has non-contributory defined benefit pension plans covering certain U.S. and non-U.S. employees. The benefits provided are primarily based on years of service and average compensation or a monthly retirement benefit amount. Certain of the Company’s U.S. pension plans have been amended to prohibit new participants from entering the plans and no longer accrue benefits. Funding for U.S. pension plans equals or exceeds the minimum requirements of the Employee Retirement Income Security Act of 1974. Funding for non-U.S. plans observes the local legal and regulatory limits. Also, the Company makes contributions to union-trusteed pension funds for construction and service personnel.

[0000833444-19-000051:notes:303]
For pension plans with accumulated benefit obligations ("ABO") that exceed plan assets for continuing and discontinued operations, the projected benefit obligation ("PBO"), ABO and fair value of plan assets of those plans were $5,450 million, $5,388 million and $4,484 million, respectively, as of September 30, 2019 and $5,166 million, $5,072 million and $4,525 million, respectively, as of September 30, 2018.

[0000833444-19-000051:notes:304]
In fiscal 2019, total employer contributions for continuing operations to the defined benefit pension plans were $50 million, none of which were voluntary contributions made by the Company. The Company expects to contribute approximately $50 million in cash to its defined benefit pension plans in fiscal 2020. Projected benefit payments from the plans as of September 30, 2019 are estimated as follows (in millions):

[0000833444-19-000051:notes:305]
| 2020 | $ | 311 |  |
| 2021 | 289 |  |
| 2022 | 294 |  |
| 2023 | 297 |  |
| 2024 | 303 |  |
| 2025-2029 | 1,487 |  |

[0000833444-19-000051:notes:306]
Postretirement Benefits

[0000833444-19-000051:notes:307]
The Company provides certain health care and life insurance benefits for eligible retirees and their dependents primarily in the U.S. and Canada. Most non-U.S. employees are covered by government sponsored programs, and the cost to the Company is not significant.

[0000833444-19-000051:notes:308]
Eligibility for coverage is based on meeting certain years of service and retirement age qualifications. These benefits may be subject to deductibles, co-payment provisions and other limitations, and the Company has reserved the right to modify these benefits. Effective January 31, 1994, the Company modified certain U.S. salaried plans to place a limit on the Company’s cost of future annual retiree medical benefits at no more than 150% of the 1993 cost.

[0000833444-19-000051:notes:309]
The health care cost trend assumption does not have a significant effect on the amounts reported.

[0000833444-19-000051:notes:310]
In fiscal 2019, total employer contributions for continuing operations to the postretirement plans were $3 million. The Company expects to contribute approximately $4 million in cash to its postretirement plans in fiscal 2020 for continuing operations. Projected benefit payments from the plans as of September 30, 2019 are estimated as follows (in millions):

[0000833444-19-000051:notes:311]
| 2020 | $ | 17 |  |
| 2021 | 16 |  |
| 2022 | 16 |  |
| 2023 | 16 |  |
| 2024 | 15 |  |
| 2025-2029 | 58 |  |

[0000833444-19-000051:notes:312]
In December 2003, the U.S. Congress enacted the Medicare Prescription Drug, Improvement and Modernization Act of 2003 ("Act") for employers sponsoring postretirement care plans that provide prescription drug benefits. The Act introduces a prescription drug benefit under Medicare as well as a federal subsidy to sponsors of retiree health care benefit plans providing a benefit that is at least actuarially equivalent to Medicare Part D.1. Under the Act, the Medicare subsidy amount is received directly by the plan

[0000833444-19-000051:notes:313]
sponsor and not the related plan. Further, the plan sponsor is not required to use the subsidy amount to fund postretirement benefits and may use the subsidy for any valid business purpose. Projected subsidy receipts are estimated to be less than $1 million per year over the next ten years.

[0000833444-19-000051:notes:314]
Defined Contribution Plans

[0000833444-19-000051:notes:315]
The Company sponsors various defined contribution savings plans that allow employees to contribute a portion of their pre-tax and/or after-tax income in accordance with plan specified guidelines. Under specified conditions, the Company will contribute to certain savings plans based on predetermined percentages of compensation earned by the employee and/or will match a percentage of the employee contributions up to certain limits. Defined contribution plan contributions charged to expense for continuing and discontinued operations amounted to $198 million, $205 million and $190 million for the fiscal years ended 2019, 2018 and 2017, respectively.

[0000833444-19-000051:notes:316]
Multiemployer Benefit Plans

[0000833444-19-000051:notes:317]
The Company contributes to multiemployer benefit plans based on obligations arising from collective bargaining agreements related to certain of its hourly employees in the U.S. These plans provide retirement benefits to participants based on their service to contributing employers. The benefits are paid from assets held in trust for that purpose. The trustees typically are responsible for determining the level of benefits to be provided to participants as well as for such matters as the investment of the assets and the administration of the plans.

[0000833444-19-000051:notes:318]
The risks of participating in these multiemployer benefit plans are different from single-employer benefit plans in the following aspects:

[0000833444-19-000051:notes:319]
| • | Assets contributed to the multiemployer benefit plan by one employer may be used to provide benefits to employees of other participating employers. |

[0000833444-19-000051:notes:320]
| • | If a participating employer stops contributing to the multiemployer benefit plan, the unfunded obligations of the plan may be borne by the remaining participating employers. |

[0000833444-19-000051:notes:321]
| • | If the Company stops participating in some of its multiemployer benefit plans, the Company may be required to pay those plans an amount based on its allocable share of the underfunded status of the plan, referred to as a withdrawal liability. |

[0000833444-19-000051:notes:322]
The Company participates in approximately 285 multiemployer benefit plans, none of which are individually significant to the Company. The number of employees covered by the Company’s multiemployer benefit plans has remained consistent over the past three years, and there have been no significant changes that affect the comparability of fiscal 2019, 2018 and 2017 contributions. The Company recognizes expense for the contractually-required contribution for each period. The Company contributed $69 million, $68 million and $67 million to multiemployer benefit plans in fiscal 2019, 2018 and 2017, respectively.

[0000833444-19-000051:notes:323]
Based on the most recent information available, the Company believes that the present value of actuarial accrued liabilities in certain of these multiemployer benefit plans may exceed the value of the assets held in trust to pay benefits. Currently, the Company is not aware of any significant multiemployer benefits plans for which it is probable or reasonably possible that the Company will be obligated to make up any shortfall in funds. Moreover, if the Company were to exit certain markets or otherwise cease making contributions to these funds, the Company could trigger a withdrawal liability. Currently, the Company is not aware of any multiemployer benefit plans for which it is probable or reasonably possible that the Company will have a significant withdrawal liability. Any accrual for a shortfall or withdrawal liability will be recorded when it is probable that a liability exists and it can be reasonably estimated.

[0000833444-19-000051:notes:324]
Plan Assets

[0000833444-19-000051:notes:325]
The Company’s investment policies employ an approach whereby a mix of equities, fixed income and alternative investments are used to maximize the long-term return of plan assets for a prudent level of risk. The investment portfolio primarily contains a diversified blend of equity and fixed income investments. Equity investments are diversified across U.S. and non-U.S. stocks, as well as growth, value and small to large capitalizations. Fixed income investments include corporate and government issues, with short-, mid- and long-term maturities, with a focus on investment grade when purchased and a target duration close to that of the plan liability. Investment and market risks are measured and monitored on an ongoing basis through regular investment portfolio reviews, annual liability measurements and periodic asset/liability studies. The majority of the real estate component of the portfolio is invested in a diversified portfolio of high-quality, operating properties with cash yields greater than the targeted appreciation. Investments in other alternative asset classes, including hedge funds and commodities, diversify the expected investment returns

[0000833444-19-000051:notes:326]
relative to the equity and fixed income investments. As a result of the Company's diversification strategies, there are no significant concentrations of risk within the portfolio of investments.

[0000833444-19-000051:notes:327]
The Company’s actual asset allocations are in line with target allocations. The Company rebalances asset allocations as appropriate, in order to stay within a range of allocation for each asset category.

[0000833444-19-000051:notes:328]
The expected return on plan assets is based on the Company’s expectation of the long-term average rate of return of the capital markets in which the plans invest. The average market returns are adjusted, where appropriate, for active asset management returns. The expected return reflects the investment policy target asset mix and considers the historical returns earned for each asset category.

[0000833444-19-000051:notes:329]
The Company’s plan assets at September 30, 2019 and 2018, by asset category, are as follows (in millions):

[0000833444-19-000051:notes:330]
|  | Fair Value Measurements Using: |
| Asset Category | Total as ofSeptember 30, 2019 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| U.S. Pension |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 55 |  |  | $ | 24 |  |  | $ | 31 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 276 |  |  | 276 |  |  | — |  |  | — |  |
| Small-Cap | 232 |  |  | 232 |  |  | — |  |  | — |  |
| International - Developed | 266 |  |  | 233 |  |  | 33 |  |  | — |  |
| International - Emerging | 52 |  |  | 42 |  |  | 10 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 332 |  |  | 47 |  |  | 285 |  |  | — |  |
| Corporate/Other | 1,266 |  |  | 1,266 |  |  | — |  |  | — |  |
| Real Estate | 55 |  |  | 55 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy | 2,534 |  |  | $ | 2,175 |  |  | $ | 359 |  |  | $ | — |  |
| Investments Measured at Net Asset Value, as Practical Expedient: |  |  |  |  |  |  |  |
| Real Estate Investments Measured at Net Asset Value* | 202 |  |  |  |  |  |  |  |
| Total Plan Assets | $ | 2,736 |  |  |  |  |  |  |  |
| Non-U.S. Pension |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 174 |  |  | $ | 174 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 214 |  |  | 23 |  |  | 191 |  |  | — |  |
| International - Developed | 289 |  |  | 54 |  |  | 235 |  |  | — |  |
| International - Emerging | 12 |  |  | 1 |  |  | 11 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 778 |  |  | 69 |  |  | 709 |  |  | — |  |
| Corporate/Other | 517 |  |  | 289 |  |  | 228 |  |  | — |  |
| Hedge Fund | 69 |  |  | — |  |  | 69 |  |  | — |  |
| Real Estate | 31 |  |  | 31 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy | 2,084 |  |  | $ | 641 |  |  | $ | 1,443 |  |  | $ | — |  |
| Investments Measured at Net Asset Value, as Practical Expedient: |  |  |  |  |  |  |  |
| Real Estate Investments Measured at Net Asset Value* | 14 |  |  |  |  |  |  |  |
| Total Plan Assets | $ | 2,098 |  |  |  |  |  |  |  |
| Postretirement |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 22 |  |  | — |  |  | 22 |  |  | — |  |
| Small-Cap | 8 |  |  | — |  |  | 8 |  |  | — |  |
| International - Developed | 19 |  |  | — |  |  | 19 |  |  | — |  |
| International - Emerging | 9 |  |  | — |  |  | 9 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 20 |  |  | — |  |  | 20 |  |  | — |  |
| Corporate/Other | 55 |  |  | — |  |  | 55 |  |  | — |  |
| Commodities | 13 |  |  | — |  |  | 13 |  |  | — |  |
| Real Estate | 11 |  |  | — |  |  | 11 |  |  | — |  |
| Total Plan Assets | $ | 163 |  |  | $ | 6 |  |  | $ | 157 |  |  | $ | — |  |

[0000833444-19-000051:notes:331]
|  | Fair Value Measurements Using: |
| Asset Category | Total as ofSeptember 30, 2018 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| U.S. Pension |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 23 |  |  | $ | 2 |  |  | $ | 21 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 430 |  |  | 309 |  |  | 121 |  |  | — |  |
| Small-Cap | 282 |  |  | 282 |  |  | — |  |  | — |  |
| International - Developed | 411 |  |  | 365 |  |  | 46 |  |  | — |  |
| International - Emerging | 94 |  |  | 80 |  |  | 14 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 333 |  |  | 307 |  |  | 26 |  |  | — |  |
| Corporate/Other | 1,183 |  |  | 1,119 |  |  | 64 |  |  | — |  |
| Total Investments in the Fair Value Hierarchy | 2,756 |  |  | $ | 2,464 |  |  | $ | 292 |  |  | $ | — |  |
| Investments Measured at Net Asset Value, as Practical Expedient: |  |  |  |  |  |  |  |  |
| Real Estate Investments Measured at Net Asset Value* | 290 |  |  |  |  |  |  |  |
| Total Plan Assets | $ | 3,046 |  |  |  |  |  |  |  |
| Non-U.S. Pension |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 44 |  |  | $ | 43 |  |  | $ | 1 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 235 |  |  | 24 |  |  | 211 |  |  | — |  |
| International - Developed | 319 |  |  | 59 |  |  | 260 |  |  | — |  |
| International - Emerging | 15 |  |  | 1 |  |  | 14 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 830 |  |  | 80 |  |  | 750 |  |  | — |  |
| Corporate/Other | 545 |  |  | 301 |  |  | 244 |  |  | — |  |
| Hedge Fund | 82 |  |  | — |  |  | 82 |  |  | — |  |
| Real Estate | 26 |  |  | 26 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy | 2,096 |  |  | $ | 534 |  |  | $ | 1,562 |  |  | $ | — |  |
| Investments Measured at Net Asset Value, as Practical Expedient: |  |  |  |  |  |  |  |
| Real Estate Investments Measured at Net Asset Value* | 21 |  |  |  |  |  |  |  |
| Total Plan Assets | $ | 2,117 |  |  |  |  |  |  |  |
| Postretirement |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 13 |  |  | $ | 13 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 26 |  |  | — |  |  | 26 |  |  | — |  |
| Small-Cap | 8 |  |  | — |  |  | 8 |  |  | — |  |
| International - Developed | 20 |  |  | — |  |  | 20 |  |  | — |  |
| International - Emerging | 9 |  |  | — |  |  | 9 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 20 |  |  | — |  |  | 20 |  |  | — |  |
| Corporate/Other | 55 |  |  | — |  |  | 55 |  |  | — |  |
| Commodities | 14 |  |  | — |  |  | 14 |  |  | — |  |
| Real Estate | 9 |  |  | — |  |  | 9 |  |  | — |  |
| Total Plan Assets | $ | 174 |  |  | $ | 13 |  |  | $ | 161 |  |  | $ | — |  |

[0000833444-19-000051:notes:332]
* The fair value of certain investments in real estate do not have a readily determinable fair value and requires the fund managers to independently arrive at fair value by calculating net asset value ("NAV") per share. In order to calculate NAV per share, the fund managers value the real estate investments using any one, or a combination of, the following methods: independent third party appraisals, discounted cash flow analysis of net cash flows projected to be generated by the investment and recent sales of comparable investments. Assumptions used to revalue the properties are updated every quarter. Due to the fact that the fund managers calculate NAV per share, the Company utilizes a practical expedient for measuring the fair value of its real-estate investments, as provided for under ASC 820, "Fair Value Measurement." In applying the practical expedient, the Company is not required to further adjust the NAV provided by the fund manager in order to determine the fair value of its investment as the NAV per share is calculated in a manner consistent with the measurement principles of ASC 946, "Financial Services - Investment Companies," and as of the Company's measurement date. The Company believes this is an appropriate methodology to obtain the fair value of these assets. For the component of the real estate portfolio under development, the investments are carried at cost until they are completed and valued by a third party appraiser. In accordance with ASU No. 2015-07, "Disclosures for Investments in Certain Entities That Calculate Net Asset Value per Share (or Its Equivalent)," investments for which fair value is measured using the net asset value per share practical expedient should be disclosed separate from the fair value hierarchy. The fair value amounts presented in this table are intended to permit reconciliation of total plan assets to the amounts presented in the notes to consolidated financial statements.

[0000833444-19-000051:notes:333]
The following is a description of the valuation methodologies used for assets measured at fair value.  Certain assets are held within commingled funds which are valued at the unitized NAV or percentage of the net asset value as determined by the manager of the fund. These values are based on the fair value of the underlying net assets owned by the fund.

[0000833444-19-000051:notes:334]
Cash and Cash Equivalents: The fair value of cash is valued at cost.

[0000833444-19-000051:notes:335]
Equity Securities: The fair value of equity securities is determined by direct quoted market prices. The underlying holdings are direct quoted market prices on regulated financial exchanges.

[0000833444-19-000051:notes:336]
Fixed Income Securities: The fair value of fixed income securities is determined by direct or indirect quoted market prices. If indirect quoted market prices are utilized, the value of assets held in separate accounts is not published, but the investment managers report daily the underlying holdings. The underlying holdings are direct quoted market prices on regulated financial exchanges.

[0000833444-19-000051:notes:337]
Commodities: The fair value of the commodities is determined by quoted market prices of the underlying holdings on regulated financial exchanges.

[0000833444-19-000051:notes:338]
Hedge Funds: The fair value of hedge funds is accounted for by the custodian. The custodian obtains valuations from underlying managers based on market quotes for the most liquid assets and alternative methods for assets that do not have sufficient trading activity to derive prices. The Company and custodian review the methods used by the underlying managers to value the assets. The Company believes this is an appropriate methodology to obtain the fair value of these assets.

[0000833444-19-000051:notes:339]
Real Estate: The fair value of real estate is determined by quoted market prices of the underlying Real Estate Investment Trusts

[0000833444-19-000051:notes:340]
("REITs"), which are securities traded on an open exchange.

[0000833444-19-000051:notes:341]
The methods described above may produce a fair value calculation that may not be indicative of net realizable value or reflective of future fair values. Furthermore, while the Company believes its valuation methods are appropriate and consistent with other market participants, the use of different methodologies or assumptions to determine the fair value of certain financial instruments could result in a different fair value measurement at the reporting date.

[0000833444-19-000051:notes:342]
There were no Level 3 assets as of September 30, 2019 or 2018 or any Level 3 asset activity during fiscal 2019 or 2018.

[0000833444-19-000051:notes:343]
Funded Status

[0000833444-19-000051:notes:344]
The table that follows contains the ABO and reconciliations of the changes in the PBO, the changes in plan assets and the funded status (in millions):

[0000833444-19-000051:notes:345]
|  | Pension Benefits |  | PostretirementBenefits |
|  | U.S. Plans |  | Non-U.S. Plans |  |
| September 30, | 2019 |  | 2018 |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Accumulated Benefit Obligation | $ | 3,115 |  |  | $ | 3,154 |  |  | $ | 2,549 |  |  | $ | 2,444 |  |  | $ | — |  |  | $ | — |  |
| Change in Projected Benefit Obligation |  |  |  |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of year | 3,191 |  |  | 3,419 |  |  | 2,542 |  |  | 2,721 |  |  | 196 |  |  | 214 |  |
| Service cost | 8 |  |  | 15 |  |  | 22 |  |  | 23 |  |  | 1 |  |  | 2 |  |
| Interest cost | 108 |  |  | 105 |  |  | 54 |  |  | 57 |  |  | 6 |  |  | 7 |  |
| Plan participant contributions | — |  |  | — |  |  | 2 |  |  | 2 |  |  | 6 |  |  | 6 |  |
| Power Solutions divestiture | (390 | ) |  | — |  |  | (86 | ) |  | — |  |  | (9 | ) |  | — |  |
| Other divestitures | — |  |  | — |  |  | (8 | ) |  | — |  |  | — |  |  | — |  |
| Actuarial (gain) loss | 441 |  |  | (70 | ) |  | 337 |  |  | (67 | ) |  | 15 |  |  | 1 |  |
| Amendments made during the year | — |  |  | — |  |  | 26 |  |  | — |  |  | (19 | ) |  | (8 | ) |
| Benefits and settlements paid | (243 | ) |  | (278 | ) |  | (126 | ) |  | (130 | ) |  | (23 | ) |  | (24 | ) |
| Estimated subsidy received | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Curtailment | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | — |  |
| Other | — |  |  | — |  |  | (2 | ) |  | (4 | ) |  | — |  |  | (1 | ) |
| Currency translation adjustment | — |  |  | — |  |  | (109 | ) |  | (58 | ) |  | — |  |  | (2 | ) |
| Projected benefit obligation at end of year | $ | 3,115 |  |  | $ | 3,191 |  |  | $ | 2,652 |  |  | $ | 2,542 |  |  | $ | 174 |  |  | $ | 196 |  |
| Change in Plan Assets |  |  |  |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year | $ | 3,046 |  |  | $ | 3,165 |  |  | $ | 2,117 |  |  | $ | 2,181 |  |  | $ | 174 |  |  | $ | 177 |  |
| Actual return on plan assets | 266 |  |  | 152 |  |  | 203 |  |  | 69 |  |  | 7 |  |  | 6 |  |
| Power Solutions divestiture | (371 | ) |  | — |  |  | (45 | ) |  | — |  |  | (4 | ) |  | — |  |
| Other divestitures | — |  |  | — |  |  | (4 | ) |  | — |  |  | — |  |  | — |  |
| Employer and employee contributions | 38 |  |  | 7 |  |  | 50 |  |  | 48 |  |  | 9 |  |  | 15 |  |
| Benefits paid | (136 | ) |  | (153 | ) |  | (76 | ) |  | (88 | ) |  | (23 | ) |  | (24 | ) |
| Settlement payments | (107 | ) |  | (125 | ) |  | (50 | ) |  | (42 | ) |  | — |  |  | — |  |
| Other | — |  |  | — |  |  | (2 | ) |  | (2 | ) |  | — |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | (95 | ) |  | (49 | ) |  | — |  |  | — |  |
| Fair value of plan assets at end of year | $ | 2,736 |  |  | $ | 3,046 |  |  | $ | 2,098 |  |  | $ | 2,117 |  |  | $ | 163 |  |  | $ | 174 |  |
| Funded status | $ | (379 | ) |  | $ | (145 | ) |  | $ | (554 | ) |  | $ | (425 | ) |  | $ | (11 | ) |  | $ | (22 | ) |
| Amounts recognized in the statement of financial position consist of: |
| Prepaid benefit cost | $ | 30 |  |  | $ | 63 |  |  | $ | 25 |  |  | $ | 26 |  |  | $ | 66 |  |  | $ | 61 |  |
| Accrued benefit liability | (409 | ) |  | (156 | ) |  | (579 | ) |  | (409 | ) |  | (77 | ) |  | (83 | ) |
| Accrued benefit liability - discontinued operations | — |  |  | (52 | ) |  | — |  |  | (42 | ) |  | — |  |  | — |  |
| Net amount recognized | $ | (379 | ) |  | $ | (145 | ) |  | $ | (554 | ) |  | $ | (425 | ) |  | $ | (11 | ) |  | $ | (22 | ) |
| Weighted Average Assumptions (1) |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate (2) | 2.95 | % |  | 4.10 | % |  | 1.50 | % |  | 2.45 | % |  | 2.90 | % |  | 3.80 | % |
| Rate of compensation increase | NA |  |  | 3.50 | % |  | 2.80 | % |  | 2.95 | % |  | NA |  |  | NA |  |

[0000833444-19-000051:notes:346]
| (1) | Plan assets and obligations are determined based on a September 30 measurement date at September 30, 2019 and 2018. |

[0000833444-19-000051:notes:347]
| (2) | The Company considers the expected benefit payments on a plan-by-plan basis when setting assumed discount rates. As a result, the Company uses different discount rates for each plan depending on the plan jurisdiction, the demographics of |

[0000833444-19-000051:notes:348]
participants and the expected timing of benefit payments. For the U.S. pension and postretirement plans, the Company uses a discount rate provided by an independent third party calculated based on an appropriate mix of high quality bonds. For the non-U.S. pension and postretirement plans, the Company consistently uses the relevant country specific benchmark indices for determining the various discount rates. The Company has elected to utilize a full yield curve approach in the estimation of service and interest components of net periodic benefit cost (credit) for pension and other postretirement for plans that utilize a yield curve approach. The full yield curve approach applies the specific spot rates along the yield curve used in the determination of the benefit obligation to the relevant projected cash flows.

[0000833444-19-000051:notes:349]
Accumulated Other Comprehensive Income

[0000833444-19-000051:notes:350]
The amounts in AOCI on the consolidated statements of financial position, exclusive of tax impacts, that have not yet been recognized as components of net periodic benefit cost at September 30, 2019 and 2018 related to pension and postretirement benefits are $6 million and less than $1 million, respectively.

[0000833444-19-000051:notes:351]
The amounts in AOCI expected to be recognized as components of net periodic benefit cost (credit) over the next fiscal year related to pension and postretirement benefits are not significant.

[0000833444-19-000051:notes:352]
Net Periodic Benefit Cost

[0000833444-19-000051:notes:353]
The table that follows contains the components of net periodic benefit costs, which are primarily recorded in selling, general and administrative expenses in the consolidated statements of income (in millions):

[0000833444-19-000051:notes:354]
|  | Pension Benefits |  | Postretirement Benefits |
|  | U.S. Plans |  | Non-U.S. Plans |  |
| Year ended September 30, | 2019 |  | 2018 |  | 2017 |  | 2019 |  | 2018 |  | 2017 |  | 2019 |  | 2018 |  | 2017 |
| Components of Net Periodic Benefit Cost (Credit): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost | $ | 8 |  |  | $ | 15 |  |  | $ | 18 |  |  | $ | 22 |  |  | $ | 23 |  |  | $ | 32 |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | 2 |  |
| Interest cost | 108 |  |  | 105 |  |  | 113 |  |  | 54 |  |  | 57 |  |  | 48 |  |  | 6 |  |  | 7 |  |  | 6 |  |
| Expected return on plan assets | (199 | ) |  | (229 | ) |  | (229 | ) |  | (105 | ) |  | (114 | ) |  | (92 | ) |  | (9 | ) |  | (10 | ) |  | (10 | ) |
| Net actuarial (gain) loss | 361 |  |  | 7 |  |  | (220 | ) |  | 236 |  |  | (22 | ) |  | (195 | ) |  | 17 |  |  | 5 |  |  | (5 | ) |
| Curtailment gain | — |  |  | — |  |  | — |  |  | — |  |  | (2 | ) |  | (19 | ) |  | — |  |  | — |  |  | — |  |
| Settlement (gain) loss | 13 |  |  | — |  |  | (16 | ) |  | 4 |  |  | — |  |  | (1 | ) |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (credit) | 291 |  |  | (102 | ) |  | (334 | ) |  | 211 |  |  | (58 | ) |  | (227 | ) |  | 15 |  |  | 4 |  |  | (7 | ) |
| Net periodic benefit (cost) credit related to discontinued operations | (2 | ) |  | (5 | ) |  | 26 |  |  | — |  |  | (7 | ) |  | 7 |  |  | — |  |  | (2 | ) |  | 2 |  |
| Net periodic benefit cost (credit) included in continuing operations | $ | 289 |  |  | $ | (107 | ) |  | $ | (308 | ) |  | $ | 211 |  |  | $ | (65 | ) |  | $ | (220 | ) |  | $ | 15 |  |  | $ | 2 |  |  | $ | (5 | ) |
| Expense Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate | 4.10 | % |  | 3.80 | % |  | 3.70 | % |  | 2.45 | % |  | 2.40 | % |  | 1.90 | % |  | 3.80 | % |  | 3.70 | % |  | 3.30 | % |
| Expected return on plan assets | 7.10 | % |  | 7.50 | % |  | 7.50 | % |  | 5.20 | % |  | 5.35 | % |  | 4.60 | % |  | 5.65 | % |  | 5.65 | % |  | 5.60 | % |
| Rate of compensation increase | 3.50 | % |  | 3.20 | % |  | 3.20 | % |  | 2.95 | % |  | 2.90 | % |  | 2.65 | % |  | NA |  |  | NA |  |  | NA |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-19-000051:notes:355]
SIGNIFICANT RESTRUCTURING AND IMPAIRMENT COSTS

[0000833444-19-000051:notes:356]
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company commits to restructuring plans as necessary.

[0000833444-19-000051:notes:357]
In fiscal 2018, the Company committed to a significant restructuring plan (2018 Plan) and recorded $255 million of restructuring and impairment costs for continuing operations in the consolidated statements of income. This was the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. Of the restructuring and impairment costs recorded, $113 million related to the Global Products segment, $56 million related to the Building Solutions EMEA/LA segment, $50 million related to Corporate, $20 million related to the Building Solutions North America segment and $16 million related to the Building Solutions Asia Pacific segment. The restructuring actions are expected to be substantially complete in 2020.

[0000833444-19-000051:notes:358]
Additionally, the Company recorded $8 million of restructuring and impairment costs related to Power Solutions in fiscal 2018. This is reported within discontinued operations.

[0000833444-19-000051:notes:359]
The following table summarizes the changes in the Company’s 2018 Plan reserve, included within other current liabilities in

[0000833444-19-000051:notes:360]
the consolidated statements of financial position (in millions):

[0000833444-19-000051:notes:361]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original reserve | $ | 209 |  |  | $ | 42 |  |  | $ | 12 |  |  | $ | — |  |  | $ | 263 |  |
| Utilized—cash | (45 | ) |  | — |  |  | (2 | ) |  | — |  |  | (47 | ) |
| Utilized—noncash | — |  |  | (42 | ) |  | — |  |  | — |  |  | (42 | ) |
| Balance at September 30, 2018 | $ | 164 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 174 |  |
| Utilized—cash | (61 | ) |  | — |  |  | (6 | ) |  | — |  |  | (67 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Transfer to liabilities held for sale | (4 | ) |  | — |  |  | — |  |  | — |  |  | (4 | ) |
| Balance at September 30, 2019 | $ | 99 |  |  | $ | — |  |  | $ | 4 |  |  | $ | (1 | ) |  | $ | 102 |  |

[0000833444-19-000051:notes:362]
In fiscal 2017, the Company committed to a significant restructuring plan (2017 Plan) and recorded $347 million of restructuring and impairment costs for continuing operations in the consolidated statements of income. This was the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. Of the restructuring and impairment costs recorded, $166 million related to Corporate, $74 million related to the Building Solutions EMEA/LA segment, $59 million related to the Building Solutions North America segment, $32 million related to the Global Products segment and $16 million related to the Building Solutions Asia Pacific segment. The restructuring actions are expected to be substantially complete in fiscal 2020.

[0000833444-19-000051:notes:363]
Additionally, the Company recorded $20 million of restructuring and impairment costs related to Power Solutions in fiscal 2017. This is reported within discontinued operations.

[0000833444-19-000051:notes:364]
The following table summarizes the changes in the Company’s 2017 Plan reserve, included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-19-000051:notes:365]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original Reserve | $ | 276 |  |  | $ | 77 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 367 |  |
| Utilized—cash | (75 | ) |  | — |  |  | — |  |  | — |  |  | (75 | ) |
| Utilized—noncash | — |  |  | (77 | ) |  | (1 | ) |  | — |  |  | (78 | ) |
| Adjustment to restructuring reserves | 25 |  |  | — |  |  | — |  |  | — |  |  | 25 |  |
| Balance at September 30, 2017 | $ | 226 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |  | $ | 239 |  |
| Utilized—cash | (152 | ) |  | — |  |  | (6 | ) |  | — |  |  | (158 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Balance at September 30, 2018 | $ | 74 |  |  | $ | — |  |  | $ | 7 |  |  | $ | (1 | ) |  | $ | 80 |  |
| Utilized—cash | (11 | ) |  | — |  |  | (2 | ) |  | — |  |  | (13 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (3 | ) |  | (3 | ) |
| Transfer to liabilities held for sale | (3 | ) |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Balance at September 30, 2019 | $ | 60 |  |  | $ | — |  |  | $ | 5 |  |  | $ | (4 | ) |  | $ | 61 |  |

[0000833444-19-000051:notes:366]
In fiscal 2016, the Company committed to a significant restructuring plan (2016 Plan) and recorded $222 million of restructuring and impairment costs for continuing operations in the consolidated statements of income. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments and change-in-control payments. Of the restructuring and impairment costs recorded, $161 million related to Corporate, $44 million related to the Global Products segment and $17 million related to the Building Solutions EMEA/LA segment. The restructuring actions are substantially complete, and final payments are expected to be made in fiscal 2020. Included in the reserve is $56 million of committed restructuring actions taken by Tyco for liabilities assumed as part of the Tyco acquisition.

[0000833444-19-000051:notes:367]
Additionally, the Company recorded $398 million of restructuring and impairment costs within discontinued operations related to Adient and Power Solutions in fiscal 2016. This is reported within discontinued operations.

[0000833444-19-000051:notes:368]
The following table summarizes the changes in the Company’s 2016 Plan reserve, included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-19-000051:notes:369]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original Reserve | $ | 368 |  |  | $ | 190 |  |  | $ | 62 |  |  | $ | — |  |  | $ | 620 |  |
| Acquired Tyco restructuring reserves | 78 |  |  | — |  |  | — |  |  | — |  |  | 78 |  |
| Utilized—cash | (32 | ) |  | — |  |  | — |  |  | — |  |  | (32 | ) |
| Utilized—noncash | — |  |  | (190 | ) |  | (32 | ) |  | 1 |  |  | (221 | ) |
| Balance at September 30, 2016 | $ | 414 |  |  | $ | — |  |  | $ | 30 |  |  | $ | 1 |  |  | $ | 445 |  |
| Adient spin-off impact | (194 | ) |  | — |  |  | (22 | ) |  | — |  |  | (216 | ) |
| Utilized—cash | (86 | ) |  | — |  |  | (2 | ) |  | — |  |  | (88 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Adjustment to restructuring reserves | (25 | ) |  | — |  |  | — |  |  | — |  |  | (25 | ) |
| Transfer to liabilities held for sale | (3 | ) |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Adjustment to acquired Tyco restructuring reserves | (22 | ) |  | — |  |  | — |  |  | — |  |  | (22 | ) |
| Balance at September 30, 2017 | $ | 84 |  |  | $ | — |  |  | $ | 6 |  |  | $ | 2 |  |  | $ | 92 |  |
| Utilized—cash | (17 | ) |  | — |  |  | (2 | ) |  | — |  |  | (19 | ) |
| Balance at September 30, 2018 | $ | 67 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 2 |  |  | $ | 73 |  |
| Utilized—cash | (37 | ) |  | — |  |  | (4 | ) |  | — |  |  | (41 | ) |
| Balance at September 30, 2019 | $ | 30 |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |  | $ | 32 |  |

[0000833444-19-000051:notes:370]
The Company's fiscal 2018, 2017 and 2016 restructuring plans included workforce reductions of approximately 11,300 employees (9,100 for the Building Technologies & Solutions business and 2,200 for Corporate). Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of September 30, 2019, approximately 6,200 of the employees have been separated from the Company pursuant to the restructuring plans. In addition, the restructuring plans included twelve plant closures in the Building Technologies & Solutions business. As of September 30, 2019, eleven of the twelve plants have been closed.

[0000833444-19-000051:notes:371]
Company management closely monitors its overall cost structure and continually analyzes each of its businesses for opportunities to consolidate current operations, improve operating efficiencies and locate facilities in close proximity to customers. This ongoing analysis includes a review of its manufacturing, engineering and purchasing operations, as well as the overall global footprint for all its businesses.


## us-gaap:AssetImpairmentChargesTextBlock

[0000833444-19-000051:notes:372]
IMPAIRMENT OF LONG-LIVED ASSETS

[0000833444-19-000051:notes:373]
The Company reviews long-lived assets, including tangible assets and other intangible assets with definitive lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of Software to be Sold, Leased, or Marketed." ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. ASC 350-30 requires intangible assets acquired in a business combination that are used in research and development activities be considered indefinite lived until the completion or abandonment of the associated research and development efforts. During the period that those assets are considered indefinite lived, they shall not be amortized but shall be tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired. If the carrying amount of an intangible asset exceeds its fair value, an entity shall recognize an impairment loss in an amount equal to that excess. ASC 985-20 requires the unamortized capitalized costs of a computer software

[0000833444-19-000051:notes:374]
product be compared to the net realizable value of that product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset shall be written off.

[0000833444-19-000051:notes:375]
In fiscal 2019, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with the plans to dispose of a business within its Global Products segment that met the criteria to be classified as held for sale. Assets and liabilities held for sale are required to be recorded at the lower of carrying value or fair value less any costs to sell. Accordingly, the Company recorded an impairment charge of $235 million within restructuring and impairment costs in the consolidated statements of income in fiscal 2019 to write down the carrying value of the assets held for sale to fair value less any costs to sell. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-19-000051:notes:376]
In fiscal 2018, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2018. As a result, the Company reviewed the long-lived assets for impairment and recorded $36 million of asset impairment charges within restructuring and impairment costs in the consolidated statements of income. Of the total impairment charges, $31 million related to the Global Products segment and $5 million related to Corporate assets. In addition, the Company recorded $6 million of asset impairments within discontinued operations related to the Power Solutions segment in fiscal 2018. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-19-000051:notes:377]
In fiscal 2017, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2017. As a result, the Company reviewed the long-lived assets for impairment and recorded $70 million of asset impairment charges within restructuring and impairment costs on the consolidated statements of income. Of the total impairment charges, $30 million related to the Building Solutions North America segment, $20 million related to the Global Products segment, $19 million related to Corporate assets and $1 million related to the Building Solutions Asia Pacific segment. In addition, the Company recorded $7 million of asset impairments within discontinued operations related to the Power Solutions segment in fiscal 2017. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-19-000051:notes:378]
At September 30, 2019, 2018 and 2017, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets. Refer to Note 1, "Summary of Significant Accounting Policies," and Note 7, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for discussion of the Company’s goodwill impairment testing.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-19-000051:notes:379]
INCOME TAXES

[0000833444-19-000051:notes:380]
The more significant components of the Company’s income tax provision from continuing operations are as follows (in millions):

[0000833444-19-000051:notes:381]
|  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Tax expense at Ireland statutory rate | $ | 132 |  |  | $ | 193 |  |  | $ | 144 |  |
| U.S. state income tax, net of federal benefit | 15 |  |  | 15 |  |  | 8 |  |
| Income subject to the U.S. federal tax rate | (110 | ) |  | 39 |  |  | (311 | ) |
| Income subject to rates different than the statutory rate | 38 |  |  | (201 | ) |  | 185 |  |
| Reserve and valuation allowance adjustments | (284 | ) |  | 31 |  |  | (164 | ) |
| Impact of acquisitions and divestitures | — |  |  | 16 |  |  | 475 |  |
| U.S. Tax Reform discrete items | — |  |  | 108 |  |  | — |  |
| Restructuring and impairment costs | (24 | ) |  | (4 | ) |  | (15 | ) |
| Income tax provision (benefit) | $ | (233 | ) |  | $ | 197 |  |  | $ | 322 |  |

[0000833444-19-000051:notes:382]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. The effective rate for continuing operations is below the statutory rate of 12.5% for fiscal 2019 primarily due to tax audit reserve adjustments, the income tax effects of  mark-to-market adjustments, a tax indemnification reserve release, the tax benefits of an asset held for sale impairment charge and continuing global tax planning initiatives, partially offset by valuation allowance adjustments as a result of tax law changes, a discrete tax charge related to newly enacted regulations related to U.S. Tax Reform and tax rate differentials. The effective rate for continuing operations is above the statutory rate of 12.5% for fiscal 2018 primarily due to the discrete net impacts of U.S. Tax Reform, the final income tax effects of the completed divestiture of the Scott Safety business, and valuation allowance adjustments, partially offset by tax audit closures, tax benefits due to changes in entity tax status, the benefits of continuing global tax planning initiatives and tax rate differentials. The effective rate is above the statutory rate of 12.5% for fiscal 2017 primarily due to the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries related to the divestiture of the Scott Safety business, the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the jurisdictional mix of significant restructuring and impairment costs, Tyco Merger transaction and integration costs, purchase accounting adjustments, tax audit closures, a tax benefit due to changes in entity tax status and the benefits of continuing global tax planning initiatives.

[0000833444-19-000051:notes:383]
Valuation Allowances

[0000833444-19-000051:notes:384]
The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary.

[0000833444-19-000051:notes:385]
In the fourth quarter of fiscal 2019, the Company performed an analysis related to the realizablility of its worldwide deferred tax assets. As a result, and after considering feasible tax planning initiatives and other positive and negative evidence, the Company determined that it was more likely than not that certain deferred tax assets primarily within the U.S., Belgium, Japan and the United Kingdom would not be realized, and it is more likely than not that certain deferred tax assets of the U.S. and France will be realized. The valuation allowance adjustments resulted in an immaterial net impact to income tax expense for the three-month period ended September 30, 2019.

[0000833444-19-000051:notes:386]
In the first quarter of fiscal 2019, as a result of changes to U.S. tax law, the Company recorded a discrete tax charge of $76 million related to valuation allowances on certain U.S. deferred tax assets.

[0000833444-19-000051:notes:387]
In the fourth quarter of fiscal 2018, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering feasible tax planning initiatives and other positive and negative evidence, the Company determined that it was more likely than not that certain deferred tax assets primarily within Germany would not be realized. Therefore, the Company recorded $56 million of valuation allowances as income tax expense in the three-month period ended September 30, 2018.

[0000833444-19-000051:notes:388]
In the fourth quarter of fiscal 2017, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering tax planning initiatives and other positive and negative evidence, the Company determined that it was more likely than not that certain deferred tax assets primarily in Canada, China and Mexico would not be able to be realized, and it was more likely than not that certain deferred tax assets in Germany would be realized. Therefore, the Company recorded $27 million of net valuation allowances as income tax expense in the three-month period ended September 30, 2017.

[0000833444-19-000051:notes:389]
Uncertain Tax Positions

[0000833444-19-000051:notes:390]
The Company is subject to income taxes in the U.S. and numerous foreign jurisdictions. Judgment is required in determining its worldwide provision for income taxes and recording the related assets and liabilities. In the ordinary course of the Company’s business, there are many transactions and calculations where the ultimate tax determination is uncertain. The Company is regularly under audit by tax authorities.

[0000833444-19-000051:notes:391]
At September 30, 2019, the Company had gross tax effected unrecognized tax benefits for continuing operations of $2,451 million of which $2,121 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2019 was approximately $181 million (net of tax benefit).

[0000833444-19-000051:notes:392]
At September 30, 2018, the Company had gross tax effected unrecognized tax benefits for continuing operations of $2,358 million of which $2,225 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2018 was approximately $119 million (net of tax benefit).

[0000833444-19-000051:notes:393]
At September 30, 2017, the Company had gross tax effected unrecognized tax benefits for continuing operations of $2,161 million of which $2,034 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2017 was approximately $99 million (net of tax benefit).

[0000833444-19-000051:notes:394]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0000833444-19-000051:notes:395]
|  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Beginning balance, October 1 | $ | 2,358 |  |  | $ | 2,161 |  |  | $ | 1,694 |  |
| Additions for tax positions related to the current year | 433 |  |  | 435 |  |  | 613 |  |
| Additions for tax positions of prior years | 347 |  |  | 7 |  |  | 116 |  |
| Reductions for tax positions of prior years | (88 | ) |  | (201 | ) |  | (44 | ) |
| Settlements with taxing authorities | — |  |  | (19 | ) |  | (95 | ) |
| Statute closings and audit resolutions | (599 | ) |  | (25 | ) |  | (264 | ) |
| Acquisition of business | — |  |  | — |  |  | 141 |  |
| Ending balance, September 30 | $ | 2,451 |  |  | $ | 2,358 |  |  | $ | 2,161 |  |

[0000833444-19-000051:notes:396]
During fiscal 2019, the Company settled tax examinations impacting fiscal years 2015 to 2016 and adjusted various tax audit reserves which resulted in a $586 million net benefit to income tax expense in the fourth quarter. In the third quarter of fiscal 2019, the Company recorded a discrete charge related to newly enacted regulations related to U.S. Tax Reform and a discrete charge related to non-U.S. tax examinations which impacted the Company’s reserves for uncertain tax positions resulting in a $226 million net charge to income tax expense.

[0000833444-19-000051:notes:397]
During fiscal 2018, the Company settled tax examinations impacting fiscal years 2010 to fiscal 2012 which resulted in a $25 million net benefit to income tax expense.

[0000833444-19-000051:notes:398]
During fiscal 2017, the Company settled a significant number of tax examinations impacting fiscal years 2006 to fiscal 2014. In the fourth quarter of fiscal 2017, income tax audit resolutions resulted in a net $191 million benefit to income tax expense.

[0000833444-19-000051:notes:399]
The Company is currently under exam in the following major non-U.S. jurisdictions for continuing operations:

[0000833444-19-000051:notes:400]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2017 |
| China |  | 2008 - 2018 |
| Germany |  | 2007 - 2016 |
| Japan |  | 2015 - 2018 |
| Spain |  | 2015 |
| United Kingdom |  | 2012 - 2015 |

[0000833444-19-000051:notes:401]
It is reasonably possible that certain tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact to tax expense.

[0000833444-19-000051:notes:402]
Other Tax Matters

[0000833444-19-000051:notes:403]
In the third quarter of fiscal 2019, the Company recorded a $235 million impairment charge related to assets held for sale. Refer to Note 17, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for further information regarding the impairment charge.  The impairment charge generated a $53 million tax benefit.

[0000833444-19-000051:notes:404]
In the third quarter of fiscal 2019, the Company released a $226 million tax indemnification reserve, which was recorded within selling, general and administrative expenses in the consolidated statements of income. Refer to Note 21, "Guarantees," of the notes

[0000833444-19-000051:notes:405]
to consolidated financial statements for further information regarding the reserve release. The reserve release generated no income tax expense.

[0000833444-19-000051:notes:406]
During fiscal 2019, 2018, and 2017, the Company recorded transaction and integration costs for continuing operations of $317 million, $226 million and $427 million, respectively. These costs generated tax benefits of $35 million, $27 million and $69 million, respectively, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-19-000051:notes:407]
During fiscal 2019, 2018 and 2017, the Company recorded mark-to-market gains (losses) of $(618) million, $24 million and $384 million, respectively. These gains (losses) generated tax expense (benefit) of $(130) million, $1 million and $113 million, respectively, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-19-000051:notes:408]
In the fourth quarter of fiscal 2018, the Company recorded a tax benefit of $139 million due to changes in entity tax status.

[0000833444-19-000051:notes:409]
In the first quarter of fiscal 2018, the Company completed the sale of its Scott Safety business to 3M Company. In connection with the sale, the Company recorded a pre-tax gain of $114 million and income tax expense of $30 million. In addition, during fiscal 2017, the Company recorded a discrete non-cash tax charge of $490 million related to establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries of the Scott Safety business. Refer to Note 2, "Acquisitions and Divestitures," of the notes to consolidated financial statements for additional information.

[0000833444-19-000051:notes:410]
During fiscal 2018 and 2017, the Company incurred significant charges for restructuring and impairment costs for continuing operations of $255 million and $347 million, respectively. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. These costs generated tax benefits of $36 million and $58 million, respectively, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-19-000051:notes:411]
In the third quarter of fiscal 2017, the Company recorded a discrete tax benefit of $75 million due to changes in entity tax status.

[0000833444-19-000051:notes:412]
In the first quarter of fiscal 2017, the Company recorded a discrete tax benefit of $101 million due to changes in entity tax status.

[0000833444-19-000051:notes:413]
Impacts of Tax Legislation and Change in Statutory Tax Rates

[0000833444-19-000051:notes:414]
On September 28, 2018 the Swiss Parliament approved the Federal Act on Tax Reform and AHV Financing (“TRAF”), which was subsequently approved by the Swiss electorate on May 19, 2019. During the fourth quarter of fiscal 2019, the Swiss Federal Council enacted TRAF which becomes effective for the Company on January 1, 2020. The impacts of the federal enactment did not have a material impact to the Company’s financial statements. TRAF also provides for parameters which enable the Swiss cantons to adjust tax rates and establish new regulations for companies. As of September 30, 2019, the canton of Schaffhausen had not concluded its public referendum; however, the enactment did take place in October 2019. The Company is still evaluating the impact on the deferred tax assets in the canton of Schaffhausen and the revaluation of these assets could have a noncash impact of less than $100 million to the Company’s financial statements.

[0000833444-19-000051:notes:415]
On December 22, 2017, the “Tax Cuts and Jobs Act” (H.R. 1) was enacted and significantly revised U.S. corporate income tax by, among other things, lowering corporate income tax rates, imposing a one-time transition tax on deemed repatriated earnings of non-U.S. subsidiaries, and implementing a territorial tax system and various base erosion minimum tax provisions.

[0000833444-19-000051:notes:416]
In connection with the Company’s analysis of the impact of the U.S. tax law changes, the Company recorded a provisional net tax charge of $108 million during fiscal 2018 consistent with guidance prescribed by Staff Accounting Bulletin 118.  This provisional net tax charge arises from a benefit of $108 million due to the remeasurement of U.S. deferred tax assets and liabilities, offset by the Company’s tax charge relating to the one-time transition tax on deemed repatriated earnings, inclusive of all relevant taxes, of $216 million. The Company’s estimated benefit of the remeasurement of U.S. deferred tax assets and liabilities increased from $101 million as of December 31, 2017 to $108 million as of September 30, 2018 due to calculation refinement of the Company’s estimated impact. The Company remeasured certain deferred tax assets and liabilities based on the rates at which they are expected to reverse in the future, which is generally 21% or the blended fiscal 2018 rate of 24.5%. The Company’s tax charge for transition tax decreased from $305 million as of December 31, 2017 to $216 million as of September 30, 2018 due to further analysis of the Company’s post-1986 non-U.S. earnings and profits (“E&P”) previously deferred from U.S. federal taxation and refinement of the estimated impact of tax law changes. During fiscal 2019, the Company completed its analysis of all enactment-date income tax effects of the U.S. tax law change with no further adjustment to the provisional amounts recorded as of September 30, 2018.

[0000833444-19-000051:notes:417]
During the fiscal years ended 2019, 2018 and 2017, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-19-000051:notes:418]
Continuing Operations

[0000833444-19-000051:notes:419]
Components of the provision (benefit) for income taxes on continuing operations were as follows (in millions):

[0000833444-19-000051:notes:420]
|  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Current |  |  |  |  |  |
| U.S. federal | $ | (1,025 | ) |  | $ | 476 |  |  | $ | (286 | ) |
| U.S. state | (33 | ) |  | 26 |  |  | (18 | ) |
| Non-U.S. | 213 |  |  | 434 |  |  | 53 |  |
|  | (845 | ) |  | 936 |  |  | (251 | ) |
| Deferred |  |  |  |  |  |
| U.S. federal | 412 |  |  | (372 | ) |  | 523 |  |
| U.S. state | 84 |  |  | (10 | ) |  | 33 |  |
| Non-U.S. | 116 |  |  | (357 | ) |  | 17 |  |
|  | 612 |  |  | (739 | ) |  | 573 |  |
| Income tax provision (benefit) | $ | (233 | ) |  | $ | 197 |  |  | $ | 322 |  |

[0000833444-19-000051:notes:421]
Consolidated U.S. income (loss) from continuing operations before income taxes and noncontrolling interests for the fiscal years ended September 30, 2019, 2018 and 2017 was income (loss) of $(259) million, $261 million and $335 million, respectively. Consolidated non-U.S. income from continuing operations before income taxes and noncontrolling interests for the fiscal years ended September 30, 2019, 2018 and 2017 was income of $1,315 million, $1,285 million and $816 million, respectively.

[0000833444-19-000051:notes:422]
Continuing operations income taxes paid for the fiscal years ended September 30, 2019, 2018 and 2017 were $377 million, $81 million and $497 million, respectively. At September 30, 2019 and 2018, the Company recorded within the continuing operations consolidated statements of financial position in other current assets approximately $1,069 million and $257 million, respectively, of income tax assets. At September 30, 2019 and 2018, the Company recorded within the continuing operations consolidated statements of financial position in other current liabilities approximately $159 million and $336 million, respectively, of accrued income tax liabilities.

[0000833444-19-000051:notes:423]
The Company has not provided U.S. or non-U.S. income taxes on approximately $20.1 billion of outside basis differences of consolidated subsidiaries of Johnson Controls International plc. The Company is indefinitely reinvested in these basis differences. The reduction of the outside basis differences via the sale or liquidation of these subsidiaries and/or distributions could create taxable income. The Company's intent is to reduce the outside basis differences only when it would be tax efficient. Given the numerous ways in which the basis differences may be reduced, it is not practicable to estimate the amount of unrecognized withholding taxes and deferred tax liability on the outside basis differences.

[0000833444-19-000051:notes:424]
Deferred taxes were classified in the consolidated statements of financial position as follows (in millions):

[0000833444-19-000051:notes:425]
|  | September 30, |
|  | 2019 |  | 2018 |
| Other noncurrent assets | 552 |  |  | 1,265 |  |
| Other noncurrent liabilities | (588 | ) |  | (727 | ) |
| Net deferred tax asset (liability) | $ | (36 | ) |  | $ | 538 |  |

[0000833444-19-000051:notes:426]
Temporary differences and carryforwards which gave rise to deferred tax assets and liabilities included (in millions):

[0000833444-19-000051:notes:427]
|  | September 30, |
|  | 2019 |  | 2018 |
| Deferred tax assets |  |  |  |
| Accrued expenses and reserves | $ | 437 |  |  | $ | 458 |  |
| Employee and retiree benefits | 265 |  |  | 178 |  |
| Net operating loss and other credit carryforwards | 5,664 |  |  | 6,350 |  |
| Research and development | 106 |  |  | 93 |  |
|  | 6,472 |  |  | 7,079 |  |
| Valuation allowances | (5,068 | ) |  | (5,088 | ) |
|  | 1,404 |  |  | 1,991 |  |
| Deferred tax liabilities |  |  |  |
| Property, plant and equipment | 139 |  |  | 179 |  |
| Subsidiaries, joint ventures and partnerships | 499 |  |  | 283 |  |
| Intangible assets | 759 |  |  | 915 |  |
| Other, net | 43 |  |  | 76 |  |
|  | 1,440 |  |  | 1,453 |  |
| Net deferred tax asset (liability) | $ | (36 | ) |  | $ | 538 |  |

[0000833444-19-000051:notes:428]
At September 30, 2019, the Company had available net operating loss carryforwards of approximately $23.3 billion, of which $13.8 billion will expire at various dates between 2020 and 2039, and the remainder has an indefinite carryforward period. The Company had available U.S. foreign tax credit carryforwards at September 30, 2019 of $35 million which will expire in 2029. The valuation allowance, generally, is for loss and credit carryforwards for which realization is uncertain because it is unlikely that the losses and/or credits will be realized given the lack of sustained profitability and/or limited carryforward periods in certain countries.

[0000833444-19-000051:notes:429]
During the first quarter of 2018, the Company adopted ASU 2016-09. As a result, the Company recognized deferred tax assets of $179 million in the consolidated statements of financial position related to certain operating loss carryforwards resulting from the exercise of employee stock options and restricted stock vestings on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of October 1, 2017.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-19-000051:notes:430]
SEGMENT INFORMATION

[0000833444-19-000051:notes:431]
ASC 280, "Segment Reporting," establishes the standards for reporting information about segments in financial statements. In applying the criteria set forth in ASC 280, the Company has determined that it has four reportable segments for financial reporting purposes.

[0000833444-19-000051:notes:432]
| • | Building Solutions North America designs, sells, installs, and services HVAC and controls systems, integrated electronic security systems (including monitoring), and integrated fire detection and suppression systems for commercial, industrial, retail, small business, institutional and governmental customers in North America. Building Solutions North America also provides energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and control systems, to non-residential building and industrial applications in the North American marketplace. |

[0000833444-19-000051:notes:433]
| • | Building Solutions EMEA/LA designs, sells, installs, and services HVAC, controls, refrigeration, integrated electronic security, integrated fire detection and suppression systems, and provides technical services to markets in Europe, the Middle East, Africa and Latin America. |

[0000833444-19-000051:notes:434]
| • | Building Solutions Asia Pacific designs, sells, installs, and services HVAC, controls, refrigeration, integrated electronic security, integrated fire detection and suppression systems, and provides technical services to the Asia Pacific marketplace. |

[0000833444-19-000051:notes:435]
| • | Global Products designs and produces heating and air conditioning for residential and commercial applications, and markets products and refrigeration systems to replacement and new construction market customers globally. The Global Products business also designs, manufactures and sells fire protection and security products, including intrusion security, |

[0000833444-19-000051:notes:436]
anti-theft devices, and access control and video management systems, for commercial, industrial, retail, residential, small business, institutional and governmental customers worldwide.  Global Products also includes the Johnson Controls-Hitachi joint venture.

[0000833444-19-000051:notes:437]
During the first quarter of fiscal 2019, the Company determined that the Power Solutions business met the criteria to be classified as a discontinued operation, which required retrospective application to financial information for all periods presented.  Refer to Note 3, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

[0000833444-19-000051:notes:438]
On October 1, 2018, the Company adopted ASU No. 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." The new standard requires the mark-to-market of marketable securities investments previously recorded within accumulated other comprehensive income on the statement of financial position be recorded in the statement of income on a prospective basis beginning as of the adoption date. As these restricted investments do not relate to the underlying operating performance of its business, the Company’s definition of segment earnings excludes the mark-to-market adjustments beginning in the first quarter of fiscal 2019.

[0000833444-19-000051:notes:439]
Management evaluates the performance of its business segments primarily on segment earnings before interest, taxes and amortization ("EBITA"), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and net mark-to-market adjustments related to pension and postretirement plans and restricted asbestos investments.

[0000833444-19-000051:notes:440]
Financial information relating to the Company’s reportable segments is as follows (in millions):

[0000833444-19-000051:notes:441]
|  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Net Sales |  |  |  |  |  |
| Building Solutions North America | $ | 9,031 |  |  | $ | 8,679 |  |  | $ | 8,341 |  |
| Building Solutions EMEA/LA | 3,655 |  |  | 3,696 |  |  | 3,595 |  |
| Building Solutions Asia Pacific | 2,658 |  |  | 2,553 |  |  | 2,444 |  |
| Global Products | 8,624 |  |  | 8,472 |  |  | 8,455 |  |
| Total net sales | $ | 23,968 |  |  | $ | 23,400 |  |  | $ | 22,835 |  |

[0000833444-19-000051:notes:442]
|  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Segment EBITA |  |  |  |  |  |
| Building Solutions North America (1) | $ | 1,153 |  |  | $ | 1,109 |  |  | $ | 1,039 |  |
| Building Solutions EMEA/LA (2) | 368 |  |  | 344 |  |  | 290 |  |
| Building Solutions Asia Pacific (3) | 341 |  |  | 347 |  |  | 323 |  |
| Global Products (4) | 1,179 |  |  | 1,338 |  |  | 1,179 |  |
| Total segment EBITA | $ | 3,041 |  |  | $ | 3,138 |  |  | $ | 2,831 |  |
| Amortization of intangible assets | (377 | ) |  | (376 | ) |  | (481 | ) |
| Corporate expenses (5) | (405 | ) |  | (584 | ) |  | (770 | ) |
| Net financing charges | (350 | ) |  | (401 | ) |  | (466 | ) |
| Restructuring and impairment costs | (235 | ) |  | (255 | ) |  | (347 | ) |
| Net mark-to-market adjustments | (618 | ) |  | 24 |  |  | 384 |  |
| Income from continuing operations before income taxes | $ | 1,056 |  |  | $ | 1,546 |  |  | $ | 1,151 |  |

[0000833444-19-000051:notes:443]
|  | September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Assets |  |  |  |  |  |
| Building Technologies & Solutions (6) |  |  |  |  |  |
| Building Solutions North America (7) | $ | 15,562 |  |  | $ | 15,384 |  |  | $ | 15,228 |  |
| Building Solutions EMEA/LA (8) | 4,786 |  |  | 4,997 |  |  | 4,885 |  |
| Building Solutions Asia Pacific (9) | 2,657 |  |  | 2,743 |  |  | 2,575 |  |
| Global Products (10) | 13,945 |  |  | 14,261 |  |  | 14,018 |  |
|  | 36,950 |  |  | 37,385 |  |  | 36,706 |  |
| Assets held for sale | 158 |  |  | 8,203 |  |  | 10,725 |  |
| Unallocated | 5,179 |  |  | 3,209 |  |  | 4,453 |  |
| Total | $ | 42,287 |  |  | $ | 48,797 |  |  | $ | 51,884 |  |

[0000833444-19-000051:notes:444]
|  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Depreciation/Amortization |  |  |  |  |  |
| Building Technologies & Solutions |  |  |  |  |  |
| Building Solutions North America | $ | 233 |  |  | $ | 236 |  |  | $ | 272 |  |
| Building Solutions EMEA/LA | 112 |  |  | 110 |  |  | 140 |  |
| Building Solutions Asia Pacific | 23 |  |  | 28 |  |  | 37 |  |
| Global Products | 396 |  |  | 390 |  |  | 410 |  |
|  | 764 |  |  | 764 |  |  | 859 |  |
| Corporate | 61 |  |  | 60 |  |  | 60 |  |
| Continuing Operations | 825 |  |  | 824 |  |  | 919 |  |
| Discontinued Operations | 32 |  |  | 261 |  |  | 269 |  |
| Total | $ | 857 |  |  | $ | 1,085 |  |  | $ | 1,188 |  |

[0000833444-19-000051:notes:445]
|  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Capital Expenditures |  |  |  |  |  |
| Building Technologies & Solutions |  |  |  |  |  |
| Building Solutions North America | $ | 119 |  |  | $ | 114 |  |  | $ | 107 |  |
| Building Solutions EMEA/LA | 93 |  |  | 73 |  |  | 98 |  |
| Building Solutions Asia Pacific | 26 |  |  | 26 |  |  | 27 |  |
| Global Products | 310 |  |  | 307 |  |  | 421 |  |
|  | 548 |  |  | 520 |  |  | 653 |  |
| Corporate | 38 |  |  | 125 |  |  | 107 |  |
| Continuing Operations | 586 |  |  | 645 |  |  | 760 |  |
| Discontinued Operations | 197 |  |  | 385 |  |  | 583 |  |
| Total | $ | 783 |  |  | $ | 1,030 |  |  | $ | 1,343 |  |

[0000833444-19-000051:notes:446]
| (1) | Building Solutions North America segment EBITA for the year ended September 30, 2018 and 2017 excludes $20 million and $59 million, respectively, of restructuring and impairment costs. |

[0000833444-19-000051:notes:447]
| (2) | Building Solutions EMEA/LA segment EBITA for the years ended September 30, 2018 and 2017 excludes $56 million and $74 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2019, 2018 and 2017, EMEA/LA segment EBITA includes $12 million, $1 million and $5 million, respectively, of equity income. |

[0000833444-19-000051:notes:448]
| (3) | Building Solutions Asia Pacific segment EBITA for the year ended September 30, 2018 and 2017 excludes $16 million and $16 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2019, 2018 and 2017, Asia Pacific segment EBITA includes $1 million, $1 million and $1 million, respectively, of equity income. |

[0000833444-19-000051:notes:449]
| (4) | Global Products segment EBITA for the years ended September 30, 2019, 2018 and 2017 excludes $235 million, $113 million and $32 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2019, 2018 and 2017, Global Products segment EBITA includes $179 million, $175 million and $151 million, respectively, of equity income. |

[0000833444-19-000051:notes:450]
| (5) | Corporate expenses for the years ended September 30, 2018 and 2017 excludes $50 million and $166 million, respectively, of restructuring and impairment costs. |

[0000833444-19-000051:notes:451]
| (6) | Current year and prior year amounts exclude assets held for sale. Refer to Note 3, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's disposal groups classified as held for sale. |

[0000833444-19-000051:notes:452]
| (7) | Buildings Solutions North America assets as of September 30, 2019, 2018 and 2017 include $8 million, $8 million and $8 million, respectively, of investments in partially-owned affiliates. |

[0000833444-19-000051:notes:453]
| (8) | Building Solutions EMEA/LA assets as of September 30, 2019, 2018 and 2017 include $109 million, $99 million and $107 million, respectively, of investments in partially-owned affiliates. |

[0000833444-19-000051:notes:454]
| (9) | Building Solutions Asia Pacific assets as of September 30, 2019 and 2018 include $6 million and $1 million, respectively, of investments in partially-owned affiliates. |

[0000833444-19-000051:notes:455]
| (10) | Global Products assets as of September 30, 2019, 2018 and 2017 include $730 million, $740 million and $629 million, respectively, of investments in partially-owned affiliates. |

[0000833444-19-000051:notes:456]
In fiscal years 2019, 2018 and 2017 no customer exceeded 10% of consolidated net sales.

[0000833444-19-000051:notes:457]
Geographic Segments

[0000833444-19-000051:notes:458]
Financial information relating to the Company’s operations by geographic area is as follows (in millions):

[0000833444-19-000051:notes:459]
|  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Net Sales |  |  |  |  |  |
| United States | $ | 11,773 |  |  | $ | 11,306 |  |  | $ | 11,353 |  |
| China | 1,424 |  |  | 1,480 |  |  | 1,448 |  |
| Japan | 1,943 |  |  | 1,903 |  |  | 1,816 |  |
| Germany | 629 |  |  | 616 |  |  | 576 |  |
| United Kingdom | 1,042 |  |  | 1,075 |  |  | 872 |  |
| Taiwan | 612 |  |  | 661 |  |  | 625 |  |
| Other foreign | 4,625 |  |  | 4,423 |  |  | 4,222 |  |
| Other European countries | 1,920 |  |  | 1,936 |  |  | 1,923 |  |
| Total | $ | 23,968 |  |  | $ | 23,400 |  |  | $ | 22,835 |  |
| Long-Lived Assets (Year-end) |  |  |  |  |  |
| United States | $ | 1,824 |  |  | $ | 1,879 |  |  | $ | 1,824 |  |
| China | 326 |  |  | 332 |  |  | 171 |  |
| Japan | 228 |  |  | 209 |  |  | 180 |  |
| Germany | 20 |  |  | 19 |  |  | 19 |  |
| United Kingdom | 77 |  |  | 73 |  |  | 109 |  |
| Taiwan | 141 |  |  | 154 |  |  | 169 |  |
| Other foreign | 568 |  |  | 464 |  |  | 595 |  |
| Other European countries | 164 |  |  | 170 |  |  | 274 |  |
| Total | $ | 3,348 |  |  | $ | 3,300 |  |  | $ | 3,341 |  |

[0000833444-19-000051:notes:460]
Net sales attributed to geographic locations are based on the location of the assets producing the sales. Long-lived assets by geographic location consist of net property, plant and equipment.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0000833444-19-000051:notes:461]
NONCONSOLIDATED PARTIALLY-OWNED AFFILIATES

[0000833444-19-000051:notes:462]
Investments in the net assets of nonconsolidated partially-owned affiliates are stated in the "Investments in partially-owned affiliates" line in the consolidated statements of financial position as of September 30, 2019 and 2018. Equity in the net income of nonconsolidated partially-owned affiliates is stated in the "Equity income" line in the consolidated statements of income for the years ended September 30, 2019, 2018 and 2017.

[0000833444-19-000051:notes:463]
The following table presents summarized financial data for the Company’s nonconsolidated partially-owned affiliates. The amounts included in the table below represent 100% of the results of continuing operations of such nonconsolidated partially-owned affiliates accounted for under the equity method.

[0000833444-19-000051:notes:464]
Summarized balance sheet data as of September 30, 2019 and 2018 is as follows (in millions):

[0000833444-19-000051:notes:465]
|  | September 30, |
|  | 2019 |  | 2018 |
| Current assets | $ | 2,941 |  |  | $ | 3,134 |  |
| Noncurrent assets | 1,020 |  |  | 804 |  |
| Total assets | $ | 3,961 |  |  | $ | 3,938 |  |
| Current liabilities | $ | 2,135 |  |  | $ | 2,111 |  |
| Noncurrent liabilities | 157 |  |  | 150 |  |
| Noncontrolling interests | 67 |  |  | 39 |  |
| Shareholders’ equity | 1,602 |  |  | 1,638 |  |
| Total liabilities and shareholders’ equity | $ | 3,961 |  |  | $ | 3,938 |  |

[0000833444-19-000051:notes:466]
Summarized income statement data for the years ended September 30, 2019, 2018 and 2017 is as follows (in millions):

[0000833444-19-000051:notes:467]
|  | Year Ended September 30, |
|  | 2019 |  | 2018 |  | 2017 |
| Net sales | $ | 3,882 |  |  | $ | 3,974 |  |  | $ | 3,113 |  |
| Gross profit | 1,070 |  |  | 1,049 |  |  | 855 |  |
| Net income | 411 |  |  | 390 |  |  | 347 |  |
| Income attributable to noncontrolling interests | 13 |  |  | 10 |  |  | 11 |  |
| Net income attributable to the entity | 398 |  |  | 380 |  |  | 336 |  |


## us-gaap:GuaranteesTextBlock

[0000833444-19-000051:notes:468]
GUARANTEES

[0000833444-19-000051:notes:469]
Certain of the Company's subsidiaries at the business segment level have guaranteed the performance of third-parties and provided financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from the current fiscal year through the completion of such transactions and would typically be triggered in the event of nonperformance. Performance under the guarantees, if required, would not have a material effect on the Company's financial position, results of operations or cash flows.

[0000833444-19-000051:notes:470]
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. A typical warranty program requires that the Company replace defective products within a specified time period from the date of sale. The Company records an estimate for future warranty-related costs based on actual historical return rates and other known factors. Based on analysis of return rates and other factors, the Company’s warranty provisions are adjusted as necessary. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different than those estimates.

[0000833444-19-000051:notes:471]
The Company’s product warranty liability for continuing operations is recorded in the consolidated statements of financial position in deferred revenue or other current liabilities if the warranty is less than one year and in other noncurrent liabilities if the warranty extends longer than one year.

[0000833444-19-000051:notes:472]
The changes in the carrying amount of the Company’s total product warranty liability for continuing operations, including extended warranties for which deferred revenue is recorded, for the fiscal years ended September 30, 2019 and 2018 were as follows (in millions):

[0000833444-19-000051:notes:473]
|  | Year EndedSeptember 30, |
|  | 2019 |  | 2018 |
| Balance at beginning of period | $ | 315 |  |  | $ | 323 |  |
| Accruals for warranties issued during the period | 110 |  |  | 128 |  |
| Accruals from acquisitions and divestitures | 1 |  |  | — |  |
| Accruals related to pre-existing warranties (including changes in estimates) | (39 | ) |  | (14 | ) |
| Settlements made (in cash or in kind) during the period | (101 | ) |  | (120 | ) |
| Currency translation | (1 | ) |  | (2 | ) |
| Balance at end of period | $ | 285 |  |  | $ | 315 |  |

[0000833444-19-000051:notes:474]
As a result of the Tyco merger in the fourth quarter of fiscal 2016, the Company recorded, as part of the acquired liabilities of Tyco, $290 million of post sale contingent tax indemnification liabilities. The liabilities are recorded at fair value and relate to certain tax related matters borne by the buyer of previously divested subsidiaries of Tyco which Tyco has indemnified certain parties and the amounts are probable of being paid. At September 30, 2018, the Company recorded liabilities of $255 million, of which $235 million was related to prior divested businesses and the remainder relates to Tyco’s tax sharing agreements from its 2007 and 2012 spin-off transactions. These are certain guarantees or indemnifications extended among Tyco, Medtronic, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 separation and tax sharing agreements. In fiscal 2019, the majority of tax indemnification liabilities were resolved including a $226 million release as a result of changes to the likelihood of payments due to the expiration of certain statute of limitations.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-19-000051:notes:475]
COMMITMENTS AND CONTINGENCIES

[0000833444-19-000051:notes:476]
Environmental Matters

[0000833444-19-000051:notes:477]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of September 30, 2019, reserves for environmental liabilities for continuing operations totaled $159 million, of which $52 million was recorded within other current liabilities and $107 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $37 million at September 30, 2018, of which $10 million was recorded within other current liabilities and $27 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.

[0000833444-19-000051:notes:478]
Tyco Fire Products L.P. (“Tyco Fire Products”), in coordination with the Wisconsin Department of Natural Resources ("WDNR"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin.  In connection with the assessment, perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluorinated substances ("PFAS") have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC. Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working closely with WDNR to address these issues insofar as they related to this migration.

[0000833444-19-000051:notes:479]
During the third quarter of 2019, the Company increased its environmental reserves which included $140 million related to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).  The Company is not able to estimate a possible loss or range of loss in excess of the established accruals at this time.

[0000833444-19-000051:notes:480]
A substantial portion of the increased reserves relates to remediation resulting from the use of fire-fighting foams containing PFAS at the FTC. The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The reserve was recorded in the quarter ended June 30, 2019 following a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR.

[0000833444-19-000051:notes:481]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS.  The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion.  On August 22, 2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation.

[0000833444-19-000051:notes:482]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers.  Tyco Fire Products voluntarily responded to the WDNR’s letter to request additional necessary information.  On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 3, 2019 letter.  The letter stated that “if you fail to take the actions required by Wis. Stat. § 292.11 to address this contamination, the DNR will move forward under Wis. Stat. § 292.31 to implement the SI workplan and evaluate further environmental enforcement actions and cost recovery under Wis. Stat. § 292.31(8).”  The WDNR issued a further letter regarding the issue on November 4, 2019.  Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations.  The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

[0000833444-19-000051:notes:483]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990.  Its corporate predecessor, Ansul Incorporated (“Ansul”) manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River.  In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. The increase in the reserve related to the Stanton Street Facility was recorded following a further review of the Consent Order, which resulted in the identification of several structural upgrades needed to preserve the effectiveness of prior remediation efforts.

[0000833444-19-000051:notes:484]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At September 30, 2019 and 2018, the Company recorded conditional asset retirement obligations for continuing operations of $30 million and $29 million, respectively.

[0000833444-19-000051:notes:485]
Asbestos Matters

[0000833444-19-000051:notes:486]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-19-000051:notes:487]
As of September 30, 2019, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $141 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $507 million, of which $50 million was recorded in other current liabilities and $457 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $366 million, of which $46 million was recorded in other current assets and $320 million was recorded in other noncurrent assets. Assets included $16 million of cash and $273 million of investments, which have all been designated as

[0000833444-19-000051:notes:488]
restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2019 was $77 million. As of September 30, 2018, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $173 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $550 million, of which $55 million was recorded in other current liabilities and $495 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $377 million, of which $33 million was recorded in other current assets and $344 million was recorded in other noncurrent assets. Assets included $6 million of cash and $281 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2018 was $90 million.

[0000833444-19-000051:notes:489]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-19-000051:notes:490]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-19-000051:notes:491]
Insurable Liabilities

[0000833444-19-000051:notes:492]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At September 30, 2019 and 2018, the insurable liabilities totaled $379 million and $417 million, respectively, of which $99 million and $95 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $258 million and $300 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at September 30, 2019 was $23 million, of which $5 million was recorded within other current assets and $18 million was recorded within other noncurrent assets. The amount of such receivables recorded at September 30, 2018 was $26 million, of which $6 million was recorded within other current assets and $20 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-19-000051:notes:493]
Aqueous Film-Forming Foam ("AFFF") Litigation

[0000833444-19-000051:notes:494]
Two of our subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals PFOS and PFOA and/or other PFAS

[0000833444-19-000051:notes:495]
compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but has stated that it will propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

[0000833444-19-000051:notes:496]
Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-19-000051:notes:497]
In September 2018, the Company filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to the MDL.

[0000833444-19-000051:notes:498]
AFFF Putative Class Actions

[0000833444-19-000051:notes:499]
Chemguard and Tyco Fire Products are named in 24 putative class actions in federal and state courts in Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington New Hampshire, Guam, and Michigan. Each of these cases has been transferred to the MDL. The following putative class actions were filed since the beginning of fiscal year 2019:

[0000833444-19-000051:notes:500]
| • | Grubb v. The 3M Company et al., filed October 30, 2018 in the United States District Court, District of Delaware. |

[0000833444-19-000051:notes:501]
| • | County of Dutchess v. The 3M Company et al., filed October 12, 2018 in the United States District Court, Southern District of New York. |

[0000833444-19-000051:notes:502]
| • | Battisti et al. v. The 3M Company et al., filed December 20, 2018 in the United States District Court, Middle District of Florida. |

[0000833444-19-000051:notes:503]
| • | Jackson et al. v. The 3M Company et al., filed February 5, 2019 in the United States District Court, Western District of Washington. |

[0000833444-19-000051:notes:504]
| • | Smith et al. v. The 3M Company et al., filed May 24, 2019 in the United States District Court, District of New Hampshire. |

[0000833444-19-000051:notes:505]
| • | Cadrette et al. v. The 3M Company et al., filed May 24, 2019 in the United States District Court, Eastern District of Michigan. |

[0000833444-19-000051:notes:506]
| • | Aguon et al. v. The 3M Company et al., filed October 3, 2019, in the United States District Court, District of Guam. |

[0000833444-19-000051:notes:507]
AFFF Individual or Mass Actions

[0000833444-19-000051:notes:508]
There are approximately 61 individual or “mass” actions pending in federal court in Colorado (41 cases), New York (4 cases), Pennsylvania (11 cases), New Mexico (2 cases) and South Carolina (3 cases) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, 15 plaintiffs in Pennsylvania, two plaintiffs in New Mexico, one plaintiff in New Hampshire, and two plaintiffs in Louisiana.  These matters have been transferred to or directly-filed in the MDL. The Company is also on notice of approximately 660 other possible individual product liability claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters, but the Company anticipates that they soon will be.

[0000833444-19-000051:notes:509]
AFFF Municipal Cases

[0000833444-19-000051:notes:510]
Chemguard and Tyco Fire Products are also defendants in 31 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Arizona, California, Colorado, Florida, Massachusetts, New Jersey, New York, Maryland, Ohio, Pennsylvania, and South Carolina.  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.  All of these cases have been transferred to the MDL. The following municipal actions were filed since the beginning of fiscal year 2019:

[0000833444-19-000051:notes:511]
| • | Dutchess County v. The 3M Company et al. filed October 12, 2018 (removed to the United States District Court, Southern District of New York) and styled as a class action. |

[0000833444-19-000051:notes:512]
| • | City of Dayton v. The 3M Company et al., filed October 3, 2018 in the United States District Court, Southern District of Ohio. |

[0000833444-19-000051:notes:513]
| • | City of Stuart v. The 3M Company et al., filed October 18, 2018 in the United States District Court, Southern District of Florida. |

[0000833444-19-000051:notes:514]
| • | City of Tucson and Town of Marana v. The 3M Company et al., filed November 8, 2018 in the Superior Court of the State of Arizona, County of Pima (removed to the United States District Court for the District of Arizona). |

[0000833444-19-000051:notes:515]
| • | New Jersey-American Water Company, Inc. v. The 3M Company et al., filed November 8, 2018 in the United States District Court for the District of New Jersey. |

[0000833444-19-000051:notes:516]
| • | Village of Farmingdale v. The 3M Company et al., filed December 19, 2018 in the Supreme Court of the State of New York, County of Nassau (removed to the United States District Court for the Eastern District of New York). |

[0000833444-19-000051:notes:517]
| • | Town of East Hampton v. The 3M Company et al., filed December 28, 2018 in the Supreme Court of the State of New York, County of Suffolk. |

[0000833444-19-000051:notes:518]
| • | Ridgewood Water v. The 3M Company et al., filed February 25, 2019, in the Superior Court of the State of New Jersey, Bergen County (removed to the United States District Court for the District of New Jersey). |

[0000833444-19-000051:notes:519]
| • | Atlantic City Municipal Utilities Authority v. The 3M Company et al., filed April 10, 2019 in the United States District Court, District of New Jersey. |

[0000833444-19-000051:notes:520]
| • | Town of Vienna v. The 3M Company et al., filed March 30, 2019 in the United States District Court, District of Maryland. |

[0000833444-19-000051:notes:521]
| • | New York American Water Company, Inc. v. The 3M Company et al., filed April 11, 2019 in the United States District Court, Eastern District of New York. |

[0000833444-19-000051:notes:522]
| • | City of Fairbanks v. The 3M Company et al., filed April 26, 2019 in the United States District Court, District of Alaska. |

[0000833444-19-000051:notes:523]
| • | County of Westchester v. The 3M Company et al., filed May 24, 2019 in the United States District Court, Southern District of New York. |

[0000833444-19-000051:notes:524]
| • | Diane Hebrank et al. v. City of Newburgh v. The 3M Company et al., third-party complaint filed June 10, 2019, in the Supreme Court of New York, Orange County. |

[0000833444-19-000051:notes:525]
| • | California-American Water v. The 3M Company et al., direct-filed on June 21, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-19-000051:notes:526]
| • | City of Sioux Falls v. The 3M Company et al., direct-filed on June 26, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-19-000051:notes:527]
| • | Sioux Falls Regional Airport Authority v. The 3M Company et al., direct-filed on June 28, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-19-000051:notes:528]
| • | Warminster Township Municipal Authority v. The 3M Company et al., direct-filed on August 30, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-19-000051:notes:529]
| • | Warrington Township v. The 3M Company et al., direct-filed on August 30, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-19-000051:notes:530]
| • | Horsham Water and Sewer Authority v. The 3M Company et al., direct-filed on August 30, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-19-000051:notes:531]
| • | Security Water District and Pike Peak Community Foundation v. United States et al., filed on March 5, 2019, in the United States District Court, District of Colorado. |

[0000833444-19-000051:notes:532]
| • | Bakman Water Co. v. The 3M Company et al., direct-filed on September 30, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-19-000051:notes:533]
| • | California Water Service Co. v. The 3M Company et al., direct-filed on October 14, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-19-000051:notes:534]
| • | Town of Ayer v. The 3M Company et al., direct-filed on November 4, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

[0000833444-19-000051:notes:535]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly resulting from the use of those products at the Peterson Air Force Base.

[0000833444-19-000051:notes:536]
State Attorneys General Litigation related to AFFF

[0000833444-19-000051:notes:537]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al., No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-19-000051:notes:538]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al., (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al., (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al., (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York.  This suit has not been served yet.

[0000833444-19-000051:notes:539]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. The 3M Company et al., No. G-4801-CI-021804752-000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio.  The lawsuit seeks to recover costs and natural resource damages associated with the contamination.  This lawsuit has been removed to the United States District Court for the Northern District of Ohio and transferred to the MDL.

[0000833444-19-000051:notes:540]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.). All three of these suits have been removed to federal court and transferred to the MDL.

[0000833444-19-000051:notes:541]
In September 2019, the government of Guam filed a lawsuit in the superior court of Guam against a number of manufacturers, including affiliates of the Company, with respect to PFOS and POA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.

[0000833444-19-000051:notes:542]
AFFF Matters Related to the Tyco Fire Products Fire Technology Center in Marinette, Wisconsin

[0000833444-19-000051:notes:543]
Tyco Fire Products and Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFAS (including PFOA/PFOS) contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. A second lawsuit, Duane and Janell Goldsmith individually and on behalf of H.G. and K.G v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) was also filed by a family alleging personal injuries due to contaminated groundwater; this case has been dismissed without prejudice.

[0000833444-19-000051:notes:544]
The Company is vigorously defending the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.

[0000833444-19-000051:notes:545]
Bosch Litigation

[0000833444-19-000051:notes:546]
On March 15, 2019, a German subsidiary of the Company received a complaint from Robert Bosch GmbH (“Bosch”), filed in a German court. The complaint relates to an automotive starter batteries joint venture in which the Company and Bosch were 80/20 parties to this joint venture. At the time the complaint was filed, JCI’s ownership interest in the joint venture was to be transferred to entities controlled by the Purchaser upon consummation of the previously announced sale of the Company’s Power Solutions business.

[0000833444-19-000051:notes:547]
The complaint alleges that certain internal Company reorganization transactions were not in compliance with the arrangements relating to such joint venture. The complaint seeks a declaration that such internal reorganization transactions are void. In the alternative, the complaint seeks a declaration of damages that represent an alleged difference between (i) the value ascribed to the joint venture interests in connection with the Power Solutions sale and (ii) the value that was assigned to those interests in connection with such internal reorganization transactions. The Company believes that it has several strong defenses to the substance of the complaint and that the complaint substantially overstates any reasonable valuation of the joint venture interests. The Company does not believe the complaint has merit, and intends to defend it vigorously. While litigation is inherently uncertain, the Company believes that any ultimate liability that may arise from this proceeding would be immaterial to its business, financial condition and results of operations.

[0000833444-19-000051:notes:548]
Under the previously announced Stock and Asset Purchase Agreement dated November 13, 2018 between the Company and the Purchaser, the Company has agreed to indemnify the Purchaser for any damages that could arise from this litigation. The German court litigation is currently stayed as the parties continue to work towards a resolution of the matter.

[0000833444-19-000051:notes:549]
Other Matters

[0000833444-19-000051:notes:550]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-19-000051:notes:551]
RELATED PARTY TRANSACTIONS

[0000833444-19-000051:notes:552]
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-19-000051:notes:553]
The net sales to and purchases from related parties included in the consolidated statements of income were $217 million and $66 million, respectively, for fiscal 2019; $220 million and $63 million, respectively, for fiscal 2018; and $226 million and $61 million, respectively, for fiscal 2017.

[0000833444-19-000051:notes:554]
The following table sets forth the amount of accounts receivable due from and payable to related parties in the consolidated statements of financial position (in millions):

[0000833444-19-000051:notes:555]
|  |  | September 30, |
|  |  | 2019 |  | 2018 |
| Receivable from related parties |  | $ | 34 |  |  | $ | 36 |  |
| Payable to related parties |  | 6 |  |  | 18 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000833444-19-000051:notes:556]
JOHNSON CONTROLS INTERNATIONAL PLC AND SUBSIDIARIES

[0000833444-19-000051:notes:557]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0000833444-19-000051:notes:558]
(In millions)

[0000833444-19-000051:notes:559]
| Year Ended September 30, | 2019 |  | 2018 |  | 2017 |
| Accounts Receivable - Allowance for Doubtful Accounts |  |  |  |  |  |
| Balance at beginning of period | $ | 169 |  |  | $ | 172 |  |  | $ | 168 |  |
| Provision charged to costs and expenses | 37 |  |  | 14 |  |  | 25 |  |
| Accounts charged off, net of recoveries | (21 | ) |  | (17 | ) |  | (41 | ) |
| Acquisition (divestiture) of businesses | (10 | ) |  | — |  |  | 18 |  |
| Currency translation | (2 | ) |  | — |  |  | 2 |  |
| Balance at end of period | $ | 173 |  |  | $ | 169 |  |  | $ | 172 |  |
| Deferred Tax Assets - Valuation Allowance |  |  |  |  |  |
| Balance at beginning of period | $ | 5,088 |  |  | $ | 3,735 |  |  | $ | 3,290 |  |
| Allowance provision for new operating and other loss carryforwards | 195 |  |  | 1,639 |  |  | 550 |  |
| Allowance provision benefits | (215 | ) |  | (286 | ) |  | (158 | ) |
| Acquisition of businesses | — |  |  | — |  |  | 53 |  |
| Balance at end of period | $ | 5,068 |  |  | $ | 5,088 |  |  | $ | 3,735 |  |
