# JCI MD&A — 0000833444-19-000051


## mdna

[0000833444-19-000051:mdna:1]
| ITEM 7 | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0000833444-19-000051:mdna:2]
General

[0000833444-19-000051:mdna:3]
The Company provides facility systems and services including comfort and energy management for the residential and non-residential buildings markets, security products and services, and fire detection and suppression products and services.

[0000833444-19-000051:mdna:4]
This discussion summarizes the significant factors affecting the consolidated operating results, financial condition and liquidity of the Company for the three-year period ended September 30, 2019. This discussion should be read in conjunction with Item 8, the consolidated financial statements and the notes to consolidated financial statements.

[0000833444-19-000051:mdna:5]
FISCAL YEAR 2019 COMPARED TO FISCAL YEAR 2018

[0000833444-19-000051:mdna:6]
Net Sales

[0000833444-19-000051:mdna:7]
|  | Year Ended September 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Net sales | $ | 23,968 |  |  | $ | 23,400 |  |  | 2 | % |

[0000833444-19-000051:mdna:8]
The increase in net sales was due to higher organic sales ($1,181 million) and acquisitions ($22 million), partially offset by the unfavorable impact of foreign currency translation ($463 million) and lower sales due to business divestitures ($172 million). The increase in organic sales related to higher volumes across all segments. Excluding the impact of foreign currency translation and business acquisitions and divestitures, net sales increased 5% as compared to the prior year. Refer to the "Segment Analysis" below within Item 7 for a discussion of net sales by segment.

[0000833444-19-000051:mdna:9]
Cost of Sales / Gross Profit

[0000833444-19-000051:mdna:10]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Cost of sales | $ | 16,275 |  |  | $ | 15,733 |  |  | 3 | % |
| Gross profit | 7,693 |  |  | 7,667 |  |  | — | % |
| % of sales | 32.1 | % |  | 32.8 | % |  |  |

[0000833444-19-000051:mdna:11]
Cost of sales increased and gross profit as a percentage of sales decreased by 70 basis points. Gross profit increased due to higher volumes across all segments, partially offset by business divestitures and higher operating costs. Net mark-to-market adjustments had a net unfavorable year-over-year impact on cost of sales of $123 million ($128 million charge in fiscal 2019 compared to a $5 million charge in fiscal 2018) primarily due to a decrease in discount rates in the current year. Foreign currency translation had a favorable impact on cost of sales of approximately $304 million. Refer to the "Segment Analysis" below within Item 7 for a discussion of segment earnings before interest, taxes and amortization ("EBITA") by segment.

[0000833444-19-000051:mdna:12]
Selling, General and Administrative Expenses

[0000833444-19-000051:mdna:13]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Selling, general and administrative expenses | $ | 6,244 |  |  | $ | 5,642 |  |  | 11 | % |
| % of sales | 26.1 | % |  | 24.1 | % |  |  |

[0000833444-19-000051:mdna:14]
Selling, general and administrative expenses ("SG&A") increased by $602 million, and SG&A as a percentage of sales increased by 200 basis points. The increase in SG&A was primarily due to net mark-to-market adjustments, a $114 million gain on sale of the Scott Safety business in the Global Products segment in the prior year and a current year environmental charge, partially offset by productivity savings and cost synergies, net of incremental investments, and a current year tax indemnification reserve release. The net mark-to-market adjustments had a net unfavorable year-over-year impact on SG&A of $519 million ($490 million loss in fiscal 2019 compared to a $29 million gain in fiscal 2018) primarily due to a decrease in discount rates in the current year. Foreign currency translation had a favorable impact on SG&A of $94 million.  Refer to the "Segment Analysis" below within Item 7 for a discussion of segment EBITA by segment.

[0000833444-19-000051:mdna:15]
Restructuring and Impairment Costs

[0000833444-19-000051:mdna:16]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Restructuring and impairment costs | $ | 235 |  |  | $ | 255 |  |  | -8 | % |

[0000833444-19-000051:mdna:17]
Refer to Note 16, "Significant Restructuring and Impairment Costs," and Note 17, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for further disclosure related to the Company's restructuring plans and impairment costs.

[0000833444-19-000051:mdna:18]
Net Financing Charges

[0000833444-19-000051:mdna:19]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Net financing charges | $ | 350 |  |  | $ | 401 |  |  | -13 | % |

[0000833444-19-000051:mdna:20]
Refer to Note 9, "Debt and Financing Arrangements," of the notes to consolidated financial statements for further disclosure related to the Company's net financing charges.

[0000833444-19-000051:mdna:21]
Equity Income

[0000833444-19-000051:mdna:22]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Equity income | $ | 192 |  |  | $ | 177 |  |  | 8 | % |

[0000833444-19-000051:mdna:23]
The increase in equity income was primarily due to higher income at certain partially-owned affiliates within the Building Solutions EMEA/LA segment and the Johnson Controls - Hitachi joint venture. Refer to the "Segment Analysis" below within Item 7 for a discussion of segment EBITA by segment.

[0000833444-19-000051:mdna:24]
Income Tax Provision

[0000833444-19-000051:mdna:25]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Income tax provision (benefit) | $ | (233 | ) |  | $ | 197 |  |  | * |
| Effective tax rate | -22 | % |  | 13 | % |  |  |

[0000833444-19-000051:mdna:26]
* Measure not meaningful

[0000833444-19-000051:mdna:27]
28

[0000833444-19-000051:mdna:28]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. The effective rate for continuing operations is below the statutory rate of 12.5% for fiscal 2019 primarily due to tax audit reserve adjustments, the income tax effects of mark-to-market adjustments, a tax indemnification reserve release, the tax benefits of an asset held for sale impairment charge and continuing global tax planning initiatives, partially offset by valuation allowance adjustments as a result of tax law changes, a discrete tax charge related to newly enacted regulations related to U.S. Tax Reform and tax rate differentials. The effective rate for continuing operations is above the statutory rate of 12.5% for fiscal 2018 primarily due to the discrete net impacts of U.S. Tax Reform, final income tax effects of the completed divestiture of the Scott Safety business and valuation allowance adjustments, partially offset by tax audit closures, tax benefits due to change in entity tax status, the benefits of continuing global tax planning initiatives and tax rate differentials. The fiscal 2019 effective tax rate decreased as compared to the fiscal 2018 effective tax rate primarily due to the discrete tax items described below and tax planning initiatives. The fiscal year 2019 and 2018 global tax planning initiatives related primarily to changes in entity tax status, global financing structures and alignment of the Company's global business functions in a tax efficient manner. Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements for further details.

[0000833444-19-000051:mdna:29]
Income From Discontinued Operations, Net of Tax

[0000833444-19-000051:mdna:30]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Income from discontinued operations, net of tax | $ | 4,598 |  |  | $ | 1,034 |  |  | * |

[0000833444-19-000051:mdna:31]
* Measure not meaningful

[0000833444-19-000051:mdna:32]
Refer to Note 3, "Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-19-000051:mdna:33]
Income Attributable to Noncontrolling Interests

[0000833444-19-000051:mdna:34]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 189 |  |  | $ | 174 |  |  | 9 | % |
| Income from discontinued operations attributable to noncontrolling interests | 24 |  |  | 47 |  |  | -49 | % |

[0000833444-19-000051:mdna:35]
The increase in income from continuing operations attributable to noncontrolling interests was primarily due to higher net income at certain partially-owned affiliates within the Global Products segment.

[0000833444-19-000051:mdna:36]
Refer to Note 3, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

[0000833444-19-000051:mdna:37]
Net Income Attributable to Johnson Controls

[0000833444-19-000051:mdna:38]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Net income attributable to Johnson Controls | $ | 5,674 |  |  | $ | 2,162 |  |  | * |

[0000833444-19-000051:mdna:39]
* Measure not meaningful

[0000833444-19-000051:mdna:40]
The increase in net income attributable to Johnson Controls was primarily due to the gain on sale of the Power Solutions business and lower income tax provision, partially offset by higher SG&A. Fiscal 2019 diluted earnings per share attributable to Johnson Controls was $6.49 compared to $2.32 in fiscal 2018.

[0000833444-19-000051:mdna:41]
Comprehensive Income Attributable to Johnson Controls

[0000833444-19-000051:mdna:42]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |
| Comprehensive income attributable to Johnson Controls | $ | 5,350 |  |  | $ | 1,689 |  |  | * |

[0000833444-19-000051:mdna:43]
* Measure not meaningful

[0000833444-19-000051:mdna:44]
The increase in comprehensive income attributable to Johnson Controls was due to higher net income attributable to Johnson Controls ($3,512 million) and an increase in other comprehensive income attributable to Johnson Controls ($149 million) resulting primarily from foreign currency translation adjustments. These year-over-year favorable foreign currency translation adjustments were primarily driven by the weakening of the euro and British pound currencies against the U.S. dollar in the prior year.

[0000833444-19-000051:mdna:45]
SEGMENT ANALYSIS

[0000833444-19-000051:mdna:46]
On October 1, 2018, the Company adopted Accounting Standards Update ("ASU") No. 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." The new standard requires the mark-to-market of marketable securities investments previously recorded within accumulated other comprehensive income on the statement of financial position be recorded in the statement of income on a prospective basis beginning as of the adoption date. As these restricted investments do not relate to the underlying operating performance of its business, the Company’s definition of segment earnings excludes the mark-to-market adjustments beginning in the first quarter of fiscal 2019.

[0000833444-19-000051:mdna:47]
Management evaluates the performance of its business units based primarily on segment EBITA, which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and net mark-to-market adjustments related to pension and postretirement plans and restricted asbestos investments.

[0000833444-19-000051:mdna:48]
|  | Net Salesfor the Year EndedSeptember 30, |  |  |  | Segment EBITAfor the Year EndedSeptember 30, |  |  |
| (in millions) | 2019 |  | 2018 |  | Change |  | 2019 |  | 2018 |  | Change |
| Building Solutions North America | $ | 9,031 |  |  | $ | 8,679 |  |  | 4 | % |  | $ | 1,153 |  |  | $ | 1,109 |  |  | 4 | % |
| Building Solutions EMEA/LA | 3,655 |  |  | 3,696 |  |  | -1 | % |  | 368 |  |  | 344 |  |  | 7 | % |
| Building Solutions Asia Pacific | 2,658 |  |  | 2,553 |  |  | 4 | % |  | 341 |  |  | 347 |  |  | -2 | % |
| Global Products | 8,624 |  |  | 8,472 |  |  | 2 | % |  | 1,179 |  |  | 1,338 |  |  | -12 | % |
|  | $ | 23,968 |  |  | $ | 23,400 |  |  | 2 | % |  | $ | 3,041 |  |  | $ | 3,138 |  |  | -3 | % |

[0000833444-19-000051:mdna:49]
Net Sales:

[0000833444-19-000051:mdna:50]
| • | The increase in Building Solutions North America was due to higher volumes ($380 million), partially offset by the unfavorable impact of foreign currency translation ($28 million). The increase in volumes was primarily attributable to higher installation / service sales. |

[0000833444-19-000051:mdna:51]
| • | The decrease in Building Solutions EMEA/LA was due to the unfavorable impact of foreign currency translation ($206 million) and lower volumes due to business divestitures ($5 million), partially offset by higher volumes ($165 million) and incremental sales related to a business acquisition ($5 million). The increase in volumes was primarily attributable to higher installation / service sales. |

[0000833444-19-000051:mdna:52]
| • | The increase in Building Solutions Asia Pacific was due to higher volumes ($190 million) and incremental sales related to a business acquisition ($1 million), partially offset by the unfavorable impact of foreign currency translation ($86 million). The increase in volumes was primarily attributable to higher installation / service sales. |

[0000833444-19-000051:mdna:53]
| • | The increase in Global Products was due to higher volumes ($446 million) and incremental sales related to business acquisitions ($16 million), partially offset by lower volumes related to business divestitures ($167 million) and the |

[0000833444-19-000051:mdna:54]
unfavorable impact of foreign currency translation ($143 million). The increase in volumes was primarily attributable to higher building management, HVAC and refrigeration equipment, and specialty products sales.

[0000833444-19-000051:mdna:55]
Segment EBITA:

[0000833444-19-000051:mdna:56]
| • | The increase in Building Solutions North America was due to favorable volumes ($92 million) and prior year integration costs ($25 million), partially offset by higher SG&A, including incremental salesforce investments, and unfavorable mix ($45 million), current year integration costs ($26 million) and the unfavorable impact of foreign currency translation ($2 million). |

[0000833444-19-000051:mdna:57]
| • | The increase in Building Solutions EMEA/LA was due to favorable volumes / mix ($57 million), higher equity income ($11 million), prior year integration costs ($6 million) and incremental income related to a business acquisition ($1 million), partially offset by the unfavorable impact of foreign currency translation ($35 million), higher SG&A, including incremental salesforce investments ($12 million) and current year integration costs ($4 million). |

[0000833444-19-000051:mdna:58]
| • | The decrease in Building Solutions Asia Pacific was due to higher SG&A, including incremental salesforce investments ($18 million), the unfavorable impact of foreign currency translation ($8 million), current year integration costs ($2 million) and lower equity income ($1 million), partially offset by net favorable volumes / mix ($23 million). |

[0000833444-19-000051:mdna:59]
| • | The decrease in Global Products was due to a current year environmental charge ($140 million), a prior year gain on sale of Scott Safety ($114 million), higher SG&A and operating expenses, including product investments and prior year gains on business divestitures, net of productivity savings ($32 million), current year integration costs ($30 million), the unfavorable impact of foreign currency translation ($20 million), and lower income due to business divestitures and acquisitions ($19 million). These items were partially offset by favorable volumes / mix ($166 million), prior year integration costs ($27 million) and higher equity income ($3 million). |

[0000833444-19-000051:mdna:60]
FISCAL YEAR 2018 COMPARED TO FISCAL YEAR 2017

[0000833444-19-000051:mdna:61]
Net Sales

[0000833444-19-000051:mdna:62]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Net sales | $ | 23,400 |  |  | $ | 22,835 |  |  | 2 | % |

[0000833444-19-000051:mdna:63]
The increase in net sales was due to higher sales ($1,004 million) and the favorable impact of foreign currency translation ($316 million), partially offset by lower sales due to business divestitures ($755 million). The increase in sales related to higher volumes across all segments. Excluding the impact of foreign currency translation, business divestitures and nonrecurring purchase accounting adjustments, net sales increased 5% as compared to the prior year. Refer to the segment analysis below within Item 7 for a discussion of net sales by segment.

[0000833444-19-000051:mdna:64]
Cost of Sales / Gross Profit

[0000833444-19-000051:mdna:65]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Cost of sales | $ | 15,733 |  |  | $ | 15,305 |  |  | 3 | % |
| Gross profit | 7,667 |  |  | 7,530 |  |  | 2 | % |
| % of sales | 32.8 | % |  | 33.0 | % |  |  |

[0000833444-19-000051:mdna:66]
Cost of sales increased and gross profit as a percentage of sales decreased by 20 basis points. Gross profit increased due to prior year nonrecurring purchase accounting adjustments ($68 million), and higher volumes and favorable mix across all segments, partially offset by business divestitures and higher operating costs. Net mark-to-market adjustments had a net unfavorable year-over-year impact on cost of sales of $45 million ($5 million charge in fiscal 2018 compared to a $40 million gain in fiscal 2017) primarily due to a decrease in U.S. investment returns. Foreign currency translation had an unfavorable impact on cost of sales of approximately $221 million. Refer to the segment analysis below within Item 7 for a discussion of EBITA by segment.

[0000833444-19-000051:mdna:67]
Selling, General and Administrative Expenses

[0000833444-19-000051:mdna:68]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Selling, general and administrative expenses | $ | 5,642 |  |  | $ | 5,723 |  |  | -1 | % |
| % of sales | 24.1 | % |  | 25.1 | % |  |  |

[0000833444-19-000051:mdna:69]
SG&A decreased by $81 million, and SG&A as a percentage of sales decreased by 100 basis points. The decrease in SG&A was primarily due to productivity savings and costs synergies, business divestitures and a gain on sale of the Scott Safety business in the Global Products segment ($114 million). The net favorable year-over-year impact on SG&A resulting from transaction and integration costs was $184 million. Foreign currency translation had an unfavorable impact on SG&A of $66 million. The net mark-to-market adjustments had a net unfavorable year-over-year impact on SG&A of $315 million ($29 million gain in fiscal 2018 compared to a $344 million gain in fiscal 2017) primarily due to a decrease in U.S. investment returns. Refer to the segment analysis below within Item 7 for a discussion of segment EBITA by segment.

[0000833444-19-000051:mdna:70]
Restructuring and Impairment Costs

[0000833444-19-000051:mdna:71]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Restructuring and impairment costs | $ | 255 |  |  | $ | 347 |  |  | -27 | % |

[0000833444-19-000051:mdna:72]
Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for further disclosure related to the Company's restructuring plans.

[0000833444-19-000051:mdna:73]
Net Financing Charges

[0000833444-19-000051:mdna:74]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Net financing charges | $ | 401 |  |  | $ | 466 |  |  | -14 | % |

[0000833444-19-000051:mdna:75]
Refer to Note 9, "Debt and Financing Arrangements," of the notes to consolidated financial statements for further disclosure related to the Company's net financing charges.

[0000833444-19-000051:mdna:76]
Equity Income

[0000833444-19-000051:mdna:77]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Equity income | $ | 177 |  |  | $ | 157 |  |  | 13 | % |

[0000833444-19-000051:mdna:78]
The increase in equity income was primarily due to higher income at the Johnson Controls - Hitachi joint venture. Refer to the segment analysis below within Item 7 for a discussion of segment EBITA by segment.

[0000833444-19-000051:mdna:79]
Income Tax Provision

[0000833444-19-000051:mdna:80]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Income tax provision | $ | 197 |  |  | $ | 322 |  |  | -39 | % |
| Effective tax rate | 13 | % |  | 28 | % |  |  |

[0000833444-19-000051:mdna:81]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. The effective rate for continuing operations is above the statutory rate of 12.5% for fiscal 2018 primarily due to the discrete net impacts of U.S. Tax Reform, final income tax effects of the completed divestiture of the Scott Safety business and valuation allowance adjustments,

[0000833444-19-000051:mdna:82]
partially offset by tax audit closures, tax benefits due to change in entity tax status, the benefits of continuing global tax planning initiatives and tax rate differentials. The effective rate is above the statutory rate of 12.5% for fiscal 2017 primarily due to the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries related to the divestiture of the Scott Safety business, the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the jurisdictional mix of significant restructuring and impairment costs, Tyco Merger transaction and integration costs, purchase accounting adjustments, tax audit closures, a tax benefit due to changes in entity tax status and the benefits of continuing global tax planning initiatives. The fiscal 2018 effective tax rate decreased as compared to the fiscal 2017 effective tax rate primarily due to discrete tax items and tax planning initiatives. The fiscal year 2018 and 2017 global tax planning initiatives related primarily to foreign tax credit planning, changes in entity tax status, global financing structures and alignment of the Company's global business functions in a tax efficient manner. Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements for further details.

[0000833444-19-000051:mdna:83]
Loss From Discontinued Operations, Net of Tax

[0000833444-19-000051:mdna:84]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Income from discontinued operations, net of tax | $ | 1,034 |  |  | $ | 990 |  |  | 4 | % |

[0000833444-19-000051:mdna:85]
Refer to Note 3, "Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-19-000051:mdna:86]
Income Attributable to Noncontrolling Interests

[0000833444-19-000051:mdna:87]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 174 |  |  | $ | 157 |  |  | 11 | % |
| Income from discontinued operations attributable to noncontrolling interests | 47 |  |  | 51 |  |  | -8 | % |

[0000833444-19-000051:mdna:88]
The increase in income from continuing operations attributable to noncontrolling interests was primarily due to higher net income related to the Johnson Controls - Hitachi joint venture.

[0000833444-19-000051:mdna:89]
Refer to Note 3, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

[0000833444-19-000051:mdna:90]
Net Income Attributable to Johnson Controls

[0000833444-19-000051:mdna:91]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Net income attributable to Johnson Controls | $ | 2,162 |  |  | $ | 1,611 |  |  | 34 | % |

[0000833444-19-000051:mdna:92]
The increase in net income attributable to Johnson Controls was primarily due to higher gross profit, lower income tax provision, lower restructuring and impairment costs, lower SG&A and lower net financing charges. Fiscal 2018 diluted earnings per share attributable to Johnson Controls was $2.32 compared to $1.71 in fiscal 2017.

[0000833444-19-000051:mdna:93]
Comprehensive Income Attributable to Johnson Controls

[0000833444-19-000051:mdna:94]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Comprehensive income attributable to Johnson Controls | $ | 1,689 |  |  | $ | 1,710 |  |  | -1 | % |

[0000833444-19-000051:mdna:95]
The decrease in comprehensive income attributable to Johnson Controls was due to a decrease in other comprehensive income attributable to Johnson Controls ($572 million) resulting primarily from unfavorable foreign currency translation adjustments, partially offset by higher net income attributable to Johnson Controls ($551 million). These year-over-year unfavorable foreign currency translation adjustments were primarily driven by the weakening of the British pound and euro currencies against the U.S. dollar.

[0000833444-19-000051:mdna:96]
Segment Analysis

[0000833444-19-000051:mdna:97]
Management evaluates the performance of its business units based primarily on segment EBITA, which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and net mark-to-market adjustments related to pension and postretirement plans and restricted asbestos investments.

[0000833444-19-000051:mdna:98]
|  | Net Salesfor the Year EndedSeptember 30, |  |  |  | Segment EBITAfor the Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Building Solutions North America | $ | 8,679 |  |  | $ | 8,341 |  |  | 4 | % |  | $ | 1,109 |  |  | $ | 1,039 |  |  | 7 | % |
| Building Solutions EMEA/LA | 3,696 |  |  | 3,595 |  |  | 3 | % |  | 344 |  |  | 290 |  |  | 19 | % |
| Building Solutions Asia Pacific | 2,553 |  |  | 2,444 |  |  | 4 | % |  | 347 |  |  | 323 |  |  | 7 | % |
| Global Products | 8,472 |  |  | 8,455 |  |  | — | % |  | 1,338 |  |  | 1,179 |  |  | 13 | % |
|  | $ | 23,400 |  |  | $ | 22,835 |  |  | 2 | % |  | $ | 3,138 |  |  | $ | 2,831 |  |  | 11 | % |

[0000833444-19-000051:mdna:99]
* Measure not meaningful

[0000833444-19-000051:mdna:100]
Net Sales:

[0000833444-19-000051:mdna:101]
| • | The increase in Building Solutions North America was due to higher volumes ($343 million) and the favorable impact of foreign currency translation ($20 million), partially offset by the impact of prior year nonrecurring purchase accounting adjustments ($25 million). The increase in volumes was primarily attributable to higher HVAC, controls, fire and security sales. |

[0000833444-19-000051:mdna:102]
| • | The increase in Building Solutions EMEA/LA was due to the favorable impact of foreign currency translation ($132 million), higher volumes ($63 million) and incremental sales related to a business acquisition ($2 million), partially offset by lower volumes related to a business divestiture ($80 million) and the impact of prior year nonrecurring purchase accounting adjustments ($16 million). The increase in volumes was primarily attributable to strong service growth which was positive across all regions led by Europe and Latin America. |

[0000833444-19-000051:mdna:103]
| • | The increase in Building Solutions Asia Pacific was due to higher volumes ($61 million), the favorable impact of foreign currency translation ($61 million) and the impact of prior year nonrecurring purchase accounting adjustments ($1 million), partially offset by lower volumes related to a business divestiture ($14 million). The increase in volumes was primarily attributable to higher service sales. |

[0000833444-19-000051:mdna:104]
| • | The increase in Global Products was due to higher volumes ($571 million), the favorable impact of foreign currency translation ($103 million) and the impact of prior year nonrecurring purchase accounting adjustments ($6 million), partially offset by lower volumes related to business divestitures ($663 million). The increase in volumes was primarily attributable to higher building management, HVAC and refrigeration equipment, and specialty products sales. |

[0000833444-19-000051:mdna:105]
Segment EBITA:

[0000833444-19-000051:mdna:106]
| • | The increase in Building Solutions North America was due to favorable volumes / mix ($100 million), prior year integration costs ($42 million), prior year transaction costs ($13 million), and the favorable impact of foreign currency translation ($1 million), partially offset by higher SG&A including incremental salesforce investments ($37 million), current year integration costs ($25 million) and prior year nonrecurring purchase accounting adjustments ($24 million). |

[0000833444-19-000051:mdna:107]
| • | The increase in Building Solutions EMEA/LA was due to a prior year unfavorable arbitration award ($50 million), favorable volumes / mix ($26 million), lower SG&A ($14 million), the favorable impact of foreign currency translation ($7 million), prior year integration costs ($6 million) and prior year transaction costs ($5 million), partially offset by prior |

[0000833444-19-000051:mdna:108]
34

[0000833444-19-000051:mdna:109]
year nonrecurring purchase accounting adjustments ($23 million), incremental salesforce investments ($14 million), current year integration costs ($6 million), higher operating costs ($5 million), lower equity income ($4 million) and lower income due to a business divestiture ($2 million).

[0000833444-19-000051:mdna:110]
| • | The increase in Building Solutions Asia Pacific was due to higher volumes / mix ($33 million), prior year integration costs ($5 million), prior year transaction costs ($2 million), prior year nonrecurring purchase accounting adjustments ($2 million) and the favorable impact of foreign currency translation ($1 million), partially offset by higher SG&A including incremental salesforce investments ($15 million), and unfavorable pricing ($4 million). |

[0000833444-19-000051:mdna:111]
| • | The increase in Global Products was due to favorable volumes / mix ($219 million), a gain on sale of Scott Safety ($114 million), prior year nonrecurring purchase accounting adjustments ($71 million), higher equity income ($25 million), prior year integration costs ($25 million), the favorable impact of foreign currency translation ($20 million) and prior year transaction costs ($13 million). These items were partially offset by lower income due to business divestitures ($167 million), higher SG&A and operating expenses including planned incremental global product and channel investments, partially offset by productivity savings and gains on business divestitures ($134 million), and current year integration costs ($27 million). |

[0000833444-19-000051:mdna:112]
GOODWILL, LONG-LIVED ASSETS AND OTHER INVESTMENTS

[0000833444-19-000051:mdna:113]
Goodwill at September 30, 2019 was $18.2 billion, $0.2 billion lower than the prior year. The decrease was primarily due to the impact of foreign currency translation.

[0000833444-19-000051:mdna:114]
Goodwill reflects the cost of an acquisition in excess of the fair values assigned to identifiable net assets acquired. The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s reportable segments or one level below the reportable segments in certain instances, using a fair value method based on management’s judgments and assumptions or third party valuations. The fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. In estimating the fair value, the Company uses multiples of earnings based on the average of published multiples of earnings of comparable entities with similar operations and economic characteristics and applies to the Company's average of historical and future financial results. In certain instances, the Company uses discounted cash flow analyses or estimated sales price to further support the fair value estimates. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The estimated fair value is then compared with the carrying amount of the reporting unit, including recorded goodwill. The Company is subject to financial statement risk to the extent that the carrying amount exceeds the estimated fair value.

[0000833444-19-000051:mdna:115]
The assumptions included in the impairment tests require judgment, and changes to these inputs could impact the results of the calculations. The primary assumptions used in the impairment tests were management's projections of future cash flows. Although the Company's cash flow forecasts are based on assumptions that are considered reasonable by management and consistent with the plans and estimates management is using to operate the underlying businesses, there are significant judgments in determining the expected future cash flows attributable to a reporting unit.

[0000833444-19-000051:mdna:116]
Indefinite-lived other intangible assets are also subject to at least annual impairment testing. A considerable amount of management judgment and assumptions are required in performing the impairment tests.

[0000833444-19-000051:mdna:117]
While the Company believes the judgments and assumptions used in the impairment tests are reasonable and no impairments of goodwill or indefinite-lived assets existed during fiscal years 2019, 2018 and 2017, different assumptions could change the estimated fair values and, therefore, impairment charges could be required, which could be material to the consolidated financial statements.

[0000833444-19-000051:mdna:118]
The Company reviews long-lived assets, including tangible assets and other intangible assets with definitive lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of Software to be Sold, Leased, or Marketed."  ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. ASC 350-30 requires intangible assets acquired in a business combination that are used in research and development activities to be considered indefinite lived until the completion or abandonment of the associated

[0000833444-19-000051:mdna:119]
research and development efforts. During the period that those assets are considered indefinite lived, they shall not be amortized but shall be tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired.  If the carrying amount of an intangible asset exceeds its fair value, an entity shall recognize an impairment loss in an amount equal to that excess. ASC 985-20 requires the unamortized capitalized costs of a computer software product be compared to the net realizable value of that product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset shall be written off.

[0000833444-19-000051:mdna:120]
In fiscal 2019, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with the plans to dispose of a business within its Global Products segment that met the criteria to be classified as held for sale. Assets and liabilities held for sale are required to be recorded at the lower of carrying value or fair value less any costs to sell. Accordingly, the Company recorded an impairment charge of $235 million within restructuring and impairment costs in the consolidated statements of income in fiscal 2019 to write down the carrying value of the assets held for sale to fair value less any costs to sell. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-19-000051:mdna:121]
In fiscal 2018, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2018. As a result, the Company reviewed the long-lived assets for impairment and recorded $36 million of asset impairment charges within restructuring and impairment costs in the consolidated statements of income. Of the total impairment charges, $31 million related to the Global Products segment and $5 million related to Corporate assets. In addition, the Company recorded $6 million of asset impairments within discontinued operations related to the Power Solutions segment in fiscal 2018. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-19-000051:mdna:122]
In fiscal 2017, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2017. As a result, the Company reviewed the long-lived assets for impairment and recorded $70 million of asset impairment charges within restructuring and impairment costs on the consolidated statements of income. Of the total impairment charges, $30 million related to the Building Solutions North America segment, $20 million related to the Global Products segment, $19 million related to Corporate assets and $1 million related to the Building Solutions Asia Pacific segment. In addition, the Company recorded $7 million of asset impairments within discontinued operations related to the Power Solutions segment in fiscal 2017. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-19-000051:mdna:123]
Investments in partially-owned affiliates ("affiliates") at September 30, 2019 were $853 million, $5 million higher than the prior year.

[0000833444-19-000051:mdna:124]
36

[0000833444-19-000051:mdna:125]
LIQUIDITY AND CAPITAL RESOURCES

[0000833444-19-000051:mdna:126]
Working Capital

[0000833444-19-000051:mdna:127]
|  | September 30, 2019 |  | September 30, 2018 |  |  |
| (in millions) |  |  | Change |
| Current assets | $ | 12,393 |  |  | $ | 11,823 |  |  |  |
| Current liabilities | (9,070 | ) |  | (11,250 | ) |  |  |
|  | 3,323 |  |  | 573 |  |  | * |  |
| Less: Cash | (2,805 | ) |  | (185 | ) |  |  |
| Add: Short-term debt | 10 |  |  | 1,306 |  |  |  |
| Add: Current portion of long-term debt | 501 |  |  | 1 |  |  |  |
| Less: Assets held for sale | (98 | ) |  | (3,015 | ) |  |  |
| Add: Liabilities held for sale | 44 |  |  | 1,791 |  |  |  |
| Working capital (as defined) | $ | 975 |  |  | $ | 471 |  |  | * |  |
| Accounts receivable | $ | 5,770 |  |  | $ | 5,622 |  |  | 3 | % |
| Inventories | 1,814 |  |  | 1,819 |  |  | — | % |
| Accounts payable | 3,582 |  |  | 3,407 |  |  | 5 | % |
| * Measure not meaningful |  |  |  |  |  |

[0000833444-19-000051:mdna:128]
| • | The Company defines working capital as current assets less current liabilities, excluding cash, short-term debt, the current portion of long-term debt, and the current portions of assets and liabilities held for sale. Management believes that this measure of working capital, which excludes financing-related items and businesses to be divested, provides a more useful measurement of the Company’s operating performance. |

[0000833444-19-000051:mdna:129]
| • | The increase in working capital at September 30, 2019 as compared to September 30, 2018, was primarily due to an increase in accounts receivable due to organic sales growth and other current assets, partially offset by an increase in accounts payable due to timing and mix of supplier payments, and other current liabilities. |

[0000833444-19-000051:mdna:130]
| • | The Company’s days sales in accounts receivable at September 30, 2019 were 67, a slight decrease from 68 at September 30, 2018. There has been no significant adverse change in the level of overdue receivables or significant changes in revenue recognition methods. |

[0000833444-19-000051:mdna:131]
| • | The Company’s inventory turns for the year ended September 30, 2019 were slightly higher than the comparable period ended September 30, 2018 primarily due to changes in inventory production levels. |

[0000833444-19-000051:mdna:132]
| • | Days in accounts payable at September 30, 2019 were 72 days, the same as at the comparable period ended September 30, 2018. |

[0000833444-19-000051:mdna:133]
Cash Flows From Continuing Operations

[0000833444-19-000051:mdna:134]
|  | Year Ended September 30, |
| (in millions) | 2019 |  | 2018 |
| Cash provided by operating activities | $ | 1,743 |  |  | $ | 1,520 |  |
| Cash provided (used) by investing activities | (533 | ) |  | 1,568 |  |
| Cash used by financing activities | (10,519 | ) |  | (3,749 | ) |

[0000833444-19-000051:mdna:135]
| • | The increase in cash provided by operating activities was primarily due to lower restructuring payments and higher partially-owned affiliate dividends. |

[0000833444-19-000051:mdna:136]
| • | The increase in cash used by investing activities was primarily due to net cash proceeds received from the Scott Safety business divestiture in the prior year, partially offset by lower capital expenditures. |

[0000833444-19-000051:mdna:137]
| • | The increase in cash used by financing activities was primarily due to higher stock repurchases and higher net repayments of debt. |

[0000833444-19-000051:mdna:138]
Capitalization

[0000833444-19-000051:mdna:139]
|  | September 30, 2019 |  | September 30, 2018 |  |  |
| (in millions) |  |  | Change |
| Short-term debt | $ | 10 |  |  | $ | 1,306 |  |  |  |
| Current portion of long-term debt | 501 |  |  | 1 |  |  |  |
| Long-term debt | 6,708 |  |  | 9,623 |  |  |  |
| Total debt | $ | 7,219 |  |  | $ | 10,930 |  |  | -34 | % |
| Less: cash and cash equivalents | 2,805 |  |  | 185 |  |  |  |
| Total net debt | $ | 4,414 |  |  | $ | 10,745 |  |  | -59 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 19,766 |  |  | 21,164 |  |  | -7 | % |
| Total capitalization | $ | 24,180 |  |  | $ | 31,909 |  |  | -24 | % |
| Total net debt as a % of total capitalization | 18.3 | % |  | 33.7 | % |  |  |

[0000833444-19-000051:mdna:140]
| • | Net debt and net debt as a percentage of total capitalization are non-GAAP financial measures. The Company believes the percentage of total net debt to total capitalization is useful to understanding the Company’s financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders. |

[0000833444-19-000051:mdna:141]
| • | In the third quarter of fiscal 2019, the Company began deploying the net cash proceeds from the Power Solution sale, which included a reduction in debt of approximately $3.4 billion and share repurchases. The debt reduction included short-term and long-term debt repayments, including a $1.5 billion debt tender as further described below. |

[0000833444-19-000051:mdna:142]
| • | The Company believes its capital resources and liquidity position at September 30, 2019 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, stock repurchases, minimum pension contributions, debt maturities and any potential acquisitions in fiscal 2020 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company is unable to issue commercial paper, it would have the ability to draw on its $2.0 billion revolving credit facility. The facility matures in August 2020. There were no draws on the revolving credit facility as of September 30, 2019 and 2018. The Company also selectively makes use of short-term credit lines other than its revolving credit facility. The Company, as of September 30, 2019, could borrow up to $2.8 billion based on committed credit lines. In addition, the Company held cash and cash equivalents of $2.8 billion as of September 30, 2019. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future. |

[0000833444-19-000051:mdna:143]
| • | In June 2019, the Company completed a "modified Dutch auction" tender offer to repurchase approximately $4.0 billion of its ordinary shares at a price of $39.25 per share. |

[0000833444-19-000051:mdna:144]
| • | In May 2019, the Company completed the debt tender offer to purchase up to $1.5 billion in aggregate principal amount of certain of its outstanding notes for $1.6 billion total consideration. The Company recognized a loss on the extinguishment of debt of $60 million, which was recorded within the net financing charges in the consolidated statements of income. |

[0000833444-19-000051:mdna:145]
| • | The Company’s debt financial covenant in its revolving credit facility requires a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of September 30, 2019, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures, governing its notes, and expect to remain in compliance |

[0000833444-19-000051:mdna:146]
38

[0000833444-19-000051:mdna:147]
for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-19-000051:mdna:148]
| • | The Company earns a significant amount of its income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances. However, in fiscal 2019, the Company provided income tax expense related to a change in the Company's assertion over the outside basis differences of the Company’s investment in certain subsidiaries as a result of the planned divestiture of the Power Solutions business. Also, in fiscal 2018, due to U.S. Tax Reform, the Company provided income tax related to the change in the Company’s assertion over the outside basis difference of certain non-U.S. subsidiaries owned directly or indirectly by U.S. subsidiaries. Under U.S. Tax Reform, the U.S. has enacted a tax system that provides an exemption for dividends received by U.S. corporations from 10% or more owned non-U.S. corporations. However, certain non-U.S, U.S. state and withholding taxes may still apply when closing an outside basis difference via distribution or other transactions. In addition, in fiscal 2017, the Company provided income tax expense related to a change in the Company’s assertion over the outside basis difference of the Scott Safety business as a result of the pending divestiture as well as the outside basis of certain nonconsolidated subsidiaries. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. Except as noted, the Company’s intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at the Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings. |

[0000833444-19-000051:mdna:149]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2018 and recorded $255 million of restructuring and impairment costs for continuing operations in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2018 restructuring plan will reduce annual operating costs for continuing operations by approximately $300 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in 2020. For fiscal 2019, the savings, net of execution costs, were approximately 70% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in 2020. The restructuring plan reserve balance of $102 million at September 30, 2019 is expected to be paid in cash. |

[0000833444-19-000051:mdna:150]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2017 and recorded $347 million of restructuring and impairment costs for continuing operations in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2017 restructuring plan will reduce annual operating costs from continuing operations for continuing operations by approximately $260 million, which is primarily the result of lower cost of sales and SG&A expenses due to reduced employee-related costs, depreciation and amortization expense. The Company substantially realized the annual benefit of these actions in fiscal 2019. The restructuring actions are expected to be substantially complete in fiscal 2020. The restructuring plan reserve balance of $61 million at September 30, 2019 is expected to be paid in cash. |

[0000833444-19-000051:mdna:151]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations to address the softness in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2016 and recorded $222 million of restructuring and impairment costs for continuing operations in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments and change-in-control payments. The restructuring action has reduced annual operating costs for continuing operations by |

[0000833444-19-000051:mdna:152]
39

[0000833444-19-000051:mdna:153]
approximately $127 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The restructuring actions are substantially complete, and final payments are expected to be made in fiscal 2020. The restructuring plan reserve balance of $32 million at September 30, 2019 is expected to be paid in cash.

[0000833444-19-000051:mdna:154]
| • | Refer to Note 9, "Debt and Financing Arrangements," of the notes to consolidated financial statements for additional information on items impacting capitalization. |

[0000833444-19-000051:mdna:155]
A summary of the Company’s significant contractual obligations for continuing operations as of September 30, 2019 is as follows (in millions):

[0000833444-19-000051:mdna:156]
|  | Total |  | 2020 |  | 2021-2022 |  | 2023-2024 |  | 2025and Beyond |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Long-term debt* | $ | 7,240 |  |  | $ | 501 |  |  | $ | 1,500 |  |  | $ | 1,486 |  |  | $ | 3,753 |  |
| Interest on long-term debt* | 3,834 |  |  | 220 |  |  | 384 |  |  | 358 |  |  | 2,872 |  |
| Operating leases | 1,193 |  |  | 352 |  |  | 487 |  |  | 182 |  |  | 172 |  |
| Purchase obligations | 1,072 |  |  | 907 |  |  | 147 |  |  | 18 |  |  | — |  |
| Pension and postretirement contributions | 415 |  |  | 54 |  |  | 69 |  |  | 76 |  |  | 216 |  |
| Total contractual cash obligations | $ | 13,754 |  |  | $ | 2,034 |  |  | $ | 2,587 |  |  | $ | 2,120 |  |  | $ | 7,013 |  |

[0000833444-19-000051:mdna:157]
* Refer to Note 9, "Debt and Financing Arrangements," of the notes to consolidated financial statements for information related to the Company's long-term debt.

[0000833444-19-000051:mdna:158]
CRITICAL ACCOUNTING ESTIMATES AND POLICIES

[0000833444-19-000051:mdna:159]
The Company prepares its consolidated financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). This requires management to make estimates and assumptions that affect reported amounts and related disclosures. Actual results could differ from those estimates. The following policies are considered by management to be the most critical in understanding the judgments that are involved in the preparation of the Company’s consolidated financial statements and the uncertainties that could impact the Company’s results of operations, financial position and cash flows.

[0000833444-19-000051:mdna:160]
Revenue Recognition

[0000833444-19-000051:mdna:161]
The Company recognizes revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. The Company does not adjust the promised amount of consideration for the effects of a significant financing component as at contract inception the Company expects to receive the payment within twelve months of transfer of goods or services.

[0000833444-19-000051:mdna:162]
The Company enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized over time on a straight-line basis over the respective contract term.

[0000833444-19-000051:mdna:163]
The Company also sells certain HVAC and refrigeration products and services in bundled arrangements with multiple performance obligations, such as equipment, commissioning, service labor and extended warranties. Approximately four to twelve months separate the timing of the first deliverable until the last piece of equipment is delivered, and there may be extended warranty arrangements with duration of one to five years commencing upon the end of the standard warranty period. In addition, the Company sells security monitoring systems that may have multiple performance obligations, including equipment, installation, monitoring services and maintenance agreements. Revenues associated with sale of equipment and related installations are recognized over time on a cost-to-cost input method, while the revenue for monitoring and maintenance services are recognized over time as services are rendered. The transaction price is allocated to each performance obligation based on the relative selling price method. In order to estimate relative selling price, market data and transfer price studies are utilized. If the standalone selling price is not directly observable, the Company estimates the standalone selling price using an adjusted market assessment approach or expected cost plus margin approach. For transactions in which the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized over time on a straight-line basis over the contract term. Non-refundable fees received in connection with the initiation of a monitoring contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the contract.

[0000833444-19-000051:mdna:164]
In all other cases, the Company recognizes revenue at the point in time when control over the goods or services transfers to the customer.

[0000833444-19-000051:mdna:165]
The Company considers the contractual consideration payable by the customer and assesses variable consideration that may affect the total transaction price, including discounts, rebates, refunds, credits or other similar sources of variable consideration, when determining the transaction price of each contract. The Company includes variable consideration in the estimated transaction price when it is probable that significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. These estimates are based on the amount of consideration that the Company expects to be entitled to.

[0000833444-19-000051:mdna:166]
Shipping and handling costs billed to customers are included in sales and the related costs are included in cost of sales when control transfers to the customer. The Company presents amounts collected from customers for sales and other taxes net of the related amounts remitted. Refer to Note 4, "Revenue Recognition," of the notes to consolidated financial statements for disclosure of the Company's revenue recognition activity.

[0000833444-19-000051:mdna:167]
Goodwill and Indefinite-Lived Intangible Assets

[0000833444-19-000051:mdna:168]
Goodwill reflects the cost of an acquisition in excess of the fair values assigned to identifiable net assets acquired. The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s reportable segments or one level below the reportable segments in certain instances, using a fair value method based on management’s judgments and assumptions or third party valuations. The fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. In estimating the fair value, the Company uses multiples of earnings based on the average of published multiples of earnings of comparable entities with similar operations and economic characteristics and applies to the Company's average of historical and future financial results. In certain instances, the Company uses discounted cash flow analyses or estimated sales price to further support the fair value estimates. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The estimated fair value is then compared with the carrying amount of the reporting unit, including recorded goodwill. The Company is subject to financial statement risk to the extent that the carrying amount exceeds the estimated fair value. Refer to Note 7, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for information regarding the goodwill impairment testing performed in fiscal years 2019, 2018 and 2017.

[0000833444-19-000051:mdna:169]
Indefinite-lived intangible assets are also subject to at least annual impairment testing. Indefinite-lived intangible assets consist of trademarks and tradenames and are tested for impairment using a relief-from-royalty method. A considerable amount of management judgment and assumptions are required in performing the impairment tests.

[0000833444-19-000051:mdna:170]
Impairment of Long-Lived Assets

[0000833444-19-000051:mdna:171]
The Company reviews long-lived assets, including tangible assets and other intangible assets with definitive lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of Software to be Sold, Leased, or Marketed." ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the

[0000833444-19-000051:mdna:172]
undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. ASC 350-30 requires intangible assets acquired in a business combination that are used in research and development activities be considered indefinite lived until the completion or abandonment of the associated research and development efforts. During the period that those assets are considered indefinite lived, they shall not be amortized but shall be tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired. If the carrying amount of an intangible asset exceeds its fair value, an entity shall recognize an impairment loss in an amount equal to that excess. ASC 985-20 requires the unamortized capitalized costs of a computer software product be compared to the net realizable value of that product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset shall be written off. Refer to Note 17, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for information regarding the impairment testing performed in fiscal years 2019, 2018 and 2017.

[0000833444-19-000051:mdna:173]
Employee Benefit Plans

[0000833444-19-000051:mdna:174]
The Company provides a range of benefits to its employees and retired employees, including pensions and postretirement benefits. Plan assets and obligations are measured annually, or more frequently if there is a significant remeasurement event, based on the Company’s measurement date utilizing various actuarial assumptions such as discount rates, assumed rates of return, compensation increases, turnover rates and health care cost trend rates as of that date. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends when appropriate.

[0000833444-19-000051:mdna:175]
The Company utilizes a mark-to-market approach for recognizing pension and postretirement benefit expenses, including measuring the market related value of plan assets at fair value and recognizing actuarial gains and losses in the fourth quarter of each fiscal year or at the date of a remeasurement event. Refer to Note 15, "Retirement Plans," of the notes to consolidated financial statements for disclosure of the Company's pension and postretirement benefit plans.

[0000833444-19-000051:mdna:176]
U.S. GAAP requires that companies recognize in the statement of financial position a liability for defined benefit pension and postretirement plans that are underfunded or unfunded, or an asset for defined benefit pension and postretirement plans that are overfunded. U.S. GAAP also requires that companies measure the benefit obligations and fair value of plan assets that determine a benefit plan’s funded status as of the date of the employer’s fiscal year end.

[0000833444-19-000051:mdna:177]
The Company considers the expected benefit payments on a plan-by-plan basis when setting assumed discount rates. As a result, the Company uses different discount rates for each plan depending on the plan jurisdiction, the demographics of participants and the expected timing of benefit payments. For the U.S. pension and postretirement plans, the Company uses a discount rate provided by an independent third party calculated based on an appropriate mix of high quality bonds. For the non-U.S. pension and postretirement plans, the Company consistently uses the relevant country specific benchmark indices for determining the various discount rates. The Company’s weighted average discount rate on U.S. pension plans was 2.95% and 4.10% at September 30, 2019 and 2018, respectively. The Company’s weighted average discount rate on postretirement plans was 2.90% and 3.80% at September 30, 2019 and 2018, respectively. The Company’s weighted average discount rate on non-U.S. pension plans was 1.50% and 2.45% at September 30, 2019 and 2018, respectively.

[0000833444-19-000051:mdna:178]
In estimating the expected return on plan assets, the Company considers the historical returns on plan assets, adjusted for forward-looking considerations, inflation assumptions and the impact of the active management of the plans’ invested assets. Reflecting the relatively long-term nature of the plans’ obligations, approximately 28% of the plans’ assets are invested in equity securities and 59% in fixed income securities, with the remainder primarily invested in alternative investments. For the years ending September 30, 2019 and 2018, the Company’s expected long-term return on U.S. pension plan assets used to determine net periodic benefit cost was 7.10% and 7.50%, respectively. The actual rate of return on U.S. pension plans was above 7.10% in fiscal year 2019 and below 7.50% in fiscal year 2018. For the years ending September 30, 2019 and 2018, the Company’s weighted average expected long-term return on non-U.S. pension plan assets was 5.20% and 5.35%, respectively. The actual rate of return on non-U.S. pension plans was above 5.20% in fiscal year 2019 and below 5.35% in fiscal year 2018. For the years ending September 30, 2019 and 2018, the Company’s weighted average expected long-term return on postretirement plan assets was 5.65%. The actual rate of return on postretirement plan assets was below 5.65% in fiscal year 2019 and 2018.

[0000833444-19-000051:mdna:179]
Beginning in fiscal 2020, the Company believes the long-term rate of return will approximate 6.90%, 5.20% and 5.70% for U.S. pension, non-U.S. pension and postretirement plans, respectively. Any differences between actual investment results and the expected long-term asset returns will be reflected in net periodic benefit costs in the fourth quarter of each fiscal year or at the date of a significant remeasurement event. If the Company’s actual returns on plan assets are less than the Company’s expectations, additional contributions may be required.

[0000833444-19-000051:mdna:180]
In fiscal 2019, total employer contributions for continuing operations to the defined benefit pension plans were $50 million, none of which were voluntary contributions made by the Company. The Company expects to contribute approximately $50 million in cash to its defined benefit pension plans in fiscal 2020. In fiscal 2019, total employer contributions for continuing operations to the postretirement plans were $3 million. The Company expects to contribute approximately $4 million in cash to its postretirement plans in fiscal 2020.

[0000833444-19-000051:mdna:181]
Based on information provided by its independent actuaries and other relevant sources, the Company believes that the assumptions used are reasonable; however, changes in these assumptions could impact the Company’s financial position, results of operations or cash flows.

[0000833444-19-000051:mdna:182]
Loss Contingencies

[0000833444-19-000051:mdna:183]
Accruals are recorded for various contingencies including legal proceedings, environmental matters, self-insurance and other claims that arise in the normal course of business. The accruals are based on judgment, the probability of losses and, where applicable, the consideration of opinions of internal and/or external legal counsel and actuarially determined estimates. Additionally, the Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-19-000051:mdna:184]
The Company is subject to laws and regulations relating to protecting the environment. The Company provides for expenses associated with environmental remediation obligations when such amounts are probable and can be reasonably estimated. Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements.

[0000833444-19-000051:mdna:185]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company records receivables from third party insurers when recovery has been determined to be probable. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-19-000051:mdna:186]
Asbestos-Related Contingencies and Insurance Receivables

[0000833444-19-000051:mdna:187]
The Company and certain of its subsidiaries along with numerous other companies are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-19-000051:mdna:188]
In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable. The Company's estimate of asbestos-related insurance recoveries represents estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims discounted to present value. In determining the amount of insurance recoverable, the Company considers available insurance, allocation methodologies, solvency and creditworthiness of the insurers. Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements for a discussion on management's judgments applied in the recognition and measurement of asbestos-related assets and liabilities.

[0000833444-19-000051:mdna:189]
Product Warranties

[0000833444-19-000051:mdna:190]
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. A typical warranty program requires that the Company replace defective products within a specified time period from the date of sale. The Company records an estimate of future warranty-related costs based on actual historical return rates and other known factors. Based on analysis of return rates and other factors, the Company’s warranty provisions are adjusted as necessary. At September 30, 2019, the Company had recorded $285 million of warranty reserves for continuing operations, including extended warranties for which deferred revenue is recorded. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different than those estimates. Refer to Note 21, "Guarantees," of the notes to consolidated financial statements for disclosure of the Company's product warranty liabilities.

[0000833444-19-000051:mdna:191]
Income Taxes

[0000833444-19-000051:mdna:192]
The Company accounts for income taxes in accordance with ASC 740, "Income Taxes." Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and other loss carryforwards. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company records a valuation allowance that primarily represents non-U.S. operating and other loss carryforwards for which realization is uncertain. Management judgment is required in determining the Company’s provision for income taxes, deferred tax assets and liabilities, and the valuation allowance recorded against the Company’s net deferred tax assets. In calculating the provision for income taxes on an interim basis, the Company uses an estimate of the annual effective tax rate based upon the facts and circumstances known at each interim period. On a quarterly basis, the actual effective tax rate is adjusted as appropriate based upon the actual results as compared to those forecasted at the beginning of the fiscal year.

[0000833444-19-000051:mdna:193]
The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary. At September 30, 2019, the Company had a valuation allowance of $5.1 billion for continuing operations, of which $4.5 billion relates to net operating loss carryforwards primarily in Australia, Brazil, France, Germany, Ireland, Luxembourg, Spain, Switzerland, United Kingdom, and the U.S. for which sustainable taxable income has not been demonstrated; and $600 million for other deferred tax assets.

[0000833444-19-000051:mdna:194]
The Company’s federal income tax returns and certain non-U.S. income tax returns for various fiscal years remain under various stages of audit by the IRS and respective non-U.S. tax authorities. Although the outcome of tax audits is always uncertain, management believes that it has appropriate support for the positions taken on its tax returns and that its annual tax provisions included amounts sufficient to pay assessments, if any, which may be proposed by the taxing authorities. At September 30, 2019, the Company had recorded a liability of $2.5 billion for its best estimate of the probable loss on certain of its tax positions, the majority of which is included in other noncurrent liabilities in the consolidated statements of financial position. Nonetheless, the amounts ultimately paid, if any, upon resolution of the issues raised by the taxing authorities may differ materially from the amounts accrued for each year.

[0000833444-19-000051:mdna:195]
The Company does not generally provide additional U.S. or non-U.S. income taxes on outside basis differences of consolidated subsidiaries included in shareholders’ equity attributable to Johnson Controls International plc, except in limited circumstances including anticipated taxation on planned divestitures.  The reduction of the outside basis differences via the sale or liquidation of these subsidiaries and/or distributions could create taxable income.  The Company’s intent is to reduce the outside basis differences only when it would be tax efficient.  Refer to "Capitalization" within the "Liquidity and Capital Resources" section for discussion of U.S. and non-U.S. cash projections.

[0000833444-19-000051:mdna:196]
Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements for the Company's income tax disclosures.

[0000833444-19-000051:mdna:197]
NEW ACCOUNTING PRONOUNCEMENTS

[0000833444-19-000051:mdna:198]
Refer to the "New Accounting Pronouncements" section within Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements.

[0000833444-19-000051:mdna:199]
44

[0000833444-19-000051:mdna:200]
RISK MANAGEMENT

[0000833444-19-000051:mdna:201]
The Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities and stock-based compensation. All hedging transactions are authorized and executed pursuant to clearly defined policies and procedures, which strictly prohibit the use of financial instruments for speculative purposes. At the inception of the hedge, the Company assesses the effectiveness of the hedge instrument and designates the hedge instrument as either (1) a hedge of a recognized asset or liability or of a recognized firm commitment (a fair value hedge), (2) a hedge of a forecasted transaction or of the variability of cash flows to be received or paid related to an unrecognized asset or liability (a cash flow hedge) or (3) a hedge of a net investment in a non-U.S. operation (a net investment hedge). The Company performs hedge effectiveness testing on an ongoing basis depending on the type of hedging instrument used. All other derivatives not designated as hedging instruments under ASC 815, "Derivatives and Hedging," are revalued in the consolidated statements of income.

[0000833444-19-000051:mdna:202]
For all foreign currency derivative instruments designated as cash flow hedges, retrospective effectiveness is tested on a monthly basis using a cumulative dollar offset test. The fair value of the hedged exposures and the fair value of the hedge instruments are revalued, and the ratio of the cumulative sum of the periodic changes in the value of the hedge instruments to the cumulative sum of the periodic changes in the value of the hedge is calculated. The hedge is deemed as highly effective if the ratio is between 80% and 125%. For commodity derivative contracts designated as cash flow hedges, effectiveness is tested using a regression calculation. Ineffectiveness is minimal as the Company aligns most of the critical terms of its derivatives with the supply contracts.

[0000833444-19-000051:mdna:203]
For net investment hedges, the Company assesses its net investment positions in the non-U.S. operations and compares it with the outstanding net investment hedges on a quarterly basis. The hedge is deemed effective if the aggregate outstanding principal of the hedge instruments designated as the net investment hedge in a non-U.S. operation does not exceed the Company’s net investment positions in the respective non-U.S. operation.

[0000833444-19-000051:mdna:204]
Equity swaps and any other derivative instruments not designated as hedging instruments under ASC 815 require no assessment of effectiveness.

[0000833444-19-000051:mdna:205]
A discussion of the Company’s accounting policies for derivative financial instruments is included in Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements, and further disclosure relating to derivatives and hedging activities is included in Note 10, "Derivative Instruments and Hedging Activities," and Note 11, "Fair Value Measurements," of the notes to consolidated financial statements.

[0000833444-19-000051:mdna:206]
Foreign Exchange

[0000833444-19-000051:mdna:207]
The Company has manufacturing, sales and distribution facilities around the world and thus makes investments and enters into transactions denominated in various foreign currencies. In order to maintain strict control and achieve the benefits of the Company’s global diversification, foreign exchange exposures for each currency are netted internally so that only its net foreign exchange exposures are, as appropriate, hedged with financial instruments.

[0000833444-19-000051:mdna:208]
The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. The Company primarily enters into foreign currency exchange contracts to reduce the earnings and cash flow impact of the variation of non-functional currency denominated receivables and payables. Gains and losses resulting from hedging instruments offset the foreign exchange gains or losses on the underlying assets and liabilities being hedged. The maturities of the forward exchange contracts generally coincide with the settlement dates of the related transactions. Realized and unrealized gains and losses on these contracts are recognized in the same period as gains and losses on the hedged items. The Company also selectively hedges anticipated transactions that are subject to foreign exchange exposure, primarily with foreign currency exchange contracts, which are designated as cash flow hedges in accordance with ASC 815.

[0000833444-19-000051:mdna:209]
The Company has entered into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of debt obligations are reflected in the accumulated other comprehensive income ("AOCI") account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally.

[0000833444-19-000051:mdna:210]
At September 30, 2019 and 2018, the Company estimates that an unfavorable 10% change in the exchange rates would have decreased net unrealized gains by approximately $358 million and $212 million, respectively.

[0000833444-19-000051:mdna:211]
Interest Rates

[0000833444-19-000051:mdna:212]
Substantially all of the Company's outstanding debt has fixed interest rates.  A 10% increase in the average cost of the Company’s variable rate debt would have had an immaterial impact on pre-tax interest expense for the year ended September 30, 2019 and an unfavorable impact of approximately $5 million for the year ended September 30, 2018.

[0000833444-19-000051:mdna:213]
Commodities

[0000833444-19-000051:mdna:214]
The Company uses commodity hedge contracts in the financial derivatives market in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. As a cash flow hedge, gains and losses resulting from the hedging instruments offset the gains or losses on purchases of the underlying commodities that will be used in the business. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities.

[0000833444-19-000051:mdna:215]
ENVIRONMENTAL, HEALTH AND SAFETY AND OTHER MATTERS

[0000833444-19-000051:mdna:216]
The Company’s global operations are governed by environmental laws and worker safety laws. Under various circumstances, these laws impose civil and criminal penalties and fines, as well as injunctive and remedial relief, for noncompliance and require remediation at sites where Company-related substances have been released into the environment.

[0000833444-19-000051:mdna:217]
The Company has expended substantial resources globally, both financial and managerial, to comply with applicable environmental laws and worker safety laws and to protect the environment and workers. The Company believes it is in substantial compliance with such laws and maintains procedures designed to foster and ensure compliance. However, the Company has been, and in the future may become, the subject of formal or informal enforcement actions or proceedings regarding noncompliance with such laws or the remediation of Company-related substances released into the environment. Such matters typically are resolved with regulatory authorities through commitments to compliance, abatement or remediation programs and in some cases payment of penalties. Historically, neither such commitments nor penalties imposed on the Company have been material.

[0000833444-19-000051:mdna:218]
Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements for additional information.

[0000833444-19-000051:mdna:219]
QUARTERLY FINANCIAL DATA

[0000833444-19-000051:mdna:220]
| (in millions, except per share data)(quarterly amounts unaudited) | FirstQuarter |  | SecondQuarter |  | ThirdQuarter |  | FourthQuarter |  | FullYear |
| 2019 |  |  |  |  |  |  |  |  |  |
| Net sales | $ | 5,464 |  |  | $ | 5,779 |  |  | $ | 6,451 |  |  | $ | 6,274 |  |  | $ | 23,968 |  |
| Gross profit | 1,725 |  |  | 1,844 |  |  | 2,144 |  |  | 1,980 |  |  | 7,693 |  |
| Net income (1) | 399 |  |  | 558 |  |  | 4,276 |  |  | 654 |  |  | 5,887 |  |
| Net income attributable to Johnson Controls | 355 |  |  | 515 |  |  | 4,192 |  |  | 612 |  |  | 5,674 |  |
| Earnings per share (2) |  |  |  |  |  |  |  |  |  |
| Basic | 0.39 |  |  | 0.57 |  |  | 4.81 |  |  | 0.78 |  |  | 6.52 |  |
| Diluted | 0.38 |  |  | 0.57 |  |  | 4.79 |  |  | 0.77 |  |  | 6.49 |  |
| 2018 |  |  |  |  |  |  |  |  |  |
| Net sales | $ | 5,305 |  |  | $ | 5,630 |  |  | $ | 6,282 |  |  | $ | 6,183 |  |  | $ | 23,400 |  |
| Gross profit | 1,698 |  |  | 1,824 |  |  | 2,088 |  |  | 2,057 |  |  | 7,667 |  |
| Net income (3) | 271 |  |  | 483 |  |  | 804 |  |  | 825 |  |  | 2,383 |  |
| Net income attributable to Johnson Controls | 230 |  |  | 438 |  |  | 723 |  |  | 771 |  |  | 2,162 |  |
| Earnings per share (2) |  |  |  |  |  |  |  |  |  |
| Basic | 0.25 |  |  | 0.47 |  |  | 0.78 |  |  | 0.83 |  |  | 2.34 |  |
| Diluted | 0.25 |  |  | 0.47 |  |  | 0.78 |  |  | 0.83 |  |  | 2.32 |  |

[0000833444-19-000051:mdna:221]
| (1) | The fiscal 2019 first quarter net income includes $50 million of transaction and integration costs and $21 million of mark-to-market losses. The fiscal 2019 second quarter net income includes $70 million of transaction and integration costs and $20 million of mark-to-market gains. The fiscal 2019 third quarter net income includes a $5.2 billion gain on sale of the Power Solutions business, net of transaction and other costs, $235 million of significant restructuring and impairment costs, $226 million of tax indemnification reserve release, $140 million of environmental charge, $86 million of transaction and integration costs, $60 million of loss on debt extinguishment and $9 million of mark-to-market gains. The fiscal 2019 fourth quarter net income includes $626 million of net mark-to-market losses and $111 million of transaction and integration costs. The preceding amounts are stated on a pre-tax and pre-noncontrolling interest impact basis and include both continuing and discontinued operations activity. |

[0000833444-19-000051:mdna:222]
| (2) | Due to the use of the weighted-average shares outstanding for each quarter for computing earnings per share, the sum of the quarterly per share amounts may not equal the per share amount for the year. |

[0000833444-19-000051:mdna:223]
| (3) | The fiscal 2018 first quarter net income includes a $114 million gain on sale of Scott Safety, $158 million of significant restructuring and impairment costs, and $50 million of transaction and integration costs. The fiscal 2018 second quarter net income includes $64 million of transaction and integration costs. The fiscal 2018 third quarter net income includes $51 million of transaction and integration costs. The fiscal 2018 fourth quarter net income includes $10 million of net mark-to-market gains on pension and postretirement plans, $105 million of significant restructuring and impairment costs, and $69 million of transaction and integration costs. The preceding amounts are stated on a pre-tax and pre-noncontrolling interest impact basis and include both continuing and discontinued operations activity. |
