# JCI note change history — 0000833444-14-000046 → 0000833444-14-000099


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-07-25):
[0000833444-14-000099:note_history:1]
With respect to Mr. Kozlowski, in the first quarter of fiscal 2014, the parties signed an agreement resolving all outstanding disputes with Mr. Kozlowski, and with Mr. Kozlowski agreeing to release the Company from any claims to monetary amounts related to compensation, retention or other arrangements, including the Key Employee Loan Program, that were alleged to have existed between him and the Company. As a result, in the first quarter of fiscal 2014, the Company reversed the net liability of approximately $92 million which was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations for the amounts allegedly due to him.  Additionally, Tyco will be entitled to a portion of the proceeds, if any, from the future sale of certain assets owned by Mr. Kozlowski, the timing and amount of which is uncertain at this time.  During the quarter ended June 27, 2014, the Company received a $4 million recovery from the sale of property owned by Mr. Kozlowski, which was recognized as a credit to Selling, general, and administrative expenses.
  (was, 2014-04-25, similarity 0.6969):
[0000833444-14-000046:note_history:1]
With respect to Mr. Kozlowski, in the first quarter of fiscal 2014, the parties signed an agreement resolving all outstanding disputes, with Mr. Kozlowski agreeing to release the Company from any claims to monetary amounts related to compensation, retention or other arrangements, including the Key Employee Loan Program, alleged to have existed between him and the Company. As a result, in the first quarter of fiscal 2014, the Company reversed the net liability of approximately $92 million which was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations for the amounts allegedly due to him.  Additionally, Tyco will be entitled to a portion of the proceeds, if any, from the future sale of certain assets owned by Mr. Kozlowski, the timing and amount of which is uncertain at this time.

- changed (2014-07-25):
[0000833444-14-000099:note_history:2]
With respect to Mr. Swartz, on March 3, 2011, the U.S. District Court for the Southern District of New York granted the Company's motion for summary judgment as to liability for its affirmative actions and further ruled that issues related to damages would need to be resolved at trial. During the second quarter of fiscal 2012, the Company reversed a $50 million liability related to Mr. Swartz's pay and benefits due to the expiration of the statute of limitations. On May 15, 2012, Mr. Swartz filed a lawsuit against Tyco in New York state court claiming entitlement to monies under ERISA. The Company removed the case to the U.S. District Court for the Southern District of New York and filed a motion to dismiss Mr. Swartz's claims for multiple reasons, including that the statute of limitations had expired, at the latest, during the second quarter of fiscal 2012. A trial to determine the Company's damages from Mr. Swartz's breaches of fiduciary duty concluded on October 17, 2012. At the conclusion of the trial, the Court ruled that the Company was entitled to recover all monies earned by Mr. Swartz in connection with his employment by Tyco between September 1, 1995 and June 1, 2002. The Company filed a motion requesting the entry of monetary sum certain judgment in conformity with the Court's ruling regarding the time period of disgorgement. The motion also requested interest related to the monies Mr. Swartz was found to have unlawfully taken from the Company. In March 2013, the Court entered an order awarding the Company's request for interest. In connection with Mr. Swartz's affirmative claims against the Company, the Court dismissed all of Mr. Swartz's claims except one claim in which Mr. Swartz contended he was entitled to reimbursement from the Company for taxes he paid in connection with his 2002 Separation Agreement. In July 2013, the parties reached an agreement in principle to resolve the matter, with Mr. Swartz agreeing to release the Company from any claims to monetary amounts related to compensation, retention or other arrangements alleged to have existed between him and the Company. Although the parties have reached an agreement in principle, a final settlement agreement has not yet been executed.
  (was, 2014-04-25, similarity 0.972):
[0000833444-14-000046:note_history:2]
With respect to Mr. Swartz, on March 3, 2011, the U.S. District Court for the Southern District of New York granted the Company's motion for summary judgment as to liability for its affirmative actions and further ruled that issues related to damages would need to be resolved at trial. During the second quarter of fiscal 2012, the Company reversed a $50 million liability related to Mr. Swartz's pay and benefits due to the expiration of the statute of limitations, which was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations. On May 15, 2012, Mr. Swartz filed a lawsuit against Tyco in New York state court claiming entitlement to monies under ERISA. The Company removed the case to the U.S. District Court for the Southern District of New York and filed a motion to dismiss Mr. Swartz's claims for multiple reasons, including that the statute of limitations had expired, at the latest, during the second quarter of fiscal 2012. A trial to determine the Company's damages from Mr. Swartz's breaches of fiduciary duty concluded on October 17, 2012. At the conclusion of the trial, the Court ruled that the Company was entitled to recover all monies earned by Mr. Swartz in connection with his employment by Tyco between September 1, 1995 and June 1, 2002. The Company filed a motion requesting the entry of monetary sum certain judgment in conformity with the Court's ruling regarding the time period of disgorgement. The motion also requested interest related to the monies Mr. Swartz was found to have unlawfully taken from the Company. In March 2013, the Court entered an order awarding the Company's request for interest. In connection with Mr. Swartz's affirmative claims against the Company, the Court dismissed all of Mr. Swartz's claims except one claim in which Mr. Swartz contends he is entitled to reimbursement from the Company for taxes he paid in connection with his 2002 Separation Agreement. In July 2013, the parties reached an agreement in principle to resolve the matter, with Mr. Swartz agreeing to release the Company from any claims to monetary amounts related to compensation, retention or other arrangements alleged to have existed between him and the Company. Although the parties have reached an agreement in principle, a final settlement agreement has not yet been executed.

- changed (2014-07-25):
[0000833444-14-000099:note_history:3]
Tyco is involved in various stages of investigation and cleanup related to environmental remediation matters at a number of sites. The ultimate cost of site cleanup is difficult to predict given the uncertainties regarding the extent of the required cleanup, the interpretation of applicable laws and regulations and alternative cleanup methods. As of June 27, 2014, Tyco concluded that it was probable that it would incur remedial costs in the range of approximately $33 million to $82 million. As of June 27, 2014, Tyco concluded that the best estimate within this range is approximately $46 million, of which $22 million is included in Accrued and other current liabilities and $24 million is included in Other liabilities in the Company's Consolidated Balance Sheet.
  (was, 2014-04-25, similarity 0.9881):
[0000833444-14-000046:note_history:3]
Tyco is involved in various stages of investigation and cleanup related to environmental remediation matters at a number of sites. The ultimate cost of site cleanup is difficult to predict given the uncertainties regarding the extent of the required cleanup, the interpretation of applicable laws and regulations and alternative cleanup methods. As of March 28, 2014, Tyco concluded that it was probable that it would incur remedial costs in the range of approximately $38 million to $87 million. As of March 28, 2014, Tyco concluded that the best estimate within this range is approximately $51 million, of which $28 million is included in Accrued and other current liabilities and $23 million is included in Other liabilities in the Company's Consolidated Balance Sheet.

- changed (2014-07-25):
[0000833444-14-000099:note_history:4]
The majority of the liabilities described above relate to ongoing remediation efforts at a facility in the Company's Global Products segment located in Marinette, Wisconsin, which the Company acquired in 1990 in connection with its acquisition of, among other things, the Ansul product line. Prior to Tyco's acquisition, Ansul manufactured arsenic-based agricultural herbicides at the Marinette facility, which resulted in significant arsenic contamination of soil and groundwater on the Marinette site and in parts of the adjoining Menominee River. Ansul has been engaged in ongoing remediation efforts at the Marinette site since 1990, and in February 2009 entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the Marinette site. Under this agreement, Ansul's principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. As of June 27, 2014, the Company concluded that its remaining remediation and monitoring costs related to the Marinette facility were in the range of approximately $21 million to $57 million. The Company's best estimate within that range is approximately $33 million, of which $19 million is included in Accrued and other current liabilities and $14 million is included in Other liabilities in the Company's Consolidated Balance Sheet. During the quarters ended June 27, 2014 and June 28, 2013, the Company recorded nil for both periods in Selling, general and administrative expenses in the Consolidated Statement of Operations, respectively. During the nine months ended June 27, 2014 and June 28, 2013, the Company recorded nil and $100 million, respectively in Selling, general and administrative expenses in the Consolidated Statement of Operations.  Although the Company has recorded its best estimate of the costs that it will incur to remediate and monitor the arsenic contamination at the Marinette facility, it is possible that technological, regulatory or enforcement developments, the results of environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows.
  (was, 2014-04-25, similarity 0.9798):
[0000833444-14-000046:note_history:4]
The majority of the liabilities described above relate to ongoing remediation efforts at a facility in the Company's Global Products segment located in Marinette, Wisconsin, which the Company acquired in 1990 in connection with its acquisition of, among other things, the Ansul product line. Prior to Tyco's acquisition, Ansul manufactured arsenic-based agricultural herbicides at the Marinette facility, which resulted in significant arsenic contamination of soil and groundwater on the Marinette site and in parts of the adjoining Menominee River. Ansul has been engaged in ongoing remediation efforts at the Marinette site since 1990, and in February 2009 entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the Marinette site. Under this agreement, Ansul's principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. As of March 28, 2014, the Company concluded that its remaining remediation and monitoring costs related to the Marinette facility were in the range of approximately $27 million to $61 million. The Company's best estimate within that range is approximately $38 million, of which $24 million is included in Accrued and other current liabilities and $14 million is included in Other liabilities in the Company's Consolidated Balance Sheet. During the quarters ended March 28, 2014 and March 29, 2013, the Company recorded nil and $94 million in Selling, general and administrative expenses in the Consolidated Statement of Operations, respectively. During the six months ended March 28, 2014 and March 29, 2013, the Company recorded nil and $100 million, respectively in Selling, general and administrative expenses in the Consolidated Statement of Operations.  Although the Company has recorded its best estimate of the costs that it will incur to remediate and monitor the arsenic contamination at the Marinette facility, it is possible that technological, regulatory or enforcement developments, the results of environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows.

- added (2014-07-25):
[0000833444-14-000099:note_history:5]
As of June 27, 2014, the Company has determined that there were approximately 5,500 claims pending against it, its subsidiaries or entities for which the Company has assumed responsibility in connection with acquisitions and divestitures. This amount reflects the Company's current estimate of the number of viable claims made against such entities and includes adjustments for claims that are not actively being prosecuted, identify incorrect defendants, are duplicative of other actions or for which the Company is indemnified.

- changed (2014-07-25):
[0000833444-14-000099:note_history:6]
The Company's estimate of its liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience over a look-back period of three years, and estimates of the number and resolution cost of potential future claims that may be filed in the look-forward period of fifteen years. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made in the future during a defined period of time (the look-forward period). On a quarterly basis, Tyco assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements.  In addition, the Company continues to evaluate its ability to reasonably estimate claim activity beyond the look forward period and may expand this period in the future.  In addition to claims and settlement experience, Tyco considers additional qualitative and quantitative factors such as changes in legislation, the legal environment, the Company's defense strategy and health related trends in the overall population of workers potentially exposed to asbestos.  Tyco also evaluates the recoverability of its insurance receivable on a quarterly basis.  The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.
  (was, 2014-04-25, similarity 0.6247):
[0000833444-14-000046:note_history:6]
The Company's estimate of its liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience over a look-back period of three years, and estimates of the number and resolution cost of potential future claims that may be filed in the look-forward period of fifteen years. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made in the future during a defined period of time (the look-forward period). On a quarterly basis, Tyco assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements.  In addition to claims and settlement experience, Tyco considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy.  Tyco also evaluates the recoverability of its insurance receivable on a quarterly basis.  The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

- added (2014-07-25):
[0000833444-14-000099:note_history:7]
As of June 27, 2014, the Company's estimated net liability of $148 million was recorded within the Company's Consolidated Balance Sheet as a liability for pending and future claims and related defense costs of $310 million, and separately as an asset for insurance recoveries of $162 million. The Company believes that its asbestos related liabilities and insurance related assets as of June 27, 2014 are appropriate. Similarly, as of September 27, 2013, the Company's estimated net liability of $169 million was recorded within the Company's Consolidated Balance Sheet as a liability for pending and future claims and related defense costs of $321 million, and separately as an asset for insurance recoveries of $152 million.

- added (2014-07-25):
[0000833444-14-000099:note_history:8]
The net liabilities reflected in the Company's Consolidated Balance Sheet represent the Company's best estimates of probable losses for the look-forward period described above. It is reasonably possible that losses will be incurred for claims made subsequent to such look-forward periods. Although the Company is evaluating its look-forward period, due to the inherent uncertainty in predicting losses beyond 2027, the Company currently is unable to reasonably estimate the amount of losses beyond such period. With respect to claims made against Yarway, the Company is unable to reasonably estimate losses beyond what it has accrued because it is uncertain what the impact of Yarway's reorganization plan under Chapter 11 of the Bankruptcy Code will be on the Company.

- changed (2014-07-25):
[0000833444-14-000099:note_history:9]
No payments with respect to these matters would be required until the dispute is definitively resolved, which, based on the experience of other companies, could take several years. Tyco believes that its income tax reserves and the liabilities recorded in the Consolidated Balance Sheet for the tax sharing agreements continue to be appropriate. However, the ultimate resolution of these matters, and the impact of that resolution, are uncertain and could have a material adverse impact on Tyco's financial condition, results of operations and cash flows. In particular, if the IRS is successful in asserting its claim, it would have an adverse impact on interest deductions related to the same intercompany debt in subsequent time periods, totaling approximately $6.6 billion, which is expected to be disallowed by the IRS.
  (was, 2014-04-25, similarity 0.9951):
[0000833444-14-000046:note_history:9]
No payments with respect to these matters would be required until the dispute is definitively resolved, which, based on the experience of other companies, could take several years. Tyco believes that its income tax reserves and the liabilities recorded in the Consolidated Balance Sheet for the tax sharing agreements continue to be appropriate. However, the ultimate resolution of these matters, and the impact of that resolution, are uncertain and could have a material impact on Tyco's financial condition, results of operations and cash flows. In particular, if the IRS is successful in asserting its claim, it would have an adverse impact on interest deductions related to the same intercompany debt in subsequent time periods, totaling approximately $6.6 billion, which is expected to be disallowed by the IRS.

- changed (2014-07-25):
[0000833444-14-000099:note_history:10]
During the fourth quarter of fiscal 2012, Tyco disclosed the improper recording of revenue in the Company's ROW Installation & Services segment related to security contracts in China.  The Company pursued collection under its insurance policy and in the second fiscal quarter of 2014, the Company recorded a $21 million insurance recovery within the ROW Installation & Services segment as a result of a settlement with the insurance carrier.  The insurance recovery was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations.
  (was, 2014-04-25, similarity 0.9599):
[0000833444-14-000046:note_history:10]
During the fourth quarter of fiscal 2012, Tyco disclosed the improper recording of revenue in the Company's ROW Installation & Services segment related to security contracts in China.  The Company pursued collection under its insurance policy and during the quarter ended March 28, 2014, the Company recorded a $21 million insurance recovery within the ROW Installation & Services segment as a result of a settlement with the insurance carrier.  The insurance recovery was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations.

- added (2014-07-25):
[0000833444-14-000099:note_history:11]
During the first quarter of fiscal 2014, Tyco settled a tax dispute with its former subsidiary, CIT Group, Inc. ("CIT").  Under the terms of the settlement agreement, Tyco received $60 million during the first quarter of 2014, which was subject to the sharing provisions of the 2007 Tax Sharing Agreement. As a result, the Company recorded a $16 million gain in Selling, general and administrative expenses in the Consolidated Statement of Operations and established payables of $25 million and $19 million due to Covidien and TE Connectivity, respectively, as of December 27, 2013. The Company paid these amounts to Covidien and TE Connectivity during the second fiscal quarter of 2014.

- removed (2014-07-25):
[0000833444-14-000046:note_history:12]
As of March 28, 2014, the Company has determined that there were approximately 5,300 claims pending against it, its subsidiaries or entities for which the Company has assumed responsibility in connection with acquisitions and divestitures. This amount reflects the Company's current estimate of the number of viable claims made against such entities and includes adjustments for claims that are not actively being prosecuted, identify incorrect defendants, are duplicative of other actions or for which the Company is indemnified.

- removed (2014-07-25):
[0000833444-14-000046:note_history:13]
As of March 28, 2014, the Company's estimated net liability of $163 million was recorded within the Company's Consolidated Balance Sheet as a liability for pending and future claims and related defense costs of $315 million, and separately as an asset for insurance recoveries of $152 million. The Company believes that its asbestos related liabilities and insurance related assets as of March 28, 2014 are appropriate. Similarly, as of September 27, 2013, the Company's estimated net liability of $169 million was recorded within the Company's Consolidated Balance Sheet as a liability for pending and future claims and related defense costs of $321 million, and separately as an asset for insurance recoveries of $152 million.

- removed (2014-07-25):
[0000833444-14-000046:note_history:14]
The net liabilities reflected in the Company's Consolidated Balance Sheet represent the Company's best estimates of probable losses for the look-forward period described above. It is reasonably possible that losses will be incurred for claims made subsequent to such look-forward periods. However, due to the inherent uncertainty and lack of reliable trend data in predicting losses beyond 2027, the Company is unable to reasonably estimate the amount of losses beyond such period. With respect to claims made against Yarway, the Company is unable to reasonably estimate losses beyond what it has accrued because it is uncertain what the impact of Yarway's reorganization plan under Chapter 11 of the Bankruptcy Code will be on the Company.

- removed (2014-07-25):
[0000833444-14-000046:note_history:15]
During the first quarter of fiscal 2014, Tyco settled a tax dispute with its former subsidiary, CIT Group, Inc. ("CIT").  Under the terms of the settlement agreement, Tyco received $60 million during the quarter ended December 27, 2013 which is subject to the terms and conditions of the 2007 Tax Sharing Agreement. As a result, the Company recorded a $16 million gain in Selling, general and administrative expenses in the Consolidated Statement of Operations and established payables of $25 million and $19 million due to Covidien and TE Connectivity, respectively, as of December 27, 2013. The Company paid these amounts to Covidien and TE Connectivity during the quarter ended March 28, 2014.

- removed (2014-07-25):
[0000833444-14-000046:note_history:16]
On December 18, 2013, the Supreme Court of the Republic of Korea issued a decision clarifying the definition of "ordinary wages," which in Korea form the basis for certain statutory entitlements due to workers upon the occurrence of specified events such as severance, disability and retirement. Although no lawsuit or claim has been asserted against the Company, the Company is currently assessing the impact, if any, the ruling as well as new guidelines related to the scope of ordinary wages issued by the Korean Ministry of Employment and Labor on January 23, 2014 may have on the Company.  Although a risk of loss is reasonably possible, the Company is unable to reasonably estimate an amount or range of loss related to this matter at this time.  Consequently, the Company has made no provision for the potential loss, if any.  However, the Company does not believe the ultimate outcome of this matter will have a material adverse affect on its financial condition, results of operations or liquidity.


## tyc:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesAndNewAccountingPronouncementsTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-07-25):
[0000833444-14-000099:note_history:17]
Basis of Presentation—The Consolidated Financial Statements included herein are unaudited, but in the opinion of management, such financial statements include all adjustments, consisting of normal recurring adjustments, necessary to summarize fairly the Company's financial position, results of operations and cash flows for the interim period. The unaudited Consolidated Financial Statements include the consolidated results of Tyco International Ltd., a corporation organized under the laws of Switzerland, and its subsidiaries (Tyco and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Tyco"). The unaudited Consolidated Financial Statements have been prepared in United States dollars ("USD") and in accordance with the instructions to Form 10-Q under the Securities and Exchange Act of 1934, as amended. The results reported in these unaudited Consolidated Financial Statements should not be taken as indicative of results that may be expected for the entire year. These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes which have been recast to reflect the South Korean security business ("ADT Korea") as a discontinued operation contained within the Company's Current Report on Form 8-K dated May 16, 2014.
  (was, 2014-04-25, similarity 0.9171):
[0000833444-14-000046:note_history:17]
Basis of Presentation—The Consolidated Financial Statements included herein are unaudited, but in the opinion of management, such financial statements include all adjustments, consisting of normal recurring adjustments, necessary to summarize fairly the Company's financial position, results of operations and cash flows for the interim period. The unaudited Consolidated Financial Statements include the consolidated results of Tyco International Ltd., a corporation organized under the laws of Switzerland, and its subsidiaries (Tyco and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Tyco"). The unaudited Consolidated Financial Statements have been prepared in United States dollars ("USD") and in accordance with the instructions to Form 10-Q under the Securities and Exchange Act of 1934, as amended. The results reported in these unaudited Consolidated Financial Statements should not be taken as indicative of results that may be expected for the entire year. These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K for the fiscal year ended September 27, 2013 (the "2013 Form 10-K").

- changed (2014-07-25):
[0000833444-14-000099:note_history:18]
References to 2014 and 2013 are to Tyco's fiscal quarters ending June 27, 2014 and June 28, 2013, respectively, unless otherwise indicated.
  (was, 2014-04-25, similarity 0.9268):
[0000833444-14-000046:note_history:18]
References to 2014 and 2013 are to Tyco's fiscal quarters ending March 28, 2014 and March 29, 2013, respectively, unless otherwise indicated.

- added (2014-07-25):
[0000833444-14-000099:note_history:19]
Change of Jurisdiction - On May 30, 2014, Tyco entered into a Merger Agreement ("Merger Agreement") with Tyco International plc, a newly-formed Irish public limited company and a wholly-owned subsidiary of Tyco ("Tyco Ireland").  Under the Merger Agreement, Tyco will merge with and into Tyco Ireland, with Tyco Ireland being the surviving company.  This Merger will result in Tyco Ireland becoming Tyco's publicly-traded parent company and change the jurisdiction of organization of Tyco from Switzerland to Ireland.  Tyco's shareholders are expected to receive one ordinary share of Tyco Ireland for each common share of Tyco held immediately prior to the Merger.  Upon completion of the Merger, Tyco Ireland is expected to conduct, through its subsidiaries, the same businesses as conducted by Tyco before the Merger.  The Merger is subject to certain conditions including shareholder approval at the special general meeting of shareholders expected to be held in September 2014.

- changed (2014-07-25):
[0000833444-14-000099:note_history:20]
Reclassifications - Certain prior period amounts have been reclassified to conform with current period presentation.  Specifically, the Company has reclassified its ADT Korea business to income from discontinued operations in the Consolidated Statements of Operations and to assets and liabilities held for sale within the Consolidated Balance Sheets as it satisfied the criteria to be presented as a discontinued operation.  The Company completed the sale of the ADT Korea business on May 22, 2014.  See Note 3.
  (was, 2014-04-25, similarity 0.8889):
[0000833444-14-000046:note_history:20]
Reclassifications - Certain prior period amounts have been reclassified to conform with current period presentation.  Specifically, the Company has reclassified its South Korean security business to income from discontinued operations in the Consolidated Statements of Operations and assets and liabilities held for sale within the Consolidated Balance Sheets as it satisfied the criteria to be presented as a discontinued operation. See Note 3.

- added (2014-07-25):
[0000833444-14-000099:note_history:21]
In addition, the Company has reclassified several businesses in the Rest of World ("ROW") Installation & Services segment to income from discontinued operations and to assets and liabilities held for sale as they satisfied the criteria to be presented as discontinued operations.  The Company expects to complete the sale of these businesses during the next twelve months. See Note 3.

- changed (2014-07-25):
[0000833444-14-000099:note_history:22]
Recently Adopted Accounting Pronouncements - In January 2013, the Financial Accounting Standards Board (FASB) issued authoritative guidance clarifying the scope of disclosures about offsetting assets and liabilities. The guidance clarifies that the scope of the disclosures applies to derivatives accounted for in accordance with authoritative guidance for derivatives and hedging, including bifurcated embedded derivatives, repurchase agreements and reverse repurchase agreements, and securities borrowing and securities lending transactions that either offset or are subject to an enforceable master netting agreement or similar agreement. The guidance is applied retrospectively and became effective for Tyco in the first quarter of fiscal 2014.  The adoption of this guidance did not have a material impact on the Company's disclosures.
  (was, 2014-04-25, similarity 0.9916):
[0000833444-14-000046:note_history:22]
Recently Adopted Accounting Pronouncements—In January 2013, the Financial Accounting Standards Board ("FASB") issued authoritative guidance clarifying the scope of disclosures about offsetting assets and liabilities. The guidance clarifies that the scope of the disclosures applies to derivatives accounted for in accordance with authoritative guidance for derivatives and hedging, including bifurcated embedded derivatives, repurchase agreements and reverse repurchase agreements, and securities borrowing and securities lending transactions that either offset or are subject to an enforceable master netting agreement or similar agreement. The guidance is applied retrospectively and became effective for Tyco in the first quarter of fiscal 2014.  The adoption of this guidance did not have a material impact on the Company's disclosures.

- changed (2014-07-25):
[0000833444-14-000099:note_history:23]
Recently Issued Accounting Pronouncements - In March 2013, the FASB issued authoritative guidance to resolve diversity in practice on the accounting for the cumulative translation adjustment ("CTA") when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets within a foreign entity. The guidance requires that the parent release any CTA into net income when the parent ceases to have a controlling financial interest in a subsidiary or group of assets within a foreign entity which results in a substantially complete liquidation of the foreign entity; when the sale of an investment in a foreign entity results in the loss of a controlling financial interest; or where an acquirer obtains control of an acquiree in which it had an equity interest immediately before the acquisition date. The guidance does not change the requirement to release a pro rata portion of the CTA into net income upon a partial sale of an equity method investment that is a foreign entity. The guidance will be effective for Tyco in the first quarter of fiscal 2015, with early adoption permitted. The Company is currently assessing the timing of its adoption along with what impact, if any, the guidance will have upon adoption.
  (was, 2014-04-25, similarity 0.9985):
[0000833444-14-000046:note_history:23]
Recently Issued Accounting Pronouncements—In March 2013, the FASB issued authoritative guidance to resolve diversity in practice on the accounting for the cumulative translation adjustment ("CTA") when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets within a foreign entity. The guidance requires that the parent release any CTA into net income when the parent ceases to have a controlling financial interest in a subsidiary or group of assets within a foreign entity which results in a substantially complete liquidation of the foreign entity; when the sale of an investment in a foreign entity results in the loss of a controlling financial interest; or where an acquirer obtains control of an acquiree in which it had an equity interest immediately before the acquisition date. The guidance does not change the requirement to release a pro rata portion of the CTA into net income upon a partial sale of an equity method investment that is a foreign entity. The guidance will be effective for Tyco in the first quarter of fiscal 2015, with early adoption permitted. The Company is currently assessing the timing of its adoption along with what impact, if any, the guidance will have upon adoption.

- added (2014-07-25):
[0000833444-14-000099:note_history:24]
In May 2014, the FASB issued authoritative guidance for revenue from contracts with customers, which provides a single comprehensive revenue recognition model to apply in determining how and when to recognize revenue. The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. When applying the new revenue model to contracts with customers the guidance requires five steps to be applied, which include: 1) identify the contract(s) with a customer, 2) identify the performance obligations in the contract, 3) determine the transaction price, 4) allocate the transaction price to the performance obligations in the contract and 5) recognize revenue when (or as) the entity satisfies a performance obligation. The guidance also requires both quantitative and qualitative disclosures, which are more comprehensive than existing revenue standards. The disclosures are intended to enable financial statement users to understand the nature, timing and uncertainty of revenue and the related cash flow. This guidance will be effective for Tyco in the first fiscal quarter of 2018, with early adoption not permitted. The Company is currently assessing the impact the guidance will have upon adoption.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-07-25):
[0000833444-14-000099:note_history:25]
Basis of Presentation—The Consolidated Financial Statements included herein are unaudited, but in the opinion of management, such financial statements include all adjustments, consisting of normal recurring adjustments, necessary to summarize fairly the Company's financial position, results of operations and cash flows for the interim period. The unaudited Consolidated Financial Statements include the consolidated results of Tyco International Ltd., a corporation organized under the laws of Switzerland, and its subsidiaries (Tyco and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Tyco"). The unaudited Consolidated Financial Statements have been prepared in United States dollars ("USD") and in accordance with the instructions to Form 10-Q under the Securities and Exchange Act of 1934, as amended. The results reported in these unaudited Consolidated Financial Statements should not be taken as indicative of results that may be expected for the entire year. These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes which have been recast to reflect the South Korean security business ("ADT Korea") as a discontinued operation contained within the Company's Current Report on Form 8-K dated May 16, 2014.
  (was, 2014-04-25, similarity 0.9171):
[0000833444-14-000046:note_history:25]
Basis of Presentation—The Consolidated Financial Statements included herein are unaudited, but in the opinion of management, such financial statements include all adjustments, consisting of normal recurring adjustments, necessary to summarize fairly the Company's financial position, results of operations and cash flows for the interim period. The unaudited Consolidated Financial Statements include the consolidated results of Tyco International Ltd., a corporation organized under the laws of Switzerland, and its subsidiaries (Tyco and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Tyco"). The unaudited Consolidated Financial Statements have been prepared in United States dollars ("USD") and in accordance with the instructions to Form 10-Q under the Securities and Exchange Act of 1934, as amended. The results reported in these unaudited Consolidated Financial Statements should not be taken as indicative of results that may be expected for the entire year. These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K for the fiscal year ended September 27, 2013 (the "2013 Form 10-K").

- changed (2014-07-25):
[0000833444-14-000099:note_history:26]
References to 2014 and 2013 are to Tyco's fiscal quarters ending June 27, 2014 and June 28, 2013, respectively, unless otherwise indicated.
  (was, 2014-04-25, similarity 0.9268):
[0000833444-14-000046:note_history:26]
References to 2014 and 2013 are to Tyco's fiscal quarters ending March 28, 2014 and March 29, 2013, respectively, unless otherwise indicated.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-07-25):
[0000833444-14-000099:note_history:27]
Debt as of June 27, 2014 and September 27, 2013 is as follows ($ in millions):
  (was, 2014-04-25, similarity 0.9343):
[0000833444-14-000046:note_history:27]
Debt as of March 28, 2014 and September 27, 2013 is as follows ($ in millions):

- changed (2014-07-25):
[0000833444-14-000099:note_history:28]
|  | As of |
|  | June 27, 2014 |  | September 27,2013 |
| 3.375% public notes due 2015 | $ | 258 |  |  | $ | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 8.5% public notes due 2019 | 364 |  |  | 364 |  |
| 7.0% public notes due 2019 | 246 |  |  | 246 |  |
| 6.875% public notes due 2021 | 465 |  |  | 466 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| Other(1) | 21 |  |  | 20 |  |
| Total debt | 1,463 |  |  | 1,463 |  |
| Less current portion | 20 |  |  | 20 |  |
| Long-term debt | $ | 1,443 |  |  | $ | 1,443 |  |
  (was, 2014-04-25, similarity 0.9871):
[0000833444-14-000046:note_history:28]
|  | As of |
|  | March 28,2014 |  | September 27,2013 |
| 3.375% public notes due 2015 | $ | 258 |  |  | $ | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 8.5% public notes due 2019 | 364 |  |  | 364 |  |
| 7.0% public notes due 2019 | 246 |  |  | 246 |  |
| 6.875% public notes due 2021 | 465 |  |  | 466 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| Other(1) | 20 |  |  | 20 |  |
| Total debt | 1,462 |  |  | 1,463 |  |
| Less current portion | 20 |  |  | 20 |  |
| Long-term debt | $ | 1,442 |  |  | $ | 1,443 |  |

- changed (2014-07-25):
[0000833444-14-000099:note_history:29]
| (1) | $20 million of the amount shown as Other as of both June 27, 2014 and September 27, 2013 represents the current portion of the Company's total debt. |
  (was, 2014-04-25, similarity 0.9695):
[0000833444-14-000046:note_history:29]
| (1) | $20 million of the amount shown as Other as of both March 28, 2014 and September 27, 2013 represents the current portion of the Company's total debt. |

- added (2014-07-25):
[0000833444-14-000099:note_history:30]
The carrying amount of Tyco's debt subject to the fair value disclosure requirements as of both June 27, 2014 and September 27, 2013 was $1,443 million.  The Company has determined the fair value of such debt to be $1,684 million and $1,676 million as of June 27, 2014 and September 27, 2013, respectively.  The Company utilizes various valuation methodologies to determine the fair value of its debt, which is primarily dependent on the type of market in which the Company's debt is traded. When available, the Company uses quoted market prices to determine the fair value of its debt that is traded in active markets.  As of June 27, 2014 and September 27, 2013, the Company's debt, all of which is actively traded and subject to the fair value disclosure requirements, is classified as Level 1 in the fair value hierarchy.

- changed (2014-07-25):
[0000833444-14-000099:note_history:31]
From time to time Tyco International Finance S.A. ("TIFSA") may issue commercial paper for general corporate purposes. The maximum aggregate amount of unsecured commercial paper notes available to be issued on a private placement basis under the commercial paper program is $1 billion as of June 27, 2014.  As of June 27, 2014 and September 27, 2013, TIFSA had no commercial paper outstanding.
  (was, 2014-04-25, similarity 0.9468):
[0000833444-14-000046:note_history:31]
From time to time Tyco International Finance S.A. ("TIFSA") may issue commercial paper for general corporate purposes. The maximum aggregate amount of unsecured commercial paper notes available to be issued on a private placement basis under the commercial paper program is $1 billion as of March 28, 2014.  As of March 28, 2014 and September 27, 2013, TIFSA had no commercial paper outstanding.

- changed (2014-07-25):
[0000833444-14-000099:note_history:32]
The Company's committed revolving credit facility totaled $1 billion as of June 27, 2014. This revolving credit facility may be used for working capital, capital expenditures and general corporate purposes. As of June 27, 2014 and September 27, 2013 there were no amounts drawn under the Company's revolving credit facility. Interest under the revolving credit facility is variable and is calculated by reference to LIBOR or an alternate base rate.
  (was, 2014-04-25, similarity 0.9792):
[0000833444-14-000046:note_history:32]
The Company's committed revolving credit facility totaled $1 billion as of March 28, 2014. This revolving credit facility may be used for working capital, capital expenditures and general corporate purposes. As of March 28, 2014 and September 27, 2013 there were no amounts drawn under the Company's revolving credit facility. Interest under the revolving credit facility is variable and is calculated by reference to LIBOR or an alternate base rate.

- removed (2014-07-25):
[0000833444-14-000046:note_history:33]
The carrying amount of Tyco's debt subject to the fair value disclosure requirements as of March 28, 2014 and September 27, 2013 was $1,442 million and $1,443 million, respectively.  The Company has determined the fair value of such debt to be $1,673 million and $1,676 million as of March 28, 2014 and September 27, 2013, respectively.  The Company utilizes various valuation methodologies to determine the fair value of its debt, which is primarily dependent on the type of market in which the Company's debt is traded. When available, the Company uses quoted market prices to determine the fair value of its debt that is traded in active markets. As of March 28, 2014 and September 27, 2013, the fair value of the Company's debt which was actively traded was $1,673 million and $1,676 million, respectively.  As of March 28, 2014 and September 27, 2013, the Company's debt that was actively traded and subject to the fair value disclosure requirements is classified as Level 1 in the fair value hierarchy.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-07-25):
[0000833444-14-000099:note_history:34]
Debt as of June 27, 2014 and September 27, 2013 is as follows ($ in millions):
  (was, 2014-04-25, similarity 0.9343):
[0000833444-14-000046:note_history:34]
Debt as of March 28, 2014 and September 27, 2013 is as follows ($ in millions):

- changed (2014-07-25):
[0000833444-14-000099:note_history:35]
|  | As of |
|  | June 27, 2014 |  | September 27,2013 |
| 3.375% public notes due 2015 | $ | 258 |  |  | $ | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 8.5% public notes due 2019 | 364 |  |  | 364 |  |
| 7.0% public notes due 2019 | 246 |  |  | 246 |  |
| 6.875% public notes due 2021 | 465 |  |  | 466 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| Other(1) | 21 |  |  | 20 |  |
| Total debt | 1,463 |  |  | 1,463 |  |
| Less current portion | 20 |  |  | 20 |  |
| Long-term debt | $ | 1,443 |  |  | $ | 1,443 |  |
  (was, 2014-04-25, similarity 0.9871):
[0000833444-14-000046:note_history:35]
|  | As of |
|  | March 28,2014 |  | September 27,2013 |
| 3.375% public notes due 2015 | $ | 258 |  |  | $ | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 8.5% public notes due 2019 | 364 |  |  | 364 |  |
| 7.0% public notes due 2019 | 246 |  |  | 246 |  |
| 6.875% public notes due 2021 | 465 |  |  | 466 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| Other(1) | 20 |  |  | 20 |  |
| Total debt | 1,462 |  |  | 1,463 |  |
| Less current portion | 20 |  |  | 20 |  |
| Long-term debt | $ | 1,442 |  |  | $ | 1,443 |  |

- changed (2014-07-25):
[0000833444-14-000099:note_history:36]
| (1) | $20 million of the amount shown as Other as of both June 27, 2014 and September 27, 2013 represents the current portion of the Company's total debt. |
  (was, 2014-04-25, similarity 0.9695):
[0000833444-14-000046:note_history:36]
| (1) | $20 million of the amount shown as Other as of both March 28, 2014 and September 27, 2013 represents the current portion of the Company's total debt. |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2014-07-25):
[0000833444-14-000099:note_history:37]
Subsequent Events

- added (2014-07-25):
[0000833444-14-000099:note_history:38]
Subsequent to June 27, 2014 and through July 22, 2014, the Company repurchased approximately 7 million common shares for approximately $319 million under the share repurchase program.
