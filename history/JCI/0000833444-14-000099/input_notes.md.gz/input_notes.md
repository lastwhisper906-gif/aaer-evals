# JCI notes — 0000833444-14-000099


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0000833444-14-000099:notes:1]
Basis of Presentation—The Consolidated Financial Statements included herein are unaudited, but in the opinion of management, such financial statements include all adjustments, consisting of normal recurring adjustments, necessary to summarize fairly the Company's financial position, results of operations and cash flows for the interim period. The unaudited Consolidated Financial Statements include the consolidated results of Tyco International Ltd., a corporation organized under the laws of Switzerland, and its subsidiaries (Tyco and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Tyco"). The unaudited Consolidated Financial Statements have been prepared in United States dollars ("USD") and in accordance with the instructions to Form 10-Q under the Securities and Exchange Act of 1934, as amended. The results reported in these unaudited Consolidated Financial Statements should not be taken as indicative of results that may be expected for the entire year. These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes which have been recast to reflect the South Korean security business ("ADT Korea") as a discontinued operation contained within the Company's Current Report on Form 8-K dated May 16, 2014.

[0000833444-14-000099:notes:2]
References to 2014 and 2013 are to Tyco's fiscal quarters ending June 27, 2014 and June 28, 2013, respectively, unless otherwise indicated.

[0000833444-14-000099:notes:3]
[same as prior period, unchanged from 0000833444-14-000046:notes:3]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000833444-14-000099:notes:4]
[same as prior period, unchanged from 0000833444-14-000046:notes:4]

[0000833444-14-000099:notes:5]
During the quarter ended June 27, 2014, cash paid for acquisitions included in continuing operations totaled $9 million, which is related to an acquisition within the Company's ROW Installation & Services segment.

[0000833444-14-000099:notes:6]
During the nine months ended June 27, 2014, total consideration included in continuing operations was $67 million, which in addition to the acquisition within the ROW Installation & Services segment described above, is comprised of $54 million of cash paid, net of $1 million cash acquired, and $2 million of contingent consideration for the acquisition of Westfire, Inc. ("Westfire") on November 8, 2013.  Westfire, a fire protection services company with operations in the United States, Chile and Peru, provides critical special-hazard suppression and detection applications in mining, telecommunications and other vertical markets and is being integrated with the NA Installation & Services and ROW Installation & Services segments.

[0000833444-14-000099:notes:7]
During the quarter ended June 28, 2013, cash paid for acquisitions included in continuing operations totaled $37 million which is related to an acquisition within the Company's ROW Installation & Services segment. During the nine months ended June 28, 2013, cash paid for acquisitions included in continuing operations totaled $75 million net of $3 million cash acquired, which is related to acquisitions within the Company's NA Installation & Services and ROW Installation & Services segments.

[0000833444-14-000099:notes:8]
[same as prior period, unchanged from 0000833444-14-000046:notes:7]

[0000833444-14-000099:notes:9]
Acquisition and integration costs are expensed as incurred.  During the quarter and nine months ended June 27, 2014, the Company incurred acquisition and integration costs of $1 million and $2 million, respectively. During the quarter and nine months ended June 28, 2013, the Company incurred acquisition and integration costs of $1 million and $2 million, respectively. Such costs are recorded in Selling, general and administrative expenses in the Company's Consolidated Statements of Operations.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-14-000099:notes:10]
Commitments and Contingencies

[0000833444-14-000099:notes:11]
Legacy Matters Related to Former Management

[0000833444-14-000099:notes:12]
The Company has been a party to several lawsuits involving disputes with former management, including its former chief executive officer, Mr. L. Dennis Kozlowski, and its former chief financial officer, Mr. Mark Swartz. The Company filed civil complaints against Mr. Kozlowski and Mr. Swartz for breach of fiduciary duty and other wrongful conduct relating to alleged abuses of the Company's Key Employee Loan Program and relocation program, unauthorized bonuses, unauthorized payments, self-dealing transactions and other improper conduct. In connection with Tyco's affirmative actions against Mr. Kozlowski and Mr. Swartz, Mr. Kozlowski, through counterclaims, and Mr. Swartz, through a separate lawsuit, sought an aggregate of approximately $140 million allegedly due in connection with their compensation and retention arrangements and under the Employee Retirement Income Security Act ("ERISA").

[0000833444-14-000099:notes:13]
With respect to Mr. Kozlowski, in the first quarter of fiscal 2014, the parties signed an agreement resolving all outstanding disputes with Mr. Kozlowski, and with Mr. Kozlowski agreeing to release the Company from any claims to monetary amounts related to compensation, retention or other arrangements, including the Key Employee Loan Program, that were alleged to have existed between him and the Company. As a result, in the first quarter of fiscal 2014, the Company reversed the net liability of approximately $92 million which was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations for the amounts allegedly due to him.  Additionally, Tyco will be entitled to a portion of the proceeds, if any, from the future sale of certain assets owned by Mr. Kozlowski, the timing and amount of which is uncertain at this time.  During the quarter ended June 27, 2014, the Company received a $4 million recovery from the sale of property owned by Mr. Kozlowski, which was recognized as a credit to Selling, general, and administrative expenses.

[0000833444-14-000099:notes:14]
With respect to Mr. Swartz, on March 3, 2011, the U.S. District Court for the Southern District of New York granted the Company's motion for summary judgment as to liability for its affirmative actions and further ruled that issues related to damages would need to be resolved at trial. During the second quarter of fiscal 2012, the Company reversed a $50 million liability related to Mr. Swartz's pay and benefits due to the expiration of the statute of limitations. On May 15, 2012, Mr. Swartz filed a lawsuit against Tyco in New York state court claiming entitlement to monies under ERISA. The Company removed the case to the U.S. District Court for the Southern District of New York and filed a motion to dismiss Mr. Swartz's claims for multiple reasons, including that the statute of limitations had expired, at the latest, during the second quarter of fiscal 2012. A trial to determine the Company's damages from Mr. Swartz's breaches of fiduciary duty concluded on October 17, 2012. At the conclusion of the trial, the Court ruled that the Company was entitled to recover all monies earned by Mr. Swartz in connection with his employment by Tyco between September 1, 1995 and June 1, 2002. The Company filed a motion requesting the entry of monetary sum certain judgment in conformity with the Court's ruling regarding the time period of disgorgement. The motion also requested interest related to the monies Mr. Swartz was found to have unlawfully taken from the Company. In March 2013, the Court entered an order awarding the Company's request for interest. In connection with Mr. Swartz's affirmative claims against the Company, the Court dismissed all of Mr. Swartz's claims except one claim in which Mr. Swartz contended he was entitled to reimbursement from the Company for taxes he paid in connection with his 2002 Separation Agreement. In July 2013, the parties reached an agreement in principle to resolve the matter, with Mr. Swartz agreeing to release the Company from any claims to monetary amounts related to compensation, retention or other arrangements alleged to have existed between him and the Company. Although the parties have reached an agreement in principle, a final settlement agreement has not yet been executed.

[0000833444-14-000099:notes:15]
Environmental Matters

[0000833444-14-000099:notes:16]
Tyco is involved in various stages of investigation and cleanup related to environmental remediation matters at a number of sites. The ultimate cost of site cleanup is difficult to predict given the uncertainties regarding the extent of the required cleanup, the interpretation of applicable laws and regulations and alternative cleanup methods. As of June 27, 2014, Tyco concluded that it was probable that it would incur remedial costs in the range of approximately $33 million to $82 million. As of June 27, 2014, Tyco concluded that the best estimate within this range is approximately $46 million, of which $22 million is included in Accrued and other current liabilities and $24 million is included in Other liabilities in the Company's Consolidated Balance Sheet.

[0000833444-14-000099:notes:17]
The majority of the liabilities described above relate to ongoing remediation efforts at a facility in the Company's Global Products segment located in Marinette, Wisconsin, which the Company acquired in 1990 in connection with its acquisition of, among other things, the Ansul product line. Prior to Tyco's acquisition, Ansul manufactured arsenic-based agricultural herbicides at the Marinette facility, which resulted in significant arsenic contamination of soil and groundwater on the Marinette site and in parts of the adjoining Menominee River. Ansul has been engaged in ongoing remediation efforts at the Marinette site since 1990, and in February 2009 entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the Marinette site. Under this agreement, Ansul's principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. As of June 27, 2014, the Company concluded that its remaining remediation and monitoring costs related to the Marinette facility were in the range of approximately $21 million to $57 million. The Company's best estimate within that range is approximately $33 million, of which $19 million is included in Accrued and other current liabilities and $14 million is included in Other liabilities in the Company's Consolidated Balance Sheet. During the quarters ended June 27, 2014 and June 28, 2013, the Company recorded nil for both periods in Selling, general and administrative expenses in the Consolidated Statement of Operations, respectively. During the nine months ended June 27, 2014 and June 28, 2013, the Company recorded nil and $100 million, respectively in Selling, general and administrative expenses in the Consolidated Statement of Operations.  Although the Company has recorded its best estimate of the costs that it will incur to remediate and monitor the arsenic contamination at the Marinette facility, it is possible that technological, regulatory or enforcement developments, the results of environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows.

[0000833444-14-000099:notes:18]
Asbestos Matters

[0000833444-14-000099:notes:19]
The Company and certain of its subsidiaries along with numerous other companies are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases typically involve product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were attached to or used with asbestos containing components manufactured by third parties. Each case typically names between dozens to hundreds of corporate defendants. While the Company has observed an increase in the number of these lawsuits over the past several years, including lawsuits by plaintiffs with mesothelioma related claims, a large percentage of these suits have not presented viable legal claims and, as a result, have been dismissed by the courts. The Company's historical strategy has been to mount a vigorous defense aimed at having unsubstantiated suits dismissed, and, where appropriate, settling suits before trial. Although a large percentage of litigated suits have been dismissed, the Company cannot predict the extent to which it will be successful in resolving lawsuits in the future. In addition, the Company continues to assess its strategy for resolving asbestos claims. Due to the number of claims and limited amount of assets held by Yarway Corporation ("Yarway"), one of the Company's indirect subsidiaries, on April 22, 2013 Yarway filed a voluntary petition for relief under Chapter 11 of the U.S. Bankruptcy Code in the United States Bankruptcy Court for the District of Delaware. As a result of this filing, all asbestos claims against Yarway have been stayed pending confirmation of a plan of reorganization by the Bankruptcy Court. Yarway's goal is to negotiate, obtain approval of, and consummate a plan of reorganization that establishes an appropriately funded trust to provide for the fair and equitable payment of legitimate current and future Yarway asbestos claims, accompanied by appropriate injunctive relief permanently protecting Yarway and certain other protected parties from any further asbestos claims arising from products manufactured, sold, and/or distributed by Yarway. Upon confirmation of such plan of  reorganization, the Company expects to deconsolidate Yarway and to settle intercompany accounts, including approximately  $100 million in intercompany liabilities. As a result of filing the voluntary petition during the third quarter of fiscal 2013, the Company recorded an expected loss upon deconsolidation of $10 million related to the Yarway bankruptcy petition. Since filing for bankruptcy protection, Yarway has negotiated with representatives of the committees representing current and future asbestos claimants, but has been unable to agree on a plan of reorganization acceptable to all parties. We believe that certain claims made by the asbestos claimants are without merit and the Company intends to vigorously defend itself. There can be no assurance that an unfavorable outcome in the Bankruptcy Court would not have a material adverse effect on the Company's results of operations, financial condition or liquidity.

[0000833444-14-000099:notes:20]
As of June 27, 2014, the Company has determined that there were approximately 5,500 claims pending against it, its subsidiaries or entities for which the Company has assumed responsibility in connection with acquisitions and divestitures. This amount reflects the Company's current estimate of the number of viable claims made against such entities and includes adjustments for claims that are not actively being prosecuted, identify incorrect defendants, are duplicative of other actions or for which the Company is indemnified.

[0000833444-14-000099:notes:21]
The Company's estimate of its liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience over a look-back period of three years, and estimates of the number and resolution cost of potential future claims that may be filed in the look-forward period of fifteen years. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made in the future during a defined period of time (the look-forward period). On a quarterly basis, Tyco assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements.  In addition, the Company continues to evaluate its ability to reasonably estimate claim activity beyond the look forward period and may expand this period in the future.  In addition to claims and settlement experience, Tyco considers additional qualitative and quantitative factors such as changes in legislation, the legal environment, the Company's defense strategy and health related trends in the overall population of workers potentially exposed to asbestos.  Tyco also evaluates the recoverability of its insurance receivable on a quarterly basis.  The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-14-000099:notes:22]
As of June 27, 2014, the Company's estimated net liability of $148 million was recorded within the Company's Consolidated Balance Sheet as a liability for pending and future claims and related defense costs of $310 million, and separately as an asset for insurance recoveries of $162 million. The Company believes that its asbestos related liabilities and insurance related assets as of June 27, 2014 are appropriate. Similarly, as of September 27, 2013, the Company's estimated net liability of $169 million was recorded within the Company's Consolidated Balance Sheet as a liability for pending and future claims and related defense costs of $321 million, and separately as an asset for insurance recoveries of $152 million.

[0000833444-14-000099:notes:23]
The net liabilities reflected in the Company's Consolidated Balance Sheet represent the Company's best estimates of probable losses for the look-forward period described above. It is reasonably possible that losses will be incurred for claims made subsequent to such look-forward periods. Although the Company is evaluating its look-forward period, due to the inherent uncertainty in predicting losses beyond 2027, the Company currently is unable to reasonably estimate the amount of losses beyond such period. With respect to claims made against Yarway, the Company is unable to reasonably estimate losses beyond what it has accrued because it is uncertain what the impact of Yarway's reorganization plan under Chapter 11 of the Bankruptcy Code will be on the Company.

[0000833444-14-000099:notes:24]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-14-000099:notes:25]
Tax Matters

[0000833444-14-000099:notes:26]
Tyco and its subsidiaries' income tax returns are examined periodically by various tax authorities. In connection with these examinations, tax authorities, including the IRS, have raised issues and proposed tax adjustments, in particular with respect to years preceding the 2007 Separation. The issues and proposed adjustments related to such years are generally subject to the sharing provisions of a tax sharing agreement entered in 2007 with Covidien and TE Connectivity (the "2007 Tax Sharing Agreement") under which Tyco, Covidien and TE Connectivity share 27%, 42% and 31%, respectively, of shared income tax liabilities that arise from adjustments made by tax authorities to Tyco's, Covidien's and TE Connectivity's U.S. and certain non-U.S. income tax returns. The costs and expenses associated with the management of these shared tax liabilities are generally shared equally among the parties. Tyco has previously disclosed that in connection with U.S. federal tax audits, the IRS has raised a number of issues and proposed tax adjustments for periods beginning with the 1997 tax year. Although Tyco has been able to resolve substantially all of the issues and adjustments proposed by the IRS for tax years through 2007, it has not been able to resolve matters related to the treatment of certain intercompany debt transactions during the period. As a result, on June 20, 2013, Tyco received Notices of Deficiency from the IRS asserting that several of Tyco's former U.S. subsidiaries owe additional taxes of $883.3 million plus penalties of $154 million based on audits of the 1997 through 2000 tax years of Tyco and its subsidiaries as they existed at that time. In addition, Tyco received Final Partnership Administrative Adjustments for certain U.S. partnerships owned by former U.S. subsidiaries with respect to which an additional tax deficiency of approximately $30 million is expected to be asserted. These amounts exclude interest and do not reflect the impact on subsequent periods if the IRS position described below is ultimately proved correct.

[0000833444-14-000099:notes:27]
The IRS asserted in the Notices of Deficiency that substantially all of Tyco's intercompany debt originated during the 1997 - 2000 period should not be treated as debt for U.S. federal income tax purposes, and has disallowed interest and related deductions recognized on U.S. income tax returns totaling approximately $2.9 billion. Tyco strongly disagrees with the IRS position and has filed petitions with the U.S. Tax Court contesting the IRS proposed adjustments. Tyco believes that it has meritorious defenses for its tax filings, that the IRS positions with regard to these matters are inconsistent with the applicable tax laws and existing Treasury regulations, and that the previously reported taxes for the years in question are appropriate.

[0000833444-14-000099:notes:28]
No payments with respect to these matters would be required until the dispute is definitively resolved, which, based on the experience of other companies, could take several years. Tyco believes that its income tax reserves and the liabilities recorded in the Consolidated Balance Sheet for the tax sharing agreements continue to be appropriate. However, the ultimate resolution of these matters, and the impact of that resolution, are uncertain and could have a material adverse impact on Tyco's financial condition, results of operations and cash flows. In particular, if the IRS is successful in asserting its claim, it would have an adverse impact on interest deductions related to the same intercompany debt in subsequent time periods, totaling approximately $6.6 billion, which is expected to be disallowed by the IRS.

[0000833444-14-000099:notes:29]
See Note 6 for additional information related to income tax matters.

[0000833444-14-000099:notes:30]
Other Matters

[0000833444-14-000099:notes:31]
During the fourth quarter of fiscal 2012, Tyco disclosed the improper recording of revenue in the Company's ROW Installation & Services segment related to security contracts in China.  The Company pursued collection under its insurance policy and in the second fiscal quarter of 2014, the Company recorded a $21 million insurance recovery within the ROW Installation & Services segment as a result of a settlement with the insurance carrier.  The insurance recovery was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations.

[0000833444-14-000099:notes:32]
During the first quarter of fiscal 2014, Tyco settled a tax dispute with its former subsidiary, CIT Group, Inc. ("CIT").  Under the terms of the settlement agreement, Tyco received $60 million during the first quarter of 2014, which was subject to the sharing provisions of the 2007 Tax Sharing Agreement. As a result, the Company recorded a $16 million gain in Selling, general and administrative expenses in the Consolidated Statement of Operations and established payables of $25 million and $19 million due to Covidien and TE Connectivity, respectively, as of December 27, 2013. The Company paid these amounts to Covidien and TE Connectivity during the second fiscal quarter of 2014.

[0000833444-14-000099:notes:33]
In addition to the foregoing, the Company is subject to claims and suits, including from time to time, contractual disputes and product and general liability claims, incidental to present and former operations, acquisitions and dispositions. With respect to many of these claims, the Company either self-insures or maintains insurance through third-parties, with varying deductibles. While the ultimate outcome of these matters cannot be predicted with certainty, the Company believes that the resolution of any such proceedings, whether the underlying claims are covered by insurance or not, will not have a material adverse effect on the Company's financial condition, results of operations or cash flows beyond amounts recorded for such matters.


## us-gaap:CondensedFinancialStatementsTextBlock

[0000833444-14-000099:notes:34]
[same as prior period, unchanged from 0000833444-14-000046:notes:34]

[0000833444-14-000099:notes:35]
[same as prior period, unchanged from 0000833444-14-000046:notes:35]

[0000833444-14-000099:notes:36]
During the fourth quarter of fiscal 2013, the Company transferred certain investments in subsidiaries from Tyco to TIFSA. There was no impact on the Company’s financial position, results of operations and cash flows as the transactions were entirely among wholly-owned subsidiaries of Tyco. The transactions, which increased TIFSA’s investment in subsidiaries, were among entities under common control and their effects have been reflected as of the beginning of the earliest period presented, which resulted in a net increase to TIFSA’s Equity in net income of subsidiaries of $8 million and $16 million for the quarter and nine months ended June 28, 2013, respectively.

[0000833444-14-000099:notes:37]
[same as prior period, unchanged from 0000833444-14-000046:notes:37]

[0000833444-14-000099:notes:38]
For the Quarter Ended June 27, 2014

[0000833444-14-000099:notes:39]
[same as prior period, unchanged from 0000833444-14-000046:notes:39]

[0000833444-14-000099:notes:40]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | 2,662 |  |  | $ | — |  |  | $ | 2,662 |  |
| Cost of product sales | — |  |  | — |  |  | 1,106 |  |  | — |  |  | 1,106 |  |
| Cost of services | — |  |  | — |  |  | 572 |  |  | — |  |  | 572 |  |
| Selling, general and administrative expenses | 5 |  |  | 1 |  |  | 665 |  |  | — |  |  | 671 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | 17 |  |  | — |  |  | 17 |  |
| Operating (loss) income | (5 | ) |  | (1 | ) |  | 302 |  |  | — |  |  | 296 |  |
| Interest income | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Interest expense | — |  |  | (23 | ) |  | (1 | ) |  | — |  |  | (24 | ) |
| Other (expense) income, net | (1 | ) |  | — |  |  | 1 |  |  | — |  |  | — |  |
| Equity in net income of subsidiaries | 1,468 |  |  | 1,466 |  |  | — |  |  | (2,934 | ) |  | — |  |
| Intercompany interest and fees | (13 | ) |  | 14 |  |  | 4 |  |  | (5 | ) |  | — |  |
| Income from continuing operations before income taxes | 1,449 |  |  | 1,456 |  |  | 310 |  |  | (2,939 | ) |  | 276 |  |
| Income tax benefit (expense) | 1 |  |  | (1 | ) |  | (55 | ) |  | — |  |  | (55 | ) |
| Equity income in earnings of unconsolidated subsidiaries | — |  |  | — |  |  | 215 |  |  | — |  |  | 215 |  |
| Income from continuing operations | 1,450 |  |  | 1,455 |  |  | 470 |  |  | (2,939 | ) |  | 436 |  |
| Income from discontinued operations, net of income taxes | — |  |  | — |  |  | 1,011 |  |  | 5 |  |  | 1,016 |  |
| Net income | 1,450 |  |  | 1,455 |  |  | 1,481 |  |  | (2,934 | ) |  | 1,452 |  |
| Less: noncontrolling interest in subsidiaries net income | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Net income attributable to Tyco common shareholders | $ | 1,450 |  |  | $ | 1,455 |  |  | $ | 1,479 |  |  | $ | (2,934 | ) |  | $ | 1,450 |  |

[0000833444-14-000099:notes:41]
[same as prior period, unchanged from 0000833444-14-000046:notes:41]

[0000833444-14-000099:notes:42]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 1,450 |  |  | $ | 1,455 |  |  | $ | 1,481 |  |  | $ | (2,934 | ) |  | $ | 1,452 |  |
| Other comprehensive income, net of tax |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | 28 |  |  | — |  |  | 28 |  |  | (28 | ) |  | 28 |  |
| Defined benefit and post retirement plans | 9 |  |  | — |  |  | 9 |  |  | (9 | ) |  | 9 |  |
| Total other comprehensive income, net of tax | 37 |  |  | — |  |  | 37 |  |  | (37 | ) |  | 37 |  |
| Comprehensive income | 1,487 |  |  | 1,455 |  |  | 1,518 |  |  | (2,971 | ) |  | 1,489 |  |
| Less: comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Comprehensive income attributable to Tyco common shareholders | $ | 1,487 |  |  | $ | 1,455 |  |  | $ | 1,516 |  |  | $ | (2,971 | ) |  | $ | 1,487 |  |

[0000833444-14-000099:notes:43]
For the Quarter Ended June 28, 2013

[0000833444-14-000099:notes:44]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | 2,537 |  |  | $ | — |  |  | $ | 2,537 |  |
| Cost of product sales | — |  |  | — |  |  | 1,000 |  |  | — |  |  | 1,000 |  |
| Cost of services | — |  |  | — |  |  | 606 |  |  | — |  |  | 606 |  |
| Selling, general and administrative expenses | 2 |  |  | 1 |  |  | 709 |  |  | — |  |  | 712 |  |
| Separation costs | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | 53 |  |  | — |  |  | 53 |  |
| Operating (loss) income | (2 | ) |  | (1 | ) |  | 165 |  |  | — |  |  | 162 |  |
| Interest income | 2 |  |  | — |  |  | 4 |  |  | — |  |  | 6 |  |
| Interest expense | (1 | ) |  | (24 | ) |  | (1 | ) |  | — |  |  | (26 | ) |
| Other expense, net | (1 | ) |  | — |  |  | — |  |  | — |  |  | (1 | ) |
| Equity in net income of subsidiaries | 160 |  |  | 128 |  |  | — |  |  | (288 | ) |  | — |  |
| Intercompany interest and fees | (23 | ) |  | 3 |  |  | 20 |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 135 |  |  | 106 |  |  | 188 |  |  | (288 | ) |  | 141 |  |
| Income tax expense | — |  |  | (2 | ) |  | (21 | ) |  | — |  |  | (23 | ) |
| Equity loss in earnings of unconsolidated subsidiaries | — |  |  | — |  |  | (6 | ) |  | — |  |  | (6 | ) |
| Income from continuing operations | 135 |  |  | 104 |  |  | 161 |  |  | (288 | ) |  | 112 |  |
| Income from discontinued operations, net of income taxes | — |  |  | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Net income | 135 |  |  | 104 |  |  | 184 |  |  | (288 | ) |  | 135 |  |
| Less: noncontrolling interest in subsidiaries net loss | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net income attributable to Tyco common shareholders | $ | 135 |  |  | $ | 104 |  |  | $ | 184 |  |  | $ | (288 | ) |  | $ | 135 |  |

[0000833444-14-000099:notes:45]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 135 |  |  | $ | 104 |  |  | $ | 184 |  |  | $ | (288 | ) |  | $ | 135 |  |
| Other comprehensive (loss) income, net of tax |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | (134 | ) |  | — |  |  | (134 | ) |  | 134 |  |  | (134 | ) |
| Defined benefit and post retirement plans | 5 |  |  | — |  |  | 5 |  |  | (5 | ) |  | 5 |  |
| Unrealized loss on marketable securities and derivative instruments | (1 | ) |  | — |  |  | (1 | ) |  | 1 |  |  | (1 | ) |
| Total other comprehensive loss, net of tax | (130 | ) |  | — |  |  | (130 | ) |  | 130 |  |  | (130 | ) |
| Comprehensive income | 5 |  |  | 104 |  |  | 54 |  |  | (158 | ) |  | 5 |  |
| Less: comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Comprehensive income attributable to Tyco common shareholders | $ | 5 |  |  | $ | 104 |  |  | $ | 54 |  |  | $ | (158 | ) |  | $ | 5 |  |

[0000833444-14-000099:notes:46]
For the Nine Months Ended June 27, 2014

[0000833444-14-000099:notes:47]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | 7,636 |  |  | $ | — |  |  | $ | 7,636 |  |
| Cost of product sales | — |  |  | — |  |  | 3,108 |  |  | — |  |  | 3,108 |  |
| Cost of services | — |  |  | — |  |  | 1,725 |  |  | — |  |  | 1,725 |  |
| Selling, general and administrative expenses | (8 | ) |  | 3 |  |  | 1,883 |  |  | — |  |  | 1,878 |  |
| Separation costs | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | 27 |  |  | — |  |  | 27 |  |
| Operating income (loss) | 8 |  |  | (3 | ) |  | 892 |  |  | — |  |  | 897 |  |
| Interest income | — |  |  | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Interest expense | — |  |  | (71 | ) |  | (2 | ) |  | — |  |  | (73 | ) |
| Other (expense) income, net | (4 | ) |  | — |  |  | 2 |  |  | — |  |  | (2 | ) |
| Equity in net income of subsidiaries | 1,935 |  |  | 1,882 |  |  | — |  |  | (3,817 | ) |  | — |  |
| Intercompany interest and fees | (11 | ) |  | 31 |  |  | (15 | ) |  | (5 | ) |  | — |  |
| Income from continuing operations before income taxes | 1,928 |  |  | 1,839 |  |  | 887 |  |  | (3,822 | ) |  | 832 |  |
| Income tax benefit (expense) | 1 |  |  | (1 | ) |  | (164 | ) |  | — |  |  | (164 | ) |
| Equity income in earnings of unconsolidated subsidiaries | — |  |  | — |  |  | 206 |  |  | — |  |  | 206 |  |
| Income from continuing operations | 1,929 |  |  | 1,838 |  |  | 929 |  |  | (3,822 | ) |  | 874 |  |
| (Loss) income from discontinued operations, net of income taxes | (2 | ) |  | — |  |  | 1,054 |  |  | 5 |  |  | 1,057 |  |
| Net income | 1,927 |  |  | 1,838 |  |  | 1,983 |  |  | (3,817 | ) |  | 1,931 |  |
| Less: noncontrolling interest in subsidiaries net income | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Net income attributable to Tyco common shareholders | $ | 1,927 |  |  | $ | 1,838 |  |  | $ | 1,979 |  |  | $ | (3,817 | ) |  | $ | 1,927 |  |

[0000833444-14-000099:notes:48]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 1,927 |  |  | $ | 1,838 |  |  | $ | 1,983 |  |  | $ | (3,817 | ) |  | $ | 1,931 |  |
| Other comprehensive (loss) income, net of tax |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | (24 | ) |  | — |  |  | (24 | ) |  | 24 |  |  | (24 | ) |
| Defined benefit and post retirement plans | 16 |  |  | — |  |  | 16 |  |  | (16 | ) |  | 16 |  |
| Total other comprehensive loss, net of tax | (8 | ) |  | — |  |  | (8 | ) |  | 8 |  |  | (8 | ) |
| Comprehensive income | 1,919 |  |  | 1,838 |  |  | 1,975 |  |  | (3,809 | ) |  | 1,923 |  |
| Less: comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Comprehensive income attributable to Tyco common shareholders | $ | 1,919 |  |  | $ | 1,838 |  |  | $ | 1,971 |  |  | $ | (3,809 | ) |  | $ | 1,919 |  |

[0000833444-14-000099:notes:49]
For the Nine Months Ended June 28, 2013

[0000833444-14-000099:notes:50]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | 7,463 |  |  | $ | — |  |  | $ | 7,463 |  |
| Cost of product sales | — |  |  | — |  |  | 2,956 |  |  | — |  |  | 2,956 |  |
| Cost of services | — |  |  | — |  |  | 1,813 |  |  | — |  |  | 1,813 |  |
| Selling, general and administrative expenses | 9 |  |  | 2 |  |  | 2,118 |  |  | — |  |  | 2,129 |  |
| Separation costs | 4 |  |  | — |  |  | 5 |  |  | — |  |  | 9 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | 82 |  |  | — |  |  | 82 |  |
| Operating (loss) income | (13 | ) |  | (2 | ) |  | 489 |  |  | — |  |  | 474 |  |
| Interest income | 2 |  |  | — |  |  | 11 |  |  | — |  |  | 13 |  |
| Interest expense | (1 | ) |  | (71 | ) |  | (3 | ) |  | — |  |  | (75 | ) |
| Other (expense) income, net | (31 | ) |  | — |  |  | 1 |  |  | — |  |  | (30 | ) |
| Equity in net income of subsidiaries | 625 |  |  | 409 |  |  | — |  |  | (1,034 | ) |  | — |  |
| Intercompany interest and fees | (212 | ) |  | 100 |  |  | 112 |  |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 370 |  |  | 436 |  |  | 610 |  |  | (1,034 | ) |  | 382 |  |
| Income tax expense | — |  |  | (2 | ) |  | (54 | ) |  | — |  |  | (56 | ) |
| Equity loss in earnings of unconsolidated subsidiaries | — |  |  | — |  |  | (18 | ) |  | — |  |  | (18 | ) |
| Income from continuing operations | 370 |  |  | 434 |  |  | 538 |  |  | (1,034 | ) |  | 308 |  |
| Income from discontinued operations, net of income taxes | — |  |  | — |  |  | 62 |  |  | — |  |  | 62 |  |
| Net income | 370 |  |  | 434 |  |  | 600 |  |  | (1,034 | ) |  | 370 |  |
| Less: noncontrolling interest in subsidiaries net income | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net income attributable to Tyco common shareholders | $ | 370 |  |  | $ | 434 |  |  | $ | 600 |  |  | $ | (1,034 | ) |  | $ | 370 |  |

[0000833444-14-000099:notes:51]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 370 |  |  | $ | 434 |  |  | $ | 600 |  |  | $ | (1,034 | ) |  | $ | 370 |  |
| Other comprehensive (loss) income, net of tax |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | (225 | ) |  | — |  |  | (225 | ) |  | 225 |  |  | (225 | ) |
| Defined benefit and post retirement plans | 14 |  |  | — |  |  | 14 |  |  | (14 | ) |  | 14 |  |
| Total other comprehensive loss, net of tax | (211 | ) |  | — |  |  | (211 | ) |  | 211 |  |  | (211 | ) |
| Comprehensive income | 159 |  |  | 434 |  |  | 389 |  |  | (823 | ) |  | 159 |  |
| Less: comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Comprehensive income attributable to Tyco common shareholders | $ | 159 |  |  | $ | 434 |  |  | $ | 389 |  |  | $ | (823 | ) |  | $ | 159 |  |

[0000833444-14-000099:notes:52]
[same as prior period, unchanged from 0000833444-14-000046:notes:52]

[0000833444-14-000099:notes:53]
As of June 27, 2014

[0000833444-14-000099:notes:54]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | — |  |  | $ | 1,912 |  |  | $ | — |  |  | $ | 1,912 |  |
| Accounts receivable, net | — |  |  | — |  |  | 1,739 |  |  | — |  |  | 1,739 |  |
| Inventories | — |  |  | — |  |  | 650 |  |  | — |  |  | 650 |  |
| Intercompany receivables | 22 |  |  | 2,174 |  |  | 7,921 |  |  | (10,117 | ) |  | — |  |
| Prepaid expenses and other current assets | 18 |  |  | — |  |  | 1,123 |  |  | — |  |  | 1,141 |  |
| Deferred income taxes | — |  |  | — |  |  | 250 |  |  | — |  |  | 250 |  |
| Assets held for sale | — |  |  | — |  |  | 27 |  |  | — |  |  | 27 |  |
| Total current assets | 40 |  |  | 2,174 |  |  | 13,622 |  |  | (10,117 | ) |  | 5,719 |  |
| Property, plant and equipment, net | — |  |  | — |  |  | 1,283 |  |  | — |  |  | 1,283 |  |
| Goodwill | — |  |  | — |  |  | 4,212 |  |  | — |  |  | 4,212 |  |
| Intangible assets, net | — |  |  | — |  |  | 765 |  |  | — |  |  | 765 |  |
| Investment in subsidiaries | 14,082 |  |  | 16,634 |  |  | — |  |  | (30,716 | ) |  | — |  |
| Intercompany loans receivable | — |  |  | 1,607 |  |  | 5,339 |  |  | (6,946 | ) |  | — |  |
| Other assets | 38 |  |  | 5 |  |  | 754 |  |  | — |  |  | 797 |  |
| Total Assets | $ | 14,160 |  |  | $ | 20,420 |  |  | $ | 25,975 |  |  | $ | (47,779 | ) |  | $ | 12,776 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |
| Loans payable and current maturities of long-term debt | $ | — |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |
| Accounts payable | — |  |  | — |  |  | 851 |  |  | — |  |  | 851 |  |
| Accrued and other current liabilities | 291 |  |  | 34 |  |  | 1,637 |  |  | — |  |  | 1,962 |  |
| Deferred revenue | — |  |  | — |  |  | 411 |  |  | — |  |  | 411 |  |
| Intercompany payables | 3,516 |  |  | 4,418 |  |  | 2,183 |  |  | (10,117 | ) |  | — |  |
| Liabilities held for sale | — |  |  | — |  |  | 15 |  |  | — |  |  | 15 |  |
| Total current liabilities | 3,807 |  |  | 4,452 |  |  | 5,117 |  |  | (10,117 | ) |  | 3,259 |  |
| Long-term debt | — |  |  | 1,442 |  |  | 1 |  |  | — |  |  | 1,443 |  |
| Intercompany loans payable | 4,079 |  |  | 1,881 |  |  | 986 |  |  | (6,946 | ) |  | — |  |
| Deferred revenue | — |  |  | — |  |  | 344 |  |  | — |  |  | 344 |  |
| Other liabilities | 272 |  |  | — |  |  | 1,417 |  |  | — |  |  | 1,689 |  |
| Total Liabilities | 8,158 |  |  | 7,775 |  |  | 7,865 |  |  | (17,063 | ) |  | 6,735 |  |
| Redeemable noncontrolling interest | — |  |  | — |  |  | 13 |  |  | — |  |  | 13 |  |
| Tyco Shareholders' Equity: |  |  |  |  |  |  |  |  |  |
| Common shares | 208 |  |  | — |  |  | — |  |  | — |  |  | 208 |  |
| Common shares held in treasury | — |  |  | — |  |  | (1,513 | ) |  | — |  |  | (1,513 | ) |
| Other shareholders' equity | 5,794 |  |  | 12,645 |  |  | 19,584 |  |  | (30,716 | ) |  | 7,307 |  |
| Total Tyco Shareholders' Equity | 6,002 |  |  | 12,645 |  |  | 18,071 |  |  | (30,716 | ) |  | 6,002 |  |
| Nonredeemable noncontrolling interest | — |  |  | — |  |  | 26 |  |  | — |  |  | 26 |  |
| Total Equity | 6,002 |  |  | 12,645 |  |  | 18,097 |  |  | (30,716 | ) |  | 6,028 |  |
| Total Liabilities, Redeemable Noncontrolling Interest and Equity | $ | 14,160 |  |  | $ | 20,420 |  |  | $ | 25,975 |  |  | $ | (47,779 | ) |  | $ | 12,776 |  |

[0000833444-14-000099:notes:55]
[same as prior period, unchanged from 0000833444-14-000046:notes:55]

[0000833444-14-000099:notes:56]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | — |  |  | $ | 563 |  |  | $ | — |  |  | $ | 563 |  |
| Accounts receivable, net | — |  |  | — |  |  | 1,704 |  |  | — |  |  | 1,704 |  |
| Inventories | — |  |  | — |  |  | 645 |  |  | — |  |  | 645 |  |
| Intercompany receivables | 22 |  |  | 2,079 |  |  | 7,354 |  |  | (9,455 | ) |  | — |  |
| Prepaid expenses and other current assets | 9 |  |  | — |  |  | 830 |  |  | — |  |  | 839 |  |
| Deferred income taxes | — |  |  | — |  |  | 250 |  |  | — |  |  | 250 |  |
| Assets held for sale | — |  |  | — |  |  | 856 |  |  | — |  |  | 856 |  |
| Total current assets | 31 |  |  | 2,079 |  |  | 12,202 |  |  | (9,455 | ) |  | 4,857 |  |
| Property, plant and equipment, net | — |  |  | — |  |  | 1,284 |  |  | — |  |  | 1,284 |  |
| Goodwill | — |  |  | — |  |  | 4,162 |  |  | — |  |  | 4,162 |  |
| Intangible assets, net | — |  |  | — |  |  | 791 |  |  | — |  |  | 791 |  |
| Investment in subsidiaries | 12,826 |  |  | 14,690 |  |  | — |  |  | (27,516 | ) |  | — |  |
| Intercompany loans receivable | — |  |  | 1,141 |  |  | 5,310 |  |  | (6,451 | ) |  | — |  |
| Other assets | 68 |  |  | 6 |  |  | 1,008 |  |  | — |  |  | 1,082 |  |
| Total Assets | $ | 12,925 |  |  | $ | 17,916 |  |  | $ | 24,757 |  |  | $ | (43,422 | ) |  | $ | 12,176 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |
| Loans payable and current maturities of long-term debt | $ | — |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |
| Accounts payable | 1 |  |  | — |  |  | 847 |  |  | — |  |  | 848 |  |
| Accrued and other current liabilities | 353 |  |  | 23 |  |  | 1,476 |  |  | — |  |  | 1,852 |  |
| Deferred revenue | — |  |  | — |  |  | 393 |  |  | — |  |  | 393 |  |
| Intercompany payables | 3,515 |  |  | 3,845 |  |  | 2,095 |  |  | (9,455 | ) |  | — |  |
| Liabilities held for sale | — |  |  | — |  |  | 236 |  |  | — |  |  | 236 |  |
| Total current liabilities | 3,869 |  |  | 3,868 |  |  | 5,067 |  |  | (9,455 | ) |  | 3,349 |  |
| Long-term debt | — |  |  | 1,443 |  |  | — |  |  | — |  |  | 1,443 |  |
| Intercompany loans payable | 3,660 |  |  | 1,852 |  |  | 939 |  |  | (6,451 | ) |  | — |  |
| Deferred revenue | — |  |  | — |  |  | 370 |  |  | — |  |  | 370 |  |
| Other liabilities | 298 |  |  | — |  |  | 1,583 |  |  | — |  |  | 1,881 |  |
| Total Liabilities | 7,827 |  |  | 7,163 |  |  | 7,959 |  |  | (15,906 | ) |  | 7,043 |  |
| Redeemable noncontrolling interest | — |  |  | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Tyco Shareholders' Equity: |  |  |  |  |  |  |  |  |  |
| Common shares | 208 |  |  | — |  |  | — |  |  | — |  |  | 208 |  |
| Common shares held in treasury | — |  |  | — |  |  | (912 | ) |  | — |  |  | (912 | ) |
| Other shareholders' equity | 4,890 |  |  | 10,753 |  |  | 17,675 |  |  | (27,516 | ) |  | 5,802 |  |
| Total Tyco Shareholders' Equity | 5,098 |  |  | 10,753 |  |  | 16,763 |  |  | (27,516 | ) |  | 5,098 |  |
| Nonredeemable noncontrolling interest | — |  |  | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Total Equity | 5,098 |  |  | 10,753 |  |  | 16,786 |  |  | (27,516 | ) |  | 5,121 |  |
| Total Liabilities, Redeemable Noncontrolling Interest and Equity | $ | 12,925 |  |  | $ | 17,916 |  |  | $ | 24,757 |  |  | $ | (43,422 | ) |  | $ | 12,176 |  |

[0000833444-14-000099:notes:57]
[same as prior period, unchanged from 0000833444-14-000046:notes:57]

[0000833444-14-000099:notes:58]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |
| Net cash (used in) provided by operating activities | $ | (184 | ) |  | $ | 455 |  |  | $ | 249 |  |  | $ | — |  |  | $ | 520 |  |
| Net cash provided by discontinued operating activities | — |  |  | — |  |  | 100 |  |  | — |  |  | 100 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | (210 | ) |  | — |  |  | (210 | ) |
| Proceeds from disposal of assets | — |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | (63 | ) |  | — |  |  | (63 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases | — |  |  | — |  |  | (20 | ) |  | — |  |  | (20 | ) |
| Net increase in intercompany loans | — |  |  | (446 | ) |  | — |  |  | 446 |  |  | — |  |
| (Increase) decrease in investment in subsidiaries | (4 | ) |  | (9 | ) |  | 4 |  |  | 9 |  |  | — |  |
| Sales and maturities of investments | — |  |  | — |  |  | 283 |  |  | — |  |  | 283 |  |
| Purchases of investments | — |  |  | — |  |  | (332 | ) |  | — |  |  | (332 | ) |
| Sale of equity investment | — |  |  | — |  |  | 250 |  |  | — |  |  | 250 |  |
| Other | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Net cash used in investing activities | (4 | ) |  | (455 | ) |  | (79 | ) |  | 455 |  |  | (83 | ) |
| Net cash provided by discontinued investing activities | — |  |  | — |  |  | 1,789 |  |  | — |  |  | 1,789 |  |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short-term debt | — |  |  | 830 |  |  | — |  |  | — |  |  | 830 |  |
| Repayment of short-term debt | — |  |  | (830 | ) |  | (1 | ) |  | — |  |  | (831 | ) |
| Proceeds from exercise of share options | — |  |  | — |  |  | 79 |  |  | — |  |  | 79 |  |
| Dividends paid | (231 | ) |  | — |  |  | — |  |  | — |  |  | (231 | ) |
| Repurchase of common shares by treasury | — |  |  | — |  |  | (806 | ) |  | — |  |  | (806 | ) |
| Net intercompany loan borrowings | 419 |  |  | — |  |  | 27 |  |  | (446 | ) |  | — |  |
| Increase in equity from parent | — |  |  | — |  |  | 9 |  |  | (9 | ) |  | — |  |
| Transfer from discontinued operations | — |  |  | — |  |  | 1,889 |  |  | — |  |  | 1,889 |  |
| Other | — |  |  | — |  |  | (10 | ) |  | — |  |  | (10 | ) |
| Net cash provided by financing activities | 188 |  |  | — |  |  | 1,187 |  |  | (455 | ) |  | 920 |  |
| Net cash used in discontinued financing activities | — |  |  | — |  |  | (1,889 | ) |  | — |  |  | (1,889 | ) |
| Effect of currency translation on cash | — |  |  | — |  |  | (8 | ) |  | — |  |  | (8 | ) |
| Net increase in cash and cash equivalents | — |  |  | — |  |  | 1,349 |  |  | — |  |  | 1,349 |  |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | 563 |  |  | — |  |  | 563 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | — |  |  | $ | 1,912 |  |  | $ | — |  |  | $ | 1,912 |  |

[0000833444-14-000099:notes:59]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |
| Net cash (used in) provided by operating activities | $ | (242 | ) |  | $ | 388 |  |  | $ | 214 |  |  | $ | — |  |  | $ | 360 |  |
| Net cash provided by discontinued operating activities | — |  |  | — |  |  | 117 |  |  | — |  |  | 117 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | (205 | ) |  | — |  |  | (205 | ) |
| Proceeds from disposal of assets | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | (75 | ) |  | — |  |  | (75 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases | — |  |  | — |  |  | (14 | ) |  | — |  |  | (14 | ) |
| Intercompany dividend from subsidiary | — |  |  | 32 |  |  | — |  |  | (32 | ) |  | — |  |
| Net increase in intercompany loans | — |  |  | (359 | ) |  | — |  |  | 359 |  |  | — |  |
| Sales and maturities of investments | — |  |  | — |  |  | 103 |  |  | — |  |  | 103 |  |
| Purchases of investments | — |  |  | — |  |  | (182 | ) |  | — |  |  | (182 | ) |
| Other | — |  |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Net cash used in investing activities | — |  |  | (327 | ) |  | (363 | ) |  | 327 |  |  | (363 | ) |
| Net cash used in discontinued investing activities | — |  |  | — |  |  | (82 | ) |  | — |  |  | (82 | ) |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short-term debt | — |  |  | 380 |  |  | — |  |  | — |  |  | 380 |  |
| Repayment of short-term debt | — |  |  | (380 | ) |  | (11 | ) |  | — |  |  | (391 | ) |
| Proceeds from exercise of share options | — |  |  | — |  |  | 125 |  |  | — |  |  | 125 |  |
| Dividends paid | (214 | ) |  | — |  |  | — |  |  | — |  |  | (214 | ) |
| Intercompany dividend to parent | — |  |  | — |  |  | (32 | ) |  | 32 |  |  | — |  |
| Repurchase of common shares by treasury | — |  |  | — |  |  | (300 | ) |  | — |  |  | (300 | ) |
| Net intercompany loan borrowings (repayments) | 366 |  |  | — |  |  | (7 | ) |  | (359 | ) |  | — |  |
| Transfer from (to) discontinued operations | 90 |  |  | (61 | ) |  | 36 |  |  | — |  |  | 65 |  |
| Other | — |  |  | — |  |  | (35 | ) |  | — |  |  | (35 | ) |
| Net cash provided by (used in) financing activities | 242 |  |  | (61 | ) |  | (224 | ) |  | (327 | ) |  | (370 | ) |
| Net cash used in by discontinued financing activities | — |  |  | — |  |  | (65 | ) |  | — |  |  | (65 | ) |
| Effect of currency translation on cash | — |  |  | — |  |  | (16 | ) |  | — |  |  | (16 | ) |
| Net decrease in cash and cash equivalents | — |  |  | — |  |  | (419 | ) |  | — |  |  | (419 | ) |
| Less: net decrease in cash and cash equivalents related to discontinued operations | — |  |  | — |  |  | (30 | ) |  | — |  |  | (30 | ) |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | 844 |  |  | — |  |  | 844 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | — |  |  | $ | 455 |  |  | $ | — |  |  | $ | 455 |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-14-000099:notes:60]
Debt

[0000833444-14-000099:notes:61]
Debt as of June 27, 2014 and September 27, 2013 is as follows ($ in millions):

[0000833444-14-000099:notes:62]
|  | As of |
|  | June 27, 2014 |  | September 27,2013 |
| 3.375% public notes due 2015 | $ | 258 |  |  | $ | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 8.5% public notes due 2019 | 364 |  |  | 364 |  |
| 7.0% public notes due 2019 | 246 |  |  | 246 |  |
| 6.875% public notes due 2021 | 465 |  |  | 466 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| Other(1) | 21 |  |  | 20 |  |
| Total debt | 1,463 |  |  | 1,463 |  |
| Less current portion | 20 |  |  | 20 |  |
| Long-term debt | $ | 1,443 |  |  | $ | 1,443 |  |

[0000833444-14-000099:notes:63]
_______________________________________________________________________________

[0000833444-14-000099:notes:64]
| (1) | $20 million of the amount shown as Other as of both June 27, 2014 and September 27, 2013 represents the current portion of the Company's total debt. |

[0000833444-14-000099:notes:65]
Fair Value

[0000833444-14-000099:notes:66]
The carrying amount of Tyco's debt subject to the fair value disclosure requirements as of both June 27, 2014 and September 27, 2013 was $1,443 million.  The Company has determined the fair value of such debt to be $1,684 million and $1,676 million as of June 27, 2014 and September 27, 2013, respectively.  The Company utilizes various valuation methodologies to determine the fair value of its debt, which is primarily dependent on the type of market in which the Company's debt is traded. When available, the Company uses quoted market prices to determine the fair value of its debt that is traded in active markets.  As of June 27, 2014 and September 27, 2013, the Company's debt, all of which is actively traded and subject to the fair value disclosure requirements, is classified as Level 1 in the fair value hierarchy.

[0000833444-14-000099:notes:67]
Commercial paper

[0000833444-14-000099:notes:68]
From time to time Tyco International Finance S.A. ("TIFSA") may issue commercial paper for general corporate purposes. The maximum aggregate amount of unsecured commercial paper notes available to be issued on a private placement basis under the commercial paper program is $1 billion as of June 27, 2014.  As of June 27, 2014 and September 27, 2013, TIFSA had no commercial paper outstanding.

[0000833444-14-000099:notes:69]
Credit Facilities

[0000833444-14-000099:notes:70]
The Company's committed revolving credit facility totaled $1 billion as of June 27, 2014. This revolving credit facility may be used for working capital, capital expenditures and general corporate purposes. As of June 27, 2014 and September 27, 2013 there were no amounts drawn under the Company's revolving credit facility. Interest under the revolving credit facility is variable and is calculated by reference to LIBOR or an alternate base rate.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-14-000099:notes:71]
[same as prior period, unchanged from 0000833444-14-000046:notes:71]

[0000833444-14-000099:notes:72]
During the quarter ended December 27, 2013, the Company issued its annual share-based compensation grants. The total number of awards issued was approximately 3.0 million, of which 1.9 million were stock options, 0.5 million were restricted unit awards and 0.6 million were performance share unit awards. The options and restricted stock units vest in equal annual installments over a period of 4 years, and the performance share unit awards vest after a period of 3 years based on the level of attainment of the applicable performance metrics, which are determined by the Compensation and Human Resources Committee of the Board. The weighted-average grant-date fair value of the stock options, restricted unit awards and performance share unit awards was $10.12, $37.15 and $39.01, respectively. The weighted-average assumptions used in the Black-Scholes option pricing model included an expected stock price volatility of 33%, a risk free interest rate of 1.63%, an expected annual dividend per share of $0.64 and an expected option life of 5.5 years.  The preceding annual share-based compensation grant information was not recast for the divestiture of the South Korean security business as the amounts were not material.

[0000833444-14-000099:notes:73]
[same as prior period, unchanged from 0000833444-14-000046:notes:73]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-14-000099:notes:74]
[same as prior period, unchanged from 0000833444-14-000046:notes:74]

[0000833444-14-000099:notes:75]
[same as prior period, unchanged from 0000833444-14-000046:notes:75]

[0000833444-14-000099:notes:76]
[same as prior period, unchanged from 0000833444-14-000046:notes:76]

[0000833444-14-000099:notes:77]
The Company intends to sell several businesses in the ROW Installation and Services segment.  The businesses are accounted for as held for sale on the Consolidated Balance Sheets as of June 27, 2014 and September 27, 2013, and their results of operations have been presented as discontinued operations on the Consolidated Statements of Operations during the quarters and nine months ended June 27, 2014 and June 28, 2013.  During the quarter ended June 27, 2014, the Company recorded a $1 million impairment loss related to writing down the net assets to their fair value.

[0000833444-14-000099:notes:78]
On May 22, 2014, the Company, together with its wholly-owned subsidiary Tyco Far East Holdings Ltd. (the “Seller”) completed the sale of Tyco Fire & Security Services Korea Co. Ltd. and its subsidiaries that form and operate the Company’s ADT Korea business to an affiliate of The Carlyle Group pursuant to a stock purchase agreement previously reported in the Company's Current Report on Form 8-K filed with the SEC on March 4, 2014. The transaction took the form of a sale by the Seller of all of the stock of Tyco Fire & Security Services Korea Co. Ltd. for an aggregate purchase price of $1.93 billion, subject to customary adjustments as set forth in the stock purchase agreement.  The Company recognized a gain of $1.0 billion, net of a $212 million charge related to the indemnification at fair value for certain tax related matters borne by the buyer that are probable of being paid.  The net gain was recorded in income from discontinued operations, net of income taxes, on the Consolidated Statements of Operations for the  quarter and nine months ended June 27, 2014.  This business was accounted for as held for sale on the Consolidated Balance Sheets as of September 27, 2013, and its results of operations have been presented within discontinued operations on the Consolidated Statements of Operations during the quarters and nine months ended June 27, 2014 and June 28, 2013.

[0000833444-14-000099:notes:79]
On March 6, 2014, the Company announced Atkore International Group Inc.'s (“Atkore”) intention to redeem all of the Company’s remaining common equity stake in Atkore.  The redemption was completed on April 9, 2014 for aggregate cash proceeds of $250 million.  This amount may be adjusted upward by up to $25 million if, prior to December 31, 2014, there is a sale or merger of Atkore, a sale of substantially all of Atkore's assets or an initial public offering of Atkore's stock.  The Company recognized a net gain of $216 million related to this transaction, which is included in Equity gain (loss) in earnings of unconsolidated subsidiaries in the Consolidated Statement of Operations for the quarter and nine months ended June 27, 2014.  The net gain is comprised of a $227 million gain on the sale of the equity investment, partially offset by an $11 million loss, which is the Company's share of loss on Atkore's debt extinguishment undertaken in connection with the redemption.

[0000833444-14-000099:notes:80]
During the quarter ended December 27, 2013, the Company completed the sale of its Armourguard business in New Zealand and its fire and security business in Fiji, both of which were in its ROW Installation & Services segment, for an immaterial amount.  These businesses were accounted for as held for sale as of September 27, 2013; however, the assets and liabilities have not been presented separately in the Consolidated Balance Sheets, and these businesses have not been presented in discontinued operations in the Consolidated Statements of Operations for all periods presented because the amounts were not material.

[0000833444-14-000099:notes:81]
[same as prior period, unchanged from 0000833444-14-000046:notes:79]

[0000833444-14-000099:notes:82]
On September 28, 2012, Tyco completed the 2012 Separation.  See Note 2 for additional information. At the time of the 2012 Separation, the Company used available information to develop its best estimates for certain assets and liabilities related to the transaction. In limited instances, final determination of the balances will be made in subsequent periods, such as in the case of when final income tax returns are filed in certain jurisdictions where those returns include a combination of Tyco, ADT and/or Tyco Flow Control legal entities.   During the quarter ended June 28, 2013, a net increase of $59 million was recorded within the Consolidated Statement of Shareholders' Equity as Other, primarily related to a cash true-up adjustment from Pentair.   During the nine months ended June 28, 2013, a net increase of $14 million was recorded within the Consolidated Statement of Shareholders' Equity as Other, primarily related to a cash true-up adjustment received from Pentair as discussed, partially offset by a cash true-up adjustment paid to ADT during the first quarter of fiscal 2013.  During the nine months ended June 27, 2014, there were no adjustments recorded within the Consolidated Statement of Shareholders' Equity related to the 2012 Separation.

[0000833444-14-000099:notes:83]
[same as prior period, unchanged from 0000833444-14-000046:notes:83]

[0000833444-14-000099:notes:84]
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 27, 2014 |  | June 28, 2013 |  | June 27, 2014 |  | June 28, 2013 |
| Net revenue | $ | 85 |  |  | $ | 141 |  |  | $ | 390 |  |  | $ | 423 |  |
| Pre-tax income from discontinued operations | 9 |  |  | 26 |  |  | 61 |  |  | 73 |  |
| Pre-tax separation (charges) income included within discontinued operations (See Note 2) | (1 | ) |  | 3 |  |  | (2 | ) |  | 5 |  |
| Pre-tax gain on sale of discontinued operations | 1,179 |  |  | — |  |  | 1,175 |  |  | — |  |
| Income tax expense | (171 | ) |  | (6 | ) |  | (177 | ) |  | (16 | ) |
| Income from discontinued operations, net of income taxes | $ | 1,016 |  |  | $ | 23 |  |  | $ | 1,057 |  |  | $ | 62 |  |

[0000833444-14-000099:notes:85]
Balance sheet information for the discontinued operations as of June 27, 2014 and September 27, 2013 was as follows ($ in millions):

[0000833444-14-000099:notes:86]
|  | As of |
|  | June 27, 2014 |  | September 27, 2013 |
| Accounts receivable, net | $ | 11 |  |  | $ | 34 |  |
| Inventories | 2 |  |  | 10 |  |
| Prepaid expenses and other current assets | 12 |  |  | 22 |  |
| Property, plant and equipment, net | — |  |  | 393 |  |
| Goodwill and intangible assets, net | — |  |  | 370 |  |
| Other assets | 2 |  |  | 27 |  |
| Total assets | $ | 27 |  |  | $ | 856 |  |
| Accounts payable | 3 |  |  | 52 |  |
| Accrued and other current liabilities | 11 |  |  | 66 |  |
| Other liabilities | 1 |  |  | 118 |  |
| Total liabilities | $ | 15 |  |  | $ | 236 |  |

[0000833444-14-000099:notes:87]
Divestiture (Losses) Gains, Net

[0000833444-14-000099:notes:88]
For the quarter and nine months ended June 27, 2014, the Company recorded a net loss of $1 million and net gain of $2 million, respectively, in Selling, general and administrative expenses in the Company's Consolidated Statements of Operations, primarily related to a favorable court judgment regarding a divested business.

[0000833444-14-000099:notes:89]
For the quarter and nine months ended June 28, 2013, the Company recorded a net loss of $4 million and $10 million, respectively, in Selling, general and administrative expenses in the Company's Consolidated Statements of Operations.  The net loss for the quarter ended June 28, 2013 was primarily related to a net charge recorded in respect of a legacy environmental remediation obligation of a divested business. The net loss for the nine months ended June 28, 2013 also included a net indemnification loss related to the divestiture of the Company's Electrical and Metal Products business (Atkore) as well as the write-down to fair value, less cost to sell, of the North America guarding business that was held for sale in the second quarter of fiscal 2013 and subsequently divested in the third quarter of fiscal 2013.


## us-gaap:EarningsPerShareTextBlock

[0000833444-14-000099:notes:90]
[same as prior period, unchanged from 0000833444-14-000046:notes:90]

[0000833444-14-000099:notes:91]
[same as prior period, unchanged from 0000833444-14-000046:notes:91]

[0000833444-14-000099:notes:92]
|  | For the Quarter Ended June 27, 2014 |  | For the Quarter Ended June 28, 2013 |
|  | Income |  | Shares |  | Per ShareAmount |  | Income |  | Shares |  | Per ShareAmount |
| Basic earnings per share attributable to Tyco common shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 434 |  |  | 458 |  |  | $ | 0.95 |  |  | $ | 112 |  |  | 463 |  |  | $ | 0.24 |  |
| Share options and restricted share awards | — |  |  | 8 |  |  |  |  | — |  |  | 8 |  |  |  |
| Diluted earnings per share attributable to Tyco common shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations attributable to Tyco common shareholders, giving effect to dilutive adjustments | $ | 434 |  |  | 466 |  |  | $ | 0.93 |  |  | $ | 112 |  |  | 471 |  |  | $ | 0.24 |  |

[0000833444-14-000099:notes:93]
|  | For the Nine Months EndedJune 27, 2014 |  | For the Nine Months EndedJune 28, 2013 |
|  | Income |  | Shares |  | Per ShareAmount |  | Income |  | Shares |  | Per ShareAmount |
| Basic earnings per share attributable to Tyco common shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 870 |  |  | 461 |  |  | $ | 1.89 |  |  | $ | 308 |  |  | 465 |  |  | $ | 0.66 |  |
| Share options and restricted share awards | — |  |  | 8 |  |  |  |  | — |  |  | 8 |  |  |  |
| Diluted earnings per share attributable to Tyco common shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations attributable to Tyco common shareholders, giving effect to dilutive adjustments | $ | 870 |  |  | 469 |  |  | $ | 1.85 |  |  | $ | 308 |  |  | 473 |  |  | $ | 0.65 |  |

[0000833444-14-000099:notes:94]
The computation of diluted earnings per share for the quarter and nine months ended June 27, 2014 excludes the effect of the potential exercise of share options to purchase approximately 2 million shares for both periods and excludes restricted stock units of approximately 1 million and 2 million shares, respectively, for the quarter and nine months ended June 27, 2014 because the effect would be anti-dilutive.

[0000833444-14-000099:notes:95]
The computation of diluted earnings per share for the quarter and nine months ended June 28, 2013 excludes the effect of the potential exercise of share options to purchase approximately 4 million and 5 million shares, respectively and excludes restricted stock units of 1 million shares for both periods because the effect would be anti-dilutive.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000833444-14-000099:notes:96]
The following table presents the Company's hierarchy for its assets measured at fair value on a recurring basis as of June 27, 2014 and September 27, 2013:

[0000833444-14-000099:notes:97]
|  |  |  |  |  |  |  | Consolidated Balance SheetClassification |
|  | As of June 27, 2014 |  | Prepaids andOther CurrentAssets |  | Other Assets |
| ($ in millions) | Level 1 |  | Level 2 |  | Total |  |
| Investment assets: |  |  |  |  |  |  |  |  |  |
| Time deposits | $ | 277 |  |  | $ | — |  |  | $ | 277 |  |  | $ | 277 |  |  | $ | — |  |

[0000833444-14-000099:notes:98]
[same as prior period, unchanged from 0000833444-14-000046:notes:98]


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000833444-14-000099:notes:99]
[same as prior period, unchanged from 0000833444-14-000046:notes:99]

[0000833444-14-000099:notes:100]
The Company's financial instruments consist primarily of cash and cash equivalents, time deposits, accounts receivable, investments, accounts payable, debt and derivative financial instruments. The fair value of cash and cash equivalents, time deposits, accounts receivable, and accounts payable approximated book value as of June 27, 2014 and September 27, 2013. The fair value of derivative financial instruments was not material to any of the periods presented. See below for the fair value of investments and Note 9 for the fair value of debt.

[0000833444-14-000099:notes:101]
[same as prior period, unchanged from 0000833444-14-000046:notes:101]

[0000833444-14-000099:notes:102]
In the normal course of business, Tyco is exposed to market risk arising from changes in currency exchange rates, interest rates and commodity prices. The Company may use derivative financial instruments to manage exposures to foreign currency, interest rate and commodity risks. The Company's objective for utilizing derivative financial instruments is to manage these risks using the most effective methods to eliminate or reduce the impacts of these exposures. The Company does not use derivative financial instruments for trading or speculative purposes. As of and during the nine months ended June 27, 2014, the Company did not hold or enter into any commodity derivative instruments or interest rate swaps.

[0000833444-14-000099:notes:103]
For derivative instruments that are designated and qualified as hedging instruments for accounting purposes, the Company documents and links the relationships between the hedging instruments and hedged items. The Company also assesses and documents at the hedge's inception whether the derivatives used in hedging transactions are effective in offsetting changes in fair values associated with the hedged items. For the quarters and nine months ended June 27, 2014 and June 28, 2013, the Company did not have any derivative instruments that were designated and qualified as hedging instrument for accounting purposes.

[0000833444-14-000099:notes:104]
[same as prior period, unchanged from 0000833444-14-000046:notes:104]

[0000833444-14-000099:notes:105]
The Company manages foreign currency exchange rate risk through the use of derivative financial instruments comprised principally of forward contracts on foreign currency which are not designated as hedging instruments for accounting purposes. The objective of the derivative instruments is to minimize the income statement impact and potential variability in cash flows associated with intercompany loans, accounts receivable, accounts payable and forecasted transactions that are denominated in certain foreign currencies.  The fair value of these derivative financial instruments and impact of such changes in the fair value was not material to the Consolidated Balance Sheets as of June 27, 2014 and September 27, 2013 or Consolidated Statements of Operations and Consolidated Statements of Cash Flows for the quarters and nine months ended June 27, 2014 and June 28, 2013. As of June 27, 2014 and September 27, 2013, the total gross notional amount of the Company's foreign exchange contracts was $423 million and $278 million, respectively, including contracts of $25 million and $60 million, respectively, related to the ADT Korea business.

[0000833444-14-000099:notes:106]
[same as prior period, unchanged from 0000833444-14-000046:notes:106]

[0000833444-14-000099:notes:107]
[same as prior period, unchanged from 0000833444-14-000046:notes:107]

[0000833444-14-000099:notes:108]
[same as prior period, unchanged from 0000833444-14-000046:notes:108]

[0000833444-14-000099:notes:109]
Investments primarily include marketable securities such as U.S. government obligations, U.S. government agency securities and corporate debt securities, and time deposits with banks.

[0000833444-14-000099:notes:110]
[same as prior period, unchanged from 0000833444-14-000046:notes:110]

[0000833444-14-000099:notes:111]
During the nine months ended June 27, 2014, the Company liquidated its portfolio of corporate and U.S. Government debt securities. The Company recorded a $1 million gain on the sale of investments during both the quarter and nine months ended June 27, 2014 related to this liquidation.  During the quarter ended June 27, 2014, the Company purchased time deposits, and as of June 27, 2014, the Company held time deposits of $277 million, which are recorded in Prepaid expenses and other current assets in the Consolidated Balance Sheet.

[0000833444-14-000099:notes:112]
[same as prior period, unchanged from 0000833444-14-000046:notes:111]

[0000833444-14-000099:notes:113]
During the quarter and nine months ended June 27, 2014, the Company did not have any significant transfers between levels within the fair value hierarchy.

[0000833444-14-000099:notes:114]
[same as prior period, unchanged from 0000833444-14-000046:notes:113]

[0000833444-14-000099:notes:115]
In addition to the gain related to the liquidation of our investment portfolio as described above, the nine months ended June 27, 2014 also included a $7 million loss on the sale of an investment related to the Company's ROW Installation & Services business.

[0000833444-14-000099:notes:116]
Additionally, the Company had $1.5 billion and $1.4 billion of intercompany loans designated as permanent in nature as of June 27, 2014 and September 27, 2013, respectively. For the quarters ended June 27, 2014 and June 28, 2013, the Company recorded $3 million and $25 million of a cumulative translation loss, respectively, through accumulated other comprehensive loss related to these loans.

[0000833444-14-000099:notes:117]
For the nine months ended June 27, 2014 and June 28, 2013, the Company recorded $1 million of cumulative translation gain and $87 million of cumulative translation loss, respectively, through accumulated other comprehensive loss related to these loans.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-14-000099:notes:118]
[same as prior period, unchanged from 0000833444-14-000046:notes:117]

[0000833444-14-000099:notes:119]
[same as prior period, unchanged from 0000833444-14-000046:notes:118]

[0000833444-14-000099:notes:120]
|  | NA Installation &Services |  | ROWInstallation &Services |  | GlobalProducts |  | Total |
| As of September 28, 2012 |  |  |  |  |  |  |  |
| Gross goodwill | $ | 2,127 |  |  | $ | 1,972 |  |  | $ | 1,696 |  |  | $ | 5,795 |  |
| Impairments | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill | 2,001 |  |  | 904 |  |  | 1,129 |  |  | 4,034 |  |
| Acquisitions/Purchase accounting adjustments | 24 |  |  | 42 |  |  | 90 |  |  | 156 |  |
| Transfers | (39 | ) |  | — |  |  | 39 |  |  | — |  |
| Currency translation | (8 | ) |  | (19 | ) |  | (1 | ) |  | (28 | ) |
| As of September 27, 2013 |  |  |  |  |  |  |  |
| Gross goodwill | $ | 2,104 |  |  | $ | 1,995 |  |  | $ | 1,824 |  |  | $ | 5,923 |  |
| Impairments | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill | 1,978 |  |  | 927 |  |  | 1,257 |  |  | 4,162 |  |
| Acquisitions/Purchase accounting adjustments | 9 |  |  | 17 |  |  | 2 |  |  | 28 |  |
| Currency translation | (6 | ) |  | 28 |  |  | — |  |  | 22 |  |
| As of June 27, 2014 |  |  |  |  |  |  |  |
| Gross goodwill | $ | 2,107 |  |  | $ | 2,040 |  |  | $ | 1,826 |  |  | $ | 5,973 |  |
| Impairments | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill | $ | 1,981 |  |  | $ | 972 |  |  | $ | 1,259 |  |  | $ | 4,212 |  |

[0000833444-14-000099:notes:121]
The following table sets forth the gross carrying amount and accumulated amortization of the Company's intangible assets as of June 27, 2014 and September 27, 2013 ($ in millions):

[0000833444-14-000099:notes:122]
|  | As of |
|  | June 27, 2014 |  | September 27, 2013 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Amortizable: |  |  |  |  |  |  |  |
| Contracts and related customer relationships | $ | 1,465 |  |  | $ | 1,155 |  |  | $ | 1,420 |  |  | $ | 1,101 |  |
| Intellectual property | 623 |  |  | 487 |  |  | 623 |  |  | 477 |  |
| Other | 40 |  |  | 19 |  |  | 40 |  |  | 13 |  |
| Total | $ | 2,128 |  |  | $ | 1,661 |  |  | $ | 2,083 |  |  | $ | 1,591 |  |
| Non-Amortizable: |  |  |  |  |  |  |  |
| Intellectual property | $ | 222 |  |  |  |  |  | $ | 223 |  |  |  |
| Franchise rights | 76 |  |  |  |  |  | 76 |  |  |  |
| Total | $ | 298 |  |  |  |  |  | $ | 299 |  |  |  |

[0000833444-14-000099:notes:123]
Intangible asset amortization expense for the quarters ended June 27, 2014 and June 28, 2013 was $23 million and $22 million, respectively. Intangible asset amortization expense for the nine months ended June 27, 2014 and June 28, 2013 was $70 million and $72 million, respectively.

[0000833444-14-000099:notes:124]
The estimated aggregate amortization expense on intangible assets is expected to be approximately $23 million for the remainder of 2014, $75 million for 2015, $69 million for 2016, $61 million for 2017, and $239 million for 2018 and thereafter.


## us-gaap:GuaranteesTextBlock

[0000833444-14-000099:notes:125]
[same as prior period, unchanged from 0000833444-14-000046:notes:124]

[0000833444-14-000099:notes:126]
[same as prior period, unchanged from 0000833444-14-000046:notes:125]

[0000833444-14-000099:notes:127]
[same as prior period, unchanged from 0000833444-14-000046:notes:126]

[0000833444-14-000099:notes:128]
In addition, Tyco historically provided support in the form of financial and/or performance guarantees to various Covidien, TE Connectivity, ADT and Tyco Flow Control operating entities. In connection with both the 2012 and 2007 Separations, the Company worked with the guarantee counterparties to cancel or assign these guarantees to Covidien, TE Connectivity, ADT or Pentair, as appropriate. To the extent these guarantees were not assigned prior to the Separation dates, Tyco remained as the guarantor, but was typically indemnified by the former subsidiary. The Company's obligations related to the 2012 Separation were $3 million, which were included in Other liabilities on the Company's Consolidated Balance Sheets as of both June 27, 2014 and September 27, 2013, with an offset to Tyco's shareholders' equity on the 2012 Separation date. The Company's obligations related to the 2007 Separation were $3 million, which were included in Other liabilities on the Company's Consolidated Balance Sheets as of both June 27, 2014 and September 27, 2013, with an offset to Tyco's shareholders' equity on the 2007 Separation date.

[0000833444-14-000099:notes:129]
In disposing of assets or businesses, the Company often provides representations, warranties and/or indemnities to cover various risks including, for example, unknown damage to the assets, environmental risks involved in the sale of real estate, liability to investigate and remediate environmental contamination at waste disposal sites and manufacturing facilities and unidentified tax liabilities and legal fees related to periods prior to disposition. The Company has no reason to believe that these contingencies, if realized, would have a material adverse effect on the Company's financial position, results of operations or cash flows. The Company has recorded liabilities for known indemnifications included as part of environmental liabilities. See Note 11.

[0000833444-14-000099:notes:130]
During the quarter ended June 27, 2014, Tyco replaced available for sale investments held as collateral for the Company's insurable liabilities with letters of credit of approximately $137 million.  See Note 10 for additional information.  The Company had total outstanding letters of credit and bank guarantees of approximately $561 million and $424 million as of June 27, 2014 and September 27, 2013, respectively.

[0000833444-14-000099:notes:131]
[same as prior period, unchanged from 0000833444-14-000046:notes:129]

[0000833444-14-000099:notes:132]
| Balance as of September 27, 2013 | $ | 31 |  |
| Warranties issued | 5 |  |
| Changes in estimates | (3 | ) |
| Settlements | (5 | ) |
| Balance as of June 27, 2014 | $ | 28 |  |

[0000833444-14-000099:notes:133]
[same as prior period, unchanged from 0000833444-14-000046:notes:131]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-14-000099:notes:134]
[same as prior period, unchanged from 0000833444-14-000046:notes:132]

[0000833444-14-000099:notes:135]
Tyco did not have a significant change to its unrecognized tax benefits during the quarter ended June 27, 2014.

[0000833444-14-000099:notes:136]
[same as prior period, unchanged from 0000833444-14-000046:notes:134]

[0000833444-14-000099:notes:137]
| Jurisdiction | Years OpenTo Audit |
| Australia | 2004-2013 |
| Canada | 2005-2013 |
| Germany | 2005-2013 |
| Switzerland | 2004-2013 |
| United Kingdom | 2012-2013 |
| United States | 1997-2013 |

[0000833444-14-000099:notes:138]
[same as prior period, unchanged from 0000833444-14-000046:notes:137]

[0000833444-14-000099:notes:139]
At each balance sheet date, the Company evaluates whether it is more likely than not that Tyco's deferred tax assets will be realized and if sufficient future taxable income will be available by assessing current period and projected operating results and other pertinent data. As of June 27, 2014, Tyco recorded deferred tax assets of approximately $211 million, which is comprised of $2.2 billion gross deferred tax assets net of $2.0 billion valuation allowances.

[0000833444-14-000099:notes:140]
[same as prior period, unchanged from 0000833444-14-000046:notes:139]

[0000833444-14-000099:notes:141]
[same as prior period, unchanged from 0000833444-14-000046:notes:140]

[0000833444-14-000099:notes:142]
[same as prior period, unchanged from 0000833444-14-000046:notes:141]

[0000833444-14-000099:notes:143]
[same as prior period, unchanged from 0000833444-14-000046:notes:142]

[0000833444-14-000099:notes:144]
[same as prior period, unchanged from 0000833444-14-000046:notes:143]

[0000833444-14-000099:notes:145]
Tyco and its subsidiaries' income tax returns are examined periodically by various tax authorities. In connection with these examinations, tax authorities, including the IRS, have raised issues and proposed tax adjustments. The issues and proposed adjustments related to such years are generally subject to the sharing provisions of the 2007 Tax Sharing Agreement, and Tyco's liabilities under the 2007 Tax Sharing Agreement are further subject to the sharing provisions in the 2012 Tax Sharing Agreement. Tyco has previously disclosed that in connection with U.S. federal tax audits, the IRS has raised a number of issues and proposed tax adjustments for periods beginning with the 1997 tax year. Although Tyco has been able to resolve substantially all of the issues and adjustments proposed by the IRS for tax years through 2007, it has not been able to resolve matters related to the treatment of certain intercompany debt transactions during the period. As a result, on June 20, 2013, Tyco received Notices of Deficiency from the IRS asserting that several of Tyco's former U.S. subsidiaries owe additional taxes of $883.3 million plus penalties of $154 million based on audits of the 1997 through 2000 tax years of Tyco and its subsidiaries as they existed at that time. In addition, Tyco received Final Partnership Administrative Adjustments for certain U.S. partnerships owned by former U.S. subsidiaries with respect to which an additional tax deficiency of approximately $30 million has been asserted. These amounts exclude interest and do not reflect the impact on subsequent periods if the IRS position described below is ultimately proved correct.

[0000833444-14-000099:notes:146]
[same as prior period, unchanged from 0000833444-14-000046:notes:145]

[0000833444-14-000099:notes:147]
[same as prior period, unchanged from 0000833444-14-000046:notes:146]

[0000833444-14-000099:notes:148]
In addition to dealing with tax liabilities for periods prior to the respective Separations, the 2012 and 2007 Tax Sharing Agreements contain sharing provisions to address the contingencies that the 2012 or 2007 Separations, or internal transactions related thereto, may be deemed taxable by U.S. or non U.S. taxing authorities. In the event the 2012 Separation is determined to be taxable and such determination was the result of actions taken after the 2012 Separations by Tyco, ADT or Pentair, the party responsible for such failure would be responsible for all taxes imposed on each company as a result thereof. If such determination is not the result of actions taken by Tyco, ADT or Pentair after the 2012 Separation, then Tyco, ADT and Pentair would be responsible for any taxes imposed on any of the companies as a result of such determination in the same manner and in the same proportions as described above. Similar provisions exist in the 2007 Tax Sharing Agreement. If either of the 2007 or 2012 Separation, or internal transactions taken in anticipation thereof, were deemed taxable, the associated liability could be significant. Tyco is responsible for all of its own taxes that are not shared pursuant to the 2012 and 2007 Tax Sharing Agreements sharing formulas. In addition, Pentair and ADT, and Covidien and TE Connectivity are responsible for their tax liabilities that are not subject to the 2012 or 2007 Tax Sharing Agreements' sharing formula.

[0000833444-14-000099:notes:149]
[same as prior period, unchanged from 0000833444-14-000046:notes:148]

[0000833444-14-000099:notes:150]
During the quarter ended June 27, 2014, Tyco made a net cash payment of $155 million to Covidien under the terms of the 2007 Tax Sharing Agreement.  The cash exchanged was a reimbursement between the parties for various payments made to the IRS for federal income taxes related to the audit of fiscal years 2005 through 2007.

[0000833444-14-000099:notes:151]
The receivables and liabilities related to the 2012 and 2007 Tax Sharing Agreements as of June 27, 2014 and September 27, 2013, are as follows ($ in millions):

[0000833444-14-000099:notes:152]
|  | 2012 Tax Sharing Agreement |  | 2007 Tax Sharing Agreement |
|  | As of |  | As of |
|  | June 27, 2014 |  | September 27, 2013 |  | June 27, 2014 |  | September 27, 2013 |
| Tax sharing agreement related receivables: |  |  |  |  |  |  |  |
| Prepaid expenses and other current assets | $ | — |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |
| Other assets | — |  |  | — |  |  | 35 |  |  | 67 |  |
|  | — |  |  | — |  |  | 48 |  |  | 67 |  |
| Tax sharing agreement related liabilities: |  |  |  |  |  |  |  |
| Accrued and other current liabilities | — |  |  | (33 | ) |  | (21 | ) |  | (130 | ) |
| Other liabilities | (66 | ) |  | (36 | ) |  | (194 | ) |  | (254 | ) |
|  | (66 | ) |  | (69 | ) |  | (215 | ) |  | (384 | ) |
| Net liability | $ | (66 | ) |  | $ | (69 | ) |  | $ | (167 | ) |  | $ | (317 | ) |

[0000833444-14-000099:notes:153]
Tyco recorded amounts in conjunction with the 2012 and 2007 Tax Sharing Agreements within Other expense, net in the Consolidated Statements of Operations for the quarters and nine months ended June 27, 2014 and June 28, 2013 as follows ($ in millions):

[0000833444-14-000099:notes:154]
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 27, 2014 |  | June 28, 2013 |  | June 27, 2014 |  | June 28, 2013 |
| (Loss) income |  |  |  |  |  |  |  |
| 2012 Tax Sharing Agreement | $ | — |  |  | $ | (1 | ) |  | $ | (5 | ) |  | $ | (31 | ) |
| 2007 Tax Sharing Agreement | — |  |  | — |  |  | 1 |  |  | — |  |

[0000833444-14-000099:notes:155]
[same as prior period, unchanged from 0000833444-14-000046:notes:153]

[0000833444-14-000099:notes:156]
During the quarter ended June 27, 2014, Tyco incurred a charge of nil to make payments to ADT and Pentair based on estimated allowable deductions for ADT and Pentair shares issued to Company employees.  During the nine months ended June 27, 2014, Tyco incurred a charge of $6 million to make payments to ADT and Pentair based on estimated allowable deductions for ADT and Pentair shares issued to Company employees, offset by income of $1 million to be received from ADT and Pentair for Company shares issued to their employees, resulting in a net impact of approximately $5 million.

[0000833444-14-000099:notes:157]
During the quarter and nine months ended June 28, 2013, Tyco incurred a charge of $1 million and $35 million, respectively, to make payments to ADT and Pentair based on estimated allowable deductions for ADT and Pentair shares issued to Company employees, offset by income of nil and $4 million, respectively, to be received from ADT and Pentair for Company shares issued to their employees, resulting in a net impact of approximately $1 million and $31 million, respectively, which was recorded in Other (expense) income, net within Tyco's Consolidated Statement of Operations.

[0000833444-14-000099:notes:158]
[same as prior period, unchanged from 0000833444-14-000046:notes:155]

[0000833444-14-000099:notes:159]
[same as prior period, unchanged from 0000833444-14-000046:notes:156]


## us-gaap:InventoryDisclosureTextBlock

[0000833444-14-000099:notes:160]
[same as prior period, unchanged from 0000833444-14-000046:notes:157]

[0000833444-14-000099:notes:161]
[same as prior period, unchanged from 0000833444-14-000046:notes:158]

[0000833444-14-000099:notes:162]
|  | As of |
|  | June 27, 2014 |  | September 27, 2013 |
| Purchased materials and manufactured parts | $ | 170 |  |  | $ | 157 |  |
| Work in process | 79 |  |  | 93 |  |
| Finished goods | 401 |  |  | 395 |  |
| Inventories | $ | 650 |  |  | $ | 645 |  |

[0000833444-14-000099:notes:163]
[same as prior period, unchanged from 0000833444-14-000046:notes:160]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-14-000099:notes:164]
[same as prior period, unchanged from 0000833444-14-000046:notes:161]

[0000833444-14-000099:notes:165]
[same as prior period, unchanged from 0000833444-14-000046:notes:162]

[0000833444-14-000099:notes:166]
|  | U.S. Plans |
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 27, 2014 |  | June 28, 2013 |  | June 27, 2014 |  | June 28, 2013 |
| Service cost | $ | 2 |  |  | $ | 1 |  |  | $ | 6 |  |  | $ | 4 |  |
| Interest cost | 10 |  |  | 8 |  |  | 28 |  |  | 24 |  |
| Expected return on plan assets | (14 | ) |  | (12 | ) |  | (38 | ) |  | (36 | ) |
| Amortization of net actuarial loss | 3 |  |  | 4 |  |  | 7 |  |  | 11 |  |
| Net periodic benefit cost | $ | 1 |  |  | $ | 1 |  |  | $ | 3 |  |  | $ | 3 |  |

[0000833444-14-000099:notes:167]
|  | Non-U.S. Plans |
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 27, 2014 |  | June 28, 2013 |  | June 27, 2014 |  | June 28, 2013 |
| Service cost | $ | 2 |  |  | $ | 2 |  |  | $ | 7 |  |  | $ | 6 |  |
| Interest cost | 13 |  |  | 12 |  |  | 41 |  |  | 38 |  |
| Expected return on plan assets | (17 | ) |  | (17 | ) |  | (55 | ) |  | (52 | ) |
| Amortization of net actuarial loss | 3 |  |  | 3 |  |  | 9 |  |  | 9 |  |
| Net periodic benefit cost | $ | 1 |  |  | $ | — |  |  | $ | 2 |  |  | $ | 1 |  |

[0000833444-14-000099:notes:168]
[same as prior period, unchanged from 0000833444-14-000046:notes:165]

[0000833444-14-000099:notes:169]
The Company's funding policy is to make contributions in accordance with the laws and customs of the various countries in which it operates and to make discretionary voluntary contributions from time to time. The Company anticipates that it will contribute at least the minimum required to its pension plans in fiscal year 2014 of $25 million for U.S. plans and $28 million for non-U.S. plans. During the quarter ended June 27, 2014, the Company made required contributions of $10 million to its U.S. pension plans and $5 million to its non-U.S. pension plans. During the nine months ended June 27, 2014, the Company made required contributions of $17 million to its U.S. pension plans and $20 million to its non-U.S. pension plans.

[0000833444-14-000099:notes:170]
[same as prior period, unchanged from 0000833444-14-000046:notes:167]


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000833444-14-000099:notes:171]
[same as prior period, unchanged from 0000833444-14-000046:notes:168]

[0000833444-14-000099:notes:172]
[same as prior period, unchanged from 0000833444-14-000046:notes:169]

[0000833444-14-000099:notes:173]
|  | As of |
|  | June 27,2014 |  | September 27,2013 |
| Land | $ | 37 |  |  | $ | 35 |  |
| Buildings | 412 |  |  | 376 |  |
| Subscriber systems | 2,313 |  |  | 2,414 |  |
| Machinery and equipment | 1,269 |  |  | 1,203 |  |
| Construction in progress | 90 |  |  | 67 |  |
| Accumulated depreciation | (2,838 | ) |  | (2,811 | ) |
| Property, plant and equipment, net | $ | 1,283 |  |  | $ | 1,284 |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000833444-14-000099:notes:174]
[same as prior period, unchanged from 0000833444-14-000046:notes:171]

[0000833444-14-000099:notes:175]
During the third quarter of fiscal 2014, the Company identified and pursued opportunities for cost savings through restructuring activities and workforce reductions to improve operating efficiencies across the Company's businesses. The Company expects to incur restructuring and restructuring related charges in the range of $50 million to $75 million in fiscal 2014, which does not include repositioning charges as described below.

[0000833444-14-000099:notes:176]
[same as prior period, unchanged from 0000833444-14-000046:notes:173]

[0000833444-14-000099:notes:177]
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 27, 2014 |  | June 28, 2013 |  | June 27, 2014 |  | June 28, 2013 |
| 2014 actions | $ | 19 |  |  | $ | — |  |  | $ | 28 |  |  | $ | — |  |
| 2013 actions | (2 | ) |  | 51 |  |  | — |  |  | 72 |  |
| 2012 and prior actions | — |  |  | 2 |  |  | (1 | ) |  | 10 |  |
| Total | $ | 17 |  |  | $ | 53 |  |  | $ | 27 |  |  | $ | 82 |  |

[0000833444-14-000099:notes:178]
[same as prior period, unchanged from 0000833444-14-000046:notes:175]

[0000833444-14-000099:notes:179]
Restructuring and asset impairment charges, net, during the quarter and nine months ended June 27, 2014 related to the 2014 actions are as follows ($ in millions):

[0000833444-14-000099:notes:180]
|  | For the Quarter Ended June 27, 2014 |
|  | EmployeeSeverance andBenefits |  | Facility Exit and Other Charges |  | Total |
| NA Installation & Services | $ | 7 |  |  | $ | — |  |  | $ | 7 |  |
| ROW Installation & Services | 7 |  |  | 3 |  |  | 10 |  |
| Global Products | 2 |  |  | — |  |  | 2 |  |
| Total | $ | 16 |  |  | $ | 3 |  |  | $ | 19 |  |

[0000833444-14-000099:notes:181]
|  | For the Nine Months EndedJune 27, 2014 |
|  | EmployeeSeverance andBenefits |  | Facility Exit and Other Charges |  | Total |
| NA Installation & Services | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |
| ROW Installation & Services | 12 |  |  | 3 |  |  | 15 |  |
| Global Products | 3 |  |  | — |  |  | 3 |  |
| Total | $ | 25 |  |  | $ | 3 |  |  | $ | 28 |  |

[0000833444-14-000099:notes:182]
The rollforward of the reserves from September 27, 2013 to June 27, 2014 is as follows ($ in millions):

[0000833444-14-000099:notes:183]
| Balance as of September 27, 2013 | $ | — |  |
| Charges | 28 |  |
| Utilization | (6 | ) |
| Balance as of June 27, 2014 | $ | 22 |  |

[0000833444-14-000099:notes:184]
[same as prior period, unchanged from 0000833444-14-000046:notes:181]

[0000833444-14-000099:notes:185]
Restructuring and asset impairment charges, net, during the quarters and nine months ended June 27, 2014 and June 28, 2013 related to the 2013 actions are as follows ($ in millions):

[0000833444-14-000099:notes:186]
|  | For the Quarter Ended June 27, 2014 |
|  | Employee Severance and Benefits |
| NA Installation & Services | $ | (1 | ) |
| ROW Installation & Services | (2 | ) |
| Global Products | $ | 1 |  |
| Total | $ | (2 | ) |

[0000833444-14-000099:notes:187]
|  | For the Quarter Ended June 28, 2013 |
|  | EmployeeSeverance andBenefits |  | Facility Exitand OtherCharges |  | Total |
| NA Installation & Services | $ | 17 |  |  | $ | (1 | ) |  | $ | 16 |  |
| ROW Installation & Services | 30 |  |  | 1 |  |  | 31 |  |
| Global Products | 2 |  |  | 2 |  |  | 4 |  |
| Total | $ | 49 |  |  | $ | 2 |  |  | $ | 51 |  |

[0000833444-14-000099:notes:188]
|  | For the Nine Months Ended June 27, 2014 |
|  | EmployeeSeverance andBenefits |  | Facility Exitand OtherCharges |  | Total |
| NA Installation & Services | $ | (2 | ) |  | $ | 1 |  |  | $ | (1 | ) |
| ROW Installation & Services | (5 | ) |  | — |  |  | (5 | ) |
| Global Products | 5 |  |  | 1 |  |  | 6 |  |
| Total | $ | (2 | ) |  | $ | 2 |  |  | $ | — |  |

[0000833444-14-000099:notes:189]
|  | For the Nine Months Ended June 28, 2013 |
|  | EmployeeSeverance andBenefits |  | Facility Exitand OtherCharges |  | Total |
| NA Installation & Services | $ | 21 |  |  | $ | 1 |  |  | $ | 22 |  |
| ROW Installation & Services | 39 |  |  | 2 |  |  | 41 |  |
| Global Products | 6 |  |  | 2 |  |  | 8 |  |
| Corporate and Other | 1 |  |  | — |  |  | 1 |  |
| Total | $ | 67 |  |  | $ | 5 |  |  | $ | 72 |  |

[0000833444-14-000099:notes:190]
[same as prior period, unchanged from 0000833444-14-000046:notes:187]

[0000833444-14-000099:notes:191]
|  | EmployeeSeverance andBenefits |  | Facility Exitand OtherCharges |  | Total |
| NA Installation & Services | $ | 32 |  |  | $ | 2 |  |  | $ | 34 |  |
| ROW Installation & Services | 41 |  |  | 4 |  |  | 45 |  |
| Global Products | 14 |  |  | 3 |  |  | 17 |  |
| Corporate and Other | 3 |  |  | — |  |  | 3 |  |
| Total | $ | 90 |  |  | $ | 9 |  |  | $ | 99 |  |

[0000833444-14-000099:notes:192]
| Balance as of September 27, 2013 | $ | 68 |  |
| Charges | 11 |  |
| Reversals | (11 | ) |
| Utilization | (34 | ) |
| Balance as of June 27, 2014 | $ | 34 |  |

[0000833444-14-000099:notes:193]
[same as prior period, unchanged from 0000833444-14-000046:notes:190]

[0000833444-14-000099:notes:194]
[same as prior period, unchanged from 0000833444-14-000046:notes:191]

[0000833444-14-000099:notes:195]
The Company continues to maintain restructuring reserves related to actions initiated prior to fiscal 2012. The total amount of these reserves was $44 million and $62 million as of June 27, 2014 and September 27, 2013, respectively. The Company incurred $1 million and $2 million of restructuring charges, $1 million and nil of reversals and utilized $3 million and $9 million for the quarters ended June 27, 2014 and June 28, 2013, respectively.  The Company incurred $6 million and $13 million of restructuring charges, $7 million and $3 million of restructuring reversals and utilized $17 million and $45 million for the nine months ended June 27, 2014 and June 28, 2013, respectively, related to 2012 and prior actions. The aggregate remaining reserves primarily relate to facility exit costs for long-term non-cancelable lease obligations primarily within the Company's ROW Installation & Services segment.

[0000833444-14-000099:notes:196]
[same as prior period, unchanged from 0000833444-14-000046:notes:193]

[0000833444-14-000099:notes:197]
As of June 27, 2014 and September 27, 2013, restructuring reserves related to all actions were included in the Company's Consolidated Balance Sheets as follows ($ in millions):

[0000833444-14-000099:notes:198]
|  | As of |
|  | June 27, 2014 |  | September 27, 2013 |
| Accrued and other current liabilities | $ | 84 |  |  | $ | 112 |  |
| Other liabilities | 16 |  |  | 18 |  |
| Total | $ | 100 |  |  | $ | 130 |  |

[0000833444-14-000099:notes:199]
[same as prior period, unchanged from 0000833444-14-000046:notes:196]

[0000833444-14-000099:notes:200]
The Company has initiated certain global actions designed to reduce its cost structure and improve future profitability by streamlining operations and better aligning functions, which the Company refers to as repositioning actions. These actions may or may not lead to a future restructuring action. During the quarter and nine months ended June 27, 2014, the Company recorded repositioning charges of $13 million and $28 million, respectively, primarily related to professional fees which have been reflected in Selling, general and administrative expenses in the Consolidated Statements of Operations.  During the  quarter and nine months ended June 28, 2013, the Company recorded repositioning charges of $5 million and $9 million, respectively.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000833444-14-000099:notes:201]
A summary of the changes in each component of accumulated other comprehensive loss, net of tax, for the nine months ended June 27, 2014 are as follows ($ in millions):

[0000833444-14-000099:notes:202]
|  | CurrencyTranslationAdjustments |  | RetirementPlans |  | Accumulated OtherComprehensive Loss |
| Balance as of September 27, 2013 | $ | (521 | ) |  | $ | (466 | ) |  | $ | (987 | ) |
| Other comprehensive loss before reclassifications, net of tax | 16 |  |  | — |  |  | 16 |  |
| Amounts reclassified from accumulated other comprehensive income (loss), net of tax | (40 | ) |  | 16 |  |  | (24 | ) |
| Other comprehensive (loss) income, net of tax | (24 | ) |  | 16 |  |  | (8 | ) |
| Balance as of June 27, 2014 | $ | (545 | ) |  | $ | (450 | ) |  | $ | (995 | ) |


## us-gaap:ScheduleOfComprehensiveIncomeLossTableTextBlock

[0000833444-14-000099:notes:203]
Other Comprehensive Income (Loss)

[0000833444-14-000099:notes:204]
Other comprehensive income (loss) is comprised of the following ($ in millions):

[0000833444-14-000099:notes:205]
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 27, 2014 |  | June 28, 2013 |  | June 27, 2014 |  | June 28, 2013 |
| Foreign currency translation | $ | 68 |  |  | $ | (135 | ) |  | $ | 16 |  |  | $ | (209 | ) |
| Liquidation of foreign entities (1) | (40 | ) |  | 1 |  |  | (40 | ) |  | (9 | ) |
| Income tax expense (2) | — |  |  | — |  |  | — |  |  | (7 | ) |
| Foreign currency translation, net of tax | 28 |  |  | (134 | ) |  | (24 | ) |  | (225 | ) |
| Amortization of net actuarial losses (3) | 11 |  |  | 7 |  |  | 21 |  |  | 20 |  |
| Income tax expense | (2 | ) |  | (2 | ) |  | (5 | ) |  | (6 | ) |
| Defined benefit and post retirement plans, net of tax | 9 |  |  | 5 |  |  | 16 |  |  | 14 |  |
| Unrealized loss on marketable securities and derivative instruments (4) | (1 | ) |  | (2 | ) |  | (1 | ) |  | (3 | ) |
| Income tax benefit | 1 |  |  | 1 |  |  | 1 |  |  | 3 |  |
| Unrealized loss on marketable securities and derivative instruments, net of tax | — |  |  | (1 | ) |  | — |  |  | — |  |
| Other comprehensive income (loss), net of tax | 37 |  |  | (130 | ) |  | (8 | ) |  | (211 | ) |
| Less: Other comprehensive income attributable to noncontrolling interests | 2 |  |  | — |  |  | 3 |  |  | — |  |
| Other comprehensive income (loss) attributable to Tyco common shareholders | $ | 35 |  |  | $ | (130 | ) |  | $ | (11 | ) |  | $ | (211 | ) |

[0000833444-14-000099:notes:206]
(1) During the nine months ended June 28, 2013, and the quarter ended June 27, 2014, $9 million and $40 million respectively of cumulative translation gains were transferred from foreign currency translation and included in Income from Discontinued Operations in the Consolidated Statements of Operations as a result of the sale of foreign entities.

[0000833444-14-000099:notes:207]
(2) Income tax expense on the net investment hedge was $7 million for the nine months ended June 28, 2013.

[0000833444-14-000099:notes:208]
(3) Reclassified to net periodic benefit cost.  See Note 12 Retirement Plans for additional information.  During the quarter ended June 27, 2014, $5 million of net actuarial losses were transferred from amortization of net actuarial losses and included in Income from discontinued operations in the Consolidated Statements of Operations as a result of the sale of foreign entities.

[0000833444-14-000099:notes:209]
[same as prior period, unchanged from 0000833444-14-000046:notes:206]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-14-000099:notes:210]
[same as prior period, unchanged from 0000833444-14-000046:notes:207]

[0000833444-14-000099:notes:211]
[same as prior period, unchanged from 0000833444-14-000046:notes:208]

[0000833444-14-000099:notes:212]
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 27, 2014 |  | June 28, 2013 |  | June 27, 2014 |  | June 28, 2013 |
| Net revenue(1): |  |  |  |  |  |  |  |
| NA Installation & Services | $ | 968 |  |  | $ | 966 |  |  | $ | 2,864 |  |  | $ | 2,895 |  |
| ROW Installation & Services | 1,001 |  |  | 971 |  |  | 2,909 |  |  | 2,856 |  |
| Global Products | 693 |  |  | 600 |  |  | 1,863 |  |  | 1,712 |  |
|  | $ | 2,662 |  |  | $ | 2,537 |  |  | $ | 7,636 |  |  | $ | 7,463 |  |

[0000833444-14-000099:notes:213]
[same as prior period, unchanged from 0000833444-14-000046:notes:210]

[0000833444-14-000099:notes:214]
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 27, 2014 |  | June 28, 2013 |  | June 27, 2014 |  | June 28, 2013 |
| Operating income (loss): |  |  |  |  |  |  |  |
| NA Installation & Services | $ | 117 |  |  | $ | 88 |  |  | $ | 333 |  |  | $ | 275 |  |
| ROW Installation & Services (1) | 101 |  |  | 77 |  |  | 308 |  |  | 250 |  |
| Global Products | 136 |  |  | 114 |  |  | 329 |  |  | 188 |  |
| Corporate and Other (2) | (58 | ) |  | (117 | ) |  | (73 | ) |  | (239 | ) |
|  | $ | 296 |  |  | $ | 162 |  |  | $ | 897 |  |  | $ | 474 |  |

[0000833444-14-000099:notes:215]
| (1) | Operating income for the nine months ended June 27, 2014 includes $21 million of an insurance recovery related to the improper recording of revenue in China that was previously disclosed in the fourth quarter of fiscal 2012. See Note 11. |

[0000833444-14-000099:notes:216]
| (2) | Operating income for the nine months ended June 27, 2014 includes $96 million of income related to the settlement of a legacy legal matter with former management and $16 million of income related to the CIT settlement. See Note 11. |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-14-000099:notes:217]
[same as prior period, unchanged from 0000833444-14-000046:notes:214]

[0000833444-14-000099:notes:218]
[same as prior period, unchanged from 0000833444-14-000046:notes:215]

[0000833444-14-000099:notes:219]
[same as prior period, unchanged from 0000833444-14-000046:notes:216]

[0000833444-14-000099:notes:220]
On March 5, 2014, the Company's shareholders approved an annual cash dividend of $0.72 per common share.  Payment of the dividend is to be made in four quarterly installments of $0.18 from May 2014 through February 2015.  As a result, during the quarter ended March 28, 2014, the Company recorded an accrued dividend of $332 million within Accrued and other current liabilities and a corresponding reduction to Contributed surplus on the Company's Consolidated Balance Sheet. The first installment was paid on May 21, 2014 to shareholders of record on April 25, 2014.  The second installment will be paid on August 20, 2014 to shareholders of record on July 25, 2014.  The third and fourth installments will be paid in November 2014 and February 2015, respectively.

[0000833444-14-000099:notes:221]
[same as prior period, unchanged from 0000833444-14-000046:notes:218]

[0000833444-14-000099:notes:222]
The Company's Board of Directors approved a $600 million share repurchase program in January 2013.  In March 2014, the Company's Board of Directors authorized an additional $1.75 billion in share repurchases.  During the quarter ended June 27, 2014, the Company repurchased a total of approximately 13 million shares for approximately $556 million. During the nine months ended June 27, 2014, the Company repurchased a total of approximately 20 million shares for approximately $806 million. As of June 27, 2014, a total of approximately $1.4 billion in share repurchase authority remained outstanding.  Share repurchases reduce the amount of common shares outstanding and decrease the accrued dividend liability on the Consolidated Statement of Stockholders' Equity, as shares repurchased by the Company or its subsidiaries are not entitled to dividends.


## us-gaap:SubsequentEventsTextBlock

[0000833444-14-000099:notes:223]
Subsequent Events

[0000833444-14-000099:notes:224]
Subsequent to June 27, 2014 and through July 22, 2014, the Company repurchased approximately 7 million common shares for approximately $319 million under the share repurchase program.


## tyc:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesAndNewAccountingPronouncementsTextBlock

[0000833444-14-000099:notes:225]
Basis of Presentation and Summary of Significant Accounting Policies

[0000833444-14-000099:notes:226]
Change of Jurisdiction - On May 30, 2014, Tyco entered into a Merger Agreement ("Merger Agreement") with Tyco International plc, a newly-formed Irish public limited company and a wholly-owned subsidiary of Tyco ("Tyco Ireland").  Under the Merger Agreement, Tyco will merge with and into Tyco Ireland, with Tyco Ireland being the surviving company.  This Merger will result in Tyco Ireland becoming Tyco's publicly-traded parent company and change the jurisdiction of organization of Tyco from Switzerland to Ireland.  Tyco's shareholders are expected to receive one ordinary share of Tyco Ireland for each common share of Tyco held immediately prior to the Merger.  Upon completion of the Merger, Tyco Ireland is expected to conduct, through its subsidiaries, the same businesses as conducted by Tyco before the Merger.  The Merger is subject to certain conditions including shareholder approval at the special general meeting of shareholders expected to be held in September 2014.

[0000833444-14-000099:notes:227]
Reclassifications - Certain prior period amounts have been reclassified to conform with current period presentation.  Specifically, the Company has reclassified its ADT Korea business to income from discontinued operations in the Consolidated Statements of Operations and to assets and liabilities held for sale within the Consolidated Balance Sheets as it satisfied the criteria to be presented as a discontinued operation.  The Company completed the sale of the ADT Korea business on May 22, 2014.  See Note 3.

[0000833444-14-000099:notes:228]
In addition, the Company has reclassified several businesses in the Rest of World ("ROW") Installation & Services segment to income from discontinued operations and to assets and liabilities held for sale as they satisfied the criteria to be presented as discontinued operations.  The Company expects to complete the sale of these businesses during the next twelve months. See Note 3.

[0000833444-14-000099:notes:229]
Recently Adopted Accounting Pronouncements - In January 2013, the Financial Accounting Standards Board (FASB) issued authoritative guidance clarifying the scope of disclosures about offsetting assets and liabilities. The guidance clarifies that the scope of the disclosures applies to derivatives accounted for in accordance with authoritative guidance for derivatives and hedging, including bifurcated embedded derivatives, repurchase agreements and reverse repurchase agreements, and securities borrowing and securities lending transactions that either offset or are subject to an enforceable master netting agreement or similar agreement. The guidance is applied retrospectively and became effective for Tyco in the first quarter of fiscal 2014.  The adoption of this guidance did not have a material impact on the Company's disclosures.

[0000833444-14-000099:notes:230]
In February 2013, the FASB issued authoritative guidance for the reporting of amounts reclassified out of Accumulated other comprehensive income ("AOCI"). The amendment did not change the current requirements for reporting net income or Other comprehensive income ("OCI") in the financial statements. The guidance requires the presentation, either on the face of the statement where net income is presented or in the notes, of the significant reclassifications out of AOCI by the respective line items of net income if the amount reclassified is required under U.S. generally accepted accounting principles ("U.S. GAAP") to be reclassified to net income in its entirety in the same reporting period. For other amounts that are not required under U.S. GAAP to be reclassified in their entirety to net income, the amendment requires a cross-reference to other disclosures under U.S. GAAP that provide additional detail about those amounts. The guidance became effective for Tyco in the first quarter of fiscal 2014 and additional disclosures are provided in Note 13.

[0000833444-14-000099:notes:231]
Recently Issued Accounting Pronouncements - In March 2013, the FASB issued authoritative guidance to resolve diversity in practice on the accounting for the cumulative translation adjustment ("CTA") when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets within a foreign entity. The guidance requires that the parent release any CTA into net income when the parent ceases to have a controlling financial interest in a subsidiary or group of assets within a foreign entity which results in a substantially complete liquidation of the foreign entity; when the sale of an investment in a foreign entity results in the loss of a controlling financial interest; or where an acquirer obtains control of an acquiree in which it had an equity interest immediately before the acquisition date. The guidance does not change the requirement to release a pro rata portion of the CTA into net income upon a partial sale of an equity method investment that is a foreign entity. The guidance will be effective for Tyco in the first quarter of fiscal 2015, with early adoption permitted. The Company is currently assessing the timing of its adoption along with what impact, if any, the guidance will have upon adoption.

[0000833444-14-000099:notes:232]
In July 2013, the FASB issued authoritative guidance for the presentation of an unrecognized tax benefit when a net operating loss (“NOL”) carryforward, a similar tax loss, or a tax credit carryforward exists. The guidance requires an entity to present an unrecognized tax benefit, or a portion of an unrecognized tax benefit, in the financial statements as a reduction to a deferred tax asset for a NOL carryforward, a similar tax loss, or a tax credit carryforward. If the NOL carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the jurisdiction or the tax law of the jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit will be presented in the financial statements as a liability and will not be combined with deferred tax assets.  This guidance does not require any additional recurring disclosures and will be effective for Tyco the first fiscal quarter of fiscal 2015. The Company is currently assessing the impact, if any, the guidance will have upon adoption.

[0000833444-14-000099:notes:233]
In April 2014, the FASB issued authoritative guidance to change the criteria for reporting discontinued operations.  Under the new guidance, only disposals representing a strategic shift in a company's operations and financial results should be reported as discontinued operations, with expanded disclosures. In addition, disclosure of the pre-tax income attributable to a disposal of a significant part of an organization that does not qualify as a discontinued operation is required.  This guidance is effective for Tyco in the first quarter of fiscal 2016, with early adoption permitted.  The Company is currently assessing the impact, if any, the guidance will have upon adoption.

[0000833444-14-000099:notes:234]
In May 2014, the FASB issued authoritative guidance for revenue from contracts with customers, which provides a single comprehensive revenue recognition model to apply in determining how and when to recognize revenue. The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. When applying the new revenue model to contracts with customers the guidance requires five steps to be applied, which include: 1) identify the contract(s) with a customer, 2) identify the performance obligations in the contract, 3) determine the transaction price, 4) allocate the transaction price to the performance obligations in the contract and 5) recognize revenue when (or as) the entity satisfies a performance obligation. The guidance also requires both quantitative and qualitative disclosures, which are more comprehensive than existing revenue standards. The disclosures are intended to enable financial statement users to understand the nature, timing and uncertainty of revenue and the related cash flow. This guidance will be effective for Tyco in the first fiscal quarter of 2018, with early adoption not permitted. The Company is currently assessing the impact the guidance will have upon adoption.


## tyc:ScheduleOfComponentsOfSeparationRelatedCostsClassificationTableTextBlock

[0000833444-14-000099:notes:235]
[same as prior period, unchanged from 0000833444-14-000046:notes:227]

[0000833444-14-000099:notes:236]
|  | For the Quarter Ended June 27, 2014 |  | For the Quarter Ended June 28, 2013 |
|  | ContinuingOperations |  | DiscontinuedOperations |  | Total |  | ContinuingOperations |  | DiscontinuedOperations |  | Total |
| Professional fees | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3 |  |  | $ | (1 | ) |  | $ | 2 |  |
| Information technology related costs | 3 |  |  | — |  |  | 3 |  |  | 3 |  |  | (2 | ) |  | 1 |  |
| Employee compensation costs | — |  |  | 1 |  |  | 1 |  |  | 3 |  |  | — |  |  | 3 |  |
| Marketing costs | 7 |  |  | — |  |  | 7 |  |  | 8 |  |  | — |  |  | 8 |  |
| Other | 1 |  |  | — |  |  | 1 |  |  | 5 |  |  | — |  |  | 5 |  |
| Total pre-tax separation charges (income) | 11 |  |  | 1 |  |  | 12 |  |  | 22 |  |  | (3 | ) |  | 19 |  |
| Tax-related separation charges | 9 |  |  | — |  |  | 9 |  |  | 2 |  |  | — |  |  | 2 |  |
| Tax benefit on pre-tax separation charges | — |  |  | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Total separation charges (income), net of tax | $ | 20 |  |  | $ | 1 |  |  | $ | 21 |  |  | $ | 21 |  |  | $ | (3 | ) |  | $ | 18 |  |

[0000833444-14-000099:notes:237]
|  | For the Nine Months Ended June 27, 2014 |  | For the Nine Months Ended June 28, 2013 |
|  | ContinuingOperations |  | DiscontinuedOperations |  | Total |  | ContinuingOperations |  | DiscontinuedOperations |  | Total |
| Professional fees | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |  | $ | 3 |  |  | $ | 3 |  |  | $ | 6 |  |
| Information technology related costs | 9 |  |  | — |  |  | 9 |  |  | 7 |  |  | — |  |  | 7 |  |
| Employee compensation costs | — |  |  | 2 |  |  | 2 |  |  | 3 |  |  | 2 |  |  | 5 |  |
| Marketing costs | 27 |  |  | — |  |  | 27 |  |  | 35 |  |  | — |  |  | 35 |  |
| Other | 4 |  |  | — |  |  | 4 |  |  | 8 |  |  | (10 | ) |  | (2 | ) |
| Total pre-tax separation charges (income) | 42 |  |  | 2 |  |  | 44 |  |  | 56 |  |  | (5 | ) |  | 51 |  |
| Tax-related separation charges | 9 |  |  | — |  |  | 9 |  |  | 6 |  |  | — |  |  | 6 |  |
| Tax benefit on pre-tax separation charges | (11 | ) |  | — |  |  | (11 | ) |  | (5 | ) |  | — |  |  | (5 | ) |
| Total separation charges (income), net of tax | $ | 40 |  |  | $ | 2 |  |  | $ | 42 |  |  | $ | 57 |  |  | $ | (5 | ) |  | $ | 52 |  |


## tyc:ScheduleOfSeparationCostsClassificationTableTextBlock

[0000833444-14-000099:notes:238]
[same as prior period, unchanged from 0000833444-14-000046:notes:230]

[0000833444-14-000099:notes:239]
|  | For the Quarters Ended |  | For the Nine Months Ended |
|  | June 27, 2014 |  | June 28, 2013 |  | June 27, 2014 |  |  | June 28, 2013 |  |
| Selling, general and administrative expenses | $ | 11 |  |  | $ | 18 |  |  | $ | 41 |  |  | $ | 47 |  |
| Separation costs | — |  |  | 4 |  |  | 1 |  |  | 9 |  |
| Total | $ | 11 |  |  | $ | 22 |  |  | $ | 42 |  |  | $ | 56 |  |


## tyc:SeparationTransactionDisclosureTextBlock

[0000833444-14-000099:notes:240]
[same as prior period, unchanged from 0000833444-14-000046:notes:232]

[0000833444-14-000099:notes:241]
[same as prior period, unchanged from 0000833444-14-000046:notes:233]

[0000833444-14-000099:notes:242]
In connection with activities taken to complete the 2012 Separation and to create the revised organizational structure of the Company, the Company incurred pre-tax charges ("Separation Charges") of $12 million and $19 million during the quarters ended June 27, 2014 and June 28, 2013, respectively, and $44 million and $51 million for the nine months ended June 27, 2014 and June 28, 2013, respectively. The amounts presented within discontinued operations are costs directly related to the 2012 Separation that are not expected to provide a future benefit to the Company. The components of the Separation Charges incurred within continuing operations and discontinued operations consisted of the following ($ in millions):
