# JCI MD&A — 0000833444-14-000099


## mdna

[0000833444-14-000099:mdna:1]
[same as prior period, unchanged from 0000833444-14-000046:mdna:1]

[0000833444-14-000099:mdna:2]
[same as prior period, unchanged from 0000833444-14-000046:mdna:2]

[0000833444-14-000099:mdna:3]
[same as prior period, unchanged from 0000833444-14-000046:mdna:3]

[0000833444-14-000099:mdna:4]
[same as prior period, unchanged from 0000833444-14-000046:mdna:4]

[0000833444-14-000099:mdna:5]
On May 30, 2014, we entered into a Merger Agreement ("Merger Agreement") with Tyco International plc, a newly-formed Irish public limited company and wholly-owned subsidiary of Tyco ("Tyco Ireland").  Under the Merger Agreement, Tyco will merge with and into Tyco Ireland, with Tyco Ireland being the surviving company.  This Merger will result in Tyco Ireland becoming Tyco's publicly-traded parent company and change the jurisdiction of organization of Tyco from Switzerland to Ireland.  See Note 1 to our unaudited Consolidated Financial Statements for additional information.

[0000833444-14-000099:mdna:6]
[same as prior period, unchanged from 0000833444-14-000046:mdna:5]

[0000833444-14-000099:mdna:7]
[same as prior period, unchanged from 0000833444-14-000046:mdna:6]

[0000833444-14-000099:mdna:8]
[same as prior period, unchanged from 0000833444-14-000046:mdna:7]

[0000833444-14-000099:mdna:9]
[same as prior period, unchanged from 0000833444-14-000046:mdna:8]

[0000833444-14-000099:mdna:10]
[same as prior period, unchanged from 0000833444-14-000046:mdna:9]

[0000833444-14-000099:mdna:11]
Certain prior period amounts have been reclassified to conform with current period presentation.  Specifically, the Company has reclassified its ADT Korea business and several other ROW Installation & Services businesses to income from discontinued operations in the Consolidated Statements of Operations and to assets and liabilities held for sale within the Consolidated Balance Sheets as they each satisfied the criteria to be presented as discontinued operations.  We completed the sale of ADT Korea on May 22, 2014, and we expect to complete the sale of the other identified ROW Installation & Services businesses in the next twelve months. See Note 3 to our unaudited Consolidated Financial Statements for additional information.

[0000833444-14-000099:mdna:12]
[same as prior period, unchanged from 0000833444-14-000046:mdna:11]

[0000833444-14-000099:mdna:13]
We are a leading global provider of security products and services, fire detection and suppression products and services and life safety products. We utilize our extensive global footprint of over 1,100 locations, including manufacturing facilities, service and distribution centers, monitoring centers and sales offices, to provide solutions and localized expertise to our global customer base. We provide an extensive range of product and service offerings to over 3 million customers in more than 100 countries through multiple channels. Our revenues are broadly diversified across the United States and Canada (collectively “North America”); Central America and South America (collectively “Latin America”); Europe, the Middle East, and Africa (collectively “EMEA”) and the Asia-Pacific geographic areas. The following chart reflects our net revenue by geographic area for the nine months ended June 27, 2014.

[0000833444-14-000099:mdna:14]
Nine Months Ended June 27, 2014

[0000833444-14-000099:mdna:15]
[same as prior period, unchanged from 0000833444-14-000046:mdna:14]

[0000833444-14-000099:mdna:16]
[same as prior period, unchanged from 0000833444-14-000046:mdna:15]

[0000833444-14-000099:mdna:17]
[same as prior period, unchanged from 0000833444-14-000046:mdna:16]

[0000833444-14-000099:mdna:18]
[same as prior period, unchanged from 0000833444-14-000046:mdna:17]

[0000833444-14-000099:mdna:19]
[same as prior period, unchanged from 0000833444-14-000046:mdna:18]

[0000833444-14-000099:mdna:20]
[same as prior period, unchanged from 0000833444-14-000046:mdna:19]

[0000833444-14-000099:mdna:21]
[same as prior period, unchanged from 0000833444-14-000046:mdna:20]

[0000833444-14-000099:mdna:22]
[same as prior period, unchanged from 0000833444-14-000046:mdna:21]

[0000833444-14-000099:mdna:23]
As a global business with a varied customer base and an extensive range of products and services, our operations and results are impacted by global, regional and industry specific factors, and by political factors. Our geographic diversity and the diversity in our customer base and our products and services has helped mitigate the impact of any one industry or the economy of any single country on our consolidated operating results, financial condition and cash flows. Due to the global nature of our business and the variety of our customers, products and services, no single factor is predominantly used to forecast Company results. Rather, management monitors a number of factors to develop expectations regarding future results, including the

[0000833444-14-000099:mdna:24]
46

[0000833444-14-000099:mdna:25]
activity of key competitors and customers, order rates for longer lead time projects, and capital expenditure budgets and spending patterns of our customers. We also monitor trends throughout the commercial and residential fire and security markets, including building codes and fire-safety standards. Our commercial installation businesses are impacted by trends in commercial construction starts, while our residential business, which is located outside of the United States, is impacted by new housing starts.

[0000833444-14-000099:mdna:26]
[same as prior period, unchanged from 0000833444-14-000046:mdna:25]

[0000833444-14-000099:mdna:27]
[same as prior period, unchanged from 0000833444-14-000046:mdna:26]

[0000833444-14-000099:mdna:28]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 27, 2014 |  | June 28, 2013 |  | June 27, 2014 |  | June 28, 2013 |
| Net revenue | $ | 2,662 |  |  | $ | 2,537 |  |  | $ | 7,636 |  |  | $ | 7,463 |  |
| Net revenue growth | 4.9 | % |  | N/A |  |  | 2.3 | % |  | N/A |  |
| Organic revenue growth | 4.2 | % |  | N/A |  |  | 2.3 | % |  | N/A |  |
| Operating income | $ | 296 |  |  | $ | 162 |  |  | $ | 897 |  |  | $ | 474 |  |
| Operating margin | 11.1 | % |  | 6.4 | % |  | 11.7 | % |  | 6.4 | % |
| Interest income | $ | 4 |  |  | $ | 6 |  |  | $ | 10 |  |  | $ | 13 |  |
| Interest expense | (24 | ) |  | (26 | ) |  | (73 | ) |  | (75 | ) |
| Other expense, net | — |  |  | (1 | ) |  | (2 | ) |  | (30 | ) |
| Income tax expense | (55 | ) |  | (23 | ) |  | (164 | ) |  | (56 | ) |
| Equity gain (loss) in earnings of unconsolidated subsidiaries | 215 |  |  | (6 | ) |  | 206 |  |  | (18 | ) |
| Income from continuing operations attributable to Tyco common shareholders | 434 |  |  | 112 |  |  | 870 |  |  | 308 |  |

[0000833444-14-000099:mdna:29]
[same as prior period, unchanged from 0000833444-14-000046:mdna:28]

[0000833444-14-000099:mdna:30]
Net revenue for the quarter ended June 27, 2014 increased by $125 million, or 4.9%, to $2,662 million as compared to net revenue of $2,537 million for the quarter ended June 28, 2013. On an organic basis, net revenue grew by $106 million, or 4.2%, year over year, primarily as a result of revenue growth in our Global Products segment and to a lesser extent in our ROW and NA Installation & Services segments. Net revenue was favorably impacted by acquisitions of $51 million, or 2.0%, primarily within our ROW Installation & Services and Global Products segments. Net revenue growth was unfavorably impacted by divestitures of $26 million, or 1.0% in our ROW and NA Installation & Services segments. Changes in foreign currency exchange rates had a negligible unfavorable impact on net revenue.

[0000833444-14-000099:mdna:31]
Net revenue for the nine months ended June 27, 2014 increased by $173 million, or 2.3%, to $7,636 million as compared to net revenue of $7,463 million for the nine months ended June 28, 2013. On an organic basis, net revenue grew by $173 million, or 2.3%, year over year, primarily as a result of revenue growth in our Global Products, and to a lesser extent, our ROW and NA Installation & Services segments. Net revenue was favorably impacted by acquisitions of $169 million, or 2.3%, primarily within our ROW Installation & Services and Global Products segments. Changes in foreign currency exchange rates, primarily in our ROW Installation & Services segment, unfavorably impacted net revenue by $82 million, or 1.1%.  Net revenue growth was also unfavorably impacted by divestitures of $87 million, or 1.2% in our NA and ROW Installation & Services segments.

[0000833444-14-000099:mdna:32]
[same as prior period, unchanged from 0000833444-14-000046:mdna:31]

[0000833444-14-000099:mdna:33]
Operating income for the quarter ended June 27, 2014 increased by $134 million, or 82.7%, to $296 million, as compared to operating income of $162 million for the quarter ended June 28, 2013.  Improved operating performance across all segments and the impact of ongoing productivity initiatives and restructuring actions contributed to the higher margin in the current period.  In addition, restructuring costs were $28 million lower in the quarter ended June 27, 2014, and we recognized a gain of $6 million during the quarter ended June 27, 2014 related to asbestos matters as compared to a charge of $12 million in the comparable period.  Operating income also included a $4 million gain from recoveries in connection with the settlement of  legacy litigation with former management, as compared to a $27 million charge for the write-off of an insurance receivable that had been established in respect of a legacy legal claim in the comparable period.

[0000833444-14-000099:mdna:34]
Operating income for the nine months ended June 27, 2014 increased by $423 million, or 89.2%, to $897 million, as compared to operating income of $474 million for the nine months ended June 28, 2013.  The factors noted above for the

[0000833444-14-000099:mdna:35]
quarter ended June 27, 2014 favorably impacted operating income. Operating income in the current period also included the reversal of a compensation reserve of $92 million established in respect of legacy litigation with former management. In addition, the nine months ended June 27, 2014 included a settlement with CIT, a former subsidiary, which resulted in a net gain of $16 million, and a $21 million insurance recovery related to China.  A charge of $100 million for environmental activities for our Global Products facility in Marinette, Wisconsin in the prior year also contributed to the improvement in operating income.  See Note 11 to the unaudited Consolidated Financial Statements for additional information related to the CIT settlement and legacy legal matters.

[0000833444-14-000099:mdna:36]
Key items impacting operating income for the quarters and nine months ended June 27, 2014 and June 28, 2013, respectively, are as follows:

[0000833444-14-000099:mdna:37]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 27, 2014 |  | June 28, 2013 |  | June 27, 2014 |  | June 28, 2013 |
| Legacy legal (gains) charges | $ | (4 | ) |  | $ | 27 |  |  | $ | (96 | ) |  | $ | 27 |  |
| CIT settlement gain | — |  |  | — |  |  | (16 | ) |  | — |  |
| Separation costs | 11 |  |  | 22 |  |  | 42 |  |  | 56 |  |
| Loss on sale of investment | — |  |  | — |  |  | 7 |  |  | — |  |
| Restructuring, repositioning and asset impairment charges, net | 30 |  |  | 58 |  |  | 55 |  |  | 91 |  |
| Losses (gains) on divestitures, net | — |  |  | 4 |  |  | (2 | ) |  | 10 |  |
| Environmental remediation costs—Marinette | — |  |  | — |  |  | — |  |  | 100 |  |
| China insurance recovery | — |  |  | — |  |  | (21 | ) |  | — |  |
| Asbestos related (gains) charges | (6 | ) |  | 12 |  |  | (5 | ) |  | 10 |  |

[0000833444-14-000099:mdna:38]
[same as prior period, unchanged from 0000833444-14-000046:mdna:36]

[0000833444-14-000099:mdna:39]
[same as prior period, unchanged from 0000833444-14-000046:mdna:37]

[0000833444-14-000099:mdna:40]
Interest income was $4 million and $6 million for the quarters ended June 27, 2014 and June 28, 2013, respectively. Interest income was $10 million and $13 million for the nine months ended June 27, 2014 and June 28, 2013, respectively.

[0000833444-14-000099:mdna:41]
Interest expense was $24 million and $26 million for the quarters ended June 27, 2014 and June 28, 2013, respectively. Interest expense was $73 million and $75 million for the nine months ended June 27, 2014 and June 28, 2013, respectively.

[0000833444-14-000099:mdna:42]
[same as prior period, unchanged from 0000833444-14-000046:mdna:40]

[0000833444-14-000099:mdna:43]
Significant components of Other expense, net for the quarters and nine months ended June 27, 2014 and June 28, 2013 are as follows:

[0000833444-14-000099:mdna:44]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 27, 2014 |  | June 28, 2013 |  | June 27, 2014 |  | June 28, 2013 |
| 2012 Tax Sharing Agreement Loss (see Note 6 to the unaudited Consolidated Financial Statements) | $ | — |  |  | $ | (1 | ) |  | $ | (5 | ) |  | $ | (31 | ) |
| 2007 Tax Sharing Agreement Loss (see Note 6 to the unaudited Consolidated Financial Statements) | — |  |  | — |  |  | 1 |  |  | — |  |
| Other | — |  |  | — |  |  | 2 |  |  | 1 |  |
| Total | $ | — |  |  | $ | (1 | ) |  | $ | (2 | ) |  | $ | (30 | ) |

[0000833444-14-000099:mdna:45]
[same as prior period, unchanged from 0000833444-14-000046:mdna:43]

[0000833444-14-000099:mdna:46]
Our effective income tax rate was 19.9% and 16.3% during the quarters ended June 27, 2014 and June 28, 2013, respectively. The current period rate represents the Company’s geographic mix of income and non-recurring tax charges.

[0000833444-14-000099:mdna:47]
Our effective income tax rate was 19.7% and 14.7% during the nine months ended June 27, 2014 and June 28, 2013, respectively. The increase in our effective tax rate was primarily due to a reversal of a compensation reserve established in respect of legacy litigation with former management that generated tax expense in a high tax jurisdiction, as well as non-recurring tax charges during the current period. The comparable period was impacted by an environmental remediation charge that generated a tax benefit in a high tax jurisdiction.

[0000833444-14-000099:mdna:48]
[same as prior period, unchanged from 0000833444-14-000046:mdna:46]

[0000833444-14-000099:mdna:49]
Equity Gain (Loss) in Earnings of Unconsolidated Subsidiaries

[0000833444-14-000099:mdna:50]
Equity gain (loss) in earnings of unconsolidated subsidiaries reflects our share of Atkore's net gain or loss, which is accounted for under the equity method of accounting. Equity gain (loss) in earnings of unconsolidated subsidiaries during the quarters ended June 27, 2014 and June 28, 2013 was a gain of $215 million and a loss of $6 million, respectively.  Equity gain (loss) in earnings of unconsolidated subsidiaries during the nine months ended June 27, 2014 and June 28, 2013 was a gain of $206 million and a loss of $18 million, respectively.

[0000833444-14-000099:mdna:51]
On March 6, 2014, we announced Atkore's intention to redeem all of our remaining common equity stake in Atkore, and on April 9, 2014, the redemption was completed for aggregate cash proceeds of $250 million.  We recognized a net gain of $216 million related to this transaction, which is comprised of a $227 million gain on the sale of the equity investment, partially offset by an $11 million loss, which is our share of loss on Atkore's debt extinguishment undertaken in connection with the redemption. See Note 3 to the unaudited Consolidated Financial Statements for additional information.

[0000833444-14-000099:mdna:52]
[same as prior period, unchanged from 0000833444-14-000046:mdna:50]

[0000833444-14-000099:mdna:53]
The following chart reflects our net revenue by operating segment, as well as the percent of net revenue by operating segment, for the quarters and nine months ended June 27, 2014 and June 28, 2013, respectively.

[0000833444-14-000099:mdna:54]
[same as prior period, unchanged from 0000833444-14-000046:mdna:52]

[0000833444-14-000099:mdna:55]
[same as prior period, unchanged from 0000833444-14-000046:mdna:53]

[0000833444-14-000099:mdna:56]
Financial information for NA Installation & Services for the quarters and nine months ended June 27, 2014 and June 28, 2013 is as follows:

[0000833444-14-000099:mdna:57]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 27, 2014 |  | June 28, 2013 |  | June 27, 2014 |  | June 28, 2013 |
| Net revenue | $ | 968 |  |  | $ | 966 |  |  | $ | 2,864 |  |  | $ | 2,895 |  |
| Net revenue growth (decline) | 0.2 | % |  | N/A |  |  | (1.1 | )% |  | N/A |  |
| Organic revenue growth | 1.0 | % |  | N/A |  |  | 0.7 | % |  | N/A |  |
| Operating income | $ | 117 |  |  | $ | 88 |  |  | $ | 333 |  |  | $ | 275 |  |
| Operating margin | 12.1 | % |  | 9.1 | % |  | 11.6 | % |  | 9.5 | % |

[0000833444-14-000099:mdna:58]
[same as prior period, unchanged from 0000833444-14-000046:mdna:56]

[0000833444-14-000099:mdna:59]
[same as prior period, unchanged from 0000833444-14-000046:mdna:57]

[0000833444-14-000099:mdna:60]
| Factors Contributing to Year-Over-Year Change |  | Third QuarterFiscal 2014Compared toThird QuarterFiscal 2013 |  | Year to Date Fiscal 2014Compared toYear to Date Fiscal 2013 |
| Organic revenue growth |  | $ | 10 |  |  | $ | 21 |  |
| Acquisitions |  | 5 |  |  | 14 |  |
| Divestitures |  | (6 | ) |  | (42 | ) |
| Impact of foreign currency |  | (7 | ) |  | (24 | ) |
| Total change |  | $ | 2 |  |  | $ | (31 | ) |

[0000833444-14-000099:mdna:61]
Net revenue increased $2 million, or 0.2%, to $968 million for the quarter ended June 27, 2014 as compared to $966 million for the quarter ended June 28, 2013. Organic revenue growth was driven by an increase in both service and installation revenue.  The impact of acquisitions was $5 million, or 0.5%, due to the acquisition of Westfire in the first quarter of fiscal 2014.  Net revenue was unfavorably impacted by $6 million, or 0.6%, due to the divestiture of our North America guarding business in the third quarter of fiscal 2013.  Changes in foreign currency exchange rates unfavorably impacted net revenue by $7 million, or 0.7%.

[0000833444-14-000099:mdna:62]
Net revenue decreased $31 million, or 1.1% to $2,864 million for the nine months ended June 27, 2014 as compared to $2,895 million for the nine months ended June 28, 2013. Net revenue was unfavorably impacted by $42 million, or 1.5%, due to the divestiture of our North America guarding business in the third quarter of fiscal 2013.  Changes in foreign currency exchange rates unfavorably impacted net revenue by $24 million, or 0.8%.  Organic revenue growth was driven by increased service revenue partially offset by a decline in installation revenue.  The impact of acquisitions was $14 million, or 0.5%, due to the acquisition of Westfire in the first quarter of fiscal 2014.

[0000833444-14-000099:mdna:63]
[same as prior period, unchanged from 0000833444-14-000046:mdna:61]

[0000833444-14-000099:mdna:64]
Operating income for the quarter ended June 27, 2014 increased $29 million, or 33.0%, to $117 million, as compared to operating income of $88 million for the quarter ended June 28, 2013. This increase is primarily due to improved execution, a $10 million decrease in restructuring costs in the current period, and savings from restructuring activities and productivity initiatives.

[0000833444-14-000099:mdna:65]
Operating income for the nine months ended June 27, 2014 increased $58 million, or 21.1%, to $333 million, as compared to operating income of $275 million for the nine months ended June 28, 2013. This increase is primarily due to a higher mix of service revenue, efficiencies gained through improved installation execution and project selectivity in the North America security business, a $15 million decrease in restructuring costs in the current period, and savings from restructuring activities and productivity initiatives.

[0000833444-14-000099:mdna:66]
Key items impacting operating income for the quarters and nine months ended June 27, 2014 and June 28, 2013, respectively, are as follows:

[0000833444-14-000099:mdna:67]
|  | For the Quarters Ended | For the Nine Months Ended |
| ($ in millions) | June 27, 2014 |  | June 28, 2013 | June 27, 2014 |  | June 28, 2013 |
| Separation costs | $ | 11 |  |  | $ | 12 |  | $ | 40 |  |  | $ | 40 |  |
| Restructuring, repositioning and asset impairment charges, net | 6 |  |  | 16 |  | 7 |  |  | 22 |  |
| Losses on divestitures, net |  |  |  | 1 |  | — |  |  | 4 |  |

[0000833444-14-000099:mdna:68]
[same as prior period, unchanged from 0000833444-14-000046:mdna:66]

[0000833444-14-000099:mdna:69]
Financial information for ROW Installation & Services for the quarters and nine months ended June 27, 2014 and June 28, 2013 is as follows:

[0000833444-14-000099:mdna:70]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 27, 2014 |  | June 28, 2013 |  | June 27, 2014 |  | June 28, 2013 |
| Net revenue | $ | 1,001 |  |  | $ | 971 |  |  | $ | 2,909 |  |  | $ | 2,856 |  |
| Net revenue growth | 3.1 | % |  | N/A |  |  | 1.9 | % |  | N/A |  |
| Organic revenue growth | 2.4 | % |  | N/A |  |  | 1.9 | % |  | N/A |  |
| Operating income | $ | 101 |  |  | $ | 77 |  |  | $ | 308 |  |  | $ | 250 |  |
| Operating margin | 10.1 | % |  | 7.9 | % |  | 10.6 | % |  | 8.8 | % |

[0000833444-14-000099:mdna:71]
[same as prior period, unchanged from 0000833444-14-000046:mdna:69]

[0000833444-14-000099:mdna:72]
[same as prior period, unchanged from 0000833444-14-000046:mdna:70]

[0000833444-14-000099:mdna:73]
| Factors Contributing to Year-Over-Year Change |  | Third QuarterFiscal 2014Compared toThird QuarterFiscal 2013 |  | Year to Date Fiscal 2014Compared toYear to Date Fiscal 2013 |
| Organic revenue growth |  | $ | 23 |  |  | $ | 53 |  |
| Acquisitions |  | 27 |  |  | 99 |  |
| Divestitures |  | (20 | ) |  | (47 | ) |
| Impact of foreign currency |  | — |  |  | (52 | ) |
| Total change |  | $ | 30 |  |  | $ | 53 |  |

[0000833444-14-000099:mdna:74]
Net revenue increased $30 million, or 3.1%, to $1,001 million for the quarter ended June 27, 2014 as compared to $971 million for the quarter ended June 28, 2013. Organic revenue growth was driven by an increase in both service and installation revenue, primarily in Asia, our other growth markets, and the United Kingdom, partially offset by continued weakness primarily in our Pacific region and Continental Europe.  The impact of acquisitions was $27 million, or 2.8%, primarily due to acquisitions within our growth markets during fiscal 2014.  Net revenue was unfavorably impacted by $20 million, or 2.1%, primarily due to the divestiture of our Armourguard business in New Zealand and fire and security business in Fiji in the first quarter of fiscal 2014.

[0000833444-14-000099:mdna:75]
Net revenue increased $53 million, or 1.9%, to $2,909 million for the nine months ended June 27, 2014 as compared to $2,856 million for the nine months ended June 28, 2013. Organic revenue growth was driven by an increase in both service and installation revenue, primarily in Asia, our other growth markets, and the United Kingdom, partially offset by declines in our Pacific region and Continental Europe.  The impact of acquisitions was $99 million, or 3.5%, primarily due to acquisitions within the Pacific region during fiscal 2013 and within our growth markets during fiscal 2014. Changes in foreign currency exchange rates unfavorably impacted net revenue by $52 million, or 1.8%.  Net revenue was unfavorably impacted by $47 million, or 1.6%, primarily due to the divestiture of our Armourguard business in New Zealand and fire and security business in Fiji in the first quarter of fiscal 2014.

[0000833444-14-000099:mdna:76]
[same as prior period, unchanged from 0000833444-14-000046:mdna:98]

[0000833444-14-000099:mdna:77]
[same as prior period, unchanged from 0000833444-14-000046:mdna:74]

[0000833444-14-000099:mdna:78]
Operating income for the quarter ended June 27, 2014 increased $24 million, or 31.2%, to $101 million as compared to operating income of $77 million for the quarter ended June 28, 2013. Operating income for the quarter ended June 27, 2014 was favorably impacted by a decrease in restructuring charges and the benefit of ongoing productivity initiatives, partially offset by a lower mix of high-margin service revenue in Australia.

[0000833444-14-000099:mdna:79]
Operating income for the nine months ended June 27, 2014 increased $58 million, or 23.2%, to $308 million as compared to operating income of $250 million for the nine months ended June 28, 2013. Operating income for the nine months ended June 27, 2014 was favorably impacted by the $21 million insurance recovery related to China, the benefit of ongoing productivity initiatives and a decrease in restructuring charges, partially offset by weakness in Australia and a loss on the sale of an investment.

[0000833444-14-000099:mdna:80]
Key items impacting operating income for the quarters and nine months ended June 27, 2014 and June 28, 2013, respectively, are as follows:

[0000833444-14-000099:mdna:81]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 27, 2014 |  | June 28, 2013 |  | June 27, 2014 |  | June 28, 2013 |
| China insurance recovery | $ | — |  |  | $ | — |  |  | $ | (21 | ) |  | $ | — |  |
| Loss on sale of investment | — |  |  | — |  |  | 7 |  |  | — |  |
| Restructuring, repositioning and asset impairment charges, net | 11 |  |  | 34 |  |  | 15 |  |  | 51 |  |

[0000833444-14-000099:mdna:82]
[same as prior period, unchanged from 0000833444-14-000046:mdna:79]

[0000833444-14-000099:mdna:83]
Financial information for Global Products for the quarters and nine months ended June 27, 2014 and June 28, 2013 is as follows:

[0000833444-14-000099:mdna:84]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 27, 2014 |  | June 28, 2013 |  | June 27, 2014 |  | June 28, 2013 |
| Net revenue | $ | 693 |  |  | $ | 600 |  |  | $ | 1,863 |  |  | $ | 1,712 |  |
| Net revenue growth | 15.5 | % |  | N/A |  |  | 8.8 | % |  | N/A |  |
| Organic revenue growth | 12.2 | % |  | N/A |  |  | 5.8 | % |  | N/A |  |
| Operating income | $ | 136 |  |  | $ | 114 |  |  | $ | 329 |  |  | $ | 188 |  |
| Operating margin | 19.6 | % |  | 19.0 | % |  | 17.7 | % |  | 11.0 | % |

[0000833444-14-000099:mdna:85]
[same as prior period, unchanged from 0000833444-14-000046:mdna:82]

[0000833444-14-000099:mdna:86]
[same as prior period, unchanged from 0000833444-14-000046:mdna:83]

[0000833444-14-000099:mdna:87]
| Factors Contributing to Year-Over-Year Change |  | Third QuarterFiscal 2014Compared toThird QuarterFiscal 2013 |  | Year to Date Fiscal 2014Compared toYear to Date Fiscal 2013 |
| Organic revenue growth |  | $ | 73 |  |  | $ | 99 |  |
| Acquisitions |  | 19 |  |  | 56 |  |
| Impact of foreign currency |  | 1 |  |  | (6 | ) |
| Other |  | — |  |  | 2 |  |
| Total change |  | $ | 93 |  |  | $ | 151 |  |

[0000833444-14-000099:mdna:88]
Net revenue increased $93 million, or 15.5%, to $693 million for the quarter ended June 27, 2014 as compared to $600 million for the quarter ended June 28, 2013.  Organic revenue growth was driven by growth within all three businesses, primarily in the life safety business due to demand for our new Scott Air-Pak product, the release of which was delayed due to industry-wide safety standard delays. Net revenue increased $19 million, or 3.2%, due to an acquisition within our security products business during fiscal 2013.

[0000833444-14-000099:mdna:89]
Net revenue increased $151 million, or 8.8%, to $1,863 million for the nine months ended June 27, 2014 as compared to $1,712 million for the nine months ended June 28, 2013.  Organic revenue growth was driven by an increase within all three

[0000833444-14-000099:mdna:90]
businesses, primarily in the security products business.  Net revenue also increased $56 million, or 3.3%, due to an acquisition within our security products business during fiscal 2013.

[0000833444-14-000099:mdna:91]
[same as prior period, unchanged from 0000833444-14-000046:mdna:88]

[0000833444-14-000099:mdna:92]
Operating income for the quarter ended June 27, 2014 increased by $22 million, or 19.3% to $136 million, as compared to operating income of $114 million for the quarter ended June 28, 2013.  The increase was driven by net revenue growth for the quarter ended June 27, 2014, partially offset by additional investments in research and development and sales and marketing costs.

[0000833444-14-000099:mdna:93]
Operating income for the nine months ended June 27, 2014 increased $141 million, or 75.0%, to $329 million, as compared to operating income of $188 million for the nine months ended June 28, 2013.  The increase was driven by net revenue growth for the nine months ended June 27, 2014 and the unfavorable impact of an environmental remediation charge  recorded in the comparable period, partially offset by additional investments in research and development and sales and marketing costs.

[0000833444-14-000099:mdna:94]
Key items impacting operating income for the quarters and nine months ended June 27, 2014 and June 28, 2013, respectively, are as follows:

[0000833444-14-000099:mdna:95]
|  | For the Quarter Ended |  | For the Nine Months Ended |
| ($ in millions) | June 27, 2014 |  | June 28, 2013 |  | June 27, 2014 |  | June 28, 2013 |
| Restructuring, repositioning and asset impairment charges, net | $ | 3 |  |  | $ | 5 |  |  | $ | 9 |  |  | $ | 10 |  |
| Environmental remediation costs - Marinette | — |  |  | — |  |  | — |  |  | 100 |  |

[0000833444-14-000099:mdna:96]
[same as prior period, unchanged from 0000833444-14-000046:mdna:93]

[0000833444-14-000099:mdna:97]
Corporate expense was $58 million for the quarter ended June 27, 2014 and $117 million for the quarter ended June 28, 2013.  The decrease of $59 million was primarily due to $18 million in asbestos related items ($6 million gain for the quarter ended June 27, 2014 as compared to a $12 million charge for the quarter ended June 28, 2013) as well as recoveries received from settlements with former management of $4 million for the quarter ended June 27, 2014, as compared to a $27 million charge for the write-off of an insurance receivable that had been established in respect of a legacy legal claim for the quarter ended June 28, 2013.  In addition, a decrease in separation costs was offset by an increase in restructuring charges as compared to the quarter ended June 28, 2013.

[0000833444-14-000099:mdna:98]
Corporate expense was $73 million for the nine months ended June 27, 2014 as compared to net expense of $239 million for the nine months ended June 28, 2013.  In addition to the factors noted above for the quarter ended June 27, 2014, which reduced Corporate expense, the decrease in expense was primarily due to the reversal of a compensation reserve of $92 million established in respect of legacy litigation with former management.  Also included in the nine months ended June 27, 2014  is a settlement with CIT, a former subsidiary, which resulted in a net gain of $16 million, in addition to benefits achieved from previous restructuring activities.  See Note 11 to the unaudited Consolidated Financial Statements for additional information related to our CIT settlement and legacy legal matters.

[0000833444-14-000099:mdna:99]
Key items included in corporate expense for the quarters and nine months ended June 27, 2014 and June 28, 2013, respectively, are as follows:

[0000833444-14-000099:mdna:100]
|  | For the Quarters Ended |  | For the Nine Months Ended |
| ($ in millions) | June 27, 2014 |  | June 28, 2013 |  | June 27, 2014 |  | June 28, 2013 |
| Legacy legal (gains) charges | $ | (4 | ) |  | $ | 27 |  |  | $ | (96 | ) |  | $ | 27 |  |
| CIT settlement gain | — |  |  | — |  |  | (16 | ) |  | — |  |
| Restructuring, repositioning and asset impairment charges, net | 10 |  |  | 3 |  |  | 24 |  |  | 8 |  |
| Asbestos related (gains) charges | (6 | ) |  | 12 |  |  | (5 | ) |  | 10 |  |
| Separation costs | — |  |  | 10 |  |  | 2 |  |  | 16 |  |
| Losses (gains) on divestitures, net |  |  |  | 3 |  |  | (3 | ) |  | 5 |  |

[0000833444-14-000099:mdna:101]
53

[0000833444-14-000099:mdna:102]
[same as prior period, unchanged from 0000833444-14-000046:mdna:99]

[0000833444-14-000099:mdna:103]
The preparation of the unaudited Consolidated Financial Statements in conformity with US GAAP requires management to use judgment in making estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of contingent assets and liabilities and the reported amounts of revenue and expenses. We believe that our accounting policies for depreciation and amortization methods of security monitoring-related assets, revenue recognition, loss contingencies, income taxes, goodwill and indefinite-lived intangible assets, long-lived assets and pension and postretirement benefits are based on, among other things, judgments and assumptions made by management that include inherent risks and uncertainties. During fiscal 2014, there have been no significant changes to these policies or in the underlying accounting assumptions and estimates used in the above critical accounting policies from those disclosed in the Consolidated Financial Statements and accompanying notes contained in the Company's Current Report on Form 8-K filed with the SEC on May 16, 2014 for the fiscal year ended September 27, 2013. See Note 1 to the unaudited Consolidated Financial Statements for the adoption and issuance of new accounting standards during fiscal 2014.

[0000833444-14-000099:mdna:104]
[same as prior period, unchanged from 0000833444-14-000046:mdna:101]

[0000833444-14-000099:mdna:105]
A fundamental objective of the Company is to have sufficient liquidity, balance sheet strength, and financial flexibility to fund the operating and capital requirements of its core businesses around the world. The primary source of funds to finance our operations and capital expenditures is cash generated by operations. In addition, we maintain a commercial paper program, have access to a committed revolving credit facility and have access to equity and debt capital from public and private sources. We continue to balance our operating, investing and financing uses of cash through investments and acquisitions in our core businesses, dividends and share repurchases. In addition, we believe our cash position, amounts available under our credit facility, commercial paper program and cash provided by operating activities will be adequate to cover our operational and business needs in the foreseeable future.

[0000833444-14-000099:mdna:106]
As of June 27, 2014 and September 27, 2013, our cash and cash equivalents, total debt and Tyco shareholders' equity are as follows:

[0000833444-14-000099:mdna:107]
|  | As of |
| ($ in millions) | June 27, 2014 |  | September 27, 2013 |
| Cash and cash equivalents | $ | 1,912 |  |  | $ | 563 |  |
| Total debt | 1,463 |  |  | 1,463 |  |
| Total Tyco shareholders' equity | 6,002 |  |  | 5,098 |  |
| Total debt as a % of total capital (1) | 19.6 | % |  | 22.3 | % |

[0000833444-14-000099:mdna:108]
(1) Total capital represents the aggregate amount of total debt and total Tyco Shareholders' equity which was $7,465 million and $6,561 million as of June 27, 2014 and September 27, 2013, respectively.

[0000833444-14-000099:mdna:109]
[same as prior period, unchanged from 0000833444-14-000046:mdna:106]

[0000833444-14-000099:mdna:110]
Our cash flows from operating, investing and financing from continuing operations for the nine months ended June 27, 2014 and June 28, 2013 are summarized below:

[0000833444-14-000099:mdna:111]
|  | For the Nine Months Ended |
| ($ in millions) | June 27, 2014 |  | June 28, 2013 |
| Net cash provided by operating activities | $ | 520 |  |  | $ | 360 |  |
| Net cash used in investing activities | (83 | ) |  | (363 | ) |
| Net cash provided by (used in) financing activities | 920 |  |  | (370 | ) |

[0000833444-14-000099:mdna:112]
[same as prior period, unchanged from 0000833444-14-000046:mdna:109]

[0000833444-14-000099:mdna:113]
[same as prior period, unchanged from 0000833444-14-000046:mdna:110]

[0000833444-14-000099:mdna:114]
The net change in working capital decreased operating cash flow by $500 million in the nine months ended June 27, 2014. The significant changes in working capital included a $360 million decrease in accrued and other liabilities, a $49 million

[0000833444-14-000099:mdna:115]
increase in contracts in process, a $35 million increase in prepaid expenses and other current assets, and a $39 million increase in accounts receivable.

[0000833444-14-000099:mdna:116]
The net change in working capital decreased operating cash flow by $367 million in the nine months ended June 28, 2013. The significant changes in working capital included a $231 million decrease in accrued and other liabilities, a $44 million decrease in accounts payable, and a $71 million increase in inventories, partially offset by a $73 million decrease in prepaid expenses and other current assets.

[0000833444-14-000099:mdna:117]
During the nine months ended June 27, 2014 and June 28, 2013, we paid approximately $57 million and $58 million respectively, in cash related to restructuring activities. See Note 4 to our unaudited Consolidated Financial Statements for further information regarding these activities.

[0000833444-14-000099:mdna:118]
In connection with the 2012 Separation, we paid $48 million and $151 million in separation costs during the nine months ended June 27, 2014 and June 28, 2013, respectively.

[0000833444-14-000099:mdna:119]
During the nine months ended June 27, 2014 and June 28, 2013, we made net payments related to asbestos liabilities of $3 million and received asbestos recoveries net of such payments of $24 million.

[0000833444-14-000099:mdna:120]
During the nine months ended June 27, 2014 and June 28, 2013, we made environmental remediation payments related to environmental remediation activities for a facility located in Marinette, Wisconsin, of $60 million and $24 million, respectively.

[0000833444-14-000099:mdna:121]
During the nine months ended June 27, 2014 and June 28, 2013, we made required contributions of $17 million and $5 million, respectively, to our U.S. pension plans and $20 million and $36 million, respectively, to our non-U.S. pension plans. We anticipate that we will contribute at least the minimum required to our pension plans in 2014 of $25 million for our U.S. plans and $28 million for our non-U.S. plans.

[0000833444-14-000099:mdna:122]
During the nine months ended June 27, 2014, Tyco made a net cash payment of $155 million to Covidien under the terms of the 2007 Tax Sharing Agreement.  The cash exchanged was a reimbursement between the parties for various payments made to the IRS for federal income taxes related to the audit of fiscal years 2005 through 2007.

[0000833444-14-000099:mdna:123]
Income taxes paid, net of refunds, related to continuing operations were $74 million and $103 million during the nine months ended June 27, 2014 and June 28, 2013, respectively.

[0000833444-14-000099:mdna:124]
Net interest paid related to continuing operations were $53 million and $46 million for the nine months ended June 27, 2014 and June 28, 2013, respectively.

[0000833444-14-000099:mdna:125]
[same as prior period, unchanged from 0000833444-14-000046:mdna:120]

[0000833444-14-000099:mdna:126]
[same as prior period, unchanged from 0000833444-14-000046:mdna:121]

[0000833444-14-000099:mdna:127]
We made capital expenditures of $210 million and $205 million for the nine months ended June 27, 2014 and June 28, 2013, respectively. The level of capital expenditures in fiscal 2014 is expected to exceed the spending levels in fiscal 2013 and is also expected to exceed depreciation expense.

[0000833444-14-000099:mdna:128]
During the nine months ended June 27, 2014, we paid cash for acquisitions included in continuing operations totaling $63 million, net of $1 million cash acquired, which related to acquisitions included in our NA Installation & Services and ROW Installation & Services segments. During the nine months ended June 28, 2013, we paid cash for acquisitions included in continuing operations totaling $75 million which primarily related to an acquisition in our NA Installation & Services segment.

[0000833444-14-000099:mdna:129]
We maintained captive insurance companies to manage certain of our insurable liabilities. The captive insurance companies held certain investment accounts for the purposes of providing collateral and other purposes for our insurable liabilities.  During the nine months ended June 27, 2014, our captive insurance companies made net sales of approximately $283 million.  During the nine months ended June 28, 2013, our captive insurance companies made net purchases of approximately $79 million.  See Notes 10 and 18 to our unaudited Consolidated Financial Statements for more information.

[0000833444-14-000099:mdna:130]
During the nine months ended June 27, 2014, we purchased time deposits with a tenor from three to six months of approximately $277 million.

[0000833444-14-000099:mdna:131]
During the nine months ended June 27, 2014, we also generated $250 million in proceeds from the sale of our equity method investment in Atkore, as described in Note 3 to our unaudited Consolidated Financial Statements.

[0000833444-14-000099:mdna:132]
55

[0000833444-14-000099:mdna:133]
[same as prior period, unchanged from 0000833444-14-000046:mdna:125]

[0000833444-14-000099:mdna:134]
[same as prior period, unchanged from 0000833444-14-000046:mdna:126]

[0000833444-14-000099:mdna:135]
During the nine months ended June 27, 2014, TIFSA issued commercial paper, for which the net proceeds were used to settle certain legacy environmental obligations, fund an acquisition, and for other general corporate purposes.  As of June 27, 2014 and September 27, 2013, TIFSA had no commercial paper outstanding.  The maximum aggregate amount of unsecured commercial paper notes available to be issued, on a private placement basis, under the commercial paper program is $1 billion as of June 27, 2014.

[0000833444-14-000099:mdna:136]
As of June 27, 2014 there were no amounts drawn under the Company's revolving credit facility.

[0000833444-14-000099:mdna:137]
Pursuant to our share repurchase program, we may repurchase Tyco shares from time to time in open market purchases at prevailing market prices, in negotiated transactions off the market, or pursuant to an approved trading plan in accordance with applicable regulations.  During the nine months ended June 27, 2014, we repurchased approximately 20 million common shares for approximately $806 million.  During the nine months ended June 28, 2013, we repurchased approximately 10 million common shares for approximately $300 million.

[0000833444-14-000099:mdna:138]
On March 5, 2014, our shareholders approved a cash dividend of $0.72 per common share payable to shareholders in four quarterly installments of $0.18 in May 2014, August 2014, November 2014 and February 2015. During the nine months ended June 27, 2014 and June 28, 2013, we paid cash dividends of approximately $231 million and $214 million, respectively.

[0000833444-14-000099:mdna:139]
[same as prior period, unchanged from 0000833444-14-000046:mdna:131]

[0000833444-14-000099:mdna:140]
Commitments and Contingencies

[0000833444-14-000099:mdna:141]
For a detailed discussion of contingencies related to tax and litigation matters, see Notes 6 and 11 to our unaudited Consolidated Financial Statements.

[0000833444-14-000099:mdna:142]
[same as prior period, unchanged from 0000833444-14-000046:mdna:134]

[0000833444-14-000099:mdna:143]
We had a backlog of unfilled orders of $5,029 million and $4,812 million as of June 27, 2014 and September 27, 2013, respectively.

[0000833444-14-000099:mdna:144]
[same as prior period, unchanged from 0000833444-14-000046:mdna:136]

[0000833444-14-000099:mdna:145]
|  | NA Installation& Services |  | ROWInstallation& Services |  | GlobalProducts |  | Total |
| As of September 27, 2013 |  |  |  |  |  |  |  |
| Backlog | $ | 908 |  |  | $ | 939 |  |  | $ | 196 |  |  | $ | 2,043 |  |
| Recurring revenue in force | 1,239 |  |  | 1,194 |  |  | — |  |  | 2,433 |  |
| Deferred revenue | 296 |  |  | 40 |  |  | — |  |  | 336 |  |
| Total Backlog | $ | 2,443 |  |  | $ | 2,173 |  |  | $ | 196 |  |  | $ | 4,812 |  |
| As of June 27, 2014 |  |  |  |  |  |  |  |  |  |  |  |
| Backlog | $ | 980 |  |  | $ | 1,106 |  |  | $ | 198 |  |  | $ | 2,284 |  |
| Recurring revenue in force | 1,233 |  |  | 1,199 |  |  | — |  |  | 2,432 |  |
| Deferred revenue | 274 |  |  | 39 |  |  | — |  |  | 313 |  |
| Total Backlog | $ | 2,487 |  |  | $ | 2,344 |  |  | $ | 198 |  |  | $ | 5,029 |  |

[0000833444-14-000099:mdna:146]
Backlog increased $217 million, or 4.5%, to $5,029 million as of June 27, 2014 compared to $4,812 million as of September 27, 2013. The net increase in backlog was driven by increases in our ROW Installation & Services segment as a result of growth in installation backlog, primarily in Asia, Pacific and Growth Markets, as well as increases in our Global Products segment across security products and fire product businesses. Changes in foreign currency unfavorably impacted backlog by $24 million, or 0.5%.

[0000833444-14-000099:mdna:147]
[same as prior period, unchanged from 0000833444-14-000046:mdna:163]

[0000833444-14-000099:mdna:148]
[same as prior period, unchanged from 0000833444-14-000046:mdna:139]

[0000833444-14-000099:mdna:149]
[same as prior period, unchanged from 0000833444-14-000046:mdna:140]

[0000833444-14-000099:mdna:150]
There are certain guarantees or indemnifications extended among Tyco, Covidien, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 Separation and Distribution Agreements and the Tax Sharing Agreements. The guarantees primarily relate to certain contingent tax liabilities included in the Tax Sharing Agreements. At the time of the 2007 and 2012 Separations, we recorded liabilities necessary to recognize the fair value of such guarantees and indemnifications. See Note 6 to the unaudited Consolidated Financial Statements for further discussion of the Tax Sharing Agreement. In addition, prior to the 2007 and 2012 Separations we provided support in the form of financial and/or performance guarantees to various Covidien, TE Connectivity, ADT and Tyco Flow Control operating entities. To the extent these guarantees were not assigned in connection with the 2007 and 2012 Separations, we remained as the guarantor, but were typically indemnified by the former subsidiary. See Note 18 to the unaudited Consolidated Financial Statements for a discussion of these liabilities.

[0000833444-14-000099:mdna:151]
[same as prior period, unchanged from 0000833444-14-000046:mdna:143]

[0000833444-14-000099:mdna:152]
[same as prior period, unchanged from 0000833444-14-000046:mdna:144]

[0000833444-14-000099:mdna:153]
During the quarter ended June 27, 2014, Tyco replaced available for sale investments held as collateral for the Company's insurable liabilities with letters of credit of approximately $137 million.  See Note 10 for further details.  The Company had total outstanding letters of credit and bank guarantees of approximately $561 million and $424 million as of June 27, 2014 and September 27, 2013, respectively.

[0000833444-14-000099:mdna:154]
[same as prior period, unchanged from 0000833444-14-000046:mdna:145]

[0000833444-14-000099:mdna:155]
[same as prior period, unchanged from 0000833444-14-000046:mdna:146]

[0000833444-14-000099:mdna:156]
[same as prior period, unchanged from 0000833444-14-000046:mdna:147]

[0000833444-14-000099:mdna:157]
[same as prior period, unchanged from 0000833444-14-000046:mdna:148]

[0000833444-14-000099:mdna:158]
Quarter Ended June 27, 2014

[0000833444-14-000099:mdna:159]
|  | Net Revenue for the Quarter Ended June 28, 2013 |  | Base YearAdjustmentsDivestitures / Other |  | AdjustedFiscal 2013Base Revenue |  | ForeignCurrency |  | Acquisitions |  | OrganicRevenue(1) |  | OrganicGrowthPercentage |  | Net Revenue for the Quarter Ended June 27, 2014 |
|  | ($ in millions) |
| NA Installation & Services | $ | 966 |  |  | $ | (6 | ) |  | $ | 960 |  |  | $ | (7 | ) |  | $ | 5 |  |  | $ | 10 |  |  | 1.0 | % |  | $ | 968 |  |
| ROW Installation & Services | 971 |  |  | (20 | ) |  | 951 |  |  | — |  |  | 27 |  |  | 23 |  |  | 2.4 | % |  | 1,001 |  |
| Global Products | 600 |  |  | — |  |  | 600 |  |  | 1 |  |  | 19 |  |  | 73 |  |  | 12.2 | % |  | 693 |  |
| Total Net Revenue | $ | 2,537 |  |  | $ | (26 | ) |  | $ | 2,511 |  |  | $ | (6 | ) |  | $ | 51 |  |  | $ | 106 |  |  | 4.2 | % |  | $ | 2,662 |  |

[0000833444-14-000099:mdna:160]
[same as prior period, unchanged from 0000833444-14-000046:mdna:151]

[0000833444-14-000099:mdna:161]
[same as prior period, unchanged from 0000833444-14-000046:mdna:152]

[0000833444-14-000099:mdna:162]
Nine Months Ended June 27, 2014

[0000833444-14-000099:mdna:163]
|  | Net Revenue for the Nine Months Ended June 28, 2013 |  | Base YearAdjustmentsDivestitures / Other(2) |  | AdjustedFiscal 2013Base Revenue |  | ForeignCurrency |  | Acquisitions |  | OrganicRevenue(1) |  | OrganicGrowthPercentage |  | Net Revenue for the Nine Months Ended June 27, 2014 |
|  | ($ in millions) |
| NA Installation & Services | $ | 2,895 |  |  | $ | (42 | ) |  | $ | 2,853 |  |  | $ | (24 | ) |  | $ | 14 |  |  | $ | 21 |  |  | 0.7 | % |  | $ | 2,864 |  |
| ROW Installation & Services | 2,856 |  |  | (47 | ) |  | 2,809 |  |  | (52 | ) |  | 99 |  |  | 53 |  |  | 1.9 | % |  | 2,909 |  |
| Global Products | 1,712 |  |  | 2 |  |  | 1,714 |  |  | (6 | ) |  | 56 |  |  | 99 |  |  | 5.8 | % |  | 1,863 |  |
| Total Net Revenue | $ | 7,463 |  |  | $ | (87 | ) |  | $ | 7,376 |  |  | $ | (82 | ) |  | $ | 169 |  |  | $ | 173 |  |  | 2.3 | % |  | $ | 7,636 |  |

[0000833444-14-000099:mdna:164]
______________________________________________________________________________

[0000833444-14-000099:mdna:165]
[same as prior period, unchanged from 0000833444-14-000046:mdna:156]

[0000833444-14-000099:mdna:166]
[same as prior period, unchanged from 0000833444-14-000046:mdna:153]

[0000833444-14-000099:mdna:167]
[same as prior period, unchanged from 0000833444-14-000046:mdna:158]

[0000833444-14-000099:mdna:168]
[same as prior period, unchanged from 0000833444-14-000046:mdna:159]

[0000833444-14-000099:mdna:169]
[same as prior period, unchanged from 0000833444-14-000046:mdna:160]

[0000833444-14-000099:mdna:170]
[same as prior period, unchanged from 0000833444-14-000046:mdna:161]

[0000833444-14-000099:mdna:171]
| • | our, and our employees' and agents' ability to comply with complex and continually changing laws and regulations that govern our international operations, including the U.S. Foreign Corrupt Practices Act, similar anti-bribery laws in other jurisdictions, a variety of export control, customs, currency exchange control and transfer pricing regulations, and our corporate policies governing these matters; |

[0000833444-14-000099:mdna:172]
| • | the outcome of litigation, arbitrations and governmental proceedings; |

[0000833444-14-000099:mdna:173]
| • | effect of income tax audits, litigation, settlements and appeals; |

[0000833444-14-000099:mdna:174]
58

[0000833444-14-000099:mdna:175]
[same as prior period, unchanged from 0000833444-14-000046:mdna:166]

[0000833444-14-000099:mdna:176]
[same as prior period, unchanged from 0000833444-14-000046:mdna:167]

[0000833444-14-000099:mdna:177]
[same as prior period, unchanged from 0000833444-14-000046:mdna:168]

[0000833444-14-000099:mdna:178]
[same as prior period, unchanged from 0000833444-14-000046:mdna:169]

[0000833444-14-000099:mdna:179]
[same as prior period, unchanged from 0000833444-14-000046:mdna:170]

[0000833444-14-000099:mdna:180]
[same as prior period, unchanged from 0000833444-14-000046:mdna:171]

[0000833444-14-000099:mdna:181]
[same as prior period, unchanged from 0000833444-14-000046:mdna:172]

[0000833444-14-000099:mdna:182]
[same as prior period, unchanged from 0000833444-14-000046:mdna:173]

[0000833444-14-000099:mdna:183]
[same as prior period, unchanged from 0000833444-14-000046:mdna:174]

[0000833444-14-000099:mdna:184]
[same as prior period, unchanged from 0000833444-14-000046:mdna:175]

[0000833444-14-000099:mdna:185]
[same as prior period, unchanged from 0000833444-14-000046:mdna:176]

[0000833444-14-000099:mdna:186]
[same as prior period, unchanged from 0000833444-14-000046:mdna:177]

[0000833444-14-000099:mdna:187]
| • | risks associated with our jurisdiction of incorporation, including the possibility of reduced flexibility with respect to certain aspects of capital management and corporate governance, increased or different regulatory burdens, and the possibility that we may not realize anticipated tax benefits; |

[0000833444-14-000099:mdna:188]
| • | the possible effects on Tyco of future legislation in the United States that may limit or eliminate potential U.S. tax benefits resulting from Tyco International's incorporation outside of the U.S. or deny U.S. government contracts to Tyco based upon its jurisdiction of incorporation; |

[0000833444-14-000099:mdna:189]
| • | risks associated with the proposed change in our global headquarters to Ireland; and |

[0000833444-14-000099:mdna:190]
[same as prior period, unchanged from 0000833444-14-000046:mdna:180]
