# JCI 8-K — 0000833444-14-000095 filed 2014-07-25

## item codes, every 8-K on or before 2014-07-25

- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2014-07-25

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-14-000095:8k_2_02:1]
EX-99.1
2
exhibit991-q314.htm
EXHIBIT 99.1 EARNINGS RELEASE

[0000833444-14-000095:8k_2_02:2]
Exhibit 99.1 - Q314

[0000833444-14-000095:8k_2_02:3]
Exhibit 99.1

[0000833444-14-000095:8k_2_02:4]
| Investor Relations Contacts: |  | Media Contact: |  |
| Antonella Franzen |  | Stephen Wasdick |  |
| +1-609-720-4665 |  | +1-609-806-2262 |  |
| afranzen@tyco.com |  | swasdick@tyco.com |  |
| Leila Peters |  |  |  |
| +1-609-720-4545 |  |  |  |
| lpeters@tyco.com |  |  |  |

[0000833444-14-000095:8k_2_02:5]
FOR IMMEDIATE RELEASE:

[0000833444-14-000095:8k_2_02:6]
TYCO REPORTS THIRD QUARTER 2014 EARNINGS

[0000833444-14-000095:8k_2_02:7]
FROM CONTINUING OPERATIONS BEFORE SPECIAL ITEMS OF $0.54 PER SHARE

[0000833444-14-000095:8k_2_02:8]
AND GAAP EARNINGS OF $0.93 PER SHARE

[0000833444-14-000095:8k_2_02:9]
| • | Revenue of $2.7 billion increases 5%, with 4% organic growth |

[0000833444-14-000095:8k_2_02:10]
| • | Before special items, segment operating income increases 11% and segment operating margin improves 80 basis points to a record-high 14.5% |

[0000833444-14-000095:8k_2_02:11]
| • | Diluted EPS from continuing operations before special items increases 17% |

[0000833444-14-000095:8k_2_02:12]
| • | As previously announced, the company completed the divestiture of its ADT Korea security business and remaining interest in Atkore International for a combined $2.2 billion in proceeds |

[0000833444-14-000095:8k_2_02:13]
| • | Company repurchased 13 million shares for $556 million during the quarter |

[0000833444-14-000095:8k_2_02:14]
(Income and EPS amounts are attributable to Tyco common shareholders)

[0000833444-14-000095:8k_2_02:15]
($ millions, except per-share amounts)

[0000833444-14-000095:8k_2_02:16]
(All prior periods have been recast to reflect certain businesses as discontinued operations)

[0000833444-14-000095:8k_2_02:17]
|  |  | Q3 2014 |  | Q3 2013 |  | % Change |  |
| Revenue |  | $ | 2,662 |  |  | $ | 2,537 |  |  | 5 | % |  |
| Segment Operating Income |  | $ | 354 |  |  | $ | 279 |  |  | 27 | % |  |
| Operating Income |  | $ | 296 |  |  | $ | 162 |  |  | 83 | % |  |
| Income from Continuing Operations |  | $ | 434 |  |  | $ | 112 |  |  | — |  |  |
| Diluted EPS from Continuing Operations |  | $ | 0.93 |  |  | $ | 0.24 |  |  | — |  |  |
| Special Items |  | $ | 0.39 |  |  | $ | (0.22 | ) |  |  |  |
| Segment Operating Income Before Special Items |  | $ | 386 |  |  | $ | 348 |  |  | 11 | % |  |
| Income from Continuing Ops Before Special Items |  | $ | 253 |  |  | $ | 213 |  |  | 19 | % |  |
| Diluted EPS from Continuing Ops Before Special Items |  | $ | 0.54 |  |  | $ | 0.46 |  |  | 17 | % |  |

[0000833444-14-000095:8k_2_02:18]
NEUHAUSEN, Switzerland, July 25, 2014 - Tyco (NYSE: TYC) today reported $0.93 in GAAP diluted earnings per share (EPS) from continuing operations for the fiscal third quarter of 2014 and diluted EPS from continuing operations before special items of $0.54. Revenue in the quarter increased 5% versus the prior year to $2.7 billion. Organic revenue grew 4% in the quarter, with growth across all segments, led by products with a 12% increase from the prior year quarter. Acquisitions contributed 2 percentage points of growth, which was partially offset by the impact of divestitures.

[0000833444-14-000095:8k_2_02:19]
“The investments we have made to expand our product capabilities, combined with continued improvements in our operational execution, drove a 17% increase in earnings per share before special items in the quarter,” said Tyco Chief Executive Officer George R. Oliver. “The pickup in revenue growth we started to see last quarter continued, resulting in strong organic growth of 4%. In addition, we moved quickly to deploy the proceeds from our recent divestitures to maximize shareholder value, repurchasing 20 million shares over the past three months.”

[0000833444-14-000095:8k_2_02:20]
Organic revenue, free cash flow, operating income, segment operating income, and diluted EPS from continuing operations before special items are non-GAAP financial measures and are described below. For a reconciliation of these non-GAAP measures, see the attached tables. Additional schedules as well as third quarter review slides can be found in the Investor Relations section of Tyco’s website at http://investors.tyco.com. Certain tables contain the symbol “-” to denote that the percentage change is not meaningful.

[0000833444-14-000095:8k_2_02:21]
SEGMENT RESULTS

[0000833444-14-000095:8k_2_02:22]
The financial results presented in the tables below are in accordance with GAAP unless otherwise indicated. All dollar amounts are pre-tax and stated in millions. During the quarter ended June 27, 2014, the company decided to sell certain businesses previously reported within its Rest of World Installation & Services operating segment. These businesses generated $41 million of revenue in fiscal 2013 with an operating loss of $11 million. Additionally, on March 3, 2014, Tyco announced that it reached a definitive agreement to sell its South Korean security business, ADT Korea, and completed the transaction on May 22, 2014.  The results of these businesses have been classified as discontinued operations for the current and historical periods. The revenue and operating income results shown below have been adjusted to reflect these changes in all periods presented. All comparisons are to the fiscal third quarter of 2013 unless otherwise indicated.

[0000833444-14-000095:8k_2_02:23]
North America Installation & Services

[0000833444-14-000095:8k_2_02:24]
|  |  | Q3 2014 |  | Q3 2013 |  | % Change |  |
| Revenue |  | $ | 968 |  |  | $ | 966 |  |  | — |  |  |
| Operating Income |  | $ | 117 |  |  | $ | 88 |  |  | 33 | % |  |
| Operating Margin |  | 12.1 | % |  | 9.1 | % |  |  |  |
| Special Items |  | $ | (17 | ) |  | $ | (29 | ) |  |  |  |
| Operating Income Before Special Items |  | $ | 134 |  |  | $ | 117 |  |  | 15 | % |  |
| Operating Margin Before Special Items |  | 13.8 | % |  | 12.1 | % |  |  |  |

[0000833444-14-000095:8k_2_02:25]
Revenue of $968 million was relatively consistent with the prior year as organic revenue growth was offset by the impact of divestitures and changes in foreign currency exchange rates. Both service and installation revenue grew 1% for total organic revenue growth of 1% in the quarter. Backlog of $2.5 billion increased 1% year over year and 1% on a quarter sequential basis, excluding the impact of foreign currency.

[0000833444-14-000095:8k_2_02:26]
Operating income for the quarter was $117 million and the operating margin was 12.1%. Special items of $17 million consisted primarily of separation and restructuring charges. Before special items, operating income was $134 million and the operating margin was 13.8%. The 170 basis point improvement in operating margin before special items resulted from improved execution and the benefit of restructuring and productivity initiatives.

[0000833444-14-000095:8k_2_02:27]
Rest of World Installation & Services

[0000833444-14-000095:8k_2_02:28]
|  |  | Q3 2014 |  | Q3 2013 |  | % Change |  |
| Revenue |  | $ | 1,001 |  |  | $ | 971 |  |  | 3 | % |  |
| Operating Income |  | $ | 101 |  |  | $ | 77 |  |  | 31 | % |  |
| Operating Margin |  | 10.1 | % |  | 7.9 | % |  |  |  |
| Special Items |  | $ | (11 | ) |  | $ | (35 | ) |  |  |  |
| Operating Income Before Special Items |  | $ | 112 |  |  | $ | 112 |  |  | — |  |  |
| Operating Margin Before Special Items |  | 11.2 | % |  | 11.5 | % |  |  |  |

[0000833444-14-000095:8k_2_02:29]
Revenue of $1.0 billion increased 3% compared to the prior year.  Organic revenue growth of 2% consisted of 4% growth in installation and 1% growth in service revenue.  Acquisitions contributed 3% to revenue growth, which was partially offset by the impact of divestitures.  Backlog of $2.3 billion increased 8% year over year and was relatively flat on a quarter sequential basis, excluding the impact of foreign currency.

[0000833444-14-000095:8k_2_02:30]
Operating income for the quarter was $101 million and the operating margin was 10.1%. Special items of $11 million consisted primarily of restructuring charges. Before special items, operating income was $112 million, and the operating margin declined 30 basis points to 11.2%.  Year over year, the operating margin was impacted by the mix of businesses contributing to growth, as well as a lower percentage of high-margin service revenue.

[0000833444-14-000095:8k_2_02:31]
Global Products

[0000833444-14-000095:8k_2_02:32]
|  |  | Q3 2014 |  | Q3 2013 |  | % Change |  |
| Revenue |  | $ | 693 |  |  | $ | 600 |  |  | 15.5 | % |  |
| Operating Income |  | $ | 136 |  |  | $ | 114 |  |  | 19 | % |  |
| Operating Margin |  | 19.6 | % |  | 19.0 |  |  |  |  |
| Special Items |  | $ | (4 | ) |  | $ | (5 | ) |  |  |  |
| Operating Income Before Special Items |  | $ | 140 |  |  | $ | 119 |  |  | 18 | % |  |
| Operating Margin Before Special Items |  | 20.2 | % |  | 19.8 | % |  |  |  |

[0000833444-14-000095:8k_2_02:33]
Revenue of $693 million increased 15.5% in the quarter, including a 3% benefit from acquisitions. Organic revenue grew 12%, with strong growth across Life Safety, Security, and Fire Protection products.  Organic growth in the quarter included a 5 percentage point benefit from increased shipments of Scott Safety Air-Pak X3s that had been building in backlog in advance of a late March regulatory approval.

[0000833444-14-000095:8k_2_02:34]
Operating income for the quarter was $136 million and the operating margin was 19.6%. Special items of $4 million consisted primarily of restructuring charges. Before special items, operating income was $140 million and the operating margin increased 40 basis points to 20.2%. Operating leverage on increased revenue and productivity benefits were partially offset by the timing of incremental R&D investments as well as non-cash purchase accounting.  Together, these items impacted the operating margin by 150 basis points.

[0000833444-14-000095:8k_2_02:35]
OTHER ITEMS

[0000833444-14-000095:8k_2_02:36]
| • | Cash from operating activities was $152 million and free cash flow was $74 million, which included a cash outflow of $234 million, primarily related to a payment under our tax sharing agreements, as well as restructuring and separation activities. Adjusted free cash flow for the quarter was $308 million. |

[0000833444-14-000095:8k_2_02:37]
| • | Corporate expense was $58 million for the quarter both before special items and on a GAAP basis, as restructuring and repositioning charges were offset by the benefit of other special items. |

[0000833444-14-000095:8k_2_02:38]
| • | The tax rate before special items was 16.9% for the quarter. |

[0000833444-14-000095:8k_2_02:39]
| • | During the quarter and through July 22, 2014, the company repurchased 20 million shares for $876 million. The remaining share repurchase authorization is now $1.1 billion. |

[0000833444-14-000095:8k_2_02:40]
| • | During the fiscal third quarter, the company decided to sell certain businesses previously reported within its Rest of World Installation & Services operating segment. These businesses generated $41 million of revenue in fiscal 2013 with an operating loss of $11 million. The results of these businesses are reflected in discontinued operations for all periods presented. |

[0000833444-14-000095:8k_2_02:41]
| • | As previously disclosed on May 22, 2014, the company completed the sale of its South Korean security business, ADT Korea, in a cash transaction valued at $1.93 billion. The results of this business are reflected in discontinued operations for all periods presented. |

[0000833444-14-000095:8k_2_02:42]
| • | As previously disclosed on April 9, 2014, the company’s remaining stake in Atkore International, Tyco’s former electrical and metal products business, was redeemed by Atkore in a cash transaction for $250 million. |

[0000833444-14-000095:8k_2_02:43]
| • | During the quarter, the company completed the acquisition of a commercial and residential security business in Belgium and reached an agreement to purchase a residential security business in Brazil, for a total of approximately $45 million in cash. On an annualized basis these businesses are expected to generate revenue of approximately $35 million. |

[0000833444-14-000095:8k_2_02:44]
ABOUT TYCO

[0000833444-14-000095:8k_2_02:45]
Tyco (NYSE: TYC) is the world’s largest pure-play fire protection and security company. Tyco provides more than three million customers around the globe with the latest fire protection and security products and services. A company with $10+ billion in annual revenue, Tyco has over 57,000 employees in more than 1,000 locations across 50 countries serving various end markets, including commercial, institutional, governmental, retail, industrial, energy, residential and small business. For more information, visit www.tyco.com.

[0000833444-14-000095:8k_2_02:46]
CONFERENCE CALL AND WEBCAST

[0000833444-14-000095:8k_2_02:47]
Management will discuss the company’s third quarter results for 2014 during a conference call and webcast today beginning at 8:00 a.m. Eastern time (ET).  Today’s conference call for investors can be accessed in the following ways:

[0000833444-14-000095:8k_2_02:48]
| • | Live via webcast - through the Investor Relations section of Tyco’s website at http://investors.tyco.com, |

[0000833444-14-000095:8k_2_02:49]
| • | Live via telephone (for “listen-only” participants and those who would like to ask a question) - by dialing 800-857-9797 (in the United States) or 517-308-9262 (outside the United States), passcode “Tyco”, |

[0000833444-14-000095:8k_2_02:50]
| • | Replay via telephone - by dialing 866-456-9373 (in the United States) or 203-369-1274 (outside the United States), passcode 6779, from 10:00 a.m. (ET) on July 25, 2014, until 11:59 p.m. (ET) on August 1, 2014, and |

[0000833444-14-000095:8k_2_02:51]
| • | Replay via webcast - through the “Presentations & Webcasts” link on the Investor Relations section of Tyco’s website: http://investors.tyco.com. |

[0000833444-14-000095:8k_2_02:52]
NON-GAAP MEASURES

[0000833444-14-000095:8k_2_02:53]
Organic revenue, free cash flow (outflow) (FCF), and income from continuing operations, earnings per share (EPS) from continuing operations, operating income and segment operating income, in each case “before special items,” are non-GAAP measures and should not be considered replacements for GAAP results.

[0000833444-14-000095:8k_2_02:54]
Organic revenue is a useful measure used by the company to measure the underlying results and trends in the business. The difference between reported net revenue (the most comparable GAAP measure) and organic revenue (the non-GAAP measure) consists of the impact from foreign currency, acquisitions and divestitures, and other changes that either do not reflect the underlying results and trends of the Company’s businesses or are not completely under management’s control. There are limitations associated with organic revenue, such as the fact that, as presented herein, the metric may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using organic revenue in combination with the GAAP numbers. Organic revenue may be used as a component in the company’s incentive compensation plans.

[0000833444-14-000095:8k_2_02:55]
FCF is a useful measure of the company's cash that permits management and investors to gain insight into the number that management employs to measure cash that is free from any significant existing obligation and is available to service debt and make investments. The difference between Cash Flows from Operating Activities (the most comparable GAAP measure) and FCF (the non-GAAP measure) consists mainly of significant cash flows that the company believes are useful to identify. It, or a

[0000833444-14-000095:8k_2_02:56]
measure that is based on it, may be used as a component in the company's incentive compensation plans. The difference reflects the impact from:

[0000833444-14-000095:8k_2_02:57]
| • | net capital expenditures, |

[0000833444-14-000095:8k_2_02:58]
| • | dealer generated accounts and bulk accounts purchased, |

[0000833444-14-000095:8k_2_02:59]
| • | cash paid for purchase accounting and holdback liabilities, and |

[0000833444-14-000095:8k_2_02:60]
| • | voluntary pension contributions. |

[0000833444-14-000095:8k_2_02:61]
Capital expenditures and dealer generated and bulk accounts purchased are subtracted because they represent long-term investments that are required for normal business activities. Cash paid for purchase accounting and holdback liabilities is subtracted because these cash outflows are not available for general corporate uses. Voluntary pension contributions are added because this activity is driven by economic financing decisions rather than operating activity. In addition, the company presents adjusted free cash flow, which is free cash flow, adjusted to exclude the cash impact of the special items highlighted below. This number provides information to investors regarding the cash impact of certain items management believes are useful to identify, as described below.

[0000833444-14-000095:8k_2_02:62]
The limitation associated with using these cash flow metrics is that they adjust for cash items that are ultimately within management's and the Board of Directors' discretion to direct and therefore may imply that there is less or more cash that is available for the company's programs than the most comparable GAAP measure. Furthermore, these non-GAAP metrics may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using FCF in combination with the GAAP cash flow numbers.

[0000833444-14-000095:8k_2_02:63]
The company has presented its income and EPS from continuing operations, operating income and segment operating income before special items. Special items include charges and gains related to divestitures, acquisitions, restructurings, impairments, certain changes to accounting methodologies, legacy legal and tax charges and other income or charges that may mask the underlying operating results and/or business trends of the company or business segment, as applicable. The company utilizes these measures to assess overall operating performance and segment level core operating performance, as well as to provide insight to management in evaluating overall and segment operating plan execution and underlying market conditions. The Company also presents its effective tax rate as adjusted for special items for consistency, and presents corporate expense excluding special items. One or more of these measures may be used as components in the company's incentive compensation plans. These measures are useful for investors because they may permit more meaningful comparisons of the company's underlying operating results and business trends between periods. The difference between income and EPS from continuing operations before special items and income and EPS from continuing operations (the most comparable GAAP measures) consists of the impact of the special items noted above on the applicable GAAP measure. The limitation of these measures is that they exclude the impact (which may be material) of items that increase or decrease the company's reported GAAP metrics, and these non-GAAP metrics may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using the non-GAAP measures in combination with the most comparable GAAP measures in order to better understand the amounts, character and impact of any increase or decrease on reported results.

[0000833444-14-000095:8k_2_02:64]
The company provides general corporate services to its segments and those costs are reported in the "Corporate and Other" segment. This segment's operating income (loss) is presented as "Corporate Expense." Segment Operating Income represents Tyco’s operating income excluding the Corporate and Other segment, and reflects the results of Tyco’s three operating segments. Segment Operating Income before special items reflects GAAP operating income adjusted for the special items noted in the paragraph above.

[0000833444-14-000095:8k_2_02:65]
FORWARD-LOOKING STATEMENTS

[0000833444-14-000095:8k_2_02:66]
This press release contains a number of forward-looking statements. In many cases forward-looking statements are identified by words, and variations of words, such as "anticipate", "estimate", "believe", “commit”, "confident", "continue", "could", "intend", "may", "plan", "potential", "predict", "positioned", "should", "will", "expect", "objective", "projection", "forecast", "goal", "guidance", "outlook", "effort", "target", and other similar words. However, the absence of these words does not mean the statements are not forward-looking. Examples of forward-looking statements include, but are not limited to, revenue, operating income, earnings per share and other financial projections, statements regarding the health and growth prospects of the industries and end markets in which Tyco operates, the leadership, resources, potential, priorities, and opportunities for Tyco in the future, Tyco’s credit profile, capital allocation priorities and other capital market related activities, and statements regarding Tyco's acquisition, divestiture, restructuring and other productivity initiatives. The forward-looking statements in this press release are based on current expectations and assumptions that are subject to risks and uncertainties, many of which are outside of our control, and could cause results to materially differ from expectations. Such risks and uncertainties include, but

[0000833444-14-000095:8k_2_02:67]
# # #

[0000833444-14-000095:8k_2_02:68]
TYCO INTERNATIONAL LTD.

[0000833444-14-000095:8k_2_02:69]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0000833444-14-000095:8k_2_02:70]
(in millions, except per share data)

[0000833444-14-000095:8k_2_02:71]
(Unaudited)

[0000833444-14-000095:8k_2_02:72]
|  |  | Quarters Ended |  | Nine Months Ended |
|  |  | June 27, 2014 |  | June 28, 2013 |  | June 27, 2014 |  | June 28, 2013 |
| Revenue from product sales |  | $ | 1,621 |  |  | $ | 1,484 |  |  | $ | 4,553 |  |  | $ | 4,319 |  |
| Service revenue |  | 1,041 |  |  | 1,053 |  |  | 3,083 |  |  | 3,144 |  |
| Net revenue |  | 2,662 |  |  | 2,537 |  |  | 7,636 |  |  | 7,463 |  |
| Cost of product sales |  | 1,106 |  |  | 1,000 |  |  | 3,108 |  |  | 2,956 |  |
| Cost of services |  | 572 |  |  | 606 |  |  | 1,725 |  |  | 1,813 |  |
| Selling, general and administrative expenses |  | 671 |  |  | 712 |  |  | 1,878 |  |  | 2,129 |  |
| Separation costs |  | — |  |  | 4 |  |  | 1 |  |  | 9 |  |
| Restructuring and asset impairment charges, net |  | 17 |  |  | 53 |  |  | 27 |  |  | 82 |  |
| Operating income |  | 296 |  |  | 162 |  |  | 897 |  |  | 474 |  |
| Interest income |  | 4 |  |  | 6 |  |  | 10 |  |  | 13 |  |
| Interest expense |  | (24 | ) |  | (26 | ) |  | (73 | ) |  | (75 | ) |
| Other expense, net |  | — |  |  | (1 | ) |  | (2 | ) |  | (30 | ) |
| Income from continuing operations before income taxes |  | 276 |  |  | 141 |  |  | 832 |  |  | 382 |  |
| Income tax expense |  | (55 | ) |  | (23 | ) |  | (164 | ) |  | (56 | ) |
| Equity gain (loss) in earnings of unconsolidated subsidiaries |  | 215 |  |  | (6 | ) |  | 206 |  |  | (18 | ) |
| Income from continuing operations |  | 436 |  |  | 112 |  |  | 874 |  |  | 308 |  |
| Income from discontinued operations, net of income taxes |  | 1,016 |  |  | 23 |  |  | 1,057 |  |  | 62 |  |
| Net income |  | 1,452 |  |  | 135 |  |  | 1,931 |  |  | 370 |  |
| Less: noncontrolling interest in subsidiaries net (loss) income |  | 2 |  |  | — |  |  | 4 |  |  | — |  |
| Net income attributable to Tyco common shareholders |  | $ | 1,450 |  |  | $ | 135 |  |  | $ | 1,927 |  |  | $ | 370 |  |
| Amounts attributable to Tyco common shareholders: |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 434 |  |  | $ | 112 |  |  | $ | 870 |  |  | $ | 308 |  |
| Income from discontinued operations |  | 1,016 |  |  | 23 |  |  | 1,057 |  |  | 62 |  |
| Net income attributable to Tyco common shareholders |  | $ | 1,450 |  |  | $ | 135 |  |  | $ | 1,927 |  |  | $ | 370 |  |
| Basic earnings per share attributable to Tyco common shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.95 |  |  | $ | 0.24 |  |  | $ | 1.89 |  |  | $ | 0.66 |  |
| Income from discontinued operations |  | 2.22 |  |  | 0.05 |  |  | 2.29 |  |  | 0.14 |  |
| Net income attributable to Tyco common shareholders |  | $ | 3.17 |  |  | $ | 0.29 |  |  | $ | 4.18 |  |  | $ | 0.80 |  |
| Diluted earnings per share attributable to Tyco common shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.93 |  |  | $ | 0.24 |  |  | $ | 1.85 |  |  | $ | 0.65 |  |
| Income from discontinued operations |  | 2.18 |  |  | 0.04 |  |  | 2.26 |  |  | 0.13 |  |
| Net income attributable to Tyco common shareholders |  | $ | 3.11 |  |  | $ | 0.28 |  |  | $ | 4.11 |  |  | $ | 0.78 |  |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 458 |  |  | 463 |  |  | 461 |  |  | 465 |  |
| Diluted |  | 466 |  |  | 471 |  |  | 469 |  |  | 473 |  |

[0000833444-14-000095:8k_2_02:73]
Note: These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Current Report on Form 8-K filed on May 16, 2014 for the fiscal year ended September 27, 2013 and Quarterly Report on Form 10-Q for the quarter ended March 28, 2014.

[0000833444-14-000095:8k_2_02:74]
TYCO INTERNATIONAL LTD.

[0000833444-14-000095:8k_2_02:75]
RESULTS OF SEGMENTS

[0000833444-14-000095:8k_2_02:76]
(in millions)

[0000833444-14-000095:8k_2_02:77]
(Unaudited)

[0000833444-14-000095:8k_2_02:78]
|  |  | Quarters Ended |  |  |  | Nine Months Ended |  |  |
|  |  | June 27, 2014 |  |  |  | June 28, 2013 |  |  |  | June 27, 2014 |  |  |  | June 28, 2013 |  |  |
| Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| NA Installation & Services |  | $ | 968 |  |  |  |  |  | $ | 966 |  |  |  |  |  | $ | 2,864 |  |  |  |  |  | $ | 2,895 |  |  |  |  |
| ROW Installation & Services |  | 1,001 |  |  |  |  |  | 971 |  |  |  |  |  | 2,909 |  |  |  |  |  | 2,856 |  |  |  |  |
| Global Products |  | 693 |  |  |  |  |  | 600 |  |  |  |  |  | 1,863 |  |  |  |  |  | 1,712 |  |  |  |  |
| Total Net Revenue |  | $ | 2,662 |  |  |  |  |  | $ | 2,537 |  |  |  |  |  | $ | 7,636 |  |  |  |  |  | $ | 7,463 |  |  |  |  |
| Operating Income and Margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| NA Installation & Services |  | $ | 117 |  |  | 12.1 | % |  | $ | 88 |  |  | 9.1 | % |  | $ | 333 |  |  | 11.6 | % |  | $ | 275 |  |  | 9.5 | % |
| ROW Installation & Services |  | 101 |  |  | 10.1 | % |  | 77 |  |  | 7.9 | % |  | 308 |  |  | 10.6 | % |  | 250 |  |  | 8.8 | % |
| Global Products |  | 136 |  |  | 19.6 | % |  | 114 |  |  | 19.0 | % |  | 329 |  |  | 17.7 | % |  | 188 |  |  | 11.0 | % |
| Corporate and Other |  | (58 | ) |  | N/M |  |  | (117 | ) |  | N/M |  |  | (73 | ) |  | N/M |  |  | (239 | ) |  | N/M |  |
| Operating Income and Margin |  | $ | 296 |  |  | 11.1 | % |  | $ | 162 |  |  | 6.4 | % |  | $ | 897 |  |  | 11.7 | % |  | $ | 474 |  |  | 6.4 | % |

[0000833444-14-000095:8k_2_02:79]
TYCO INTERNATIONAL LTD.

[0000833444-14-000095:8k_2_02:80]
CONSOLIDATED BALANCE SHEETS

[0000833444-14-000095:8k_2_02:81]
(in millions)

[0000833444-14-000095:8k_2_02:82]
(Unaudited)

[0000833444-14-000095:8k_2_02:83]
|  |  | June 27, 2014 |  | September 27, 2013 |
| Assets |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,912 |  |  | $ | 563 |  |
| Accounts receivable, net |  | 1,739 |  |  | 1,704 |  |
| Inventories |  | 650 |  |  | 645 |  |
| Prepaid expenses and other current assets |  | 1,141 |  |  | 839 |  |
| Deferred income taxes |  | 250 |  |  | 250 |  |
| Assets held for sale |  | 27 |  |  | 856 |  |
| Total Current Assets |  | 5,719 |  |  | 4,857 |  |
| Property, plant and equipment, net |  | 1,283 |  |  | 1,284 |  |
| Goodwill |  | 4,212 |  |  | 4,162 |  |
| Intangible assets, net |  | 765 |  |  | 791 |  |
| Other assets |  | 797 |  |  | 1,082 |  |
| Total Assets |  | $ | 12,776 |  |  | $ | 12,176 |  |
| Liabilities and Equity |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |
| Loans payable and current maturities of long-term debt |  | $ | 20 |  |  | $ | 20 |  |
| Accounts payable |  | 851 |  |  | 848 |  |
| Accrued and other current liabilities |  | 1,962 |  |  | 1,852 |  |
| Deferred revenue |  | 411 |  |  | 393 |  |
| Liabilities held for sale |  | 15 |  |  | 236 |  |
| Total Current Liabilities |  | 3,259 |  |  | 3,349 |  |
| Long-term debt |  | 1,443 |  |  | 1,443 |  |
| Deferred revenue |  | 344 |  |  | 370 |  |
| Other liabilities |  | 1,689 |  |  | 1,881 |  |
| Total Liabilities |  | 6,735 |  |  | 7,043 |  |
| Redeemable noncontrolling interest |  | 13 |  |  | 12 |  |
| Total Tyco shareholders' equity |  | 6,002 |  |  | 5,098 |  |
| Nonredeemable noncontrolling interest |  | 26 |  |  | 23 |  |
| Total Equity |  | 6,028 |  |  | 5,121 |  |
| Total Liabilities, Redeemable Noncontrolling Interest and Equity |  | $ | 12,776 |  |  | $ | 12,176 |  |

[0000833444-14-000095:8k_2_02:84]
Note: These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Current Report on Form 8-K filed on May 16, 2014 for the fiscal year ended September 27, 2013 and Quarterly Report on Form 10-Q for the quarter ended March 28, 2014.

[0000833444-14-000095:8k_2_02:85]
TYCO INTERNATIONAL LTD.

[0000833444-14-000095:8k_2_02:86]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000833444-14-000095:8k_2_02:87]
(in millions)

[0000833444-14-000095:8k_2_02:88]
(Unaudited)

[0000833444-14-000095:8k_2_02:89]
|  |  | For the Quarters Ended |  | For the Nine Months Ended |
|  |  | June 27, 2014 |  | June 28, 2013 |  | June 27, 2014 |  | June 28, 2013 |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Tyco common shareholders |  | $ | 1,450 |  |  | 135 |  |  | 1,927 |  |  | 370 |  |
| Noncontrolling interest in subsidiaries net income |  | 2 |  |  | — |  |  | 4 |  |  | — |  |
| Income from discontinued operations, net of income taxes |  | (1,016 | ) |  | (23 | ) |  | (1,057 | ) |  | (62 | ) |
| Income from continuing operations |  | 436 |  |  | 112 |  |  | 874 |  |  | 308 |  |
| Adjustments to reconcile net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  | 89 |  |  | 95 |  |  | 270 |  |  | 284 |  |
| Non-cash compensation expense |  | 17 |  |  | 16 |  |  | 48 |  |  | 47 |  |
| Deferred income taxes |  | 29 |  |  | (7 | ) |  | 85 |  |  | (52 | ) |
| Provision for losses on accounts receivable and inventory |  | 8 |  |  | 16 |  |  | 31 |  |  | 52 |  |
| Legacy legal matters |  | — |  |  | — |  |  | (92 | ) |  | — |  |
| (Gain) loss on divestitures |  | — |  |  | 4 |  |  | (2 | ) |  | 10 |  |
| Loss (gain) on investments |  | (219 | ) |  | 6 |  |  | (214 | ) |  | 14 |  |
| Other non-cash items |  | 6 |  |  | 39 |  |  | 20 |  |  | 64 |  |
| Changes in assets and liabilities, net of the effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (78 | ) |  | (47 | ) |  | (39 | ) |  | (32 | ) |
| Contracts in progress |  | (44 | ) |  | (4 | ) |  | (49 | ) |  | (13 | ) |
| Inventories |  | 10 |  |  | (39 | ) |  | (13 | ) |  | (71 | ) |
| Prepaid expenses and other current assets |  | (6 | ) |  | 37 |  |  | (35 | ) |  | 73 |  |
| Accounts payable |  | 63 |  |  | 45 |  |  | 15 |  |  | (44 | ) |
| Accrued and other liabilities |  | (140 | ) |  | (26 | ) |  | (360 | ) |  | (231 | ) |
| Deferred revenue |  | (23 | ) |  | (6 | ) |  | (13 | ) |  | (1 | ) |
| Other |  | 4 |  |  | (33 | ) |  | (6 | ) |  | (48 | ) |
| Net cash provided by operating activities |  | 152 |  |  | 208 |  |  | 520 |  |  | 360 |  |
| Net cash provided by discontinued operating activities |  | 25 |  |  | 60 |  |  | 100 |  |  | 117 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures |  | (75 | ) |  | (65 | ) |  | (210 | ) |  | (205 | ) |
| Proceeds from disposal of assets |  | 1 |  |  | — |  |  | 7 |  |  | 4 |  |
| Acquisition of businesses, net of cash acquired |  | (9 | ) |  | (37 | ) |  | (63 | ) |  | (75 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases |  | (4 | ) |  | (4 | ) |  | (20 | ) |  | (14 | ) |
| Sales and maturities of investments |  | 142 |  |  | 64 |  |  | 283 |  |  | 103 |  |
| Purchases of investments |  | (292 | ) |  | (63 | ) |  | (332 | ) |  | (182 | ) |
| Sale of equity investment |  | 250 |  |  | — |  |  | 250 |  |  | — |  |
| Other |  | (4 | ) |  | 12 |  |  | 2 |  |  | 6 |  |
| Net cash provided by (used in) investing activities |  | 9 |  |  | (93 | ) |  | (83 | ) |  | (363 | ) |
| Net cash provided by (used in) discontinued investing activities |  | 1,846 |  |  | (28 | ) |  | 1,789 |  |  | (82 | ) |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short-term debt |  | 115 |  |  | 280 |  |  | 830 |  |  | 380 |  |
| Repayment of short-term debt |  | (116 | ) |  | (290 | ) |  | (831 | ) |  | (391 | ) |
| Proceeds from exercise of share options |  | 17 |  |  | 31 |  |  | 79 |  |  | 125 |  |
| Dividends paid |  | (83 | ) |  | (74 | ) |  | (231 | ) |  | (214 | ) |
| Repurchase of common shares by treasury |  | (556 | ) |  | (100 | ) |  | (806 | ) |  | (300 | ) |
| Transfer from discontinued operations |  | 1,871 |  |  | 94 |  |  | 1,889 |  |  | 65 |  |
| Other |  | — |  |  | (18 | ) |  | (10 | ) |  | (35 | ) |
| Net cash provided by (used in) financing activities |  | 1,248 |  |  | (77 | ) |  | 920 |  |  | (370 | ) |
| Net cash used in discontinued financing activities |  | (1,871 | ) |  | (94 | ) |  | (1,889 | ) |  | (65 | ) |
| Effect of currency translation on cash |  | 8 |  |  | (13 | ) |  | (8 | ) |  | (16 | ) |
| Net increase (decrease) in cash and cash equivalents |  | 1,417 |  |  | (37 | ) |  | 1,349 |  |  | (419 | ) |
| Less: net decrease in cash and cash equivalents related to discontinued operations |  | — |  |  | (62 | ) |  | — |  |  | (30 | ) |
| Cash and cash equivalents at beginning of period |  | 495 |  |  | 430 |  |  | 563 |  |  | 844 |  |
| Cash and cash equivalents at end of period |  | $ | 1,912 |  |  | $ | 455 |  |  | $ | 1,912 |  |  | $ | 455 |  |

[0000833444-14-000095:8k_2_02:90]
| Reconciliation to "Free Cash Flow": |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 152 |  |  | $ | 208 |  |  | $ | 520 |  |  | $ | 360 |  |
| Capital expenditures, net |  | (74 | ) |  | (65 | ) |  | (203 | ) |  | (201 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases |  | (4 | ) |  | (4 | ) |  | (20 | ) |  | (14 | ) |
| Purchase accounting and holdback liabilities |  | — |  |  | (1 | ) |  | — |  |  | (7 | ) |
| Free Cash Flow |  | $ | 74 |  |  | $ | 138 |  |  | $ | 297 |  |  | $ | 138 |  |
| Reconciliation to "Adjusted Free Cash Flow": |  |  |  |  |  |  |  |  |
| CIT settlement |  | $ | — |  |  | $ | — |  |  | $ | (17 | ) |  | $ | — |  |
| IRS litigation costs |  | — |  |  | — |  |  | 1 |  |  | — |  |
| Separation costs |  | 27 |  |  | 20 |  |  | 71 |  |  | 168 |  |
| Restructuring and repositioning costs |  | 23 |  |  | 20 |  |  | 79 |  |  | 61 |  |
| Environmental remediation payments |  | 6 |  |  | 11 |  |  | 60 |  |  | 24 |  |
| Legal settlements |  | 6 |  |  | 13 |  |  | 6 |  |  | 46 |  |
| Net asbestos payments (recoveries) |  | 6 |  |  | 26 |  |  | 13 |  |  | (24 | ) |
| Cash payment from Covidien/TE Connectivity |  | 147 |  |  | 16 |  |  | 149 |  |  | 11 |  |
| Cash payment from ADT Resi/Pentair |  | 19 |  |  | — |  |  | 30 |  |  | — |  |
| Special Items |  | $ | 234 |  |  | $ | 106 |  |  | $ | 392 |  |  | $ | 286 |  |
| Adjusted Free Cash Flow |  | $ | 308 |  |  | $ | 244 |  |  | $ | 689 |  |  | $ | 424 |  |

[0000833444-14-000095:8k_2_02:91]
NOTE: Free cash flow is a non-GAAP measure.  See description of non-GAAP measures contained in this release.

[0000833444-14-000095:8k_2_02:92]
TYCO INTERNATIONAL LTD.

[0000833444-14-000095:8k_2_02:93]
ORGANIC GROWTH RECONCILIATION - REVENUE

[0000833444-14-000095:8k_2_02:94]
(in millions)

[0000833444-14-000095:8k_2_02:95]
|  |  |  |  | Quarter Ended June 27, 2014 |  |  |  |  |
|  |  |  |  | Base Year |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Net Revenue for the Quarter Ended June 28, 2013 |  | Adjustments |  | Adjusted Fiscal 2013 BaseRevenue |  |  |  |  |  |  |  |  |  |  |  |  |  | Net Revenue for the Quarter Ended June 27, 2014 |
|  |  |  | Divestitures / Other |  |  | Foreign Currency |  | Acquisitions |  | Organic Revenue(1) |  |
| NA Installation & Services |  | $ | 966 |  |  | $ | (6 | ) |  | (0.6 | )% |  | $ | 960 |  |  | $ | (7 | ) |  | (0.7 | )% |  | $ | 5 |  |  | 0.5 | % |  | $ | 10 |  |  | 1.0 | % |  | $ | 968 |  |  | 0.2 | % |
| ROW Installation & Services |  | 971 |  |  | (20 | ) |  | (2.1 | )% |  | 951 |  |  | — |  |  | — | % |  | 27 |  |  | 2.8 | % |  | 23 |  |  | 2.4 | % |  | 1,001 |  |  | 3.1 | % |
| Global Products |  | 600 |  |  | — |  |  | — | % |  | 600 |  |  | 1 |  |  | 0.2 | % |  | 19 |  |  | 3.2 | % |  | 73 |  |  | 12.2 | % |  | 693 |  |  | 15.5 | % |
| Total Net Revenue |  | $ | 2,537 |  |  | $ | (26 | ) |  | (1.0 | )% |  | $ | 2,511 |  |  | $ | (6 | ) |  | (0.2 | )% |  | $ | 51 |  |  | 2.0 | % |  | $ | 106 |  |  | 4.2 | % |  | $ | 2,662 |  |  | 4.9 | % |

[0000833444-14-000095:8k_2_02:96]
|  | (1) Organic revenue growth percentage based on adjusted fiscal 2013 base revenue. |

[0000833444-14-000095:8k_2_02:97]
|  |  |  |  | Nine Months Ended June 27, 2014 |  |  |  |  |
|  |  |  |  | Base Year |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Net Revenue for the Nine Months Ended June 28, 2013 |  | Adjustments |  | Adjusted Fiscal 2013 BaseRevenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Net Revenue for the Nine Months Ended June 27, 2014 |
|  |  |  | Divestitures / Other (2) |  |  | Foreign Currency |  | Acquisitions |  |  | Organic Revenue(1) |  |
| NA Installation & Services |  | $ | 2,895 |  |  | $ | (42 | ) |  | (1.5 | )% |  | $ | 2,853 |  |  | $ | (24 | ) |  | (0.8 | )% |  | $ | 14 |  |  | 0.5 | % |  |  | $ | 21 |  |  | 0.7 | % |  | $ | 2,864 |  |  | (1.1 | )% |
| ROW Installation & Services |  | 2,856 |  |  | (47 | ) |  | (1.6 | )% |  | 2,809 |  |  | (52 | ) |  | (1.8 | )% |  | 99 |  |  | 3.5 | % |  |  | 53 |  |  | 1.9 | % |  | 2,909 |  |  | 1.9 | % |
| Global Products |  | 1,712 |  |  | 2 |  |  | 0.1 | % |  | 1,714 |  |  | (6 | ) |  | (0.4 | )% |  | 56 |  |  | 3.3 | % |  |  | 99 |  |  | 5.8 | % |  | 1,863 |  |  | 8.8 | % |
| Total Net Revenue |  | $ | 7,463 |  |  | $ | (87 | ) |  | (1.2 | )% |  | $ | 7,376 |  |  | $ | (82 | ) |  | (1.1 | )% |  | $ | 169 |  |  | 2.3 | % |  |  | $ | 173 |  |  | 2.3 | % |  | $ | 7,636 |  |  | 2.3 | % |

[0000833444-14-000095:8k_2_02:98]
|  | (1) Organic revenue growth percentage based on adjusted fiscal 2013 base revenue. |
|  | (2)Amounts include the transfer of a business from NA Installation & Services to Global Products. |

[0000833444-14-000095:8k_2_02:99]
Earnings Per Share Summary

[0000833444-14-000095:8k_2_02:100]
(Unaudited)

[0000833444-14-000095:8k_2_02:101]
|  | Quarter Ended |  | Quarter Ended |  | Year Ended |
|  | Dec. 27, 2013 |  | March 28, 2014 |  | June 27, 2014 |  | Dec. 28, 2012 |  | March 29, 2013 |  | June 28, 2013 |  | Sept. 27, 2013 |  | Sept. 27, 2013 |
| Diluted EPS from Continuing Operations Attributable to Tyco Shareholders (GAAP) | $ | 0.52 |  |  | $ | 0.40 |  |  | $ | 0.93 |  |  | $ | 0.30 |  |  | $ | 0.11 |  |  | $ | 0.24 |  |  | $ | 0.29 |  |  | $ | 0.94 |  |
| expense / (benefit) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and repositioning activities | 0.01 |  |  | 0.02 |  |  | 0.05 |  |  | 0.01 |  |  | 0.04 |  |  | 0.10 |  |  | 0.06 |  |  | 0.21 |  |
| Separation costs included in SG&A | 0.02 |  |  | 0.02 |  |  | 0.02 |  |  | 0.01 |  |  | 0.04 |  |  | 0.04 |  |  | 0.02 |  |  | 0.10 |  |
| (Gains) / losses on divestitures, net included in SG&A | — |  |  | — |  |  | — |  |  | — |  |  | 0.02 |  |  | — |  |  | 0.02 |  |  | 0.04 |  |
| Acquisition / integration costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.01 |  |
| Asbestos | — |  |  | — |  |  | (0.01 | ) |  | — |  |  | — |  |  | 0.03 |  |  | — |  |  | 0.03 |  |
| Environmental remediation | — |  |  | — |  |  | — |  |  | 0.01 |  |  | 0.12 |  |  | — |  |  | — |  |  | 0.13 |  |
| Tyco share of Atkore impairment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.04 |  |  | 0.03 |  |
| Legacy legal items | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.04 |  |  | — |  |  | 0.04 |  |
| Loss on sale of investment | 0.01 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| CIT settlement | (0.03 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Settlement with former management | (0.11 | ) |  | — |  |  | (0.01 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Separation costs | — |  |  | — |  |  | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |  | 0.02 |  |
| Tax items | — |  |  | 0.01 |  |  | 0.02 |  |  | 0.01 |  |  | — |  |  | — |  |  | 0.04 |  |  | 0.04 |  |
| 2012 Tax Sharing Agreement | — |  |  | 0.01 |  |  | — |  |  | 0.02 |  |  | 0.04 |  |  | — |  |  | — |  |  | 0.07 |  |
| Gain on sale of Atkore divestiture | — |  |  | — |  |  | (0.46 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total Before Special Items | $ | 0.42 |  |  | $ | 0.46 |  |  | $ | 0.54 |  |  | $ | 0.37 |  |  | $ | 0.37 |  |  | $ | 0.46 |  |  | $ | 0.47 |  |  | $ | 1.66 |  |

[0000833444-14-000095:8k_2_02:102]
Note: Prior periods have been recast to present certain businesses as a discontinued operation.

[0000833444-14-000095:8k_2_02:103]
Tyco International Ltd.

[0000833444-14-000095:8k_2_02:104]
For the Quarter Ended December 28, 2013

[0000833444-14-000095:8k_2_02:105]
(in millions, except per share data)

[0000833444-14-000095:8k_2_02:106]
(Unaudited)

[0000833444-14-000095:8k_2_02:107]
expense / (benefit)

[0000833444-14-000095:8k_2_02:108]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation & Services |  |  |  | ROW Installation & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $957 |  |  |  |  |  | $971 |  |  |  |  |  | $565 |  |  |  |  |  | $2,493 |  |  |  |  |  | $— |  |  |  |  |  | $2,493 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation& Services |  | Margin |  | ROW Installation& Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other (Expense), net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $117 |  |  | 12.2 | % |  |  | $95 |  |  | 9.8 | % |  |  | $86 |  |  | 15.2 | % |  |  | $298 |  |  | 12.0 | % |  |  | $46 |  |  | N/M |  |  | $344 |  |  | 13.8 | % |  |  | ($21 | ) |  |  | ($1 | ) |  |  | ($70 | ) |  |  | ($4 | ) |  |  | ($2 | ) |  |  | $246 |  |  | $0.52 |  |
| Restructuring and repositioning activities |  | (2 | ) |  |  |  |  |  |  |  | 4 |  |  |  |  | 2 |  |  |  |  | 7 |  |  |  |  | 9 |  |  |  |  |  |  |  |  | (2 | ) |  |  |  |  |  | 7 |  | 0.01 |  |
| Separation costs included in SG&A |  | 14 |  |  |  |  |  |  |  |  |  |  |  |  | 14 |  |  |  |  | 1 |  |  |  |  | 15 |  |  |  |  |  |  |  |  | (6 | ) |  |  |  |  |  | 9 |  | 0.02 |  |
| (Gains) / losses on divestitures, net included in SG&A |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (3 | ) |  |  |  | (3 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  | (3 | ) | — |  |
| Acquisition / integration costs |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Settlement with former management |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (92 | ) |  |  |  | (92 | ) |  |  |  |  |  |  |  | 36 |  |  |  |  |  |  | (56 | ) | (0.11 | ) |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | — |  | — |  |
| IRS litigation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| CIT settlement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (16 | ) |  |  |  | (16 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  | (16 | ) | (0.03 | ) |
| Loss on sale of investment |  |  |  |  |  | 7 |  |  |  |  |  |  |  |  | 7 |  |  |  |  |  |  |  |  | 7 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 7 |  | 0.01 |  |
| 2012 Tax Sharing Agreement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  |  |  | 2 |  | — |  |
| Total Before Special Items |  |  | $129 |  |  | 13.5 | % |  |  | $103 |  |  | 10.6 | % |  |  | $90 |  |  | 15.9 | % |  |  | $322 |  |  | 12.9 | % |  |  | ($55 | ) |  | N/M |  |  | $267 |  |  | 10.7 | % |  |  | ($21 | ) |  |  | $1 |  |  |  | ($43 | ) |  |  | ($4 | ) |  |  | ($2 | ) |  |  | $198 |  |  | $0.42 |  |
| Note: This period has been recast to present certain businesses as a discontinued operation. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 471 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 471 |  |

[0000833444-14-000095:8k_2_02:109]
Tyco International Ltd.

[0000833444-14-000095:8k_2_02:110]
For the Quarter Ended March 28, 2014

[0000833444-14-000095:8k_2_02:111]
(in millions, except per share data)

[0000833444-14-000095:8k_2_02:112]
(Unaudited)

[0000833444-14-000095:8k_2_02:113]
expense / (benefit)

[0000833444-14-000095:8k_2_02:114]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation & Services |  |  |  | ROW Installation & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $939 |  |  |  |  |  | $937 |  |  |  |  |  | $605 |  |  |  |  |  | $2,481 |  |  |  |  |  | $— |  |  |  |  |  | $2,481 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation& Services |  | Margin |  | ROW Installation& Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other (Expense), net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $99 |  |  | 10.5 | % |  |  | $112 |  |  | 12.0 | % |  |  | $107 |  |  | 17.7 | % |  |  | $318 |  |  | 12.8 | % |  |  | ($61 | ) |  | N/M |  |  | $257 |  |  | 10.4 | % |  |  | ($22 | ) |  |  | ($1 | ) |  |  | ($39 | ) |  |  | ($5 | ) |  | — |  |  |  | $190 |  |  | $0.40 |  |
| Restructuring and repositioning activities |  | 3 |  |  |  |  | 4 |  |  |  |  | 2 |  |  |  |  | 9 |  |  |  |  | 7 |  |  |  |  | 16 |  |  |  |  |  |  |  |  | (6 | ) |  |  |  |  |  | 10 |  | 0.02 |  |
| Separation costs included in SG&A |  | 15 |  |  |  |  |  |  |  |  |  |  |  |  | 15 |  |  |  |  |  |  |  |  | 15 |  |  |  |  |  |  |  |  | (5 | ) |  |  |  |  |  | 10 |  | 0.02 |  |
| (Gains) / losses on divestitures, net included in SG&A |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Acquisition / integration costs |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| IRS litigation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (1 | ) |  |  |  | (1 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  | (1 | ) | — |  |
| Separation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Tax items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 4 |  |  |  |  |  |  | 4 |  | 0.01 |  |
| 2012 Tax Sharing Agreement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 3 |  |  |  |  |  |  |  |  | 3 |  | 0.01 |  |
| Total Before Special Items |  |  | $117 |  |  | 12.5 | % |  |  | $118 |  |  | 12.6 | % |  |  | $109 |  |  | 18.0 | % |  |  | $344 |  |  | 13.9 | % |  |  | ($54 | ) |  | N/M |  |  | $290 |  |  | 11.7 | % |  |  | ($22 | ) |  |  | $2 |  |  |  | ($46 | ) |  |  | ($5 | ) |  | — |  |  |  | $219 |  |  | $0.46 |  |
| Note: This period has been recast to present certain businesses as a discontinued operation. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 469 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 469 |  |

[0000833444-14-000095:8k_2_02:115]
Tyco International Ltd.

[0000833444-14-000095:8k_2_02:116]
For the Quarter Ended June 27, 2014

[0000833444-14-000095:8k_2_02:117]
(in millions, except per share data)

[0000833444-14-000095:8k_2_02:118]
(Unaudited)

[0000833444-14-000095:8k_2_02:119]
expense / (benefit)

[0000833444-14-000095:8k_2_02:120]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation & Services |  |  |  | ROW Installation & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $968 |  |  |  |  |  | $1,001 |  |  |  |  |  | $693 |  |  |  |  |  | $2,662 |  |  |  |  |  | $— |  |  |  |  |  | $2,662 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation& Services |  | Margin |  | ROW Installation& Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other (Expense), net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $117 |  |  | 12.1 | % |  |  | $101 |  |  | 10.1 | % |  |  | $136 |  |  | 19.6 | % |  |  | $354 |  |  | 13.3 | % |  |  | ($58 | ) |  | N/M |  |  | $296 |  |  | 11.1 | % |  |  | ($20 | ) |  | — |  |  |  | ($55 | ) |  |  | $215 |  |  |  | ($2 | ) |  |  | $434 |  |  | $0.93 |  |
| Restructuring and repositioning activities |  | 6 |  |  |  |  | 11 |  |  |  |  | 3 |  |  |  |  | 20 |  |  |  |  | 10 |  |  |  |  | 30 |  |  |  |  |  |  |  |  | (9 | ) |  |  |  |  |  | 21 |  | 0.05 |  |
| Separation costs included in SG&A |  | 11 |  |  |  |  |  |  |  |  |  |  |  |  | 11 |  |  |  |  |  |  |  |  | 11 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | 10 |  | 0.02 |  |
| Acquisition / integration costs |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Settlement with former management |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (4 | ) |  |  |  | (4 | ) |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  | (3 | ) | (0.01 | ) |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (6 | ) |  |  |  | (6 | ) |  |  |  |  |  |  |  | 3 |  |  |  |  |  |  | (3 | ) | (0.01 | ) |
| Tax items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 9 |  |  |  |  |  |  | 9 |  | 0.02 |  |
| Gain on sale of Atkore divestiture |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (216 | ) |  |  |  | (216 | ) | (0.46 | ) |
| Total Before Special Items |  |  | $134 |  |  | 13.8 | % |  |  | $112 |  |  | 11.2 | % |  |  | $140 |  |  | 20.2 | % |  |  | $386 |  |  | 14.5 | % |  |  | ($58 | ) |  | N/M |  |  | $328 |  |  | 12.3 | % |  |  | ($20 | ) |  |  | $— |  |  |  | ($52 | ) |  |  | ($1 | ) |  |  | ($2 | ) |  |  | $253 |  |  | $0.54 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 466 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 466 |  |

[0000833444-14-000095:8k_2_02:121]
Tyco International Ltd.

[0000833444-14-000095:8k_2_02:122]
For the Quarter Ended December 28, 2012

[0000833444-14-000095:8k_2_02:123]
(in millions, except per share data)

[0000833444-14-000095:8k_2_02:124]
(Unaudited)

[0000833444-14-000095:8k_2_02:125]
expense / (benefit)

[0000833444-14-000095:8k_2_02:126]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation & Services |  |  |  | ROW Installation & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $976 |  |  |  |  |  | $953 |  |  |  |  |  | $534 |  |  |  |  |  | $2,463 |  |  |  |  |  | $— |  |  |  |  |  | $2,463 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation& Services |  | Margin |  | ROW Installation& Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other (Expense), net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $108 |  |  | 11.1 | % |  |  | $94 |  |  | 9.9 | % |  |  | $74 |  |  | 13.9 | % |  |  | $276 |  |  | 11.2 | % |  |  | ($61 | ) |  | N/M |  |  | $215 |  |  | 8.7 | % |  |  | ($20 | ) |  |  | ($9 | ) |  |  | ($35 | ) |  |  | ($6 | ) |  |  | ($2 | ) |  |  | $143 |  |  | $0.30 |  |
| Restructuring, net |  |  |  |  |  | 4 |  |  |  |  | 2 |  |  |  |  | 6 |  |  |  |  | 1 |  |  |  |  | 7 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | 6 |  | 0.01 |  |
| Separation costs included in SG&A |  | 12 |  |  |  |  |  |  |  |  |  |  |  |  | 12 |  |  |  |  | 1 |  |  |  |  | 13 |  |  |  |  |  |  |  |  | (5 | ) |  |  |  |  |  | 8 |  | 0.01 |  |
| (Gains) / losses on divestitures, net included in SG&A |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (3 | ) |  |  |  | (3 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  | (3 | ) | — |  |
| Acquisition / integration costs |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (1 | ) |  |  |  | (1 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  | (1 | ) | — |  |
| Environmental remediation |  |  |  |  |  |  |  |  |  | 6 |  |  |  |  | 6 |  |  |  |  |  |  |  |  | 6 |  |  |  |  |  |  |  |  | (2 | ) |  |  |  |  |  | 4 |  | 0.01 |  |
| Separation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 5 |  |  |  |  | 5 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 5 |  | 0.01 |  |
| Tax items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 4 |  |  |  |  |  |  | 4 |  | 0.01 |  |
| 2012 Tax Sharing Agreement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 10 |  |  |  |  |  |  |  |  | 10 |  | 0.02 |  |
| Total Before Special Items |  |  | $120 |  |  | 12.3 | % |  |  | $98 |  |  | 10.3 | % |  |  | $83 |  |  | 15.5 | % |  |  | $301 |  |  | 12.2 | % |  |  | ($58 | ) |  | N/M |  |  | $243 |  |  | 9.9 | % |  |  | ($20 | ) |  |  | $1 |  |  |  | ($39 | ) |  |  | ($6 | ) |  |  | ($2 | ) |  |  | $177 |  |  | $0.37 |  |
| Note: This period has been recast to present certain businesses as a discontinued operation. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 473 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 473 |  |

[0000833444-14-000095:8k_2_02:127]
Tyco International Ltd.

[0000833444-14-000095:8k_2_02:128]
For the Quarter Ended March 29, 2013

[0000833444-14-000095:8k_2_02:129]
(in millions, except per share data)

[0000833444-14-000095:8k_2_02:130]
(Unaudited)

[0000833444-14-000095:8k_2_02:131]
expense / (benefit)

[0000833444-14-000095:8k_2_02:132]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation & Services |  |  |  | ROW Installation & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $953 |  |  |  |  |  | $932 |  |  |  |  |  | $578 |  |  |  |  |  | $2,463 |  |  |  |  |  | $— |  |  |  |  |  | $2,463 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation& Services |  | Margin |  | ROW Installation& Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other (Expense), net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $79 |  |  | 8.3 | % |  |  | $79 |  |  | 8.5 | % |  | — |  |  | — |  |  |  | $158 |  |  | 6.4 | % |  |  | ($61 | ) |  | N/M |  |  | $97 |  |  | 3.9 | % |  |  | ($22 | ) |  |  | ($20 | ) |  |  | $2 |  |  |  | ($6 | ) |  |  | $2 |  |  |  | $53 |  |  | $0.11 |  |
| Restructuring and repositioning activities |  | 6 |  |  |  |  | 13 |  |  |  |  | 3 |  |  |  |  | 22 |  |  |  |  | 4 |  |  |  |  | 26 |  |  |  |  |  |  |  |  | (7 | ) |  |  |  |  |  | 19 |  | 0.04 |  |
| Separation costs included in SG&A |  | 16 |  |  |  |  |  |  |  |  |  |  |  |  | 16 |  |  |  |  |  |  |  |  | 16 |  |  |  |  |  |  |  |  | 3 |  |  |  |  |  |  | 19 |  | 0.04 |  |
| (Gains) / losses on divestitures, net included in SG&A |  | 3 |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 4 |  |  |  |  | 5 |  |  |  |  | 9 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 9 |  | 0.02 |  |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (1 | ) |  |  |  | (1 | ) |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  | — |  | — |  |
| Environmental remediation |  |  |  |  |  |  |  |  |  | 94 |  |  |  |  | 94 |  |  |  |  |  |  |  |  | 94 |  |  |  |  |  |  |  |  | (37 | ) |  |  |  |  |  | 57 |  | 0.12 |  |
| 2012 Tax Sharing Agreement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 20 |  |  |  |  |  |  |  |  | 20 |  | 0.04 |  |
| Total Before Special Items |  |  | $104 |  |  | 10.9 | % |  |  | $93 |  |  | 10.0 | % |  |  | $97 |  |  | 16.8 | % |  |  | $294 |  |  | 11.9 | % |  |  | ($53 | ) |  | N/M |  |  | $241 |  |  | 9.8 | % |  |  | ($22 | ) |  | — |  |  |  | ($38 | ) |  |  | ($6 | ) |  |  | $2 |  |  |  | $177 |  |  | $0.37 |  |
| Note: This period has been recast to present certain businesses as a discontinued operation. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 474 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 474 |  |

[0000833444-14-000095:8k_2_02:133]
Tyco International Ltd.

[0000833444-14-000095:8k_2_02:134]
For the Quarter Ended June 28, 2013

[0000833444-14-000095:8k_2_02:135]
(in millions, except per share data)

[0000833444-14-000095:8k_2_02:136]
(Unaudited)

[0000833444-14-000095:8k_2_02:137]
expense / (benefit)

[0000833444-14-000095:8k_2_02:138]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation & Services |  |  |  | ROW Installation & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $966 |  |  |  |  |  | $971 |  |  |  |  |  | $600 |  |  |  |  |  | $2,537 |  |  |  |  |  | $— |  |  |  |  |  | $2,537 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation& Services |  | Margin |  | ROW Installation& Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other (Expense), net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $88 |  |  | 9.1 | % |  |  | $77 |  |  | 7.9 | % |  |  | $114 |  |  | 19.0 | % |  |  | $279 |  |  | 11.0 | % |  |  | ($117 | ) |  | N/M |  |  | $162 |  |  | 6.4 | % |  |  | ($20 | ) |  |  | ($1 | ) |  |  | ($23 | ) |  |  | ($6 | ) |  | — |  |  |  | $112 |  |  | $0.24 |  |
| Restructuring and repositioning activities |  | 16 |  |  |  |  | 34 |  |  |  |  | 5 |  |  |  |  | 55 |  |  |  |  | 3 |  |  |  |  | 58 |  |  |  |  |  |  |  |  | (11 | ) |  |  |  |  |  | 47 |  | 0.10 |  |
| Separation costs included in SG&A |  | 12 |  |  |  |  |  |  |  |  |  |  |  |  | 12 |  |  |  |  | 6 |  |  |  |  | 18 |  |  |  |  |  |  |  |  | (3 | ) |  |  |  |  |  | 15 |  | 0.04 |  |
| (Gains) / losses on divestitures, net included in SG&A |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 3 |  |  |  |  | 4 |  |  |  |  |  |  |  |  | (2 | ) |  |  |  |  |  | 2 |  | — |  |
| Acquisition/integration costs |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 12 |  |  |  |  | 12 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | 11 |  | 0.03 |  |
| Legacy legal items |  |  |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  | — |  | 27 |  |  |  |  | 27 |  |  |  |  |  |  |  |  | (9 | ) |  |  |  |  |  | 18 |  | 0.04 |  |
| Separation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 4 |  |  |  |  | 4 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 4 |  | 0.01 |  |
| Tax items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  | 2 |  | — |  |
| 2012 Tax Sharing Agreement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Total Before Special Items |  |  | $117 |  |  | 12.1 | % |  |  | $112 |  |  | 11.5 | % |  |  | $119 |  |  | 19.8 | % |  |  | $348 |  |  | 13.7 | % |  |  | ($62 | ) |  | N/M |  |  | $286 |  |  | 11.3 | % |  |  | ($20 | ) |  | — |  |  |  | ($47 | ) |  |  | ($6 | ) |  | — |  |  |  | $213 |  |  | $0.46 |  |
| Note: This period has been recast to present certain businesses as a discontinued operation. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 471 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 471 |  |

[0000833444-14-000095:8k_2_02:139]
Tyco International Ltd.

[0000833444-14-000095:8k_2_02:140]
For the Quarter Ended September 27, 2013

[0000833444-14-000095:8k_2_02:141]
(in millions, except per share data)

[0000833444-14-000095:8k_2_02:142]
(Unaudited)

[0000833444-14-000095:8k_2_02:143]
expense / (benefit)

[0000833444-14-000095:8k_2_02:144]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation & Services |  |  |  | ROW Installation & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $996 |  |  |  |  |  | $987 |  |  |  |  |  | $627 |  |  |  |  |  | $2,610 |  |  |  |  |  | $— |  |  |  |  |  | $2,610 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation& Services |  | Margin |  | ROW Installation& Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other (Expense), net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $113 |  |  | 11.3 | % |  |  | $83 |  |  | 8.4 | % |  |  | $119 |  |  | 19.0 | % |  |  | $315 |  |  | 12.1 | % |  |  | ($80 | ) |  | N/M |  |  | $235 |  |  | 9.0 | % |  |  | ($22 | ) |  |  | $1 |  |  |  | ($52 | ) |  |  | ($30 | ) |  |  | $3 |  |  |  | $135 |  |  | $0.29 |  |
| Restructuring and repositioning activities |  | 14 |  |  |  |  | 12 |  |  |  |  | 2 |  |  |  |  | 28 |  |  |  |  | 11 |  |  |  |  | 39 |  |  |  |  |  |  |  |  | (14 | ) |  |  |  |  |  | 25 |  | 0.06 |  |
| Separation costs included in SG&A |  | 9 |  |  |  |  |  |  |  |  |  |  |  |  | 9 |  |  |  |  | 5 |  |  |  |  | 14 |  |  |  |  |  |  |  |  | (8 | ) |  |  |  |  |  | 6 |  | 0.02 |  |
| (Gains) / losses on divestitures, net included in SG&A |  | (3 | ) |  |  |  | 13 |  |  |  |  |  |  |  |  | 10 |  |  |  |  |  |  |  |  | 10 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 10 |  | 0.02 |  |
| Acquisition / integration costs |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  | 2 |  |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  | — |  |
| Asset impairment charges |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  |  |  |  | 2 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  | — |  |
| Tyco share of Atkore impairment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 21 |  |  |  |  | 21 |  | 0.04 |  |
| Separation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (1 | ) |  |  |  | (1 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  | (1 | ) | — |  |
| Tax items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 16 |  |  |  |  |  |  | 16 |  | 0.04 |  |
| 2012 Tax Sharing Agreement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Total Before Special Items |  |  | $133 |  |  | 13.4 | % |  |  | $110 |  |  | 11.1 | % |  |  | $122 |  |  | 19.5 | % |  |  | $365 |  |  | 14.0 | % |  |  | ($63 | ) |  | N/M |  |  | $302 |  |  | 11.6 | % |  |  | ($22 | ) |  |  | $2 |  |  |  | ($58 | ) |  |  | ($9 | ) |  |  | $3 |  |  |  | $218 |  |  | $0.47 |  |
| Note: This period has been recast to present certain businesses as a discontinued operation. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 471 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 471 |  |

[0000833444-14-000095:8k_2_02:145]
Tyco International Ltd.

[0000833444-14-000095:8k_2_02:146]
For the Year Ended September 27, 2013

[0000833444-14-000095:8k_2_02:147]
(in millions, except per share data)

[0000833444-14-000095:8k_2_02:148]
(Unaudited)

[0000833444-14-000095:8k_2_02:149]
expense / (benefit)

[0000833444-14-000095:8k_2_02:150]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation & Services |  |  |  | ROW Installation & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $3,891 |  |  |  |  |  | $3,843 |  |  |  |  |  | $2,339 |  |  |  |  |  | $10,073 |  |  |  |  |  | $— |  |  |  |  |  | $10,073 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation& Services |  | Margin |  | ROW Installation& Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other (Expense), net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $388 |  |  | 10.0 | % |  |  | $333 |  |  | 8.7 | % |  |  | $307 |  |  | 13.1 | % |  |  | $1,028 |  |  | 10.2 | % |  |  | ($319 | ) |  | N/M |  |  | $709 |  |  | 7.0 | % |  |  | ($84 | ) |  |  | ($29 | ) |  |  | ($108 | ) |  |  | ($48 | ) |  |  | $3 |  |  |  | $443 |  |  | $0.94 |  |
| Restructuring and repositioning activities |  | 36 |  |  |  |  | 63 |  |  |  |  | 12 |  |  |  |  | 111 |  |  |  |  | 19 |  |  |  |  | 130 |  |  |  |  |  |  |  |  | (33 | ) |  |  |  |  |  | 97 |  | 0.21 |  |
| Separation costs included in SG&A |  | 49 |  |  |  |  |  |  |  |  |  |  |  |  | 49 |  |  |  |  | 12 |  |  |  |  | 61 |  |  |  |  |  |  |  |  | (13 | ) |  |  |  |  |  | 48 |  | 0.10 |  |
| (Gains) / losses on divestitures, net included in SG&A |  | 1 |  |  |  |  | 14 |  |  |  |  |  |  |  |  | 15 |  |  |  |  | 5 |  |  |  |  | 20 |  |  |  |  |  |  |  |  | (2 | ) |  |  |  |  |  | 18 |  | 0.04 |  |
| Acquisition / integration costs |  |  |  |  |  | 2 |  |  |  |  | 2 |  |  |  |  | 4 |  |  |  |  |  |  |  |  | 4 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 4 |  | 0.01 |  |
| Asset impairment charges |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 12 |  |  |  |  | 12 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 12 |  | 0.03 |  |
| Environmental remediation |  |  |  |  |  |  |  |  |  | 100 |  |  |  |  | 100 |  |  |  |  |  |  |  |  | 100 |  |  |  |  |  |  |  |  | (39 | ) |  |  |  |  |  | 61 |  | 0.13 |  |
| Tyco share of Atkore impairment |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 21 |  |  |  |  | 21 |  | 0.03 |  |
| Legacy legal items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27 |  |  |  |  | 27 |  |  |  |  |  |  |  |  | (9 | ) |  |  |  |  |  | 18 |  | 0.04 |  |
| Separation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 8 |  |  |  |  | 8 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 8 |  | 0.02 |  |
| Tax items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 22 |  |  |  |  |  |  | 22 |  | 0.04 |  |
| 2012 Tax Sharing Agreement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 32 |  |  |  |  |  |  |  |  | 32 |  | 0.07 |  |
| Total Before Special Items |  |  | $474 |  |  | 12.2 | % |  |  | $413 |  |  | 10.7 | % |  |  | $421 |  |  | 18.0 | % |  |  | $1,308 |  |  | 13.0 | % |  |  | ($236 | ) |  | N/M |  |  | $1,072 |  |  | 10.6 | % |  |  | ($84 | ) |  |  | $3 |  |  |  | ($182 | ) |  |  | ($27 | ) |  |  | $3 |  |  |  | $785 |  |  | $1.66 |  |
| Note: This period has been recast to present certain businesses as a discontinued operation. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 472 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 472 |  |
