# JCI notes — 0000833444-15-000032


## tyc:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesAndNewAccountingPronouncementsTextBlock

[0000833444-15-000032:notes:1]
Basis of Presentation and Summary of Significant Accounting Policies

[0000833444-15-000032:notes:2]
Basis of Presentation—The Consolidated Financial Statements included herein are unaudited, but in the opinion of management, such financial statements include all adjustments, consisting of normal recurring adjustments, necessary to summarize fairly the Company's financial position, results of operations and cash flows for the interim period. The unaudited Consolidated Financial Statements include the consolidated results of Tyco International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Tyco and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Tyco"). The unaudited Consolidated Financial Statements have been prepared in United States dollars ("USD") and in accordance with the instructions to Form 10-Q under the Securities and Exchange Act of 1934, as amended. The results reported in these unaudited Consolidated Financial Statements should not be taken as indicative of results that may be expected for the entire year.  These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K for the fiscal year ended September 26, 2014 (the "2014 Form 10-K").

[0000833444-15-000032:notes:3]
References to 2015 and 2014 are to Tyco's fiscal quarters ending March 27, 2015 and March 28, 2014, respectively, unless otherwise indicated.  The Company has a 52 or 53-week fiscal year that ends on the last Friday in September.  Fiscal years 2015 and 2014 are both 52-week years.

[0000833444-15-000032:notes:4]
Change of Jurisdiction - On November 17, 2014, Tyco International Ltd., an entity organized under the laws of Switzerland ("Tyco Switzerland"), completed its change of jurisdiction of incorporation from Switzerland to Ireland by merging with its subsidiary, Tyco International plc ("Tyco Ireland"), a public limited company incorporated under the laws of Ireland (the "Merger"). As a result of the Merger, Tyco Ireland is the successor issuer to Tyco Switzerland, has succeeded to the attributes of Tyco Switzerland as the registrant under SEC regulations, and has assumed all pre-Merger obligations of Tyco Switzerland.

[0000833444-15-000032:notes:5]
Reclassifications - Certain prior period amounts have been reclassified to conform with current period presentation.  The Company has reclassified several businesses in the Rest of World ("ROW") Installation & Services segment to (Loss) income from discontinued operations in the Consolidated Statements of Operations and the assets and liabilities as held for sale within the Consolidated Balance Sheets for all periods presented as they satisfied the criteria to be presented as discontinued operations.  In addition, the Company has reclassified the assets and liabilities of several businesses in the ROW Installation & Services segment as held for sale during the quarter ended March 27, 2015.  One of these businesses satisfied the criteria to be presented as discontinued operations and has been reflected as such in the Consolidated Statements of Operations for all periods presented.  See Note 3.

[0000833444-15-000032:notes:6]
Recently Adopted Accounting Pronouncements - In March 2013, the Financial Accounting Standards Board ("FASB") issued authoritative guidance to resolve diversity in practice on the accounting for the cumulative translation adjustment ("CTA") when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets within a foreign entity. The guidance requires that the parent release any CTA into net income when the parent ceases to have a controlling financial interest in a subsidiary or group of assets within a foreign entity which results in a substantially complete liquidation of the foreign entity; when the sale of an investment in a foreign entity results in the loss of a controlling financial interest; or where an acquirer obtains control of an acquiree in which it had an equity interest immediately before the acquisition date. The guidance does not change the requirement to release a pro rata portion of the CTA into net income upon a partial sale of an equity method investment that is a foreign entity. The guidance became effective for Tyco in the first quarter of fiscal 2015. The adoption of this guidance, which was applied on a prospective basis, did not have a material impact on the Company's financial position, results of operations or cash flows.

[0000833444-15-000032:notes:7]
In July 2013, the FASB issued authoritative guidance for the presentation of an unrecognized tax benefit when a net operating loss (“NOL”) carryforward, a similar tax loss, or a tax credit carryforward exists. The guidance requires an entity to present an unrecognized tax benefit, or a portion of an unrecognized tax benefit, in the financial statements as a reduction to a deferred tax asset for a NOL carryforward, a similar tax loss, or a tax credit carryforward. If the NOL carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the jurisdiction or the tax law of the jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit will be presented in the financial statements as a liability and will not be combined with deferred tax assets.  This guidance does not require any additional recurring disclosures and became effective for Tyco during the first fiscal quarter of fiscal 2015.  The adoption of this guidance, which was applied on a prospective basis, did not have a material impact on the Company's financial position, results of operations or cash flows.

[0000833444-15-000032:notes:8]
Recently Issued Accounting Pronouncements - In April 2014, the FASB issued authoritative guidance to change the criteria for reporting discontinued operations.  Under the new guidance, only disposals representing a strategic shift in a company's operations and financial results should be reported as discontinued operations, with expanded disclosures. In addition, disclosure of the pre-tax income attributable to a disposal of a significant part of an organization that does not qualify as a discontinued operation is required.  This guidance is effective for Tyco in the first quarter of fiscal 2016, with early adoption permitted only for disposals that have not been reported in financial statements previously issued or available for issuance.  The Company is currently assessing the impact, if any, the guidance will have upon adoption.

[0000833444-15-000032:notes:9]
In May 2014, the FASB issued authoritative guidance for revenue from contracts with customers, which provides a single comprehensive revenue recognition model to apply in determining how and when to recognize revenue. The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. When applying the new revenue model to contracts with customers the guidance requires five steps to be applied, which include: 1) identify the contract(s) with a customer, 2) identify the performance obligations in the contract, 3) determine the transaction price, 4) allocate the transaction price to the performance obligations in the contract and 5) recognize revenue when (or as) the entity satisfies a performance obligation. The guidance also requires both quantitative and qualitative disclosures, which are more comprehensive than existing revenue standards. The disclosures are intended to enable financial statement users to understand the nature, timing and uncertainty of revenue and the related cash flow. This guidance will be effective for Tyco in the first quarter of fiscal 2018, with early adoption not permitted. The Company is currently assessing the impact the guidance will have upon adoption.


## tyc:ScheduleOfIntangibleAssetsTextBlock

[0000833444-15-000032:notes:10]
The following table sets forth the gross carrying amount and accumulated amortization of the Company's intangible assets as of March 27, 2015 and September 26, 2014 ($ in millions):

[0000833444-15-000032:notes:11]
|  | As of |
|  | March 27, 2015 |  | September 26, 2014 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Amortizable: |  |  |  |  |  |  |  |
| Contracts and related customer relationships | $ | 1,377 |  |  | $ | 1,040 |  |  | $ | 1,400 |  |  | $ | 1,113 |  |
| Intellectual property | 768 |  |  | 497 |  |  | 608 |  |  | 487 |  |
| Other | 10 |  |  | 7 |  |  | 29 |  |  | 15 |  |
| Total | $ | 2,155 |  |  | $ | 1,544 |  |  | $ | 2,037 |  |  | $ | 1,615 |  |
| Non-Amortizable: |  |  |  |  |  |  |  |
| Intellectual property | $ | 212 |  |  |  |  |  | $ | 214 |  |  |  |
| Franchise rights | 76 |  |  |  |  |  | 76 |  |  |  |
| Other | 9 |  |  |  |  | — |  |  |  |
| Total | $ | 297 |  |  |  |  |  | $ | 290 |  |  |  |


## tyc:ScheduleOfNetReceivablesAndLiabilitiesRecordedUnderTaxSharingAgreementsTableTextBlock

[0000833444-15-000032:notes:12]
he receivables and liabilities related to the 2012 and 2007 Tax Sharing Agreements as of March 27, 2015 and September 26, 2014, are as follows ($ in millions):

[0000833444-15-000032:notes:13]
|  | 2012 Tax Sharing Agreement |  | 2007 Tax Sharing Agreement |
|  | As of |  | As of |
|  | March 27, 2015 |  | September 26, 2014 |  | March 27, 2015 |  | September 26, 2014 |
| Tax sharing agreement related receivables: |  |  |  |  |  |  |  |
| Prepaid expenses and other current assets | $ | — |  |  | $ | — |  |  | $ | 3 |  |  | $ | 3 |  |
| Other assets | — |  |  | — |  |  | 24 |  |  | 23 |  |
|  | — |  |  | — |  |  | 27 |  |  | 26 |  |
| Tax sharing agreement related liabilities: |  |  |  |  |  |  |  |
| Accrued and other current liabilities | — |  |  | — |  |  | (21 | ) |  | (21 | ) |
| Other liabilities | (46 | ) |  | (46 | ) |  | (194 | ) |  | (194 | ) |
|  | (46 | ) |  | (46 | ) |  | (215 | ) |  | (215 | ) |
| Net liability | $ | (46 | ) |  | $ | (46 | ) |  | $ | (188 | ) |  | $ | (189 | ) |


## tyc:ScheduleOfRestructuringReserveByBalanceSheetLocationTextBlock

[0000833444-15-000032:notes:14]
As of March 27, 2015 and September 26, 2014, restructuring reserves related to all actions were included in the Company's Consolidated Balance Sheets as follows ($ in millions):

[0000833444-15-000032:notes:15]
|  | As of |
|  | March 27, 2015 |  | September 26, 2014 |
| Accrued and other current liabilities | $ | 90 |  |  | $ | 83 |  |
| Other liabilities | 15 |  |  | 16 |  |
| Total | $ | 105 |  |  | $ | 99 |  |


## tyc:ScheduleOfSegmentReportingInformationNetRevenueAndOperatingIncomeLossBySegmentTableTextBlock

[0000833444-15-000032:notes:16]
[same as prior period, unchanged from 0000833444-15-000013:notes:18]

[0000833444-15-000032:notes:17]
|  | For the Quarters Ended |  | For the Six Months Ended |
|  | March 27, 2015 |  | March 28, 2014 |  | March 27, 2015 |  | March 28, 2014 |
| Net revenue(1): |  |  |  |  |  |  |  |
| NA Installation & Services | $ | 944 |  |  | $ | 939 |  |  | $ | 1,895 |  |  | $ | 1,896 |  |
| ROW Installation & Services | 847 |  |  | 936 |  |  | 1,763 |  |  | 1,903 |  |
| Global Products | 639 |  |  | 605 |  |  | 1,250 |  |  | 1,170 |  |
|  | $ | 2,430 |  |  | $ | 2,480 |  |  | $ | 4,908 |  |  | $ | 4,969 |  |

[0000833444-15-000032:notes:18]
[same as prior period, unchanged from 0000833444-15-000013:notes:20]

[0000833444-15-000032:notes:19]
[same as prior period, unchanged from 0000833444-15-000013:notes:21]

[0000833444-15-000032:notes:20]
|  | For the Quarters Ended |  | For the Six Months Ended |
|  | March 27, 2015 |  | March 28, 2014 |  | March 27, 2015 |  | March 28, 2014 |
| Operating income (loss): |  |  |  |  |  |  |  |
| NA Installation & Services | $ | 119 |  |  | $ | 99 |  |  | $ | 224 |  |  | $ | 216 |  |
| ROW Installation & Services (1) | 60 |  |  | 114 |  |  | 130 |  |  | 208 |  |
| Global Products | 110 |  |  | 107 |  |  | 208 |  |  | 193 |  |
| Corporate and Other (2) | (68 | ) |  | (61 | ) |  | (142 | ) |  | (15 | ) |
|  | $ | 221 |  |  | $ | 259 |  |  | $ | 420 |  |  | $ | 602 |  |

[0000833444-15-000032:notes:21]
[same as prior period, unchanged from 0000833444-15-000013:notes:23]

[0000833444-15-000032:notes:22]
| (1) | Operating income for the quarter and six months ended March 28, 2014 includes $21 million of an insurance recovery related to the improper recording of revenue in China that was previously disclosed in the fourth quarter of fiscal 2012. |

[0000833444-15-000032:notes:23]
| (2) | Operating income for the six months ended March 28, 2014 includes $92 million of income related to the settlement of a legacy legal matter with former management and $16 million of income related to the CIT settlement. |


## tyc:SeparationTransactionDisclosureTextBlock

[0000833444-15-000032:notes:24]
[same as prior period, unchanged from 0000833444-15-000013:notes:25]

[0000833444-15-000032:notes:25]
[same as prior period, unchanged from 0000833444-15-000013:notes:26]

[0000833444-15-000032:notes:26]
In connection with activities taken to complete the 2012 Separation and to create the revised organizational structure of the Company, the Company incurred pre-tax charges ("Separation Charges") within continuing operations of nil and $16 million during the quarters ended March 27, 2015 and March 28, 2014, respectively, and $2 million and $31 million for the six months ended March 27, 2015 and March 28, 2014, respectively.  In addition, the Company incurred pre-tax charges within discontinued operations of nil and $1 million for both the quarters and six months ended March 27, 2015 and March 28, 2014, respectively.  The amounts presented within discontinued operations are costs directly related to the 2012 Separation that are not expected to provide a future benefit to the Company.  The Company received associated tax benefits of nil and $5 million during the quarters ended March 27, 2015 and March 28, 2014, respectively, and $1 million and $11 million for the six months ended March 27, 2015 and March 28, 2014, respectively. The Company does not expect to incur material separation charges relating to activities taken to complete the 2012 Separation in future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000833444-15-000032:notes:27]
[same as prior period, unchanged from 0000833444-15-000013:notes:28]

[0000833444-15-000032:notes:28]
During the quarter ended March 27, 2015, total consideration paid, net of $6 million of cash acquired and $5 million of holdback liability, for six acquisitions included in continuing operations was $373 million.  Current quarter activity is primarily related to the acquisition of Industrial Safety Technologies International ("IST"), a global leader in gas and flame detection with operations in Europe, the Middle East, China, and the U.S., for total consideration paid, net of $5 million of cash acquired, of $327 million.  The purchase price for IST was allocated to $70 million of assets, $134 million of goodwill, $143 million of intangible assets and the assumption of $15 million of liabilities.  IST is being integrated into the Global Products segment.  The remaining $46 million in purchase price relates to five acquisitions that will be integrated into the ROW Installation & Services and Global Products segments and working capital adjustments related to prior year acquisitions.

[0000833444-15-000032:notes:29]
During the six months ended March 27, 2015, total consideration paid, net of $26 million of cash acquired and $8 million of holdback liability, for 11 acquisitions included in continuing operations was $525 million.  This includes working capital adjustments described above.  In addition to the acquisition of IST within the Global Products segment, the Company made 10 acquisitions during the six months ended March 27, 2015.

[0000833444-15-000032:notes:30]
The determination of fair value for certain assets and liabilities relating to the acquisitions made during the quarter ended December 27, 2014 has been finalized, which did not result in a material adjustment.  The final determination of fair value for certain assets and liabilities relating to several of the acquisitions made during the quarter ended March 27, 2015 remains subject to change based on final valuations of the assets acquired and liabilities assumed.  The Company does not expect the finalization of these matters, which is expected to be completed within fiscal 2015, to have a material effect on the purchase price allocation.

[0000833444-15-000032:notes:31]
During the quarter ended March 28, 2014, the Company did not complete any acquisitions. During the six months ended March 28, 2014, total consideration paid, net of $1 million cash acquired, and $1 million of contingent consideration, for acquisitions included in continuing operations was $54 million, This was entirely related to the acquisition of Westfire, Inc. ("Westfire") on November 8, 2013.  Westfire, a fire protection services company with operations in the United States, Chile and Peru, provides critical special-hazard suppression and detection applications in mining, telecommunications and other vertical markets and has been integrated into the NA Installation & Services and ROW Installation & Services segments.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-15-000032:notes:32]
Commitments and Contingencies

[0000833444-15-000032:notes:33]
Legacy Matters Related to Former Management

[0000833444-15-000032:notes:34]
In recent years, the Company has settled several lawsuits involving disputes with former management. With respect to Dennis Kozlowski, the Company's former chief executive officer, in the first quarter of fiscal 2014, the parties signed an agreement resolving all outstanding disputes, with Mr. Kozlowski agreeing to release the Company from any claims to monetary amounts related to compensation, retention or other arrangements. As a result, in the first quarter of fiscal 2014, the Company reversed a non-cash net liability of approximately $92 million which was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations for the amounts allegedly due to him.  Pursuant to the settlement agreement, Tyco will be entitled to a portion of the proceeds, if any, from the future sale of certain assets owned by Mr. Kozlowski, the timing and amount of which is uncertain.

[0000833444-15-000032:notes:35]
With respect to Mark Swartz, the Company's former chief financial officer, in November 2014, the parties reached a definitive agreement to resolve all outstanding disputes, with Mr. Swartz agreeing to release the Company from any claims to monetary amounts related to compensation, retention or other arrangements alleged to have existed between him and the Company.  In the first quarter of fiscal 2015, the Company also received approximately $12 million in cash from Mr. Swartz, $5 million of which will be shared pursuant to the terms of a legacy class action lawsuit, resulting in a net recovery of $7 million for the Company, which was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations. The cash received has been classified as restricted.

[0000833444-15-000032:notes:36]
Environmental Matters

[0000833444-15-000032:notes:37]
Tyco is involved in various stages of investigation and cleanup related to environmental remediation matters at a number of sites. The ultimate cost of site cleanup is difficult to predict given the uncertainties regarding the extent of the required cleanup, the interpretation of applicable laws and regulations and alternative cleanup methods. As of March 27, 2015, Tyco concluded that it was probable that it would incur remedial costs in the range of approximately $29 million to $72 million. As of March 27, 2015, Tyco concluded that the best estimate within this range is approximately $33 million, of which $15 million is included in Accrued and other current liabilities and $18 million is included in Other liabilities in the Company's Consolidated Balance Sheet.

[0000833444-15-000032:notes:38]
The majority of the liabilities described above relate to ongoing remediation efforts at a facility in the Company's Global Products segment located in Marinette, Wisconsin, which the Company acquired in 1990 in connection with its acquisition of, among other things, the Ansul product line. Prior to Tyco's acquisition, Ansul manufactured arsenic-based agricultural herbicides at the Marinette facility, which resulted in significant arsenic contamination of soil and groundwater on the Marinette site and in parts of the adjoining Menominee River. Ansul has been engaged in ongoing remediation efforts at the Marinette site since 1990, and in February 2009 entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the Marinette site. Under this agreement, Ansul's principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. As of March 27, 2015, the Company concluded that its remaining remediation and monitoring costs related to the Marinette facility were in the range of approximately $19 million to $46 million. The Company's best estimate within that range is approximately $22 million, of which $10 million is included in Accrued and other current liabilities and $12 million is included in Other liabilities in the Company's Consolidated Balance Sheet.  Although the Company has recorded its best estimate of the costs that it will incur to remediate and monitor the arsenic contamination at the Marinette facility, it is possible that technological, regulatory or enforcement developments, the results of environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows.

[0000833444-15-000032:notes:39]
Asbestos Matters

[0000833444-15-000032:notes:40]
The Company and certain of its subsidiaries, including Yarway Corporation (“Yarway”) and Grinnell LLC (“Grinnell”), along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. Over 90% of cases pending against affiliates of the Company have been filed against Yarway or Grinnell, and have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components. Claims filed against Yarway derive from Yarway’s purported use of asbestos-containing gaskets and packing in the sale or distribution of steam valves and traps and from its alleged manufacture of asbestos-containing expansion joint packing. Yarway’s alleged manufacture, distribution and/or sale of asbestos-containing materials ceased by 1988, and Yarway ceased substantially all of its manufacturing, distribution and sales operations in 2003. Claims filed against Grinnell typically allege that it manufactured, sold or distributed valves, gaskets, piping and sprinkler systems containing asbestos.

[0000833444-15-000032:notes:41]
As of March 27, 2015, the Company has determined that there were approximately 5,900 claims pending against it, which includes approximately 3,200 claims pending against Yarway. This amount reflects the Company's current estimate of the number of viable claims made against it and includes adjustments for claims that are not actively being prosecuted, identify incorrect defendants, are duplicative of other actions or for which the Company is indemnified by third parties. Additionally, as a result of the Yarway bankruptcy filing described below, claims against Yarway have been stayed since April 2013.

[0000833444-15-000032:notes:42]
As of March 27, 2015, the Company's estimated net liability, including Yarway, recorded within the Company's Consolidated Balance Sheet is $319 million.  The net liability is comprised of a liability for pending and future claims and related defense costs of $846 million, of which $349 million is recorded in Accrued and other current liabilities, and $497 million is recorded in Other liabilities.  The Company also maintains separate cash, investment and other assets of $527 million, of which $43 million is recorded in Prepaid expenses and other current assets, and $484 million is recorded in Other assets.  Assets include $22 million of cash and $282 million of investments, which have all been designated as restricted.  The Company believes that the asbestos related liabilities and insurance related assets as of March 27, 2015 are appropriate.  As of September 26, 2014, the Company's estimated net liability, including Yarway, of $608 million was recorded within the Company's Consolidated Balance Sheet as a liability for pending and future claims and related defense costs of $853 million, and separately as an asset for insurance recoveries of $245 million.

[0000833444-15-000032:notes:43]
Yarway

[0000833444-15-000032:notes:44]
As previously disclosed, on April 22, 2013 Yarway filed a voluntary petition for relief under Chapter 11 of the U.S. Bankruptcy Code (“Chapter 11”) in the United States Bankruptcy Court for the District of Delaware (“Bankruptcy Court”). As a result of this filing, the continuation or commencement of asbestos-related litigation against Yarway has been enjoined by the automatic stay imposed by the U.S. Bankruptcy Code. Yarway's goal has been to negotiate, obtain approval of, and consummate a plan of reorganization that establishes a trust to fairly and equitably value and pay current and future Yarway asbestos claims, and that, in exchange for funding of the trust by the Company and/or its subsidiaries, provides permanent injunctive relief protecting the Company, each of its current and former affiliates and various other parties (the “Company Protected Parties”) from any further asbestos claims based on products manufactured, sold, and/or distributed by Yarway. On October 9, 2014, the Company reached an agreement in principle with Yarway, the Official Committee of Asbestos Claimants (“ACC”) appointed in the Yarway Chapter 11 case as the representative of current Yarway asbestos claimants, and the Future Claimants Representative (“FCR”) appointed in the Yarway Chapter 11 case as the representative of future Yarway asbestos claimants, to fund a section 524(g) trust for the resolution and payment of current and future Yarway asbestos claims. The agreement in principle will be implemented through a Chapter 11 plan of reorganization for Yarway, and is intended to resolve the potential liability of the Company Protected Parties for pending and future derivative personal injury claims related to exposure to asbestos-containing products that were allegedly manufactured, distributed, and/or sold by Yarway (“Yarway Asbestos Claims”). Under the Chapter 11 plan, an asbestos settlement trust (the “Yarway Trust”) that conforms to the provisions of Section 524(g) of the U.S. Bankruptcy Code will be established and, on the effective date of the Chapter 11 plan, the Company and Yarway will contribute to the Yarway Trust a total of approximately $325 million in cash (“Settlement Consideration”), which includes approximately $100 million relating to the settlement of intercompany amounts allegedly due to Yarway. In exchange for the Settlement Consideration, each of the Company Protected Parties will receive the benefit of a release from Yarway and an injunction under section 524(g) of the Bankruptcy Code permanently enjoining the assertion of Yarway Asbestos Claims against those Parties.  On April 8, 2015, following the approval of the  Plan by the required number of Yarway's current asbestos claimants, the Bankruptcy Court issued an order confirming the Plan.  As a result, the Plan has been filed with the United States District Court for the District of Delaware ("District Court") and is awaiting affirmation by the District Court.  There have been no objections filed with respect to the Plan.  Upon the District Court's affirmation of the Plan, Yarway and the Plan proponents will schedule an effective date for the Plan, which is anticipated to occur during the Company's third fiscal quarter.

[0000833444-15-000032:notes:45]
On the effective date of the Plan, the Company and Yarway will pay the Settlement Consideration and Yarway Asbestos Claims against the Company Protected Parties will be permanently enjoined. Yarway is anticipated to become a wholly-owned subsidiary of the Yarway Trust and, accordingly, would no longer be owned by or be part of a consolidated group with the Company.  As a result of the agreement in principle to settle, the Company recorded a charge of $225 million in Selling, general and administrative expenses in the Consolidated Statement of Operations during the fourth fiscal quarter of 2014.

[0000833444-15-000032:notes:46]
As a result of filing the voluntary bankruptcy petition during the third quarter of fiscal 2013, the Company recorded an expected loss upon deconsolidation of $10 million related to the Yarway Chapter 11 filing, which continues to represent the Company’s best estimate of its loss.

[0000833444-15-000032:notes:47]
Other Claims

[0000833444-15-000032:notes:48]
The Company continuously assesses the sufficiency of its estimated liability for pending and future asbestos claims and defense costs. On a quarterly basis, the Company evaluates actual experience regarding asbestos claims filed, settled and dismissed, amounts paid in settlements, and the recoverability of its insurance assets. If and when data from actual experience demonstrate an unfavorable discernible trend, the Company performs a valuation of its asbestos related liabilities and corresponding insurance assets including a comprehensive review of the underlying assumptions. In addition, the Company evaluates its ability to reasonably estimate claim activity beyond its current look-forward period in order to assess whether such period is appropriate. In addition to claims and litigation experience, the Company considers additional qualitative and quantitative factors such as changes in legislation, the legal environment, the Company’s strategy in managing claims and obtaining insurance, including its defense strategy, and health related trends in the overall population of individuals potentially exposed to asbestos. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance assets is warranted.

[0000833444-15-000032:notes:49]
During the fourth quarter of fiscal 2014, the Company concluded that an unfavorable trend had developed in actual claim filing activity compared to projected claim filing activity established during the Company’s most recent valuation. Accordingly, the Company, with the assistance of independent actuarial service providers, performed a revised valuation of its asbestos-related liabilities and corresponding insurance assets. As part of the revised valuation, the Company assessed whether a change in its look-forward period was appropriate, taking into consideration its more extensive history and experience with asbestos-related claims and litigation (including its experience with Yarway), and determined that it was possible to make a reasonable estimate of the actuarially determined ultimate risk of loss for pending and unasserted potential future asbestos-related claims through 2056. In connection with the revised valuation, the Company considered a recent settlement with one of its insurers calling for the establishment of a qualified settlement fund, and the results of a separate independent actuarial consulting firm report conducted in the fourth quarter to assist the Company in obtaining insurance to fully fund all estimable asbestos-related claims (excluding Yarway claims) incurred through 2056.

[0000833444-15-000032:notes:50]
The independent actuarial service firm calculated a total estimated liability for asbestos-related claims of the Company, which reflects the Company’s best estimate of its ultimate risk of loss to resolve all pending and future claims (excluding Yarway claims) through 2056, which is the Company’s reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates.

[0000833444-15-000032:notes:51]
In conjunction with determining the total estimated liability, the Company retained an independent third party to assist it in valuing its insurance assets responsive to asbestos-related claims, excluding Yarway claims. These insurance assets represent amounts due to the Company for previously settled claims and the probable reimbursements relating to its total liability for pending and unasserted potential future asbestos claims and defense costs. In calculating this amount, the Company used the estimated asbestos liability for pending and projected future claims and defense costs described above, and it also considered the amount of insurance available, the solvency risk with respect to the Company's insurance carriers, resolution of insurance coverage issues, gaps in coverage, allocation methodologies, and the terms of existing settlement agreements with insurance carriers.

[0000833444-15-000032:notes:52]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-15-000032:notes:53]
In connection with the foregoing, during the third quarter of fiscal 2014, the Company resolved disputes with certain of its historical insurers and agreed that certain insurance proceeds would be used to establish and fund a qualified settlement fund (“QSF”), within the meaning of the Internal Revenue Code, which would be used for the resolution primarily of Grinnell asbestos liabilities of the Company. It is intended that the QSF will receive future insurance payments and proceeds from third party insurers and, in addition, will fund and manage liabilities for certain historical operations of the Company. On January 9, 2015, the Company completed a series of restructuring transactions related to the establishment and funding of a dedicated structure pursuant to which a subsidiary of the Company acquired the assets of Grinnell and transferred cash and other assets totaling approximately $278 million (not including $22 million received by the QSF during the quarter ended December 26, 2014 from historic third-party insurers in settlement of coverage disputes) to the structure. As part of the restructuring, subsidiaries in the structure assumed certain liabilities related to historic Grinnell, Scott and Figgie operations, including all historical Grinnell asbestos liabilities, and such subsidiaries purchased additional insurance by, through or from a wholly-owned subsidiary in the structure in order to supplement and enhance existing insurance assets. The structure and the QSF fully fund all historic Grinnell asbestos liabilities and provide for the efficient and streamlined management of claims related thereto.

[0000833444-15-000032:notes:54]
The Company consolidates the qualified settlement fund and related entities that were established for the purpose of managing and resolving the liabilities described above. Although the entities in the dedicated structure serve the specific purpose of managing certain liabilities, each entity in the structure is a wholly-owned indirect subsidiary of the Company, and therefore is required to be consolidated under U.S. generally accepted accounting principles.

[0000833444-15-000032:notes:55]
Tax Matters

[0000833444-15-000032:notes:56]
Tyco and its subsidiaries' income tax returns are examined periodically by various tax authorities. In connection with these examinations, tax authorities, including the IRS, have raised issues and proposed tax adjustments, in particular with respect to years preceding the 2007 Separation. The issues and proposed adjustments related to such years are generally subject to the sharing provisions of a tax sharing agreement entered in 2007 with Medtronic and TE Connectivity (the "2007 Tax Sharing Agreement") under which Tyco, Medtronic and TE Connectivity share 27%, 42% and 31%, respectively, of shared income tax liabilities that arise from adjustments made by tax authorities to Tyco's, Medtronic's and TE Connectivity's U.S. and certain non-U.S. income tax returns. The costs and expenses associated with the management of these shared tax liabilities are generally shared equally among the parties. Tyco has previously disclosed that in connection with U.S. federal tax audits, the IRS has raised a number of issues and proposed tax adjustments for periods beginning with the 1997 tax year. Although Tyco has been able to resolve substantially all of the issues and adjustments proposed by the IRS for tax years through 2007, it has not been able to resolve matters related to the treatment of certain intercompany debt transactions during the period. As a result, on June 20, 2013, Tyco received Notices of Deficiency from the IRS asserting that several of Tyco's former U.S. subsidiaries owe additional taxes of $883.3 million plus penalties of $154 million based on audits of the 1997 through 2000 tax years of Tyco and its subsidiaries as they existed at that time. In addition, Tyco received Final Partnership Administrative Adjustments for certain U.S. partnerships owned by former U.S. subsidiaries with respect to which an additional tax deficiency of approximately $30 million has been asserted. These amounts exclude interest and do not reflect the impact on subsequent periods if the IRS position described below is ultimately proved correct.

[0000833444-15-000032:notes:57]
The IRS asserted in the Notices of Deficiency that substantially all of Tyco's intercompany debt originated during the 1997 - 2000 period should not be treated as debt for U.S. federal income tax purposes, and has disallowed interest and related deductions recognized on U.S. income tax returns totaling approximately $2.9 billion. Tyco strongly disagrees with the IRS position and has filed petitions with the U.S. Tax Court contesting the IRS proposed adjustments. A trial date has been set for February 2016. Tyco believes that it has meritorious defenses for its tax filings, that the IRS positions with regard to these matters are inconsistent with the applicable tax laws and existing Treasury regulations, and that the previously reported taxes for the years in question are appropriate.

[0000833444-15-000032:notes:58]
No payments with respect to these matters would be required until the dispute is definitively resolved, which, based on the experience of other companies, could take several years. Tyco believes that its income tax reserves and the liabilities recorded in the Consolidated Balance Sheet for the tax sharing agreements continue to be appropriate. However, the ultimate resolution of these matters, and the impact of that resolution, are uncertain and could have a material impact on Tyco's financial condition, results of operations and cash flows. In particular, if the IRS is successful in asserting its claim, it would have an adverse impact on interest deductions related to the same intercompany debt in subsequent time periods, totaling approximately $6.6 billion, which is expected to be disallowed by the IRS.

[0000833444-15-000032:notes:59]
See Note 6 for additional information related to income tax matters.

[0000833444-15-000032:notes:60]
Other Matters

[0000833444-15-000032:notes:61]
As previously disclosed, SimplexGrinnell LP (“SG”), a subsidiary of the Company in the North America Installation & Services segment, has been named as a defendant in lawsuits in several jurisdictions seeking damages for SG’s alleged failure to pay prevailing wages and for other pay-related claims.  Through the first quarter of fiscal 2015, the Company had recorded a total of approximately $17 million in charges related to these lawsuits, which was recorded in the Cost of services within the Consolidated Statement of Operations.  During the quarter ended March 27, 2015, the Company agreed in principle to settle all outstanding lawsuits for a total of approximately $14 million.

[0000833444-15-000032:notes:62]
During the first quarter of fiscal 2015, the Company received and responded to inquiries from the U.S. Department of the Navy regarding the formulation of certain aqueous film forming foam ("AFFF") concentrates. The Company investigated such matters and ceased selling certain AFFF and other foam products pending the outcome of its investigation.  During the course of the investigation, three AFFF products were removed from the Navy’s Qualified Products List ("QPL"); one AFFF product remains on the QPL. The Company has shared the results of its investigation with appropriate governmental authorities and is also communicating with the government regarding the re-qualification of these products.  The government has confirmed that it considers the Company to be “presently responsible,” and that no suspension or debarment is warranted.  At this time, we cannot predict the outcome of these inquiries and whether this will result in further action by the Navy or other governmental authorities, but it is possible that the Company could be required to pay material fines, consent to injunctions on future conduct, or suffer other criminal or civil penalties or adverse impacts, including being subject to lawsuits brought by private litigants, each of which may have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000833444-15-000032:notes:63]
In addition to the foregoing, the Company is subject to claims and suits, including from time to time, contractual disputes and product and general liability claims, incidental to present and former operations, acquisitions and dispositions. With respect to many of these claims, the Company either self-insures or maintains insurance through third-parties, with varying deductibles. While the ultimate outcome of these matters cannot be predicted with certainty, the Company believes that the resolution of any such proceedings, whether the underlying claims are covered by insurance or not, will not have a material adverse effect on the Company's financial condition, results of operations or cash flows beyond amounts recorded for such matters.


## us-gaap:CondensedFinancialStatementsTextBlock

[0000833444-15-000032:notes:64]
Guarantor Financial Statements

[0000833444-15-000032:notes:65]
TIFSA, a 100% owned subsidiary of the Company, has public debt securities outstanding which are fully and unconditionally guaranteed by Tyco and by Tyco Fire & Security Finance SCA ("TIFSCA"), a wholly owned subsidiary of Tyco and parent company of TIFSA.  The following tables present condensed consolidating financial information for Tyco, TIFSCA, TIFSA and all other subsidiaries. Condensed financial information for Tyco, TIFSCA and TIFSA on a stand-alone basis is presented using the equity method of accounting for subsidiaries.

[0000833444-15-000032:notes:66]
[same as prior period, unchanged from 0000833444-15-000013:notes:64]

[0000833444-15-000032:notes:67]
For the Quarter Ended March 27, 2015

[0000833444-15-000032:notes:68]
[same as prior period, unchanged from 0000833444-15-000013:notes:66]

[0000833444-15-000032:notes:69]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,430 |  |  | $ | — |  |  | $ | 2,430 |  |
| Cost of product sales | — |  |  | — |  |  | — |  |  | 999 |  |  | — |  |  | 999 |  |
| Cost of services | — |  |  | — |  |  | — |  |  | 550 |  |  | — |  |  | 550 |  |
| Selling, general and administrative expenses | 2 |  |  | — |  |  | — |  |  | 646 |  |  | — |  |  | 648 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Operating (loss) income | (2 | ) |  | — |  |  | — |  |  | 223 |  |  | — |  |  | 221 |  |
| Interest income | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Interest expense | — |  |  | — |  |  | (24 | ) |  | (1 | ) |  | — |  |  | (25 | ) |
| Other (expense) income, net | — |  |  | — |  |  | (2 | ) |  | 1 |  |  | — |  |  | (1 | ) |
| Equity in net income of subsidiaries | 152 |  |  | 158 |  |  | 160 |  |  | — |  |  | (470 | ) |  | — |  |
| Intercompany interest and fees | 17 |  |  | — |  |  | 24 |  |  | (41 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 167 |  |  | 158 |  |  | 158 |  |  | 186 |  |  | (470 | ) |  | 199 |  |
| Income tax expense | — |  |  | — |  |  | — |  |  | (18 | ) |  | — |  |  | (18 | ) |
| Income from continuing operations | 167 |  |  | 158 |  |  | 158 |  |  | 168 |  |  | (470 | ) |  | 181 |  |
| Loss from discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | (16 | ) |  | — |  |  | (16 | ) |
| Net income | 167 |  |  | 158 |  |  | 158 |  |  | 152 |  |  | (470 | ) |  | 165 |  |
| Less: noncontrolling interest in subsidiaries net loss | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 167 |  |  | $ | 158 |  |  | $ | 158 |  |  | $ | 154 |  |  | $ | (470 | ) |  | $ | 167 |  |

[0000833444-15-000032:notes:70]
[same as prior period, unchanged from 0000833444-15-000013:notes:68]

[0000833444-15-000032:notes:71]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 167 |  |  | $ | 158 |  |  | $ | 158 |  |  | $ | 152 |  |  | $ | (470 | ) |  | $ | 165 |  |
| Other comprehensive (loss) income, net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | (176 | ) |  | — |  |  | 16 |  |  | (192 | ) |  | 176 |  |  | (176 | ) |
| Defined benefit and post retirement plans | 4 |  |  | — |  |  | — |  |  | 4 |  |  | (4 | ) |  | 4 |  |
| Total other comprehensive (loss) income net of tax | (172 | ) |  | — |  |  | 16 |  |  | (188 | ) |  | 172 |  |  | (172 | ) |
| Comprehensive (loss) income | (5 | ) |  | 158 |  |  | 174 |  |  | (36 | ) |  | (298 | ) |  | (7 | ) |
| Less: comprehensive loss attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Comprehensive (loss) income attributable to Tyco ordinary shareholders | $ | (5 | ) |  | $ | 158 |  |  | $ | 174 |  |  | $ | (34 | ) |  | $ | (298 | ) |  | $ | (5 | ) |

[0000833444-15-000032:notes:72]
For the Quarter Ended March 28, 2014

[0000833444-15-000032:notes:73]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | 2,480 |  |  | $ | — |  |  | $ | 2,480 |  |
| Cost of product sales | — |  |  | — |  |  | 1,003 |  |  | — |  |  | 1,003 |  |
| Cost of services | — |  |  | — |  |  | 575 |  |  | — |  |  | 575 |  |
| Selling, general and administrative expenses | — |  |  | 1 |  |  | 634 |  |  | — |  |  | 635 |  |
| Separation costs | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Operating (loss) income | — |  |  | (1 | ) |  | 260 |  |  | — |  |  | 259 |  |
| Interest income | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Interest expense | — |  |  | (24 | ) |  | (1 | ) |  | — |  |  | (25 | ) |
| Other (expense) income, net | (2 | ) |  | — |  |  | 1 |  |  | — |  |  | (1 | ) |
| Equity in net income of subsidiaries | 199 |  |  | 227 |  |  | — |  |  | (426 | ) |  | — |  |
| Intercompany interest and fees | 12 |  |  | 8 |  |  | (20 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 209 |  |  | 210 |  |  | 243 |  |  | (426 | ) |  | 236 |  |
| Income tax expense | — |  |  | — |  |  | (39 | ) |  | — |  |  | (39 | ) |
| Equity loss in earnings of unconsolidated subsidiaries | — |  |  | — |  |  | (5 | ) |  | — |  |  | (5 | ) |
| Income from continuing operations | 209 |  |  | 210 |  |  | 199 |  |  | (426 | ) |  | 192 |  |
| (Loss) income from discontinued operations, net of income taxes | (2 | ) |  | — |  |  | 17 |  |  | — |  |  | 15 |  |
| Net income | 207 |  |  | 210 |  |  | 216 |  |  | (426 | ) |  | 207 |  |
| Net income attributable to Tyco ordinary shareholders | $ | 207 |  |  | $ | 210 |  |  | $ | 216 |  |  | $ | (426 | ) |  | $ | 207 |  |

[0000833444-15-000032:notes:74]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 207 |  |  | $ | 210 |  |  | $ | 216 |  |  | $ | (426 | ) |  | $ | 207 |  |
| Other comprehensive (loss) income, net of tax |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | (15 | ) |  | — |  |  | (15 | ) |  | 15 |  |  | (15 | ) |
| Defined benefit and post retirement plans | 4 |  |  | — |  |  | 4 |  |  | (4 | ) |  | 4 |  |
| Total other comprehensive loss, net of tax | (11 | ) |  | — |  |  | (11 | ) |  | 11 |  |  | (11 | ) |
| Comprehensive income | 196 |  |  | 210 |  |  | 205 |  |  | (415 | ) |  | 196 |  |
| Less: comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Comprehensive income attributable to Tyco ordinary shareholders | $ | 196 |  |  | $ | 210 |  |  | $ | 205 |  |  | $ | (415 | ) |  | $ | 196 |  |

[0000833444-15-000032:notes:75]
For the Six Months Ended March 27, 2015

[0000833444-15-000032:notes:76]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 4,908 |  |  | $ | — |  |  | $ | 4,908 |  |
| Cost of product sales | — |  |  | — |  |  | — |  |  | 2,021 |  |  | — |  |  | 2,021 |  |
| Cost of services | — |  |  | — |  |  | — |  |  | 1,097 |  |  | — |  |  | 1,097 |  |
| Selling, general and administrative expenses | 5 |  |  | — |  |  | 1 |  |  | 1,294 |  |  | — |  |  | 1,300 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | — |  |  | 70 |  |  | — |  |  | 70 |  |
| Operating (loss) income | (5 | ) |  | — |  |  | (1 | ) |  | 426 |  |  | — |  |  | 420 |  |
| Interest income | — |  |  | — |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Interest expense | — |  |  | — |  |  | (48 | ) |  | (1 | ) |  | — |  |  | (49 | ) |
| Other income, net | — |  |  | — |  |  | 2 |  |  | 1 |  |  | — |  |  | 3 |  |
| Equity in net income of subsidiaries | 295 |  |  | 291 |  |  | 287 |  |  | — |  |  | (873 | ) |  | — |  |
| Intercompany interest and fees | 39 |  |  | — |  |  | 51 |  |  | (90 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 329 |  |  | 291 |  |  | 291 |  |  | 343 |  |  | (873 | ) |  | 381 |  |
| Income tax expense | — |  |  | — |  |  | — |  |  | (37 | ) |  | — |  |  | (37 | ) |
| Income from continuing operations | 329 |  |  | 291 |  |  | 291 |  |  | 306 |  |  | (873 | ) |  | 344 |  |
| Loss from discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | (18 | ) |  | — |  |  | (18 | ) |
| Net income | 329 |  |  | 291 |  |  | 291 |  |  | 288 |  |  | (873 | ) |  | 326 |  |
| Less: noncontrolling interest in subsidiaries net loss | — |  |  | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 329 |  |  | $ | 291 |  |  | $ | 291 |  |  | $ | 291 |  |  | $ | (873 | ) |  | $ | 329 |  |

[0000833444-15-000032:notes:77]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 329 |  |  | $ | 291 |  |  | $ | 291 |  |  | $ | 288 |  |  | $ | (873 | ) |  | $ | 326 |  |
| Other comprehensive (loss) income, net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | (374 | ) |  | — |  |  | 15 |  |  | (389 | ) |  | 374 |  |  | (374 | ) |
| Defined benefit and post retirement plans | 9 |  |  | — |  |  | — |  |  | 9 |  |  | (9 | ) |  | 9 |  |
| Total other comprehensive (loss) income, net of tax | (365 | ) |  | — |  |  | 15 |  |  | (380 | ) |  | 365 |  |  | (365 | ) |
| Comprehensive (loss) income | (36 | ) |  | 291 |  |  | 306 |  |  | (92 | ) |  | (508 | ) |  | (39 | ) |
| Less: comprehensive loss attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Comprehensive (loss) income attributable to Tyco ordinary shareholders | $ | (36 | ) |  | $ | 291 |  |  | $ | 306 |  |  | $ | (89 | ) |  | $ | (508 | ) |  | $ | (36 | ) |

[0000833444-15-000032:notes:78]
For the Six Months Ended March 28, 2014

[0000833444-15-000032:notes:79]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | 4,969 |  |  | $ | — |  |  | $ | 4,969 |  |
| Cost of product sales | — |  |  | — |  |  | 2,001 |  |  | — |  |  | 2,001 |  |
| Cost of services | — |  |  | — |  |  | 1,150 |  |  | — |  |  | 1,150 |  |
| Selling, general and administrative expenses | (13 | ) |  | 2 |  |  | 1,216 |  |  | — |  |  | 1,205 |  |
| Separation costs | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Operating income (loss) | 13 |  |  | (2 | ) |  | 591 |  |  | — |  |  | 602 |  |
| Interest income | — |  |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Interest expense | — |  |  | (48 | ) |  | (1 | ) |  | — |  |  | (49 | ) |
| Other (expense) income, net | (3 | ) |  | — |  |  | 1 |  |  | — |  |  | (2 | ) |
| Equity in net income of subsidiaries | 467 |  |  | 511 |  |  | — |  |  | (978 | ) |  | — |  |
| Intercompany interest and fees | 2 |  |  | 17 |  |  | (19 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 479 |  |  | 478 |  |  | 578 |  |  | (978 | ) |  | 557 |  |
| Income tax expense | — |  |  | — |  |  | (109 | ) |  | — |  |  | (109 | ) |
| Equity loss in earnings of unconsolidated subsidiaries | — |  |  | — |  |  | (9 | ) |  | — |  |  | (9 | ) |
| Income from continuing operations | 479 |  |  | 478 |  |  | 460 |  |  | (978 | ) |  | 439 |  |
| (Loss) income from discontinued operations, net of income taxes | (2 | ) |  | — |  |  | 42 |  |  | — |  |  | 40 |  |
| Net income | 477 |  |  | 478 |  |  | 502 |  |  | (978 | ) |  | 479 |  |
| Less: noncontrolling interest in subsidiaries net income | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Net income attributable to Tyco ordinary shareholders | $ | 477 |  |  | $ | 478 |  |  | $ | 500 |  |  | $ | (978 | ) |  | $ | 477 |  |

[0000833444-15-000032:notes:80]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 477 |  |  | $ | 478 |  |  | $ | 502 |  |  | $ | (978 | ) |  | $ | 479 |  |
| Other comprehensive (loss) income, net of tax |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | (52 | ) |  | — |  |  | (52 | ) |  | 52 |  |  | (52 | ) |
| Defined benefit and post retirement plans | 7 |  |  | — |  |  | 7 |  |  | (7 | ) |  | 7 |  |
| Total other comprehensive loss, net of tax | (45 | ) |  | — |  |  | (45 | ) |  | 45 |  |  | (45 | ) |
| Comprehensive income | 432 |  |  | 478 |  |  | 457 |  |  | (933 | ) |  | 434 |  |
| Less: comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Comprehensive income attributable to Tyco ordinary shareholders | $ | 432 |  |  | $ | 478 |  |  | $ | 455 |  |  | $ | (933 | ) |  | $ | 432 |  |

[0000833444-15-000032:notes:81]
[same as prior period, unchanged from 0000833444-15-000013:notes:73]

[0000833444-15-000032:notes:82]
As of March 27, 2015

[0000833444-15-000032:notes:83]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 432 |  |  | $ | — |  |  | $ | 432 |  |
| Accounts receivable, net | — |  |  | — |  |  | — |  |  | 1,643 |  |  | — |  |  | 1,643 |  |
| Inventories | — |  |  | — |  |  | — |  |  | 677 |  |  | — |  |  | 677 |  |
| Intercompany receivables | 35 |  |  | — |  |  | 302 |  |  | 7,369 |  |  | (7,706 | ) |  | — |  |
| Prepaid expenses and other current assets | 1 |  |  | — |  |  | 71 |  |  | 795 |  |  | — |  |  | 867 |  |
| Deferred income taxes | — |  |  | — |  |  | — |  |  | 304 |  |  | — |  |  | 304 |  |
| Assets held for sale | — |  |  | — |  |  | — |  |  | 155 |  |  | — |  |  | 155 |  |
| Total current assets | 36 |  |  | — |  |  | 373 |  |  | 11,375 |  |  | (7,706 | ) |  | 4,078 |  |
| Property, plant and equipment, net | — |  |  | — |  |  | — |  |  | 1,216 |  |  | — |  |  | 1,216 |  |
| Goodwill | — |  |  | — |  |  | — |  |  | 4,265 |  |  | — |  |  | 4,265 |  |
| Intangible assets, net | — |  |  | — |  |  | — |  |  | 908 |  |  | — |  |  | 908 |  |
| Investment in subsidiaries | 10,846 |  |  | 11,053 |  |  | 15,805 |  |  | — |  |  | (37,704 | ) |  | — |  |
| Intercompany loans receivable | — |  |  | — |  |  | 2,958 |  |  | 5,050 |  |  | (8,008 | ) |  | — |  |
| Other assets | 1 |  |  | — |  |  | 32 |  |  | 1,195 |  |  | — |  |  | 1,228 |  |
| Total Assets | $ | 10,883 |  |  | $ | 11,053 |  |  | $ | 19,168 |  |  | $ | 24,009 |  |  | $ | (53,418 | ) |  | $ | 11,695 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Loans payable and current maturities of long-term debt | $ | — |  |  | $ | — |  |  | $ | 258 |  |  | $ | 20 |  |  | $ | — |  |  | $ | 278 |  |
| Accounts payable | — |  |  | — |  |  | — |  |  | 735 |  |  | — |  |  | 735 |  |
| Accrued and other current liabilities | 93 |  |  | — |  |  | 66 |  |  | 1,800 |  |  | — |  |  | 1,959 |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 405 |  |  | — |  |  | 405 |  |
| Intercompany payables | 3,463 |  |  | — |  |  | 3,909 |  |  | 334 |  |  | (7,706 | ) |  | — |  |
| Liabilities held for sale | — |  |  | — |  |  | — |  |  | 102 |  |  | — |  |  | 102 |  |
| Total current liabilities | 3,556 |  |  | — |  |  | 4,233 |  |  | 3,396 |  |  | (7,706 | ) |  | 3,479 |  |
| Long-term debt | — |  |  | — |  |  | 1,731 |  |  | 1 |  |  | — |  |  | 1,732 |  |
| Intercompany loans payable | 3,146 |  |  | — |  |  | 1,904 |  |  | 2,958 |  |  | (8,008 | ) |  | — |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 315 |  |  | — |  |  | 315 |  |
| Other liabilities | — |  |  | — |  |  | 247 |  |  | 1,680 |  |  | — |  |  | 1,927 |  |
| Total Liabilities | 6,702 |  |  | — |  |  | 8,115 |  |  | 8,350 |  |  | (15,714 | ) |  | 7,453 |  |
| Redeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Tyco Shareholders' Equity: |  |  |  |  |  |  |  |  |  |  |  |
| Ordinary shares | 4 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |
| Other shareholders' equity | 4,177 |  |  | 11,053 |  |  | 11,053 |  |  | 15,598 |  |  | (37,704 | ) |  | 4,177 |  |
| Total Tyco Shareholders' Equity | 4,181 |  |  | 11,053 |  |  | 11,053 |  |  | 15,598 |  |  | (37,704 | ) |  | 4,181 |  |
| Nonredeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 49 |  |  | — |  |  | 49 |  |
| Total Equity | 4,181 |  |  | 11,053 |  |  | 11,053 |  |  | 15,647 |  |  | (37,704 | ) |  | 4,230 |  |
| Total Liabilities, Redeemable Noncontrolling Interest and Equity | $ | 10,883 |  |  | $ | 11,053 |  |  | $ | 19,168 |  |  | $ | 24,009 |  |  | $ | (53,418 | ) |  | $ | 11,695 |  |

[0000833444-15-000032:notes:84]
[same as prior period, unchanged from 0000833444-15-000013:notes:76]

[0000833444-15-000032:notes:85]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | — |  |  | $ | 892 |  |  | $ | — |  |  | $ | 892 |  |
| Accounts receivable, net | — |  |  | — |  |  | 1,734 |  |  | — |  |  | 1,734 |  |
| Inventories | — |  |  | — |  |  | 625 |  |  | — |  |  | 625 |  |
| Intercompany receivables | 18 |  |  | 245 |  |  | 8,102 |  |  | (8,365 | ) |  | — |  |
| Prepaid expenses and other current assets | 7 |  |  | 62 |  |  | 982 |  |  | — |  |  | 1,051 |  |
| Deferred income taxes | — |  |  | — |  |  | 304 |  |  | — |  |  | 304 |  |
| Assets held for sale | — |  |  | — |  |  | 180 |  |  | — |  |  | 180 |  |
| Total current assets | 25 |  |  | 307 |  |  | 12,819 |  |  | (8,365 | ) |  | 4,786 |  |
| Property, plant and equipment, net | — |  |  | — |  |  | 1,262 |  |  | — |  |  | 1,262 |  |
| Goodwill | — |  |  | — |  |  | 4,122 |  |  | — |  |  | 4,122 |  |
| Intangible assets, net | — |  |  | — |  |  | 712 |  |  | — |  |  | 712 |  |
| Investment in subsidiaries | 12,738 |  |  | 16,209 |  |  | — |  |  | (28,947 | ) |  | — |  |
| Intercompany loans receivable | — |  |  | 3,693 |  |  | 5,346 |  |  | (9,039 | ) |  | — |  |
| Other assets | 26 |  |  | 4 |  |  | 897 |  |  | — |  |  | 927 |  |
| Total Assets | $ | 12,789 |  |  | $ | 20,213 |  |  | $ | 25,158 |  |  | $ | (46,351 | ) |  | $ | 11,809 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |
| Loans payable and current maturities of long-term debt | $ | — |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |
| Accounts payable | 1 |  |  | — |  |  | 824 |  |  | — |  |  | 825 |  |
| Accrued and other current liabilities | 191 |  |  | 23 |  |  | 1,900 |  |  | — |  |  | 2,114 |  |
| Deferred revenue | — |  |  | — |  |  | 400 |  |  | — |  |  | 400 |  |
| Intercompany payables | 3,517 |  |  | 4,593 |  |  | 255 |  |  | (8,365 | ) |  | — |  |
| Liabilities held for sale | — |  |  | — |  |  | 118 |  |  | — |  |  | 118 |  |
| Total current liabilities | 3,709 |  |  | 4,616 |  |  | 3,517 |  |  | (8,365 | ) |  | 3,477 |  |
| Long-term debt | — |  |  | 1,441 |  |  | 2 |  |  | — |  |  | 1,443 |  |
| Intercompany loans payable | 4,180 |  |  | 1,888 |  |  | 2,971 |  |  | (9,039 | ) |  | — |  |
| Deferred revenue | — |  |  | — |  |  | 335 |  |  | — |  |  | 335 |  |
| Other liabilities | 253 |  |  | — |  |  | 1,618 |  |  | — |  |  | 1,871 |  |
| Total Liabilities | 8,142 |  |  | 7,945 |  |  | 8,443 |  |  | (17,404 | ) |  | 7,126 |  |
| Redeemable noncontrolling interest | — |  |  | — |  |  | 13 |  |  | — |  |  | 13 |  |
| Tyco Shareholders' Equity: |  |  |  |  |  |  |  |  |  |
| Ordinary shares | 208 |  |  | — |  |  | — |  |  | — |  |  | 208 |  |
| Ordinary shares held in treasury | — |  |  | — |  |  | (2,515 | ) |  | — |  |  | (2,515 | ) |
| Other shareholders' equity | 4,439 |  |  | 12,268 |  |  | 19,194 |  |  | (28,947 | ) |  | 6,954 |  |
| Total Tyco Shareholders' Equity | 4,647 |  |  | 12,268 |  |  | 16,679 |  |  | (28,947 | ) |  | 4,647 |  |
| Nonredeemable noncontrolling interest | — |  |  | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Total Equity | 4,647 |  |  | 12,268 |  |  | 16,702 |  |  | (28,947 | ) |  | 4,670 |  |
| Total Liabilities, Redeemable Noncontrolling Interest and Equity | $ | 12,789 |  |  | $ | 20,213 |  |  | $ | 25,158 |  |  | $ | (46,351 | ) |  | $ | 11,809 |  |

[0000833444-15-000032:notes:86]
[same as prior period, unchanged from 0000833444-15-000013:notes:78]

[0000833444-15-000032:notes:87]
|  | TycoInternational plc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | 20 |  |  | $ | — |  |  | $ | (504 | ) |  | $ | 746 |  |  | $ | — |  |  | $ | 262 |  |
| Net cash provided by discontinued operating activities | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | — |  |  | (123 | ) |  | — |  |  | (123 | ) |
| Proceeds from disposal of assets | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | — |  |  | (525 | ) |  | — |  |  | (525 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases | — |  |  | — |  |  | — |  |  | (8 | ) |  | — |  |  | (8 | ) |
| Divestiture of businesses, net of cash divested | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Net increase in intercompany loans | — |  |  | — |  |  | (59 | ) |  | — |  |  | 59 |  |  | — |  |
| Sales and maturities of investments | — |  |  | — |  |  | — |  |  | 279 |  |  | — |  |  | 279 |  |
| Purchases of investments | — |  |  | — |  |  | — |  |  | (288 | ) |  | — |  |  | (288 | ) |
| Increase in restricted cash | — |  |  | — |  |  | — |  |  | (39 | ) |  | — |  |  | (39 | ) |
| Other | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Net cash used in investing activities | — |  |  | — |  |  | (59 | ) |  | (703 | ) |  | 59 |  |  | (703 | ) |
| Net cash used in discontinued investing activities | — |  |  | — |  |  | — |  |  | (15 | ) |  | — |  |  | (15 | ) |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Repayment of short-term debt | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Proceeds from issuance of long-term debt | — |  |  | — |  |  | 567 |  |  | — |  |  | — |  |  | 567 |  |
| Proceeds from exercise of share options | 50 |  |  | — |  |  | — |  |  | 7 |  |  | — |  |  | 57 |  |
| Dividends paid | (151 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (151 | ) |
| Repurchase of ordinary shares by treasury | — |  |  | — |  |  | — |  |  | (417 | ) |  | — |  |  | (417 | ) |
| Net intercompany loan borrowings | 83 |  |  | — |  |  | — |  |  | (24 | ) |  | (59 | ) |  | — |  |
| Transfer to discontinued operations | — |  |  | — |  |  | — |  |  | (12 | ) |  | — |  |  | (12 | ) |
| Payment of contingent consideration | — |  |  | — |  |  | — |  |  | (23 | ) |  | — |  |  | (23 | ) |
| Other | (2 | ) |  | — |  |  | (4 | ) |  | (17 | ) |  | — |  |  | (23 | ) |
| Net cash (used in) provided by financing activities | (20 | ) |  | — |  |  | 563 |  |  | (487 | ) |  | (59 | ) |  | (3 | ) |
| Net cash provided by discontinued financing activities | — |  |  | — |  |  | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Effect of currency translation on cash | — |  |  | — |  |  | — |  |  | (16 | ) |  | — |  |  | (16 | ) |
| Net decrease in cash and cash equivalents | — |  |  | — |  |  | — |  |  | (460 | ) |  | — |  |  | (460 | ) |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | — |  |  | 892 |  |  | — |  |  | 892 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 432 |  |  | $ | — |  |  | $ | 432 |  |

[0000833444-15-000032:notes:88]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |
| Net cash (used in) provided by operating activities | $ | (20 | ) |  | $ | 215 |  |  | $ | 171 |  |  | $ | — |  |  | $ | 366 |  |
| Net cash provided by discontinued operating activities | — |  |  | — |  |  | 77 |  |  | — |  |  | 77 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | (135 | ) |  | — |  |  | (135 | ) |
| Proceeds from disposal of assets | — |  |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | (54 | ) |  | — |  |  | (54 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases | — |  |  | — |  |  | (16 | ) |  | — |  |  | (16 | ) |
| Net increase in intercompany loans | — |  |  | (206 | ) |  | — |  |  | 206 |  |  | — |  |
| Increase in investment in subsidiaries | — |  |  | (9 | ) |  | — |  |  | 9 |  |  | — |  |
| Sales and maturities of investments | — |  |  | — |  |  | 141 |  |  | — |  |  | 141 |  |
| Purchases of investments | — |  |  | — |  |  | (40 | ) |  | — |  |  | (40 | ) |
| Decrease in restricted cash | — |  |  | — |  |  | 6 |  |  | — |  |  | 6 |  |
| Other | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net cash used in investing activities | — |  |  | (215 | ) |  | (92 | ) |  | 215 |  |  | (92 | ) |
| Net cash used in discontinued investing activities | — |  |  | — |  |  | (57 | ) |  | — |  |  | (57 | ) |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short-term debt | — |  |  | 715 |  |  | — |  |  | — |  |  | 715 |  |
| Repayment of short-term debt | — |  |  | (715 | ) |  | — |  |  | — |  |  | (715 | ) |
| Proceeds from exercise of share options | — |  |  | — |  |  | 62 |  |  | — |  |  | 62 |  |
| Dividends paid | (148 | ) |  | — |  |  | — |  |  | — |  |  | (148 | ) |
| Repurchase of ordinary shares by treasury | — |  |  | — |  |  | (250 | ) |  | — |  |  | (250 | ) |
| Net intercompany loan borrowings | 168 |  |  | — |  |  | 38 |  |  | (206 | ) |  | — |  |
| Increase in equity from parent | — |  |  | — |  |  | 9 |  |  | (9 | ) |  | — |  |
| Transfer from discontinued operations | — |  |  | — |  |  | 20 |  |  | — |  |  | 20 |  |
| Other | — |  |  | — |  |  | (10 | ) |  | — |  |  | (10 | ) |
| Net cash provided by (used in) financing activities | 20 |  |  | — |  |  | (131 | ) |  | (215 | ) |  | (326 | ) |
| Net cash used in discontinued financing activities | — |  |  | — |  |  | (20 | ) |  | — |  |  | (20 | ) |
| Effect of currency translation on cash | — |  |  | — |  |  | (16 | ) |  | — |  |  | (16 | ) |
| Net decrease in cash and cash equivalents | — |  |  | — |  |  | (68 | ) |  | — |  |  | (68 | ) |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | 563 |  |  | — |  |  | 563 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | — |  |  | $ | 495 |  |  | $ | — |  |  | $ | 495 |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-15-000032:notes:89]
Debt

[0000833444-15-000032:notes:90]
Debt as of March 27, 2015 and September 26, 2014 is as follows ($ in millions):

[0000833444-15-000032:notes:91]
|  | As of |
|  | March 27, 2015 |  | September 26, 2014 |
| 3.375% public notes due 2015 (1) | $ | 258 |  |  | $ | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 8.5% public notes due 2019 | 364 |  |  | 364 |  |
| 7.0% public notes due 2019 | 245 |  |  | 245 |  |
| 6.875% public notes due 2021 | 465 |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% public notes due 2025 | 548 |  |  | — |  |
| Other (2) | 21 |  |  | 22 |  |
| Total debt | 2,010 |  |  | 1,463 |  |
| Less current portion | 278 |  |  | 20 |  |
| Long-term debt | $ | 1,732 |  |  | $ | 1,443 |  |

[0000833444-15-000032:notes:92]
(1)  $258 million of 3.375% public notes due October 2015 is included in the current portion of debt as of March 27, 2015.

[0000833444-15-000032:notes:93]
(2)  $20 million of the amount shown as other is included in the current portion of the Company's total debt as of both March 27, 2015 and September 26, 2014.

[0000833444-15-000032:notes:94]
Fair Value

[0000833444-15-000032:notes:95]
The carrying amount of Tyco's debt subject to the fair value disclosure requirements as of March 27, 2015 and September 26, 2014 was $1,989 million and $1,441 million, respectively.  The Company has determined the fair value of such debt to be $2,198 million and $1,670 million as of March 27, 2015 and September 26, 2014, respectively.  The Company utilizes various valuation methodologies to determine the fair value of its debt, which is primarily dependent on the type of market in which the Company's debt is traded. When available, the Company uses quoted market prices to determine the fair value of its debt that is traded in active markets.  As of March 27, 2015 and September 26, 2014, $1,989 million and $1,441 million, respectively, of the Company's debt, which is actively traded and subject to the fair value disclosure requirements, is classified as Level 1 in the fair value hierarchy.

[0000833444-15-000032:notes:96]
Commercial Paper

[0000833444-15-000032:notes:97]
From time to time, the Company's wholly-owned subsidiary, Tyco International Finance S.A. ("TIFSA") may issue commercial paper for general corporate purposes. The maximum aggregate amount of unsecured commercial paper notes available to be issued on a private placement basis under the commercial paper program is $1 billion as of March 27, 2015.  As of March 27, 2015 and September 26, 2014, TIFSA had no commercial paper outstanding.

[0000833444-15-000032:notes:98]
Credit Facilities

[0000833444-15-000032:notes:99]
The Company's committed revolving credit facility totaled $1 billion as of March 27, 2015. This revolving credit facility may be used for working capital, capital expenditures and general corporate purposes. As of March 27, 2015 and September 26, 2014, there were no amounts drawn under the Company's revolving credit facility. Interest under the revolving credit facility is variable and is calculated by reference to LIBOR or an alternate base rate.

[0000833444-15-000032:notes:100]
Debt Issuance/Repayment

[0000833444-15-000032:notes:101]
On February 25, 2015, TIFSA issued €500 million aggregate principal amount of 1.375% Notes due February 25, 2025 (the "Notes"), which are fully and unconditionally guaranteed by each of the Company and Tyco Fire & Security Finance S.C.A.  TIFSA received total net proceeds of approximately $563 million after deducting debt issuance costs of approximately $5 million and a debt discount of approximately $1 million.  The net proceeds, were made available for general corporate purposes.  The Notes are TIFSA’s senior unsecured obligations and rank equally in right of payment with all of its existing and future senior debt, and senior to any subordinated indebtedness that TIFSA may incur.  The Notes were designated as a net investment hedge.  See Note 10.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-15-000032:notes:102]
[same as prior period, unchanged from 0000833444-15-000013:notes:92]

[0000833444-15-000032:notes:103]
[same as prior period, unchanged from 0000833444-15-000013:notes:93]

[0000833444-15-000032:notes:104]
[same as prior period, unchanged from 0000833444-15-000013:notes:95]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-15-000032:notes:105]
[same as prior period, unchanged from 0000833444-15-000013:notes:96]

[0000833444-15-000032:notes:106]
[same as prior period, unchanged from 0000833444-15-000013:notes:97]

[0000833444-15-000032:notes:107]
During the quarter ended March 27, 2015, the Company concluded that several businesses in the ROW Installation & Services segment which it intends to sell met the criteria to be classified as held for sale.  The Company expects to complete the sale of these businesses during the remainder of fiscal 2015.  In addition, during fiscal 2014, the Company concluded that several other businesses in the ROW Installation & Services segment which it intends to sell met the criteria to be classified as held for sale. The Company expects to complete the sale of these businesses by the end of the third quarter of fiscal 2015.

[0000833444-15-000032:notes:108]
The businesses described above are accounted for as held for sale on the Consolidated Balance Sheets as of March 27, 2015 and September 26, 2014.  To the extent the criteria required to be presented as a discontinued operation have been satisfied, the businesses results of operations have been presented as such on the Consolidated Statements of Operations during the quarters and six months ended March 27, 2015 and March 28, 2014.

[0000833444-15-000032:notes:109]
[same as prior period, unchanged from 0000833444-15-000013:notes:101]

[0000833444-15-000032:notes:110]
The components of (loss) income from discontinued operations, net of income taxes are as follows ($ in millions):

[0000833444-15-000032:notes:111]
|  | For the Quarters Ended |  | For the Six Months Ended |
|  | March 27, 2015 |  | March 28, 2014 |  | March 27, 2015 |  | March 28, 2014 |
| Net revenue | $ | 5 |  |  | $ | 152 |  |  | $ | 10 |  |  | $ | 310 |  |
| Pre-tax (loss) income from discontinued operations | (6 | ) |  | 20 |  |  | (9 | ) |  | 52 |  |
| Pre-tax separation loss included within discontinued operations (See Note 2) | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Pre-tax (loss) gain on sale of discontinued operations | — |  |  | (4 | ) |  | 1 |  |  | (4 | ) |
| Income tax expense | (10 | ) |  | — |  |  | (10 | ) |  | (7 | ) |
| (Loss) income from discontinued operations, net of income taxes | $ | (16 | ) |  | $ | 15 |  |  | $ | (18 | ) |  | $ | 40 |  |

[0000833444-15-000032:notes:112]
Balance sheet information for the discontinued operations as of March 27, 2015 and September 26, 2014 was as follows ($ in millions):

[0000833444-15-000032:notes:113]
|  | As of |
|  | March 27, 2015 |  | September 26, 2014 |
| Accounts receivable, net | $ | 20 |  |  | $ | 26 |  |
| Inventories | 6 |  |  | 7 |  |
| Prepaid expenses and other current assets | 95 |  |  | 107 |  |
| Deferred income taxes | 3 |  |  | 3 |  |
| Property, plant and equipment, net | 6 |  |  | 6 |  |
| Goodwill | 3 |  |  | 3 |  |
| Intangible assets, net | 21 |  |  | 25 |  |
| Other assets | 1 |  |  | 3 |  |
| Total assets | $ | 155 |  |  | $ | 180 |  |
| Accounts payable | 38 |  |  | 48 |  |
| Accrued and other current liabilities | 55 |  |  | 62 |  |
| Deferred revenue | 2 |  |  | 2 |  |
| Other liabilities | 7 |  |  | 6 |  |
| Total liabilities | $ | 102 |  |  | $ | 118 |  |

[0000833444-15-000032:notes:114]
Because the Company utilizes a centralized approach to cash management and the financing of its operations, all cash that is generated by discontinued operations is routinely transferred to the Company's financing subsidiaries in continuing operations.  As a result, Transfers from discontinued operations on the Company's Consolidated Statement of Cash Flows reflects the net cash movements from discontinued operations to continuing operations that have occurred during the period.


## us-gaap:EarningsPerShareTextBlock

[0000833444-15-000032:notes:115]
[same as prior period, unchanged from 0000833444-15-000013:notes:106]

[0000833444-15-000032:notes:116]
[same as prior period, unchanged from 0000833444-15-000013:notes:107]

[0000833444-15-000032:notes:117]
|  | For the Quarter Ended March 27, 2015 |  | For the Quarter Ended March 28, 2014 |
|  | Income |  | Shares |  | Per ShareAmount |  | Income |  | Shares |  | Per ShareAmount |
| Basic earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 183 |  |  | 420 |  |  | $ | 0.44 |  |  | $ | 192 |  |  | 461 |  |  | $ | 0.41 |  |
| Share options and restricted share awards | — |  |  | 7 |  |  |  |  | — |  |  | 8 |  |  |  |
| Diluted earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations attributable to Tyco ordinary shareholders, giving effect to dilutive adjustments | $ | 183 |  |  | 427 |  |  | $ | 0.43 |  |  | $ | 192 |  |  | 469 |  |  | $ | 0.41 |  |

[0000833444-15-000032:notes:118]
|  | For the Six Months Ended March 27, 2015 |  | For the Six Months Ended March 28, 2014 |
|  | Income |  | Shares |  | Per ShareAmount |  | Income |  | Shares |  | Per ShareAmount |
| Basic earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 347 |  |  | 420 |  |  | $ | 0.83 |  |  | $ | 437 |  |  | 462 |  |  | $ | 0.94 |  |
| Share options and restricted share awards | — |  |  | 7 |  |  |  |  | — |  |  | 8 |  |  |  |
| Diluted earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations attributable to Tyco ordinary shareholders, giving effect to dilutive adjustments | $ | 347 |  |  | 427 |  |  | $ | 0.81 |  |  | $ | 437 |  |  | 470 |  |  | $ | 0.93 |  |

[0000833444-15-000032:notes:119]
The computation of diluted earnings per share for the quarter and six months ended March 27, 2015 excludes the effect of the potential exercise of share options to purchase approximately 3 million shares for both periods and excludes restricted stock units of approximately 1 million shares for both periods because the effect would be anti-dilutive.

[0000833444-15-000032:notes:120]
The computation of diluted earnings per share for the quarter and six months ended March 28, 2014 excludes the effect of the potential exercise of share options to purchase approximately 2 million shares for both periods and excludes restricted stock units of approximately 2 million shares for both periods because the effect would be anti-dilutive.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000833444-15-000032:notes:121]
The following table presents the Company's hierarchy for its assets measured at fair value on a recurring basis as of March 27, 2015 and September 26, 2014 ($ in millions):

[0000833444-15-000032:notes:122]
|  |  |  |  |  |  |  | Consolidated Balance SheetClassification |
|  | As of March 27, 2015 |  | Prepaids andOther CurrentAssets |  | Other Assets |
| Investment Assets: | Level 1 |  | Level 2 |  | Total |  |  |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Exchange traded funds (fixed income) (1) | $ | 198 |  |  | $ | — |  |  | $ | 198 |  |  | $ | — |  |  | $ | 198 |  |
| Exchange traded funds (equity) (1) | 84 |  |  | — |  |  | 84 |  |  | — |  |  | 84 |  |
| Trading securities: |  |  |  |  |  |  |  |  |  |
| Exchange traded funds (equity) | 63 |  |  | — |  |  | 63 |  |  | 63 |  |  | — |  |
|  | $ | 345 |  |  | $ | — |  |  | $ | 345 |  |  | $ | 63 |  |  | $ | 282 |  |

[0000833444-15-000032:notes:123]
(1) Classified as restricted investments.  See Note 11.

[0000833444-15-000032:notes:124]
|  |  |  |  |  |  |  | Consolidated Balance SheetClassification |
|  | As of September 26, 2014 |  | Prepaids andOther CurrentAssets |
| Investment Assets: | Level 1 |  | Level 2 |  | Total |  |
| Time deposits | $ | 275 |  |  | $ | — |  |  | $ | 275 |  |  | $ | 275 |  |
| Trading Securities: |  |  |  |  |  |  |  |
| Exchange traded funds (equity) | 62 |  |  | — |  |  | 62 |  |  | 62 |  |
|  | $ | 337 |  |  | $ | — |  |  | $ | 337 |  |  | $ | 337 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000833444-15-000032:notes:125]
[same as prior period, unchanged from 0000833444-15-000013:notes:114]

[0000833444-15-000032:notes:126]
The Company's financial instruments consist primarily of cash and cash equivalents, time deposits, accounts receivable, investments, accounts payable, debt and derivative financial instruments. The fair value of cash and cash equivalents, time deposits, accounts receivable, and accounts payable approximated book value as of March 27, 2015 and September 26, 2014. The fair value of derivative financial instruments was not material to any of the periods presented. See below for the fair value of investments and Note 9 for the fair value of debt.

[0000833444-15-000032:notes:127]
[same as prior period, unchanged from 0000833444-15-000013:notes:116]

[0000833444-15-000032:notes:128]
In the normal course of business, Tyco is exposed to market risk arising from changes in currency exchange rates, interest rates and commodity prices. The Company may use derivative financial instruments to manage exposures to foreign currency, interest rate and commodity risks. The Company's objective for utilizing derivative financial instruments is to manage these risks using the most effective methods to eliminate or reduce the impacts of these exposures. The Company does not use derivative financial instruments for trading or speculative purposes.  As of and during the six months ended March 27, 2015, the Company did not hold or enter into any commodity derivative instruments or interest rate swaps.

[0000833444-15-000032:notes:129]
For derivative instruments that are designated and qualified as hedging instruments for accounting purposes, the Company documents and links the relationships between the hedging instruments and hedged items.  The Company also assesses and documents at the hedge's inception whether the derivatives used in hedging transactions are effective in offsetting changes in fair values associated with the hedged items.  During the quarter, the Company designated its €500 million of 1.375% public notes due February 2025 as a net investment hedge of the Company’s investments in certain of its international subsidiaries that use the Euro as their functional currency and intercompany permanent loans in order to reduce the volatility caused by changes in foreign currency exchange rates of the Euro with respect to the U.S. Dollar.  During the quarter ended March 27, 2015, the change in the carrying value due to remeasurement of the Euro denominated 2025 Notes resulted in a $20 million gain reported in Accumulated other comprehensive loss on the Consolidated Balance Sheets. This hedge did not result in any hedge ineffectiveness for the quarter and six months ended March 27, 2015.  During the quarter ended March 28, 2014, the Company did not have hedging instruments that were designated and qualified as hedging instruments for accounting purposes.

[0000833444-15-000032:notes:130]
As of March 27, 2015 and September 26, 2014, the total gross notional amount of the Company's foreign exchange contracts was $298 million and $258 million, respectively. The fair value of these derivative financial instruments and impact of such changes in the fair value was not material to the Consolidated Balance Sheets as of March 27, 2015 and September 26, 2014 or Consolidated Statements of Operations and Consolidated Statements of Cash Flows for the quarters and six months ended March 27, 2015 and March 28, 2014.

[0000833444-15-000032:notes:131]
[same as prior period, unchanged from 0000833444-15-000013:notes:119]

[0000833444-15-000032:notes:132]
[same as prior period, unchanged from 0000833444-15-000013:notes:120]

[0000833444-15-000032:notes:133]
[same as prior period, unchanged from 0000833444-15-000013:notes:121]

[0000833444-15-000032:notes:134]
Investments may primarily include marketable securities such as U.S. government obligations, U.S. government agency and corporate debt securities, equity securities, exchange traded funds or time deposits with banks.

[0000833444-15-000032:notes:135]
[same as prior period, unchanged from 0000833444-15-000013:notes:123]

[0000833444-15-000032:notes:136]
[same as prior period, unchanged from 0000833444-15-000013:notes:124]

[0000833444-15-000032:notes:137]
During the quarter and six months ended March 27, 2015, the Company did not have any significant transfers between levels within the fair value hierarchy.

[0000833444-15-000032:notes:138]
Unrealized gains and losses related to trading securities are recorded in Other (expense) income, net in the Consolidated Statements of Operations.  Unrealized gains and losses related to available for sale securities are recorded in Other comprehensive income.

[0000833444-15-000032:notes:139]
[same as prior period, unchanged from 0000833444-15-000013:notes:126]

[0000833444-15-000032:notes:140]
The Company had $1.4 billion and $1.5 billion of intercompany loans designated as permanent in nature as of March 27, 2015 and September 26, 2014, respectively.  Additionally, for the quarters ended March 27, 2015 and March 28, 2014, the Company recorded $75 million and $7 million of a cumulative translation loss, respectively, through Accumulated other comprehensive loss related to these loans.

[0000833444-15-000032:notes:141]
For the six months ended March 27, 2015 and March 28, 2014, the Company recorded $145 million of a cumulative translation loss and $4 million of a cumulative translation gain, respectively, through Accumulated other comprehensive loss related to these loans.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-15-000032:notes:142]
[same as prior period, unchanged from 0000833444-15-000013:notes:128]

[0000833444-15-000032:notes:143]
[same as prior period, unchanged from 0000833444-15-000013:notes:129]

[0000833444-15-000032:notes:144]
|  | NA Installation &Services |  | ROWInstallation &Services |  | GlobalProducts |  | Total |
| Gross goodwill | $ | 2,104 |  |  | $ | 1,991 |  |  | $ | 1,824 |  |  | $ | 5,919 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of September 27, 2013 | 1,978 |  |  | 923 |  |  | 1,257 |  |  | 4,158 |  |
| 2014 activity: |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions/ purchase accounting adjustments | 10 |  |  | 15 |  |  | (4 | ) |  | 21 |  |
| Currency translation | (12 | ) |  | (34 | ) |  | (11 | ) |  | (57 | ) |
| Gross goodwill | $ | 2,102 |  |  | $ | 1,972 |  |  | $ | 1,809 |  |  | $ | 5,883 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of September 26, 2014 | 1,976 |  |  | 904 |  |  | 1,242 |  |  | 4,122 |  |
| 2015 activity: |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions / purchase accounting adjustments | 15 |  |  | 34 |  |  | 275 |  |  | 324 |  |
| Currency translation | (20 | ) |  | (128 | ) |  | (33 | ) |  | (181 | ) |
| Gross goodwill | $ | 2,097 |  |  | $ | 1,878 |  |  | $ | 2,051 |  |  | $ | 6,026 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of March 27, 2015 | $ | 1,971 |  |  | $ | 810 |  |  | $ | 1,484 |  |  | $ | 4,265 |  |

[0000833444-15-000032:notes:145]
Intangible asset amortization expense for the quarters ended March 27, 2015 and March 28, 2014 was $21 million and $23 million, respectively.  Intangible asset amortization expense for the six months ended March 27, 2015 and March 28, 2014 was $41 million and $46 million, respectively.

[0000833444-15-000032:notes:146]
The estimated aggregate amortization expense on intangible assets is expected to be approximately $40 million for the remainder of 2015, $88 million for 2016, $79 million for 2017, $74 million for 2018, and $330 million for 2019 and thereafter.


## us-gaap:GuaranteesTextBlock

[0000833444-15-000032:notes:147]
[same as prior period, unchanged from 0000833444-15-000013:notes:133]

[0000833444-15-000032:notes:148]
Certain of the Company's subsidiaries at the business segment level have guaranteed the performance of third-parties and provided financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from the current fiscal year through the completion of such transactions and would typically be triggered in the event of nonperformance.  Performance under the guarantees, if required, would not have a material effect on the Company's financial position, results of operations or cash flows.

[0000833444-15-000032:notes:149]
There are certain guarantees or indemnifications extended among Tyco, Medtronic, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 Separation and Distribution Agreements and Tax Sharing Agreements. These guarantees primarily relate to certain contingent tax liabilities included in the Tax Sharing Agreements. See Note 6.

[0000833444-15-000032:notes:150]
In addition, Tyco historically provided support in the form of financial and/or performance guarantees to various Medtronic, TE Connectivity, ADT and Tyco Flow Control operating entities. In connection with both the 2012 and 2007 Separations, the Company worked with the guarantee counterparties to cancel or assign these guarantees to Medtronic, TE Connectivity, ADT or Pentair, as appropriate. To the extent these guarantees were not assigned prior to the Separation dates, Tyco remained as the guarantor, but was typically indemnified by the former subsidiary. The Company's obligations related to the 2012 Separation were $3 million, which were included in Other liabilities on the Company's Consolidated Balance Sheets as of both March 27, 2015 and September 26, 2014, with an offset to Tyco's shareholders' equity on the 2012 Separation date. The Company's obligations related to the 2007 Separation were $3 million, which were included in Other liabilities on the Company's Consolidated Balance Sheets as of both March 27, 2015 and September 26, 2014, with an offset to Tyco's shareholders' equity on the 2007 Separation date.

[0000833444-15-000032:notes:151]
In disposing of assets or businesses, the Company or its subsidiaries often provides representations, warranties and/or indemnities to cover various risks including, for example, unknown damage to the assets, environmental risks involved in the sale of real estate, liability to investigate and remediate environmental contamination at waste disposal sites and manufacturing facilities and unidentified tax liabilities and legal fees related to periods prior to disposition. The Company has no reason to believe that these contingencies, if realized, would have a material adverse effect on the Company's financial position, results of operations or cash flows. The Company has recorded liabilities for known indemnifications included as part of environmental liabilities. See Note 11.

[0000833444-15-000032:notes:152]
[same as prior period, unchanged from 0000833444-15-000013:notes:138]

[0000833444-15-000032:notes:153]
The changes in the carrying amount of the Company's warranty accrual from September 26, 2014 to March 27, 2015 were as follows ($ million):

[0000833444-15-000032:notes:154]
| Balance as of September 26, 2014 | $ | 28 |  |
| Warranties issued | 12 |  |
| Changes in estimates | 1 |  |
| Settlements | (6 | ) |
| Currency translation | (1 | ) |
| Balance as of March 27, 2015 | $ | 34 |  |

[0000833444-15-000032:notes:155]
[same as prior period, unchanged from 0000833444-15-000013:notes:141]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-15-000032:notes:156]
[same as prior period, unchanged from 0000833444-15-000013:notes:142]

[0000833444-15-000032:notes:157]
Tyco did not have a significant change to its unrecognized tax benefits during the quarter ended March 27, 2015.

[0000833444-15-000032:notes:158]
[same as prior period, unchanged from 0000833444-15-000013:notes:144]

[0000833444-15-000032:notes:159]
[same as prior period, unchanged from 0000833444-15-000013:notes:145]

[0000833444-15-000032:notes:160]
[same as prior period, unchanged from 0000833444-15-000013:notes:146]

[0000833444-15-000032:notes:161]
At each balance sheet date, the Company evaluates whether it is more likely than not that Tyco's deferred tax assets will be realized and if sufficient future taxable income will be available by assessing current period and projected operating results and other pertinent data. As of March 27, 2015, Tyco recorded deferred tax assets of approximately $349 million, which is comprised of $2.4 billion gross deferred tax assets net of $2.0 billion valuation allowances.

[0000833444-15-000032:notes:162]
[same as prior period, unchanged from 0000833444-15-000013:notes:148]

[0000833444-15-000032:notes:163]
In connection with the 2012 and 2007 Separations, Tyco entered into the 2012 and 2007 Tax Sharing Agreements, respectively, that govern the respective rights, responsibilities, and obligations of (i) Tyco, Pentair and ADT after the 2012 Separation and (ii) Tyco, Medtronic (formerly Covidien plc) and TE Connectivity after the 2007 Separation, with respect to taxes. Specifically, this includes taxes in the ordinary course of business and taxes, if any, incurred as a result of any failure of the respective distributions to qualify tax-free for U.S. federal income tax purposes within the meaning of Section 355 of the Internal Revenue Code ("the Code") or certain internal transactions undertaken in anticipation of the spin-offs to qualify for tax-favored treatment under the Code.

[0000833444-15-000032:notes:164]
[same as prior period, unchanged from 0000833444-15-000013:notes:150]

[0000833444-15-000032:notes:165]
Under the 2007 Tax Sharing Agreement, Tyco shares responsibility for certain of Tyco's, Medtronic's and TE Connectivity's income tax liabilities, which result in cash payments, based on a sharing formula for periods prior to and including June 29, 2007. More specifically, Tyco, Medtronic and TE Connectivity share 27%, 42% and 31%, respectively, of shared income tax liabilities that arise from adjustments made by tax authorities to Tyco's, Medtronic's and TE Connectivity's U.S. and certain non-U.S. income tax returns. The costs and expenses associated with the management of these shared tax liabilities are generally shared equally among the parties. In connection with the execution of the 2007 Tax Sharing Agreement, Tyco established a net receivable from Medtronic and TE Connectivity representing the amount Tyco expected to receive for pre-2007 Separation uncertain tax positions, including amounts owed to the Internal Revenue Service ("IRS"). Tyco also established liabilities representing the fair market value of its share of Medtronic's and TE Connectivity's estimated obligations, primarily to the IRS, for their pre-2007 Separation taxes covered by the 2007 Tax Sharing Agreement.

[0000833444-15-000032:notes:166]
Tyco assesses the shared tax liabilities and related guaranteed liabilities related to both the 2012 and 2007 Tax Sharing Agreements at each reporting period. Tyco will provide payment to Pentair and ADT under the 2012 Tax Sharing Agreement and Medtronic and TE Connectivity under the 2007 Tax Sharing Agreement as the shared income tax liabilities are settled. Settlement is expected to occur as the tax audit and legal processes are completed for the impacted years and cash payments are made. Due to the nature of the unresolved adjustments described in the next paragraph, the maximum amount of future payments under the 2012 and 2007 Tax Sharing Agreements is not known. Such cash payments, when they occur, will reduce the guarantor liability as they represent an equivalent reduction of risk. Tyco also assesses the sufficiency of the 2012 and 2007 Tax Sharing Agreements guarantee liabilities on a quarterly basis and will increase the liability when it is probable that cash payments expected to be made exceed the recorded balance.

[0000833444-15-000032:notes:167]
[same as prior period, unchanged from 0000833444-15-000013:notes:153]

[0000833444-15-000032:notes:168]
[same as prior period, unchanged from 0000833444-15-000013:notes:154]

[0000833444-15-000032:notes:169]
[same as prior period, unchanged from 0000833444-15-000013:notes:155]

[0000833444-15-000032:notes:170]
[same as prior period, unchanged from 0000833444-15-000013:notes:156]

[0000833444-15-000032:notes:171]
In addition to dealing with tax liabilities for periods prior to the respective Separations, the 2012 and 2007 Tax Sharing Agreements contain sharing provisions to address the contingencies that the 2012 or 2007 Separations, or internal transactions related thereto, may be deemed taxable by U.S. or non U.S. taxing authorities. In the event the 2012 Separation is determined to be taxable and such determination was the result of actions taken after the 2012 Separations by Tyco, ADT or Pentair, the party responsible for such failure would be responsible for all taxes imposed on each company as a result thereof. If such determination is not the result of actions taken by Tyco, ADT or Pentair after the 2012 Separation, then Tyco, ADT and Pentair would be responsible for any taxes imposed on any of the companies as a result of such determination in the same manner and in the same proportions as described above. Similar provisions exist in the 2007 Tax Sharing Agreement. If either of the 2007 or 2012 Separation, or internal transactions taken in anticipation thereof, were deemed taxable, the associated liability could be significant. Tyco is responsible for all of its own taxes that are not shared pursuant to the 2012 and 2007 Tax Sharing Agreements' sharing formulas. In addition, Pentair and ADT, and Medtronic and TE Connectivity are responsible for their tax liabilities that are not subject to the 2012 or 2007 Tax Sharing Agreements' sharing formula.

[0000833444-15-000032:notes:172]
[same as prior period, unchanged from 0000833444-15-000013:notes:158]

[0000833444-15-000032:notes:173]
The receivables and liabilities related to the 2012 and 2007 Tax Sharing Agreements as of March 27, 2015 and September 26, 2014, are as follows ($ in millions):

[0000833444-15-000032:notes:174]
[same as prior period, unchanged from 0000833444-15-000013:notes:160]

[0000833444-15-000032:notes:175]
[same as prior period, unchanged from 0000833444-15-000013:notes:161]


## us-gaap:InventoryDisclosureTextBlock

[0000833444-15-000032:notes:176]
[same as prior period, unchanged from 0000833444-15-000013:notes:162]

[0000833444-15-000032:notes:177]
[same as prior period, unchanged from 0000833444-15-000013:notes:163]

[0000833444-15-000032:notes:178]
|  | As of |
|  | March 27, 2015 |  | September 26, 2014 |
| Purchased materials and manufactured parts | $ | 181 |  |  | $ | 159 |  |
| Work in process | 91 |  |  | 85 |  |
| Finished goods | 405 |  |  | 381 |  |
| Inventories | $ | 677 |  |  | $ | 625 |  |

[0000833444-15-000032:notes:179]
[same as prior period, unchanged from 0000833444-15-000013:notes:165]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-15-000032:notes:180]
[same as prior period, unchanged from 0000833444-15-000013:notes:166]

[0000833444-15-000032:notes:181]
[same as prior period, unchanged from 0000833444-15-000013:notes:167]

[0000833444-15-000032:notes:182]
|  | U.S. Plans |
|  | For the Quarters Ended |  | For the Six Months Ended |
|  | March 27, 2015 |  | March 28, 2014 |  | March 27, 2015 |  | March 28, 2014 |
| Service cost | $ | 2 |  |  | $ | 2 |  |  | $ | 4 |  |  | $ | 4 |  |
| Interest cost | 9 |  |  | 9 |  |  | 18 |  |  | 18 |  |
| Expected return on plan assets | (14 | ) |  | (12 | ) |  | (28 | ) |  | (24 | ) |
| Amortization of net actuarial loss | 2 |  |  | 2 |  |  | 4 |  |  | 4 |  |
| Net periodic benefit cost | $ | (1 | ) |  | $ | 1 |  |  | $ | (2 | ) |  | $ | 2 |  |

[0000833444-15-000032:notes:183]
|  | Non-U.S. Plans |
|  | For the Quarters Ended |  | For the Six Months Ended |
|  | March 27, 2015 |  | March 28, 2014 |  | March 27, 2015 |  | March 28, 2014 |
| Service cost | $ | 3 |  |  | $ | 2 |  |  | $ | 5 |  |  | $ | 5 |  |
| Interest cost | 13 |  |  | 14 |  |  | 26 |  |  | 28 |  |
| Expected return on plan assets | (19 | ) |  | (18 | ) |  | (39 | ) |  | (37 | ) |
| Amortization of net actuarial loss | 3 |  |  | 3 |  |  | 7 |  |  | 6 |  |
| Net periodic benefit cost | $ | — |  |  | $ | 1 |  |  | $ | (1 | ) |  | $ | 2 |  |

[0000833444-15-000032:notes:184]
[same as prior period, unchanged from 0000833444-15-000013:notes:170]

[0000833444-15-000032:notes:185]
The Company's funding policy is to make contributions in accordance with the laws and customs of the various countries in which it operates and to make discretionary voluntary contributions from time to time. The Company anticipates that it will contribute at least the minimum required to its pension plans in fiscal year 2015 of $13 million for U.S. plans and $23 million for non-U.S. plans. During the quarter ended March 27, 2015, the Company made required contributions of $3 million to its U.S. pension plans and $4 million to its non-U.S. pension plans.  During the six months ended March 27, 2015, the Company made required contributions of $4 million to its U.S. pension plans and $9 million to its non-U.S. pension plans.

[0000833444-15-000032:notes:186]
[same as prior period, unchanged from 0000833444-15-000013:notes:172]


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000833444-15-000032:notes:187]
[same as prior period, unchanged from 0000833444-15-000013:notes:173]

[0000833444-15-000032:notes:188]
[same as prior period, unchanged from 0000833444-15-000013:notes:174]

[0000833444-15-000032:notes:189]
|  | As of |
|  | March 27, 2015 |  | September 26, 2014 |
| Land | $ | 33 |  |  | $ | 36 |  |
| Buildings | 408 |  |  | 411 |  |
| Subscriber systems | 2,044 |  |  | 2,210 |  |
| Machinery and equipment | 1,253 |  |  | 1,265 |  |
| Construction in progress | 93 |  |  | 90 |  |
| Accumulated depreciation | (2,615 | ) |  | (2,750 | ) |
| Property, plant and equipment, net | $ | 1,216 |  |  | $ | 1,262 |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000833444-15-000032:notes:190]
[same as prior period, unchanged from 0000833444-15-000013:notes:176]

[0000833444-15-000032:notes:191]
During fiscal 2015, the Company identified and pursued additional opportunities for cost savings through restructuring activities and workforce reductions to improve operating efficiencies across the Company's businesses. The Company expects to incur restructuring and restructuring related charges in the range of $75 million to $100 million in fiscal 2015, which does not include repositioning charges as described below.

[0000833444-15-000032:notes:192]
[same as prior period, unchanged from 0000833444-15-000013:notes:178]

[0000833444-15-000032:notes:193]
|  | For the Quarters Ended |  | For the Six Months Ended |
|  | March 27, 2015 |  | March 28, 2014 |  | March 27, 2015 |  | March 28, 2014 |
| 2015 actions | $ | 9 |  |  | $ | — |  |  | $ | 58 |  |  | $ | — |  |
| 2014 actions | 4 |  |  | 8 |  |  | 10 |  |  | 9 |  |
| 2013 and prior actions | (1 | ) |  | (1 | ) |  | 2 |  |  | 1 |  |
| Total | $ | 12 |  |  | $ | 7 |  |  | $ | 70 |  |  | $ | 10 |  |

[0000833444-15-000032:notes:194]
[same as prior period, unchanged from 0000833444-15-000013:notes:180]

[0000833444-15-000032:notes:195]
Restructuring and asset impairment charges, net, during the quarter and six months ended March 27, 2015 related to the 2015 actions are as follows ($ in millions):

[0000833444-15-000032:notes:196]
|  | For the Quarter Ended March 27, 2015 |
|  | EmployeeSeverance andBenefits |
| NA Installation & Services | $ | 4 |  |
| ROW Installation & Services | 4 |  |
| Global Products | 1 |  |
| Total | $ | 9 |  |

[0000833444-15-000032:notes:197]
|  | For the Six Months Ended March 27, 2015 |
|  | EmployeeSeverance andBenefits |  | Facility Exit and Other Charges |  | Total |
| NA Installation & Services | $ | 26 |  |  | $ | — |  |  | $ | 26 |  |
| ROW Installation & Services | 14 |  |  | 5 |  |  | 19 |  |
| Global Products | 3 |  |  | — |  |  | 3 |  |
| Corporate and Other | 10 |  |  | — |  |  | 10 |  |
| Total | $ | 53 |  |  | $ | 5 |  |  | $ | 58 |  |

[0000833444-15-000032:notes:198]
The rollforward of the reserves from September 26, 2014 to March 27, 2015 is as follows ($ in millions):

[0000833444-15-000032:notes:199]
| Balance as of September 26, 2014 | $ | — |  |
| Charges | 60 |  |
| Reversals | (2 | ) |
| Utilization | (25 | ) |
| Currency translation | (1 | ) |
| Balance as of March 27, 2015 | $ | 32 |  |

[0000833444-15-000032:notes:200]
[same as prior period, unchanged from 0000833444-15-000013:notes:186]

[0000833444-15-000032:notes:201]
Restructuring and asset impairment charges, net, during the quarters and six months ended March 27, 2015 and March 28, 2014 related to the 2014 actions are as follows ($ in millions):

[0000833444-15-000032:notes:202]
|  | For the Quarter Ended March 27, 2015 |  | For the Quarter Ended March 28, 2014 |
|  | EmployeeSeverance andBenefits |  | EmployeeSeverance andBenefits |
| NA Installation & Services | $ | — |  |  | $ | 3 |  |
| ROW Installation & Services | — |  |  | 4 |  |
| Global Products | 4 |  |  | 1 |  |
| Total | $ | 4 |  |  | $ | 8 |  |

[0000833444-15-000032:notes:203]
|  | For the Six Months Ended March 27, 2015 |  | For the Six Months Ended March 28, 2014 |
|  | EmployeeSeverance andBenefits |  | EmployeeSeverance andBenefits |
| NA Installation & Services | $ | 1 |  |  | $ | 3 |  |
| ROW Installation & Services | — |  |  | 5 |  |
| Global Products | 9 |  |  | 1 |  |
| Total | $ | 10 |  |  | $ | 9 |  |

[0000833444-15-000032:notes:204]
[same as prior period, unchanged from 0000833444-15-000013:notes:190]

[0000833444-15-000032:notes:205]
|  | EmployeeSeverance andBenefits |  | Facility Exitand OtherCharges |  | Charges Reflected in SG&A |  | Total |
| NA Installation & Services | $ | 17 |  |  | $ | — |  |  | $ | — |  |  | $ | 17 |  |
| ROW Installation & Services | 18 |  |  | 5 |  |  | — |  |  | 23 |  |
| Global Products | 12 |  |  | — |  |  | 2 |  |  | 14 |  |
| Total | $ | 47 |  |  | $ | 5 |  |  | $ | 2 |  |  | $ | 54 |  |

[0000833444-15-000032:notes:206]
| Balance as of September 26, 2014 | $ | 29 |  |
| Charges | 10 |  |
| Utilization | (14 | ) |
| Currency translation | (2 | ) |
| Balance as of March 27, 2015 | $ | 23 |  |

[0000833444-15-000032:notes:207]
[same as prior period, unchanged from 0000833444-15-000013:notes:193]

[0000833444-15-000032:notes:208]
The Company continues to maintain restructuring reserves related to actions initiated prior to fiscal 2014. The total amount of these reserves was $50 million and $70 million as of March 27, 2015 and September 26, 2014, respectively. The Company incurred $2 million and $4 million of restructuring charges, $3 million and $5 million of reversals, and utilized $6 million and $17 million for the quarters ended March 27, 2015 and March 28, 2014, respectively, related to 2013 and prior actions.  The Company incurred $5 million and $14 million of restructuring charges, $3 million and $13 million of reversals, and utilized $15 million and $41 million for the six months ended March 27, 2015 and March 28, 2014, respectively, related to 2013 and prior actions.  The remaining change in reserve during the quarters and six months ended March 27, 2015 and March 28, 2014 relates to currency translation. The aggregate remaining reserves primarily relate to facility exit costs for long-term non-cancelable lease obligations primarily within the Company's ROW Installation & Services segment.

[0000833444-15-000032:notes:209]
[same as prior period, unchanged from 0000833444-15-000013:notes:195]

[0000833444-15-000032:notes:210]
[same as prior period, unchanged from 0000833444-15-000013:notes:196]

[0000833444-15-000032:notes:211]
The Company has initiated certain global actions designed to reduce its cost structure and improve future profitability by streamlining operations and better aligning functions, which the Company refers to as repositioning actions. These actions may or may not lead to a future restructuring action. During the quarters ended March 27, 2015 and March 28, 2014, the Company recorded repositioning charges of $17 million and $9 million, respectively, and $34 million and $15 million for the six months ended March 27, 2015 and March 28, 2014, respectively, primarily related to professional fees which have been reflected in Selling, general and administrative expenses in the Consolidated Statements of Operations.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000833444-15-000032:notes:212]
A summary of the changes in each component of Accumulated other comprehensive loss, net of tax, for the six months ended March 27, 2015 and March 28, 2014 are as follows ($ in millions):

[0000833444-15-000032:notes:213]
|  | CurrencyTranslationAdjustments |  | RetirementPlans |  | Accumulated OtherComprehensive Loss |
| Balance as of September 26, 2014 | $ | (693 | ) |  | $ | (532 | ) |  | $ | (1,225 | ) |
| Other comprehensive loss before reclassifications, net of tax | (374 | ) |  | — |  |  | (374 | ) |
| Amounts reclassified from accumulated other comprehensive income, net of tax | — |  |  | 9 |  |  | 9 |  |
| Balance as of March 27, 2015 | $ | (1,067 | ) |  | $ | (523 | ) |  | $ | (1,590 | ) |

[0000833444-15-000032:notes:214]
|  | CurrencyTranslationAdjustments |  | RetirementPlans |  | Accumulated OtherComprehensive Loss |
| Balance as of September 27, 2013 | $ | (519 | ) |  | $ | (468 | ) |  | $ | (987 | ) |
| Other comprehensive loss before reclassifications, net of tax | (52 | ) |  | — |  |  | (52 | ) |
| Amounts reclassified from accumulated other comprehensive income, net of tax | — |  |  | 7 |  |  | 7 |  |
| Balance as of March 28, 2014 | $ | (571 | ) |  | $ | (461 | ) |  | $ | (1,032 | ) |


## us-gaap:ScheduleOfComprehensiveIncomeLossTableTextBlock

[0000833444-15-000032:notes:215]
Comprehensive (Loss) Income

[0000833444-15-000032:notes:216]
Comprehensive (loss) income is comprised of the following ($ in millions):

[0000833444-15-000032:notes:217]
|  | For the Quarters Ended |  | For the Six Months Ended |
|  | March 27, 2015 |  | March 28, 2014 |  | March 27, 2015 |  | March 28, 2014 |
| Net income | $ | 165 |  |  | $ | 207 |  |  | $ | 326 |  |  | $ | 479 |  |
| Foreign currency translation (1) | (176 | ) |  | (15 | ) |  | (374 | ) |  | (52 | ) |
| Amortization of net actuarial losses (2) | 5 |  |  | 5 |  |  | 11 |  |  | 10 |  |
| Income tax expense | (1 | ) |  | (1 | ) |  | (2 | ) |  | (3 | ) |
| Defined benefit and post retirement plans, net of tax | 4 |  |  | 4 |  |  | 9 |  |  | 7 |  |
| Total other comprehensive loss, net of tax | (172 | ) |  | (11 | ) |  | (365 | ) |  | (45 | ) |
| Comprehensive (loss) income | (7 | ) |  | 196 |  |  | (39 | ) |  | 434 |  |
| Less: comprehensive (loss) income attributable to noncontrolling interests | (2 | ) |  | — |  |  | (3 | ) |  | 2 |  |
| Comprehensive (loss) income attributable to Tyco ordinary shareholders | $ | (5 | ) |  | $ | 196 |  |  | $ | (36 | ) |  | $ | 432 |  |

[0000833444-15-000032:notes:218]
(1) Includes $20 million related to the net investment hedge for the quarter and six months ended March 27, 2015

[0000833444-15-000032:notes:219]
(2) Reclassified to net periodic benefit cost.  See Note 12 Retirement Plans for additional information.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-15-000032:notes:220]
[same as prior period, unchanged from 0000833444-15-000013:notes:203]

[0000833444-15-000032:notes:221]
[same as prior period, unchanged from 0000833444-15-000013:notes:204]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-15-000032:notes:222]
[same as prior period, unchanged from 0000833444-15-000013:notes:205]

[0000833444-15-000032:notes:223]
[same as prior period, unchanged from 0000833444-15-000013:notes:207]

[0000833444-15-000032:notes:224]
As a result of the Merger, the Company’s authorized share capital changed.  The authorized share capital of Tyco Ireland is $11,000,000 and €40,000, divided into 1,000,000,000 ordinary shares with a par value of $0.01 per share, 100,000,000 preferred shares with a par value of $0.01 per share and 40,000 ordinary A shares with a par value of €1.00 per share.  The authorized share capital includes 40,000 ordinary A shares with a par value of €1.00 per share in order to satisfy statutory requirements for the incorporation of all Irish public limited companies. Tyco Ireland may issue shares subject to the maximum prescribed by its authorized share capital contained in its memorandum of association. In connection with the Merger, Tyco Ireland canceled all the outstanding treasury shares, including shares held by subsidiaries, with an offsetting reduction in Additional paid in capital.

[0000833444-15-000032:notes:225]
[same as prior period, unchanged from 0000833444-15-000013:notes:209]

[0000833444-15-000032:notes:226]
Tyco Ireland issued one ordinary share in exchange for each common share of Tyco Switzerland to the former shareholders of Tyco Switzerland.  All Tyco Ireland ordinary shares issued at the effective time of the Merger were issued as fully paid-up and non-assessable.

[0000833444-15-000032:notes:227]
[same as prior period, unchanged from 0000833444-15-000013:notes:211]

[0000833444-15-000032:notes:228]
On March 4, 2015, the Board of Directors approved a quarterly dividend of $0.205 per share payable on May 20, 2015 to shareholders of record on April 24, 2015.

[0000833444-15-000032:notes:229]
On March 5, 2014, the Company's shareholders approved an annual cash dividend of $0.72 per ordinary share.  Payment of the dividend was made in four quarterly installments of $0.18 from May 2014 through February 2015.  As a result, during the quarter ended March 28, 2014, the Company recorded an accrued dividend of $332 million within Accrued and other current liabilities and a corresponding reduction to Additional paid in capital on the Company's Consolidated Balance Sheet.

[0000833444-15-000032:notes:230]
[same as prior period, unchanged from 0000833444-15-000013:notes:213]

[0000833444-15-000032:notes:231]
[same as prior period, unchanged from 0000833444-15-000013:notes:214]

[0000833444-15-000032:notes:232]
[same as prior period, unchanged from 0000833444-15-000013:notes:215]

[0000833444-15-000032:notes:233]
The Company's Board of Directors approved $1.75 billion and $1 billion share repurchase programs in March 2014 and September 2014, respectively.  During the quarter ended December 26, 2014, the Company repurchased a total of approximately 10 million shares for approximately $417 million which completed the $1.75 billion share repurchase program.  No shares were repurchased during the quarter ended March 27, 2015.  As of March 27, 2015, a total of approximately $1 billion in share repurchase authority remained outstanding.
