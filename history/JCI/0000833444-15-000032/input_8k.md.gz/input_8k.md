# JCI 8-K — 0000833444-15-000028 filed 2015-04-24

## item codes, every 8-K on or before 2015-04-24

- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2015-04-24

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-15-000028:8k_2_02:1]
EX-99.1
2
exhibit991-q215.htm
EXHIBIT 99.1

[0000833444-15-000028:8k_2_02:2]
Exhibit 99.1 - Q215

[0000833444-15-000028:8k_2_02:3]
| Investor Contacts: |  | Media Contact: |  |
| Antonella Franzen |  | Stephen Wasdick |  |
| +1-609-720-4665 |  | +1-609-806-2262 |  |
| afranzen@tyco.com |  | swasdick@tyco.com |  |
| Leila Peters |  |  |  |
| +1-609-720-4545 |  |  |  |
| lpeters@tyco.com |  |  |  |

[0000833444-15-000028:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-15-000028:8k_2_02:5]
TYCO REPORTS SECOND QUARTER 2015 EARNINGS FROM CONTINUING OPERATIONS

[0000833444-15-000028:8k_2_02:6]
BEFORE SPECIAL ITEMS OF $0.55 PER SHARE AND GAAP EARNINGS OF $0.43 PER SHARE

[0000833444-15-000028:8k_2_02:7]
| • | Excluding the impact of foreign currency exchange rates, revenue of $2.4 billion increases 4%, with 2% organic growth and 2% growth from acquisitions |

[0000833444-15-000028:8k_2_02:8]
| • | Diluted EPS from continuing operations before special items increases 17% |

[0000833444-15-000028:8k_2_02:9]
| • | As previously announced, during the quarter the company completes the acquisition of Industrial Safety Technologies (IST), a global leader in gas and flame detection |

[0000833444-15-000028:8k_2_02:10]
| • | The company's Board of Directors approves a 14% increase in the company's quarterly dividend to $0.205 per share, as previously announced |

[0000833444-15-000028:8k_2_02:11]
| • | Provides guidance for third quarter 2015 EPS before special items of $0.55 - $0.57 |

[0000833444-15-000028:8k_2_02:12]
| • | Updates guidance for full year 2015 EPS before special items from a range of $2.30 - $2.40 previously to $2.23 - $2.27, primarily related to headwinds from foreign currency exchange rates and the decline in the oil and gas end market |

[0000833444-15-000028:8k_2_02:13]
(Income and EPS amounts are attributable to Tyco ordinary shareholders)

[0000833444-15-000028:8k_2_02:14]
($ millions, except per-share amounts)

[0000833444-15-000028:8k_2_02:15]
(All prior periods have been recast to reflect certain businesses as discontinued operations)

[0000833444-15-000028:8k_2_02:16]
|  |  | Q2 2015 |  | Q2 2014 |  | % Change |  |
| Revenue |  | $ | 2,430 |  |  | $ | 2,480 |  |  | (2 | )% |  |
| Segment Operating Income |  | $ | 289 |  |  | $ | 320 |  |  | (10 | )% |  |
| Operating Income |  | $ | 221 |  |  | $ | 259 |  |  | (15 | )% |  |
| Income from Continuing Operations |  | $ | 183 |  |  | $ | 192 |  |  | (5 | )% |  |
| Diluted EPS from Continuing Operations |  | $ | 0.43 |  |  | $ | 0.41 |  |  | 5 | % |  |
| Special Items |  | $ | (0.12 | ) |  | $ | (0.06 | ) |  |  |  |
| Segment Operating Income Before Special Items |  | $ | 331 |  |  | $ | 346 |  |  | (4 | )% |  |
| Income from Continuing Ops Before Special Items |  | $ | 234 |  |  | $ | 221 |  |  | 6 | % |  |
| Diluted EPS from Continuing Ops Before Special Items |  | $ | 0.55 |  |  | $ | 0.47 |  |  | 17 | % |  |

[0000833444-15-000028:8k_2_02:17]
CORK, Ireland, April 24, 2015 - Tyco (NYSE: TYC) today reported $0.43 in GAAP diluted earnings per share (EPS) from continuing operations for the fiscal second quarter of 2015 and diluted EPS from continuing operations before special items of $0.55.  Revenue of $2.4 billion in the quarter decreased 2% versus the prior year due to a 6% negative impact of the stronger U.S. dollar against foreign currencies.  Organic revenue grew 2% in the quarter, led by Global Products with a 7% increase.  Installation revenue grew 1% organically and service revenue was relatively flat.  Acquisitions contributed 2 percentage points of growth.

[0000833444-15-000028:8k_2_02:18]
“We continued to deliver strong profitability in the second quarter, with earnings per share growing 17% year over year before special items and segment operating margin improving 50 basis points on a normalized basis,” said Tyco Chief Executive Officer George R. Oliver.  “Excluding the impact of foreign currency exchange rates, we grew revenue 4% in the quarter through a combination of organic growth and acquisitions.

[0000833444-15-000028:8k_2_02:19]
"Looking ahead to the full year, despite headwinds from the stronger U.S. dollar and the decline in the oil and gas sector, we expect to deliver earnings per share growth before special items of 12% to 14%.  The investments we are making to expand our capabilities and technology, along with our efforts to further streamline our operations, position us well to deliver strong double-digit earnings growth this year and give us confidence in our ability to transition to a growth company and deliver sustained double-digit earnings growth as we enter our next three-year plan,” Mr. Oliver added.

[0000833444-15-000028:8k_2_02:20]
Organic revenue, free cash flow, adjusted free cash flow, operating income, segment operating income, and diluted EPS from continuing operations before special items are non-GAAP financial measures and are described below.  For a reconciliation of these non-GAAP measures, see the attached tables. Additional schedules as well as second quarter review slides can be found in the Investor Relations section of Tyco’s website at http://investors.tyco.com.

[0000833444-15-000028:8k_2_02:21]
SEGMENT RESULTS

[0000833444-15-000028:8k_2_02:22]
The financial results presented in the tables below are in accordance with GAAP unless otherwise indicated. All dollar amounts are pre-tax and stated in millions.  Certain businesses have been classified as discontinued operations.  The revenue and operating income results shown below have been adjusted to reflect these changes in all periods presented.  All comparisons are to the fiscal second quarter of 2014 unless otherwise indicated.

[0000833444-15-000028:8k_2_02:23]
North America Installation & Services

[0000833444-15-000028:8k_2_02:24]
|  |  | Q2 2015 |  | Q2 2014 |  | % Change |  |
| Revenue |  | $ | 944 |  |  | $ | 939 |  |  | 1 | % |  |
| Operating Income |  | $ | 119 |  |  | $ | 99 |  |  | 20 | % |  |
| Operating Margin |  | 12.6 | % |  | 10.5 | % |  |  |  |
| Special Items |  | $ | (6 | ) |  | $ | (18 | ) |  |  |  |
| Operating Income Before Special Items |  | $ | 125 |  |  | $ | 117 |  |  | 7 | % |  |
| Operating Margin Before Special Items |  | 13.2 | % |  | 12.5 | % |  |  |  |

[0000833444-15-000028:8k_2_02:25]
Revenue of $944 million increased 1%, as organic growth was partially offset by the weakening of the Canadian dollar.  Organic revenue growth of 2% resulted almost entirely from installation growth.  Backlog of $2.5 billion increased 3% year over year and was relatively flat on a quarter sequential basis, excluding the impact of foreign currency.

[0000833444-15-000028:8k_2_02:26]
Operating income for the quarter was $119 million and the operating margin was 12.6%. Special items of $6 million consisted primarily of restructuring charges.  Before special items, operating income was $125 million and the operating margin improved 70 basis points to 13.2%.  Improved execution and the benefit of restructuring and productivity initiatives drove the operating margin expansion.

[0000833444-15-000028:8k_2_02:27]
Rest of World Installation & Services

[0000833444-15-000028:8k_2_02:28]
|  |  | Q2 2015 |  | Q2 2014 |  | % Change |  |
| Revenue |  | $ | 847 |  |  | $ | 936 |  |  | (10 | )% |  |
| Operating Income |  | $ | 60 |  |  | $ | 114 |  |  | (47 | )% |  |
| Operating Margin |  | 7.1 | % |  | 12.2 | % |  |  |  |
| Special Items |  | $ | (30 | ) |  | $ | (6 | ) |  |  |  |
| Operating Income Before Special Items |  | $ | 90 |  |  | $ | 120 |  |  | (25 | )% |  |
| Operating Margin Before Special Items |  | 10.6 | % |  | 12.8 | % |  |  |  |

[0000833444-15-000028:8k_2_02:29]
Revenue of $847 million decreased 10% compared to the prior year, driven by an 11% unfavorable impact related to changes in foreign currency exchange rates.  Organic revenue growth was relatively flat, as service revenue growth of 1% was offset by a 1% decline in installation revenue.  Acquisitions contributed 1% to revenue growth.  Backlog of $2.0 billion decreased 2% year over year and 1% on a quarter sequential basis, excluding the impact of foreign currency.

[0000833444-15-000028:8k_2_02:30]
Operating income for the quarter was $60 million and the operating margin was 7.1%.  Special items of $30 million consisted primarily of charges related to restructuring and an expected loss on the divestiture of our majority interest in a joint venture in China.  Before special items, operating income was $90 million and the operating margin was 10.6%.  The prior year's operating income included a previously disclosed $21 million insurance recovery.  This recovery benefited the prior year operating margin by 220 basis points.  On a normalized basis, the operating margin was flat on a year-over-year basis as the benefit of restructuring and productivity initiatives was offset by the mix of geographies contributing to growth.

[0000833444-15-000028:8k_2_02:31]
Global Products

[0000833444-15-000028:8k_2_02:32]
|  |  | Q2 2015 |  | Q2 2014 |  | % Change |  |
| Revenue |  | $ | 639 |  |  | $ | 605 |  |  | 6 | % |  |
| Operating Income |  | $ | 110 |  |  | $ | 107 |  |  | 3 | % |  |
| Operating Margin |  | 17.2 | % |  | 17.7 | % |  |  |  |
| Special Items |  | $ | (6 | ) |  | $ | (2 | ) |  |  |  |
| Operating Income Before Special Items |  | $ | 116 |  |  | $ | 109 |  |  | 6 | % |  |
| Operating Margin Before Special Items |  | 18.2 | % |  | 18.0 | % |  |  |  |

[0000833444-15-000028:8k_2_02:33]
Revenue of $639 million increased 6% in the quarter.  Organic revenue growth of 7% was driven by strong growth in Life Safety Products and Security Products.  Organic growth included a 3 percentage point benefit from increased shipments of Scott Safety Air-Pak X3s compared to the prior year, when shipments were delayed to the third quarter due to regulatory matters.  Acquisitions contributed 4 percentage points of growth, which was more than offset by a 6% decrease related to changes in foreign currency exchange rates.

[0000833444-15-000028:8k_2_02:34]
Operating income for the quarter was $110 million and the operating margin was 17.2%.  Special items of $6 million consisted primarily of restructuring charges.  Before special items, operating income was $116 million and the operating margin increased 20 basis points to 18.2%.  Operating leverage on increased revenue and productivity benefits were partially offset by non-cash purchase accounting related to the amortization of intangible assets, and incremental investments in research and development, which negatively impacted the operating margin by 30 basis points and 70 basis points, respectively.

[0000833444-15-000028:8k_2_02:35]
OTHER ITEMS

[0000833444-15-000028:8k_2_02:36]
| • | Cash from operating activities was $167 million and free cash flow was $107 million, which included a cash outflow of $44 million from special items primarily related to restructuring and repositioning activities. Adjusted free cash flow for the quarter was $151 million. The company completed the quarter with $432 million in cash and cash equivalents. |

[0000833444-15-000028:8k_2_02:37]
| • | Corporate expense for the quarter was $51 million before special items and $68 million on a GAAP basis, which includes restructuring and repositioning charges. |

[0000833444-15-000028:8k_2_02:38]
| • | The tax rate before special items was 11.5% for the quarter, due to a one-time benefit recorded in the quarter. |

[0000833444-15-000028:8k_2_02:39]
| • | As previously announced, during the quarter the company completed the acquisition of IST, a global leader in gas and flame detection. On an annualized basis, the addition of IST to Tyco's Global Products segment is expected to generate approximately $140 million in revenue. |

[0000833444-15-000028:8k_2_02:40]
| • | As previously disclosed, the company issued 500 million euros of 1.375% notes due February 25, 2025. |

[0000833444-15-000028:8k_2_02:41]
ABOUT TYCO

[0000833444-15-000028:8k_2_02:42]
Tyco (NYSE: TYC) is the world’s largest pure-play fire protection and security company. Tyco provides more than three million customers around the globe with the latest fire protection and security products and services. A company with $10+ billion in annual revenue, Tyco has over 57,000 employees in more than 900 locations across 50 countries serving various end markets, including commercial, institutional, governmental, retail, industrial, energy, residential and small business. For more information, visit www.tyco.com.

[0000833444-15-000028:8k_2_02:43]
CONFERENCE CALL AND WEBCAST

[0000833444-15-000028:8k_2_02:44]
Management will discuss the company’s second quarter results for 2015 during a conference call and webcast today beginning at 8:00 a.m. Eastern time (ET).  Today’s conference call for investors can be accessed in the following ways:

[0000833444-15-000028:8k_2_02:45]
| • | Live via webcast - through the Investor Relations section of Tyco’s website at http://investors.tyco.com, |

[0000833444-15-000028:8k_2_02:46]
| • | Live via telephone (for “listen-only” participants and those who would like to ask a question) - by dialing 800-857-9797 (in the United States) or 517-308-9029 (outside the United States), passcode “Tyco”, |

[0000833444-15-000028:8k_2_02:47]
| • | Replay via telephone - by dialing 800-568-5006 (in the United States) or 402-998-0083 (outside the United States), passcode 3077, from 10:00 a.m. (ET) on April 24, 2015, until 11:59 p.m. (ET) on May 1, 2015, and |

[0000833444-15-000028:8k_2_02:48]
| • | Replay via webcast - through the “Presentations & Webcasts” link on the Investor Relations section of Tyco’s website: http://investors.tyco.com. |

[0000833444-15-000028:8k_2_02:49]
NON-GAAP MEASURES

[0000833444-15-000028:8k_2_02:50]
Organic revenue, free cash flow (outflow) (FCF), and income from continuing operations, earnings per share (EPS) from continuing operations, operating income and segment operating income, in each case “before special items,” are non-GAAP measures and should not be considered replacements for GAAP results.

[0000833444-15-000028:8k_2_02:51]
Organic revenue is a useful measure used by the company to measure the underlying results and trends in the business. The difference between reported net revenue (the most comparable GAAP measure) and organic revenue (the non-GAAP measure) consists of the impact from foreign currency, acquisitions and divestitures, and other changes that either do not reflect the underlying results and trends of the Company’s businesses or are not completely under management’s control. There are limitations associated with organic revenue, such as the fact that, as presented herein, the metric may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using organic revenue in combination with the GAAP numbers. Organic revenue may be used as a component in the company’s incentive compensation plans.

[0000833444-15-000028:8k_2_02:52]
FCF is a useful measure of the company's cash that permits management and investors to gain insight into the number that management employs to measure cash that is free from any significant existing obligation and is available to service debt and make investments. The difference between Cash Flows from Operating Activities (the most comparable GAAP measure) and FCF (the non-GAAP measure) consists mainly of significant cash flows that the company believes are useful to identify. It, or a measure that is based on it, may be used as a component in the company's incentive compensation plans. The difference reflects the impact from:

[0000833444-15-000028:8k_2_02:53]
| • | net capital expenditures, |

[0000833444-15-000028:8k_2_02:54]
| • | dealer generated accounts and bulk accounts purchased, |

[0000833444-15-000028:8k_2_02:55]
| • | cash paid for purchase accounting and holdback liabilities, and |

[0000833444-15-000028:8k_2_02:56]
| • | voluntary pension contributions. |

[0000833444-15-000028:8k_2_02:57]
Capital expenditures and dealer generated and bulk accounts purchased are subtracted because they represent long-term investments that are required for normal business activities. Cash paid for purchase accounting and holdback liabilities is subtracted because these cash outflows are not available for general corporate uses. Voluntary pension contributions are added because this activity is driven by economic financing decisions rather than operating activity. In addition, the company presents adjusted free cash flow, which is free cash flow, adjusted to exclude the cash impact of the special items highlighted below. This number provides information to investors regarding the cash impact of certain items management believes are useful to identify, as described below.

[0000833444-15-000028:8k_2_02:58]
The limitation associated with using these cash flow metrics is that they adjust for cash items that are ultimately within management's and the Board of Directors' discretion to direct and therefore may imply that there is less or more cash that is available for the company's programs than the most comparable GAAP measure. Furthermore, these non-GAAP metrics may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using FCF in combination with the GAAP cash flow numbers.

[0000833444-15-000028:8k_2_02:59]
The company has presented its income and EPS from continuing operations, operating income and segment operating income before special items. Special items include charges and gains related to divestitures, acquisitions, restructurings, impairments, certain changes to accounting methodologies, legacy legal and tax charges and other income or charges that may mask the underlying operating results and/or business trends of the company or business segment, as applicable. The company utilizes these measures to assess overall operating performance and segment level core operating performance,

[0000833444-15-000028:8k_2_02:60]
as well as to provide insight to management in evaluating overall and segment operating plan execution and underlying market conditions. The Company also presents its effective tax rate as adjusted for special items for consistency, and presents corporate expense excluding special items. One or more of these measures may be used as components in the company's incentive compensation plans. These measures are useful for investors because they may permit more meaningful comparisons of the company's underlying operating results and business trends between periods. The difference between income and EPS from continuing operations before special items and income and EPS from continuing operations (the most comparable GAAP measures) consists of the impact of the special items noted above on the applicable GAAP measure. The limitation of these measures is that they exclude the impact (which may be material) of items that increase or decrease the company's reported GAAP metrics, and these non-GAAP metrics may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using the non-GAAP measures in combination with the most comparable GAAP measures in order to better understand the amounts, character and impact of any increase or decrease on reported results.

[0000833444-15-000028:8k_2_02:61]
The company provides general corporate services to its segments and those costs are reported in the "Corporate and Other" segment. This segment's operating income (loss) is presented as "Corporate Expense." Segment Operating Income represents Tyco’s operating income excluding the Corporate and Other segment, and reflects the results of Tyco’s three operating segments. Segment Operating Income before special items reflects GAAP operating income adjusted for the special items noted in the paragraph above.

[0000833444-15-000028:8k_2_02:62]
FORWARD-LOOKING STATEMENTS

[0000833444-15-000028:8k_2_02:63]
# # #

[0000833444-15-000028:8k_2_02:64]
TYCO INTERNATIONAL PLC

[0000833444-15-000028:8k_2_02:65]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0000833444-15-000028:8k_2_02:66]
(in millions, except per share data)

[0000833444-15-000028:8k_2_02:67]
(Unaudited)

[0000833444-15-000028:8k_2_02:68]
|  |  | Quarters Ended |  | Six Months Ended |
|  |  | March 27, 2015 |  | March 28, 2014 |  | March 27, 2015 |  | March 28, 2014 |
| Revenue from product sales |  | $ | 1,458 |  |  | $ | 1,464 |  |  | $ | 2,946 |  |  | $ | 2,930 |  |
| Service revenue |  | 972 |  |  | 1,016 |  |  | 1,962 |  |  | 2,039 |  |
| Net revenue |  | 2,430 |  |  | 2,480 |  |  | 4,908 |  |  | 4,969 |  |
| Cost of product sales |  | 999 |  |  | 1,003 |  |  | 2,021 |  |  | 2,001 |  |
| Cost of services |  | 550 |  |  | 575 |  |  | 1,097 |  |  | 1,150 |  |
| Selling, general and administrative expenses |  | 648 |  |  | 635 |  |  | 1,300 |  |  | 1,205 |  |
| Separation costs |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Restructuring and asset impairment charges, net |  | 12 |  |  | 7 |  |  | 70 |  |  | 10 |  |
| Operating income |  | 221 |  |  | 259 |  |  | 420 |  |  | 602 |  |
| Interest income |  | 4 |  |  | 3 |  |  | 7 |  |  | 6 |  |
| Interest expense |  | (25 | ) |  | (25 | ) |  | (49 | ) |  | (49 | ) |
| Other (expense) income, net |  | (1 | ) |  | (1 | ) |  | 3 |  |  | (2 | ) |
| Income from continuing operations before income taxes |  | 199 |  |  | 236 |  |  | 381 |  |  | 557 |  |
| Income tax expense |  | (18 | ) |  | (39 | ) |  | (37 | ) |  | (109 | ) |
| Equity loss in earnings of unconsolidated subsidiaries |  | — |  |  | (5 | ) |  | — |  |  | (9 | ) |
| Income from continuing operations |  | 181 |  |  | 192 |  |  | 344 |  |  | 439 |  |
| (Loss) income from discontinued operations, net of income taxes |  | (16 | ) |  | 15 |  |  | (18 | ) |  | 40 |  |
| Net income |  | 165 |  |  | 207 |  |  | 326 |  |  | 479 |  |
| Less: noncontrolling interest in subsidiaries net (loss) income |  | (2 | ) |  | — |  |  | (3 | ) |  | 2 |  |
| Net income attributable to Tyco ordinary shareholders |  | $ | 167 |  |  | $ | 207 |  |  | $ | 329 |  |  | $ | 477 |  |
| Amounts attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 183 |  |  | $ | 192 |  |  | $ | 347 |  |  | $ | 437 |  |
| (Loss) income from discontinued operations |  | (16 | ) |  | 15 |  |  | (18 | ) |  | 40 |  |
| Net income attributable to Tyco ordinary shareholders |  | $ | 167 |  |  | $ | 207 |  |  | $ | 329 |  |  | $ | 477 |  |
| Basic earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.44 |  |  | $ | 0.41 |  |  | $ | 0.83 |  |  | $ | 0.94 |  |
| (Loss) income from discontinued operations |  | (0.04 | ) |  | 0.04 |  |  | (0.05 | ) |  | 0.09 |  |
| Net income attributable to Tyco ordinary shareholders |  | $ | 0.40 |  |  | $ | 0.45 |  |  | $ | 0.78 |  |  | $ | 1.03 |  |
| Diluted earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.43 |  |  | $ | 0.41 |  |  | $ | 0.81 |  |  | $ | 0.93 |  |
| (Loss) income from discontinued operations |  | (0.04 | ) |  | 0.03 |  |  | (0.04 | ) |  | 0.08 |  |
| Net income attributable to Tyco ordinary shareholders |  | $ | 0.39 |  |  | $ | 0.44 |  |  | $ | 0.77 |  |  | $ | 1.01 |  |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | 420 |  |  | 461 |  |  | 420 |  |  | 462 |  |
| Diluted |  | 427 |  |  | 469 |  |  | 427 |  |  | 470 |  |

[0000833444-15-000028:8k_2_02:69]
Note: These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K filed on November 14, 2014 for the fiscal year ended September 26, 2014 and Quarterly Report on Form 10-Q filed on January 30, 2015 for the quarter ended December 26, 2014.

[0000833444-15-000028:8k_2_02:70]
TYCO INTERNATIONAL PLC

[0000833444-15-000028:8k_2_02:71]
RESULTS OF SEGMENTS

[0000833444-15-000028:8k_2_02:72]
(in millions)

[0000833444-15-000028:8k_2_02:73]
(Unaudited)

[0000833444-15-000028:8k_2_02:74]
|  |  | Quarters Ended |  |  |  | Six Months Ended |  |  |
|  |  | March 27, 2015 |  |  |  | March 28, 2014 |  |  |  | March 27, 2015 |  |  |  | March 28, 2014 |  |  |
| Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| NA Installation & Services |  | $ | 944 |  |  |  |  |  | $ | 939 |  |  |  |  |  | $ | 1,895 |  |  |  |  |  | $ | 1,896 |  |  |  |  |
| ROW Installation & Services |  | 847 |  |  |  |  |  | 936 |  |  |  |  |  | 1,763 |  |  |  |  |  | 1,903 |  |  |  |  |
| Global Products |  | 639 |  |  |  |  |  | 605 |  |  |  |  |  | 1,250 |  |  |  |  |  | 1,170 |  |  |  |  |
| Total Net Revenue |  | $ | 2,430 |  |  |  |  |  | $ | 2,480 |  |  |  |  |  | $ | 4,908 |  |  |  |  |  | $ | 4,969 |  |  |  |  |
| Operating Income and Margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| NA Installation & Services |  | $ | 119 |  |  | 12.6 | % |  | $ | 99 |  |  | 10.5 | % |  | $ | 224 |  |  | 11.8 | % |  | $ | 216 |  |  | 11.4 | % |
| ROW Installation & Services |  | 60 |  |  | 7.1 | % |  | 114 |  |  | 12.2 | % |  | 130 |  |  | 7.4 | % |  | 208 |  |  | 10.9 | % |
| Global Products |  | 110 |  |  | 17.2 | % |  | 107 |  |  | 17.7 | % |  | 208 |  |  | 16.6 | % |  | 193 |  |  | 16.5 | % |
| Corporate and Other |  | (68 | ) |  | N/M |  |  | (61 | ) |  | N/M |  |  | (142 | ) |  | N/M |  |  | (15 | ) |  | N/M |  |
| Operating Income and Margin |  | $ | 221 |  |  | 9.1 | % |  | $ | 259 |  |  | 10.4 | % |  | $ | 420 |  |  | 8.6 | % |  | $ | 602 |  |  | 12.1 | % |

[0000833444-15-000028:8k_2_02:75]
TYCO INTERNATIONAL PLC

[0000833444-15-000028:8k_2_02:76]
CONSOLIDATED BALANCE SHEETS

[0000833444-15-000028:8k_2_02:77]
(in millions)

[0000833444-15-000028:8k_2_02:78]
(Unaudited)

[0000833444-15-000028:8k_2_02:79]
|  |  | March 27, 2015 |  | September 26, 2014 |
| Assets |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 432 |  |  | $ | 892 |  |
| Accounts receivable, net |  | 1,643 |  |  | 1,734 |  |
| Inventories |  | 677 |  |  | 625 |  |
| Prepaid expenses and other current assets |  | 867 |  |  | 1,051 |  |
| Deferred income taxes |  | 304 |  |  | 304 |  |
| Assets held for sale |  | 155 |  |  | 180 |  |
| Total Current Assets |  | 4,078 |  |  | 4,786 |  |
| Property, plant and equipment, net |  | 1,216 |  |  | 1,262 |  |
| Goodwill |  | 4,265 |  |  | 4,122 |  |
| Intangible assets, net |  | 908 |  |  | 712 |  |
| Other assets |  | 1,228 |  |  | 927 |  |
| Total Assets |  | $ | 11,695 |  |  | $ | 11,809 |  |
| Liabilities and Equity |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |
| Loans payable and current maturities of long-term debt |  | $ | 278 |  |  | $ | 20 |  |
| Accounts payable |  | 735 |  |  | 825 |  |
| Accrued and other current liabilities |  | 1,959 |  |  | 2,114 |  |
| Deferred revenue |  | 405 |  |  | 400 |  |
| Liabilities held for sale |  | 102 |  |  | 118 |  |
| Total Current Liabilities |  | 3,479 |  |  | 3,477 |  |
| Long-term debt |  | 1,732 |  |  | 1,443 |  |
| Deferred revenue |  | 315 |  |  | 335 |  |
| Other liabilities |  | 1,927 |  |  | 1,871 |  |
| Total Liabilities |  | 7,453 |  |  | 7,126 |  |
| Redeemable noncontrolling interest in businesses held for sale |  | 12 |  |  | 13 |  |
| Total Tyco shareholders' equity |  | 4,181 |  |  | 4,647 |  |
| Nonredeemable noncontrolling interest |  | 49 |  |  | 23 |  |
| Total Equity |  | 4,230 |  |  | 4,670 |  |
| Total Liabilities, Redeemable Noncontrolling Interest and Equity |  | $ | 11,695 |  |  | $ | 11,809 |  |

[0000833444-15-000028:8k_2_02:80]
Note: These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K filed on November 14, 2014 for the fiscal year ended September 26, 2014 and Quarterly Report on Form 10-Q filed on January 30, 2015 for the quarter ended December 26, 2014.

[0000833444-15-000028:8k_2_02:81]
TYCO INTERNATIONAL PLC

[0000833444-15-000028:8k_2_02:82]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000833444-15-000028:8k_2_02:83]
(in millions)

[0000833444-15-000028:8k_2_02:84]
(Unaudited)

[0000833444-15-000028:8k_2_02:85]
|  |  | For the Quarters Ended |  | For the Six Months Ended |
|  |  | March 27, 2015 |  | March 28, 2014 |  | March 27, 2015 |  | March 28, 2014 |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Tyco ordinary shareholders |  | $ | 167 |  |  | $ | 207 |  |  | $ | 329 |  |  | $ | 477 |  |
| Noncontrolling interest in subsidiaries net (loss) income |  | (2 | ) |  | — |  |  | (3 | ) |  | 2 |  |
| Income (loss) from discontinued operations, net of income taxes |  | 16 |  |  | (15 | ) |  | 18 |  |  | (40 | ) |
| Income from continuing operations |  | 181 |  |  | 192 |  |  | 344 |  |  | 439 |  |
| Adjustments to reconcile net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  | 81 |  |  | 87 |  |  | 171 |  |  | 180 |  |
| Non-cash compensation expense |  | 15 |  |  | 16 |  |  | 30 |  |  | 31 |  |
| Deferred income taxes |  | (23 | ) |  | 5 |  |  | (29 | ) |  | 56 |  |
| Provision for losses on accounts receivable and inventory |  | 18 |  |  | 13 |  |  | 34 |  |  | 23 |  |
| Legacy legal matters |  | — |  |  | — |  |  | — |  |  | (92 | ) |
| Other non-cash items |  | 25 |  |  | 10 |  |  | 23 |  |  | 17 |  |
| Changes in assets and liabilities, net of the effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | 29 |  |  | 13 |  |  | 22 |  |  | 36 |  |
| Contracts in progress |  | (38 | ) |  | (17 | ) |  | (30 | ) |  | (5 | ) |
| Inventories |  | (21 | ) |  | 6 |  |  | (64 | ) |  | (24 | ) |
| Prepaid expenses and other assets |  | (41 | ) |  | 12 |  |  | (44 | ) |  | (40 | ) |
| Accounts payable |  | (46 | ) |  | (7 | ) |  | (87 | ) |  | (48 | ) |
| Accrued and other liabilities |  | (31 | ) |  | (113 | ) |  | (64 | ) |  | (220 | ) |
| Deferred revenue |  | 42 |  |  | 50 |  |  | 4 |  |  | 11 |  |
| Other |  | (24 | ) |  | 3 |  |  | (48 | ) |  | 2 |  |
| Net cash provided by operating activities |  | 167 |  |  | 270 |  |  | 262 |  |  | 366 |  |
| Net cash provided by discontinued operating activities |  | 2 |  |  | 51 |  |  | 3 |  |  | 77 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures |  | (57 | ) |  | (72 | ) |  | (123 | ) |  | (135 | ) |
| Proceeds from disposal of assets |  | 2 |  |  | 2 |  |  | 3 |  |  | 6 |  |
| Acquisition of businesses, net of cash acquired |  | (373 | ) |  | — |  |  | (525 | ) |  | (54 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases |  | (4 | ) |  | (5 | ) |  | (8 | ) |  | (16 | ) |
| Divestiture of business, net of cash divested |  | (1 | ) |  | — |  |  | (1 | ) |  | — |  |
| Sales and maturities of investments |  | 4 |  |  | 29 |  |  | 279 |  |  | 141 |  |
| Purchases of investments |  | (287 | ) |  | (8 | ) |  | (288 | ) |  | (40 | ) |
| (Increase) decrease in restricted cash |  | 6 |  |  | 2 |  |  | (39 | ) |  | 6 |  |
| Other |  | — |  |  | (2 | ) |  | (1 | ) |  | — |  |
| Net cash used in investing activities |  | (710 | ) |  | (54 | ) |  | (703 | ) |  | (92 | ) |
| Net cash used in discontinued investing activities |  | — |  |  | (28 | ) |  | (15 | ) |  | (57 | ) |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short-term debt |  | — |  |  | 405 |  |  | — |  |  | 715 |  |
| Repayment of short-term debt |  | (1 | ) |  | (565 | ) |  | (1 | ) |  | (715 | ) |
| Proceeds from issuance of long-term debt |  | 567 |  |  | — |  |  | 567 |  |  | — |  |
| Proceeds from exercise of share options |  | 24 |  |  | 22 |  |  | 57 |  |  | 62 |  |
| Dividends paid |  | (76 | ) |  | (74 | ) |  | (151 | ) |  | (148 | ) |
| Repurchase of ordinary shares |  | — |  |  | — |  |  | (417 | ) |  | (250 | ) |
| Transfer from (to) discontinued operations |  | 2 |  |  | 23 |  |  | (12 | ) |  | 20 |  |
| Payment of contingent consideration |  | — |  |  | — |  |  | (23 | ) |  | — |  |
| Other |  | (8 | ) |  | (1 | ) |  | (23 | ) |  | (10 | ) |
| Net cash provided by (used in) financing activities |  | 508 |  |  | (190 | ) |  | (3 | ) |  | (326 | ) |
| Net cash (used in) provided by discontinued financing activities |  | (2 | ) |  | (23 | ) |  | 12 |  |  | (20 | ) |
| Effect of currency translation on cash |  | (6 | ) |  | (9 | ) |  | (16 | ) |  | (16 | ) |
| Net decrease in cash and cash equivalents |  | (41 | ) |  | 17 |  |  | (460 | ) |  | (68 | ) |
| Cash and cash equivalents at beginning of period |  | 473 |  |  | 478 |  |  | 892 |  |  | 563 |  |
| Cash and cash equivalents at end of period |  | $ | 432 |  |  | $ | 495 |  |  | $ | 432 |  |  | $ | 495 |  |

[0000833444-15-000028:8k_2_02:86]
| Reconciliation to "Free Cash Flow": |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 167 |  |  | $ | 270 |  |  | $ | 262 |  |  | $ | 366 |  |
| Capital expenditures, net |  | (55 | ) |  | (70 | ) |  | (120 | ) |  | (129 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases |  | (4 | ) |  | (5 | ) |  | (8 | ) |  | (16 | ) |
| Payment of contingent consideration |  | (1 | ) |  | — |  |  | (24 | ) |  | — |  |
| Free Cash Flow |  | $ | 107 |  |  | $ | 195 |  |  | $ | 110 |  |  | $ | 221 |  |
| Reconciliation to "Adjusted Free Cash Flow": |  |  |  |  |  |  |  |  |
| CIT settlement |  | $ | — |  |  | $ | 43 |  |  | $ | — |  |  | $ | (17 | ) |
| IRS litigation costs |  | — |  |  | — |  |  | — |  |  | 1 |  |
| Separation costs |  | — |  |  | 22 |  |  | 3 |  |  | 44 |  |
| Restructuring and repositioning costs |  | 37 |  |  | 27 |  |  | 71 |  |  | 56 |  |
| Environmental remediation payments |  | 1 |  |  | 23 |  |  | 8 |  |  | 54 |  |
| Legal settlements |  | — |  |  | — |  |  | (12 | ) |  | — |  |
| Net asbestos payments |  | 3 |  |  | 4 |  |  | 8 |  |  | 7 |  |
| Tax related separation costs and other tax matters |  | — |  |  | 3 |  |  | — |  |  | 2 |  |
| Cash payment from ADT Resi / Pentair |  | 1 |  |  | 11 |  |  | 1 |  |  | 11 |  |
| Acquisition / integration costs |  | 2 |  |  | — |  |  | 3 |  |  | — |  |
| Special Items |  | $ | 44 |  |  | $ | 133 |  |  | $ | 82 |  |  | $ | 158 |  |
| Adjusted Free Cash Flow |  | $ | 151 |  |  | $ | 328 |  |  | $ | 192 |  |  | $ | 379 |  |

[0000833444-15-000028:8k_2_02:87]
Note: Free cash flow is a non-GAAP measure.  See description of non-GAAP measures contained in this release.

[0000833444-15-000028:8k_2_02:88]
TYCO INTERNATIONAL PLC

[0000833444-15-000028:8k_2_02:89]
ORGANIC GROWTH RECONCILIATION - REVENUE

[0000833444-15-000028:8k_2_02:90]
(in millions)

[0000833444-15-000028:8k_2_02:91]
(Unaudited)

[0000833444-15-000028:8k_2_02:92]
|  |  |  |  | Quarter Ended March 27, 2015 |  |  |  |  |
|  |  |  |  | Base Year |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Net Revenue for the Quarter Ended March 28, 2014 |  | Adjustments |  | Adjusted Fiscal 2014 BaseRevenue |  |  |  |  |  |  |  |  |  |  |  |  |  | Net Revenue for the Quarter Ended March 27, 2015 |
|  |  |  | Divestitures / Other |  |  | Foreign Currency |  | Acquisitions |  | Organic Revenue(1) |  |
| NA Installation & Services |  | $ | 939 |  |  | $ | — |  |  | — | % |  | $ | 939 |  |  | $ | (12 | ) |  | (1.3 | )% |  | $ | 2 |  |  | 0.2 | % |  | $ | 15 |  |  | 1.6 | % |  | $ | 944 |  |  | 0.5 | % |
| ROW Installation & Services |  | 936 |  |  | — |  |  | — | % |  | 936 |  |  | (100 | ) |  | (10.7 | )% |  | 13 |  |  | 1.4 | % |  | (2 | ) |  | (0.2 | )% |  | 847 |  |  | (9.5 | )% |
| Global Products |  | 605 |  |  | — |  |  | — | % |  | 605 |  |  | (37 | ) |  | (6.1 | )% |  | 26 |  |  | 4.3 | % |  | 45 |  |  | 7.4 | % |  | 639 |  |  | 5.6 | % |
| Total Net Revenue |  | $ | 2,480 |  |  | $ | — |  |  | — | % |  | $ | 2,480 |  |  | $ | (149 | ) |  | (6.0 | )% |  | $ | 41 |  |  | 1.7 | % |  | $ | 58 |  |  | 2.3 | % |  | $ | 2,430 |  |  | (2.0 | )% |

[0000833444-15-000028:8k_2_02:93]
|  | (1) Organic revenue growth percentage based on adjusted fiscal 2014 base revenue. |

[0000833444-15-000028:8k_2_02:94]
|  |  |  |  | Six Months Ended March 27, 2015 |  |  |  |  |
|  |  |  |  | Base Year |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Net Revenue for the Six Months Ended March 28, 2014 |  | Adjustments |  | Adjusted Fiscal 2014 BaseRevenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Net Revenue for the Six Months Ended March 27, 2015 |
|  |  |  | Divestitures / Other |  |  | Foreign Currency |  | Acquisitions |  |  | Organic Revenue (1) |  |
| NA Installation & Services |  | $ | 1,896 |  |  | $ | — |  |  | — | % |  | $ | 1,896 |  |  | $ | (21 | ) |  | (1.1 | )% |  | $ | 6 |  |  | 0.3 | % |  |  | $ | 14 |  |  | 0.7 | % |  | $ | 1,895 |  |  | (0.1 | )% |
| ROW Installation & Services |  | 1,903 |  |  | (13 | ) |  | (0.7 | )% |  | 1,890 |  |  | (163 | ) |  | (8.6 | )% |  | 33 |  |  | 1.7 | % |  |  | 3 |  |  | 0.2 | % |  | 1,763 |  |  | (7.4 | )% |
| Global Products |  | 1,170 |  |  | — |  |  | — | % |  | 1,170 |  |  | (54 | ) |  | (4.6 | )% |  | 31 |  |  | 2.6 | % |  |  | 103 |  |  | 8.8 | % |  | 1,250 |  |  | 6.8 | % |
| Total Net Revenue |  | $ | 4,969 |  |  | $ | (13 | ) |  | (0.3 | )% |  | $ | 4,956 |  |  | $ | (238 | ) |  | (4.8 | )% |  | $ | 70 |  |  | 1.4 | % |  |  | $ | 120 |  |  | 2.4 | % |  | $ | 4,908 |  |  | (1.2 | )% |

[0000833444-15-000028:8k_2_02:95]
|  | (1) Organic revenue growth percentage based on adjusted fiscal 2014 base revenue. |

[0000833444-15-000028:8k_2_02:96]
Earnings Per Share Summary

[0000833444-15-000028:8k_2_02:97]
(Unaudited)

[0000833444-15-000028:8k_2_02:98]
|  |  | Quarter Ended |  | Quarter Ended |
|  |  | March 27, 2015 |  | March 28, 2014 |
| Diluted EPS from Continuing Operations Attributable to Tyco Shareholders (GAAP) |  | $ | 0.43 |  |  | $ | 0.41 |  |
| expense / (benefit) |  |  |  |  |
| Restructuring and repositioning activities |  | 0.05 |  |  | 0.02 |  |
| Separation costs included in SG&A |  | — |  |  | 0.02 |  |
| (Gains) / losses on divestitures, net included in SG&A |  | 0.06 |  |  | — |  |
| Tax items |  | — |  |  | 0.01 |  |
| 2012 Tax Sharing Agreement |  | 0.01 |  |  | 0.01 |  |
| Total Before Special Items |  | $ | 0.55 |  |  | $ | 0.47 |  |
| Note: Prior period has been recast to present certain businesses as a discontinued operation. |  |  |  |  |

[0000833444-15-000028:8k_2_02:99]
Tyco International plc

[0000833444-15-000028:8k_2_02:100]
For the Quarter Ended March 27, 2015

[0000833444-15-000028:8k_2_02:101]
(in millions, except per share data)

[0000833444-15-000028:8k_2_02:102]
(Unaudited)

[0000833444-15-000028:8k_2_02:103]
expense / (benefit)

[0000833444-15-000028:8k_2_02:104]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation & Services |  |  |  | ROW Installation & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $944 |  |  |  |  |  | $847 |  |  |  |  |  | $639 |  |  |  |  |  | $2,430 |  |  |  |  |  | $— |  |  |  |  |  | $2,430 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation& Services |  | Margin |  | ROW Installation& Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other Income, net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $119 |  |  | 12.6 | % |  |  | $60 |  |  | 7.1 | % |  |  | $110 |  |  | 17.2 | % |  |  | $289 |  |  | 11.9 | % |  |  | ($68 | ) |  | N/M |  |  | $221 |  |  | 9.1 | % |  |  | ($21 | ) |  |  | ($1 | ) |  |  | ($18 | ) |  |  | $— |  |  |  | $2 |  |  |  | $183 |  |  | $0.43 |  |
| Restructuring and repositioning activities |  | 6 |  |  |  |  | 7 |  |  |  |  | 4 |  |  |  |  | 17 |  |  |  |  | 12 |  |  |  |  | 29 |  |  |  |  |  |  |  |  | (10 | ) |  |  |  |  |  | 19 |  | 0.05 |  |
| (Gains) / losses on divestitures, net included in SG&A |  |  |  |  |  | 22 |  |  |  |  |  |  |  |  | 22 |  |  |  |  |  |  |  |  | 22 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 22 |  | 0.06 |  |
| Acquisition / integration costs |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Legacy legal items |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Amortization of inventory step-up |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 3 |  |  |  |  | 3 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | 2 |  | — |  |
| IRS litigation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  |  |  |  | 2 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | 1 |  | — |  |
| 2012 Tax Sharing Agreement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 4 |  |  |  |  |  |  |  |  | 4 |  | 0.01 |  |
| Total Before Special Items |  |  | $125 |  |  | 13.2 | % |  |  | $90 |  |  | 10.6 | % |  |  | $116 |  |  | 18.2 | % |  |  | $331 |  |  | 13.6 | % |  |  | ($51 | ) |  | N/M |  |  | $280 |  |  | 11.5 | % |  |  | ($21 | ) |  |  | $3 |  |  |  | ($30 | ) |  |  | $— |  |  |  | $2 |  |  |  | $234 |  |  | $0.55 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 427 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 427 |  |

[0000833444-15-000028:8k_2_02:105]
Tyco International plc

[0000833444-15-000028:8k_2_02:106]
For the Quarter Ended March 28, 2014

[0000833444-15-000028:8k_2_02:107]
(in millions, except per share data)

[0000833444-15-000028:8k_2_02:108]
(Unaudited)

[0000833444-15-000028:8k_2_02:109]
expense / (benefit)

[0000833444-15-000028:8k_2_02:110]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation & Services |  |  |  | ROW Installation & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $939 |  |  |  |  |  | $936 |  |  |  |  |  | $605 |  |  |  |  |  | $2,480 |  |  |  |  |  | $— |  |  |  |  |  | $2,480 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Installation& Services |  | Margin |  | ROW Installation& Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other (Expense), net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $99 |  |  | 10.5 | % |  |  | $114 |  |  | 12.2 | % |  |  | $107 |  |  | 17.7 | % |  |  | $320 |  |  | 12.9 | % |  |  | ($61 | ) |  | N/M |  |  | $259 |  |  | 10.4 | % |  |  | ($22 | ) |  |  | ($1 | ) |  |  | ($39 | ) |  |  | ($5 | ) |  |  | $— |  |  |  | $192 |  |  | $0.41 |  |
| Restructuring and repositioning activities |  | 3 |  |  |  |  | 4 |  |  |  |  | 2 |  |  |  |  | 9 |  |  |  |  | 7 |  |  |  |  | 16 |  |  |  |  |  |  |  |  | (6 | ) |  |  |  |  |  | 10 |  | 0.02 |  |
| Separation costs included in SG&A |  | 15 |  |  |  |  |  |  |  |  |  |  |  |  | 15 |  |  |  |  |  |  |  |  | 15 |  |  |  |  |  |  |  |  | (5 | ) |  |  |  |  |  | 10 |  | 0.02 |  |
| (Gains) / losses on divestitures, net included in SG&A |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Acquisition / integration costs |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| IRS litigation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (1 | ) |  |  |  | (1 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  | (1 | ) | — |  |
| Separation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Tax items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 4 |  |  |  |  |  |  | 4 |  | 0.01 |  |
| 2012 Tax Sharing Agreement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 3 |  |  |  |  |  |  |  |  | 3 |  | 0.01 |  |
| Total Before Special Items |  |  | $117 |  |  | 12.5 | % |  |  | $120 |  |  | 12.8 | % |  |  | $109 |  |  | 18.0 | % |  |  | $346 |  |  | 14.0 | % |  |  | ($54 | ) |  | N/M |  |  | $292 |  |  | 11.8 | % |  |  | ($22 | ) |  |  | $2 |  |  |  | ($46 | ) |  |  | ($5 | ) |  |  | $— |  |  |  | $221 |  |  | $0.47 |  |
| Note: This period has been recast to present certain businesses as a discontinued operation. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 469 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 469 |  |
