# JCI MD&A — 0000833444-15-000032


## mdna

[0000833444-15-000032:mdna:1]
[same as prior period, unchanged from 0000833444-15-000013:mdna:1]

[0000833444-15-000032:mdna:2]
[same as prior period, unchanged from 0000833444-15-000013:mdna:2]

[0000833444-15-000032:mdna:3]
[same as prior period, unchanged from 0000833444-15-000013:mdna:3]

[0000833444-15-000032:mdna:4]
[same as prior period, unchanged from 0000833444-15-000013:mdna:4]

[0000833444-15-000032:mdna:5]
References to 2015 and 2014 are to Tyco's fiscal quarters ending March 27, 2015 and March 28, 2014, respectively, unless otherwise indicated.  The Company has a 52 or 53-week fiscal year that ends on the last Friday in September. Fiscal years 2015 and 2014 are both 52-week years.

[0000833444-15-000032:mdna:6]
[same as prior period, unchanged from 0000833444-15-000013:mdna:6]

[0000833444-15-000032:mdna:7]
[same as prior period, unchanged from 0000833444-15-000013:mdna:7]

[0000833444-15-000032:mdna:8]
[same as prior period, unchanged from 0000833444-15-000013:mdna:8]

[0000833444-15-000032:mdna:9]
[same as prior period, unchanged from 0000833444-15-000013:mdna:9]

[0000833444-15-000032:mdna:10]
[same as prior period, unchanged from 0000833444-15-000013:mdna:10]

[0000833444-15-000032:mdna:11]
[same as prior period, unchanged from 0000833444-15-000013:mdna:11]

[0000833444-15-000032:mdna:12]
[same as prior period, unchanged from 0000833444-15-000013:mdna:12]

[0000833444-15-000032:mdna:13]
Certain prior period amounts have been reclassified to conform with current period presentation.  The Company has reclassified several businesses in the Rest of World ("ROW") Installation & Services segment to Income from discontinued operations in the Consolidated Statements of Operations and the assets and liabilities as held for sale within the Consolidated Balance Sheets for all periods presented as they satisfied the criteria to be presented as discontinued operations.  The Company expects to complete the sale of these businesses by the end of the third quarter of fiscal 2015.  In addition, the Company has reclassified the assets and liabilities of several businesses in the ROW Installation & Services segment as held for sale during the quarter ended March 27, 2015, and the Company expects to complete the sale of these businesses during the remainder of fiscal 2015.  One of these businesses satisfied the criteria to be presented as discontinued operations and has been reflected as such in the Consolidated Statements of Operations for all periods presented.  See Note 3 to our unaudited Consolidated Financial Statements.

[0000833444-15-000032:mdna:14]
45

[0000833444-15-000032:mdna:15]
[same as prior period, unchanged from 0000833444-15-000013:mdna:14]

[0000833444-15-000032:mdna:16]
We are a leading global provider of security products and services, fire detection and suppression products and services and life safety products. We utilize our extensive global footprint of approximately 900 locations, including manufacturing facilities, service and distribution centers, monitoring centers and sales offices, to provide solutions and localized expertise to our global customer base. We provide an extensive range of product and service offerings to over 3 million customers in more than 100 countries through multiple channels. Our revenues are broadly diversified across the United States and Canada (collectively “North America”); Central America and South America (collectively “Latin America”); Europe, the Middle East, and Africa (collectively “EMEA”) and the Asia-Pacific geographic areas. The following chart reflects our net revenue by geographic area for the six months ended March 27, 2015.

[0000833444-15-000032:mdna:17]
Six Months Ended March 27, 2015

[0000833444-15-000032:mdna:18]
[same as prior period, unchanged from 0000833444-15-000013:mdna:18]

[0000833444-15-000032:mdna:19]
[same as prior period, unchanged from 0000833444-15-000013:mdna:19]

[0000833444-15-000032:mdna:20]
[same as prior period, unchanged from 0000833444-15-000013:mdna:20]

[0000833444-15-000032:mdna:21]
[same as prior period, unchanged from 0000833444-15-000013:mdna:21]

[0000833444-15-000032:mdna:22]
[same as prior period, unchanged from 0000833444-15-000013:mdna:22]

[0000833444-15-000032:mdna:23]
[same as prior period, unchanged from 0000833444-15-000013:mdna:23]

[0000833444-15-000032:mdna:24]
[same as prior period, unchanged from 0000833444-15-000013:mdna:24]

[0000833444-15-000032:mdna:25]
[same as prior period, unchanged from 0000833444-15-000013:mdna:96]

[0000833444-15-000032:mdna:26]
[same as prior period, unchanged from 0000833444-15-000013:mdna:25]

[0000833444-15-000032:mdna:27]
As a global business with a varied customer base and an extensive range of products and services, our operations and results are impacted by global, regional and industry specific factors, and by political factors. Our geographic diversity and the diversity in our customer base and our products and services has helped mitigate the impact of any one industry or the economy of any single country on our consolidated operating results, financial condition and cash flows. Due to the global nature of our business and the variety of our customers, products and services, no single factor is predominantly used to forecast Company results. Rather, management monitors a number of factors to develop expectations regarding future results, including the activity of key competitors and customers, order rates for longer lead time projects, and capital expenditure budgets and spending patterns of our customers. We also monitor trends throughout the commercial and residential fire and security markets, including building codes and fire-safety standards. Our commercial installation businesses are impacted by trends in commercial construction starts, while our residential business, which is located outside of the United States, is impacted by new housing starts.

[0000833444-15-000032:mdna:28]
Because we are a global business, with approximately 50% of our revenue generated outside the United States, and because our financial statements are prepared in U.S. Dollars, our results of operations are impacted by changes in foreign currency exchange rates. In recent months, the U.S. Dollar has continued to strengthen against the currencies of most of the significant non-U.S. jurisdictions where we operate. The most significant drop has been in the Euro, which decreased to a recent low of approximately EUR 1.05 per 1.00 U.S. Dollar from approximately EUR 1.26 at the beginning of our fiscal year. The significant strengthening of the U.S. Dollar has negatively impacted our revenue and operating income during the first six months of fiscal 2015 and is expected to continue to do so during the second half of fiscal 2015. In addition, the Company sells its products and services into the petrochemical, oil and gas market. Revenue from this market vertical is spread across each of the Company’s segments, with the most significant exposure in the United Kingdom in the ROW Installation & Services segment and in the Fire Protection Products business in the Global Products segment. As a result of recent declines in oil prices, this market vertical has seen significant changes in spending patterns, in particular with respect to capital expenditures. Based on activity in the second fiscal quarter, the Company expects the revenue tied to this market vertical to be negatively impacted during the fiscal year.

[0000833444-15-000032:mdna:29]
[same as prior period, unchanged from 0000833444-15-000013:mdna:29]

[0000833444-15-000032:mdna:30]
[same as prior period, unchanged from 0000833444-15-000013:mdna:30]

[0000833444-15-000032:mdna:31]
|  | For the Quarters Ended |  | For the Six Months Ended |
| ($ in millions) | March 27, 2015 |  | March 28, 2014 |  | March 27, 2015 |  | March 28, 2014 |
| Net revenue | $ | 2,430 |  |  | $ | 2,480 |  |  | $ | 4,908 |  |  | $ | 4,969 |  |
| Net revenue decline | (2.0 | )% |  | N/A |  |  | (1.2 | )% |  | N/A |  |
| Organic revenue growth | 2.3 | % |  | N/A |  |  | 2.4 | % |  | N/A |  |
| Operating income | $ | 221 |  |  | $ | 259 |  |  | $ | 420 |  |  | $ | 602 |  |
| Operating margin | 9.1 | % |  | 10.4 | % |  | 8.6 | % |  | 12.1 | % |
| Interest income | $ | 4 |  |  | $ | 3 |  |  | $ | 7 |  |  | $ | 6 |  |
| Interest expense | (25 | ) |  | (25 | ) |  | (49 | ) |  | (49 | ) |
| Other (expense) income, net | (1 | ) |  | (1 | ) |  | 3 |  |  | (2 | ) |
| Income tax expense | (18 | ) |  | (39 | ) |  | (37 | ) |  | (109 | ) |
| Equity loss in earnings of unconsolidated subsidiaries | — |  |  | (5 | ) |  | — |  |  | (9 | ) |
| Income from continuing operations attributable to Tyco ordinary shareholders | 183 |  |  | 192 |  |  | 347 |  |  | 437 |  |

[0000833444-15-000032:mdna:32]
[same as prior period, unchanged from 0000833444-15-000013:mdna:32]

[0000833444-15-000032:mdna:33]
Net revenue for the quarter ended March 27, 2015 decreased by $50 million, or 2.0%, to $2,430 million as compared to net revenue of $2,480 million for the quarter ended March 28, 2014.  Changes in foreign currency exchange rates had an unfavorable impact of $149 million, or 6.0%, on net revenue, primarily in our ROW Installation & Services segment, and to a lesser extent, in our Global Products segment.  On an organic basis, net revenue grew by $58 million, or 2.3%, year over year, primarily as a result of revenue growth in our Global Products segment, and to a lesser extent, in our NA Installation & Services segment.  Organic revenue for our ROW Installation & Services segment was flat.  Net revenue was favorably impacted by

[0000833444-15-000032:mdna:34]
acquisitions that contributed $41 million, or 1.7%, primarily within our Global Products and ROW Installation & Services segment.

[0000833444-15-000032:mdna:35]
Net revenue for the six months ended March 27, 2015 decreased by $61 million, or 1.2%, to $4,908 million as compared to net revenue of $4,969 million for the six months ended March 28, 2014.  Changes in foreign currency exchange rates had an unfavorable impact of $238 million, or 4.8%, on net revenue, primarily in our ROW Installation & Services segment, and to a lesser extent, in our Global Products and NA Installation & Services segments. Net revenue was also unfavorably impacted by divestitures of $13 million, or 0.3%, in our ROW Installation & Services segment, but was partially offset by the favorable impact of acquisitions, which contributed $70 million, or 1.4%, within our ROW Installation & Services and Global Products segments.  On an organic basis, net revenue grew by $120 million, or 2.4%, year over year, primarily as a result of revenue growth in our Global Products segment.

[0000833444-15-000032:mdna:36]
[same as prior period, unchanged from 0000833444-15-000013:mdna:34]

[0000833444-15-000032:mdna:37]
Operating income for the quarter ended March 27, 2015 decreased by $38 million, or 14.7%, to $221 million, as compared to operating income of $259 million for the quarter ended March 28, 2014.  This decline is primarily due to a non-recurring $21 million insurance recovery which occurred in the comparable period.  Operating income was also unfavorably impacted by a $21 million increase in loss on divestitures which primarily related to the sale of a joint venture interest in our ROW Installation & Services segment, and a $13 million increase in restructuring and repositioning charges as compared to the  comparable period.  In addition, changes in foreign currency exchange rates had an unfavorable impact on operating income of $16 million.  These items were offset by a $16 million decrease in separation costs and benefits from sourcing, productivity and restructuring activities.

[0000833444-15-000032:mdna:38]
Operating income for the six months ended March 27, 2015 decreased by $182 million, or 30.2%, to $420 million, as compared to operating income of $602 million for the six months ended March 28, 2014.  Most of this decline is due to a reversal of a compensation reserve of $92 million for the settlement of legacy litigation with former management, and a gain of $16 million related to a legal settlement with CIT Group in the comparable period.  Operating income was also unfavorably impacted by a $79 million increase in restructuring and repositioning charges, as well as a $25 million increase in loss on divestitures.  In addition, changes in foreign currency exchange rates had an unfavorable impact on operating income of $25 million.  These items were offset by a $29 million decrease in separation costs and benefits from sourcing, productivity and restructuring activities.

[0000833444-15-000032:mdna:39]
Key items impacting operating income for the quarters and six months ended March 27, 2015 and March 28, 2014, respectively, are as follows:

[0000833444-15-000032:mdna:40]
|  | For the Quarters Ended |  | For the Six Months Ended |
| ($ in millions) | March 27, 2015 |  | March 28, 2014 |  | March 27, 2015 |  | March 28, 2014 |
| Legacy legal gains | $ | — |  |  | $ | — |  |  | $ | (7 | ) |  | $ | (92 | ) |
| CIT settlement gain | — |  |  | — |  |  | — |  |  | (16 | ) |
| Separation costs | — |  |  | 16 |  |  | 2 |  |  | 31 |  |
| Loss on sale of investment | — |  |  | — |  |  | — |  |  | 7 |  |
| Restructuring, repositioning and asset impairment charges, net | 29 |  |  | 16 |  |  | 104 |  |  | 25 |  |
| Loss (gain) on divestitures | 22 |  |  | 1 |  |  | 23 |  |  | (2 | ) |
| China insurance recovery | — |  |  | (21 | ) |  | — |  |  | (21 | ) |
| Impact of foreign currency | 16 |  |  | 5 |  |  | 25 |  |  | 10 |  |

[0000833444-15-000032:mdna:41]
We continue to identify and pursue opportunities for cost savings through restructuring activities and workforce reductions to improve operating efficiencies across our businesses. Additionally, we initiated certain global actions designed to reduce our cost structure and improve future profitability by streamlining operations and better aligning functions, which we refer to as repositioning actions. The Company expects to incur approximately $150 million of restructuring and repositioning charges in fiscal 2015. See Note 4 to our unaudited Consolidated Financial Statements.

[0000833444-15-000032:mdna:42]
[same as prior period, unchanged from 0000833444-15-000013:mdna:39]

[0000833444-15-000032:mdna:43]
Interest income was $4 million and $3 million for the quarters ended March 27, 2015 and March 28, 2014.  Interest income was $7 million and $6 million for the six months ended March 27, 2015 and March 28, 2014, respectively.

[0000833444-15-000032:mdna:44]
Interest expense was $25 million for both quarters ended March 27, 2015 and March 28, 2014.  Interest expense was $49 million for both the six months ended March 27, 2015 and March 28, 2014.

[0000833444-15-000032:mdna:45]
Other (Expense) Income, net

[0000833444-15-000032:mdna:46]
Other expense of $1 million for both quarters ended March 27, 2015 and March 28, 2014 primarily related to a net loss related to the 2012 Tax Sharing Agreement between the Company, ADT and Pentair.

[0000833444-15-000032:mdna:47]
Other income of $3 million for the six months ended March 27, 2015 primarily related to an unrealized gain on trading securities, partially offset by a net loss related to the 2012 Tax Sharing Agreement.  Other expense of $2 million for the six months ended March 28, 2014 primarily related to a net loss on the 2012 Tax Sharing Agreement activity.

[0000833444-15-000032:mdna:48]
[same as prior period, unchanged from 0000833444-15-000013:mdna:43]

[0000833444-15-000032:mdna:49]
Our effective income tax rate was 9.0% and 16.5% during the quarters ended March 27, 2015 and March 28, 2014, respectively. The decrease in our effective tax rate in the current period was primarily due to a decrease in valuation allowances on the basis of management's reassessment of the amount of its deferred tax assets that are more likely than not to be realized as a result of the impact of restructuring actions and tax law changes in a non-U.S. jurisdiction.

[0000833444-15-000032:mdna:50]
Our effective income tax rate was 9.7% and 19.6% during the six months ended March 27, 2015 and March 28, 2014, respectively. The decrease in our effective tax rate in the current period was primarily due to a decrease in valuation allowances on the basis of management's reassessment of the amount of its deferred tax assets that are more likely than not to be realized resulting from the impact of restructuring actions and tax law changes in a non-U.S. jurisdiction, and income from a non-recurring reversal of a compensation reserve established in respect of legacy litigation with former management that generated increased tax expense during the prior period.

[0000833444-15-000032:mdna:51]
The rate can vary from quarter to quarter due to discrete items, such as the settlement of income tax audits and changes in tax laws, as well as recurring factors such as the geographic mix of income before taxes.  The Company has operations and a taxable presence in nearly 60 countries outside the U.S.  All of these countries have a tax rate that is lower than the rate in the U.S.  The countries in which the Company has a material presence that have lower tax rates compared to the U.S. include Canada, Australia, Ireland, Germany, Switzerland and the United Kingdom.  The Company's ability to obtain a benefit from lower tax rates outside the U.S. is dependent on its relative levels of income in countries outside the U.S. and on the statutory tax rates and tax laws in these countries.  Based on the dispersion of the Company's non-U.S. income and management’s assessment of the likelihood and magnitude of any potential change to statutory tax rates or tax laws affecting the Company, any such changes are not expected to materially affect the Company's income tax provision or net income, aside from any one-time adjustment to reflect the impact of the change in the tax rate to the Company's deferred tax balances.

[0000833444-15-000032:mdna:52]
Equity Loss in Earnings of Unconsolidated Subsidiaries

[0000833444-15-000032:mdna:53]
Equity loss in earnings of unconsolidated subsidiaries of $5 million and $9 million for the quarter and six months ended March 28, 2014, respectively, reflects our share of Atkore International Group Inc.'s  ("Atkore") net gain or loss, which was accounted for under the equity method of accounting.  On April 9, 2014, Atkore redeemed all of our common equity stake in Atkore.

[0000833444-15-000032:mdna:54]
[same as prior period, unchanged from 0000833444-15-000013:mdna:48]

[0000833444-15-000032:mdna:55]
The following chart reflects our net revenue by operating segment, as well as the percent of net revenue by operating segment, for the quarters and six months ended March 27, 2015 and March 28, 2014, respectively.

[0000833444-15-000032:mdna:56]
[same as prior period, unchanged from 0000833444-15-000013:mdna:50]

[0000833444-15-000032:mdna:57]
[same as prior period, unchanged from 0000833444-15-000013:mdna:51]

[0000833444-15-000032:mdna:58]
Financial information for NA Installation & Services for the quarters and six months ended March 27, 2015 and March 28, 2014 is as follows:

[0000833444-15-000032:mdna:59]
|  | For the Quarters Ended |  | For the Six Months Ended |
| ($ in millions) | March 27, 2015 |  | March 28, 2014 |  | March 27, 2015 |  | March 28, 2014 |
| Net revenue | $ | 944 |  |  | $ | 939 |  |  | $ | 1,895 |  |  | $ | 1,896 |  |
| Net revenue growth (decline) | 0.5 | % |  | N/A |  |  | (0.1 | )% |  | N/A |  |
| Organic revenue growth | 1.6 | % |  | N/A |  |  | 0.7 | % |  | N/A |  |
| Operating income | $ | 119 |  |  | $ | 99 |  |  | $ | 224 |  |  | $ | 216 |  |
| Operating margin | 12.6 | % |  | 10.5 | % |  | 11.8 | % |  | 11.4 | % |

[0000833444-15-000032:mdna:60]
50

[0000833444-15-000032:mdna:61]
[same as prior period, unchanged from 0000833444-15-000013:mdna:54]

[0000833444-15-000032:mdna:62]
[same as prior period, unchanged from 0000833444-15-000013:mdna:55]

[0000833444-15-000032:mdna:63]
| Factors Contributing to Year-Over-Year Change |  | Second QuarterFiscal 2015 Compared toSecond QuarterFiscal 2014 |  | Year to Date Fiscal 2015 Compared to Year to Date Fiscal 2014 |
| Organic revenue growth |  | $ | 15 |  |  | $ | 14 |  |
| Acquisitions |  | 2 |  |  | 6 |  |
| Impact of foreign currency |  | (12 | ) |  | (21 | ) |
| Total change |  | $ | 5 |  |  | $ | (1 | ) |

[0000833444-15-000032:mdna:64]
Net revenue increased $5 million, or 0.5%, to $944 million for the quarter ended March 27, 2015 as compared to $939 million for the quarter ended March 28, 2014. On an organic basis, net revenue grew by 1.6% from the comparable quarter, with increases in both service and installation revenue.  Net revenue was also favorably impacted by $2 million, or 0.2%, due to several small acquisitions made during the quarter ended March 27, 2015.  Changes in foreign currency exchange rates unfavorably impacted net revenue by $12 million, or 1.3%.

[0000833444-15-000032:mdna:65]
Net revenue decreased $1 million, or 0.1%, to $1,895 million for the six months ended March 27, 2015 as compared to $1,896 million for the six months ended March 28, 2014.  Changes in foreign currency exchange rates unfavorably impacted net revenue by $21 million, or 1.1%.  On an organic basis, net revenue grew by 0.7% from the comparable period, as increased service revenue was partially offset by a decline in installation revenue.  Net revenue was favorably impacted by $6 million, or 0.3%, due to the acquisition of Westfire in the first quarter of fiscal 2014 and several small acquisitions made during the first six months of fiscal 2015.

[0000833444-15-000032:mdna:66]
[same as prior period, unchanged from 0000833444-15-000013:mdna:58]

[0000833444-15-000032:mdna:67]
Operating income for the quarter ended March 27, 2015 increased $20 million, or 20.2%, to $119 million, as compared to operating income of $99 million for the quarter ended March 28, 2014.  This increase was primarily due to a $15 million decline in separation costs and the benefit of previous productivity and restructuring actions.

[0000833444-15-000032:mdna:68]
Operating income for the six months ended March 27, 2015 increased $8 million, or 3.7%, to $224 million, as compared to operating income of $216 million for the six months ended March 28, 2014.  The benefits of previous productivity and restructuring actions and a $27 million decline in separation costs was partially offset by an increase of $29 million in restructuring and repositioning activities.

[0000833444-15-000032:mdna:69]
Key items impacting operating income for the quarters and six months ended March 27, 2015 and March 28, 2014, respectively, are as follows:

[0000833444-15-000032:mdna:70]
|  | For the Quarters Ended |  | For the Six Months Ended |
| ($ in millions) | March 27, 2015 |  | March 28, 2014 |  | March 27, 2015 |  | March 28, 2014 |
| Separation costs | $ | — |  |  | $ | 15 |  |  | $ | 2 |  |  | $ | 29 |  |
| Restructuring, repositioning and asset impairment charges, net | 6 |  |  | 3 |  |  | 30 |  |  | 1 |  |

[0000833444-15-000032:mdna:71]
[same as prior period, unchanged from 0000833444-15-000013:mdna:62]

[0000833444-15-000032:mdna:72]
Financial information for ROW Installation & Services for the quarters and six months ended March 27, 2015 and March 28, 2014 is as follows:

[0000833444-15-000032:mdna:73]
|  | For the Quarters Ended |  | For the Six Months Ended |
| ($ in millions) | March 27, 2015 |  | March 28, 2014 |  | March 27, 2015 |  | March 28, 2014 |
| Net revenue | $ | 847 |  |  | $ | 936 |  |  | $ | 1,763 |  |  | $ | 1,903 |  |
| Net revenue decline | (9.5 | )% |  | N/A |  |  | (7.4 | )% |  | N/A |  |
| Organic revenue (decline) growth | (0.2 | )% |  | N/A |  |  | 0.2 | % |  | N/A |  |
| Operating income | $ | 60 |  |  | $ | 114 |  |  | $ | 130 |  |  | $ | 208 |  |
| Operating margin | 7.1 | % |  | 12.2 | % |  | 7.4 | % |  | 10.9 | % |

[0000833444-15-000032:mdna:74]
[same as prior period, unchanged from 0000833444-15-000013:mdna:65]

[0000833444-15-000032:mdna:75]
[same as prior period, unchanged from 0000833444-15-000013:mdna:66]

[0000833444-15-000032:mdna:76]
| Factors Contributing to Year-Over-Year Change |  | Second QuarterFiscal 2015Compared toSecond QuarterFiscal 2014 |  | Year to Date Fiscal 2015 Compared to Year to Date Fiscal 2014 |
| Organic revenue (decline) growth |  | $ | (2 | ) |  | $ | 3 |  |
| Acquisitions |  | 13 |  |  | 33 |  |
| Divestitures |  | — |  |  | (13 | ) |
| Impact of foreign currency |  | (100 | ) |  | (163 | ) |
| Total change |  | $ | (89 | ) |  | $ | (140 | ) |

[0000833444-15-000032:mdna:77]
Net revenue decreased $89 million, or 9.5%, to $847 million for the quarter ended March 27, 2015 as compared to $936 million for the quarter ended March 28, 2014. Changes in foreign currency exchange rates unfavorably impacted net revenue by $100 million, or 10.7%.  On an organic basis, net revenue was relatively unchanged, as growth in services was offset by a decline in installation revenue.  Net revenue was favorably impacted by $13 million, or 1.4%, due to acquisitions within growth markets, Continental Europe and the United Kingdom.

[0000833444-15-000032:mdna:78]
Net revenue decreased $140 million, or 7.4%, to $1,763 million for the six months ended March 27, 2015 as compared to $1,903 million for the six months ended March 28, 2014.  Changes in foreign currency exchange rates unfavorably impacted net revenue by $163 million, or 8.6%.  Net revenue was also unfavorably impacted by $13 million, or 0.7%, due to the divestiture of our Armourguard business in New Zealand and fire and security business in Fiji in the first quarter of fiscal 2014. On an organic basis, revenue was relatively unchanged, as growth in growth markets and to a lesser extent, Asia and Continental Europe, was offset by declines in our Pacific region and the United Kingdom.  Net revenue was favorably impacted by $33 million, or 1.7%, primarily due to acquisitions within growth markets, continental Europe and the United Kingdom.

[0000833444-15-000032:mdna:79]
[same as prior period, unchanged from 0000833444-15-000013:mdna:69]

[0000833444-15-000032:mdna:80]
Operating income for the quarter ended March 27, 2015 decreased $54 million, or 47.4%, to $60 million as compared to operating income of $114 million for the quarter ended March 28, 2014.  Operating income was unfavorably impacted by a $22 million anticipated loss on disposal of a joint venture interest in China during the quarter ended March 27, 2015, the unfavorable impact of $9 million relating to changes in foreign currency exchange rates, and a slightly lower mix of high-margin service revenue.  Operating income also declined due to a $21 million insurance recovery in the comparable quarter.

[0000833444-15-000032:mdna:81]
Operating income for the six months ended March 27, 2015 decreased $78 million, or 37.5%, to $130 million as compared to operating income of $208 million for the six months ended March 28, 2014.  Operating income was unfavorably impacted by a $22 million increase in restructuring and repositioning charges during the six months ended March 27, 2015, a $23 million increase in loss on divestitures, and a slightly lower mix of high-margin service revenue. Operating income for the six months ended March 27, 2015 was also unfavorably impacted by $15 million related to changes in foreign currency exchange rates and $21 million related to the insurance recovery noted above.  Additionally, the comparable period of fiscal 2014 included a $7 million loss on the sale of an investment.

[0000833444-15-000032:mdna:82]
Key items impacting operating income for the quarters and six months ended March 27, 2015 and March 28, 2014, respectively, are as follows:

[0000833444-15-000032:mdna:83]
|  | For the Quarters Ended |  | For the Six Months Ended |
| ($ in millions) | March 27, 2015 |  | March 28, 2014 |  | March 27, 2015 |  | March 28, 2014 |
| Loss on sale of investment | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 7 |  |
| Restructuring, repositioning and asset impairment charges, net | 7 |  |  | 4 |  |  | 26 |  |  | 4 |  |
| Loss on divestitures | 22 |  |  | — |  |  | 23 |  |  | — |  |
| China insurance recovery | — |  |  | (21 | ) |  | — |  |  | (21 | ) |
| Impact of foreign currency | 9 |  |  | 4 |  |  | 15 |  |  | 8 |  |

[0000833444-15-000032:mdna:84]
[same as prior period, unchanged from 0000833444-15-000013:mdna:73]

[0000833444-15-000032:mdna:85]
Financial information for Global Products for the quarters and six months ended March 27, 2015 and March 28, 2014 is as follows:

[0000833444-15-000032:mdna:86]
|  | For the Quarters Ended |  | For the Six Months Ended |
| ($ in millions) | March 27, 2015 |  | March 28, 2014 |  | March 27, 2015 |  | March 28, 2014 |
| Net revenue | $ | 639 |  |  | $ | 605 |  |  | $ | 1,250 |  |  | $ | 1,170 |  |
| Net revenue growth | 5.6 | % |  | N/A |  |  | 6.8 | % |  | N/A |  |
| Organic revenue growth | 7.4 | % |  | N/A |  |  | 8.8 | % |  | N/A |  |
| Operating income | $ | 110 |  |  | $ | 107 |  |  | $ | 208 |  |  | $ | 193 |  |
| Operating margin | 17.2 | % |  | 17.7 | % |  | 16.6 | % |  | 16.5 | % |

[0000833444-15-000032:mdna:87]
[same as prior period, unchanged from 0000833444-15-000013:mdna:76]

[0000833444-15-000032:mdna:88]
[same as prior period, unchanged from 0000833444-15-000013:mdna:77]

[0000833444-15-000032:mdna:89]
| Factors Contributing to Year-Over-Year Change |  | Second QuarterFiscal 2015Compared toSecond QuarterFiscal 2014 |  | Year to Date Fiscal 2015 Compared to Year to Date Fiscal 2014 |
| Organic revenue growth |  | $ | 45 |  |  | $ | 103 |  |
| Acquisitions |  | 26 |  |  | 31 |  |
| Impact of foreign currency |  | (37 | ) |  | (54 | ) |
| Total change |  | $ | 34 |  |  | $ | 80 |  |

[0000833444-15-000032:mdna:90]
Net revenue increased $34 million, or 5.6%, to $639 million for the quarter ended March 27, 2015 as compared to $605 million for the quarter ended March 28, 2014.  On an organic basis, net revenue growth was primarily driven by our life safety business and security products businesses.  Within life safety, revenue in the comparable period of fiscal 2014 was negatively impacted by industry-wide approval delays of new standards related to self-contained breathing apparatuses.  Net revenue was favorably impacted by $26 million, or 4.3%, from acquisitions during the quarter ended March 27, 2015.  Changes in foreign currency exchange rates unfavorably impacted net revenue by $37 million, or 6.1%.

[0000833444-15-000032:mdna:91]
Net revenue increased $80 million, or 6.8%, to $1,250 million for the six months ended March 27, 2015 as compared to $1,170 million for the six months ended March 28, 2014.  On an organic basis, net revenue growth was driven by growth across all three businesses, predominantly in our life safety business.  Within life safety, revenue in the comparable period of fiscal 2014 was negatively impacted by industry-wide approval delays of new standards related to self-contained breathing apparatuses.  Net revenue was favorably impacted by $31 million, or 2.6%, from acquisitions during the first half of fiscal 2015.  Changes in foreign currency exchange rates unfavorably impacted net revenue by $54 million, or 4.6%.

[0000833444-15-000032:mdna:92]
[same as prior period, unchanged from 0000833444-15-000013:mdna:80]

[0000833444-15-000032:mdna:93]
Operating income for the quarter ended March 27, 2015 increased by $3 million, or 2.8% to $110 million, as compared to operating income of $107 million for the quarter ended March 28, 2014.  Operating income increased due to net revenue growth for the quarter ended March 27, 2015, as well as the benefit of productivity and restructuring initiatives. These were partially offset by additional investments in research and development and sales and marketing costs.  In addition, changes in foreign currency exchange rates had an unfavorable impact on operating income of $6 million.

[0000833444-15-000032:mdna:94]
Operating income for the six months ended March 27, 2015 increased by $15 million, or 7.8% to $208 million, as compared to operating income of $193 million for the six months ended March 28, 2014.  Operating income increased due to net revenue growth for the six months ended March 27, 2015, as well as the benefit of productivity and restructuring initiatives. These were partially offset by a $5 million increase in restructuring and repositioning charges, and additional investments in research and development and sales and marketing costs.  In addition, changes in foreign currency exchange rates had an unfavorable impact on operating income of $8 million.

[0000833444-15-000032:mdna:95]
Key items impacting operating income for the quarters and six months ended March 27, 2015 and March 28, 2014, respectively, are as follows:

[0000833444-15-000032:mdna:96]
|  | For the Quarter Ended |  | For the Six Months Ended |
| ($ in millions) | March 27, 2015 |  | March 28, 2014 |  | March 27, 2015 |  | March 28, 2014 |
| Restructuring, repositioning and asset impairment charges, net | $ | 4 |  |  | $ | 2 |  |  | $ | 11 |  |  | $ | 6 |  |
| Impact of foreign currency | 6 |  |  | — |  |  | 8 |  |  | — |  |

[0000833444-15-000032:mdna:97]
[same as prior period, unchanged from 0000833444-15-000013:mdna:84]

[0000833444-15-000032:mdna:98]
Corporate expense was $68 million for the quarter ended March 27, 2015 compared to $61 million for the quarter ended March 28, 2014.  The increase in expense was primarily due to a $5 million increase in restructuring and repositioning charges compared to the quarter ended March 28, 2014.

[0000833444-15-000032:mdna:99]
Corporate expense was $142 million for the six months ended March 27, 2015 compared to $15 million for the six months ended March 28, 2014.  The increase in expense was primarily due to the reversal of a compensation reserve of $92 million for the settlement of legacy litigation with former management, and a gain of $16 million related to a legal settlement with CIT Group, for the six months ended March 28, 2014.  In addition, restructuring and repositioning charges increased by $23 million compared to the six months ended March 28, 2014.

[0000833444-15-000032:mdna:100]
Key items included in corporate expense for the quarters and six months ended March 27, 2015 and March 28, 2014, respectively, are as follows:

[0000833444-15-000032:mdna:101]
|  | For the Quarters Ended |  | For the Six Months Ended |
| ($ in millions) | March 27, 2015 |  | March 28, 2014 |  | March 27, 2015 |  | March 28, 2014 |
| Legacy legal gains | $ | — |  |  | $ | — |  |  | $ | (7 | ) |  | $ | (92 | ) |
| CIT settlement gain | — |  |  | — |  |  | — |  |  | (16 | ) |
| Restructuring, repositioning and asset impairment charges, net | 12 |  |  | 7 |  |  | 37 |  |  | 14 |  |

[0000833444-15-000032:mdna:102]
[same as prior period, unchanged from 0000833444-15-000013:mdna:88]

[0000833444-15-000032:mdna:103]
The preparation of the unaudited Consolidated Financial Statements in conformity with US GAAP requires management to use judgment in making estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of contingent assets and liabilities and the reported amounts of revenue and expenses. We believe that our accounting policies for depreciation and amortization methods of security monitoring-related assets, revenue recognition, loss contingencies, income taxes, goodwill and indefinite-lived intangible assets, long-lived assets and pension and postretirement benefits are based on, among other things, judgments and assumptions made by management that include inherent risks and uncertainties. During fiscal 2015, there have been no significant changes to these policies or in the underlying accounting assumptions and estimates used in the above critical accounting policies from those disclosed in the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K filed with the SEC on November 14, 2014 for the fiscal year ended September 26, 2014.

[0000833444-15-000032:mdna:104]
[same as prior period, unchanged from 0000833444-15-000013:mdna:90]

[0000833444-15-000032:mdna:105]
A fundamental objective of the Company is to have sufficient liquidity, balance sheet strength, and financial flexibility to fund the operating and capital requirements of its core businesses around the world. The primary source of funds to finance our operations and capital expenditures is cash generated by operations. In addition, we maintain a commercial paper program, have access to a committed revolving credit facility and have access to equity and debt capital from public and private sources. We continue to balance our operating, investing and financing uses of cash through investments and acquisitions in our core businesses, dividends and share repurchases. In addition, we believe our cash position, amounts available under our credit facility, commercial paper program and cash provided by operating activities will be adequate to cover our operational and business needs in the foreseeable future.

[0000833444-15-000032:mdna:106]
As of March 27, 2015 and September 26, 2014, our cash and cash equivalents, total debt and Tyco shareholders' equity are as follows:

[0000833444-15-000032:mdna:107]
|  | As of |
| ($ in millions) | March 27, 2015 |  | September 26, 2014 |
| Cash and cash equivalents | $ | 432 |  |  | $ | 892 |  |
| Total debt | 2,010 |  |  | 1,463 |  |
| Total Tyco shareholders' equity | 4,181 |  |  | 4,647 |  |
| Total debt as a % of total capital (1) | 32.5 | % |  | 23.9 | % |

[0000833444-15-000032:mdna:108]
(1) Total capital represents the aggregate amount of total debt and total Tyco Shareholders' equity which was $6,191 million and $6,110 million as of March 27, 2015 and September 26, 2014, respectively.

[0000833444-15-000032:mdna:109]
[same as prior period, unchanged from 0000833444-15-000013:mdna:97]

[0000833444-15-000032:mdna:110]
Our cash flows from operating, investing and financing from continuing operations for the six months ended March 27, 2015 and March 28, 2014 are summarized below:

[0000833444-15-000032:mdna:111]
|  | For the Six Months Ended |
| ($ in millions) | March 27, 2015 |  | March 28, 2014 |
| Net cash provided by operating activities | $ | 262 |  |  | $ | 366 |  |
| Net cash used in investing activities | (703 | ) |  | (92 | ) |
| Net cash used in financing activities | (3 | ) |  | (326 | ) |

[0000833444-15-000032:mdna:112]
On January 9, 2015, the Company completed a series of restructuring transactions related to the establishment and funding of a structure dedicated to resolving certain historic Grinnell asbestos liabilities. Pursuant to this transaction, a subsidiary of the Company acquired certain assets of Grinnell and transferred cash and other assets totaling approximately $278 million to the structure.  The cash and assets transferred to the structure have been designated as restricted by the Company. In addition, on the effective date of Yarway’s Chapter 11 plan of reorganization, which is anticipated to occur in the third fiscal quarter of 2015, the Company expects to contribute approximately $325 million to an asbestos settlement trust that conforms to the provisions of Section 524(g) of the U.S. Bankruptcy Code.  See Note 11 to our unaudited Consolidated Financial Statements.

[0000833444-15-000032:mdna:113]
[same as prior period, unchanged from 0000833444-15-000013:mdna:100]

[0000833444-15-000032:mdna:114]
Cash flow from operating activities can fluctuate significantly from period to period as working capital needs and the timing of payments for items such as restructuring activities, asbestos related liabilities, pension funding, income taxes and other items impact reported cash flow.

[0000833444-15-000032:mdna:115]
The net change in working capital decreased operating cash flow by $311 million in the six months ended March 27, 2015. The significant changes in working capital included an $87 million decrease in accounts payable, a $64 million decrease in accrued and other liabilities, a $64 million increase in inventories, a $44 million increase in prepaid expenses and other current assets, and a $30 million increase in contracts in process.

[0000833444-15-000032:mdna:116]
The net change in working capital decreased operating cash flow by $288 million in the six months ended March 28, 2014. The significant changes in working capital included a $220 million decrease in accrued and other liabilities,  a $48

[0000833444-15-000032:mdna:117]
million decrease in accounts payable, a $40 million increase in prepaid expenses and other current assets and a $24 million increase in inventories, partially offset by a $36 million decrease in accounts receivable.

[0000833444-15-000032:mdna:118]
During the six months ended March 27, 2015 and March 28, 2014, we paid approximately $55 million and $41 million, respectively, in cash related to restructuring activities.

[0000833444-15-000032:mdna:119]
In connection with the 2012 Separation, we paid $2 million and $31 million in separation costs during the six months ended March 27, 2015 and March 28, 2014, respectively.

[0000833444-15-000032:mdna:120]
During the six months ended March 27, 2015 and March 28, 2014, we made net payments related to asbestos liabilities of $8 million and $7 million, respectively.

[0000833444-15-000032:mdna:121]
During the six months ended March 27, 2015 and March 28, 2014, we made payments related to environmental remediation activities for a facility located in Marinette, Wisconsin, of $8 million and $54 million respectively.

[0000833444-15-000032:mdna:122]
During the six months ended March 28, 2014, Tyco settled a tax dispute with CIT Group, a former subsidiary.  Under the terms of the settlement agreement, Tyco received $60 million of which $25 million and $19 million was subsequently paid during fiscal 2014 to Medtronic and TE Connectivity, respectively, under the terms of the 2007 Tax Sharing Agreement.

[0000833444-15-000032:mdna:123]
During the six months ended March 27, 2015 and March 28, 2014, we made required contributions of $4 million and $7 million, respectively, to our U.S. pension plans and $9 million and $16 million, respectively, to our non-U.S. pension plans. We anticipate that we will contribute at least the minimum required to our pension plans in 2015 of $13 million for our U.S. plans and $23 million for our non-U.S. plans.

[0000833444-15-000032:mdna:124]
Income taxes paid, net of refunds, related to continuing operations were $65 million and $47 million during the six months ended March 27, 2015 and March 28, 2014, respectively.

[0000833444-15-000032:mdna:125]
Net interest paid related to continuing operations was $42 million and $43 million for the six months ended March 27, 2015 and March 28, 2014, respectively.

[0000833444-15-000032:mdna:126]
[same as prior period, unchanged from 0000833444-15-000013:mdna:113]

[0000833444-15-000032:mdna:127]
[same as prior period, unchanged from 0000833444-15-000013:mdna:114]

[0000833444-15-000032:mdna:128]
We made capital expenditures of $123 million and $135 million for the six months ended March 27, 2015 and March 28, 2014, respectively.  The level of capital expenditures in fiscal 2015 is expected to be in line with the spending levels in fiscal 2014.

[0000833444-15-000032:mdna:129]
During the six months ended March 27, 2015, we paid cash for acquisitions included in continuing operations totaling $525 million, net of cash acquired of $26 million, which primarily related to acquisitions in our ROW Installation & Services and Global Products segments.  During the six months ended March 28, 2014, we paid cash for acquisitions included in continuing operations totaling $54 million, net of $1 million cash acquired, which related to an acquisition included in our NA Installation & Services segment and ROW Installation & Services segments.

[0000833444-15-000032:mdna:130]
We maintain captive insurance companies to manage certain of our insurable liabilities. The captive insurance companies held certain investment accounts for the purposes of providing collateral for our insurable liabilities.  During fiscal 2014, the portfolio of investments was liquidated and we now provide letters of credit as collateral.  During the six months ended March 28, 2014, our captive insurance companies made net sales of approximately $101 million.  See Notes 10 and 18 to our unaudited Consolidated Financial Statements.

[0000833444-15-000032:mdna:131]
During the six months ended March 27, 2015, our time deposits of $275 million matured, and we made purchases of $288 million of investments, primarily consisting of exchange traded equity and fixed income funds, which are classified as available-for-sale investments and are restricted as to use.

[0000833444-15-000032:mdna:132]
During the six months ended March 27, 2015, our restricted cash increased by $39 million.  This increase was primarily driven by an increase of $14 million related to the asbestos-related qualified settlement fund, $13 million of restricted cash related to an acquisition, and $12 million of cash received from Mr. Swartz.

[0000833444-15-000032:mdna:133]
[same as prior period, unchanged from 0000833444-15-000013:mdna:120]

[0000833444-15-000032:mdna:134]
[same as prior period, unchanged from 0000833444-15-000013:mdna:121]

[0000833444-15-000032:mdna:135]
On February 25, 2015, TIFSA issued €500 million aggregate principal amount of public notes due 2025, which resulted in  proceeds of $567 million.

[0000833444-15-000032:mdna:136]
As of March 27, 2015 and September 26, 2014, TIFSA had no commercial paper outstanding.  The maximum aggregate amount of unsecured commercial paper notes available to be issued, on a private placement basis, under the commercial paper program is $1 billion as of March 27, 2015.

[0000833444-15-000032:mdna:137]
As of March 27, 2015 and September 26, 2014, there were no amounts drawn under the Company's revolving credit facility.

[0000833444-15-000032:mdna:138]
Pursuant to our share repurchase program, we may repurchase Tyco shares from time to time in open market purchases at prevailing market prices, in negotiated transactions off the market, or pursuant to an approved trading plan in accordance with applicable regulations.  During the six months ended March 27, 2015, we repurchased approximately 10 million ordinary  shares for approximately $417 million.  During the six months ended March 28, 2014, we repurchased approximately 7 million ordinary shares for approximately $250 million.

[0000833444-15-000032:mdna:139]
On March 4, 2015, the Board of Directors approved a quarterly dividend of $0.205 per share payable on May 20, 2015 to shareholders of record on April 24, 2015.  On March 5, 2014, our shareholders approved a cash dividend of $0.72 per ordinary share payable to shareholders in four quarterly installments of $0.18 in May 2014, August 2014, November 2014 and February 2015. During the six months ended March 27, 2015 and March 28, 2014, we paid cash dividends of approximately $151 million and $148 million, respectively.

[0000833444-15-000032:mdna:140]
Included in cash flows from financing activities for the six months ended March 27, 2015 is payment of contingent consideration of $23 million related to the acquisition of a business during fiscal year 2014.

[0000833444-15-000032:mdna:141]
Management believes that cash generated by or available to us should be sufficient to fund our capital and operational business needs for the foreseeable future, including capital expenditures, quarterly dividend payments, share repurchases, asbestos-related and other expenses.

[0000833444-15-000032:mdna:142]
Commitments and Contingencies

[0000833444-15-000032:mdna:143]
For a detailed discussion of contingencies related to tax and litigation matters, see Notes 6 and 11 to our unaudited Consolidated Financial Statements.

[0000833444-15-000032:mdna:144]
[same as prior period, unchanged from 0000833444-15-000013:mdna:130]

[0000833444-15-000032:mdna:145]
We had a backlog of unfilled orders of $4,715 million and $4,857 million as of March 27, 2015 and September 26, 2014, respectively.

[0000833444-15-000032:mdna:146]
[same as prior period, unchanged from 0000833444-15-000013:mdna:132]

[0000833444-15-000032:mdna:147]
|  | NA Installation& Services |  | ROWInstallation& Services |  | GlobalProducts |  | Total |
| As of September 26, 2014 |  |  |  |  |  |  |  |
| Backlog | $ | 992 |  |  | $ | 997 |  |  | $ | 181 |  |  | $ | 2,170 |  |
| Recurring revenue in force | 1,243 |  |  | 1,140 |  |  | — |  |  | 2,383 |  |
| Deferred revenue | 266 |  |  | 38 |  |  | — |  |  | 304 |  |
| Total Backlog | $ | 2,501 |  |  | $ | 2,175 |  |  | $ | 181 |  |  | $ | 4,857 |  |
| As of March 27, 2015 |  |  |  |  |  |  |  |  |  |  |  |
| Backlog | $ | 1,017 |  |  | $ | 903 |  |  | $ | 200 |  |  | $ | 2,120 |  |
| Recurring revenue in force | 1,231 |  |  | 1,080 |  |  | — |  |  | 2,311 |  |
| Deferred revenue | 249 |  |  | 35 |  |  | — |  |  | 284 |  |
| Total Backlog | $ | 2,497 |  |  | $ | 2,018 |  |  | $ | 200 |  |  | $ | 4,715 |  |

[0000833444-15-000032:mdna:148]
Backlog decreased $142 million, or 2.9%, to $4,715 million as of March 27, 2015 compared to $4,857 million as of September 26, 2014.  Acquisitions primarily in our Global Products business contributed $14 million to backlog while changes in foreign currency had an unfavorable impact of $226 million, or 4.7%, primarily in our ROW Installation & Services

[0000833444-15-000032:mdna:149]
segment.  The remaining change in backlog was driven by growth across all of our segments, which is comprised of $30 million in NA Installation & Services, $24 million in ROW Installation & Services, and $16 million in Global Products.

[0000833444-15-000032:mdna:150]
[same as prior period, unchanged from 0000833444-15-000013:mdna:135]

[0000833444-15-000032:mdna:151]
[same as prior period, unchanged from 0000833444-15-000013:mdna:136]

[0000833444-15-000032:mdna:152]
There are certain guarantees or indemnifications extended among Tyco, Medtronic, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 Separation and Distribution Agreements and the Tax Sharing Agreements. The guarantees primarily relate to certain contingent tax liabilities included in the Tax Sharing Agreements. At the time of the 2007 and 2012 Separations, we recorded liabilities necessary to recognize the fair value of such guarantees and indemnifications. See Note 6 to the unaudited Consolidated Financial Statements. In addition, prior to the 2007 and 2012 Separations we provided support in the form of financial and/or performance guarantees to various Medtronic, TE Connectivity, ADT and Tyco Flow Control operating entities. To the extent these guarantees were not assigned in connection with the 2007 and 2012 Separations, we remained as the guarantor, but were typically indemnified by the former subsidiary. See Note 18 to the unaudited Consolidated Financial Statements.

[0000833444-15-000032:mdna:153]
[same as prior period, unchanged from 0000833444-15-000013:mdna:138]

[0000833444-15-000032:mdna:154]
[same as prior period, unchanged from 0000833444-15-000013:mdna:139]

[0000833444-15-000032:mdna:155]
[same as prior period, unchanged from 0000833444-15-000013:mdna:140]

[0000833444-15-000032:mdna:156]
[same as prior period, unchanged from 0000833444-15-000013:mdna:141]

[0000833444-15-000032:mdna:157]
[same as prior period, unchanged from 0000833444-15-000013:mdna:142]

[0000833444-15-000032:mdna:158]
58

[0000833444-15-000032:mdna:159]
[same as prior period, unchanged from 0000833444-15-000013:mdna:143]

[0000833444-15-000032:mdna:160]
Quarter Ended March 27, 2015

[0000833444-15-000032:mdna:161]
|  | Net Revenue for the Quarter Ended March 28, 2014 |  | Base YearAdjustmentsDivestitures / Other |  | AdjustedFiscal 2014Base Revenue |  | ForeignCurrency |  | Acquisitions |  | OrganicRevenue(1) |  | OrganicGrowthPercentage |  | Net Revenue for the Quarter Ended March 27, 2015 |
|  | ($ in millions) |
| NA Installation & Services | $ | 939 |  |  | $ | — |  |  | $ | 939 |  |  | $ | (12 | ) |  | $ | 2 |  |  | $ | 15 |  |  | 1.6 | % |  | $ | 944 |  |
| ROW Installation & Services | 936 |  |  | — |  |  | 936 |  |  | (100 | ) |  | 13 |  |  | (2 | ) |  | (0.2 | )% |  | 847 |  |
| Global Products | 605 |  |  | — |  |  | 605 |  |  | (37 | ) |  | 26 |  |  | 45 |  |  | 7.4 | % |  | 639 |  |
| Total Net Revenue | $ | 2,480 |  |  | $ | — |  |  | $ | 2,480 |  |  | $ | (149 | ) |  | $ | 41 |  |  | $ | 58 |  |  | 2.3 | % |  | $ | 2,430 |  |

[0000833444-15-000032:mdna:162]
[same as prior period, unchanged from 0000833444-15-000013:mdna:146]

[0000833444-15-000032:mdna:163]
[same as prior period, unchanged from 0000833444-15-000013:mdna:147]

[0000833444-15-000032:mdna:164]
Six Months Ended March 27, 2015

[0000833444-15-000032:mdna:165]
|  | Net Revenue for the Quarter Ended March 28, 2014 |  | Base YearAdjustmentsDivestitures / Other |  | AdjustedFiscal 2014Base Revenue |  | ForeignCurrency |  | Acquisitions |  | OrganicRevenue(1) |  | OrganicGrowthPercentage |  | Net Revenue for the Six Months Ended March 27, 2015 |
|  | ($ in millions) |
| NA Installation & Services | $ | 1,896 |  |  | $ | — |  |  | $ | 1,896 |  |  | $ | (21 | ) |  | $ | 6 |  |  | $ | 14 |  |  | 0.7 | % |  | $ | 1,895 |  |
| ROW Installation & Services | 1,903 |  |  | (13 | ) |  | 1,890 |  |  | (163 | ) |  | 33 |  |  | 3 |  |  | 0.2 | % |  | 1,763 |  |
| Global Products | 1,170 |  |  | — |  |  | 1,170 |  |  | (54 | ) |  | 31 |  |  | 103 |  |  | 8.8 | % |  | 1,250 |  |
| Total Net Revenue | $ | 4,969 |  |  | $ | (13 | ) |  | $ | 4,956 |  |  | $ | (238 | ) |  | $ | 70 |  |  | $ | 120 |  |  | 2.4 | % |  | $ | 4,908 |  |

[0000833444-15-000032:mdna:166]
| (1) | Organic revenue growth percentage based on adjusted fiscal 2014 base revenue. |

[0000833444-15-000032:mdna:167]
[same as prior period, unchanged from 0000833444-15-000013:mdna:148]

[0000833444-15-000032:mdna:168]
[same as prior period, unchanged from 0000833444-15-000013:mdna:149]

[0000833444-15-000032:mdna:169]
[same as prior period, unchanged from 0000833444-15-000013:mdna:150]

[0000833444-15-000032:mdna:170]
[same as prior period, unchanged from 0000833444-15-000013:mdna:151]

[0000833444-15-000032:mdna:171]
[same as prior period, unchanged from 0000833444-15-000013:mdna:152]

[0000833444-15-000032:mdna:172]
| • | the outcome of litigation, arbitrations and governmental proceedings; |

[0000833444-15-000032:mdna:173]
| • | effect of income tax audits, litigation, settlements and appeals; |

[0000833444-15-000032:mdna:174]
[same as prior period, unchanged from 0000833444-15-000013:mdna:155]

[0000833444-15-000032:mdna:175]
[same as prior period, unchanged from 0000833444-15-000013:mdna:156]

[0000833444-15-000032:mdna:176]
[same as prior period, unchanged from 0000833444-15-000013:mdna:157]

[0000833444-15-000032:mdna:177]
| • | other capital market conditions, including availability of funding sources; |

[0000833444-15-000032:mdna:178]
| • | currency exchange rate fluctuations; |

[0000833444-15-000032:mdna:179]
[same as prior period, unchanged from 0000833444-15-000013:mdna:159]

[0000833444-15-000032:mdna:180]
[same as prior period, unchanged from 0000833444-15-000013:mdna:160]

[0000833444-15-000032:mdna:181]
[same as prior period, unchanged from 0000833444-15-000013:mdna:161]

[0000833444-15-000032:mdna:182]
[same as prior period, unchanged from 0000833444-15-000013:mdna:162]

[0000833444-15-000032:mdna:183]
[same as prior period, unchanged from 0000833444-15-000013:mdna:163]

[0000833444-15-000032:mdna:184]
[same as prior period, unchanged from 0000833444-15-000013:mdna:164]

[0000833444-15-000032:mdna:185]
[same as prior period, unchanged from 0000833444-15-000013:mdna:165]

[0000833444-15-000032:mdna:186]
[same as prior period, unchanged from 0000833444-15-000013:mdna:166]

[0000833444-15-000032:mdna:187]
[same as prior period, unchanged from 0000833444-15-000013:mdna:167]

[0000833444-15-000032:mdna:188]
[same as prior period, unchanged from 0000833444-15-000013:mdna:168]

[0000833444-15-000032:mdna:189]
[same as prior period, unchanged from 0000833444-15-000013:mdna:169]

[0000833444-15-000032:mdna:190]
[same as prior period, unchanged from 0000833444-15-000013:mdna:170]
