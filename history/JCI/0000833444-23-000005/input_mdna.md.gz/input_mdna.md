# JCI MD&A — 0000833444-23-000005


## mdna

[0000833444-23-000005:mdna:1]
[same as prior period, unchanged from 0000833444-22-000036:mdna:1]

[0000833444-23-000005:mdna:2]
[same as prior period, unchanged from 0000833444-22-000036:mdna:2]

[0000833444-23-000005:mdna:3]
[same as prior period, unchanged from 0000833444-22-000036:mdna:3]

[0000833444-23-000005:mdna:4]
[same as prior period, unchanged from 0000833444-22-000036:mdna:4]

[0000833444-23-000005:mdna:5]
[same as prior period, unchanged from 0000833444-22-000036:mdna:5]

[0000833444-23-000005:mdna:6]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including residential and commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions powered by its OpenBlue software platform and capabilities. The Company partners with customers by leveraging its broad product portfolio and digital capabilities powered by OpenBlue, together with

[0000833444-23-000005:mdna:7]
its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency, enhance security, create healthy environments and reduce greenhouse gas emissions.

[0000833444-23-000005:mdna:8]
The following information should be read in conjunction with the September 30, 2022 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in our Annual Report on Form 10-K for the year ended September 30, 2022 filed with the SEC on November 15, 2022. References in the following discussion and analysis to "Three Months" (or similar language) refer to the three months ended December 31, 2022 compared to the three months ended December 31, 2021.

[0000833444-23-000005:mdna:9]
[same as prior period, unchanged from 0000833444-22-000036:mdna:9]

[0000833444-23-000005:mdna:10]
[same as prior period, unchanged from 0000833444-22-000036:mdna:10]

[0000833444-23-000005:mdna:11]
As a result of the Company’s global presence, a significant portion of its revenues and expenses is denominated in currencies other than the U.S. dollar. The Company is therefore subject to non-U.S. currency risks and non-U.S. exchange exposure. While the Company employs financial instruments to hedge some of its transactional foreign exchange exposure, these activities do not insulate it completely from those exposures. In addition, the currency exposure from the translation of non-U.S. dollar functional currency subsidiaries are not able to be hedged. Exchange rates can be volatile and a substantial weakening or strengthening of foreign currencies against the U.S. dollar could increase or reduce the Company’s profit margin, respectively, and impact the comparability of results from period to period. During the three months ended December 31, 2022, revenue and profits were adversely impacted due to the strengthening of the U.S. dollar against foreign currencies. The continued strength of the U.S. dollar could continue to adversely impact the Company's results.

[0000833444-23-000005:mdna:12]
The Company continues to observe trends demonstrating increased interest and demand for its products and services that enable smart, safe, efficient and sustainable buildings. This demand is driven in part by government tax incentives, building performance standards and other regulations designed to limit emissions and combat climate change. In particular, legislative and regulatory initiatives such as the U.S. Climate Smart Buildings Initiative, U.S. Inflation Reduction Act and EU Energy Performance of Buildings Directive include provisions designed to fund and encourage investment in decarbonization and digital technologies for buildings. This demand is supplemented by an increase in commitments in both the public and private sectors to reduce emissions and/or achieve net zero emissions. The Company seeks to capitalize on these trends to drive growth by developing and delivering technologies and solutions to create smart, sustainable and healthy buildings. The Company is investing in new digital and product capabilities, including its OpenBlue platform, to enable it to deliver sustainable, high-efficiency products and tailored services to enable customers to achieve their sustainability goals. The Company is leveraging its install base, together with data-driven products and services to offer outcome-based solutions to customers with a focus on generating accelerated growth in services and recurring revenue.

[0000833444-23-000005:mdna:13]
The Company has experienced, and expects to continue to experience, increased material cost inflation and component shortages, as well as disruptions and delays in its supply chain, as a result of global macroeconomic trends, including increased global demand, the conflict between Russia and Ukraine, government-mandated actions in response to COVID-19, particularly in China, and labor shortages. Actions taken by the Company to mitigate supply chain disruptions and inflation, including expanding and redistributing its supplier network, supplier financing, price increases and productivity improvements, have generally been successful in offsetting some, but not all, of the impact of these trends. The collective impact of these trends has been favorable to revenue due to increased demand and price increases to offset inflation, while negatively impacting margins due to supply chain disruptions and cost pressures. However, the Company is beginning to observe improved margins as supply chain disruptions ease and higher priced backlog is converted to sales. Although the Company has experienced recent improvement in its supply chain, the Company could experience further disruptions, shortages and cost increases in the future, the effect of which will depend on the Company’s ability to successfully mitigate and offset the impact of these events.

[0000833444-23-000005:mdna:14]
During the second quarter of fiscal 2022, the Company suspended its operations in Russia in response to the conflict between Russia and Ukraine, with existing contractual obligations being fulfilled in a manner that fully complies with all sanctions and

[0000833444-23-000005:mdna:15]
38

[0000833444-23-000005:mdna:16]
trade controls. The Company has subsequently reduced its business presence and operations in Russia. Although these actions have not had and are not expected to have a material impact on the Company’s operating results, the broader consequences of this conflict, including heightened supply chain disruption, inflation, economic instability and other factors have and could continue to adversely impact the Company’s results of operations.

[0000833444-23-000005:mdna:17]
Impact of COVID-19 Pandemic

[0000833444-23-000005:mdna:18]
The COVID-19 pandemic continues to impact aspects of the Company's operations and results. Recently, the Company’s facilities have generally operated at normal levels. As a result of the pandemic, the Company has seen an increase in demand for its products and solutions that promote building health and optimize customers’ infrastructure.

[0000833444-23-000005:mdna:19]
[same as prior period, unchanged from 0000833444-22-000036:mdna:19]

[0000833444-23-000005:mdna:20]
The extent to which the COVID-19 pandemic continues to impact the Company’s results of operations and financial condition will depend on future developments that are highly uncertain and cannot be predicted. See the section entitled "Risk Factors" in Johnson Controls' Annual Report on Form 10-K for the year ended September 30, 2022 filed with the United States Securities and Exchange Commission ("SEC") on November 15, 2022 for additional discussion of risks related to COVID-19.

[0000833444-23-000005:mdna:21]
[same as prior period, unchanged from 0000833444-22-000036:mdna:23]

[0000833444-23-000005:mdna:22]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  |  |  |  |  |  |
| Net sales | $ | 6,068 |  |  | $ | 5,862 |  |  | 4 | % |  |  |  |  |  |  |

[0000833444-23-000005:mdna:23]
The increase in consolidated net sales for the three months ended December 31, 2022 was due to higher organic sales ($497 million) and incremental sales from acquisitions ($27 million), partially offset by the unfavorable impact of foreign currency translation ($300 million) and lower sales due to business divestitures ($18 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales increased 9% as compared to the prior year, attributable to increased pricing in response to inflation pressures. Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-23-000005:mdna:24]
[same as prior period, unchanged from 0000833444-22-000036:mdna:27]

[0000833444-23-000005:mdna:25]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  |  |  |  |  |  |
| Cost of sales | $ | 3,977 |  |  | $ | 3,971 |  |  | — | % |  |  |  |  |  |  |
| Gross profit | 2,091 |  |  | 1,891 |  |  | 11 | % |  |  |  |  |  |  |
| % of sales | 34.5 | % |  | 32.3 | % |  |  |  |  |  |  |  |  |

[0000833444-23-000005:mdna:26]
Cost of sales and gross profit increased for the three-month period ended December 31, 2022, and gross profit as a percentage of sales increased by 220 basis points. Gross profit increased due to sales growth and favorable price/cost, partially offset by unfavorable foreign currency translation ($94 million) and the unfavorable year-over-year impact of net mark-to-market adjustments. Gross profit as a percentage of sales increased primarily due to favorable price/cost. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA").

[0000833444-23-000005:mdna:27]
[same as prior period, unchanged from 0000833444-22-000036:mdna:32]

[0000833444-23-000005:mdna:28]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  |  |  |  |  |  |
| Selling, general and administrative expenses | $ | 1,571 |  |  | $ | 1,369 |  |  | 15 | % |  |  |  |  |  |  |
| % of sales | 25.9 | % |  | 23.4 | % |  |  |  |  |  |  |  |  |

[0000833444-23-000005:mdna:29]
Selling, general and administrative expenses ("SG&A") for the three-month period ended December 31, 2022 increased $202 million, and SG&A as a percentage of sales increased by 250 basis points. The increase in SG&A was primarily due to the unfavorable year-over-year impact of net mark-to-market adjustments, a loss associated with a fire at a leased warehouse facility, certain investments to support growth and one-time transaction and separation costs, partially offset by favorable foreign currency translation ($65 million). Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA.

[0000833444-23-000005:mdna:30]
[same as prior period, unchanged from 0000833444-22-000036:mdna:36]

[0000833444-23-000005:mdna:31]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  |  |  |  |  |  |
| Restructuring and impairment costs | $ | 345 |  |  | $ | 49 |  |  | * |  |  |  |  |  |  |

[0000833444-23-000005:mdna:32]
[same as prior period, unchanged from 0000833444-22-000036:mdna:38]

[0000833444-23-000005:mdna:33]
Restructuring and impairment costs for the three-month period ended December 31, 2022 included $288 million of impairment costs related to businesses classified as held-for-sale, $30 million in severance and $27 million in other long-lived asset impairments and restructuring costs.

[0000833444-23-000005:mdna:34]
Restructuring and impairment costs for the three-month period ended December 31, 2021 included primarily severance and other cash related items.

[0000833444-23-000005:mdna:35]
Refer to Note 4, "Assets and Liabilities Held for Sale" and Note 17, "Significant Restructuring and Impairment Costs," of the notes to the consolidated financial statements for further disclosure related to the Company's restructuring plans and impairment costs.

[0000833444-23-000005:mdna:36]
[same as prior period, unchanged from 0000833444-22-000036:mdna:40]

[0000833444-23-000005:mdna:37]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  |  |  |  |  |  |
| Net financing charges | $ | 67 |  |  | $ | 53 |  |  | 26 | % |  |  |  |  |  |  |

[0000833444-23-000005:mdna:38]
[same as prior period, unchanged from 0000833444-22-000036:mdna:42]

[0000833444-23-000005:mdna:39]
[same as prior period, unchanged from 0000833444-22-000036:mdna:43]

[0000833444-23-000005:mdna:40]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  |  |  |  |  |  |
| Equity income | $ | 62 |  |  | $ | 70 |  |  | (11) | % |  |  |  |  |  |  |

[0000833444-23-000005:mdna:41]
The decrease in equity income for the three months ended December 31, 2022 was primarily due to lower income at certain partially-owned affiliates of Johnson Controls within the Building Solutions EMEA/LA segment. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA.

[0000833444-23-000005:mdna:42]
[same as prior period, unchanged from 0000833444-22-000036:mdna:47]

[0000833444-23-000005:mdna:43]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  |  |  |  |  |  |
| Income tax provision | $ | 14 |  |  | $ | 71 |  |  | (80) | % |  |  |  |  |  |  |
| Effective tax rate | 8.2 | % |  | 14.5 | % |  |  |  |  |  |  |  |  |

[0000833444-23-000005:mdna:44]
[same as prior period, unchanged from 0000833444-22-000036:mdna:49]

[0000833444-23-000005:mdna:45]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended December 31, 2022, the Company's effective tax rate for continuing operations was 8.2% and was lower than the statutory tax rate of 12.5% primarily due to impairment and restructuring charges and the benefits of continuing global tax planning initiatives, partially offset by tax rate differentials. For the three months ended December 31, 2021, the Company's effective tax rate for continuing operations was 14.5% and was higher than the statutory tax rate of 12.5% primarily due to the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. The effective tax rate for the three months ended December 31, 2022 decreased as compared to the three months ended December 31, 2021 primarily due to the discrete tax items. Refer to Note 18, "Income Taxes," of the notes to the consolidated financial statements for further detail.

[0000833444-23-000005:mdna:46]
[same as prior period, unchanged from 0000833444-22-000036:mdna:56]

[0000833444-23-000005:mdna:47]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  |  |  |  |  |  |
| Income from continuing operations attributable to noncontrolling interests | $ | 38 |  |  | $ | 38 |  |  | — | % |  |  |  |  |  |  |

[0000833444-23-000005:mdna:48]
41

[0000833444-23-000005:mdna:49]
[same as prior period, unchanged from 0000833444-22-000036:mdna:59]

[0000833444-23-000005:mdna:50]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  |  |  |  |  |  |
| Net income attributable to Johnson Controls | $ | 118 |  |  | $ | 381 |  |  | (69) | % |  |  |  |  |  |  |

[0000833444-23-000005:mdna:51]
The decrease in net income attributable to Johnson Controls for the three months ended December 31, 2022 was primarily due to higher restructuring and impairment costs and higher SG&A, partially offset by higher gross profit, all of which are discussed above.

[0000833444-23-000005:mdna:52]
Diluted earnings per share attributable to Johnson Controls for the three months ended December 31, 2022 was $0.17 compared to $0.54 for the three months ended December 31, 2021.

[0000833444-23-000005:mdna:53]
[same as prior period, unchanged from 0000833444-22-000036:mdna:63]

[0000833444-23-000005:mdna:54]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  |  |  |  |  |  |
| Comprehensive income attributable to Johnson Controls | $ | 165 |  |  | $ | 468 |  |  | (65) | % |  |  |  |  |  |  |

[0000833444-23-000005:mdna:55]
The decrease in comprehensive income attributable to Johnson Controls for the three months ended December 31, 2022 was due to lower net income attributable to Johnson Controls ($263 million) and a decrease in other comprehensive income attributable to Johnson Controls ($40 million) resulting from currency translation adjustments and realized and unrealized losses on derivatives.

[0000833444-23-000005:mdna:56]
[same as prior period, unchanged from 0000833444-22-000036:mdna:68]

[0000833444-23-000005:mdna:57]
[same as prior period, unchanged from 0000833444-22-000036:mdna:69]

[0000833444-23-000005:mdna:58]
[same as prior period, unchanged from 0000833444-22-000036:mdna:72]

[0000833444-23-000005:mdna:59]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,367 |  |  | $ | 2,152 |  |  | 10 | % |  |  |  |  |  |  |
| Building Solutions EMEA/LA | 975 |  |  | 959 |  |  | 2 | % |  |  |  |  |  |  |
| Building Solutions Asia Pacific | 646 |  |  | 675 |  |  | (4) | % |  |  |  |  |  |  |
| Global Products | 2,080 |  |  | 2,076 |  |  | — | % |  |  |  |  |  |  |
|  | $ | 6,068 |  |  | $ | 5,862 |  |  | 4 | % |  |  |  |  |  |  |

[0000833444-23-000005:mdna:60]
•The increase in Building Solutions North America was due to higher prices and volumes ($223 million) and incremental sales related to business acquisitions ($7 million), partially offset by the unfavorable impact of foreign currency translation ($15 million). Sales growth was led by continued growth in the project-based business, including low double-digit growth in new construction.

[0000833444-23-000005:mdna:61]
•The increase in Building Solutions EMEA/LA was due to higher prices ($103 million) and incremental sales related to business acquisitions ($20 million), partially offset by the unfavorable impact of foreign currency translation ($89 million) and business divestitures ($18 million). Excluding the impacts of foreign currency translation and business acquisitions and divestitures, sales growth was led by mid-teens growth in the service-based business and low double-digit growth in Fire & Security. By region, there was strong organic growth in Europe, Latin America and the Middle East.

[0000833444-23-000005:mdna:62]
•The decrease in Building Solutions Asia Pacific was due to the unfavorable impact of foreign currency translation ($71 million), partially offset by the net impact of higher prices and lower volumes ($42 million). Excluding the impacts of foreign currency translation, sales growth was led by strong demand for HVAC & Controls. By region, sales in China grew 1% in the quarter, as strong service execution offset a decline in the project-based business.

[0000833444-23-000005:mdna:63]
•The increase in Global Products was due to the net impact of higher prices and lower volumes ($129 million), partially offset by the unfavorable impact of foreign currency translation ($125 million). Excluding the impacts of foreign currency translation, sales growth was driven by strong price realization and continued growth in Applied and Fire Detection products.

[0000833444-23-000005:mdna:64]
[same as prior period, unchanged from 0000833444-22-000036:mdna:84]

[0000833444-23-000005:mdna:65]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2022 |  | 2021 |  | Change |  |  |  |  |  |  |
| Building Solutions North America | $ | 267 |  |  | $ | 250 |  |  | 7 | % |  |  |  |  |  |  |
| Building Solutions EMEA/LA | 75 |  |  | 104 |  |  | (28) | % |  |  |  |  |  |  |
| Building Solutions Asia Pacific | 68 |  |  | 68 |  |  | 0 | % |  |  |  |  |  |  |
| Global Products | 382 |  |  | 301 |  |  | 27 | % |  |  |  |  |  |  |
|  | $ | 792 |  |  | $ | 723 |  |  | 10 | % |  |  |  |  |  |  |

[0000833444-23-000005:mdna:66]
•The increase in Building Solutions North America was primarily due to favorable price/cost and productivity savings, partially offset by unfavorable project mix.

[0000833444-23-000005:mdna:67]
•The decrease in Building Solutions EMEA/LA was primarily due to unfavorable project mix and the unfavorable impact of foreign currency translation ($9 million), partially offset by favorable volume leverage and productivity savings.

[0000833444-23-000005:mdna:68]
•Building Solutions Asia Pacific remained flat as favorable price/cost and productivity savings were offset by the unfavorable impact of foreign currency translation ($10 million) and lower volumes.

[0000833444-23-000005:mdna:69]
•The increase in Global Products was primarily due to favorable price/cost and productivity savings, partially offset by an uninsured loss associated with a fire at a leased warehouse facility in ($40 million) and the unfavorable impact of foreign currency translation ($15 million).

[0000833444-23-000005:mdna:70]
[same as prior period, unchanged from 0000833444-22-000036:mdna:96]

[0000833444-23-000005:mdna:71]
The Company’s backlog is applicable to its sales of systems and services. At December 31, 2022, the backlog was $12.7 billion, of which $11.3 billion was attributable to the field business. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-23-000005:mdna:72]
At December 31, 2022, remaining performance obligations were $18.4 billion, which is $5.7 billion higher than the Company's backlog of $12.7 billion. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-23-000005:mdna:73]
•Remaining performance obligations include large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which are services to be performed over the building's lifetime with average initial contract

[0000833444-23-000005:mdna:74]
terms of 25 to 35 years for the entire term of the contract versus backlog which includes only the lifecycle period of these contracts which approximates five years;

[0000833444-23-000005:mdna:75]
•Remaining performance obligations exclude certain customer contracts with a term of one year or less or contracts that are cancellable without substantial penalty versus backlog which includes short-term and cancellable contracts; and

[0000833444-23-000005:mdna:76]
[same as prior period, unchanged from 0000833444-22-000036:mdna:101]

[0000833444-23-000005:mdna:77]
[same as prior period, unchanged from 0000833444-22-000036:mdna:102]

[0000833444-23-000005:mdna:78]
[same as prior period, unchanged from 0000833444-22-000036:mdna:104]

[0000833444-23-000005:mdna:79]
[same as prior period, unchanged from 0000833444-22-000036:mdna:105]

[0000833444-23-000005:mdna:80]
|  | December 31, |  | September 30, |  |  |
| (in millions) | 2022 |  | 2022 |  | Change |
| Current assets | $ | 11,837 |  |  | $ | 11,685 |  |  |  |
| Current liabilities | (11,563) |  |  | (11,239) |  |  |  |
|  | 274 |  |  | 446 |  |  | (39) | % |
| Less: Cash and cash equivalents | (1,509) |  |  | (2,031) |  |  |  |
| Add: Short-term debt | 1,026 |  |  | 669 |  |  |  |
| Add: Current portion of long-term debt | 937 |  |  | 865 |  |  |  |
| Less: Current assets held for sale | (418) |  |  | (387) |  |  |  |
| Add: Current liabilities held for sale | 310 |  |  | 236 |  |  |  |
| Working capital (as defined) | $ | 620 |  |  | $ | (202) |  |  | * |
| Accounts receivable - net | $ | 5,722 |  |  | $ | 5,528 |  |  | 4 | % |
| Inventories | 2,895 |  |  | 2,510 |  |  | 15 | % |
| Accounts payable | 4,138 |  |  | 4,241 |  |  | (2) | % |

[0000833444-23-000005:mdna:81]
[same as prior period, unchanged from 0000833444-22-000036:mdna:54]

[0000833444-23-000005:mdna:82]
•Working capital is a non-GAAP financial measure. The Company defines working capital as current assets less current liabilities, excluding cash, short-term debt, the current portion of long-term debt, and current assets and liabilities held for sale. Management believes that this measure of working capital, which excludes financing-related items and businesses to be divested, provides a more useful measurement of the Company’s operating performance.

[0000833444-23-000005:mdna:83]
•The increase in working capital at December 31, 2022 as compared to September 30, 2022, was primarily due to an increase in inventory due to supply chain disruptions, an increase in accounts receivable and a decrease in accounts payable.

[0000833444-23-000005:mdna:84]
•The Company’s days sales in accounts receivable at December 31, 2022 and September 30, 2022 were 60 days and 51 days, respectively. There has been no significant adverse changes in the level of overdue receivables or significant changes in revenue recognition methods.

[0000833444-23-000005:mdna:85]
•The Company’s inventory turns for the three months ended December 31, 2022 were lower than the comparable period ended September 30, 2022 primarily due to supply chain disruptions.

[0000833444-23-000005:mdna:86]
•Days in accounts payable at December 31, 2022 were 93 days, higher than 85 days at the comparable period ended September 30, 2022, primarily due to timing of payments.

[0000833444-23-000005:mdna:87]
[same as prior period, unchanged from 0000833444-22-000036:mdna:113]

[0000833444-23-000005:mdna:88]
|  |  | Three Months Ended December 31, |
| (in millions) |  | 2022 |  | 2021 |
| Cash provided (used) by operating activities |  | $ | (296) |  |  | $ | 392 |  |
| Cash used by investing activities |  | (189) |  |  | (218) |  |
| Cash provided (used) by financing activities |  | 9 |  |  | (357) |  |

[0000833444-23-000005:mdna:89]
•The increase in cash used by operating activities was primarily due to the timing of accounts payable and accrued liabilities payments.

[0000833444-23-000005:mdna:90]
•The decrease in cash used by investing activities was primarily due to lower cash payments made for acquisitions and increased sales of property, plant and equipment, partially offset by prior year divestitures.

[0000833444-23-000005:mdna:91]
•The increase in cash provided by financing activities was primarily due to lower stock repurchases.

[0000833444-23-000005:mdna:92]
[same as prior period, unchanged from 0000833444-22-000036:mdna:118]

[0000833444-23-000005:mdna:93]
|  | December 31, |  | September 30, |  |  |
| (in millions) | 2022 |  | 2022 |  | Change |
| Short-term debt | $ | 1,026 |  |  | $ | 669 |  |  |  |
| Current portion of long-term debt | 937 |  |  | 865 |  |  |  |
| Long-term debt | 7,784 |  |  | 7,426 |  |  |  |
| Total debt | 9,747 |  |  | 8,960 |  |  | 9 | % |
| Less: Cash and cash equivalents | 1,509 |  |  | 2,031 |  |  |  |
| Total net debt | 8,238 |  |  | 6,929 |  |  | 19 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 16,046 |  |  | 16,268 |  |  | (1) | % |
| Total capitalization | $ | 24,284 |  |  | $ | 23,197 |  |  | 5 | % |
| Total net debt as a % of total capitalization | 33.9 | % |  | 29.9 | % |  |  |

[0000833444-23-000005:mdna:94]
[same as prior period, unchanged from 0000833444-22-000036:mdna:120]

[0000833444-23-000005:mdna:95]
[same as prior period, unchanged from 0000833444-22-000036:mdna:121]

[0000833444-23-000005:mdna:96]
•As of December 31, 2022, approximately $3.5 billion remains available under the Company's share repurchase authorization, which does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. The Company expects to repurchase outstanding shares from time to time depending on market conditions, alternate uses of capital, liquidity, and the economic environment.

[0000833444-23-000005:mdna:97]
•The Company declared a dividend of $0.35 per common share in the quarter ended December 31, 2022 and intends to continue paying dividends throughout fiscal 2023.

[0000833444-23-000005:mdna:98]
•The Company believes its capital resources and liquidity position, including cash and cash equivalents of $1.5 billion at December 31, 2022, are adequate to fund operations and meet its obligations for the foreseeable future. The Company expects requirements for working capital, capital expenditures, dividends, minimum pension contributions, debt maturities

[0000833444-23-000005:mdna:99]
and any potential acquisitions or stock repurchases in the remainder of fiscal 2023 will be funded from operations, supplemented by short- and long-term borrowings, if required.

[0000833444-23-000005:mdna:100]
–The Company manages its short-term debt position in the U.S. and euro commercial paper and bank loan markets. The Company had $715 million and $172 million of commercial paper outstanding as of December 31, 2022 and September 30, 2022, respectively.

[0000833444-23-000005:mdna:101]
–The Company expects to file a new shelf registration statement with the SEC under which it may issue additional debt securities, ordinary shares, preferred shares, depository shares, warrants purchase contracts and units that may be offered in one or more offerings on terms to be determined at the time of the offering. The Company anticipates that the proceeds of any offering would be used for general corporate purposes, including repayment of indebtedness, acquisitions, additions to working capital, repurchases of ordinary shares, dividends, capital expenditures and investments in the Company's subsidiaries.

[0000833444-23-000005:mdna:102]
–The Company also has the ability to draw on its $2.5 billion revolving credit facility which expires in December 2024 or its $0.5 billion 364-day revolving credit facility which expires in November 2023. There were no draws on the revolving credit facilities as of December 31, 2022 and September 30, 2022.

[0000833444-23-000005:mdna:103]
•The Company's ability to access the global capital markets and the related cost of financing is dependent upon, among other factors, the Company's credit ratings. As of December 31, 2022, the Company's credit ratings and outlook were as follows:

[0000833444-23-000005:mdna:104]
| Rating Agency |  | Short-Term Rating |  | Long-Term Rating |  | Outlook |
| S&P |  | A-2 |  | BBB+ |  | Stable |
| Moody's |  | P-2 |  | Baa2 |  | Positive |

[0000833444-23-000005:mdna:105]
[same as prior period, unchanged from 0000833444-22-000036:mdna:128]

[0000833444-23-000005:mdna:106]
•Financial covenants in the Company's revolving credit facilities requires a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of December 31, 2022, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures governing its notes, and expects to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-23-000005:mdna:107]
•The key financial assumptions used in calculating the Company’s pension liability are determined annually, or whenever plan assets and liabilities are re-measured as required under accounting principles generally accepted in the U.S., including the expected rate of return on its plan assets. In fiscal 2023, the Company believes the long-term rate of return will approximate 8.25%, 3.70% and 6.65% for U.S. pension, non-U.S. pension and postretirement plans, respectively. During the first three months of fiscal 2023, the Company made approximately $9 million in total pension and postretirement contributions. In total, the Company expects to contribute approximately $38 million in cash to its defined benefit pension plans in fiscal 2023. The Company expects to contribute $3 million in cash to its postretirement plans in fiscal 2023.

[0000833444-23-000005:mdna:108]
•The Company earns a significant amount of its income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances. However, in fiscal 2022, the Company recorded income tax expense related to a change in the Company's assertion over the outside basis differences of the Company’s investment in certain subsidiaries as a result of the planned divestitures. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. The Company's intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and

[0000833444-23-000005:mdna:109]
cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at its Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings.

[0000833444-23-000005:mdna:110]
[same as prior period, unchanged from 0000833444-22-000036:mdna:134]

[0000833444-23-000005:mdna:111]
[same as prior period, unchanged from 0000833444-22-000036:mdna:135]

[0000833444-23-000005:mdna:112]
[same as prior period, unchanged from 0000833444-22-000036:mdna:139]

[0000833444-23-000005:mdna:113]
The following information is provided in compliance with Rule 13-01 of Regulation S-X under the Securities Exchange Act of 1934 with respect to the (i) $625 million aggregate principal amount of 1.750% Senior Notes due 2030 (the “2030 Notes”), (ii) €500 million aggregate principal amount of 0.375% Senior Notes due 2027 (the “2027 Notes”), (iii) €500 million aggregate principal amount of 1.000% Senior Notes due 2032 (the “2032 Notes”), (iv) $500 million aggregate principal amount of 2.000% Sustainability-Linked Senior Notes due 2031 (the “2031 Notes”), (v) €600 million aggregate principal amount of  3.000% Senior Notes due 2028 (the “2028 Notes”) and (vi) $400 million aggregate principal amount of 4.900% Senior Notes due 2032 (the “2032 Notes 2” and together with the 2032 Notes, the 2030 Notes, the 2028 Notes and the 2027 Notes, the “Notes”), each issued by Johnson Controls International plc ("Parent Company") and Tyco Fire & Security Finance S.C.A. (“TFSCA”), a corporate partnership limited by shares (société en commandite par actions) incorporated and organized under the laws of the Grand Duchy of Luxembourg (“Luxembourg”).

[0000833444-23-000005:mdna:114]
[same as prior period, unchanged from 0000833444-22-000036:mdna:141]

[0000833444-23-000005:mdna:115]
[same as prior period, unchanged from 0000833444-22-000036:mdna:142]

[0000833444-23-000005:mdna:116]
[same as prior period, unchanged from 0000833444-22-000036:mdna:143]

[0000833444-23-000005:mdna:117]
|  |  | Three Months Ended December 31, 2022 |  | Year EndedSeptember 30, 2022 |  |
| Net sales |  | $ | — |  |  | $ | — |  |  |
| Gross profit |  | — |  |  | — |  |  |
| Loss from continuing operations |  | (94) |  |  | (268) |  |  |
| Net loss |  | (94) |  |  | (268) |  |  |
| Income attributable to noncontrolling interests |  | — |  |  | — |  |  |
| Net loss attributable to the entity |  | (94) |  |  | (268) |  |  |

[0000833444-23-000005:mdna:118]
[same as prior period, unchanged from 0000833444-22-000036:mdna:145]

[0000833444-23-000005:mdna:119]
|  |  | Three Months Ended December 31, 2022 |  | Year EndedSeptember 30, 2022 |  |
| Net sales |  | $ | — |  |  | $ | — |  |  |
| Gross profit |  | — |  |  | — |  |  |
| Income from continuing operations |  | 3 |  |  | 92 |  |  |
| Net income |  | 3 |  |  | 92 |  |  |
| Income attributable to noncontrolling interests |  | — |  |  | — |  |  |
| Net income attributable to the entity |  | 3 |  |  | 92 |  |  |

[0000833444-23-000005:mdna:120]
The following table presents summarized balance sheet information as of December 31, 2022 and September 30, 2022 (in millions):

[0000833444-23-000005:mdna:121]
|  |  | December 31, 2022 |  | September 30, 2022 |  |
| Current assets |  | $ | 714 |  |  | $ | 1,231 |  |  |
| Noncurrent assets |  | 243 |  |  | 243 |  |  |
| Current liabilities |  | 6,856 |  |  | 5,463 |  |  |
| Noncurrent liabilities |  | 7,527 |  |  | 7,176 |  |  |
| Noncontrolling interests |  | — |  |  | — |  |  |

[0000833444-23-000005:mdna:122]
[same as prior period, unchanged from 0000833444-22-000036:mdna:150]

[0000833444-23-000005:mdna:123]
|  |  | December 31, 2022 |  | September 30, 2022 |  |
| Current assets |  | $ | 342 |  |  | $ | 455 |  |  |
| Noncurrent assets |  | 3,543 |  |  | 2,952 |  |  |
| Current liabilities |  | 7,218 |  |  | 2,538 |  |  |
| Noncurrent liabilities |  | 6,331 |  |  | 6,228 |  |  |
| Noncontrolling interests |  | — |  |  | — |  |  |

[0000833444-23-000005:mdna:124]
The same accounting policies as described in Note 1, "Summary of Significant Accounting Policies," of the Company's Annual Report on 10-K for the year ended September 30, 2022 are used by the Parent Company and each of its subsidiaries in connection with the summarized financial information presented above.

[0000833444-23-000005:mdna:125]
48

[0000833444-23-000005:mdna:126]
[same as prior period, unchanged from 0000833444-22-000036:mdna:153]

[0000833444-23-000005:mdna:127]
[same as prior period, unchanged from 0000833444-22-000036:mdna:154]

[0000833444-23-000005:mdna:128]
[same as prior period, unchanged from 0000833444-22-000036:mdna:155]

[0000833444-23-000005:mdna:129]
The Company prepares its consolidated financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). This requires management to make estimates and assumptions that affect reported amounts and related disclosures. Actual results could differ from those estimates. The Company’s critical accounting estimates requiring significant judgement that could materially impact the Company's results of operations, financial position and cash flows are described in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in the Company’s Annual Report on Form 10-K for the year ended September 30, 2022. Since the date of the Company’s most recent Annual Report, there have been no material changes in the Company’s critical accounting estimates or assumptions.
