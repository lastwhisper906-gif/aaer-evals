# JCI notes — 0000833444-23-000005


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-23-000005:notes:1]
Basis of Presentation
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company," or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2022 filed with the SEC on November 15, 2022. The results of operations for the three month period ended December 31, 2022 are not necessarily indicative of results for the Company’s 2023 fiscal year because of seasonal and other factors.

[0000833444-23-000005:notes:2]
[same as prior period, unchanged from 0000833444-22-000036:notes:2]

[0000833444-23-000005:notes:3]
[same as prior period, unchanged from 0000833444-22-000036:notes:3]

[0000833444-23-000005:notes:4]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including residential and commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions powered by its OpenBlue software platform and capabilities. The Company partners with customers by leveraging its broad product portfolio and digital capabilities powered by OpenBlue, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency, enhance security, create healthy environments and reduce greenhouse gas emissions.

[0000833444-23-000005:notes:5]
[same as prior period, unchanged from 0000833444-22-000036:notes:5]

[0000833444-23-000005:notes:6]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries that are consolidated in conformity with U.S. GAAP. All significant intercompany transactions have been eliminated. The results of companies acquired or disposed of during the reporting period are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company exercises significant influence, which typically occurs when its ownership interest exceeds 20%, and the Company does not have a controlling interest.

[0000833444-23-000005:notes:7]
The Company consolidates variable interest entities ("VIE") when it has the power to direct the significant activities of the entity and the obligation to absorb losses or receive benefits from the entity that may be significant. The Company did not have any material consolidated or nonconsolidated VIE's for the presented reporting periods.

[0000833444-23-000005:notes:8]
Restricted Cash
Restricted cash relates to amounts restricted for payment of asbestos liabilities and certain litigation and environmental matters. Restricted cash is recorded within other current assets in the consolidated statements of financial position and totaled $67 million and $35 million at December 31, 2022 and September 30, 2022, respectively.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000833444-23-000005:notes:9]
New Accounting Standards
Recently Issued Accounting Pronouncements

[0000833444-23-000005:notes:10]
In September 2022, the FASB issued ASU 2022-04, "Disclosure of Supplier Finance Program Obligations", which is intended to enhance the transparency surrounding the use of supplier finance programs. Supplier finance programs may also be referred to as reverse factoring, payables finance, or structured payables arrangements. The amendments require a buyer that uses supplier finance programs to make annual disclosures about the program’s key terms, the balance sheet presentation of related amounts, the confirmed amount outstanding at the end of the period, and associated rollforward information. Only the amount outstanding at the end of the period must be disclosed in interim periods. The Company expects to adopt the new disclosures, other than the rollforward disclosure, as required at the beginning of fiscal 2024. The rollforward disclosures will be adopted as required at the beginning of fiscal 2025.

[0000833444-23-000005:notes:11]
Other recently issued accounting pronouncements are not expected to have a material impact on the Company's consolidated financial statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-23-000005:notes:12]
Acquisitions and Divestitures
During the first quarter of fiscal 2023, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $105 million, of which $79 million was paid as of December 31, 2022. In connection with the acquisitions, the Company recorded goodwill of $53 million within the Global Products segment and $2 million within the Building Solutions EMEA/LA segment.

[0000833444-23-000005:notes:13]
The Company completed no divestitures during the first quarter of fiscal 2023.

[0000833444-23-000005:notes:14]
During the first quarter of fiscal 2022, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $142 million, of which $108 million was paid as of December 31, 2021. In connection with the acquisitions, the Company recorded goodwill of $45 million within the Building Solutions Asia Pacific segment, $20 million within the Building Solutions North America segment, $19 million within the Building Solutions EMEA/LA segment and $10 million within the Global Products segment.

[0000833444-23-000005:notes:15]
During the first quarter of fiscal 2022, the Company completed a divestiture within the Buildings Solutions EMEA/LA segment. The selling price, net of cash divested, was $18 million, of which $16 million was received as of December 31, 2021. In connection with the divestiture, the Company reduced goodwill by $5 million.

[0000833444-23-000005:notes:16]
Acquisitions and divestitures were not material individually or in the aggregate in the first quarter of fiscal 2023 or 2022.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-23-000005:notes:17]
Assets and Liabilities Held for Sale
During fiscal 2022, the Company determined that its Global Retail business within its Building Solutions North America, Building Solutions Asia Pacific and Building Solutions EMEA/LA segments and a business within the Building Solutions Asia Pacific segment both met the criteria to be classified as held for sale. The assets and liabilities of both businesses are presented as held for sale in the consolidated statements of financial position as of December 31, 2022 and September 30, 2022. Assets and liabilities held for sale are recorded at the lower of carrying value or fair value, less costs to sell in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets". The carrying amount of any assets, including goodwill, that are part of the disposal group, but not in the scope of ASC 360-10, are tested for impairment under the relevant guidance prior to measuring the disposal group at fair value, less cost to sell.

[0000833444-23-000005:notes:18]
During the three months ended December 31, 2022, the Company recorded impairment charges primarily due to reductions in the estimated fair values for the Global Retail business of $228 million and for the business in the Building Solutions Asia Pacific of $60 million. All of the impairments were recorded within restructuring and impairment costs in the consolidated statements of income.

[0000833444-23-000005:notes:19]
The divestiture of the businesses held for sale could result in a gain or loss on sale to the extent the ultimate selling prices differ from the current carrying value of the net assets recorded, which could be material. The businesses did not meet the criteria to be classified as discontinued operations as neither divestiture represents a strategic shift that will have a major effect on the Company's operations and financial results. Both divestitures are expected to be finalized in fiscal 2023.

[0000833444-23-000005:notes:20]
[same as prior period, unchanged from 0000833444-22-000036:notes:33]

[0000833444-23-000005:notes:21]
|  |  |  | December 31, 2022 |  | September 30, 2022 |
| Accounts receivable - net |  |  | $ | 220 |  |  | $ | 199 |  |
| Inventories |  |  | 157 |  |  | 155 |  |
| Other current assets |  |  | 28 |  |  | 21 |  |
| Current assets held for sale |  |  | $ | 405 |  |  | $ | 375 |  |
| Property, plant and equipment - net |  |  | $ | 191 |  |  | $ | 89 |  |
| Goodwill |  |  | — |  |  | 22 |  |
| Other intangible assets - net |  |  | 322 |  |  | 514 |  |
| Other noncurrent assets |  |  | 72 |  |  | 72 |  |
| Noncurrent assets held for sale |  |  | $ | 585 |  |  | $ | 697 |  |
| Accounts payable |  |  | $ | 129 |  |  | $ | 127 |  |
| Accrued compensation and benefits |  |  | 16 |  |  | 25 |  |
| Deferred revenue |  |  | 38 |  |  | 36 |  |
| Other current liabilities |  |  | 116 |  |  | 33 |  |
| Current liabilities held for sale |  |  | $ | 299 |  |  | $ | 221 |  |
| Other noncurrent liabilities |  |  | $ | 61 |  |  | $ | 61 |  |
| Noncurrent liabilities held for sale |  |  | $ | 61 |  |  | $ | 61 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-23-000005:notes:22]
[same as prior period, unchanged from 0000833444-22-000036:notes:36]

[0000833444-23-000005:notes:23]
[same as prior period, unchanged from 0000833444-22-000036:notes:37]

[0000833444-23-000005:notes:24]
|  |  | Three Months Ended December 31, |
|  |  | 2022 |  | 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,451 |  |  | $ | 916 |  |  | $ | 2,367 |  |  | $ | 1,299 |  |  | $ | 853 |  |  | $ | 2,152 |  |
| Building Solutions EMEA/LA |  | 552 |  |  | 423 |  |  | 975 |  |  | 544 |  |  | 415 |  |  | 959 |  |
| Building Solutions Asia Pacific |  | 473 |  |  | 173 |  |  | 646 |  |  | 501 |  |  | 174 |  |  | 675 |  |
| Global Products |  | 2,080 |  |  | — |  |  | 2,080 |  |  | 2,076 |  |  | — |  |  | 2,076 |  |
| Total |  | $ | 4,556 |  |  | $ | 1,512 |  |  | $ | 6,068 |  |  | $ | 4,420 |  |  | $ | 1,442 |  |  | $ | 5,862 |  |

[0000833444-23-000005:notes:25]
[same as prior period, unchanged from 0000833444-22-000036:notes:40]

[0000833444-23-000005:notes:26]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| HVAC |  | $ | 1,440 |  |  | $ | 1,483 |  |  |  |  |  |
| Fire & Security |  | 570 |  |  | 544 |  |  |  |  |  |
| Industrial Refrigeration |  | 70 |  |  | 49 |  |  |  |  |  |
| Total |  | $ | 2,080 |  |  | $ | 2,076 |  |  |  |  |  |

[0000833444-23-000005:notes:27]
[same as prior period, unchanged from 0000833444-22-000036:notes:42]

[0000833444-23-000005:notes:28]
[same as prior period, unchanged from 0000833444-22-000036:notes:43]

[0000833444-23-000005:notes:29]
[same as prior period, unchanged from 0000833444-22-000036:notes:44]

[0000833444-23-000005:notes:30]
|  |  | Location of contract balances |  | December 31, 2022 |  | September 30, 2022 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,019 |  |  | $ | 2,020 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 83 |  |  | 79 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,774) |  |  | (1,768) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (293) |  |  | (282) |  |  |  |

[0000833444-23-000005:notes:31]
For the three months ended December 31, 2022 and 2021, the Company recognized revenue of $846 million and $751 million, respectively, that was included in the beginning of period contract liability balance.

[0000833444-23-000005:notes:32]
[same as prior period, unchanged from 0000833444-22-000036:notes:47]

[0000833444-23-000005:notes:33]
[same as prior period, unchanged from 0000833444-22-000036:notes:48]

[0000833444-23-000005:notes:34]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of December 31, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $18.4 billion, of which approximately 65% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

[0000833444-23-000005:notes:35]
[same as prior period, unchanged from 0000833444-22-000036:notes:50]

[0000833444-23-000005:notes:36]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when these costs are recoverable. These costs consist primarily of sales commissions and design costs that relate to a contract or an anticipated contract that we expect to recover. Costs to obtain or fulfill a contract are capitalized and amortized over the period of contract performance.

[0000833444-23-000005:notes:37]
[same as prior period, unchanged from 0000833444-22-000036:notes:52]

[0000833444-23-000005:notes:38]
|  |  | December 31, 2022 |  | September 30, 2022 |  |  |
| Other current assets |  | $ | 148 |  |  | $ | 139 |  |  |  |
| Other noncurrent assets |  | 191 |  |  | 174 |  |  |  |
| Total |  | $ | 339 |  |  | $ | 313 |  |  |  |

[0000833444-23-000005:notes:39]
For the three months ended December 31, 2022 and 2021, the Company recognized amortization expense of  $61 million, and $50 million related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three months ended December 31, 2022 and 2021.


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0000833444-23-000005:notes:40]
Accounts ReceivableThe Company enters into various factoring agreements to sell certain accounts receivable to third-party financial institutions. For the majority of these agreements, for ease of administration, the Company collects customer payments related to the factored receivables on behalf of the financial institutions but otherwise maintains no continuing involvement with respect to the factored receivables. Sales of accounts receivable are reflected as a reduction of accounts receivable in the consolidated statements of financial position and the proceeds are included in cash flows from operating activities in the consolidated statements of cash flows. The Company sold $409 million and $134 million of accounts receivable under these factoring agreements during the three months ended December 31, 2022 and 2021, respectively. The cost of factoring such receivables was not material. Previously sold receivables still outstanding were $384 million and $476 million as of December 31, 2022 and  September 30, 2022, respectively.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-23-000005:notes:41]
[same as prior period, unchanged from 0000833444-22-000036:notes:61]

[0000833444-23-000005:notes:42]
|  | December 31, 2022 |  | September 30, 2022 |
| Raw materials and supplies | $ | 1,162 |  |  | $ | 1,009 |  |
| Work-in-process | 215 |  |  | 196 |  |
| Finished goods | 1,518 |  |  | 1,305 |  |
| Inventories | $ | 2,895 |  |  | $ | 2,510 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-23-000005:notes:43]
Goodwill and Other Intangible Assets
The changes in the carrying amount of goodwill in each of the Company’s reportable segments were as follows (in millions):

[0000833444-23-000005:notes:44]
|  |  | Three Months Ended December 31, 2022 |
|  |  | Building Solutions North America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | Total |
| Goodwill |  | $ | 9,630 |  |  | $ | 1,772 |  |  | $ | 1,116 |  |  | $ | 5,591 |  |  | 18,109 |  |
| Accumulated impairment loss |  | (659) |  |  | (47) |  |  | — |  |  | (75) |  |  | (781) |  |
| Balance at beginning of period |  | 8,971 |  |  | 1,725 |  |  | 1,116 |  |  | 5,516 |  |  | 17,328 |  |
| Acquisitions |  | — |  |  | 2 |  |  | — |  |  | 53 |  |  | 55 |  |
| Foreign currency translation and other |  | 8 |  |  | 139 |  |  | 62 |  |  | 92 |  |  | 301 |  |
| Balance at end of period |  | $ | 8,979 |  |  | $ | 1,866 |  |  | $ | 1,178 |  |  | $ | 5,661 |  |  | $ | 17,684 |  |

[0000833444-23-000005:notes:45]
The Company tests goodwill for impairment annually as of July 31 or more frequently if events or changes in circumstances indicate the asset might be impaired. There were no triggering events requiring an impairment assessment be conducted in the three months ended December 31, 2022. However, it is possible that future changes in circumstances would require the Company to record additional non-cash impairment charges.

[0000833444-23-000005:notes:46]
[same as prior period, unchanged from 0000833444-22-000036:notes:70]

[0000833444-23-000005:notes:47]
|  | December 31, 2022 |  | September 30, 2022 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Definite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,415 |  |  | $ | (699) |  |  | $ | 716 |  |  | $ | 1,353 |  |  | $ | (658) |  |  | $ | 695 |  |
| Customer relationships | 2,793 |  |  | (1,330) |  |  | 1,463 |  |  | 2,742 |  |  | (1,254) |  |  | 1,488 |  |
| Miscellaneous | 780 |  |  | (407) |  |  | 373 |  |  | 756 |  |  | (386) |  |  | 370 |  |
|  | 4,988 |  |  | (2,436) |  |  | 2,552 |  |  | 4,851 |  |  | (2,298) |  |  | 2,553 |  |
| Indefinite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,121 |  |  | — |  |  | 2,121 |  |  | 2,088 |  |  | — |  |  | 2,088 |  |
|  | 2,121 |  |  | — |  |  | 2,121 |  |  | 2,088 |  |  | — |  |  | 2,088 |  |
| Total intangible assets | $ | 7,109 |  |  | $ | (2,436) |  |  | $ | 4,673 |  |  | $ | 6,939 |  |  | $ | (2,298) |  |  | $ | 4,641 |  |

[0000833444-23-000005:notes:48]
Amortization of other intangible assets included within continuing operations for the three-month periods ended December 31, 2022 and 2021 was $104 million and $118 million, respectively.

[0000833444-23-000005:notes:49]
The Company tests indefinite-lived intangible assets for impairment annually as of July 31 or more frequently if events or changes in circumstances indicate the asset might be impaired. There were no triggering events requiring that an impairment assessment be conducted in the three months ended December 31, 2022. However, it is possible that future changes in circumstances would require the Company to record additional non-cash impairment charges.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000833444-23-000005:notes:50]
[same as prior period, unchanged from 0000833444-22-000036:notes:74]

[0000833444-23-000005:notes:51]
|  | Location of lease balances |  | December 31, 2022 |  | September 30, 2022 |
| Operating lease right-of-use assets | Other noncurrent assets |  | $ | 1,311 |  |  | $ | 1,271 |  |
| Operating lease liabilities - current | Other current liabilities |  | 290 |  |  | 280 |  |
| Operating lease liabilities - noncurrent | Other noncurrent liabilities |  | 1,018 |  |  | 987 |  |

[0000833444-23-000005:notes:52]
[same as prior period, unchanged from 0000833444-22-000036:notes:76]

[0000833444-23-000005:notes:53]
|  |  |  |  | Three Months Ended December 31, |  |  |
|  |  |  |  |  |  | 2022 |  | 2021 |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  |  |  |  |  | $ | 110 |  |  | $ | 55 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-23-000005:notes:54]
Debt and Financing Arrangements
As of December 31, 2022, the Company had a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in November 2023. As of December 31, 2022, there were no draws on the facilities.

[0000833444-23-000005:notes:55]
In October 2022, the Company repaid a €200 million ($196 million as of September 30, 2022) term loan with an interest rate of EURIBOR plus 0.5% and entered into a €150 million ($161 million as of December 31, 2022) term loan with an interest rate of EURIBOR plus 0.7% which is due in April 2024.

[0000833444-23-000005:notes:56]
The Company had $715 million and $172 million of commercial paper outstanding as of December 31, 2022 and September 30, 2022, respectively.

[0000833444-23-000005:notes:57]
Net Financing Charges

[0000833444-23-000005:notes:58]
Net financing charges consisted of the following (in millions):

[0000833444-23-000005:notes:59]
|  | Three Months Ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Interest expense, net of capitalized interest costs | $ | 69 |  |  | $ | 55 |  |  |  |  |  |
| Other financing charges | 10 |  |  | 5 |  |  |  |  |  |
| Interest income | (4) |  |  | (2) |  |  |  |  |  |
| Net foreign exchange results for financing activities | (8) |  |  | (5) |  |  |  |  |  |
| Net financing charges | $ | 67 |  |  | $ | 53 |  |  |  |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-23-000005:notes:60]
Derivative Instruments and Hedging Activities
The Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities and interest rates. Under Company policy, the use of derivatives is restricted to those intended for hedging purposes; the use of any derivative instrument for speculative purposes is strictly prohibited. A description of each type of derivative utilized by the Company to manage risk is included in the following paragraphs. In addition, refer to Note 12, "Fair Value Measurements," of the notes to the consolidated financial statements for information related to the fair value measurements and valuation methods utilized by the Company for each derivative type.

[0000833444-23-000005:notes:61]
[same as prior period, unchanged from 0000833444-22-000036:notes:85]

[0000833444-23-000005:notes:62]
[same as prior period, unchanged from 0000833444-22-000036:notes:86]

[0000833444-23-000005:notes:63]
[same as prior period, unchanged from 0000833444-22-000036:notes:87]

[0000833444-23-000005:notes:64]
As cash flow hedges under ASC 815, "Derivatives and Hedging," hedge gains or losses due to changes in fair value are initially recorded as a component of accumulated other comprehensive income (loss) ("AOCI") and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the three months ended December 31, 2022 and 2021.

[0000833444-23-000005:notes:65]
[same as prior period, unchanged from 0000833444-22-000036:notes:89]

[0000833444-23-000005:notes:66]
|  |  | Volume Outstanding as of |
| Commodity |  | December 31, 2022 |  | September 30, 2022 |
| Copper |  | 4,218 |  |  | 3,629 |  |
| Aluminum |  | 10,362 |  |  | 6,758 |  |

[0000833444-23-000005:notes:67]
[same as prior period, unchanged from 0000833444-22-000036:notes:92]

[0000833444-23-000005:notes:68]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in AOCI attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company's net investments globally.

[0000833444-23-000005:notes:69]
The following table summarizes net investment hedges (in billions):

[0000833444-23-000005:notes:70]
|  |  | December 31, |  | September 30, |
|  | 2022 |  | 2022 |
| Euro-denominated bonds designated as net investment hedges in Europe |  | € | 2.9 |  |  | € | 2.9 |  |
| Yen-denominated debt designated as a net investment hedge in Japan |  | ¥ | 30 |  |  | ¥ | 30 |  |

[0000833444-23-000005:notes:71]
[same as prior period, unchanged from 0000833444-22-000036:notes:94]

[0000833444-23-000005:notes:72]
The Company holds certain foreign currency forward contracts not designated as hedging instruments under ASC 815 to hedge foreign currency exposure resulting from monetary assets and liabilities denominated in nonfunctional currencies.  The changes in fair value of these foreign currency forward exchange derivatives are recorded in the consolidated statements of income where they offset foreign currency transactional gains and losses on the nonfunctional currency denominated assets and liabilities being hedged.

[0000833444-23-000005:notes:73]
[same as prior period, unchanged from 0000833444-22-000036:notes:97]

[0000833444-23-000005:notes:74]
[same as prior period, unchanged from 0000833444-22-000036:notes:98]

[0000833444-23-000005:notes:75]
|  | Derivatives and Hedging Activities Designated as Hedging Instruments under ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instruments under ASC 815 |
|  | December 31, |  | September 30, |  | December 31, |  | September 30, |
|  | 2022 |  | 2022 |  | 2022 |  | 2022 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 26 |  |  | $ | 30 |  |  | $ | — |  |  | $ | 24 |  |
| Commodity derivatives | 2 |  |  | — |  |  | — |  |  | — |  |
| Total assets | $ | 28 |  |  | $ | 30 |  |  | $ | — |  |  | $ | 24 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 50 |  |  | $ | 24 |  |  | $ | 14 |  |  | $ | 27 |  |
| Commodity derivatives | 2 |  |  | 10 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 3,346 |  |  | 3,077 |  |  | — |  |  | — |  |
| Total liabilities | $ | 3,398 |  |  | $ | 3,111 |  |  | $ | 14 |  |  | $ | 27 |  |

[0000833444-23-000005:notes:76]
[same as prior period, unchanged from 0000833444-22-000036:notes:100]

[0000833444-23-000005:notes:77]
[same as prior period, unchanged from 0000833444-22-000036:notes:101]

[0000833444-23-000005:notes:78]
[same as prior period, unchanged from 0000833444-22-000036:notes:102]

[0000833444-23-000005:notes:79]
[same as prior period, unchanged from 0000833444-22-000036:notes:103]

[0000833444-23-000005:notes:80]
|  |  | Fair Value of Assets |  |  |  | Fair Value of Liabilities |  |  |
|  |  | December 31, |  | September 30, |  |  |  | December 31, |  | September 30, |  |  |
|  |  | 2022 |  | 2022 |  |  |  | 2022 |  | 2022 |  |  |
| Gross amount recognized |  | $ | 28 |  |  | $ | 54 |  |  |  |  | $ | 3,412 |  |  | $ | 3,138 |  |  |  |
| Gross amount eligible for offsetting |  | (17) |  |  | (42) |  |  |  |  | (17) |  |  | (42) |  |  |  |
| Net amount |  | $ | 11 |  |  | $ | 12 |  |  |  |  | $ | 3,395 |  |  | $ | 3,096 |  |  |  |

[0000833444-23-000005:notes:81]
[same as prior period, unchanged from 0000833444-22-000036:notes:105]

[0000833444-23-000005:notes:82]
The following table presents the pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges (in millions):

[0000833444-23-000005:notes:83]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Three Months Ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Foreign currency exchange derivatives |  | $ | (21) |  |  | $ | 13 |  |  |  |  |  |
| Commodity derivatives |  | 4 |  |  | (2) |  |  |  |  |  |
| Total |  | $ | (17) |  |  | $ | 11 |  |  |  |  |  |

[0000833444-23-000005:notes:84]
[same as prior period, unchanged from 0000833444-22-000036:notes:108]

[0000833444-23-000005:notes:85]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Location of Gain (Loss) Reclassified from AOCI into Income |  | Three Months Ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 9 |  |  | $ | 5 |  |  |  |  |  |
| Commodity derivatives |  | Cost of sales |  | (6) |  |  | (4) |  |  |  |  |  |
| Interest rate swaps |  | Net financing charges |  | — |  |  | (1) |  |  |  |  |  |
| Total |  |  |  | $ | 3 |  |  | $ | — |  |  |  |  |  |

[0000833444-23-000005:notes:86]
The following table presents the location and amount of pre-tax gains on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income (in millions):

[0000833444-23-000005:notes:87]
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of GainRecognized in Income on Derivative |  | Three Months Ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 2 |  |  | $ | 10 |  |  |  |  |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | 79 |  |  | 87 |  |  |  |  |  |
| Equity swap |  | Selling, general and administrative |  | — |  |  | 5 |  |  |  |  |  |
| Total |  |  |  | $ | 81 |  |  | $ | 102 |  |  |  |  |  |

[0000833444-23-000005:notes:88]
Pre-tax gains (losses) on net investment hedges recorded as foreign currency translation adjustments ("CTA") within other comprehensive income (loss) were $(269) and $73 million for the three months ended December 31, 2022 and 2021, respectively. No gains or losses were reclassified from CTA into income during the three months ended December 31, 2022 and 2021.


## us-gaap:DerivativesPolicyTextBlock

[0000833444-23-000005:notes:89]
As cash flow hedges under ASC 815, "Derivatives and Hedging," hedge gains or losses due to changes in fair value are initially recorded as a component of accumulated other comprehensive income (loss) ("AOCI") and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings.The currency effects of the debt obligations are reflected in AOCI attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company's net investments globally.The Company holds certain foreign currency forward contracts not designated as hedging instruments under ASC 815 to hedge foreign currency exposure resulting from monetary assets and liabilities denominated in nonfunctional currencies.  The changes in fair value of these foreign currency forward exchange derivatives are recorded in the consolidated statements of income where they offset foreign currency transactional gains and losses on the nonfunctional currency denominated assets and liabilities being hedged.
The use of derivative financial instruments exposes the Company to counterparty credit risk. The Company has established policies and procedures to limit the potential for counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association ("ISDA") master netting agreements with substantially all of its counterparties. The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-23-000005:notes:90]
[same as prior period, unchanged from 0000833444-22-000036:notes:114]

[0000833444-23-000005:notes:91]
[same as prior period, unchanged from 0000833444-22-000036:notes:115]

[0000833444-23-000005:notes:92]
[same as prior period, unchanged from 0000833444-22-000036:notes:116]

[0000833444-23-000005:notes:93]
[same as prior period, unchanged from 0000833444-22-000036:notes:117]

[0000833444-23-000005:notes:94]
[same as prior period, unchanged from 0000833444-22-000036:notes:118]

[0000833444-23-000005:notes:95]
[same as prior period, unchanged from 0000833444-22-000036:notes:119]

[0000833444-23-000005:notes:96]
[same as prior period, unchanged from 0000833444-22-000036:notes:120]

[0000833444-23-000005:notes:97]
|  | Fair Value Measurements Using: |
|  | Total as of December 31, 2022 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 26 |  |  | $ | — |  |  | $ | 26 |  |  | $ | — |  |
| Exchange traded funds (fixed income)1 | 23 |  |  | 23 |  |  | — |  |  | — |  |
| Commodity derivatives | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 49 |  |  | 49 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 82 |  |  | 82 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 139 |  |  | 139 |  |  | — |  |  | — |  |
| Total assets | $ | 321 |  |  | $ | 293 |  |  | $ | 28 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 64 |  |  | $ | — |  |  | $ | 64 |  |  | $ | — |  |
| Commodity derivatives | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Contingent earn-out liabilities | 49 |  |  | — |  |  | — |  |  | 49 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 34 |  |  | — |  |  | — |  |  | 34 |  |
| Total liabilities | $ | 149 |  |  | $ | — |  |  | $ | 66 |  |  | $ | 83 |  |

[0000833444-23-000005:notes:98]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2022 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |  | $ | — |  |
| Exchange traded funds (fixed income)1 | 22 |  |  | 22 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 46 |  |  | 46 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 86 |  |  | 86 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 131 |  |  | 131 |  |  | — |  |  | — |  |
| Total assets | $ | 339 |  |  | $ | 285 |  |  | $ | 54 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 51 |  |  | $ | — |  |  | $ | 51 |  |  | $ | — |  |
| Commodity derivatives | 10 |  |  | — |  |  | 10 |  |  | — |  |
| Contingent earn-out liabilities | 30 |  |  | — |  |  | — |  |  | 30 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 30 |  |  | — |  |  | — |  |  | 30 |  |
| Total liabilities | $ | 121 |  |  | $ | — |  |  | $ | 61 |  |  | $ | 60 |  |

[0000833444-23-000005:notes:99]
1 Classified as restricted investments for payment of asbestos liabilities. See Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further details.

[0000833444-23-000005:notes:100]
[same as prior period, unchanged from 0000833444-22-000036:notes:124]

[0000833444-23-000005:notes:101]
| Balance at September 30, 2022 | $ | 60 |  |  |
| Acquisitions | 25 |  |  |
| Payments | (3) |  |  |
| Currency translation | 1 |  |  |
| Balance at December 31, 2022 | $ | 83 |  |  |

[0000833444-23-000005:notes:102]
[same as prior period, unchanged from 0000833444-22-000036:notes:126]

[0000833444-23-000005:notes:103]
[same as prior period, unchanged from 0000833444-22-000036:notes:127]

[0000833444-23-000005:notes:104]
[same as prior period, unchanged from 0000833444-22-000036:notes:128]

[0000833444-23-000005:notes:105]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices. Unrealized gains (losses) on the deferred compensation plan assets are recognized in the consolidated statements of income where they offset unrealized gains and losses on the related deferred compensation plan liability.

[0000833444-23-000005:notes:106]
Investments in exchange traded funds:  Investments in exchange traded funds are valued using a market approach based on  quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments.  Refer to Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further information.

[0000833444-23-000005:notes:107]
Contingent earn-out liabilities:  The contingent earn-out liabilities were established using a Monte Carlo simulation based on the forecasted operating results and the earn-out formula specified in the purchase agreements.

[0000833444-23-000005:notes:108]
The following table presents the portion of unrealized gains recognized in the consolidated statements of income that relate to equity securities still held at December 31, 2022 and 2021 (in millions):

[0000833444-23-000005:notes:109]
|  |  | Three Months Ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Deferred compensation plan assets |  | $ | 3 |  |  | $ | 3 |  |  |  |  |  |
| Investments in exchange traded funds |  | 11 |  |  | 14 |  |  |  |  |  |

[0000833444-23-000005:notes:110]
All of the gains on investments in exchange traded funds related to restricted investments. 
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. At December 31, 2022, the fair value of long-term debt was $7.9 billion, including public debt of $7.5 billion and other long-term debt of $0.4 billion. At September 30, 2022, the fair value of long-term debt was $7.3 billion, including public debt of $7.1 billion and other long-term debt of $0.2 billion. The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000833444-23-000005:notes:111]
[same as prior period, unchanged from 0000833444-22-000036:notes:137]

[0000833444-23-000005:notes:112]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices. Unrealized gains (losses) on the deferred compensation plan assets are recognized in the consolidated statements of income where they offset unrealized gains and losses on the related deferred compensation plan liability. 
Investments in exchange traded funds:  Investments in exchange traded funds are valued using a market approach based on  quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments.  Refer to Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further information.Contingent earn-out liabilities:  The contingent earn-out liabilities were established using a Monte Carlo simulation based on the forecasted operating results and the earn-out formula specified in the purchase agreements.The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-23-000005:notes:113]
Stock-Based Compensation
On March 10, 2021, the shareholders of the Company approved the Johnson Controls International plc 2021 Equity and Incentive Plan (the "Plan"). The Plan authorizes stock options, stock appreciation rights, restricted (non-vested) stock/units, performance share units and other stock-based awards. The Compensation and Talent Development Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. Awards are typically granted annually in the Company’s fiscal first quarter.

[0000833444-23-000005:notes:114]
[same as prior period, unchanged from 0000833444-22-000036:notes:140]

[0000833444-23-000005:notes:115]
|  | Three Months Ended December 31, |  |  |
|  | 2022 |  |  |  | 2021 |  |  |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |
| Restricted stock/units | 1,614,493 |  |  | $ | 66.73 |  |  |  |  | 1,170,634 |  |  | $ | 79.54 |  |  |  |
| Performance shares | 339,191 |  |  | 79.54 |  |  |  |  | 438,476 |  |  | 84.27 |  |  |  |
| Stock options | 570,140 |  |  | 18.21 |  |  |  |  | 548,398 |  |  | 18.59 |  |  |  |

[0000833444-23-000005:notes:116]
[same as prior period, unchanged from 0000833444-22-000036:notes:150]

[0000833444-23-000005:notes:117]
The following table summarizes the assumptions used in determining the fair value of performance share units granted:

[0000833444-23-000005:notes:118]
|  | Three Months Ended December 31, |
|  | 2022 |  | 2021 |
| Risk-free interest rate | 4.04% |  | 0.99% |
| Expected volatility of the Company’s stock | 33.5% |  | 30.0% |

[0000833444-23-000005:notes:119]
[same as prior period, unchanged from 0000833444-22-000036:notes:142]

[0000833444-23-000005:notes:120]
The following table summarizes the assumptions used in determining the fair value of stock options granted:

[0000833444-23-000005:notes:121]
|  | Three Months Ended December 31, |
|  | 2022 |  | 2021 |
| Expected life of option (years) | 5.8 |  | 6.0 |
| Risk-free interest rate | 3.59% |  | 1.35% |
| Expected volatility of the Company’s stock | 29.4% |  | 27.8% |
| Expected dividend yield on the Company’s stock | 2.10% |  | 1.71% |


## us-gaap:EarningsPerShareTextBlock

[0000833444-23-000005:notes:122]
Earnings Per Share
The following table reconciles the numerators and denominators used to calculate basic and diluted earnings per share (in millions):

[0000833444-23-000005:notes:123]
|  | Three Months Ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Income Available to Ordinary Shareholders |  |  |  |  |  |  |  |
| Basic and diluted income available to shareholders | $ | 118 |  |  | $ | 381 |  |  |  |  |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 687.0 |  |  | 704.3 |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 3.3 |  |  | 5.2 |  |  |  |  |  |
| Diluted weighted average shares outstanding | 690.3 |  |  | 709.5 |  |  |  |  |  |
| Antidilutive Securities |  |  |  |  |  |  |  |
| Stock options and unvested restricted stock | 0.3 |  |  | — |  |  |  |  |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-23-000005:notes:124]
[same as prior period, unchanged from 0000833444-22-000036:notes:158]

[0000833444-23-000005:notes:125]
For the three months ended December 31, 2022 and 2021, the Company repurchased and immediately retired $154 million and $526 million of its ordinary shares, respectively. As of December 31, 2022, approximately $3.5 billion remains available under the Company's share repurchase program, which was approved by the Company's Board of Directors in March 2021. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice.

[0000833444-23-000005:notes:126]
[same as prior period, unchanged from 0000833444-22-000036:notes:160]

[0000833444-23-000005:notes:127]
[same as prior period, unchanged from 0000833444-22-000036:notes:161]

[0000833444-23-000005:notes:128]
|  | Three Months Ended December 31, |
|  | 2022 |  | 2021 |
| Foreign currency translation adjustments |  |  |  |
| Balance at beginning of period | $ | (901) |  |  | $ | (421) |  |
| Aggregate adjustment for the period (net of tax effect of $0 and $0) | 59 |  |  | 84 |  |
| Balance at end of period | (842) |  |  | (337) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | (11) |  |  | (17) |  |
| Current period changes in fair value (net of tax effect of $(2) and $3) | (9) |  |  | 4 |  |
| Reclassification to income (net of tax effect of $(1) and $0) * | (2) |  |  | — |  |
| Balance at end of period | (22) |  |  | (13) |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | 1 |  |  | 4 |  |
| Reclassification to income (net of tax effect of $0 and $0) | (1) |  |  | (1) |  |
| Balance at end of period | — |  |  | 3 |  |
| Accumulated other comprehensive loss, end of period | $ | (864) |  |  | $ | (347) |  |

[0000833444-23-000005:notes:129]
[same as prior period, unchanged from 0000833444-22-000036:notes:164]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-23-000005:notes:130]
[same as prior period, unchanged from 0000833444-22-000036:notes:165]

[0000833444-23-000005:notes:131]
|  | U.S. Pension Plans |
|  | Three Months Ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Interest cost | $ | 21 |  |  | $ | 10 |  |  |  |  |  |
| Expected return on plan assets | (34) |  |  | (41) |  |  |  |  |  |
| Net actuarial loss (gain) | 8 |  |  | (42) |  |  |  |  |  |
| Settlement gain | — |  |  | (1) |  |  |  |  |  |
| Net periodic benefit credit | $ | (5) |  |  | $ | (74) |  |  |  |  |  |

[0000833444-23-000005:notes:132]
|  | Non-U.S. Pension Plans |
|  | Three Months Ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Service cost | $ | 3 |  |  | $ | 6 |  |  |  |  |  |
| Interest cost | 16 |  |  | 10 |  |  |  |  |  |
| Expected return on plan assets | (18) |  |  | (21) |  |  |  |  |  |
| Net periodic benefit cost (credit) | $ | 1 |  |  | $ | (5) |  |  |  |  |  |

[0000833444-23-000005:notes:133]
|  | Postretirement Benefits |
|  | Three Months Ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Interest cost | $ | 1 |  |  | $ | — |  |  |  |  |  |
| Expected return on plan assets | (2) |  |  | (2) |  |  |  |  |  |
| Amortization of prior service credit | (1) |  |  | (1) |  |  |  |  |  |
| Net periodic benefit credit | $ | (2) |  |  | $ | (3) |  |  |  |  |  |

[0000833444-23-000005:notes:134]
During the three months ended December 31, 2022, the amount of cumulative fiscal 2023 lump sum payouts triggered a remeasurement event for certain U.S. pension plans resulting in the recognition of net actuarial losses of $8 million, primarily due to decreases in discount rates, partially offset by favorable plan asset performance.

[0000833444-23-000005:notes:135]
During the three months ended December 31, 2021, the amount of cumulative fiscal 2022 lump sum payouts triggered a remeasurement event for certain U.S. pension plans resulting in the recognition of net actuarial gains of $42 million, primarily due to favorable plan asset performance.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-23-000005:notes:136]
Significant Restructuring and Impairment Costs
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company commits to various restructuring activities as necessary. Restructuring activities generally result in charges for workforce reductions, plant closures, asset impairments and other related costs which are reported as restructuring and impairment costs in the Company’s consolidated statements of income. The other related costs consist primarily of consulting costs incurred as a direct result of the restructuring activities. The Company expects the restructuring activities to reduce cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense.

[0000833444-23-000005:notes:137]
During the three months ended December 31, 2022, the Company recorded $57 million of restructuring and impairment costs in the consolidated statements of income. These charges relate to restructuring plans within the segments and at Corporate to reduce and optimize our cost structure. Refer to Note 4, "Assets and Liabilities Held for Sale" of the notes to the consolidated financial statements for disclosure of other impairment costs.

[0000833444-23-000005:notes:138]
In fiscal 2021, the Company committed to a significant multi-year restructuring plan ("2021 Plan"). The restructuring actions were substantially completed in fiscal 2022 and final payments, which are not material, will be made in fiscal 2023.

[0000833444-23-000005:notes:139]
The following table summarizes restructuring and impairment costs (in millions):

[0000833444-23-000005:notes:140]
|  | Three Months Ended December 31, 2022 |  |  |
| Building Solutions North America | $ | 2 |  |  |  |
| Building Solutions EMEA/LA | 21 |  |  |  |
| Building Solutions Asia Pacific | 5 |  |  |  |
| Global Products | 23 |  |  |  |
| Corporate | 6 |  |  |  |
| Total | $ | 57 |  |  |  |

[0000833444-23-000005:notes:141]
The following table summarizes changes in the restructuring reserve, which is included within other current liabilities in the consolidated statements of financial position, for new restructuring actions taken in the three months ended December 31, 2022 (in millions):

[0000833444-23-000005:notes:142]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  |  |  | Total |
| Original reserve | $ | 30 |  |  | $ | 6 |  |  | $ | 21 |  |  |  |  | $ | 57 |  |
| Utilized—cash | (3) |  |  | — |  |  | (5) |  |  |  |  | (8) |  |
| Utilized—noncash | — |  |  | (6) |  |  | — |  |  |  |  | (6) |  |
| Balance at December 31, 2022 | $ | 27 |  |  | $ | — |  |  | $ | 16 |  |  |  |  | $ | 43 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-23-000005:notes:143]
[same as prior period, unchanged from 0000833444-22-000036:notes:186]

[0000833444-23-000005:notes:144]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended December 31, 2022, the Company's effective tax rate for continuing operations was 8.2% and was lower than the statutory tax rate of 12.5% primarily due to impairment and restructuring charges and the benefits of continuing global tax planning initiatives, partially offset by tax rate differentials. For the three months ended December 31, 2021, the Company's effective tax rate for continuing operations was 14.5% and was higher than the statutory tax rate of 12.5% primarily due to the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives.

[0000833444-23-000005:notes:145]
[same as prior period, unchanged from 0000833444-22-000036:notes:188]

[0000833444-23-000005:notes:146]
[same as prior period, unchanged from 0000833444-22-000036:notes:189]

[0000833444-23-000005:notes:147]
[same as prior period, unchanged from 0000833444-22-000036:notes:191]

[0000833444-23-000005:notes:148]
At September 30, 2022, the Company had gross tax-effected unrecognized tax benefits of $2,537 million, of which $1,973 million, if recognized, would impact the effective tax rate. Accrued interest, net at September 30, 2022 was approximately $284 million (net of tax benefit). Interest accrued during the three months ended December 31, 2022 and 2021 was approximately $26 million (net of tax benefit) and approximately $17 million (net of tax benefit), respectively. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-23-000005:notes:149]
[same as prior period, unchanged from 0000833444-22-000036:notes:193]

[0000833444-23-000005:notes:150]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2021 |
| Germany |  | 2007 - 2018 |
| Luxembourg |  | 2017 - 2018 |
| Mexico |  | 2015 - 2017 |
| United Kingdom |  | 2014 - 2015, 2017 - 2018; 2020 |

[0000833444-23-000005:notes:151]
It is reasonably possible that tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense. Based upon the circumstances surrounding these examinations, the impact is not currently quantifiable.

[0000833444-23-000005:notes:152]
[same as prior period, unchanged from 0000833444-22-000036:notes:196]

[0000833444-23-000005:notes:153]
The Company recorded restructuring and impairment costs of $345 million, which generated a $52 million tax benefit, during the three months ended December 31, 2022 and $49 million, which generated a $7 million tax benefit, during the three months ended December 31, 2021,

[0000833444-23-000005:notes:154]
Tax expenses and benefits for the above transactions reflect the Company’s current tax positions in the impacted jurisdictions. Refer to Note 17, “Significant Restructuring and Impairment Costs,” of the notes to the consolidated financial statements for additional information.

[0000833444-23-000005:notes:155]
Impacts of Tax Legislation
During the three months ended December 31, 2022 and 2021, tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-23-000005:notes:156]
Segment Information
ASC 280, "Segment Reporting," establishes the standards for reporting information about segments in financial statements. In applying the criteria set forth in ASC 280, the Company has determined that it has four reportable segments for financial reporting purposes.

[0000833444-23-000005:notes:157]
•Building Solutions North America: Building Solutions North America designs, sells, installs, and services HVAC, controls, building management, refrigeration, integrated electronic security, and integrated fire detection and suppression systems for commercial, industrial, retail, small business, institutional and governmental customers in the United States and Canada. Building Solutions North America also provides energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and control systems, as well as data-driven "smart building" solutions, to non-residential building and industrial applications in the United States and Canadian marketplace.

[0000833444-23-000005:notes:158]
•Building Solutions EMEA/LA: Building Solutions EMEA/LA designs, sells, installs and services HVAC, controls, building management, refrigeration, integrated electronic security, integrated fire detection and suppression systems, and provides technical services, including data-driven "smart building" solutions, to markets in Europe, the Middle East, Africa and Latin America.

[0000833444-23-000005:notes:159]
•Building Solutions Asia Pacific: Building Solutions Asia Pacific designs, sells, installs and services HVAC, controls, building management, refrigeration, integrated electronic security, integrated fire-detection and suppression systems, and provides technical services, including data-driven "smart building" solutions, in the Asia Pacific marketplace.

[0000833444-23-000005:notes:160]
[same as prior period, unchanged from 0000833444-22-000036:notes:206]

[0000833444-23-000005:notes:161]
[same as prior period, unchanged from 0000833444-22-000036:notes:208]

[0000833444-23-000005:notes:162]
[same as prior period, unchanged from 0000833444-22-000036:notes:209]

[0000833444-23-000005:notes:163]
|  | Net Sales |
|  | Three Months Ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Building Solutions North America | $ | 2,367 |  |  | $ | 2,152 |  |  |  |  |  |
| Building Solutions EMEA/LA | 975 |  |  | 959 |  |  |  |  |  |
| Building Solutions Asia Pacific | 646 |  |  | 675 |  |  |  |  |  |
| Global Products | 2,080 |  |  | 2,076 |  |  |  |  |  |
| Total net sales | $ | 6,068 |  |  | $ | 5,862 |  |  |  |  |  |

[0000833444-23-000005:notes:164]
|  | Segment EBITA |
|  | Three Months Ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Building Solutions North America | $ | 267 |  |  | $ | 250 |  |  |  |  |  |
| Building Solutions EMEA/LA | 75 |  |  | 104 |  |  |  |  |  |
| Building Solutions Asia Pacific | 68 |  |  | 68 |  |  |  |  |  |
| Global Products | 382 |  |  | 301 |  |  |  |  |  |
| Total segment EBITA | 792 |  |  | 723 |  |  |  |  |  |
| Corporate expenses | (109) |  |  | (70) |  |  |  |  |  |
| Amortization of intangible assets | (104) |  |  | (118) |  |  |  |  |  |
| Restructuring and impairment costs | (345) |  |  | (49) |  |  |  |  |  |
| Net mark-to-market adjustments | 3 |  |  | 57 |  |  |  |  |  |
| Net financing charges | (67) |  |  | (53) |  |  |  |  |  |
| Income from continuing operations before income taxes | $ | 170 |  |  | $ | 490 |  |  |  |  |  |


## us-gaap:GuaranteesTextBlock

[0000833444-23-000005:notes:165]
[same as prior period, unchanged from 0000833444-22-000036:notes:212]

[0000833444-23-000005:notes:166]
[same as prior period, unchanged from 0000833444-22-000036:notes:213]

[0000833444-23-000005:notes:167]
The Company’s product warranty liability is recorded in the consolidated statements of financial position in other current liabilities if the warranty is less than one year and in other non-current liabilities if the warranty extends longer than one year.

[0000833444-23-000005:notes:168]
The changes in the carrying amount of the Company’s total product warranty liability were as follows (in millions):

[0000833444-23-000005:notes:169]
|  | Three Months Ended December 31, |
|  | 2022 |  | 2021 |
| Balance at beginning of period | $ | 179 |  |  | $ | 192 |  |
| Accruals for warranties issued during the period | 29 |  |  | 22 |  |
| Accruals from acquisition and divestitures | (1) |  |  | — |  |
| Settlements made (in cash or in kind) during the period | (29) |  |  | (29) |  |
| Currency translation | 3 |  |  | (1) |  |
| Balance at end of period | $ | 181 |  |  | $ | 184 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-23-000005:notes:170]
Commitments and Contingencies
Environmental Matters

[0000833444-23-000005:notes:171]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-23-000005:notes:172]
|  | December 31, 2022 |  | September 30, 2022 |
| Other current liabilities | $ | 48 |  |  | $ | 66 |  |
| Other noncurrent liabilities | 227 |  |  | 220 |  |
| Total reserves for environmental liabilities | $ | 275 |  |  | $ | 286 |  |

[0000833444-23-000005:notes:173]
The Company periodically examines whether the contingent liabilities related to the environmental matters described below are probable and reasonably estimable based on experience and ongoing developments in those matters, including continued study and analysis of ongoing remediation obligations. During the three months ended September 30, 2022, with the assistance of independent environmental consultants and taking into consideration investigation and remediation actions previously completed, new information available to the Company during the fourth quarter of fiscal 2022 and ongoing discussions with the Wisconsin Department of Natural Resources ("WDNR"), the Company completed a comprehensive long-term analysis and cost assessment related to the Company’s ongoing environmental remediation obligations. As a result of this analysis, the Company increased its accrual for environmental liabilities by $228 million, which are recorded on an undiscounted basis. The Company expects that it will pay the amounts recorded over an estimated period of up to 20 years. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals for environmental liabilities at this time.

[0000833444-23-000005:notes:174]
A substantial portion of the increase to the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to fire-fighting foams containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The increase in reserves was recorded as a result of several events that occurred in the three months ended September 30, 2022, including the completion and testing of the Groundwater Extraction and Treatment System (“GETS”) at the FTC (as further discussed below), the completion of resident surveys in Peshtigo regarding long-term drinking water solutions, correspondence with regulators on planned remediation activities, finalization of cost estimates for system upgrades and related long-term run rate costs in response to new permit requirements at the Stanton Street Facility, and the development of additional information through ongoing investigation and analysis. These events allowed the Company to develop estimates of costs associated with the long-term remediation actions expected to be

[0000833444-23-000005:notes:175]
performed over an estimated period of up to 20 years, including the continued operation of the GETS, the implementation of long-term drinking water solutions, continued monitoring and testing of the wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

[0000833444-23-000005:notes:176]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports, or elsewhere. In May 2021, as part of Tyco Fire Products’ ongoing investigation and remediation program, the WDNR approved Tyco Fire Products’ proposed GETS, a permanent groundwater remediation system that will extract groundwater that contains PFAS, treat it using advanced filtration systems, and return the treated water to the environment. Tyco Fire Products has completed construction of the GETS, which is now in operation. Tyco Fire Products is also in the process of completing the removal and disposal of PFAS-affected soil from the FTC. In December 2022, Tyco Fire Products also began implementation of a long-term drinking water solution for some Peshtigo residents with the installation of the first deep aquifer private drinking wells.

[0000833444-23-000005:notes:177]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency (“EPA”) to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the WDNR to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

[0000833444-23-000005:notes:178]
PFOA, PFOS, and other PFAS compounds are being studied by EPA and other environmental and health agencies and researchers. EPA has not issued binding regulatory limits, but had initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. While those studies continue, EPA issued in June 2022 an updated set of interim health advisory levels for PFOA and PFOS in drinking water, as well as final health advisory levels for two other types of PFAS (PFBS and GenX chemicals). In November 2022, EPA added a class definition of PFAS to the final version of EPA's fifth Contaminant Candidate List (CCL 5), which is a list of substances not currently subject to national drinking water regulation, but which EPA believes may require future regulation.

[0000833444-23-000005:notes:179]
In October 2021, EPA released its "PFAS Strategic Roadmap: EPA's Commitments to Action 2021-2024." The 2021-2024 Roadmap sets timelines by which EPA plans to take specific actions, including, among other items, publishing a national PFAS testing strategy, proposing to designate PFOA and PFOS as Comprehensive Environmental Response, Compensation and Liability Act hazardous substances, restricting PFAS discharges from industrial sources through Effluent Limitations Guidelines, publishing the final toxicity assessment for five additional PFAS, requiring water systems to test for 29 PFAS under the Safe Drinking Water Act, and publishing improved analytical methods in eight different environmental matrices to monitor 40 PFAS present in wastewater and stormwater discharges. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains. In August 2022, EPA published a proposed rule that would designate PFOA and PFOS as “hazardous substances” under CERCLA.

[0000833444-23-000005:notes:180]
It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of

[0000833444-23-000005:notes:181]
the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000833444-23-000005:notes:182]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $17 million at both December 31, 2022 and September 30, 2022.

[0000833444-23-000005:notes:183]
FTC-Related Remediation and Litigation

[0000833444-23-000005:notes:184]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin recently approved final regulatory standards for PFOA and PFOS in drinking water and surface water, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. In September 2022, the Governor of Wisconsin signed a scope statement setting out parameters for the WDNR to draft a final rule regarding groundwater quality standards for PFOA and PFOS, among other compounds. The WDNR is now in the process of drafting the rule.

[0000833444-23-000005:notes:185]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. Tyco Fire Products responded to the WDNR’s letter by requesting additional necessary information. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 3, 2019 letter. The WDNR issued a further letter regarding the issue on November 4, 2019. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to date. Tyco Fire Products responded to the WDNR’s September 2021 notice by the December 27, 2021 deadline set by WDNR and submitted a Land Applied Biosolids Interim Site Status Update Report to WDNR on October 25, 2022. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

[0000833444-23-000005:notes:186]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR’s requests. The lawsuit is presently at the beginning stages of litigation: Tyco Fire Products and Johnson Controls, Inc. each filed Answers to the Complaint on April 4, 2022 and the parties are proceeding with initial fact discovery. The Company is vigorously defending this civil enforcement action and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

[0000833444-23-000005:notes:187]
In October 2022, the Town of Peshtigo filed a tort action in Wisconsin state court against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and ChemDesign, Inc. relating to environmental matters at the FTC (Town of Peshtigo v. Tyco Fire Products L.P. et al., Case No. 2022CV000234 (filed October 18, 2022 in Circuit Court in Marinette County, Wisconsin)). The Town alleges that use of AFFF products at the FTC caused contamination of water supplies in Peshtigo. The Town seeks monetary penalties and an injunction ordering abatement of PFAS contamination in Peshtigo. The case has been removed to federal court and transferred to a multi-district litigation ("MDL") before the United States District Court for the District of South Carolina. The Company plans to vigorously defend against this case and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

[0000833444-23-000005:notes:188]
In November 2022, individuals filed six actions in Dane County, Wisconsin alleging personal injury and/or property damage against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and other unaffiliated defendants related to environmental matters at the FTC. Plaintiffs allege that use of AFFF products at the FTC and activities by third parties unrelated to the Company contaminated nearby drinking water sources, surface waters, and other natural resources and properties, including their personal properties. The individuals seek monetary damages for their personal injury and/or property damage. These lawsuits were removed to federal court on December 21, 2022, and were tagged to the MDL on December 22, 2022. The Plaintiffs have opposed removal and transfer to the MDL. These lawsuits are presently at the beginning stages of litigation. The Company is vigorously defending these cases and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

[0000833444-23-000005:notes:189]
Aqueous Film-Forming Foam ("AFFF") Litigation

[0000833444-23-000005:notes:190]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-23-000005:notes:191]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to the MDL. Additional cases have been identified for transfer to or are being directly filed in the MDL.

[0000833444-23-000005:notes:192]
AFFF Putative Class Actions

[0000833444-23-000005:notes:193]
Chemguard and Tyco Fire Products are named in 34 pending putative class actions in federal courts originating from 15 states and territories. All but one of these cases have been direct-filed in or transferred to the MDL and it is anticipated that the remaining case will be transferred to the MDL.

[0000833444-23-000005:notes:194]
AFFF Individual or Mass Actions

[0000833444-23-000005:notes:195]
There are more than 3,100 individual or “mass” actions pending that were filed in state or federal courts originating from 51 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 3,100 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona and Illinois.

[0000833444-23-000005:notes:196]
Tyco and Chemguard are also periodically notified by other individuals that they may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-23-000005:notes:197]
AFFF Municipal and Water Provider Cases

[0000833444-23-000005:notes:198]
Chemguard and Tyco Fire Products have been named as defendants in more than 290 cases involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 27 states. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation. The MDL Court has set the first case for trial on June 4, 2023, (City of Stuart (Florida) v. 3M Co. et al.) and has ordered the parties to conduct mediation of the water provider cases pending in the MDL.

[0000833444-23-000005:notes:199]
Tyco and Chemguard are also periodically notified by other municipal entities that those entities may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-23-000005:notes:200]
State or U.S. Territory Attorneys General Litigation related to AFFF

[0000833444-23-000005:notes:201]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-23-000005:notes:202]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-23-000005:notes:203]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. The 3M Company et al., No. G-4801-CI-021804752-000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio. The lawsuit seeks to recover costs and natural resource damages associated with the contamination. This lawsuit has been removed to the United States District Court for the Northern District of Ohio and transferred to the MDL.

[0000833444-23-000005:notes:204]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.). All three of these suits have been removed to federal court and transferred to the MDL.

[0000833444-23-000005:notes:205]
In September 2019, the government of Guam filed a lawsuit in the superior court of Guam against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-23-000005:notes:206]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.

[0000833444-23-000005:notes:207]
In August 2020, Attorney General of the State of Michigan filed two substantially similar lawsuits—one in federal court and one in state court—against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within the State. The federal action has been transferred to the MDL, and the state court action has been removed to federal court and transferred to the MDL.

[0000833444-23-000005:notes:208]
In December 2020, the State of Mississippi filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State.  This complaint was direct-filed in the MDL in South Carolina.

[0000833444-23-000005:notes:209]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. The State’s case has been removed to federal court and transferred to the MDL. The State of Alaska has also named a number of manufacturers and other defendants, including affiliates of the Company, as third-party defendants in two cases brought by individuals against the State. These two cases have also been transferred to the MDL.

[0000833444-23-000005:notes:210]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL. In October 2022, the Attorney General filed two similar lawsuits in the superior courts of the State of North Carolina regarding alleged PFAS damages at two additional locations. It is anticipated that these two cases will be removed to federal court and transferred to the MDL.

[0000833444-23-000005:notes:211]
In February 2022, the Attorney General of the State of Colorado filed a lawsuit in Colorado state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources, public health, and State property allegedly resulting from the use of firefighting foams at various locations throughout the State. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-23-000005:notes:212]
In April 2022, the Attorney General of the State of Florida filed a lawsuit in Florida state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage to the State’s natural resources and public health allegedly resulting from the use of firefighting foams at various locations throughout the State. It is anticipated that this complaint will be removed to federal court and transferred to the MDL.

[0000833444-23-000005:notes:213]
In May 2022, the Attorney General of the Commonwealth of Massachusetts filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s natural resources, property, residents, and consumers allegedly resulting from the use of firefighting foams at various locations throughout the State.  This complaint was direct-filed in the MDL in South Carolina.

[0000833444-23-000005:notes:214]
In July 2022, the Attorney General of the State of Wisconsin filed a lawsuit in Wisconsin state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage to the State’s natural resources and public health allegedly resulting, in part, from the use of firefighting foams at various locations throughout the State. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-23-000005:notes:215]
In November 2022, the Attorney General of the State of California filed a lawsuit in California state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the manufacture, use, marketing, or sale of PFAS-containing products, including firefighting foams, at various locations throughout the State. On December 20, 2022, the case was removed to federal court and tagged to the MDL. The Attorney General has opposed removal and transfer.

[0000833444-23-000005:notes:216]
Other AFFF Related Matters

[0000833444-23-000005:notes:217]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

[0000833444-23-000005:notes:218]
In October 2022, the Red Cliff Band of Lake Superior Chippewa Indians (a federally recognized tribe) filed a lawsuit in the United States District Court for the Western District of Wisconsin against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota. This complaint has been transferred to the MDL.

[0000833444-23-000005:notes:219]
The Company is vigorously defending the above matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. In September 2022, the AFFF MDL Court declined to grant summary judgment on the government contractor defense, ruling that various factual issues relevant to the defense must be decided by a jury rather than the Court. Tyco and Chemguard have insurance that has been in place for many years and the Company is pursuing this coverage for these matters. However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

[0000833444-23-000005:notes:220]
Asbestos Matters

[0000833444-23-000005:notes:221]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-23-000005:notes:222]
The Company estimates the asbestos-related liability for pending and future claims and related defense costs on a discounted basis. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable.

[0000833444-23-000005:notes:223]
The following table presents the location and amount of asbestos-related assets and liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-23-000005:notes:224]
|  | December 31, 2022 |  | September 30, 2022 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 375 |  |  | 380 |  |
| Total asbestos-related liabilities | 433 |  |  | 438 |  |
| Other current assets | 39 |  |  | 37 |  |
| Other noncurrent assets | 267 |  |  | 263 |  |
| Total asbestos-related assets | 306 |  |  | 300 |  |
| Net asbestos-related liabilities | $ | 127 |  |  | $ | 138 |  |

[0000833444-23-000005:notes:225]
The following table presents the components of asbestos-related assets (in millions):

[0000833444-23-000005:notes:226]
|  | December 31, 2022 |  | September 30, 2022 |
| Restricted |  |  |  |
| Cash | $ | 8 |  |  | $ | 6 |  |
| Investments | 244 |  |  | 239 |  |
| Total restricted assets | 252 |  |  | 245 |  |
| Insurance receivables for asbestos-related liabilities | 54 |  |  | 55 |  |
| Total asbestos-related assets | $ | 306 |  |  | $ | 300 |  |

[0000833444-23-000005:notes:227]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be paid by Company affiliates). Estimated asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be paid through 2068. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-23-000005:notes:228]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption may impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-23-000005:notes:229]
Self-Insured Liabilities

[0000833444-23-000005:notes:230]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage its self-insured liabilities.

[0000833444-23-000005:notes:231]
The following table presents the location and amount of self-insured liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-23-000005:notes:232]
|  | December 31, 2022 |  | September 30, 2022 |
| Other current liabilities | $ | 112 |  |  | $ | 89 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 230 |  |  | 230 |  |
| Total self-insured liabilities | $ | 364 |  |  | $ | 341 |  |

[0000833444-23-000005:notes:233]
The following table presents the location and amount of insurance receivables in the Company's consolidated statements of financial position (in millions):

[0000833444-23-000005:notes:234]
|  | December 31, 2022 |  | September 30, 2022 |
| Other current assets | $ | 10 |  |  | $ | 10 |  |
| Other noncurrent assets | 20 |  |  | 20 |  |
| Total insurance receivables | $ | 30 |  |  | $ | 30 |  |

[0000833444-23-000005:notes:235]
Other Matters

[0000833444-23-000005:notes:236]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock

[0000833444-23-000005:notes:237]
The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):
