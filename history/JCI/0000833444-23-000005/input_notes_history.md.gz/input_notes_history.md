# JCI note change history — 0000833444-22-000036 → 0000833444-23-000005


## jci:ScheduleOfAccrualForAsbestosLossContingenciesTableTextBlock (contingencies) — matched_by: no_current_note, score: 0.0

- removed (2023-02-01):
[0000833444-22-000036:note_history:1]
The following table presents the location and amount of asbestos-related assets and liabilities in the Company's consolidated statements of financial position (in millions):

- removed (2023-02-01):
[0000833444-22-000036:note_history:2]
|  | June 30, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 385 |  |  | 400 |  |
| Total asbestos-related liabilities | 443 |  |  | 458 |  |
| Other current assets | 39 |  |  | 13 |  |
| Other noncurrent assets | 279 |  |  | 365 |  |
| Total asbestos-related assets | 318 |  |  | 378 |  |
| Net asbestos-related liabilities | $ | 125 |  |  | $ | 80 |  |

- removed (2023-02-01):
[0000833444-22-000036:note_history:3]
The following table presents the components of asbestos-related assets (in millions):

- removed (2023-02-01):
[0000833444-22-000036:note_history:4]
|  | June 30, 2022 |  | September 30, 2021 |
| Restricted |  |  |  |
| Cash | $ | 8 |  |  | $ | 6 |  |
| Investments | 255 |  |  | 314 |  |
| Total restricted assets | 263 |  |  | 320 |  |
| Insurance recoveries for asbestos-related liabilities | 55 |  |  | 58 |  |
| Total asbestos-related assets | $ | 318 |  |  | $ | 378 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-02-01):
[0000833444-23-000005:note_history:5]
|  | December 31, 2022 |  | September 30, 2022 |
| Other current liabilities | $ | 48 |  |  | $ | 66 |  |
| Other noncurrent liabilities | 227 |  |  | 220 |  |
| Total reserves for environmental liabilities | $ | 275 |  |  | $ | 286 |  |
  (was, 2022-08-04, similarity 0.9706):
[0000833444-22-000036:note_history:5]
|  | June 30, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 57 |  |  | $ | 48 |  |
| Other noncurrent liabilities | 15 |  |  | 54 |  |
| Total reserves for environmental liabilities | $ | 72 |  |  | $ | 102 |  |

- added (2023-02-01):
[0000833444-23-000005:note_history:6]
The Company periodically examines whether the contingent liabilities related to the environmental matters described below are probable and reasonably estimable based on experience and ongoing developments in those matters, including continued study and analysis of ongoing remediation obligations. During the three months ended September 30, 2022, with the assistance of independent environmental consultants and taking into consideration investigation and remediation actions previously completed, new information available to the Company during the fourth quarter of fiscal 2022 and ongoing discussions with the Wisconsin Department of Natural Resources ("WDNR"), the Company completed a comprehensive long-term analysis and cost assessment related to the Company’s ongoing environmental remediation obligations. As a result of this analysis, the Company increased its accrual for environmental liabilities by $228 million, which are recorded on an undiscounted basis. The Company expects that it will pay the amounts recorded over an estimated period of up to 20 years. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals for environmental liabilities at this time.

- added (2023-02-01):
[0000833444-23-000005:note_history:7]
A substantial portion of the increase to the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to fire-fighting foams containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The increase in reserves was recorded as a result of several events that occurred in the three months ended September 30, 2022, including the completion and testing of the Groundwater Extraction and Treatment System (“GETS”) at the FTC (as further discussed below), the completion of resident surveys in Peshtigo regarding long-term drinking water solutions, correspondence with regulators on planned remediation activities, finalization of cost estimates for system upgrades and related long-term run rate costs in response to new permit requirements at the Stanton Street Facility, and the development of additional information through ongoing investigation and analysis. These events allowed the Company to develop estimates of costs associated with the long-term remediation actions expected to be

- added (2023-02-01):
[0000833444-23-000005:note_history:8]
performed over an estimated period of up to 20 years, including the continued operation of the GETS, the implementation of long-term drinking water solutions, continued monitoring and testing of the wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

- added (2023-02-01):
[0000833444-23-000005:note_history:9]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports, or elsewhere. In May 2021, as part of Tyco Fire Products’ ongoing investigation and remediation program, the WDNR approved Tyco Fire Products’ proposed GETS, a permanent groundwater remediation system that will extract groundwater that contains PFAS, treat it using advanced filtration systems, and return the treated water to the environment. Tyco Fire Products has completed construction of the GETS, which is now in operation. Tyco Fire Products is also in the process of completing the removal and disposal of PFAS-affected soil from the FTC. In December 2022, Tyco Fire Products also began implementation of a long-term drinking water solution for some Peshtigo residents with the installation of the first deep aquifer private drinking wells.

- changed (2023-02-01):
[0000833444-23-000005:note_history:10]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency (“EPA”) to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the WDNR to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.
  (was, 2022-08-04, similarity 0.8472):
[0000833444-22-000036:note_history:10]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”) manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. The increase in the reserve related to the Stanton Street Facility in the third quarter of 2019 was recorded following a further review of the Consent Order, which

- changed (2023-02-01):
[0000833444-23-000005:note_history:11]
PFOA, PFOS, and other PFAS compounds are being studied by EPA and other environmental and health agencies and researchers. EPA has not issued binding regulatory limits, but had initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. While those studies continue, EPA issued in June 2022 an updated set of interim health advisory levels for PFOA and PFOS in drinking water, as well as final health advisory levels for two other types of PFAS (PFBS and GenX chemicals). In November 2022, EPA added a class definition of PFAS to the final version of EPA's fifth Contaminant Candidate List (CCL 5), which is a list of substances not currently subject to national drinking water regulation, but which EPA believes may require future regulation.
  (was, 2022-08-04, similarity 0.7442):
[0000833444-22-000036:note_history:11]
PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but had initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. In March 2021, the EPA published its final determination to regulate PFOS and PFOA in drinking water. While those studies continue, the EPA issued in June 2022 an updated set of interim health advisory levels for PFOA and PFOS in drinking water.

- changed (2023-02-01):
[0000833444-23-000005:note_history:12]
In October 2021, EPA released its "PFAS Strategic Roadmap: EPA's Commitments to Action 2021-2024." The 2021-2024 Roadmap sets timelines by which EPA plans to take specific actions, including, among other items, publishing a national PFAS testing strategy, proposing to designate PFOA and PFOS as Comprehensive Environmental Response, Compensation and Liability Act hazardous substances, restricting PFAS discharges from industrial sources through Effluent Limitations Guidelines, publishing the final toxicity assessment for five additional PFAS, requiring water systems to test for 29 PFAS under the Safe Drinking Water Act, and publishing improved analytical methods in eight different environmental matrices to monitor 40 PFAS present in wastewater and stormwater discharges. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains. In August 2022, EPA published a proposed rule that would designate PFOA and PFOS as “hazardous substances” under CERCLA.
  (was, 2022-08-04, similarity 0.9479):
[0000833444-22-000036:note_history:12]
In October 2021, the EPA released its "PFAS Strategic Roadmap: EPA's Commitments to Action 2021-2024." The 2021-2024 Roadmap sets timelines by which the EPA plans to take specific actions, including, among other items, publishing a national PFAS testing strategy, proposing to designate PFOA and PFOS as Comprehensive Environmental Response, Compensation and Liability Act hazardous substances, restricting PFAS discharges from industrial sources through Effluent Limitations Guidelines, publishing the final toxicity assessment for five additional PFAS, requiring water systems to test for 29 PFAS under the Safe Drinking Water Act, and publishing improved analytical methods in eight different environmental matrices to monitor 40 PFAS present in wastewater and stormwater discharges. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

- added (2023-02-01):
[0000833444-23-000005:note_history:13]
It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of

- added (2023-02-01):
[0000833444-23-000005:note_history:14]
the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- changed (2023-02-01):
[0000833444-23-000005:note_history:15]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $17 million at both December 31, 2022 and September 30, 2022.
  (was, 2022-08-04, similarity 0.8006):
[0000833444-22-000036:note_history:15]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. The Company's conditional asset retirement obligations for continuing operations were $25 million and $29 million at June 30, 2022 and September 30, 2021, respectively.

- added (2023-02-01):
[0000833444-23-000005:note_history:16]
FTC-Related Remediation and Litigation

- added (2023-02-01):
[0000833444-23-000005:note_history:17]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin recently approved final regulatory standards for PFOA and PFOS in drinking water and surface water, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. In September 2022, the Governor of Wisconsin signed a scope statement setting out parameters for the WDNR to draft a final rule regarding groundwater quality standards for PFOA and PFOS, among other compounds. The WDNR is now in the process of drafting the rule.

- added (2023-02-01):
[0000833444-23-000005:note_history:18]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. Tyco Fire Products responded to the WDNR’s letter by requesting additional necessary information. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 3, 2019 letter. The WDNR issued a further letter regarding the issue on November 4, 2019. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to date. Tyco Fire Products responded to the WDNR’s September 2021 notice by the December 27, 2021 deadline set by WDNR and submitted a Land Applied Biosolids Interim Site Status Update Report to WDNR on October 25, 2022. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

- changed (2023-02-01):
[0000833444-23-000005:note_history:19]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR’s requests. The lawsuit is presently at the beginning stages of litigation: Tyco Fire Products and Johnson Controls, Inc. each filed Answers to the Complaint on April 4, 2022 and the parties are proceeding with initial fact discovery. The Company is vigorously defending this civil enforcement action and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.
  (was, 2022-08-04, similarity 0.7969):
[0000833444-22-000036:note_history:19]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR’s requests. The lawsuit is presently at the beginning stages of litigation: Tyco Fire Products and Johnson Controls, Inc. each filed Answers to the Complaint on April 4, 2022. The Company is vigorously defending this civil enforcement action and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

- added (2023-02-01):
[0000833444-23-000005:note_history:20]
In October 2022, the Town of Peshtigo filed a tort action in Wisconsin state court against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and ChemDesign, Inc. relating to environmental matters at the FTC (Town of Peshtigo v. Tyco Fire Products L.P. et al., Case No. 2022CV000234 (filed October 18, 2022 in Circuit Court in Marinette County, Wisconsin)). The Town alleges that use of AFFF products at the FTC caused contamination of water supplies in Peshtigo. The Town seeks monetary penalties and an injunction ordering abatement of PFAS contamination in Peshtigo. The case has been removed to federal court and transferred to a multi-district litigation ("MDL") before the United States District Court for the District of South Carolina. The Company plans to vigorously defend against this case and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

- added (2023-02-01):
[0000833444-23-000005:note_history:21]
In November 2022, individuals filed six actions in Dane County, Wisconsin alleging personal injury and/or property damage against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and other unaffiliated defendants related to environmental matters at the FTC. Plaintiffs allege that use of AFFF products at the FTC and activities by third parties unrelated to the Company contaminated nearby drinking water sources, surface waters, and other natural resources and properties, including their personal properties. The individuals seek monetary damages for their personal injury and/or property damage. These lawsuits were removed to federal court on December 21, 2022, and were tagged to the MDL on December 22, 2022. The Plaintiffs have opposed removal and transfer to the MDL. These lawsuits are presently at the beginning stages of litigation. The Company is vigorously defending these cases and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

- changed (2023-02-01):
[0000833444-23-000005:note_history:22]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to the MDL. Additional cases have been identified for transfer to or are being directly filed in the MDL.
  (was, 2022-08-04, similarity 0.8788):
[0000833444-22-000036:note_history:22]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to or are being directly filed in the MDL.

- added (2023-02-01):
[0000833444-23-000005:note_history:23]
Chemguard and Tyco Fire Products are named in 34 pending putative class actions in federal courts originating from 15 states and territories. All but one of these cases have been direct-filed in or transferred to the MDL and it is anticipated that the remaining case will be transferred to the MDL.

- added (2023-02-01):
[0000833444-23-000005:note_history:24]
There are more than 3,100 individual or “mass” actions pending that were filed in state or federal courts originating from 51 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 3,100 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona and Illinois.

- changed (2023-02-01):
[0000833444-23-000005:note_history:25]
Tyco and Chemguard are also periodically notified by other individuals that they may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.
  (was, 2022-08-04, similarity 0.8387):
[0000833444-22-000036:note_history:25]
The Company has periodically been notified by other municipal entities that those entities may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

- changed (2023-02-01):
[0000833444-23-000005:note_history:26]
AFFF Municipal and Water Provider Cases
  (was, 2022-08-04, similarity 0.678):
[0000833444-22-000036:note_history:26]
AFFF Municipal Cases

- added (2023-02-01):
[0000833444-23-000005:note_history:27]
Chemguard and Tyco Fire Products have been named as defendants in more than 290 cases involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 27 states. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation. The MDL Court has set the first case for trial on June 4, 2023, (City of Stuart (Florida) v. 3M Co. et al.) and has ordered the parties to conduct mediation of the water provider cases pending in the MDL.

- added (2023-02-01):
[0000833444-23-000005:note_history:28]
Tyco and Chemguard are also periodically notified by other municipal entities that those entities may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

- changed (2023-02-01):
[0000833444-23-000005:note_history:29]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.
  (was, 2022-08-04, similarity 0.7211):
[0000833444-22-000036:note_history:29]
New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

- added (2023-02-01):
[0000833444-23-000005:note_history:30]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL. In October 2022, the Attorney General filed two similar lawsuits in the superior courts of the State of North Carolina regarding alleged PFAS damages at two additional locations. It is anticipated that these two cases will be removed to federal court and transferred to the MDL.

- changed (2023-02-01):
[0000833444-23-000005:note_history:31]
In July 2022, the Attorney General of the State of Wisconsin filed a lawsuit in Wisconsin state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage to the State’s natural resources and public health allegedly resulting, in part, from the use of firefighting foams at various locations throughout the State. This complaint has been removed to federal court and transferred to the MDL.
  (was, 2022-08-04, similarity 0.9694):
[0000833444-22-000036:note_history:31]
In July 2022, the Attorney General of the State of Wisconsin filed a lawsuit in Wisconsin state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage to the State’s natural resources and public health allegedly resulting, in part, from the use of firefighting foams at various locations throughout the State. This complaint has been removed to federal court and tagged for transfer to the MDL.

- added (2023-02-01):
[0000833444-23-000005:note_history:32]
In November 2022, the Attorney General of the State of California filed a lawsuit in California state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the manufacture, use, marketing, or sale of PFAS-containing products, including firefighting foams, at various locations throughout the State. On December 20, 2022, the case was removed to federal court and tagged to the MDL. The Attorney General has opposed removal and transfer.

- added (2023-02-01):
[0000833444-23-000005:note_history:33]
In October 2022, the Red Cliff Band of Lake Superior Chippewa Indians (a federally recognized tribe) filed a lawsuit in the United States District Court for the Western District of Wisconsin against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota. This complaint has been transferred to the MDL.

- added (2023-02-01):
[0000833444-23-000005:note_history:34]
The Company is vigorously defending the above matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. In September 2022, the AFFF MDL Court declined to grant summary judgment on the government contractor defense, ruling that various factual issues relevant to the defense must be decided by a jury rather than the Court. Tyco and Chemguard have insurance that has been in place for many years and the Company is pursuing this coverage for these matters. However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

- added (2023-02-01):
[0000833444-23-000005:note_history:35]
|  | December 31, 2022 |  | September 30, 2022 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 375 |  |  | 380 |  |
| Total asbestos-related liabilities | 433 |  |  | 438 |  |
| Other current assets | 39 |  |  | 37 |  |
| Other noncurrent assets | 267 |  |  | 263 |  |
| Total asbestos-related assets | 306 |  |  | 300 |  |
| Net asbestos-related liabilities | $ | 127 |  |  | $ | 138 |  |

- added (2023-02-01):
[0000833444-23-000005:note_history:36]
|  | December 31, 2022 |  | September 30, 2022 |
| Restricted |  |  |  |
| Cash | $ | 8 |  |  | $ | 6 |  |
| Investments | 244 |  |  | 239 |  |
| Total restricted assets | 252 |  |  | 245 |  |
| Insurance receivables for asbestos-related liabilities | 54 |  |  | 55 |  |
| Total asbestos-related assets | $ | 306 |  |  | $ | 300 |  |

- changed (2023-02-01):
[0000833444-23-000005:note_history:37]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be paid by Company affiliates). Estimated asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be paid through 2068. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.
  (was, 2022-08-04, similarity 0.9941):
[0000833444-22-000036:note_history:37]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be paid by Company affiliates). Asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be paid through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

- changed (2023-02-01):
[0000833444-23-000005:note_history:38]
Self-Insured Liabilities
  (was, 2022-08-04, similarity 0.8):
[0000833444-22-000036:note_history:38]
Insurable Liabilities

- changed (2023-02-01):
[0000833444-23-000005:note_history:39]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage its self-insured liabilities.
  (was, 2022-08-04, similarity 0.9763):
[0000833444-22-000036:note_history:39]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage its insurable liabilities.

- changed (2023-02-01):
[0000833444-23-000005:note_history:40]
The following table presents the location and amount of self-insured liabilities in the Company's consolidated statements of financial position (in millions):
  (was, 2022-08-04, similarity 0.9712):
[0000833444-22-000036:note_history:40]
The following table presents the location and amount of insurable liabilities in the Company's consolidated statements of financial position (in millions):

- changed (2023-02-01):
[0000833444-23-000005:note_history:41]
|  | December 31, 2022 |  | September 30, 2022 |
| Other current liabilities | $ | 112 |  |  | $ | 89 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 230 |  |  | 230 |  |
| Total self-insured liabilities | $ | 364 |  |  | $ | 341 |  |
  (was, 2022-08-04, similarity 0.7817):
[0000833444-22-000036:note_history:41]
|  | June 30, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 91 |  |  | $ | 77 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 219 |  |  | 226 |  |
| Total insurable liabilities | $ | 332 |  |  | $ | 325 |  |

- changed (2023-02-01):
[0000833444-23-000005:note_history:42]
The following table presents the location and amount of insurance receivables in the Company's consolidated statements of financial position (in millions):
  (was, 2022-08-04, similarity 0.9871):
[0000833444-22-000036:note_history:42]
The following table presents the location and amount of insurable receivables in the Company's consolidated statements of financial position (in millions):

- changed (2023-02-01):
[0000833444-23-000005:note_history:43]
|  | December 31, 2022 |  | September 30, 2022 |
| Other current assets | $ | 10 |  |  | $ | 10 |  |
| Other noncurrent assets | 20 |  |  | 20 |  |
| Total insurance receivables | $ | 30 |  |  | $ | 30 |  |
  (was, 2022-08-04, similarity 0.9605):
[0000833444-22-000036:note_history:43]
|  | June 30, 2022 |  | September 30, 2021 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 15 |  |  | 15 |  |
| Total insurable receivables | $ | 20 |  |  | $ | 20 |  |

- removed (2023-02-01):
[0000833444-22-000036:note_history:44]
Tyco Fire Products L.P. (“Tyco Fire Products”), in coordination with the Wisconsin Department of Natural Resources ("WDNR"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin. In connection with the assessment, perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluoroalkyl substances ("PFAS") have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC. Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working with WDNR to address these issues insofar as they related to this migration.

- removed (2023-02-01):
[0000833444-22-000036:note_history:45]
A substantial portion of the Company’s environmental reserves relates to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The Company’s reserves for remediation efforts at or near the FTC are based on a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals at this time. The Company is currently conducting additional analyses and cost assessments associated with longer-term remediation actions at or near the FTC. The Company anticipates recording additional remediation reserves in the fourth quarter of fiscal 2022 when the associated liabilities become estimable following completion of these analyses and assessments.

- removed (2023-02-01):
[0000833444-22-000036:note_history:46]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. On August 22, 2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation. On November 6, 2020, WDNR received further recommendations from WDHS regarding individual standards for 12 additional PFAS and a combined standard for four additional PFAS, PFOA, and PFOS.

- removed (2023-02-01):
[0000833444-22-000036:note_history:47]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. Tyco Fire Products voluntarily responded to the WDNR’s letter to request additional necessary information.  On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. The letter stated that “if you fail to take the actions required by Wis. Stat. § 292.11 to address this contamination, the DNR will move forward under Wis. Stat. § 292.31 to implement the SI workplan and evaluate further environmental enforcement actions and cost recovery under Wis. Stat. § 292.31(8).” The WDNR issued a further letter regarding the issue on November 4, 2019.  In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to date. Tyco Fire Products responded to the WDNR’s September 2021 notice by the December 27, 2021 deadline set by WDNR. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

- removed (2023-02-01):
[0000833444-22-000036:note_history:48]
In May 2021, as part of Tyco Fire Products’ ongoing investigation and remediation program, WDNR approved Tyco Fire Products’ proposed Groundwater Extraction and Treatment System (“GETS”), a permanent groundwater remediation system that will extract groundwater that contains PFAS, treat it using advanced filtration systems, and return the treated water to the environment. Tyco Fire Products is nearing completion of construction on the GETS. Tyco Fire Products is also nearly finished removing PFAS-affected soil from the FTC.

- removed (2023-02-01):
[0000833444-22-000036:note_history:49]
resulted in the identification of several structural upgrades needed to preserve the effectiveness of prior remediation efforts. In addition to ongoing remediation activities, the Company is also working with the WDNR to investigate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation of PFAS in the Marinette region.

- removed (2023-02-01):
[0000833444-22-000036:note_history:50]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- removed (2023-02-01):
[0000833444-22-000036:note_history:51]
|  | June 30, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 385 |  |  | 400 |  |
| Total asbestos-related liabilities | 443 |  |  | 458 |  |
| Other current assets | 39 |  |  | 13 |  |
| Other noncurrent assets | 279 |  |  | 365 |  |
| Total asbestos-related assets | 318 |  |  | 378 |  |
| Net asbestos-related liabilities | $ | 125 |  |  | $ | 80 |  |

- removed (2023-02-01):
[0000833444-22-000036:note_history:52]
|  | June 30, 2022 |  | September 30, 2021 |
| Restricted |  |  |  |
| Cash | $ | 8 |  |  | $ | 6 |  |
| Investments | 255 |  |  | 314 |  |
| Total restricted assets | 263 |  |  | 320 |  |
| Insurance recoveries for asbestos-related liabilities | 55 |  |  | 58 |  |
| Total asbestos-related assets | $ | 318 |  |  | $ | 378 |  |

- removed (2023-02-01):
[0000833444-22-000036:note_history:53]
Chemguard and Tyco Fire Products are named in 33 putative class actions in federal courts originating from Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington, New Hampshire, South Carolina, the District of Columbia, Guam, West Virginia, Michigan, Texas and South Dakota. All of these cases except one have been direct-filed in or transferred to the MDL.

- removed (2023-02-01):
[0000833444-22-000036:note_history:54]
There are more than 2,500 individual or “mass” actions pending that were filed in state or federal court in various states including California, Colorado, New York, Pennsylvania, New Mexico, Missouri, Arizona, Texas, and South Carolina against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 2,100 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona, Illinois, and Texas.

- removed (2023-02-01):
[0000833444-22-000036:note_history:55]
Chemguard and Tyco Fire Products have been named as defendants in more than 200 cases in federal and state courts involving municipal or water provider plaintiffs in various states including Alaska, Alabama, Arizona, California, Colorado, Connecticut, Florida, Idaho, Illinois, Kentucky, Louisiana, Maryland, Massachusetts, Michigan, New Jersey, New York, North Carolina, Ohio, Pennsylvania, Virginia, Washington, West Virginia, Wisconsin, the District of Columbia, and several municipalities or water providers from various states who direct-filed complaints in South Carolina. The vast majority of these cases have been transferred to or directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.

- removed (2023-02-01):
[0000833444-22-000036:note_history:56]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of

- removed (2023-02-01):
[0000833444-22-000036:note_history:57]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the

- removed (2023-02-01):
[0000833444-22-000036:note_history:58]
Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL.

- removed (2023-02-01):
[0000833444-22-000036:note_history:59]
The Company is vigorously defending the above matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. Tyco and Chemguard have insurance that has been in place for many years and the Company is pursuing this coverage for these matters. However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: title_similarity, score: 1.0

- changed (2023-02-01):
[0000833444-23-000005:note_history:60]
|  | December 31, 2022 |  | September 30, 2022 |
| Other current liabilities | $ | 48 |  |  | $ | 66 |  |
| Other noncurrent liabilities | 227 |  |  | 220 |  |
| Total reserves for environmental liabilities | $ | 275 |  |  | $ | 286 |  |
  (was, 2022-08-04, similarity 0.9706):
[0000833444-22-000036:note_history:60]
|  | June 30, 2022 |  | September 30, 2021 |
| Other current liabilities | $ | 57 |  |  | $ | 48 |  |
| Other noncurrent liabilities | 15 |  |  | 54 |  |
| Total reserves for environmental liabilities | $ | 72 |  |  | $ | 102 |  |

- added (2023-02-01):
[0000833444-23-000005:note_history:61]
The following table presents the location and amount of asbestos-related assets and liabilities in the Company's consolidated statements of financial position (in millions):

- added (2023-02-01):
[0000833444-23-000005:note_history:62]
|  | December 31, 2022 |  | September 30, 2022 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 375 |  |  | 380 |  |
| Total asbestos-related liabilities | 433 |  |  | 438 |  |
| Other current assets | 39 |  |  | 37 |  |
| Other noncurrent assets | 267 |  |  | 263 |  |
| Total asbestos-related assets | 306 |  |  | 300 |  |
| Net asbestos-related liabilities | $ | 127 |  |  | $ | 138 |  |

- added (2023-02-01):
[0000833444-23-000005:note_history:63]
The following table presents the components of asbestos-related assets (in millions):

- added (2023-02-01):
[0000833444-23-000005:note_history:64]
|  | December 31, 2022 |  | September 30, 2022 |
| Restricted |  |  |  |
| Cash | $ | 8 |  |  | $ | 6 |  |
| Investments | 244 |  |  | 239 |  |
| Total restricted assets | 252 |  |  | 245 |  |
| Insurance receivables for asbestos-related liabilities | 54 |  |  | 55 |  |
| Total asbestos-related assets | $ | 306 |  |  | $ | 300 |  |

- added (2023-02-01):
[0000833444-23-000005:note_history:65]
The following table presents the location and amount of self-insured liabilities in the Company's consolidated statements of financial position (in millions):

- added (2023-02-01):
[0000833444-23-000005:note_history:66]
|  | December 31, 2022 |  | September 30, 2022 |
| Other current liabilities | $ | 112 |  |  | $ | 89 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 230 |  |  | 230 |  |
| Total self-insured liabilities | $ | 364 |  |  | $ | 341 |  |

- added (2023-02-01):
[0000833444-23-000005:note_history:67]
The following table presents the location and amount of insurance receivables in the Company's consolidated statements of financial position (in millions):

- added (2023-02-01):
[0000833444-23-000005:note_history:68]
|  | December 31, 2022 |  | September 30, 2022 |
| Other current assets | $ | 10 |  |  | $ | 10 |  |
| Other noncurrent assets | 20 |  |  | 20 |  |
| Total insurance receivables | $ | 30 |  |  | $ | 30 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-02-01):
[0000833444-23-000005:note_history:69]
Basis of Presentation
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company," or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2022 filed with the SEC on November 15, 2022. The results of operations for the three month period ended December 31, 2022 are not necessarily indicative of results for the Company’s 2023 fiscal year because of seasonal and other factors.
  (was, 2022-08-04, similarity 0.978):
[0000833444-22-000036:note_history:69]
Basis of Presentation
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2021 filed with the SEC on November 15, 2021. The results of operations for the three and nine month periods ended June 30, 2022 are not necessarily indicative of results for the Company’s 2022 fiscal year because of seasonal and other factors.

- changed (2023-02-01):
[0000833444-23-000005:note_history:70]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including residential and commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions powered by its OpenBlue software platform and capabilities. The Company partners with customers by leveraging its broad product portfolio and digital capabilities powered by OpenBlue, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency, enhance security, create healthy environments and reduce greenhouse gas emissions.
  (was, 2022-08-04, similarity 0.953):
[0000833444-22-000036:note_history:70]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including residential and commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management and repair of equipment (in the HVAC, industrial refrigeration, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions powered by its OpenBlue software platform and capabilities. The Company partners with customers by leveraging its broad product portfolio and digital capabilities powered by OpenBlue, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency and reduce greenhouse gas emissions.

- changed (2023-02-01):
[0000833444-23-000005:note_history:71]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries that are consolidated in conformity with U.S. GAAP. All significant intercompany transactions have been eliminated. The results of companies acquired or disposed of during the reporting period are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company exercises significant influence, which typically occurs when its ownership interest exceeds 20%, and the Company does not have a controlling interest.
  (was, 2022-08-04, similarity 0.9407):
[0000833444-22-000036:note_history:71]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries that are consolidated in conformity with U.S. GAAP. All significant intercompany transactions have been eliminated. The results of companies acquired or disposed of during the reporting period are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company’s interest exceeds 20% and the Company does not have a controlling interest.

- changed (2023-02-01):
[0000833444-23-000005:note_history:72]
The Company consolidates variable interest entities ("VIE") when it has the power to direct the significant activities of the entity and the obligation to absorb losses or receive benefits from the entity that may be significant. The Company did not have any material consolidated or nonconsolidated VIE's for the presented reporting periods.
  (was, 2022-08-04, similarity 0.7696):
[0000833444-22-000036:note_history:72]
The Company consolidates variable interest entities ("VIE") in which the Company has the power to direct the significant activities of the entity and the obligation to absorb losses or receive benefits from the entity that may be significant. The Company did not have a significant variable interest in any consolidated or nonconsolidated VIEs in its continuing operations for the presented reporting periods.

- added (2023-02-01):
[0000833444-23-000005:note_history:73]
Restricted Cash
Restricted cash relates to amounts restricted for payment of asbestos liabilities and certain litigation and environmental matters. Restricted cash is recorded within other current assets in the consolidated statements of financial position and totaled $67 million and $35 million at December 31, 2022 and September 30, 2022, respectively.

- removed (2023-02-01):
[0000833444-22-000036:note_history:74]
Restricted Cash

- removed (2023-02-01):
[0000833444-22-000036:note_history:75]
At June 30, 2022 and September 30, 2021, the Company held restricted cash of approximately $35 million and $6 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities and certain litigation and environmental matters.

- removed (2023-02-01):
[0000833444-22-000036:note_history:76]
Retrospective Changes

- removed (2023-02-01):
[0000833444-22-000036:note_history:77]
Effective October 1, 2021, the Company's marine businesses, which were previously included in the Building Solutions Asia Pacific and Global Products segments, became part of the Building Solutions EMEA/LA segment. Historical information has been re-cast to present the comparative periods on a consistent basis. This change was not material to the segment presentation. Refer to Note 8, "Goodwill and Other Intangible Assets," and Note 20, “Segment Information,” of the notes to the consolidated financial statements for further information.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-01):
[0000833444-23-000005:note_history:78]
Debt and Financing Arrangements
As of December 31, 2022, the Company had a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in November 2023. As of December 31, 2022, there were no draws on the facilities.
  (was, 2022-08-04, similarity 0.9548):
[0000833444-22-000036:note_history:78]
Debt and Financing Arrangements
As of June 30, 2022, the Company had a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2022. As of June 30, 2022, there were no draws on the facilities.

- added (2023-02-01):
[0000833444-23-000005:note_history:79]
In October 2022, the Company repaid a €200 million ($196 million as of September 30, 2022) term loan with an interest rate of EURIBOR plus 0.5% and entered into a €150 million ($161 million as of December 31, 2022) term loan with an interest rate of EURIBOR plus 0.7% which is due in April 2024.

- changed (2023-02-01):
[0000833444-23-000005:note_history:80]
The Company had $715 million and $172 million of commercial paper outstanding as of December 31, 2022 and September 30, 2022, respectively.
  (was, 2022-08-04, similarity 0.6877):
[0000833444-22-000036:note_history:80]
The Company had $1.6 billion of commercial paper outstanding as of June 30, 2022. No commercial paper was outstanding as of September 30, 2021.

- added (2023-02-01):
[0000833444-23-000005:note_history:81]
|  | Three Months Ended December 31, |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Interest expense, net of capitalized interest costs | $ | 69 |  |  | $ | 55 |  |  |  |  |  |
| Other financing charges | 10 |  |  | 5 |  |  |  |  |  |
| Interest income | (4) |  |  | (2) |  |  |  |  |  |
| Net foreign exchange results for financing activities | (8) |  |  | (5) |  |  |  |  |  |
| Net financing charges | $ | 67 |  |  | $ | 53 |  |  |  |  |  |

- removed (2023-02-01):
[0000833444-22-000036:note_history:82]
In March 2022, the Company entered into two bank term loans totaling €285 million ($297 million as of June 30, 2022) which are both due in March 2023. In November 2021, the Company entered into a €200 million ($208 million as of June 30, 2022) bank term loan which is due in October 2022.

- removed (2023-02-01):
[0000833444-22-000036:note_history:83]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Interest expense, net of capitalized interest costs | $ | 54 |  |  | $ | 55 |  |  | $ | 165 |  |  | $ | 167 |  |
| Other financing charges | 6 |  |  | 7 |  |  | 16 |  |  | 19 |  |
| Interest income | (2) |  |  | (1) |  |  | (5) |  |  | (7) |  |
| Net foreign exchange results for financing activities | (9) |  |  | (5) |  |  | (23) |  |  | (20) |  |
| Net financing charges | $ | 49 |  |  | $ | 56 |  |  | $ | 153 |  |  | $ | 159 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: no_current_note, score: 0.0

- removed (2023-02-01):
[0000833444-22-000036:note_history:84]
Related Party Transactions
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

- removed (2023-02-01):
[0000833444-22-000036:note_history:85]
The following table presents net sales to and purchases from related parties (in millions):

- removed (2023-02-01):
[0000833444-22-000036:note_history:86]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales to related parties |  | $ | 50 |  |  | $ | 46 |  |  | $ | 133 |  |  | $ | 143 |  |
| Purchases from related parties |  | 57 |  |  | 55 |  |  | 148 |  |  | 121 |  |

- removed (2023-02-01):
[0000833444-22-000036:note_history:87]
The following table presents receivables from and payables to related parties in the consolidated statements of financial position (in millions):

- removed (2023-02-01):
[0000833444-22-000036:note_history:88]
|  |  | June 30, 2022 |  | September 30, 2021 |
| Receivable from related parties |  | $ | 64 |  |  | $ | 73 |  |
| Payable to related parties |  | 34 |  |  | 45 |  |

- removed (2023-02-01):
[0000833444-22-000036:note_history:89]
Additionally, the Company leases certain facilities used in its operations from a related party. The following table presents right-of use assets and lease liabilities associated with these leases in the consolidated statements of financial position (in millions):

- removed (2023-02-01):
[0000833444-22-000036:note_history:90]
|  |  | June 30, 2022 |  | September 30, 2021 |
| Right-of-use assets |  | $ | 10 |  |  | $ | 11 |  |
| Lease liabilities |  | 9 |  |  | 10 |  |

- removed (2023-02-01):
[0000833444-22-000036:note_history:91]
Amounts paid for these leases were not material.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: no_current_note, score: 0.0

- removed (2023-02-01):
[0000833444-22-000036:note_history:92]
The following table presents net sales to and purchases from related parties (in millions):

- removed (2023-02-01):
[0000833444-22-000036:note_history:93]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales to related parties |  | $ | 50 |  |  | $ | 46 |  |  | $ | 133 |  |  | $ | 143 |  |
| Purchases from related parties |  | 57 |  |  | 55 |  |  | 148 |  |  | 121 |  |

- removed (2023-02-01):
[0000833444-22-000036:note_history:94]
The following table presents receivables from and payables to related parties in the consolidated statements of financial position (in millions):

- removed (2023-02-01):
[0000833444-22-000036:note_history:95]
|  |  | June 30, 2022 |  | September 30, 2021 |
| Receivable from related parties |  | $ | 64 |  |  | $ | 73 |  |
| Payable to related parties |  | 34 |  |  | 45 |  |

- removed (2023-02-01):
[0000833444-22-000036:note_history:96]
Additionally, the Company leases certain facilities used in its operations from a related party. The following table presents right-of use assets and lease liabilities associated with these leases in the consolidated statements of financial position (in millions):

- removed (2023-02-01):
[0000833444-22-000036:note_history:97]
|  |  | June 30, 2022 |  | September 30, 2021 |
| Right-of-use assets |  | $ | 10 |  |  | $ | 11 |  |
| Lease liabilities |  | 9 |  |  | 10 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-02-01):
[0000833444-23-000005:note_history:98]
|  |  | Three Months Ended December 31, |
|  |  | 2022 |  | 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,451 |  |  | $ | 916 |  |  | $ | 2,367 |  |  | $ | 1,299 |  |  | $ | 853 |  |  | $ | 2,152 |  |
| Building Solutions EMEA/LA |  | 552 |  |  | 423 |  |  | 975 |  |  | 544 |  |  | 415 |  |  | 959 |  |
| Building Solutions Asia Pacific |  | 473 |  |  | 173 |  |  | 646 |  |  | 501 |  |  | 174 |  |  | 675 |  |
| Global Products |  | 2,080 |  |  | — |  |  | 2,080 |  |  | 2,076 |  |  | — |  |  | 2,076 |  |
| Total |  | $ | 4,556 |  |  | $ | 1,512 |  |  | $ | 6,068 |  |  | $ | 4,420 |  |  | $ | 1,442 |  |  | $ | 5,862 |  |

- changed (2023-02-01):
[0000833444-23-000005:note_history:99]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| HVAC |  | $ | 1,440 |  |  | $ | 1,483 |  |  |  |  |  |
| Fire & Security |  | 570 |  |  | 544 |  |  |  |  |  |
| Industrial Refrigeration |  | 70 |  |  | 49 |  |  |  |  |  |
| Total |  | $ | 2,080 |  |  | $ | 2,076 |  |  |  |  |  |
  (was, 2022-08-04, similarity 0.7105):
[0000833444-22-000036:note_history:99]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| HVAC |  | $ | 1,889 |  |  | $ | 1,781 |  |  | $ | 5,030 |  |  | $ | 4,373 |  |
| Fire & Security |  | 610 |  |  | 580 |  |  | 1,732 |  |  | 1,605 |  |
| Industrial Refrigeration |  | 72 |  |  | 64 |  |  | 175 |  |  | 176 |  |
| Total |  | $ | 2,571 |  |  | $ | 2,425 |  |  | $ | 6,937 |  |  | $ | 6,154 |  |

- removed (2023-02-01):
[0000833444-22-000036:note_history:100]
|  |  | Three Months Ended June 30, |
|  |  | 2022 |  | 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,481 |  |  | $ | 945 |  |  | $ | 2,426 |  |  | $ | 1,355 |  |  | $ | 857 |  |  | $ | 2,212 |  |
| Building Solutions EMEA/LA |  | 537 |  |  | 415 |  |  | 952 |  |  | 507 |  |  | 494 |  |  | 1,001 |  |
| Building Solutions Asia Pacific |  | 493 |  |  | 172 |  |  | 665 |  |  | 413 |  |  | 290 |  |  | 703 |  |
| Global Products |  | 2,571 |  |  | — |  |  | 2,571 |  |  | 2,425 |  |  | — |  |  | 2,425 |  |
| Total |  | $ | 5,082 |  |  | $ | 1,532 |  |  | $ | 6,614 |  |  | $ | 4,700 |  |  | $ | 1,641 |  |  | $ | 6,341 |  |

- removed (2023-02-01):
[0000833444-22-000036:note_history:101]
|  |  | Nine Months Ended June 30, |
|  |  | 2022 |  | 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 4,123 |  |  | $ | 2,682 |  |  | $ | 6,805 |  |  | $ | 3,869 |  |  | $ | 2,469 |  |  | $ | 6,338 |  |
| Building Solutions EMEA/LA |  | 1,617 |  |  | 1,252 |  |  | 2,869 |  |  | 1,441 |  |  | 1,442 |  |  | 2,883 |  |
| Building Solutions Asia Pacific |  | 1,442 |  |  | 521 |  |  | 1,963 |  |  | 1,067 |  |  | 834 |  |  | 1,901 |  |
| Global Products |  | 6,937 |  |  | — |  |  | 6,937 |  |  | 6,154 |  |  | — |  |  | 6,154 |  |
| Total |  | $ | 14,119 |  |  | $ | 4,455 |  |  | $ | 18,574 |  |  | $ | 12,531 |  |  | $ | 4,745 |  |  | $ | 17,276 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2023-02-01):
[0000833444-23-000005:note_history:102]
Contract Balances

- added (2023-02-01):
[0000833444-23-000005:note_history:103]
Contract assets relate to the Company’s right to consideration for performance obligations satisfied but not billed and consist of unbilled receivables and costs in excess of billings. Contract liabilities relate to customer payments received in advance of satisfaction of performance obligations under the contract. Contract balances are classified as assets or liabilities on a contract-by-contract basis at the end of each reporting period.

- added (2023-02-01):
[0000833444-23-000005:note_history:104]
Performance Obligations

- added (2023-02-01):
[0000833444-23-000005:note_history:105]
A performance obligation is a distinct good, service, or a bundle of goods and services promised in a contract. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When contracts with customers require significant and complex integration, contain goods or services which are highly interdependent or interrelated, or are goods or services which significantly modify or customize other promises in the contracts and, therefore, are not distinct, then the entire contract is accounted for as a single performance obligation. For any contracts with multiple performance obligations, the contract’s transaction price is allocated to each performance obligation based on the estimated relative standalone selling price of each distinct good or service in the contract. For product sales, each product sold to a customer typically represents a distinct performance obligation.

- added (2023-02-01):
[0000833444-23-000005:note_history:106]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of December 31, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $18.4 billion, of which approximately 65% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

- added (2023-02-01):
[0000833444-23-000005:note_history:107]
Costs to Obtain or Fulfill a Contract

- added (2023-02-01):
[0000833444-23-000005:note_history:108]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when these costs are recoverable. These costs consist primarily of sales commissions and design costs that relate to a contract or an anticipated contract that we expect to recover. Costs to obtain or fulfill a contract are capitalized and amortized over the period of contract performance.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-02-01):
[0000833444-23-000005:note_history:109]
|  |  | Three Months Ended December 31, |
|  |  | 2022 |  | 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,451 |  |  | $ | 916 |  |  | $ | 2,367 |  |  | $ | 1,299 |  |  | $ | 853 |  |  | $ | 2,152 |  |
| Building Solutions EMEA/LA |  | 552 |  |  | 423 |  |  | 975 |  |  | 544 |  |  | 415 |  |  | 959 |  |
| Building Solutions Asia Pacific |  | 473 |  |  | 173 |  |  | 646 |  |  | 501 |  |  | 174 |  |  | 675 |  |
| Global Products |  | 2,080 |  |  | — |  |  | 2,080 |  |  | 2,076 |  |  | — |  |  | 2,076 |  |
| Total |  | $ | 4,556 |  |  | $ | 1,512 |  |  | $ | 6,068 |  |  | $ | 4,420 |  |  | $ | 1,442 |  |  | $ | 5,862 |  |

- changed (2023-02-01):
[0000833444-23-000005:note_history:110]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| HVAC |  | $ | 1,440 |  |  | $ | 1,483 |  |  |  |  |  |
| Fire & Security |  | 570 |  |  | 544 |  |  |  |  |  |
| Industrial Refrigeration |  | 70 |  |  | 49 |  |  |  |  |  |
| Total |  | $ | 2,080 |  |  | $ | 2,076 |  |  |  |  |  |
  (was, 2022-08-04, similarity 0.7105):
[0000833444-22-000036:note_history:110]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| HVAC |  | $ | 1,889 |  |  | $ | 1,781 |  |  | $ | 5,030 |  |  | $ | 4,373 |  |
| Fire & Security |  | 610 |  |  | 580 |  |  | 1,732 |  |  | 1,605 |  |
| Industrial Refrigeration |  | 72 |  |  | 64 |  |  | 175 |  |  | 176 |  |
| Total |  | $ | 2,571 |  |  | $ | 2,425 |  |  | $ | 6,937 |  |  | $ | 6,154 |  |

- added (2023-02-01):
[0000833444-23-000005:note_history:111]
|  |  | Location of contract balances |  | December 31, 2022 |  | September 30, 2022 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,019 |  |  | $ | 2,020 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 83 |  |  | 79 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,774) |  |  | (1,768) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (293) |  |  | (282) |  |  |  |

- changed (2023-02-01):
[0000833444-23-000005:note_history:112]
For the three months ended December 31, 2022 and 2021, the Company recognized revenue of $846 million and $751 million, respectively, that was included in the beginning of period contract liability balance.
  (was, 2022-08-04, similarity 0.648):
[0000833444-22-000036:note_history:112]
For the three months ended June 30, 2022 and 2021, the Company recognized revenue of $193 million and $149 million, respectively, that was included in the beginning of period contract liability balance. For the nine months ended June 30, 2022 and 2021, the Company recognized revenue of $1,252 million and $1,084 million, respectively, that was included in the beginning of period contract liability balance.

- changed (2023-02-01):
[0000833444-23-000005:note_history:113]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of December 31, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $18.4 billion, of which approximately 65% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.
  (was, 2022-08-04, similarity 0.9858):
[0000833444-22-000036:note_history:113]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of June 30, 2022, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $17.5 billion, of which approximately 65% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

- added (2023-02-01):
[0000833444-23-000005:note_history:114]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when these costs are recoverable. These costs consist primarily of sales commissions and design costs that relate to a contract or an anticipated contract that we expect to recover. Costs to obtain or fulfill a contract are capitalized and amortized over the period of contract performance.

- changed (2023-02-01):
[0000833444-23-000005:note_history:115]
|  |  | December 31, 2022 |  | September 30, 2022 |  |  |
| Other current assets |  | $ | 148 |  |  | $ | 139 |  |  |  |
| Other noncurrent assets |  | 191 |  |  | 174 |  |  |  |
| Total |  | $ | 339 |  |  | $ | 313 |  |  |  |
  (was, 2022-08-04, similarity 0.9721):
[0000833444-22-000036:note_history:115]
|  |  | June 30, 2022 |  | September 30, 2021 |  |  |
| Other current assets |  | $ | 169 |  |  | $ | 149 |  |  |  |
| Other noncurrent assets |  | 122 |  |  | 117 |  |  |  |
| Total |  | $ | 291 |  |  | $ | 266 |  |  |  |

- added (2023-02-01):
[0000833444-23-000005:note_history:116]
For the three months ended December 31, 2022 and 2021, the Company recognized amortization expense of  $61 million, and $50 million related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three months ended December 31, 2022 and 2021.

- removed (2023-02-01):
[0000833444-22-000036:note_history:117]
|  |  | Three Months Ended June 30, |
|  |  | 2022 |  | 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,481 |  |  | $ | 945 |  |  | $ | 2,426 |  |  | $ | 1,355 |  |  | $ | 857 |  |  | $ | 2,212 |  |
| Building Solutions EMEA/LA |  | 537 |  |  | 415 |  |  | 952 |  |  | 507 |  |  | 494 |  |  | 1,001 |  |
| Building Solutions Asia Pacific |  | 493 |  |  | 172 |  |  | 665 |  |  | 413 |  |  | 290 |  |  | 703 |  |
| Global Products |  | 2,571 |  |  | — |  |  | 2,571 |  |  | 2,425 |  |  | — |  |  | 2,425 |  |
| Total |  | $ | 5,082 |  |  | $ | 1,532 |  |  | $ | 6,614 |  |  | $ | 4,700 |  |  | $ | 1,641 |  |  | $ | 6,341 |  |

- removed (2023-02-01):
[0000833444-22-000036:note_history:118]
|  |  | Nine Months Ended June 30, |
|  |  | 2022 |  | 2021 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 4,123 |  |  | $ | 2,682 |  |  | $ | 6,805 |  |  | $ | 3,869 |  |  | $ | 2,469 |  |  | $ | 6,338 |  |
| Building Solutions EMEA/LA |  | 1,617 |  |  | 1,252 |  |  | 2,869 |  |  | 1,441 |  |  | 1,442 |  |  | 2,883 |  |
| Building Solutions Asia Pacific |  | 1,442 |  |  | 521 |  |  | 1,963 |  |  | 1,067 |  |  | 834 |  |  | 1,901 |  |
| Global Products |  | 6,937 |  |  | — |  |  | 6,937 |  |  | 6,154 |  |  | — |  |  | 6,154 |  |
| Total |  | $ | 14,119 |  |  | $ | 4,455 |  |  | $ | 18,574 |  |  | $ | 12,531 |  |  | $ | 4,745 |  |  | $ | 17,276 |  |

- removed (2023-02-01):
[0000833444-22-000036:note_history:119]
|  |  | Location of contract balances |  | June 30, 2022 |  | September 30, 2021 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,951 |  |  | $ | 1,718 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 104 |  |  | 99 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,846) |  |  | (1,637) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (278) |  |  | (269) |  |  |  |

- removed (2023-02-01):
[0000833444-22-000036:note_history:120]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when these costs are recoverable. These costs consist primarily of sales commissions and bid/proposal costs. Costs to obtain or fulfill a contract are capitalized and amortized to revenue over the period of contract performance.

- removed (2023-02-01):
[0000833444-22-000036:note_history:121]
During both the three months ended June 30, 2022 and 2021, the Company recognized amortization expense of $48 million, related to costs to obtain or fulfill a contract. During the nine months ended June 30, 2022 and 2021, the Company 
recognized amortization expense of $145 million and $136 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and nine months ended June 30, 2022 and 2021.
