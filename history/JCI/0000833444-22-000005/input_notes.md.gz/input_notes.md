# JCI notes — 0000833444-22-000005


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-22-000005:notes:1]
Basis of Presentation
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2021 filed with the SEC on November 15, 2021. The results of operations for the three-month period ended December 31, 2021 are not necessarily indicative of results for the Company’s 2022 fiscal year because of seasonal and other factors.

[0000833444-22-000005:notes:2]
[same as prior period, unchanged from 0000833444-21-000040:notes:2]

[0000833444-22-000005:notes:3]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, healthy and sustainable buildings, serving a wide range of customers in more than 150 countries. The Company’s products, services, systems and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-22-000005:notes:4]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including residential and commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management and repair of equipment (in the HVAC, industrial refrigeration, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions powered by its OpenBlue software platform and capabilities. The Company partners with customers by leveraging its broad product portfolio and digital capabilities powered by OpenBlue, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency and reduce greenhouse gas emissions.

[0000833444-22-000005:notes:5]
[same as prior period, unchanged from 0000833444-21-000040:notes:5]

[0000833444-22-000005:notes:6]
[same as prior period, unchanged from 0000833444-21-000040:notes:6]

[0000833444-22-000005:notes:7]
[same as prior period, unchanged from 0000833444-21-000040:notes:7]

[0000833444-22-000005:notes:8]
[same as prior period, unchanged from 0000833444-21-000040:notes:8]

[0000833444-22-000005:notes:9]
At December 31, 2021 and September 30, 2021, the Company held restricted cash of approximately $15 million and $6 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities and certain litigation and environmental matters.

[0000833444-22-000005:notes:10]
Retrospective Changes

[0000833444-22-000005:notes:11]
Effective October 1, 2021, the Company's marine businesses previously included in the Building Solutions Asia Pacific and Global Products segments are now part of the Building Solutions EMEA/LA segment. Historical information has been re-cast to present the comparative periods on a consistent basis. This change was not material to the segment presentation. Refer to Note 8, "Goodwill and Other Intangible Assets," and Note 20, “Segment Information,” of the notes to consolidated financial statements for further information.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000833444-22-000005:notes:12]
New Accounting Standards
Recently Adopted Accounting Pronouncements

[0000833444-22-000005:notes:13]
In October 2021, the FASB issued ASU No. 2021-08, “Business Combinations (Topic 805), Accounting for Contract Assets and Contract Liabilities from Contracts with Customers,” which requires contract assets and contract liabilities (e.g. deferred revenue) acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with ASC 606, “Revenue from Contracts with Customers.” Generally, this new guidance will result in the acquirer recognizing contract assets and contract liabilities at the same amounts recorded by the acquiree. Historically, such amounts were recognized by the acquirer at fair value in acquisition accounting. The guidance is applied prospectively to acquisitions occurring on or after the effective date. During the quarter ended December 31, 2021, the Company early adopted ASU No. 2021-08. The adoption of the new standard did not have a material impact on the Company's consolidated financial statements.

[0000833444-22-000005:notes:14]
Recently Issued Accounting Pronouncements

[0000833444-22-000005:notes:15]
Recently issued accounting pronouncements are not expected to have a material impact on the Company's consolidated financial statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-22-000005:notes:16]
Acquisitions and Divestitures
During the first quarter of fiscal 2022, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $142 million, of which $108 million was paid as of December 31, 2021. In connection with the acquisitions, the Company recorded goodwill of $45 million within the Building Solutions Asia Pacific segment, $20 million within the Building Solutions North America segment, $19 million within the Building Solutions EMEA/LA segment and $10 million within the Global Products segment.

[0000833444-22-000005:notes:17]
During the first quarter of fiscal 2022, the Company completed a divestiture within the Buildings Solutions EMEA/LA segment. The selling price, net of cash divested, was $18 million, of which $16 million was received as of December 31, 2021. In connection with the divestiture, the Company reduced goodwill by $5 million.

[0000833444-22-000005:notes:18]
During the first quarter of fiscal 2021, the Company completed certain divestitures within the Buildings Solutions Asia Pacific segment. The combined selling price was $15 million, of which $11 million was received as of December 31, 2020. In connection with the divestitures, the Company reduced goodwill by $4 million.

[0000833444-22-000005:notes:19]
Acquisitions and divestitures were not material to the Company's consolidated financial statements in the first quarter of fiscal 2022 or 2021.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-22-000005:notes:20]
Discontinued OperationsOn April 30, 2019, the Company completed the sale of its Power Solutions business. In December 2020, the favorable resolution of certain post-closing working capital and net debt adjustments resulted in income from discontinued operations, net of tax, of $124 million due to a reversal of a reserve established in connection with the sale.
The following table summarizes the results of Power Solutions which are classified as discontinued operations for the three months ended December 31, 2020 (in millions):

[0000833444-22-000005:notes:21]
|  |  |  | Three Months Ended December 31, 2020 |
| Net sales |  |  | $ | — |  |
| Income from discontinued operations before income taxes |  |  | 150 |  |
| Provision for income taxes on discontinued operations |  |  | (26) |  |
| Income from discontinued operations attributable to noncontrolling interests, net of tax |  |  | — |  |
| Income from discontinued operations |  |  | $ | 124 |  |

[0000833444-22-000005:notes:22]
There is no Power Solutions related activity for the three months ended December 31, 2021.

[0000833444-22-000005:notes:23]
Assets and Liabilities Held for Sale
During the third quarter of fiscal 2020, the Company determined that certain assets of the Building Solutions Asia Pacific segment met the criteria to be classified as held for sale. The estimated fair value, less costs to sell, of these assets was $159 million at December 31, 2021 and $156 million at September 30, 2021.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-22-000005:notes:24]
[same as prior period, unchanged from 0000833444-21-000040:notes:30]

[0000833444-22-000005:notes:25]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three months ended December 31, 2021 and 2020 (in millions):

[0000833444-22-000005:notes:26]
|  |  | Three Months Ended December 31, 2021 |  | Three Months Ended December 31, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,299 |  |  | $ | 853 |  |  | $ | 2,152 |  |  | $ | 1,242 |  |  | $ | 792 |  |  | $ | 2,034 |  |
| Building Solutions EMEA/LA |  | 544 |  |  | 415 |  |  | 959 |  |  | 468 |  |  | 480 |  |  | 948 |  |
| Building Solutions Asia Pacific |  | 501 |  |  | 174 |  |  | 675 |  |  | 334 |  |  | 270 |  |  | 604 |  |
| Global Products |  | 2,076 |  |  | — |  |  | 2,076 |  |  | 1,755 |  |  | — |  |  | 1,755 |  |
| Total |  | $ | 4,420 |  |  | $ | 1,442 |  |  | $ | 5,862 |  |  | $ | 3,799 |  |  | $ | 1,542 |  |  | $ | 5,341 |  |

[0000833444-22-000005:notes:27]
The following table presents further disaggregation of Global Products segment revenues by product type for the three months ended December 31, 2021 and 2020 (in millions):

[0000833444-22-000005:notes:28]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| HVAC |  | $ | 1,483 |  |  | $ | 1,218 |  |  |  |  |  |
| Fire & Security |  | 544 |  |  | 488 |  |  |  |  |  |
| Industrial Refrigeration |  | 49 |  |  | 49 |  |  |  |  |  |
| Total |  | $ | 2,076 |  |  | $ | 1,755 |  |  |  |  |  |

[0000833444-22-000005:notes:29]
[same as prior period, unchanged from 0000833444-21-000040:notes:36]

[0000833444-22-000005:notes:30]
Contract assets relate to the Company’s right to consideration for performance obligations satisfied but not billed and consist of unbilled receivables and costs in excess of billings. Contract liabilities relate to customer payments received in advance of satisfaction of performance obligations under the contract. Contract balances are classified as assets or liabilities on a contract-by-contract basis at the end of each reporting period.

[0000833444-22-000005:notes:31]
[same as prior period, unchanged from 0000833444-21-000040:notes:38]

[0000833444-22-000005:notes:32]
|  |  | Location of contract balances |  | December 31, 2021 |  | September 30, 2021 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,806 |  |  | $ | 1,718 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 98 |  |  | 99 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,845) |  |  | (1,637) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (287) |  |  | (269) |  |  |  |

[0000833444-22-000005:notes:33]
For the three months ended December 31, 2021 and December 31, 2020, the Company recognized revenue of $751 million and $714 million, respectively, that was included in the beginning of period contract liability balance.

[0000833444-22-000005:notes:34]
[same as prior period, unchanged from 0000833444-21-000040:notes:41]

[0000833444-22-000005:notes:35]
[same as prior period, unchanged from 0000833444-21-000040:notes:42]

[0000833444-22-000005:notes:36]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of December 31, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $16.5 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

[0000833444-22-000005:notes:37]
[same as prior period, unchanged from 0000833444-21-000040:notes:44]

[0000833444-22-000005:notes:38]
[same as prior period, unchanged from 0000833444-21-000040:notes:45]

[0000833444-22-000005:notes:39]
The following table presents the location and amount of costs to obtain or fulfill a contract recorded in the Company's consolidated statements of financial position (in millions):

[0000833444-22-000005:notes:40]
|  |  | December 31, 2021 |  | September 30, 2021 |  |  |
| Other current assets |  | $ | 149 |  |  | $ | 149 |  |  |  |
| Other noncurrent assets |  | 120 |  |  | 117 |  |  |  |
| Total |  | $ | 269 |  |  | $ | 266 |  |  |  |

[0000833444-22-000005:notes:41]
During the three months ended December 31, 2021 and 2020, the Company recognized amortization expense of $50 million and $41 million, respectively, related to costs to obtain or fulfill a contract.  There were no impairment losses recognized in the three months ended December 31, 2021 and 2020.


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0000833444-22-000005:notes:42]
Accounts Receivable, Net
Receivables consist of amounts billed and currently due from customers and unbilled costs and accrued profits related to revenues on long-term contracts that have been recognized for accounting purposes but not yet billed to customers. The Company extends credit to customers in the normal course of business and maintains an allowance for expected credit losses resulting from the inability or unwillingness of customers to make required payments. The allowance for expected credit losses is based on historical experience, existing economic conditions, reasonable and supportable forecasts, and any specific customer collection issues the Company has identified. The Company evaluates the reasonableness of the allowance for credit losses on a quarterly basis.

[0000833444-22-000005:notes:43]
The Company enters into various factoring agreements to sell certain accounts receivable to third-party financial institutions. For ease of administration, the Company collects customer payments related to the factored receivables on behalf of the financial institutions but otherwise maintains no continuing involvement with respect to the factored receivables. During the quarter ended December 31, 2021, the Company sold $134 million of accounts receivable under these factoring agreements, and the costs of factoring such receivables were not material. As of December, 31, 2021, the outstanding amount of account receivable sold under the factoring agreements was $135 million. No receivables were factored during the quarter ended December 31, 2020. Sales of accounts receivable are reflected as a reduction of accounts receivable in the consolidated statements of financial position and the proceeds are included in cash flows from operating activities in the consolidated statements of cash flows.

[0000833444-22-000005:notes:44]
[same as prior period, unchanged from 0000833444-21-000040:notes:49]

[0000833444-22-000005:notes:45]
|  |  | December 31, 2021 |  | September 30, 2021 |  |  |
| Accounts receivable |  | $ | 5,762 |  |  | $ | 5,723 |  |  |  |
| Less: Allowance for expected credit losses |  | (91) |  |  | (110) |  |  |  |
| Accounts receivable, net |  | $ | 5,671 |  |  | $ | 5,613 |  |  |  |

[0000833444-22-000005:notes:46]
The changes in the allowance for expected credit losses related to accounts receivable for the three months ended December 31, 2021 and 2020 were as follows (in millions):

[0000833444-22-000005:notes:47]
|  | Three Months Ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |
| Balance at beginning of period | $ | 110 |  |  | $ | 173 |  |  |  |
| Provision (benefit) for expected credit losses | (6) |  |  | 7 |  |  |  |
| Write-offs charged against the allowance for expected credit losses | (14) |  |  | (12) |  |  |  |
| Other | 1 |  |  | 5 |  |  |  |
| Balance at end of period | $ | 91 |  |  | $ | 173 |  |  |  |


## us-gaap:InventoryDisclosureTextBlock

[0000833444-22-000005:notes:48]
[same as prior period, unchanged from 0000833444-21-000040:notes:59]

[0000833444-22-000005:notes:49]
|  | December 31, 2021 |  | September 30, 2021 |
| Raw materials and supplies | $ | 967 |  |  | $ | 769 |  |
| Work-in-process | 195 |  |  | 166 |  |
| Finished goods | 1,263 |  |  | 1,122 |  |
| Inventories | $ | 2,425 |  |  | $ | 2,057 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-22-000005:notes:50]
Goodwill and Other Intangible Assets
Effective October 1, 2021, the Company's marine businesses previously included in the Building Solutions Asia Pacific and Global Products reportable segments are now part of the Building Solutions EMEA/LA reportable segment. Historical information has been re-cast to present the comparative periods on a consistent basis. This change was not material to the segment presentation or the allocation of goodwill.

[0000833444-22-000005:notes:51]
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the three-month period ended December 31, 2021 were as follows (in millions):

[0000833444-22-000005:notes:52]
|  |  |  | Business Acquisitions |  |  |  | Business Divestitures |  | Currency Translation and Other |  |  |
|  | September 30, |  |  |  |  |  | December 31, |
|  | 2021 |  |  |  |  |  | 2021 |
| Building Solutions North America | $ | 9,215 |  |  | $ | 20 |  |  |  |  | $ | — |  |  | $ | 1 |  |  | $ | 9,236 |  |
| Building Solutions EMEA/LA | 2,041 |  |  | 27 |  |  |  |  | (5) |  |  | (29) |  |  | 2,034 |  |
| Building Solutions Asia Pacific | 1,237 |  |  | 45 |  |  |  |  | — |  |  | 4 |  |  | 1,286 |  |
| Global Products | 5,842 |  |  | 10 |  |  |  |  | — |  |  | (22) |  |  | 5,830 |  |
| Total | $ | 18,335 |  |  | $ | 102 |  |  |  |  | $ | (5) |  |  | $ | (46) |  |  | $ | 18,386 |  |

[0000833444-22-000005:notes:53]
At September 30, 2021 and December 31, 2021, accumulated goodwill impairment charges totaled $471 million, of which $424 million related to the North America Retail reporting unit and $47 million related to the Building Solutions EMEA/LA - Building Solutions reporting unit.

[0000833444-22-000005:notes:54]
The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. There were no triggering events requiring that an impairment assessment be conducted in the three-month period ended December 31, 2021. However, it is possible that future changes in circumstances would require the Company to record additional non-cash impairment charges.

[0000833444-22-000005:notes:55]
[same as prior period, unchanged from 0000833444-21-000040:notes:65]

[0000833444-22-000005:notes:56]
|  | December 31, 2021 |  | September 30, 2021 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Definite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,505 |  |  | $ | (661) |  |  | $ | 844 |  |  | $ | 1,464 |  |  | $ | (629) |  |  | $ | 835 |  |
| Customer relationships | 3,105 |  |  | (1,244) |  |  | 1,861 |  |  | 3,097 |  |  | (1,191) |  |  | 1,906 |  |
| Miscellaneous | 772 |  |  | (377) |  |  | 395 |  |  | 750 |  |  | (354) |  |  | 396 |  |
|  | 5,382 |  |  | (2,282) |  |  | 3,100 |  |  | 5,311 |  |  | (2,174) |  |  | 3,137 |  |
| Indefinite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,325 |  |  | — |  |  | 2,325 |  |  | 2,332 |  |  | — |  |  | 2,332 |  |
| Miscellaneous | 80 |  |  | — |  |  | 80 |  |  | 80 |  |  | — |  |  | 80 |  |
|  | 2,405 |  |  | — |  |  | 2,405 |  |  | 2,412 |  |  | — |  |  | 2,412 |  |
| Total intangible assets | $ | 7,787 |  |  | $ | (2,282) |  |  | $ | 5,505 |  |  | $ | 7,723 |  |  | $ | (2,174) |  |  | $ | 5,549 |  |

[0000833444-22-000005:notes:57]
Amortization of other intangible assets included within continuing operations for the three-month periods ended December 31, 2021 and 2020 was $118 million and $104 million, respectively.

[0000833444-22-000005:notes:58]
The Company reviews indefinite-lived intangible assets for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. There were no triggering events requiring that an impairment assessment be conducted in the three-month period ended December 31, 2021. However, it is possible that future changes in circumstances would require the Company to record additional non-cash impairment charges.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000833444-22-000005:notes:59]
Leases
The following table presents supplemental consolidated statement of financial position information as of December 31, 2021 and September 30, 2021 (in millions):

[0000833444-22-000005:notes:60]
|  | Location of lease balances |  | December 31, 2021 |  | September 30, 2021 |
| Operating lease right-of-use assets | Other noncurrent assets |  | $ | 1,341 |  |  | $ | 1,376 |  |
| Operating lease liabilities - current | Other current liabilities |  | 314 |  |  | 319 |  |
| Operating lease liabilities - noncurrent | Other noncurrent liabilities |  | 1,022 |  |  | 1,055 |  |

[0000833444-22-000005:notes:61]
The following table presents supplemental noncash operating lease activity, excluding leases acquired in business combinations, for the three months ended December 31, 2021 and 2020 (in millions):

[0000833444-22-000005:notes:62]
|  |  |  |  | Three Months Ended December 31, |  |  |
|  |  |  |  |  |  | 2021 |  | 2020 |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  |  |  |  |  | $ | 55 |  |  | $ | 175 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-22-000005:notes:63]
Debt and Financing ArrangementsAs of December 31, 2021, the Company has a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which was renewed in December 2021 and is now scheduled to expire in December 2022. As of December 31, 2021, there were no draws on the facilities.
In November 2021, the Company entered into a €200 million bank term loan which is due in October 2022.

[0000833444-22-000005:notes:64]
The Company had $150 million of commercial paper outstanding as of December 31, 2021 and no commercial paper outstanding as of September 30, 2021.

[0000833444-22-000005:notes:65]
Net Financing Charges

[0000833444-22-000005:notes:66]
Net financing charges consisted of the following (in millions):

[0000833444-22-000005:notes:67]
|  | Three Months Ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Interest expense, net of capitalized interest costs | $ | 55 |  |  | $ | 59 |  |  |  |  |  |
| Banking fees and bond cost amortization | 5 |  |  | 8 |  |  |  |  |  |
| Interest income | (2) |  |  | (3) |  |  |  |  |  |
| Net foreign exchange results for financing activities | (5) |  |  | (5) |  |  |  |  |  |
| Net financing charges | $ | 53 |  |  | $ | 59 |  |  |  |  |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-22-000005:notes:68]
Derivative Instruments and Hedging Activities
The Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities, stock-based compensation liabilities and interest rates. Under Company policy, the use of derivatives is restricted to those intended for hedging purposes; the use of any derivative instrument for speculative purposes is strictly prohibited. A description of each type of derivative utilized by the Company to manage risk is included in the following paragraphs. In addition, refer to Note 12, "Fair Value Measurements," of the notes to consolidated financial statements for information related to the fair value measurements and valuation methods utilized by the Company for each derivative type.

[0000833444-22-000005:notes:69]
[same as prior period, unchanged from 0000833444-21-000040:notes:148]

[0000833444-22-000005:notes:70]
The Company has global operations and participates in foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange forward contracts. The Company hedges 70% to 90% of the notional amount of each of its known foreign exchange transactional exposures.

[0000833444-22-000005:notes:71]
[same as prior period, unchanged from 0000833444-21-000040:notes:150]

[0000833444-22-000005:notes:72]
As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of accumulated other comprehensive income (loss) ("AOCI") and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the three months ended December 31, 2021 and 2020.

[0000833444-22-000005:notes:73]
[same as prior period, unchanged from 0000833444-21-000040:notes:152]

[0000833444-22-000005:notes:74]
|  |  | Volume Outstanding as of |
| Commodity |  | December 31, 2021 |  | September 30, 2021 |
| Copper |  | 3,314 |  |  | 2,656 |  |
| Aluminum |  | 7,193 |  |  | 5,159 |  |

[0000833444-22-000005:notes:75]
In April 2021, the Company entered into two forward-starting interest rate swaps with a combined notional amount of $500 million, in conjunction with its anticipated $500 million note issuance. In September 2021, the Company terminated the swaps as the debt was issued. Accumulated amounts recorded in AOCI as of the date of the debt issuance are amortized to interest expense over the life of the related note to reflect the difference between the swap's reference rate and the fixed rate of the note.

[0000833444-22-000005:notes:76]
[same as prior period, unchanged from 0000833444-21-000040:notes:155]

[0000833444-22-000005:notes:77]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in AOCI attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company's net investments globally. The Company had 2.3 billion of euro-denominated bonds designated as net investment hedges of a portion of its net investment in European subsidiaries and 25 billion of yen-denominated debt designated as a net investment hedge of a portion of its net investment in Japanese subsidiaries as of December 31, 2021 and September 30, 2021.

[0000833444-22-000005:notes:78]
[same as prior period, unchanged from 0000833444-21-000040:notes:157]

[0000833444-22-000005:notes:79]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount. The Company hedged approximately 0.3 million of its ordinary shares, which have a cost basis of $23 million, as of December 31, 2021 and September 30, 2021.

[0000833444-22-000005:notes:80]
The Company also holds certain foreign currency forward contracts not designated as hedging instruments under ASC 815 to hedge foreign currency exposure resulting from monetary assets and liabilities denominated in nonfunctional currencies.  The changes in fair value of these foreign currency forward exchange derivatives are recorded in the consolidated statements of income where they offset foreign currency transactional gains and losses on the nonfunctional currency denominated assets and liabilities being hedged.

[0000833444-22-000005:notes:81]
[same as prior period, unchanged from 0000833444-21-000040:notes:160]

[0000833444-22-000005:notes:82]
[same as prior period, unchanged from 0000833444-21-000040:notes:161]

[0000833444-22-000005:notes:83]
|  | Derivatives and Hedging Activities Designatedas Hedging Instruments under ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instruments under ASC 815 |
|  | December 31, |  | September 30, |  | December 31, |  | September 30, |
|  | 2021 |  | 2021 |  | 2021 |  | 2021 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 27 |  |  | $ | 15 |  |  | $ | 17 |  |  | $ | 17 |  |
| Commodity derivatives | 3 |  |  | 2 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Equity swap | — |  |  | — |  |  | 28 |  |  | 23 |  |
| Total assets | $ | 30 |  |  | $ | 17 |  |  | $ | 45 |  |  | $ | 40 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 12 |  |  | $ | 11 |  |  | $ | 13 |  |  | $ | 6 |  |
| Commodity derivatives | 1 |  |  | 1 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 2,845 |  |  | 2,918 |  |  | — |  |  | — |  |
| Total liabilities | $ | 2,858 |  |  | $ | 2,930 |  |  | $ | 13 |  |  | $ | 6 |  |

[0000833444-22-000005:notes:84]
[same as prior period, unchanged from 0000833444-21-000040:notes:163]

[0000833444-22-000005:notes:85]
[same as prior period, unchanged from 0000833444-21-000040:notes:164]

[0000833444-22-000005:notes:86]
The Company's derivative contracts do not contain any credit risk related contingent features and do not require collateral or other security to be furnished by the Company or the counterparties. The Company's exposure to credit risk associated with its derivative instruments is measured on an individual counterparty basis, as well as by groups of counterparties that share similar attributes. The Company does not anticipate any non-performance by any of its counterparties, and the concentration of risk with financial institutions does not present significant credit risk to the Company.

[0000833444-22-000005:notes:87]
[same as prior period, unchanged from 0000833444-21-000040:notes:167]

[0000833444-22-000005:notes:88]
|  |  | Fair Value of Assets |  |  |  | Fair Value of Liabilities |  |  |
|  |  | December 31, |  | September 30, |  |  |  | December 31, |  | September 30, |  |  |
|  |  | 2021 |  | 2021 |  |  |  | 2021 |  | 2021 |  |  |
| Gross amount recognized |  | $ | 75 |  |  | $ | 57 |  |  |  |  | $ | 2,871 |  |  | $ | 2,936 |  |  |  |
| Gross amount eligible for offsetting |  | (17) |  |  | (16) |  |  |  |  | (17) |  |  | (16) |  |  |  |
| Net amount |  | $ | 58 |  |  | $ | 41 |  |  |  |  | $ | 2,854 |  |  | $ | 2,920 |  |  |  |

[0000833444-22-000005:notes:89]
[same as prior period, unchanged from 0000833444-21-000040:notes:169]

[0000833444-22-000005:notes:90]
The following table presents the pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges for the three months ended December 31, 2021 and 2020 (in millions):

[0000833444-22-000005:notes:91]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Three Months Ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Foreign currency exchange derivatives |  | $ | 13 |  |  | $ | 3 |  |  |  |  |  |
| Commodity derivatives |  | (2) |  |  | 1 |  |  |  |  |  |
| Total |  | $ | 11 |  |  | $ | 4 |  |  |  |  |  |

[0000833444-22-000005:notes:92]
The following table presents the location and amount of the pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income for the three months ended December 31, 2021 and 2020 (in millions):

[0000833444-22-000005:notes:93]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Location of Gain (Loss) Reclassified from AOCI into Income |  | Three Months Ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 5 |  |  | $ | 2 |  |  |  |  |  |
| Commodity derivatives |  | Cost of sales |  | (4) |  |  | (1) |  |  |  |  |  |
| Interest rate swaps |  | Net financing charges |  | (1) |  |  | — |  |  |  |  |  |
| Total |  |  |  | $ | — |  |  | $ | 1 |  |  |  |  |  |

[0000833444-22-000005:notes:94]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income for the three months ended December 31, 2021 and 2020 (in millions):

[0000833444-22-000005:notes:95]
|  |  |  |  | Amount of Gain (Loss) Recognized inIncome on Derivative |
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months Ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 10 |  |  | $ | 6 |  |  |  |  |  |
| Foreign currency exchange derivatives |  | Selling, general and administrative |  | — |  |  | (2) |  |  |  |  |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | 87 |  |  | (41) |  |  |  |  |  |
| Equity swap |  | Selling, general and administrative |  | 5 |  |  | 6 |  |  |  |  |  |
| Total |  |  |  | $ | 102 |  |  | $ | (31) |  |  |  |  |  |

[0000833444-22-000005:notes:96]
Pre-tax gains (losses) on net investment hedges recorded as foreign currency translation adjustments ("CTA") within other comprehensive income (loss) were $73 million and $(135) million for the three months ended December 31, 2021 and 2020, respectively. For the three months ended December 31, 2021 and 2020, no gains or losses were reclassified from CTA into income.


## us-gaap:DerivativesPolicyTextBlock

[0000833444-22-000005:notes:97]
As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of accumulated other comprehensive income (loss) ("AOCI") and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings.The currency effects of the debt obligations are reflected in AOCI attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company's net investments globally.The Company also holds certain foreign currency forward contracts not designated as hedging instruments under ASC 815 to hedge foreign currency exposure resulting from monetary assets and liabilities denominated in nonfunctional currencies.  The changes in fair value of these foreign currency forward exchange derivatives are recorded in the consolidated statements of income where they offset foreign currency transactional gains and losses on the nonfunctional currency denominated assets and liabilities being hedged.The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-22-000005:notes:98]
[same as prior period, unchanged from 0000833444-21-000040:notes:178]

[0000833444-22-000005:notes:99]
[same as prior period, unchanged from 0000833444-21-000040:notes:179]

[0000833444-22-000005:notes:100]
[same as prior period, unchanged from 0000833444-21-000040:notes:180]

[0000833444-22-000005:notes:101]
[same as prior period, unchanged from 0000833444-21-000040:notes:181]

[0000833444-22-000005:notes:102]
[same as prior period, unchanged from 0000833444-21-000040:notes:182]

[0000833444-22-000005:notes:103]
[same as prior period, unchanged from 0000833444-21-000040:notes:183]

[0000833444-22-000005:notes:104]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value as of December 31, 2021 and September 30, 2021 (in millions):

[0000833444-22-000005:notes:105]
|  | Fair Value Measurements Using: |
|  | Total as of December 31, 2021 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 44 |  |  | $ | — |  |  | $ | 44 |  |  | $ | — |  |
| Commodity derivatives | 3 |  |  | — |  |  | 3 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 67 |  |  | 67 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 140 |  |  | 140 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 183 |  |  | 183 |  |  | — |  |  | — |  |
| Equity swap | 28 |  |  | — |  |  | 28 |  |  | — |  |
| Total assets | $ | 465 |  |  | $ | 390 |  |  | $ | 75 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 25 |  |  | $ | — |  |  | $ | 25 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Contingent earn-out liabilities | 48 |  |  | — |  |  | — |  |  | 48 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 55 |  |  | — |  |  | — |  |  | 55 |  |
| Total liabilities | $ | 129 |  |  | $ | — |  |  | $ | 26 |  |  | $ | 103 |  |

[0000833444-22-000005:notes:106]
The increases in the contingent earn-out liabilities during the three-month period ended December 31, 2021 were due to acquisitions.

[0000833444-22-000005:notes:107]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2021 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 32 |  |  | $ | — |  |  | $ | 32 |  |  | $ | — |  |
| Commodity derivatives | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 63 |  |  | 63 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 146 |  |  | 146 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 168 |  |  | 168 |  |  | — |  |  | — |  |
| Equity swap | 23 |  |  | — |  |  | 23 |  |  | — |  |
| Total assets | $ | 434 |  |  | $ | 377 |  |  | $ | 57 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 17 |  |  | $ | — |  |  | $ | 17 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Contingent earn-out liabilities | 32 |  |  | — |  |  | — |  |  | $ | 32 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 50 |  |  | — |  |  | — |  |  | 50 |  |
| Total liabilities | $ | 100 |  |  | $ | — |  |  | $ | 18 |  |  | $ | 82 |  |

[0000833444-22-000005:notes:108]
1 Classified as restricted investments for payment of asbestos liabilities. See Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements for further details.

[0000833444-22-000005:notes:109]
[same as prior period, unchanged from 0000833444-21-000040:notes:188]

[0000833444-22-000005:notes:110]
[same as prior period, unchanged from 0000833444-21-000040:notes:189]

[0000833444-22-000005:notes:111]
[same as prior period, unchanged from 0000833444-21-000040:notes:190]

[0000833444-22-000005:notes:112]
[same as prior period, unchanged from 0000833444-21-000040:notes:191]

[0000833444-22-000005:notes:113]
[same as prior period, unchanged from 0000833444-21-000040:notes:192]

[0000833444-22-000005:notes:114]
Investments in exchange traded funds:  Investments in exchange traded funds are valued using a market approach based on  quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments.  Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements for further information.

[0000833444-22-000005:notes:115]
Contingent earn-out liabilities:  The contingent earn-out liabilities, which are primarily related to the Silent-Aire acquisition, were established using a Monte Carlo simulation based on the forecasted operating results and the earn-out formula specified in the purchase agreement.

[0000833444-22-000005:notes:116]
The following table presents the portion of unrealized gains recognized in the consolidated statements of income for the three months ended December 31, 2021 and 2020 that relate to equity securities still held at December 31, 2021 and 2020 (in millions):

[0000833444-22-000005:notes:117]
|  |  | Three Months Ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Deferred compensation plan assets |  | $ | 3 |  |  | $ | 5 |  |  |  |  |  |
| Investments in exchange traded funds |  | 14 |  |  | 21 |  |  |  |  |  |

[0000833444-22-000005:notes:118]
All of the gains on investments in exchange traded funds related to restricted investments. 
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. At December 31, 2021, the fair value of long-term debt was $8.4 billion, including public debt of $8.2 billion and other long-term debt of $0.2 billion. At September 30, 2021, the fair value of long-term debt was $8.5 billion, including public debt of $8.3 billion and other long-term debt of $0.2 billion. The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy.  The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000833444-22-000005:notes:119]
[same as prior period, unchanged from 0000833444-21-000040:notes:198]

[0000833444-22-000005:notes:120]
Investments in exchange traded funds:  Investments in exchange traded funds are valued using a market approach based on  quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments.  Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements for further information.
Contingent earn-out liabilities:  The contingent earn-out liabilities, which are primarily related to the Silent-Aire acquisition, were established using a Monte Carlo simulation based on the forecasted operating results and the earn-out formula specified in the purchase agreement.The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy.  The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-22-000005:notes:121]
Stock-Based Compensation
On March 10, 2021, the shareholders of the Company approved the Johnson Controls International plc 2021 Equity and Incentive Plan, which terminated the 2012 Share and Incentive Plan, as amended in September 2016 (collectively, the "Plans"). Both Plans authorize stock options, stock appreciation rights, restricted (non-vested) stock/units, performance shares, performance units and other stock-based awards. The Compensation and Talent Development Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. Awards are typically granted annually in the Company’s fiscal first quarter.

[0000833444-22-000005:notes:122]
A summary of the stock-based awards granted during the three-month periods ended December 31, 2021 and 2020 is presented below:

[0000833444-22-000005:notes:123]
|  | Three Months Ended December 31, |  |  |
|  | 2021 |  |  |  | 2020 |  |  |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |
| Stock options | 548,398 |  |  | $ | 18.59 |  |  |  |  | 932,678 |  |  | $ | 9.36 |  |  |  |
| Stock appreciation rights | 19,768 |  |  | 18.59 |  |  |  |  | 35,254 |  |  | 9.36 |  |  |  |
| Restricted stock/units | 1,170,634 |  |  | 79.54 |  |  |  |  | 1,599,552 |  |  | 45.61 |  |  |  |
| Performance shares | 438,476 |  |  | 84.27 |  |  |  |  | 410,934 |  |  | 50.53 |  |  |  |

[0000833444-22-000005:notes:124]
[same as prior period, unchanged from 0000833444-21-000040:notes:119]

[0000833444-22-000005:notes:125]
[same as prior period, unchanged from 0000833444-21-000040:notes:120]

[0000833444-22-000005:notes:126]
[same as prior period, unchanged from 0000833444-21-000040:notes:121]

[0000833444-22-000005:notes:127]
|  | Three Months Ended December 31, |
|  | 2021 |  | 2020 |
| Expected life of option (years) | 6.0 |  | 6.5 |
| Risk-free interest rate | 1.35% |  | 0.6% |
| Expected volatility of the Company’s stock | 27.8% |  | 27.6% |
| Expected dividend yield on the Company’s stock | 1.71% |  | 2.28% |

[0000833444-22-000005:notes:128]
[same as prior period, unchanged from 0000833444-21-000040:notes:123]

[0000833444-22-000005:notes:129]
SARs vest under the same terms and conditions as stock option awards; however, they are settled in cash for the difference between the market price on the date of the exercise and the exercise price. As a result, SARs are recorded in the Company's consolidated financial statements of financial position as a liability until the date of exercise. The fair value of each SAR award is estimated using a similar method and assumptions as described for stock options. The fair value of each SAR award is recalculated at the end of each reporting period and the liability and expense are adjusted based on the new fair value.

[0000833444-22-000005:notes:130]
[same as prior period, unchanged from 0000833444-21-000040:notes:126]

[0000833444-22-000005:notes:131]
Restricted stock or restricted stock units are typically share settled unless the employee is a non-U.S. employee, in which case the awards are settled in cash. Restricted awards typically vest over a period of three years from the grant date. The Plans allow for different vesting terms on specific grants with approval by the Compensation and Talent Development Committee. The fair value of each share-settled restricted award is based on the closing market value of the Company’s ordinary shares on the date of grant. The fair value of each cash-settled restricted award is recalculated at the end of each reporting period based on the closing market value of the Company's ordinary shares at the end of the reporting period, and the liability and expense are adjusted based on the new fair value.

[0000833444-22-000005:notes:132]
[same as prior period, unchanged from 0000833444-21-000040:notes:128]

[0000833444-22-000005:notes:133]
Performance-based share unit ("PSU") awards are generally contingent on the achievement of predetermined performance goals over a performance period of one to three years as well as on the award holder's continuous employment until the vesting date. The majority of PSUs are also indexed to the achievement of specified levels of total shareholder return versus a peer group over the performance period. Each PSU that is earned is settled with shares of the Company's ordinary shares following the completion of the performance period, unless the employee is a non-U.S. employee, in which case the awards are settled in cash.

[0000833444-22-000005:notes:134]
The fair value of the portion of PSUs linked to the achievement of performance goals is based on the closing market value of the Company's ordinary shares on the date of grant. Share-based compensation expense for these PSUs is recognized over the performance period based on the probability of achieving the performance targets.

[0000833444-22-000005:notes:135]
The fair value of the portion of PSUs indexed to total shareholder return is estimated on the date of grant using a Monte Carlo simulation that uses the assumptions noted in the following table. The risk-free interest rate for periods during the contractual life of the PSU is based on the U.S. Treasury yield curve in effect at the time of grant. The expected volatility is based on the historical volatility of the Company's stock over the most recent three-year period as of the grant date. Share-based compensation expense for these PSUs is not adjusted based upon performance subsequent to the grant date as the likelihood of achieving the market condition is incorporated in the grant date fair value of the award.

[0000833444-22-000005:notes:136]
|  | Three Months Ended December 31, |
|  | 2021 |  | 2020 |
| Risk-free interest rate | 0.99% |  | 0.20% |
| Expected volatility of the Company’s stock | 30.0% |  | 30.9% |


## us-gaap:EarningsPerShareTextBlock

[0000833444-22-000005:notes:137]
Earnings Per Share
The Company presents both basic and diluted earnings per share ("EPS") amounts. Basic EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares outstanding during the reporting period. Diluted EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares and ordinary equivalent shares outstanding during the reporting period that are calculated using the treasury stock method for stock options, unvested restricted stock and unvested performance share awards. The treasury stock method assumes that the Company uses the proceeds from the exercise of stock option awards to repurchase ordinary shares at the average market price during the period. The assumed proceeds under the treasury stock method include the purchase price that the grantee will pay in the future and compensation cost for future service that the Company has not yet recognized. For unvested restricted stock and unvested performance share awards, assumed proceeds under the treasury stock method include unamortized compensation cost.

[0000833444-22-000005:notes:138]
The following table reconciles the numerators and denominators used to calculate basic and diluted earnings per share (in millions):

[0000833444-22-000005:notes:139]
|  | Three Months Ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Income Available to Ordinary Shareholders |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 381 |  |  | $ | 327 |  |  |  |  |  |
| Income from discontinued operations | — |  |  | 124 |  |  |  |  |  |
| Basic and diluted income available to shareholders | $ | 381 |  |  | $ | 451 |  |  |  |  |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 704.3 |  |  | 723.1 |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 5.2 |  |  | 3.4 |  |  |  |  |  |
| Diluted weighted average shares outstanding | 709.5 |  |  | 726.5 |  |  |  |  |  |
| Antidilutive Securities |  |  |  |  |  |  |  |
| Options to purchase shares | — |  |  | 0.2 |  |  |  |  |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-22-000005:notes:140]
Equity 
Share repurchase program

[0000833444-22-000005:notes:141]
For the three months ended December 31, 2021 and 2020, the Company repurchased and immediately retired $526 million and $346 million of its ordinary shares, respectively. In March 2021, the Company's Board of Directors approved a $4 billion increase to the Company's share repurchase authorization, adding to the $2 billion remaining as of December 31, 2020 under the prior share repurchase authorization approved in 2019. As of December 31, 2021, approximately $4.5 billion remains available under the Company's share repurchase authorization.

[0000833444-22-000005:notes:142]
Accumulated Other Comprehensive Income (Loss)

[0000833444-22-000005:notes:143]
The following schedules present changes in AOCI attributable to Johnson Controls (in millions, net of tax):

[0000833444-22-000005:notes:144]
|  | Three Months Ended December 31, |
|  | 2021 |  | 2020 |
| Foreign currency translation adjustments |  |  |  |
| Balance at beginning of period | $ | (421) |  |  | $ | (778) |  |
| Aggregate adjustment for the period (net of tax effect of $0 and $0) | 84 |  |  | 272 |  |
| Balance at end of period | (337) |  |  | (506) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | (17) |  |  | 2 |  |
| Current period changes in fair value (net of tax effect of $3 and $2) | 4 |  |  | 2 |  |
| Reclassification to income (net of tax effect of $0 and $0) * | — |  |  | (1) |  |
| Balance at end of period | (13) |  |  | 3 |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | 4 |  |  | — |  |
| Reclassification to income (net of tax effect of $0 and $0) | (1) |  |  | (1) |  |
| Balance at end of period | 3 |  |  | (1) |  |
| Accumulated other comprehensive loss, end of period | $ | (347) |  |  | $ | (504) |  |

[0000833444-22-000005:notes:145]
* Refer to Note 11, "Derivative Instruments and Hedging Activities," of the notes to consolidated financial statements for

[0000833444-22-000005:notes:146]
[same as prior period, unchanged from 0000833444-21-000040:notes:145]

[0000833444-22-000005:notes:147]
[same as prior period, unchanged from 0000833444-21-000040:notes:146]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-22-000005:notes:148]
[same as prior period, unchanged from 0000833444-21-000040:notes:103]

[0000833444-22-000005:notes:149]
|  | U.S. Pension Plans |
|  | Three Months Ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Interest cost | $ | 10 |  |  | $ | 11 |  |  |  |  |  |
| Expected return on plan assets | (41) |  |  | (42) |  |  |  |  |  |
| Net actuarial gain | (42) |  |  | — |  |  |  |  |  |
| Settlement gain | (1) |  |  | — |  |  |  |  |  |
| Net periodic benefit credit | $ | (74) |  |  | $ | (31) |  |  |  |  |  |

[0000833444-22-000005:notes:150]
|  | Non-U.S. Pension Plans |
|  | Three Months Ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Service cost | $ | 6 |  |  | $ | 7 |  |  |  |  |  |
| Interest cost | 10 |  |  | 8 |  |  |  |  |  |
| Expected return on plan assets | (21) |  |  | (28) |  |  |  |  |  |
| Net periodic benefit credit | $ | (5) |  |  | $ | (13) |  |  |  |  |  |

[0000833444-22-000005:notes:151]
|  | Postretirement Benefits |
|  | Three Months Ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Interest cost | $ | — |  |  | $ | 1 |  |  |  |  |  |
| Expected return on plan assets | (2) |  |  | (2) |  |  |  |  |  |
| Amortization of prior service credit | (1) |  |  | (1) |  |  |  |  |  |
| Net periodic benefit credit | $ | (3) |  |  | $ | (2) |  |  |  |  |  |

[0000833444-22-000005:notes:152]
During the three months ended December 31, 2021, the amount of cumulative fiscal 2022 lump sum payouts triggered a remeasurement event for certain U.S. pension plans resulting in the recognition of net actuarial gains of $42 million, primarily due to favorable plan asset performance.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-22-000005:notes:153]
Significant Restructuring and Impairment Costs
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company commits to various restructuring plans as necessary. Restructuring plans generally result in charges for workforce reductions, plant closures, asset impairments and other related costs which are reported as restructuring and impairment costs in the Company’s consolidated statements of income. The other related costs consist primarily of consulting costs incurred as a direct result of the restructuring initiatives. The Company expects the restructuring actions to reduce cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense.

[0000833444-22-000005:notes:154]
In fiscal 2021, the Company committed to a significant multi-year restructuring plan ("2021 Plan") which is expected to be completed during fiscal 2023. During the three months ended December 31, 2021, the Company recorded $49 million of restructuring and impairment costs in the consolidated statements of income. The total amount expected to be incurred for this restructuring plan is $385 million across all segments and at Corporate. Of the restructuring and impairment costs recorded in the three months ended December 31, 2021, $24 million related to the Global Products segment, $9 million related to the Building Solutions North America segment, $8 million related to the Building Solutions Asia Pacific segment, $5 million related to the Building Solutions EMEA/LA segment and $3 million related to Corporate. In total, the Company has recorded $291 million of restructuring and impairment costs  related to the 2021 Plan, including $115 million related to the Global Products segment, $79 million related to the Building Solutions North America segment, $36 million related to the Building Solutions Asia Pacific segment, $34 million related to the Building Solutions EMEA/LA segment and $27 million related to Corporate.

[0000833444-22-000005:notes:155]
[same as prior period, unchanged from 0000833444-21-000040:notes:71]

[0000833444-22-000005:notes:156]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  |  |  | Total |
| Original reserve | $ | 68 |  |  | $ | 98 |  |  | $ | 76 |  |  |  |  | $ | 242 |  |
| Utilized—cash | (28) |  |  | — |  |  | (51) |  |  |  |  | (79) |  |
| Utilized—noncash | — |  |  | (98) |  |  | — |  |  |  |  | (98) |  |
| Balance at September 30, 2021 | 40 |  |  | — |  |  | 25 |  |  |  |  | 65 |  |
| Additional restructuring costs | 28 |  |  | — |  |  | 21 |  |  |  |  | 49 |  |
| Utilized—cash | (13) |  |  | — |  |  | (7) |  |  |  |  | (20) |  |
| Currency translation | (1) |  |  | — |  |  | — |  |  |  |  | (1) |  |
| Balance at December 31, 2021 | $ | 54 |  |  | $ | — |  |  | $ | 39 |  |  |  |  | $ | 93 |  |

[0000833444-22-000005:notes:157]
The 2021 Plan included workforce reductions of approximately 4,000 employees. Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of December 31, 2021, approximately 1,800 of the employees have been separated from the Company pursuant to the 2021 Plan.
Company management closely monitors its overall cost structure and continually analyzes each of its businesses for opportunities to consolidate current operations, improve operating efficiencies and locate facilities in close proximity to customers. This ongoing analysis includes a review of its manufacturing, engineering and purchasing operations, as well as the overall global footprint for all its businesses.


## us-gaap:AssetImpairmentChargesTextBlock

[0000833444-22-000005:notes:158]
Impairment of Long-Lived AssetsThe Company reviews long-lived assets, including right-of-use assets under operating leases, other tangible assets and intangible assets with definitive lives, for impairment whenever events or changes in circumstances indicate that the asset’s 
carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of Software to be Sold, Leased, or Marketed."

[0000833444-22-000005:notes:159]
The Company groups assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluates the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on a discounted cash flow analysis or appraisals. Intangible assets acquired in a business combination that are used in research and development activities are considered indefinite-lived until the completion or abandonment of the associated research and development efforts. During the period that those assets are considered indefinite lived, they are not amortized but are tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired.  If the carrying amount of an intangible asset exceeds its fair value, the Company recognizes an impairment loss in an amount equal to that excess. Unamortized capitalized costs of a computer software product are compared to the net realizable value of the product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset is written off.

[0000833444-22-000005:notes:160]
At December 31, 2021 and 2020, the Company concluded it did not have any triggering events requiring assessment of impairment of its long-lived assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-22-000005:notes:161]
[same as prior period, unchanged from 0000833444-21-000040:notes:79]

[0000833444-22-000005:notes:162]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended December 31, 2021, the Company's effective tax rate for continuing operations was 14.5% and was higher than the statutory tax rate of 12.5% primarily due to the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the three months ended December 31, 2020, the Company's effective tax rate for continuing operations was 14.1% and was higher than the statutory tax rate of 12.5% primarily due to tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives.

[0000833444-22-000005:notes:163]
[same as prior period, unchanged from 0000833444-21-000040:notes:81]

[0000833444-22-000005:notes:164]
[same as prior period, unchanged from 0000833444-21-000040:notes:82]

[0000833444-22-000005:notes:165]
[same as prior period, unchanged from 0000833444-21-000040:notes:84]

[0000833444-22-000005:notes:166]
At September 30, 2021, the Company had gross tax-effected unrecognized tax benefits of $2,726 million, of which $2,268 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2021 was approximately $252 million (net of tax benefit). Total net accrued interest during the three months ended December 31, 2021 and 2020 was approximately $17 million (net of tax benefit) and approximately $15 million (net of tax benefit), respectively. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-22-000005:notes:167]
[same as prior period, unchanged from 0000833444-21-000040:notes:88]

[0000833444-22-000005:notes:168]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2020 |
| Germany |  | 2007 - 2018 |
| Luxembourg |  | 2017 - 2018 |
| Mexico |  | 2015 - 2020 |
| United Kingdom |  | 2014 - 2015, 2017 - 2018 |

[0000833444-22-000005:notes:169]
It is reasonably possible that certain tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense. Based upon the circumstances surrounding these examinations, the impact is not currently quantifiable.

[0000833444-22-000005:notes:170]
[same as prior period, unchanged from 0000833444-21-000040:notes:91]

[0000833444-22-000005:notes:171]
In the first quarter of fiscal 2022, the Company recorded net mark-to-market gains of $57 million which generated tax expense of $14 million and restructuring and impairment costs of $49 million which generated a $7 million tax benefit.

[0000833444-22-000005:notes:172]
Tax expenses and benefits for the above transactions reflect the Company’s current tax positions in the impacted jurisdictions.  Refer to Note 17, “Significant Restructuring and Impairment Costs,” of the notes to consolidated financial statements for additional information.

[0000833444-22-000005:notes:173]
Impacts of Tax Legislation
During the three months ended December 31, 2021, tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-22-000005:notes:174]
Segment Information
ASC 280, "Segment Reporting," establishes the standards for reporting information about segments in financial statements. In applying the criteria set forth in ASC 280, the Company has determined that it has four reportable segments for financial reporting purposes.

[0000833444-22-000005:notes:175]
•Building Solutions North America: Building Solutions North America designs, sells, installs, and services HVAC, controls, building management, refrigeration, integrated electronic security, and integrated fire detection and suppression systems for commercial, industrial, retail, small business, institutional and governmental customers in the United States and Canada. Building Solutions North America also provides energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and control systems, as well as data-driven "smart building" solutions, to non-residential building and industrial applications in the United States and Canadian marketplace.

[0000833444-22-000005:notes:176]
•Building Solutions EMEA/LA: Building Solutions EMEA/LA designs, sells, installs, and services HVAC, controls, building management, refrigeration, integrated electronic security, integrated fire detection and suppression systems, and provides technical services, including data-driven "smart building" solutions, to markets in Europe, the Middle East, Africa and Latin America.

[0000833444-22-000005:notes:177]
•Building Solutions Asia Pacific: Building Solutions Asia Pacific designs, sells, installs, and services HVAC, controls, building management, refrigeration, integrated electronic security, integrated fire-detection and suppression systems, and provides technical services, including data-driven "smart building" solutions, to the Asia Pacific marketplace.

[0000833444-22-000005:notes:178]
•Global Products: Global Products designs, manufactures and sells HVAC equipment, controls software and software services for residential and commercial applications to commercial, industrial, retail, residential, small business, institutional and governmental customers worldwide. In addition, Global Products designs, manufactures and sells refrigeration equipment and controls globally. The Global Products business also designs, manufactures and sells fire protection, fire suppression and security products, including intrusion security, anti-theft devices, access control, and video surveillance and management systems, for commercial, industrial, retail, residential, small business, institutional and governmental customers worldwide. Global Products also includes the Johnson Controls-Hitachi joint venture.

[0000833444-22-000005:notes:179]
Effective October 1, 2021, the Company's marine businesses previously included in Building Solutions Asia Pacific and Global Products reportable segments are now part of Building Solutions EMEA/LA reportable segment. Historical information has been re-cast to present the comparative periods on a consistent basis. This change was not material to the segment presentation.

[0000833444-22-000005:notes:180]
Management evaluates the performance of its business segments primarily on segment earnings before interest, taxes and amortization ("EBITA"), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and the net mark-to-market adjustments related to pension and postretirement plans and restricted asbestos investments.

[0000833444-22-000005:notes:181]
[same as prior period, unchanged from 0000833444-21-000040:notes:216]

[0000833444-22-000005:notes:182]
|  | Net Sales |
|  | Three Months Ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Building Solutions North America | $ | 2,152 |  |  | $ | 2,034 |  |  |  |  |  |
| Building Solutions EMEA/LA | 959 |  |  | 948 |  |  |  |  |  |
| Building Solutions Asia Pacific | 675 |  |  | 604 |  |  |  |  |  |
| Global Products | 2,076 |  |  | 1,755 |  |  |  |  |  |
| Total net sales | $ | 5,862 |  |  | $ | 5,341 |  |  |  |  |  |

[0000833444-22-000005:notes:183]
|  | Segment EBITA |
|  | Three Months Ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Building Solutions North America | $ | 250 |  |  | $ | 255 |  |  |  |  |  |
| Building Solutions EMEA/LA | 104 |  |  | 98 |  |  |  |  |  |
| Building Solutions Asia Pacific | 68 |  |  | 77 |  |  |  |  |  |
| Global Products | 301 |  |  | 212 |  |  |  |  |  |
| Total segment EBITA | 723 |  |  | 642 |  |  |  |  |  |
| Corporate expenses | (70) |  |  | (67) |  |  |  |  |  |
| Amortization of intangible assets | (118) |  |  | (104) |  |  |  |  |  |
| Restructuring and impairment costs | (49) |  |  | — |  |  |  |  |  |
| Net mark-to-market adjustments | 57 |  |  | 21 |  |  |  |  |  |
| Net financing charges | (53) |  |  | (59) |  |  |  |  |  |
| Income from continuing operations before income taxes | $ | 490 |  |  | $ | 433 |  |  |  |  |  |


## us-gaap:GuaranteesTextBlock

[0000833444-22-000005:notes:184]
Guarantees
Certain of the Company's subsidiaries at the business segment level have guaranteed the performance of third parties and provided financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from the current fiscal year through the completion of such transactions and would typically be triggered in the event of nonperformance. Performance under the guarantees, if required, would not have a material effect on the Company's financial position, results of operations or cash flows.

[0000833444-22-000005:notes:185]
[same as prior period, unchanged from 0000833444-21-000040:notes:220]

[0000833444-22-000005:notes:186]
[same as prior period, unchanged from 0000833444-21-000040:notes:221]

[0000833444-22-000005:notes:187]
The changes in the carrying amount of the Company’s total product warranty liability for continuing operations, for the three months ended December 31, 2021 and 2020 were as follows (in millions):

[0000833444-22-000005:notes:188]
|  | Three Months Ended December 31, |
|  | 2021 |  | 2020 |
| Balance at beginning of period | $ | 192 |  |  | $ | 167 |  |
| Accruals for warranties issued during the period | 22 |  |  | 22 |  |
| Accruals related to pre-existing warranties | — |  |  | 6 |  |
| Settlements made (in cash or in kind) during the period | (29) |  |  | (17) |  |
| Currency translation | (1) |  |  | 2 |  |
| Balance at end of period | $ | 184 |  |  | $ | 180 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-22-000005:notes:189]
Commitments and Contingencies
Environmental Matters

[0000833444-22-000005:notes:190]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-22-000005:notes:191]
|  | December 31, 2021 |  | September 30, 2021 |
| Other current liabilities | $ | 64 |  |  | $ | 48 |  |
| Other noncurrent liabilities | 29 |  |  | 54 |  |
| Total reserves for environmental liabilities | $ | 93 |  |  | $ | 102 |  |

[0000833444-22-000005:notes:192]
Tyco Fire Products L.P. (“Tyco Fire Products”), in coordination with the Wisconsin Department of Natural Resources ("WDNR"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin. In connection with the assessment, perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluoroalkyl substances ("PFAS") have been detected at the FTC and in groundwater and surface water outside of the

[0000833444-22-000005:notes:193]
boundaries of the FTC. Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working with WDNR to address these issues insofar as they related to this migration.

[0000833444-22-000005:notes:194]
During the third quarter of 2019, the Company increased its environmental reserves, which included $140 million related to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The Company is not able to estimate a possible loss or range of loss in excess of the established accruals at this time.

[0000833444-22-000005:notes:195]
A substantial portion of the increased reserves relates to remediation resulting from the use of fire-fighting foams containing PFAS at the FTC. The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The reserve was recorded in the quarter ended June 30, 2019 following a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR.

[0000833444-22-000005:notes:196]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. On August 22, 2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation. On November 6, 2020, WDNR received further recommendations from WDHS regarding individual standards for 12 additional PFAS and a combined standard for four additional PFAS, PFOA, and PFOS.

[0000833444-22-000005:notes:197]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. Tyco Fire Products voluntarily responded to the WDNR’s letter to request additional necessary information.  On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. The letter stated that “if you fail to take the actions required by Wis. Stat. § 292.11 to address this contamination, the DNR will move forward under Wis. Stat. § 292.31 to implement the SI workplan and evaluate further environmental enforcement actions and cost recovery under Wis. Stat. § 292.31(8).” The WDNR issued a further letter regarding the issue on November 4, 2019.  In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to date. Tyco Fire Products responded to the WDNR’s September 2021 notice by the December 27, 2021 deadline set by WDNR. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

[0000833444-22-000005:notes:198]
In May 2021, as part of Tyco Fire Products’ ongoing investigation and remediation program, WDNR approved Tyco Fire Products’ proposed Groundwater Extraction and Treatment System (“GETS”), a permanent groundwater remediation system that will extract groundwater that contains PFAS, treat it using advanced filtration systems, and return the treated water to the environment. Tyco Fire Products has commenced construction on the GETS. Tyco Fire Products also has started the process of removing PFAS-affected soil from the FTC.

[0000833444-22-000005:notes:199]
In December 2020, the Company received a notice from the Wisconsin Department of Justice (“WDOJ”) that the WDOJ was considering a potential civil enforcement action against the Company relating to environmental matters at the FTC including, but not limited to, the investigation and remediation of PFAS at or near the FTC as discussed above and the Company’s alleged failure to timely report the presence of PFAS chemicals at the FTC. Such enforcement action could seek civil monetary penalties and/or injunctive relief. The Company is presently unable to predict the duration, scope, or

[0000833444-22-000005:notes:200]
results of any potential civil enforcement action that may result, the consequences of any such action, or the nature of any resolution of these potential claims with the WDOJ.

[0000833444-22-000005:notes:201]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”) manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. The increase in the reserve related to the Stanton Street Facility in the third quarter of 2019 was recorded following a further review of the Consent Order, which resulted in the identification of several structural upgrades needed to preserve the effectiveness of prior remediation efforts. In addition to ongoing remediation activities, the Company is also working with the WDNR to investigate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation of PFAS in the Marinette region.

[0000833444-22-000005:notes:202]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. The Company recorded conditional asset retirement obligations for continuing operations of $29 million at both December 31, 2021 and September 30, 2021.

[0000833444-22-000005:notes:203]
Asbestos Matters

[0000833444-22-000005:notes:204]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-22-000005:notes:205]
The Company estimates the asbestos-related liability for pending and future claims and related defense costs on a discounted basis. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable.

[0000833444-22-000005:notes:206]
The following table presents the location and amount of asbestos-related assets and liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-22-000005:notes:207]
|  | December 31, 2021 |  | September 30, 2021 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 395 |  |  | 400 |  |
| Total asbestos-related liabilities | 453 |  |  | 458 |  |
| Other current assets | 15 |  |  | 13 |  |
| Other noncurrent assets | 373 |  |  | 365 |  |
| Total asbestos-related assets | 388 |  |  | 378 |  |
| Net asbestos-related liabilities | $ | 65 |  |  | $ | 80 |  |

[0000833444-22-000005:notes:208]
The following table presents the components of asbestos-related assets (in millions):

[0000833444-22-000005:notes:209]
|  | December 31, 2021 |  | September 30, 2021 |
| Restricted |  |  |  |
| Cash | $ | 7 |  |  | $ | 6 |  |
| Investments | 323 |  |  | 314 |  |
| Total restricted assets | 330 |  |  | 320 |  |
| Insurance recoveries for asbestos-related liabilities | 58 |  |  | 58 |  |
| Total asbestos-related assets | $ | 388 |  |  | $ | 378 |  |

[0000833444-22-000005:notes:210]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be paid by Company affiliates). Asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be paid through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-22-000005:notes:211]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption may impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-22-000005:notes:212]
Insurable Liabilities

[0000833444-22-000005:notes:213]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-22-000005:notes:214]
The following table presents the location and amount of insurable liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-22-000005:notes:215]
|  | December 31, 2021 |  | September 30, 2021 |
| Other current liabilities | $ | 79 |  |  | $ | 77 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 218 |  |  | 226 |  |
| Total insurable liabilities | $ | 319 |  |  | $ | 325 |  |

[0000833444-22-000005:notes:216]
The following table presents the location and amount of insurable receivables in the Company's consolidated statements of financial position (in millions):

[0000833444-22-000005:notes:217]
|  | December 31, 2021 |  | September 30, 2021 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 15 |  |  | 15 |  |
| Total insurable receivables | $ | 20 |  |  | $ | 20 |  |

[0000833444-22-000005:notes:218]
Aqueous Film-Forming Foam ("AFFF") Litigation

[0000833444-22-000005:notes:219]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-22-000005:notes:220]
PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but had initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. In March 2021, the EPA published its final determination to regulate PFOS and PFOA in drinking water. In October 2021, the EPA released its "PFAS Strategic Roadmap: EPA's Commitments to Action 2021-2024." The 2021-2024 Roadmap sets timelines by which the EPA plans to take specific actions, including, among other items, publishing a national PFAS testing strategy, proposing to designate PFOA and PFOS as Comprehensive Environmental Response, Compensation and Liability Act hazardous substances, restricting PFAS discharges from industrial sources through Effluent Limitations Guidelines, publishing the final toxicity assessment for five additional PFAS, requiring water systems to test for 29 PFAS under the Safe Drinking Water Act, and publishing improved analytical methods in eight different environmental matrices to monitor 40 PFAS present in wastewater and stormwater

[0000833444-22-000005:notes:221]
discharges. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

[0000833444-22-000005:notes:222]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to or are being directly filed in the MDL.

[0000833444-22-000005:notes:223]
AFFF Putative Class Actions

[0000833444-22-000005:notes:224]
Chemguard and Tyco Fire Products are named in 32 putative class actions in federal courts originating from Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington, New Hampshire, South Carolina, the District of Columbia, Guam, West Virginia, Michigan, Texas and South Dakota. All of these cases except one have been direct-filed in or transferred to the MDL.

[0000833444-22-000005:notes:225]
AFFF Individual or Mass Actions

[0000833444-22-000005:notes:226]
There are more than 1,900 individual or “mass” actions pending that were filed in state or federal court in various states including California, Colorado, New York, Pennsylvania, New Mexico, Missouri, Arizona, Texas, and South Carolina against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 1,900 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly filed state court actions will be similarly tagged and transferred. There are three matters that are proceeding in state court: One case, Young v. Chemguard et al., was filed in superior court in Maricopa County, Arizona, removed to the United States District Court, District of Arizona, and tagged to the MDL, but was remanded to state court prior to being transferred to the MDL. The decision to remand the case to state court is currently being appealed. The second case, Forbach et al. v. Chemguard et al., was filed in superior court in Coconino County, Arizona, and is proceeding with initial discovery. The third case, Ellison-Wood v. Chemguard, Inc., et al., was filed recently in district court in Tarrant County, Texas.

[0000833444-22-000005:notes:227]
AFFF Municipal Cases

[0000833444-22-000005:notes:228]
Chemguard and Tyco Fire Products have been named as defendants in approximately 168 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Alabama, Arizona, California, Colorado, Connecticut, Florida, Idaho, Illinois, Kentucky, Louisiana, Maryland, Massachusetts, Michigan, New Jersey, New York, North Carolina, Ohio, Pennsylvania, Virginia, Washington, West Virginia, Wisconsin, the District of Columbia, and several municipalities or water providers from various states who direct-filed complaints in South Carolina. All but five of these cases have been transferred to or directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.

[0000833444-22-000005:notes:229]
The Company has periodically been notified by other municipal entities that those entities may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-22-000005:notes:230]
State or U.S. Territory Attorneys General Litigation related to AFFF

[0000833444-22-000005:notes:231]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-22-000005:notes:232]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-22-000005:notes:233]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. The 3M Company et al., No. G-4801-CI-021804752 -000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio. The lawsuit seeks to recover costs and natural resource damages associated with the contamination. This lawsuit has been removed to the United States District Court for the Northern District of Ohio and transferred to the MDL.

[0000833444-22-000005:notes:234]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.). All three of these suits have been removed to federal court and transferred to the MDL.

[0000833444-22-000005:notes:235]
In September 2019, the government of Guam filed a lawsuit in the superior court of Guam against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-22-000005:notes:236]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.

[0000833444-22-000005:notes:237]
In August 2020, Attorney General of the State of Michigan filed two substantially similar lawsuits—one in federal court and one in state court—against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within the State. The federal action has been transferred to the MDL, and the state court action has been removed to federal court and transferred to the MDL.

[0000833444-22-000005:notes:238]
In December 2020, the State of Mississippi filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State.  This complaint was direct-filed in the MDL in South Carolina.

[0000833444-22-000005:notes:239]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. The State’s case has been removed to federal court and transferred to the MDL. The State of Alaska has also named a number of manufacturers and other defendants, including affiliates of the Company, as third-party defendants in two cases brought by individuals against the State. These two cases have also been transferred to the MDL.

[0000833444-22-000005:notes:240]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL.

[0000833444-22-000005:notes:241]
Other AFFF Related Matters

[0000833444-22-000005:notes:242]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

[0000833444-22-000005:notes:243]
The Company is vigorously defending the above matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. Tyco and Chemguard have insurance that has been in place for many years and the Company is pursuing this coverage for these matters. However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

[0000833444-22-000005:notes:244]
Other Matters

[0000833444-22-000005:notes:245]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-22-000005:notes:246]
Related Party Transactions
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-22-000005:notes:247]
The following table presents net sales to and purchases from related parties for the three months ended December 31, 2021 and 2020 (in millions):

[0000833444-22-000005:notes:248]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Net sales to related parties |  | $ | 35 |  |  | $ | 44 |  |  |  |  |  |
| Purchases from related parties |  | 44 |  |  | 29 |  |  |  |  |  |

[0000833444-22-000005:notes:249]
The following table presents receivables from and payables to related parties in the consolidated statements of financial position (in millions):

[0000833444-22-000005:notes:250]
|  |  | December 31, 2021 |  | September 30, 2021 |
| Receivable from related parties |  | $ | 58 |  |  | $ | 73 |  |
| Payable to related parties |  | 15 |  |  | 45 |  |

[0000833444-22-000005:notes:251]
Additionally, the Company leases certain facilities used in its operations from a related party. As of December 31, 2021, the right-of-use asset and lease liability associated with these leases were $10 million. As of September 30, 2021, the right-of-use asset associated with these leases was $11 million and the lease liability was $10 million. Amounts paid for these leases were not material.
