# JCI 8-K — 0000833444-22-000003 filed 2022-02-02

## item codes, every 8-K on or before 2022-02-02

- 2022-02-02 0000833444-22-000003 — 2.02, 9.01
- 2021-12-10 0000833444-21-000050 — 5.02
- 2021-11-05 0000833444-21-000043 — 2.02, 9.01
- 2021-09-16 0001193125-21-275152 — 1.01, 8.01, 9.01
- 2021-07-30 0000833444-21-000038 — 2.02, 9.01
- 2021-05-03 0000833444-21-000023 — 8.01
- 2021-04-30 0000833444-21-000017 — 2.02, 9.01
- 2021-03-11 0000833444-21-000013 — 5.02, 5.07, 9.01
- 2021-02-17 0001193125-21-045768 — 7.01, 9.01
- 2021-01-29 0000833444-21-000009 — 2.02, 9.01
- 2021-01-07 0000833444-21-000004 — 7.01
- 2020-11-03 0000833444-20-000043 — 2.02, 9.01
- 2020-09-15 0001193125-20-246240 — 1.01, 8.01, 9.01
- 2020-09-11 0001193125-20-244119 — 1.01, 8.01, 9.01
- 2020-08-18 0000833444-20-000038 — 5.02, 9.01
- 2020-07-31 0000833444-20-000034 — 2.02, 9.01
- 2020-06-12 0000833444-20-000020 — 8.01
- 2020-05-01 0000833444-20-000013 — 2.02, 9.01
- 2020-03-12 0000833444-20-000010 — 5.02
- 2020-03-06 0000833444-20-000008 — 5.07
- 2020-01-31 0000833444-20-000003 — 2.02, 9.01
- 2019-12-06 0001193125-19-308301 — 1.01, 1.02, 2.03, 9.01
- 2019-11-07 0000833444-19-000048 — 5.02, 9.01
- 2019-11-07 0000833444-19-000046 — 2.02, 9.01
- 2019-08-21 0000833444-19-000043 — 8.01
- 2019-07-31 0000833444-19-000038 — 2.02, 9.01
- 2019-07-23 0000833444-19-000035 — 5.02, 8.01, 9.01
- 2019-07-02 0000833444-19-000033 — 1.02, 8.01
- 2019-06-05 0001193125-19-165565 — 8.01
- 2019-05-30 0001193125-19-160205 — 8.01, 9.01
- 2019-05-16 0001193125-19-148262 — 8.01, 9.01
- 2019-05-07 0001193125-19-139826 — 5.04, 9.01
- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2022-02-02

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-22-000003:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq1fy22.htm
EX-99.1

[0000833444-22-000003:8k_2_02:2]
Document

[0000833444-22-000003:8k_2_02:3]
Exhibit 99.1

[0000833444-22-000003:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-22-000003:8k_2_02:5]
Johnson Controls reports strong revenue and EPS growth in Q1 and reaffirms FY22 EPS guidance

[0000833444-22-000003:8k_2_02:6]
________________________________________________________________________________

[0000833444-22-000003:8k_2_02:7]
▪GAAP EPS of $0.54; Adjusted EPS of $0.54, up 26% versus prior year

[0000833444-22-000003:8k_2_02:8]
▪Reported sales +10% versus prior year; +8% organic

[0000833444-22-000003:8k_2_02:9]
▪Orders +8% year-over-year, with broad-based underlying momentum; Backlog of $10.5 billion increased 10% organically year-over-year

[0000833444-22-000003:8k_2_02:10]
▪Cash provided by operating activities of $0.4 billion; Free cash flow of $0.3 billion

[0000833444-22-000003:8k_2_02:11]
▪Completed over $500 million in share repurchases in Q1, increased the dividend by 26%, and deployed over $100 million in cash on acquisitions

[0000833444-22-000003:8k_2_02:12]
▪Reaffirms fiscal 2022 adjusted EPS guidance of $3.22 to $3.32, an increase of 22 to 25% year-over-year; Fiscal Q2 adjusted EPS guided to $0.62 to $0.64, an increase of 19 to 23% year-over-year

[0000833444-22-000003:8k_2_02:13]
________________________________________________________________________________

[0000833444-22-000003:8k_2_02:14]
CORK, Ireland, February 2, 2022 -- Johnson Controls International plc (NYSE: JCI), a global leader for smart, healthy and sustainable buildings, today reported fiscal first quarter 2022 GAAP earnings per share (“EPS”) from continuing operations, including special items, of $0.54. Excluding these items, adjusted EPS from continuing operations was also $0.54, up 26% versus the prior year period (see attached footnotes for non-GAAP reconciliation).

[0000833444-22-000003:8k_2_02:15]
Sales of $5.9 billion increased 10% compared to the prior year on an as reported basis, and up 8% organically. GAAP net income from continuing operations was $381 million. Adjusted net income from continuing operations of $380 million increased 22% versus the prior year. Earnings before interest and taxes (“EBIT”) was $543 million and EBIT margin was 9.3%. Adjusted EBIT was $542 million and adjusted EBIT margin was 9.2%, up 40 basis points versus the prior year.

[0000833444-22-000003:8k_2_02:16]
“We are off to a strong start in fiscal 2022, delivering strong order, revenue and profitability growth in the quarter, despite a continuously challenging operating environment,” said George Oliver, chairman and chief executive officer. “Our first quarter results further demonstrate our ability to execute, even as persistent supply chain disruptions and labor constraints presented increased inflationary headwinds. Order and revenue performance reflects continued robust demand for healthy, smart, and sustainable building solutions as well as our teams’ unwavering focus on serving our customers’ needs. We continue to reinvest in our business, both organically and inorganically, and remain committed to driving strong cash flow and returning capital to shareholders.”

[0000833444-22-000003:8k_2_02:17]
“Despite increased pressure from ongoing supply chain and labor constraints, we are reaffirming guidance for the full year,” said Olivier Leonetti, chief financial officer. “More importantly, we believe we remain well positioned for accelerated growth as we leverage our OpenBlue digital platform to capitalize on the global trend towards reducing carbon emissions and energy intensity and improving the overall health of indoor environments.”

[0000833444-22-000003:8k_2_02:18]
Page 1 of 17

[0000833444-22-000003:8k_2_02:19]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-22-000003:8k_2_02:20]
($ millions, except per-share amounts)

[0000833444-22-000003:8k_2_02:21]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the first fiscal quarter of 2021. Effective October 1, 2021, the Company’s Marine business, previously reported across Building Solutions Asia Pacific, Global Products and Building Solutions EMEA/LA segments, is now managed and reported under the Building Solutions EMEA/LA segment. Historical information has been re-cast to present the comparative periods on a consistent basis.

[0000833444-22-000003:8k_2_02:22]
Organic sales, adjusted sales, total segment EBITA, adjusted segment EBITA, adjusted corporate expense, EBIT, adjusted EBIT, adjusted net income from continuing operations, adjusted EPS from continuing operations, free cash flow and free cash flow conversion are non-GAAP financial measures. For a reconciliation of these non-GAAP measures and detail of the special items, refer to the attached footnotes. A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-22-000003:8k_2_02:23]
|  |  | Fiscal Q1 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  |  |  |  |  |  |
| Sales |  | $5,341 |  | $5,862 |  | $5,341 |  | $5,862 |  |  |  |  |  |  |
| Segment EBITA |  | 642 |  | 723 |  |  | 642 |  | 723 |  |  |  |  |  |  |  |
| EBIT |  | 492 |  | 543 |  | 471 |  | 542 |  |  |  |  |  |  |
| Net income from continuing operations |  | 327 |  | 381 |  | 311 |  | 380 |  |  |  |  |  |  |
| Diluted EPS from continuing operations |  | $0.45 |  |  | $0.54 |  |  | $0.43 |  |  | $0.54 |  |  |  |  |  |  |  |

[0000833444-22-000003:8k_2_02:24]
Page 2 of 17

[0000833444-22-000003:8k_2_02:25]
SEGMENT RESULTS

[0000833444-22-000003:8k_2_02:26]
Building Solutions North America

[0000833444-22-000003:8k_2_02:27]
|  |  | Fiscal Q1 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  |  |  |  |  |  |
| Sales |  | $2,034 |  | $2,152 |  | $2,034 |  | $2,152 |  |  |  |  |  |  |
| Segment EBITA |  | 255 |  | 250 |  |  | 255 |  | 250 |  |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 12.5% |  | 11.6% |  | 12.5% |  | 11.6% |  |  |  |  |  |  |

[0000833444-22-000003:8k_2_02:28]
Sales in the quarter of $2.2 billion increased 6% versus the prior year. Organic sales increased 5% over the prior year, led by high-single digit growth in Service and strong growth in our HVAC & Controls platform.

[0000833444-22-000003:8k_2_02:29]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 11% year-over-year. Backlog at the end of the quarter of $6.5 billion increased 12% compared to the prior year, excluding M&A and adjusted for foreign currency.

[0000833444-22-000003:8k_2_02:30]
Adjusted segment EBITA was $250 million, down 2% versus the prior year. Adjusted segment EBITA margin of 11.6% declined 90 basis points versus the prior year as the benefit of volume leverage and the SG&A/COGS actions were more than offset by inefficiencies related to supply chain disruptions and labor constraints.

[0000833444-22-000003:8k_2_02:31]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-22-000003:8k_2_02:32]
|  |  | Fiscal Q1 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  |  |  |  |  |  |
| Sales |  | $948 |  |  | $959 |  |  | $948 |  |  | $959 |  |  |  |  |  |  |  |
| Segment EBITA |  | 98 |  | 104 |  |  | 98 |  | 104 |  |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 10.3% |  | 10.8% |  | 10.3% |  | 10.8% |  |  |  |  |  |  |

[0000833444-22-000003:8k_2_02:33]
Sales in the quarter of $959 million increased 1% versus the prior year. Organic sales grew 3% versus the prior year with balanced growth in both project installations and service activity, led by strength in Fire & Security. By region, sales growth outperformed in Europe and Latin America, partially offset by continued weakness in the Middle East.

[0000833444-22-000003:8k_2_02:34]
Page 3 of 17

[0000833444-22-000003:8k_2_02:35]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 3% year-over-year. Backlog at the end of the quarter of $2.2 billion increased 12% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-22-000003:8k_2_02:36]
Adjusted segment EBITA was $104 million, up 6% versus the prior year. Adjusted segment EBITA margin of 10.8% expanded 50 basis points over the prior year, as positive price/cost was partially offset by negative mix and the impact of M&A. On an organic basis, adjusted segment EBITA margin increased 90 basis points.

[0000833444-22-000003:8k_2_02:37]
Building Solutions Asia Pacific

[0000833444-22-000003:8k_2_02:38]
|  |  | Fiscal Q1 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  |  |  |  |  |  |
| Sales |  | $604 |  |  | $675 |  |  | $604 |  |  | $675 |  |  |  |  |  |  |  |
| Segment EBITA |  | 77 |  | 68 |  |  | 77 |  | 68 |  |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 12.7% |  | 10.1% |  | 12.7% |  | 10.1% |  |  |  |  |  |  |

[0000833444-22-000003:8k_2_02:39]
Sales in the quarter of $675 million increased 12% versus the prior year. Organic sales also grew 12% versus the prior year, led by mid-teens growth in project installations, driven by strong growth in Commercial Applied HVAC & Controls. China remains the primary source of growth, with growth stabilizing across the rest of the region.

[0000833444-22-000003:8k_2_02:40]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 5% year-over-year. Backlog at the end of the quarter of $1.8 billion increased 2% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-22-000003:8k_2_02:41]
Adjusted segment EBITA was $68 million, declined 12% versus the prior year. Adjusted segment EBITA margin of 10.1% declined 260 basis points versus the prior year as volume leverage and the benefit of SG&A/COGS actions were more than offset by negative price/cost and the unfavorable impact of install/service and geographic mix.

[0000833444-22-000003:8k_2_02:42]
Page 4 of 17

[0000833444-22-000003:8k_2_02:43]
Global Products

[0000833444-22-000003:8k_2_02:44]
|  |  | Fiscal Q1 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  |  |  |  |  |  |
| Sales |  | $1,755 |  |  | $2,076 |  |  | $1,755 |  |  | $2,076 |  |  |  |  |  |  |  |
| Segment EBITA |  | 212 |  | 301 |  |  | 212 |  | 301 |  |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 12.1% |  | 14.5% |  | 12.1% |  | 14.5% |  |  |  |  |  |  |

[0000833444-22-000003:8k_2_02:45]
Sales in the quarter of $2.1 billion increased 18% versus the prior year. Organic sales grew 14% versus the prior year driven by broad-based strength across Commercial and Residential HVAC and Fire & Security products.

[0000833444-22-000003:8k_2_02:46]
Adjusted segment EBITA was $301 million, up 42% versus the prior year. Adjusted segment EBITA margin of 14.5% expanded 240 basis points versus the prior year as volume leverage, positive mix, increased equity income and the benefit of SG&A/COGS actions were partially offset by negative price/cost and supply chain disruptions.

[0000833444-22-000003:8k_2_02:47]
Corporate

[0000833444-22-000003:8k_2_02:48]
|  |  | Fiscal Q1 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2021 |  | 2022 |  | 2021 |  | 2022 |  |  |  |  |  |  |
| Corporate Expense |  | ($67) |  |  | ($70) |  |  | ($67) |  |  | ($70) |  |  |  |  |  |  |  |

[0000833444-22-000003:8k_2_02:49]
Adjusted Corporate expense was $70 million in the quarter, an increase of 4% compared to the prior year.

[0000833444-22-000003:8k_2_02:50]
OTHER ITEMS

[0000833444-22-000003:8k_2_02:51]
▪For the quarter, cash provided by operating activities from continuing operations was $0.4 billion and capital expenditures were $0.1 billion, resulting in free cash flow from continuing operations of $0.3 billion.

[0000833444-22-000003:8k_2_02:52]
▪During the quarter, the Company repurchased approximately 7.2 million shares for $526 million.

[0000833444-22-000003:8k_2_02:53]
▪During the quarter, the Company increased its regular quarterly cash dividend by 26%, to $0.34 per common share.

[0000833444-22-000003:8k_2_02:54]
Page 5 of 17

[0000833444-22-000003:8k_2_02:55]
▪During the quarter, the Company recorded net pre-tax mark-to-market gains of $57 million related primarily to the remeasurement of the Company’s pension and postretirement benefit plans.

[0000833444-22-000003:8k_2_02:56]
▪During the quarter, the Company recorded pre-tax restructuring and impairment costs of $49 million and acquisition related charges of $7 million.

[0000833444-22-000003:8k_2_02:57]
SECOND QUARTER GUIDANCE

[0000833444-22-000003:8k_2_02:58]
The Company initiated fiscal 2022 second quarter guidance:

[0000833444-22-000003:8k_2_02:59]
▪Organic revenue up high-single digits year-over-year

[0000833444-22-000003:8k_2_02:60]
▪Adjusted segment EBITA margin expansion of 50 to 60 basis points, year-over-year

[0000833444-22-000003:8k_2_02:61]
▪Adjusted EPS before special items of $0.62 to $0.64; represents 19 to 23% growth year-over-year

[0000833444-22-000003:8k_2_02:62]
FULL YEAR GUIDANCE

[0000833444-22-000003:8k_2_02:63]
The Company reaffirmed fiscal 2022 full year EPS guidance:

[0000833444-22-000003:8k_2_02:64]
▪Organic revenue growth of 8 to 10% year-over-year

[0000833444-22-000003:8k_2_02:65]
▪Adjusted segment EBITA margin expansion of 50 to 60 basis points, year-over-year

[0000833444-22-000003:8k_2_02:66]
▪Adjusted EPS before special items of $3.22 to $3.32; represents 22 to 25% growth year-over-year

[0000833444-22-000003:8k_2_02:67]
CONFERENCE CALL & WEBCAST INFO

[0000833444-22-000003:8k_2_02:68]
Johnson Controls will host a conference call to discuss this quarter’s results at 8:30 a.m. ET today, which can be accessed by dialing 888-324-9610 (in the United States) or 630-395-0255 (outside the United States), or via webcast. The passcode is “Johnson Controls”. A slide presentation will accompany the prepared remarks and has been posted on the investor relations section of the Johnson Controls website at https://investors.johnsoncontrols.com/news-and-events/events-and-presentations. A replay will be made available approximately two hours following the conclusion of the conference call.

[0000833444-22-000003:8k_2_02:69]
About Johnson Controls:

[0000833444-22-000003:8k_2_02:70]
At Johnson Controls (NYSE:JCI) we transform the environments where people live, work, learn and play. As the global leader in smart, healthy and sustainable buildings, our mission is to reimagine the performance of buildings to serve people, places and the planet.

[0000833444-22-000003:8k_2_02:71]
With a history of more than 135 years of innovation, Johnson Controls delivers the blueprint of the future for industries such as healthcare, schools, data centers, airports, stadiums, manufacturing and beyond through its comprehensive digital offering OpenBlue. With a global team of 100,000 experts in more than 150 countries, Johnson Controls offers the world`s largest portfolio of building technology, software as well

[0000833444-22-000003:8k_2_02:72]
Page 6 of 17

[0000833444-22-000003:8k_2_02:73]
as service solutions with some of the most trusted names in the industry. For more information, visit www.johnsoncontrols.com or follow us @johnsoncontrols on Twitter.

[0000833444-22-000003:8k_2_02:74]
JOHNSON CONTROLS CONTACTS:

[0000833444-22-000003:8k_2_02:75]
| INVESTOR CONTACTS: | MEDIA CONTACTS: |  |  |  |
| Antonella Franzen | Karen Tognarelli |  |  |  |
| Direct: +1 609.720.4665 | Direct: +1 571.214.7744 |  |  |  |
| Email: antonella.franzen@jci.com | Email: karen.tognarelli@jci.com |  |  |  |
| Ryan Edelman | Michael Isaac |  |  |  |
| Direct: +1 609.720.4545 | Direct: +41 52 6330374 |  |  |  |
| Email: ryan.edelman@jci.com | Email: michael.isaac@jci.com |  |  |  |

[0000833444-22-000003:8k_2_02:76]
###

[0000833444-22-000003:8k_2_02:77]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-22-000003:8k_2_02:78]
Page 7 of 17

[0000833444-22-000003:8k_2_02:79]
transaction costs and/or unknown liabilities associated with such transactions; fluctuations in currency exchange rates; labor shortages, work stoppages, union negotiations, labor disputes and other matters associated with the labor force; and the cancellation of or changes to commercial arrangements. A detailed discussion of risks related to Johnson Controls’ business is included in the section entitled “Risk Factors” in Johnson Controls’ Annual Report on Form 10-K for the 2021 fiscal year filed with the SEC on November 15, 2021, which is available at www.sec.gov and www.johnsoncontrols.com under the “Investors” tab. The description of certain of these risks is supplemented in Item 1A of Part II of Johnson Controls’ subsequently filed Quarterly Reports on Form 10-Q. Shareholders, potential investors and others should consider these factors in evaluating the forward-looking statements and should not place undue reliance on such statements. The forward-looking statements included in this communication are made only as of the date of this document, unless otherwise specified, and, except as required by law, Johnson Controls assumes no obligation, and disclaims any obligation, to update such statements to reflect events or circumstances occurring after the date of this communication.

[0000833444-22-000003:8k_2_02:80]
###

[0000833444-22-000003:8k_2_02:81]
Non-GAAP Financial Information

[0000833444-22-000003:8k_2_02:82]
This press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include restructuring and impairment costs, net mark-to-market adjustments, Silent-Aire transaction costs and other nonrecurring costs, Power Solutions divestiture reserve adjustment and discrete tax items. Financial information regarding organic sales, adjusted sales, EBIT, EBIT margin, adjusted EBIT, adjusted EBIT margin, total segment EBITA, adjusted segment EBITA, adjusted segment EBITA margin, adjusted corporate expense, free cash flow, free cash flow conversion and adjusted net income from continuing operations are also presented, which are non-GAAP performance measures. Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.  For further information on the calculation of the non-GAAP measures and a reconciliation of these non-GAAP measures, refer to the attached footnotes.

[0000833444-22-000003:8k_2_02:83]
###

[0000833444-22-000003:8k_2_02:84]
Page 8 of 17

[0000833444-22-000003:8k_2_02:85]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |  |
|  |  | Three Months Ended December 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Net sales | $ | 5,862 |  |  |  | $ | 5,341 |  |  |
| Cost of sales | 3,971 |  |  |  | 3,613 |  |  |
|  | Gross profit | 1,891 |  |  |  | 1,728 |  |  |
| Selling, general and administrative expenses | (1,369) |  |  |  | (1,294) |  |  |
| Restructuring and impairment costs | (49) |  |  |  | — |  |  |
| Net financing charges | (53) |  |  |  | (59) |  |  |
| Equity income | 70 |  |  |  | 58 |  |  |
| Income from continuing operations before income taxes | 490 |  |  |  | 433 |  |  |
| Income tax provision | 71 |  |  |  | 61 |  |  |
| Income from continuing operations | 419 |  |  |  | 372 |  |  |
| Income from discontinued operations, net of tax | — |  |  |  | 124 |  |  |
| Net income | 419 |  |  |  | 496 |  |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 38 |  |  |  | 45 |  |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | — |  |  |
| Net income attributable to JCI | $ | 381 |  |  |  | $ | 451 |  |  |
| Income from continuing operations | $ | 381 |  |  |  | $ | 327 |  |  |
| Income from discontinued operations | — |  |  |  | 124 |  |  |
| Net income attributable to JCI | $ | 381 |  |  |  | $ | 451 |  |  |
| Diluted earnings per share from continuing operations | $ | 0.54 |  |  |  | $ | 0.45 |  |  |
| Diluted earnings per share from discontinued operations | — |  |  |  | 0.17 |  |  |
| Diluted earnings per share | $ | 0.54 |  |  |  | $ | 0.62 |  |  |
| Diluted weighted average shares | 709.5 |  |  |  | 726.5 |  |  |
| Shares outstanding at period end | 702.8 |  |  |  | 720.3 |  |  |

[0000833444-22-000003:8k_2_02:86]
Page 9 of 17

[0000833444-22-000003:8k_2_02:87]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | December 31,2021 |  | September 30,2021 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 1,207 |  |  | $ | 1,336 |  |
| Accounts receivable - net | 5,671 |  |  | 5,613 |  |
| Inventories | 2,425 |  |  | 2,057 |  |
| Other current assets | 1,050 |  |  | 992 |  |
|  | Current assets | 10,353 |  |  | 9,998 |  |
| Property, plant and equipment - net | 3,213 |  |  | 3,228 |  |
| Goodwill | 18,386 |  |  | 18,335 |  |
| Other intangible assets - net | 5,505 |  |  | 5,549 |  |
| Investments in partially-owned affiliates | 1,102 |  |  | 1,066 |  |
| Noncurrent assets held for sale | 159 |  |  | 156 |  |
| Other noncurrent assets | 3,504 |  |  | 3,558 |  |
|  | Total assets | $ | 42,222 |  |  | $ | 41,890 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 612 |  |  | $ | 234 |  |
| Accounts payable and accrued expenses | 5,009 |  |  | 4,754 |  |
| Other current liabilities | 4,366 |  |  | 4,110 |  |
|  | Current liabilities | 9,987 |  |  | 9,098 |  |
| Long-term debt | 7,437 |  |  | 7,506 |  |
| Other noncurrent liabilities | 6,308 |  |  | 6,533 |  |
| Shareholders' equity attributable to JCI | 17,249 |  |  | 17,562 |  |
| Noncontrolling interests | 1,241 |  |  | 1,191 |  |
|  | Total liabilities and equity | $ | 42,222 |  |  | $ | 41,890 |  |

[0000833444-22-000003:8k_2_02:88]
Page 10 of 17

[0000833444-22-000003:8k_2_02:89]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Three Months Ended December 31, |
|  |  |  |  |  |  | 2021 |  |  | 2020 |
| Operating Activities |  |  |  |  |
| Net income from continuing operations attributable to JCI | $ | 381 |  |  |  | $ | 327 |  |
| Income from continuing operations attributable to noncontrolling interests | 38 |  |  |  | 45 |  |
| Net income from continuing operations | 419 |  |  |  | 372 |  |
| Adjustments to reconcile net income from continuing operations to cash provided by |  |  |  |  |
| operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 224 |  |  |  | 207 |  |
|  |  | Pension and postretirement benefit income | (82) |  |  |  | (46) |  |
|  |  | Pension and postretirement contributions | (41) |  |  |  | (17) |  |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (18) |  |  |  | (52) |  |
|  |  | Deferred income taxes | (32) |  |  |  | (59) |  |
|  |  | Other - net | 1 |  |  |  | (25) |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (75) |  |  |  | 224 |  |
|  |  |  |  | Inventories | (376) |  |  |  | (98) |  |
|  |  |  |  | Other assets | (63) |  |  |  | (70) |  |
|  |  |  |  | Restructuring reserves | 19 |  |  |  | (34) |  |
|  |  |  |  | Accounts payable and accrued liabilities | 333 |  |  |  | 91 |  |
|  |  |  |  | Accrued income taxes | 83 |  |  |  | 22 |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 392 |  |  |  | 515 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (135) |  |  |  | (91) |  |
| Acquisition of businesses, net of cash acquired | (108) |  |  |  | — |  |
| Business divestitures, net of cash divested | 16 |  |  |  | 11 |  |
| Other - net | 9 |  |  |  | 43 |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (218) |  |  |  | (37) |  |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short-term debt - net | 394 |  |  |  | (20) |  |
| Stock repurchases and retirements | (526) |  |  |  | (346) |  |
| Payment of cash dividends | (191) |  |  |  | (190) |  |
| Proceeds from the exercise of stock options | 8 |  |  |  | 31 |  |
| Employee equity-based compensation withholding taxes | (47) |  |  |  | (21) |  |
| Other - net | 5 |  |  |  | (1) |  |
|  |  |  |  |  | Cash used by financing activities from continuing operations | (357) |  |  |  | (547) |  |
| Discontinued Operations |  |  |  |  |
| Net cash used by operating activities | (4) |  |  |  | (36) |  |
| Net cash provided by investing activities | — |  |  |  | — |  |
| Net cash provided by financing activities | — |  |  |  | — |  |
|  |  |  |  |  | Net cash flows used by discontinued operations | (4) |  |  |  | (36) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 67 |  |  |  | (11) |  |
| Changes in cash held for sale | — |  |  |  | — |  |
| Decrease in cash, cash equivalents and restricted cash | $ | (120) |  |  |  | $ | (116) |  |

[0000833444-22-000003:8k_2_02:90]
Page 11 of 17

[0000833444-22-000003:8k_2_02:91]
FOOTNOTES

[0000833444-22-000003:8k_2_02:92]
1. Financial Summary

[0000833444-22-000003:8k_2_02:93]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and the net mark-to-market adjustments related to restricted asbestos investments and pension and postretirement plans. The financial results shown below are for continuing operations and exclude the Power Solutions business. Historical information has been re-cast for changes in the composition of reportable segments effective October 1, 2021, to present the comparative periods on a consistent basis.

[0000833444-22-000003:8k_2_02:94]
| (in millions; unaudited) | Three Months Ended December 31, |
|  | 2021 |  | 2020 |
|  | Actual |  | AdjustedNon-GAAP |  | Actual |  | AdjustedNon-GAAP |
| Net sales (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,152 |  |  | $ | 2,152 |  |  | $ | 2,034 |  |  | $ | 2,034 |  |
| Building Solutions EMEA/LA | 959 |  |  | 959 |  |  | 948 |  |  | 948 |  |
| Building Solutions Asia Pacific | 675 |  |  | 675 |  |  | 604 |  |  | 604 |  |
| Global Products | 2,076 |  |  | 2,076 |  |  | 1,755 |  |  | 1,755 |  |
| Net sales | $ | 5,862 |  |  | $ | 5,862 |  |  | $ | 5,341 |  |  | $ | 5,341 |  |
| Segment EBITA |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 250 |  |  | $ | 250 |  |  | $ | 255 |  |  | $ | 255 |  |
| Building Solutions EMEA/LA | 104 |  |  | 104 |  |  | 98 |  |  | 98 |  |
| Building Solutions Asia Pacific | 68 |  |  | 68 |  |  | 77 |  |  | 77 |  |
| Global Products | 301 |  |  | 301 |  |  | 212 |  |  | 212 |  |
| Segment EBITA (1) | 723 |  |  | 723 |  |  | 642 |  |  | 642 |  |
| Segment EBITA margin | 12.3 | % |  | 12.3 | % |  | 12.0 | % |  | 12.0 | % |
| Corporate expenses | (70) |  |  | (70) |  |  | (67) |  |  | (67) |  |
| Amortization of intangible assets (2) | (118) |  |  | (111) |  |  | (104) |  |  | (104) |  |
| Net mark-to-market adjustments (3) | 57 |  |  | — |  |  | 21 |  |  | — |  |
| Restructuring and impairment costs (4) | (49) |  |  | — |  |  | — |  |  | — |  |
| EBIT (5) | 543 |  |  | 542 |  |  | 492 |  |  | 471 |  |
| EBIT margin | 9.3 | % |  | 9.2 | % |  | 9.2 | % |  | 8.8 | % |
| Net financing charges | (53) |  |  | (53) |  |  | (59) |  |  | (59) |  |
| Income from continuing operations before income taxes | 490 |  |  | 489 |  |  | 433 |  |  | 412 |  |
| Income tax provision (6) | (71) |  |  | (66) |  |  | (61) |  |  | (56) |  |
| Income from continuing operations | 419 |  |  | 423 |  |  | 372 |  |  | 356 |  |
| Income from continuing operations attributable to noncontrolling interests (7) | (38) |  |  | (43) |  |  | (45) |  |  | (45) |  |
| Net income from continuing operations attributable to JCI | $ | 381 |  |  | $ | 380 |  |  | $ | 327 |  |  | $ | 311 |  |

[0000833444-22-000003:8k_2_02:95]
(1) The Company's press release contains financial information regarding adjusted net sales, segment EBITA, adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures. The Company's definition of adjusted net sales and adjusted segment EBITA excludes special items because these items are not considered to be directly related to the underlying operating performance of its businesses. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company. A reconciliation of segment EBITA to income from continuing operations is shown earlier within this footnote. For the three months ended December 31, 2021 and 2020, there were no items excluded from the calculation of adjusted net sales and adjusted segment EBITA.

[0000833444-22-000003:8k_2_02:96]
(2) Adjusted amortization of intangible assets for the three months ended December 31, 2021 excludes $7 million of nonrecurring intangible asset amortization related to Silent-Aire purchase accounting.

[0000833444-22-000003:8k_2_02:97]
(3) The three months ended December 31, 2021 exclude the net mark-to-market adjustments on restricted investments and pension and postretirement plans of $57 million. The three months ended December 31, 2020 exclude the net mark-to-market adjustment on restricted investments of $21 million.

[0000833444-22-000003:8k_2_02:98]
(4) Restructuring and impairment costs for the three months ended December 31, 2021 of $49 million are excluded from the adjusted non-GAAP results. The restructuring actions and impairment costs are related primarily to workforce reductions and other related costs.

[0000833444-22-000003:8k_2_02:99]
(5) Management defines earnings before interest and taxes (EBIT) as income from continuing operations before net financing charges, income taxes and noncontrolling interests. EBIT is a non-GAAP performance measure. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company. A reconciliation of EBIT to income from continuing operations is shown earlier within this footnote.

[0000833444-22-000003:8k_2_02:100]
(6) Adjusted income tax provision for the three months ended December 31, 2021 excludes tax provisions related to net mark-to-market adjustments of $14 million, partially offset by tax benefits related to restructuring and impairment costs of $7 million and Silent-Aire nonrecurring intangible asset amortization of $2 million. Adjusted income tax provision for the three months ended December 31, 2020 excludes tax provision from net mark-to-market adjustments of $5 million.

[0000833444-22-000003:8k_2_02:101]
(7) Adjusted income from continuing operations attributable to noncontrolling interests for the three months ended December 31, 2021 excludes $5 million impact from restructuring and impairment costs.

[0000833444-22-000003:8k_2_02:102]
Page 12 of 17

[0000833444-22-000003:8k_2_02:103]
2.  Diluted Earnings Per Share Reconciliation

[0000833444-22-000003:8k_2_02:104]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include net mark-to-market adjustments, restructuring and impairment costs, Silent-Aire transaction costs and other nonrecurring costs, Power Solutions divestiture reserve adjustment, and discrete tax items. The Company excludes these items because they are not considered to be directly related to the underlying operating performance of the Company. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-22-000003:8k_2_02:105]
A reconciliation of diluted earnings per share as reported to adjusted diluted earnings per share for the respective periods is shown below (unaudited):

[0000833444-22-000003:8k_2_02:106]
|  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc from Continuing Operations |  |  |  |  |
|  | Three Months Ended |  | Three Months Ended |  |  |  |  |
|  | December 31, |  | December 31, |  |  |  |  |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |  |  |  |  |  |  |  |  |
| Earnings per share as reported for JCI plc | $ | 0.54 |  |  | $ | 0.62 |  |  | $ | 0.54 |  |  | $ | 0.45 |  |  |  |  |  |  |  |  |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | (0.08) |  |  | (0.03) |  |  | (0.08) |  |  | (0.03) |  |  |  |  |  |  |  |  |  |
| Related tax impact | 0.02 |  |  | 0.01 |  |  | 0.02 |  |  | 0.01 |  |  |  |  |  |  |  |  |  |
| Restructuring and impairment costs | 0.07 |  |  | — |  |  | 0.07 |  |  | — |  |  |  |  |  |  |  |  |  |
| Related tax impact | (0.01) |  |  | — |  |  | (0.01) |  |  | — |  |  |  |  |  |  |  |  |  |
| NCI impact of restructuring and impairment costs | (0.01) |  |  | — |  |  | (0.01) |  |  | — |  |  |  |  |  |  |  |  |  |
| Power Solutions divestiture reserve adjustment | — |  |  | (0.21) |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Related tax impact | — |  |  | 0.04 |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Silent-Aire transaction costs and other nonrecurring costs | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |  |  |  |  |  |  |  |  |
| Adjusted earnings per share for JCI plc | $ | 0.54 |  |  | $ | 0.43 |  |  | $ | 0.54 |  |  | $ | 0.43 |  |  |  |  |  |  |  |  |  |

[0000833444-22-000003:8k_2_02:107]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-22-000003:8k_2_02:108]
|  | Three Months Ended |  |  |  |  |  |  |
|  | December 31, |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding for JCI plc |  |  |  |  |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 704.3 |  |  | 723.1 |  |  |  |  |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock |  |  |  |  |  |  |  |  |  |  |  |
| and unvested performance share awards | 5.2 |  |  | 3.4 |  |  |  |  |  |  |  |  |  |
| Diluted weighted average shares outstanding | 709.5 |  |  | 726.5 |  |  |  |  |  |  |  |  |  |

[0000833444-22-000003:8k_2_02:109]
The Company has presented forward-looking statements regarding adjusted corporate expense, adjusted EPS, organic revenue, adjusted EBITA margin and free cash flow conversion, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts, expenses, income or cash flows from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts that are excluded from these non-GAAP financial measures are a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period, including but not limited to the high variability of the net mark-to-market adjustments and the effect of foreign currency exchange fluctuations. Our fiscal 2022 second quarter and full year guidance for organic revenue also excludes the effect of acquisitions, divestitures and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available and management cannot reliably predict all of the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s second quarter and full year 2022 GAAP financial results.

[0000833444-22-000003:8k_2_02:110]
Page 13 of 17

[0000833444-22-000003:8k_2_02:111]
3. Organic Growth Reconciliation

[0000833444-22-000003:8k_2_02:112]
The components of the change in net sales for the three months ended December 31, 2021 versus the three months ended December 31, 2020, including organic growth, are shown below (unaudited):

[0000833444-22-000003:8k_2_02:113]
| (in millions) | Net Sales for the Three Months Ended December 31, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the ThreeMonths EndedDecember 31, 2020 |  | Acquisitions |  | Organic Growth |  | Net Sales for the Three Months EndedDecember 31, 2021 |
| Building Solutions North America | $ | 2,034 |  |  | $ | — |  | — |  |  | $ | 6 |  | — |  |  | $ | 2,040 |  |  | $ | 5 |  | — |  |  | $ | 107 |  | 5 | % |  | $ | 2,152 |  | 6 | % |
| Building Solutions EMEA/LA | 948 |  |  | (1) |  | — |  |  | (22) |  | -2 | % |  | 925 |  |  | 8 |  | 1 | % |  | 26 |  | 3 | % |  | 959 |  | 1 | % |
| Building Solutions Asia Pacific | 604 |  |  | (1) |  | — |  |  | (6) |  | -1 | % |  | 597 |  |  | 9 |  | 2 | % |  | 69 |  | 12 | % |  | 675 |  | 12 | % |
| Total field | 3,586 |  |  | (2) |  | — |  |  | (22) |  | -1 | % |  | 3,562 |  |  | 22 |  | 1 | % |  | 202 |  | 6 | % |  | 3,786 |  | 6 | % |
| Global Products | 1,755 |  |  | — |  | — |  |  | (23) |  | -1 | % |  | 1,732 |  |  | 106 |  | 6 | % |  | 238 |  | 14 | % |  | 2,076 |  | 18 | % |
| Total net sales | $ | 5,341 |  |  | $ | (2) |  | — |  |  | $ | (45) |  | -1 | % |  | $ | 5,294 |  |  | $ | 128 |  | 2 | % |  | $ | 440 |  | 8 | % |  | $ | 5,862 |  | 10 | % |

[0000833444-22-000003:8k_2_02:114]
The Company's earnings presentation presents organic growth for each of the periods re-casted as a result of changes in the composition of reportable segments effective October 1, 2021. The components of the change in adjusted net sales, including organic growth, are shown below for the three months ended December 31, 2020 versus the three months ended December 31, 2019, the three months ended March 31, 2021 versus the three months ended March 31, 2020, the three months ended June 30, 2021 versus the three months ended June 30, 2020, the three months ended September 30, 2021 versus the three months ended September 30, 2020, and the twelve months ended September 30, 2021 versus the twelve months ended September 30, 2020 (unaudited).

[0000833444-22-000003:8k_2_02:115]
| (in millions) | Adjusted Net Sales for the Three Months Ended December 31, 2019 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the ThreeMonths EndedDecember 31, 2019 |  | Acquisitions |  | Organic Growth |  | Adjusted Net Sales for the Three Months EndedDecember 31, 2020 |
| Building Solutions North America | $ | 2,167 |  |  | $ | — |  | — |  |  | $ | 3 |  | — |  |  | $ | 2,170 |  |  | $ | — |  | — |  |  | $ | (136) |  | -6 | % |  | $ | 2,034 |  | -6 | % |
| Building Solutions EMEA/LA | 970 |  |  | — |  | — |  |  | 24 |  | 2 | % |  | 994 |  |  | 9 |  | 1 | % |  | (55) |  | -6 | % |  | 948 |  | -2 | % |
| Building Solutions Asia Pacific | 620 |  |  | (2) |  | — |  |  | 28 |  | 5 | % |  | 646 |  |  | — |  | — |  |  | (42) |  | -7 | % |  | 604 |  | -3 | % |
| Total field | 3,757 |  |  | (2) |  | — |  |  | 55 |  | 1 | % |  | 3,810 |  |  | 9 |  | — |  |  | (233) |  | -6 | % |  | 3,586 |  | -5 | % |
| Global Products | 1,819 |  |  | (71) |  | -4 | % |  | 35 |  | 2 | % |  | 1,783 |  |  | — |  | — |  |  | (28) |  | -2 | % |  | 1,755 |  | -4 | % |
| Total net sales | $ | 5,576 |  |  | $ | (73) |  | -1 | % |  | $ | 90 |  | 2 | % |  | $ | 5,593 |  |  | $ | 9 |  | — |  |  | $ | (261) |  | -5 | % |  | $ | 5,341 |  | -4 | % |

[0000833444-22-000003:8k_2_02:116]
| (in millions) | Adjusted Net Sales for the Three Months Ended March 31, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the ThreeMonths EndedMarch 31, 2020 |  | Acquisitions |  | Organic Growth |  | Adjusted Net Sales for the Three Months EndedMarch 31, 2021 |
| Building Solutions North America | $ | 2,175 |  |  | $ | — |  | — |  |  | $ | 13 |  | 1 | % |  | $ | 2,188 |  |  | $ | — |  | — |  |  | $ | (96) |  | -4 | % |  | $ | 2,092 |  | -4 | % |
| Building Solutions EMEA/LA | 891 |  |  | — |  | — |  |  | 44 |  | 5 | % |  | 935 |  |  | 4 |  | — |  |  | (5) |  | -1 | % |  | 934 |  | 5 | % |
| Building Solutions Asia Pacific | 518 |  |  | (2) |  | — |  |  | 29 |  | 6 | % |  | 545 |  |  | — |  | — |  |  | 49 |  | 9 | % |  | 594 |  | 15 | % |
| Total field | 3,584 |  |  | (2) |  | — |  |  | 86 |  | 2 | % |  | 3,668 |  |  | 4 |  | — |  |  | (52) |  | -1 | % |  | 3,620 |  | 1 | % |
| Global Products | 1,860 |  |  | (62) |  | -3 | % |  | 49 |  | 3 | % |  | 1,847 |  |  | — |  | — |  |  | 127 |  | 7 | % |  | 1,974 |  | 6 | % |
| Total net sales | $ | 5,444 |  |  | $ | (64) |  | -1 | % |  | $ | 135 |  | 2 | % |  | $ | 5,515 |  |  | $ | 4 |  | — |  |  | $ | 75 |  | 1 | % |  | $ | 5,594 |  | 3 | % |

[0000833444-22-000003:8k_2_02:117]
| (in millions) | Adjusted Net Sales for the Three Months Ended June 30, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the ThreeMonths EndedJune 30, 2020 |  | Acquisitions |  | Organic Growth |  | Adjusted Net Sales for the Three Months EndedJune 30, 2021 |
| Building Solutions North America | $ | 2,020 |  |  | $ | — |  | — |  |  | $ | 21 |  | 1 | % |  | $ | 2,041 |  |  | $ | — |  | — |  |  | $ | 171 |  | 8 | % |  | $ | 2,212 |  | 10 | % |
| Building Solutions EMEA/LA | 795 |  |  | — |  | — |  |  | 60 |  | 8 | % |  | 855 |  |  | 10 |  | 1 | % |  | 136 |  | 16 | % |  | 1,001 |  | 26 | % |
| Building Solutions Asia Pacific | 579 |  |  | (3) |  | -1 | % |  | 40 |  | 7 | % |  | 616 |  |  | — |  | — |  |  | 87 |  | 14 | % |  | 703 |  | 21 | % |
| Total field | 3,394 |  |  | (3) |  | — |  |  | 121 |  | 4 | % |  | 3,512 |  |  | 10 |  | — |  |  | 394 |  | 11 | % |  | 3,916 |  | 15 | % |
| Global Products | 1,949 |  |  | (54) |  | -3 | % |  | 44 |  | 2 | % |  | 1,939 |  |  | 80 |  | 4 | % |  | 409 |  | 21 | % |  | 2,428 |  | 25 | % |
| Total net sales | $ | 5,343 |  |  | $ | (57) |  | -1 | % |  | $ | 165 |  | 3 | % |  | $ | 5,451 |  |  | $ | 90 |  | 2 | % |  | $ | 803 |  | 15 | % |  | $ | 6,344 |  | 19 | % |

[0000833444-22-000003:8k_2_02:118]
| (in millions) | Adjusted Net Sales for the Three Months Ended September 30, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the ThreeMonths EndedSeptember 30, 2020 |  | Acquisitions |  | Organic Growth |  | Adjusted Net Sales for the Three Months EndedSeptember 30, 2021 |
| Building Solutions North America | $ | 2,243 |  |  | $ | — |  | — |  |  | $ | 12 |  | 1 | % |  | $ | 2,255 |  |  | $ | 4 |  | — |  |  | $ | 88 |  | 4 | % |  | $ | 2,347 |  | 5 | % |
| Building Solutions EMEA/LA | 957 |  |  | — |  | — |  |  | 17 |  | 2 | % |  | 974 |  |  | 14 |  | 1 | % |  | 13 |  | 1 | % |  | 1,001 |  | 5 | % |
| Building Solutions Asia Pacific | 651 |  |  | (2) |  | — |  |  | 18 |  | 3 | % |  | 667 |  |  | — |  | — |  |  | 48 |  | 7 | % |  | 715 |  | 10 | % |
| Total field | 3,851 |  |  | (2) |  | — |  |  | 47 |  | 1 | % |  | 3,896 |  |  | 18 |  | — |  |  | 149 |  | 4 | % |  | 4,063 |  | 6 | % |
| Global Products | 2,103 |  |  | (79) |  | -4 | % |  | 10 |  | — |  |  | 2,034 |  |  | 132 |  | 6 | % |  | 166 |  | 8 | % |  | 2,332 |  | 11 | % |
| Total net sales | $ | 5,954 |  |  | $ | (81) |  | -1 | % |  | $ | 57 |  | 1 | % |  | $ | 5,930 |  |  | $ | 150 |  | 3 | % |  | $ | 315 |  | 5 | % |  | $ | 6,395 |  | 7 | % |

[0000833444-22-000003:8k_2_02:119]
| (in millions) | Adjusted Net Sales for the Twelve Months Ended September 30, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the TwelveMonths EndedSeptember 30, 2020 |  | Acquisitions |  | Organic Growth |  | Adjusted Net Sales for the TwelveMonths EndedSeptember 30, 2021 |
| Building Solutions North America | $ | 8,605 |  |  | $ | — |  | — |  |  | $ | 49 |  | 1 | % |  | $ | 8,654 |  |  | $ | 4 |  | — |  |  | $ | 27 |  | — |  |  | $ | 8,685 |  | 1 | % |
| Building Solutions EMEA/LA | 3,613 |  |  | — |  | — |  |  | 145 |  | 4 | % |  | 3,758 |  |  | 37 |  | 1 | % |  | 89 |  | 2 | % |  | 3,884 |  | 8 | % |
| Building Solutions Asia Pacific | 2,368 |  |  | (9) |  | — |  |  | 115 |  | 5 | % |  | 2,474 |  |  | — |  | — |  |  | 142 |  | 6 | % |  | 2,616 |  | 10 | % |
| Total field | 14,586 |  |  | (9) |  | — |  |  | 309 |  | 2 | % |  | 14,886 |  |  | 41 |  | — |  |  | 258 |  | 2 | % |  | 15,185 |  | 4 | % |
| Global Products | 7,731 |  |  | (266) |  | -3 | % |  | 138 |  | 2 | % |  | 7,603 |  |  | 212 |  | 3 | % |  | 674 |  | 9 | % |  | 8,489 |  | 10 | % |
| Total net sales | $ | 22,317 |  |  | $ | (275) |  | -1 | % |  | $ | 447 |  | 2 | % |  | $ | 22,489 |  |  | $ | 253 |  | 1 | % |  | $ | 932 |  | 4 | % |  | $ | 23,674 |  | 6 | % |

[0000833444-22-000003:8k_2_02:120]
Page 14 of 17

[0000833444-22-000003:8k_2_02:121]
The organic growth reconciliations presented earlier within this footnote contain financial information regarding adjusted net sales. The following is the reconciliation of net sales as re-casted to adjusted net sales for the three months ended December 31, 2020 and 2019, the three months ended March 31, 2021 and 2020, the three months ended June 30, 2021 and 2020, the three months ended September 30, 2021 and 2020, and the twelve months ended September 30, 2021 and 2020 (unaudited):

[0000833444-22-000003:8k_2_02:122]
|  | Three Months Ended |  | Twelve Months Ended |
|  | December 31, |  | March 31, |  | June 30, |  | September 30, |  | September 30, |
| (in millions) | 2020 |  | 2019 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales as re-casted |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,034 |  |  | $ | 2,167 |  |  | $ | 2,092 |  |  | $ | 2,175 |  |  | $ | 2,212 |  |  | $ | 2,020 |  |  | $ | 2,347 |  |  | $ | 2,243 |  |  | $ | 8,685 |  |  | $ | 8,605 |  |
| Building Solutions EMEA/LA | 948 |  |  | 970 |  |  | 934 |  |  | 891 |  |  | 1,001 |  |  | 795 |  |  | 1,001 |  |  | 957 |  |  | 3,884 |  |  | 3,613 |  |
| Building Solutions Asia Pacific | 604 |  |  | 620 |  |  | 594 |  |  | 518 |  |  | 703 |  |  | 579 |  |  | 715 |  |  | 651 |  |  | 2,616 |  |  | 2,368 |  |
| Global Products | 1,755 |  |  | 1,819 |  |  | 1,974 |  |  | 1,860 |  |  | 2,425 |  |  | 1,949 |  |  | 2,329 |  |  | 2,103 |  |  | 8,483 |  |  | 7,731 |  |
| Net Sales as re-casted | 5,341 |  |  | 5,576 |  |  | 5,594 |  |  | 5,444 |  |  | 6,341 |  |  | 5,343 |  |  | 6,392 |  |  | 5,954 |  |  | 23,668 |  |  | 22,317 |  |
| Adjusting items (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Building Solutions North America | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Building Solutions EMEA/LA | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Building Solutions Asia Pacific | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Global Products | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |  | — |  |  | 6 |  |  | — |  |
| Adjusting items | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |  | — |  |  | 6 |  |  | — |  |
| Adjusted net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Building Solutions North America | 2,034 |  |  | 2,167 |  |  | 2,092 |  |  | 2,175 |  |  | 2,212 |  |  | 2,020 |  |  | 2,347 |  |  | 2,243 |  |  | 8,685 |  |  | 8,605 |  |
| Building Solutions EMEA/LA | 948 |  |  | 970 |  |  | 934 |  |  | 891 |  |  | 1,001 |  |  | 795 |  |  | 1,001 |  |  | 957 |  |  | 3,884 |  |  | 3,613 |  |
| Building Solutions Asia Pacific | 604 |  |  | 620 |  |  | 594 |  |  | 518 |  |  | 703 |  |  | 579 |  |  | 715 |  |  | 651 |  |  | 2,616 |  |  | 2,368 |  |
| Global Products | 1,755 |  |  | 1,819 |  |  | 1,974 |  |  | 1,860 |  |  | 2,428 |  |  | 1,949 |  |  | 2,332 |  |  | 2,103 |  |  | 8,489 |  |  | 7,731 |  |
| Adjusted net sales | $ | 5,341 |  |  | $ | 5,576 |  |  | $ | 5,594 |  |  | $ | 5,444 |  |  | $ | 6,344 |  |  | $ | 5,343 |  |  | $ | 6,395 |  |  | $ | 5,954 |  |  | $ | 23,674 |  |  | $ | 22,317 |  |

[0000833444-22-000003:8k_2_02:123]
(1) Adjusting items to net sales relate to nonrecurring Silent-Aire purchase accounting impacts.

[0000833444-22-000003:8k_2_02:124]
The components of the change in service revenue for the three months ended December 31, 2021 versus the three months ended December 31, 2020, including organic growth, are shown below (unaudited):

[0000833444-22-000003:8k_2_02:125]
| (in millions) | Proforma ServiceRevenue for the Three Months EndedDecember 31, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base ServiceRevenue for the ThreeMonths EndedDecember 31, 2020 |  | Acquisitions |  | Organic Growth |  | Service Revenue for the Three Months EndedDecember 31, 2021 |
| Building Solutions North America | $ | 792 |  |  | $ | — |  | — |  |  | $ | 3 |  | — |  |  | $ | 795 |  |  | $ | 4 |  | 1 | % |  | $ | 55 |  | 7 | % |  | $ | 854 |  | 8 | % |
| Building Solutions EMEA/LA | 417 |  |  | (1) |  | — |  |  | (11) |  | -3 | % |  | 405 |  |  | 1 |  | — |  |  | 9 |  | 2 | % |  | 415 |  | — |  |
| Building Solutions Asia Pacific | 168 |  |  | (1) |  | -1 | % |  | (2) |  | -1 | % |  | 165 |  |  | 3 |  | 2 | % |  | 6 |  | 4 | % |  | 174 |  | 4 | % |
| Total field | 1,377 |  |  | (2) |  | — |  |  | (10) |  | -1 | % |  | 1,365 |  |  | 8 |  | 1 | % |  | 70 |  | 5 | % |  | 1,443 |  | 5 | % |
| Global Products | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |
| Total service revenue | $ | 1,377 |  |  | $ | (2) |  | — |  |  | $ | (10) |  | -1 | % |  | $ | 1,365 |  |  | $ | 8 |  | 1 | % |  | $ | 70 |  | 5 | % |  | $ | 1,443 |  | 5 | % |

[0000833444-22-000003:8k_2_02:126]
The Company's earnings presentation presents proforma service revenue and organic growth for the three months ended December 31, 2020, the three months ended March 31, 2021, the three months ended June 30, 2021, the three months ended September 30, 2021, and the twelve months ended September 30, 2021. The components of the change in proforma service revenue, including organic growth, for each period for which proforma financial information is presented are shown below (unaudited).

[0000833444-22-000003:8k_2_02:127]
| (in millions) | Proforma ServiceRevenue for the Three Months EndedDecember 31, 2019 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base ServiceRevenue for the ThreeMonths EndedDecember 31, 2019 |  | Acquisitions |  | Organic Growth |  | Proforma Service Revenue for theThree Months EndedDecember 31, 2020 |
| Building Solutions North America | $ | 811 |  |  | $ | — |  | — |  |  | $ | 1 |  | — |  |  | $ | 812 |  |  | $ | — |  | — |  |  | $ | (20) |  | -2 | % |  | $ | 792 |  | -2 | % |
| Building Solutions EMEA/LA | 414 |  |  | — |  | — |  |  | 5 |  | 1 | % |  | 419 |  |  | 3 |  | 1 | % |  | (5) |  | -1 | % |  | 417 |  | 1 | % |
| Building Solutions Asia Pacific | 165 |  |  | (2) |  | -1 | % |  | 7 |  | 4 | % |  | 170 |  |  | — |  | — |  |  | (2) |  | -1 | % |  | 168 |  | 2 | % |
| Total field | 1,390 |  |  | (2) |  | — |  |  | 13 |  | 1 | % |  | 1,401 |  |  | 3 |  | — |  |  | (27) |  | -2 | % |  | 1,377 |  | -1 | % |
| Global Products | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |
| Total service revenue | $ | 1,390 |  |  | $ | (2) |  | — |  |  | $ | 13 |  | 1 | % |  | $ | 1,401 |  |  | $ | 3 |  | — |  |  | $ | (27) |  | -2 | % |  | $ | 1,377 |  | -1 | % |

[0000833444-22-000003:8k_2_02:128]
| (in millions) | Proforma ServiceRevenue for the Three Months EndedMarch 31, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base ServiceRevenue for the ThreeMonths EndedMarch 31, 2020 |  | Acquisitions |  | Organic Growth |  | Proforma Service Revenue for theThree Months EndedMarch 31, 2021 |
| Building Solutions North America | $ | 818 |  |  | $ | — |  | — |  |  | $ | 4 |  | — |  |  | $ | 822 |  |  | $ | — |  | — |  |  | $ | (2) |  | — |  |  | $ | 820 |  | — |  |
| Building Solutions EMEA/LA | 396 |  |  | — |  | — |  |  | 16 |  | 4 | % |  | 412 |  |  | 2 |  | — |  |  | (7) |  | -2 | % |  | 407 |  | 3 | % |
| Building Solutions Asia Pacific | 160 |  |  | (2) |  | -1 | % |  | 11 |  | 7 | % |  | 169 |  |  | — |  | — |  |  | 2 |  | 1 | % |  | 171 |  | 7 | % |
| Total field | 1,374 |  |  | (2) |  | — |  |  | 31 |  | 2 | % |  | 1,403 |  |  | 2 |  | — |  |  | (7) |  | — |  |  | 1,398 |  | 2 | % |
| Global Products | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |
| Total service revenue | $ | 1,374 |  |  | $ | (2) |  | — |  |  | $ | 31 |  | 2 | % |  | $ | 1,403 |  |  | $ | 2 |  | — |  |  | $ | (7) |  | — |  |  | $ | 1,398 |  | 2 | % |

[0000833444-22-000003:8k_2_02:129]
Page 15 of 17

[0000833444-22-000003:8k_2_02:130]
| (in millions) | Proforma ServiceRevenue for theThree Months EndedJune 30, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base ServiceRevenue for the ThreeMonths EndedJune 30, 2020 |  | Acquisitions |  | Organic Growth |  | Proforma Service Revenue for theThree Months EndedJune 30, 2021 |
| Building Solutions North America | $ | 770 |  |  | $ | — |  | — |  |  | $ | 9 |  | 1 | % |  | $ | 779 |  |  | $ | — |  | — |  |  | $ | 78 |  | 10 | % |  | $ | 857 |  | 11 | % |
| Building Solutions EMEA/LA | 349 |  |  | — |  | — |  |  | 26 |  | 7 | % |  | 375 |  |  | 4 |  | 1 | % |  | 48 |  | 13 | % |  | 427 |  | 22 | % |
| Building Solutions Asia Pacific | 156 |  |  | (3) |  | -2 | % |  | 12 |  | 8 | % |  | 165 |  |  | — |  | — |  |  | 18 |  | 11 | % |  | 183 |  | 17 | % |
| Total field | 1,275 |  |  | (3) |  | — |  |  | 47 |  | 4 | % |  | 1,319 |  |  | 4 |  | — |  |  | 144 |  | 11 | % |  | 1,467 |  | 15 | % |
| Global Products | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |
| Total service revenue | $ | 1,275 |  |  | $ | (3) |  | — |  |  | $ | 47 |  | 4 | % |  | $ | 1,319 |  |  | $ | 4 |  | — |  |  | $ | 144 |  | 11 | % |  | $ | 1,467 |  | 15 | % |

[0000833444-22-000003:8k_2_02:131]
| (in millions) | Proforma ServiceRevenue for theThree Months EndedSeptember 30, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base ServiceRevenue for the ThreeMonths EndedSeptember 30, 2020 |  | Acquisitions |  | Organic Growth |  | Proforma Service Revenue for theThree Months EndedSeptember 30, 2021 |
| Building Solutions North America | $ | 835 |  |  | $ | — |  | — |  |  | $ | 4 |  | — |  |  | $ | 839 |  |  | $ | 3 |  | — |  |  | $ | 62 |  | 7 | % |  | $ | 904 |  | 8 | % |
| Building Solutions EMEA/LA | 435 |  |  | — |  | — |  |  | 6 |  | 1 | % |  | 441 |  |  | 1 |  | — |  |  | (9) |  | -2 | % |  | 433 |  | — |  |
| Building Solutions Asia Pacific | 180 |  |  | (2) |  | -1 | % |  | 4 |  | 2 | % |  | 182 |  |  | — |  | — |  |  | 2 |  | 1 | % |  | 184 |  | 2 | % |
| Total field | 1,450 |  |  | (2) |  | — |  |  | 14 |  | 1 | % |  | 1,462 |  |  | 4 |  | — |  |  | 55 |  | 4 | % |  | 1,521 |  | 5 | % |
| Global Products | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |
| Total service revenue | $ | 1,450 |  |  | $ | (2) |  | — |  |  | $ | 14 |  | 1 | % |  | $ | 1,462 |  |  | $ | 4 |  | — |  |  | $ | 55 |  | 4 | % |  | $ | 1,521 |  | 5 | % |

[0000833444-22-000003:8k_2_02:132]
| (in millions) | Proforma ServiceRevenue for theTwelve Months EndedSeptember 30, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base ServiceRevenue for the Twelve Months EndedSeptember 30, 2020 |  | Acquisitions |  | Organic Growth |  | Proforma Service Revenue for theTwelve Months EndedSeptember 30, 2021 |
| Building Solutions North America | $ | 3,234 |  |  | $ | — |  | — |  |  | $ | 18 |  | 1 | % |  | $ | 3,252 |  |  | $ | 3 |  | — |  |  | $ | 118 |  | 4 | % |  | $ | 3,373 |  | 4 | % |
| Building Solutions EMEA/LA | 1,594 |  |  | — |  | — |  |  | 53 |  | 3 | % |  | 1,647 |  |  | 10 |  | 1 | % |  | 27 |  | 2 | % |  | 1,684 |  | 6 | % |
| Building Solutions Asia Pacific | 661 |  |  | (9) |  | -1 | % |  | 34 |  | 5 | % |  | 686 |  |  | — |  | — |  |  | 20 |  | 3 | % |  | 706 |  | 7 | % |
| Total field | 5,489 |  |  | (9) |  | — |  |  | 105 |  | 2 | % |  | 5,585 |  |  | 13 |  | — |  |  | 165 |  | 3 | % |  | 5,763 |  | 5 | % |
| Global Products | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |
| Total service revenue | $ | 5,489 |  |  | $ | (9) |  | — |  |  | $ | 105 |  | 2 | % |  | $ | 5,585 |  |  | $ | 13 |  | — |  |  | $ | 165 |  | 3 | % |  | $ | 5,763 |  | 5 | % |

[0000833444-22-000003:8k_2_02:133]
4.   Free Cash Flow Conversion

[0000833444-22-000003:8k_2_02:134]
The Company's press release contains financial information regarding free cash flow and free cash flow conversion, which are non-GAAP performance measures. Free cash flow is defined as cash provided by operating activities less capital expenditures. Free cash flow conversion is defined as free cash flow divided by adjusted net

[0000833444-22-000003:8k_2_02:135]
income attributable to JCI. Management believes these non-GAAP measures are useful to investors in understanding the strength of the Company and its ability to generate cash. These non-GAAP measures can also be used to evaluate our ability to generate cash flow from operations and the impact that this cash flow has on our liquidity.

[0000833444-22-000003:8k_2_02:136]
The following is the three months ended December 31, 2021 and 2020 reconciliation of free cash flow and free cash flow conversion for continuing operations (unaudited):

[0000833444-22-000003:8k_2_02:137]
|  | Three Months Ended |  |  |  |  |  |
| (in millions) | December 31, 2021 |  | December 31, 2020 |  |  |  |  |  |  |  |
| Cash provided by operating activities from continuing |  |  |  |  |  |  |  |  |  |  |
| operations | $ | 392 |  | $ | 515 |  |  |  |  |  |  |  |
| Capital expenditures | (135) |  | (91) |  |  |  |  |  |  |  |
| Reported free cash flow | 257 |  | 424 |  |  |  |  |  |  |  |
| Adjusted net income from continuing operations |  |  |  |  |  |  |  |  |  |  |
| attributable to JCI | $ | 380 |  | $ | 311 |  |  |  |  |  |  |  |
| Free cash flow conversion | 68 | % |  | 136 | % |  |  |  |  |  |  |  |

[0000833444-22-000003:8k_2_02:138]
Page 16 of 17

[0000833444-22-000003:8k_2_02:139]
5.  Net Debt to EBITDA

[0000833444-22-000003:8k_2_02:140]
The Company provides financial information regarding net debt to adjusted EBITDA, which is a non-GAAP performance measure. The Company believes the total net debt to adjusted EBITDA ratio is useful to understanding the Company's financial condition as it provides a view of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders. The following is the December 31, 2021 calculation of net debt to adjusted EBITDA (unaudited):

[0000833444-22-000003:8k_2_02:141]
| (in millions) | December 31, 2021 |  |  |
| Short-term debt and current portion of long-term debt | $ | 612 |  |  |  |
| Long-term debt | 7,437 |  |  |  |
| Total debt | 8,049 |  |  |  |
| Less: cash and cash equivalents | 1,207 |  |  |  |
| Total net debt | $ | 6,842 |  |  |  |
| Last twelve months adjusted EBITDA | $ | 3,599 |  |  |  |
| Total net debt to adjusted EBITDA | 1.9x |  |  |

[0000833444-22-000003:8k_2_02:142]
The following is the last twelve months ended December 31, 2021 reconciliation of income from continuing operations to adjusted EBIT and adjusted EBITDA, which are non-GAAP performance measures (unaudited):

[0000833444-22-000003:8k_2_02:143]
| (in millions) | Last Twelve MonthsEndedDecember 31, 2021 |  |  |
| Income from continuing operations | $ | 1,793 |  |  |  |
| Income tax provision | 878 |  |  |  |
| Net financing charges | 200 |  |  |  |
| EBIT | 2,871 |  |  |  |
| Adjusting items: |  |  |  |
| Net mark-to-market adjustments | (438) |  |  |  |
| Restructuring and impairment costs | 291 |  |  |  |
| Silent-Aire transaction and other nonrecurring costs | 30 |  |  |  |
| Adjusted EBIT (1) | 2,754 |  |  |  |
| Depreciation and amortization | 845 |  |  |  |
| Adjusted EBITDA (1) | $ | 3,599 |  |  |  |

[0000833444-22-000003:8k_2_02:144]
(1) The Company's definition of adjusted EBIT and adjusted EBITDA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its businesses. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-22-000003:8k_2_02:145]
6.  Trade Working Capital as a Percentage of Net Sales

[0000833444-22-000003:8k_2_02:146]
The Company provides financial information regarding trade working capital as a percentage of net sales, which is a non-GAAP performance measure. Trade working capital is defined as current assets less current liabilities, excluding cash and cash equivalents, short-term debt, the current portion of long-term debt, the current portion of assets and liabilities held for sale, accrued compensation and benefits, and other current assets and liabilities. Management believes this non-GAAP measure, which excludes financing-related items, non-trade related items and businesses to be divested, is a more useful measurement of the Company's operating performance. The following is the December 31, 2021 and December 31, 2020 calculation of trade working capital as a percentage of net sales (unaudited):

[0000833444-22-000003:8k_2_02:147]
| (in millions) | December 31, 2021 |  | December 31, 2020 |
| Current assets | $ | 10,353 |  |  | $ | 10,034 |  |
| Current liabilities | (9,987) |  |  | (8,486) |  |
| Total working capital | 366 |  |  | 1,548 |  |
| Less: cash and cash equivalents | (1,207) |  |  | (1,839) |  |
| Less: other current assets | (1,050) |  |  | (1,105) |  |
| Add: short-term debt | 392 |  |  | 11 |  |
| Add: current portion of long-term debt | 220 |  |  | 453 |  |
| Add: accrued compensation and benefits | 926 |  |  | 836 |  |
| Add: other current liabilities | 2,521 |  |  | 2,393 |  |
| Trade working capital | $ | 2,168 |  |  | $ | 2,297 |  |
| Last twelve months net sales | $ | 24,189 |  |  | $ | 22,082 |  |
| Trade working capital as a percentage of net sales | 9.0 | % |  | 10.4 | % |

[0000833444-22-000003:8k_2_02:148]
7.  Income Taxes

[0000833444-22-000003:8k_2_02:149]
The Company's effective tax rate from continuing operations before consideration of net mark-to-market adjustments, restructuring and impairment costs and discrete tax items for the three months ending December 31, 2021 and December 31, 2020 is approximately 13.5%.

[0000833444-22-000003:8k_2_02:150]
8.  Restructuring and Impairment Costs

[0000833444-22-000003:8k_2_02:151]
The three months ended December 31, 2021 include restructuring and impairment costs of $49 million related primarily to workforce reductions and other related costs.

[0000833444-22-000003:8k_2_02:152]
Page 17 of 17
