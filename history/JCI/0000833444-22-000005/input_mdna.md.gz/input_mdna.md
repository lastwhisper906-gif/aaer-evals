# JCI MD&A — 0000833444-22-000005


## mdna

[0000833444-22-000005:mdna:1]
[same as prior period, unchanged from 0000833444-21-000040:mdna:1]

[0000833444-22-000005:mdna:2]
[same as prior period, unchanged from 0000833444-21-000040:mdna:2]

[0000833444-22-000005:mdna:3]
[same as prior period, unchanged from 0000833444-21-000040:mdna:3]

[0000833444-22-000005:mdna:4]
[same as prior period, unchanged from 0000833444-21-000040:mdna:4]

[0000833444-22-000005:mdna:5]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, healthy and sustainable buildings, serving a wide range of customers in more than 150 countries. The Company’s products, services, systems and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-22-000005:mdna:6]
The Company is a global leader in engineering, manufacturing and commissioning building products and systems, including residential and commercial HVAC equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions powered by its OpenBlue software platform and related digital capabilities. The Company partners with customers by leveraging its broad product portfolio and digital capabilities powered by OpenBlue, together with its direct channel service and solutions

[0000833444-22-000005:mdna:7]
capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency and reduce greenhouse gas emissions.

[0000833444-22-000005:mdna:8]
The following information should be read in conjunction with the September 30, 2021 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in our Annual Report on Form 10-K for the year ended September 30, 2021 filed with the SEC on November 15, 2021. References in the following discussion and analysis to "Three Months" (or similar language) refer to the three months ended December 31, 2021 compared to the three months ended December 31, 2020.

[0000833444-22-000005:mdna:9]
Macroeconomic Trends

[0000833444-22-000005:mdna:10]
Much of the demand for installation of the Company’s products and solutions is driven by commercial and residential construction and industrial facility expansion and maintenance projects. Commercial and residential construction projects are heavily dependent on general economic conditions, localized demand for commercial and residential real estate and availability of credit. Positive or negative fluctuations in commercial and residential construction, industrial facility expansion and maintenance projects and other capital investments in buildings could have a corresponding impact on the Company’s financial condition, results of operations and cash flows.

[0000833444-22-000005:mdna:11]
As a result of the Company’s global presence, a significant portion of its revenues and expenses is denominated in currencies other than the U.S. dollar. The Company is therefore subject to non-U.S. currency risks and non-U.S. exchange exposure. While the Company employs financial instruments to hedge some of its transactional foreign exchange exposure, these activities do not insulate it completely from those exposures. Exchange rates can be volatile and a substantial weakening or strengthening of foreign currencies against the U.S. dollar could increase or reduce the Company’s profit margin in various locations outside of the U.S. and impact the comparability of results from period to period.

[0000833444-22-000005:mdna:12]
The Company continues to observe trends demonstrating increased interest and demand for safe, efficient and sustainable buildings, and seeks to capitalize on these trends to drive growth by developing and delivering technologies and solutions to create smart and healthy buildings. In 2020, the Company launched its software platform, OpenBlue, enabling enterprises to manage all aspects of their physical spaces delivering sustainability, new occupant experiences, and safety and security by combining the Company’s building expertise with cutting-edge technology, including AI-powered service solutions such as remote diagnostics, predictive maintenance, compliance monitoring and advanced risk assessments. The Company continues to leverage its install base, together with data-driven products and services to offer outcome-based solutions to customers with a focus on generating accelerated growth in services and recurring revenue for the Company. The Company has committed to investing in new product research and development in climate-related innovation to develop sustainable products and services.

[0000833444-22-000005:mdna:13]
The Company has experienced, and expects to continue to experience, increased input material cost inflation and component shortages, as well as disruptions and delays in its supply chain, as a result of global macroeconomic trends (including increased global demand), government-mandated actions in response to COVID-19 and labor shortages. Actions taken by the Company to mitigate supply chain disruptions and inflation, including expanding and redistributing its supplier network, supplier financing, price increases and productivity improvements, have generally been successful in offsetting some, but not all, of the impact of these trends. These trends have continued to negatively impact the Company’s revenue and margins during the first quarter of fiscal year 2022, and it is expected these trends will continue to be a headwind for the remainder of fiscal 2022. Therefore, the Company could experience further disruptions, shortages and price increases in the future, the effect of which will depend on the Company’s ability to successfully mitigate and offset the impact of these events.

[0000833444-22-000005:mdna:14]
[same as prior period, unchanged from 0000833444-21-000040:mdna:12]

[0000833444-22-000005:mdna:15]
The global outbreak of COVID-19 severely restricted the level of economic activity around the world and caused a significant contraction in the global economy.

[0000833444-22-000005:mdna:16]
The Company’s affiliates, employees, suppliers, customers and others have been and may continue to be restricted or prevented from conducting normal business activities, including as a result of shutdowns, travel restrictions and other actions that may be requested or mandated by governmental authorities. Although shutdown orders and similar restrictions have been lifted in many jurisdictions in conjunction with the global distribution of vaccines, challenges in achieving sufficient vaccination levels and the spread of new variants of COVID-19 have caused some governments to extend or reinstitute restrictions in impacted areas. During the first quarter of fiscal 2022, the Company’s facilities generally operated at normal levels.

[0000833444-22-000005:mdna:17]
The Company continues to focus its efforts on preserving the health and safety of its employees and customers, as well as maintaining the continuity of its operations. The Company modified its business practices in response to the COVID-19 outbreak, including restricting non-essential employee travel, implementing remote work protocols, and limiting physical participation in meetings, events and conferences. The Company also instituted preventive measures at its facilities, including enhanced health and safety protocols, temperature screening, requiring face coverings for all unvaccinated employees and encouraging employees to follow similar protocols when away from work. The Company has adopted and implemented a multifaceted framework to guide its decision making as it reopens its offices and facilities to employees, and will continue to monitor and audit its facilities to ensure that they are in compliance with the Company’s COVID-19 safety requirements.

[0000833444-22-000005:mdna:18]
The Company has experienced increases in both demand and volumes as governments have distributed vaccines and lifted COVID-19-related restrictions, leading to increases in retrofit activity and, to a lesser extent, commercial building construction. The global pandemic has also provided the Company with the opportunity to help its customers by delivering solutions and support that enhance the safety and increase the efficiency of their operations. As a result of the pandemic, the Company has seen an increase in demand for its products and solutions that promote building health and optimize customers’ infrastructure.

[0000833444-22-000005:mdna:19]
However, the Company continues to be influenced by COVID-19-related trends impacting site access and the labor force, which have and may continue to negatively impact the Company’s revenues and margins. Challenges in reaching sufficient vaccination levels and the introduction of new variants of COVID-19 have caused some governments to extend or reinstitute lockdowns and similar restrictive measures, which, in some cases, have limited the Company’s ability to access customer sites to install and maintain its products and deliver services. In addition, the Company has experienced and continues to experience labor shortages at certain facilities as the Company expands its production capacity to meet increased customer demand. Although the Company is mitigating these shortages through focused recruitment efforts and competitive compensation packages, the Company could continue to experience such shortages in the future. Recently, the U.S. Government has promulgated orders mandating vaccinations or regular COVID-19 testing for large employers and federal contractors. Similar mandates have also been imposed by local governments and certain of the Company’s customers. The Company’s efforts to comply with these mandates, including requiring that some or all of its employees be fully vaccinated against COVID-19, could result in increased labor attrition or disruption, and could adversely impact the Company’s ability to deliver services to its customers.

[0000833444-22-000005:mdna:20]
The extent to which the COVID-19 pandemic continues to impact the Company’s results of operations and financial condition will depend on future developments that are highly uncertain and cannot be predicted, including the resurgence of COVID-19 and its variants in regions recovering from the impacts of the pandemic, the effectiveness of COVID-19 vaccines and the speed at which populations are vaccinated around the globe, the impact of COVID-19 on economic activity, and regulatory actions taken to contain its impact on public health and the global economy. See Part I, Item 1A, of the Company’s Annual Report on Form 10-K for the year ended September 30, 2021 for an additional discussion of risks related to COVID-19.

[0000833444-22-000005:mdna:21]
[same as prior period, unchanged from 0000833444-21-000040:mdna:23]

[0000833444-22-000005:mdna:22]
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company has committed to various restructuring plans. In fiscal 2021, the Company announced its plans to optimize its cost structure through broad-based SG&A actions focused on simplification, standardization and centralization, with the intent to deliver annualized savings of $300 million by fiscal 2023. Additionally, the Company announced cost of sales actions to drive $250 million in annual run rate savings by fiscal 2023. The Company believes it is on track to deliver the productivity savings by fiscal 2023. For more information on the Company’s restructuring plans, see “Liquidity and Capital Resources—Restructuring.”

[0000833444-22-000005:mdna:23]
41

[0000833444-22-000005:mdna:24]
[same as prior period, unchanged from 0000833444-21-000040:mdna:26]

[0000833444-22-000005:mdna:25]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
| Net sales | $ | 5,862 |  |  | $ | 5,341 |  |  | 10 | % |  |  |  |  |  |  |

[0000833444-22-000005:mdna:26]
The increase in consolidated net sales for the three months ended December 31, 2021 was due to higher organic sales ($440 million) and incremental sales from acquisitions ($128 million), partially offset by the unfavorable impact of foreign currency translation ($45 million) and lower sales due to business divestitures ($2 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales increased 8% as compared to the prior year, attributable to higher volumes and increased pricing in response to inflation pressures. Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-22-000005:mdna:27]
[same as prior period, unchanged from 0000833444-21-000040:mdna:30]

[0000833444-22-000005:mdna:28]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
| Cost of sales | $ | 3,971 |  |  | $ | 3,613 |  |  | 10 | % |  |  |  |  |  |  |
| Gross profit | 1,891 |  |  | 1,728 |  |  | 9 | % |  |  |  |  |  |  |
| % of sales | 32.3 | % |  | 32.4 | % |  |  |  |  |  |  |  |  |

[0000833444-22-000005:mdna:29]
Cost of sales and gross profit increased for the three-month period ended December 31, 2021, and gross profit as a percentage of sales decreased by 10 basis points. Gross profit increased due to organic sales growth, business acquisitions, favorable foreign currency translation ($34 million) and the favorable year-over-year impact of net mark-to-market adjustments on pension plans ($9 million). Gross profit as a percentage of sales decreased slightly as the benefit of volume leverage was more than offset by supply chain inefficiencies and price/cost pressures.  Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA").

[0000833444-22-000005:mdna:30]
[same as prior period, unchanged from 0000833444-21-000040:mdna:35]

[0000833444-22-000005:mdna:31]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
| Selling, general and administrative expenses | $ | 1,369 |  |  | $ | 1,294 |  |  | 6 | % |  |  |  |  |  |  |
| % of sales | 23.4 | % |  | 24.2 | % |  |  |  |  |  |  |  |  |

[0000833444-22-000005:mdna:32]
Selling, general and administrative expenses ("SG&A") for the three-month period ended December 31, 2021 increased $75 million, and SG&A as a percentage of sales decreased by 80 basis points. The increase in SG&A was primarily due to the absence of certain one-time cost mitigation actions, incremental sales investments and current year business acquisitions, partially offset by the favorable year-over-year impact of net mark-to-market adjustments on pension plans ($34 million). Foreign currency translation had a favorable impact on SG&A of $10 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA.

[0000833444-22-000005:mdna:33]
42

[0000833444-22-000005:mdna:34]
[same as prior period, unchanged from 0000833444-21-000040:mdna:39]

[0000833444-22-000005:mdna:35]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
| Restructuring and impairment costs | $ | 49 |  |  | $ | — |  |  | * |  |  |  |  |  |  |

[0000833444-22-000005:mdna:36]
[same as prior period, unchanged from 0000833444-21-000040:mdna:51]

[0000833444-22-000005:mdna:37]
Refer to Note 17, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements and "Restructuring" below within this Item 2 for further disclosure related to the Company's restructuring plans and impairment costs.

[0000833444-22-000005:mdna:38]
[same as prior period, unchanged from 0000833444-21-000040:mdna:42]

[0000833444-22-000005:mdna:39]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
| Net financing charges | $ | 53 |  |  | $ | 59 |  |  | -10 | % |  |  |  |  |  |  |

[0000833444-22-000005:mdna:40]
Refer to Note 10, "Debt and Financing Arrangements," of the notes to consolidated financial statements for further disclosure related to the Company's net financing charges.

[0000833444-22-000005:mdna:41]
[same as prior period, unchanged from 0000833444-21-000040:mdna:45]

[0000833444-22-000005:mdna:42]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
| Equity income | $ | 70 |  |  | $ | 58 |  |  | 21 | % |  |  |  |  |  |  |

[0000833444-22-000005:mdna:43]
The increase in equity income for the three months ended December 31, 2021 was primarily due to higher income at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture and within the Building Solutions EMEA/LA segment.  Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-22-000005:mdna:44]
[same as prior period, unchanged from 0000833444-21-000040:mdna:49]

[0000833444-22-000005:mdna:45]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
| Income tax provision | $ | 71 |  |  | $ | 61 |  |  | 16 | % |  |  |  |  |  |  |
| Effective tax rate | 14.5 | % |  | 14.1 | % |  |  |  |  |  |  |  |  |

[0000833444-22-000005:mdna:46]
[same as prior period, unchanged from 0000833444-21-000040:mdna:52]

[0000833444-22-000005:mdna:47]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended December 31, 2021, the Company's effective tax rate for continuing operations was 14.5% and was higher than the statutory tax rate of 12.5% primarily due to the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. For the three months ended December 31, 2020, the Company's effective tax rate for continuing operations was 14.1% and was higher than the statutory tax rate of 12.5% primarily

[0000833444-22-000005:mdna:48]
due to tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. Refer to Note 19, "Income Taxes," of the notes to consolidated financial statements for further detail.

[0000833444-22-000005:mdna:49]
[same as prior period, unchanged from 0000833444-21-000040:mdna:54]

[0000833444-22-000005:mdna:50]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
| Income from discontinued operations, net of tax | $ | — |  |  | $ | 124 |  |  | * |  |  |  |  |  |  |

[0000833444-22-000005:mdna:51]
[same as prior period, unchanged from 0000833444-21-000040:mdna:56]

[0000833444-22-000005:mdna:52]
[same as prior period, unchanged from 0000833444-21-000040:mdna:57]

[0000833444-22-000005:mdna:53]
[same as prior period, unchanged from 0000833444-21-000040:mdna:58]

[0000833444-22-000005:mdna:54]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
| Income from continuing operations attributable to noncontrolling interests | $ | 38 |  |  | $ | 45 |  |  | -16 | % |  |  |  |  |  |  |

[0000833444-22-000005:mdna:55]
The decrease in income from continuing operations attributable to noncontrolling interests for the three months ended December 31, 2021 was primarily due to lower net income at certain partially-owned affiliates within the Global Products segment.

[0000833444-22-000005:mdna:56]
Net Income Attributable to Johnson Controls

[0000833444-22-000005:mdna:57]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
| Net income attributable to Johnson Controls | $ | 381 |  |  | $ | 451 |  |  | -16 | % |  |  |  |  |  |  |

[0000833444-22-000005:mdna:58]
The decrease in net income attributable to Johnson Controls for the three months ended December 31, 2021 was primarily due to the prior year income from discontinued operations, higher SG&A and higher restructuring and impairment costs, partially offset by higher gross profit.

[0000833444-22-000005:mdna:59]
Diluted earnings per share attributable to Johnson Controls for the three months ended December 31, 2021 was $0.54 compared to $0.62 for the three months ended December 31, 2020.

[0000833444-22-000005:mdna:60]
Comprehensive Income Attributable to Johnson Controls

[0000833444-22-000005:mdna:61]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
| Comprehensive income attributable to Johnson Controls | $ | 468 |  |  | $ | 723 |  |  | -35 | % |  |  |  |  |  |  |

[0000833444-22-000005:mdna:62]
The decrease in comprehensive income attributable to Johnson Controls for the three months ended December 31, 2021 was due to a decrease in other comprehensive income attributable to Johnson Controls ($185 million) resulting primarily from

[0000833444-22-000005:mdna:63]
currency translation adjustments and lower net income attributable to Johnson Controls ($70 million). The year-over-year unfavorable foreign currency translation adjustments were primarily driven by the strengthening of the Brazilian real, British pound, euro and Mexican peso against the U.S. dollar in the prior year.

[0000833444-22-000005:mdna:64]
[same as prior period, unchanged from 0000833444-21-000040:mdna:71]

[0000833444-22-000005:mdna:65]
[same as prior period, unchanged from 0000833444-21-000040:mdna:72]

[0000833444-22-000005:mdna:66]
Effective October 1, 2021, the Company's marine businesses previously included in Building Solutions Asia Pacific and Global Products reportable segments are now part of Building Solutions EMEA/LA reportable segment. Historical information has been re-cast to present the comparative periods on a consistent basis. This change was not material to the segment presentation. Refer to Note 20, “Segment Information,” of the notes to consolidated financial statements for further information.

[0000833444-22-000005:mdna:67]
Beginning on October 1, 2021, the Company began reporting certain retrofit projects in Building Solutions EMEA/LA and Building Solutions Asia Pacific as products and systems revenue on a prospective basis as they have evolved to be more aligned with other install offerings.

[0000833444-22-000005:mdna:68]
[same as prior period, unchanged from 0000833444-21-000040:mdna:73]

[0000833444-22-000005:mdna:69]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,152 |  |  | $ | 2,034 |  |  | 6 | % |  |  |  |  |  |  |
| Building Solutions EMEA/LA | 959 |  |  | 948 |  |  | 1 | % |  |  |  |  |  |  |
| Building Solutions Asia Pacific | 675 |  |  | 604 |  |  | 12 | % |  |  |  |  |  |  |
| Global Products | 2,076 |  |  | 1,755 |  |  | 18 | % |  |  |  |  |  |  |
|  | $ | 5,862 |  |  | $ | 5,341 |  |  | 10 | % |  |  |  |  |  |  |

[0000833444-22-000005:mdna:70]
•The increase in Building Solutions North America was due to higher volumes and prices ($107 million), the favorable impact of foreign currency translation ($6 million) and incremental sales related to business acquisitions ($5 million). The sales increase was led by growth in service and HVAC & Controls.

[0000833444-22-000005:mdna:71]
•The increase in Building Solutions EMEA/LA was due to higher prices ($26 million) and incremental sales related to business acquisitions ($8 million), partially offset by the unfavorable impact of foreign currency translation ($22 million) and business divestitures ($1 million). The increase in sales is driven by balanced growth in both project installations and service activity, led by strength in Fire & Security. By region, sales growth outperformed in Europe and Latin America, partially offset by continued weakness in the Middle East.

[0000833444-22-000005:mdna:72]
•The increase in Building Solutions Asia Pacific was due to higher volumes and prices ($69 million) and incremental sales related to business acquisitions ($9 million), partially offset by the unfavorable impact of foreign currency translation ($6 million) and business divestitures ($1 million). The increase in sales was led by growth in project installations, driven by strong growth in Commercial Applied HVAC & Controls. China remains the primary source of growth, with growth stabilizing across the rest of the region.

[0000833444-22-000005:mdna:73]
•The increase in Global Products was due to higher volumes and prices ($238 million) and incremental sales related to business acquisitions ($106 million), partially offset by the unfavorable impact of foreign currency translation ($23 million). Sales growth was driven by broad-based strength across Commercial and Residential HVAC and Fire & Security products.

[0000833444-22-000005:mdna:74]
[same as prior period, unchanged from 0000833444-21-000040:mdna:7]

[0000833444-22-000005:mdna:75]
[same as prior period, unchanged from 0000833444-21-000040:mdna:85]

[0000833444-22-000005:mdna:76]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  |  |  |  |  |  |
| Building Solutions North America | $ | 250 |  |  | $ | 255 |  |  | -2 | % |  |  |  |  |  |  |
| Building Solutions EMEA/LA | 104 |  |  | 98 |  |  | 6 | % |  |  |  |  |  |  |
| Building Solutions Asia Pacific | 68 |  |  | 77 |  |  | -12 | % |  |  |  |  |  |  |
| Global Products | 301 |  |  | 212 |  |  | 42 | % |  |  |  |  |  |  |
|  | $ | 723 |  |  | $ | 642 |  |  | 13 | % |  |  |  |  |  |  |

[0000833444-22-000005:mdna:77]
•The decrease in Building Solutions North America was primarily due to supply chain disruptions and labor constraints, partially offset by favorable volumes, productivity savings and foreign currency translation.

[0000833444-22-000005:mdna:78]
•The increase in Building Solutions EMEA/LA was primarily due to favorable pricing and productivity savings, partially offset by unfavorable mix and the unfavorable impact of foreign currency translation.

[0000833444-22-000005:mdna:79]
•The decrease in Building Solutions Asia Pacific was primarily due to unfavorable mix, unfavorable price/cost and the unfavorable impact of foreign currency translation, partially offset by favorable volume leverage and productivity savings.

[0000833444-22-000005:mdna:80]
•The increase in Global Products was primarily due to favorable volumes and mix, productivity savings, higher equity income driven primarily by certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture and the favorable impact of foreign currency translation, partially offset by unfavorable price/cost and supply chain disruptions.

[0000833444-22-000005:mdna:81]
[same as prior period, unchanged from 0000833444-21-000040:mdna:97]

[0000833444-22-000005:mdna:82]
The Company’s backlog is applicable to its sales of systems and services. At December 31, 2021, the backlog was $10.9 billion, of which $10.5 billion was attributable to the field business. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-22-000005:mdna:83]
At December 31, 2021, remaining performance obligations were $16.5 billion, which is $5.6 billion higher than the Company's backlog of $10.9 billion. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-22-000005:mdna:84]
[same as prior period, unchanged from 0000833444-21-000040:mdna:100]

[0000833444-22-000005:mdna:85]
[same as prior period, unchanged from 0000833444-21-000040:mdna:101]

[0000833444-22-000005:mdna:86]
[same as prior period, unchanged from 0000833444-21-000040:mdna:102]

[0000833444-22-000005:mdna:87]
[same as prior period, unchanged from 0000833444-21-000040:mdna:103]

[0000833444-22-000005:mdna:88]
[same as prior period, unchanged from 0000833444-21-000040:mdna:104]

[0000833444-22-000005:mdna:89]
[same as prior period, unchanged from 0000833444-21-000040:mdna:105]

[0000833444-22-000005:mdna:90]
|  | December 31, |  | September 30, |  |  |
| (in millions) | 2021 |  | 2021 |  | Change |
| Current assets | $ | 10,353 |  |  | $ | 9,998 |  |  |  |
| Current liabilities | (9,987) |  |  | (9,098) |  |  |  |
|  | 366 |  |  | 900 |  |  | -59 | % |
| Less: Cash and cash equivalents | (1,207) |  |  | (1,336) |  |  |  |
| Add: Short-term debt | 392 |  |  | 8 |  |  |  |
| Add: Current portion of long-term debt | 220 |  |  | 226 |  |  |  |
| Working capital (as defined) | $ | (229) |  |  | $ | (202) |  |  | 13 | % |
| Accounts receivable - net | $ | 5,671 |  |  | $ | 5,613 |  |  | 1 | % |
| Inventories | 2,425 |  |  | 2,057 |  |  | 18 | % |
| Accounts payable | 4,083 |  |  | 3,746 |  |  | 9 | % |

[0000833444-22-000005:mdna:91]
[same as prior period, unchanged from 0000833444-21-000040:mdna:107]

[0000833444-22-000005:mdna:92]
•The decrease in working capital at December 31, 2021 as compared to September 30, 2021, was primarily due to an increase in accounts payable and deferred revenue, partially offset by an increase in inventory due to supply chain disruptions and a decrease in accrued compensation and benefits liabilities.

[0000833444-22-000005:mdna:93]
•The Company’s days sales in accounts receivable at December 31, 2021 and September 30, 2021 were 62 days and 58 days, respectively. There has been no significant adverse changes in the level of overdue receivables or significant changes in revenue recognition methods.

[0000833444-22-000005:mdna:94]
•The Company’s inventory turns for the three months ended December 31, 2021 were lower than the comparable period ended September 30, 2021, primarily due to supply chain disruptions.

[0000833444-22-000005:mdna:95]
•Days in accounts payable at December 31, 2021 were 90 days, higher than 76 days at the comparable period ended September 30, 2021, primarily due to timing.

[0000833444-22-000005:mdna:96]
[same as prior period, unchanged from 0000833444-21-000040:mdna:112]

[0000833444-22-000005:mdna:97]
|  |  | Three Months Ended December 31, |
| (in millions) |  | 2021 |  | 2020 |
| Cash provided by operating activities |  | $ | 392 |  |  | $ | 515 |  |
| Cash used by investing activities |  | (218) |  |  | (37) |  |
| Cash used by financing activities |  | (357) |  |  | (547) |  |

[0000833444-22-000005:mdna:98]
•The decrease in cash provided by operating activities was primarily due to increases in accounts receivable and inventory, partially offset by favorable changes in accounts payable and accrued liabilities.

[0000833444-22-000005:mdna:99]
•The increase in cash used by investing activities was primarily due to higher cash payments made for acquisitions and higher capital expenditures.

[0000833444-22-000005:mdna:100]
•The decrease in cash used by financing activities was primarily due to higher net short-term debt borrowings, partially offset by higher stock repurchases.

[0000833444-22-000005:mdna:101]
[same as prior period, unchanged from 0000833444-21-000040:mdna:117]

[0000833444-22-000005:mdna:102]
|  | December 31, |  | September 30, |  |  |
| (in millions) | 2021 |  | 2021 |  | Change |
| Short-term debt | $ | 392 |  |  | $ | 8 |  |  |  |
| Current portion of long-term debt | 220 |  |  | 226 |  |  |  |
| Long-term debt | 7,437 |  |  | 7,506 |  |  |  |
| Total debt | 8,049 |  |  | 7,740 |  |  | 4 | % |
| Less: Cash and cash equivalents | 1,207 |  |  | 1,336 |  |  |  |
| Total net debt | 6,842 |  |  | 6,404 |  |  | 7 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 17,249 |  |  | 17,562 |  |  | -2 | % |
| Total capitalization | $ | 24,091 |  |  | $ | 23,966 |  |  | 1 | % |
| Total net debt as a % of total capitalization | 28.4 | % |  | 26.7 | % |  |  |

[0000833444-22-000005:mdna:103]
•Net debt and net debt as a percentage of total capitalization are non-GAAP financial measures. The Company believes the percentage of total net debt to total capitalization is useful to understanding the Company’s financial condition as it provides a view of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders.

[0000833444-22-000005:mdna:104]
•The Company's material cash requirements primarily consist of working capital requirements, repayments of long-term debt and related interest, operating leases, dividends, capital expenditures, potential acquisitions and share repurchases.

[0000833444-22-000005:mdna:105]
•As of December 31, 2021, approximately $4.5 billion remains available under the Company's share repurchase authorization, which does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. The Company expects to repurchase outstanding shares from time to time depending on market conditions, alternate uses of capital, liquidity, and the economic environment.

[0000833444-22-000005:mdna:106]
•In the first quarter of fiscal 2022, the Company raised its quarterly dividend from $0.27 per share to $0.34 per share. The Company intends to continue paying quarterly dividends throughout fiscal 2022.

[0000833444-22-000005:mdna:107]
•The Company believes its capital resources and liquidity position at December 31, 2021 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, minimum pension

[0000833444-22-000005:mdna:108]
contributions, debt maturities and any potential acquisitions or stock repurchases in the remainder of fiscal 2022 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company is unable to issue commercial paper, it would have the ability to draw on its $2.5 billion revolving credit facility which expires in December 2024 or its $0.5 billion 364-day revolving credit facility which expires in December 2022. There were no draws on the revolving credit facilities as of December 31, 2021 and September 30, 2021. The Company estimates that, as of December 31, 2021, it could borrow up to $2.9 billion based on average borrowing levels during the first quarter of fiscal 2022 on committed credit lines. The Company maintains a shelf registration statement with the SEC under which it may issue additional debt securities, ordinary shares, preferred shares, depositary shares, warrants purchase contracts and units that may be offered in one or more offerings on terms to be determined at the time of the offering. The Company anticipates that the proceeds of any offering would be used for general corporate purposes, including repayment of indebtedness, acquisitions, additions to working capital, repurchases of ordinary shares, dividends, capital expenditures and investments in the Company's subsidiaries. In addition, the Company held cash and cash equivalents of $1.2 billion as of December 31, 2021. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future.

[0000833444-22-000005:mdna:109]
•The Company's ability to access the global capital markets and the related cost of financing is dependent upon, among other factors, the Company's credit ratings. As of December 31, 2021, the Company's credit ratings and outlook were as follows:

[0000833444-22-000005:mdna:110]
| Rating Agency |  | Short-Term Rating |  | Long-Term Rating |  | Outlook |
| S&P |  | A-2 |  | BBB+ |  | Stable |
| Moody's |  | P-2 |  | Baa2 |  | Stable |

[0000833444-22-000005:mdna:111]
The security ratings set forth above are issued by unaffiliated third party rating agencies and are not a recommendation to buy, sell or hold securities. The ratings may be subject to revision or withdrawal by the assigning rating organization at any time.

[0000833444-22-000005:mdna:112]
•Financial covenants in the Company's revolving credit facilities requires a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of December 31, 2021, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures governing its notes, and expects to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-22-000005:mdna:113]
•The key financial assumptions used in calculating the Company’s pension liability are determined annually, or whenever plan assets and liabilities are re-measured as required under accounting principles generally accepted in the U.S., including the expected rate of return on its plan assets. In fiscal 2022, the Company believes the long-term rate of return will approximate 7.00%, 3.70% and 5.30% for U.S. pension, non-U.S. pension and postretirement plans, respectively. During the first three months of fiscal 2022, the Company made approximately $41 million in total pension and postretirement contributions. In total, the Company expects to contribute approximately $100 million in cash to its defined benefit pension plans in fiscal 2022. The Company expects to contribute $3 million in cash to its postretirement plans in fiscal 2022.

[0000833444-22-000005:mdna:114]
•The Company earns a significant amount of its income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. The Company's intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects

[0000833444-22-000005:mdna:115]
49

[0000833444-22-000005:mdna:116]
existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at the Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings.

[0000833444-22-000005:mdna:117]
•The Company may from time to time purchase its outstanding debt through open market purchases, privately negotiated transactions or otherwise. Purchases or retirement of debt, if any, will depend on prevailing market conditions, liquidity requirements, contractual restrictions and other factors. The amounts involved may be material.

[0000833444-22-000005:mdna:118]
•Refer to Note 10, "Debt and Financing Arrangements," of the notes to consolidated financial statements for additional information on items impacting capitalization.

[0000833444-22-000005:mdna:119]
[same as prior period, unchanged from 0000833444-21-000040:mdna:128]

[0000833444-22-000005:mdna:120]
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company has committed to various restructuring plans. Restructuring plans generally result in charges for workforce reductions, plant closures, asset impairments and other related costs which are reported as restructuring and impairment costs in the Company’s consolidated statements of income. The Company expects the restructuring actions to reduce cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense.

[0000833444-22-000005:mdna:121]
•In fiscal 2021, the Company announced its plans to optimize its cost structure through broad-based SG&A actions focused on simplification, standardization and centralization, with the intent to deliver annualized savings of $300 million by fiscal 2023. Additionally, the Company announced cost of sales actions intended to drive $250 million in annual run rate savings by fiscal 2023. The one-time pre-tax costs associated with these actions are estimated to be approximately $385 million across all segments and at Corporate. During the three months ended December 31, 2021, the Company recorded $49 million of costs resulting from the 2021 restructuring plan. The restructuring action is expected to be substantially complete in fiscal 2023. The Company has outstanding restructuring reserves of $93 million at December 31, 2021, all of which is expected to be paid in cash.

[0000833444-22-000005:mdna:122]
[same as prior period, unchanged from 0000833444-21-000040:mdna:133]

[0000833444-22-000005:mdna:123]
The following information is provided in compliance with Rule 13-01 of Regulation S-X under the Securities Exchange Act of 1934 with respect to the (i) $625 million aggregate principal amount of 1.750% Senior Notes due 2030 (the “2030 Notes”), (ii) €500 million aggregate principal amount of 0.375% Senior Notes due 2027 (the “2027 Notes”), (iii) €500 million aggregate principal amount of 1.000% Senior Notes due 2032 (the “2032 Notes”) and (iv) $500 million aggregate principal amount of 2.000% Sustainability-Linked Senior Notes due 2031 (the “2031 Notes” and together with the 2032 Notes, the 2030 Notes and the 2027 Notes, the “Notes”), each issued by Johnson Controls International plc ("Parent Company") and Tyco Fire & Security Finance S.C.A. (“TFSCA”), a corporate partnership limited by shares (société en commandite par actions) incorporated and organized under the laws of the Grand Duchy of Luxembourg (“Luxembourg”).

[0000833444-22-000005:mdna:124]
TFSCA is a wholly-owned consolidated subsidiary of the Company that is 99.924% owned directly by the Parent Company and 0.076% owned by TFSCA’s sole general partner and manager, Tyco Fire & Security S.à r.l., which is itself wholly-owned by the Company. The Notes are the Parent Company’s and TFSCA’s unsecured, unsubordinated obligations. The Parent Company is incorporated and organized under the laws of Ireland and TFSCA is incorporated and organized under the laws of Luxembourg. The bankruptcy, insolvency, administrative, debtor relief and other laws of Luxembourg or Ireland, as applicable, may be materially different from, or in conflict with, those of the United States, including in the areas of rights of creditors, priority of governmental and other creditors, ability to obtain post-petition interest and duration of the proceeding. The application of these laws, or any conflict among them, could adversely affect noteholders’ ability to enforce their rights under the Notes in those jurisdictions or limit any amounts that they may receive.

[0000833444-22-000005:mdna:125]
[same as prior period, unchanged from 0000833444-21-000040:mdna:136]

[0000833444-22-000005:mdna:126]
[same as prior period, unchanged from 0000833444-21-000040:mdna:137]

[0000833444-22-000005:mdna:127]
|  |  | Three Months Ended December 31, 2021 |  | Year EndedSeptember 30, 2021 |  |
| Net sales |  | $ | — |  |  | $ | — |  |  |
| Gross profit |  | — |  |  | — |  |  |
| Loss from continuing operations |  | (57) |  |  | (212) |  |  |
| Net loss |  | (57) |  |  | (212) |  |  |
| Income attributable to noncontrolling interests |  | — |  |  | — |  |  |
| Net loss attributable to the entity |  | (57) |  |  | (212) |  |  |

[0000833444-22-000005:mdna:128]
51

[0000833444-22-000005:mdna:129]
[same as prior period, unchanged from 0000833444-21-000040:mdna:140]

[0000833444-22-000005:mdna:130]
|  |  | Three Months Ended December 31, 2021 |  | Year EndedSeptember 30, 2021 |  |
| Net sales |  | $ | — |  |  | $ | — |  |  |
| Gross profit |  | — |  |  | — |  |  |
| Income from continuing operations |  | 14 |  |  | 223 |  |  |
| Net income |  | 14 |  |  | 223 |  |  |
| Income attributable to noncontrolling interests |  | — |  |  | — |  |  |
| Net income attributable to the entity |  | 14 |  |  | 223 |  |  |

[0000833444-22-000005:mdna:131]
The following table presents summarized balance sheet information as of December 31, 2021 and September 30, 2021 (in millions):

[0000833444-22-000005:mdna:132]
|  |  | December 31, 2021 |  | September 30, 2021 |  |
| Current assets |  | $ | 1,405 |  |  | $ | 1,036 |  |  |
| Noncurrent assets |  | 271 |  |  | 280 |  |  |
| Current liabilities |  | 2,601 |  |  | 1,825 |  |  |
| Noncurrent liabilities |  | 7,192 |  |  | 7,260 |  |  |
| Noncontrolling interests |  | — |  |  | — |  |  |

[0000833444-22-000005:mdna:133]
[same as prior period, unchanged from 0000833444-21-000040:mdna:144]

[0000833444-22-000005:mdna:134]
|  |  | December 31, 2021 |  | September 30, 2021 |  |
| Current assets |  | $ | 348 |  |  | $ | 465 |  |  |
| Noncurrent assets |  | 2,989 |  |  | 2,992 |  |  |
| Current liabilities |  | 2,512 |  |  | 1,660 |  |  |
| Noncurrent liabilities |  | 7,127 |  |  | 7,199 |  |  |
| Noncontrolling interests |  | — |  |  | — |  |  |

[0000833444-22-000005:mdna:135]
The same accounting policies as described in Note 1, "Summary of Significant Accounting Policies," of the Company's Annual Report on 10-K for the year ended September 30, 2021 are used by the Parent Company and each of its subsidiaries in connection with the summarized financial information presented above.

[0000833444-22-000005:mdna:136]
[same as prior period, unchanged from 0000833444-21-000040:mdna:147]

[0000833444-22-000005:mdna:137]
[same as prior period, unchanged from 0000833444-21-000040:mdna:148]
