# JCI note change history — 0000833444-21-000040 → 0000833444-22-000005


## jci:ScheduleOfAccrualForAsbestosLossContingenciesTableTextBlock (contingencies) — matched_by: no_prior_note, score: 0.0

- added (2022-02-02):
[0000833444-22-000005:note_history:1]
The following table presents the location and amount of asbestos-related assets and liabilities in the Company's consolidated statements of financial position (in millions):

- added (2022-02-02):
[0000833444-22-000005:note_history:2]
|  | December 31, 2021 |  | September 30, 2021 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 395 |  |  | 400 |  |
| Total asbestos-related liabilities | 453 |  |  | 458 |  |
| Other current assets | 15 |  |  | 13 |  |
| Other noncurrent assets | 373 |  |  | 365 |  |
| Total asbestos-related assets | 388 |  |  | 378 |  |
| Net asbestos-related liabilities | $ | 65 |  |  | $ | 80 |  |

- added (2022-02-02):
[0000833444-22-000005:note_history:3]
The following table presents the components of asbestos-related assets (in millions):

- added (2022-02-02):
[0000833444-22-000005:note_history:4]
|  | December 31, 2021 |  | September 30, 2021 |
| Restricted |  |  |  |
| Cash | $ | 7 |  |  | $ | 6 |  |
| Investments | 323 |  |  | 314 |  |
| Total restricted assets | 330 |  |  | 320 |  |
| Insurance recoveries for asbestos-related liabilities | 58 |  |  | 58 |  |
| Total asbestos-related assets | $ | 388 |  |  | $ | 378 |  |


## jci:ScheduleOfAccrualForEnvironmentalLossContingenciesTableTextBlock (contingencies) — matched_by: no_prior_note, score: 0.0

- added (2022-02-02):
[0000833444-22-000005:note_history:5]
The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):

- added (2022-02-02):
[0000833444-22-000005:note_history:6]
|  | December 31, 2021 |  | September 30, 2021 |
| Other current liabilities | $ | 64 |  |  | $ | 48 |  |
| Other noncurrent liabilities | 29 |  |  | 54 |  |
| Total reserves for environmental liabilities | $ | 93 |  |  | $ | 102 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2022-02-02):
[0000833444-22-000005:note_history:7]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):

- added (2022-02-02):
[0000833444-22-000005:note_history:8]
|  | December 31, 2021 |  | September 30, 2021 |
| Other current liabilities | $ | 64 |  |  | $ | 48 |  |
| Other noncurrent liabilities | 29 |  |  | 54 |  |
| Total reserves for environmental liabilities | $ | 93 |  |  | $ | 102 |  |

- changed (2022-02-02):
[0000833444-22-000005:note_history:9]
Tyco Fire Products L.P. (“Tyco Fire Products”), in coordination with the Wisconsin Department of Natural Resources ("WDNR"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin. In connection with the assessment, perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluoroalkyl substances ("PFAS") have been detected at the FTC and in groundwater and surface water outside of the
  (was, 2021-07-30, similarity 0.843):
[0000833444-21-000040:note_history:9]
Tyco Fire Products L.P. (“Tyco Fire Products”), in coordination with the Wisconsin Department of Natural Resources ("WDNR"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin. In connection with the assessment, perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluoroalkyl substances ("PFAS") have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC. Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working with WDNR to address these issues insofar as they related to this migration.

- added (2022-02-02):
[0000833444-22-000005:note_history:10]
boundaries of the FTC. Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working with WDNR to address these issues insofar as they related to this migration.

- added (2022-02-02):
[0000833444-22-000005:note_history:11]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. On August 22, 2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation. On November 6, 2020, WDNR received further recommendations from WDHS regarding individual standards for 12 additional PFAS and a combined standard for four additional PFAS, PFOA, and PFOS.

- changed (2022-02-02):
[0000833444-22-000005:note_history:12]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. Tyco Fire Products voluntarily responded to the WDNR’s letter to request additional necessary information.  On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. The letter stated that “if you fail to take the actions required by Wis. Stat. § 292.11 to address this contamination, the DNR will move forward under Wis. Stat. § 292.31 to implement the SI workplan and evaluate further environmental enforcement actions and cost recovery under Wis. Stat. § 292.31(8).” The WDNR issued a further letter regarding the issue on November 4, 2019.  In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to date. Tyco Fire Products responded to the WDNR’s September 2021 notice by the December 27, 2021 deadline set by WDNR. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.
  (was, 2021-07-30, similarity 0.7494):
[0000833444-21-000040:note_history:12]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. Tyco Fire Products voluntarily responded to the WDNR’s letter to request additional necessary information.  On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. The letter stated that “if you fail to take the actions required by Wis. Stat. § 292.11 to address this contamination, the DNR will move forward under Wis. Stat. § 292.31 to implement the SI workplan and evaluate further environmental enforcement actions and cost recovery under Wis. Stat. § 292.31(8).” The WDNR issued a further letter regarding the issue on November 4, 2019.  In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

- changed (2022-02-02):
[0000833444-22-000005:note_history:13]
In December 2020, the Company received a notice from the Wisconsin Department of Justice (“WDOJ”) that the WDOJ was considering a potential civil enforcement action against the Company relating to environmental matters at the FTC including, but not limited to, the investigation and remediation of PFAS at or near the FTC as discussed above and the Company’s alleged failure to timely report the presence of PFAS chemicals at the FTC. Such enforcement action could seek civil monetary penalties and/or injunctive relief. The Company is presently unable to predict the duration, scope, or
  (was, 2021-07-30, similarity 0.8682):
[0000833444-21-000040:note_history:13]
In December 2020, the Company received a notice from the Wisconsin Department of Justice (“WDOJ”) that the WDOJ was considering a potential civil enforcement action against the Company relating to environmental matters at the FTC including, but not limited to, the investigation and remediation of PFAS at or near the FTC as discussed above and the Company’s alleged failure to timely report the presence of PFAS chemicals at the FTC. Such enforcement action could seek civil monetary penalties and/or injunctive relief. The Company is presently unable to predict the duration, scope, or results of any potential civil enforcement action that may result, the consequences of any such action, or the nature of any resolution of these potential claims with the WDOJ.

- added (2022-02-02):
[0000833444-22-000005:note_history:14]
results of any potential civil enforcement action that may result, the consequences of any such action, or the nature of any resolution of these potential claims with the WDOJ.

- added (2022-02-02):
[0000833444-22-000005:note_history:15]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. The Company recorded conditional asset retirement obligations for continuing operations of $29 million at both December 31, 2021 and September 30, 2021.

- added (2022-02-02):
[0000833444-22-000005:note_history:16]
The Company estimates the asbestos-related liability for pending and future claims and related defense costs on a discounted basis. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable.

- added (2022-02-02):
[0000833444-22-000005:note_history:17]
The following table presents the location and amount of asbestos-related assets and liabilities in the Company's consolidated statements of financial position (in millions):

- added (2022-02-02):
[0000833444-22-000005:note_history:18]
|  | December 31, 2021 |  | September 30, 2021 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 395 |  |  | 400 |  |
| Total asbestos-related liabilities | 453 |  |  | 458 |  |
| Other current assets | 15 |  |  | 13 |  |
| Other noncurrent assets | 373 |  |  | 365 |  |
| Total asbestos-related assets | 388 |  |  | 378 |  |
| Net asbestos-related liabilities | $ | 65 |  |  | $ | 80 |  |

- added (2022-02-02):
[0000833444-22-000005:note_history:19]
The following table presents the components of asbestos-related assets (in millions):

- added (2022-02-02):
[0000833444-22-000005:note_history:20]
|  | December 31, 2021 |  | September 30, 2021 |
| Restricted |  |  |  |
| Cash | $ | 7 |  |  | $ | 6 |  |
| Investments | 323 |  |  | 314 |  |
| Total restricted assets | 330 |  |  | 320 |  |
| Insurance recoveries for asbestos-related liabilities | 58 |  |  | 58 |  |
| Total asbestos-related assets | $ | 388 |  |  | $ | 378 |  |

- changed (2022-02-02):
[0000833444-22-000005:note_history:21]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be paid by Company affiliates). Asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be paid through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.
  (was, 2021-07-30, similarity 0.9913):
[0000833444-21-000040:note_history:21]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

- changed (2022-02-02):
[0000833444-22-000005:note_history:22]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption may impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.
  (was, 2021-07-30, similarity 0.9977):
[0000833444-21-000040:note_history:22]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

- added (2022-02-02):
[0000833444-22-000005:note_history:23]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage its insurable liabilities.

- added (2022-02-02):
[0000833444-22-000005:note_history:24]
The following table presents the location and amount of insurable liabilities in the Company's consolidated statements of financial position (in millions):

- added (2022-02-02):
[0000833444-22-000005:note_history:25]
|  | December 31, 2021 |  | September 30, 2021 |
| Other current liabilities | $ | 79 |  |  | $ | 77 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 218 |  |  | 226 |  |
| Total insurable liabilities | $ | 319 |  |  | $ | 325 |  |

- added (2022-02-02):
[0000833444-22-000005:note_history:26]
The following table presents the location and amount of insurable receivables in the Company's consolidated statements of financial position (in millions):

- added (2022-02-02):
[0000833444-22-000005:note_history:27]
|  | December 31, 2021 |  | September 30, 2021 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 15 |  |  | 15 |  |
| Total insurable receivables | $ | 20 |  |  | $ | 20 |  |

- added (2022-02-02):
[0000833444-22-000005:note_history:28]
PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but had initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. In March 2021, the EPA published its final determination to regulate PFOS and PFOA in drinking water. In October 2021, the EPA released its "PFAS Strategic Roadmap: EPA's Commitments to Action 2021-2024." The 2021-2024 Roadmap sets timelines by which the EPA plans to take specific actions, including, among other items, publishing a national PFAS testing strategy, proposing to designate PFOA and PFOS as Comprehensive Environmental Response, Compensation and Liability Act hazardous substances, restricting PFAS discharges from industrial sources through Effluent Limitations Guidelines, publishing the final toxicity assessment for five additional PFAS, requiring water systems to test for 29 PFAS under the Safe Drinking Water Act, and publishing improved analytical methods in eight different environmental matrices to monitor 40 PFAS present in wastewater and stormwater

- changed (2022-02-02):
[0000833444-22-000005:note_history:29]
discharges. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.
  (was, 2021-07-30, similarity 0.9233):
[0000833444-21-000040:note_history:29]
Act. The Agency reissued those actions in February 2021. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

- added (2022-02-02):
[0000833444-22-000005:note_history:30]
Chemguard and Tyco Fire Products are named in 32 putative class actions in federal courts originating from Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington, New Hampshire, South Carolina, the District of Columbia, Guam, West Virginia, Michigan, Texas and South Dakota. All of these cases except one have been direct-filed in or transferred to the MDL.

- changed (2022-02-02):
[0000833444-22-000005:note_history:31]
There are more than 1,900 individual or “mass” actions pending that were filed in state or federal court in various states including California, Colorado, New York, Pennsylvania, New Mexico, Missouri, Arizona, Texas, and South Carolina against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 1,900 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly filed state court actions will be similarly tagged and transferred. There are three matters that are proceeding in state court: One case, Young v. Chemguard et al., was filed in superior court in Maricopa County, Arizona, removed to the United States District Court, District of Arizona, and tagged to the MDL, but was remanded to state court prior to being transferred to the MDL. The decision to remand the case to state court is currently being appealed. The second case, Forbach et al. v. Chemguard et al., was filed in superior court in Coconino County, Arizona, and is proceeding with initial discovery. The third case, Ellison-Wood v. Chemguard, Inc., et al., was filed recently in district court in Tarrant County, Texas.
  (was, 2021-07-30, similarity 0.6179):
[0000833444-21-000040:note_history:31]
There are approximately 1,270 individual or “mass” actions pending that were filed in state or federal court in various states including California, Colorado, New York, Pennsylvania, New Mexico, Missouri, Arizona, Texas, and South Carolina against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, and approximately 1,000 other plaintiffs. All but two of these matters have been transferred to or directly-filed in the MDL. One case, Young v. Chemguard et al., was filed in superior court in Maricopa County, Arizona, removed to the United States District Court, District of Arizona, and tagged to the MDL, but was remanded to state court prior to being transferred to the MDL. The decision to remand the case to state court is currently being appealed. Many of the additional filed actions were directly filed in South Carolina by plaintiffs who were among the 660 plaintiffs the Company had previously disclosed to have made filings in Pennsylvania state court. The Company anticipates that the remainder of the possible individual product liability claims filed in Pennsylvania state court will either soon be filed in the MDL (and that all such claims in state court will be dismissed accordingly) or will be dismissed in Pennsylvania without a corresponding filing in South Carolina.

- added (2022-02-02):
[0000833444-22-000005:note_history:32]
Chemguard and Tyco Fire Products have been named as defendants in approximately 168 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Alabama, Arizona, California, Colorado, Connecticut, Florida, Idaho, Illinois, Kentucky, Louisiana, Maryland, Massachusetts, Michigan, New Jersey, New York, North Carolina, Ohio, Pennsylvania, Virginia, Washington, West Virginia, Wisconsin, the District of Columbia, and several municipalities or water providers from various states who direct-filed complaints in South Carolina. All but five of these cases have been transferred to or directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.

- added (2022-02-02):
[0000833444-22-000005:note_history:33]
The Company has periodically been notified by other municipal entities that those entities may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

- changed (2022-02-02):
[0000833444-22-000005:note_history:34]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. The State’s case has been removed to federal court and transferred to the MDL. The State of Alaska has also named a number of manufacturers and other defendants, including affiliates of the Company, as third-party defendants in two cases brought by individuals against the State. These two cases have also been transferred to the MDL.
  (was, 2021-07-30, similarity 0.6819):
[0000833444-21-000040:note_history:34]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. This complaint has not yet been served.

- added (2022-02-02):
[0000833444-22-000005:note_history:35]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL.

- removed (2022-02-02):
[0000833444-21-000040:note_history:36]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of June 30, 2021, reserves for environmental liabilities for continuing operations totaled $100 million, of which $50 million was recorded within other current liabilities and $50 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $130 million at September 30, 2020, of which $61 million was recorded within other current liabilities and $69 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.

- removed (2022-02-02):
[0000833444-21-000040:note_history:37]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. On August 22,

- removed (2022-02-02):
[0000833444-21-000040:note_history:38]
2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation. On November 6, 2020, WDNR received further recommendations from WDHS regarding individual standards for 12 additional PFAS and a combined standard for four additional PFAS, PFOA, and PFOS.

- removed (2022-02-02):
[0000833444-21-000040:note_history:39]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and

- removed (2022-02-02):
[0000833444-21-000040:note_history:40]
risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At June 30, 2021 and September 30, 2020, the Company recorded conditional asset retirement obligations for continuing operations of $29 million and $29 million, respectively.

- removed (2022-02-02):
[0000833444-21-000040:note_history:41]
As of June 30, 2021, the Company's estimated asbestos-related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $78 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $466 million, of which $49 million was recorded in other current liabilities and $417 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $388 million, of which $19 million was recorded in other current assets, and $369 million was recorded in other noncurrent assets. Assets included $7 million of cash and $320 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at June 30, 2021 was $61 million. As of September 30, 2020, the Company's estimated asbestos-related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $115 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $483 million, of which $49 million was recorded in other current liabilities and $434 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $368 million, of which $39 million was recorded in other current assets, and $329 million was recorded in other noncurrent assets. Assets included $9 million of cash and $291 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2020 was $68 million.

- removed (2022-02-02):
[0000833444-21-000040:note_history:42]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At June 30, 2021 and September 30, 2020, the insurable liabilities totaled $359 million and $363 million, respectively, of which $89 million and $83 million was recorded within other current liabilities, $23 million and $22 million was recorded within accrued compensation and benefits, and $247 million and $258 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at June 30, 2021 were $21 million, of which $5 million was recorded within other current assets and $16 million was recorded within other noncurrent assets, respectively. The amount of such receivables recorded at September 30, 2020 were $21 million, of which $5 million was recorded within other current assets and $16 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.

- removed (2022-02-02):
[0000833444-21-000040:note_history:43]
PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but had initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. The EPA also announced in January 2021 that it will issue an advance notice of proposed rulemaking to solicit public comment on whether the agency should take additional regulatory steps to address PFAS contamination, including designating PFOA and PFOS and other PFAS as hazardous substances under the Comprehensive Environmental Response, Compensation, and Liability Act and seeking comment on whether PFOA and PFOS and other PFAS should be subject to regulation as hazardous waste under the Resource Conservation and Recovery

- removed (2022-02-02):
[0000833444-21-000040:note_history:44]
Chemguard and Tyco Fire Products are named in 32 putative class actions in federal courts originating from Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington, New Hampshire, South Carolina, the District of Columbia, Guam, West Virginia, Michigan, Texas and South Dakota. All of these cases except one have been direct-filed in or transferred to the MDL, with one recently-filed case expected to be transferred to the MDL shortly. Since the beginning of fiscal year 2021, three putative class actions (Jackson v. 3M Company, et al., direct filed on January 15, 2021 in the MDL pending in the United States District Court, District of South Carolina; Ogden v. Intercontinental Terminals Company LLC, et al., filed in the United States District Court, Southern District of Texas on January 27, 2021, and transferred to the MDL; Miller v. 3M Company et al., filed in the United States District Court, Northern District of West Virginia on July 8, 2021, and tagged to the MDL) have been filed against the Company.

- removed (2022-02-02):
[0000833444-21-000040:note_history:45]
Chemguard and Tyco Fire Products have been named as defendants in 119 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Alabama, Arizona, California, Colorado, Florida, Idaho, Kentucky, Louisiana, Massachusetts, New Jersey, New York, Maryland, North Carolina, Ohio, Pennsylvania, Virginia, Washington, the District of Columbia and several municipalities or water providers from various states who direct-filed complaints in South Carolina. All but seven of these cases have been transferred to or directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.

- removed (2022-02-02):
[0000833444-21-000040:note_history:46]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly

- removed (2022-02-02):
[0000833444-21-000040:note_history:47]
resulting from the use of those products at the Peterson Air Force Base. In May 2020, the Company was also notified by the Lakewood Water District in Pierce County, Washington that it may assert claims regarding remediation in connection with PFOA, PFOS, and other PFAS contamination allegedly resulting from the use of those products at Joint Base Lewis-McChord.

- removed (2022-02-02):
[0000833444-21-000040:note_history:48]
AFFF Matters Related to the Tyco Fire Products Fire Technology Center in Marinette, Wisconsin

- removed (2022-02-02):
[0000833444-21-000040:note_history:49]
Tyco Fire Products and Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFAS (including PFOA/PFOS) contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. On January 7, 2021, the parties agreed to settle the lawsuit. The settlement provides that Tyco will pay up to $17.5 million to compensate Town of Peshtigo residents who live in the area affected by PFAS from the FTC for claims related to loss of real property value, exposure and/or personal injury. The settlement does not constitute an admission of wrongdoing by Tyco or Chemguard and is subject to approval by the federal court presiding over the lawsuit and other contingencies. The court conducted a hearing regarding the proposed settlement in May 2021; following this hearing the parties will submit for final approval an amended settlement agreement. The Company does not expect the settlement to have a significant impact on its fiscal year 2021 results of operations or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-02-02):
[0000833444-22-000005:note_history:50]
Basis of Presentation
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2021 filed with the SEC on November 15, 2021. The results of operations for the three-month period ended December 31, 2021 are not necessarily indicative of results for the Company’s 2022 fiscal year because of seasonal and other factors.
  (was, 2021-07-30, similarity 0.9628):
[0000833444-21-000040:note_history:50]
Financial Statements
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2020 filed with the SEC on November 16, 2020. The results of operations for the three and nine month periods ended June 30, 2021 are not necessarily indicative of results for the Company’s 2021 fiscal year because of seasonal and other factors.

- added (2022-02-02):
[0000833444-22-000005:note_history:51]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, healthy and sustainable buildings, serving a wide range of customers in more than 150 countries. The Company’s products, services, systems and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

- added (2022-02-02):
[0000833444-22-000005:note_history:52]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including residential and commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management and repair of equipment (in the HVAC, industrial refrigeration, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions powered by its OpenBlue software platform and capabilities. The Company partners with customers by leveraging its broad product portfolio and digital capabilities powered by OpenBlue, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency and reduce greenhouse gas emissions.

- changed (2022-02-02):
[0000833444-22-000005:note_history:53]
At December 31, 2021 and September 30, 2021, the Company held restricted cash of approximately $15 million and $6 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities and certain litigation and environmental matters.
  (was, 2021-07-30, similarity 0.9096):
[0000833444-21-000040:note_history:53]
At June 30, 2021 and September 30, 2020, the Company held restricted cash of approximately $7 million and $9 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities.

- added (2022-02-02):
[0000833444-22-000005:note_history:54]
Retrospective Changes

- added (2022-02-02):
[0000833444-22-000005:note_history:55]
Effective October 1, 2021, the Company's marine businesses previously included in the Building Solutions Asia Pacific and Global Products segments are now part of the Building Solutions EMEA/LA segment. Historical information has been re-cast to present the comparative periods on a consistent basis. This change was not material to the segment presentation. Refer to Note 8, "Goodwill and Other Intangible Assets," and Note 20, “Segment Information,” of the notes to consolidated financial statements for further information.

- removed (2022-02-02):
[0000833444-21-000040:note_history:56]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global diversified technology and multi-industrial leader serving a wide range of customers in more than 150 countries. The Company’s products and solutions enable smart, energy efficient, sustainable buildings that work seamlessly together to advance the safety, comfort and intelligence of spaces to power its customers’ mission. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

- removed (2022-02-02):
[0000833444-21-000040:note_history:57]
The Company is a global leader in engineering, manufacturing and commissioning building products and systems, including residential and commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire detection systems and fire suppression solutions. The Company further serves customers by providing technical services, including maintenance, repair, retrofit and replacement of equipment (in the HVAC, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions powered by its digital platforms and capabilities.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-02):
[0000833444-22-000005:note_history:58]
Debt and Financing ArrangementsAs of December 31, 2021, the Company has a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which was renewed in December 2021 and is now scheduled to expire in December 2022. As of December 31, 2021, there were no draws on the facilities.
In November 2021, the Company entered into a €200 million bank term loan which is due in October 2022.
  (was, 2021-07-30, similarity 0.7388):
[0000833444-21-000040:note_history:58]
As of June 30, 2021, the Company has a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2021. As of June 30, 2021, there were no draws on the facilities.

- added (2022-02-02):
[0000833444-22-000005:note_history:59]
The Company had $150 million of commercial paper outstanding as of December 31, 2021 and no commercial paper outstanding as of September 30, 2021.

- added (2022-02-02):
[0000833444-22-000005:note_history:60]
Net Financing Charges

- changed (2022-02-02):
[0000833444-22-000005:note_history:61]
|  | Three Months Ended December 31, |  |  |
|  | 2021 |  | 2020 |  |  |  |  |
| Interest expense, net of capitalized interest costs | $ | 55 |  |  | $ | 59 |  |  |  |  |  |
| Banking fees and bond cost amortization | 5 |  |  | 8 |  |  |  |  |  |
| Interest income | (2) |  |  | (3) |  |  |  |  |  |
| Net foreign exchange results for financing activities | (5) |  |  | (5) |  |  |  |  |  |
| Net financing charges | $ | 53 |  |  | $ | 59 |  |  |  |  |  |
  (was, 2021-07-30, similarity 0.8005):
[0000833444-21-000040:note_history:61]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Interest expense, net of capitalized interest costs | $ | 55 |  |  | $ | 58 |  |  | $ | 167 |  |  | $ | 182 |  |
| Banking fees and bond cost amortization | 7 |  |  | 8 |  |  | 19 |  |  | 18 |  |
| Interest income | (1) |  |  | (3) |  |  | (7) |  |  | (21) |  |
| Net foreign exchange results for financing activities | (5) |  |  | (5) |  |  | (20) |  |  | (10) |  |
| Net financing charges | $ | 56 |  |  | $ | 58 |  |  | $ | 159 |  |  | $ | 169 |  |

- removed (2022-02-02):
[0000833444-21-000040:note_history:62]
Debt and Financing Arrangements
Net Financing Charges

- removed (2022-02-02):
[0000833444-21-000040:note_history:63]
In July 2021, the Company issued a notice of redemption for all of its outstanding 3.75% senior notes maturing December 1, 2021. The notes have an aggregate principal amount of $171 million and will be redeemed on September 1, 2021.

- removed (2022-02-02):
[0000833444-21-000040:note_history:64]
In May 2021, the Company retired €35 million in principal amount, plus accrued interest, of its 1.00% fixed rate notes expiring in September 2023.

- removed (2022-02-02):
[0000833444-21-000040:note_history:65]
In March 2021, the Company entered into a bank term loan arrangement totaling €200 million due in March 2022 and retired $257 million in principal amount, plus accrued interest, of its 4.25% fixed rate notes that expired in March 2021.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2022-02-02):
[0000833444-22-000005:note_history:66]
The following table presents net sales to and purchases from related parties for the three months ended December 31, 2021 and 2020 (in millions):
  (was, 2021-07-30, similarity 0.9319):
[0000833444-21-000040:note_history:66]
The following table presents net sales to and purchases from related parties for the three and nine months ended June 30, 2021 and 2020 (in millions):

- changed (2022-02-02):
[0000833444-22-000005:note_history:67]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Net sales to related parties |  | $ | 35 |  |  | $ | 44 |  |  |  |  |  |
| Purchases from related parties |  | 44 |  |  | 29 |  |  |  |  |  |
  (was, 2021-07-30, similarity 0.6838):
[0000833444-21-000040:note_history:67]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales to related parties |  | $ | 46 |  |  | $ | 52 |  |  | $ | 143 |  |  | $ | 135 |  |
| Purchases from related parties |  | 55 |  |  | 25 |  |  | 121 |  |  | 47 |  |

- changed (2022-02-02):
[0000833444-22-000005:note_history:68]
|  |  | December 31, 2021 |  | September 30, 2021 |
| Receivable from related parties |  | $ | 58 |  |  | $ | 73 |  |
| Payable to related parties |  | 15 |  |  | 45 |  |
  (was, 2021-07-30, similarity 0.965):
[0000833444-21-000040:note_history:68]
|  |  | June 30, 2021 |  | September 30, 2020 |
| Receivable from related parties |  | $ | 73 |  |  | $ | 48 |  |
| Payable to related parties |  | 33 |  |  | 11 |  |

- added (2022-02-02):
[0000833444-22-000005:note_history:69]
Additionally, the Company leases certain facilities used in its operations from a related party. As of December 31, 2021, the right-of-use asset and lease liability associated with these leases were $10 million. As of September 30, 2021, the right-of-use asset associated with these leases was $11 million and the lease liability was $10 million. Amounts paid for these leases were not material.

- removed (2022-02-02):
[0000833444-21-000040:note_history:70]
Additionally, the Company leases certain facilities used in its operations from a related party. As of June 30, 2021, the right-of-use asset associated with these leases was $12 million and the lease liability was $11 million. Amounts paid for these leases were not material.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2022-02-02):
[0000833444-22-000005:note_history:71]
The following table presents net sales to and purchases from related parties for the three months ended December 31, 2021 and 2020 (in millions):
  (was, 2021-07-30, similarity 0.9319):
[0000833444-21-000040:note_history:71]
The following table presents net sales to and purchases from related parties for the three and nine months ended June 30, 2021 and 2020 (in millions):

- changed (2022-02-02):
[0000833444-22-000005:note_history:72]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Net sales to related parties |  | $ | 35 |  |  | $ | 44 |  |  |  |  |  |
| Purchases from related parties |  | 44 |  |  | 29 |  |  |  |  |  |
  (was, 2021-07-30, similarity 0.6838):
[0000833444-21-000040:note_history:72]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales to related parties |  | $ | 46 |  |  | $ | 52 |  |  | $ | 143 |  |  | $ | 135 |  |
| Purchases from related parties |  | 55 |  |  | 25 |  |  | 121 |  |  | 47 |  |

- changed (2022-02-02):
[0000833444-22-000005:note_history:73]
|  |  | December 31, 2021 |  | September 30, 2021 |
| Receivable from related parties |  | $ | 58 |  |  | $ | 73 |  |
| Payable to related parties |  | 15 |  |  | 45 |  |
  (was, 2021-07-30, similarity 0.965):
[0000833444-21-000040:note_history:73]
|  |  | June 30, 2021 |  | September 30, 2020 |
| Receivable from related parties |  | $ | 73 |  |  | $ | 48 |  |
| Payable to related parties |  | 33 |  |  | 11 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-02-02):
[0000833444-22-000005:note_history:74]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three months ended December 31, 2021 and 2020 (in millions):
  (was, 2021-07-30, similarity 0.9504):
[0000833444-21-000040:note_history:74]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three and nine months ended June 30, 2021 and 2020 (in millions):

- added (2022-02-02):
[0000833444-22-000005:note_history:75]
|  |  | Three Months Ended December 31, 2021 |  | Three Months Ended December 31, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,299 |  |  | $ | 853 |  |  | $ | 2,152 |  |  | $ | 1,242 |  |  | $ | 792 |  |  | $ | 2,034 |  |
| Building Solutions EMEA/LA |  | 544 |  |  | 415 |  |  | 959 |  |  | 468 |  |  | 480 |  |  | 948 |  |
| Building Solutions Asia Pacific |  | 501 |  |  | 174 |  |  | 675 |  |  | 334 |  |  | 270 |  |  | 604 |  |
| Global Products |  | 2,076 |  |  | — |  |  | 2,076 |  |  | 1,755 |  |  | — |  |  | 1,755 |  |
| Total |  | $ | 4,420 |  |  | $ | 1,442 |  |  | $ | 5,862 |  |  | $ | 3,799 |  |  | $ | 1,542 |  |  | $ | 5,341 |  |

- changed (2022-02-02):
[0000833444-22-000005:note_history:76]
The following table presents further disaggregation of Global Products segment revenues by product type for the three months ended December 31, 2021 and 2020 (in millions):
  (was, 2021-07-30, similarity 0.9429):
[0000833444-21-000040:note_history:76]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and nine months ended June 30, 2021 and 2020 (in millions):

- changed (2022-02-02):
[0000833444-22-000005:note_history:77]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| HVAC |  | $ | 1,483 |  |  | $ | 1,218 |  |  |  |  |  |
| Fire & Security |  | 544 |  |  | 488 |  |  |  |  |  |
| Industrial Refrigeration |  | 49 |  |  | 49 |  |  |  |  |  |
| Total |  | $ | 2,076 |  |  | $ | 1,755 |  |  |  |  |  |
  (was, 2021-07-30, similarity 0.7105):
[0000833444-21-000040:note_history:77]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC |  | $ | 1,811 |  |  | $ | 1,503 |  |  | $ | 4,462 |  |  | $ | 4,127 |  |
| Fire & Security |  | 580 |  |  | 422 |  |  | 1,605 |  |  | 1,425 |  |
| Industrial Refrigeration |  | 64 |  |  | 54 |  |  | 176 |  |  | 173 |  |
| Total |  | $ | 2,455 |  |  | $ | 1,979 |  |  | $ | 6,243 |  |  | $ | 5,725 |  |

- removed (2022-02-02):
[0000833444-21-000040:note_history:78]
|  |  | Three Months Ended June 30, 2021 |  | Three Months Ended June 30, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,355 |  |  | $ | 857 |  |  | $ | 2,212 |  |  | $ | 1,250 |  |  | $ | 770 |  |  | $ | 2,020 |  |
| Building Solutions EMEA/LA |  | 468 |  |  | 494 |  |  | 962 |  |  | 346 |  |  | 410 |  |  | 756 |  |
| Building Solutions Asia Pacific |  | 422 |  |  | 290 |  |  | 712 |  |  | 344 |  |  | 244 |  |  | 588 |  |
| Global Products |  | 2,455 |  |  | — |  |  | 2,455 |  |  | 1,979 |  |  | — |  |  | 1,979 |  |
| Total |  | $ | 4,700 |  |  | $ | 1,641 |  |  | $ | 6,341 |  |  | $ | 3,919 |  |  | $ | 1,424 |  |  | $ | 5,343 |  |

- removed (2022-02-02):
[0000833444-21-000040:note_history:79]
|  |  | Nine Months Ended June 30, 2021 |  | Nine Months Ended June 30, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,869 |  |  | $ | 2,469 |  |  | $ | 6,338 |  |  | $ | 3,963 |  |  | $ | 2,399 |  |  | $ | 6,362 |  |
| Building Solutions EMEA/LA |  | 1,323 |  |  | 1,442 |  |  | 2,765 |  |  | 1,203 |  |  | 1,331 |  |  | 2,534 |  |
| Building Solutions Asia Pacific |  | 1,096 |  |  | 834 |  |  | 1,930 |  |  | 986 |  |  | 756 |  |  | 1,742 |  |
| Global Products |  | 6,243 |  |  | — |  |  | 6,243 |  |  | 5,725 |  |  | — |  |  | 5,725 |  |
| Total |  | $ | 12,531 |  |  | $ | 4,745 |  |  | $ | 17,276 |  |  | $ | 11,877 |  |  | $ | 4,486 |  |  | $ | 16,363 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-02-02):
[0000833444-22-000005:note_history:80]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three months ended December 31, 2021 and 2020 (in millions):
  (was, 2021-07-30, similarity 0.9504):
[0000833444-21-000040:note_history:80]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three and nine months ended June 30, 2021 and 2020 (in millions):

- added (2022-02-02):
[0000833444-22-000005:note_history:81]
|  |  | Three Months Ended December 31, 2021 |  | Three Months Ended December 31, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,299 |  |  | $ | 853 |  |  | $ | 2,152 |  |  | $ | 1,242 |  |  | $ | 792 |  |  | $ | 2,034 |  |
| Building Solutions EMEA/LA |  | 544 |  |  | 415 |  |  | 959 |  |  | 468 |  |  | 480 |  |  | 948 |  |
| Building Solutions Asia Pacific |  | 501 |  |  | 174 |  |  | 675 |  |  | 334 |  |  | 270 |  |  | 604 |  |
| Global Products |  | 2,076 |  |  | — |  |  | 2,076 |  |  | 1,755 |  |  | — |  |  | 1,755 |  |
| Total |  | $ | 4,420 |  |  | $ | 1,442 |  |  | $ | 5,862 |  |  | $ | 3,799 |  |  | $ | 1,542 |  |  | $ | 5,341 |  |

- changed (2022-02-02):
[0000833444-22-000005:note_history:82]
The following table presents further disaggregation of Global Products segment revenues by product type for the three months ended December 31, 2021 and 2020 (in millions):
  (was, 2021-07-30, similarity 0.9429):
[0000833444-21-000040:note_history:82]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and nine months ended June 30, 2021 and 2020 (in millions):

- changed (2022-02-02):
[0000833444-22-000005:note_history:83]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| HVAC |  | $ | 1,483 |  |  | $ | 1,218 |  |  |  |  |  |
| Fire & Security |  | 544 |  |  | 488 |  |  |  |  |  |
| Industrial Refrigeration |  | 49 |  |  | 49 |  |  |  |  |  |
| Total |  | $ | 2,076 |  |  | $ | 1,755 |  |  |  |  |  |
  (was, 2021-07-30, similarity 0.7105):
[0000833444-21-000040:note_history:83]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC |  | $ | 1,811 |  |  | $ | 1,503 |  |  | $ | 4,462 |  |  | $ | 4,127 |  |
| Fire & Security |  | 580 |  |  | 422 |  |  | 1,605 |  |  | 1,425 |  |
| Industrial Refrigeration |  | 64 |  |  | 54 |  |  | 176 |  |  | 173 |  |
| Total |  | $ | 2,455 |  |  | $ | 1,979 |  |  | $ | 6,243 |  |  | $ | 5,725 |  |

- changed (2022-02-02):
[0000833444-22-000005:note_history:84]
Contract assets relate to the Company’s right to consideration for performance obligations satisfied but not billed and consist of unbilled receivables and costs in excess of billings. Contract liabilities relate to customer payments received in advance of satisfaction of performance obligations under the contract. Contract balances are classified as assets or liabilities on a contract-by-contract basis at the end of each reporting period.
  (was, 2021-07-30, similarity 0.9466):
[0000833444-21-000040:note_history:84]
Contract assets relate to the Company’s right to consideration for performance obligations satisfied but not billed and consist of unbilled receivables and costs in excess of billings. Contract liabilities relate to customer payments received in advance of satisfaction of performance obligations under the contract. Contract liabilities consist of deferred revenue. Contract balances are classified as assets or liabilities on a contract-by-contract basis at the end of each reporting period.

- added (2022-02-02):
[0000833444-22-000005:note_history:85]
|  |  | Location of contract balances |  | December 31, 2021 |  | September 30, 2021 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,806 |  |  | $ | 1,718 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 98 |  |  | 99 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,845) |  |  | (1,637) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (287) |  |  | (269) |  |  |  |

- changed (2022-02-02):
[0000833444-22-000005:note_history:86]
For the three months ended December 31, 2021 and December 31, 2020, the Company recognized revenue of $751 million and $714 million, respectively, that was included in the beginning of period contract liability balance.
  (was, 2021-07-30, similarity 0.6007):
[0000833444-21-000040:note_history:86]
For the three months ended June 30, 2021 and June 30, 2020, the Company recognized revenue of $149 million and $125 million, respectively, that was included in the beginning of period contract liability balance. For the nine months ended June 30, 2021 and June 30, 2020, the Company recognized revenue of $1,084 million and $1,137 million, respectively, that was included in the beginning of period contract liability balance.

- changed (2022-02-02):
[0000833444-22-000005:note_history:87]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of December 31, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $16.5 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.
  (was, 2021-07-30, similarity 0.9939):
[0000833444-21-000040:note_history:87]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of June 30, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $15.6 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

- added (2022-02-02):
[0000833444-22-000005:note_history:88]
The following table presents the location and amount of costs to obtain or fulfill a contract recorded in the Company's consolidated statements of financial position (in millions):

- added (2022-02-02):
[0000833444-22-000005:note_history:89]
|  |  | December 31, 2021 |  | September 30, 2021 |  |  |
| Other current assets |  | $ | 149 |  |  | $ | 149 |  |  |  |
| Other noncurrent assets |  | 120 |  |  | 117 |  |  |  |
| Total |  | $ | 269 |  |  | $ | 266 |  |  |  |

- changed (2022-02-02):
[0000833444-22-000005:note_history:90]
During the three months ended December 31, 2021 and 2020, the Company recognized amortization expense of $50 million and $41 million, respectively, related to costs to obtain or fulfill a contract.  There were no impairment losses recognized in the three months ended December 31, 2021 and 2020.
  (was, 2021-07-30, similarity 0.643):
[0000833444-21-000040:note_history:90]
During the three months ended June 30, 2021 and 2020, the Company recognized amortization expense of $48 million and $47 million, respectively, related to costs to obtain or fulfill a contract. During the nine months ended June 30, 2021 and 2020, the Company recognized amortization expense of $136 million and $116 million, respectively, related to costs to 
obtain or fulfill a contract. There were no impairment losses recognized in the three and nine months ended June 30, 2021 and 2020.

- removed (2022-02-02):
[0000833444-21-000040:note_history:91]
|  |  | Three Months Ended June 30, 2021 |  | Three Months Ended June 30, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,355 |  |  | $ | 857 |  |  | $ | 2,212 |  |  | $ | 1,250 |  |  | $ | 770 |  |  | $ | 2,020 |  |
| Building Solutions EMEA/LA |  | 468 |  |  | 494 |  |  | 962 |  |  | 346 |  |  | 410 |  |  | 756 |  |
| Building Solutions Asia Pacific |  | 422 |  |  | 290 |  |  | 712 |  |  | 344 |  |  | 244 |  |  | 588 |  |
| Global Products |  | 2,455 |  |  | — |  |  | 2,455 |  |  | 1,979 |  |  | — |  |  | 1,979 |  |
| Total |  | $ | 4,700 |  |  | $ | 1,641 |  |  | $ | 6,341 |  |  | $ | 3,919 |  |  | $ | 1,424 |  |  | $ | 5,343 |  |

- removed (2022-02-02):
[0000833444-21-000040:note_history:92]
|  |  | Nine Months Ended June 30, 2021 |  | Nine Months Ended June 30, 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,869 |  |  | $ | 2,469 |  |  | $ | 6,338 |  |  | $ | 3,963 |  |  | $ | 2,399 |  |  | $ | 6,362 |  |
| Building Solutions EMEA/LA |  | 1,323 |  |  | 1,442 |  |  | 2,765 |  |  | 1,203 |  |  | 1,331 |  |  | 2,534 |  |
| Building Solutions Asia Pacific |  | 1,096 |  |  | 834 |  |  | 1,930 |  |  | 986 |  |  | 756 |  |  | 1,742 |  |
| Global Products |  | 6,243 |  |  | — |  |  | 6,243 |  |  | 5,725 |  |  | — |  |  | 5,725 |  |
| Total |  | $ | 12,531 |  |  | $ | 4,745 |  |  | $ | 17,276 |  |  | $ | 11,877 |  |  | $ | 4,486 |  |  | $ | 16,363 |  |

- removed (2022-02-02):
[0000833444-21-000040:note_history:93]
|  |  | Location of contract balances |  | June 30, 2021 |  | September 30, 2020 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,553 |  |  | $ | 1,395 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 95 |  |  | 104 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,649) |  |  | (1,435) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (263) |  |  | (245) |  |  |  |
| Total |  |  |  | $ | (264) |  |  | $ | (181) |  |  |  |

- removed (2022-02-02):
[0000833444-21-000040:note_history:94]
As of June 30, 2021, the Company recorded the costs to obtain or fulfill a contract of $258 million, of which $143 million is recorded within other current assets and $115 million is recorded within other noncurrent assets in the consolidated statements of financial position. As of September 30, 2020, the Company recorded the costs to obtain or fulfill a contract of $223 million, of which $119 million is recorded within other current assets and $104 million is recorded within other noncurrent assets in the consolidated statements of financial position.
