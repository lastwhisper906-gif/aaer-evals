# JCI notes — 0000833444-18-000044


## jci:ComponentsOfNetFinancingChargesTableTextBlock

[0000833444-18-000044:notes:1]
The Company's net financing charges line item in the consolidated statements of income for the three and nine months ended June 30, 2018 and 2017 contained the following components (in millions):

[0000833444-18-000044:notes:2]
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Interest expense, net of capitalized interest costs | $ | 110 |  |  | $ | 115 |  |  | $ | 328 |  |  | $ | 343 |  |
| Banking fees and bond cost amortization | 14 |  |  | 14 |  |  | 41 |  |  | 55 |  |
| Interest income | (10 | ) |  | (4 | ) |  | (24 | ) |  | (16 | ) |
| Net foreign exchange results for financing activities | (13 | ) |  | (1 | ) |  | (13 | ) |  | (6 | ) |
| Net financing charges | $ | 101 |  |  | $ | 124 |  |  | $ | 332 |  |  | $ | 376 |  |


## jci:DisposalGroupIncludingDiscontinuedOperationsIncomeStatementDisclosuresTableTextBlock

[0000833444-18-000044:notes:3]
The following table summarizes the results of Adient, reclassified as discontinued operations for the nine month period ended June 30, 2017 (in millions). As the Adient spin-off occurred on October 31, 2016, there is only one month of Adient results included in the nine month period ended June 30, 2017.

[0000833444-18-000044:notes:4]
|  | Nine Months EndedJune 30, |
|  | 2017 |
| Net sales | $ | 1,434 |  |
| Income from discontinued operations before income taxes | 1 |  |
| Provision for income taxes on discontinued operations | 35 |  |
| Income from discontinued operations attributable to noncontrolling interests, net of tax | 9 |  |
| Loss from discontinued operations | $ | (43 | ) |


## jci:EquityAttributableToParentAndNoncontrollingInterestsTableTextBlock

[0000833444-18-000044:notes:5]
[same as prior period, unchanged from 0000833444-18-000021:notes:5]

[0000833444-18-000044:notes:6]
|  | Three Months Ended June 30, 2018 |  | Three Months Ended June 30, 2017 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, March 31 | $ | 20,874 |  |  | $ | 1,006 |  |  | $ | 21,880 |  |  | $ | 19,388 |  |  | $ | 813 |  |  | $ | 20,201 |  |
| Total comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | 723 |  |  | 71 |  |  | 794 |  |  | 555 |  |  | 66 |  |  | 621 |  |
| Foreign currency translation adjustments | (557 | ) |  | (44 | ) |  | (601 | ) |  | 268 |  |  | 3 |  |  | 271 |  |
| Realized and unrealized gains (losses) on derivatives | 3 |  |  | (1 | ) |  | 2 |  |  | (7 | ) |  | (1 | ) |  | (8 | ) |
| Realized and unrealized losses on marketable securities | — |  |  | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Other comprehensive income (loss) | (554 | ) |  | (45 | ) |  | (599 | ) |  | 258 |  |  | 2 |  |  | 260 |  |
| Comprehensive income | 169 |  |  | 26 |  |  | 195 |  |  | 813 |  |  | 68 |  |  | 881 |  |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (240 | ) |  | — |  |  | (240 | ) |  | (234 | ) |  | — |  |  | (234 | ) |
| Repurchases of ordinary shares | (56 | ) |  | — |  |  | (56 | ) |  | (307 | ) |  | — |  |  | (307 | ) |
| Change in noncontrolling interest share | — |  |  | 4 |  |  | 4 |  |  | — |  |  | 3 |  |  | 3 |  |
| Other, including options exercised | 26 |  |  | — |  |  | 26 |  |  | 71 |  |  | — |  |  | 71 |  |
| Ending balance, June 30 | $ | 20,773 |  |  | $ | 1,036 |  |  | $ | 21,809 |  |  | $ | 19,731 |  |  | $ | 884 |  |  | $ | 20,615 |  |

[0000833444-18-000044:notes:7]
|  | Nine Months Ended June 30, 2018 |  | Nine Months Ended June 30, 2017 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, September 30, | $ | 20,447 |  |  | $ | 920 |  |  | $ | 21,367 |  |  | $ | 24,118 |  |  | $ | 972 |  |  | $ | 25,090 |  |
| Total comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | 1,391 |  |  | 132 |  |  | 1,523 |  |  | 736 |  |  | 127 |  |  | 863 |  |
| Foreign currency translation adjustments | (331 | ) |  | 3 |  |  | (328 | ) |  | (150 | ) |  | (22 | ) |  | (172 | ) |
| Realized and unrealized gains (losses) on derivatives | (2 | ) |  | 1 |  |  | (1 | ) |  | (13 | ) |  | 1 |  |  | (12 | ) |
| Realized and unrealized gains (losses) on marketable securities | (2 | ) |  | — |  |  | (2 | ) |  | 6 |  |  | — |  |  | 6 |  |
| Other comprehensive income (loss) | (335 | ) |  | 4 |  |  | (331 | ) |  | (157 | ) |  | (21 | ) |  | (178 | ) |
| Comprehensive income | 1,056 |  |  | 136 |  |  | 1,192 |  |  | 579 |  |  | 106 |  |  | 685 |  |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (722 | ) |  | — |  |  | (722 | ) |  | (705 | ) |  | — |  |  | (705 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (43 | ) |  | (43 | ) |  | — |  |  | (47 | ) |  | (47 | ) |
| Repurchases of ordinary shares | (255 | ) |  | — |  |  | (255 | ) |  | (426 | ) |  | — |  |  | (426 | ) |
| Change in noncontrolling interest share | — |  |  | 23 |  |  | 23 |  |  | — |  |  | (9 | ) |  | (9 | ) |
| Adoption of ASU 2016-09 | 179 |  |  | — |  |  | 179 |  |  | — |  |  | — |  |  | — |  |
| Spin-off of Adient | — |  |  | — |  |  | — |  |  | (4,038 | ) |  | (138 | ) |  | (4,176 | ) |
| Other, including options exercised | 68 |  |  | — |  |  | 68 |  |  | 203 |  |  | — |  |  | 203 |  |
| Ending balance, June 30 | $ | 20,773 |  |  | $ | 1,036 |  |  | $ | 21,809 |  |  | $ | 19,731 |  |  | $ | 884 |  |  | $ | 20,615 |  |


## jci:OffsettingDerivativeAssetsandLiabilitiesTableTextBlock

[0000833444-18-000044:notes:8]
[same as prior period, unchanged from 0000833444-18-000021:notes:8]

[0000833444-18-000044:notes:9]
|  |  | Fair Value of Assets |  | Fair Value of Liabilities |
|  |  | June 30, |  | September 30, |  | June 30, |  | September 30, |
|  |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Gross amount recognized |  | $ | 81 |  |  | $ | 91 |  |  | $ | 2,948 |  |  | $ | 2,105 |  |
| Gross amount eligible for offsetting |  | (18 | ) |  | (16 | ) |  | (18 | ) |  | (16 | ) |
| Net amount |  | $ | 63 |  |  | $ | 75 |  |  | $ | 2,930 |  |  | $ | 2,089 |  |


## jci:ScheduleOfIntangibleAssetsTableTextBlock

[0000833444-18-000044:notes:10]
[same as prior period, unchanged from 0000833444-18-000021:notes:10]

[0000833444-18-000044:notes:11]
|  | June 30, 2018 |  | September 30, 2017 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Amortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,326 |  |  | $ | (233 | ) |  | $ | 1,093 |  |  | $ | 1,328 |  |  | $ | (137 | ) |  | $ | 1,191 |  |
| Customer relationships | 3,091 |  |  | (605 | ) |  | 2,486 |  |  | 3,168 |  |  | (486 | ) |  | 2,682 |  |
| Miscellaneous | 457 |  |  | (181 | ) |  | 276 |  |  | 389 |  |  | (147 | ) |  | 242 |  |
| Total amortized intangible assets | 4,874 |  |  | (1,019 | ) |  | 3,855 |  |  | 4,885 |  |  | (770 | ) |  | 4,115 |  |
| Unamortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,447 |  |  | — |  |  | 2,447 |  |  | 2,483 |  |  | — |  |  | 2,483 |  |
| Miscellaneous | 122 |  |  | — |  |  | 122 |  |  | 143 |  |  | — |  |  | 143 |  |
|  | 2,569 |  |  | — |  |  | 2,569 |  |  | 2,626 |  |  | — |  |  | 2,626 |  |
| Total intangible assets | $ | 7,443 |  |  | $ | (1,019 | ) |  | $ | 6,424 |  |  | $ | 7,511 |  |  | $ | (770 | ) |  | $ | 6,741 |  |


## jci:ScheduleofsharebasedpaymentawardperformancesharevaluationassumptionsTableTextBlock

[0000833444-18-000044:notes:12]
|  | Nine Months Ended June 30, |
|  | 2018 |  | 2017 |
| Risk-free interest rate | 1.92% |  | 1.40% |
| Expected volatility of the Company’s stock | 21.7% |  | 21.0% |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-18-000044:notes:13]
Commitments and Contingencies

[0000833444-18-000044:notes:14]
Environmental Matters

[0000833444-18-000044:notes:15]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of June 30, 2018, reserves for environmental liabilities totaled $43 million, of which $14 million was recorded within other current liabilities and $29 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities totaled $51 million at September 30, 2017, of which $10 million was recorded within other current liabilities and $41 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At June 30, 2018 and September 30, 2017, the Company recorded conditional asset retirement obligations of $48 million and $61 million, respectively.

[0000833444-18-000044:notes:16]
Asbestos Matters

[0000833444-18-000044:notes:17]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-18-000044:notes:18]
As of June 30, 2018, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $180 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $557 million, of which $54 million was recorded in other current liabilities and $503 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $377 million, of which $41 million was recorded in other current assets, and $336 million was recorded in other noncurrent assets. Assets included $10 million of cash and $274 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at June 30, 2018 was $93 million. As of September 30, 2017, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $181 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $573 million, of which $48 million was recorded in other current liabilities and $525 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $392 million, of which $53 million was recorded in other current assets, and $339 million was recorded in other noncurrent assets. Assets included $22 million of cash and $269 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2017 was $101 million.

[0000833444-18-000044:notes:19]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-18-000044:notes:20]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-18-000044:notes:21]
Insurable Liabilities

[0000833444-18-000044:notes:22]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At June 30, 2018 and September 30, 2017, the insurable liabilities totaled $444 million and $445 million, respectively, of which $80 million and $122 million was recorded within other current liabilities, $25 million and $22 million was recorded within accrued compensation and benefits, and $339 million and $301 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at June 30, 2018 was $21 million, of which $6 million was recorded within other current assets and $15 million was recorded within other noncurrent assets.  The amount of such receivables recorded at September 30, 2017 was $46 million, of which $31 million was recorded within other current assets and $15 million was recorded within other noncurrent assets. The Company maintains captive insurance companies to manage certain of its insurable liabilities.

[0000833444-18-000044:notes:23]
Arbitration Award

[0000833444-18-000044:notes:24]
In September 2017, the Company was subject to an unfavorable arbitration award of approximately $50 million relating to a contractual dispute with a subcontractor used by the Company at an airport construction project in Doha, Qatar. In connection with the unfavorable arbitration award, the Company recorded a charge of $50 million within selling, general and administrative expenses in the consolidated statements of income in the fourth quarter of fiscal 2017. The airport project is being managed by a steering committee. The Company and the subcontractor were working jointly to document claims for increased costs against the steering committee when the subcontractor initiated the arbitration proceeding against the Company. Pursuant to its arbitration proceeding against the Company, the subcontractor sought to recover costs it alleges it incurred due to project delays, additional work and related financing costs. The Company has filed annulment proceedings with respect to the arbitration award in the local court in Qatar. While the award remains outstanding, a portion of the balance will accrue interest at a statutory rate of 9.56%.

[0000833444-18-000044:notes:25]
In a related action, the Company has initiated an arbitration claim against the steering committee related to costs it incurred in connection with delays of the airport construction project, including costs related to the above award. The arbitrator is expected to issue a decision on the Company’s claims against the steering committee by the end of fiscal 2018.

[0000833444-18-000044:notes:26]
Aqueous Film-Forming Foam ("AFFF") Litigation

[0000833444-18-000044:notes:27]
Two of our subsidiaries, Chemguard, Inc. ("Chemguard") and Tyco Fire Products L.P. ("Tyco Fire Products"), have been named, along with other defendant manufacturers, in a number of class action lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and that the use of these products by others at various airbases and airports resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports and airbases. PFOA and PFOS are being studied by the United States Environmental Protection Agency (EPA) and other environmental and health agencies and researchers. The EPA has not issued regulatory limits, however; while those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

[0000833444-18-000044:notes:28]
Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination. As of August 2, 2018, the Company is named in 16 putative class actions in federal courts in six states as set forth below:

[0000833444-18-000044:notes:29]
Colorado

[0000833444-18-000044:notes:30]
| • | District of Colorado - Bell et al. v. The 3M Company et al., filed September 18, 2016. |

[0000833444-18-000044:notes:31]
| • | District of Colorado - Davis et al. v. The 3M Company et al., filed September 22, 2016. |

[0000833444-18-000044:notes:32]
The above cases have been consolidated in the U.S. District Court for the District of Colorado, and a hearing on the plaintiffs’ motion for class certification is expected in 2018 with a trial date schedule for April 2019.

[0000833444-18-000044:notes:33]
Delaware

[0000833444-18-000044:notes:34]
| • | District of Delaware - Anderson v. The 3M Company et al., filed June 12, 2018 in the United States District Court District of Delaware. |

[0000833444-18-000044:notes:35]
Massachusetts

[0000833444-18-000044:notes:36]
| • | District of Massachusetts - Civitarese et al. v. The 3M Company et al., filed April 18, 2018 in the United States District Court of Massachusetts. |

[0000833444-18-000044:notes:37]
Washington

[0000833444-18-000044:notes:38]
| • | Eastern District of Washington - Ackerman et al. v. The 3M Company et al., filed April 5, 2018 in the United States District Court, Eastern District of Washington. |

[0000833444-18-000044:notes:39]
New York

[0000833444-18-000044:notes:40]
| • | Eastern District of New York - Green et al. v. The 3M Company et al., filed March 27, 2017 in Supreme Court of the State of New York, Suffolk County, prior to removal to federal court. |

[0000833444-18-000044:notes:41]
| • | Southern District of New York - Adamo et al. v. The Port Authority of NY and NJ et al., filed August 11, 2017 in Supreme Court of the State of New York, Orange County, prior to removal to federal court. |

[0000833444-18-000044:notes:42]
| • | Southern District of New York - Fogarty et al. v. The Port Authority of NY and NJ et al., filed August 11, 2017 in Supreme Court of the State of New York, Orange County, prior to removal to federal court. |

[0000833444-18-000044:notes:43]
| • | Southern District of New York - Miller et al. v. The Port Authority of NY and NJ et al., filed August 11, 2017 in Supreme Court of the State of New York, Orange County, prior to removal to federal court. |

[0000833444-18-000044:notes:44]
| • | Supreme Court of the State of New York, Suffolk County - Singer et al. v. The 3M Company et al., filed October 10, 2017. |

[0000833444-18-000044:notes:45]
| • | Supreme Court of the State of New York, Suffolk County - Shipman et al. v. The 3M Company et al., filed March 21, 2018. |

[0000833444-18-000044:notes:46]
Pennsylvania

[0000833444-18-000044:notes:47]
| • | Eastern District of Pennsylvania - Bates et al. v. The 3M Company et al., filed September 15, 2016. |

[0000833444-18-000044:notes:48]
| • | Eastern District of Pennsylvania - Grande et al. v. The 3M Company et al., filed October 13, 2016. |

[0000833444-18-000044:notes:49]
| • | Eastern District of Pennsylvania - Yockey et al. v. The 3M Company et al., filed October 24, 2016. |

[0000833444-18-000044:notes:50]
| • | Eastern District of Pennsylvania - Fearnley et al. v. The 3M Company et al., filed December 9, 2016. |

[0000833444-18-000044:notes:51]
The above cases have been consolidated in the U.S. District Court for the Eastern District of Pennsylvania. The defendants' motion to dismiss the complaint in the consolidated proceeding was denied without prejudice and the cases are currently stayed pending the appeal of an action in which the Company is not a party.

[0000833444-18-000044:notes:52]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. 3M Co., No. 904029-18 (N.Y. Sup. Ct., Albany County) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites.

[0000833444-18-000044:notes:53]
In addition, as of August 2, 2018, there were a total of 51 individual or “mass” actions filed in state court in Colorado (41 cases), New York (1 case) and Pennsylvania (9 cases) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve approximately 7,000 plaintiffs in Colorado, 26 plaintiffs in New York and 13 plaintiffs in Pennsylvania.  The Company is also on notice of approximately 622 other possible individual product liability claims and 3 possible municipal claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters, and, under Pennsylvania’s procedural rules, they may or may not result in lawsuits.

[0000833444-18-000044:notes:54]
Chemguard and Tyco Fire Products are also defendants in three municipal cases pending in the U.S. District Court for the District of Massachusetts: Town of Barnstable v. the 3M. Co., et al, (filed Nov. 21, 2016), County of Barnstable v. the 3M. Co., et al, (filed January 9, 2017) and City of Westfield v. the 3M Co., et al., (filed on February 24, 2018), as well as two municipal cases pending in the Eastern District of New York: Suffolk County Water Auth. v. 3M Co. (filed November 30, 2017) and Hampton Bays Water Dist. v. 3M Co. (filed Feb. 21, 2018), and one municipal case pending in the Northern District of Florida: Emerald Coast Utilities Auth. v. 3M Co. (filed June 22, 2018). These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property. The defendants have filed motions to dismiss in County of Barnstable and City of Westfield.

[0000833444-18-000044:notes:55]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly resulting from the use of those products at the Peterson Air Force Base. In addition, three water districts in Pennsylvania, Horsham Water and Sewer Authority, Warminster Municipal Authority, and Warrington Township have filed praecipes for summons against Chemguard and Tyco Fire Products and other AFFF manufacturers relating to alleged PFOS and PFOA contamination.  These praecipes are not active suits, but have the effect of tolling the statute of limitations.

[0000833444-18-000044:notes:56]
Other AFFF Matters

[0000833444-18-000044:notes:57]
Tyco Fire Products, in coordination with the Wisconsin Department of Natural Resources (WDNR) and the Wisconsin Department of Health Services (DHS), has been conducting an environmental assessment of its Fire Technology Center (FTC) located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin.  In connection with the assessment, PFOS and PFOA have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC.  Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working closely with WDNR and DHS to develop interim measures to remove these compounds from certain areas where they have been detected.

[0000833444-18-000044:notes:58]
The Company is vigorously defending these cases and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.

[0000833444-18-000044:notes:59]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:DebtDisclosureTextBlock

[0000833444-18-000044:notes:60]
Debt and Financing Arrangements

[0000833444-18-000044:notes:61]
In October 2017, the Company completed the previously announced sale of its Scott Safety business to 3M. Net cash proceeds from the transaction of approximately $1.9 billion were used to repay a significant portion of the TSarl $4.0 billion of merger-related debt. In addition, in March 2018, the Company repaid $26 million in principal amount, plus accrued interest and in April 2018, the Company refinanced approximately $400 million in principal amount, plus accrued interest of the TSarl merger-related debt with commercial paper.

[0000833444-18-000044:notes:62]
In March 2018, the Company increased the committed credit limit from $1.0 billion to $1.25 billion on TSarl's committed revolving credit facility scheduled to expire in August 2020. As of June 30, 2018, there were no draws on the facility.

[0000833444-18-000044:notes:63]
In March 2018, the Company entered into a 364-day $250 million committed revolving credit facility scheduled to expire in March 2019. As of June 30, 2018, there were no draws on the facility.

[0000833444-18-000044:notes:64]
In March 2018, a 364-day $150 million committed revolving credit facility expired. The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2019. As of June 30, 2018, there were no draws on the facility.

[0000833444-18-000044:notes:65]
In February 2018, a 364-day $150 million committed revolving credit facility expired. The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2019. As of June 30, 2018, there were no draws on the facility.

[0000833444-18-000044:notes:66]
In January 2018, a 364-day $250 million committed revolving credit facility expired. The Company entered into a new $200 million committed revolving credit facility scheduled to expire in January 2019. As of June 30, 2018, there were no draws on the facility.

[0000833444-18-000044:notes:67]
In January 2018, the Company retired $67 million in principal amount, plus accrued interest, of its 3.75% fixed rate notes  that expired in January 2018.

[0000833444-18-000044:notes:68]
In December 2017, the Company repaid a 364-day 150 million euro floating rate term loan, plus accrued interest, scheduled  to mature in September 2018.

[0000833444-18-000044:notes:69]
In November 2017, the Company issued 750 million euro in principal amount of 0.0% senior unsecured fixed rate notes due in December 2020. Proceeds from the issuance were used to repay existing debt and for other general corporate purposes.

[0000833444-18-000044:notes:70]
In November 2017, the Company retired $300 million in principal amount, plus accrued interest, of its 1.4% fixed rate notes that expired in November 2017.

[0000833444-18-000044:notes:71]
Net Financing Charges

[0000833444-18-000044:notes:72]
Net financing charges for the nine month period ended June 30, 2017, included $17 million of transaction costs related primarily to the prior year debt exchange offer fees.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-18-000044:notes:73]
[same as prior period, unchanged from 0000833444-18-000021:notes:92]

[0000833444-18-000044:notes:74]
[same as prior period, unchanged from 0000833444-18-000021:notes:93]

[0000833444-18-000044:notes:75]
[same as prior period, unchanged from 0000833444-18-000021:notes:94]

[0000833444-18-000044:notes:76]
The Company has global operations and participates in the foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange hedge contracts. The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the three and nine months ended June 30, 2018 and 2017.

[0000833444-18-000044:notes:77]
The Company selectively hedges anticipated transactions that are subject to commodity price risk, primarily using commodity hedge contracts, to minimize overall price risk associated with the Company’s purchases of lead, copper, tin, aluminum and polypropylene in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. As cash flow hedges, the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions, typically sales, occur and affect earnings. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in commodity prices during the three and nine months ended June 30, 2018 and 2017.

[0000833444-18-000044:notes:78]
[same as prior period, unchanged from 0000833444-18-000021:notes:97]

[0000833444-18-000044:notes:79]
|  |  | Volume Outstanding as of |
| Commodity |  | June 30, 2018 |  | September 30, 2017 |
| Copper |  | 2,948 |  |  | 1,962 |  |
| Polypropylene |  | 8,540 |  |  | 19,563 |  |
| Lead |  | 31,009 |  |  | 24,705 |  |
| Aluminum |  | 3,885 |  |  | 2,169 |  |
| Tin |  | 2,276 |  |  | 1,715 |  |

[0000833444-18-000044:notes:80]
[same as prior period, unchanged from 0000833444-18-000021:notes:99]

[0000833444-18-000044:notes:81]
The Company selectively uses interest rate swaps to reduce market risk associated with changes in interest rates for its fixed-rate bonds. As fair value hedges, the interest rate swaps and related debt balances are valued under a market approach using publicized swap curves. Changes in the fair value of the swap and hedged portion of the debt are recorded in the consolidated statements of income. As of September 30, 2016, the Company had four fixed to floating interest rate swaps totaling $400 million to hedge the coupon of its 2.6% notes that matured in December 2016, three fixed to floating interest rate swaps totaling $300 million to hedge the coupon of its 1.4% notes maturing November 2017 and one fixed to floating interest rate swap totaling $150 million to hedge the coupon of its 7.125% notes maturing July 2017.  In December 2016, the four remaining outstanding interest rate swaps were terminated. The Company had no interest rate swaps outstanding at June 30, 2018 and September 30, 2017, respectively.

[0000833444-18-000044:notes:82]
[same as prior period, unchanged from 0000833444-18-000021:notes:101]

[0000833444-18-000044:notes:83]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company’s net investments globally. At June 30, 2018, the Company had one billion euro, 750 million euro, 423 million euro and 58 million euro bonds designated as net investment hedges in the Company's net investment in Europe and 35 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan. At September 30, 2017, the Company had one billion euro, 423 million euro and 58 million euro bonds designated as net investment hedges in the Company's net investment in Europe and 35 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan.

[0000833444-18-000044:notes:84]
[same as prior period, unchanged from 0000833444-18-000021:notes:103]

[0000833444-18-000044:notes:85]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount.  As of June 30, 2018, the Company hedged approximately 1.8 million shares of its ordinary shares, which have a cost basis of $73 million. As of September 30, 2017, the Company hedged approximately 1.4 million shares of its ordinary shares, which have a cost basis of $58 million.

[0000833444-18-000044:notes:86]
[same as prior period, unchanged from 0000833444-18-000021:notes:105]

[0000833444-18-000044:notes:87]
[same as prior period, unchanged from 0000833444-18-000021:notes:106]

[0000833444-18-000044:notes:88]
[same as prior period, unchanged from 0000833444-18-000021:notes:107]

[0000833444-18-000044:notes:89]
|  | Derivatives and Hedging Activities Designatedas Hedging Instruments under ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instruments under ASC 815 |
|  | June 30, |  | September 30, |  | June 30, |  | September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 8 |  |  | $ | 27 |  |  | $ | 11 |  |  | $ | — |  |
| Commodity derivatives | 2 |  |  | 9 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Equity swap | — |  |  | — |  |  | 60 |  |  | 55 |  |
| Total assets | $ | 10 |  |  | $ | 36 |  |  | $ | 71 |  |  | $ | 55 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 7 |  |  | $ | 21 |  |  | $ | 22 |  |  | $ | 25 |  |
| Commodity derivatives | 3 |  |  | 1 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 2,916 |  |  | 2,058 |  |  | — |  |  | — |  |
| Total liabilities | $ | 2,926 |  |  | $ | 2,080 |  |  | $ | 22 |  |  | $ | 25 |  |

[0000833444-18-000044:notes:90]
[same as prior period, unchanged from 0000833444-18-000021:notes:109]

[0000833444-18-000044:notes:91]
[same as prior period, unchanged from 0000833444-18-000021:notes:110]

[0000833444-18-000044:notes:92]
The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position. Collateral is generally not required of the Company or the counterparties under the master netting agreements. As of June 30, 2018 and September 30, 2017, no cash collateral was received or pledged under the master netting agreements.

[0000833444-18-000044:notes:93]
[same as prior period, unchanged from 0000833444-18-000021:notes:112]

[0000833444-18-000044:notes:94]
The following table presents the pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges for the three and nine months ended June 30, 2018 and 2017 (in millions):

[0000833444-18-000044:notes:95]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Foreign currency exchange derivatives |  | $ | 6 |  |  | $ | (3 | ) |  | $ | 7 |  |  | $ | 3 |  |
| Commodity derivatives |  | — |  |  | 1 |  |  | 2 |  |  | 6 |  |
| Total |  | $ | 6 |  |  | $ | (2 | ) |  | $ | 9 |  |  | $ | 9 |  |

[0000833444-18-000044:notes:96]
The following tables present the location and amount of the pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income for the three and nine months ended June 30, 2018 and 2017 (in millions):

[0000833444-18-000044:notes:97]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Location of Gain (Loss) Reclassified from AOCI into Income |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 2 |  |  | $ | 8 |  |  | $ | 2 |  |  | $ | 24 |  |
| Commodity derivatives |  | Cost of sales |  | 2 |  |  | 3 |  |  | 11 |  |  | 7 |  |
| Total |  |  |  | $ | 4 |  |  | $ | 11 |  |  | $ | 13 |  |  | $ | 31 |  |

[0000833444-18-000044:notes:98]
The following table presents the location and amount of pre-tax gains (losses) on fair value hedges recognized in the Company’s consolidated statements of income for the three and nine months ended June 30, 2018 and 2017 (in millions):

[0000833444-18-000044:notes:99]
| Derivatives in ASC 815 Fair ValueHedging Relationships |  | Location of Gain (Loss) Recognized in Income on Derivative |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Interest rate swap |  | Net financing charges |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (1 | ) |
| Fixed rate debt swapped to floating |  | Net financing charges |  | — |  |  | — |  |  | — |  |  | 2 |  |
| Total |  |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |

[0000833444-18-000044:notes:100]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income for the three and nine months ended June 30, 2018 and 2017 (in millions):

[0000833444-18-000044:notes:101]
|  |  |  |  | Amount of Gain (Loss) Recognized inIncome on Derivative |
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (4 | ) |  | $ | (4 | ) |  | $ | (6 | ) |  | $ | (1 | ) |
| Foreign currency exchange derivatives |  | Net financing charges |  | (27 | ) |  | 51 |  |  | (26 | ) |  | 60 |  |
| Foreign currency exchange derivatives |  | Income tax provision |  | — |  |  | 1 |  |  | 2 |  |  | (2 | ) |
| Foreign currency exchange derivatives |  | Income (loss) from discontinued operations |  | — |  |  | — |  |  | — |  |  | 5 |  |
| Equity swap |  | Selling, general and administrative |  | (3 | ) |  | 2 |  |  | (10 | ) |  | 2 |  |
| Total |  |  |  | $ | (34 | ) |  | $ | 50 |  |  | $ | (40 | ) |  | $ | 64 |  |

[0000833444-18-000044:notes:102]
The pre-tax gains (losses) recorded in CTA within other comprehensive income (loss) related to net investment hedges were $165 million and $(105) million for the three months ended June 30, 2018 and 2017, respectively. The pre-tax gains (losses) recorded in CTA within other comprehensive income (loss) related to net investment hedges were $29 million and $(77) million for the nine months ended June 30, 2018 and 2017, respectively. For the three and nine months ended June 30, 2018 and 2017, no gains or losses were reclassified from CTA into income for the Company’s outstanding net investment hedges.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-18-000044:notes:103]
[same as prior period, unchanged from 0000833444-18-000021:notes:122]

[0000833444-18-000044:notes:104]
During September 2016, the Board of Directors of the Company approved amendments to the Johnson Controls International plc 2012 Share and Incentive Plan (the "Plan"). The types of awards authorized by the Plan comprise of stock options, stock appreciation rights, performance shares, performance units and other stock-based compensation awards. The Compensation Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. Awards are typically granted annually in the Company’s fiscal first quarter. A summary of the stock-based awards granted during the nine month periods ended June 30, 2018 and 2017 is presented below:

[0000833444-18-000044:notes:105]
|  | Nine Months Ended June 30, |
|  | 2018 |  | 2017 |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  | Number Granted |  | Weighted Average Grant Date Fair Value |
| Stock options | 1,376,807 |  |  | $ | 7.04 |  |  | 2,841,686 |  |  | $ | 7.81 |  |
| Stock appreciation rights | — |  |  | — |  |  | 15,693 |  |  | 8.28 |  |
| Restricted stock/units | 2,188,131 |  |  | 37.26 |  |  | 1,671,677 |  |  | 41.75 |  |
| Performance shares | 496,478 |  |  | 36.31 |  |  | 846,725 |  |  | 48.40 |  |

[0000833444-18-000044:notes:106]
[same as prior period, unchanged from 0000833444-18-000021:notes:125]

[0000833444-18-000044:notes:107]
[same as prior period, unchanged from 0000833444-18-000021:notes:126]

[0000833444-18-000044:notes:108]
[same as prior period, unchanged from 0000833444-18-000021:notes:127]

[0000833444-18-000044:notes:109]
|  | Nine Months Ended June 30, |
|  | 2018 |  | 2017 |
| Expected life of option (years) | 6.5 |  | 4.75 & 6.5 |
| Risk-free interest rate | 2.28% |  | 1.23% - 1.93% |
| Expected volatility of the Company’s stock | 23.7% |  | 24.60% |
| Expected dividend yield on the Company’s stock | 2.78% |  | 2.21% |

[0000833444-18-000044:notes:110]
[same as prior period, unchanged from 0000833444-18-000021:notes:129]

[0000833444-18-000044:notes:111]
[same as prior period, unchanged from 0000833444-18-000021:notes:130]

[0000833444-18-000044:notes:112]
[same as prior period, unchanged from 0000833444-18-000021:notes:131]

[0000833444-18-000044:notes:113]
[same as prior period, unchanged from 0000833444-18-000021:notes:132]

[0000833444-18-000044:notes:114]
[same as prior period, unchanged from 0000833444-18-000021:notes:133]

[0000833444-18-000044:notes:115]
[same as prior period, unchanged from 0000833444-18-000021:notes:134]

[0000833444-18-000044:notes:116]
[same as prior period, unchanged from 0000833444-18-000021:notes:135]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-18-000044:notes:117]
[same as prior period, unchanged from 0000833444-18-000021:notes:136]

[0000833444-18-000044:notes:118]
[same as prior period, unchanged from 0000833444-18-000021:notes:137]

[0000833444-18-000044:notes:119]
For the nine months ended June 30, 2017, the income from discontinued operations before income taxes included separation costs of $79 million.

[0000833444-18-000044:notes:120]
For the nine months ended June 30, 2017, the effective tax rate was more than the U.S. federal statutory rate of 35% primarily due to the tax impacts of separation costs and Adient spin-off related tax expense, partially offset by non-U.S. tax rate differentials.

[0000833444-18-000044:notes:121]
The following table summarizes depreciation and amortization, capital expenditures, and significant operating and investing noncash items related to Adient for the nine month period ended June 30, 2017 (in millions):

[0000833444-18-000044:notes:122]
|  | Nine Months EndedJune 30, |
|  | 2017 |
| Depreciation and amortization | $ | 29 |  |
| Equity in earnings of partially-owned affiliates | (31 | ) |
| Deferred income taxes | 562 |  |
| Equity-based compensation | 1 |  |
| Accrued income taxes | (808 | ) |
| Capital expenditures | (91 | ) |

[0000833444-18-000044:notes:123]
[same as prior period, unchanged from 0000833444-18-000021:notes:142]

[0000833444-18-000044:notes:124]
[same as prior period, unchanged from 0000833444-18-000021:notes:143]

[0000833444-18-000044:notes:125]
[same as prior period, unchanged from 0000833444-18-000021:notes:144]

[0000833444-18-000044:notes:126]
[same as prior period, unchanged from 0000833444-18-000021:notes:145]

[0000833444-18-000044:notes:127]
At June 30, 2018, $12 million of certain Corporate assets were classified as held for sale.


## us-gaap:EarningsPerShareTextBlock

[0000833444-18-000044:notes:128]
[same as prior period, unchanged from 0000833444-18-000021:notes:147]

[0000833444-18-000044:notes:129]
[same as prior period, unchanged from 0000833444-18-000021:notes:148]

[0000833444-18-000044:notes:130]
[same as prior period, unchanged from 0000833444-18-000021:notes:149]

[0000833444-18-000044:notes:131]
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Income Available to Ordinary Shareholders |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 723 |  |  | $ | 555 |  |  | $ | 1,391 |  |  | $ | 779 |  |
| Loss from discontinued operations | — |  |  | — |  |  | — |  |  | (43 | ) |
| Basic and diluted income available to shareholders | $ | 723 |  |  | $ | 555 |  |  | $ | 1,391 |  |  | $ | 736 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 925.6 |  |  | 935.4 |  |  | 926.0 |  |  | 937.2 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 5.1 |  |  | 9.0 |  |  | 6.1 |  |  | 9.6 |  |
| Diluted weighted average shares outstanding | 930.7 |  |  | 944.4 |  |  | 932.1 |  |  | 946.8 |  |
| Antidilutive Securities |  |  |  |  |  |  |  |
| Options to purchase shares | 2.1 |  |  | 0.1 |  |  | 1.5 |  |  | 0.1 |  |

[0000833444-18-000044:notes:132]
During the three months ended June 30, 2018 and 2017, the Company declared a dividend of $0.26 and $0.25, respectively, per share. During the nine months ended June 30, 2018 and 2017, the Company declared dividends of $0.78 and $0.75, respectively, per share. The Company paid all dividends in the month subsequent to the end of each fiscal quarter.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-18-000044:notes:133]
[same as prior period, unchanged from 0000833444-18-000021:notes:153]

[0000833444-18-000044:notes:134]
[same as prior period, unchanged from 0000833444-18-000021:notes:154]

[0000833444-18-000044:notes:135]
[same as prior period, unchanged from 0000833444-18-000021:notes:155]

[0000833444-18-000044:notes:136]
[same as prior period, unchanged from 0000833444-18-000021:notes:156]

[0000833444-18-000044:notes:137]
[same as prior period, unchanged from 0000833444-18-000021:notes:157]

[0000833444-18-000044:notes:138]
[same as prior period, unchanged from 0000833444-18-000021:notes:158]

[0000833444-18-000044:notes:139]
[same as prior period, unchanged from 0000833444-18-000021:notes:159]

[0000833444-18-000044:notes:140]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value as of June 30, 2018 and September 30, 2017 (in millions):

[0000833444-18-000044:notes:141]
|  | Fair Value Measurements Using: |
|  | Total as of June 30, 2018 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 19 |  |  | $ | — |  |  | $ | 19 |  |  | $ | — |  |
| Commodity derivatives | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Exchange traded funds (fixed income)1 | 14 |  |  | 14 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Investments in marketable common stock | 4 |  |  | 4 |  |  | — |  |  | — |  |
| Deferred compensation plan assets | 97 |  |  | 97 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 148 |  |  | 148 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 112 |  |  | 112 |  |  | — |  |  | — |  |
| Equity swap | 60 |  |  |  |  |  | 60 |  |  | — |  |
| Total assets | $ | 456 |  |  | $ | 375 |  |  | $ | 81 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 29 |  |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |
| Commodity derivatives | 3 |  |  | — |  |  | 3 |  |  | — |  |
| Total liabilities | $ | 32 |  |  | $ | — |  |  | $ | 32 |  |  | $ | — |  |

[0000833444-18-000044:notes:142]
[same as prior period, unchanged from 0000833444-18-000021:notes:162]

[0000833444-18-000044:notes:143]
1 Classified as restricted investments for payment of asbestos liabilities. See Note 20, "Commitments and Contingencies," of the notes to consolidated financial statements for further details.

[0000833444-18-000044:notes:144]
[same as prior period, unchanged from 0000833444-18-000021:notes:164]

[0000833444-18-000044:notes:145]
[same as prior period, unchanged from 0000833444-18-000021:notes:165]

[0000833444-18-000044:notes:146]
[same as prior period, unchanged from 0000833444-18-000021:notes:166]

[0000833444-18-000044:notes:147]
[same as prior period, unchanged from 0000833444-18-000021:notes:167]

[0000833444-18-000044:notes:148]
[same as prior period, unchanged from 0000833444-18-000021:notes:168]

[0000833444-18-000044:notes:149]
Investments in marketable common stock and exchange traded funds:  Investments in marketable common stock and exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. The Company recorded unrealized gains of $20 million and unrealized losses of $18 million on these investments as of June 30, 2018 within AOCI in the consolidated statements of financial position. The Company recorded unrealized gains of $10 million and unrealized losses of $6 million on these investments  as of September 30, 2017 within AOCI in the consolidated statements of financial position. During the nine months ended June 30, 2018, the Company sold certain marketable common stock for approximately $3 million. As a result, the Company recorded $2 million of realized gains within selling, general and administrative expenses.

[0000833444-18-000044:notes:150]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. The fair value of long-term debt was $10.4 billion and $12.7 billion at June 30, 2018 and September 30, 2017, respectively. The fair value of public debt was $8.7 billion and $8.6 billion, at June 30, 2018 and September 30, 2017, respectively, which was determined primarily using market quotes classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was $1.7 billion and $4.1 billion at June 30, 2018 and September 30, 2017, respectively, which was determined based on quoted market prices for similar instruments classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-18-000044:notes:151]
[same as prior period, unchanged from 0000833444-18-000021:notes:171]

[0000833444-18-000044:notes:152]
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the nine month period ended June 30, 2018 were as follows (in millions):

[0000833444-18-000044:notes:153]
|  |  |  | Business Acquisitions |  | Business Divestitures |  | Currency Translation and Other |  |  |
|  | September 30, |  |  |  |  | June 30, |
|  | 2017 |  |  |  |  | 2018 |
| Building Technologies & Solutions |  |  |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 9,637 |  |  | $ | — |  |  | $ | — |  |  | $ | (45 | ) |  | $ | 9,592 |  |
| Building Solutions EMEA/LA | 2,012 |  |  | — |  |  | — |  |  | (53 | ) |  | 1,959 |  |
| Building Solutions Asia Pacific | 1,255 |  |  | — |  |  | — |  |  | 2 |  |  | 1,257 |  |
| Global Products | 5,687 |  |  | 12 |  |  | (20 | ) |  | (70 | ) |  | 5,609 |  |
| Power Solutions | 1,097 |  |  | — |  |  | — |  |  | (2 | ) |  | 1,095 |  |
| Total | $ | 19,688 |  |  | $ | 12 |  |  | $ | (20 | ) |  | $ | (168 | ) |  | $ | 19,512 |  |

[0000833444-18-000044:notes:154]
[same as prior period, unchanged from 0000833444-18-000021:notes:174]

[0000833444-18-000044:notes:155]
Amortization of other intangible assets included within continuing operations for the three month periods ended June 30, 2018 and 2017 was $100 million and $108 million, respectively. Amortization of other intangible assets included within continuing operations for the nine month periods ended June 30, 2018 and 2017 was $288 million and $383 million, respectively. Excluding the impact of any future acquisitions, the Company anticipates amortization for fiscal 2019, 2020, 2021, 2022 and 2023 will be approximately $388 million, $380 million, $371 million, $365 million and $344 million per year, respectively.


## us-gaap:GuaranteesTextBlock

[0000833444-18-000044:notes:156]
[same as prior period, unchanged from 0000833444-18-000021:notes:176]

[0000833444-18-000044:notes:157]
[same as prior period, unchanged from 0000833444-18-000021:notes:177]

[0000833444-18-000044:notes:158]
[same as prior period, unchanged from 0000833444-18-000021:notes:178]

[0000833444-18-000044:notes:159]
[same as prior period, unchanged from 0000833444-18-000021:notes:179]

[0000833444-18-000044:notes:160]
The changes in the carrying amount of the Company’s total product warranty liability, including extended warranties for which deferred revenue is recorded, for the nine months ended June 30, 2018 and 2017 were as follows (in millions):

[0000833444-18-000044:notes:161]
|  | Nine Months EndedJune 30, |
|  | 2018 |  | 2017 |
| Balance at beginning of period | $ | 409 |  |  | $ | 374 |  |
| Accruals for warranties issued during the period | 225 |  |  | 221 |  |
| Accruals from acquisition and divestitures | 1 |  |  | 2 |  |
| Accruals related to pre-existing warranties | (24 | ) |  | (5 | ) |
| Settlements made (in cash or in kind) during the period | (212 | ) |  | (199 | ) |
| Currency translation | — |  |  | (1 | ) |
| Balance at end of period | $ | 399 |  |  | $ | 392 |  |

[0000833444-18-000044:notes:162]
As a result of the Tyco Merger in the fourth quarter of fiscal 2016, the Company recorded, as part of the acquired liabilities of Tyco, $290 million of post sale contingent tax indemnification liabilities which is generally recorded within other noncurrent liabilities in the consolidated statements of financial position. The liabilities are recorded at fair value and relate to certain tax related matters borne by the buyer of previously divested subsidiaries of Tyco which Tyco has indemnified certain parties and the amounts are probable of being paid. At June 30, 2018 and September 30, 2017, the Company recorded liabilities of $276 million and $290 million, respectively. Of the $276 million recorded as of June 30, 2018, $235 million is related to prior divested businesses and the remainder relates to Tyco’s tax sharing agreements from its 2007 and 2012 spin-off transactions. These are certain guarantees or indemnifications extended among Tyco, Medtronic, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 separation and tax sharing agreements.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0000833444-18-000044:notes:163]
[same as prior period, unchanged from 0000833444-18-000021:notes:183]

[0000833444-18-000044:notes:164]
[same as prior period, unchanged from 0000833444-18-000021:notes:184]

[0000833444-18-000044:notes:165]
[same as prior period, unchanged from 0000833444-18-000021:notes:185]

[0000833444-18-000044:notes:166]
In the first, second and third quarters of fiscal 2017, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2017. As a result, the Company reviewed the long-lived assets for impairment and recorded $69 million of asset impairment charges within restructuring and impairment costs in the consolidated statements of income, of which $15 million was recorded in the first quarter, $23 million was recorded in the second quarter and $31 million was recorded in the third quarter. Of the total impairment charges, $28 million related to the Buildings North America segment, $20 million related to the Global Products segment, $17 million related to Corporate assets and $4 million related to the Power Solutions segment. Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-18-000044:notes:167]
At June 30, 2018 and 2017, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-18-000044:notes:168]
[same as prior period, unchanged from 0000833444-18-000021:notes:188]

[0000833444-18-000044:notes:169]
[same as prior period, unchanged from 0000833444-18-000021:notes:189]

[0000833444-18-000044:notes:170]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended June 30, 2018 and 2017, the Company's effective tax rate was consistent with the statutory tax rate of 12.5%. For the nine months ended June 30, 2018, the Company's effective tax rate was 22% and was higher than the statutory tax rate of 12.5% primarily due to the discrete net impacts of U.S. Tax Reform, final income tax effects of the completed divestiture of the Scott Safety business and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives and tax audit closures. For the nine months ended June 30, 2017, the Company's effective tax rate was 38% and was higher than the statutory tax rate of 12.5% primarily due to the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries related to the divestiture of the Scott Safety business, the income tax effects of pension mark-to-market gains and tax rate differentials, partially offset by the jurisdictional mix of significant restructuring and impairment costs, Tyco Merger transaction and integration costs, purchase accounting adjustments, a tax benefit due to changes in entity tax status and the benefits of continuing global tax planning initiatives.

[0000833444-18-000044:notes:171]
[same as prior period, unchanged from 0000833444-18-000021:notes:191]

[0000833444-18-000044:notes:172]
[same as prior period, unchanged from 0000833444-18-000021:notes:192]

[0000833444-18-000044:notes:173]
[same as prior period, unchanged from 0000833444-18-000021:notes:193]

[0000833444-18-000044:notes:174]
At September 30, 2017, the Company had gross tax effected unrecognized tax benefits of $2,173 million, of which $2,047 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2017 was approximately $99 million (net of tax benefit). The interest and penalties accrued during the nine months ended June 30, 2018 and 2017 were immaterial. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-18-000044:notes:175]
In the first quarter of fiscal 2018, tax audit resolutions resulted in a $25 million net benefit to income tax expense.

[0000833444-18-000044:notes:176]
[same as prior period, unchanged from 0000833444-18-000021:notes:196]

[0000833444-18-000044:notes:177]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2016 |
| China |  | 2008 - 2016 |
| France |  | 2010 - 2012; 2015 - 2016 |
| Germany |  | 2007 - 2015 |
| Spain |  | 2010 - 2012 |
| Switzerland |  | 2011 - 2014 |
| United Kingdom |  | 2011 - 2015 |

[0000833444-18-000044:notes:178]
[same as prior period, unchanged from 0000833444-18-000021:notes:198]

[0000833444-18-000044:notes:179]
On December 22, 2017, the “Tax Cuts and Jobs Act” (H.R. 1) was enacted and significantly revises U.S. corporate income tax by, among other things, lowering corporate income tax rates, imposing a one-time transition tax on deemed repatriated earnings of non-U.S. subsidiaries, and implementing a territorial tax system and various base erosion minimum tax provisions.

[0000833444-18-000044:notes:180]
[same as prior period, unchanged from 0000833444-18-000021:notes:200]

[0000833444-18-000044:notes:181]
[same as prior period, unchanged from 0000833444-18-000021:notes:201]

[0000833444-18-000044:notes:182]
[same as prior period, unchanged from 0000833444-18-000021:notes:202]

[0000833444-18-000044:notes:183]
On October 13, 2016, the U.S. Treasury and the IRS released final and temporary Section 385 regulations. These regulations address whether certain instruments between related parties are treated as debt or equity. The Company does not expect that the regulations will have a material impact on its consolidated financial statements.

[0000833444-18-000044:notes:184]
During the nine months ended June 30, 2018 and 2017, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-18-000044:notes:185]
[same as prior period, unchanged from 0000833444-18-000021:notes:205]

[0000833444-18-000044:notes:186]
In the third quarter of fiscal 2018, the Company recorded $51 million of transaction and integration costs. These costs generated a $6 million tax benefit which reflects the Company's current tax position in these jurisdictions.

[0000833444-18-000044:notes:187]
[same as prior period, unchanged from 0000833444-18-000021:notes:206]

[0000833444-18-000044:notes:188]
[same as prior period, unchanged from 0000833444-18-000021:notes:207]

[0000833444-18-000044:notes:189]
In the first quarter of fiscal 2018, the Company recorded $50 million of transaction and integration costs.  These costs generated a $7 million tax benefit which reflects the Company’s current tax position in these jurisdictions.

[0000833444-18-000044:notes:190]
In the first quarter of fiscal 2018, the Company recorded $158 million of significant restructuring and impairment costs. Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $24 million tax benefit, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-18-000044:notes:191]
In the third quarter of fiscal 2017, the Company recorded $70 million of transaction and integration costs which generated an $11 million tax benefit.

[0000833444-18-000044:notes:192]
In the third quarter of fiscal 2017, the Company recorded pension mark-to-market losses of $45 million which generated an $18 million tax benefit.

[0000833444-18-000044:notes:193]
In the third quarter of fiscal 2017, the Company recorded $49 million of significant restructuring and impairment costs. Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $15 million tax benefit.

[0000833444-18-000044:notes:194]
[same as prior period, unchanged from 0000833444-18-000021:notes:210]

[0000833444-18-000044:notes:195]
[same as prior period, unchanged from 0000833444-18-000021:notes:211]

[0000833444-18-000044:notes:196]
[same as prior period, unchanged from 0000833444-18-000021:notes:212]

[0000833444-18-000044:notes:197]
In the second quarter of fiscal 2017, the Company recorded $99 million of significant restructuring and impairment costs. Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $20 million tax benefit, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-18-000044:notes:198]
[same as prior period, unchanged from 0000833444-18-000021:notes:214]

[0000833444-18-000044:notes:199]
[same as prior period, unchanged from 0000833444-18-000021:notes:215]

[0000833444-18-000044:notes:200]
[same as prior period, unchanged from 0000833444-18-000021:notes:216]

[0000833444-18-000044:notes:201]
In the first quarter of fiscal 2017, the Company recorded $78 million of significant restructuring and impairment costs. Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $14 million tax benefit, which reflects the Company’s current tax position in these jurisdictions.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-18-000044:notes:202]
[same as prior period, unchanged from 0000833444-18-000021:notes:218]

[0000833444-18-000044:notes:203]
[same as prior period, unchanged from 0000833444-18-000021:notes:219]

[0000833444-18-000044:notes:204]
|  | June 30, 2018 |  | September 30, 2017 |
| Raw materials and supplies | $ | 953 |  |  | $ | 919 |  |
| Work-in-process | 578 |  |  | 567 |  |
| Finished goods | 1,978 |  |  | 1,723 |  |
| Inventories | $ | 3,509 |  |  | $ | 3,209 |  |


## us-gaap:LongTermContractsOrProgramsDisclosureTextBlock

[0000833444-18-000044:notes:205]
[same as prior period, unchanged from 0000833444-18-000021:notes:221]

[0000833444-18-000044:notes:206]
The Building Technologies & Solutions business records certain long-term contracts under the percentage-of-completion method of accounting. Under this method, sales and gross profit are recognized as work is performed based on the relationship between actual costs incurred and total estimated costs at completion. The Company records costs and earnings in excess of billings on uncompleted contracts primarily within accounts receivable - net and billings in excess of costs and earnings on uncompleted contracts primarily within deferred revenue in the consolidated statements of financial position. Costs and earnings in excess of billings related to these contracts were $1,025 million and $908 million at June 30, 2018 and September 30, 2017, respectively. Billings in excess of costs and earnings related to these contracts were $545 million and $451 million at June 30, 2018 and September 30, 2017, respectively.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-18-000044:notes:207]
[same as prior period, unchanged from 0000833444-18-000021:notes:223]

[0000833444-18-000044:notes:208]
During the first nine months of fiscal 2018, the Company completed certain acquisitions for a combined purchase price of $24 million, all of which was paid as of June 30, 2018. The acquisitions in the aggregate were not material to the Company’s consolidated financial statements. In connection with the acquisitions, the Company recorded goodwill of $12 million within the Global Products segment.

[0000833444-18-000044:notes:209]
[same as prior period, unchanged from 0000833444-18-000021:notes:225]

[0000833444-18-000044:notes:210]
[same as prior period, unchanged from 0000833444-18-000021:notes:226]

[0000833444-18-000044:notes:211]
In the first nine months of fiscal 2017, the Company completed three acquisitions for a combined purchase price, net of cash acquired, of $9 million, $6 million of which was paid in the nine months ended June 30, 2017. The acquisitions in the aggregate were not material to the Company’s consolidated financial statements.

[0000833444-18-000044:notes:212]
In the second quarter of fiscal 2017, the Company completed the sale of its ADT security business in South Africa within the Building Solutions EMEA/LA segment. The selling price, net of cash divested, was $129 million, all of which was received in the nine months ended June 30, 2017. In connection with the sale, the Company reduced goodwill in assets held for sale by $92 million. The divestiture was not material to the Company's consolidated financial statements.

[0000833444-18-000044:notes:213]
In the first nine months of fiscal 2017, the Company completed one additional divestiture for a sales price of $4 million, all of which was received in the nine months ended June 30, 2017. The divestiture decreased the Company's ownership from a controlling to noncontrolling interest, and as a result, the Company deconsolidated cash of $5 million. The divestiture was not material to the Company's consolidated financial statements.

[0000833444-18-000044:notes:214]
In the first nine months of fiscal 2017, the Company received $52 million in net cash proceeds related to prior year business divestitures and paid $75 million related to prior year business acquisitions.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-18-000044:notes:215]
[same as prior period, unchanged from 0000833444-18-000021:notes:231]

[0000833444-18-000044:notes:216]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2017 filed with the SEC on November 21, 2017. The results of operations for the three and nine month periods ended June 30, 2018 are not necessarily indicative of results for the Company’s 2018 fiscal year because of seasonal and other factors.

[0000833444-18-000044:notes:217]
[same as prior period, unchanged from 0000833444-18-000021:notes:233]

[0000833444-18-000044:notes:218]
[same as prior period, unchanged from 0000833444-18-000021:notes:234]

[0000833444-18-000044:notes:219]
[same as prior period, unchanged from 0000833444-18-000021:notes:235]

[0000833444-18-000044:notes:220]
[same as prior period, unchanged from 0000833444-18-000021:notes:236]

[0000833444-18-000044:notes:221]
[same as prior period, unchanged from 0000833444-18-000021:notes:237]

[0000833444-18-000044:notes:222]
[same as prior period, unchanged from 0000833444-18-000021:notes:238]

[0000833444-18-000044:notes:223]
[same as prior period, unchanged from 0000833444-18-000021:notes:239]

[0000833444-18-000044:notes:224]
[same as prior period, unchanged from 0000833444-18-000021:notes:240]

[0000833444-18-000044:notes:225]
[same as prior period, unchanged from 0000833444-18-000021:notes:241]

[0000833444-18-000044:notes:226]
Based upon the criteria set forth in ASC 810, the Company has determined that it was not the primary beneficiary in any VIEs for the reporting period ended June 30, 2018 and that it was the primary beneficiary in one VIE for the reporting period ended September 30, 2017, as the Company absorbed significant economics of the entity and had the power to direct the activities that are considered most significant to the entity.

[0000833444-18-000044:notes:227]
In fiscal 2012, a pre-existing VIE accounted for under the equity method was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The Company acquired additional interests in two of the reorganized group entities. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company was considered the primary beneficiary of one of the entities due to the Company’s power pertaining to decisions over significant activities of the entity. As such, this VIE was consolidated within the Company’s consolidated statements of financial position as of September 30, 2017. During the quarter ended December 31, 2017, certain joint venture agreements were amended, and as a result, the Company can no longer make key operating decisions considered to be most significant to the VIE. As such, the Company is no longer considered the primary beneficiary of this entity, and the Company deconsolidated the entity during the quarter ended December 31, 2017. The impact of the entity on the Company’s consolidated statements of income for the nine month periods ended June 30, 2018 and 2017 was not material.

[0000833444-18-000044:notes:228]
[same as prior period, unchanged from 0000833444-18-000021:notes:244]

[0000833444-18-000044:notes:229]
[same as prior period, unchanged from 0000833444-18-000021:notes:245]

[0000833444-18-000044:notes:230]
[same as prior period, unchanged from 0000833444-18-000021:notes:246]

[0000833444-18-000044:notes:231]
[same as prior period, unchanged from 0000833444-18-000021:notes:247]

[0000833444-18-000044:notes:232]
As mentioned previously within the "Consolidated VIEs" section above, in fisca1 2012, a pre-existing VIE was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The VIEs are named as co-obligors under a third party debt agreement in the amount of $157 million, maturing in fiscal 2020, under which a VIE could become subject to paying more than its allocated share of the third party debt in the event of bankruptcy of one or more of the other co-obligors. The other co-obligors, all related parties in which the Company is an equity investor, consist of the remaining group entities involved in the reorganization. As part of the overall reorganization transaction, the Company has also provided financial support to the group entities in the form of loans totaling $38 million, which are subordinate to the third party debt agreement. The Company is a significant customer of certain co-obligors, resulting in a remote possibility of loss. Additionally, the Company is subject to a floor guaranty expiring in fiscal 2022; in the event that the other owner party no longer owns any part of the group entities due to sale or transfer, the Company has guaranteed that the proceeds received from the sale or transfer will not be less than $25 million. The Company has partnered with the group entities to design and manufacture battery components for the Power Solutions business. The Company is not considered to be the primary beneficiary of three of the entities as of June 30, 2018 and two of the entities as of September 30, 2017, as the Company cannot make key operating decisions considered to be most significant to the VIEs. Therefore, the entities are accounted for under the equity method of accounting as the Company’s interest exceeds 20% and the Company does not have a controlling interest. The Company’s maximum exposure to loss includes the partially-owned affiliate investment balances of $42 million and $65 million at June 30, 2018 and September 30, 2017, respectively, as well as the subordinated loan from the Company, third party debt agreement and floor guaranty mentioned above. Current liabilities due to the VIEs are not material and represent normal course of business trade payables for all presented periods.

[0000833444-18-000044:notes:233]
[same as prior period, unchanged from 0000833444-18-000021:notes:249]

[0000833444-18-000044:notes:234]
[same as prior period, unchanged from 0000833444-18-000021:notes:250]

[0000833444-18-000044:notes:235]
At June 30, 2018, the Company held restricted cash of approximately $19 million, of which $10 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. At September 30, 2017, the Company held restricted cash of approximately $31 million, of which $22 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash restricted for payment of asbestos liabilities.

[0000833444-18-000044:notes:236]
[same as prior period, unchanged from 0000833444-18-000021:notes:252]

[0000833444-18-000044:notes:237]
[same as prior period, unchanged from 0000833444-18-000021:notes:253]

[0000833444-18-000044:notes:238]
In March 2016, the FASB issued Accounting Standards Update ("ASU") No. 2016-09, "Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting." During the quarter ended December 31, 2017, the Company adopted ASU No. 2016-09. As a result, employee withholding taxes paid to taxing authorities for equity-based compensation transactions, previously classified as cash flows from operating activities, were reclassified to financing activities in the consolidated statements of cash flows for the nine months ended June 30, 2017. Refer to Note 2, "New Accounting Standards," of the notes to consolidated financial statements for further information.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-18-000044:notes:239]
[same as prior period, unchanged from 0000833444-18-000021:notes:255]

[0000833444-18-000044:notes:240]
[same as prior period, unchanged from 0000833444-18-000021:notes:256]

[0000833444-18-000044:notes:241]
|  | U.S. Pension Plans |
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Service cost | $ | 4 |  |  | $ | 4 |  |  | $ | 11 |  |  | $ | 13 |  |
| Interest cost | 27 |  |  | 28 |  |  | 80 |  |  | 85 |  |
| Expected return on plan assets | (58 | ) |  | (57 | ) |  | (172 | ) |  | (174 | ) |
| Net actuarial (gain) loss | — |  |  | 45 |  |  | — |  |  | (90 | ) |
| Settlement (gain) loss | — |  |  | 1 |  |  | — |  |  | (8 | ) |
| Net periodic benefit cost (credit) | $ | (27 | ) |  | $ | 21 |  |  | $ | (81 | ) |  | $ | (174 | ) |

[0000833444-18-000044:notes:242]
|  | Non-U.S. Pension Plans |
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Service cost | $ | 6 |  |  | $ | 8 |  |  | $ | 18 |  |  | $ | 24 |  |
| Interest cost | 14 |  |  | 13 |  |  | 43 |  |  | 36 |  |
| Expected return on plan assets | (29 | ) |  | (23 | ) |  | (87 | ) |  | (68 | ) |
| Net periodic benefit credit | $ | (9 | ) |  | $ | (2 | ) |  | $ | (26 | ) |  | $ | (8 | ) |

[0000833444-18-000044:notes:243]
|  | Postretirement Benefits |
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |
| Interest cost | 2 |  |  | 1 |  |  | 5 |  |  | 4 |  |
| Expected return on plan assets | (2 | ) |  | (2 | ) |  | (7 | ) |  | (7 | ) |
| Net periodic benefit credit | $ | — |  |  | $ | (1 | ) |  | $ | (1 | ) |  | $ | (2 | ) |

[0000833444-18-000044:notes:244]
During the three and nine months ended June 30, 2017, the amount of lump sum payouts triggered a remeasurement event for certain U.S. pension plans resulting in the recognition of net actuarial (gains) losses of $45 million and $(90) million, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-18-000044:notes:245]
Related Party Transactions

[0000833444-18-000044:notes:246]
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-18-000044:notes:247]
The net sales to and purchases from related parties included in the consolidated statements of income were $256 million and $45 million, respectively, for the three months ended June 30, 2018; and $251 million and $64 million, respectively, for the three months ended June 30, 2017. The net sales to and purchases from related parties included in the consolidated statements of income were $720 million and $137 million, respectively, for the nine months ended June 30, 2018; and $705 million and $165 million, respectively, for the nine months ended June 30, 2017.

[0000833444-18-000044:notes:248]
The following table sets forth the amount of accounts receivable due from and payable to related parties in the consolidated statements of financial position (in millions):

[0000833444-18-000044:notes:249]
|  |  | June 30, 2018 |  | September 30, 2017 |  |
| Receivable from related parties |  | $ | 109 |  |  | $ | 108 |  |
| Payable to related parties |  | 51 |  |  | 50 |  |

[0000833444-18-000044:notes:250]
The Company has also provided financial support to certain of its VIE's; see Note 1, "Financial Statements," of the notes to consolidated financial statements for additional information.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-18-000044:notes:251]
[same as prior period, unchanged from 0000833444-18-000021:notes:267]

[0000833444-18-000044:notes:252]
[same as prior period, unchanged from 0000833444-18-000021:notes:268]

[0000833444-18-000044:notes:253]
[same as prior period, unchanged from 0000833444-18-000021:notes:269]

[0000833444-18-000044:notes:254]
[same as prior period, unchanged from 0000833444-18-000021:notes:270]

[0000833444-18-000044:notes:255]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | Total |
| Original reserve | $ | 125 |  |  | $ | 30 |  |  | $ | 3 |  |  | $ | 158 |  |
| Utilized—noncash | — |  |  | (30 | ) |  | — |  |  | (30 | ) |
| Balance at December 31, 2017 | $ | 125 |  |  | $ | — |  |  | $ | 3 |  |  | $ | 128 |  |
| Utilized—cash | (8 | ) |  | — |  |  | (1 | ) |  | (9 | ) |
| Balance at March 31, 2018 | $ | 117 |  |  | $ | — |  |  | $ | 2 |  |  | $ | 119 |  |
| Utilized—cash | (12 | ) |  | — |  |  | (1 | ) |  | (13 | ) |
| Balance at June 30, 2018 | $ | 105 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 106 |  |

[0000833444-18-000044:notes:256]
[same as prior period, unchanged from 0000833444-18-000021:notes:272]

[0000833444-18-000044:notes:257]
[same as prior period, unchanged from 0000833444-18-000021:notes:273]

[0000833444-18-000044:notes:258]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original reserve | $ | 276 |  |  | $ | 77 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 367 |  |
| Utilized—cash | (75 | ) |  | — |  |  | — |  |  | — |  |  | (75 | ) |
| Utilized—noncash | — |  |  | (77 | ) |  | (1 | ) |  | — |  |  | (78 | ) |
| Adjustment to restructuring reserves | 25 |  |  | — |  |  | — |  |  | — |  |  | 25 |  |
| Balance at September 30, 2017 | $ | 226 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |  | $ | 239 |  |
| Utilized—cash | (142 | ) |  | — |  |  | (4 | ) |  | — |  |  | (146 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Balance at June 30, 2018 | $ | 84 |  |  | $ | — |  |  | $ | 9 |  |  | $ | (1 | ) |  | $ | 92 |  |

[0000833444-18-000044:notes:259]
[same as prior period, unchanged from 0000833444-18-000021:notes:275]

[0000833444-18-000044:notes:260]
[same as prior period, unchanged from 0000833444-18-000021:notes:276]

[0000833444-18-000044:notes:261]
[same as prior period, unchanged from 0000833444-18-000021:notes:277]

[0000833444-18-000044:notes:262]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original reserve | $ | 368 |  |  | $ | 190 |  |  | $ | 62 |  |  | $ | — |  |  | $ | 620 |  |
| Acquired Tyco restructuring reserves | 78 |  |  | — |  |  | — |  |  | — |  |  | 78 |  |
| Utilized—cash | (32 | ) |  | — |  |  | — |  |  | — |  |  | (32 | ) |
| Utilized—noncash | — |  |  | (190 | ) |  | (32 | ) |  | 1 |  |  | (221 | ) |
| Balance at September 30, 2016 | $ | 414 |  |  | $ | — |  |  | $ | 30 |  |  | $ | 1 |  |  | $ | 445 |  |
| Adient spin-off impact | (194 | ) |  | — |  |  | (22 | ) |  | — |  |  | (216 | ) |
| Utilized—cash | (86 | ) |  | — |  |  | (2 | ) |  | — |  |  | (88 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Adjustment to restructuring reserves | (25 | ) |  | — |  |  | — |  |  | — |  |  | (25 | ) |
| Transfer to liabilities held for sale | (3 | ) |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Adjustment to acquired Tyco restructuring reserves | (22 | ) |  | — |  |  | — |  |  | — |  |  | (22 | ) |
| Balance at September 30, 2017 | $ | 84 |  |  | $ | — |  |  | $ | 6 |  |  | $ | 2 |  |  | $ | 92 |  |
| Utilized—cash | (16 | ) |  | — |  |  | (2 | ) |  | — |  |  | (18 | ) |
| Balance at June 30, 2018 | $ | 68 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 2 |  |  | $ | 74 |  |

[0000833444-18-000044:notes:263]
The Company's fiscal 2018, 2017 and 2016 restructuring plans included workforce reductions of approximately 9,200 employees (7,300 for the Building Technologies & Solutions business, 1,700 for Corporate and 200 for Power Solutions). Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of June 30, 2018, approximately 4,300 of the employees have been separated from the Company pursuant to the restructuring plans. In addition, the restructuring plans included eleven plant closures in the Building Technologies & Solutions business. As of June 30, 2018, six of the eleven plants have been closed.

[0000833444-18-000044:notes:264]
[same as prior period, unchanged from 0000833444-18-000021:notes:280]


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000833444-18-000044:notes:265]
[same as prior period, unchanged from 0000833444-18-000021:notes:281]

[0000833444-18-000044:notes:266]
|  | Three Months EndedJune 30, |
|  | 2018 |  | 2017 |
| Foreign currency translation adjustments ("CTA") |  |  |  |
| Balance at beginning of period | $ | (255 | ) |  | $ | (1,007 | ) |
| Aggregate adjustment for the period (net of tax effect of $0 and $(5)) | (557 | ) |  | 268 |  |
| Balance at end of period | (812 | ) |  | (739 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | 1 |  |  | 14 |  |
| Current period changes in fair value (net of tax effect of $1 and $(1)) | 5 |  |  | (1 | ) |
| Reclassification to income (net of tax effect of $(2) and $(5)) ** | (2 | ) |  | (6 | ) |
| Balance at end of period | 4 |  |  | 7 |  |
| Realized and unrealized gains (losses) on marketable securities |  |  |  |
| Balance at beginning of period | 2 |  |  | 8 |  |
| Current period changes in fair value (net of tax effect of $0 and $1) | 1 |  |  | (3 | ) |
| Reclassification to income (net of tax effect of $(1) and $0) *** | (1 | ) |  | — |  |
| Balance at end of period | 2 |  |  | 5 |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (2 | ) |  | (2 | ) |
| Other changes | — |  |  | — |  |
| Balance at end of period | (2 | ) |  | (2 | ) |
| Accumulated other comprehensive loss, end of period | $ | (808 | ) |  | $ | (729 | ) |

[0000833444-18-000044:notes:267]
|  | Nine Months EndedJune 30, |
|  | 2018 |  | 2017 |
| CTA |  |  |  |
| Balance at beginning of period | $ | (481 | ) |  | $ | (1,152 | ) |
| Aggregate adjustment for the period (net of tax effect of $1 and $0) * | (331 | ) |  | (150 | ) |
| Adient spin-off impact (net of tax effect of $0) | — |  |  | 563 |  |
| Balance at end of period | (812 | ) |  | (739 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | 6 |  |  | 4 |  |
| Current period changes in fair value (net of tax effect of $2 and $3) | 7 |  |  | 6 |  |
| Reclassification to income (net of tax effect of $(4) and $(12)) ** | (9 | ) |  | (19 | ) |
| Adient spin-off impact (net of tax effect of $0 and $6) | — |  |  | 16 |  |
| Balance at end of period | 4 |  |  | 7 |  |
| Realized and unrealized gains (losses) on marketable securities |  |  |  |
| Balance at beginning of period | 4 |  |  | (1 | ) |
| Current period changes in fair value (net of tax effect of $0 and $1) | (1 | ) |  | 6 |  |
| Reclassification to income (net of tax effect of $(1) and $0) *** | (1 | ) |  | — |  |
| Balance at end of period | 2 |  |  | 5 |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (2 | ) |  | (4 | ) |
| Adient spin-off impact (net of tax effect of $0) | — |  |  | 2 |  |
| Balance at end of period | (2 | ) |  | (2 | ) |
| Accumulated other comprehensive loss, end of period | $ | (808 | ) |  | $ | (729 | ) |

[0000833444-18-000044:notes:268]
* During the nine months ended June 30, 2018, $12 million of cumulative CTA was recognized as part of the divestiture-related gain recognized as part of the divestiture of Scott Safety.

[0000833444-18-000044:notes:269]
[same as prior period, unchanged from 0000833444-18-000021:notes:285]

[0000833444-18-000044:notes:270]
***During the nine months ended June 30, 2018, the Company sold certain marketable common stock for approximately $3 million. As a result, the Company recorded $2 million of realized gains within selling, general and administrative expenses.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000833444-18-000044:notes:271]
[same as prior period, unchanged from 0000833444-18-000021:notes:286]

[0000833444-18-000044:notes:272]
|  | Net Sales |
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Building Technologies & Solutions |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,246 |  |  | $ | 2,142 |  |  | $ | 6,355 |  |  | $ | 6,181 |  |
| Building Solutions EMEA/LA | 926 |  |  | 896 |  |  | 2,748 |  |  | 2,669 |  |
| Building Solutions Asia Pacific | 681 |  |  | 630 |  |  | 1,864 |  |  | 1,767 |  |
| Global Products | 2,429 |  |  | 2,406 |  |  | 6,250 |  |  | 6,214 |  |
|  | 6,282 |  |  | 6,074 |  |  | 17,217 |  |  | 16,831 |  |
| Power Solutions | 1,838 |  |  | 1,609 |  |  | 5,813 |  |  | 5,205 |  |
| Total net sales | $ | 8,120 |  |  | $ | 7,683 |  |  | $ | 23,030 |  |  | $ | 22,036 |  |

[0000833444-18-000044:notes:273]
|  | Segment EBITA |
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Building Technologies & Solutions |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 314 |  |  | $ | 290 |  |  | $ | 780 |  |  | $ | 741 |  |
| Building Solutions EMEA/LA | 96 |  |  | 100 |  |  | 242 |  |  | 238 |  |
| Building Solutions Asia Pacific | 97 |  |  | 85 |  |  | 242 |  |  | 215 |  |
| Global Products | 435 |  |  | 437 |  |  | 949 |  |  | 806 |  |
|  | 942 |  |  | 912 |  |  | 2,213 |  |  | 2,000 |  |
| Power Solutions | 310 |  |  | 304 |  |  | 1,008 |  |  | 996 |  |
| Total segment EBITA | $ | 1,252 |  |  | $ | 1,216 |  |  | $ | 3,221 |  |  | $ | 2,996 |  |
| Corporate expenses | $ | (141 | ) |  | $ | (172 | ) |  | $ | (434 | ) |  | $ | (605 | ) |
| Amortization of intangible assets | (100 | ) |  | (108 | ) |  | (288 | ) |  | (383 | ) |
| Restructuring and impairment costs | — |  |  | (49 | ) |  | (158 | ) |  | (226 | ) |
| Net mark-to-market adjustments on pension plans | — |  |  | (45 | ) |  | — |  |  | 90 |  |
| Net financing charges | (101 | ) |  | (124 | ) |  | (332 | ) |  | (376 | ) |
| Income from continuing operations before income taxes | $ | 910 |  |  | $ | 718 |  |  | $ | 2,009 |  |  | $ | 1,496 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-18-000044:notes:274]
[same as prior period, unchanged from 0000833444-18-000021:notes:289]

[0000833444-18-000044:notes:275]
[same as prior period, unchanged from 0000833444-18-000021:notes:290]

[0000833444-18-000044:notes:276]
[same as prior period, unchanged from 0000833444-18-000021:notes:291]

[0000833444-18-000044:notes:277]
[same as prior period, unchanged from 0000833444-18-000021:notes:292]

[0000833444-18-000044:notes:278]
[same as prior period, unchanged from 0000833444-18-000021:notes:293]

[0000833444-18-000044:notes:279]
[same as prior period, unchanged from 0000833444-18-000021:notes:294]

[0000833444-18-000044:notes:280]
[same as prior period, unchanged from 0000833444-18-000021:notes:295]

[0000833444-18-000044:notes:281]
[same as prior period, unchanged from 0000833444-18-000021:notes:296]

[0000833444-18-000044:notes:282]
[same as prior period, unchanged from 0000833444-18-000021:notes:297]

[0000833444-18-000044:notes:283]
[same as prior period, unchanged from 0000833444-18-000021:notes:298]

[0000833444-18-000044:notes:284]
[same as prior period, unchanged from 0000833444-18-000021:notes:299]

[0000833444-18-000044:notes:285]
[same as prior period, unchanged from 0000833444-18-000021:notes:300]

[0000833444-18-000044:notes:286]
[same as prior period, unchanged from 0000833444-18-000021:notes:301]

[0000833444-18-000044:notes:287]
[same as prior period, unchanged from 0000833444-18-000021:notes:302]

[0000833444-18-000044:notes:288]
[same as prior period, unchanged from 0000833444-18-000021:notes:303]

[0000833444-18-000044:notes:289]
[same as prior period, unchanged from 0000833444-18-000021:notes:304]

[0000833444-18-000044:notes:290]
[same as prior period, unchanged from 0000833444-18-000021:notes:305]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-18-000044:notes:291]
[same as prior period, unchanged from 0000833444-18-000021:notes:306]

[0000833444-18-000044:notes:292]
[same as prior period, unchanged from 0000833444-18-000021:notes:307]

[0000833444-18-000044:notes:293]
As previously disclosed, during the quarter ended December 31, 2017, the Company adopted ASU No. 2016-09. As a result, the Company recognized deferred tax assets of $179 million related to certain operating loss carryforwards resulting from the exercise of employee stock options and restricted stock vestings on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of October 1, 2017.

[0000833444-18-000044:notes:294]
[same as prior period, unchanged from 0000833444-18-000021:notes:309]

[0000833444-18-000044:notes:295]
Following the Tyco Merger, the Company adopted, subject to the ongoing existence of sufficient distributable reserves, the existing Tyco International plc $1 billion share repurchase program in September 2016. In December 2017, the Company's Board of Directors approved an $1 billion increase to its share repurchase authorization. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. For the three and nine month periods ended June 30, 2018, the Company repurchased $56 million and $255 million of its ordinary shares, respectively. For the three and nine month periods ended June 30, 2017, the Company repurchased $307 million and $426 million of its ordinary shares, respectively. As of June 30, 2018, approximately $1.1 billion remains available under the share repurchase program.

[0000833444-18-000044:notes:296]
[same as prior period, unchanged from 0000833444-18-000021:notes:311]

[0000833444-18-000044:notes:297]
[same as prior period, unchanged from 0000833444-18-000021:notes:312]

[0000833444-18-000044:notes:298]
|  | Three Months EndedJune 30, |
|  | 2018 |  | 2017 |
| Beginning balance, March 31 | $ | 235 |  |  | $ | 168 |  |
| Net income | 10 |  |  | 8 |  |
| Foreign currency translation adjustments | (13 | ) |  | 14 |  |
| Realized and unrealized losses on derivatives | (1 | ) |  | (1 | ) |
| Ending balance, June 30 | $ | 231 |  |  | $ | 189 |  |

[0000833444-18-000044:notes:299]
|  | Nine Months EndedJune 30, |
|  | 2018 |  | 2017 |
| Beginning balance, September 30 | $ | 211 |  |  | $ | 234 |  |
| Net income | 35 |  |  | 29 |  |
| Foreign currency translation adjustments | (3 | ) |  | 6 |  |
| Realized and unrealized losses on derivatives | (9 | ) |  | (1 | ) |
| Dividends | (3 | ) |  | (43 | ) |
| Spin-off of Adient | — |  |  | (36 | ) |
| Ending balance, June 30 | $ | 231 |  |  | $ | 189 |  |
