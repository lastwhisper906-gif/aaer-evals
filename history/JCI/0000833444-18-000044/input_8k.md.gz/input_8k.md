# JCI 8-K — 0000833444-18-000040 filed 2018-07-31

## item codes, every 8-K on or before 2018-08-02

- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2018-08-02

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-18-000040:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq3fy18.htm
EXHIBIT 99.1

[0000833444-18-000040:8k_2_02:2]
Exhibit

[0000833444-18-000040:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000833444-18-000040:8k_2_02:4]
| CONTACT: | Investors:Antonella Franzen(609) 720-4665Ryan Edelman(609) 720-4545Media:Fraser Engerman(414) 524-2733 | Exhibit 99.1 |

[0000833444-18-000040:8k_2_02:5]
Johnson Controls reports fiscal Q3 earnings with strong organic growth

[0000833444-18-000040:8k_2_02:6]
and underlying margin expansion

[0000833444-18-000040:8k_2_02:7]
_______________________________________________________________________________

[0000833444-18-000040:8k_2_02:8]
| ▪ | GAAP earnings of $0.78 per share, including special items |

[0000833444-18-000040:8k_2_02:9]
| ▪ | Adjusted EPS from continuing operations of $0.81, up 14% versus prior year |

[0000833444-18-000040:8k_2_02:10]
| ▪ | Sales of $8.1 billion, up 6% versus prior year, reflecting overall organic growth of 6%; +5% Buildings and +10% Power |

[0000833444-18-000040:8k_2_02:11]
| ▪ | Buildings Field orders up 8% organically with continued strong quoting activity |

[0000833444-18-000040:8k_2_02:12]
| ▪ | GAAP EBIT margin expansion of 150 basis points; 70 basis points underlying margin expansion |

[0000833444-18-000040:8k_2_02:13]
| ▪ | Adjusted free cash flow of $0.6 billion in Q3; $1.0 billion year-to-date |

[0000833444-18-000040:8k_2_02:14]
| ▪ | Tightened full year guidance range for adjusted EPS from continuing operations to $2.80 to $2.82 from previous range of $2.75 to $2.85 |

[0000833444-18-000040:8k_2_02:15]
________________________________________________________________________________

[0000833444-18-000040:8k_2_02:16]
CORK, Ireland, July 31, 2018 -- Johnson Controls International plc (NYSE: JCI) today reported fiscal third quarter 2018 GAAP earnings per share (“EPS”) from continuing operations, including special items, of $0.78.  Excluding these items, adjusted EPS from continuing operations was $0.81, up 14% versus the prior year period (see attached footnotes for non-GAAP reconciliation).

[0000833444-18-000040:8k_2_02:17]
Sales of $8.1 billion increased 6% compared to the prior year.  Excluding the impacts of M&A, foreign currency and lead prices, total sales also grew 6% organically.

[0000833444-18-000040:8k_2_02:18]
Page 1 of 18

[0000833444-18-000040:8k_2_02:19]
GAAP earnings before interest and taxes (“EBIT”) was $1,011 million and EBIT margin was 12.5%. Adjusted EBIT was $1,062 million and adjusted EBIT margin was 13.1%, up 10 basis points over the prior year.   Excluding the impact of the Scott Safety divestiture, foreign currency and lead prices, the underlying adjusted EBIT margin increased 70 basis points.

[0000833444-18-000040:8k_2_02:20]
“We delivered another quarter of strong results, with our commitment to execution driving continued operating momentum across the organization.  Organic sales growth accelerated to 6%, with solid growth in both Buildings and Power Solutions.  More disciplined operating fundamentals and processes are driving improved performance against all of our key initiatives, including service, pricing, orders, underlying margins and free cash flow,” said George Oliver, chairman and chief executive officer.

[0000833444-18-000040:8k_2_02:21]
Additionally, I am very pleased with the significant progress we have made on the strategic review of our Power Solutions business, across multiple alternatives.  We expect to conclude the review by the release of our fourth quarter earnings,” Oliver continued.

[0000833444-18-000040:8k_2_02:22]
“Based on our year-to-date performance and continued momentum in the businesses, we are tightening our full year guidance range for adjusted EPS from continuing operations to $2.80 to $2.82.”

[0000833444-18-000040:8k_2_02:23]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-18-000040:8k_2_02:24]
($ millions, except per-share amounts)

[0000833444-18-000040:8k_2_02:25]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the fiscal third quarter of 2017.

[0000833444-18-000040:8k_2_02:26]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q3 2017 |  | Q3 2018 |  | Q3 2017 |  | Q3 2018 |  | Change |
| Sales |  | $7,683 |  | $8,120 |  | $7,669 |  | $8,120 |  | +6% |
| Segment EBITA |  | 1,216 |  | 1,252 |  | 1,212 |  | 1,264 |  | +4% |
| EBIT |  | 842 |  | 1,011 |  | 1,000 |  | 1,062 |  | +6% |
| Net income from continuing operations |  | 555 |  | 723 |  | 671 |  | 755 |  | +13% |
| Diluted EPS from continuing operations |  | $0.59 |  | $0.78 |  | $0.71 |  | $0.81 |  | +14% |

[0000833444-18-000040:8k_2_02:27]
Organic sales growth, adjusted segment EBITA, adjusted EBIT, adjusted EPS from continuing operations and adjusted free cash flow are non-GAAP financial measures. For a reconciliation of these non-GAAP measures and detail of the special items, refer to the attached footnotes.  A slide presentation reviewing third quarter results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-18-000040:8k_2_02:28]
Page 2 of 18

[0000833444-18-000040:8k_2_02:29]
BUSINESS RESULTS

[0000833444-18-000040:8k_2_02:30]
Building Solutions North America

[0000833444-18-000040:8k_2_02:31]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q3 2017 |  | Q3 2018 |  | Q3 2017 |  | Q3 2018 |  | Change |
| Sales |  | $2,142 |  | $2,246 |  | $2,135 |  | $2,246 |  | +5% |
| Segment EBITA |  | $290 |  | $314 |  | $290 |  | $318 |  | +10% |
| Segment EBITA margin % |  | 13.5% |  | 14.0% |  | 13.6% |  | 14.2% |  | +60bps |

[0000833444-18-000040:8k_2_02:32]
Sales in the quarter were $2.2 billion, an increase of 5% versus the prior year quarter.  Excluding M&A and foreign currency, organic sales also increased 5% versus the prior year, driven primarily by strong growth in Fire & Security and HVAC & Controls.

[0000833444-18-000040:8k_2_02:33]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 8% year-over-year.  Backlog at the end of the quarter of $5.4 billion increased 7% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-18-000040:8k_2_02:34]
Adjusted segment EBITA was $318 million, up 10% versus the prior year. Adjusted segment EBITA margin of 14.2% expanded 60 basis points driven by favorable volume and mix as well as cost synergies and productivity savings, partially offset by salesforce additions and, to a lesser extent, lower margin backlog conversion.

[0000833444-18-000040:8k_2_02:35]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-18-000040:8k_2_02:36]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q3 2017 |  | Q3 2018 |  | Q3 2017 |  | Q3 2018 |  | Change |
| Sales |  | $896 |  | $926 |  | $889 |  | $926 |  | +4% |
| Segment EBITA |  | $100 |  | $96 |  | $89 |  | $98 |  | +10% |
| Segment EBITA margin % |  | 11.2% |  | 10.4% |  | 10.0% |  | 10.6% |  | +60bps |

[0000833444-18-000040:8k_2_02:37]
Sales in the quarter were $926 million, an increase of 4% versus the prior year quarter.  Excluding M&A and foreign currency, organic sales were flat with the prior year as stronger service activity was offset primarily by continued softness in project installations in European HVAC and Industrial Refrigeration. By region, growth in Latin America and the Middle East was offset by declines in Europe.

[0000833444-18-000040:8k_2_02:38]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 13% year-over-year.  Backlog at the end of the quarter of $1.6 billion increased 6% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-18-000040:8k_2_02:39]
Page 3 of 18

[0000833444-18-000040:8k_2_02:40]
Adjusted segment EBITA was $98 million, up 10% versus the prior year quarter. Adjusted segment EBITA margin of 10.6% expanded 60 basis points over the prior year, including a 40 basis point headwind related to foreign currency.  Adjusting for foreign currency, the underlying margin improved 100 basis points driven primarily by the benefit from cost synergies and productivity savings.

[0000833444-18-000040:8k_2_02:41]
Building Solutions Asia Pacific

[0000833444-18-000040:8k_2_02:42]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q3 2017 |  | Q3 2018 |  | Q3 2017 |  | Q3 2018 |  | Change |
| Sales |  | $630 |  | $681 |  | $630 |  | $681 |  | +8% |
| Segment EBITA |  | $85 |  | $97 |  | $84 |  | $97 |  | +15% |
| Segment EBITA margin % |  | 13.5% |  | 14.2% |  | 13.3% |  | 14.2% |  | +90bps |

[0000833444-18-000040:8k_2_02:43]
Sales in the quarter were $681 million, an increase of 8% versus the prior year quarter.  Excluding M&A and foreign currency, organic sales increased 4% versus the prior year, with double-digit growth in service and low-single digit growth in project installations.

[0000833444-18-000040:8k_2_02:44]
Orders in the quarter, excluding M&A and adjusted for foreign currency, declined 1% year-over-year.  Backlog at the end of the quarter of $1.5 billion increased 9% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-18-000040:8k_2_02:45]
Adjusted segment EBITA was $97 million, up 15% versus the prior year. Adjusted segment EBITA margin of 14.2% expanded 90 basis points over the prior year, including a 50 basis point headwind related to foreign currency.  Adjusting for foreign currency, the underlying margin improved 140 basis points driven by the benefit of cost synergies and productivity savings as well as favorable volume and mix, partially offset by salesforce additions.

[0000833444-18-000040:8k_2_02:46]
Global Products

[0000833444-18-000040:8k_2_02:47]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q3 2017 |  | Q3 2018 |  | Q3 2017 |  | Q3 2018 |  | Change |
| Sales |  | $2,406 |  | $2,429 |  | $2,406 |  | $2,429 |  | +1% |
| Segment EBITA |  | $437 |  | $435 |  | $445 |  | $441 |  | (1%) |
| Segment EBITA margin % |  | 18.2% |  | 17.9% |  | 18.5% |  | 18.2% |  | (30bps) |

[0000833444-18-000040:8k_2_02:48]
Page 4 of 18

[0000833444-18-000040:8k_2_02:49]
Sales in the quarter were $2.4 billion, an increase of 1% versus the prior year quarter.  Excluding M&A and foreign currency, organic sales increased 7% versus the prior year led by high-single digit growth in both HVAC & Refrigeration Equipment and Building Management Systems, and mid-single digit growth in Specialty Products.

[0000833444-18-000040:8k_2_02:50]
Adjusted segment EBITA was $441 million, down 1% versus the prior year, primarily attributable to the impact of the Scott Safety divestiture.  Adjusted segment EBITA margin of 18.2% declined 30 basis points over the prior year including a 90 basis point headwind related to the divestiture of the Scott Safety business. The underlying margin expanded 60 basis points as favorable volume leverage and the benefit of cost synergies and productivity savings was partially offset by product and channel investments.

[0000833444-18-000040:8k_2_02:51]
Power Solutions

[0000833444-18-000040:8k_2_02:52]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q3 2017 |  | Q3 2018 |  | Q3 2017 |  | Q3 2018 |  | Change |
| Sales |  | $1,609 |  | $1,838 |  | $1,609 |  | $1,838 |  | +14% |
| Segment EBITA |  | $304 |  | $310 |  | $304 |  | $310 |  | +2% |
| Segment EBITA margin % |  | 18.9% |  | 16.9% |  | 18.9% |  | 16.9% |  | (200bps) |

[0000833444-18-000040:8k_2_02:53]
Sales in the quarter were $1.8 billion, an increase of 14% versus the prior year quarter.  Excluding the impact of higher lead pass-through and foreign currency, organic sales increased 10% driven by higher unit volumes, as well as favorable price and technology mix. Global original equipment battery shipments increased 6%, outpacing overall market demand, benefitting from several recent business wins. Aftermarket shipments also grew 6% driven by strong growth in EMEA and China. Start-stop battery shipments increased 30% year-over-year, led by strong growth in China, EMEA and the Americas.

[0000833444-18-000040:8k_2_02:54]
Power Solutions adjusted segment EBITA was $310 million, a 2% increase compared to the prior year.  Adjusted segment EBITA margin of 16.9% decreased 200 basis points compared with the prior year, including a 150 basis point headwind related to the impact of higher lead prices and foreign currency. Power Solution's underlying margin declined 50 basis points as favorable volume mix and productivity savings were more than offset by higher transportation costs and planned incremental investments.

[0000833444-18-000040:8k_2_02:55]
Page 5 of 18

[0000833444-18-000040:8k_2_02:56]
Corporate

[0000833444-18-000040:8k_2_02:57]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q3 2017 |  | Q3 2018 |  | Q3 2017 |  | Q3 2018 |  | Change |
| Corporate expense |  | $(172) |  | $(141) |  | $(122) |  | $(102) |  | (16%) |

[0000833444-18-000040:8k_2_02:58]
Adjusted Corporate expense was $102 million in the quarter, a decrease of 16% compared to the prior year quarter driven primarily by cost synergies and productivity savings.

[0000833444-18-000040:8k_2_02:59]
OTHER ITEMS

[0000833444-18-000040:8k_2_02:60]
| • | Cash from operating activities less capex was $0.4 billion for the quarter and $0.5 billion year-to- date. Adjusted free cash flow was $0.6 billion for the quarter and $1.0 billion year-to-date. Adjusted free cash flow excludes net cash outflows of $0.2 billion in the quarter and $0.5 billion year-to-date primarily related to restructuring and integration costs and nonrecurring tax payments. |

[0000833444-18-000040:8k_2_02:61]
| • | During the quarter, the Company repurchased 1.6 million shares for approximately $60 million; year-to-date share repurchases totaled 6.5 million shares for approximately $250 million. |

[0000833444-18-000040:8k_2_02:62]
###

[0000833444-18-000040:8k_2_02:63]
About Johnson Controls

[0000833444-18-000040:8k_2_02:64]
Johnson Controls is a global diversified technology and multi industrial leader serving a wide range of customers in more than 150 countries. Our 120,000 employees create intelligent buildings, efficient energy solutions, integrated infrastructure and next generation transportation systems that work seamlessly together to deliver on the promise of smart cities and communities. Our commitment to sustainability dates back to our roots in 1885, with the invention of the first electric room thermostat. We are committed to helping our customers win and creating greater value for all of our stakeholders through strategic focus on our buildings and energy growth platforms. For additional information, please visit http://www.johnsoncontrols.com or follow us @johnsoncontrols on Twitter.

[0000833444-18-000040:8k_2_02:65]
###

[0000833444-18-000040:8k_2_02:66]
Page 6 of 18

[0000833444-18-000040:8k_2_02:67]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-18-000040:8k_2_02:68]
###

[0000833444-18-000040:8k_2_02:69]
Page 7 of 18

[0000833444-18-000040:8k_2_02:70]
Non GAAP Financial Information

[0000833444-18-000040:8k_2_02:71]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include mark-to-market for pension and postretirement plans, transaction/integration/separation costs, restructuring and impairment costs, nonrecurring purchase accounting impacts related to the Tyco merger, Scott Safety gain on sale and discrete tax items. Financial information regarding adjusted sales, organic sales, adjusted segment EBITA, adjusted segment EBITA margin and adjusted free cash flow are also presented, which are non-GAAP performance measures. Adjusted segment EBITA excludes special items such as transaction/integration/separation costs and nonrecurring purchase accounting impacts because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.

[0000833444-18-000040:8k_2_02:72]
###

[0000833444-18-000040:8k_2_02:73]
Page 8 of 18

[0000833444-18-000040:8k_2_02:74]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Three Months Ended June 30, |
|  |  | 2018 |  |  | 2017 |
| Net sales | $ | 8,120 |  |  |  | $ | 7,683 |  |
| Cost of sales | 5,648 |  |  |  | 5,252 |  |
|  | Gross profit | 2,472 |  |  |  | 2,431 |  |
| Selling, general and administrative expenses | (1,527 | ) |  |  | (1,609 | ) |
| Restructuring and impairment costs | — |  |  |  | (49 | ) |
| Net financing charges | (101 | ) |  |  | (124 | ) |
| Equity income | 66 |  |  |  | 69 |  |
| Income from continuing operations before income taxes | 910 |  |  |  | 718 |  |
| Income tax provision | 106 |  |  |  | 89 |  |
| Income from continuing operations | 804 |  |  |  | 629 |  |
| Loss from discontinued operations, net of tax | — |  |  |  | — |  |
| Net income | 804 |  |  |  | 629 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 81 |  |  |  | 74 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | — |  |
| Net income attributable to JCI | $ | 723 |  |  |  | $ | 555 |  |
| Income from continuing operations | $ | 723 |  |  |  | $ | 555 |  |
| Loss from discontinued operations | — |  |  |  | — |  |
| Net income attributable to JCI | $ | 723 |  |  |  | $ | 555 |  |
| Diluted earnings per share from continuing operations | $ | 0.78 |  |  |  | $ | 0.59 |  |
| Diluted loss per share from discontinued operations | — |  |  |  | — |  |
| Diluted earnings per share | $ | 0.78 |  |  |  | $ | 0.59 |  |
| Diluted weighted average shares | 930.7 |  |  |  | 944.4 |  |
| Shares outstanding at period end | 924.9 |  |  |  | 932.4 |  |

[0000833444-18-000040:8k_2_02:75]
Page 9 of 18

[0000833444-18-000040:8k_2_02:76]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Nine Months Ended June 30, |
|  |  | 2018 |  |  | 2017 |
| Net sales | $ | 23,030 |  |  |  | $ | 22,036 |  |
| Cost of sales | 16,169 |  |  |  | 15,210 |  |
|  | Gross profit | 6,861 |  |  |  | 6,826 |  |
| Selling, general and administrative expenses | (4,532 | ) |  |  | (4,905 | ) |
| Restructuring and impairment costs | (158 | ) |  |  | (226 | ) |
| Net financing charges | (332 | ) |  |  | (376 | ) |
| Equity income | 170 |  |  |  | 177 |  |
| Income from continuing operations before income taxes | 2,009 |  |  |  | 1,496 |  |
| Income tax provision | 451 |  |  |  | 570 |  |
| Income from continuing operations | 1,558 |  |  |  | 926 |  |
| Loss from discontinued operations, net of tax | — |  |  |  | (34 | ) |
| Net income | 1,558 |  |  |  | 892 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 167 |  |  |  | 147 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | 9 |  |
| Net income attributable to JCI | $ | 1,391 |  |  |  | $ | 736 |  |
| Income from continuing operations | $ | 1,391 |  |  |  | $ | 779 |  |
| Loss from discontinued operations | — |  |  |  | (43 | ) |
| Net income attributable to JCI | $ | 1,391 |  |  |  | $ | 736 |  |
| Diluted earnings per share from continuing operations | $ | 1.49 |  |  |  | $ | 0.82 |  |
| Diluted loss per share from discontinued operations | — |  |  |  | (0.05 | ) |
| Diluted earnings per share* | $ | 1.49 |  |  |  | $ | 0.78 |  |
| Diluted weighted average shares | 932.1 |  |  |  | 946.8 |  |
| Shares outstanding at period end | 924.9 |  |  |  | 932.4 |  |

[0000833444-18-000040:8k_2_02:77]
* May not sum due to rounding.

[0000833444-18-000040:8k_2_02:78]
Page 10 of 18

[0000833444-18-000040:8k_2_02:79]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | June 30,2018 |  | September 30,2017 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 283 |  |  | $ | 321 |  |
| Accounts receivable - net | 6,895 |  |  | 6,666 |  |
| Inventories | 3,509 |  |  | 3,209 |  |
| Assets held for sale | 12 |  |  | 189 |  |
| Other current assets | 1,766 |  |  | 1,907 |  |
|  | Current assets | 12,465 |  |  | 12,292 |  |
| Property, plant and equipment - net | 6,093 |  |  | 6,121 |  |
| Goodwill | 19,512 |  |  | 19,688 |  |
| Other intangible assets - net | 6,424 |  |  | 6,741 |  |
| Investments in partially-owned affiliates | 1,290 |  |  | 1,191 |  |
| Noncurrent assets held for sale | — |  |  | 1,920 |  |
| Other noncurrent assets | 3,622 |  |  | 3,931 |  |
|  | Total assets | $ | 49,406 |  |  | $ | 51,884 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 1,583 |  |  | $ | 1,608 |  |
| Accounts payable and accrued expenses | 5,394 |  |  | 5,342 |  |
| Liabilities held for sale | — |  |  | 72 |  |
| Other current liabilities | 4,324 |  |  | 4,832 |  |
|  | Current liabilities | 11,301 |  |  | 11,854 |  |
| Long-term debt | 10,373 |  |  | 11,964 |  |
| Other noncurrent liabilities | 5,692 |  |  | 6,315 |  |
| Noncurrent liabilities held for sale | — |  |  | 173 |  |
| Redeemable noncontrolling interests | 231 |  |  | 211 |  |
| Shareholders' equity attributable to JCI | 20,773 |  |  | 20,447 |  |
| Noncontrolling interests | 1,036 |  |  | 920 |  |
|  | Total liabilities and equity | $ | 49,406 |  |  | $ | 51,884 |  |

[0000833444-18-000040:8k_2_02:80]
Page 11 of 18

[0000833444-18-000040:8k_2_02:81]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Three Months Ended June 30, |
|  |  |  |  |  |  | 2018 |  |  | 2017 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI | $ | 723 |  |  |  | $ | 555 |  |
| Income from continuing operations attributable to noncontrolling interests | 81 |  |  |  | 74 |  |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | — |  |
| Net income | 804 |  |  |  | 629 |  |
| Adjustments to reconcile net income to cash provided by operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 292 |  |  |  | 281 |  |
|  |  | Pension and postretirement benefit expense (income) | (36 | ) |  |  | 18 |  |
|  |  | Pension and postretirement contributions | (17 | ) |  |  | (17 | ) |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (32 | ) |  |  | (50 | ) |
|  |  | Deferred income taxes | 2 |  |  |  | (3 | ) |
|  |  | Non-cash restructuring and impairment costs | — |  |  |  | 31 |  |
|  |  | Other - net | 37 |  |  |  | 35 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (390 | ) |  |  | (298 | ) |
|  |  |  |  | Inventories | (38 | ) |  |  | (215 | ) |
|  |  |  |  | Other assets | (79 | ) |  |  | (108 | ) |
|  |  |  |  | Restructuring reserves | (51 | ) |  |  | (25 | ) |
|  |  |  |  | Accounts payable and accrued liabilities | 323 |  |  |  | 9 |  |
|  |  |  |  | Accrued income taxes | (87 | ) |  |  | (71 | ) |
|  |  |  |  |  | Cash provided by operating activities | 728 |  |  |  | 216 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (285 | ) |  |  | (362 | ) |
| Sale of property, plant and equipment | 13 |  |  |  | 5 |  |
| Acquisition of businesses, net of cash acquired | (9 | ) |  |  | — |  |
| Business divestitures, net of cash divested | (13 | ) |  |  | — |  |
| Other - net | — |  |  |  | (3 | ) |
|  |  |  |  |  | Cash used by investing activities | (294 | ) |  |  | (360 | ) |
| Financing Activities |  |  |  |  |
| Increase in short and long-term debt - net | 18 |  |  |  | 692 |  |
| Debt financing costs | — |  |  |  | (1 | ) |
| Stock repurchases | (56 | ) |  |  | (307 | ) |
| Payment of cash dividends | (241 | ) |  |  | (234 | ) |
| Proceeds from the exercise of stock options | 3 |  |  |  | 42 |  |
| Dividends paid to noncontrolling interests | — |  |  |  | — |  |
| Cash transferred to Adient related to spin-off | — |  |  |  | — |  |
| Cash paid related to prior acquisitions | — |  |  |  | (38 | ) |
| Other - net | 2 |  |  |  | (1 | ) |
|  |  |  |  |  | Cash provided (used) by financing activities | (274 | ) |  |  | 153 |  |
| Effect of exchange rate changes on cash and cash equivalents | (145 | ) |  |  | 37 |  |
| Increase in cash and cash equivalents | $ | 15 |  |  |  | $ | 46 |  |

[0000833444-18-000040:8k_2_02:82]
Page 12 of 18

[0000833444-18-000040:8k_2_02:83]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Nine Months Ended June 30, |
|  |  |  |  |  |  | 2018 |  |  | 2017 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI | $ | 1,391 |  |  |  | $ | 736 |  |
| Income from continuing operations attributable to noncontrolling interests | 167 |  |  |  | 147 |  |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | 9 |  |
| Net income | 1,558 |  |  |  | 892 |  |
| Adjustments to reconcile net income to cash provided (used) by operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 844 |  |  |  | 919 |  |
|  |  | Pension and postretirement benefit income | (108 | ) |  |  | (184 | ) |
|  |  | Pension and postretirement contributions | (54 | ) |  |  | (275 | ) |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (111 | ) |  |  | (166 | ) |
|  |  | Deferred income taxes | (75 | ) |  |  | 1,056 |  |
|  |  | Non-cash restructuring and impairment costs | 30 |  |  |  | 70 |  |
|  |  | Gain on Scott Safety business divestiture | (114 | ) |  |  | — |  |
|  |  | Other - net | 69 |  |  |  | 117 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (282 | ) |  |  | (319 | ) |
|  |  |  |  | Inventories | (338 | ) |  |  | (585 | ) |
|  |  |  |  | Other assets | (64 | ) |  |  | (258 | ) |
|  |  |  |  | Restructuring reserves | (63 | ) |  |  | 22 |  |
|  |  |  |  | Accounts payable and accrued liabilities | (198 | ) |  |  | (590 | ) |
|  |  |  |  | Accrued income taxes | 167 |  |  |  | (2,002 | ) |
|  |  |  |  |  | Cash provided (used) by operating activities | 1,261 |  |  |  | (1,303 | ) |
| Investing Activities |  |  |  |  |
| Capital expenditures | (782 | ) |  |  | (996 | ) |
| Sale of property, plant and equipment | 23 |  |  |  | 23 |  |
| Acquisition of businesses, net of cash acquired | (24 | ) |  |  | (6 | ) |
| Business divestitures, net of cash divested | 2,101 |  |  |  | 180 |  |
| Other - net | (14 | ) |  |  | (33 | ) |
|  |  |  |  |  | Cash provided (used) by investing activities | 1,304 |  |  |  | (832 | ) |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | (1,524 | ) |  |  | 1,468 |  |
| Debt financing costs | (4 | ) |  |  | (18 | ) |
| Stock repurchases | (255 | ) |  |  | (426 | ) |
| Payment of cash dividends | (714 | ) |  |  | (469 | ) |
| Proceeds from the exercise of stock options | 39 |  |  |  | 130 |  |
| Dividends paid to noncontrolling interests | (46 | ) |  |  | (78 | ) |
| Dividend from Adient spin-off | — |  |  |  | 2,050 |  |
| Cash transferred to Adient related to spin-off | — |  |  |  | (665 | ) |
| Cash paid related to prior acquisitions | — |  |  |  | (75 | ) |
| Other - net | (24 | ) |  |  | (20 | ) |
|  |  |  |  |  | Cash provided (used) by financing activities | (2,528 | ) |  |  | 1,897 |  |
| Effect of exchange rate changes on cash and cash equivalents | (84 | ) |  |  | 12 |  |
| Change in cash held for sale | 9 |  |  |  | 105 |  |
| Decrease in cash and cash equivalents | $ | (38 | ) |  |  | $ | (121 | ) |

[0000833444-18-000040:8k_2_02:84]
Page 13 of 18

[0000833444-18-000040:8k_2_02:85]
FOOTNOTES

[0000833444-18-000040:8k_2_02:86]
1. Financial Summary

[0000833444-18-000040:8k_2_02:87]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, significant restructuring and impairment costs, and the net mark-to-market adjustments related to pension and postretirement plans.

[0000833444-18-000040:8k_2_02:88]
|  | Three Months Ended June 30, |
| (in millions; unaudited) | 2018 |  | 2017 |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,246 |  |  | $ | 2,246 |  |  | $ | 2,142 |  |  | $ | 2,135 |  |
| Building Solutions EMEA/LA | 926 |  |  | 926 |  |  | 896 |  |  | 889 |  |
| Building Solutions Asia Pacific | 681 |  |  | 681 |  |  | 630 |  |  | 630 |  |
| Global Products | 2,429 |  |  | 2,429 |  |  | 2,406 |  |  | 2,406 |  |
| Total Building Technologies & Solutions | 6,282 |  |  | 6,282 |  |  | 6,074 |  |  | 6,060 |  |
| Power Solutions | 1,838 |  |  | 1,838 |  |  | 1,609 |  |  | 1,609 |  |
| Net sales | $ | 8,120 |  |  | $ | 8,120 |  |  | $ | 7,683 |  |  | $ | 7,669 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 314 |  |  | $ | 318 |  |  | $ | 290 |  |  | $ | 290 |  |
| Building Solutions EMEA/LA | 96 |  |  | 98 |  |  | 100 |  |  | 89 |  |
| Building Solutions Asia Pacific | 97 |  |  | 97 |  |  | 85 |  |  | 84 |  |
| Global Products | 435 |  |  | 441 |  |  | 437 |  |  | 445 |  |
| Total Building Technologies & Solutions | 942 |  |  | 954 |  |  | 912 |  |  | 908 |  |
| Power Solutions | 310 |  |  | 310 |  |  | 304 |  |  | 304 |  |
| Segment EBITA | 1,252 |  |  | 1,264 |  |  | 1,216 |  |  | 1,212 |  |
| Corporate expenses (2) | (141 | ) |  | (102 | ) |  | (172 | ) |  | (122 | ) |
| Amortization of intangible assets (3) | (100 | ) |  | (100 | ) |  | (108 | ) |  | (90 | ) |
| Mark-to-market loss for pension plans (4) | — |  |  | — |  |  | (45 | ) |  | — |  |
| Restructuring and impairment costs (5) | — |  |  | — |  |  | (49 | ) |  | — |  |
| EBIT (6) | 1,011 |  |  | 1,062 |  |  | 842 |  |  | 1,000 |  |
| EBIT margin | 12.5 | % |  | 13.1 | % |  | 11.0 | % |  | 13.0 | % |
| Net financing charges (7) | (101 | ) |  | (101 | ) |  | (124 | ) |  | (124 | ) |
| Income from continuing operations before income taxes | 910 |  |  | 961 |  |  | 718 |  |  | 876 |  |
| Income tax provision (8) | (106 | ) |  | (125 | ) |  | (89 | ) |  | (131 | ) |
| Income from continuing operations | 804 |  |  | 836 |  |  | 629 |  |  | 745 |  |
| Income from continuing operations attributable to noncontrolling interests | (81 | ) |  | (81 | ) |  | (74 | ) |  | (74 | ) |
| Net income from continuing operations attributable to JCI | $ | 723 |  |  | $ | 755 |  |  | $ | 555 |  |  | $ | 671 |  |

[0000833444-18-000040:8k_2_02:89]
|  | Nine Months Ended June 30, |
| (in millions; unaudited) | 2018 |  | 2017 |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 6,355 |  |  | $ | 6,355 |  |  | $ | 6,181 |  |  | $ | 6,151 |  |
| Building Solutions EMEA/LA | 2,748 |  |  | 2,748 |  |  | 2,669 |  |  | 2,658 |  |
| Building Solutions Asia Pacific | 1,864 |  |  | 1,864 |  |  | 1,767 |  |  | 1,768 |  |
| Global Products | 6,250 |  |  | 6,250 |  |  | 6,214 |  |  | 6,220 |  |
| Total Building Technologies & Solutions | 17,217 |  |  | 17,217 |  |  | 16,831 |  |  | 16,797 |  |
| Power Solutions | 5,813 |  |  | 5,813 |  |  | 5,205 |  |  | 5,205 |  |
| Net sales | $ | 23,030 |  |  | $ | 23,030 |  |  | $ | 22,036 |  |  | $ | 22,002 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 780 |  |  | $ | 798 |  |  | $ | 741 |  |  | $ | 755 |  |
| Building Solutions EMEA/LA | 242 |  |  | 247 |  |  | 238 |  |  | 233 |  |
| Building Solutions Asia Pacific | 242 |  |  | 242 |  |  | 215 |  |  | 223 |  |
| Global Products | 949 |  |  | 856 |  |  | 806 |  |  | 903 |  |
| Total Building Technologies & Solutions | 2,213 |  |  | 2,143 |  |  | 2,000 |  |  | 2,114 |  |
| Power Solutions | 1,008 |  |  | 1,008 |  |  | 996 |  |  | 997 |  |
| Segment EBITA | 3,221 |  |  | 3,151 |  |  | 2,996 |  |  | 3,111 |  |
| Corporate expenses (2) | (434 | ) |  | (313 | ) |  | (605 | ) |  | (358 | ) |
| Amortization of intangible assets (3) | (288 | ) |  | (288 | ) |  | (383 | ) |  | (285 | ) |
| Mark-to-market gain for pension plans (4) | — |  |  | — |  |  | 90 |  |  | — |  |
| Restructuring and impairment costs (5) | (158 | ) |  | — |  |  | (226 | ) |  | — |  |
| EBIT (6) | 2,341 |  |  | 2,550 |  |  | 1,872 |  |  | 2,468 |  |
| EBIT margin | 10.2 | % |  | 11.1 | % |  | 8.5 | % |  | 11.2 | % |
| Net financing charges (7) | (332 | ) |  | (332 | ) |  | (376 | ) |  | (359 | ) |
| Income from continuing operations before income taxes | 2,009 |  |  | 2,218 |  |  | 1,496 |  |  | 2,109 |  |
| Income tax provision (8) | (451 | ) |  | (288 | ) |  | (570 | ) |  | (316 | ) |
| Income from continuing operations | 1,558 |  |  | 1,930 |  |  | 926 |  |  | 1,793 |  |
| Income from continuing operations attributable to noncontrolling interests | (167 | ) |  | (167 | ) |  | (147 | ) |  | (147 | ) |
| Net income from continuing operations attributable to JCI | $ | 1,391 |  |  | $ | 1,763 |  |  | $ | 779 |  |  | $ | 1,646 |  |

[0000833444-18-000040:8k_2_02:90]
Building Technologies & Solutions - Provides facility systems and services including comfort, energy and security management for the non-residential buildings market, and provides heating, ventilating, and air conditioning products and services, security products and services, and fire detection and suppression products and services.

[0000833444-18-000040:8k_2_02:91]
Power Solutions - Services both automotive original equipment manufacturers and the battery aftermarket by providing advanced battery technology, coupled with systems engineering, marketing and service expertise.

[0000833444-18-000040:8k_2_02:92]
Page 14 of 18

[0000833444-18-000040:8k_2_02:93]
(1) The Company's press release contains financial information regarding adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures.  The Company's definition of adjusted segment EBITA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-18-000040:8k_2_02:94]
The following is the three months ended June 30, 2018 and 2017 reconciliation of net sales, segment EBITA and segment EBITA margin as reported to adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-18-000040:8k_2_02:95]
| (in millions) | Building SolutionsNorth America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | Total Building Technologies & Solutions |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales as reported | $ | 2,246 |  |  | $ | 2,142 |  |  | $ | 926 |  |  | $ | 896 |  |  | $ | 681 |  |  | $ | 630 |  |  | $ | 2,429 |  |  | $ | 2,406 |  |  | $ | 6,282 |  |  | $ | 6,074 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring purchase accounting impacts | — |  |  | (7 | ) |  | — |  |  | (7 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (14 | ) |
| Adjusted net sales | $ | 2,246 |  |  | $ | 2,135 |  |  | $ | 926 |  |  | $ | 889 |  |  | $ | 681 |  |  | $ | 630 |  |  | $ | 2,429 |  |  | $ | 2,406 |  |  | $ | 6,282 |  |  | $ | 6,060 |  |
| Segment EBITA as reported | $ | 314 |  |  | $ | 290 |  |  | $ | 96 |  |  | $ | 100 |  |  | $ | 97 |  |  | $ | 85 |  |  | $ | 435 |  |  | $ | 437 |  |  | $ | 942 |  |  | $ | 912 |  |
| Segment EBITA margin as reported | 14.0 | % |  | 13.5 | % |  | 10.4 | % |  | 11.2 | % |  | 14.2 | % |  | 13.5 | % |  | 17.9 | % |  | 18.2 | % |  | 15.0 | % |  | 15.0 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | 2 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 6 |  |
| Integration costs | 4 |  |  | 10 |  |  | 2 |  |  | — |  |  | — |  |  | — |  |  | 6 |  |  | 4 |  |  | 12 |  |  | 14 |  |
| Nonrecurring purchase accounting impacts | — |  |  | (12 | ) |  | — |  |  | (11 | ) |  | — |  |  | (1 | ) |  | — |  |  | — |  |  | — |  |  | (24 | ) |
| Adjusted segment EBITA | $ | 318 |  |  | $ | 290 |  |  | $ | 98 |  |  | $ | 89 |  |  | $ | 97 |  |  | $ | 84 |  |  | $ | 441 |  |  | $ | 445 |  |  | $ | 954 |  |  | $ | 908 |  |
| Adjusted segment EBITA margin | 14.2 | % |  | 13.6 | % |  | 10.6 | % |  | 10.0 | % |  | 14.2 | % |  | 13.3 | % |  | 18.2 | % |  | 18.5 | % |  | 15.2 | % |  | 15.0 | % |

[0000833444-18-000040:8k_2_02:96]
| (in millions) | Total Building Technologies & Solutions |  | Power Solutions |  | Consolidated JCI plc |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales as reported | $ | 6,282 |  |  | $ | 6,074 |  |  | $ | 1,838 |  |  | $ | 1,609 |  |  | $ | 8,120 |  |  | $ | 7,683 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring purchase accounting impacts | — |  |  | (14 | ) |  | — |  |  | — |  |  | — |  |  | (14 | ) |
| Adjusted net sales | $ | 6,282 |  |  | $ | 6,060 |  |  | $ | 1,838 |  |  | $ | 1,609 |  |  | $ | 8,120 |  |  | $ | 7,669 |  |
| Segment EBITA as reported | $ | 942 |  |  | $ | 912 |  |  | $ | 310 |  |  | $ | 304 |  |  | $ | 1,252 |  |  | $ | 1,216 |  |
| Segment EBITA margin as reported | 15.0 | % |  | 15.0 | % |  | 16.9 | % |  | 18.9 | % |  | 15.4 | % |  | 15.8 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | 6 |  |  | — |  |  | — |  |  | — |  |  | 6 |  |
| Integration costs | 12 |  |  | 14 |  |  | — |  |  | — |  |  | 12 |  |  | 14 |  |
| Nonrecurring purchase accounting impacts | — |  |  | (24 | ) |  | — |  |  | — |  |  | — |  |  | (24 | ) |
| Adjusted segment EBITA | $ | 954 |  |  | $ | 908 |  |  | $ | 310 |  |  | $ | 304 |  |  | $ | 1,264 |  |  | $ | 1,212 |  |
| Adjusted segment EBITA margin | 15.2 | % |  | 15.0 | % |  | 16.9 | % |  | 18.9 | % |  | 15.6 | % |  | 15.8 | % |

[0000833444-18-000040:8k_2_02:97]
The following is the nine months ended June 30, 2018 and 2017 reconciliation of net sales, segment EBITA and segment EBITA margin as reported to adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-18-000040:8k_2_02:98]
| (in millions) | Building SolutionsNorth America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | Total Building Technologies & Solutions |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales as reported | $ | 6,355 |  |  | $ | 6,181 |  |  | $ | 2,748 |  |  | $ | 2,669 |  |  | $ | 1,864 |  |  | $ | 1,767 |  |  | $ | 6,250 |  |  | $ | 6,214 |  |  | $ | 17,217 |  |  | $ | 16,831 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring purchase accounting impacts | — |  |  | (30 | ) |  | — |  |  | (11 | ) |  | — |  |  | 1 |  |  | — |  |  | 6 |  |  | — |  |  | (34 | ) |
| Adjusted net sales | $ | 6,355 |  |  | $ | 6,151 |  |  | $ | 2,748 |  |  | $ | 2,658 |  |  | $ | 1,864 |  |  | $ | 1,768 |  |  | $ | 6,250 |  |  | $ | 6,220 |  |  | $ | 17,217 |  |  | $ | 16,797 |  |
| Segment EBITA as reported | $ | 780 |  |  | $ | 741 |  |  | $ | 242 |  |  | $ | 238 |  |  | $ | 242 |  |  | $ | 215 |  |  | $ | 949 |  |  | $ | 806 |  |  | $ | 2,213 |  |  | $ | 2,000 |  |
| Segment EBITA margin as reported | 12.3 | % |  | 12.0 | % |  | 8.8 | % |  | 8.9 | % |  | 13.0 | % |  | 12.2 | % |  | 15.2 | % |  | 13.0 | % |  | 12.9 | % |  | 11.9 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | 13 |  |  | — |  |  | 5 |  |  | — |  |  | 2 |  |  | — |  |  | 13 |  |  | — |  |  | 33 |  |
| Integration costs | 18 |  |  | 24 |  |  | 5 |  |  | 4 |  |  | — |  |  | 3 |  |  | 21 |  |  | 13 |  |  | 44 |  |  | 44 |  |
| Scott Safety gain on sale | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (114 | ) |  | — |  |  | (114 | ) |  | — |  |
| Nonrecurring purchase accounting impacts | — |  |  | (23 | ) |  | — |  |  | (14 | ) |  | — |  |  | 3 |  |  | — |  |  | 71 |  |  | — |  |  | 37 |  |
| Adjusted segment EBITA | $ | 798 |  |  | $ | 755 |  |  | $ | 247 |  |  | $ | 233 |  |  | $ | 242 |  |  | $ | 223 |  |  | $ | 856 |  |  | $ | 903 |  |  | $ | 2,143 |  |  | $ | 2,114 |  |
| Adjusted segment EBITA margin | 12.6 | % |  | 12.3 | % |  | 9.0 | % |  | 8.8 | % |  | 13.0 | % |  | 12.6 | % |  | 13.7 | % |  | 14.5 | % |  | 12.4 | % |  | 12.6 | % |

[0000833444-18-000040:8k_2_02:99]
| (in millions) | Total Building Technologies & Solutions |  | Power Solutions |  | Consolidated JCI plc |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales as reported | $ | 17,217 |  |  | $ | 16,831 |  |  | $ | 5,813 |  |  | $ | 5,205 |  |  | $ | 23,030 |  |  | $ | 22,036 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring purchase accounting impacts | — |  |  | (34 | ) |  | — |  |  | — |  |  | — |  |  | (34 | ) |
| Adjusted net sales | $ | 17,217 |  |  | $ | 16,797 |  |  | $ | 5,813 |  |  | $ | 5,205 |  |  | $ | 23,030 |  |  | $ | 22,002 |  |
| Segment EBITA as reported | $ | 2,213 |  |  | $ | 2,000 |  |  | $ | 1,008 |  |  | $ | 996 |  |  | $ | 3,221 |  |  | $ | 2,996 |  |
| Segment EBITA margin as reported | 12.9 | % |  | 11.9 | % |  | 17.3 | % |  | 19.1 | % |  | 14.0 | % |  | 13.6 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | 33 |  |  | — |  |  | 1 |  |  | — |  |  | 34 |  |
| Integration costs | 44 |  |  | 44 |  |  | — |  |  | — |  |  | 44 |  |  | 44 |  |
| Scott Safety gain on sale | (114 | ) |  | — |  |  | — |  |  | — |  |  | (114 | ) |  | — |  |
| Nonrecurring purchase accounting impacts | — |  |  | 37 |  |  | — |  |  | — |  |  | — |  |  | 37 |  |
| Adjusted segment EBITA | $ | 2,143 |  |  | $ | 2,114 |  |  | $ | 1,008 |  |  | $ | 997 |  |  | $ | 3,151 |  |  | $ | 3,111 |  |
| Adjusted segment EBITA margin | 12.4 | % |  | 12.6 | % |  | 17.3 | % |  | 19.2 | % |  | 13.7 | % |  | 14.1 | % |

[0000833444-18-000040:8k_2_02:100]
(2) Adjusted Corporate expenses for the three months ended June 30, 2018 excludes $37 million of integration costs and $2 million of transaction costs.  Adjusted Corporate expenses for the nine months ended June 30, 2018 excludes $111 million of integration costs and $10 million of transaction costs.  Adjusted Corporate expenses for the three months ended June 30, 2017 excludes $40 million of integration costs and $10 million of transaction costs.  Adjusted Corporate expenses for the nine months ended June 30, 2017 excludes $185 million of integration costs, $58 million of transaction costs and $4 million of separation costs.

[0000833444-18-000040:8k_2_02:101]
(3) Adjusted amortization of intangible assets for the three and nine months ended June 30, 2017 excludes $18 million and $98 million, respectively, of nonrecurring asset amortization related to Tyco purchase accounting.

[0000833444-18-000040:8k_2_02:102]
(4) The three months ended June 30, 2017 pension mark-to-market loss of $45 million and the nine months ended June 30, 2017 pension mark-to-market gain of $90 million due to lump sum payouts for certain U.S. pension plans are excluded from the adjusted non-GAAP results.

[0000833444-18-000040:8k_2_02:103]
(5) Restructuring and impairment costs for the nine months ended June 30, 2018 of $158 million are excluded from the adjusted non-GAAP results.  Restructuring and impairment costs for the three and nine months ended June 30, 2017 of $49 million and $226 million, respectively, are excluded from the adjusted non-GAAP results.

[0000833444-18-000040:8k_2_02:104]
(6) Management defines earnings before interest and taxes (EBIT) as income from continuing operations before net financing charges, income taxes and noncontrolling interests.

[0000833444-18-000040:8k_2_02:105]
(7) Adjusted net financing charges for the nine months ended June 30, 2017 exclude $17 million of transaction costs related to the debt exchange offers.

[0000833444-18-000040:8k_2_02:106]
(8) Adjusted income tax provision for the three months ended June 30, 2018 excludes the tax benefits of the change in effective tax rate from 14% to 13% on the first and second quarters of $13 million and integration costs of $6 million.  Adjusted income tax provision for the nine months ended June 30, 2018 excludes the net tax provision related to the U.S. Tax Reform legislation of $204 million and the Scott Safety gain on sale of $30 million, partially offset by the tax benefits for tax audit settlements of $25 million, restructuring and impairment costs of $24 million, integration costs of $21 million and transaction costs of $1 million.  Adjusted income tax provision for the three months ended June 30, 2017 excludes the tax benefits of the pension mark-to-market loss of $18 million, restructuring and impairment costs of $15 million, integration costs of $9 million and transaction costs of $2 million, partially offset by the tax provision for Tyco nonrecurring purchase accounting impacts of $2 million.  Adjusted income tax provision for the nine months ended June 30, 2017 excludes the non-cash tax charge of $457 million related to establishment of a deferred tax liability on the outside basis difference of the Company’s investment in certain subsidiaries of the Scott Safety business and the tax provision for the pension mark-to-market net gain of $36 million, partially offset by the tax benefits of changes in entity tax status of $101 million, restructuring and impairment costs of $49 million, integration costs of $41 million, Tyco nonrecurring purchase accounting impacts of $36 million and transaction costs of $12 million.

[0000833444-18-000040:8k_2_02:107]
Page 15 of 18

[0000833444-18-000040:8k_2_02:108]
2. Diluted Earnings Per Share Reconciliation

[0000833444-18-000040:8k_2_02:109]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure.  The adjusting items include transaction/integration/separation costs, nonrecurring purchase accounting impacts related to the Tyco merger, mark-to-market gain or loss for pension and postretirement plans, Scott Safety gain on sale, restructuring and impairment costs and discrete tax items.  The Company excludes these items because they are not considered to be directly related to the underlying operating performance of the Company.  Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-18-000040:8k_2_02:110]
A reconciliation of diluted earnings per share as reported to diluted adjusted earnings per share for the respective periods is shown below (unaudited):

[0000833444-18-000040:8k_2_02:111]
|  | Net Income Attributable to JCI plc |  | Net Income Attributableto JCI plc fromContinuing Operations |
|  | Three Months Ended |  | Three Months Ended |
|  | June 30, |  | June 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Earnings per share as reported for JCI plc | $ | 0.78 |  |  | $ | 0.59 |  |  | $ | 0.78 |  |  | $ | 0.59 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | 0.02 |  |  | — |  |  | 0.02 |  |
| Related tax impact | — |  |  | — |  |  | — |  |  | — |  |
| Integration costs | 0.05 |  |  | 0.06 |  |  | 0.05 |  |  | 0.06 |  |
| Related tax impact | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |
| Nonrecurring purchase accounting impacts | — |  |  | (0.01 | ) |  | — |  |  | (0.01 | ) |
| Related tax impact | — |  |  | — |  |  | — |  |  | — |  |
| Mark-to-market loss for pension plans | — |  |  | 0.05 |  |  | — |  |  | 0.05 |  |
| Related tax impact | — |  |  | (0.02 | ) |  | — |  |  | (0.02 | ) |
| Restructuring and impairment costs | — |  |  | 0.05 |  |  | — |  |  | 0.05 |  |
| Related tax impact | — |  |  | (0.02 | ) |  | — |  |  | (0.02 | ) |
| Discrete tax items | (0.01 | ) |  | — |  |  | (0.01 | ) |  | — |  |
| Adjusted earnings per share for JCI plc | $ | 0.81 |  |  | $ | 0.71 |  |  | $ | 0.81 |  |  | $ | 0.71 |  |

[0000833444-18-000040:8k_2_02:112]
|  | Net Income Attributable to JCI plc |  | Net Income Attributableto JCI plc fromContinuing Operations |
|  | Nine Months Ended |  | Nine Months Ended |
|  | June 30, |  | June 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Earnings per share as reported for JCI plc | $ | 1.49 |  |  | $ | 0.78 |  |  | $ | 1.49 |  |  | $ | 0.82 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction costs | 0.01 |  |  | 0.12 |  |  | 0.01 |  |  | 0.12 |  |
| Related tax impact | — |  |  | (0.01 | ) |  | — |  |  | (0.01 | ) |
| Integration costs | 0.17 |  |  | 0.24 |  |  | 0.17 |  |  | 0.24 |  |
| Related tax impact | (0.02 | ) |  | (0.04 | ) |  | (0.02 | ) |  | (0.04 | ) |
| Separation costs | — |  |  | 0.09 |  |  | — |  |  | — |  |
| Nonrecurring purchase accounting impacts | — |  |  | 0.14 |  |  | — |  |  | 0.14 |  |
| Related tax impact | — |  |  | (0.04 | ) |  | — |  |  | (0.04 | ) |
| Mark-to-market gain for pension plans | — |  |  | (0.10 | ) |  | — |  |  | (0.10 | ) |
| Related tax impact | — |  |  | 0.04 |  |  | — |  |  | 0.04 |  |
| Scott Safety gain on sale | (0.12 | ) |  | — |  |  | (0.12 | ) |  | — |  |
| Related tax impact | 0.03 |  |  | — |  |  | 0.03 |  |  | — |  |
| Restructuring and impairment costs | 0.17 |  |  | 0.24 |  |  | 0.17 |  |  | 0.24 |  |
| Related tax impact | (0.03 | ) |  | (0.05 | ) |  | (0.03 | ) |  | (0.05 | ) |
| Discrete tax items | 0.19 |  |  | 0.40 |  |  | 0.19 |  |  | 0.38 |  |
| Adjusted earnings per share for JCI plc* | $ | 1.89 |  |  | $ | 1.80 |  |  | $ | 1.89 |  |  | $ | 1.74 |  |

[0000833444-18-000040:8k_2_02:113]
* May not sum due to rounding.

[0000833444-18-000040:8k_2_02:114]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-18-000040:8k_2_02:115]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, |  | June 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Weighted Average Shares Outstanding for JCI plc |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 925.6 |  |  | 935.4 |  |  | 926.0 |  |  | 937.2 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock |  |  |  |  |  |  |  |
| and unvested performance share awards | 5.1 |  |  | 9.0 |  |  | 6.1 |  |  | 9.6 |  |
| Diluted weighted average shares outstanding | 930.7 |  |  | 944.4 |  |  | 932.1 |  |  | 946.8 |  |

[0000833444-18-000040:8k_2_02:116]
The Company has presented forward-looking statements regarding adjusted EPS from continuing operations, adjusted EBIT margin, organic adjusted net sales growth and adjusted free cash flow conversion (defined as adjusted free cash flow divided by adjusted net income from continuing operations attributable to JCI) for the full fiscal year of 2018, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts, expenses, income or cash flows from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts that are excluded from these non-GAAP financial measures are a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period, including but not limited to the high variability of the net mark-to-market adjustments related to pension and postretirement plans and the effect of foreign currency exchange fluctuations.  Our fiscal 2018 outlook for organic adjusted net sales growth also excludes the effect of acquisitions and divestitures, and for our Power Solutions business, the impacts of lead price fluctuations.  We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available and management cannot reliably predict all of the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s full year 2018 GAAP financial results.

[0000833444-18-000040:8k_2_02:117]
Page 16 of 18

[0000833444-18-000040:8k_2_02:118]
3. Organic Adjusted Net Sales Growth Reconciliation

[0000833444-18-000040:8k_2_02:119]
The components of the changes in adjusted net sales for the three months ended June 30, 2018 versus the three months ended June 30, 2017, including organic net sales, is shown below (unaudited):

[0000833444-18-000040:8k_2_02:120]
| (in millions) | Adjusted Net Sales for the Three Months Ended June 30, 2017 |  | Base Year Adjustments -Divestitures |  | Adjusted Base Net Sales for the Three Months Ended June 30, 2017 |  | Foreign Currency |  | Lead Impact |  | Organic Net Sales |  | Adjusted Net Sales for the Three Months EndedJune 30, 2018 |
| Building Solutions North America | $ | 2,135 |  |  | $ | — |  |  | 0.0 | % |  | $ | 2,135 |  |  | $ | 8 |  |  | 0.4 | % |  | $ | — |  |  | 0.0 | % |  | $ | 103 |  |  | 4.8 | % |  | $ | 2,246 |  |  | 5.2 | % |
| Building Solutions EMEA/LA | 889 |  |  | — |  |  | 0.0 | % |  | 889 |  |  | 33 |  |  | 3.7 | % |  | — |  |  | 0.0 | % |  | 4 |  |  | 0.4 | % |  | 926 |  |  | 4.2 | % |
| Building Solutions Asia Pacific | 630 |  |  | (3 | ) |  | -0.5 | % |  | 627 |  |  | 26 |  |  | 4.1 | % |  | — |  |  | 0.0 | % |  | 28 |  |  | 4.5 | % |  | 681 |  |  | 8.6 | % |
| Global Products | 2,406 |  |  | (175 | ) |  | -7.3 | % |  | 2,231 |  |  | 35 |  |  | 1.6 | % |  | — |  |  | 0.0 | % |  | 163 |  |  | 7.3 | % |  | 2,429 |  |  | 8.9 | % |
| Total Building Technologies & Solutions | 6,060 |  |  | (178 | ) |  | -2.9 | % |  | 5,882 |  |  | 102 |  |  | 1.7 | % |  | — |  |  | 0.0 | % |  | 298 |  |  | 5.1 | % |  | 6,282 |  |  | 6.8 | % |
| Power Solutions | 1,609 |  |  | — |  |  | 0.0 | % |  | 1,609 |  |  | 37 |  |  | 2.3 | % |  | 31 |  |  | 1.9 | % |  | 161 |  |  | 10.0 | % |  | 1,838 |  |  | 14.2 | % |
| Total net sales | $ | 7,669 |  |  | $ | (178 | ) |  | -2.3 | % |  | $ | 7,491 |  |  | $ | 139 |  |  | 1.9 | % |  | $ | 31 |  |  | 0.4 | % |  | $ | 459 |  |  | 6.1 | % |  | $ | 8,120 |  |  | 8.4 | % |

[0000833444-18-000040:8k_2_02:121]
The components of the changes in adjusted net sales for the nine months ended June 30, 2018 versus the nine months ended June 30, 2017, including organic net sales, is shown below (unaudited):

[0000833444-18-000040:8k_2_02:122]
| (in millions) | Adjusted Net Sales for the Nine Months Ended June 30, 2017 |  | Base Year Adjustments -Divestitures |  | Adjusted Base Net Sales for the Nine Months Ended June 30, 2017 |  | Foreign Currency |  | Lead Impact |  | Organic Net Sales |  | Adjusted Net Sales for the Nine Months EndedJune 30, 2018 |
| Building Solutions North America | $ | 6,151 |  |  | $ | — |  |  | 0.0 | % |  | $ | 6,151 |  |  | $ | 28 |  |  | 0.5 | % |  | $ | — |  |  | 0.0 | % |  | $ | 176 |  |  | 2.9 | % |  | $ | 6,355 |  |  | 3.3 | % |
| Building Solutions EMEA/LA | 2,658 |  |  | (80 | ) |  | -3.0 | % |  | 2,578 |  |  | 160 |  |  | 6.2 | % |  | — |  |  | 0.0 | % |  | 10 |  |  | 0.4 | % |  | 2,748 |  |  | 6.6 | % |
| Building Solutions Asia Pacific | 1,768 |  |  | (12 | ) |  | -0.7 | % |  | 1,756 |  |  | 75 |  |  | 4.3 | % |  | — |  |  | 0.0 | % |  | 33 |  |  | 1.9 | % |  | 1,864 |  |  | 6.2 | % |
| Global Products | 6,220 |  |  | (474 | ) |  | -7.6 | % |  | 5,746 |  |  | 127 |  |  | 2.2 | % |  | — |  |  | 0.0 | % |  | 377 |  |  | 6.6 | % |  | 6,250 |  |  | 8.8 | % |
| Total Building Technologies & Solutions | 16,797 |  |  | (566 | ) |  | -3.4 | % |  | 16,231 |  |  | 390 |  |  | 2.4 | % |  | — |  |  | 0.0 | % |  | 596 |  |  | 3.7 | % |  | 17,217 |  |  | 6.1 | % |
| Power Solutions | 5,205 |  |  | — |  |  | 0.0 | % |  | 5,205 |  |  | 228 |  |  | 4.4 | % |  | 230 |  |  | 4.4 | % |  | 150 |  |  | 2.9 | % |  | 5,813 |  |  | 11.7 | % |
| Total net sales | $ | 22,002 |  |  | $ | (566 | ) |  | -2.6 | % |  | $ | 21,436 |  |  | $ | 618 |  |  | 2.9 | % |  | $ | 230 |  |  | 1.1 | % |  | $ | 746 |  |  | 3.5 | % |  | $ | 23,030 |  |  | 7.4 | % |

[0000833444-18-000040:8k_2_02:123]
4. Adjusted Free Cash Flow Reconciliation

[0000833444-18-000040:8k_2_02:124]
The Company's press release contains financial information regarding free cash flow and adjusted free cash flow, which are non-GAAP performance measures.  Free cash flow is defined as cash used by operating activities less capital expenditures.  Adjusted free cash flow excludes special items, as included in the table below, because these cash flows are not considered to be directly related to its underlying business.  Management believes these non-GAAP measures are useful to investors in understanding the strength of the Company and its ability to generate cash.

[0000833444-18-000040:8k_2_02:125]
The following is the three and nine months ended June 30, 2018 and 2017 reconciliation of free cash flow and adjusted free cash flow (unaudited):

[0000833444-18-000040:8k_2_02:126]
| (in billions) | Three Months Ended June 30, 2018 |  | Three Months Ended June 30, 2017 |  | Nine Months Ended June 30, 2018 |  | Nine Months Ended June 30, 2017 |
| Cash provided (used) by operating activities | $ | 0.7 |  |  | $ | 0.2 |  |  | $ | 1.3 |  |  | $ | (1.3 | ) |
| Capital expenditures | (0.3 | ) |  | (0.4 | ) |  | (0.8 | ) |  | (1.0 | ) |
| Reported free cash flow* | $ | 0.4 |  |  | $ | (0.1 | ) |  | $ | 0.5 |  |  | $ | (2.3 | ) |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction/integration/separation costs | — |  |  | 0.1 |  |  | 0.2 |  |  | 0.4 |  |
| Nonrecurring tax payments | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | 1.4 |  |
| Adient cash outflow | — |  |  | — |  |  | — |  |  | 0.3 |  |
| Change in control pension payment | — |  |  | — |  |  | — |  |  | 0.2 |  |
| Restructuring costs | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.2 |  |
| Total adjusting items | 0.2 |  |  | 0.3 |  |  | 0.5 |  |  | 2.5 |  |
| Adjusted free cash flow | $ | 0.6 |  |  | $ | 0.2 |  |  | $ | 1.0 |  |  | $ | 0.2 |  |

[0000833444-18-000040:8k_2_02:127]
*May not sum due to rounding.

[0000833444-18-000040:8k_2_02:128]
Page 17 of 18

[0000833444-18-000040:8k_2_02:129]
5. Net Debt to Capitalization

[0000833444-18-000040:8k_2_02:130]
The Company provides financial information regarding net debt as a percentage of total capitalization, which is a non-GAAP performance measure.  The Company believes the percentage of total net debt to total capitalization is useful to understanding the Company's financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders.  The following is the June 30, 2018 and September 30, 2017 calculation of net debt as a percentage of total capitalization (unaudited):

[0000833444-18-000040:8k_2_02:131]
| (in millions) | June 30, 2018 |  | September 30, 2017 |
| Short-term debt and current portion of long-term debt | $ | 1,583 |  |  | $ | 1,608 |  |
| Long-term debt | 10,373 |  |  | 11,964 |  |
| Total debt | 11,956 |  |  | 13,572 |  |
| Less: cash and cash equivalents | 283 |  |  | 321 |  |
| Total net debt | 11,673 |  |  | 13,251 |  |
| Shareholders' equity attributable to JCI | 20,773 |  |  | 20,447 |  |
| Total capitalization | $ | 32,446 |  |  | $ | 33,698 |  |
| Total net debt as a % of total capitalization | 36.0 | % |  | 39.3 | % |

[0000833444-18-000040:8k_2_02:132]
6. Mark-to-Market of Pension and Postretirement Plans

[0000833444-18-000040:8k_2_02:133]
The pension and postretirement mark-to-market gain or loss for each period is excluded from adjusted diluted earnings per share.  There was no mark-to-market gain or loss for pension and postretirement plans for the three and nine months ended June 30, 2018.  The three months ended June 30, 2017 includes a pension mark-to-market loss of $45 million and the nine months ended June 30, 2017 includes a pension mark-to-market gain of $90 million recorded due to lump sum payouts for certain U.S. pension plans.

[0000833444-18-000040:8k_2_02:134]
7. Divestitures

[0000833444-18-000040:8k_2_02:135]
On March 16, 2017, the Company announced that it signed a definitive agreement to sell its Scott Safety business to 3M for approximately $2.0 billion.  The transaction closed on October 4, 2017.  Net cash proceeds from the transaction approximated $1.9 billion and the Company recorded a net gain of $114 million ($84 million after tax).  Scott Safety is a leader in the design, manufacture and sale of high performance respiratory protection, gas and flame detection, thermal imaging and other critical products for fire services, law enforcement, industrial, oil and gas, chemical, armed forces, and homeland defense end markets.  The Scott Safety business is included within assets held for sale and liabilities held for sale in the accompanying condensed consolidated statement of financial position as of September 30, 2017.

[0000833444-18-000040:8k_2_02:136]
On October 31, 2017, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience business from JCI plc to Adient plc and the issuance of ordinary shares of Adient plc directly to holders of JCI plc ordinary shares on a pro rata basis.  Following the separation, Adient plc is now an independent public company trading on the New York Stock Exchange (NYSE) under the symbol "ADNT." The Company did not retain any equity interest in Adient plc.  Beginning in the first quarter of fiscal 2017, Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation.

[0000833444-18-000040:8k_2_02:137]
8. Income Taxes

[0000833444-18-000040:8k_2_02:138]
The Company's effective tax rate from continuing operations before consideration of the transaction/integration/separation costs, nonrecurring purchase accounting impacts related to the Tyco merger, mark-to-market gains or losses for pension and postretirement plans, Scott Safety gain on sale, restructuring and impairment costs and discrete tax items for the nine months ending June 30, 2018 and June 30, 2017 is approximately 13 percent and 15 percent, respectively.

[0000833444-18-000040:8k_2_02:139]
9. Restructuring

[0000833444-18-000040:8k_2_02:140]
The nine months ended June 30, 2018 include restructuring and impairment costs of $158 million related primarily to workforce reductions, plant closures and asset impairments in the Building Technologies & Solutions and Power Solutions businesses, and at Corporate.  The three and nine months ended June 30, 2017 restructuring and impairment costs of $49 million and $226 million, respectively, related primarily to workforce reductions, plant closures and asset impairments in the Building Technologies & Solutions and Power Solutions businesses, and at Corporate.

[0000833444-18-000040:8k_2_02:141]
Page 18 of 18
