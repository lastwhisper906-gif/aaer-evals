# JCI MD&A — 0000833444-18-000044


## mdna

[0000833444-18-000044:mdna:1]
[same as prior period, unchanged from 0000833444-18-000021:mdna:1]

[0000833444-18-000044:mdna:2]
[same as prior period, unchanged from 0000833444-18-000021:mdna:2]

[0000833444-18-000044:mdna:3]
[same as prior period, unchanged from 0000833444-18-000021:mdna:3]

[0000833444-18-000044:mdna:4]
[same as prior period, unchanged from 0000833444-18-000021:mdna:4]

[0000833444-18-000044:mdna:5]
[same as prior period, unchanged from 0000833444-18-000021:mdna:5]

[0000833444-18-000044:mdna:6]
[same as prior period, unchanged from 0000833444-18-000021:mdna:6]

[0000833444-18-000044:mdna:7]
In the fourth quarter of fiscal 2016, Johnson Controls, Inc. ("JCI Inc.") and Tyco completed their combination, with JCI Inc. merging with a wholly owned, indirect subsidiary of Tyco (the "Merger"). Following the Merger, Tyco changed its name to “Johnson Controls International plc” and JCI Inc. is a wholly-owned subsidiary of Johnson Controls International plc. The Merger was accounted for as a reverse acquisition using the acquisition method of accounting in accordance with Accounting Standards Codification ("ASC") 805, "Business Combinations." JCI Inc. was the accounting acquirer for financial reporting purposes. Accordingly, the historical consolidated financial statements of JCI Inc. for periods prior to this transaction are considered to be the historic financial statements of the Company.

[0000833444-18-000044:mdna:8]
[same as prior period, unchanged from 0000833444-18-000021:mdna:9]

[0000833444-18-000044:mdna:9]
[same as prior period, unchanged from 0000833444-18-000021:mdna:10]

[0000833444-18-000044:mdna:10]
[same as prior period, unchanged from 0000833444-18-000021:mdna:11]

[0000833444-18-000044:mdna:11]
[same as prior period, unchanged from 0000833444-18-000021:mdna:12]

[0000833444-18-000044:mdna:12]
The following information should be read in conjunction with the September 30, 2017 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in our Annual Report on Form 10-K for the year ended September 30, 2017 filed with the SEC on November 21, 2017. References in the following discussion and analysis to "Three Months"(or similar language) refer to the three months ended June 30, 2018 compared to the three months ended June 30, 2017, while "Year-to-Date" refers to the nine months ended June 30, 2018 compared to the nine months ended June 30, 2017.

[0000833444-18-000044:mdna:13]
48

[0000833444-18-000044:mdna:14]
[same as prior period, unchanged from 0000833444-18-000021:mdna:15]

[0000833444-18-000044:mdna:15]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Net sales | $ | 8,120 |  |  | $ | 7,683 |  |  | 6 | % |  | $ | 23,030 |  |  | $ | 22,036 |  |  | 5 | % |

[0000833444-18-000044:mdna:16]
The increase in consolidated net sales for the three months ended June 30, 2018 was due to higher sales in the Building Technologies & Solutions business ($284 million) and the Power Solutions business ($192 million), and the favorable impact of foreign currency translation ($139 million), partially offset by lower sales due to business divestitures ($178 million). The increased sales in the Building Technologies & Solutions business, net of divestitures, primarily related to higher volumes across all segments. Increased sales in the Power Solutions business primarily resulted from higher volumes and favorable price and product mix. Excluding the impact of foreign currency translation, impact of lead costs on pricing and business divestitures, consolidated net sales increased 6% as compared to the prior year. Refer to the "Segment Analysis" below within Item 2 for a discussion of net sales by segment.

[0000833444-18-000044:mdna:17]
The increase in consolidated net sales for the nine months ended June 30, 2018 was due to the favorable impact of foreign currency translation ($622 million) and higher sales in the Building Technologies & Solutions business ($558 million) and the Power Solutions business ($380 million), partially offset by lower sales due to business divestitures ($566 million). The increased sales in the Building Technologies & Solutions business, net of divestitures, primarily related to higher volumes across all segments. Increased sales in the Power Solutions business primarily resulted from the impact of higher lead costs on pricing. Excluding the impact of foreign currency translation, impact of lead costs on pricing and business divestitures, consolidated net sales increased 3% as compared to the prior year. Refer to the "Segment Analysis" below within Item 2 for a discussion of net sales by segment.

[0000833444-18-000044:mdna:18]
[same as prior period, unchanged from 0000833444-18-000021:mdna:19]

[0000833444-18-000044:mdna:19]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Cost of sales | $ | 5,648 |  |  | $ | 5,252 |  |  | 8 | % |  | $ | 16,169 |  |  | $ | 15,210 |  |  | 6 | % |
| Gross profit | 2,472 |  |  | 2,431 |  |  | 2 | % |  | 6,861 |  |  | 6,826 |  |  | 1 | % |
| % of sales | 30.4 | % |  | 31.6 | % |  |  |  | 29.8 | % |  | 31.0 | % |  |  |

[0000833444-18-000044:mdna:20]
Cost of sales for the three month period ended June 30, 2018 increased as compared to the three month period ended June 30, 2017, and gross profit as a percentage of sales decreased by 120 basis points. Gross profit in the Building Technologies & Solutions business increased due to higher volumes and favorable mix in the Global Products and Building Solutions North America segments, partially offset by business divestitures and prior year nonrecurring purchase accounting adjustments ($14 million). Gross profit in the Power Solutions business was impacted by higher operating costs primarily driven by efforts to satisfy customer demand, partially offset by higher volumes. Foreign currency translation had an unfavorable impact on cost of sales of approximately $100 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA") by segment.

[0000833444-18-000044:mdna:21]
Cost of sales for the nine month period ended June 30, 2018 increased as compared to the nine month period ended June 30, 2017, and gross profit as a percentage of sales decreased by 120 basis points. Gross profit in the Building Technologies & Solutions business increased due to prior year nonrecurring purchase accounting adjustments ($68 million), and higher volumes and favorable mix in the Global Products and Building Solutions North America segments, partially offset by business divestitures and higher operating costs. Gross profit in the Power Solutions business was impacted by higher operating costs primarily driven by efforts to satisfy customer demand, partially offset by favorable pricing and product mix. Foreign currency translation had an unfavorable impact on cost of sales of approximately $457 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-18-000044:mdna:22]
49

[0000833444-18-000044:mdna:23]
[same as prior period, unchanged from 0000833444-18-000021:mdna:23]

[0000833444-18-000044:mdna:24]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Selling, general and administrative expenses | $ | 1,527 |  |  | $ | 1,609 |  |  | -5 | % |  | $ | 4,532 |  |  | $ | 4,905 |  |  | -8 | % |
| % of sales | 18.8 | % |  | 20.9 | % |  |  |  | 19.7 | % |  | 22.3 | % |  |  |

[0000833444-18-000044:mdna:25]
Selling, general and administrative expenses ("SG&A") for the three month period ended June 30, 2018 decreased 5% as compared to the three month period ended June 30, 2017. The decrease in SG&A was primarily due to productivity savings and costs synergies, business divestitures and net mark-to-market adjustments on pension plans which had a prior year unfavorable impact on SG&A of $42 million primarily due to a decrease in discount rates. Foreign currency translation had an unfavorable impact on SG&A of $24 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-18-000044:mdna:26]
SG&A for the nine month period ended June 30, 2018 decreased 8% as compared to the nine month period ended June 30, 2017. The decrease in SG&A was primarily due to productivity savings and costs synergies, business divestitures and a gain on sale of Scott Safety in the Building Technologies & Solutions Global Products segment ($114 million), partially offset by net mark-to-market adjustments on pension plans which had a prior year favorable impact on SG&A of $78 million primarily due to an increase in discount rates. Foreign currency translation had an unfavorable impact on SG&A of $95 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-18-000044:mdna:27]
[same as prior period, unchanged from 0000833444-18-000021:mdna:27]

[0000833444-18-000044:mdna:28]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Restructuring and impairment costs | $ | — |  |  | $ | 49 |  |  | * |  | $ | 158 |  |  | $ | 226 |  |  | -30 | % |

[0000833444-18-000044:mdna:29]
[same as prior period, unchanged from 0000833444-18-000021:mdna:29]

[0000833444-18-000044:mdna:30]
[same as prior period, unchanged from 0000833444-18-000021:mdna:30]

[0000833444-18-000044:mdna:31]
[same as prior period, unchanged from 0000833444-18-000021:mdna:31]

[0000833444-18-000044:mdna:32]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Net financing charges | $ | 101 |  |  | $ | 124 |  |  | -19 | % |  | $ | 332 |  |  | $ | 376 |  |  | -12 | % |

[0000833444-18-000044:mdna:33]
Refer to Note 11, "Debt and Financing Arrangements," of the notes to consolidated financial statements for further disclosure related to the Company's net financing charges.

[0000833444-18-000044:mdna:34]
[same as prior period, unchanged from 0000833444-18-000021:mdna:34]

[0000833444-18-000044:mdna:35]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Equity income | $ | 66 |  |  | $ | 69 |  |  | -4 | % |  | $ | 170 |  |  | $ | 177 |  |  | -4 | % |

[0000833444-18-000044:mdna:36]
The decrease in equity income for the three and nine months ended June 30, 2018 was primarily due to lower income at partially-owned affiliates in the Power Solutions business, partially offset by higher income at partially-owned affiliates in the Building Technologies & Solutions business. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-18-000044:mdna:37]
[same as prior period, unchanged from 0000833444-18-000021:mdna:37]

[0000833444-18-000044:mdna:38]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Income tax provision | $ | 106 |  |  | $ | 89 |  |  | 19 | % |  | $ | 451 |  |  | $ | 570 |  |  | -21 | % |
| Effective tax rate | 12 | % |  | 12 | % |  |  |  | 22 | % |  | 38 | % |  |  |

[0000833444-18-000044:mdna:39]
[same as prior period, unchanged from 0000833444-18-000021:mdna:40]

[0000833444-18-000044:mdna:40]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended June 30, 2018 and 2017, the Company's effective tax rate was consistent with the statutory tax rate of 12.5%. For the nine months ended June 30, 2018, the Company's effective tax rate was 22% and was higher than the statutory tax rate of 12.5% primarily due to the discrete net impacts of U.S. Tax Reform, final income tax effects of the completed divestiture of the Scott Safety business and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives and tax audit closures. For the nine months ended June 30, 2017, the Company's effective tax rate was 38% and was higher than the statutory tax rate of 12.5% primarily due to the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries related to the divestiture of the Scott Safety business, the income tax effects of pension mark-to-market gains and tax rate differentials, partially offset by the jurisdictional mix of significant restructuring and impairment costs, Tyco Merger transaction and integration costs, purchase accounting adjustments, a tax benefit due to changes in entity tax status and the benefits of continuing global tax planning initiatives. The effective tax rate for the nine months ended June 30, 2018 decreased as compared to the nine months ended June 30, 2017, primarily due to the discrete tax items described below and tax planning initiatives. The global tax planning initiatives related primarily to foreign tax credit planning, global financing structures and alignment of our global business functions in a tax efficient manner.

[0000833444-18-000044:mdna:41]
In the third quarter of fiscal 2018, the Company recorded $51 million of transaction and integration costs. These costs generated a $6 million tax benefit which reflects the Company’s current tax position in these jurisdictions.

[0000833444-18-000044:mdna:42]
In the second quarter of fiscal 2018, the Company recorded $64 million of transaction and integration costs. These costs generated a $9 million tax benefit which reflects the Company’s current tax position in these jurisdictions.

[0000833444-18-000044:mdna:43]
On December 22, 2017, the “Tax Cuts and Jobs Act” (H.R. 1) was enacted and significantly revises U.S. corporate income tax by, among other things, lowering corporate income tax rates, imposing a one-time transition tax on deemed repatriated earnings of non-U.S. subsidiaries, and implementing a territorial tax system and various base erosion minimum tax provisions.

[0000833444-18-000044:mdna:44]
In the first quarter of fiscal 2018, as a result of the enacted legislation, the Company recorded a discrete non-cash tax benefit of $101 million due to the remeasurement of U.S. deferred tax assets and liabilities.  The Company remeasured certain deferred tax assets and liabilities based on the rates at which they are expected to reverse in the future, which is generally 21% or the blended fiscal 2018 rate of 24.5%. This tax benefit is provisional as the Company is still analyzing certain aspects of the legislation and

[0000833444-18-000044:mdna:45]
refining calculations, which could potentially materially affect the measurement of these amounts or give rise to new deferred tax amounts.

[0000833444-18-000044:mdna:46]
[same as prior period, unchanged from 0000833444-18-000021:mdna:46]

[0000833444-18-000044:mdna:47]
[same as prior period, unchanged from 0000833444-18-000021:mdna:47]

[0000833444-18-000044:mdna:48]
[same as prior period, unchanged from 0000833444-18-000021:mdna:48]

[0000833444-18-000044:mdna:49]
[same as prior period, unchanged from 0000833444-18-000021:mdna:50]

[0000833444-18-000044:mdna:50]
In the first quarter of fiscal 2018, the Company recorded $50 million of transaction and integration costs.  These costs generated a $7 million tax benefit which reflects the Company’s current tax position in these jurisdictions.

[0000833444-18-000044:mdna:51]
In the first quarter of fiscal 2018, the Company recorded $158 million of significant restructuring and impairment costs. Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $24 million tax benefit, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-18-000044:mdna:52]
In the third quarter of fiscal 2017, the Company recorded $70 million of transaction and integration costs which generated an $11 million tax benefit.

[0000833444-18-000044:mdna:53]
In the third quarter of fiscal 2017, the Company recorded pension mark-to-market losses of $45 million which generated an $18 million tax benefit.

[0000833444-18-000044:mdna:54]
In the third quarter of fiscal 2017, the Company recorded $49 million of significant restructuring and impairment costs. Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $15 million tax benefit.

[0000833444-18-000044:mdna:55]
[same as prior period, unchanged from 0000833444-18-000021:mdna:52]

[0000833444-18-000044:mdna:56]
[same as prior period, unchanged from 0000833444-18-000021:mdna:53]

[0000833444-18-000044:mdna:57]
[same as prior period, unchanged from 0000833444-18-000021:mdna:54]

[0000833444-18-000044:mdna:58]
52

[0000833444-18-000044:mdna:59]
In the second quarter of fiscal 2017, the Company recorded $99 million of significant restructuring and impairment costs. Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $20 million tax benefit, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-18-000044:mdna:60]
[same as prior period, unchanged from 0000833444-18-000021:mdna:56]

[0000833444-18-000044:mdna:61]
[same as prior period, unchanged from 0000833444-18-000021:mdna:57]

[0000833444-18-000044:mdna:62]
[same as prior period, unchanged from 0000833444-18-000021:mdna:58]

[0000833444-18-000044:mdna:63]
In the first quarter of fiscal 2017, the Company recorded $78 million of significant restructuring and impairment costs. Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $14 million tax benefit, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-18-000044:mdna:64]
[same as prior period, unchanged from 0000833444-18-000021:mdna:60]

[0000833444-18-000044:mdna:65]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Loss from discontinued operations, net of tax | $ | — |  |  | $ | — |  |  | * |  | $ | — |  |  | $ | (34 | ) |  | * |

[0000833444-18-000044:mdna:66]
[same as prior period, unchanged from 0000833444-18-000021:mdna:39]

[0000833444-18-000044:mdna:67]
[same as prior period, unchanged from 0000833444-18-000021:mdna:63]

[0000833444-18-000044:mdna:68]
[same as prior period, unchanged from 0000833444-18-000021:mdna:64]

[0000833444-18-000044:mdna:69]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 81 |  |  | $ | 74 |  |  | 9 | % |  | $ | 167 |  |  | $ | 147 |  |  | 14 | % |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  | — |  |  | * |  |  | — |  |  | 9 |  |  | * |  |

[0000833444-18-000044:mdna:70]
[same as prior period, unchanged from 0000833444-18-000021:mdna:62]

[0000833444-18-000044:mdna:71]
The increase in income from continuing operations attributable to noncontrolling interests for the three and nine months ended June 30, 2018 was primarily due to higher net income related to the Johnson Controls - Hitachi joint venture in the Building Technologies & Solutions business and higher net income at a Power Solutions partially-owned affiliate.

[0000833444-18-000044:mdna:72]
[same as prior period, unchanged from 0000833444-18-000021:mdna:68]

[0000833444-18-000044:mdna:73]
Net Income Attributable to Johnson Controls

[0000833444-18-000044:mdna:74]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Net income attributable to Johnson Controls | $ | 723 |  |  | $ | 555 |  |  | 30 | % |  | $ | 1,391 |  |  | $ | 736 |  |  | 89 | % |

[0000833444-18-000044:mdna:75]
The increase in net income attributable to Johnson Controls for the three months ended June 30, 2018 was primarily due to lower SG&A, lower restructuring and impairment costs, lower net financing charges and higher gross profit. The increase in net income attributable to Johnson Controls for the nine months ended June 30, 2018 was primarily due to higher gross profit, lower SG&A, income tax provision due to higher discrete period net tax charges in the prior year and lower net financing charges. Diluted earnings per share attributable to Johnson Controls for the three months ended June 30, 2018 was $0.78 compared to $0.59 for the three months ended June 30, 2017. Diluted earnings per share attributable to Johnson Controls for the nine months ended June 30, 2018 was $1.49 compared to $0.78 for the nine months ended June 30, 2017.

[0000833444-18-000044:mdna:76]
Comprehensive Income Attributable to Johnson Controls

[0000833444-18-000044:mdna:77]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Comprehensive income attributable to Johnson Controls | $ | 169 |  |  | $ | 813 |  |  | -79 | % |  | $ | 1,056 |  |  | $ | 579 |  |  | 82 | % |

[0000833444-18-000044:mdna:78]
The decrease in comprehensive income attributable to Johnson Controls for the three months ended June 30, 2018 was primarily due to a decrease in other comprehensive income attributable to Johnson Controls ($812 million) resulting primarily from unfavorable foreign currency translation adjustments, partially offset by higher net income attributable to Johnson Controls ($168 million). These year-over-year unfavorable foreign currency translation adjustments were primarily driven by the weakening of the British pound and euro currencies against the U.S. dollar.

[0000833444-18-000044:mdna:79]
The increase in comprehensive income attributable to Johnson Controls for the nine months ended June 30, 2018 was primarily due to higher net income attributable to Johnson Controls ($655 million), partially offset by an increase in other comprehensive loss attributable to Johnson Controls ($178 million) resulting primarily from unfavorable foreign currency translation adjustments. These year-over-year unfavorable foreign currency translation adjustments were primarily driven by the weakening of the British pound and euro currencies against the U.S. dollar.

[0000833444-18-000044:mdna:80]
[same as prior period, unchanged from 0000833444-18-000021:mdna:78]

[0000833444-18-000044:mdna:81]
[same as prior period, unchanged from 0000833444-18-000021:mdna:79]

[0000833444-18-000044:mdna:82]
[same as prior period, unchanged from 0000833444-18-000021:mdna:80]

[0000833444-18-000044:mdna:83]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Building Solutions North America | $ | 2,246 |  |  | $ | 2,142 |  |  | 5 | % |  | $ | 6,355 |  |  | $ | 6,181 |  |  | 3 | % |
| Building Solutions EMEA/LA | 926 |  |  | 896 |  |  | 3 | % |  | 2,748 |  |  | 2,669 |  |  | 3 | % |
| Building Solutions Asia Pacific | 681 |  |  | 630 |  |  | 8 | % |  | 1,864 |  |  | 1,767 |  |  | 5 | % |
| Global Products | 2,429 |  |  | 2,406 |  |  | 1 | % |  | 6,250 |  |  | 6,214 |  |  | 1 | % |
|  | $ | 6,282 |  |  | $ | 6,074 |  |  | 3 | % |  | $ | 17,217 |  |  | $ | 16,831 |  |  | 2 | % |

[0000833444-18-000044:mdna:84]
[same as prior period, unchanged from 0000833444-18-000021:mdna:82]

[0000833444-18-000044:mdna:85]
| • | The increase in Building Solutions North America was due to higher volumes ($103 million) and the favorable impact of foreign currency translation ($8 million), partially offset by the impact of prior year nonrecurring purchase accounting adjustments ($7 million). The increase in volumes was primarily attributable to higher HVAC, controls, fire and security sales. |

[0000833444-18-000044:mdna:86]
| • | The increase in Building Solutions EMEA/LA was due to the favorable impact of foreign currency translation ($33 million) and higher volumes ($4 million), partially offset by the impact of prior year nonrecurring purchase accounting adjustments ($7 million). |

[0000833444-18-000044:mdna:87]
| • | The increase in Building Solutions Asia Pacific was due to higher volumes ($28 million) and the favorable impact of foreign currency translation ($26 million), partially offset by lower volumes related to a business divestiture ($3 million). The increase in volumes was primarily attributable to higher service sales. |

[0000833444-18-000044:mdna:88]
| • | The increase in Global Products was due to higher volumes ($163 million) and the favorable impact of foreign currency translation ($35 million), partially offset by lower volumes related to business divestitures ($175 million). The increase in volumes was primarily attributable to higher building management, HVAC and refrigeration equipment, and specialty products sales. |

[0000833444-18-000044:mdna:89]
[same as prior period, unchanged from 0000833444-18-000021:mdna:87]

[0000833444-18-000044:mdna:90]
| • | The increase in Building Solutions North America was due to higher volumes ($176 million) and the favorable impact of foreign currency translation ($28 million), partially offset by the impact of prior year nonrecurring purchase accounting adjustments ($30 million). The increase in volumes was primarily attributable to higher HVAC, controls, fire and security sales. |

[0000833444-18-000044:mdna:91]
| • | The increase in Building Solutions EMEA/LA was due to the favorable impact of foreign currency translation ($161 million) and higher volumes ($9 million), partially offset by lower volumes related to a business divestiture ($80 million) and the impact of prior year nonrecurring purchase accounting adjustments ($11 million). |

[0000833444-18-000044:mdna:92]
| • | The increase in Building Solutions Asia Pacific was due to the favorable impact of foreign currency translation ($75 million), higher volumes ($33 million) and the impact of prior year nonrecurring purchase accounting adjustments ($1 million), partially offset by lower volumes related to a business divestiture ($12 million). The increase in volumes was primarily attributable to higher service sales. |

[0000833444-18-000044:mdna:93]
| • | The increase in Global Products was due to higher volumes ($374 million), the favorable impact of foreign currency translation ($130 million) and the impact of prior year nonrecurring purchase accounting adjustments ($6 million), partially offset by lower volumes related to business divestitures ($474 million). The increase in volumes was primarily attributable to higher building management, HVAC and refrigeration equipment, and specialty products sales. |

[0000833444-18-000044:mdna:94]
[same as prior period, unchanged from 0000833444-18-000021:mdna:92]

[0000833444-18-000044:mdna:95]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Building Solutions North America | $ | 314 |  |  | $ | 290 |  |  | 8 | % |  | $ | 780 |  |  | $ | 741 |  |  | 5 | % |
| Building Solutions EMEA/LA | 96 |  |  | 100 |  |  | -4 | % |  | 242 |  |  | 238 |  |  | 2 | % |
| Building Solutions Asia Pacific | 97 |  |  | 85 |  |  | 14 | % |  | 242 |  |  | 215 |  |  | 13 | % |
| Global Products | 435 |  |  | 437 |  |  | — | % |  | 949 |  |  | 806 |  |  | 18 | % |
|  | $ | 942 |  |  | $ | 912 |  |  | 3 | % |  | $ | 2,213 |  |  | $ | 2,000 |  |  | 11 | % |

[0000833444-18-000044:mdna:96]
55

[0000833444-18-000044:mdna:97]
[same as prior period, unchanged from 0000833444-18-000021:mdna:94]

[0000833444-18-000044:mdna:98]
| • | The increase in Building Solutions North America was due to favorable volumes / mix ($33 million), prior year integration costs ($10 million), lower selling, general and administrative expenses ($2 million), prior year transaction costs ($2 million) and the favorable impact of foreign currency translation ($1 million), partially offset by prior year nonrecurring purchase accounting adjustments ($12 million), incremental investments ($8 million) and current year integration costs ($4 million). |

[0000833444-18-000044:mdna:99]
| • | The decrease in Building Solutions EMEA/LA was due to prior year nonrecurring purchase accounting adjustments ($11 million), incremental investments ($5 million) and current year integration costs ($2 million), partially offset by lower selling, general and administrative expenses ($8 million), and favorable volumes / mix ($6 million). |

[0000833444-18-000044:mdna:100]
| • | The increase in Building Solutions Asia Pacific was due to lower selling, general and administrative expenses ($9 million), higher volumes / mix ($5 million) and the favorable impact of foreign currency translation ($1 million), partially offset by incremental investments ($2 million) and prior year nonrecurring purchase accounting adjustments ($1 million). |

[0000833444-18-000044:mdna:101]
| • | The decrease in Global Products was due to lower income due to business divestitures ($47 million), higher selling, general and administrative expenses and operating costs including planned incremental global product and channel investments ($44 million), and current year integration costs ($6 million), partially offset by favorable volumes / mix ($69 million), higher equity income ($10 million), the favorable impact of foreign currency translation ($8 million), prior year transaction costs ($4 million) and prior year integration costs ($4 million). |

[0000833444-18-000044:mdna:102]
[same as prior period, unchanged from 0000833444-18-000021:mdna:100]

[0000833444-18-000044:mdna:103]
| • | The increase in Building Solutions North America was due to favorable volumes / mix ($49 million), prior year integration costs ($24 million), prior year transaction costs ($13 million), lower selling, general and administrative expenses ($5 million), lower operating costs ($3 million) and the favorable impact of foreign currency translation ($2 million), partially offset by prior year nonrecurring purchase accounting adjustments ($23 million), current year integration costs ($18 million) and incremental investments ($16 million). |

[0000833444-18-000044:mdna:104]
| • | The increase in Building Solutions EMEA/LA was due to the favorable impact of foreign currency translation ($13 million), favorable volumes / mix ($10 million), lower selling, general and administrative expenses ($8 million), prior year transaction costs ($5 million) and prior year integration costs ($4 million), partially offset by prior year nonrecurring purchase accounting adjustments ($14 million), incremental investments ($8 million), current year integration costs ($5 million), higher operating costs ($5 million), lower income due to a business divestiture ($2 million) and lower equity income ($2 million). |

[0000833444-18-000044:mdna:105]
| • | The increase in Building Solutions Asia Pacific was due to higher volumes / mix ($13 million), lower selling, general and administrative expenses ($11 million), prior year nonrecurring purchase accounting adjustments ($3 million), prior year integration costs ($3 million), the favorable impact of foreign currency translation ($3 million) and prior year transaction costs ($2 million), partially offset by unfavorable pricing ($4 million) and incremental investments ($4 million). |

[0000833444-18-000044:mdna:106]
| • | The increase in Global Products was due to favorable volumes / mix ($136 million), a gain on sale of Scott Safety ($114 million), prior year nonrecurring purchase accounting adjustments ($71 million), the favorable impact of foreign currency translation ($23 million), higher equity income ($21 million), prior year integration costs ($13 million) and prior year transaction costs ($13 million). These items were partially offset by lower income due to business divestitures ($121 million), higher selling, general and administrative expenses and operating expenses including planned incremental global product and channel investments partially offset by productivity savings and an insignificant gain on a business divestiture ($106 million), and current year integration costs ($21 million). |

[0000833444-18-000044:mdna:107]
[same as prior period, unchanged from 0000833444-18-000021:mdna:105]

[0000833444-18-000044:mdna:108]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Net sales | $ | 1,838 |  |  | $ | 1,609 |  |  | 14 | % |  | $ | 5,813 |  |  | $ | 5,205 |  |  | 12 | % |
| Segment EBITA | 310 |  |  | 304 |  |  | 2 | % |  | 1,008 |  |  | 996 |  |  | 1 | % |

[0000833444-18-000044:mdna:109]
[same as prior period, unchanged from 0000833444-18-000021:mdna:107]

[0000833444-18-000044:mdna:110]
| • | Net sales increased due to the favorable impact of higher volumes ($121 million), favorable pricing and product mix ($40 million), foreign currency translation ($37 million) and the impact of higher lead costs on pricing ($31 million). The increase in volumes was driven by changes in customer demand patterns in Europe, growth in China and an increase in start-stop battery volumes. Additionally, higher start-stop volumes contributed to favorable product mix. |

[0000833444-18-000044:mdna:111]
| • | Segment EBITA increased due to higher volumes ($35 million), lower selling, general and administrative expenses due to lower employee related expenses and cost reduction initiatives ($27 million), and the favorable impact of foreign currency translation ($5 million), partially offset by higher operating costs primarily driven by efforts to satisfy customer demand including higher transportation costs ($40 million), lower equity income ($12 million) and incremental investments ($9 million). |

[0000833444-18-000044:mdna:112]
[same as prior period, unchanged from 0000833444-18-000021:mdna:112]

[0000833444-18-000044:mdna:113]
| • | Net sales increased due to the impact of higher lead costs on pricing ($230 million), the favorable impact of foreign currency translation ($228 million), favorable pricing and product mix ($119 million), and higher volumes ($31 million). The increase in volumes was driven by growth in China and an increase in start-stop battery volumes, partially offset by changes in customer demand patterns in North America. Additionally, higher start-stop volumes contributed to favorable product mix. |

[0000833444-18-000044:mdna:114]
| • | Segment EBITA increased due to lower selling, general and administrative expenses from productivity savings and a gain on a business deconsolidation ($56 million), favorable pricing and product mix ($48 million), the favorable impact of foreign currency translation ($29 million), higher volumes ($5 million) and prior year transaction costs ($1 million), partially offset by higher operating costs primarily driven by efforts to satisfy customer demand including higher transportation costs ($72 million), lower equity income ($28 million) and incremental investments ($27 million). |

[0000833444-18-000044:mdna:115]
[same as prior period, unchanged from 0000833444-18-000021:mdna:115]

[0000833444-18-000044:mdna:116]
The Company's backlog relating to the Building Technologies & Solutions business is applicable to its sales of systems and services. At June 30, 2018, the backlog was $8.8 billion. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned during the fiscal year.

[0000833444-18-000044:mdna:117]
57

[0000833444-18-000044:mdna:118]
[same as prior period, unchanged from 0000833444-18-000021:mdna:117]

[0000833444-18-000044:mdna:119]
[same as prior period, unchanged from 0000833444-18-000021:mdna:118]

[0000833444-18-000044:mdna:120]
|  | June 30, |  | September 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Current assets | $ | 12,465 |  |  | $ | 12,292 |  |  |  |
| Current liabilities | (11,301 | ) |  | (11,854 | ) |  |  |
|  | 1,164 |  |  | 438 |  |  | * |  |
| Less: Cash | (283 | ) |  | (321 | ) |  |  |
| Add: Short-term debt | 1,559 |  |  | 1,214 |  |  |  |
| Add: Current portion of long-term debt | 24 |  |  | 394 |  |  |  |
| Less: Assets held for sale | (12 | ) |  | (189 | ) |  |  |
| Add: Liabilities held for sale | — |  |  | 72 |  |  |  |
| Working capital (as defined) | $ | 2,452 |  |  | $ | 1,608 |  |  | 52 | % |
| Accounts receivable - net | $ | 6,895 |  |  | $ | 6,666 |  |  | 3 | % |
| Inventories | 3,509 |  |  | 3,209 |  |  | 9 | % |
| Accounts payable | 4,410 |  |  | 4,271 |  |  | 3 | % |
| * Measure not meaningful |  |  |  |  |  |

[0000833444-18-000044:mdna:121]
[same as prior period, unchanged from 0000833444-18-000021:mdna:120]

[0000833444-18-000044:mdna:122]
| • | The increase in working capital at June 30, 2018 as compared to September 30, 2017, was primarily due to an increase in inventory to meet anticipated customer demand and a decrease in other current liabilities. |

[0000833444-18-000044:mdna:123]
| • | The Company’s days sales in accounts receivable at June 30, 2018 were 63 days, lower than 65 days at September 30, 2017. There has been no significant adverse changes in the level of overdue receivables or changes in revenue recognition methods. |

[0000833444-18-000044:mdna:124]
| • | The Company’s inventory turns for the three months ended June 30, 2018 were lower than the comparable period ended September 30, 2017, primarily due to changes in inventory production levels. |

[0000833444-18-000044:mdna:125]
| • | Days in accounts payable at June 30, 2018 were 72 days, slightly lower than 73 days at the comparable period ended September 30, 2017. |

[0000833444-18-000044:mdna:126]
[same as prior period, unchanged from 0000833444-18-000021:mdna:126]

[0000833444-18-000044:mdna:127]
|  |  | Nine Months Ended June 30, |
| (in millions) |  | 2018 |  | 2017 |
| Cash provided (used) by operating activities |  | $ | 1,261 |  |  | $ | (1,303 | ) |
| Cash provided (used) by investing activities |  | 1,304 |  |  | (832 | ) |
| Cash provided (used) by financing activities |  | (2,528 | ) |  | 1,897 |  |
| Capital expenditures |  | (782 | ) |  | (996 | ) |

[0000833444-18-000044:mdna:128]
| • | The increase in cash provided by operating activities for the nine months ended June 30, 2018 was primarily due to favorable movements in working capital balances, higher prior year income tax payments related to the Adient spin-off ($1.2 billion in the first quarter of fiscal 2017), and prior year operating cash outflows in the Automotive Experience business before the Adient spin-off, change in control pension payments and transaction/integration related payments. |

[0000833444-18-000044:mdna:129]
| • | The increase in cash provided by investing activities for the nine months ended June 30, 2018 was primarily due to net cash proceeds received from the Scott Safety business divestiture in the current year and a decrease in capital expenditures. |

[0000833444-18-000044:mdna:130]
| • | The increase in cash used by financing activities for the nine months ended June 30, 2018 was primarily due to the prior year net dividend proceeds from the Adient spin-off, higher current year repayments of long-term debt and a decrease in debt borrowings, partially offset by cash transferred in the prior year to Adient related to the spin-off. |

[0000833444-18-000044:mdna:131]
| • | The decrease in capital expenditures for the nine months ended June 30, 2018 primarily relates to lower capital investments in the current year in the Building Technologies & Solutions business and prior year capital investments in the Automotive Experience business before the Adient spin-off. |

[0000833444-18-000044:mdna:132]
[same as prior period, unchanged from 0000833444-18-000021:mdna:132]

[0000833444-18-000044:mdna:133]
|  | June 30, |  | September 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Short-term debt | $ | 1,559 |  |  | $ | 1,214 |  |  |  |
| Current portion of long-term debt | 24 |  |  | 394 |  |  |  |
| Long-term debt | 10,373 |  |  | 11,964 |  |  |  |
| Total debt | 11,956 |  |  | 13,572 |  |  | -12 | % |
| Less: cash and cash equivalents | 283 |  |  | 321 |  |  |  |
| Total net debt | 11,673 |  |  | 13,251 |  |  | -12 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 20,773 |  |  | 20,447 |  |  | 2 | % |
| Total capitalization | $ | 32,446 |  |  | $ | 33,698 |  |  | -4 | % |
| Total net debt as a % of total capitalization | 36.0 | % |  | 39.3 | % |  |  |

[0000833444-18-000044:mdna:134]
[same as prior period, unchanged from 0000833444-18-000021:mdna:134]

[0000833444-18-000044:mdna:135]
| • | The Company believes its capital resources and liquidity position at June 30, 2018 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, stock repurchases, minimum pension contributions, debt maturities and any potential acquisitions in the remainder of fiscal 2018 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company and Tyco |

[0000833444-18-000044:mdna:136]
[same as prior period, unchanged from 0000833444-18-000021:mdna:14]

[0000833444-18-000044:mdna:137]
International Holding S.à.r.l ("TSarl") are unable to issue commercial paper, they would have the ability to draw on their $2.0 billion and $1.25 billion revolving credit facilities, respectively. Both facilities mature in August 2020. There were no draws on the revolving credit facility as of June 30, 2018 and September 30, 2017. The Company also selectively makes use of short-term credit lines other than its revolving credit facilities at the Company and TSarl. The Company estimates that, as of June 30, 2018, it could borrow up to $1.6 billion based on average borrowing levels during the quarter on committed credit lines. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future.

[0000833444-18-000044:mdna:138]
| • | The Company’s debt financial covenant in its revolving credit facility require a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. TSarl's revolving credit facility contains customary terms and conditions, and a financial covenant that limits the ratio of TSarl's debt to earnings before interest, taxes, depreciation, and amortization as adjusted for certain items set forth in the agreement to 3.5x. TSarl's revolving credit facility also limits its ability to incur subsidiary debt or grant liens on its and its subsidiaries' property. As of June 30, 2018, the Company and TSarl were in compliance with all covenants and other requirements set forth in their credit agreements and the indentures, governing their notes, and expect to remain in compliance for the foreseeable future. None of the Company’s or TSarl's debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the respective borrower's credit rating. |

[0000833444-18-000044:mdna:139]
| • | The key financial assumptions used in calculating the Company’s pension liability are determined annually, or whenever plan assets and liabilities are re-measured as required under accounting principles generally accepted in the U.S., including the expected rate of return on its plan assets. In fiscal 2018, the Company believes the long-term rate of return will approximate 7.50%, 5.35% and 5.65% for U.S. pension, non-U.S. pension and postretirement plans, respectively. During the first nine months of fiscal 2018, the Company made approximately $54 million in total pension and postretirement contributions. In total, the Company expects to contribute approximately $100 million in cash to its defined benefit pension plans in fiscal 2018. The Company expects to contribute $5 million in cash to its postretirement plans in fiscal 2018. |

[0000833444-18-000044:mdna:140]
[same as prior period, unchanged from 0000833444-18-000021:mdna:140]

[0000833444-18-000044:mdna:141]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2018 and recorded $158 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2018 restructuring plan will reduce annual operating costs by approximately $150 million, which is primarily the result of lower cost of sales and selling, general and administrative expenses due to |

[0000833444-18-000044:mdna:142]
60

[0000833444-18-000044:mdna:143]
reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in 2020. For fiscal 2018, the savings, net of execution costs, are expected to be approximately 45% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in 2020. The restructuring plan reserve balance of $106 million at June 30, 2018 is expected to be paid in cash.

[0000833444-18-000044:mdna:144]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2017 and recorded $367 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2017 restructuring plan will reduce annual operating costs by approximately $280 million, which is primarily the result of lower cost of sales and selling, general and administrative expenses due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in fiscal 2019. For fiscal 2018, the savings, net of execution costs, are expected to be approximately 85% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in 2018. The restructuring plan reserve balance of $92 million at June 30, 2018 is expected to be paid in cash. |

[0000833444-18-000044:mdna:145]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations to address the softness in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2016 and recorded $288 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments and change-in-control payments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2016 restructuring plan will reduce annual operating costs by approximately $135 million, which is primarily the result of lower cost of sales and selling, general and administrative expenses due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in fiscal 2019. For fiscal 2018, the savings, net of execution costs, are expected to be approximately 75% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in 2018. The restructuring plan reserve balance of $74 million at June 30, 2018 is expected to be paid in cash. |

[0000833444-18-000044:mdna:146]
[same as prior period, unchanged from 0000833444-18-000021:mdna:146]

[0000833444-18-000044:mdna:147]
[same as prior period, unchanged from 0000833444-18-000021:mdna:147]

[0000833444-18-000044:mdna:148]
[same as prior period, unchanged from 0000833444-18-000021:mdna:148]
