# JCI notes — 0000833444-24-000029


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-24-000029:notes:1]
BASIS OF PRESENTATION
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2023 filed with the SEC on December 14, 2023. The results of operations for the three and six month periods ended March 31, 2024 are not necessarily indicative of results for the Company’s 2024 fiscal year because of seasonal and other factors.

[0000833444-24-000029:notes:2]
[same as prior period, unchanged from 0000833444-24-000011:notes:2]

[0000833444-24-000029:notes:3]
[same as prior period, unchanged from 0000833444-24-000011:notes:3]

[0000833444-24-000029:notes:4]
[same as prior period, unchanged from 0000833444-24-000011:notes:4]

[0000833444-24-000029:notes:5]
[same as prior period, unchanged from 0000833444-24-000011:notes:5]

[0000833444-24-000029:notes:6]
[same as prior period, unchanged from 0000833444-24-000011:notes:6]

[0000833444-24-000029:notes:7]
[same as prior period, unchanged from 0000833444-24-000011:notes:7]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000833444-24-000029:notes:8]
NEW ACCOUNTING STANDARDS
Recently Adopted Accounting Pronouncements

[0000833444-24-000029:notes:9]
In September 2022, the FASB issued ASU 2022-04, "Disclosure of Supplier Finance Program Obligations," which is intended to enhance the transparency surrounding the use of supplier finance programs. Supplier finance programs may

[0000833444-24-000029:notes:10]
also be referred to as reverse factoring, payables finance, or structured payables arrangements. The amendments require a buyer that uses supplier finance programs to make annual disclosures about the program’s key terms, the balance sheet presentation of related amounts, the confirmed amount outstanding at the end of the period, and associated rollforward information. Only the amount outstanding at the end of the period must be disclosed in interim periods. The Company adopted the new disclosures, other than the rollforward disclosure, as required at the beginning of fiscal 2024. The rollforward disclosure will be adopted as required at the beginning of fiscal 2025.

[0000833444-24-000029:notes:11]
The Company maintains agreements with third-party financial institutions who offer voluntary supply chain financing ("SCF") programs to its suppliers. The SCF programs enable suppliers to sell their receivables to third-party financial institutions and receive payments earlier than the negotiated commercial terms between the suppliers and the Company, which generally range from 90 to 120 days. Suppliers sell receivables to third-party financial institutions on terms negotiated between the supplier and the respective third-party financial institution. The Company remains obligated to make payments under the terms of the original commercial arrangement regardless of whether the supplier receivable is sold, and does not pledge any assets as security or provide other forms of guarantees for the committed payment to the third-party financial institutions.

[0000833444-24-000029:notes:12]
Amounts outstanding related to SCF programs are included in accounts payable in the consolidated statements of financial position. Accounts payable included in the SCF programs were approximately $561 million and $566 million as of March 31, 2024, and September 30, 2023, respectively.

[0000833444-24-000029:notes:13]
Recently Issued Accounting Pronouncements

[0000833444-24-000029:notes:14]
In December 2023, the FASB issued ASU 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures," which is intended to enhance the transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. The amendments require that on an annual basis, entities disclose specific categories in the rate reconciliation and provide additional information for reconciling items that meet a quantitative threshold. In addition, the amendments require that entities disclose additional information about income taxes paid as well as additional disclosures of pretax income and income tax expense, and remove the requirement to disclose certain items that are no longer considered cost beneficial or relevant. The Company expects to adopt the new annual disclosures as required for fiscal 2026.

[0000833444-24-000029:notes:15]
In November 2023, the FASB issued ASU 2023-07, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures," which is intended to improve reportable segment disclosures, primarily through enhanced disclosures about significant segment expenses. In addition, the amendments enhance interim disclosure requirements, clarify circumstances in which an entity can disclose multiple segment measures of profit or loss, provide new segment disclosure requirements for entities with a single reportable segment and contain other disclosure requirements. The Company expects to adopt the new annual disclosures as required for fiscal 2025 and the interim disclosures as required beginning with the first quarter of fiscal 2026.

[0000833444-24-000029:notes:16]
Other recently issued accounting pronouncements are not expected to have a material impact on the Company's consolidated financial statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-24-000029:notes:17]
ACQUISITIONS AND DIVESTITURES
During the six months ended March 31, 2023, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $115 million, of which $89 million was paid as of March 31, 2023. In connection with the acquisitions, the Company recorded goodwill of $53 million within the Global Products segment and $14 million within the Building Solutions EMEA/LA segment.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-24-000029:notes:18]
ASSETS AND LIABILITIES HELD FOR SALE
During the three and six months ended March 31, 2023, the Company recorded impairment charges primarily due to reductions in the estimated fair value of its Global Retail business of $210 million and $438 million, respectively. During the six months ended March 31, 2023, the Company also recorded an impairment charge for a business in the Building Solutions Asia Pacific segment of $60 million. Both businesses were classified as held for sale as of March 31, 2023. All of the impairments were recorded within restructuring and impairment costs in the consolidated statements of income.

[0000833444-24-000029:notes:19]
No assets and liabilities were classified as held for sale as of March 31, 2024 or September 30, 2023.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-24-000029:notes:20]
[same as prior period, unchanged from 0000833444-24-000011:notes:21]

[0000833444-24-000029:notes:21]
[same as prior period, unchanged from 0000833444-24-000011:notes:22]

[0000833444-24-000029:notes:22]
|  |  | Three Months Ended March 31, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,700 |  |  | $ | 1,039 |  |  | $ | 2,739 |  |  | $ | 1,554 |  |  | $ | 966 |  |  | $ | 2,520 |  |
| Building Solutions EMEA/LA |  | 572 |  |  | 492 |  |  | 1,064 |  |  | 582 |  |  | 449 |  |  | 1,031 |  |
| Building Solutions Asia Pacific |  | 308 |  |  | 183 |  |  | 491 |  |  | 479 |  |  | 188 |  |  | 667 |  |
| Global Products |  | 2,405 |  |  | — |  |  | 2,405 |  |  | 2,468 |  |  | — |  |  | 2,468 |  |
| Total |  | $ | 4,985 |  |  | $ | 1,714 |  |  | $ | 6,699 |  |  | $ | 5,083 |  |  | $ | 1,603 |  |  | $ | 6,686 |  |

[0000833444-24-000029:notes:23]
|  |  | Six Months Ended March 31, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,218 |  |  | $ | 2,008 |  |  | $ | 5,226 |  |  | $ | 3,005 |  |  | $ | 1,882 |  |  | $ | 4,887 |  |
| Building Solutions EMEA/LA |  | 1,144 |  |  | 958 |  |  | 2,102 |  |  | 1,134 |  |  | 872 |  |  | 2,006 |  |
| Building Solutions Asia Pacific |  | 645 |  |  | 353 |  |  | 998 |  |  | 952 |  |  | 361 |  |  | 1,313 |  |
| Global Products |  | 4,467 |  |  | — |  |  | 4,467 |  |  | 4,548 |  |  | — |  |  | 4,548 |  |
| Total |  | $ | 9,474 |  |  | $ | 3,319 |  |  | $ | 12,793 |  |  | $ | 9,639 |  |  | $ | 3,115 |  |  | $ | 12,754 |  |

[0000833444-24-000029:notes:24]
[same as prior period, unchanged from 0000833444-24-000011:notes:24]

[0000833444-24-000029:notes:25]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC |  | $ | 1,683 |  |  | $ | 1,757 |  |  | $ | 3,101 |  |  | $ | 3,197 |  |
| Fire & Security |  | 607 |  |  | 623 |  |  | 1,154 |  |  | 1,193 |  |
| Industrial Refrigeration |  | 115 |  |  | 88 |  |  | 212 |  |  | 158 |  |
| Total |  | $ | 2,405 |  |  | $ | 2,468 |  |  | $ | 4,467 |  |  | $ | 4,548 |  |

[0000833444-24-000029:notes:26]
[same as prior period, unchanged from 0000833444-24-000011:notes:26]

[0000833444-24-000029:notes:27]
[same as prior period, unchanged from 0000833444-24-000011:notes:27]

[0000833444-24-000029:notes:28]
[same as prior period, unchanged from 0000833444-24-000011:notes:28]

[0000833444-24-000029:notes:29]
|  |  | Location of contract balances |  | March 31, 2024 |  | September 30, 2023 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,063 |  |  | $ | 2,370 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 5 |  |  | 12 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,331 |  |  | 1,996 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 310 |  |  | 297 |  |  |  |

[0000833444-24-000029:notes:30]
For the three months ended March 31, 2024 and 2023, the Company recognized revenue of $372 million and $319 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year. For the six months ended March 31, 2024 and 2023, the Company recognized revenue of $1,261 million and $1,165 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year.

[0000833444-24-000029:notes:31]
[same as prior period, unchanged from 0000833444-24-000011:notes:31]

[0000833444-24-000029:notes:32]
[same as prior period, unchanged from 0000833444-24-000011:notes:32]

[0000833444-24-000029:notes:33]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of March 31, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $21.2 billion, of which approximately 66% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.

[0000833444-24-000029:notes:34]
[same as prior period, unchanged from 0000833444-24-000011:notes:34]

[0000833444-24-000029:notes:35]
[same as prior period, unchanged from 0000833444-24-000011:notes:35]

[0000833444-24-000029:notes:36]
[same as prior period, unchanged from 0000833444-24-000011:notes:36]

[0000833444-24-000029:notes:37]
|  |  | March 31, 2024 |  | September 30, 2023 |  |  |
| Other current assets |  | $ | 204 |  |  | $ | 156 |  |  |  |
| Other noncurrent assets |  | 263 |  |  | 224 |  |  |  |
| Total |  | $ | 467 |  |  | $ | 380 |  |  |  |

[0000833444-24-000029:notes:38]
During the three months ended March 31, 2024 and 2023, the Company recognized amortization expense of $77 million and $61 million, respectively, related to costs to obtain or fulfill a contract. During the six months ended March 31, 2024 and 2023, the Company recognized amortization expense of $134 million and $122 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and six months ended March 31, 2024 and 2023.


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0000833444-24-000029:notes:39]
ACCOUNTS RECEIVABLEThe Company sold $702 million of accounts receivable under factoring agreements during the six months ended March 31, 2024. No amounts were sold during the three months ended March 31, 2024 as the Company discontinued its receivable factoring program. The Company sold $427 million and $836 million of accounts receivable during the three and six months ended March 31, 2023, respectively. Previously sold receivables still outstanding were $82 million and $681 million as of March 31, 2024 and September 30, 2023, respectively.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-24-000029:notes:40]
[same as prior period, unchanged from 0000833444-24-000011:notes:40]

[0000833444-24-000029:notes:41]
|  | March 31, 2024 |  | September 30, 2023 |
| Raw materials and supplies | $ | 1,218 |  |  | $ | 1,203 |  |
| Work-in-process | 267 |  |  | 226 |  |
| Finished goods | 1,506 |  |  | 1,347 |  |
| Inventories | $ | 2,991 |  |  | $ | 2,776 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-24-000029:notes:42]
GOODWILL AND OTHER INTANGIBLE ASSETS
The following table summarizes changes in the carrying amount of goodwill in each of the Company’s reportable segments (in millions):

[0000833444-24-000029:notes:43]
|  |  | Building Solutions North America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | Total |
| Goodwill |  | $ | 10,040 |  |  | $ | 1,932 |  |  | $ | 1,179 |  |  | $ | 5,750 |  |  | 18,901 |  |
| Accumulated impairment loss |  | (659) |  |  | (47) |  |  | — |  |  | (259) |  |  | (965) |  |
| Balance at September 30, 2023 |  | 9,381 |  |  | 1,885 |  |  | 1,179 |  |  | 5,491 |  |  | 17,936 |  |
| Impairments |  | — |  |  | (230) |  |  | — |  |  | — |  |  | (230) |  |
| Foreign currency translation and other (1) |  | 11 |  |  | 44 |  |  | 1 |  |  | (5) |  |  | 51 |  |
| Balance at March 31, 2024 |  | $ | 9,392 |  |  | $ | 1,699 |  |  | $ | 1,180 |  |  | $ | 5,486 |  |  | $ | 17,757 |  |

[0000833444-24-000029:notes:44]
[same as prior period, unchanged from 0000833444-24-000011:notes:44]

[0000833444-24-000029:notes:45]
The Company tests goodwill for impairment annually as of July 31 or more frequently if events or changes in circumstances indicate the asset might be impaired. During the second quarter of fiscal 2024, the Company determined a

[0000833444-24-000029:notes:46]
triggering event had occurred for one of its reporting units due to year-to-date results and projections for the remainder of fiscal 2024 being lower than the forecast used in the previous annual goodwill impairment test, and a quantitative test of goodwill for possible impairment was necessary. As a result of the goodwill impairment test, the Company recorded a non-cash impairment charge of $230 million within restructuring and impairment cost in the consolidated statements of income, which was determined by comparing the carrying amount of the reporting unit to its fair value. The Company used a discounted cash flow model to estimate the fair value of the reporting unit. The primary assumptions used in the model were management's internal projections of future cash flows, the weighted-average cost of capital and the long-term growth rate, which are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The reporting unit whose goodwill was impaired was previously disclosed as being at risk of impairment in the Company’s Annual Report on Form 10-K for the year-ended September 30, 2023. It is possible that future changes in circumstances, including an increase in the discount rate or a decrease in the revenue growth rates, could result in an additional non-cash impairment charge of the remaining $215 million of goodwill for this reporting unit. There were no other triggering events requiring an impairment assessment be conducted in the six months ended March 31, 2024.

[0000833444-24-000029:notes:47]
Other intangible assets, primarily from business acquisitions, consisted of (in millions):

[0000833444-24-000029:notes:48]
|  | March 31, 2024 |  | September 30, 2023 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Definite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,592 |  |  | $ | (884) |  |  | $ | 708 |  |  | $ | 1,575 |  |  | $ | (806) |  |  | $ | 769 |  |
| Customer relationships | 3,056 |  |  | (1,616) |  |  | 1,440 |  |  | 3,047 |  |  | (1,496) |  |  | 1,551 |  |
| Miscellaneous | 938 |  |  | (487) |  |  | 451 |  |  | 889 |  |  | (435) |  |  | 454 |  |
|  | 5,586 |  |  | (2,987) |  |  | 2,599 |  |  | 5,511 |  |  | (2,737) |  |  | 2,774 |  |
| Indefinite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,118 |  |  | — |  |  | 2,118 |  |  | 2,114 |  |  | — |  |  | 2,114 |  |
| Total intangible assets | $ | 7,704 |  |  | $ | (2,987) |  |  | $ | 4,717 |  |  | $ | 7,625 |  |  | $ | (2,737) |  |  | $ | 4,888 |  |

[0000833444-24-000029:notes:49]
Amortization of other intangible assets for the three months ended March 31, 2024 and 2023 was $125 million and $104 million, respectively. Amortization of other intangible assets for the six months ended March 31, 2024 and 2023 was $247 million and $208 million, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000833444-24-000029:notes:50]
[same as prior period, unchanged from 0000833444-24-000011:notes:48]

[0000833444-24-000029:notes:51]
|  | Location of lease balances |  | March 31, 2024 |  | September 30, 2023 |
| Operating lease right-of-use assets | Other noncurrent assets |  | $ | 1,342 |  |  | $ | 1,389 |  |
| Operating lease liabilities - current | Other current liabilities |  | 317 |  |  | 318 |  |
| Operating lease liabilities - noncurrent | Other noncurrent liabilities |  | 1,039 |  |  | 1,086 |  |

[0000833444-24-000029:notes:52]
[same as prior period, unchanged from 0000833444-24-000011:notes:50]

[0000833444-24-000029:notes:53]
|  |  |  |  | Six Months Ended March 31, |  |  |
|  |  |  |  |  |  | 2024 |  | 2023 |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  |  |  |  |  | $ | 135 |  |  | $ | 215 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-24-000029:notes:54]
DEBT AND FINANCING ARRANGEMENTS
Short-term debt consisted of the following (in millions):

[0000833444-24-000029:notes:55]
|  | March 31, |  | September 30, |
|  | 2024 |  | 2023 |
| Commercial paper | $ | 1,784 |  |  | $ | 200 |  |
| Term loans | 424 |  |  | 159 |  |
| Bank borrowings | 2 |  |  | 26 |  |
|  | $ | 2,210 |  |  | $ | 385 |  |
| Weighted average interest rate on short-term debt outstanding | 4.7 | % |  | 5.1 | % |

[0000833444-24-000029:notes:56]
As of March 31, 2024, the Company had syndicated committed revolving credit facilities of $2.5 billion which is scheduled to expire in December 2028 and $500 million which is scheduled to expire in December 2024. There were no draws on the facilities as of March 31, 2024.

[0000833444-24-000029:notes:57]
In April 2024, the Company and its wholly-owned subsidiary, Tyco Fire & Security Finance S.C.A, co-issued $700 million unsecured, unsubordinated senior notes with an interest rate of 5.50% which is due April 2029.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-24-000029:notes:58]
[same as prior period, unchanged from 0000833444-24-000011:notes:55]

[0000833444-24-000029:notes:59]
[same as prior period, unchanged from 0000833444-24-000011:notes:56]

[0000833444-24-000029:notes:60]
[same as prior period, unchanged from 0000833444-24-000011:notes:57]

[0000833444-24-000029:notes:61]
The Company enters into forward-starting interest-rate swaps in conjunction with anticipated note issuances. Forward-starting interest-rate swaps are terminated when the anticipated notes are issued. Accumulated amounts recorded in accumulated other comprehensive income (loss) ("AOCI") as of the date of the note issuance are amortized to interest expense over the life of the related note to reflect the difference between the swap's reference rate and the fixed rate of the note.

[0000833444-24-000029:notes:62]
During the three months ended March 31, 2024, the Company terminated $600 million of forward-starting interest-rate swaps related to an anticipated note issuance that was no longer highly likely to occur. Accumulated amounts previously recorded in AOCI were not material and were recognized as net financing charges in the consolidated statements of income when the swaps were terminated.

[0000833444-24-000029:notes:63]
[same as prior period, unchanged from 0000833444-24-000011:notes:59]

[0000833444-24-000029:notes:64]
[same as prior period, unchanged from 0000833444-24-000011:notes:60]

[0000833444-24-000029:notes:65]
|  |  | Volume Outstanding as of |
| Commodity |  | March 31, 2024 |  | September 30, 2023 |
| Copper |  | 3,447 |  |  | 2,812 |  |
| Aluminum |  | 7,085 |  |  | 5,976 |  |

[0000833444-24-000029:notes:66]
Cash flow hedges under ASC 815, "Derivatives and Hedging," that hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates and commodity prices during the three and six months ended March 31, 2024 and 2023.

[0000833444-24-000029:notes:67]
[same as prior period, unchanged from 0000833444-24-000011:notes:63]

[0000833444-24-000029:notes:68]
The Company enters into cross-currency interest rate swaps and foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the cross-currency interest rate swaps and debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally.

[0000833444-24-000029:notes:69]
[same as prior period, unchanged from 0000833444-24-000011:notes:65]

[0000833444-24-000029:notes:70]
|  |  | March 31, |  | September 30, |
|  | 2024 |  | 2023 |
| Euro-denominated bonds designated as net investment hedges in Europe |  | € | 2.9 |  |  | € | 2.9 |  |
| Yen-denominated debt designated as a net investment hedge in Japan |  | ¥ | 30 |  |  | ¥ | 30 |  |
| US dollar vs. Yen cross-currency interest rate swap designated as a net investment hedge in Japan |  | ¥ | 14 |  |  | ¥ | 14 |  |

[0000833444-24-000029:notes:71]
[same as prior period, unchanged from 0000833444-24-000011:notes:67]

[0000833444-24-000029:notes:72]
[same as prior period, unchanged from 0000833444-24-000011:notes:68]

[0000833444-24-000029:notes:73]
[same as prior period, unchanged from 0000833444-24-000011:notes:69]

[0000833444-24-000029:notes:74]
[same as prior period, unchanged from 0000833444-24-000011:notes:70]

[0000833444-24-000029:notes:75]
|  | Derivatives and Hedging Activities Designatedas Hedging Instruments |  | Derivatives and Hedging ActivitiesNot Designatedas Hedging Instruments |
|  | March 31, |  | September 30, |  | March 31, |  | September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 18 |  |  | $ | 16 |  |  | $ | 7 |  |  | $ | 13 |  |
| Interest rate swaps | — |  |  | 22 |  |  | — |  |  | — |  |
| Commodity derivatives | 2 |  |  | — |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Cross-currency interest rate swap | 7 |  |  | 5 |  |  | — |  |  | — |  |
| Total assets | $ | 27 |  |  | $ | 43 |  |  | $ | 7 |  |  | $ | 13 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 17 |  |  | $ | 20 |  |  | $ | — |  |  | $ | 5 |  |
| Commodity derivatives | — |  |  | 2 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 3,302 |  |  | 3,253 |  |  | — |  |  | — |  |
| Total liabilities | $ | 3,319 |  |  | $ | 3,275 |  |  | $ | — |  |  | $ | 5 |  |

[0000833444-24-000029:notes:76]
[same as prior period, unchanged from 0000833444-24-000011:notes:72]

[0000833444-24-000029:notes:77]
[same as prior period, unchanged from 0000833444-24-000011:notes:73]

[0000833444-24-000029:notes:78]
[same as prior period, unchanged from 0000833444-24-000011:notes:74]

[0000833444-24-000029:notes:79]
[same as prior period, unchanged from 0000833444-24-000011:notes:75]

[0000833444-24-000029:notes:80]
|  |  | Fair Value of Assets |  |  |  | Fair Value of Liabilities |  |  |
|  |  | March 31, |  | September 30, |  |  |  | March 31, |  | September 30, |  |  |
|  |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 |  |  |
| Gross amount recognized |  | $ | 34 |  |  | $ | 56 |  |  |  |  | $ | 3,319 |  |  | $ | 3,280 |  |  |  |
| Gross amount eligible for offsetting |  | (10) |  |  | (19) |  |  |  |  | (10) |  |  | (19) |  |  |  |
| Net amount |  | $ | 24 |  |  | $ | 37 |  |  |  |  | $ | 3,309 |  |  | $ | 3,261 |  |  |  |

[0000833444-24-000029:notes:81]
[same as prior period, unchanged from 0000833444-24-000011:notes:77]

[0000833444-24-000029:notes:82]
[same as prior period, unchanged from 0000833444-24-000011:notes:78]

[0000833444-24-000029:notes:83]
| Derivatives in Cash Flow Hedging Relationships |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Foreign currency exchange derivatives |  | $ | 15 |  |  | $ | 9 |  |  | $ | 2 |  |  | $ | (12) |  |
| Commodity derivatives |  | — |  |  | 3 |  |  | 1 |  |  | 7 |  |
| Interest rate swaps |  | 14 |  |  | 5 |  |  | (21) |  |  | 5 |  |
| Total |  | $ | 29 |  |  | $ | 17 |  |  | $ | (18) |  |  | $ | — |  |

[0000833444-24-000029:notes:84]
[same as prior period, unchanged from 0000833444-24-000011:notes:80]

[0000833444-24-000029:notes:85]
| Derivatives in Cash Flow Hedging Relationships |  | Location of Gain (Loss) Reclassified from AOCI into Income |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (2) |  |  | $ | (5) |  |  | $ | (3) |  |  | $ | 4 |  |
| Commodity derivatives |  | Cost of sales |  | (1) |  |  | (2) |  |  | (4) |  |  | (8) |  |
| Total |  |  |  | $ | (3) |  |  | $ | (7) |  |  | $ | (7) |  |  | $ | (4) |  |

[0000833444-24-000029:notes:86]
[same as prior period, unchanged from 0000833444-24-000011:notes:82]

[0000833444-24-000029:notes:87]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 2 |  |  | $ | (6) |  |  | $ | (3) |  |  | $ | (8) |  |
| Foreign currency exchange derivatives |  | SG&A |  | (1) |  |  | — |  |  | (1) |  |  | — |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | 59 |  |  | 15 |  |  | 16 |  |  | (64) |  |
| Total |  |  |  | $ | 60 |  |  | $ | 9 |  |  | $ | 12 |  |  | $ | (72) |  |

[0000833444-24-000029:notes:88]
The following table presents pre-tax gains (losses) on net investment hedges recorded as foreign currency translation adjustments ("CTA") within other comprehensive income (loss) (in millions):

[0000833444-24-000029:notes:89]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
| 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net investment hedges | $ | 98 |  |  | $ | (60) |  |  | $ | (47) |  |  | $ | (329) |  |

[0000833444-24-000029:notes:90]
No gains or losses were reclassified from CTA into income during the three and six months ended March 31, 2024 and 2023.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-24-000029:notes:91]
[same as prior period, unchanged from 0000833444-24-000011:notes:85]

[0000833444-24-000029:notes:92]
[same as prior period, unchanged from 0000833444-24-000011:notes:86]

[0000833444-24-000029:notes:93]
[same as prior period, unchanged from 0000833444-24-000011:notes:87]

[0000833444-24-000029:notes:94]
[same as prior period, unchanged from 0000833444-24-000011:notes:88]

[0000833444-24-000029:notes:95]
[same as prior period, unchanged from 0000833444-24-000011:notes:89]

[0000833444-24-000029:notes:96]
[same as prior period, unchanged from 0000833444-24-000011:notes:90]

[0000833444-24-000029:notes:97]
[same as prior period, unchanged from 0000833444-24-000011:notes:91]

[0000833444-24-000029:notes:98]
|  | Fair Value Measurements Using: |
|  | Total as of March 31, 2024 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 25 |  |  | $ | — |  |  | $ | 25 |  |  | $ | — |  |
| Commodity derivatives | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Cross-currency interest rate swap | 7 |  |  | — |  |  | 7 |  |  | — |  |
| Deferred compensation plan assets | 53 |  |  | 53 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)(1) | 81 |  |  | 81 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)(1) | 186 |  |  | 186 |  |  | — |  |  | — |  |
| Total assets | $ | 354 |  |  | $ | 320 |  |  | $ | 34 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 17 |  |  | $ | — |  |  | $ | 17 |  |  | $ | — |  |
| Contingent earn-out liabilities | 63 |  |  | — |  |  | — |  |  | 63 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 33 |  |  | — |  |  | — |  |  | 33 |  |
| Total liabilities | $ | 113 |  |  | $ | — |  |  | $ | 17 |  |  | $ | 96 |  |

[0000833444-24-000029:notes:99]
[same as prior period, unchanged from 0000833444-24-000011:notes:93]

[0000833444-24-000029:notes:100]
(1)  Classified as restricted investments for payment of asbestos liabilities. See Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further details.

[0000833444-24-000029:notes:101]
The following table summarizes changes in contingent earn-out liabilities, which are valued using significant unobservable inputs (Level 3) (in millions):

[0000833444-24-000029:notes:102]
| Balance at September 30, 2023 | $ | 124 |  |  |
| Payments | (20) |  |  |
| Reduction for change in estimates | (8) |  |  |
| Balance at March 31, 2024 | $ | 96 |  |  |

[0000833444-24-000029:notes:103]
[same as prior period, unchanged from 0000833444-24-000011:notes:97]

[0000833444-24-000029:notes:104]
[same as prior period, unchanged from 0000833444-24-000011:notes:98]

[0000833444-24-000029:notes:105]
[same as prior period, unchanged from 0000833444-24-000011:notes:99]

[0000833444-24-000029:notes:106]
[same as prior period, unchanged from 0000833444-24-000011:notes:100]

[0000833444-24-000029:notes:107]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices. Unrealized gains (losses) on the deferred compensation plan assets are recognized in the consolidated statements of income where they offset unrealized gains and losses on the related deferred compensation plan liability.

[0000833444-24-000029:notes:108]
Exchange traded funds: Investments in exchange traded funds are valued using a market approach based on quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. Refer to Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further information.

[0000833444-24-000029:notes:109]
[same as prior period, unchanged from 0000833444-24-000011:notes:104]

[0000833444-24-000029:notes:110]
[same as prior period, unchanged from 0000833444-24-000011:notes:105]

[0000833444-24-000029:notes:111]
The following table presents the portion of unrealized gains recognized in the consolidated statements of income that relate to equity securities still held at March 31, 2024 and 2023 (in millions):

[0000833444-24-000029:notes:112]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Deferred compensation plan assets |  | $ | 3 |  |  | $ | 2 |  |  | $ | 7 |  |  | $ | 5 |  |
| Investments in exchange traded funds |  | 17 |  |  | 12 |  |  | 39 |  |  | 23 |  |

[0000833444-24-000029:notes:113]
[same as prior period, unchanged from 0000833444-24-000011:notes:109]

[0000833444-24-000029:notes:114]
The fair value of long-term debt at March 31, 2024 and September 30, 2023 was as follows (in billions):

[0000833444-24-000029:notes:115]
|  |  | March 31, |  | September 30, |  |
|  | 2024 |  | 2023 |  |
| Public debt |  | $ | 7.6 |  |  | $ | 7.1 |  |  |
| Other long-term debt |  | 0.4 |  |  | 0.4 |  |  |
| Total fair value of long-term debt |  | $ | 8.0 |  |  | $ | 7.5 |  |  |

[0000833444-24-000029:notes:116]
[same as prior period, unchanged from 0000833444-24-000011:notes:112]


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000833444-24-000029:notes:117]
[same as prior period, unchanged from 0000833444-24-000011:notes:113]

[0000833444-24-000029:notes:118]
[same as prior period, unchanged from 0000833444-24-000011:notes:114]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-24-000029:notes:119]
[same as prior period, unchanged from 0000833444-24-000011:notes:115]

[0000833444-24-000029:notes:120]
[same as prior period, unchanged from 0000833444-24-000011:notes:116]

[0000833444-24-000029:notes:121]
|  | Six Months Ended March 31, |  |  |
|  | 2024 |  |  |  | 2023 |  |  |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |
| Restricted stock/units | 1,838,525 |  |  | $ | 53.69 |  |  |  |  | 1,720,662 |  |  | $ | 66.59 |  |  |  |
| Performance shares | 370,307 |  |  | 54.13 |  |  |  |  | 339,191 |  |  | 79.54 |  |  |  |
| Stock options | 652,702 |  |  | 13.74 |  |  |  |  | 570,140 |  |  | 18.21 |  |  |  |

[0000833444-24-000029:notes:122]
[same as prior period, unchanged from 0000833444-24-000011:notes:118]

[0000833444-24-000029:notes:123]
[same as prior period, unchanged from 0000833444-24-000011:notes:119]

[0000833444-24-000029:notes:124]
|  | Six Months Ended March 31, |
|  | 2024 |  | 2023 |
| Risk-free interest rate | 4.21% |  | 4.04% |
| Expected volatility of the Company’s stock | 27.2% |  | 33.5% |

[0000833444-24-000029:notes:125]
[same as prior period, unchanged from 0000833444-24-000011:notes:121]

[0000833444-24-000029:notes:126]
[same as prior period, unchanged from 0000833444-24-000011:notes:122]

[0000833444-24-000029:notes:127]
|  | Six Months Ended March 31, |
|  | 2024 |  | 2023 |
| Expected life of option (years) | 5.7 |  | 5.8 |
| Risk-free interest rate | 3.86% |  | 3.59% |
| Expected volatility of the Company’s stock | 29.8% |  | 29.4% |
| Expected dividend yield on the Company’s stock | 2.77% |  | 2.10% |


## us-gaap:EarningsPerShareTextBlock

[0000833444-24-000029:notes:128]
[same as prior period, unchanged from 0000833444-24-000011:notes:124]

[0000833444-24-000029:notes:129]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net income (loss) attributable to Johnson Controls | $ | (277) |  |  | $ | 133 |  |  | $ | 97 |  |  | $ | 251 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 679.0 |  |  | 686.8 |  |  | 679.9 |  |  | 686.9 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | — |  |  | 2.9 |  |  | 1.6 |  |  | 3.1 |  |
| Diluted weighted average shares outstanding | 679.0 |  |  | 689.7 |  |  | 681.5 |  |  | 690.0 |  |
| Antidilutive Securities |  |  |  |  |  |  |  |
| Stock options and unvested restricted stock | — |  |  | 0.3 |  |  | 0.5 |  |  | 0.3 |  |

[0000833444-24-000029:notes:130]
For the three months ended March 31, 2024, the total number of potential dilutive shares due to stock options, unvested restricted stock and unvested performance share awards was 1.6 million. However, these items were not included in the computation of diluted loss per share for the three months ended March 31, 2024 since to do so would decrease the loss per share.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-24-000029:notes:131]
[same as prior period, unchanged from 0000833444-24-000011:notes:126]

[0000833444-24-000029:notes:132]
During the three and six months ended March 31, 2024, the Company repurchased and immediately retired $474 million of its ordinary shares. During the three and six months ended March 31, 2023, the Company repurchased and immediately retired $93 million and $247 million, respectively, of its ordinary shares.

[0000833444-24-000029:notes:133]
As of March 31, 2024, approximately $2.5 billion remains available under the Company's share repurchase program, which was approved by the Company's Board of Directors in March 2021. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice.

[0000833444-24-000029:notes:134]
[same as prior period, unchanged from 0000833444-24-000011:notes:129]

[0000833444-24-000029:notes:135]
The following schedules present changes in AOCI attributable to Johnson Controls (in millions):

[0000833444-24-000029:notes:136]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Foreign currency translation adjustments |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (909) |  |  | $ | (842) |  |  | $ | (970) |  |  | $ | (901) |  |
| Aggregate adjustment for the period | (92) |  |  | (1) |  |  | (31) |  |  | 58 |  |
| Balance at end of period | (1,001) |  |  | (843) |  |  | (1,001) |  |  | (843) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |  |  |  |  |
| Balance at beginning of period | (23) |  |  | (22) |  |  | 15 |  |  | (11) |  |
| Current period changes in fair value | 23 |  |  | 16 |  |  | (20) |  |  | 5 |  |
| Reclassification to income (1) | 3 |  |  | 7 |  |  | 7 |  |  | 4 |  |
| Net tax impact | (3) |  |  | (4) |  |  | (2) |  |  | (1) |  |
| Balance at end of period | — |  |  | (3) |  |  | — |  |  | (3) |  |
| Pension and postretirement plans |  |  |  |  |  |  |  |
| Balance at beginning of period | (1) |  |  | — |  |  | — |  |  | 1 |  |
| Reclassification to income | (2) |  |  | (1) |  |  | (3) |  |  | (2) |  |
| Net tax impact | 1 |  |  | 1 |  |  | 1 |  |  | 1 |  |
| Balance at end of period | (2) |  |  | — |  |  | (2) |  |  | — |  |
| Accumulated other comprehensive loss, end of period | $ | (1,003) |  |  | $ | (846) |  |  | $ | (1,003) |  |  | $ | (846) |  |

[0000833444-24-000029:notes:137]
[same as prior period, unchanged from 0000833444-24-000011:notes:132]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-24-000029:notes:138]
[same as prior period, unchanged from 0000833444-24-000011:notes:133]

[0000833444-24-000029:notes:139]
|  | U.S. Pension Plans |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Interest cost | $ | 19 |  |  | $ | 20 |  |  | $ | 39 |  |  | $ | 41 |  |
| Expected return on plan assets | (30) |  |  | (33) |  |  | (60) |  |  | (67) |  |
| Net actuarial loss | — |  |  | 15 |  |  | — |  |  | 23 |  |
| Settlement loss | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net periodic benefit cost (credit) | $ | (11) |  |  | $ | 3 |  |  | $ | (21) |  |  | $ | (2) |  |

[0000833444-24-000029:notes:140]
|  | Non-U.S. Pension Plans |
|  | Three Months Ended March 31, |  | Six Months EndedMarch 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Service cost | $ | 4 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 7 |  |
| Interest cost | 17 |  |  | 17 |  |  | 34 |  |  | 33 |  |
| Expected return on plan assets | (18) |  |  | (19) |  |  | (36) |  |  | (37) |  |
| Net periodic benefit cost | $ | 3 |  |  | $ | 2 |  |  | $ | 6 |  |  | $ | 3 |  |

[0000833444-24-000029:notes:141]
|  | Postretirement Benefits |
|  | Three Months Ended March 31, |  | Six Months EndedMarch 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Interest cost | $ | 1 |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | 2 |  |
| Expected return on plan assets | (2) |  |  | (2) |  |  | (4) |  |  | (4) |  |
| Amortization of prior service credit | (2) |  |  | (1) |  |  | (3) |  |  | (2) |  |
| Net periodic benefit credit | $ | (3) |  |  | $ | (2) |  |  | $ | (5) |  |  | $ | (4) |  |

[0000833444-24-000029:notes:142]
During the three and six months ended March 31, 2023, the amount of cumulative fiscal 2023 lump sum payouts triggered a remeasurement event for certain U.S. pension plans resulting in the recognition of net actuarial losses of $15 million and $23 million, respectively, primarily due to decreases in discount rates, partially offset by favorable plan asset performance.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-24-000029:notes:143]
[same as prior period, unchanged from 0000833444-24-000011:notes:138]

[0000833444-24-000029:notes:144]
In the third and fourth quarters of fiscal 2023, the Company developed a restructuring plan which included workforce reductions and other actions focused on continued scaling of SG&A expenses to its planned growth. Additional restructuring charges related to this plan were recorded in the three and six months ended March 31, 2024 and are expected in subsequent quarters.

[0000833444-24-000029:notes:145]
The following table summarizes restructuring and related costs (in millions):

[0000833444-24-000029:notes:146]
|  | Three Months Ended March 31, 2024 |  | Six Months Ended March 31, 2024 |  |  |
| Building Solutions North America | $ | — |  |  | $ | 4 |  |  |  |
| Building Solutions EMEA/LA | — |  |  | 13 |  |  |  |
| Building Solutions Asia Pacific | 3 |  |  | 3 |  |  |  |
| Global Products | 15 |  |  | 36 |  |  |  |
| Corporate | 6 |  |  | 7 |  |  |  |
| Total | $ | 24 |  |  | $ | 63 |  |  |  |

[0000833444-24-000029:notes:147]
The following table summarizes changes in the restructuring reserve, which is included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-24-000029:notes:148]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  |  |  | Total |
| Restructuring and related costs | $ | 204 |  |  | $ | 38 |  |  | $ | 34 |  |  |  |  | $ | 276 |  |
| Utilized—cash | (111) |  |  | — |  |  | (19) |  |  |  |  | (130) |  |
| Utilized—noncash | — |  |  | (38) |  |  | (3) |  |  |  |  | (41) |  |
| Balance at September 30, 2023 | 93 |  |  | — |  |  | 12 |  |  |  |  | 105 |  |
| Additional restructuring and related costs | 34 |  |  | 23 |  |  | 6 |  |  |  |  | 63 |  |
| Utilized—cash | (84) |  |  | — |  |  | (6) |  |  |  |  | (90) |  |
| Utilized—noncash | — |  |  | (23) |  |  | (1) |  |  |  |  | (24) |  |
| Other | 28 |  |  | — |  |  | — |  |  |  |  | 28 |  |
| Balance at March 31, 2024 | $ | 71 |  |  | $ | — |  |  | $ | 11 |  |  |  |  | $ | 82 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-24-000029:notes:149]
[same as prior period, unchanged from 0000833444-24-000011:notes:144]

[0000833444-24-000029:notes:150]
[same as prior period, unchanged from 0000833444-24-000011:notes:145]

[0000833444-24-000029:notes:151]
For the three months ended March 31, 2024, the Company's effective tax rate was 35.2% and was higher than the statutory tax rate of 12.5% primarily due to the tax impact of an impairment charge and tax rate differentials, partially offset by the tax impact of the water systems Aqueous Film Forming Foam ("AFFF") settlement costs and the benefits of continuing global tax planning.

[0000833444-24-000029:notes:152]
For the six months ended March 31, 2024, the Company's effective tax rate was (305%) and was lower than the statutory tax rate of 12.5% primarily due to the tax impact of the water systems AFFF settlement costs, Swiss tax reform, and the benefits of continuing global tax planning, partially offset by the tax impact of an impairment charge, the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain consolidated subsidiaries and tax rate differentials.

[0000833444-24-000029:notes:153]
For the three months ended March 31, 2023, the Company's effective tax rate was 22.0% and was higher than the statutory tax rate of 12.5% primarily due to the tax impact of an impairment charge and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives.

[0000833444-24-000029:notes:154]
For the six months ended March 31, 2023, the Company's effective tax rate was 16.0% and was higher than the statutory tax rate of 12.5% primarily due to the tax impact of an impairment charge and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives.

[0000833444-24-000029:notes:155]
Refer to Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further disclosure related to the water systems AFFF settlement.

[0000833444-24-000029:notes:156]
[same as prior period, unchanged from 0000833444-24-000011:notes:150]

[0000833444-24-000029:notes:157]
At September 30, 2023, the Company had gross tax-effected unrecognized tax benefits of $2.2 billion, of which $1.6 billion, if recognized, would impact the effective tax rate. Accrued interest, net at September 30, 2023 was approximately

[0000833444-24-000029:notes:158]
$335 million (net of tax benefit). Interest accrued during the six months ended March 31, 2024 and 2023 was approximately $60 million and $56 million (both net of tax benefit), respectively. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-24-000029:notes:159]
In the U.S., fiscal years 2019 through 2020 are currently under audit and fiscal years 2017 through 2018 are currently under appeal with the Internal Revenue Service (“IRS”) for certain legal entities. In addition, fiscal years 2016 through 2019 are also under exam by the IRS in relation to a separate consolidated filing group. Additionally, the Company is currently under exam in the following major non-U.S. jurisdictions:

[0000833444-24-000029:notes:160]
[same as prior period, unchanged from 0000833444-24-000011:notes:153]

[0000833444-24-000029:notes:161]
It is reasonably possible that tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense. Based upon the circumstances surrounding these examinations, the impact is not currently quantifiable.

[0000833444-24-000029:notes:162]
[same as prior period, unchanged from 0000833444-24-000011:notes:158]

[0000833444-24-000029:notes:163]
On September 11, 2023, the Schaffhausen parliament approved a partial revision of the cantonal act on direct taxation: Immediate Minimum Taxation Measure (“IMTM”). On November 19, 2023, IMTM was approved in a public referendum in the canton of Schaffhausen, was published in the cantonal official gazette on December 8, 2023, and is effective starting January 1, 2024. The IMTM increased Switzerland's combined statutory income tax rate to approximately 15%. As a result, in the six months ended March 31, 2024, the Company recorded a noncash discrete net tax benefit of $80 million due to the remeasurement of deferred tax assets and liabilities related to Switzerland and the canton of Schaffhausen.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-24-000029:notes:164]
[same as prior period, unchanged from 0000833444-24-000011:notes:161]

[0000833444-24-000029:notes:165]
The Company conducts its business through four operating segments, all of which are reportable segments:

[0000833444-24-000029:notes:166]
[same as prior period, unchanged from 0000833444-24-000011:notes:163]

[0000833444-24-000029:notes:167]
[same as prior period, unchanged from 0000833444-24-000011:notes:164]

[0000833444-24-000029:notes:168]
[same as prior period, unchanged from 0000833444-24-000011:notes:165]

[0000833444-24-000029:notes:169]
[same as prior period, unchanged from 0000833444-24-000011:notes:166]

[0000833444-24-000029:notes:170]
[same as prior period, unchanged from 0000833444-24-000011:notes:167]

[0000833444-24-000029:notes:171]
[same as prior period, unchanged from 0000833444-24-000011:notes:168]

[0000833444-24-000029:notes:172]
[same as prior period, unchanged from 0000833444-24-000011:notes:169]

[0000833444-24-000029:notes:173]
[same as prior period, unchanged from 0000833444-24-000011:notes:170]

[0000833444-24-000029:notes:174]
[same as prior period, unchanged from 0000833444-24-000011:notes:171]

[0000833444-24-000029:notes:175]
[same as prior period, unchanged from 0000833444-24-000011:notes:172]

[0000833444-24-000029:notes:176]
[same as prior period, unchanged from 0000833444-24-000011:notes:173]

[0000833444-24-000029:notes:177]
[same as prior period, unchanged from 0000833444-24-000011:notes:174]

[0000833444-24-000029:notes:178]
[same as prior period, unchanged from 0000833444-24-000011:notes:175]

[0000833444-24-000029:notes:179]
Management evaluates the performance of its segments primarily on segment earnings before interest, taxes and amortization ("EBITA"), which represents income before income taxes and noncontrolling interests, excluding corporate expenses, amortization of intangible assets, restructuring and impairment costs, the water systems AFFF settlement costs, net mark-to-market gains and losses related to pension and postretirement plans and restricted asbestos investments, and net financing charges.

[0000833444-24-000029:notes:180]
[same as prior period, unchanged from 0000833444-24-000011:notes:177]

[0000833444-24-000029:notes:181]
|  | Net Sales |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Building Solutions North America | $ | 2,739 |  |  | $ | 2,520 |  |  | $ | 5,226 |  |  | $ | 4,887 |  |
| Building Solutions EMEA/LA | 1,064 |  |  | 1,031 |  |  | 2,102 |  |  | 2,006 |  |
| Building Solutions Asia Pacific | 491 |  |  | 667 |  |  | 998 |  |  | 1,313 |  |
| Global Products | 2,405 |  |  | 2,468 |  |  | 4,467 |  |  | 4,548 |  |
| Total net sales | $ | 6,699 |  |  | $ | 6,686 |  |  | $ | 12,793 |  |  | $ | 12,754 |  |

[0000833444-24-000029:notes:182]
|  | Segment EBITA |
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Building Solutions North America | $ | 373 |  |  | $ | 315 |  |  | $ | 658 |  |  | $ | 582 |  |
| Building Solutions EMEA/LA | 89 |  |  | 69 |  |  | 169 |  |  | 144 |  |
| Building Solutions Asia Pacific | 54 |  |  | 79 |  |  | 100 |  |  | 147 |  |
| Global Products | 429 |  |  | 488 |  |  | 798 |  |  | 870 |  |
| Total segment EBITA | 945 |  |  | 951 |  |  | 1,725 |  |  | 1,743 |  |
| Corporate expenses | 99 |  |  | 131 |  |  | 238 |  |  | 240 |  |
| Amortization of intangible assets | 125 |  |  | 104 |  |  | 247 |  |  | 208 |  |
| Restructuring and impairment costs | 254 |  |  | 418 |  |  | 293 |  |  | 763 |  |
| Water systems AFFF settlement (1) | 750 |  |  | — |  |  | 750 |  |  | — |  |
| Net mark-to-market losses (gains) | (15) |  |  | 4 |  |  | (37) |  |  | 1 |  |
| Net financing charges | 93 |  |  | 71 |  |  | 192 |  |  | 138 |  |
| Income (loss) before income taxes | $ | (361) |  |  | $ | 223 |  |  | $ | 42 |  |  | $ | 393 |  |

[0000833444-24-000029:notes:183]
(1) Refer to Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further disclosure related to the water systems AFFF settlement.


## us-gaap:GuaranteesTextBlock

[0000833444-24-000029:notes:184]
[same as prior period, unchanged from 0000833444-24-000011:notes:180]

[0000833444-24-000029:notes:185]
[same as prior period, unchanged from 0000833444-24-000011:notes:181]

[0000833444-24-000029:notes:186]
[same as prior period, unchanged from 0000833444-24-000011:notes:182]

[0000833444-24-000029:notes:187]
The following table summarizes changes in the total product warranty liability (in millions):

[0000833444-24-000029:notes:188]
| Balance at September 30, 2023 | $ | 203 |  |  |
| Accruals for warranties issued during the period | 71 |  |  |
| Settlements made (in cash or in kind) during the period | (64) |  |  |
| Changes in estimates to pre-existing warranties | 28 |  |  |
| Balance at March 31, 2024 | $ | 238 |  |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-24-000029:notes:189]
COMMITMENTS AND CONTINGENCIES
Environmental Matters

[0000833444-24-000029:notes:190]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-24-000029:notes:191]
|  | March 31, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 28 |  |  | $ | 31 |  |
| Other noncurrent liabilities | 194 |  |  | 211 |  |
| Total reserves for environmental liabilities | $ | 222 |  |  | $ | 242 |  |

[0000833444-24-000029:notes:192]
The Company periodically examines whether the contingent liabilities related to the environmental matters described below are probable and reasonably estimable based on experience and ongoing developments in those matters, including continued study and analysis of ongoing remediation obligations. The Company expects that it will pay the amounts recorded over an estimated period of up to 20 years. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals for environmental liabilities at this time.

[0000833444-24-000029:notes:193]
A substantial portion of the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to Aqueous Film Forming Foam ("AFFF") containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire

[0000833444-24-000029:notes:194]
Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).

[0000833444-24-000029:notes:195]
PFOA, PFOS, and other PFAS compounds are being studied by the U.S. Environmental Protection Agency ("EPA")  and other environmental and health agencies and researchers. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. On April 10, 2024, EPA announced the final National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR established legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion ("ppt") for each of PFOA and PFOS, 10 ppt for each of PFHxS, PFNA, and HFPO-DA (commonly known as GenX Chemicals), and a Hazard Index of one for mixtures containing two or more of PFHxS, PFNA, HFPO-DA, and PFBA. In February 2024, EPA released two proposed rules relating to PFAS under the Resource Conservation and Recovery Act (“RCRA”): one rule proposes to list nine PFAS (including PFOA and PFOS) as “hazardous constituents,” and a second rule proposes to clarify that hazardous waste regulated under the rule includes not only substances listed or identified as hazardous waste in the regulations, but also any substances that meets the statutory definition of hazardous waste.

[0000833444-24-000029:notes:196]
In August 2022, EPA published a proposed rule that would designate PFOA and PFOS as “hazardous substances” under Comprehensive Environmental Response, Compensation and Liability Act ("CERCLA"). In April 2023, EPA issued an Advanced Notice of Proposed Rulemaking ("ANPR") seeking input on whether it should expand the proposed rule to designate as "hazardous substances" under CERCLA: (1) seven additional PFAS; (2) the precursors to PFOA, PFOS, and the seven additional PFAS; or (3) entire categories of PFAS. On April 17, 2024, the EPA Administrator signed the final rule designating PFOA and PFOS, along with their salts and structural isomers, as “hazardous substances.”

[0000833444-24-000029:notes:197]
It is not possible to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in soil, groundwater and drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000833444-24-000029:notes:198]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $10 million and $13 million at March 31, 2024 and September 30, 2023, respectively.

[0000833444-24-000029:notes:199]
FTC-Related Matters

[0000833444-24-000029:notes:200]
FTC Remediation

[0000833444-24-000029:notes:201]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. On July 18, 2023, Tyco Fire Products announced that it plans to discontinue the production and sale of fluorinated firefighting foams by June 2024, including AFFF products, and will transition to non-fluorinated foam alternatives.

[0000833444-24-000029:notes:202]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street

[0000833444-24-000029:notes:203]
Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with  EPA to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

[0000833444-24-000029:notes:204]
Tyco Fire Products is operating and monitoring at the FTC a Groundwater Extraction and Treatment System ("GETS"), a permanent groundwater remediation system that extracts groundwater containing PFAS, treats it using advanced filtration systems, and returns the treated water to the environment. Tyco Fire Products has also completed the removal and disposal of PFAS-affected soil from the FTC. The Company's reserves for continued remediation of the FTC, the Stanton Street Facility and surrounding areas in Marinette and Peshtigo are based on estimates of costs associated with the long-term remediation actions, including the continued operation of the GETS, the implementation of long-term drinking water solutions for the area impacted by groundwater migrating from the FTC, continued monitoring and testing of groundwater monitoring wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

[0000833444-24-000029:notes:205]
FTC-Related Litigation

[0000833444-24-000029:notes:206]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water in February 2022, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. The WDNR initiated a rulemaking proceeding that would establish groundwater quality standards for PFOA, PFOS, perfluorobutane sulfonic acid and its potassium salt (“PFBS”) and hexafluoropropylene oxide dimer acid and its ammonium salt (“HFPO-DA”). Pursuant to state law, the WDNR has stopped work on the proposed rule and notified the state legislature that, following economic analysis, the proposed costs would exceed statutory thresholds. As a result, the state legislature is required to authorize the WDNR to allow the rulemaking to continue.

[0000833444-24-000029:notes:207]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. The WDNR issued a further letter regarding the issue on November 4, 2019. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to that date. On April 10, 2023, the WDNR issued a third “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids in the Marinette region. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions, including the potential assessment of penalties.

[0000833444-24-000029:notes:208]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the

[0000833444-24-000029:notes:209]
FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR's requests. The parties are proceeding with expert discovery and the court has set a trial date of December 3, 2024.

[0000833444-24-000029:notes:210]
In October 2022, the Town of Peshtigo filed a tort action in Wisconsin state court against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and ChemDesign, Inc. relating to environmental matters at the FTC (Town of Peshtigo v. Tyco Fire Products L.P. et al., Case No. 2022CV000234 (filed October 18, 2022 in Circuit Court in Marinette County, Wisconsin)). The Town alleges that use of AFFF products at the FTC caused contamination of water supplies in Peshtigo. The Town seeks monetary penalties and an injunction ordering abatement of PFAS contamination in Peshtigo. The case has been removed to federal court and transferred to a multi-district litigation ("MDL") before the United States District Court for the District of South Carolina.

[0000833444-24-000029:notes:211]
In November 2022, individuals filed six actions in Dane County, Wisconsin alleging personal injury and/or property damage against Tyco Fire Products, Johnson Controls Inc., Chemguard, and other unaffiliated defendants related to environmental matters at the FTC. Plaintiffs allege that use of AFFF products at the FTC and activities by third parties unrelated to the Company contaminated nearby drinking water sources, surface waters, and other natural resources and properties, including their personal properties. The individuals seek monetary damages for their personal injury and/or property damage. These lawsuits have been transferred to the MDL. Subsequently, several additional plaintiffs have direct-filed in the MDL complaints with similar allegations.

[0000833444-24-000029:notes:212]
The Company is vigorously defending each of these cases and believes that it has meritorious defenses, but it is presently unable to predict the duration, scope, or outcome of these actions.

[0000833444-24-000029:notes:213]
Aqueous Film-Forming Foam ("AFFF") Matters

[0000833444-24-000029:notes:214]
AFFF Litigation

[0000833444-24-000029:notes:215]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-24-000029:notes:216]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to the MDL. Additional cases have been identified for transfer to or are being directly filed in the MDL.

[0000833444-24-000029:notes:217]
AFFF Municipal and Water Provider Cases

[0000833444-24-000029:notes:218]
Chemguard and Tyco Fire Products have been named as defendants in more than 815 cases in federal and state courts involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 35 states and territories. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard

[0000833444-24-000029:notes:219]
bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation.

[0000833444-24-000029:notes:220]
Tyco Fire Products and Chemguard are also periodically notified by other municipal entities that those entities may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-24-000029:notes:221]
Water Systems AFFF Settlement Agreement

[0000833444-24-000029:notes:222]
On April 12, 2024, Tyco Fire Products agreed to a settlement with a nationwide class of public water systems that detected PFAS in their drinking water systems that they allege to be associated with the use of AFFF. Under the terms of the agreement, Tyco Fire Products agreed to contribute $750 million to resolve these PFAS claims. The settlement releases these claims against Tyco Fire Products, Chemguard, and other related corporate entities. In connection with the settlement, a charge for $750 million was recorded by the Company in the three months ended March 31, 2024.

[0000833444-24-000029:notes:223]
Tyco Fire Products expects to contribute an initial $250 million on or about May 25, 2024, with the remaining $500 million to be contributed six months after preliminary court approval of the settlement, which is expected to be addressed by the MDL court in or around mid-May, 2024. Tyco Fire Products has a significant amount of insurance through a number of insurers and expects to apply the proceeds recovered under its policies to cover a substantial portion of the total payment, although the specific amount and timing of any insurance recoveries are uncertain.

[0000833444-24-000029:notes:224]
There are still several procedural and legal steps that must occur before the settlement is final and payments are made. The settlement is subject to approval by the MDL court and other contingencies, and that process is expected to take several months.

[0000833444-24-000029:notes:225]
The class of public water systems included in this settlement broadly includes any public water system (as defined in the settlement agreement) that has detected PFAS in its drinking water sources as of May 15, 2024. The following systems are excluded from the settlement class: water systems owned and operated by a State or the United States government; systems that have not detected the presence of PFAS as of May 15, 2024; small transient water systems; privately-owned drinking water wells; and the water system in the city of Marinette, Wisconsin (which is included only if it so requests). The settlement does not resolve claims of public water systems that request exclusion from the class (“opt out”) pursuant to the process to be established by the MDL Court. It also does not resolve potential future claims of public water systems that detect PFAS in their water systems for the first time after May 15, 2024, or certain claims not related to drinking water, such as separate alleged claims relating to real property damage or stormwater or wastewater treatment. Finally, this settlement does not affect the other categories of cases that remain at issue in the MDL, such as personal injury cases, property damage cases, other types of class actions, claims brought by state or territory attorneys general, or other types of damages alleged to be related to the historic use of AFFF manufactured and sold by Tyco Fire Products and Chemguard. While it is reasonably possible that the excluded systems or claims could result in additional future lawsuits, claims, assessments or proceedings, it is not possible to predict the outcome of any such matters, and as such, the Company is unable to develop an estimate of a possible loss or range of losses, if any, at this time.

[0000833444-24-000029:notes:226]
The settlement does not constitute an admission of liability or wrongdoing by Tyco Fire Products or Chemguard. If the MDL court does not approve the agreement or certain terms are not fulfilled, Tyco Fire Products and Chemguard will continue to defend themselves in the litigation.

[0000833444-24-000029:notes:227]
AFFF Putative Class Actions

[0000833444-24-000029:notes:228]
Chemguard and Tyco Fire Products are named in 46 pending putative class actions in federal courts originating from 18 states and territories. All but one of these cases have been direct-filed in or transferred to the MDL. It is anticipated that the remaining state-court action will be similarly tagged and transferred. Tyco Fire Products was also recently named in a class action in British Columbia, Canada.

[0000833444-24-000029:notes:229]
AFFF Individual or Mass Actions

[0000833444-24-000029:notes:230]
There are more than 7,000 individual or “mass” actions pending that were filed in state or federal courts originating from 52 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 7,000 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly-filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona, Illinois and Virginia.

[0000833444-24-000029:notes:231]
Tyco and Chemguard are also periodically notified by other individuals that they may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-24-000029:notes:232]
AFFF State or U.S. Territory Attorneys General Litigation

[0000833444-24-000029:notes:233]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-24-000029:notes:234]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-24-000029:notes:235]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. The State’s case has been removed to federal court and transferred to the MDL. The State of Alaska has also named a number of manufacturers and other defendants, including affiliates of the Company, as third-party defendants in two cases brought by individuals against the State. These two cases have also been transferred to the MDL.

[0000833444-24-000029:notes:236]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL. In October 2022, the Attorney General filed two similar lawsuits in the superior courts of the State of North Carolina regarding alleged PFAS damages at two additional locations. These two cases have also been removed to federal court and transferred to the MDL.

[0000833444-24-000029:notes:237]
In addition, 32 other states and territories have filed 34 lawsuits against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of each of those State's environmental and natural resources allegedly resulting from the manufacture, storage, sale, distribution, marketing, and use of PFAS-containing AFFF within each respective State. The states and territories are: Arkansas, Arizona, California, Colorado, Connecticut, Delaware, the District of Columbia, Florida, Hawaii, Illinois, Kentucky, Massachusetts, Maryland, Maine, Michigan, Mississippi, New Hampshire, New Jersey, New Mexico, Ohio, Oklahoma, Oregon, Rhode Island, South Carolina, Tennessee, Texas, Vermont, Washington, Wisconsin, Guam, the Northern Mariana Islands, and Puerto Rico. All of these complaints, if not filed directly in the MDL, have been removed to federal court and transferred to the MDL.

[0000833444-24-000029:notes:238]
Other AFFF Related Matters

[0000833444-24-000029:notes:239]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

[0000833444-24-000029:notes:240]
In October 2022, the Red Cliff Band of Lake Superior Chippewa Indians (a federally recognized tribe) filed a lawsuit in the United States District Court for the Western District of Wisconsin against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota. This complaint has been transferred to the MDL.

[0000833444-24-000029:notes:241]
In July 2023, the Fond du Lac Band of Lake Superior Chippewa (a federally recognized tribe) direct-filed a lawsuit in the MDL against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota.

[0000833444-24-000029:notes:242]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. In September 2022, the AFFF MDL Court declined to grant summary judgment on the government contractor defense, ruling that various factual issues relevant to the defense must be decided by a jury rather than the Court. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin and a federal district court in South Carolina. The insurance litigation involves numerous factual and legal issues. There are numerous factual and legal issues to be resolved in connection with these claims. The Company is presently unable to predict the outcome or ultimate financial exposure beyond the water systems AFFF settlement discussed above, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

[0000833444-24-000029:notes:243]
Asbestos Matters

[0000833444-24-000029:notes:244]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-24-000029:notes:245]
The following table presents the location and amount of asbestos-related assets and liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-24-000029:notes:246]
|  | March 31, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 358 |  |  | 364 |  |
| Total asbestos-related liabilities | 416 |  |  | 422 |  |
| Other current assets | 22 |  |  | 28 |  |
| Other noncurrent assets | 308 |  |  | 273 |  |
| Total asbestos-related assets | 330 |  |  | 301 |  |
| Net asbestos-related liabilities | $ | 86 |  |  | $ | 121 |  |

[0000833444-24-000029:notes:247]
The following table presents the components of asbestos-related assets (in millions):

[0000833444-24-000029:notes:248]
|  | March 31, 2024 |  | September 30, 2023 |
| Restricted |  |  |  |
| Cash | $ | 14 |  |  | $ | 20 |  |
| Investments | 267 |  |  | 231 |  |
| Total restricted assets | 281 |  |  | 251 |  |
| Insurance receivables for asbestos-related liabilities | 49 |  |  | 50 |  |
| Total asbestos-related assets | $ | 330 |  |  | $ | 301 |  |

[0000833444-24-000029:notes:249]
The amounts recorded for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption may impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-24-000029:notes:250]
Self-Insured Liabilities

[0000833444-24-000029:notes:251]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage a portion of its insurable liabilities.

[0000833444-24-000029:notes:252]
The following table presents the location and amount of self-insured liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-24-000029:notes:253]
|  | March 31, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 90 |  |  | $ | 86 |  |
| Accrued compensation and benefits | 23 |  |  | 21 |  |
| Other noncurrent liabilities | 226 |  |  | 226 |  |
| Total self-insured liabilities | $ | 339 |  |  | $ | 333 |  |

[0000833444-24-000029:notes:254]
The following table presents the location and amount of insurance receivables in the Company's consolidated statements of financial position (in millions):

[0000833444-24-000029:notes:255]
|  | March 31, 2024 |  | September 30, 2023 |
| Other current assets | $ | 6 |  |  | $ | 6 |  |
| Other noncurrent assets | 14 |  |  | 14 |  |
| Total insurance receivables | $ | 20 |  |  | $ | 20 |  |

[0000833444-24-000029:notes:256]
Other Matters

[0000833444-24-000029:notes:257]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to the Company, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock

[0000833444-24-000029:notes:258]
The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):


## ecd:MtrlTermsOfTrdArrTextBlock

[0000833444-24-000029:notes:259]
On January 31, 2024, Nathan Manning, the Company's Vice President and Chief Operations Officer, Global Field Operations, entered into a Rule 10b5-1 trading arrangement (the "Manning 10b5-1 Plan") during the Company's fiscal second quarter open trading window. The Manning 10b5-1 Plan contemplates the sale in regular intervals of 10,669 ordinary shares of Company stock previously issued upon the vesting of restricted stock unit awards. The Manning 10b5-1 Plan is expected to become effective on or about May 6, 2024 and is scheduled to terminate upon the earlier of the sale of all shares contemplated under the Manning 10b5-1 Plan or October 31, 2024.
