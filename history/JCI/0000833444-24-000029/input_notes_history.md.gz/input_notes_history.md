# JCI note change history — 0000833444-24-000011 → 0000833444-24-000029


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-05-01):
[0000833444-24-000029:note_history:1]
|  | March 31, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 28 |  |  | $ | 31 |  |
| Other noncurrent liabilities | 194 |  |  | 211 |  |
| Total reserves for environmental liabilities | $ | 222 |  |  | $ | 242 |  |
  (was, 2024-01-30, similarity 0.9731):
[0000833444-24-000011:note_history:1]
|  | December 31, 2023 |  | September 30, 2023 |
| Other current liabilities | $ | 31 |  |  | $ | 31 |  |
| Other noncurrent liabilities | 201 |  |  | 211 |  |
| Total reserves for environmental liabilities | $ | 232 |  |  | $ | 242 |  |

- added (2024-05-01):
[0000833444-24-000029:note_history:2]
A substantial portion of the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to Aqueous Film Forming Foam ("AFFF") containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire

- changed (2024-05-01):
[0000833444-24-000029:note_history:3]
Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).
  (was, 2024-01-30, similarity 0.7014):
[0000833444-24-000011:note_history:3]
A substantial portion of the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to fire-fighting foams containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).

- added (2024-05-01):
[0000833444-24-000029:note_history:4]
PFOA, PFOS, and other PFAS compounds are being studied by the U.S. Environmental Protection Agency ("EPA")  and other environmental and health agencies and researchers. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. On April 10, 2024, EPA announced the final National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR established legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion ("ppt") for each of PFOA and PFOS, 10 ppt for each of PFHxS, PFNA, and HFPO-DA (commonly known as GenX Chemicals), and a Hazard Index of one for mixtures containing two or more of PFHxS, PFNA, HFPO-DA, and PFBA. In February 2024, EPA released two proposed rules relating to PFAS under the Resource Conservation and Recovery Act (“RCRA”): one rule proposes to list nine PFAS (including PFOA and PFOS) as “hazardous constituents,” and a second rule proposes to clarify that hazardous waste regulated under the rule includes not only substances listed or identified as hazardous waste in the regulations, but also any substances that meets the statutory definition of hazardous waste.

- changed (2024-05-01):
[0000833444-24-000029:note_history:5]
In August 2022, EPA published a proposed rule that would designate PFOA and PFOS as “hazardous substances” under Comprehensive Environmental Response, Compensation and Liability Act ("CERCLA"). In April 2023, EPA issued an Advanced Notice of Proposed Rulemaking ("ANPR") seeking input on whether it should expand the proposed rule to designate as "hazardous substances" under CERCLA: (1) seven additional PFAS; (2) the precursors to PFOA, PFOS, and the seven additional PFAS; or (3) entire categories of PFAS. On April 17, 2024, the EPA Administrator signed the final rule designating PFOA and PFOS, along with their salts and structural isomers, as “hazardous substances.”
  (was, 2024-01-30, similarity 0.8162):
[0000833444-24-000011:note_history:5]
In August 2022, EPA published a proposed rule that would designate PFOA and PFOS as “hazardous substances” under Comprehensive Environmental Response, Compensation and Liability Act ("CERCLA"). In April 2023, EPA issued an Advanced Notice of Proposed Rulemaking ("ANPR") seeking input on whether it should expand the proposed rule to designate as "hazardous substances" under CERCLA: (1) seven additional PFAS; (2) the precursors to PFOA, PFOS, and the seven additional PFAS; or (3) entire categories of PFAS. The EPA indicated that it anticipates finalizing the regulation by March 2024.

- changed (2024-05-01):
[0000833444-24-000029:note_history:6]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $10 million and $13 million at March 31, 2024 and September 30, 2023, respectively.
  (was, 2024-01-30, similarity 0.9802):
[0000833444-24-000011:note_history:6]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $10 million and $13 million at December 31, 2023 and September 30, 2023, respectively.

- added (2024-05-01):
[0000833444-24-000029:note_history:7]
FTC Remediation

- added (2024-05-01):
[0000833444-24-000029:note_history:8]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street

- changed (2024-05-01):
[0000833444-24-000029:note_history:9]
Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with  EPA to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.
  (was, 2024-01-30, similarity 0.8953):
[0000833444-24-000011:note_history:9]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency (“EPA”) to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

- changed (2024-05-01):
[0000833444-24-000029:note_history:10]
Tyco Fire Products is operating and monitoring at the FTC a Groundwater Extraction and Treatment System ("GETS"), a permanent groundwater remediation system that extracts groundwater containing PFAS, treats it using advanced filtration systems, and returns the treated water to the environment. Tyco Fire Products has also completed the removal and disposal of PFAS-affected soil from the FTC. The Company's reserves for continued remediation of the FTC, the Stanton Street Facility and surrounding areas in Marinette and Peshtigo are based on estimates of costs associated with the long-term remediation actions, including the continued operation of the GETS, the implementation of long-term drinking water solutions for the area impacted by groundwater migrating from the FTC, continued monitoring and testing of groundwater monitoring wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.
  (was, 2024-01-30, similarity 0.7537):
[0000833444-24-000011:note_history:10]
Tyco Fire Products is operating and monitoring at the FTC a Groundwater Extraction and Treatment System ("GETS"), a permanent groundwater remediation system that extracts groundwater containing PFAS, treats it using advanced filtration systems, and returns the treated water to the environment. Tyco Fire Products has also completed the removal and disposal of PFAS-affected soil from the FTC. The Company's reserves for continued remediation of the FTC, the Stanton Street Facility and surrounding areas in Marinette and Peshtigo are based on estimates of costs associated with the long-term

- added (2024-05-01):
[0000833444-24-000029:note_history:11]
FTC-Related Litigation

- added (2024-05-01):
[0000833444-24-000029:note_history:12]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. The WDNR issued a further letter regarding the issue on November 4, 2019. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to that date. On April 10, 2023, the WDNR issued a third “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids in the Marinette region. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions, including the potential assessment of penalties.

- changed (2024-05-01):
[0000833444-24-000029:note_history:13]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the
  (was, 2024-01-30, similarity 0.7056):
[0000833444-24-000011:note_history:13]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR's requests. The parties are proceeding with fact discovery and the court has set a trial date of December 3, 2024.

- added (2024-05-01):
[0000833444-24-000029:note_history:14]
FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR's requests. The parties are proceeding with expert discovery and the court has set a trial date of December 3, 2024.

- changed (2024-05-01):
[0000833444-24-000029:note_history:15]
In November 2022, individuals filed six actions in Dane County, Wisconsin alleging personal injury and/or property damage against Tyco Fire Products, Johnson Controls Inc., Chemguard, and other unaffiliated defendants related to environmental matters at the FTC. Plaintiffs allege that use of AFFF products at the FTC and activities by third parties unrelated to the Company contaminated nearby drinking water sources, surface waters, and other natural resources and properties, including their personal properties. The individuals seek monetary damages for their personal injury and/or property damage. These lawsuits have been transferred to the MDL. Subsequently, several additional plaintiffs have direct-filed in the MDL complaints with similar allegations.
  (was, 2024-01-30, similarity 0.9961):
[0000833444-24-000011:note_history:15]
In November 2022, individuals filed six actions in Dane County, Wisconsin alleging personal injury and/or property damage against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and other unaffiliated defendants related to environmental matters at the FTC. Plaintiffs allege that use of AFFF products at the FTC and activities by third parties unrelated to the Company contaminated nearby drinking water sources, surface waters, and other natural resources and properties, including their personal properties. The individuals seek monetary damages for their personal injury and/or property damage. These lawsuits have been transferred to the MDL. Subsequently, several additional plaintiffs have direct-filed in the MDL complaints with similar allegations.

- changed (2024-05-01):
[0000833444-24-000029:note_history:16]
The Company is vigorously defending each of these cases and believes that it has meritorious defenses, but it is presently unable to predict the duration, scope, or outcome of these actions.
  (was, 2024-01-30, similarity 0.8261):
[0000833444-24-000011:note_history:16]
These FTC-related lawsuits are presently at the beginning stages of litigation. The Company is vigorously defending each of these cases and believes that it has meritorious defenses, but it is presently unable to predict the duration, scope, or outcome of these actions.

- changed (2024-05-01):
[0000833444-24-000029:note_history:17]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.
  (was, 2024-01-30, similarity 0.8779):
[0000833444-24-000011:note_history:17]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including

- added (2024-05-01):
[0000833444-24-000029:note_history:18]
Chemguard and Tyco Fire Products have been named as defendants in more than 815 cases in federal and state courts involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 35 states and territories. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard

- added (2024-05-01):
[0000833444-24-000029:note_history:19]
bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation.

- changed (2024-05-01):
[0000833444-24-000029:note_history:20]
Tyco Fire Products and Chemguard are also periodically notified by other municipal entities that those entities may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.
  (was, 2024-01-30, similarity 0.9659):
[0000833444-24-000011:note_history:20]
Tyco and Chemguard are also periodically notified by other municipal entities that those entities may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

- added (2024-05-01):
[0000833444-24-000029:note_history:21]
Water Systems AFFF Settlement Agreement

- added (2024-05-01):
[0000833444-24-000029:note_history:22]
On April 12, 2024, Tyco Fire Products agreed to a settlement with a nationwide class of public water systems that detected PFAS in their drinking water systems that they allege to be associated with the use of AFFF. Under the terms of the agreement, Tyco Fire Products agreed to contribute $750 million to resolve these PFAS claims. The settlement releases these claims against Tyco Fire Products, Chemguard, and other related corporate entities. In connection with the settlement, a charge for $750 million was recorded by the Company in the three months ended March 31, 2024.

- added (2024-05-01):
[0000833444-24-000029:note_history:23]
Tyco Fire Products expects to contribute an initial $250 million on or about May 25, 2024, with the remaining $500 million to be contributed six months after preliminary court approval of the settlement, which is expected to be addressed by the MDL court in or around mid-May, 2024. Tyco Fire Products has a significant amount of insurance through a number of insurers and expects to apply the proceeds recovered under its policies to cover a substantial portion of the total payment, although the specific amount and timing of any insurance recoveries are uncertain.

- added (2024-05-01):
[0000833444-24-000029:note_history:24]
There are still several procedural and legal steps that must occur before the settlement is final and payments are made. The settlement is subject to approval by the MDL court and other contingencies, and that process is expected to take several months.

- added (2024-05-01):
[0000833444-24-000029:note_history:25]
The class of public water systems included in this settlement broadly includes any public water system (as defined in the settlement agreement) that has detected PFAS in its drinking water sources as of May 15, 2024. The following systems are excluded from the settlement class: water systems owned and operated by a State or the United States government; systems that have not detected the presence of PFAS as of May 15, 2024; small transient water systems; privately-owned drinking water wells; and the water system in the city of Marinette, Wisconsin (which is included only if it so requests). The settlement does not resolve claims of public water systems that request exclusion from the class (“opt out”) pursuant to the process to be established by the MDL Court. It also does not resolve potential future claims of public water systems that detect PFAS in their water systems for the first time after May 15, 2024, or certain claims not related to drinking water, such as separate alleged claims relating to real property damage or stormwater or wastewater treatment. Finally, this settlement does not affect the other categories of cases that remain at issue in the MDL, such as personal injury cases, property damage cases, other types of class actions, claims brought by state or territory attorneys general, or other types of damages alleged to be related to the historic use of AFFF manufactured and sold by Tyco Fire Products and Chemguard. While it is reasonably possible that the excluded systems or claims could result in additional future lawsuits, claims, assessments or proceedings, it is not possible to predict the outcome of any such matters, and as such, the Company is unable to develop an estimate of a possible loss or range of losses, if any, at this time.

- added (2024-05-01):
[0000833444-24-000029:note_history:26]
The settlement does not constitute an admission of liability or wrongdoing by Tyco Fire Products or Chemguard. If the MDL court does not approve the agreement or certain terms are not fulfilled, Tyco Fire Products and Chemguard will continue to defend themselves in the litigation.

- added (2024-05-01):
[0000833444-24-000029:note_history:27]
Chemguard and Tyco Fire Products are named in 46 pending putative class actions in federal courts originating from 18 states and territories. All but one of these cases have been direct-filed in or transferred to the MDL. It is anticipated that the remaining state-court action will be similarly tagged and transferred. Tyco Fire Products was also recently named in a class action in British Columbia, Canada.

- changed (2024-05-01):
[0000833444-24-000029:note_history:28]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.
  (was, 2024-01-30, similarity 0.7045):
[0000833444-24-000011:note_history:28]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in

- changed (2024-05-01):
[0000833444-24-000029:note_history:29]
In addition, 32 other states and territories have filed 34 lawsuits against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of each of those State's environmental and natural resources allegedly resulting from the manufacture, storage, sale, distribution, marketing, and use of PFAS-containing AFFF within each respective State. The states and territories are: Arkansas, Arizona, California, Colorado, Connecticut, Delaware, the District of Columbia, Florida, Hawaii, Illinois, Kentucky, Massachusetts, Maryland, Maine, Michigan, Mississippi, New Hampshire, New Jersey, New Mexico, Ohio, Oklahoma, Oregon, Rhode Island, South Carolina, Tennessee, Texas, Vermont, Washington, Wisconsin, Guam, the Northern Mariana Islands, and Puerto Rico. All of these complaints, if not filed directly in the MDL, have been removed to federal court and transferred to the MDL.
  (was, 2024-01-30, similarity 0.8537):
[0000833444-24-000011:note_history:29]
In addition, 31 other states and territories have filed 33 lawsuits against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of each of those State's environmental and natural resources allegedly resulting from the manufacture, storage, sale, distribution, marketing, and use of PFAS-containing AFFF within each respective State. The states and territories are: Arkansas, Arizona, California, Colorado, Connecticut, Delaware, the District of Columbia, Florida, Hawaii, Illinois, Kentucky, Massachusetts, Maryland, Maine, Michigan, Mississippi, New Hampshire, New Jersey, New Mexico, Ohio, Oregon, Rhode Island, South Carolina, Tennessee, Texas, Vermont, Washington, Wisconsin, Guam, the Northern Mariana Islands, and Puerto Rico. All of these complaints, other than Hawaii and Connecticut, have been removed to federal court and transferred to the MDL. The Hawaii complaint has been removed to federal court and it is anticipated that it will be transferred to the MDL. It is anticipated that the Connecticut complaint will be removed to federal court and transferred to the MDL.

- changed (2024-05-01):
[0000833444-24-000029:note_history:30]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. In September 2022, the AFFF MDL Court declined to grant summary judgment on the government contractor defense, ruling that various factual issues relevant to the defense must be decided by a jury rather than the Court. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin and a federal district court in South Carolina. The insurance litigation involves numerous factual and legal issues. There are numerous factual and legal issues to be resolved in connection with these claims. The Company is presently unable to predict the outcome or ultimate financial exposure beyond the water systems AFFF settlement discussed above, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.
  (was, 2024-01-30, similarity 0.8956):
[0000833444-24-000011:note_history:30]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. In September 2022, the AFFF MDL Court declined to grant summary judgment on the government contractor defense, ruling that various factual issues relevant to the defense must be decided by a jury rather than the Court. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin and a federal district court in South Carolina. The insurance litigation involves numerous factual and legal issues and remains at a relatively early stage. There are numerous factual and legal issues to be resolved in connection with these claims. The Company is presently unable to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

- added (2024-05-01):
[0000833444-24-000029:note_history:31]
|  | March 31, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 358 |  |  | 364 |  |
| Total asbestos-related liabilities | 416 |  |  | 422 |  |
| Other current assets | 22 |  |  | 28 |  |
| Other noncurrent assets | 308 |  |  | 273 |  |
| Total asbestos-related assets | 330 |  |  | 301 |  |
| Net asbestos-related liabilities | $ | 86 |  |  | $ | 121 |  |

- added (2024-05-01):
[0000833444-24-000029:note_history:32]
|  | March 31, 2024 |  | September 30, 2023 |
| Restricted |  |  |  |
| Cash | $ | 14 |  |  | $ | 20 |  |
| Investments | 267 |  |  | 231 |  |
| Total restricted assets | 281 |  |  | 251 |  |
| Insurance receivables for asbestos-related liabilities | 49 |  |  | 50 |  |
| Total asbestos-related assets | $ | 330 |  |  | $ | 301 |  |

- changed (2024-05-01):
[0000833444-24-000029:note_history:33]
|  | March 31, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 90 |  |  | $ | 86 |  |
| Accrued compensation and benefits | 23 |  |  | 21 |  |
| Other noncurrent liabilities | 226 |  |  | 226 |  |
| Total self-insured liabilities | $ | 339 |  |  | $ | 333 |  |
  (was, 2024-01-30, similarity 0.9773):
[0000833444-24-000011:note_history:33]
|  | December 31, 2023 |  | September 30, 2023 |
| Other current liabilities | $ | 87 |  |  | $ | 86 |  |
| Accrued compensation and benefits | 22 |  |  | 21 |  |
| Other noncurrent liabilities | 219 |  |  | 226 |  |
| Total self-insured liabilities | $ | 328 |  |  | $ | 333 |  |

- changed (2024-05-01):
[0000833444-24-000029:note_history:34]
|  | March 31, 2024 |  | September 30, 2023 |
| Other current assets | $ | 6 |  |  | $ | 6 |  |
| Other noncurrent assets | 14 |  |  | 14 |  |
| Total insurance receivables | $ | 20 |  |  | $ | 20 |  |
  (was, 2024-01-30, similarity 0.9746):
[0000833444-24-000011:note_history:34]
|  | December 31, 2023 |  | September 30, 2023 |
| Other current assets | $ | 6 |  |  | $ | 6 |  |
| Other noncurrent assets | 14 |  |  | 14 |  |
| Total insurance receivables | $ | 20 |  |  | $ | 20 |  |

- removed (2024-05-01):
[0000833444-24-000011:note_history:35]
remediation actions, including the continued operation of the GETS, the implementation of long-term drinking water solutions for the area impacted by groundwater migrating from the FTC, continued monitoring and testing of groundwater monitoring wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

- removed (2024-05-01):
[0000833444-24-000011:note_history:36]
PFOA, PFOS, and other PFAS compounds are being studied by EPA and other environmental and health agencies and researchers. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. In March 2023, EPA announced a proposed National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR proposes establishing legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion for each of PFOA and PFOS. The EPA has stated that it intends to propose two rules relating to PFAS under the Resource Conservation and Recovery Act (“RCRA”): one rule would list four PFAS (PFOA, PFOS, PFBS, and GenX) as “hazardous constituents,” and a second rule would clarify that hazardous constituents are subject to RCRA's corrective action program.

- removed (2024-05-01):
[0000833444-24-000011:note_history:37]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and

- removed (2024-05-01):
[0000833444-24-000011:note_history:38]
spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. The WDNR issued a further letter regarding the issue on November 4, 2019. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to that date. On April 10, 2023, the WDNR issued a third “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids in the Marinette region. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions, including the potential assessment of penalties.

- removed (2024-05-01):
[0000833444-24-000011:note_history:39]
damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

- removed (2024-05-01):
[0000833444-24-000011:note_history:40]
Chemguard and Tyco Fire Products are named in 44 pending putative class actions in federal courts originating from 16 states and territories. All of these cases have been direct-filed in or transferred to the MDL. Tyco Fire Products was also recently named in a class action in British Columbia, Canada.

- removed (2024-05-01):
[0000833444-24-000011:note_history:41]
Chemguard and Tyco Fire Products have been named as defendants in more than 770 cases in federal and state courts involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 35 states and territories. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation. The MDL court set the first case for trial on June 5, 2023 (City of Stuart (Florida) v. 3M Co. et al.). On April 26, 2023, the parties entered a stipulation dismissing Chemguard with prejudice from the City of Stuart case, and on May 4, 2023 the parties entered into a stipulation dismissing Tyco with prejudice from the City of Stuart case. On June 5, 2023, the MDL court continued the trial date for the City of Stuart case, and the parties remaining in that case later reached settlement. The parties in the MDL designated four additional plaintiffs as water provider bellwether cases and conducted initial discovery into those cases. On December 19, 2023, the MDL court selected two of those cases to proceed into additional discovery. The parties have also identified 25 personal injury bellwether cases, which have entered into the first phase of bellwether discovery.

- removed (2024-05-01):
[0000833444-24-000011:note_history:42]
Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

- removed (2024-05-01):
[0000833444-24-000011:note_history:43]
|  | December 31, 2023 |  | September 30, 2023 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 359 |  |  | 364 |  |
| Total asbestos-related liabilities | 417 |  |  | 422 |  |
| Other current assets | 27 |  |  | 28 |  |
| Other noncurrent assets | 294 |  |  | 273 |  |
| Total asbestos-related assets | 321 |  |  | 301 |  |
| Net asbestos-related liabilities | $ | 96 |  |  | $ | 121 |  |

- removed (2024-05-01):
[0000833444-24-000011:note_history:44]
|  | December 31, 2023 |  | September 30, 2023 |
| Restricted |  |  |  |
| Cash | $ | 19 |  |  | $ | 20 |  |
| Investments | 252 |  |  | 231 |  |
| Total restricted assets | 271 |  |  | 251 |  |
| Insurance receivables for asbestos-related liabilities | 50 |  |  | 50 |  |
| Total asbestos-related assets | $ | 321 |  |  | $ | 301 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-05-01):
[0000833444-24-000029:note_history:45]
|  | March 31, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 28 |  |  | $ | 31 |  |
| Other noncurrent liabilities | 194 |  |  | 211 |  |
| Total reserves for environmental liabilities | $ | 222 |  |  | $ | 242 |  |
  (was, 2024-01-30, similarity 0.9731):
[0000833444-24-000011:note_history:45]
|  | December 31, 2023 |  | September 30, 2023 |
| Other current liabilities | $ | 31 |  |  | $ | 31 |  |
| Other noncurrent liabilities | 201 |  |  | 211 |  |
| Total reserves for environmental liabilities | $ | 232 |  |  | $ | 242 |  |

- added (2024-05-01):
[0000833444-24-000029:note_history:46]
|  | March 31, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 358 |  |  | 364 |  |
| Total asbestos-related liabilities | 416 |  |  | 422 |  |
| Other current assets | 22 |  |  | 28 |  |
| Other noncurrent assets | 308 |  |  | 273 |  |
| Total asbestos-related assets | 330 |  |  | 301 |  |
| Net asbestos-related liabilities | $ | 86 |  |  | $ | 121 |  |

- added (2024-05-01):
[0000833444-24-000029:note_history:47]
|  | March 31, 2024 |  | September 30, 2023 |
| Restricted |  |  |  |
| Cash | $ | 14 |  |  | $ | 20 |  |
| Investments | 267 |  |  | 231 |  |
| Total restricted assets | 281 |  |  | 251 |  |
| Insurance receivables for asbestos-related liabilities | 49 |  |  | 50 |  |
| Total asbestos-related assets | $ | 330 |  |  | $ | 301 |  |

- changed (2024-05-01):
[0000833444-24-000029:note_history:48]
|  | March 31, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 90 |  |  | $ | 86 |  |
| Accrued compensation and benefits | 23 |  |  | 21 |  |
| Other noncurrent liabilities | 226 |  |  | 226 |  |
| Total self-insured liabilities | $ | 339 |  |  | $ | 333 |  |
  (was, 2024-01-30, similarity 0.9773):
[0000833444-24-000011:note_history:48]
|  | December 31, 2023 |  | September 30, 2023 |
| Other current liabilities | $ | 87 |  |  | $ | 86 |  |
| Accrued compensation and benefits | 22 |  |  | 21 |  |
| Other noncurrent liabilities | 219 |  |  | 226 |  |
| Total self-insured liabilities | $ | 328 |  |  | $ | 333 |  |

- changed (2024-05-01):
[0000833444-24-000029:note_history:49]
|  | March 31, 2024 |  | September 30, 2023 |
| Other current assets | $ | 6 |  |  | $ | 6 |  |
| Other noncurrent assets | 14 |  |  | 14 |  |
| Total insurance receivables | $ | 20 |  |  | $ | 20 |  |
  (was, 2024-01-30, similarity 0.9746):
[0000833444-24-000011:note_history:49]
|  | December 31, 2023 |  | September 30, 2023 |
| Other current assets | $ | 6 |  |  | $ | 6 |  |
| Other noncurrent assets | 14 |  |  | 14 |  |
| Total insurance receivables | $ | 20 |  |  | $ | 20 |  |

- removed (2024-05-01):
[0000833444-24-000011:note_history:50]
|  | December 31, 2023 |  | September 30, 2023 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 359 |  |  | 364 |  |
| Total asbestos-related liabilities | 417 |  |  | 422 |  |
| Other current assets | 27 |  |  | 28 |  |
| Other noncurrent assets | 294 |  |  | 273 |  |
| Total asbestos-related assets | 321 |  |  | 301 |  |
| Net asbestos-related liabilities | $ | 96 |  |  | $ | 121 |  |

- removed (2024-05-01):
[0000833444-24-000011:note_history:51]
|  | December 31, 2023 |  | September 30, 2023 |
| Restricted |  |  |  |
| Cash | $ | 19 |  |  | $ | 20 |  |
| Investments | 252 |  |  | 231 |  |
| Total restricted assets | 271 |  |  | 251 |  |
| Insurance receivables for asbestos-related liabilities | 50 |  |  | 50 |  |
| Total asbestos-related assets | $ | 321 |  |  | $ | 301 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-05-01):
[0000833444-24-000029:note_history:52]
BASIS OF PRESENTATION
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2023 filed with the SEC on December 14, 2023. The results of operations for the three and six month periods ended March 31, 2024 are not necessarily indicative of results for the Company’s 2024 fiscal year because of seasonal and other factors.
  (was, 2024-01-30, similarity 0.9773):
[0000833444-24-000011:note_history:52]
BASIS OF PRESENTATION
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company," or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2023 filed with the SEC on December 14, 2023. The results of operations for the three-month period ended December 31, 2023 are not necessarily indicative of results for the Company’s 2024 fiscal year because of seasonal and other factors.

- removed (2024-05-01):
[0000833444-24-000011:note_history:53]
Prior Period Revision – Statement of Cash Flows

- removed (2024-05-01):
[0000833444-24-000011:note_history:54]
The Company revised the amounts previously reported as net proceeds from borrowings with maturities less than three months and proceeds from debt for certain short-term debt transactions that were incorrectly presented on a net basis within the financing activities section of the consolidated statements of cash flows for the three months ended December 30, 2022. 
The revision did not change cash provided by financing activities or the total decrease in cash, cash equivalents and restricted cash. The Company does not believe the impact of the incorrect presentation was material.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-05-01):
[0000833444-24-000029:note_history:55]
|  | March 31, |  | September 30, |
|  | 2024 |  | 2023 |
| Commercial paper | $ | 1,784 |  |  | $ | 200 |  |
| Term loans | 424 |  |  | 159 |  |
| Bank borrowings | 2 |  |  | 26 |  |
|  | $ | 2,210 |  |  | $ | 385 |  |
| Weighted average interest rate on short-term debt outstanding | 4.7 | % |  | 5.1 | % |

- changed (2024-05-01):
[0000833444-24-000029:note_history:56]
As of March 31, 2024, the Company had syndicated committed revolving credit facilities of $2.5 billion which is scheduled to expire in December 2028 and $500 million which is scheduled to expire in December 2024. There were no draws on the facilities as of March 31, 2024.
  (was, 2024-01-30, similarity 0.9325):
[0000833444-24-000011:note_history:56]
As of December 31, 2023, the Company had syndicated committed revolving credit facilities of $2.5 billion which is scheduled to expire in December 2028 and $500 million which is scheduled to expire in December 2024. There were no draws on the facilities as of December 31, 2023.

- added (2024-05-01):
[0000833444-24-000029:note_history:57]
In April 2024, the Company and its wholly-owned subsidiary, Tyco Fire & Security Finance S.C.A, co-issued $700 million unsecured, unsubordinated senior notes with an interest rate of 5.50% which is due April 2029.

- removed (2024-05-01):
[0000833444-24-000011:note_history:58]
|  | December 31, |  | September 30, |
|  | 2023 |  | 2023 |
| Commercial paper | $ | 1,383 |  |  | $ | 200 |  |
| Term loans | 598 |  |  | 159 |  |
| Bank borrowings | 17 |  |  | 26 |  |
|  | $ | 1,998 |  |  | $ | 385 |  |
| Weighted average interest rate on short-term debt outstanding | 4.4 | % |  | 5.1 | % |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-01):
[0000833444-24-000029:note_history:59]
The fair value of long-term debt at March 31, 2024 and September 30, 2023 was as follows (in billions):
  (was, 2024-01-30, similarity 0.9524):
[0000833444-24-000011:note_history:59]
The fair value of long-term debt at December 31, 2023 and September 30, 2023 was as follows (in billions):

- changed (2024-05-01):
[0000833444-24-000029:note_history:60]
|  |  | March 31, |  | September 30, |  |
|  | 2024 |  | 2023 |  |
| Public debt |  | $ | 7.6 |  |  | $ | 7.1 |  |  |
| Other long-term debt |  | 0.4 |  |  | 0.4 |  |  |
| Total fair value of long-term debt |  | $ | 8.0 |  |  | $ | 7.5 |  |  |
  (was, 2024-01-30, similarity 0.9726):
[0000833444-24-000011:note_history:60]
|  |  | December 31, |  | September 30, |  |
|  | 2023 |  | 2023 |  |
| Public debt |  | $ | 7.8 |  |  | $ | 7.1 |  |  |
| Other long-term debt |  | 0.4 |  |  | 0.4 |  |  |
| Total fair value of long-term debt |  | $ | 8.2 |  |  | $ | 7.5 |  |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-05-01):
[0000833444-24-000029:note_history:61]
|  | March 31, |  | September 30, |
|  | 2024 |  | 2023 |
| Commercial paper | $ | 1,784 |  |  | $ | 200 |  |
| Term loans | 424 |  |  | 159 |  |
| Bank borrowings | 2 |  |  | 26 |  |
|  | $ | 2,210 |  |  | $ | 385 |  |
| Weighted average interest rate on short-term debt outstanding | 4.7 | % |  | 5.1 | % |

- removed (2024-05-01):
[0000833444-24-000011:note_history:62]
|  | December 31, |  | September 30, |
|  | 2023 |  | 2023 |
| Commercial paper | $ | 1,383 |  |  | $ | 200 |  |
| Term loans | 598 |  |  | 159 |  |
| Bank borrowings | 17 |  |  | 26 |  |
|  | $ | 1,998 |  |  | $ | 385 |  |
| Weighted average interest rate on short-term debt outstanding | 4.4 | % |  | 5.1 | % |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-05-01):
[0000833444-24-000029:note_history:63]
|  |  | Three Months Ended March 31, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,700 |  |  | $ | 1,039 |  |  | $ | 2,739 |  |  | $ | 1,554 |  |  | $ | 966 |  |  | $ | 2,520 |  |
| Building Solutions EMEA/LA |  | 572 |  |  | 492 |  |  | 1,064 |  |  | 582 |  |  | 449 |  |  | 1,031 |  |
| Building Solutions Asia Pacific |  | 308 |  |  | 183 |  |  | 491 |  |  | 479 |  |  | 188 |  |  | 667 |  |
| Global Products |  | 2,405 |  |  | — |  |  | 2,405 |  |  | 2,468 |  |  | — |  |  | 2,468 |  |
| Total |  | $ | 4,985 |  |  | $ | 1,714 |  |  | $ | 6,699 |  |  | $ | 5,083 |  |  | $ | 1,603 |  |  | $ | 6,686 |  |

- added (2024-05-01):
[0000833444-24-000029:note_history:64]
|  |  | Six Months Ended March 31, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,218 |  |  | $ | 2,008 |  |  | $ | 5,226 |  |  | $ | 3,005 |  |  | $ | 1,882 |  |  | $ | 4,887 |  |
| Building Solutions EMEA/LA |  | 1,144 |  |  | 958 |  |  | 2,102 |  |  | 1,134 |  |  | 872 |  |  | 2,006 |  |
| Building Solutions Asia Pacific |  | 645 |  |  | 353 |  |  | 998 |  |  | 952 |  |  | 361 |  |  | 1,313 |  |
| Global Products |  | 4,467 |  |  | — |  |  | 4,467 |  |  | 4,548 |  |  | — |  |  | 4,548 |  |
| Total |  | $ | 9,474 |  |  | $ | 3,319 |  |  | $ | 12,793 |  |  | $ | 9,639 |  |  | $ | 3,115 |  |  | $ | 12,754 |  |

- changed (2024-05-01):
[0000833444-24-000029:note_history:65]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC |  | $ | 1,683 |  |  | $ | 1,757 |  |  | $ | 3,101 |  |  | $ | 3,197 |  |
| Fire & Security |  | 607 |  |  | 623 |  |  | 1,154 |  |  | 1,193 |  |
| Industrial Refrigeration |  | 115 |  |  | 88 |  |  | 212 |  |  | 158 |  |
| Total |  | $ | 2,405 |  |  | $ | 2,468 |  |  | $ | 4,467 |  |  | $ | 4,548 |  |
  (was, 2024-01-30, similarity 0.7092):
[0000833444-24-000011:note_history:65]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| HVAC |  | $ | 1,418 |  |  | $ | 1,440 |  |  |  |  |  |
| Fire & Security |  | 547 |  |  | 570 |  |  |  |  |  |
| Industrial Refrigeration |  | 97 |  |  | 70 |  |  |  |  |  |
| Total |  | $ | 2,062 |  |  | $ | 2,080 |  |  |  |  |  |

- removed (2024-05-01):
[0000833444-24-000011:note_history:66]
|  |  | Three Months Ended December 31, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,518 |  |  | $ | 969 |  |  | $ | 2,487 |  |  | $ | 1,451 |  |  | $ | 916 |  |  | $ | 2,367 |  |
| Building Solutions EMEA/LA |  | 572 |  |  | 466 |  |  | 1,038 |  |  | 552 |  |  | 423 |  |  | 975 |  |
| Building Solutions Asia Pacific |  | 337 |  |  | 170 |  |  | 507 |  |  | 473 |  |  | 173 |  |  | 646 |  |
| Global Products |  | 2,062 |  |  | — |  |  | 2,062 |  |  | 2,080 |  |  | — |  |  | 2,080 |  |
| Total |  | $ | 4,489 |  |  | $ | 1,605 |  |  | $ | 6,094 |  |  | $ | 4,556 |  |  | $ | 1,512 |  |  | $ | 6,068 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-01):
[0000833444-24-000029:note_history:67]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of March 31, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $21.2 billion, of which approximately 66% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.
  (was, 2024-01-30, similarity 0.9935):
[0000833444-24-000011:note_history:67]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of December 31, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $19.9 billion, of which approximately 64% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-05-01):
[0000833444-24-000029:note_history:68]
|  |  | Three Months Ended March 31, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,700 |  |  | $ | 1,039 |  |  | $ | 2,739 |  |  | $ | 1,554 |  |  | $ | 966 |  |  | $ | 2,520 |  |
| Building Solutions EMEA/LA |  | 572 |  |  | 492 |  |  | 1,064 |  |  | 582 |  |  | 449 |  |  | 1,031 |  |
| Building Solutions Asia Pacific |  | 308 |  |  | 183 |  |  | 491 |  |  | 479 |  |  | 188 |  |  | 667 |  |
| Global Products |  | 2,405 |  |  | — |  |  | 2,405 |  |  | 2,468 |  |  | — |  |  | 2,468 |  |
| Total |  | $ | 4,985 |  |  | $ | 1,714 |  |  | $ | 6,699 |  |  | $ | 5,083 |  |  | $ | 1,603 |  |  | $ | 6,686 |  |

- added (2024-05-01):
[0000833444-24-000029:note_history:69]
|  |  | Six Months Ended March 31, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,218 |  |  | $ | 2,008 |  |  | $ | 5,226 |  |  | $ | 3,005 |  |  | $ | 1,882 |  |  | $ | 4,887 |  |
| Building Solutions EMEA/LA |  | 1,144 |  |  | 958 |  |  | 2,102 |  |  | 1,134 |  |  | 872 |  |  | 2,006 |  |
| Building Solutions Asia Pacific |  | 645 |  |  | 353 |  |  | 998 |  |  | 952 |  |  | 361 |  |  | 1,313 |  |
| Global Products |  | 4,467 |  |  | — |  |  | 4,467 |  |  | 4,548 |  |  | — |  |  | 4,548 |  |
| Total |  | $ | 9,474 |  |  | $ | 3,319 |  |  | $ | 12,793 |  |  | $ | 9,639 |  |  | $ | 3,115 |  |  | $ | 12,754 |  |

- changed (2024-05-01):
[0000833444-24-000029:note_history:70]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC |  | $ | 1,683 |  |  | $ | 1,757 |  |  | $ | 3,101 |  |  | $ | 3,197 |  |
| Fire & Security |  | 607 |  |  | 623 |  |  | 1,154 |  |  | 1,193 |  |
| Industrial Refrigeration |  | 115 |  |  | 88 |  |  | 212 |  |  | 158 |  |
| Total |  | $ | 2,405 |  |  | $ | 2,468 |  |  | $ | 4,467 |  |  | $ | 4,548 |  |
  (was, 2024-01-30, similarity 0.7092):
[0000833444-24-000011:note_history:70]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| HVAC |  | $ | 1,418 |  |  | $ | 1,440 |  |  |  |  |  |
| Fire & Security |  | 547 |  |  | 570 |  |  |  |  |  |
| Industrial Refrigeration |  | 97 |  |  | 70 |  |  |  |  |  |
| Total |  | $ | 2,062 |  |  | $ | 2,080 |  |  |  |  |  |

- added (2024-05-01):
[0000833444-24-000029:note_history:71]
|  |  | Location of contract balances |  | March 31, 2024 |  | September 30, 2023 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,063 |  |  | $ | 2,370 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 5 |  |  | 12 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,331 |  |  | 1,996 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 310 |  |  | 297 |  |  |  |

- added (2024-05-01):
[0000833444-24-000029:note_history:72]
For the three months ended March 31, 2024 and 2023, the Company recognized revenue of $372 million and $319 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year. For the six months ended March 31, 2024 and 2023, the Company recognized revenue of $1,261 million and $1,165 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year.

- changed (2024-05-01):
[0000833444-24-000029:note_history:73]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of March 31, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $21.2 billion, of which approximately 66% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.
  (was, 2024-01-30, similarity 0.9935):
[0000833444-24-000011:note_history:73]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of December 31, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $19.9 billion, of which approximately 64% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.

- changed (2024-05-01):
[0000833444-24-000029:note_history:74]
|  |  | March 31, 2024 |  | September 30, 2023 |  |  |
| Other current assets |  | $ | 204 |  |  | $ | 156 |  |  |  |
| Other noncurrent assets |  | 263 |  |  | 224 |  |  |  |
| Total |  | $ | 467 |  |  | $ | 380 |  |  |  |
  (was, 2024-01-30, similarity 0.9749):
[0000833444-24-000011:note_history:74]
|  |  | December 31, 2023 |  | September 30, 2023 |  |  |
| Other current assets |  | $ | 183 |  |  | $ | 156 |  |  |  |
| Other noncurrent assets |  | 215 |  |  | 224 |  |  |  |
| Total |  | $ | 398 |  |  | $ | 380 |  |  |  |

- added (2024-05-01):
[0000833444-24-000029:note_history:75]
During the three months ended March 31, 2024 and 2023, the Company recognized amortization expense of $77 million and $61 million, respectively, related to costs to obtain or fulfill a contract. During the six months ended March 31, 2024 and 2023, the Company recognized amortization expense of $134 million and $122 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and six months ended March 31, 2024 and 2023.

- removed (2024-05-01):
[0000833444-24-000011:note_history:76]
|  |  | Three Months Ended December 31, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,518 |  |  | $ | 969 |  |  | $ | 2,487 |  |  | $ | 1,451 |  |  | $ | 916 |  |  | $ | 2,367 |  |
| Building Solutions EMEA/LA |  | 572 |  |  | 466 |  |  | 1,038 |  |  | 552 |  |  | 423 |  |  | 975 |  |
| Building Solutions Asia Pacific |  | 337 |  |  | 170 |  |  | 507 |  |  | 473 |  |  | 173 |  |  | 646 |  |
| Global Products |  | 2,062 |  |  | — |  |  | 2,062 |  |  | 2,080 |  |  | — |  |  | 2,080 |  |
| Total |  | $ | 4,489 |  |  | $ | 1,605 |  |  | $ | 6,094 |  |  | $ | 4,556 |  |  | $ | 1,512 |  |  | $ | 6,068 |  |

- removed (2024-05-01):
[0000833444-24-000011:note_history:77]
|  |  | Location of contract balances |  | December 31, 2023 |  | September 30, 2023 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,170 |  |  | $ | 2,370 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 4 |  |  | 12 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,122 |  |  | 1,996 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 306 |  |  | 297 |  |  |  |

- removed (2024-05-01):
[0000833444-24-000011:note_history:78]
For the three months ended December 31, 2023 and 2022, the Company recognized revenue of $889 million and $846 million, respectively, that was included in the beginning of period contract liability balance.

- removed (2024-05-01):
[0000833444-24-000011:note_history:79]
During the three months ended December 31, 2023 and 2022, the Company recognized amortization expense of $57 million and $61 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three months ended December 31, 2023 and 2022.
