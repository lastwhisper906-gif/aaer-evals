# JCI 8-K — 0000833444-24-000026 filed 2024-05-01

## item codes, every 8-K on or before 2024-05-01

- 2024-05-01 0000833444-24-000026 — 2.02, 9.01
- 2024-04-19 0001193125-24-102867 — 8.01, 9.01
- 2024-04-12 0000833444-24-000023 — 1.01, 8.01, 9.01
- 2024-03-18 0000833444-24-000020 — 5.07
- 2024-01-30 0000833444-24-000007 — 2.02, 9.01
- 2024-01-16 0000833444-24-000004 — 5.02, 9.01
- 2023-12-12 0000833444-23-000044 — 2.02, 9.01
- 2023-12-08 0000833444-23-000042 — 5.02
- 2023-11-13 0000833444-23-000038 — 8.01
- 2023-09-27 0000833444-23-000036 — 8.01
- 2023-09-08 0000833444-23-000033 — 5.02
- 2023-08-21 0001193125-23-217018 — 8.01, 9.01
- 2023-08-07 0001193125-23-205014 — 8.01, 9.01
- 2023-08-02 0000833444-23-000028 — 2.02, 9.01
- 2023-05-23 0001193125-23-151889 — 8.01, 9.01
- 2023-05-05 0000833444-23-000011 — 2.02, 9.01
- 2023-03-14 0000833444-23-000007 — 5.07
- 2023-02-01 0000833444-23-000003 — 2.02, 9.01
- 2022-12-22 0000833444-22-000047 — 5.02
- 2022-12-09 0000833444-22-000045 — 5.02
- 2022-11-03 0000833444-22-000038 — 2.02, 9.01
- 2022-09-14 0001193125-22-244741 — 8.01, 9.01
- 2022-09-07 0001193125-22-240030 — 8.01, 9.01
- 2022-08-04 0000833444-22-000034 — 2.02, 9.01
- 2022-07-06 0000833444-22-000029 — 5.02, 9.01
- 2022-06-30 0000833444-22-000027 — 5.02
- 2022-05-04 0000833444-22-000014 — 2.02, 9.01
- 2022-03-11 0001193125-22-073382 — 5.07
- 2022-02-15 0000833444-22-000010 — 5.02
- 2022-02-02 0000833444-22-000003 — 2.02, 9.01
- 2021-12-10 0000833444-21-000050 — 5.02
- 2021-11-05 0000833444-21-000043 — 2.02, 9.01
- 2021-09-16 0001193125-21-275152 — 1.01, 8.01, 9.01
- 2021-07-30 0000833444-21-000038 — 2.02, 9.01
- 2021-05-03 0000833444-21-000023 — 8.01
- 2021-04-30 0000833444-21-000017 — 2.02, 9.01
- 2021-03-11 0000833444-21-000013 — 5.02, 5.07, 9.01
- 2021-02-17 0001193125-21-045768 — 7.01, 9.01
- 2021-01-29 0000833444-21-000009 — 2.02, 9.01
- 2021-01-07 0000833444-21-000004 — 7.01
- 2020-11-03 0000833444-20-000043 — 2.02, 9.01
- 2020-09-15 0001193125-20-246240 — 1.01, 8.01, 9.01
- 2020-09-11 0001193125-20-244119 — 1.01, 8.01, 9.01
- 2020-08-18 0000833444-20-000038 — 5.02, 9.01
- 2020-07-31 0000833444-20-000034 — 2.02, 9.01
- 2020-06-12 0000833444-20-000020 — 8.01
- 2020-05-01 0000833444-20-000013 — 2.02, 9.01
- 2020-03-12 0000833444-20-000010 — 5.02
- 2020-03-06 0000833444-20-000008 — 5.07
- 2020-01-31 0000833444-20-000003 — 2.02, 9.01
- 2019-12-06 0001193125-19-308301 — 1.01, 1.02, 2.03, 9.01
- 2019-11-07 0000833444-19-000048 — 5.02, 9.01
- 2019-11-07 0000833444-19-000046 — 2.02, 9.01
- 2019-08-21 0000833444-19-000043 — 8.01
- 2019-07-31 0000833444-19-000038 — 2.02, 9.01
- 2019-07-23 0000833444-19-000035 — 5.02, 8.01, 9.01
- 2019-07-02 0000833444-19-000033 — 1.02, 8.01
- 2019-06-05 0001193125-19-165565 — 8.01
- 2019-05-30 0001193125-19-160205 — 8.01, 9.01
- 2019-05-16 0001193125-19-148262 — 8.01, 9.01
- 2019-05-07 0001193125-19-139826 — 5.04, 9.01
- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2024-05-01

- 2023-11-29 0000833444-23-000040 — NT 10-K, for the period ended 2023-09-30
- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-24-000026:8k_2_02:1]
EX-99.1
2
q2exh991xq2fy24earningsrel.htm
EX-99.1

[0000833444-24-000026:8k_2_02:2]
Document

[0000833444-24-000026:8k_2_02:3]
Exhibit 99.1

[0000833444-24-000026:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-24-000026:8k_2_02:5]
Johnson Controls Reports Solid Q2 Results; Maintains FY24 Guidance

[0000833444-24-000026:8k_2_02:6]
________________________________________________________________________________

[0000833444-24-000026:8k_2_02:7]
▪Q2 reported sales were flat versus prior year and increased 1% organically

[0000833444-24-000026:8k_2_02:8]
▪Q2 GAAP EPS of $(0.41); Q2 Adjusted EPS of $0.78

[0000833444-24-000026:8k_2_02:9]
▪Q2 Orders +12% organically year-over-year

[0000833444-24-000026:8k_2_02:10]
▪Building Solutions backlog of $12.6 billion increased 10% organically year-over-year

[0000833444-24-000026:8k_2_02:11]
▪Initiates fiscal Q3 and maintains full year fiscal 2024 guidance

[0000833444-24-000026:8k_2_02:12]
______________________________________________________________________________

[0000833444-24-000026:8k_2_02:13]
CORK, Ireland — May 1, 2024 — Johnson Controls International plc (NYSE: JCI), a global leader for smart, healthy and sustainable buildings, today reported fiscal second quarter 2024 GAAP earnings per share (“EPS”) of $(0.41). Excluding special items, adjusted EPS was $0.78 (see attached footnotes for non-GAAP reconciliation).

[0000833444-24-000026:8k_2_02:14]
Sales in the quarter of $6.7 billion were flat compared to the prior year on an as reported basis and increased 1% organically. GAAP net loss was $(277) million. Adjusted net income was $533 million.

[0000833444-24-000026:8k_2_02:15]
“We are proud of the work underway at Johnson Controls as we delivered another successful quarter, underscored by accelerating sales growth and margin expansion,” said George Oliver, Chairman and CEO. “We made great progress this quarter in further strengthening our balance sheet. Our record backlog provides visibility into the remainder of the fiscal year and we remain confident in our ability to deliver on our financial and operational commitments as we continue our transformation into a comprehensive solutions provider for commercial buildings.”

[0000833444-24-000026:8k_2_02:16]
1

[0000833444-24-000026:8k_2_02:17]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-24-000026:8k_2_02:18]
($ millions, except per-share amounts)

[0000833444-24-000026:8k_2_02:19]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the fiscal second quarter of 2023.

[0000833444-24-000026:8k_2_02:20]
Organic sales growth, adjusted segment EBITA, adjusted segment EBITA margin, adjusted corporate expense, adjusted net income, adjusted EPS, and adjusted free cash flow are non-GAAP financial measures. For a reconciliation of non-GAAP measures and detail of the special items, refer to the attached footnotes.

[0000833444-24-000026:8k_2_02:21]
This press release includes forward-looking statements regarding organic revenue growth, adjusted segment EBITA margin improvement and adjusted EPS, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as mark-to-market adjustments. Organic revenue growth excludes the effect of acquisitions, divestitures and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s fiscal 2024 third quarter and full year GAAP financial results.

[0000833444-24-000026:8k_2_02:22]
A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-24-000026:8k_2_02:23]
2

[0000833444-24-000026:8k_2_02:24]
FISCAL Q2 SEGMENT RESULTS

[0000833444-24-000026:8k_2_02:25]
Building Solutions North America

[0000833444-24-000026:8k_2_02:26]
|  |  | Fiscal Q2 |  |  |  |  |  |
|  |  | 2024 |  | 2023 |  | Change |  |  |  |  |  |
| Sales |  | $ | 2,739 |  |  | $ | 2,520 |  |  | 9 | % |  |  |  |  |  |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 373 |  |  | 315 |  |  | 18 | % |  |  |  |  |  |
| Adjusted |  | 373 |  |  | 315 |  |  | 18 | % |  |  |  |  |  |
| Segment EBITA Margin % |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 13.6 | % |  | 12.5 | % |  | 110 | bp |  |  |  |  |  |
| Adjusted |  | 13.6 | % |  | 12.5 | % |  | 110 | bp |  |  |  |  |  |

[0000833444-24-000026:8k_2_02:27]
Sales in the quarter of $2.7 billion increased 9% over the prior year. Organic sales increased 8% over the prior year led by high-teens growth in Applied HVAC & Controls.

[0000833444-24-000026:8k_2_02:28]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 19% year-over-year. Backlog at the end of the quarter of $8.9 billion increased 15% compared to the prior year, excluding M&A and adjusted for foreign currency.

[0000833444-24-000026:8k_2_02:29]
Segment EBITA margin of 13.6% expanded 110 basis points versus the prior year led by higher margin backlog conversion and continued growth in Services.

[0000833444-24-000026:8k_2_02:30]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-24-000026:8k_2_02:31]
|  |  | Fiscal Q2 |  |  |  |  |  |
|  |  | 2024 |  | 2023 |  | Change |  |  |  |  |  |
| Sales |  | $ | 1,064 |  |  | $ | 1,031 |  |  | 3 | % |  |  |  |  |  |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 89 |  |  | 69 |  |  | 29 | % |  |  |  |  |  |
| Adjusted |  | 89 |  |  | 69 |  |  | 29 | % |  |  |  |  |  |
| Segment EBITA Margin % |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 8.4 | % |  | 6.7 | % |  | 170 | bp |  |  |  |  |  |
| Adjusted |  | 8.4 | % |  | 6.7 | % |  | 170 | bp |  |  |  |  |  |

[0000833444-24-000026:8k_2_02:32]
Sales in the quarter of $1.1 billion increased 3% over the prior year. Organic sales grew 4% versus the prior year led by strong low-teen growth in Service.

[0000833444-24-000026:8k_2_02:33]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 8% year-over-year. Backlog at the end of the quarter of $2.4 billion increased 10% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-24-000026:8k_2_02:34]
Segment EBITA margin of 8.4% expanded 170 basis points versus the prior year led by productivity benefits and positive Service mix.

[0000833444-24-000026:8k_2_02:35]
3

[0000833444-24-000026:8k_2_02:36]
Building Solutions Asia Pacific

[0000833444-24-000026:8k_2_02:37]
|  |  | Fiscal Q2 |  |  |  |  |  |
|  |  | 2024 |  | 2023 |  | Change |  |  |  |  |  |
| Sales |  | $ | 491 |  |  | $ | 667 |  |  | (26 | %) |  |  |  |  |  |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 54 |  |  | 79 |  |  | (32 | %) |  |  |  |  |  |
| Adjusted |  | 54 |  |  | 79 |  |  | (32 | %) |  |  |  |  |  |
| Segment EBITA Margin % |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 11.0 | % |  | 11.8 | % |  | (80 | bp) |  |  |  |  |  |
| Adjusted |  | 11.0 | % |  | 11.8 | % |  | (80 | bp) |  |  |  |  |  |

[0000833444-24-000026:8k_2_02:38]
Sales in the quarter of $491 million declined 26% versus the prior year. Organic sales declined 23% versus the prior year as high single-digit Service growth was more than offset by continued weakness in China.

[0000833444-24-000026:8k_2_02:39]
Orders in the quarter, excluding M&A and adjusted for foreign currency, declined 9% year-over-year. Backlog at the end of the quarter of $1.3 billion decreased 18% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-24-000026:8k_2_02:40]
Segment EBITA margin of 11.0% declined 80 basis points versus the prior year primarily related to continued declines in the Systems business in China.

[0000833444-24-000026:8k_2_02:41]
Global Products

[0000833444-24-000026:8k_2_02:42]
|  |  | Fiscal Q2 |  |  |  |  |  |
|  |  | 2024 |  | 2023 |  | Change |  |  |  |  |  |
| Sales |  | $ | 2,405 |  |  | $ | 2,468 |  |  | (3 | %) |  |  |  |  |  |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 429 |  |  | 488 |  |  | (12 | %) |  |  |  |  |  |
| Adjusted |  | 455 |  |  | 458 |  |  | (1 | %) |  |  |  |  |  |
| Segment EBITA Margin % |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 17.8 | % |  | 19.8 | % |  | (200 | bp) |  |  |  |  |  |
| Adjusted |  | 18.9 | % |  | 18.6 | % |  | 30 | bp |  |  |  |  |  |

[0000833444-24-000026:8k_2_02:43]
Sales in the quarter of $2.4 billion declined 3% versus the prior year. Organic sales were down 1% versus the prior year as growth in Commercial HVAC was offset by declines in global Residential HVAC and Fire & Security.

[0000833444-24-000026:8k_2_02:44]
Segment EBITA margin of 17.8% declined 200 basis points versus the prior year primarily due to unfavorable mix, a charge related to a product quality issue, and the favorable prior year impact of an acquisition earn-out liability. Adjusted segment EBITA excludes costs for a product quality issue, partially offset by a favorable earn-out liability adjustment in Q2 2024. Adjusted segment EBITA excludes a favorable earn-out liability adjustment in Q2 2023.

[0000833444-24-000026:8k_2_02:45]
4

[0000833444-24-000026:8k_2_02:46]
Corporate

[0000833444-24-000026:8k_2_02:47]
|  |  | Fiscal Q2 |  |  |  |  |  |
|  |  | 2024 |  | 2023 |  | Change |  |  |  |  |  |
| Corporate Expense |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 99 |  |  | $ | 131 |  |  | (24 | %) |  |  |  |  |  |
| Adjusted |  | 83 |  |  | 101 |  |  | (18 | %) |  |  |  |  |  |

[0000833444-24-000026:8k_2_02:48]
Adjusted Corporate expense in Q2 2024 excluded certain one-time cyber incident-related costs. Both periods exclude certain transaction/separation costs.

[0000833444-24-000026:8k_2_02:49]
OTHER Q2 ITEMS

[0000833444-24-000026:8k_2_02:50]
▪The Company discontinued its receivables factoring programs. Cash used by operating activities was $(203) million. Free cash flow was $(336) million and adjusted free cash flow was $375 million for Q2 2024.

[0000833444-24-000026:8k_2_02:51]
▪The Company paid dividends of approximately $252 million during Q2 2024.

[0000833444-24-000026:8k_2_02:52]
▪The Company repurchased 8.0 million shares of common stock for approximately $474 million.

[0000833444-24-000026:8k_2_02:53]
▪The Company recorded pre-tax restructuring and impairment costs of $254 million, comprised of a goodwill impairment ($230 million) and severance charges related to ongoing restructuring actions ($24 million).

[0000833444-24-000026:8k_2_02:54]
▪The Company recorded a pre-tax charge of $750 million related to a settlement with a nationwide class of public water systems concerning the use of Aqueous Film Forming Foam ("AFFF") manufactured and sold by a subsidiary of the Company.

[0000833444-24-000026:8k_2_02:55]
THIRD QUARTER GUIDANCE

[0000833444-24-000026:8k_2_02:56]
The Company initiated fiscal 2024 third quarter guidance:

[0000833444-24-000026:8k_2_02:57]
▪Organic revenue up ~LSD year-over-year

[0000833444-24-000026:8k_2_02:58]
▪Adjusted segment EBITA margin of ~17.0%

[0000833444-24-000026:8k_2_02:59]
▪Adjusted EPS before special items of ~$1.05 to $1.10

[0000833444-24-000026:8k_2_02:60]
FULL YEAR GUIDANCE

[0000833444-24-000026:8k_2_02:61]
The Company maintains fiscal 2024 full year EPS guidance:

[0000833444-24-000026:8k_2_02:62]
▪Organic revenue growth up ~MSD year-over-year

[0000833444-24-000026:8k_2_02:63]
▪Adjusted segment EBITA margin improvement of ~50 to 75 basis points, year-over-year

[0000833444-24-000026:8k_2_02:64]
▪Adjusted EPS before special items of ~$3.60 to $3.75

[0000833444-24-000026:8k_2_02:65]
5

[0000833444-24-000026:8k_2_02:66]
CONFERENCE CALL & WEBCAST INFO

[0000833444-24-000026:8k_2_02:67]
Johnson Controls will host a conference call to discuss this quarter’s results at 8:30 a.m. ET today, which can be accessed by dialing 844-763-8274 (in the United States) or +1-412-717-9224 (outside the United States), or via webcast. A slide presentation will accompany the prepared remarks and has been posted on the investor relations section of the Johnson Controls website at https://investors.johnsoncontrols.com/news-and-events/events-and-presentations. A replay will be made available approximately two hours following the conclusion of the conference call.

[0000833444-24-000026:8k_2_02:68]
About Johnson Controls

[0000833444-24-000026:8k_2_02:69]
At Johnson Controls (NYSE:JCI), we transform the environments where people live, work, learn and play. As the global leader in smart, healthy and sustainable buildings, our mission is to reimagine the performance of buildings to serve people, places and the planet.

[0000833444-24-000026:8k_2_02:70]
Building on a proud history of nearly 140 years of innovation, we deliver the blueprint of the future for industries such as healthcare, schools, data centers, airports, stadiums, manufacturing and beyond through OpenBlue, our comprehensive digital offering.

[0000833444-24-000026:8k_2_02:71]
Today, with a global team of 100,000 experts in more than 150 countries, Johnson Controls offers the world`s largest portfolio of building technology and software as well as service solutions from some of the most trusted names in the industry.

[0000833444-24-000026:8k_2_02:72]
Visit www.johnsoncontrols.com for more information and follow @Johnson Controls on social platforms.

[0000833444-24-000026:8k_2_02:73]
JOHNSON CONTROLS CONTACTS:

[0000833444-24-000026:8k_2_02:74]
| INVESTOR CONTACTS: | MEDIA CONTACT: |  |  |  |
| Jim Lucas | Danielle Canzanella |  |  |  |
| Direct: +1 651.391.3182 | Direct: +1 203.499.8297 |  |  |  |
| Email: jim.lucas@jci.com | Email: danielle.canzanella@jci.com |  |  |  |
| Michael Gates |  |  |  |  |
| Direct: +1 414.524.5785 |  |  |  |  |
| Email: michael.j.gates@jci.com |  |  |  |  |

[0000833444-24-000026:8k_2_02:75]
###

[0000833444-24-000026:8k_2_02:76]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-24-000026:8k_2_02:77]
6

[0000833444-24-000026:8k_2_02:78]
position, sales, costs, earnings, cash flows, other measures of results of operations, synergies and integration opportunities, capital expenditures, debt levels and market outlook are forward-looking statements. Words such as “may,” “will,” “expect,” “intend,” “estimate,” “anticipate,” “believe,” “should,” “forecast,” “project” or “plan” and terms of similar meaning are also generally intended to identify forward-looking statements.  However, the absence of these words does not mean that a statement is not forward-looking. Johnson Controls cautions that these statements are subject to numerous important risks, uncertainties, assumptions and other factors, some of which are beyond its control, that could cause its actual results to differ materially from those expressed or implied by such forward-looking statements, including, among others, risks related to: Johnson Controls ability to develop or acquire new products and technologies that achieve market acceptance and meet applicable quality and regulatory requirements; the ability to manage general economic, business and capital market conditions, including the impact of recessions, economic downturns and global price inflation; fluctuations in the cost and availability of public and private financing for its customers; the ability to innovate and adapt to emerging technologies, ideas and trends in the marketplace, including the incorporation of technologies such as artificial intelligence; the ability to manage macroeconomic and geopolitical volatility, including shortages impacting the availability of raw materials and component products and the conflicts between Russia and Ukraine and Israel and Hamas; managing the risks and impacts of potential and actual security breaches, cyberattacks, privacy breaches or data breaches, including business, service, or operational disruptions, the unauthorized access to or disclosure of data, financial loss, reputational damage, increased response and remediation costs, legal, and regulatory proceedings or other unfavorable outcomes; our ability to remediate our material weakness; maintaining and improving the capacity, reliability and security of Johnson Controls enterprise information technology infrastructure; the ability to manage the lifecycle cybersecurity risk in the development, deployment and operation of Johnson Controls digital platforms and services; changes to laws or policies governing foreign trade, including economic sanctions, tariffs, foreign exchange and capital controls, import/export controls or other trade restrictions; fluctuations in currency exchange rates; changes or uncertainty in laws, regulations, rates, policies, or interpretations that impact Johnson Controls business operations or tax status; the ability to adapt to global climate change, climate change regulation and successfully meet Johnson Controls public sustainability commitments; risks and uncertainties related to the settlement with a nationwide class of public water systems concerning the use of AFFF; the outcome of litigation and governmental proceedings; the risk of infringement or expiration of intellectual property rights; Johnson Controls ability to manage disruptions caused by catastrophic or geopolitical events, such as natural disasters, armed conflict, political change, climate change, pandemics and outbreaks of contagious diseases and other adverse public health developments; the ability of Johnson Controls to drive organizational improvement;  any delay or inability of Johnson Controls to realize the expected benefits and synergies of recent portfolio transactions; the ability to hire and retain senior management and other key personnel; the tax treatment of recent portfolio transactions; significant transaction costs and/or unknown liabilities associated with such transactions; labor shortages, work stoppages, union negotiations, labor disputes and other matters associated with the labor force; and the cancellation of or changes to commercial arrangements. A detailed discussion of risks related to Johnson Controls business is included in the section entitled “Risk Factors” in Johnson Controls Annual Report on Form 10-K for the fiscal year filed with the SEC, which is available at www.sec.gov and www.johnsoncontrols.com under the “Investors” tab. The description of certain of these risks is supplemented in Item 1A of Part II of Johnson Controls subsequently filed Quarterly Reports on Form 10-Q. Shareholders, potential investors and others should consider these factors in evaluating the forward-looking statements and should not place undue reliance on such statements. The forward-looking statements included in this communication are made only as of the date of this document, unless otherwise specified, and, except as required by law, Johnson Controls assumes no obligation, and disclaims any obligation, to update such statements to reflect events or circumstances occurring after the date of this communication.

[0000833444-24-000026:8k_2_02:79]
###

[0000833444-24-000026:8k_2_02:80]
7

[0000833444-24-000026:8k_2_02:81]
Non-GAAP Financial Information

[0000833444-24-000026:8k_2_02:82]
This press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include net mark-to-market adjustments, restructuring and impairment costs, the water systems AFFF settlement, certain transaction/separation costs, Silent-Aire earn-out adjustment, warehouse fire loss, cyber incident costs, Global Products product quality issue costs, and discrete tax items. Financial information regarding organic sales growth, adjusted segment EBITA, adjusted segment EBITA margin, adjusted Corporate expense, adjusted free cash flow, and adjusted net income are also presented, which are non-GAAP performance measures. Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of Johnson Controls. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.  For further information on the calculation of the non-GAAP measures and a reconciliation of these non-GAAP measures, refer to the attached footnotes.

[0000833444-24-000026:8k_2_02:83]
###

[0000833444-24-000026:8k_2_02:84]
8

[0000833444-24-000026:8k_2_02:85]
JOHNSON CONTROLS INTERNATIONAL PLC

[0000833444-24-000026:8k_2_02:86]
CONSOLIDATED STATEMENTS OF INCOME

[0000833444-24-000026:8k_2_02:87]
(in millions, except per share data; unaudited)

[0000833444-24-000026:8k_2_02:88]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales |  |  |  |  |  |  |  |
| Products and systems | $ | 4,985 |  |  | $ | 5,083 |  |  | $ | 9,474 |  |  | $ | 9,639 |  |
| Services | 1,714 |  |  | 1,603 |  |  | 3,319 |  |  | 3,115 |  |
|  | 6,699 |  |  | 6,686 |  |  | 12,793 |  |  | 12,754 |  |
| Cost of sales |  |  |  |  |  |  |  |
| Products and systems | 3,459 |  |  | 3,516 |  |  | 6,621 |  |  | 6,629 |  |
| Services | 1,059 |  |  | 929 |  |  | 1,999 |  |  | 1,793 |  |
|  | 4,518 |  |  | 4,445 |  |  | 8,620 |  |  | 8,422 |  |
| Gross profit | 2,181 |  |  | 2,241 |  |  | 4,173 |  |  | 4,332 |  |
| Selling, general and administrative expenses | 2,251 |  |  | 1,579 |  |  | 3,764 |  |  | 3,150 |  |
| Restructuring and impairment costs | 254 |  |  | 418 |  |  | 293 |  |  | 763 |  |
| Net financing charges | 93 |  |  | 71 |  |  | 192 |  |  | 138 |  |
| Equity income | 56 |  |  | 50 |  |  | 118 |  |  | 112 |  |
| Income (loss) before income taxes | (361) |  |  | 223 |  |  | 42 |  |  | 393 |  |
| Income tax (benefit) provision | (127) |  |  | 49 |  |  | (128) |  |  | 63 |  |
| Net income (loss) | (234) |  |  | 174 |  |  | 170 |  |  | 330 |  |
| Less: Income attributable to noncontrolling interests | 43 |  |  | 41 |  |  | 73 |  |  | 79 |  |
| Net income (loss) attributable to Johnson Controls | $ | (277) |  |  | $ | 133 |  |  | $ | 97 |  |  | $ | 251 |  |
| Earnings (loss) per share attributable to Johnson Controls |  |  |  |  |  |  |  |
| Basic | $ | (0.41) |  |  | $ | 0.19 |  |  | $ | 0.14 |  |  | $ | 0.37 |  |
| Diluted | (0.41) |  |  | 0.19 |  |  | 0.14 |  |  | 0.36 |  |

[0000833444-24-000026:8k_2_02:89]
9

[0000833444-24-000026:8k_2_02:90]
JOHNSON CONTROLS INTERNATIONAL PLC

[0000833444-24-000026:8k_2_02:91]
CONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION

[0000833444-24-000026:8k_2_02:92]
(in millions; unaudited)

[0000833444-24-000026:8k_2_02:93]
|  | March 31, 2024 |  | September 30, 2023 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 843 |  |  | $ | 835 |  |
| Accounts receivable - net | 6,688 |  |  | 6,006 |  |
| Inventories | 2,991 |  |  | 2,776 |  |
| Other current assets | 1,355 |  |  | 1,120 |  |
| Current assets | 11,877 |  |  | 10,737 |  |
| Property, plant and equipment - net | 3,104 |  |  | 3,136 |  |
| Goodwill | 17,757 |  |  | 17,936 |  |
| Other intangible assets - net | 4,717 |  |  | 4,888 |  |
| Investments in partially-owned affiliates | 1,172 |  |  | 1,056 |  |
| Other noncurrent assets | 4,830 |  |  | 4,489 |  |
| Total assets | $ | 43,457 |  |  | $ | 42,242 |  |
| Liabilities and Equity |  |  |  |
| Short-term debt | $ | 2,210 |  |  | $ | 385 |  |
| Current portion of long-term debt | 1,165 |  |  | 645 |  |
| Accounts payable | 4,019 |  |  | 4,268 |  |
| Accrued compensation and benefits | 779 |  |  | 958 |  |
| Deferred revenue | 2,331 |  |  | 1,996 |  |
| Other current liabilities | 3,095 |  |  | 2,832 |  |
| Current liabilities | 13,599 |  |  | 11,084 |  |
| Long-term debt | 7,348 |  |  | 7,818 |  |
| Pension and postretirement benefits | 251 |  |  | 278 |  |
| Other noncurrent liabilities | 5,418 |  |  | 5,368 |  |
| Long-term liabilities | 13,017 |  |  | 13,464 |  |
| Shareholders’ equity attributable to Johnson Controls | 15,658 |  |  | 16,545 |  |
| Noncontrolling interests | 1,183 |  |  | 1,149 |  |
| Total equity | 16,841 |  |  | 17,694 |  |
| Total liabilities and equity | $ | 43,457 |  |  | $ | 42,242 |  |

[0000833444-24-000026:8k_2_02:94]
10

[0000833444-24-000026:8k_2_02:95]
JOHNSON CONTROLS INTERNATIONAL PLC

[0000833444-24-000026:8k_2_02:96]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000833444-24-000026:8k_2_02:97]
(in millions; unaudited)

[0000833444-24-000026:8k_2_02:98]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Operating Activities |  |  |  |  |  |  |  |
| Net income (loss) attributable to Johnson Controls | $ | (277) |  |  | $ | 133 |  |  | $ | 97 |  |  | $ | 251 |  |
| Income attributable to noncontrolling interests | 43 |  |  | 41 |  |  | 73 |  |  | 79 |  |
| Net income (loss) | (234) |  |  | 174 |  |  | 170 |  |  | 330 |  |
| Adjustments to reconcile net income (loss) to cash provided (used) by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization | 236 |  |  | 206 |  |  | 467 |  |  | 409 |  |
| Pension and postretirement benefit expense (income) | (10) |  |  | 3 |  |  | (20) |  |  | (3) |  |
| Pension and postretirement contributions | (7) |  |  | (17) |  |  | (13) |  |  | (26) |  |
| Equity in earnings of partially-owned affiliates, net of dividends received | (46) |  |  | 1 |  |  | (102) |  |  | (55) |  |
| Deferred income taxes | (330) |  |  | (76) |  |  | (400) |  |  | (168) |  |
| Noncash restructuring and impairment charges | 244 |  |  | 397 |  |  | 253 |  |  | 691 |  |
| Equity-based compensation | 26 |  |  | 31 |  |  | 56 |  |  | 61 |  |
| Other - net | (16) |  |  | (60) |  |  | (38) |  |  | (87) |  |
| Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |  |  |  |
| Accounts receivable | (720) |  |  | (272) |  |  | (659) |  |  | (360) |  |
| Inventories | (25) |  |  | (145) |  |  | (228) |  |  | (493) |  |
| Other assets | (13) |  |  | (101) |  |  | (204) |  |  | (169) |  |
| Restructuring reserves | (46) |  |  | (31) |  |  | (60) |  |  | (17) |  |
| Accounts payable and accrued liabilities | 772 |  |  | 183 |  |  | 358 |  |  | (155) |  |
| Accrued income taxes | (34) |  |  | 21 |  |  | (29) |  |  | 60 |  |
| Cash provided (used) by operating activities | (203) |  |  | 314 |  |  | (449) |  |  | 18 |  |
| Investing Activities |  |  |  |  |  |  |  |
| Capital expenditures | (133) |  |  | (121) |  |  | (225) |  |  | (255) |  |
| Acquisition of businesses, net of cash acquired | 3 |  |  | (10) |  |  | 1 |  |  | (89) |  |
| Other - net | (7) |  |  | 6 |  |  | 13 |  |  | 30 |  |
| Cash used by investing activities | (137) |  |  | (125) |  |  | (211) |  |  | (314) |  |
| Financing Activities |  |  |  |  |  |  |  |
| Net proceeds from borrowings with maturities less than three months | 411 |  |  | 821 |  |  | 1,519 |  |  | 1,288 |  |
| Proceeds from debt | — |  |  | 162 |  |  | 422 |  |  | 316 |  |
| Repayments of debt | (163) |  |  | (335) |  |  | (163) |  |  | (536) |  |
| Stock repurchases and retirements | (474) |  |  | (93) |  |  | (474) |  |  | (247) |  |
| Payment of cash dividends | (252) |  |  | (240) |  |  | (504) |  |  | (481) |  |
| Employee equity-based compensation withholding taxes | (1) |  |  | (2) |  |  | (24) |  |  | (32) |  |
| Dividends paid to noncontrolling interests | (39) |  |  | (62) |  |  | (51) |  |  | (72) |  |
| Other - net | (33) |  |  | 2 |  |  | (48) |  |  | 26 |  |
| Cash provided (used) by financing activities | (551) |  |  | 253 |  |  | 677 |  |  | 262 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (41) |  |  | 22 |  |  | 19 |  |  | 8 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | (932) |  |  | 464 |  |  | 36 |  |  | (26) |  |
| Cash, cash equivalents and restricted cash at beginning of period | 1,892 |  |  | 1,576 |  |  | 924 |  |  | 2,066 |  |
| Cash, cash equivalents and restricted cash at end of period | 960 |  |  | 2,040 |  |  | 960 |  |  | 2,040 |  |
| Less: Restricted cash | 117 |  |  | 65 |  |  | 117 |  |  | 65 |  |
| Cash and cash equivalents at end of period | $ | 843 |  |  | $ | 1,975 |  |  | $ | 843 |  |  | $ | 1,975 |  |

[0000833444-24-000026:8k_2_02:99]
11

[0000833444-24-000026:8k_2_02:100]
FOOTNOTES

[0000833444-24-000026:8k_2_02:101]
1. Financial Summary

[0000833444-24-000026:8k_2_02:102]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net mark-to-market adjustments related to restricted asbestos investments and pension and postretirement plans, restructuring and impairment costs and net financing charges.

[0000833444-24-000026:8k_2_02:103]
| (in millions; unaudited) | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | Actual |  | AdjustedNon-GAAP |  | Actual |  | AdjustedNon-GAAP |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Segment EBITA (1) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 373 |  |  | $ | 315 |  |  | $ | 373 |  |  | $ | 315 |  |  | $ | 658 |  |  | $ | 582 |  |  | $ | 658 |  |  | $ | 582 |  |
| Building Solutions EMEA/LA | 89 |  |  | 69 |  | 89 |  |  | 69 |  |  | 169 |  |  | 144 |  |  | 169 |  |  | 144 |  |
| Building Solutions Asia Pacific | 54 |  |  | 79 |  | 54 |  |  | 79 |  |  | 100 |  |  | 147 |  |  | 100 |  |  | 147 |  |
| Global Products | 429 |  |  | 488 |  |  | 455 |  |  | 458 |  |  | 798 |  |  | 870 |  |  | 824 |  |  | 880 |  |
| Net income (loss) attributable to JCI | $ | (277) |  |  | $ | 133 |  |  | $ | 533 |  |  | $ | 517 |  |  | $ | 97 |  |  | $ | 251 |  |  | $ | 883 |  |  | $ | 980 |  |
| Income attributable to noncontrolling interests (2) | 43 |  |  | 41 |  |  | 45 |  |  | 41 |  |  | 73 |  |  | 79 |  |  | 77 |  |  | 79 |  |
| Net income (loss) | (234) |  |  | 174 |  |  | 578 |  |  | 558 |  |  | 170 |  |  | 330 |  |  | 960 |  |  | 1,059 |  |
| Less: Income tax benefit (provision) (3) | 127 |  |  | (49) |  |  | (92) |  |  | (87) |  |  | 128 |  |  | (63) |  |  | (153) |  |  | (165) |  |
| Income (loss) before income taxes | (361) |  |  | 223 |  |  | 670 |  |  | 645 |  |  | 42 |  |  | 393 |  |  | 1,113 |  |  | 1,224 |  |
| Net financing charges | 93 |  |  | 71 |  |  | 93 |  |  | 71 |  |  | 192 |  |  | 138 |  |  | 192 |  |  | 138 |  |
| EBIT (4) | $ | (268) |  |  | $ | 294 |  |  | $ | 763 |  |  | $ | 716 |  |  | $ | 234 |  |  | $ | 531 |  |  | $ | 1,305 |  |  | $ | 1,362 |  |

[0000833444-24-000026:8k_2_02:104]
(1) The Company's press release contains financial information regarding adjusted segment EBITA, which is a non-GAAP performance measure. The Company's definition of adjusted segment EBITA excludes other non-recurring items that are not considered to be directly related to the underlying operating performance of its businesses. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-24-000026:8k_2_02:105]
(2) Adjusted income attributable to noncontrolling interests for the three and six months ended March 31, 2024 excludes impact from restructuring and impairment costs of $2 million and $4 million, respectively.

[0000833444-24-000026:8k_2_02:106]
(3) Adjusted income tax provision for the three and six months ended March 31, 2024 excludes the net tax benefit and other impacts of pre-tax adjusting items of $219 million and $281 million, respectively. Adjusted income tax provision for the three and six months ended March 31, 2023 excludes the net tax benefit of pre-tax adjusting items of $38 million and $102 million, respectively.

[0000833444-24-000026:8k_2_02:107]
(4) Management defines earnings before interest and taxes (EBIT) as income before net financing charges, income taxes and noncontrolling interests. EBIT is a non-GAAP performance measure. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-24-000026:8k_2_02:108]
12

[0000833444-24-000026:8k_2_02:109]
The following is the three months ended March 31, 2024 and 2023 reconciliation of segment EBITA as reported to adjusted segment EBITA (unaudited):

[0000833444-24-000026:8k_2_02:110]
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building SolutionsAsia Pacific |  | Global Products |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Segment EBITA as reported | $ | 373 |  |  | $ | 315 |  |  | $ | 89 |  |  | $ | 69 |  |  | $ | 54 |  |  | $ | 79 |  |  | $ | 429 |  |  | $ | 488 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Silent-Aire earn-out adjustment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (7) |  |  | (30) |  |
| Global Products product quality issue (5) | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 33 |  |  | — |  |
| Adjusted segment EBITA | $ | 373 |  |  | $ | 315 |  |  | $ | 89 |  |  | $ | 69 |  |  | $ | 54 |  |  | $ | 79 |  |  | $ | 455 |  |  | $ | 458 |  |

[0000833444-24-000026:8k_2_02:111]
(5) Adjusted segment EBITA excludes costs related to a product quality issue within the Company's Global Products business for the three and six months ended March 31, 2024. Management believes the exclusion of these costs is  useful to investors due to the unusual nature and magnitude of the expected related costs.

[0000833444-24-000026:8k_2_02:112]
The following is the six months ended March 31, 2024 and 2023 reconciliation of segment EBITA as reported to adjusted segment EBITA (unaudited):

[0000833444-24-000026:8k_2_02:113]
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building SolutionsAsia Pacific |  | Global Products |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Segment EBITA as reported | $ | 658 |  |  | $ | 582 |  |  | $ | 169 |  |  | $ | 144 |  |  | $ | 100 |  |  | $ | 147 |  |  | $ | 798 |  |  | $ | 870 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Silent-Aire earn-out adjustment | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (7) |  |  | (30) |  |
| Warehouse fire loss (6) | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 40 |  |
| Global Products product quality issue | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 33 |  |  | — |  |
| Adjusted segment EBITA | $ | 658 |  |  | $ | 582 |  |  | $ | 169 |  |  | $ | 144 |  |  | $ | 100 |  |  | $ | 147 |  |  | $ | 824 |  |  | $ | 880 |  |

[0000833444-24-000026:8k_2_02:114]
(6) Adjusted segment EBITA excludes a $40 million uninsured loss attributable to a fire at a warehouse in Menominee, Michigan.

[0000833444-24-000026:8k_2_02:115]
The Company's press release and earnings presentation include forward-looking statements regarding organic revenue growth, adjusted free cash flow and adjusted EPS, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as mark-to-market adjustments. Organic revenue growth excludes the effect of acquisitions, divestitures and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s fiscal 2024 third quarter and full year GAAP financial results.

[0000833444-24-000026:8k_2_02:116]
13

[0000833444-24-000026:8k_2_02:117]
2.  Net Income and Diluted Earnings Per Share Reconciliations

[0000833444-24-000026:8k_2_02:118]
The Company's press release contains financial information regarding adjusted earnings per share and adjusted net income (loss) attributable to JCI, which are non-GAAP performance measures. The adjusting items shown in the table below are excluded because these items are not considered to be directly related to the underlying operating performance of the Company. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-24-000026:8k_2_02:119]
A reconciliation of diluted earnings per share as reported to adjusted diluted earnings per share and net income (loss) attributable to JCI to adjusted net income (loss) attributable to JCI for the three months ended March 31, 2024 and 2023 is shown below (unaudited):

[0000833444-24-000026:8k_2_02:120]
|  | Three Months Ended March 31, |
|  | Net income (loss) attributable to JCI |  | Earnings per share |
| (in millions, except per share) | 2024 |  | 2023 |  | 2024 |  | 2023 |
| As reported for JCI plc | $ | (277) |  |  | $ | 133 |  |  | $ | (0.41) |  |  | $ | 0.19 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | (15) |  |  | 4 |  |  | (0.02) |  |  | 0.01 |  |
| Restructuring and impairment costs | 254 |  |  | 418 |  |  | 0.37 |  |  | 0.61 |  |
| NCI impact of restructuring and impairment costs | (2) |  |  | — |  |  | — |  |  | — |  |
| Water systems AFFF settlement (1) | 750 |  |  | — |  |  | 1.10 |  |  | — |  |
| Transaction/separation costs | 12 |  |  | 30 |  |  | 0.02 |  |  | 0.04 |  |
| Silent-Aire earn-out adjustment | (7) |  |  | (30) |  |  | (0.01) |  |  | (0.04) |  |
| Cyber incident costs | 4 |  |  | — |  |  | 0.01 |  |  | — |  |
| Global Products product quality issue | 33 |  |  | — |  |  | 0.05 |  |  | — |  |
| Related tax impact | (219) |  |  | (38) |  |  | (0.32) |  |  | (0.05) |  |
| Adjusted JCI plc* | $ | 533 |  |  | $ | 517 |  |  | $ | 0.78 |  |  | $ | 0.75 |  |

[0000833444-24-000026:8k_2_02:121]
* May not sum due to rounding

[0000833444-24-000026:8k_2_02:122]
(1) The Company recorded a pre-tax charge of $750 million related to a settlement with a nationwide class of public water systems concerning the use of AFFF manufactured and sold by a subsidiary of the Company.

[0000833444-24-000026:8k_2_02:123]
14

[0000833444-24-000026:8k_2_02:124]
A reconciliation of diluted earnings per share as reported to adjusted diluted earnings per share and net income (loss) attributable to JCI to adjusted net income (loss) attributable to JCI for the six months ended March 31, 2024 and 2023 is shown below (unaudited):

[0000833444-24-000026:8k_2_02:125]
|  | Six Months Ended March 31, |
|  | Net income (loss) attributable to JCI |  | Earnings per share |
| (in millions, except per share) | 2024 |  | 2023 |  | 2024 |  | 2023 |
| As reported for JCI plc | $ | 97 |  |  | $ | 251 |  |  | $ | 0.14 |  |  | $ | 0.36 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | (37) |  |  | 1 |  |  | (0.05) |  |  | — |  |
| Restructuring and impairment costs | 293 |  |  | 763 |  |  | 0.43 |  |  | 1.11 |  |
| NCI impact of restructuring and impairment costs | (4) |  |  | — |  |  | (0.01) |  |  | — |  |
| Water systems AFFF settlement | 750 |  |  | — |  |  | 1.10 |  |  | — |  |
| Transaction/separation costs | 12 |  |  | 57 |  |  | 0.02 |  |  | 0.08 |  |
| Silent-Aire earn-out adjustment | (7) |  |  | (30) |  |  | (0.01) |  |  | (0.04) |  |
| Warehouse fire loss | — |  |  | 40 |  |  | — |  |  | 0.06 |  |
| Cyber incident costs | 27 |  |  | — |  |  | 0.04 |  |  | — |  |
| Global Products product quality issue | 33 |  |  | — |  |  | 0.05 |  |  | — |  |
| Related tax impact | (281) |  |  | (102) |  |  | (0.41) |  |  | (0.15) |  |
| Adjusted JCI plc* | $ | 883 |  |  | $ | 980 |  |  | $ | 1.30 |  |  | $ | 1.42 |  |

[0000833444-24-000026:8k_2_02:126]
* May not sum due to rounding

[0000833444-24-000026:8k_2_02:127]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-24-000026:8k_2_02:128]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Weighted average shares outstanding for JCI plc |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 679.0 |  |  | 686.8 |  | 679.9 |  | 686.9 |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | — |  |  | 2.9 |  | 1.6 |  | 3.1 |
| Diluted weighted average shares outstanding | 679.0 |  |  | 689.7 |  |  | 681.5 |  |  | 690.0 |  |

[0000833444-24-000026:8k_2_02:129]
For the three months ended March 31, 2024, the total number of potential dilutive shares due to stock options, unvested restricted stock and unvested performance share awards was 1.6 million. However, these items were not included in the computation of diluted loss per share for the three months ended March 31, 2024, since to do so would decrease the loss per share. On an adjusted diluted outstanding share basis, inclusion of the effect of dilutive securities results in diluted weighted average shares outstanding of 680.7 million for the three months ended March 31, 2024.

[0000833444-24-000026:8k_2_02:130]
15

[0000833444-24-000026:8k_2_02:131]
3. Organic Growth Reconciliation

[0000833444-24-000026:8k_2_02:132]
The components of the change in net sales for the three months ended March 31, 2024 versus the three months ended March 31, 2023, including organic growth, are shown below (unaudited):

[0000833444-24-000026:8k_2_02:133]
|  | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Three months ended March 31, 2023 |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | $ | 2,520 |  |  | $ | 1,031 |  |  | $ | 667 |  |  | $ | 4,218 |  |  | $ | 2,468 |  |  | $ | 6,686 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | (2) |  |  | (17) |  |  | (19) |  |  | (3) |  |  | (22) |  |
| Foreign currency | 7 |  |  | (4) |  |  | (33) |  |  | (30) |  |  | (54) |  |  | (84) |  |
| Adjusted base net sales | 2,527 |  |  | 1,025 |  |  | 617 |  |  | 4,169 |  |  | 2,411 |  |  | 6,580 |  |
| Acquisitions | 16 |  |  | 3 |  |  | 17 |  |  | 36 |  |  | 7 |  |  | 43 |  |
| Organic Growth | 196 |  |  | 36 |  |  | (143) |  |  | 89 |  |  | (13) |  |  | 76 |  |
| Net sales for the three months ended March 31, 2024 | $ | 2,739 |  |  | $ | 1,064 |  |  | $ | 491 |  |  | $ | 4,294 |  |  | $ | 2,405 |  |  | $ | 6,699 |  |
| Change in net sales attributable to: |  |  |  |  |  |  |  |  |  |  |  |
| Organic growth | 8 | % |  | 4 | % |  | (23) | % |  | 2 | % |  | (1) | % |  | 1 | % |
| Foreign currency | — |  |  | — |  |  | (5) |  |  | (1) |  |  | (2) |  |  | (1) |  |
| Acquisitions | 1 |  |  | — |  |  | 3 |  |  | 1 |  |  | — |  |  | 1 |  |
| Divestitures and other | — |  |  | — |  |  | (3) |  |  | — |  |  | — |  |  | — |  |
| Total change in net sales | 9 | % |  | 3 | % |  | (26) | % |  | 2 | % |  | (3) | % |  | — | % |

[0000833444-24-000026:8k_2_02:134]
The components of the change in net sales for the six months ended March 31, 2024 versus the six months ended March 31, 2023, including organic growth, are shown below (unaudited):

[0000833444-24-000026:8k_2_02:135]
|  | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Six months ended March 31, 2023 |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | $ | 4,887 |  |  | $ | 2,006 |  |  | $ | 1,313 |  |  | $ | 8,206 |  |  | $ | 4,548 |  |  | $ | 12,754 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | (2) |  |  | (34) |  |  | (36) |  |  | (5) |  |  | (41) |  |
| Foreign currency | 13 |  |  | 38 |  |  | (43) |  |  | 8 |  |  | (64) |  |  | (56) |  |
| Adjusted base net sales | 4,900 |  |  | 2,042 |  |  | 1,236 |  |  | 8,178 |  |  | 4,479 |  |  | 12,657 |  |
| Acquisitions | 32 |  |  | 6 |  |  | 36 |  |  | 74 |  |  | 29 |  |  | 103 |  |
| Organic growth | 294 |  |  | 54 |  |  | (274) |  |  | 74 |  |  | (41) |  |  | 33 |  |
| Net sales for the six months ended March 31, 2024 | $ | 5,226 |  |  | $ | 2,102 |  |  | $ | 998 |  |  | $ | 8,326 |  |  | $ | 4,467 |  |  | $ | 12,793 |  |
| Change in net sales attributable to: |  |  |  |  |  |  |  |  |  |  |  |
| Organic growth | 6 | % |  | 3 | % |  | (22) | % |  | 1 | % |  | (1) | % |  | — | % |
| Foreign currency | — |  |  | 2 |  |  | (3) |  |  | — |  |  | (1) |  |  | — |  |
| Acquisitions | 1 |  |  | — |  |  | 3 |  |  | 1 |  |  | 1 |  |  | 1 |  |
| Divestitures and other | — |  |  | — |  |  | (3) |  |  | — |  |  | — |  |  | — |  |
| Total change in net sales | 7 | % |  | 5 | % |  | (24) | % |  | 1 | % |  | (2) | % |  | — | % |

[0000833444-24-000026:8k_2_02:136]
16

[0000833444-24-000026:8k_2_02:137]
The components of the change in total service revenue for the three months ended March 31, 2024 versus the three months ended March 31, 2023, including organic growth, is shown below (unaudited):

[0000833444-24-000026:8k_2_02:138]
|  | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Three months ended March 31, 2023 |  |  |  |  |  |  |  |  |  |  |  |
| Service revenue | $ | 966 |  |  | $ | 449 |  |  | $ | 188 |  |  | $ | 1,603 |  |  | $ | — |  |  | $ | 1,603 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | — |  |  | (17) |  |  | (17) |  |  | — |  |  | (17) |  |
| Foreign currency | — |  |  | (17) |  |  | (8) |  |  | (25) |  |  | — |  |  | (25) |  |
| Adjusted base service revenue | 966 |  |  | 432 |  |  | 163 |  |  | 1,561 |  |  | — |  |  | 1,561 |  |
| Acquisitions | 15 |  |  | 1 |  |  | 8 |  |  | 24 |  |  | — |  |  | 24 |  |
| Organic growth | 57 |  |  | 60 |  |  | 12 |  |  | 129 |  |  | — |  |  | 129 |  |
| Service revenue for the three months ended March 31, 2024 | $ | 1,038 |  |  | $ | 493 |  |  | $ | 183 |  |  | $ | 1,714 |  |  | $ | — |  |  | $ | 1,714 |  |
| Change in service revenue attributable to: |  |  |  |  |  |  |  |  |  |  |  |
| Organic growth | 6 | % |  | 14 | % |  | 7 | % |  | 8 | % |  | — | % |  | 8 | % |
| Foreign currency | — |  |  | (4) |  |  | (4) |  |  | (2) |  |  | — |  |  | (2) |  |
| Acquisitions | 2 |  |  | — |  |  | 5 |  |  | 2 |  |  | — |  |  | 2 |  |
| Divestitures and other | — |  |  | — |  |  | (9) |  |  | (1) |  |  | — |  |  | (1) |  |
| Total change in service revenue | 7 | % |  | 10 | % |  | (3) | % |  | 7 | % |  | — | % |  | 7 | % |

[0000833444-24-000026:8k_2_02:139]
The components of the change in total service revenue for the six months ended March 31, 2024 versus the six months ended March 31, 2023, including organic growth, is shown below (unaudited):

[0000833444-24-000026:8k_2_02:140]
|  | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Six months ended March 31, 2023 |  |  |  |  |  |  |  |  |  |  |  |
| Service revenue | $ | 1,882 |  |  | $ | 872 |  |  | $ | 361 |  |  | $ | 3,115 |  |  | $ | — |  |  | $ | 3,115 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | (1) |  |  | (34) |  |  | (35) |  |  | — |  |  | (35) |  |
| Foreign currency | 1 |  |  | (9) |  |  | (10) |  |  | (18) |  |  | — |  |  | (18) |  |
| Adjusted base service revenue | 1,883 |  |  | 862 |  |  | 317 |  |  | 3,062 |  |  | — |  |  | 3,062 |  |
| Acquisitions | 29 |  |  | 3 |  |  | 16 |  |  | 48 |  |  | — |  |  | 48 |  |
| Organic growth | 95 |  |  | 94 |  |  | 20 |  |  | 209 |  |  | — |  |  | 209 |  |
| Service revenue for the six months ended March 31, 2024 | $ | 2,007 |  |  | $ | 959 |  |  | $ | 353 |  |  | $ | 3,319 |  |  | $ | — |  |  | $ | 3,319 |  |
| Change in service revenue attributable to: |  |  |  |  |  |  |  |  |  |  |  |
| Organic growth | 5 | % |  | 11 | % |  | 6 | % |  | 7 | % |  | — | % |  | 7 | % |
| Foreign currency | — |  |  | (1) |  |  | (3) |  |  | (1) |  |  | — |  |  | (1) |  |
| Acquisitions | 2 |  |  | — |  |  | 5 |  |  | 2 |  |  | — |  |  | 2 |  |
| Divestitures and other | — |  |  | — |  |  | (9) |  |  | (1) |  |  | — |  |  | (1) |  |
| Total change in service revenue | 7 | % |  | 10 | % |  | (2) | % |  | 7 | % |  | — | % |  | 7 | % |

[0000833444-24-000026:8k_2_02:141]
17

[0000833444-24-000026:8k_2_02:142]
The components of the change in total systems/install revenue for the three months ended March 31, 2024 versus the three months ended March 31, 2023, including organic growth, is shown below (unaudited):

[0000833444-24-000026:8k_2_02:143]
|  | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Three months ended March 31, 2023 |  |  |  |  |  |  |  |  |  |  |  |
| Systems/install revenue | $ | 1,554 |  |  | $ | 582 |  |  | $ | 479 |  |  | $ | 2,615 |  |  | $ | 2,468 |  |  | $ | 5,083 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | (2) |  |  | — |  |  | (2) |  |  | (3) |  |  | (5) |  |
| Foreign currency | 7 |  |  | 13 |  |  | (25) |  |  | (5) |  |  | (54) |  |  | (59) |  |
| Adjusted base systems/install revenue | 1,561 |  |  | 593 |  |  | 454 |  |  | 2,608 |  |  | 2,411 |  |  | 5,019 |  |
| Acquisitions | 1 |  |  | 2 |  |  | 9 |  |  | 12 |  |  | 7 |  |  | 19 |  |
| Organic growth | 139 |  |  | (24) |  |  | (155) |  |  | (40) |  |  | (13) |  |  | (53) |  |
| Systems/install revenue for the three months ended March 31, 2024 | $ | 1,701 |  |  | $ | 571 |  |  | $ | 308 |  |  | $ | 2,580 |  |  | $ | 2,405 |  |  | $ | 4,985 |  |
| Change in systems/install revenue attributable to: |  |  |  |  |  |  |  |  |  |  |  |
| Organic growth | 9 | % |  | (4) | % |  | (34) | % |  | (2) | % |  | (1) | % |  | (1) | % |
| Foreign currency | — |  |  | 2 |  |  | (5) |  |  | — |  |  | (2) |  |  | (1) |  |
| Acquisitions | — |  |  | — |  |  | 2 |  |  | — |  |  | — |  |  | — |  |
| Total change in systems/install revenue | 9 | % |  | (2) | % |  | (36) | % |  | (1) | % |  | (3) | % |  | (2) | % |

[0000833444-24-000026:8k_2_02:144]
The components of the change in total systems/install revenue for the six months ended March 31, 2024 versus the six months ended March 31, 2023, including organic growth, is shown below (unaudited):

[0000833444-24-000026:8k_2_02:145]
|  | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Six months ended March 31, 2023 |  |  |  |  |  |  |  |  |  |  |  |
| Systems/install revenue | $ | 3,005 |  |  | $ | 1,134 |  |  | $ | 952 |  |  | $ | 5,091 |  |  | $ | 4,548 |  |  | $ | 9,639 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | (1) |  |  | — |  |  | (1) |  |  | (5) |  |  | (6) |  |
| Foreign currency | 12 |  |  | 47 |  |  | (33) |  |  | 26 |  |  | (64) |  |  | (38) |  |
| Adjusted base systems/install revenue | 3,017 |  |  | 1,180 |  |  | 919 |  |  | 5,116 |  |  | 4,479 |  |  | 9,595 |  |
| Acquisitions | 3 |  |  | 3 |  |  | 20 |  |  | 26 |  |  | 29 |  |  | 55 |  |
| Organic growth | 199 |  |  | (40) |  |  | (294) |  |  | (135) |  |  | (41) |  |  | (176) |  |
| Systems/install revenue for the six months ended March 31, 2024 | $ | 3,219 |  |  | $ | 1,143 |  |  | $ | 645 |  |  | $ | 5,007 |  |  | $ | 4,467 |  |  | $ | 9,474 |  |
| Change in systems/install revenue attributable to: |  |  |  |  |  |  |  |  |  |  |  |
| Organic growth | 7 | % |  | (3) | % |  | (32) | % |  | (3) | % |  | (1) | % |  | (2) | % |
| Foreign currency | — |  |  | 4 |  |  | (3) |  |  | 1 |  |  | (1) |  |  | — |  |
| Acquisitions | — |  |  | — |  |  | 2 |  |  | 1 |  |  | — |  |  | 1 |  |
| Total change in systems/install revenue | 7 | % |  | 1 | % |  | (32) | % |  | (2) | % |  | (2) | % |  | (2) | % |

[0000833444-24-000026:8k_2_02:146]
18

[0000833444-24-000026:8k_2_02:147]
4.   Adjusted Free Cash Flow Conversion

[0000833444-24-000026:8k_2_02:148]
The Company's press release contains financial information regarding adjusted cash flows from operating activities, adjusted free cash flow and adjusted free cash flow conversion, which are non-GAAP performance measures. We also present below free cash flow conversion from the GAAP measure of net income attributable to JCI.

[0000833444-24-000026:8k_2_02:149]
Effective January 1, 2023, the Company has excluded the impact of its financing entity, JC Capital, from the calculation of adjusted free cash flow. Management believes this provides a more true representation of the Company’s operational ability to convert cash, without the contrary impact from financing activities. The impact on interim and annual periods prior to January 1, 2023 was not material. JC Capital cash flows that are excluded from the calculation of adjusted free cash flow primarily include activity associated with finance/notes receivables and inventory and/or capital expenditures related to lease arrangements. JC Capital net income that is excluded is primarily related to interest income on the finance/notes receivable and profit recognized on arrangements with sales-type lease components.

[0000833444-24-000026:8k_2_02:150]
During the three months ended March 31, 2024, the Company discontinued its receivables factoring program. Effective January 1, 2024, the Company has excluded the impact of the discontinuation of its accounts receivables factoring programs from the calculation of adjusted free cash flow. Management believes this provides a more accurate representation of the Company’s current period operating cash flows compared to the prior year. The Company has also re-baselined the prior year adjusted free cash flow measure to present a more comparative measure without the impact of factoring.

[0000833444-24-000026:8k_2_02:151]
Adjusted free cash flow is defined as cash provided (used) by operating activities, less capital expenditures, excluding the impacts from JC Capital and the discontinuation of the factoring programs. Free cash flow conversion from net income is defined as free cash flow divided by net income attributable to JCI. Adjusted free cash flow conversion is defined as adjusted free cash flow divided by adjusted net income attributable to JCI, excluding JC Capital. Management believes these non-GAAP measures are useful to investors in understanding the strength of the Company and its ability to generate cash. These non-GAAP measures can also be used to evaluate our ability to generate cash flow from operations and the impact that this cash flow has on our liquidity.

[0000833444-24-000026:8k_2_02:152]
The following is the three and six months ended March 31, 2024 and 2023 calculation of free cash flow and free cash flow conversion from net income (unaudited):

[0000833444-24-000026:8k_2_02:153]
|  | Three Months Ended |  | Six Months Ended |
| (in millions) | March 31, 2024 |  | March 31, 2023 |  | March 31, 2024 |  | March 31, 2023 |
| Cash provided (used) by operating activities | $ | (203) |  | $ | 314 |  |  | $ | (449) |  | $ | 18 |  |
| Capital expenditures | (133) |  | (121) |  |  | (225) |  | (255) |  |
| Free cash flow | $ | (336) |  | $ | 193 |  |  | $ | (674) |  | $ | (237) |  |
| Net income (loss) attributable to JCI | $ | (277) |  | $ | 133 |  |  | $ | 97 |  | $ | 251 |  |
| Free cash flow conversion from net income (loss) | * |  | 145% |  |  | (695) | % |  | (94) | % |  |

[0000833444-24-000026:8k_2_02:154]
* Metric not meaningful

[0000833444-24-000026:8k_2_02:155]
19

[0000833444-24-000026:8k_2_02:156]
The following is the three and six months ended March 31, 2024 and 2023 calculation of adjusted free cash flow and adjusted free cash flow conversion (unaudited):

[0000833444-24-000026:8k_2_02:157]
|  | Three Months Ended | Six Months Ended |
| (in millions) | March 31, 2024 |  | March 31, 2023 | March 31, 2024 |  | March 31, 2023 |
| Free cash flow | $ | (336) |  | $ | 193 |  | $ | (674) |  | $ | (237) |
| Less: JC Capital cash used by operating activities | (32) |  | (42) |  | (120) |  | (42) |
| Less: Impact from discontinuation of factoring programs | (679) |  | — |  | (599) |  | — |
| Adjusted free cash flow | 375 |  | 235 |  | 45 |  | (195) |
| Less: Prior year impact from factoringprograms | — |  | 18 |  | — |  | (74) |
| Re-baselined adjusted free cash flow | $ | 375 |  | $ | 217 |  | $ | 45 |  | $ | (121) |
| Adjusted net income attributable to JCI | $ | 533 |  | $ | 517 |  | $ | 883 |  | $ | 980 |
| Less: JC Capital net income | 3 |  | 8 |  | 5 |  | 8 |
| Adjusted net income attributable to JCI, excluding JC Capital | $ | 530 |  | $ | 509 |  | $ | 878 |  | $ | 972 |
| Adjusted free cash flow conversion | 71% |  | 43% |  | 5% |  | (12) | % |

[0000833444-24-000026:8k_2_02:158]
5.  Debt Ratios

[0000833444-24-000026:8k_2_02:159]
The Company's earnings presentation provides financial information regarding net debt to adjusted EBITDA, which is a non-GAAP performance measure. We also present below net debt to income before income taxes. The Company believes these ratios are useful to understanding the Company's financial condition as they provide an overview of the extent to which the Company relies on external debt financing for its funding and are a measure of risk to its shareholders. The following is the March 31, 2024, December 31, 2023, and March 31, 2023 calculation of net debt to income before income taxes and net debt to adjusted EBITDA (unaudited):

[0000833444-24-000026:8k_2_02:160]
| (in millions) | March 31, 2024 |  | December 31, 2023 |  | March 31, 2023 |  |  |
| Short-term debt and current portion of long-term debt | $ | 3,375 |  |  | $ | 2,650 |  |  | $ | 2,659 |  |  |  |
| Long-term debt | 7,348 |  |  | 7,959 |  |  | 7,832 |  |  |  |
| Total debt | 10,723 |  |  | 10,609 |  |  | 10,491 |  |  |  |
| Less: cash and cash equivalents | 843 |  |  | 1,801 |  |  | 1,975 |  |  |  |
| Total net debt | $ | 9,880 |  |  | $ | 8,808 |  |  | $ | 8,516 |  |  |  |
| Last twelve months income before income taxes | $ | 1,359 |  |  | $ | 1,943 |  |  | $ | 1,503 |  |  |  |
| Total net debt to income before income taxes | 7.3x |  | 4.5x |  | 5.7x |  |  |
| Last twelve months adjusted EBITDA | $ | 4,128 |  |  | $ | 4,051 |  |  | $ | 3,895 |  |  |  |
| Total net debt to adjusted EBITDA | 2.4x |  | 2.2x |  | 2.2x |  |  |

[0000833444-24-000026:8k_2_02:161]
20

[0000833444-24-000026:8k_2_02:162]
The following is the twelve months ended March 31, 2024, December 31, 2023, and March 31, 2023 reconciliation of income from continuing operations to adjusted EBIT and adjusted EBITDA, which are non-GAAP performance measures (unaudited):

[0000833444-24-000026:8k_2_02:163]
| (in millions) | Last Twelve Months Ended March 31, 2024 |  | Last Twelve Months Ended December 31, 2023 |  | Last Twelve Months Ended March 31, 2023 |  |  |
| Net income | $ | 1,873 |  |  | $ | 2,281 |  |  | $ | 1,582 |  |  |  |
| Income tax benefit | (514) |  |  | (338) |  |  | (79) |  |  |  |
| Net financing charges | 335 |  |  | 313 |  |  | 247 |  |  |  |
| EBIT | 1,694 |  |  | 2,256 |  |  | 1,750 |  |  |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | 54 |  |  | 73 |  |  | (65) |  |  |  |
| Restructuring and impairment costs | 594 |  |  | 758 |  |  | 1,051 |  |  |  |
| Environmental remediation and related reserves adjustment | — |  |  | — |  |  | 255 |  |  |  |
| Water systems AFFF settlement | 750 |  |  | — |  |  | — |  |  |  |
| Silent-Aire earn-out adjustment | (7) |  |  | (30) |  |  | (30) |  |  |  |
| Global Products product quality issue | 33 |  |  | — |  |  | — |  |  |  |
| Warehouse fire loss | — |  |  | — |  |  | 40 |  |  |  |
| Cyber incident costs | 27 |  |  | 23 |  |  | — |  |  |  |
| Transaction/separation costs | 77 |  |  | 95 |  |  | 87 |  |  |  |
| Adjusted EBIT (1) | 3,222 |  |  | 3,175 |  |  | 3,088 |  |  |  |
| Depreciation and amortization | 906 |  |  | 876 |  |  | 807 |  |  |  |
| Adjusted EBITDA (1) | $ | 4,128 |  |  | $ | 4,051 |  |  | $ | 3,895 |  |  |  |

[0000833444-24-000026:8k_2_02:164]
(1) The Company's definition of adjusted EBIT and adjusted EBITDA excludes special items that are not considered to be directly related to the underlying operating performance of its businesses. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-24-000026:8k_2_02:165]
6.  Income Taxes

[0000833444-24-000026:8k_2_02:166]
The Company's effective tax rate before consideration of net mark-to-market adjustments, restructuring and impairment costs, discrete tax items, Silent-Aire earn-out adjustments, certain transaction/separation costs, cyber incident costs, Global Products product quality issue costs and the water systems AFFF settlement for the three and six months ending March 31, 2024 is approximately 13.75%. The Company's effective tax rate before consideration of net mark-to-market adjustments, restructuring and impairment costs, discrete tax items, certain transaction/separation costs and warehouse fire loss for the three and six months ending March 31, 2023 is approximately 13.5%.

[0000833444-24-000026:8k_2_02:167]
21
