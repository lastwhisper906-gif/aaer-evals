# JCI MD&A — 0000833444-24-000029


## mdna

[0000833444-24-000029:mdna:1]
[same as prior period, unchanged from 0000833444-24-000011:mdna:1]

[0000833444-24-000029:mdna:2]
[same as prior period, unchanged from 0000833444-24-000011:mdna:2]

[0000833444-24-000029:mdna:3]
[same as prior period, unchanged from 0000833444-24-000011:mdna:3]

[0000833444-24-000029:mdna:4]
[same as prior period, unchanged from 0000833444-24-000011:mdna:4]

[0000833444-24-000029:mdna:5]
[same as prior period, unchanged from 0000833444-24-000011:mdna:5]

[0000833444-24-000029:mdna:6]
[same as prior period, unchanged from 0000833444-24-000011:mdna:6]

[0000833444-24-000029:mdna:7]
The following information should be read in conjunction with the September 30, 2023 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in the Company's Annual Report on Form 10-K for the year ended September 30, 2023 filed with the SEC on December 14, 2023. References in the following discussion and analysis to "Three Months," "Second Quarter" or similar language refer to the three months ended March 31, 2024 compared to the three months ended March 31, 2023, while "Year-to-Date" refers to six months ended March 31, 2024 compared to the six months ended March 31, 2023.

[0000833444-24-000029:mdna:8]
[same as prior period, unchanged from 0000833444-24-000011:mdna:8]

[0000833444-24-000029:mdna:9]
Much of the demand for the Company’s products and solutions is driven by construction, facility expansion, retrofit and maintenance projects within the commercial, institutional, industrial, data center, governmental and residential sectors. Construction projects are heavily dependent on general economic conditions, localized demand for real estate and the availability of credit, public funding or other financing sources. Positive or negative fluctuations in construction, industrial facility expansion, retrofit activity, maintenance projects and other capital investments in buildings within the sectors that the Company serves, as well as availability of credit, financing or funding for such projects, could have a corresponding impact on the Company’s financial condition, results of operations and cash flows. During the six months ended March 31, 2024, the Company observed continued softening of economic conditions in China, negatively impacting the performance of the Building Solutions Asia Pacific segment. The Company expects economic conditions in China to remain soft throughout the remainder of fiscal 2024, which could impact the performance of the Building Solutions Asia Pacific segment.

[0000833444-24-000029:mdna:10]
As a result of the Company’s global presence, a significant portion of its revenues and expenses is denominated in currencies other than the U.S. dollar. The Company is therefore subject to non-U.S. currency risks and non-U.S. exchange exposure. While the Company employs financial instruments to hedge some of its transactional foreign exchange exposure, these activities do not insulate it completely from those exposures. In addition, the currency exposure from the translation of non-U.S. dollar functional currency subsidiaries are not able to be hedged. Exchange rates can be volatile and a substantial weakening or strengthening of foreign currencies against the U.S. dollar could increase or reduce the Company’s profit margin, respectively, and impact the comparability of results from period to period. Revenue and profits were negatively impacted by movements in foreign exchange rates against the U.S. dollar during the three and six months ended March 31, 2024.

[0000833444-24-000029:mdna:11]
The Company continues to observe trends demonstrating increased interest and demand for its products and services that enable smart, safe, efficient and sustainable buildings. This demand is driven in part by government tax incentives, building performance standards and other regulations designed to limit emissions and combat climate change. In particular, legislative and regulatory initiatives such as the U.S. Climate Smart Buildings Initiative, U.S. Inflation Reduction Act and EU Energy Performance of Buildings Directive include provisions designed to fund and encourage investment in decarbonization and digital technologies for buildings. This demand is supplemented by an increase in commitments in both the public and private sectors to reduce emissions and/or achieve net zero emissions. The Company seeks to capitalize on these trends to drive growth by developing and delivering technologies and solutions to create smart, sustainable and healthy buildings. The Company is investing in new digital and product capabilities, including its OpenBlue platform, to enable it to deliver sustainable, high-

[0000833444-24-000029:mdna:12]
[same as prior period, unchanged from 0000833444-24-000011:mdna:34]

[0000833444-24-000029:mdna:13]
efficiency products and tailored services to enable customers to achieve their sustainability goals. The Company is leveraging its install base, together with data-driven products and services, to offer outcome-based solutions to customers with a focus on generating accelerated growth in services and recurring revenue.

[0000833444-24-000029:mdna:14]
The Company has experienced, and could continue to experience, increased material cost inflation and component shortages, as well as disruptions and delays in its supply chain, as a result of global macroeconomic trends, including increased global demand, geopolitical and economic tensions, including the conflict between Russia and Ukraine and Israel and Hamas, and labor shortages. Actions taken by the Company to mitigate supply chain disruptions and inflation, including expanding and redistributing its supplier network, supplier financing, price increases and productivity improvements, have generally been successful in offsetting some, but not all, of the impact of these trends. The collective impact of these trends has been favorable to revenue due to increased demand and price increases to offset inflation, while negatively impacting margins primarily due to ongoing cost pressures. Although the Company has experienced recent improvement, further disruptions, shortages and cost increases could occur in the future, the effect of which will depend on the Company’s ability to successfully mitigate and offset the impact of these events.

[0000833444-24-000029:mdna:15]
[same as prior period, unchanged from 0000833444-24-000011:mdna:14]

[0000833444-24-000029:mdna:16]
[same as prior period, unchanged from 0000833444-24-000011:mdna:15]

[0000833444-24-000029:mdna:17]
During the weekend of September 23, 2023, the Company experienced a cybersecurity incident impacting its internal information technology ("IT") infrastructure and applications. The cybersecurity incident consisted of unauthorized access, data exfiltration and deployment of ransomware by a third party to a portion of the Company's internal IT infrastructure. The incident caused disruptions and limitation of access to portions of the Company's business applications supporting aspects of the Company's operations and corporate functions, which disruptions and limitations continued into the early portion of the first quarter of fiscal 2024. The Company has contained the unauthorized access and restored the impacted applications and systems.

[0000833444-24-000029:mdna:18]
The Company’s investigation and remediation efforts remain ongoing, including the analysis of data accessed, exfiltrated or otherwise impacted during the cybersecurity incident. Based on the information reviewed to date, the Company has not observed evidence of any impact to its digital products, services and solutions, including OpenBlue and Metasys.

[0000833444-24-000029:mdna:19]
The impact on net income for the six months ended March 31, 2024 was approximately $29 million. The impact is primarily attributable to expenses associated with the response to, and remediation of, the incident, and is net of insurance recoveries and revenues deferred at the end of fiscal 2023 which were recognized in the first half of fiscal 2024. Additional expenses are expected in the remainder of the fiscal year, but are not expected to be material.

[0000833444-24-000029:mdna:20]
Expenses include third-party expenditures, including IT recovery and forensic experts and others performing professional services to investigate and remediate the incident, as well as incremental operating expenses incurred from the resulting disruption to the Company’s business operations. The overall impact of the cybersecurity incident in fiscal 2024 is not expected to be material to net income, net of insurance recoveries, or cash flows from continuing operations; however, the timing of recognizing the insurance recoveries may differ from the timing of recognizing the associated expenses.

[0000833444-24-000029:mdna:21]
[same as prior period, unchanged from 0000833444-24-000011:mdna:20]

[0000833444-24-000029:mdna:22]
[same as prior period, unchanged from 0000833444-24-000011:mdna:21]

[0000833444-24-000029:mdna:23]
In the third and fourth quarters of fiscal 2023, the Company developed a restructuring plan which included workforce reductions and other actions focused on continued scaling of selling, general and administrative expenses ("SG&A") to its planned growth. The costs of the plan were recorded to restructuring and impairment costs in the consolidated statements of income. In the three and six months ended March 31, 2024, an additional $24 million and $63 million, respectively, of restructuring charges related to this plan were incurred. Additional restructuring charges are expected in subsequent quarters. The Company expects savings from the restructuring initiatives to be substantially offset by incremental ongoing operating costs and investments to grow the business.

[0000833444-24-000029:mdna:24]
[same as prior period, unchanged from 0000833444-24-000011:mdna:25]

[0000833444-24-000029:mdna:25]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
| (in millions) | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
| Net sales | $ | 6,699 |  |  | $ | 6,686 |  |  | — | % |  | $ | 12,793 |  |  | $ | 12,754 |  |  | — | % |

[0000833444-24-000029:mdna:26]
For the three months ended March 31, 2024, higher organic sales ($76 million) and the net impact of acquisitions and divestitures ($21 million) were substantially offset by the unfavorable impact of foreign currency translation ($84 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, net sales increased 1% over the prior year, primarily attributable to growth in Service, which was partially offset by continued weakness in China's Systems/Install business and declines in Residential HVAC.

[0000833444-24-000029:mdna:27]
For the six months ended March 31, 2024, the net impact of acquisitions and divestitures ($62 million) and higher organic sales ($33 million) were substantially offset by the unfavorable impact of foreign currency translation ($56 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, net sales were flat compared to the prior year, as growth in Service was offset primarily by weakness in China's Systems/Install business and declines in global residential HVAC.

[0000833444-24-000029:mdna:28]
Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-24-000029:mdna:29]
[same as prior period, unchanged from 0000833444-24-000011:mdna:28]

[0000833444-24-000029:mdna:30]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
| (in millions) | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
| Cost of sales | $ | 4,518 |  |  | $ | 4,445 |  |  | 2 | % |  | $ | 8,620 |  |  | $ | 8,422 |  |  | 2 | % |
| Gross profit | 2,181 |  |  | 2,241 |  |  | (3) |  |  | 4,173 |  |  | 4,332 |  |  | (4) |  |
| % of sales | 32.6 | % |  | 33.5 | % |  | (90) | bp |  | 32.6 | % |  | 34.0 | % |  | (140) | bp |

[0000833444-24-000029:mdna:31]
Decreases in gross profit for both the three and six months ended March 31, 2024 were primarily due to unfavorable mix and lower volumes in the Global Products segment, while higher gross profit in the Systems/Install business of the Building Solutions segments was partially offset by lower gross profit in the Service business due to unfavorable service mix.

[0000833444-24-000029:mdna:32]
Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA").

[0000833444-24-000029:mdna:33]
[same as prior period, unchanged from 0000833444-24-000011:mdna:31]

[0000833444-24-000029:mdna:34]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
| (in millions) | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
| SG&A | $ | 2,251 |  |  | $ | 1,579 |  |  | 43 | % |  | $ | 3,764 |  |  | $ | 3,150 |  |  | 19 | % |
| % of sales | 33.6 | % |  | 23.6 | % |  | 1,000 | bp |  | 29.4 | % |  | 24.7 | % |  | 470 | bp |

[0000833444-24-000029:mdna:35]
For the three months ended March 31, 2024, the increase in SG&A was primarily due to the accrual of the water systems AFFF settlement agreement costs ($750 million), partially offset by lower transaction and separation costs and higher mark-to-market gains.

[0000833444-24-000029:mdna:36]
For the six months ended March 31, 2024, the increase in SG&A was primarily due to the accrual of the water systems AFFF settlement agreement costs ($750 million), partially offset by lower transaction and separation costs, higher mark-to-market gains, and the absence of the prior year loss associated with a fire at a leased warehouse facility.

[0000833444-24-000029:mdna:37]
41

[0000833444-24-000029:mdna:38]
Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA. Refer to Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further disclosure related to the water systems AFFF settlement.

[0000833444-24-000029:mdna:39]
[same as prior period, unchanged from 0000833444-24-000011:mdna:35]

[0000833444-24-000029:mdna:40]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
| (in millions) | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 |  |
| Goodwill impairments | $ | 230 |  |  | $ | 184 |  |  |  |  | $ | 230 |  |  | $ | 184 |  |  |
| Other impairments | — |  |  | 210 |  |  |  |  | — |  |  | 498 |  |  |
| Restructuring and related costs | 24 |  |  | 24 |  |  |  |  | 63 |  |  | 81 |  |  |
| Restructuring and impairment costs | $ | 254 |  |  | $ | 418 |  |  |  |  | $ | 293 |  |  | $ | 763 |  |  |

[0000833444-24-000029:mdna:41]
Refer to Note 4, "Assets and Liabilities Held for Sale," Note 8, "Goodwill and Other Intangible Assets," and Note 17, "Restructuring and Related Costs," of the notes to the consolidated financial statements for further disclosure related to the Company's restructuring actions and impairment costs.

[0000833444-24-000029:mdna:42]
[same as prior period, unchanged from 0000833444-24-000011:mdna:40]

[0000833444-24-000029:mdna:43]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
| (in millions) | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
| Interest expense, net of capitalized interest costs | $ | 100 |  |  | $ | 71 |  |  | 41 | % |  | $ | 191 |  |  | $ | 140 |  |  | 36 | % |
| Other financing charges | 4 |  |  | 11 |  |  | (64) |  |  | 28 |  |  | 21 |  |  | 33 |  |
| Interest income | (5) |  |  | (3) |  |  | 67 |  |  | (10) |  |  | (7) |  |  | 43 |  |
| Net foreign exchange results for financing activities | (6) |  |  | (8) |  |  | (25) |  |  | (17) |  |  | (16) |  |  | 6 |  |
| Net financing charges | $ | 93 |  |  | $ | 71 |  |  | 31 | % |  | $ | 192 |  |  | $ | 138 |  |  | 39 | % |

[0000833444-24-000029:mdna:44]
[same as prior period, unchanged from 0000833444-24-000011:mdna:42]

[0000833444-24-000029:mdna:45]
[same as prior period, unchanged from 0000833444-24-000011:mdna:43]

[0000833444-24-000029:mdna:46]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
| (in millions) | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
| Income tax (benefit) provision | $ | (127) |  |  | $ | 49 |  |  | * |  | $ | (128) |  |  | $ | 63 |  |  | * |
| Effective tax rate | 35.2 | % |  | 22.0 | % |  | * |  | (305 | %) |  | 16.0 | % |  | * |

[0000833444-24-000029:mdna:47]
[same as prior period, unchanged from 0000833444-24-000011:mdna:45]

[0000833444-24-000029:mdna:48]
Refer to Note 18, "Income Taxes" of the notes to the consolidated financial statements for further disclosure related to the Company's income taxes.

[0000833444-24-000029:mdna:49]
[same as prior period, unchanged from 0000833444-24-000011:mdna:47]

[0000833444-24-000029:mdna:50]
Management evaluates the performance of its segments primarily on segment earnings before interest, taxes and amortization ("EBITA"), which represents income before income taxes and noncontrolling interests, excluding corporate expenses, amortization of intangible assets, restructuring and impairment costs, the water systems AFFF settlement costs, net mark-to-market gains and losses related to pension and postretirement plans and restricted asbestos investments, and net financing charges.

[0000833444-24-000029:mdna:51]
[same as prior period, unchanged from 0000833444-24-000011:mdna:49]

[0000833444-24-000029:mdna:52]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
| (in millions) | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
| Building Solutions North America | $ | 2,739 |  |  | $ | 2,520 |  |  | 9 | % |  | $ | 5,226 |  |  | $ | 4,887 |  |  | 7 | % |
| Building Solutions EMEA/LA | 1,064 |  |  | 1,031 |  |  | 3 |  |  | 2,102 |  |  | 2,006 |  |  | 5 |  |
| Building Solutions Asia Pacific | 491 |  |  | 667 |  |  | (26) |  |  | 998 |  |  | 1,313 |  |  | (24) |  |
| Global Products | 2,405 |  |  | 2,468 |  |  | (3) |  |  | 4,467 |  |  | 4,548 |  |  | (2) |  |
|  | $ | 6,699 |  |  | $ | 6,686 |  |  | — | % |  | $ | 12,793 |  |  | $ | 12,754 |  |  | — | % |

[0000833444-24-000029:mdna:53]
Three Months:

[0000833444-24-000029:mdna:54]
•The increase in Building Solutions North America was primarily due to organic growth, including higher prices ($196 million), incremental sales related to business acquisitions ($16 million) and the favorable impact of foreign currency translation ($7 million). Excluding the impacts of foreign currency translation and business acquisitions, sales growth was led by high-teens growth in Applied HVAC & Controls.

[0000833444-24-000029:mdna:55]
•The increase in Building Solutions EMEA/LA was primarily due to organic growth, including higher prices ($36 million). Sales growth was led by mid-teen growth in Service.

[0000833444-24-000029:mdna:56]
•The decrease in Building Solutions Asia Pacific was primarily due to organic sales declines ($143 million) and the unfavorable impact of foreign currency translation ($33 million). Excluding the impacts of foreign currency translation, sales decreased as high single-digit Service growth was more than offset by continued weakness in the China Systems/Install business.

[0000833444-24-000029:mdna:57]
•The decrease in Global Products was due to the unfavorable impact of foreign currency translation ($54 million) and the net impact of lower volumes and higher prices ($13 million). Excluding the impacts of foreign currency translation, sales decreased as growth in Applied and Commercial HVAC was more than offset by declines in Residential HVAC and Fire & Security.

[0000833444-24-000029:mdna:58]
Year-to-Date:

[0000833444-24-000029:mdna:59]
•The increase in Building Solutions North America was primarily due to organic growth, including higher prices ($294 million), incremental sales related to business acquisitions ($32 million) and the favorable impact of foreign currency translation ($13 million). Excluding the impacts of foreign currency translation and business acquisitions and divestitures, sales growth was led by growth in Applied HVAC & Controls.

[0000833444-24-000029:mdna:60]
•The increase in Building Solutions EMEA/LA was primarily due to organic growth, including higher prices ($54 million) and the favorable impact of foreign currency translation ($38 million). Excluding the impacts of foreign currency translation, sales growth was led by growth in Service.

[0000833444-24-000029:mdna:61]
•The decrease in Building Solutions Asia Pacific was primarily due to organic sales declines ($274 million) and the unfavorable impact of foreign currency translation ($43 million). Excluding the impacts of foreign currency translation, sales decreased as Service growth was more than offset by weakness in the China Systems/Install business.

[0000833444-24-000029:mdna:62]
43

[0000833444-24-000029:mdna:63]
•The decrease in Global Products was due to the unfavorable impact of foreign currency translation ($64 million) and the net impact of lower volumes and higher prices ($41 million), partially offset by the net impact of business acquisitions and divestitures ($24 million). Excluding the impacts of foreign currency translation and business acquisitions and divestitures, sales decreased as growth in Applied and Commercial HVAC was more than offset by declines in Residential HVAC.

[0000833444-24-000029:mdna:64]
[same as prior period, unchanged from 0000833444-24-000011:mdna:55]

[0000833444-24-000029:mdna:65]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
| (in millions) | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
| Building Solutions North America | $ | 373 |  |  | $ | 315 |  |  | 18 | % |  | $ | 658 |  |  | $ | 582 |  |  | 13 | % |
| Building Solutions EMEA/LA | 89 |  |  | 69 |  |  | 29 |  |  | 169 |  |  | 144 |  |  | 17 |  |
| Building Solutions Asia Pacific | 54 |  |  | 79 |  |  | (32) |  |  | 100 |  |  | 147 |  |  | (32) |  |
| Global Products | 429 |  |  | 488 |  |  | (12) |  |  | 798 |  |  | 870 |  |  | (8) |  |

[0000833444-24-000029:mdna:66]
Three Months:

[0000833444-24-000029:mdna:67]
[same as prior period, unchanged from 0000833444-24-000011:mdna:57]

[0000833444-24-000029:mdna:68]
•The increase in Building Solutions EMEA/LA was primarily due to productivity benefits, higher margin backlog converting to sales, and growth in higher margin Service.

[0000833444-24-000029:mdna:69]
•The decrease in Building Solutions Asia Pacific was primarily due to continued declines in the Systems/Install business in China offsetting the impact of positive mix in Service.

[0000833444-24-000029:mdna:70]
•The decrease in Global Products was primarily due to unfavorable mix and volumes, a charge related to a product quality issue, and the more favorable impact of an acquisition earn-out liability adjustment in the prior year.

[0000833444-24-000029:mdna:71]
Year-to-Date:

[0000833444-24-000029:mdna:72]
•The increase in Building Solutions North America was primarily due to favorable price/cost as higher margin backlog converted to sales and continued growth in Service.

[0000833444-24-000029:mdna:73]
•The increase in Building Solutions EMEA/LA was primarily due to productivity benefits and growth in higher margin Service.

[0000833444-24-000029:mdna:74]
•The decrease in Building Solutions Asia Pacific was primarily due to continued weakness in the Systems/Install business in China.

[0000833444-24-000029:mdna:75]
•The decrease in Global Products was primarily due to unfavorable mix, a charge related to a product quality issue, and the more favorable impact of an acquisition earn-out liability adjustment in the prior year, partially offset by the absence of the prior year loss associated with a fire at a leased warehouse facility.

[0000833444-24-000029:mdna:76]
Backlog and Orders

[0000833444-24-000029:mdna:77]
Backlog and orders are additional metrics that are meant to provide management with a deeper level of insight into the progress of specific strategic and growth initiatives. Backlog is applicable to sales of systems and services and totaled $15.2 billion at March 31, 2024, including both Building Solutions and Global Products. Orders provide management with a signal of customer demand for the Company's products and services, as well as an indication of future revenues and performance. However, the timing and conversion of backlog and orders are subject to numerous uncertainties and risks and are not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-24-000029:mdna:78]
The following table summarizes backlog and orders for the Building Solutions segments:

[0000833444-24-000029:mdna:79]
|  | Backlog |  | Orders |
| (in billions) | March 31, 2024 |  |  |  | Year-over-Year Change (1) |  | Three months ended March 31, 2024 |  |  |  | Year-over-Year Change (1) |
| Building Solutions North America | $ | 8.9 |  |  |  |  | 15 | % |  | $ | 3.3 |  |  |  |  | 19 | % |
| Building Solutions EMEA/LA | 2.4 |  |  |  |  | 10 |  |  | 1.2 |  |  |  |  | 8 |  |
| Building Solutions Asia Pacific | 1.3 |  |  |  |  | (18) |  |  | 0.6 |  |  |  |  | (9) |  |
| Total Building Solutions | $ | 12.6 |  |  |  |  | 10 | % |  | $ | 5.1 |  |  |  |  | 12 | % |

[0000833444-24-000029:mdna:80]
(1) Change is compared to March 31, 2023 (backlog) and the three months ended March 31, 2023 (orders) and excludes the impact of mergers, acquisitions, dispositions and foreign currency.

[0000833444-24-000029:mdna:81]
Remaining performance obligations were $21.2 billion at March 31, 2024. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-24-000029:mdna:82]
[same as prior period, unchanged from 0000833444-24-000011:mdna:64]

[0000833444-24-000029:mdna:83]
•Remaining performance obligations exclude service contracts with an original expected duration of one year or less and contracts that are cancellable without substantial penalty versus backlog which includes short-term and cancellable contracts; and

[0000833444-24-000029:mdna:84]
[same as prior period, unchanged from 0000833444-24-000011:mdna:66]

[0000833444-24-000029:mdna:85]
The Company reports backlog, which it believes is a useful measure of evaluating the Company's operational performance and relationship to total orders.

[0000833444-24-000029:mdna:86]
[same as prior period, unchanged from 0000833444-24-000011:mdna:68]

[0000833444-24-000029:mdna:87]
[same as prior period, unchanged from 0000833444-24-000011:mdna:69]

[0000833444-24-000029:mdna:88]
| (in millions) | March 31, 2024 |  | September 30, 2023 |  | Change |
| Current assets | $ | 11,877 |  |  | $ | 10,737 |  |  |  |
| Current liabilities | 13,599 |  |  | 11,084 |  |  |  |
| Working capital | $ | (1,722) |  |  | $ | (347) |  |  | * |
| Accounts receivable - net | $ | 6,688 |  |  | $ | 6,006 |  |  | 11 | % |
| Inventories | 2,991 |  |  | 2,776 |  |  | 8 | % |
| Accounts payable | 4,019 |  |  | 4,268 |  |  | (6 | %) |

[0000833444-24-000029:mdna:89]
* Measure not meaningful

[0000833444-24-000029:mdna:90]
•The decrease in working capital was primarily due to higher current borrowings and the accrual for the water systems AFFF settlement costs, partially offset by increases in accounts receivable and the net impact of various other current assets and liabilities.

[0000833444-24-000029:mdna:91]
•During the three months ended March 31, 2024, the Company discontinued its receivables factoring programs. The Company did not factor any receivables during the three months ended March 31, 2024, and does not expect to engage in any receivables factoring during the remainder of fiscal year 2024, resulting in an unfavorable impact of approximately $700 million on operating cash flows in fiscal 2024.

[0000833444-24-000029:mdna:92]
•Material cash requirements primarily consist of working capital, capital expenditures, dividends, minimum pension contributions, debt maturities and interest, operating leases, payments related to the water systems AFFF settlement , and any potential acquisitions or stock repurchases. The Company expects cash requirements for the remainder of fiscal 2024 will be funded from operations, supplemented by other sources of short- and long-term borrowings, including term loans, commercial paper and the issuance of debt securities. The Company also expects to fund a portion of the payments related to the water systems AFFF settlement through insurance recoveries.

[0000833444-24-000029:mdna:93]
[same as prior period, unchanged from 0000833444-24-000011:mdna:72]

[0000833444-24-000029:mdna:94]
|  |  | Six Months Ended March 31, |
| (in millions) |  | 2024 |  | 2023 |
| Cash provided (used) by operating activities |  | $ | (449) |  |  | $ | 18 |  |
| Cash used by investing activities |  | (211) |  |  | (314) |  |
| Cash provided by financing activities |  | 677 |  |  | 262 |  |

[0000833444-24-000029:mdna:95]
•The increase in cash used by operating activities was primarily due to increases in accounts receivable due to the discontinuation of factoring programs and tax items, partially offset by decreases in accounts payable due to the timing of payments.

[0000833444-24-000029:mdna:96]
•The decrease in cash used by investing activities was primarily due to greater cash usage in the prior year for acquisitions.

[0000833444-24-000029:mdna:97]
•The increase in cash provided by financing activities was primarily due to changes in net debt activity, partially offset by higher share repurchases in the six months ended March 31, 2024.

[0000833444-24-000029:mdna:98]
[same as prior period, unchanged from 0000833444-24-000011:mdna:77]

[0000833444-24-000029:mdna:99]
| (in millions) | March 31, 2024 |  | September 30, 2023 |  |  |
| Short-term debt | $ | 2,210 |  |  | $ | 385 |  |  |  |
| Current portion of long-term debt | 1,165 |  |  | 645 |  |  |  |
| Long-term debt | 7,348 |  |  | 7,818 |  |  |  |
| Total debt | 10,723 |  |  | 8,848 |  |  |  |
| Less: Cash and cash equivalents | 843 |  |  | 835 |  |  |  |
| Net debt | $ | 9,880 |  |  | $ | 8,013 |  |  |  |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders ("Equity") | $ | 15,658 |  |  | $ | 16,545 |  |  |  |
| Total capitalization (Total debt plus Equity) | 26,381 |  |  | 25,393 |  |  |  |
| Net capitalization (Net debt plus Equity) | 25,538 |  |  | 24,558 |  |  |  |
| Total debt as a % of Total capitalization | 40.6 | % |  | 34.8 | % |  |  |
| Net debt as a % of Net capitalization | 38.7 | % |  | 32.6 | % |  |  |

[0000833444-24-000029:mdna:100]
[same as prior period, unchanged from 0000833444-24-000011:mdna:79]

[0000833444-24-000029:mdna:101]
•As of March 31, 2024, approximately $2.5 billion remains available under the Company's share repurchase authorization, which does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. The Company expects to repurchase outstanding shares from time to time depending on market conditions, alternate uses of capital, liquidity, and the economic environment.

[0000833444-24-000029:mdna:102]
•The Company declared a dividend of $0.37 per common share in the quarter ended March 31, 2024 and intends to continue paying dividends throughout fiscal 2024.

[0000833444-24-000029:mdna:103]
•On April 12, 2024, Tyco Fire Products, a subsidiary of the Company, agreed to a settlement with a nationwide class of public water systems that detected PFAS in their drinking water systems that they allege to be associated with the use of AFFF. Under the terms of the agreement, Tyco Fire Products agreed to contribute $750 million to resolve these PFAS claims. Tyco Fire Products expects to contribute an initial $250 million on or about May 25, 2024, with the remaining $500 million to be contributed six months after preliminary court approval of the settlement, which is expected to be addressed by the MDL court in or around mid-May, 2024. Tyco Fire Products has a significant amount of insurance through a number of insurers and expects to apply the proceeds recovered under its policies to cover a substantial portion of the total payment, although the specific amount and timing of any insurance recoveries are uncertain.  Refer to Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for additional discussion of the water systems settlement.

[0000833444-24-000029:mdna:104]
•The Company believes its capital resources and liquidity position, including cash and cash equivalents of $843 million at March 31, 2024, are adequate to fund operations and meet its cash obligations for the foreseeable future.

[0000833444-24-000029:mdna:105]
–The Company manages its short-term debt position in the U.S. and euro commercial paper and bank loan markets. Commercial paper outstanding totaled $1.8 billion as of March 31, 2024 and $0.2 billion as of September 30, 2023.

[0000833444-24-000029:mdna:106]
[same as prior period, unchanged from 0000833444-24-000011:mdna:85]

[0000833444-24-000029:mdna:107]
–The Company also has the ability to draw on its $2.5 billion revolving credit facility which is scheduled to expire in December 2028 or its $0.5 billion revolving credit facility which is scheduled to expire in December 2024. There were no draws on the revolving credit facilities as of March 31, 2024 and September 30, 2023.

[0000833444-24-000029:mdna:108]
–In April 2024, the Company and its wholly-owned subsidiary, Tyco Fire & Security Finance S.C.A, co-issued $700 million unsecured, unsubordinated senior notes with an interest rate of 5.50% which is due April 2029.

[0000833444-24-000029:mdna:109]
•The Company's ability to access the global capital markets and the related cost of financing is dependent upon, among other factors, the Company's credit ratings. As of March 31, 2024, the Company's credit ratings and outlook were as follows:

[0000833444-24-000029:mdna:110]
[same as prior period, unchanged from 0000833444-24-000011:mdna:88]

[0000833444-24-000029:mdna:111]
[same as prior period, unchanged from 0000833444-24-000011:mdna:89]

[0000833444-24-000029:mdna:112]
•Financial covenants in the Company's revolving credit facilities require a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of March 31, 2024, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures governing its notes, and expects to remain in compliance

[0000833444-24-000029:mdna:113]
for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-24-000029:mdna:114]
•The Company earns a significant amount of its income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances. However, in the first quarter of fiscal 2024, the Company provided income tax expense related to a change in the Company's assertion over the outside basis differences of the Company’s investment in certain consolidated subsidiaries. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. The Company's intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at its Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings.

[0000833444-24-000029:mdna:115]
[same as prior period, unchanged from 0000833444-24-000011:mdna:93]

[0000833444-24-000029:mdna:116]
•Refer to Note 10, "Debt and Financing Arrangements," and Note 21, "Commitments and Contingencies" of the notes to the consolidated financial statements for additional information on debt balances, the water systems AFFF settlement agreement and items impacting capitalization.

[0000833444-24-000029:mdna:117]
[same as prior period, unchanged from 0000833444-24-000011:mdna:95]

[0000833444-24-000029:mdna:118]
[same as prior period, unchanged from 0000833444-24-000011:mdna:96]

[0000833444-24-000029:mdna:119]
•€500 million aggregate principal amount of 0.375% Senior Notes due 2027

[0000833444-24-000029:mdna:120]
•€600 million aggregate principal amount of 3.000% Senior Notes due 2028

[0000833444-24-000029:mdna:121]
•$700 million aggregate principal amount of 5.500% Senior Notes due 2029

[0000833444-24-000029:mdna:122]
•$625 million aggregate principal amount of 1.750% Senior Notes due 2030

[0000833444-24-000029:mdna:123]
•$500 million aggregate principal amount of 2.000% Sustainability-Linked Senior Notes due 2031

[0000833444-24-000029:mdna:124]
•€500 million aggregate principal amount of 1.000% Senior Notes due 2032

[0000833444-24-000029:mdna:125]
•$400 million aggregate principal amount of 4.900% Senior Notes due 2032

[0000833444-24-000029:mdna:126]
•€800 million aggregate principal amount of 4.25% Senior Notes due 2035

[0000833444-24-000029:mdna:127]
[same as prior period, unchanged from 0000833444-24-000011:mdna:104]

[0000833444-24-000029:mdna:128]
The following table presents the net loss attributable to the Parent Company and TFSCA (collectively, the "Obligor Group") and the net income (loss) attributable to intercompany transactions between the Obligor Group and subsidiaries of the Parent Company other than TFSCA (collectively, the "Non-Obligor Subsidiaries") which are excluded from the Net loss attributable to the Obligor Group (in millions):

[0000833444-24-000029:mdna:129]
|  |  | Six Months Ended March 31, 2024 |  | Year Ended September 30, 2023 |  |
| Net loss attributable to the Obligor Group |  | $ | (282) |  |  | $ | (458) |  |  |
| Net income (loss) attributable to intercompany transactions |  | 143 |  |  | (139) |  |  |

[0000833444-24-000029:mdna:130]
[same as prior period, unchanged from 0000833444-24-000011:mdna:107]

[0000833444-24-000029:mdna:131]
[same as prior period, unchanged from 0000833444-24-000011:mdna:108]

[0000833444-24-000029:mdna:132]
|  |  | Obligor Group |  | Intercompany Balances |
|  |  | March 31, 2024 |  | September 30, 2023 |  | March 31, 2024 |  | September 30, 2023 |
| Current assets |  | $ | 282 |  |  | $ | 26 |  |  | $ | 654 |  |  | $ | 5,608 |  |
| Noncurrent assets |  | 250 |  |  | 270 |  |  | 8,029 |  |  | 1,882 |  |
| Current liabilities |  | 5,330 |  |  | 3,652 |  |  | 3,025 |  |  | 9,289 |  |
| Noncurrent liabilities |  | 7,175 |  |  | 7,585 |  |  | 9,412 |  |  | 3,462 |  |

[0000833444-24-000029:mdna:133]
[same as prior period, unchanged from 0000833444-24-000011:mdna:110]

[0000833444-24-000029:mdna:134]
[same as prior period, unchanged from 0000833444-24-000011:mdna:111]

[0000833444-24-000029:mdna:135]
[same as prior period, unchanged from 0000833444-24-000011:mdna:112]

[0000833444-24-000029:mdna:136]
[same as prior period, unchanged from 0000833444-24-000011:mdna:113]

[0000833444-24-000029:mdna:137]
[same as prior period, unchanged from 0000833444-24-000011:mdna:114]
