# JCI MD&A — 0000833444-25-000032


## mdna

[0000833444-25-000032:mdna:1]
[same as prior period, unchanged from 0000833444-25-000011:mdna:1]

[0000833444-25-000032:mdna:2]
[same as prior period, unchanged from 0000833444-25-000011:mdna:2]

[0000833444-25-000032:mdna:3]
[same as prior period, unchanged from 0000833444-25-000011:mdna:3]

[0000833444-25-000032:mdna:4]
[same as prior period, unchanged from 0000833444-25-000011:mdna:4]

[0000833444-25-000032:mdna:5]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, safe, healthy and sustainable buildings, serving a wide range of customers around the globe. The Company’s products, services, systems and solutions

[0000833444-25-000032:mdna:6]
advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-25-000032:mdna:7]
[same as prior period, unchanged from 0000833444-25-000011:mdna:6]

[0000833444-25-000032:mdna:8]
On April 1, 2025, the Company, as part of ongoing initiatives to drive simplification, accelerate growth, better reflect its organizational and operational structure and align with the manner in which the Company's chief operating decision maker assesses performance and makes decisions regarding the allocation of resources following portfolio simplification actions, realigned into three reportable segments (Americas, EMEA and APAC) from four reportable segments (Global Products, Building Solutions North America, Building Solutions EMEA/LA and Building Solutions APAC). The Company will begin reporting under this segment structure when it reports its quarterly results for the fiscal third quarter ending June 30, 2025.

[0000833444-25-000032:mdna:9]
The following information should be read in conjunction with the September 30, 2024 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in the Company's Annual Report on Form 10-K for the year ended September 30, 2024 filed with the SEC on November 19, 2024. References in the following discussion and analysis to "Three Months," "Second Quarter" or similar language refer to the three months ended March 31, 2025 compared to the three months ended March 31, 2024, while "Year-to-Date" refers to six months ended March 31, 2025 compared to the six months ended March 31, 2024.

[0000833444-25-000032:mdna:10]
[same as prior period, unchanged from 0000833444-25-000011:mdna:8]

[0000833444-25-000032:mdna:11]
Much of the demand for the Company’s products and solutions is heavily dependent on general economic conditions, localized demand for real estate and the availability of credit, public funding or other financing sources. Positive or negative fluctuations in these dependencies could have a corresponding impact on the Company’s financial condition, results of operations and cash flows.

[0000833444-25-000032:mdna:12]
The Company maintains operations worldwide. Recently, the United States has announced tariffs and reciprocal tariffs on a wide range of products manufactured or produced worldwide, including Canada, China, the European Union, Japan and Mexico, among others. Several countries have similarly announced reciprocal or other tariffs impacting products manufactured or produced in the United States. In addition, the United States and other nations have, and may in the future, pause, reimpose, decrease or increase tariffs. If the actual and potential tariffs and reciprocal tariffs are implemented as currently enacted or proposed, the Company expects that such actions will negatively impact its revenue growth and margins in future periods through decreased sales and increased cost of goods sold. Further, the Company has experienced, and could again experience, increased material cost inflation and component shortages, as well as disruptions and delays in its supply chain, as a result of global macroeconomic trends including the imposition of tariffs and other restrictive trade measures, as well as geopolitical and economic tensions. The net effect of these events will depend on the Company’s ability to successfully mitigate and offset their impact.

[0000833444-25-000032:mdna:13]
The Company is currently taking actions to mitigate the actual and anticipated impact of these events, including strengthening the Company's in region, for region manufacturing strategy, pivoting to local sourcing in its supply chain, accelerating pricing actions and asserting contractual rights through change orders. The Company has historically taken a variety of actions to mitigate trade restrictions, supply chain disruptions and inflation, including through expanding and redistributing its supplier network, supplier financing, accelerated purchasing and productivity improvements. These actions have historically been successful in offsetting some, but not all, of the impact of these trends, and it is uncertain as to whether the actions taken or contemplated to be taken by the Company will be effective in mitigating the impact of current and future trade restrictions and their related impacts. The Company continues to actively monitor and evaluate the development and potential impacts of tariffs and other trade restrictions on its supply chain and results of operations.

[0000833444-25-000032:mdna:14]
As a result of the Company’s global presence, a significant portion of its revenues and expenses are denominated in currencies other than the U.S. dollar, which results in non-U.S. currency risks and exchange exposure. While the Company employs financial instruments to hedge some of its transactional foreign exchange exposure, these activities do not insulate it completely from those exposures. In addition, currency exposure from the translation of non-U.S. dollar functional currency subsidiaries cannot be hedged. Exchange rates can be volatile and a substantial weakening or strengthening of foreign currencies against the U.S. dollar could increase or reduce the Company’s profit margin, respectively, and impact the comparability of results from period to period. Revenue and profits were negatively impacted by movements in foreign exchange rates against the U.S. dollar during the three and six months ended March 31, 2025.

[0000833444-25-000032:mdna:15]
The Company continues to observe trends demonstrating increased interest and demand for its products and services that enable smart, safe, efficient and sustainable buildings, which are driven in part by government tax incentives, building performance standards and other regulations designed to limit emissions and combat climate change. In particular, legislative and regulatory initiatives such as the EU Energy Efficiency Directive, U.S. Inflation Reduction Act and EU Energy Performance of Buildings Directive include provisions designed to fund and encourage investment in decarbonization and digital technologies for buildings. This demand is supplemented by an increase in commitments in both the public and private sectors to reduce emissions and/or achieve net zero emissions. The Company seeks to capitalize on these trends to enable delivery of sustainable, high-efficiency products and tailored services to enable customers to achieve their sustainability goals. The Company is leveraging its install base, together with data-driven products and services, to offer outcome-based solutions to customers with a focus on generating accelerated growth in services and recurring revenue.

[0000833444-25-000032:mdna:16]
Recently, certain of our customers, including governmental and institutional customers, have exhibited increased uncertainty regarding future spending decisions due to various political and economic factors, including budget reductions, reprioritization of spending, interest rate fluctuation and economic uncertainty. This uncertainty has and may in the future impact the Company's ability to predict and forecast the revenue and backlog associated with these customers.

[0000833444-25-000032:mdna:17]
The extent to which the Company’s results of operations and financial condition are impacted by these and other factors in the future will depend on developments that are highly uncertain and cannot be predicted. See the section entitled "Risk Factors" in Johnson Controls' Annual Report on Form 10-K for the year ended September 30, 2024 filed with the United States Securities and Exchange Commission ("SEC") on November 19, 2024. Certain of these risk factors have been updated and supplemented in the Company's Quarterly Report on Form 10-Q for the quarter ended December 31, 2024 filed on February 5, 2025 and in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0000833444-25-000032:mdna:18]
[same as prior period, unchanged from 0000833444-25-000011:mdna:16]

[0000833444-25-000032:mdna:19]
The Company continues to engage in an ongoing evaluation of its non-core product lines in connection with its objective to be a pure-play provider of comprehensive solutions for commercial buildings. During the fourth quarter of fiscal 2024, the Company entered into a definitive agreement to sell its Residential and Light Commercial ("R&LC") HVAC business to Robert Bosch GmbH (“Bosch”) for approximately $8.1 billion in cash with the Company's portion of the aggregate consideration being approximately $6.7 billion, inclusive of an upfront royalty payment for the licensing of the York tradename. The R&LC HVAC business includes the Company's North America Ducted business and Johnson Controls-Hitachi Air Conditioning Holding (UK) Ltd., the Company’s global residential joint venture with Hitachi Global Life Solutions, Inc. (“Hitachi”), of which the Company owns 60% and Hitachi owns 40%. The R&LC HVAC business, which was previously reported in the Global Products segment, meets the criteria to be classified as a discontinued operation and, as a result, its historical financial results are reflected in the consolidated financial statements as a discontinued operation, and assets and liabilities were reclassified as held for sale for all periods presented. The Company expects that the sale of the R&LC HVAC business will close in the second half of fiscal 2025.

[0000833444-25-000032:mdna:20]
[same as prior period, unchanged from 0000833444-25-000011:mdna:18]

[0000833444-25-000032:mdna:21]
During the fourth quarter of fiscal 2024, the Company committed to a multi-year restructuring plan to address stranded costs and further right-size its global operations as a result of previously announced portfolio simplification actions. It is expected that one-time restructuring costs, including severance and other employee termination benefits, contract termination costs, and certain other related cash and non-cash charges, of approximately $400 million will be incurred over the course of fiscal 2025, 2026 and 2027, resulting in expected annual cost savings of approximately $500 million upon full completion of the plan. The Company’s ability to execute the most significant aspects of the restructuring plan will be dependent on the timing of the close of the R&LC HVAC business divestiture transaction. Accordingly, the Company is unable to estimate the specific costs to be

[0000833444-25-000032:mdna:22]
38

[0000833444-25-000032:mdna:23]
incurred and savings to be achieved in fiscal 2025; however, depending on the finalization of the carve-out of the R&LC HVAC business, including post-closing separation obligations, the timing of the closing of the transaction and the ability to execute more significant aspects of the planned restructuring actions, the impact of costs on net income could be material in fiscal 2025. Restructuring costs will be incurred across all segments and Corporate functions.

[0000833444-25-000032:mdna:24]
[same as prior period, unchanged from 0000833444-25-000011:mdna:20]

[0000833444-25-000032:mdna:25]
During the weekend of September 23, 2023, the Company experienced a cybersecurity incident impacting its internal information technology ("IT") infrastructure and applications.

[0000833444-25-000032:mdna:26]
[same as prior period, unchanged from 0000833444-25-000011:mdna:22]

[0000833444-25-000032:mdna:27]
[same as prior period, unchanged from 0000833444-25-000011:mdna:23]

[0000833444-25-000032:mdna:28]
[same as prior period, unchanged from 0000833444-25-000011:mdna:24]

[0000833444-25-000032:mdna:29]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
| (in millions) | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
| Net sales | $ | 5,676 |  |  | $ | 5,597 |  |  | 1 | % |  | $ | 11,102 |  |  | $ | 10,806 |  |  | 3 | % |

[0000833444-25-000032:mdna:30]
The increase in net sales for the three months ended March 31, 2025 was due to higher organic sales ($381 million), partially offset by the net impact of acquisitions and divestitures ($233 million) and the unfavorable impact of foreign currency translation ($69 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, net sales increased 7% over the prior year, driven by strong growth in Products and Systems in the Building Solutions North America, Building Solutions Asia Pacific and Global Products segments and growth in Services in all Building Solutions segments.

[0000833444-25-000032:mdna:31]
The increase in net sales for the six months ended March 31, 2025 was due to higher organic sales ($861 million), partially offset by the net impact of acquisitions and divestitures ($463 million) and the unfavorable impact of foreign currency translation ($102 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, net sales increased 8% over the prior year, driven by strong growth in Products and Systems in the Building Solutions North America, Building Solutions Asia Pacific and Global Products segments and growth in Services in all Building Solutions segments.

[0000833444-25-000032:mdna:32]
[same as prior period, unchanged from 0000833444-25-000011:mdna:27]

[0000833444-25-000032:mdna:33]
[same as prior period, unchanged from 0000833444-25-000011:mdna:28]

[0000833444-25-000032:mdna:34]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
| (in millions) | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
| Cost of sales | $ | 3,607 |  |  | $ | 3,675 |  |  | (2 | %) |  | $ | 7,107 |  |  | $ | 7,106 |  |  | — | % |
| Gross profit | 2,069 |  |  | 1,922 |  |  | 8 | % |  | 3,995 |  |  | 3,700 |  |  | 8 | % |
| % of sales | 36.5 | % |  | 34.3 | % |  | 220 | bp |  | 36.0 | % |  | 34.2 | % |  | 180 | bp |

[0000833444-25-000032:mdna:35]
The increase in gross profit for the three and six months ended March 31, 2025 was primarily due to margin improvements in the Building Solutions segments as a result of converting backlog with increased mix of long-term, higher margin Systems projects and optimized Services mix.

[0000833444-25-000032:mdna:36]
[same as prior period, unchanged from 0000833444-25-000011:mdna:31]

[0000833444-25-000032:mdna:37]
[same as prior period, unchanged from 0000833444-25-000011:mdna:32]

[0000833444-25-000032:mdna:38]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
| (in millions) | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
| SG&A | $ | 1,427 |  |  | $ | 2,064 |  |  | (31 | %) |  | $ | 2,826 |  |  | $ | 3,398 |  |  | (17 | %) |
| % of sales | 25.1 | % |  | 36.9 | % |  | (1,180) | bp |  | 25.5 | % |  | 31.4 | % |  | (590) | bp |

[0000833444-25-000032:mdna:39]
For the three months ended March 31, 2025, the decrease in SG&A was primarily due to the favorable impact of the prior year water systems AFFF settlement agreement costs ($750 million), partially offset by higher transformation costs ($46 million) and the impact of net mark-to-market adjustments ($28 million).

[0000833444-25-000032:mdna:40]
For the six months ended March 31, 2025, the decrease in SG&A was primarily due to the favorable impact of the prior year water systems AFFF settlement agreement costs ($750 million), partially offset by higher transformation costs ($79 million) and the impact of net mark-to-market adjustments ($51 million).

[0000833444-25-000032:mdna:41]
Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA. Refer to Note 18, "Commitments and Contingencies," of the notes to the consolidated financial statements for further disclosure related to the water systems AFFF settlement.

[0000833444-25-000032:mdna:42]
[same as prior period, unchanged from 0000833444-25-000011:mdna:36]

[0000833444-25-000032:mdna:43]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
| (in millions) | 2025 |  | 2024 |  |  |  | 2025 |  | 2024 |  |
| Goodwill and other intangible asset impairments | $ | 22 |  |  | $ | 230 |  |  |  |  | $ | 22 |  |  | $ | 230 |  |  |
| Restructuring and related costs | 40 |  |  | 9 |  |  |  |  | 73 |  |  | 44 |  |  |
| Restructuring and impairment costs | $ | 62 |  |  | $ | 239 |  |  |  |  | $ | 95 |  |  | $ | 274 |  |  |

[0000833444-25-000032:mdna:44]
[same as prior period, unchanged from 0000833444-25-000011:mdna:38]

[0000833444-25-000032:mdna:45]
[same as prior period, unchanged from 0000833444-25-000011:mdna:39]

[0000833444-25-000032:mdna:46]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
| (in millions) | 2025 |  | 2024 |  |  |  | 2025 |  | 2024 |  |  |
| Interest expense, net of capitalized interest costs | $ | 56 |  |  | $ | 96 |  |  |  |  | $ | 123 |  |  | $ | 182 |  |  |  |
| Other financing charges | 4 |  |  | 4 |  |  |  |  | 10 |  |  | 26 |  |  |  |
| Interest income | (2) |  |  | (5) |  |  |  |  | (5) |  |  | (10) |  |  |  |
| Net foreign exchange results for financing activities | 22 |  |  | (6) |  |  |  |  | 38 |  |  | (22) |  |  |  |
| Net financing charges | $ | 80 |  |  | $ | 89 |  |  |  |  | $ | 166 |  |  | $ | 176 |  |  |  |

[0000833444-25-000032:mdna:47]
[same as prior period, unchanged from 0000833444-25-000011:mdna:41]

[0000833444-25-000032:mdna:48]
40

[0000833444-25-000032:mdna:49]
[same as prior period, unchanged from 0000833444-25-000011:mdna:42]

[0000833444-25-000032:mdna:50]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
| (in millions) | 2025 |  | 2024 |  |  |  | 2025 |  | 2024 |  |  |
| Income tax provision (benefit) | $ | 26 |  |  | $ | (153) |  |  |  |  | $ | 73 |  |  | $ | (173) |  |  |  |
| Effective tax rate | 5.2 | % |  | 32.5 | % |  |  |  | 8.0 | % |  | 114.6 | % |  |  |

[0000833444-25-000032:mdna:51]
[same as prior period, unchanged from 0000833444-25-000011:mdna:44]

[0000833444-25-000032:mdna:52]
[same as prior period, unchanged from 0000833444-25-000011:mdna:45]

[0000833444-25-000032:mdna:53]
[same as prior period, unchanged from 0000833444-25-000011:mdna:46]

[0000833444-25-000032:mdna:54]
[same as prior period, unchanged from 0000833444-25-000011:mdna:47]

[0000833444-25-000032:mdna:55]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
| (in millions) | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
| Building Solutions North America | $ | 2,916 |  |  | $ | 2,739 |  |  | 6 | % |  | $ | 5,660 |  |  | $ | 5,226 |  |  | 8 | % |
| Building Solutions EMEA/LA | 1,085 |  |  | 1,064 |  |  | 2 | % |  | 2,158 |  |  | 2,102 |  |  | 3 | % |
| Building Solutions Asia Pacific | 542 |  |  | 491 |  |  | 10 | % |  | 1,069 |  |  | 998 |  |  | 7 | % |
| Global Products | 1,133 |  |  | 1,303 |  |  | (13 | %) |  | 2,215 |  |  | 2,480 |  |  | (11 | %) |
|  | $ | 5,676 |  |  | $ | 5,597 |  |  | 1 | % |  | $ | 11,102 |  |  | $ | 10,806 |  |  | 3 | % |

[0000833444-25-000032:mdna:56]
Three Months:

[0000833444-25-000032:mdna:57]
•The increase in Building Solutions North America was primarily due to organic growth ($187 million), partially offset by the unfavorable impact of foreign currency translation ($10 million). Excluding the impact of foreign currency translation, sales growth was led by continued strength across Applied HVAC and Controls. Products and Systems sales increased 8% and Services increased 5%.

[0000833444-25-000032:mdna:58]
•The increase in Building Solutions EMEA/LA was primarily due to organic growth ($48 million) and incremental sales related to business acquisitions ($9 million), partially offset by the unfavorable impact of foreign currency translation ($36 million). Excluding the impact of business acquisitions and foreign currency translation, sales growth was primarily led by 9% growth in Services.

[0000833444-25-000032:mdna:59]
•The increase in Building Solutions Asia Pacific was primarily due to organic growth ($62 million), partially offset by the unfavorable impact of foreign currency translation ($11 million). Excluding the impact of foreign currency translation, sales growth was led by 15% growth in Services and 12% growth in Products and Systems.

[0000833444-25-000032:mdna:60]
•The decrease in Global Products was primarily due to the impact of business divestitures ($242 million) and the unfavorable impact of foreign currency translation ($12 million), partially offset by organic growth ($84 million). Excluding the impact of business divestitures and foreign currency, sales increased 8%, led by positive price and volume growth. Applied HVAC grew over 20%.

[0000833444-25-000032:mdna:61]
Year to Date:

[0000833444-25-000032:mdna:62]
•The increase in Building Solutions North America was primarily due to organic growth ($447 million), partially offset by the unfavorable impact of foreign currency translation ($13 million). Excluding the impact of foreign currency translation, sales growth was led by growth in Applied HVAC and Controls.

[0000833444-25-000032:mdna:63]
•The increase in Building Solutions EMEA/LA was primarily due to organic growth ($105 million) and incremental sales related to business acquisitions ($12 million), partially offset by the unfavorable impact of foreign currency translation ($61 million). Excluding the impact of business acquisitions and foreign currency translation, sales growth was primarily led by growth in Services.

[0000833444-25-000032:mdna:64]
•The increase in Building Solutions Asia Pacific was primarily due to organic growth ($85 million), partially offset by the unfavorable impact of foreign currency translation ($14 million). Excluding the impact of foreign currency translation, sales growth was led by strong growth in Services as well as growth in Products and Systems.

[0000833444-25-000032:mdna:65]
•The decrease in Global Products was primarily due to the impact of business divestitures ($475 million) and the unfavorable impact of foreign currency translation ($14 million), partially offset by organic growth ($224 million). Excluding the impact of business divestitures and foreign currency, sales growth was led by positive price and volume growth, including strong growth in Applied HVAC.

[0000833444-25-000032:mdna:66]
[same as prior period, unchanged from 0000833444-25-000011:mdna:53]

[0000833444-25-000032:mdna:67]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
| (in millions) | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
| Building Solutions North America | $ | 390 |  |  | $ | 373 |  |  | 5 | % |  | $ | 722 |  |  | $ | 658 |  |  | 10 | % |
| Building Solutions EMEA/LA | 136 |  |  | 89 |  |  | 53 | % |  | 244 |  |  | 169 |  |  | 44 | % |
| Building Solutions Asia Pacific | 79 |  |  | 54 |  |  | 46 | % |  | 128 |  |  | 100 |  |  | 28 | % |
| Global Products | 341 |  |  | 290 |  |  | 18 | % |  | 667 |  |  | 557 |  |  | 20 | % |

[0000833444-25-000032:mdna:68]
Three Months:

[0000833444-25-000032:mdna:69]
•The increase in Building Solutions North America was primarily due to higher margin backlog conversion and productivity improvements.

[0000833444-25-000032:mdna:70]
[same as prior period, unchanged from 0000833444-25-000011:mdna:56]

[0000833444-25-000032:mdna:71]
•The increase in Building Solutions Asia Pacific was primarily driven by productivity improvements.

[0000833444-25-000032:mdna:72]
•The increase in Global Products was primarily due to improved operational efficiencies, which more than offset the impact of divestitures.

[0000833444-25-000032:mdna:73]
Year to Date:

[0000833444-25-000032:mdna:74]
•The increase in Building Solutions North America was primarily due to higher margin backlog conversion and productivity improvements, partially offset by impacts from ongoing growth investments.

[0000833444-25-000032:mdna:75]
•The increase in Building Solutions EMEA/LA was primarily driven by productivity improvements and positive mix from the growth in Services.

[0000833444-25-000032:mdna:76]
•The increase in Building Solutions Asia Pacific was primarily driven by productivity improvements.

[0000833444-25-000032:mdna:77]
•The increase in Global Products was primarily due to increased volumes and improved operational efficiencies, which more than offset the impact of divestitures.

[0000833444-25-000032:mdna:78]
[same as prior period, unchanged from 0000833444-25-000011:mdna:59]

[0000833444-25-000032:mdna:79]
Backlog and orders are additional metrics that are meant to provide management with a deeper level of insight into the progress of specific strategic and growth initiatives. Backlog is applicable to sales of products and systems and services and totaled $16.0 billion at March 31, 2025, including both the Building Solutions and Global Products segments. Orders provide management with a signal of customer demand for the Company's products and services, as well as an indication of future revenues and performance. However, the timing and conversion of backlog and orders are subject to numerous uncertainties and risks and are not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-25-000032:mdna:80]
[same as prior period, unchanged from 0000833444-25-000011:mdna:62]

[0000833444-25-000032:mdna:81]
|  | Backlog |  | Orders |
| (in billions) | March 31, 2025 |  |  |  | Year-over-Year Change (1) |  | Three Months Ended March 31, 2025 |  |  |  | Year-over-Year Change (1) |
| Building Solutions North America | $ | 9.8 |  |  |  |  | 11 | % |  | $ | 3.4 |  |  |  |  | 4 | % |
| Building Solutions EMEA/LA | 2.7 |  |  |  |  | 10 | % |  | 1.2 |  |  |  |  | 10 | % |
| Building Solutions Asia Pacific | 1.5 |  |  |  |  | 21 | % |  | 0.6 |  |  |  |  | — | % |
| Total Building Solutions | $ | 14.0 |  |  |  |  | 12 | % |  | $ | 5.2 |  |  |  |  | 5 | % |

[0000833444-25-000032:mdna:82]
(1) Change is compared to March 31, 2024 (backlog) and the three months ended March 31, 2024 (orders) and excludes the impact of mergers, acquisitions, divestitures and foreign currency.

[0000833444-25-000032:mdna:83]
Remaining performance obligations were $22.0 billion at March 31, 2025. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-25-000032:mdna:84]
[same as prior period, unchanged from 0000833444-25-000011:mdna:66]

[0000833444-25-000032:mdna:85]
[same as prior period, unchanged from 0000833444-25-000011:mdna:67]

[0000833444-25-000032:mdna:86]
[same as prior period, unchanged from 0000833444-25-000011:mdna:68]

[0000833444-25-000032:mdna:87]
[same as prior period, unchanged from 0000833444-25-000011:mdna:69]

[0000833444-25-000032:mdna:88]
[same as prior period, unchanged from 0000833444-25-000011:mdna:70]

[0000833444-25-000032:mdna:89]
| (in millions) | March 31, 2025 |  | September 30, 2024 |  | Change |
| Current assets | $ | 11,350 |  |  | $ | 11,179 |  |  |  |
| Current liabilities | 11,817 |  |  | 11,955 |  |  |  |
| Working capital | $ | (467) |  |  | $ | (776) |  |  | (40) | % |
| Accounts receivable - net | $ | 5,858 |  |  | $ | 6,051 |  |  | (3) | % |
| Inventories | 1,756 |  |  | 1,774 |  |  | (1) | % |
| Accounts payable | 3,254 |  |  | 3,389 |  |  | (4) | % |

[0000833444-25-000032:mdna:90]
•The increase in working capital at March 31, 2025 as compared to September 30, 2024 was primarily due to a decrease in other current liabilities due to a payment related to the AFFF settlement agreement and an increase in current assets held for sale primarily due to seasonal increases in inventory related to the R&LC HVAC business, partially offset by higher short-term debt and the net impact of various other current assets and liabilities.

[0000833444-25-000032:mdna:91]
[same as prior period, unchanged from 0000833444-25-000011:mdna:74]

[0000833444-25-000032:mdna:92]
|  |  | Six Months Ended March 31, |
| (in millions) |  | 2025 |  | 2024 |
| Cash provided (used) by operating activities |  | $ | 799 |  |  | $ | (437) |  |
| Cash used by investing activities |  | (217) |  |  | (196) |  |
| Cash provided (used) by financing activities |  | (474) |  |  | 740 |  |

[0000833444-25-000032:mdna:93]
•The increase in cash provided by operating activities reflects higher net income, decreases in accounts receivable and higher cash used for inventory in fiscal 2024, partially offset by the timing of accounts payable and accrued liabilities payments.

[0000833444-25-000032:mdna:94]
•The increase in cash used by investing activities was due to various investment transactions.

[0000833444-25-000032:mdna:95]
•The increase in cash used by financing activities was primarily due to changes in net debt activity and higher share repurchases, which were temporarily halted in the first quarter of fiscal 2024.

[0000833444-25-000032:mdna:96]
[same as prior period, unchanged from 0000833444-25-000011:mdna:79]

[0000833444-25-000032:mdna:97]
| (in millions) | March 31, 2025 |  | September 30, 2024 |  |  |
| Short-term debt | $ | 1,261 |  |  | $ | 953 |  |  |  |
| Current portion of long-term debt | 558 |  |  | 536 |  |  |  |
| Long-term debt | 8,167 |  |  | 8,004 |  |  |  |
| Total debt | 9,986 |  |  | 9,493 |  |  |  |
| Less: Cash and cash equivalents | 795 |  |  | 606 |  |  |  |
| Net debt | $ | 9,191 |  |  | $ | 8,887 |  |  |  |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders ("Equity") | $ | 15,805 |  |  | $ | 16,098 |  |  |  |
| Total capitalization (Total debt plus Equity) | 25,791 |  |  | 25,591 |  |  |  |
| Net capitalization (Net debt plus Equity) | 24,996 |  |  | 24,985 |  |  |  |
| Total debt as a % of Total capitalization | 38.7 | % |  | 37.1 | % |  |  |
| Net debt as a % of Net capitalization | 36.8 | % |  | 35.6 | % |  |  |

[0000833444-25-000032:mdna:98]
[same as prior period, unchanged from 0000833444-25-000011:mdna:81]

[0000833444-25-000032:mdna:99]
•As of March 31, 2025, approximately $1.1 billion remains available under the Company's share repurchase authorization, which does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. The Company expects to repurchase outstanding shares from time to time depending on market conditions, alternate uses of capital, liquidity, and the economic environment.

[0000833444-25-000032:mdna:100]
•The Company declared a dividend of $0.37 per common share in the quarter ended March 31, 2025 and intends to continue paying dividends throughout fiscal 2025.

[0000833444-25-000032:mdna:101]
•The Company expects to receive net cash proceeds related to the sale of its R&LC HVAC business of approximately $5.0 billion after tax and transaction-related expenses when the transaction closes, likely in the second half of fiscal 2025. Consistent with its capital allocation policy, the Company expects to use a portion of the proceeds to pay down debt to the extent required to retain its investment grade rating, with the remaining proceeds expected to be returned to shareholders through share repurchases.

[0000833444-25-000032:mdna:102]
44

[0000833444-25-000032:mdna:103]
•The Company believes its capital resources and liquidity position, including cash and cash equivalents of $0.8 billion at March 31, 2025, are adequate to fund operations and meet its cash obligations for the foreseeable future.

[0000833444-25-000032:mdna:104]
–The Company manages its short-term debt position in the U.S. and euro commercial paper and bank loan markets. Commercial paper outstanding totaled $673 million as of March 31, 2025 and $350 million as of September 30, 2024.

[0000833444-25-000032:mdna:105]
–The Company maintains a shelf registration statement with the SEC under which it may issue additional debt securities, ordinary shares, preferred shares, depository shares, warrants, purchase contracts and units that may be offered in one or more offerings on terms to be determined at the time of the offering. The Company anticipates that the proceeds of any offering would be used for general corporate purposes, including repayment of indebtedness, acquisitions, additions to working capital, repurchases of ordinary shares, dividends, capital expenditures and investments in the Company's subsidiaries.

[0000833444-25-000032:mdna:106]
–The Company also has the ability to draw on its $2.5 billion revolving credit facility which is scheduled to expire in December 2028 or its $0.5 billion revolving credit facility which is scheduled to expire in December 2025. There were no draws on the revolving credit facilities as of March 31, 2025 and September 30, 2024.

[0000833444-25-000032:mdna:107]
•The Company's ability to access the global capital markets and the related cost of financing is dependent upon, among other factors, the Company's credit ratings. As of March 31, 2025, the Company's credit ratings and outlook were as follows:

[0000833444-25-000032:mdna:108]
[same as prior period, unchanged from 0000833444-25-000011:mdna:90]

[0000833444-25-000032:mdna:109]
[same as prior period, unchanged from 0000833444-25-000011:mdna:91]

[0000833444-25-000032:mdna:110]
•Financial covenants in the Company's revolving credit facilities require a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of March 31, 2025, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures governing its notes, and expects to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-25-000032:mdna:111]
•The Company earns a significant amount of its income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances. However, in the first quarter of fiscal 2024, the Company recorded income tax expense related to a change in the Company's assertion over the outside basis differences of the Company’s investment in certain consolidated subsidiaries as a result of the planned divestiture of its R&LC HVAC business. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. The Company's intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve

[0000833444-25-000032:mdna:112]
months and thereafter for the foreseeable future. Should the Company require more capital at its Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings.

[0000833444-25-000032:mdna:113]
[same as prior period, unchanged from 0000833444-25-000011:mdna:95]

[0000833444-25-000032:mdna:114]
[same as prior period, unchanged from 0000833444-25-000011:mdna:96]

[0000833444-25-000032:mdna:115]
[same as prior period, unchanged from 0000833444-25-000011:mdna:97]

[0000833444-25-000032:mdna:116]
[same as prior period, unchanged from 0000833444-25-000011:mdna:98]

[0000833444-25-000032:mdna:117]
•€500 million aggregate principal amount of 0.375% Senior Notes due 2027

[0000833444-25-000032:mdna:118]
•€600 million aggregate principal amount of 3.000% Senior Notes due 2028

[0000833444-25-000032:mdna:119]
•$700 million aggregate principal amount of 5.500% Senior Notes due 2029

[0000833444-25-000032:mdna:120]
•$625 million aggregate principal amount of 1.750% Senior Notes due 2030

[0000833444-25-000032:mdna:121]
•$500 million aggregate principal amount of 2.000% Sustainability-Linked Senior Notes due 2031

[0000833444-25-000032:mdna:122]
•€500 million aggregate principal amount of 1.000% Senior Notes due 2032

[0000833444-25-000032:mdna:123]
•$650 million aggregate principal amount of 4.900% Senior Notes due 2032

[0000833444-25-000032:mdna:124]
•€500 million aggregate principal amount of 3.125% Senior Notes due 2033

[0000833444-25-000032:mdna:125]
•€800 million aggregate principal amount of 4.250% Senior Notes due 2035

[0000833444-25-000032:mdna:126]
[same as prior period, unchanged from 0000833444-25-000011:mdna:108]

[0000833444-25-000032:mdna:127]
[same as prior period, unchanged from 0000833444-25-000011:mdna:109]

[0000833444-25-000032:mdna:128]
|  |  | Six Months Ended March 31, 2025 |  | Year Ended September 30, 2024 |  |
| Net loss attributable to the Obligor Group |  | $ | (374) |  |  | $ | (609) |  |  |
| Net income (loss) attributable to intercompany transactions |  | (27) |  |  | 511 |  |  |

[0000833444-25-000032:mdna:129]
[same as prior period, unchanged from 0000833444-25-000011:mdna:111]

[0000833444-25-000032:mdna:130]
46

[0000833444-25-000032:mdna:131]
[same as prior period, unchanged from 0000833444-25-000011:mdna:112]

[0000833444-25-000032:mdna:132]
|  |  | Obligor Group |  | Intercompany Balances |
|  |  | March 31, 2025 |  | September 30, 2024 |  | March 31, 2025 |  | September 30, 2024 |
| Current assets |  | $ | 66 |  |  | $ | 1,339 |  |  | $ | 693 |  |  | $ | 823 |  |
| Noncurrent assets |  | 243 |  |  | 243 |  |  | 9,362 |  |  | 7,522 |  |
| Current liabilities |  | 8,379 |  |  | 6,726 |  |  | 3,298 |  |  | 2,789 |  |
| Noncurrent liabilities |  | 8,031 |  |  | 7,836 |  |  | 8,306 |  |  | 9,028 |  |

[0000833444-25-000032:mdna:133]
[same as prior period, unchanged from 0000833444-25-000011:mdna:114]

[0000833444-25-000032:mdna:134]
[same as prior period, unchanged from 0000833444-25-000011:mdna:115]

[0000833444-25-000032:mdna:135]
[same as prior period, unchanged from 0000833444-25-000011:mdna:116]

[0000833444-25-000032:mdna:136]
[same as prior period, unchanged from 0000833444-25-000011:mdna:117]

[0000833444-25-000032:mdna:137]
[same as prior period, unchanged from 0000833444-25-000011:mdna:118]
