# JCI note change history — 0000833444-25-000011 → 0000833444-25-000032


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0000833444-25-000032:note_history:1]
|  | March 31, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 25 |  |  | $ | 32 |  |
| Other noncurrent liabilities | 174 |  |  | 179 |  |
| Total reserves for environmental liabilities | $ | 199 |  |  | $ | 211 |  |
  (was, 2025-02-05, similarity 0.9731):
[0000833444-25-000011:note_history:1]
|  | December 31, 2024 |  | September 30, 2024 |
| Other current liabilities | $ | 28 |  |  | $ | 32 |  |
| Other noncurrent liabilities | 175 |  |  | 179 |  |
| Total reserves for environmental liabilities | $ | 203 |  |  | $ | 211 |  |

- changed (2025-05-07):
[0000833444-25-000032:note_history:2]
A substantial portion of the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to Aqueous Film Forming Foam ("AFFF") containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). During the three months ended June 30, 2024, Tyco Fire Products completed its previously announced plan to discontinue the production and sale of fluorinated firefighting foams, including AFFF products, and has transitioned to non-fluorinated foam alternatives.
  (was, 2025-02-05, similarity 0.852):
[0000833444-25-000011:note_history:2]
A substantial portion of the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to Aqueous Film Forming Foam ("AFFF") containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).

- changed (2025-05-07):
[0000833444-25-000032:note_history:3]
PFOA, PFOS, and other PFAS compounds are being studied by the U.S. Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. In April 2024, EPA published National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR established legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion ("ppt") for each of PFOA and PFOS, 10 ppt for each of PFHxS, PFNA, and HFPO-DA (commonly known as GenX Chemicals), and a Hazard Index of one for mixtures containing two or more of PFHxS, PFNA, HFPO-DA, and PFBA. In February 2024, EPA released two proposed rules relating to PFAS under the Resource Conservation and Recovery Act (“RCRA”): one rule proposes to list nine PFAS (including PFOA and PFOS) as “hazardous constituents,” and a second rule proposes to clarify that hazardous waste regulated under the rule includes not only substances listed or identified as hazardous waste in the regulations, but also any substances that meet the statutory definition of hazardous waste. In April 2024, EPA finalized a rule designating PFOA and PFOS, along with their salts and structural isomers, as "hazardous substances" under the Comprehensive Environmental Response, Compensation and Liability Act ("CERCLA").
  (was, 2025-02-05, similarity 0.7979):
[0000833444-25-000011:note_history:3]
PFOS and PFOA in drinking water. On April 10, 2024, EPA announced the final National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR established legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion ("ppt") for each of PFOA and PFOS, 10 ppt for each of PFHxS, PFNA, and HFPO-DA (commonly known as GenX Chemicals), and a Hazard Index of one for mixtures containing two or more of PFHxS, PFNA, HFPO-DA, and PFBA. In February 2024, EPA released two proposed rules relating to PFAS under the Resource Conservation and Recovery Act (“RCRA”): one rule proposes to list nine PFAS (including PFOA and PFOS) as “hazardous constituents,” and a second rule proposes to clarify that hazardous waste regulated under the rule includes not only substances listed or identified as hazardous waste in the regulations, but also any substances that meet the statutory definition of hazardous waste.

- changed (2025-05-07):
[0000833444-25-000032:note_history:4]
It is not possible to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in soil, groundwater and drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future
  (was, 2025-02-05, similarity 0.8931):
[0000833444-25-000011:note_history:4]
It is not possible to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in soil, groundwater and drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- added (2025-05-07):
[0000833444-25-000032:note_history:5]
results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- changed (2025-05-07):
[0000833444-25-000032:note_history:6]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $7 million at both March 31, 2025 and September 30, 2024.
  (was, 2025-02-05, similarity 0.9787):
[0000833444-25-000011:note_history:6]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $7 million at both December 31, 2024 and September 30, 2024.

- changed (2025-05-07):
[0000833444-25-000032:note_history:7]
FTC and Stanton Street Remediation
  (was, 2025-02-05, similarity 0.6122):
[0000833444-25-000011:note_history:7]
FTC Remediation

- changed (2025-05-07):
[0000833444-25-000032:note_history:8]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere.
  (was, 2025-02-05, similarity 0.7156):
[0000833444-25-000011:note_history:8]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. During the three months ended June 30, 2024, Tyco Fire Products completed its previously announced plan to discontinue the production and sale of fluorinated firefighting foams, including AFFF products, and has transitioned to non-fluorinated foam alternatives.

- changed (2025-05-07):
[0000833444-25-000032:note_history:9]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the EPA to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.
  (was, 2025-02-05, similarity 0.848):
[0000833444-25-000011:note_history:9]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the EPA to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and

- added (2025-05-07):
[0000833444-25-000032:note_history:10]
Tyco Fire Products is operating and monitoring at the FTC a Groundwater Extraction and Treatment System ("GETS"), a permanent groundwater remediation system that extracts groundwater containing PFAS, treats it using advanced filtration systems, and returns the treated water to the environment. Tyco Fire Products has also completed the removal and disposal of PFAS-affected soil from the FTC. The Company is also continuing to replace private drinking water wells that may have been impacted by PFAS migrating from the FTC. The Company's reserves for continued remediation of the FTC, the Stanton Street Facility and surrounding areas in Marinette and Peshtigo are based on estimates of costs associated with the long-term remediation actions, including the continued operation of the GETS, the implementation of long-term drinking water solutions for the area impacted by groundwater migrating from the FTC, continued monitoring and testing of groundwater monitoring wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

- added (2025-05-07):
[0000833444-25-000032:note_history:11]
Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water in February 2022. In August 2024, WDNR issued a new proposed rule to adopt the EPA Maximum Contaminant Levels for PFAS in drinking water. In February 2025, the Wisconsin Department of Health Services ("WDHS") recommended individual groundwater enforcement standards of 4 ng/L for PFOA and PFOS, 10 ng/L for PFHxS, PFNA, and HFPO-DA, and 2,000 ng/L for PFBS. Following the February 2025 WDHS recommendation, the WDNR Secretary and the Governor signed the WDNR scope statement and WDNR is in the early stages of rule development for enforcement standards for these six PFAS constituents.

- added (2025-05-07):
[0000833444-25-000032:note_history:12]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. On October 16, 2019, the WDNR issued a

- changed (2025-05-07):
[0000833444-25-000032:note_history:13]
“Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to that date. On April 10, 2023, the WDNR issued a third “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids in the Marinette region. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions, including the potential assessment of penalties.
  (was, 2025-02-05, similarity 0.8391):
[0000833444-25-000011:note_history:13]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. The WDNR issued a further letter regarding the issue on November 4, 2019. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to that date. On April 10, 2023, the WDNR issued a third “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids in the Marinette region. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions, including the potential assessment of penalties.

- changed (2025-05-07):
[0000833444-25-000032:note_history:14]
Chemguard and Tyco Fire Products are named in 46 pending putative class actions in federal courts originating from 19 states and territories. All of these cases have been direct-filed in or transferred to the MDL. In addition, six proposed class actions were filed in Canada (British Columbia, Manitoba, Quebec and Ontario), which name Tyco Fire Products and other manufacturers as defendants, on behalf of various classes of members (including individuals and government entities) who seek to recover for remediation (past and future) costs, claim property or other environmental damages, or claim personal injuries or other harms arising from alleged exposure to or contamination with PFAS or PFAS-containing products (including AFFF).
  (was, 2025-02-05, similarity 0.9886):
[0000833444-25-000011:note_history:14]
Chemguard and Tyco Fire Products are named in 45 pending putative class actions in federal courts originating from 18 states and territories. All of these cases have been direct-filed in or transferred to the MDL. In addition, six proposed class actions were filed in Canada (British Columbia, Manitoba, Quebec and Ontario) in the past year, which name Tyco Fire Products and other manufacturers as defendants, on behalf of various classes of members (including individuals and government entities) who seek to recover for remediation (past and future) costs, claim property or other environmental damages, or claim personal injuries or other harms arising from alleged exposure to or contamination with PFAS or PFAS-containing products (including AFFF).

- changed (2025-05-07):
[0000833444-25-000032:note_history:15]
There are more than 7,510 individual or “mass” actions pending that were filed in state or federal courts originating from 52 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 7,510 other plaintiffs. The decrease in individual actions during the three months ended March 31, 2025 reflect a court order establishing a dismissal process for cases that do not involve certain types of personal injuries. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly-filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona, Illinois and Wisconsin.
  (was, 2025-02-05, similarity 0.8967):
[0000833444-25-000011:note_history:15]
There are more than 8,800 individual or “mass” actions pending that were filed in state or federal courts originating from 52 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 8,800 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly-filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona, Illinois and Wisconsin.

- changed (2025-05-07):
[0000833444-25-000032:note_history:16]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. The State’s case has been removed to federal court and transferred to the MDL. The State of Alaska has also named a
  (was, 2025-02-05, similarity 0.8133):
[0000833444-25-000011:note_history:16]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. The State’s case has been removed to federal court and transferred to the MDL. The State of Alaska has also named a number of manufacturers and other defendants, including affiliates of the Company, as third-party defendants in two cases brought by individuals against the State. These two cases have also been transferred to the MDL.

- added (2025-05-07):
[0000833444-25-000032:note_history:17]
number of manufacturers and other defendants, including affiliates of the Company, as third-party defendants in two cases brought by individuals against the State. These two cases have also been transferred to the MDL.

- changed (2025-05-07):
[0000833444-25-000032:note_history:18]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.
  (was, 2025-02-05, similarity 0.8231):
[0000833444-25-000011:note_history:18]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and

- added (2025-05-07):
[0000833444-25-000032:note_history:19]
|  | March 31, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 344 |  |  | 350 |  |
| Total asbestos-related liabilities | 402 |  |  | 408 |  |
| Other current assets | 15 |  |  | 14 |  |
| Other noncurrent assets | 299 |  |  | 320 |  |
| Total asbestos-related assets | 314 |  |  | 334 |  |
| Net asbestos-related liabilities | $ | 88 |  |  | $ | 74 |  |

- added (2025-05-07):
[0000833444-25-000032:note_history:20]
|  | March 31, 2025 |  | September 30, 2024 |
| Restricted |  |  |  |
| Cash | $ | 7 |  |  | $ | 6 |  |
| Investments | 262 |  |  | 281 |  |
| Total restricted assets | 269 |  |  | 287 |  |
| Insurance receivables for asbestos-related liabilities | 45 |  |  | 47 |  |
| Total asbestos-related assets | $ | 314 |  |  | $ | 334 |  |

- changed (2025-05-07):
[0000833444-25-000032:note_history:21]
|  | March 31, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 99 |  |  | $ | 92 |  |
| Accrued compensation and benefits | 20 |  |  | 20 |  |
| Other noncurrent liabilities | 251 |  |  | 239 |  |
| Total self-insured liabilities | $ | 370 |  |  | $ | 351 |  |
  (was, 2025-02-05, similarity 0.9773):
[0000833444-25-000011:note_history:21]
|  | December 31, 2024 |  | September 30, 2024 |
| Other current liabilities | $ | 98 |  |  | $ | 92 |  |
| Accrued compensation and benefits | 20 |  |  | 20 |  |
| Other noncurrent liabilities | 247 |  |  | 239 |  |
| Total self-insured liabilities | $ | 365 |  |  | $ | 351 |  |

- changed (2025-05-07):
[0000833444-25-000032:note_history:22]
|  | March 31, 2025 |  | September 30, 2024 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 13 |  |  | 13 |  |
| Total insurance receivables | $ | 18 |  |  | $ | 18 |  |
  (was, 2025-02-05, similarity 0.9746):
[0000833444-25-000011:note_history:22]
|  | December 31, 2024 |  | September 30, 2024 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 13 |  |  | 13 |  |
| Total insurance receivables | $ | 18 |  |  | $ | 18 |  |

- removed (2025-05-07):
[0000833444-25-000011:note_history:23]
PFOA, PFOS, and other PFAS compounds are being studied by the U.S. Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. In March 2021, EPA published its final determination to regulate

- removed (2025-05-07):
[0000833444-25-000011:note_history:24]
In August 2022, EPA published a proposed rule that would designate PFOA and PFOS as “hazardous substances” under Comprehensive Environmental Response, Compensation and Liability Act ("CERCLA"). In April 2023, EPA issued an Advanced Notice of Proposed Rulemaking ("ANPR") seeking input on whether it should expand the proposed rule to designate as "hazardous substances" under CERCLA: (1) seven additional PFAS; (2) the precursors to PFOA, PFOS, and the seven additional PFAS; or (3) entire categories of PFAS. On April 17, 2024, the EPA Administrator signed the final rule designating PFOA and PFOS, along with their salts and structural isomers, as “hazardous substances.”

- removed (2025-05-07):
[0000833444-25-000011:note_history:25]
treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

- removed (2025-05-07):
[0000833444-25-000011:note_history:26]
Tyco Fire Products is operating and monitoring at the FTC a Groundwater Extraction and Treatment System ("GETS"), a permanent groundwater remediation system that extracts groundwater containing PFAS, treats it using advanced filtration systems, and returns the treated water to the environment. Tyco Fire Products has also completed the removal and disposal of PFAS-affected soil from the FTC. The Company's reserves for continued remediation of the FTC, the Stanton Street Facility and surrounding areas in Marinette and Peshtigo are based on estimates of costs associated with the long-term remediation actions, including the continued operation of the GETS, the implementation of long-term drinking water solutions for the area impacted by groundwater migrating from the FTC, continued monitoring and testing of groundwater monitoring wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

- removed (2025-05-07):
[0000833444-25-000011:note_history:27]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water in February 2022, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. In August 2024, WDNR issued a new proposed rule to adopt the EPA Maximum Contaminant Levels for PFAS in drinking water. The WDNR initiated a rulemaking proceeding that would establish groundwater quality standards for PFOA, PFOS, perfluorobutane sulfonic acid and its potassium salt (“PFBS”) and hexafluoropropylene oxide dimer acid and its ammonium salt (“HFPO-DA”). Pursuant to state law, the WDNR has stopped work on the proposed rule and notified the state legislature that, following economic analysis, the proposed costs would exceed statutory thresholds. As a result, the state legislature is required to authorize the WDNR to allow the rulemaking to continue.

- removed (2025-05-07):
[0000833444-25-000011:note_history:28]
disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

- removed (2025-05-07):
[0000833444-25-000011:note_history:29]
|  | December 31, 2024 |  | September 30, 2024 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 344 |  |  | 350 |  |
| Total asbestos-related liabilities | 402 |  |  | 408 |  |
| Other current assets | 15 |  |  | 14 |  |
| Other noncurrent assets | 315 |  |  | 320 |  |
| Total asbestos-related assets | 330 |  |  | 334 |  |
| Net asbestos-related liabilities | $ | 72 |  |  | $ | 74 |  |

- removed (2025-05-07):
[0000833444-25-000011:note_history:30]
|  | December 31, 2024 |  | September 30, 2024 |
| Restricted |  |  |  |
| Cash | $ | 7 |  |  | $ | 6 |  |
| Investments | 277 |  |  | 281 |  |
| Total restricted assets | 284 |  |  | 287 |  |
| Insurance receivables for asbestos-related liabilities | 46 |  |  | 47 |  |
| Total asbestos-related assets | $ | 330 |  |  | $ | 334 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0000833444-25-000032:note_history:31]
|  | March 31, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 25 |  |  | $ | 32 |  |
| Other noncurrent liabilities | 174 |  |  | 179 |  |
| Total reserves for environmental liabilities | $ | 199 |  |  | $ | 211 |  |
  (was, 2025-02-05, similarity 0.9731):
[0000833444-25-000011:note_history:31]
|  | December 31, 2024 |  | September 30, 2024 |
| Other current liabilities | $ | 28 |  |  | $ | 32 |  |
| Other noncurrent liabilities | 175 |  |  | 179 |  |
| Total reserves for environmental liabilities | $ | 203 |  |  | $ | 211 |  |

- added (2025-05-07):
[0000833444-25-000032:note_history:32]
|  | March 31, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 344 |  |  | 350 |  |
| Total asbestos-related liabilities | 402 |  |  | 408 |  |
| Other current assets | 15 |  |  | 14 |  |
| Other noncurrent assets | 299 |  |  | 320 |  |
| Total asbestos-related assets | 314 |  |  | 334 |  |
| Net asbestos-related liabilities | $ | 88 |  |  | $ | 74 |  |

- added (2025-05-07):
[0000833444-25-000032:note_history:33]
|  | March 31, 2025 |  | September 30, 2024 |
| Restricted |  |  |  |
| Cash | $ | 7 |  |  | $ | 6 |  |
| Investments | 262 |  |  | 281 |  |
| Total restricted assets | 269 |  |  | 287 |  |
| Insurance receivables for asbestos-related liabilities | 45 |  |  | 47 |  |
| Total asbestos-related assets | $ | 314 |  |  | $ | 334 |  |

- changed (2025-05-07):
[0000833444-25-000032:note_history:34]
|  | March 31, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 99 |  |  | $ | 92 |  |
| Accrued compensation and benefits | 20 |  |  | 20 |  |
| Other noncurrent liabilities | 251 |  |  | 239 |  |
| Total self-insured liabilities | $ | 370 |  |  | $ | 351 |  |
  (was, 2025-02-05, similarity 0.9773):
[0000833444-25-000011:note_history:34]
|  | December 31, 2024 |  | September 30, 2024 |
| Other current liabilities | $ | 98 |  |  | $ | 92 |  |
| Accrued compensation and benefits | 20 |  |  | 20 |  |
| Other noncurrent liabilities | 247 |  |  | 239 |  |
| Total self-insured liabilities | $ | 365 |  |  | $ | 351 |  |

- changed (2025-05-07):
[0000833444-25-000032:note_history:35]
|  | March 31, 2025 |  | September 30, 2024 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 13 |  |  | 13 |  |
| Total insurance receivables | $ | 18 |  |  | $ | 18 |  |
  (was, 2025-02-05, similarity 0.9746):
[0000833444-25-000011:note_history:35]
|  | December 31, 2024 |  | September 30, 2024 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 13 |  |  | 13 |  |
| Total insurance receivables | $ | 18 |  |  | $ | 18 |  |

- removed (2025-05-07):
[0000833444-25-000011:note_history:36]
|  | December 31, 2024 |  | September 30, 2024 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 344 |  |  | 350 |  |
| Total asbestos-related liabilities | 402 |  |  | 408 |  |
| Other current assets | 15 |  |  | 14 |  |
| Other noncurrent assets | 315 |  |  | 320 |  |
| Total asbestos-related assets | 330 |  |  | 334 |  |
| Net asbestos-related liabilities | $ | 72 |  |  | $ | 74 |  |

- removed (2025-05-07):
[0000833444-25-000011:note_history:37]
|  | December 31, 2024 |  | September 30, 2024 |
| Restricted |  |  |  |
| Cash | $ | 7 |  |  | $ | 6 |  |
| Investments | 277 |  |  | 281 |  |
| Total restricted assets | 284 |  |  | 287 |  |
| Insurance receivables for asbestos-related liabilities | 46 |  |  | 47 |  |
| Total asbestos-related assets | $ | 330 |  |  | $ | 334 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0000833444-25-000032:note_history:38]
BASIS OF PRESENTATION
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2024 filed with the SEC on November 19, 2024. The results of operations for the three and six month periods ended March 31, 2025 are not necessarily indicative of results for the Company’s 2025 fiscal year because of seasonal and other factors.
  (was, 2025-02-05, similarity 0.9784):
[0000833444-25-000011:note_history:38]
BASIS OF PRESENTATION
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2024 filed with the SEC on November 19, 2024. The results of operations for the three month period ended December 31, 2024 are not necessarily indicative of results for the Company’s 2025 fiscal year because of seasonal and other factors.

- changed (2025-05-07):
[0000833444-25-000032:note_history:39]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, safe, healthy and sustainable buildings, serving a wide range of customers around the globe. The Company’s products, services, systems and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.
  (was, 2025-02-05, similarity 0.9939):
[0000833444-25-000011:note_history:39]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, healthy and sustainable buildings, serving a wide range of customers around the globe. The Company’s products, services, systems and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

- changed (2025-05-07):
[0000833444-25-000032:note_history:40]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries in conformity with U.S. GAAP. The results of companies acquired or disposed of during the reporting period are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company exercises significant influence, which typically occurs when its ownership interest exceeds 20%, and the Company does not have a controlling interest.
  (was, 2025-02-05, similarity 0.9823):
[0000833444-25-000011:note_history:40]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries that are consolidated in conformity with U.S. GAAP. The results of companies acquired or disposed of during the reporting period are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company exercises significant influence, which typically occurs when its ownership interest exceeds 20%, and the Company does not have a controlling interest.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-05-07):
[0000833444-25-000032:note_history:41]
|  | March 31, |  | September 30, |
|  | 2025 |  | 2024 |
| Commercial paper | $ | 673 |  |  | $ | 350 |  |
| Term loans | 587 |  |  | 603 |  |
| Bank borrowings | 1 |  |  | — |  |
|  | $ | 1,261 |  |  | $ | 953 |  |
| Weighted average interest rate on short-term debt outstanding | 3.8 | % |  | 4.8 | % |

- changed (2025-05-07):
[0000833444-25-000032:note_history:42]
As of March 31, 2025, the Company had two syndicated committed revolving credit facilities, including $2.5 billion which is scheduled to expire in December 2028 and $500 million which is scheduled to expire in December 2025. There were no draws on the facilities as of March 31, 2025.
  (was, 2025-02-05, similarity 0.9356):
[0000833444-25-000011:note_history:42]
As of December 31, 2024, the Company had two syndicated committed revolving credit facilities, including $2.5 billion which is scheduled to expire in December 2028 and $500 million which is scheduled to expire in December 2025. There were no draws on the facilities as of December 31, 2024.

- added (2025-05-07):
[0000833444-25-000032:note_history:43]
In February 2025, the Company repaid €476 million of its 1.375% Notes due 2025 and extinguished $7 million of its 5.125% Notes due 2045 through a bilateral private purchase.

- changed (2025-05-07):
[0000833444-25-000032:note_history:44]
•$250 million 4.900% Senior Notes due 2032. These notes are a further issuance of the $400 million, 4.900% Senior Notes due 2032, which were originally issued in September 2022.
  (was, 2025-02-05, similarity 0.9714):
[0000833444-25-000011:note_history:44]
•$250 million 4.900% Senior Notes due December 2032. These notes are a further issuance of the $400 million, 4.900% Senior Notes due 2032, which were originally issued in September 2022.

- changed (2025-05-07):
[0000833444-25-000032:note_history:45]
•€500 million 3.125% Senior Notes due 2033.
  (was, 2025-02-05, similarity 0.88):
[0000833444-25-000011:note_history:45]
•€500 million 3.125% Senior Notes due December 2033.

- removed (2025-05-07):
[0000833444-25-000011:note_history:46]
|  | December 31, |  | September 30, |
|  | 2024 |  | 2024 |
| Commercial paper | $ | 309 |  |  | $ | 350 |  |
| Term loans | 569 |  |  | 603 |  |
| Bank borrowings | 4 |  |  | — |  |
|  | $ | 882 |  |  | $ | 953 |  |
| Weighted average interest rate on short-term debt outstanding | 3.7 | % |  | 4.8 | % |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0000833444-25-000032:note_history:47]
The fair value of long-term debt at March 31, 2025 and September 30, 2024 was as follows (in billions):
  (was, 2025-02-05, similarity 0.9524):
[0000833444-25-000011:note_history:47]
The fair value of long-term debt at December 31, 2024 and September 30, 2024 was as follows (in billions):

- changed (2025-05-07):
[0000833444-25-000032:note_history:48]
|  |  | March 31, |  | September 30, |  |
|  | 2025 |  | 2024 |  |
| Public debt |  | $ | 8.0 |  |  | $ | 8.1 |  |  |
| Other long-term debt |  | 0.3 |  |  | 0.2 |  |  |
| Total fair value of long-term debt |  | $ | 8.3 |  |  | $ | 8.3 |  |  |
  (was, 2025-02-05, similarity 0.9726):
[0000833444-25-000011:note_history:48]
|  |  | December 31, |  | September 30, |  |
|  | 2024 |  | 2024 |  |
| Public debt |  | $ | 8.4 |  |  | $ | 8.1 |  |  |
| Other long-term debt |  | 0.2 |  |  | 0.2 |  |  |
| Total fair value of long-term debt |  | $ | 8.6 |  |  | $ | 8.3 |  |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-05-07):
[0000833444-25-000032:note_history:49]
|  | March 31, |  | September 30, |
|  | 2025 |  | 2024 |
| Commercial paper | $ | 673 |  |  | $ | 350 |  |
| Term loans | 587 |  |  | 603 |  |
| Bank borrowings | 1 |  |  | — |  |
|  | $ | 1,261 |  |  | $ | 953 |  |
| Weighted average interest rate on short-term debt outstanding | 3.8 | % |  | 4.8 | % |

- removed (2025-05-07):
[0000833444-25-000011:note_history:50]
|  | December 31, |  | September 30, |
|  | 2024 |  | 2024 |
| Commercial paper | $ | 309 |  |  | $ | 350 |  |
| Term loans | 569 |  |  | 603 |  |
| Bank borrowings | 4 |  |  | — |  |
|  | $ | 882 |  |  | $ | 953 |  |
| Weighted average interest rate on short-term debt outstanding | 3.7 | % |  | 4.8 | % |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-05-07):
[0000833444-25-000032:note_history:51]
|  |  | Three Months Ended March 31, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,829 |  |  | $ | 1,087 |  |  | $ | 2,916 |  |  | $ | 1,700 |  |  | $ | 1,039 |  |  | $ | 2,739 |  |
| Building Solutions EMEA/LA |  | 566 |  |  | 519 |  |  | 1,085 |  |  | 572 |  |  | 492 |  |  | 1,064 |  |
| Building Solutions Asia Pacific |  | 337 |  |  | 205 |  |  | 542 |  |  | 308 |  |  | 183 |  |  | 491 |  |
| Global Products |  | 1,133 |  |  | — |  |  | 1,133 |  |  | 1,303 |  |  | — |  |  | 1,303 |  |
| Total |  | $ | 3,865 |  |  | $ | 1,811 |  |  | $ | 5,676 |  |  | $ | 3,883 |  |  | $ | 1,714 |  |  | $ | 5,597 |  |

- added (2025-05-07):
[0000833444-25-000032:note_history:52]
|  |  | Six Months Ended March 31, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,524 |  |  | $ | 2,136 |  |  | $ | 5,660 |  |  | $ | 3,218 |  |  | $ | 2,008 |  |  | $ | 5,226 |  |
| Building Solutions EMEA/LA |  | 1,140 |  |  | 1,018 |  |  | 2,158 |  |  | 1,144 |  |  | 958 |  |  | 2,102 |  |
| Building Solutions Asia Pacific |  | 671 |  |  | 398 |  |  | 1,069 |  |  | 645 |  |  | 353 |  |  | 998 |  |
| Global Products |  | 2,215 |  |  | — |  |  | 2,215 |  |  | 2,480 |  |  | — |  |  | 2,480 |  |
| Total |  | $ | 7,550 |  |  | $ | 3,552 |  |  | $ | 11,102 |  |  | $ | 7,487 |  |  | $ | 3,319 |  |  | $ | 10,806 |  |

- changed (2025-05-07):
[0000833444-25-000032:note_history:53]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| HVAC |  | $ | 468 |  |  | $ | 581 |  |  | $ | 936 |  |  | $ | 1,114 |  |
| Fire & Security |  | 573 |  |  | 607 |  |  | 1,095 |  |  | 1,154 |  |
| Industrial Refrigeration |  | 92 |  |  | 115 |  |  | 184 |  |  | 212 |  |
| Total |  | $ | 1,133 |  |  | $ | 1,303 |  |  | $ | 2,215 |  |  | $ | 2,480 |  |
  (was, 2025-02-05, similarity 0.7092):
[0000833444-25-000011:note_history:53]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| HVAC |  | $ | 468 |  |  | $ | 533 |  |  |  |  |  |
| Fire & Security |  | 522 |  |  | 547 |  |  |  |  |  |
| Industrial Refrigeration |  | 92 |  |  | 97 |  |  |  |  |  |
| Total |  | $ | 1,082 |  |  | $ | 1,177 |  |  |  |  |  |

- removed (2025-05-07):
[0000833444-25-000011:note_history:54]
|  |  | Three Months Ended December 31, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,695 |  |  | $ | 1,049 |  |  | $ | 2,744 |  |  | $ | 1,518 |  |  | $ | 969 |  |  | $ | 2,487 |  |
| Building Solutions EMEA/LA |  | 574 |  |  | 499 |  |  | 1,073 |  |  | 572 |  |  | 466 |  |  | 1,038 |  |
| Building Solutions Asia Pacific |  | 334 |  |  | 193 |  |  | 527 |  |  | 337 |  |  | 170 |  |  | 507 |  |
| Global Products |  | 1,082 |  |  | — |  |  | 1,082 |  |  | 1,177 |  |  | — |  |  | 1,177 |  |
| Total |  | $ | 3,685 |  |  | $ | 1,741 |  |  | $ | 5,426 |  |  | $ | 3,604 |  |  | $ | 1,605 |  |  | $ | 5,209 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-07):
[0000833444-25-000032:note_history:55]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of March 31, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $22 billion, of which approximately 63% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less and contracts that are cancellable without substantial penalty.
  (was, 2025-02-05, similarity 0.9935):
[0000833444-25-000011:note_history:55]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of December 31, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $20.9 billion, of which approximately 64% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less and contracts that are cancellable without substantial penalty.

- removed (2025-05-07):
[0000833444-25-000011:note_history:56]
A performance obligation is a distinct good, service, or a bundle of goods and services promised in a contract. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When contracts with customers require significant and complex integration, contain

- removed (2025-05-07):
[0000833444-25-000011:note_history:57]
goods or services which are highly interdependent or interrelated, or are goods or services which significantly modify or customize other promises in the contracts and, therefore, are not distinct, then the entire contract is accounted for as a single performance obligation. For any contracts with multiple performance obligations, the contract’s transaction price is allocated to each performance obligation based on the estimated relative standalone selling price of each distinct good or service in the contract. For product sales, each product sold to a customer typically represents a distinct performance obligation.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-05-07):
[0000833444-25-000032:note_history:58]
|  |  | Three Months Ended March 31, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,829 |  |  | $ | 1,087 |  |  | $ | 2,916 |  |  | $ | 1,700 |  |  | $ | 1,039 |  |  | $ | 2,739 |  |
| Building Solutions EMEA/LA |  | 566 |  |  | 519 |  |  | 1,085 |  |  | 572 |  |  | 492 |  |  | 1,064 |  |
| Building Solutions Asia Pacific |  | 337 |  |  | 205 |  |  | 542 |  |  | 308 |  |  | 183 |  |  | 491 |  |
| Global Products |  | 1,133 |  |  | — |  |  | 1,133 |  |  | 1,303 |  |  | — |  |  | 1,303 |  |
| Total |  | $ | 3,865 |  |  | $ | 1,811 |  |  | $ | 5,676 |  |  | $ | 3,883 |  |  | $ | 1,714 |  |  | $ | 5,597 |  |

- added (2025-05-07):
[0000833444-25-000032:note_history:59]
|  |  | Six Months Ended March 31, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,524 |  |  | $ | 2,136 |  |  | $ | 5,660 |  |  | $ | 3,218 |  |  | $ | 2,008 |  |  | $ | 5,226 |  |
| Building Solutions EMEA/LA |  | 1,140 |  |  | 1,018 |  |  | 2,158 |  |  | 1,144 |  |  | 958 |  |  | 2,102 |  |
| Building Solutions Asia Pacific |  | 671 |  |  | 398 |  |  | 1,069 |  |  | 645 |  |  | 353 |  |  | 998 |  |
| Global Products |  | 2,215 |  |  | — |  |  | 2,215 |  |  | 2,480 |  |  | — |  |  | 2,480 |  |
| Total |  | $ | 7,550 |  |  | $ | 3,552 |  |  | $ | 11,102 |  |  | $ | 7,487 |  |  | $ | 3,319 |  |  | $ | 10,806 |  |

- changed (2025-05-07):
[0000833444-25-000032:note_history:60]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| HVAC |  | $ | 468 |  |  | $ | 581 |  |  | $ | 936 |  |  | $ | 1,114 |  |
| Fire & Security |  | 573 |  |  | 607 |  |  | 1,095 |  |  | 1,154 |  |
| Industrial Refrigeration |  | 92 |  |  | 115 |  |  | 184 |  |  | 212 |  |
| Total |  | $ | 1,133 |  |  | $ | 1,303 |  |  | $ | 2,215 |  |  | $ | 2,480 |  |
  (was, 2025-02-05, similarity 0.7092):
[0000833444-25-000011:note_history:60]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| HVAC |  | $ | 468 |  |  | $ | 533 |  |  |  |  |  |
| Fire & Security |  | 522 |  |  | 547 |  |  |  |  |  |
| Industrial Refrigeration |  | 92 |  |  | 97 |  |  |  |  |  |
| Total |  | $ | 1,082 |  |  | $ | 1,177 |  |  |  |  |  |

- added (2025-05-07):
[0000833444-25-000032:note_history:61]
|  |  | Location of contract balances |  | March 31, 2025 |  | September 30, 2024 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,998 |  |  | $ | 1,931 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 7 |  |  | 11 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,380 |  |  | 2,160 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 261 |  |  | 252 |  |  |  |

- changed (2025-05-07):
[0000833444-25-000032:note_history:62]
For the three months ended March 31, 2025 and 2024, the Company recognized revenue of $393 million and $369 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year. For the six months ended March 31, 2025 and 2024, the Company recognized revenue of $1,271 million and $1,208 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year.
  (was, 2025-02-05, similarity 0.6484):
[0000833444-25-000011:note_history:62]
For the three months ended December 31, 2024 and 2023, the Company recognized revenue of $878 million and $839 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year.

- changed (2025-05-07):
[0000833444-25-000032:note_history:63]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of March 31, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $22 billion, of which approximately 63% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less and contracts that are cancellable without substantial penalty.
  (was, 2025-02-05, similarity 0.9935):
[0000833444-25-000011:note_history:63]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of December 31, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $20.9 billion, of which approximately 64% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less and contracts that are cancellable without substantial penalty.

- changed (2025-05-07):
[0000833444-25-000032:note_history:64]
|  |  | March 31, 2025 |  | September 30, 2024 |  |  |
| Other current assets |  | $ | 283 |  |  | $ | 265 |  |  |  |
| Other noncurrent assets |  | 290 |  |  | 291 |  |  |  |
| Total |  | $ | 573 |  |  | $ | 556 |  |  |  |
  (was, 2025-02-05, similarity 0.9749):
[0000833444-25-000011:note_history:64]
|  |  | December 31, 2024 |  | September 30, 2024 |  |  |
| Other current assets |  | $ | 276 |  |  | $ | 265 |  |  |  |
| Other noncurrent assets |  | 284 |  |  | 291 |  |  |  |
| Total |  | $ | 560 |  |  | $ | 556 |  |  |  |

- added (2025-05-07):
[0000833444-25-000032:note_history:65]
During the three months ended March 31, 2025 and 2024, the Company recognized expense of $91 million and $77 million, respectively, related to costs to obtain or fulfill a contract. During the six months ended March 31, 2025 and 2024, the Company recognized expense of $175 million and $134 million, respectively, related to costs to obtain or fulfill a contract.

- removed (2025-05-07):
[0000833444-25-000011:note_history:66]
|  |  | Three Months Ended December 31, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,695 |  |  | $ | 1,049 |  |  | $ | 2,744 |  |  | $ | 1,518 |  |  | $ | 969 |  |  | $ | 2,487 |  |
| Building Solutions EMEA/LA |  | 574 |  |  | 499 |  |  | 1,073 |  |  | 572 |  |  | 466 |  |  | 1,038 |  |
| Building Solutions Asia Pacific |  | 334 |  |  | 193 |  |  | 527 |  |  | 337 |  |  | 170 |  |  | 507 |  |
| Global Products |  | 1,082 |  |  | — |  |  | 1,082 |  |  | 1,177 |  |  | — |  |  | 1,177 |  |
| Total |  | $ | 3,685 |  |  | $ | 1,741 |  |  | $ | 5,426 |  |  | $ | 3,604 |  |  | $ | 1,605 |  |  | $ | 5,209 |  |

- removed (2025-05-07):
[0000833444-25-000011:note_history:67]
|  |  | Location of contract balances |  | December 31, 2024 |  | September 30, 2024 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,917 |  |  | $ | 1,931 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 6 |  |  | 11 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,211 |  |  | 2,160 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 253 |  |  | 252 |  |  |  |

- removed (2025-05-07):
[0000833444-25-000011:note_history:68]
A performance obligation is a distinct good, service, or a bundle of goods and services promised in a contract. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When contracts with customers require significant and complex integration, contain

- removed (2025-05-07):
[0000833444-25-000011:note_history:69]
goods or services which are highly interdependent or interrelated, or are goods or services which significantly modify or customize other promises in the contracts and, therefore, are not distinct, then the entire contract is accounted for as a single performance obligation. For any contracts with multiple performance obligations, the contract’s transaction price is allocated to each performance obligation based on the estimated relative standalone selling price of each distinct good or service in the contract. For product sales, each product sold to a customer typically represents a distinct performance obligation.

- removed (2025-05-07):
[0000833444-25-000011:note_history:70]
During the three months ended December 31, 2024 and 2023, the Company recognized expense of $84 million and $57 million, respectively, related to costs to obtain or fulfill a contract.  There were no impairment losses recognized in the three months ended December 31, 2024 and 2023.
