# JCI 8-K — 0000833444-25-000029 filed 2025-05-07

## item codes, every 8-K on or before 2025-05-07

- 2025-05-07 0000833444-25-000029 — 2.02, 9.01
- 2025-05-05 0000833444-25-000025 — 7.01, 9.01
- 2025-04-02 0000833444-25-000021 — 5.02, 7.01
- 2025-03-14 0000833444-25-000019 — 5.02, 5.07
- 2025-02-05 0001104659-25-009733 — 5.02, 7.01, 9.01
- 2025-02-05 0000833444-25-000009 — 2.02, 7.01, 9.01
- 2025-01-10 0000833444-25-000002 — 5.02
- 2024-12-12 0000833444-24-000066 — 5.02
- 2024-12-11 0001193125-24-275613 — 8.01, 9.01
- 2024-12-10 0001193125-24-274338 — 8.01, 9.01
- 2024-11-06 0000833444-24-000060 — 2.02, 9.01
- 2024-08-05 0000833444-24-000055 — 5.02, 7.01, 9.01
- 2024-07-31 0000833444-24-000049 — 2.02, 9.01
- 2024-07-26 0001193125-24-186281 — 1.01, 9.01
- 2024-07-23 0000833444-24-000044 — 2.02, 7.01, 9.01
- 2024-06-04 0001193125-24-154244 — 8.01, 9.01
- 2024-05-20 0000833444-24-000032 — 8.01, 9.01
- 2024-05-01 0000833444-24-000026 — 2.02, 9.01
- 2024-04-19 0001193125-24-102867 — 8.01, 9.01
- 2024-04-12 0000833444-24-000023 — 1.01, 8.01, 9.01
- 2024-03-18 0000833444-24-000020 — 5.07
- 2024-01-30 0000833444-24-000007 — 2.02, 9.01
- 2024-01-16 0000833444-24-000004 — 5.02, 9.01
- 2023-12-12 0000833444-23-000044 — 2.02, 9.01
- 2023-12-08 0000833444-23-000042 — 5.02
- 2023-11-13 0000833444-23-000038 — 8.01
- 2023-09-27 0000833444-23-000036 — 8.01
- 2023-09-08 0000833444-23-000033 — 5.02
- 2023-08-21 0001193125-23-217018 — 8.01, 9.01
- 2023-08-07 0001193125-23-205014 — 8.01, 9.01
- 2023-08-02 0000833444-23-000028 — 2.02, 9.01
- 2023-05-23 0001193125-23-151889 — 8.01, 9.01
- 2023-05-05 0000833444-23-000011 — 2.02, 9.01
- 2023-03-14 0000833444-23-000007 — 5.07
- 2023-02-01 0000833444-23-000003 — 2.02, 9.01
- 2022-12-22 0000833444-22-000047 — 5.02
- 2022-12-09 0000833444-22-000045 — 5.02
- 2022-11-03 0000833444-22-000038 — 2.02, 9.01
- 2022-09-14 0001193125-22-244741 — 8.01, 9.01
- 2022-09-07 0001193125-22-240030 — 8.01, 9.01
- 2022-08-04 0000833444-22-000034 — 2.02, 9.01
- 2022-07-06 0000833444-22-000029 — 5.02, 9.01
- 2022-06-30 0000833444-22-000027 — 5.02
- 2022-05-04 0000833444-22-000014 — 2.02, 9.01
- 2022-03-11 0001193125-22-073382 — 5.07
- 2022-02-15 0000833444-22-000010 — 5.02
- 2022-02-02 0000833444-22-000003 — 2.02, 9.01
- 2021-12-10 0000833444-21-000050 — 5.02
- 2021-11-05 0000833444-21-000043 — 2.02, 9.01
- 2021-09-16 0001193125-21-275152 — 1.01, 8.01, 9.01
- 2021-07-30 0000833444-21-000038 — 2.02, 9.01
- 2021-05-03 0000833444-21-000023 — 8.01
- 2021-04-30 0000833444-21-000017 — 2.02, 9.01
- 2021-03-11 0000833444-21-000013 — 5.02, 5.07, 9.01
- 2021-02-17 0001193125-21-045768 — 7.01, 9.01
- 2021-01-29 0000833444-21-000009 — 2.02, 9.01
- 2021-01-07 0000833444-21-000004 — 7.01
- 2020-11-03 0000833444-20-000043 — 2.02, 9.01
- 2020-09-15 0001193125-20-246240 — 1.01, 8.01, 9.01
- 2020-09-11 0001193125-20-244119 — 1.01, 8.01, 9.01
- 2020-08-18 0000833444-20-000038 — 5.02, 9.01
- 2020-07-31 0000833444-20-000034 — 2.02, 9.01
- 2020-06-12 0000833444-20-000020 — 8.01
- 2020-05-01 0000833444-20-000013 — 2.02, 9.01
- 2020-03-12 0000833444-20-000010 — 5.02
- 2020-03-06 0000833444-20-000008 — 5.07
- 2020-01-31 0000833444-20-000003 — 2.02, 9.01
- 2019-12-06 0001193125-19-308301 — 1.01, 1.02, 2.03, 9.01
- 2019-11-07 0000833444-19-000048 — 5.02, 9.01
- 2019-11-07 0000833444-19-000046 — 2.02, 9.01
- 2019-08-21 0000833444-19-000043 — 8.01
- 2019-07-31 0000833444-19-000038 — 2.02, 9.01
- 2019-07-23 0000833444-19-000035 — 5.02, 8.01, 9.01
- 2019-07-02 0000833444-19-000033 — 1.02, 8.01
- 2019-06-05 0001193125-19-165565 — 8.01
- 2019-05-30 0001193125-19-160205 — 8.01, 9.01
- 2019-05-16 0001193125-19-148262 — 8.01, 9.01
- 2019-05-07 0001193125-19-139826 — 5.04, 9.01
- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2025-05-07

- 2023-11-29 0000833444-23-000040 — NT 10-K, for the period ended 2023-09-30
- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-25-000029:8k_2_02:1]
EX-99.1
2
q2ex991xq2fy25earningsrele.htm
EX-99.1

[0000833444-25-000029:8k_2_02:2]
Document

[0000833444-25-000029:8k_2_02:3]
Exhibit 99.1

[0000833444-25-000029:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-25-000029:8k_2_02:5]
Johnson Controls Reports Strong Q2 Results; Raises FY25 Guidance

[0000833444-25-000029:8k_2_02:6]
______________________________________________________________________________________

[0000833444-25-000029:8k_2_02:7]
▪Q2 sales increased 1% and organic sales increased 7%*

[0000833444-25-000029:8k_2_02:8]
▪Q2 GAAP EPS of $0.71; Q2 Adjusted EPS* of $0.82

[0000833444-25-000029:8k_2_02:9]
▪Q2 orders increased 5% organically year-over-year

[0000833444-25-000029:8k_2_02:10]
▪Building Solutions backlog of $14.0 billion increased 12% organically year-over-year

[0000833444-25-000029:8k_2_02:11]
▪Initiates fiscal Q3 and raises full year fiscal 2025 guidance*

[0000833444-25-000029:8k_2_02:12]
*  This news release contains non-GAAP financial measures. Definitions and reconciliations of the non-GAAP financial measures can be found in the attached footnotes. Non-GAAP measures should be considered in addition to, and not as replacements for, the most comparable GAAP measures.

[0000833444-25-000029:8k_2_02:13]
_____________________________________________________________________________________

[0000833444-25-000029:8k_2_02:14]
CORK, Ireland — May 7, 2025 — Johnson Controls International plc (NYSE: JCI), a global leader for smart, safe, healthy and sustainable buildings, today reported fiscal second quarter 2025 GAAP earnings per share (“EPS”) of $0.71. Adjusted EPS was $0.82.

[0000833444-25-000029:8k_2_02:15]
Sales in the quarter of $5.7 billion increased 1% over the prior year on an as reported basis and 7% organically. GAAP income from continuing operations was $473 million. Adjusted income from continuing operations was $545 million.

[0000833444-25-000029:8k_2_02:16]
“The Johnson Controls team delivered strong second quarter results, highlighted by organic sales growth, margin expansion and record backlog,” said Joakim Weidemanis, CEO. “The results reflect the strengthened execution from our team as well as broad-based and sustained demand for our differentiated solutions. We have a strong foundation in place and by starting to increase customer focus and implement lean and business system approaches, we can take the first step to accelerate our momentum and enhance value for all of our stakeholders.”

[0000833444-25-000029:8k_2_02:17]
FISCAL Q2 SEGMENT RESULTS

[0000833444-25-000029:8k_2_02:18]
The financial highlights presented in the tables below exclude discontinued operations and are in accordance with GAAP, unless otherwise indicated. All comparisons are to the second quarter of fiscal 2024.

[0000833444-25-000029:8k_2_02:19]
A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-25-000029:8k_2_02:20]
1

[0000833444-25-000029:8k_2_02:21]
Building Solutions North America

[0000833444-25-000029:8k_2_02:22]
|  |  | Fiscal Q2 |  |  |  |  |  |
| (in millions) |  | 2025 |  | 2024 |  | Change |  |  |  |  |  |
| Sales |  | $ | 2,916 |  |  | $ | 2,739 |  |  | 6 | % |  |  |  |  |  |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 390 |  |  | 373 |  |  | 5 | % |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 390 |  |  | 373 |  |  | 5 | % |  |  |  |  |  |
| Segment EBITA Margin % |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 13.4 | % |  | 13.6 | % |  | (20 | bp) |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 13.4 | % |  | 13.6 | % |  | (20 | bp) |  |  |  |  |  |

[0000833444-25-000029:8k_2_02:23]
Sales in the quarter of $2.9 billion increased 6% over the prior year. Organic sales increased 7% over the prior year, led by continued strength across Applied HVAC and Controls.

[0000833444-25-000029:8k_2_02:24]
Excluding M&A and adjusted for foreign currency, orders increased 4% year-over-year and backlog of $9.8 billion increased 11% year-over-year.

[0000833444-25-000029:8k_2_02:25]
Segment EBITA margin of 13.4% declined 20 basis points versus the prior year as Systems growth outpaced Service growth.

[0000833444-25-000029:8k_2_02:26]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-25-000029:8k_2_02:27]
|  |  | Fiscal Q2 |  |  |  |  |  |
| (in millions) |  | 2025 |  | 2024 |  | Change |  |  |  |  |  |
| Sales |  | $ | 1,085 |  |  | $ | 1,064 |  |  | 2 | % |  |  |  |  |  |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 136 |  |  | 89 |  |  | 53 | % |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 136 |  |  | 89 |  |  | 53 | % |  |  |  |  |  |
| Segment EBITA Margin % |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 12.5 | % |  | 8.4 | % |  | 410 | bp |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 12.5 | % |  | 8.4 | % |  | 410 | bp |  |  |  |  |  |

[0000833444-25-000029:8k_2_02:28]
Sales in the quarter of $1.1 billion increased 2% over the prior year. Organic sales grew 5% versus the prior year quarter led by 9% growth in Service, including solid growth in Applied HVAC and Fire and Security sales.

[0000833444-25-000029:8k_2_02:29]
Excluding M&A and adjusted for foreign currency, orders increased 10% year-over-year and backlog of $2.7 billion increased 10% year-over-year.

[0000833444-25-000029:8k_2_02:30]
Segment EBITA margin of 12.5% expanded 410 basis points versus the prior year driven by productivity improvements and positive mix from growth in Service.

[0000833444-25-000029:8k_2_02:31]
2

[0000833444-25-000029:8k_2_02:32]
Building Solutions Asia Pacific

[0000833444-25-000029:8k_2_02:33]
|  |  | Fiscal Q2 |  |  |  |  |  |
| (in millions) |  | 2025 |  | 2024 |  | Change |  |  |  |  |  |
| Sales |  | $ | 542 |  |  | $ | 491 |  |  | 10 | % |  |  |  |  |  |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 79 |  |  | 54 |  |  | 46 | % |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 79 |  |  | 54 |  |  | 46 | % |  |  |  |  |  |
| Segment EBITA Margin % |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 14.6 | % |  | 11.0 | % |  | 360 | bp |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 14.6 | % |  | 11.0 | % |  | 360 | bp |  |  |  |  |  |

[0000833444-25-000029:8k_2_02:34]
Sales in the quarter of $542 million increased 10% versus the prior year. Organic sales increased 13% versus the prior year led by strong double-digit growth from both Service and Systems.

[0000833444-25-000029:8k_2_02:35]
Excluding M&A and adjusted for foreign currency, orders were flat year-over-year and backlog of $1.5 billion increased 21% year-over-year.

[0000833444-25-000029:8k_2_02:36]
Segment EBITA margin of 14.6% increased 360 basis points versus the prior year driven by productivity improvements.

[0000833444-25-000029:8k_2_02:37]
Global Products

[0000833444-25-000029:8k_2_02:38]
|  |  | Fiscal Q2 |  |  |  |  |  |
| (in millions) |  | 2025 |  | 2024 |  | Change |  |  |  |  |  |
| Sales |  | $ | 1,133 |  |  | $ | 1,303 |  |  | (13 | %) |  |  |  |  |  |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 341 |  |  | 290 |  |  | 18 | % |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 343 |  |  | 316 |  |  | 9 | % |  |  |  |  |  |
| Segment EBITA Margin % |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 30.1 | % |  | 22.3 | % |  | 780 | bp |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 30.3 | % |  | 24.3 | % |  | 600 | bp |  |  |  |  |  |

[0000833444-25-000029:8k_2_02:39]
Sales in the quarter of $1.1 billion declined 13% versus the prior year. Organic sales grew 8% versus the prior year, led by positive price and volume growth. Excluding the impact of divestitures, Applied HVAC grew over 20% with strong double-digit growth in North America and EMEA/LA.

[0000833444-25-000029:8k_2_02:40]
Segment EBITA margin of 30.1% expanded 780 basis points versus the prior year due to enhanced operational efficiencies and increased volumes, excluding the impact of divestitures. Adjusted segment EBITA in Q2 2025 excludes transformation costs. Adjusted segment EBITA in Q2 2024 excludes costs for a product quality issue, partially offset by favorable earn-out adjustments.

[0000833444-25-000029:8k_2_02:41]
3

[0000833444-25-000029:8k_2_02:42]
Corporate

[0000833444-25-000029:8k_2_02:43]
|  |  | Fiscal Q2 |  |  |  |  |  |
| (in millions) |  | 2025 |  | 2024 |  | Change |  |  |  |  |  |
| Corporate Expense |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 186 |  |  | $ | 92 |  |  | 102 | % |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 135 |  |  | 83 |  |  | 63 | % |  |  |  |  |  |

[0000833444-25-000029:8k_2_02:44]
Corporate expenses increased over the prior year as a result of certain corporate accruals combined with the impact of stranded costs from the planned divestiture of the R&LC HVAC business. Adjusted Corporate expense in Q2 2025 excludes certain transaction/separation costs and transformation costs. Adjusted Corporate expense in Q2 2024 excludes certain transaction/separation costs and cyber incident costs.

[0000833444-25-000029:8k_2_02:45]
OTHER Q2 ITEMS

[0000833444-25-000029:8k_2_02:46]
▪Cash provided by operating activities was $550 million. Free cash flow was $456 million and adjusted free cash flow was $463 million.

[0000833444-25-000029:8k_2_02:47]
▪The Company paid dividends of $245 million.

[0000833444-25-000029:8k_2_02:48]
▪The Company repurchased 4.1 million shares of common stock for $330 million.

[0000833444-25-000029:8k_2_02:49]
GUIDANCE

[0000833444-25-000029:8k_2_02:50]
The following forward-looking statements regarding organic sales growth, adjusted segment EBITA margin, adjusted segment EBITA margin improvement, adjusted EPS and adjusted free cash flow conversion are non-GAAP financial measures and are presented on a continuing operations basis excluding the Residential and Light Commercial HVAC business, which was classified as discontinued operations beginning in the fiscal fourth quarter of 2024. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as mark-to-market adjustments. Organic revenue growth excludes the effect of acquisitions, divestitures and foreign currency. The Company is unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to its most directly comparable forward-looking GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s fiscal 2025 third quarter and full year GAAP financial results from continuing operations.

[0000833444-25-000029:8k_2_02:51]
4

[0000833444-25-000029:8k_2_02:52]
The Company initiated fiscal 2025 third quarter guidance:

[0000833444-25-000029:8k_2_02:53]
▪Organic sales growth of mid-single digits

[0000833444-25-000029:8k_2_02:54]
▪Adjusted segment EBITA margin of ~17.5%

[0000833444-25-000029:8k_2_02:55]
▪Adjusted EPS before special items of ~$0.97 to $1.00

[0000833444-25-000029:8k_2_02:56]
The Company raised fiscal 2025 full year guidance:

[0000833444-25-000029:8k_2_02:57]
▪Organic sales growth of mid-single digits (unchanged)

[0000833444-25-000029:8k_2_02:58]
▪Adjusted segment EBITA margin improvement of ~90 basis points year-over-year (previously more than 80 bps)

[0000833444-25-000029:8k_2_02:59]
▪Adjusted EPS before special items of ~$3.60 (previously ~$3.50 to $3.60)

[0000833444-25-000029:8k_2_02:60]
▪Adjusted free cash flow conversion of ~100% (previously ~90%+)

[0000833444-25-000029:8k_2_02:61]
CONFERENCE CALL & WEBCAST INFO

[0000833444-25-000029:8k_2_02:62]
Johnson Controls will host a conference call to discuss this quarter’s results at 8:30 a.m. ET today, which can be accessed by dialing 844-763-8274 (in the United States) or +1-412-717-9224 (outside the United States), or via webcast. A slide presentation will accompany the prepared remarks and has been posted on the investor relations section of the Johnson Controls website at https://investors.johnsoncontrols.com/news-and-events/events-and-presentations. A replay will be made available approximately two hours following the conclusion of the conference call.

[0000833444-25-000029:8k_2_02:63]
ABOUT JOHNSON CONTROLS

[0000833444-25-000029:8k_2_02:64]
At Johnson Controls (NYSE:JCI), we transform the environments where people live, work, learn and play. As the global leader in smart, healthy and sustainable buildings, our mission is to reimagine the performance of buildings to serve people, places and the planet.

[0000833444-25-000029:8k_2_02:65]
Building on a proud history of nearly 140 years of innovation, we deliver the blueprint of the future for industries such as healthcare, schools, data centers, airports, stadiums, manufacturing and beyond through OpenBlue, our comprehensive digital offering.

[0000833444-25-000029:8k_2_02:66]
Today, Johnson Controls offers the world`s largest portfolio of building technology and software as well as service solutions from some of the most trusted names in the industry.

[0000833444-25-000029:8k_2_02:67]
Visit www.johnsoncontrols.com for more information and follow @Johnson Controls on social platforms.

[0000833444-25-000029:8k_2_02:68]
5

[0000833444-25-000029:8k_2_02:69]
JOHNSON CONTROLS CONTACTS:

[0000833444-25-000029:8k_2_02:70]
| INVESTOR CONTACTS: | MEDIA CONTACT: |  |  |  |
| Jim Lucas | Danielle Canzanella |  |  |  |
| Direct: +1 414.340.1752 | Direct: +1 203.499.8297 |  |  |  |
| Email: jim.lucas@jci.com | Email: danielle.canzanella@jci.com |  |  |  |
| Michael Gates |  |  |  |  |
| Direct: +1 414.524.5785 |  |  |  |  |
| Email: michael.j.gates@jci.com |  |  |  |  |

[0000833444-25-000029:8k_2_02:71]
###

[0000833444-25-000029:8k_2_02:72]
JOHNSON CONTROLS INTERNATIONAL PLC CAUTIONARY STATEMENT REGARDING FORWARD-LOOKING STATEMENTS

[0000833444-25-000029:8k_2_02:73]
6

[0000833444-25-000029:8k_2_02:74]
interpretations that impact Johnson Controls’ business operations or tax status; the ability to adapt to global climate change, climate change regulation and successfully meet Johnson Controls’ public sustainability commitments; the outcome of litigation and governmental proceedings; the risk of infringement or expiration of intellectual property rights; Johnson Controls’ ability to manage disruptions caused by catastrophic or geopolitical events, such as natural disasters, armed conflict, political change, climate change, pandemics and outbreaks of contagious diseases and other adverse public health developments; any delay or inability of Johnson Controls to realize the expected benefits and synergies of recent portfolio transactions; the tax treatment of recent portfolio transactions; significant transaction costs and/or unknown liabilities associated with such transactions; labor shortages, work stoppages, union negotiations, labor disputes and other matters associated with the labor force; and the cancellation of or changes to commercial arrangements. A detailed discussion of risks related to Johnson Controls' business is included in the section entitled “Risk Factors” in Johnson Controls Annual Report on Form 10-K for the fiscal year ended September 30, 2024 filed with the SEC on November 19, 2024, which is available at www.sec.gov and www.johnsoncontrols.com under the “Investors” tab. The description of certain of these risks is supplemented in Item 1A of Part II of Johnson Controls subsequently filed Quarterly Reports on Form 10-Q. Shareholders, potential investors and others should consider these factors in evaluating the forward-looking statements and should not place undue reliance on such statements. The forward-looking statements included in this communication are made only as of the date of this document, unless otherwise specified, and, except as required by law, Johnson Controls assumes no obligation, and disclaims any obligation, to update such statements to reflect events or circumstances occurring after the date of this communication.

[0000833444-25-000029:8k_2_02:75]
###

[0000833444-25-000029:8k_2_02:76]
7

[0000833444-25-000029:8k_2_02:77]
FINANCIAL STATEMENTS

[0000833444-25-000029:8k_2_02:78]
Johnson Controls International plc

[0000833444-25-000029:8k_2_02:79]
Consolidated Statements of Income

[0000833444-25-000029:8k_2_02:80]
(in millions, except per share data; unaudited)

[0000833444-25-000029:8k_2_02:81]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales |  |  |  |  |  |  |  |
| Products and systems | $ | 3,865 |  |  | $ | 3,883 |  |  | $ | 7,550 |  |  | $ | 7,487 |  |
| Services | 1,811 |  |  | 1,714 |  |  | 3,552 |  |  | 3,319 |  |
|  | 5,676 |  |  | 5,597 |  |  | 11,102 |  |  | 10,806 |  |
| Cost of sales |  |  |  |  |  |  |  |
| Products and systems | 2,523 |  |  | 2,616 |  |  | 4,979 |  |  | 5,107 |  |
| Services | 1,084 |  |  | 1,059 |  |  | 2,128 |  |  | 1,999 |  |
|  | 3,607 |  |  | 3,675 |  |  | 7,107 |  |  | 7,106 |  |
| Gross profit | 2,069 |  |  | 1,922 |  |  | 3,995 |  |  | 3,700 |  |
| Selling, general and administrative expenses | 1,427 |  |  | 2,064 |  |  | 2,826 |  |  | 3,398 |  |
| Restructuring and impairment costs | 62 |  |  | 239 |  |  | 95 |  |  | 274 |  |
| Net financing charges | 80 |  |  | 89 |  |  | 166 |  |  | 176 |  |
| Equity income (loss) | 1 |  |  | (1) |  |  | 1 |  |  | (3) |  |
| Income (loss) from continuing operations before income taxes | 501 |  |  | (471) |  |  | 909 |  |  | (151) |  |
| Income tax provision (benefit) | 26 |  |  | (153) |  |  | 73 |  |  | (173) |  |
| Income (loss) from continuing operations | 475 |  |  | (318) |  |  | 836 |  |  | 22 |  |
| Income from discontinued operations, net of tax | 51 |  |  | 84 |  |  | 141 |  |  | 148 |  |
| Net income (loss) | 526 |  |  | (234) |  |  | 977 |  |  | 170 |  |
| Income (loss) attributable to noncontrolling interests |  |  |  |  |  |  |  |
| Continuing operations | 2 |  |  | 3 |  |  | — |  |  | 3 |  |
| Discontinued operations | 46 |  |  | 40 |  |  | 80 |  |  | 70 |  |
| Net income (loss) attributable to Johnson Controls | $ | 478 |  |  | $ | (277) |  |  | $ | 897 |  |  | $ | 97 |  |
| Income (loss) attributable to Johnson Controls |  |  |  |  |  |  |  |
| Continuing operations | $ | 473 |  |  | $ | (321) |  |  | $ | 836 |  |  | $ | 19 |  |
| Discontinued operations | 5 |  |  | 44 |  |  | 61 |  |  | 78 |  |
| Total | $ | 478 |  |  | $ | (277) |  |  | $ | 897 |  |  | $ | 97 |  |
| Basic earnings (loss) per share attributable to Johnson Controls |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.72 |  |  | $ | (0.47) |  |  | $ | 1.27 |  |  | $ | 0.03 |  |
| Discontinued operations | 0.01 |  |  | 0.06 |  |  | 0.09 |  |  | 0.11 |  |
| Total | $ | 0.73 |  |  | $ | (0.41) |  |  | $ | 1.36 |  |  | $ | 0.14 |  |
| Diluted earnings (loss) per share attributable to Johnson Controls |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.71 |  |  | $ | (0.47) |  |  | 1.26 |  | 0.03 |
| Discontinued operations | 0.01 |  |  | 0.06 |  |  | 0.09 |  | 0.11 |
| Total | $ | 0.72 |  |  | $ | (0.41) |  |  | $ | 1.35 |  |  | $ | 0.14 |  |

[0000833444-25-000029:8k_2_02:82]
8

[0000833444-25-000029:8k_2_02:83]
Johnson Controls International plc

[0000833444-25-000029:8k_2_02:84]
Condensed Consolidated Statements of Financial Position

[0000833444-25-000029:8k_2_02:85]
(in millions; unaudited)

[0000833444-25-000029:8k_2_02:86]
|  | March 31, 2025 |  | September 30, 2024 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 795 |  |  | $ | 606 |  |
| Accounts receivable - net | 5,858 |  |  | 6,051 |  |
| Inventories | 1,756 |  |  | 1,774 |  |
| Current assets held for sale | 1,856 |  |  | 1,595 |  |
| Other current assets | 1,085 |  |  | 1,153 |  |
| Current assets | 11,350 |  |  | 11,179 |  |
| Property, plant and equipment - net | 2,422 |  |  | 2,403 |  |
| Goodwill | 16,509 |  |  | 16,725 |  |
| Other intangible assets - net | 3,883 |  |  | 4,130 |  |
| Noncurrent assets held for sale | 3,101 |  |  | 3,210 |  |
| Other noncurrent assets | 5,102 |  |  | 5,048 |  |
| Total assets | $ | 42,367 |  |  | $ | 42,695 |  |
| Liabilities and Equity |  |  |  |
| Short-term debt | $ | 1,261 |  |  | $ | 953 |  |
| Current portion of long-term debt | 558 |  |  | 536 |  |
| Accounts payable | 3,254 |  |  | 3,389 |  |
| Accrued compensation and benefits | 832 |  |  | 1,048 |  |
| Deferred revenue | 2,380 |  |  | 2,160 |  |
| Current liabilities held for sale | 1,544 |  |  | 1,431 |  |
| Other current liabilities | 1,988 |  |  | 2,438 |  |
| Current liabilities | 11,817 |  |  | 11,955 |  |
| Long-term debt | 8,167 |  |  | 8,004 |  |
| Pension and postretirement benefit obligations | 181 |  |  | 217 |  |
| Noncurrent liabilities held for sale | 429 |  |  | 405 |  |
| Other noncurrent liabilities | 4,741 |  |  | 4,753 |  |
| Long-term liabilities | 13,518 |  |  | 13,379 |  |
| Shareholders’ equity attributable to Johnson Controls | 15,805 |  |  | 16,098 |  |
| Noncontrolling interests | 1,227 |  |  | 1,263 |  |
| Total equity | 17,032 |  |  | 17,361 |  |
| Total liabilities and equity | $ | 42,367 |  |  | $ | 42,695 |  |

[0000833444-25-000029:8k_2_02:87]
9

[0000833444-25-000029:8k_2_02:88]
Consolidated Statements of Cash Flows

[0000833444-25-000029:8k_2_02:89]
(in millions; unaudited)

[0000833444-25-000029:8k_2_02:90]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Operating Activities of Continuing Operations |  |  |  |  |  |  |  |
| Income (loss) from continuing operations attributable to Johnson Controls | $ | 473 |  |  | $ | (321) |  |  | $ | 836 |  |  | $ | 19 |  |
| Income from continuing operations attributable to noncontrolling interests | 2 |  |  | 3 |  |  | — |  |  | 3 |  |
| Income (loss) from continuing operations | 475 |  |  | (318) |  |  | 836 |  |  | 22 |  |
| Adjustments to reconcile net income to cash provided (used) by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization | 202 |  |  | 215 |  |  | 395 |  |  | 423 |  |
| Pension and postretirement income and contributions | (21) |  |  | (15) |  |  | (37) |  |  | (31) |  |
| Deferred income taxes | (53) |  |  | (339) |  |  | (107) |  |  | (419) |  |
| Noncash restructuring and impairment charges | 25 |  |  | 244 |  |  | 33 |  |  | 253 |  |
| Equity-based compensation | 31 |  |  | 25 |  |  | 59 |  |  | 54 |  |
| Other - net | 24 |  |  | (15) |  |  | 32 |  |  | (37) |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable | (191) |  |  | (549) |  |  | 93 |  |  | (509) |  |
| Inventories | (12) |  |  | (29) |  |  | (27) |  |  | (135) |  |
| Other assets | (42) |  |  | 5 |  |  | (213) |  |  | (190) |  |
| Restructuring reserves | (5) |  |  | (46) |  |  | (3) |  |  | (60) |  |
| Accounts payable and accrued liabilities | 180 |  |  | 517 |  |  | (227) |  |  | 202 |  |
| Accrued income taxes | (63) |  |  | (21) |  |  | (35) |  |  | (10) |  |
| Cash provided (used) by operating activities from continuing operations | 550 |  |  | (326) |  |  | 799 |  |  | (437) |  |
| Investing Activities of Continuing Operations |  |  |  |  |  |  |  |
| Capital expenditures | (94) |  |  | (128) |  |  | (210) |  |  | (210) |  |
| Other - net | (18) |  |  | (4) |  |  | (7) |  |  | 14 |  |
| Cash used by investing activities from continuing operations | (112) |  |  | (132) |  |  | (217) |  |  | (196) |  |
| Financing Activities of Continuing Operations |  |  |  |  |  |  |  |
| Net proceeds from borrowings with maturities less than three months | 346 |  |  | 427 |  |  | 358 |  |  | 1,543 |  |
| Proceeds from debt | — |  |  | — |  |  | 775 |  |  | 422 |  |
| Repayments of debt | (502) |  |  | (163) |  |  | (502) |  |  | (163) |  |
| Stock repurchases and retirements | (330) |  |  | (474) |  |  | (660) |  |  | (474) |  |
| Payment of cash dividends | (245) |  |  | (252) |  |  | (490) |  |  | (504) |  |
| Proceeds from the exercise of stock options | 61 |  |  | 8 |  |  | 105 |  |  | 20 |  |
| Employee equity-based compensation withholding taxes | (2) |  |  | (1) |  |  | (31) |  |  | (24) |  |
| Other - net | (3) |  |  | (41) |  |  | (29) |  |  | (80) |  |
| Cash provided (used) by financing activities from continuing operations | (675) |  |  | (496) |  |  | (474) |  |  | 740 |  |
| Discontinued Operations |  |  |  |  |  |  |  |
| Cash provided (used) by operating activities | 49 |  |  | 123 |  |  | 47 |  |  | (12) |  |
| Cash used by investing activities | (17) |  |  | (5) |  |  | (27) |  |  | (15) |  |
| Cash used by financing activities | (65) |  |  | (55) |  |  | (65) |  |  | (63) |  |
| Cash provided (used) by discontinued operations | (33) |  |  | 63 |  |  | (45) |  |  | (90) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (169) |  |  | (41) |  |  | (15) |  |  | 19 |  |
| Change in cash, cash equivalents and restricted cash held for sale | (1) |  |  | (4) |  |  | 3 |  |  | 1 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | (440) |  |  | (936) |  |  | 51 |  |  | 37 |  |
| Cash, cash equivalents and restricted cash at beginning of period | 1,258 |  |  | 1,890 |  |  | 767 |  |  | 917 |  |
| Cash, cash equivalents and restricted cash at end of period | 818 |  |  | 954 |  |  | 818 |  |  | 954 |  |
| Less: Restricted cash | 23 |  |  | 116 |  |  | 23 |  |  | 116 |  |
| Cash and cash equivalents at end of period | $ | 795 |  |  | $ | 838 |  |  | $ | 795 |  |  | $ | 838 |  |

[0000833444-25-000029:8k_2_02:91]
10

[0000833444-25-000029:8k_2_02:92]
FOOTNOTES

[0000833444-25-000029:8k_2_02:93]
1.Sale of Residential and Light Commercial HVAC Business

[0000833444-25-000029:8k_2_02:94]
The Company signed a definitive agreement in July 2024 to sell its Residential and Light Commercial ("R&LC") HVAC business, which includes the North America Ducted businesses and the global Residential joint venture with Hitachi Global Life Solutions, Inc. (“Hitachi”), of which Johnson Controls owns 60% and Hitachi owns 40%. The R&LC HVAC business, which was previously reported in the Global Products segment, meets the criteria to be classified as a discontinued operation and, as a result, its historical financial results are reflected in the consolidated financial statements as a discontinued operation, and assets and liabilities were reclassified as held for sale for all periods presented. Unless otherwise noted, all activities and amounts reported in the following footnotes include only continuing operations of the Company and exclude activities and amounts related to the R&LC HVAC business.

[0000833444-25-000029:8k_2_02:95]
2.Non-GAAP Measures

[0000833444-25-000029:8k_2_02:96]
The Company reports various non-GAAP measures in this earnings release and the related earnings presentation.  Non-GAAP measures should be considered in addition to, and not as replacements for, the most comparable GAAP measures. Refer to footnotes three through eight for further information on the calculations of the non-GAAP measures and reconciliations of the non-GAAP measures to the most comparable GAAP measures.

[0000833444-25-000029:8k_2_02:97]
Organic sales

[0000833444-25-000029:8k_2_02:98]
Organic sales growth excludes the impact of acquisitions, divestitures and foreign currency. Management believes organic sales growth is useful to investors in understanding period-over-period sales results and trends.

[0000833444-25-000029:8k_2_02:99]
Cash flow

[0000833444-25-000029:8k_2_02:100]
Management believes free cash flow and adjusted free cash flow measures are useful to investors in understanding the strength of the Company and its ability to generate cash. These non-GAAP measures can also be used to evaluate the Company’s ability to generate cash flow from operations and the impact that this cash flow has on its liquidity. Management also believes adjusted free cash flows are useful to investors in understanding period-over-period cash flows, cash trends and ongoing cash flows of the Company.

[0000833444-25-000029:8k_2_02:101]
Adjusted free cash flow and adjusted free cash flow conversion are non-GAAP measures which exclude the impacts of the following:

[0000833444-25-000029:8k_2_02:102]
•JC Capital cash flows primarily include activity associated with finance/notes receivables and inventory and/or capital expenditures related to lease arrangements. JC Capital net income is primarily related to interest income on the finance/notes receivable and profit recognized on arrangements with sales-type lease components.

[0000833444-25-000029:8k_2_02:103]
•Effective January 1, 2024, the Company has excluded the impact of discontinuing its accounts receivables factoring programs from adjusted free cash flow and adjusted free cash flow conversion. The Company has also re-baselined the prior year adjusted free cash flow measures to present a more comparative measure without the impact of factoring.

[0000833444-25-000029:8k_2_02:104]
•Cash payments related to the water systems AFFF settlement and cash receipts for AFFF-related insurance recoveries.

[0000833444-25-000029:8k_2_02:105]
Adjusted financial measures

[0000833444-25-000029:8k_2_02:106]
Adjusted financial measures include adjusted segment EBITA, adjusted segment EBITA margin, adjusted net income, adjusted earnings per share, adjusted EBIT, adjusted EBITDA and adjusted corporate expenses. These non-GAAP measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the excluded amounts is a matter of management judgment and depends upon the nature and variability of the underlying expense or income amounts and other factors.

[0000833444-25-000029:8k_2_02:107]
11

[0000833444-25-000029:8k_2_02:108]
As detailed in the tables included in footnotes five through eight, the following items were excluded from certain financial measures:

[0000833444-25-000029:8k_2_02:109]
•Net mark-to-market adjustments are the result of adjusting restricted asbestos investments and pension and postretirement plan assets to their current market value. These adjustments may have a favorable or unfavorable impact on results.

[0000833444-25-000029:8k_2_02:110]
•Restructuring and impairment costs, net of NCI represents restructuring costs attributable to Johnson Controls including costs associated with exit plans or other restructuring plans that will have a more significant impact on the underlying cost structure of the organization. Impairment costs primarily relate to write-downs of goodwill, intangible assets and assets held for sale to their fair value.

[0000833444-25-000029:8k_2_02:111]
•Water systems AFFF settlement and insurance recoveries include amounts related to a settlement with a nationwide class of public water systems concerning the use of AFFF manufactured and sold by a subsidiary of the Company, and AFFF-related insurance recoveries.

[0000833444-25-000029:8k_2_02:112]
•Transaction/separation costs include costs associated with significant mergers and acquisitions.

[0000833444-25-000029:8k_2_02:113]
•Transformation costs represent incremental expenses incurred in association with strategic growth initiatives and cost saving opportunities in order to realize the benefits of portfolio simplification and the Company's lifecycle solutions strategy.

[0000833444-25-000029:8k_2_02:114]
•Earn-out adjustments relate to earn-out liabilities associated with certain significant acquisitions and may have a favorable or unfavorable impact on results.

[0000833444-25-000029:8k_2_02:115]
•Cyber incident costs primarily represent expenses, net of insurance recoveries, associated with the response to, and remediation of, a cybersecurity incident which occurred in September 2023.

[0000833444-25-000029:8k_2_02:116]
•Global Products product quality costs are costs related to a product quality issue within the Global Products segment that is unusual due to the magnitude of the expected cost to remediate in comparison to typical product quality issues experienced by the Company.

[0000833444-25-000029:8k_2_02:117]
•Loss on divestiture relates to the sale of the ADTi business.

[0000833444-25-000029:8k_2_02:118]
•EMEA/LA joint venture loss relates to certain non-recurring losses associated with the equity method accounting of a joint venture company.

[0000833444-25-000029:8k_2_02:119]
•Discrete tax items, net includes the net impact of discrete tax items within the period, including the following types of items: changes in estimates associated with valuation allowances, changes in estimates associated with reserves for uncertain tax positions, withholding taxes recorded upon changes in indefinite re-investment assertions for businesses to be disposed of, impacts from statutory rate changes, and the recording of significant tax credits.

[0000833444-25-000029:8k_2_02:120]
•Related tax impact includes the tax impact of the various excluded items.

[0000833444-25-000029:8k_2_02:121]
Management believes the exclusion of these items is useful to investors due to the unusual nature and/or magnitude of the amounts. When considered together with unadjusted amounts, adjusted financial measures are useful to investors in understanding period-over-period operating results, business trends and ongoing operations of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes.

[0000833444-25-000029:8k_2_02:122]
Debt ratios

[0000833444-25-000029:8k_2_02:123]
Management believes that net debt to adjusted EBITDA, a non-GAAP measure, is useful to understanding the Company's financial condition as the ratio provides an overview of the extent to which the Company relies on external debt financing for its funding and also is a measure of risk to its shareholders.

[0000833444-25-000029:8k_2_02:124]
12

[0000833444-25-000029:8k_2_02:125]
3. Sales

[0000833444-25-000029:8k_2_02:126]
The following tables detail the changes in sales from continuing operations attributable to organic growth, foreign currency, acquisitions, divestitures and other (unaudited):

[0000833444-25-000029:8k_2_02:127]
|  | Three Months Ended March 31 |
| Net sales | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Net sales - 2024 | $ | 2,739 |  |  | $ | 1,064 |  |  | $ | 491 |  |  | $ | 4,294 |  |  | $ | 1,303 |  |  | $ | 5,597 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | — |  |  | — |  |  | — |  |  | (242) |  |  | (242) |  |
| Foreign currency | (10) |  |  | (36) |  |  | (11) |  |  | (57) |  |  | (12) |  |  | (69) |  |
| Adjusted base net sales | 2,729 |  |  | 1,028 |  |  | 480 |  |  | 4,237 |  |  | 1,049 |  |  | 5,286 |  |
| Acquisitions | — |  |  | 9 |  |  | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Organic growth | 187 |  |  | 48 |  |  | 62 |  |  | 297 |  |  | 84 |  |  | 381 |  |
| Net sales - 2025 | $ | 2,916 |  |  | $ | 1,085 |  |  | $ | 542 |  |  | $ | 4,543 |  |  | $ | 1,133 |  |  | $ | 5,676 |  |
| Growth %: |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | 6 | % |  | 2 | % |  | 10 | % |  | 6 | % |  | (13) | % |  | 1 | % |
| Organic growth | 7 | % |  | 5 | % |  | 13 | % |  | 7 | % |  | 8 | % |  | 7 | % |

[0000833444-25-000029:8k_2_02:128]
|  | Six Months Ended March 31 |
| Net sales | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Net sales - 2024 | $ | 5,226 |  |  | $ | 2,102 |  |  | $ | 998 |  |  | $ | 8,326 |  |  | $ | 2,480 |  |  | $ | 10,806 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | — |  |  | — |  |  | — |  |  | (475) |  |  | (475) |  |
| Foreign currency | (13) |  |  | (61) |  |  | (14) |  |  | (88) |  |  | (14) |  |  | (102) |  |
| Adjusted base net sales | 5,213 |  |  | 2,041 |  |  | 984 |  |  | 8,238 |  |  | 1,991 |  |  | 10,229 |  |
| Acquisitions | — |  |  | 12 |  |  | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Organic growth | 447 |  |  | 105 |  |  | 85 |  |  | 637 |  |  | 224 |  |  | 861 |  |
| Net sales - 2025 | $ | 5,660 |  |  | $ | 2,158 |  |  | $ | 1,069 |  |  | $ | 8,887 |  |  | $ | 2,215 |  |  | $ | 11,102 |  |
| Growth %: |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | 8 | % |  | 3 | % |  | 7 | % |  | 7 | % |  | (11) | % |  | 3 | % |
| Organic growth | 9 | % |  | 5 | % |  | 9 | % |  | 8 | % |  | 11 | % |  | 8 | % |

[0000833444-25-000029:8k_2_02:129]
13

[0000833444-25-000029:8k_2_02:130]
|  | Three Months Ended March 31 |
| Products and systems revenue | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Products and systems revenue - 2024 | $ | 1,700 |  |  | $ | 572 |  |  | $ | 308 |  |  | $ | 2,580 |  |  | $ | 1,303 |  |  | $ | 3,883 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | — |  |  | — |  |  | — |  |  | (242) |  |  | (242) |  |
| Foreign currency | (5) |  |  | (20) |  |  | (7) |  |  | (32) |  |  | (12) |  |  | (44) |  |
| Adjusted products and systems revenue | 1,695 |  |  | 552 |  |  | 301 |  |  | 2,548 |  |  | 1,049 |  |  | 3,597 |  |
| Acquisitions | — |  |  | 7 |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Organic growth | 135 |  |  | 6 |  |  | 36 |  |  | 177 |  |  | 84 |  |  | 261 |  |
| Products and systems revenue - 2025 | $ | 1,830 |  |  | $ | 565 |  |  | $ | 337 |  |  | $ | 2,732 |  |  | $ | 1,133 |  |  | $ | 3,865 |  |
| Growth %: |  |  |  |  |  |  |  |  |  |  |  |
| Products and systems revenue | 8 | % |  | (1) | % |  | 9 | % |  | 6 | % |  | (13) | % |  | — | % |
| Organic growth | 8 | % |  | 1 | % |  | 12 | % |  | 7 | % |  | 8 | % |  | 7 | % |

[0000833444-25-000029:8k_2_02:131]
|  | Six Months Ended March 31 |
| Products and systems revenue | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Products and systems revenue - 2024 | $ | 3,218 |  |  | $ | 1,144 |  |  | $ | 645 |  |  | $ | 5,007 |  |  | $ | 2,480 |  |  | $ | 7,487 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | — |  |  | — |  |  | — |  |  | (475) |  |  | (475) |  |
| Foreign currency | (5) |  |  | (32) |  |  | (10) |  |  | (47) |  |  | (14) |  |  | (61) |  |
| Adjusted products and systems revenue | 3,213 |  |  | 1,112 |  |  | 635 |  |  | 4,960 |  |  | 1,991 |  |  | 6,951 |  |
| Acquisitions | — |  |  | 9 |  |  | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Organic growth | 311 |  |  | 19 |  |  | 36 |  |  | 366 |  |  | 224 |  |  | 590 |  |
| Products and systems revenue - 2025 | $ | 3,524 |  |  | $ | 1,140 |  |  | $ | 671 |  |  | $ | 5,335 |  |  | $ | 2,215 |  |  | $ | 7,550 |  |
| Growth %: |  |  |  |  |  |  |  |  |  |  |  |
| Products and systems revenue | 10 | % |  | — | % |  | 4 | % |  | 7 | % |  | (11) | % |  | 1 | % |
| Organic growth | 10 | % |  | 2 | % |  | 6 | % |  | 7 | % |  | 11 | % |  | 8 | % |

[0000833444-25-000029:8k_2_02:132]
14

[0000833444-25-000029:8k_2_02:133]
|  | Three Months Ended March 31 |
| Service revenue | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Service revenue - 2024 | $ | 1,039 |  |  | $ | 492 |  |  | $ | 183 |  |  | $ | 1,714 |  |  | $ | — |  |  | $ | 1,714 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Foreign currency | (5) |  |  | (16) |  |  | (4) |  |  | (25) |  |  | — |  |  | (25) |  |
| Adjusted base service revenue | 1,034 |  |  | 476 |  |  | 179 |  |  | 1,689 |  |  | — |  |  | 1,689 |  |
| Acquisitions | — |  |  | 2 |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Organic growth | 52 |  |  | 42 |  |  | 26 |  |  | 120 |  |  | — |  |  | 120 |  |
| Service revenue - 2025 | $ | 1,086 |  |  | $ | 520 |  |  | $ | 205 |  |  | $ | 1,811 |  |  | $ | — |  |  | $ | 1,811 |  |
| Growth %: |  |  |  |  |  |  |  |  |  |  |  |
| Service revenue | 5 | % |  | 6 | % |  | 12 | % |  | 6 | % |  | — | % |  | 6 | % |
| Organic growth | 5 | % |  | 9 | % |  | 15 | % |  | 7 | % |  | — | % |  | 7 | % |

[0000833444-25-000029:8k_2_02:134]
|  | Six Months Ended March 31 |
| Service revenue | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Service revenue - 2024 | $ | 2,008 |  |  | $ | 958 |  |  | $ | 353 |  |  | $ | 3,319 |  |  | $ | — |  |  | $ | 3,319 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Foreign currency | (8) |  |  | (29) |  |  | (4) |  |  | (41) |  |  | — |  |  | (41) |  |
| Adjusted base service revenue | 2,000 |  |  | 929 |  |  | 349 |  |  | 3,278 |  |  | — |  |  | 3,278 |  |
| Acquisitions | — |  |  | 3 |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Organic growth | 136 |  |  | 86 |  |  | 49 |  |  | 271 |  |  | — |  |  | 271 |  |
| Service revenue - 2025 | $ | 2,136 |  |  | $ | 1,018 |  |  | $ | 398 |  |  | $ | 3,552 |  |  | $ | — |  |  | $ | 3,552 |  |
| Growth %: |  |  |  |  |  |  |  |  |  |  |  |
| Service revenue | 6 | % |  | 6 | % |  | 13 | % |  | 7 | % |  | — | % |  | 7 | % |
| Organic growth | 7 | % |  | 9 | % |  | 14 | % |  | 8 | % |  | — | % |  | 8 | % |

[0000833444-25-000029:8k_2_02:135]
15

[0000833444-25-000029:8k_2_02:136]
4.   Cash Flow, Free Cash Flow and Free Cash Flow Conversion

[0000833444-25-000029:8k_2_02:137]
The following table includes operating cash flow conversion, free cash flow and free cash flow conversion (unaudited):

[0000833444-25-000029:8k_2_02:138]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
| (in millions) | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Cash provided (used) by operating activities from continuing operations | $ | 550 |  | $ | (326) |  | $ | 799 |  | $ | (437) |
| Income (loss) from continuing operations attributable to Johnson Controls | 473 |  | (321) |  | 836 |  | 19 |
| Operating cash flow conversion | 116 | % |  | * |  | 96 | % |  | * |
| Cash provided (used) by operating activities from continuing operations | 550 |  | (326) |  | 799 |  | (437) |
| Capital expenditures | (94) |  | (128) |  | (210) |  | (210) |
| Free cash flow (non-GAAP) | $ | 456 |  | $ | (454) |  | $ | 589 |  | $ | (647) |
| Income (loss) from continuing operations attributable to Johnson Controls | 473 |  | (321) |  | 836 |  | 19 |
| Free cash flow conversion from net income (non-GAAP) | 96 | % |  | * |  | 70 | % |  | * |

[0000833444-25-000029:8k_2_02:139]
* Measure not meaningful

[0000833444-25-000029:8k_2_02:140]
The following table includes adjusted free cash flow and adjusted free cash flow conversion (unaudited):

[0000833444-25-000029:8k_2_02:141]
|  | Three Months Ended March 31, |  |  | Six Months Ended March 31, |  |
| (in millions) | 2025 |  | 2024 |  |  | 2025 |  | 2024 |  |
| Free cash flow (non-GAAP) | $ | 456 |  | $ | (454) |  |  | $ | 589 |  | $ | (647) |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| JC Capital cash used by operating activities | 11 |  | 32 |  |  | 77 |  | 120 |  |
| Water systems AFFF settlement cash payments and insurance recoveries | (11) |  | — |  |  | 386 |  | — |  |
| Impact from discontinuation of factoring programs | 7 |  | — |  |  | 14 |  | — |  |
| Adjusted free cash flow (non-GAAP) | 463 |  | (422) |  |  | 1,066 |  | (527) |  |
| Prior year impact from factoring programs | — |  | 619 |  |  | — |  | 534 |  |
| Re-baselined adjusted free cash flow (non-GAAP) | $ | 463 |  | $ | 197 |  |  | $ | 1,066 |  | $ | 7 |  |
| Adjusted net income attributable to JCI (non-GAAP) | $ | 545 |  | $ | 471 |  |  | $ | 971 |  | $ | 786 |  |
| JC Capital net income (loss) | 9 |  | (3) |  |  | 4 |  | (5) |  |
| Adjusted net income attributable to JCI, excluding JC Capital (non-GAAP) | $ | 554 |  | $ | 468 |  |  | $ | 975 |  | $ | 781 |  |
| Adjusted free cash flow conversion (non-GAAP) | 84 | % |  | 42 | % |  |  | 109 | % |  | 1 | % |  |

[0000833444-25-000029:8k_2_02:142]
16

[0000833444-25-000029:8k_2_02:143]
5. EBITA, EBIT and Corporate Expense

[0000833444-25-000029:8k_2_02:144]
The Company evaluates the performance of its business units primarily on segment EBITA. The following table includes continuing operations (unaudited):

[0000833444-25-000029:8k_2_02:145]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | Actual |  | Adjusted(Non-GAAP) |  | Actual |  | Adjusted(Non-GAAP) |
| (in millions) | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 390 |  |  | $ | 373 |  |  | $ | 390 |  |  | $ | 373 |  |  | $ | 722 |  |  | $ | 658 |  |  | $ | 722 |  |  | $ | 658 |  |
| Building Solutions EMEA/LA | 136 |  |  | 89 |  | 136 |  |  | 89 |  |  | 244 |  |  | 169 |  |  | 244 |  |  | 169 |  |
| Building Solutions Asia Pacific | 79 |  |  | 54 |  | 79 |  |  | 54 |  |  | 128 |  |  | 100 |  |  | 128 |  |  | 100 |  |
| Global Products | 341 |  |  | 290 |  |  | 343 |  |  | 316 |  |  | 667 |  |  | 557 |  |  | 669 |  |  | 583 |  |
| EBIT (non-GAAP) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) from continuing operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Attributable to Johnson Controls | $ | 473 |  |  | $ | (321) |  |  | $ | 545 |  |  | $ | 471 |  |  | $ | 836 |  |  | $ | 19 |  |  | $ | 971 |  |  | $ | 786 |  |
| Attributable to noncontrolling interests | 2 |  |  | 3 |  |  | 2 |  |  | 3 |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Income (loss) from continuing operations | 475 |  |  | (318) |  |  | 547 |  |  | 474 |  |  | 836 |  |  | 22 |  |  | 971 |  |  | 789 |  |
| Less: Income tax provision (benefit) (1) | 26 |  |  | (153) |  |  | 74 |  |  | 64 |  |  | 73 |  |  | (173) |  |  | 132 |  |  | 105 |  |
| Income (loss) before income taxes | 501 |  |  | (471) |  |  | 621 |  |  | 538 |  |  | 909 |  |  | (151) |  |  | 1,103 |  |  | 894 |  |
| Net financing charges | 80 |  |  | 89 |  |  | 80 |  |  | 89 |  |  | 166 |  |  | 176 |  |  | 166 |  |  | 176 |  |
| EBIT (non-GAAP) | $ | 581 |  |  | $ | (382) |  |  | $ | 701 |  |  | $ | 627 |  |  | $ | 1,075 |  |  | $ | 25 |  |  | $ | 1,269 |  |  | $ | 1,070 |  |

[0000833444-25-000029:8k_2_02:146]
(1) Adjusted income tax provision (benefit) excludes the related tax impacts of pre-tax adjusting items.

[0000833444-25-000029:8k_2_02:147]
The following tables include the reconciliations of segment EBITA as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-25-000029:8k_2_02:148]
|  | Three Months Ended March 31, |
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building SolutionsAsia Pacific |  | Global Products |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Sales | $ | 2,916 |  |  | $ | 2,739 |  |  | $ | 1,085 |  |  | $ | 1,064 |  |  | $ | 542 |  |  | $ | 491 |  |  | $ | 1,133 |  |  | $ | 1,303 |  |
| Segment EBITA | $ | 390 |  |  | $ | 373 |  |  | $ | 136 |  |  | $ | 89 |  |  | $ | 79 |  |  | $ | 54 |  |  | $ | 341 |  |  | $ | 290 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Transformation costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |
| Earn-out adjustments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (7) |  |
| Global Products product quality costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 33 |  |
| Adjusted segment EBITA(non-GAAP) | $ | 390 |  |  | $ | 373 |  |  | $ | 136 |  |  | $ | 89 |  |  | $ | 79 |  |  | $ | 54 |  |  | $ | 343 |  |  | $ | 316 |  |
| Adjusted segment EBITA Margin % (non-GAAP) | 13.4 | % |  | 13.6 | % |  | 12.5 | % |  | 8.4 | % |  | 14.6 | % |  | 11.0 | % |  | 30.3 | % |  | 24.3 | % |

[0000833444-25-000029:8k_2_02:149]
17

[0000833444-25-000029:8k_2_02:150]
|  | Six Months Ended March 31, |
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building SolutionsAsia Pacific |  | Global Products |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Sales | $ | 5,660 |  |  | $ | 5,226 |  |  | $ | 2,158 |  |  | $ | 2,102 |  |  | $ | 1,069 |  |  | $ | 998 |  |  | $ | 2,215 |  |  | $ | 2,480 |  |
| Segment EBITA | $ | 722 |  |  | $ | 658 |  |  | $ | 244 |  |  | $ | 169 |  |  | $ | 128 |  |  | $ | 100 |  |  | $ | 667 |  |  | $ | 557 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Transformation costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |
| Earn-out adjustments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (7) |  |
| Global Products product quality costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 33 |  |
| Adjusted segment EBITA(non-GAAP) | $ | 722 |  |  | $ | 658 |  |  | $ | 244 |  |  | $ | 169 |  |  | $ | 128 |  |  | $ | 100 |  |  | $ | 669 |  |  | $ | 583 |  |
| Adjusted segment EBITA Margin % (non-GAAP) | 12.8 | % |  | 12.6 | % |  | 11.3 | % |  | 8.0 | % |  | 12.0 | % |  | 10.0 | % |  | 30.2 | % |  | 23.5 | % |

[0000833444-25-000029:8k_2_02:151]
The following table reconciles Corporate expense from continuing operations as reported to the comparable adjusted amounts (unaudited):

[0000833444-25-000029:8k_2_02:152]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |  |  |  |  |
| (in millions) | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  |  |
| Corporate expense (GAAP) | $ | 186 |  |  | $ | 92 |  |  | $ | 357 |  |  | $ | 231 |  |  |  |  |  |
|  |  |  |  |  | . |  |  |  |  |  |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Transaction/separation costs | (7) |  |  | (5) |  |  | (18) |  |  | (5) |  |  |  |  |  |
| Transformation costs | (44) |  |  | — |  |  | (77) |  |  | — |  |  |  |  |  |
| Cyber incident costs | — |  |  | (4) |  |  |  |  | (27) |  |  |  |  |  |
| Adjusted corporate expense (non-GAAP) | $ | 135 |  |  | $ | 83 |  |  | $ | 262 |  |  | $ | 199 |  |  |  |  |  |

[0000833444-25-000029:8k_2_02:153]
18

[0000833444-25-000029:8k_2_02:154]
6.  Net Income and Diluted Earnings Per Share

[0000833444-25-000029:8k_2_02:155]
The following tables reconcile income from continuing operations attributable to JCI and diluted earnings per share from continuing operations as reported to the comparable adjusted amounts (unaudited):

[0000833444-25-000029:8k_2_02:156]
|  | Three Months Ended March 31, |
|  | Income from continuing operations attributable to JCI |  | Diluted earnings per share |
| (in millions, except per share) | 2025 |  | 2024 |  | 2025 |  | 2024 |
| As reported (GAAP) | $ | 473 |  |  | $ | (321) |  |  | $ | 0.71 |  |  | $ | (0.47) |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | 13 |  |  | (15) |  |  | 0.02 |  |  | (0.02) |  |
| Earn-out adjustments | — |  |  | (7) |  |  | — |  |  | (0.01) |  |
| Restructuring and impairment costs, net of NCI | 62 |  |  | 239 |  |  | 0.09 |  |  | 0.35 |  |
| Water systems AFFF settlement | — |  |  | 750 |  |  | — |  |  | 1.10 |  |
| Water systems AFFF insurance recoveries | (8) |  |  | — |  |  | (0.01) |  |  | — |  |
| Global Products product quality costs | — |  |  | 33 |  |  | — |  |  | 0.05 |  |
| Transaction/separation costs | 7 |  |  | 5 |  |  | 0.01 |  |  | 0.01 |  |
| Transformation costs | 46 |  |  | — |  |  | 0.07 |  |  | — |  |
| Cyber incident costs | — |  |  | 4 |  |  | — |  |  | 0.01 |  |
| Discrete tax items | (36) |  |  | — |  |  | (0.05) |  |  | — |  |
| Related tax impact | (12) |  |  | (217) |  |  | (0.02) |  |  | (0.32) |  |
| Adjusted (non-GAAP)* | $ | 545 |  |  | $ | 471 |  |  | $ | 0.82 |  |  | $ | 0.69 |  |

[0000833444-25-000029:8k_2_02:157]
* May not sum due to rounding

[0000833444-25-000029:8k_2_02:158]
|  | Six Months Ended March 31, |
|  | Income from continuing operations attributable to JCI |  | Diluted earnings per share |
| (in millions, except per share) | 2025 |  | 2024 |  | 2025 |  | 2024 |
| As reported (GAAP) | $ | 836 |  |  | $ | 19 |  |  | $ | 1.26 |  |  | $ | 0.03 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | 14 |  |  | (37) |  |  | 0.02 |  |  | (0.05) |  |
| Earn-out adjustments | — |  |  | (7) |  |  | — |  |  | (0.01) |  |
| Restructuring and impairment costs, net of NCI | 95 |  |  | 274 |  |  | 0.14 |  |  | 0.40 |  |
| Water systems AFFF settlement | — |  |  | 750 |  |  | — |  |  | 1.10 |  |
| Water systems AFFF insurance recoveries | (12) |  |  | — |  |  | (0.02) |  |  | — |  |
| Global Products product quality issue | — |  |  | 33 |  |  | — |  |  | 0.05 |  |
| Transaction/separation costs | 18 |  |  | 5 |  |  | 0.03 |  |  | 0.01 |  |
| Transformation costs | 79 |  |  | — |  |  | 0.12 |  |  | — |  |
| Cyber incident costs | — |  |  | 27 |  |  | — |  |  | 0.04 |  |
| Discrete tax items | (36) |  |  | (57) |  |  | (0.05) |  |  | (0.08) |  |
| Related tax impact | (23) |  |  | (221) |  |  | (0.03) |  |  | (0.32) |  |
| Adjusted (non-GAAP)* | $ | 971 |  |  | $ | 786 |  |  | $ | 1.46 |  |  | $ | 1.15 |  |

[0000833444-25-000029:8k_2_02:159]
* May not sum due to rounding

[0000833444-25-000029:8k_2_02:160]
19

[0000833444-25-000029:8k_2_02:161]
The following table reconciles the denominators used to calculate basic and diluted earnings per share (in millions; unaudited):

[0000833444-25-000029:8k_2_02:162]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Weighted average shares outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 659.1 |  |  | 679 |  | $ | 660.6 |  |  | $ | 679.9 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 1.9 |  |  | — |  |  | 2.4 |  |  | 1.6 |  |
| Diluted weighted average shares outstanding | 661.0 |  |  | 679.0 |  |  | 663.0 |  |  | 681.5 |  |

[0000833444-25-000029:8k_2_02:163]
For the three months ended March 31, 2024, the total number of potential dilutive shares due to stock options, unvested restricted stock and unvested performance share awards was 1.6 million. However, these items were not included in the computation of diluted loss per share for the three months ended March 31, 2024 since to do so would decrease the loss per share.

[0000833444-25-000029:8k_2_02:164]
7.  Debt Ratios

[0000833444-25-000029:8k_2_02:165]
The following table includes continuing operations and details net debt to income before income taxes and net debt to adjusted EBITDA (unaudited):

[0000833444-25-000029:8k_2_02:166]
| (in millions) | March 31, 2025 |  | December 31, 2024 |  | March 31, 2024 |  |  |
| Short-term debt | $ | 1,261 |  |  | $ | 882 |  |  | $ | 2,210 |  |  |  |
| Current portion of long-term debt | 558 |  |  | 522 |  |  | 1,165 |  |  |  |
| Long-term debt | 8,167 |  |  | 8,589 |  |  | 7,348 |  |  |  |
| Total debt | 9,986 |  |  | 9,993 |  |  | 10,723 |  |  |  |
| Less: cash and cash equivalents | 795 |  |  | 1,237 |  |  | 838 |  |  |  |
| Net debt | $ | 9,191 |  |  | $ | 8,756 |  |  | $ | 9,885 |  |  |  |
| Last twelve months income before income taxes | $ | 2,582 |  |  | $ | 1,610 |  |  | $ | 811 |  |  |  |
| Net debt to income before income taxes | 3.6 | x |  | 5.4 | x |  | 12.2 | x |  |  |
| Last twelve months adjusted EBITDA (non-GAAP) | $ | 3,779 |  |  | $ | 3,733 |  |  | $ | 3,423 |  |  |  |
| Net debt to adjusted EBITDA (non-GAAP) | 2.4x |  | 2.3x |  | 2.9x |  |  |

[0000833444-25-000029:8k_2_02:167]
20

[0000833444-25-000029:8k_2_02:168]
The following table reconciles income from continuing operations to adjusted EBIT and adjusted EBITDA (unaudited):

[0000833444-25-000029:8k_2_02:169]
|  | Twelve Months Ended |  |  |
| (in millions) | March 31, 2025 |  | December 31, 2024 |  | March 31, 2024 |  |  |
| Income from continuing operations | $ | 2,225 |  |  | $ | 1,432 |  |  | $ | 1,457 |  |  |  |
| Income tax provision (benefit) | 357 |  |  | 178 |  |  | (646) |  |  |  |
| Income before income taxes | 2,582 |  |  | 1,610 |  |  | 811 |  |  |  |
| Net financing charges | 332 |  |  | 341 |  |  | 306 |  |  |  |
| EBIT | 2,914 |  |  | 1,951 |  |  | 1,117 |  |  |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | 4 |  |  | (24) |  |  | 57 |  |  |  |
| Restructuring and impairment costs | 330 |  |  | 507 |  |  | 565 |  |  |  |
| Water systems AFFF settlement | — |  |  | 750 |  |  | 750 |  |  |  |
| Water systems AFFF insurance recoveries | (379) |  |  | (371) |  |  | — |  |  |  |
| Earn-out adjustments | (61) |  |  | (68) |  |  | (7) |  |  |  |
| Transaction/separation costs | 45 |  |  | 43 |  |  | 68 |  |  |  |
| Transformation costs | 79 |  |  | 33 |  |  | — |  |  |  |
| Cyber incident costs | — |  |  | 4 |  |  | 27 |  |  |  |
| Global Products product quality costs | — |  |  | 33 |  |  | 33 |  |  |  |
| Loss on divestiture | 42 |  |  | 42 |  |  | — |  |  |  |
| EMEA/LA joint venture loss | 17 |  |  | 17 |  |  | — |  |  |  |
| Adjusted EBIT (non-GAAP) | 2,991 |  |  | 2,917 |  |  | 2,610 |  |  |  |
| Depreciation and amortization | 788 |  |  | 816 |  |  | 813 |  |  |  |
| Adjusted EBITDA (non-GAAP) | $ | 3,779 |  |  | $ | 3,733 |  |  | $ | 3,423 |  |  |  |

[0000833444-25-000029:8k_2_02:170]
8.  Income Taxes

[0000833444-25-000029:8k_2_02:171]
The Company's effective tax rate before consideration of certain excluded items was approximately 12.0% for the three and six months ending March 31, 2025 and 11.9% and 11.7% for the three and six months ending March 31, 2024, respectively.

[0000833444-25-000029:8k_2_02:172]
21
