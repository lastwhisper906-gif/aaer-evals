# JCI notes — 0000833444-16-000172


## us-gaap:DividendsDeclaredTableTextBlock

[0000833444-16-000172:notes:1]
86


## tyc:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesAndNewAccountingPronouncementsTextBlock

[0000833444-16-000172:notes:2]
Basis of Presentation and Summary of Significant Accounting Policies

[0000833444-16-000172:notes:3]
Basis of Presentation—The Consolidated Financial Statements included herein are unaudited, but in the opinion of management, such financial statements include all adjustments, consisting of normal recurring adjustments, necessary to summarize fairly the Company's financial position, results of operations and cash flows for the interim period. The unaudited Consolidated Financial Statements include the consolidated results of Tyco International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Tyco and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Tyco"). The unaudited Consolidated Financial Statements have been prepared in United States dollars ("USD") and in accordance with the instructions to Form 10-Q under the Securities and Exchange Act of 1934, as amended. The results reported in these unaudited Consolidated Financial Statements should not be taken as indicative of results that may be expected for the entire year.  These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K for the fiscal year ended September 25, 2015 (the "2015 Form 10-K") and Current Report filed on Form 8-K filed on March 11, 2016 which recast the Company's consolidated financial statements for each of the three years in the period ended September 25, 2015 to reflect changes in the presentation of operating income by segment. The information included in this Form 8-K was presented for informational purposes only and does not amend or restate the Company’s audited consolidated financial statements, which were included in its 2015 Form 10-K, and did not affect the Company’s previously reported net income, earnings per share, cash flows, operating income or assets or liabilities for any of the periods presented therein.

[0000833444-16-000172:notes:4]
References to 2016 and 2015 are to Tyco's fiscal quarters ending March 25, 2016 and March 27, 2015, respectively, unless otherwise indicated.  The Company has a 52- or 53-week fiscal year that ends on the last Friday in September.  Fiscal 2016 is a 53-week year as compared with fiscal 2015, which was 52 weeks, with the additional week occurring in the fourth quarter of fiscal 2016.  The Company's results for the quarters and six months ended March 25, 2016 and March 27, 2015 both consisted of 13 weeks and 26 weeks, respectively.

[0000833444-16-000172:notes:5]
The Company operates and reports financial and operating information in the following three segments: North America Integrated Solutions & Services ("NA Integrated Solutions & Services"), Rest of World Integrated Solutions & Services ("ROW Integrated Solutions & Services") and Global Products. The Company also provides general corporate services to its segments which is reported as a fourth, non-operating segment, Corporate and Other.

[0000833444-16-000172:notes:6]
Proposed Merger with Johnson Controls, Inc.— On January 24, 2016, Tyco entered into an Agreement and Plan of Merger (the “Merger Agreement”) with Johnson Controls, Inc., a Wisconsin corporation (“Johnson Controls”), and certain other parties named therein, including Jagara Merger Sub LLC, a Wisconsin limited liability company and indirect wholly owned subsidiary of Tyco (“Merger Sub”). Pursuant to the Merger Agreement and subject to the terms and conditions set forth therein, Merger Sub will merge with and into Johnson Controls (the “Merger”), with Johnson Controls surviving the Merger as an indirect wholly owned subsidiary of Tyco. At the effective time of the Merger, Tyco will change its name to “Johnson Controls plc” and will trade under the ticker symbol “JCI.” Following such time, Tyco is referred to below as the “Combined Company.”

[0000833444-16-000172:notes:7]
As a result of the Merger, each outstanding share of Johnson Controls common stock (the “Johnson Controls Shares”), other than shares held by Johnson Controls, its subsidiaries, Tyco or Merger Sub, will be converted into the right to receive (subject to proration as described below), at the holder’s election, either: (i) one (1) (the “Exchange Ratio”) ordinary share of the Combined Company (the “Share Consideration”); or (ii) an amount in cash equal to $34.88 (the “Cash Consideration”). Elections will be prorated so that Johnson Controls shareholders will receive in the aggregate approximately $3.864 billion of cash in the Merger (the “Aggregate Cash Consideration”). Holders that do not make an election will be treated as having elected to receive the Share Consideration. The Exchange Ratio takes into account the effects of a Tyco share consolidation contemplated by the Merger Agreement whereby, immediately prior to the Merger, every issued and unissued ordinary share of Tyco (each, a “Tyco Share”) will be consolidated into 0.955 of a share of Tyco.

[0000833444-16-000172:notes:8]
The completion of the Merger is subject to certain closing conditions, including, among others, (i) the approval and adoption of the Merger Agreement by holders of two-thirds of the Johnson Controls Shares entitled to vote on such matter, (ii) the approval by the Tyco shareholders, at a special meeting of the Tyco shareholders (the “Tyco Special Meeting”) of (A) the issuance of Tyco shares in connection with the Merger, (B) the Tyco share consolidation and (C) the increase in Tyco’s authorized share capital, in each case, by a majority of the votes cast on these matters at the Tyco Special Meeting, and of certain amendments to Tyco’s articles of association, including a change of its name to “Johnson Controls plc,” by at least 75% of the votes cast on these matters at the Tyco Special Meeting (clause (ii), collectively, the “Tyco Shareholder Approvals”), (iii) the expiration or termination of any waiting period applicable to the Merger under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, the consent of, or filing with, certain specified antitrust authorities, and certain other customary regulatory approvals, and (iv) Tyco’s obtaining the financing required to close the Merger on the terms set forth in the Merger Agreement.

[0000833444-16-000172:notes:9]
The Merger Agreement contains specified termination rights, including, among others, the right of either party to terminate the Merger Agreement (i) if the requisite shareholder approvals have not been obtained, (ii) if the board of directors of the other party effects a change of recommendation, (iii) if the closing has not occurred by October 24, 2016, subject to extension to January 24, 2017 in certain circumstances, (iv) in response to certain intervening events (subject to the limitations set forth in the Merger Agreement) or (v) if there is a material breach by the other party of any of its representations, warranties or covenants, subject to certain conditions.

[0000833444-16-000172:notes:10]
Tyco has entered into a senior unsecured term loan facility in the amount of $4 billion to finance the cash consideration for, and fees, expenses and costs incurred in connection with, the merger. In addition, the Company has entered into a revolving credit agreement in the amount of $1 billion, which is intended to replace Tyco's existing $1.5 billion revolving credit agreement. Tyco's ability to draw down on both the term loan facility and the new revolving credit agreement are contingent on the consummation of the merger with Johnson Controls. See Note 9.

[0000833444-16-000172:notes:11]
Change of Jurisdiction— On May 30, 2014, Tyco entered into a Merger Agreement with Tyco International plc, a newly-formed Irish public limited company and a wholly-owned subsidiary of Tyco ("Tyco Ireland").  Under the Merger Agreement with Tyco Ireland, Tyco merged with and into Tyco Ireland, with Tyco Ireland being the surviving company. This resulted in Tyco Ireland becoming Tyco's publicly-traded parent company and changed the jurisdiction of organization of Tyco from Switzerland to Ireland. Tyco's shareholders received one ordinary share of Tyco Ireland for each ordinary share of Tyco held immediately prior to the re-domicile to Ireland. The re-domicile to Ireland became effective on November 17, 2014.

[0000833444-16-000172:notes:12]
Reclassifications— Certain prior period amounts have been reclassified to conform with the current period presentation.

[0000833444-16-000172:notes:13]
Effective for the first quarter of fiscal 2016, the Company has elected to present operating income by segment, as well as Corporate and Other, excluding restructuring and repositioning charges, net.  Restructuring and repositioning charges, net, are shown in aggregate. This presentation is consistent with how management reviews the businesses, makes investing and resource decisions and assesses operating performance. See Note 15.

[0000833444-16-000172:notes:14]
During the second quarter of fiscal 2016, the Company completed the sale of its Australian fire protection business, included in the ROW Integrated Solutions & Services segment. The assets and liabilities related to this business were classified as held for sale as of September 25, 2015.  Its results of operations are included in continuing operations, as the criteria to be presented as a discontinued operation were not satisfied. See Note 3.

[0000833444-16-000172:notes:15]
Recently Adopted Accounting Pronouncements— In April 2014, the Financial Accounting Standards Board ("FASB") issued authoritative guidance to change the criteria for reporting discontinued operations. Under the new guidance, only disposals representing a strategic shift that has or will have a major effect on the Company's operations and financial results should be reported as discontinued operations, with expanded disclosures. The guidance became effective for Tyco in the first quarter of fiscal 2016. The Company considers both qualitative and quantitative factors when assessing whether a disposed business represents a strategic shift that will have a major effect on the Company's operations and financial results. The Company considers the level (e.g. individual business or product line, reporting unit or reportable segment) and geographic impact (e.g. country, region, worldwide) of the disposal group. In addition, the Company considers the significance of the disposed business on certain financial measures when assessing whether or not such disposal has a major effect on the Company's operations and financial results. The adoption of this guidance did not have a material impact on the Company's financial position, results of operations or cash flows. During fiscal 2016, the divestiture of the Company's Australian fire protection business did not meet the criteria set forth in the new guidance and therefore was not classified as a discontinued operation. See Note 3.

[0000833444-16-000172:notes:16]
Recently Issued Accounting Pronouncements— In May 2014, the FASB issued authoritative guidance for revenue from contracts with customers, which provides a single comprehensive revenue recognition model to apply in determining how and when to recognize revenue. The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. When applying the new revenue model to contracts with customers the guidance requires five steps to be applied, which include: 1) identify the contract(s) with a customer, 2) identify the performance obligations in the contract, 3) determine the transaction price, 4) allocate the transaction price to the performance obligations in the contract and 5) recognize revenue when (or as) the entity satisfies a performance obligation. The guidance also requires quantitative and qualitative disclosures that are more comprehensive than existing standards. The disclosures are intended to enable financial statement users to understand the nature, timing and uncertainty of revenue and the related cash flow. The new standard permits either the full retrospective method or the modified retrospective method of adoption. In August 2015, the FASB issued authoritative guidance to defer the effective date of this guidance, which for Tyco will be the first quarter of fiscal 2019, with early adoption permitted beginning the first quarter of fiscal 2018. In March 2016, the FASB issued additional authoritative guidance clarifying its implementation guidance on principal versus agent considerations when determining whether to report revenue gross versus net. The Company is in the process of assessing the impact the guidance is expected to have upon adoption, including determining the adoption method.

[0000833444-16-000172:notes:17]
In May 2015, the FASB issued authoritative guidance that is intended to improve the existing disclosure requirements for short-duration contracts for insurance entities that issue such contracts.  The guidance requires additional information to be disclosed about the liability for unpaid claims and claim adjustment expenses to increase the transparency of significant estimates made in measuring those liabilities.  This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted.  The Company is currently assessing the impact, if any, the guidance may have upon adoption.

[0000833444-16-000172:notes:18]
In July 2015, the FASB issued authoritative guidance intended to simplify the existing guidance under which an entity must measure inventory at the lower of cost or market. Under the new guidance, inventory is “measured at the lower of cost and net realizable value,” and does not apply to inventory that is measured using last-in, first-out or the retail method. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted on a prospective basis. The Company is currently assessing the impact, if any, the guidance may have upon adoption.

[0000833444-16-000172:notes:19]
In September 2015, the FASB issued authoritative guidance intended to reduce the cost and complexity of financial reporting when recognizing adjustments to provisional amounts in connection with a business combination. This guidance eliminates the requirement to restate prior period financial statements, but requires entities to present separately on the face of the income statement, or disclose in the notes, the portion of the amount recorded in current-period earnings by line item that would have been recorded in previous reporting periods if the adjustment to the provisional amounts had been recognized as of the acquisition date. This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted on a prospective basis. The Company is currently assessing the impact, if any, the guidance may have upon adoption.

[0000833444-16-000172:notes:20]
In November 2015, the FASB issued authoritative guidance intended to simplify the presentation of deferred income taxes.  Under the new guidance, deferred tax liabilities and deferred tax assets are to be classified as noncurrent in a classified statement of financial position.  The current requirement that deferred tax liabilities and assets of a tax-paying component of an entity be offset and presented as a single amount is not affected by the amendments in this update. This guidance is effective for Tyco in the first quarter of fiscal 2018, with early adoption permitted on a prospective or retrospective basis. The Company plans to adopt this guidance as of September 30, 2016 and does not expect the guidance to have a material impact on its financial statements.

[0000833444-16-000172:notes:21]
In January 2016, the FASB issued authoritative guidance addressing the recognition, measurement, presentation and disclosure of financial assets and liabilities. The guidance primarily affects the accounting for equity investments, financial liabilities under the fair value option and the presentation and disclosure requirements for financial instruments. In addition, the guidance clarifies the valuation allowance assessment when recognizing deferred tax assets resulting from unrealized losses on available-for-sale debt securities. This guidance is effective for Tyco in the first quarter of fiscal 2019, and early adoption is not permitted, with certain exceptions.  The amendments are required to be applied by means of a cumulative-effect adjustment on the balance sheet as of the beginning of the fiscal year of adoption.  The Company is currently assessing the impact, if any, the guidance may have upon adoption.

[0000833444-16-000172:notes:22]
In February 2016, the FASB issued authoritative guidance requiring the recognition of lease assets and lease liabilities by lessees for those leases previously classified as operating leases. The guidance requires quantitative and qualitative disclosures that are more comprehensive than existing standards. The disclosures are intended to enable financial statement users to understand the amount, timing and uncertainty of cash flows arising from leases. This guidance is effective for Tyco in the first quarter of fiscal 2020 with early adoption permitted. The amendments are required to be applied by means of a modified retrospective approach. The Company is currently assessing the impact, if any, the guidance may have upon adoption.

[0000833444-16-000172:notes:23]
In March 2016, the FASB amended its authoritative guidance for employee share-based payment transactions by simplifying several aspects of the accounting for employee share-based payment awards, including the accounting for income taxes, withholding taxes and forfeitures, as well as classification on the statement of cash flows. The amended guidance is effective for Tyco in the first quarter of fiscal 2018 with early adoption permitted.  The Company is currently assessing the impact, if any, the guidance may have upon adoption.


## tyc:ScheduleOfIntangibleAssetsTextBlock

[0000833444-16-000172:notes:24]
The following table sets forth the gross carrying amount and accumulated amortization of the Company's intangible assets as of March 25, 2016 and September 25, 2015 ($ in millions):

[0000833444-16-000172:notes:25]
|  | As of |
|  | March 25, 2016 |  | September 25, 2015 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Amortizable: |  |  |  |  |  |  |  |
| Contracts and related customer relationships | $ | 1,372 |  |  | $ | 1,017 |  |  | $ | 1,281 |  |  | $ | 991 |  |
| Intellectual property | 877 |  |  | 516 |  |  | 760 |  |  | 496 |  |
| Other | 9 |  |  | 5 |  |  | 8 |  |  | 5 |  |
| Total | $ | 2,258 |  |  | $ | 1,538 |  |  | $ | 2,049 |  |  | $ | 1,492 |  |
| Non-Amortizable: |  |  |  |  |  |  |  |
| Intellectual property | $ | 210 |  |  |  |  |  | $ | 210 |  |  |  |
| Franchise rights | 76 |  |  |  |  |  | 76 |  |  |  |
| In-process research and development | 19 |  |  |  |  | 20 |  |  |  |
| Total | $ | 305 |  |  |  |  |  | $ | 306 |  |  |  |


## tyc:ScheduleOfNetReceivablesAndLiabilitiesRecordedUnderTaxSharingAgreementsTableTextBlock

[0000833444-16-000172:notes:26]
The receivables and liabilities related to the 2012 and 2007 Tax Sharing Agreements as of March 25, 2016 and September 25, 2015, are as follows ($ in millions):

[0000833444-16-000172:notes:27]
|  | 2012 Tax Sharing Agreement |  | 2007 Tax Sharing Agreement |
|  | As of |  | As of |
|  | March 25, 2016 |  | September 25, 2015 |  | March 25, 2016 |  | September 25, 2015 |
| Tax sharing agreement related receivables: |  |  |  |  |  |  |  |
| Other assets | $ | — |  |  | $ | — |  |  | $ | 19 |  |  | $ | 19 |  |
|  | — |  |  | — |  |  | 19 |  |  | 19 |  |
| Tax sharing agreement related liabilities: |  |  |  |  |  |  |  |
| Accrued and other current liabilities | — |  |  | — |  |  | (87 | ) |  | (15 | ) |
| Other liabilities | (46 | ) |  | (46 | ) |  | — |  |  | (194 | ) |
|  | (46 | ) |  | (46 | ) |  | (87 | ) |  | (209 | ) |
| Net liability | $ | (46 | ) |  | $ | (46 | ) |  | $ | (68 | ) |  | $ | (190 | ) |


## tyc:ScheduleOfRestructuringReserveByBalanceSheetLocationTextBlock

[0000833444-16-000172:notes:28]
As of March 25, 2016 and September 25, 2015, restructuring reserves related to all actions were included within the Company's Consolidated Balance Sheets as follows ($ in millions):

[0000833444-16-000172:notes:29]
|  | As of |
|  | March 25, 2016 |  | September 25, 2015 |
| Accrued and other current liabilities | $ | 111 |  |  | $ | 140 |  |
| Other liabilities | 14 |  |  | 15 |  |
| Total | $ | 125 |  |  | $ | 155 |  |


## tyc:ScheduleOfSegmentReportingInformationNetRevenueAndOperatingIncomeLossBySegmentTableTextBlock

[0000833444-16-000172:notes:30]
[same as prior period, unchanged from 0000833444-16-000120:notes:23]

[0000833444-16-000172:notes:31]
|  | For the Quarters Ended |  | For the Six Months Ended |
|  | March 25, 2016 |  | March 27, 2015 |  | March 25, 2016 |  | March 27, 2015 |
| Net revenue(1): |  |  |  |  |  |  |  |
| NA Integrated Solutions & Services | $ | 947 |  |  | $ | 944 |  |  | $ | 1,900 |  |  | $ | 1,895 |  |
| ROW Integrated Solutions & Services | 768 |  |  | 847 |  |  | 1,580 |  |  | 1,763 |  |
| Global Products | 616 |  |  | 639 |  |  | 1,227 |  |  | 1,250 |  |
|  | $ | 2,331 |  |  | $ | 2,430 |  |  | $ | 4,707 |  |  | $ | 4,908 |  |

[0000833444-16-000172:notes:32]
[same as prior period, unchanged from 0000833444-16-000120:notes:25]

[0000833444-16-000172:notes:33]
|  | For the Quarters Ended |  | For the Six Months Ended |
|  | March 25, 2016 |  | March 27, 2015 |  | March 25, 2016 |  | March 27, 2015 |
| Operating income: |  |  |  |  |  |  |  |
| NA Integrated Solutions & Services | $ | 131 |  |  | $ | 125 |  |  | $ | 263 |  |  | $ | 254 |  |
| ROW Integrated Solutions & Services | 57 |  |  | 67 |  |  | 190 |  |  | 156 |  |
| Global Products | 101 |  |  | 114 |  |  | 198 |  |  | 219 |  |
| Segment operating income | 289 |  |  | 306 |  |  | 651 |  |  | 629 |  |
| Corporate and Other | (54 | ) |  | (56 | ) |  | (105 | ) |  | (105 | ) |
| Restructuring and repositioning charges, net | (10 | ) |  | (29 | ) |  | (28 | ) |  | (104 | ) |
| Operating income | $ | 225 |  |  | $ | 221 |  |  | $ | 518 |  |  | $ | 420 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000833444-16-000172:notes:34]
[same as prior period, unchanged from 0000833444-16-000120:notes:27]

[0000833444-16-000172:notes:35]
During the quarter ended March 25, 2016, cash consideration for acquisitions included in continuing operations was $176 million, which was comprised of $182 million of cash paid, net of cash acquired of $6 million.  This was related to the acquisition of ShopperTrak, a leading global provider of retail consumer behavior insights and location-based analytics. ShopperTrak is being integrated into the NA Integrated Solutions & Services and ROW Integrated Solutions & Services segments.

[0000833444-16-000172:notes:36]
During the six months ended March 25, 2016, cash consideration for acquisitions included in continuing operations was $314 million.  In addition to the ShopperTrak acquisition discussed above, cash consideration for the six month period included $128 million, which was comprised of $166 million of cash paid, including $5 million to settle pre-existing matters and $6 million for prepaid agency commissions, net of cash acquired of $27 million, related to an additional investment in the Company's Tyco UAE joint venture with its local partner Suwaidi Engineering Group ("Suwaidi") in the United Arab Emirates ("UAE").  Tyco UAE is a leading provider of fire, security and integrated solutions and services in the UAE and also has operations in Qatar and Oman.  Effective with the date of this transaction, the Company consolidated 100% of Tyco UAE, which is recorded in the Company's ROW Integrated Solutions & Services segment. The total enterprise fair value of the UAE joint venture was allocated as follows: $99 million of assets, $136 million of goodwill, $99 million of intangible assets and the assumption of $32 million of liabilities. The Company's proportionate share of the joint venture's net income was historically recorded in Selling, general and administrative expenses within the Consolidated Statements of Operations for periods prior to the acquisition date. As a result of this transaction, the Company recorded a net gain of $111 million which primarily relates to the Company's previously held 49% equity interest in the joint venture, which was previously accounted for under the equity method of accounting, inclusive of a charge for the settlement of pre-existing matters with the Company's former joint venture partner. The Company recorded the net gain in Selling, general and administrative expenses within the Consolidated Statements of Operations during the quarter ended December 25, 2015.  The balance of the cash paid during the six months ended March 25, 2016 of $10 million related to an acquisition within the Company's ROW Integrated Solutions & Services segment which was not material.

[0000833444-16-000172:notes:37]
The final determination of fair value of certain assets and liabilities related to the ShopperTrak acquisition remains subject to change based on final valuations of the assets and liabilities assumed.  The Company does not expect the finalization of this matter to have a material effect on the purchase price allocation, which is expected to be completed within fiscal 2016.  During the six months ended March 25, 2016, the Company finalized the determination of fair value for certain assets and liabilities relating to the acquisitions closed during the first quarter of fiscal 2016 and fourth quarter of fiscal 2015, with no material adjustment to the preliminary purchase price allocations.

[0000833444-16-000172:notes:38]
During the quarter ended March 27, 2015, total consideration paid, net of $6 million of cash acquired and $5 million of holdback liability, for six acquisitions included in continuing operations was $373 million.  The activity is primarily related to the acquisition of Industrial Safety Technologies International ("IST"), a global leader in gas and flame detection with operations in Europe, the Middle East, China, and the U.S., for total consideration paid, net of $5 million of cash acquired, of $327 million. IST has been integrated into the Global Products segment.  The remaining $46 million in purchase price related to five acquisitions that have been integrated into the ROW Integrated Solutions & Services and Global Products segments and working capital adjustments related to fiscal year 2014 acquisitions.

[0000833444-16-000172:notes:39]
During the six months ended March 27, 2015, total consideration paid, net of $26 million of cash acquired and $8 million of holdback liability, for 11 acquisitions included in continuing operations was $525 million.  This includes working capital adjustments described above.  In addition to the acquisition of IST within the Global Products segment, the Company made 10 acquisitions during the six months ended March 27, 2015.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-16-000172:notes:40]
Commitments and Contingencies

[0000833444-16-000172:notes:41]
Environmental Matters

[0000833444-16-000172:notes:42]
Tyco is involved in various stages of investigation and cleanup related to environmental remediation matters at a number of sites. The ultimate cost of site cleanup is difficult to predict given the uncertainties regarding the extent of the required cleanup, the interpretation of applicable laws and regulations and alternative cleanup methods. As of March 25, 2016, Tyco concluded that it was probable that it would incur remedial costs in the range of approximately $21 million to $70 million. As of March 25, 2016, Tyco concluded that the best estimate within this range is approximately $31 million, of which $11 million is included in Accrued and other current liabilities and $20 million is included in Other liabilities within the Company's Consolidated Balance Sheet.

[0000833444-16-000172:notes:43]
As previously disclosed, the majority of the liabilities described above relate to ongoing remediation efforts at a facility in the Company's Global Products segment located in Marinette, Wisconsin, which the Company acquired in 1990 in connection with its acquisition of, among other things, the Ansul product line. As of March 25, 2016, the Company concluded that its remaining remediation and monitoring costs related to the Marinette facility were in the range of approximately $13 million to $45 million. The Company's best estimate within that range is approximately $21 million, of which $9 million is included in Accrued and other current liabilities and $12 million is included in Other liabilities within the Company's Consolidated Balance Sheet.  Although the Company has recorded its best estimate of the costs that it will incur to remediate and monitor contamination at the Marinette facility, it is possible that technological, regulatory or enforcement developments, the results of environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows.

[0000833444-16-000172:notes:44]
Asbestos Matters

[0000833444-16-000172:notes:45]
The Company and certain of its subsidiaries, including Grinnell LLC (“Grinnell”), along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. Substantially all cases pending against affiliates of the Company have been filed against Grinnell, and have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-16-000172:notes:46]
During the third quarter of fiscal 2014, the Company, through Grinnell, resolved disputes with certain of its historical insurers and agreed that certain insurance proceeds would be used to establish and fund a qualified settlement fund (“QSF”), within the meaning of the Internal Revenue Code, which would be used for the resolution primarily of Grinnell asbestos liabilities. It is intended that the QSF will receive future insurance payments and proceeds from third party insurers and, in addition, will fund and manage liabilities for certain historical operations of the Company, primarily related to Grinnell. On January 9, 2015, the Company completed a series of restructuring transactions related to the establishment and funding of a dedicated structure pursuant to which a subsidiary of the Company acquired the assets of Grinnell and transferred cash and other assets totaling approximately $278 million (not including $22 million received by the QSF during the quarter ended December 26, 2014 from historic third-party insurers in settlement of coverage disputes) to the structure. As part of the restructuring, subsidiaries in the structure assumed certain liabilities related to historic Grinnell, Scott and Figgie operations, including all historical Grinnell asbestos liabilities, and such subsidiaries purchased additional insurance by, through or from a wholly-owned subsidiary in the structure in order to supplement and enhance existing insurance assets.

[0000833444-16-000172:notes:47]
The Company consolidates the qualified settlement fund and related entities that were established for the purpose of managing and resolving the liabilities described above. Although the entities in the dedicated structure serve the specific purpose of managing certain liabilities, each entity in the structure is a wholly-owned indirect subsidiary of the Company, and therefore is required to be consolidated under GAAP.

[0000833444-16-000172:notes:48]
As of March 25, 2016, the Company has determined that there were approximately 3,100 claims pending against its subsidiaries, primarily Grinnell. This amount reflects the Company's current estimate of the number of viable claims made against Grinnell and includes adjustments for claims that are not actively being prosecuted, identify incorrect defendants, are duplicative of other actions or for which the Company is indemnified by third parties.

[0000833444-16-000172:notes:49]
As of March 25, 2016, the Company's estimated asbestos related net liability recorded within the Company's Consolidated Balance Sheet is $24 million. The net liability within the Consolidated Balance Sheet is comprised of a liability for pending and future claims and related defense costs of $500 million, of which $10 million is recorded in Accrued and other current liabilities, and $490 million is recorded in Other liabilities. The Company also maintains separate cash, investment and other assets within the Consolidated Balance Sheet of $476 million, of which $37 million is recorded in Prepaid expenses and other current assets, and $439 million is recorded in Other assets. Assets include $3 million of cash and $265 million of investments, which have all been designated as restricted.  As of September 25, 2015, the Company's estimated net liability recorded within the Company's Consolidated Balance Sheet was $28 million. The net liability was comprised of a liability for pending and future claims and related defense costs of $515 million, of which $23 million was recorded in Accrued and other current liabilities, and $492 million was recorded in Other liabilities.  The Company also maintained separate cash, investment and other assets within the Consolidated Balance Sheet of $487 million, of which $38 million was recorded in Prepaid expenses and other current assets, and $449 million was recorded in Other assets. Assets included $11 million of cash and $263 million of investments, which were all designated as restricted.

[0000833444-16-000172:notes:50]
The Company periodically assesses the sufficiency of its estimated liability for pending and future asbestos claims and defense costs. On a periodic basis, the Company, through the dedicated structure referred to above, evaluates actual experience regarding asbestos claims filed, settled and dismissed, amounts paid in settlements, and the recoverability of its insurance assets. If and when data from actual experience demonstrate a significant unfavorable discernible trend, the Company performs a valuation of its asbestos related liabilities and corresponding insurance assets including a comprehensive review of the underlying assumptions. In addition, the Company evaluates its ability to reasonably estimate claim activity beyond its current look-forward period (through 2056) in order to assess whether such period continues to be appropriate. In addition to claims and litigation experience, the Company considers additional qualitative and quantitative factors such as changes in legislation, the legal environment, the Company’s strategy in managing claims and obtaining insurance, including its defense strategy, and health related trends in the overall population of individuals potentially exposed to asbestos. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance assets is warranted.

[0000833444-16-000172:notes:51]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-16-000172:notes:52]
Tax Matters

[0000833444-16-000172:notes:53]
Tyco and its subsidiaries' income tax returns are examined periodically by various tax authorities. In connection with these examinations, tax authorities, including the IRS, have raised issues and proposed tax adjustments, in particular with respect to years preceding the 2007 Separation.  The issues and proposed adjustments related to such years are generally subject to the sharing provisions of the 2007 Tax Sharing Agreement and Tyco's liabilities under the 2007 Tax Sharing Agreement are further subject to the sharing provisions in the 2012 Tax Sharing Agreement. Tyco has previously disclosed that in connection with U.S. federal tax audits, the IRS raised a number of issues and proposed tax adjustments for periods beginning with the 1997 tax year. Although Tyco resolved substantially all of the issues and adjustments proposed by the IRS for tax years through 2007, it was not able to resolve matters related to the treatment of certain intercompany debt transactions during the period. As a result, on June 20, 2013, Tyco received Notices of Deficiency from the IRS asserting that several of Tyco's former U.S. subsidiaries owe additional taxes of $883.3 million plus penalties of $154 million based on audits of the 1997 through 2000 tax years of Tyco and its subsidiaries as they existed at that time. In addition, Tyco received Final Partnership Administrative Adjustments for certain U.S. partnerships owned by former U.S. subsidiaries with respect to which an additional tax deficiency of approximately $30 million has been asserted. These amounts excluded interest and did not reflect the roll-forward impact on subsequent audit periods.

[0000833444-16-000172:notes:54]
On January 15, 2016, Tyco entered into Stipulations of Settled Issues with the IRS intended to resolve all disputes related to the intercompany debt issues described above for the 1997 - 2000 audit cycle currently before the U.S. Tax Court. The Stipulations of Settled Issues are contingent upon the IRS Appeals Division applying the same settlement to all intercompany debt issues on appeal for subsequent audit cycles (2001 - 2007) and, if applicable, review by the United States Congress Joint Committee on Taxation.

[0000833444-16-000172:notes:55]
If finalized, the tentative resolution would cover all aspects of the controversy before the U.S. Tax Court described above and before the Appeals Division of the IRS, and would result in a total cash payment to the IRS in the range of $475 million to $525 million, which includes all interest and penalties. This payment would be subject to the sharing formula in each Tax Sharing Agreement, and would be shared among Tyco, Covidien and TE Connectivity 27%, 42% and 31%, respectively, with neither ADT nor Pentair being responsible for any payment related to this amount.

[0000833444-16-000172:notes:56]
Assuming the tentative resolution is finalized, Tyco does not expect to recognize any additional charges related to the resolution, as it had previously recorded sufficient reserves with respect to this controversy and its obligations under the Tax Sharing Agreements. The Company made a payment of $120 million to TE Connectivity and $2 million to Covidien, which was subsequently paid to the IRS, during the second quarter of fiscal 2016 in connection with the tentative resolution. See Note 6.

[0000833444-16-000172:notes:57]
Other Matters

[0000833444-16-000172:notes:58]
On March 1, 2016, a putative class action lawsuit, Wandel v. Tyco International plc, et al., Docket No. C-000010-16, was filed in the Superior Court of New Jersey naming Tyco, the individual members of its board of directors, Johnson Controls and Merger Sub as defendants. The complaint alleges that Tyco’s directors breached their fiduciary duties and exercised their powers as directors in a manner oppressive to the public shareholders of Tyco in violation of Irish law by, among other things, failing to take steps to maximize shareholder value and failing to protect against purported conflicts of interest. The complaint further alleges that Tyco, Johnson Controls and Merger Sub aided and abetted Tyco’s directors in the breach of their fiduciary duties. The complaint seeks, among other things, to enjoin the merger. The Company believes that the claims asserted by the complaint are not valid.

[0000833444-16-000172:notes:59]
In addition to the foregoing, the Company is subject to claims and suits, including from time to time, contractual disputes and product and general liability claims, incidental to present and former operations, acquisitions and dispositions. With respect to many of these claims, the Company either self-insures or maintains insurance through third-parties, with varying deductibles. While the ultimate outcome of these matters cannot be predicted with certainty, the Company believes that the resolution of any such proceedings, whether the underlying claims are covered by insurance or not, will not have a material adverse effect on the Company's financial condition, results of operations or cash flows beyond amounts recorded for such matters.


## us-gaap:CondensedFinancialStatementsTextBlock

[0000833444-16-000172:notes:60]
[same as prior period, unchanged from 0000833444-16-000120:notes:57]

[0000833444-16-000172:notes:61]
[same as prior period, unchanged from 0000833444-16-000120:notes:58]

[0000833444-16-000172:notes:62]
[same as prior period, unchanged from 0000833444-16-000120:notes:59]

[0000833444-16-000172:notes:63]
For the Quarter Ended March 25, 2016

[0000833444-16-000172:notes:64]
[same as prior period, unchanged from 0000833444-16-000120:notes:61]

[0000833444-16-000172:notes:65]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,331 |  |  | $ | — |  |  | $ | 2,331 |  |
| Cost of product sales | — |  |  | — |  |  | — |  |  | 968 |  |  | — |  |  | 968 |  |
| Cost of services | — |  |  | — |  |  | — |  |  | 506 |  |  | — |  |  | 506 |  |
| Selling, general and administrative expenses | 2 |  |  | — |  |  | 1 |  |  | 599 |  |  | — |  |  | 602 |  |
| Merger costs | — |  |  | — |  |  | 10 |  |  | 16 |  |  | — |  |  | 26 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Operating (loss) income | (2 | ) |  | — |  |  | (11 | ) |  | 238 |  |  | — |  |  | 225 |  |
| Interest income | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Interest expense | — |  |  | — |  |  | (22 | ) |  | — |  |  | — |  |  | (22 | ) |
| Other (expense) income, net | — |  |  | — |  |  | (1 | ) |  | 1 |  |  | — |  |  | — |  |
| Equity in net income of subsidiaries | 145 |  |  | 144 |  |  | 156 |  |  | — |  |  | (445 | ) |  | — |  |
| Intercompany interest and fees | 5 |  |  | — |  |  | 22 |  |  | (27 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 148 |  |  | 144 |  |  | 144 |  |  | 216 |  |  | (445 | ) |  | 207 |  |
| Income tax expense | (2 | ) |  | — |  |  | — |  |  | (61 | ) |  | — |  |  | (63 | ) |
| Income from continuing operations | 146 |  |  | 144 |  |  | 144 |  |  | 155 |  |  | (445 | ) |  | 144 |  |
| Income from discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net income | 146 |  |  | 144 |  |  | 144 |  |  | 156 |  |  | (445 | ) |  | 145 |  |
| Less: noncontrolling interest in subsidiaries net loss | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 146 |  |  | $ | 144 |  |  | $ | 144 |  |  | $ | 157 |  |  | $ | (445 | ) |  | $ | 146 |  |

[0000833444-16-000172:notes:66]
[same as prior period, unchanged from 0000833444-16-000120:notes:63]

[0000833444-16-000172:notes:67]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 146 |  |  | $ | 144 |  |  | $ | 144 |  |  | $ | 156 |  |  | $ | (445 | ) |  | $ | 145 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | 44 |  |  | — |  |  | (13 | ) |  | 57 |  |  | (44 | ) |  | 44 |  |
| Defined benefit and post retirement plans | 3 |  |  | — |  |  | — |  |  | 3 |  |  | (3 | ) |  | 3 |  |
| Unrealized gain on marketable securities and derivative instruments, net of tax | 2 |  |  | — |  |  | — |  |  | 2 |  |  | (2 | ) |  | 2 |  |
| Total other comprehensive income (loss), net of tax | 49 |  |  | — |  |  | (13 | ) |  | 62 |  |  | (49 | ) |  | 49 |  |
| Comprehensive income | 195 |  |  | 144 |  |  | 131 |  |  | 218 |  |  | (494 | ) |  | 194 |  |
| Less: comprehensive loss attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Comprehensive income attributable to Tyco ordinary shareholders | $ | 195 |  |  | $ | 144 |  |  | $ | 131 |  |  | $ | 219 |  |  | $ | (494 | ) |  | $ | 195 |  |

[0000833444-16-000172:notes:68]
For the Quarter Ended March 27, 2015

[0000833444-16-000172:notes:69]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,430 |  |  | $ | — |  |  | $ | 2,430 |  |
| Cost of product sales | — |  |  | — |  |  | — |  |  | 999 |  |  | — |  |  | 999 |  |
| Cost of services | — |  |  | — |  |  | — |  |  | 550 |  |  | — |  |  | 550 |  |
| Selling, general and administrative expenses | 2 |  |  | — |  |  | — |  |  | 646 |  |  | — |  |  | 648 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Operating (loss) income | (2 | ) |  | — |  |  | — |  |  | 223 |  |  | — |  |  | 221 |  |
| Interest income | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Interest expense | — |  |  | — |  |  | (24 | ) |  | (1 | ) |  | — |  |  | (25 | ) |
| Other (expense) income, net | — |  |  | — |  |  | (2 | ) |  | 1 |  |  | — |  |  | (1 | ) |
| Equity in net income of subsidiaries | 152 |  |  | 158 |  |  | 160 |  |  | — |  |  | (470 | ) |  | — |  |
| Intercompany interest and fees | 17 |  |  | — |  |  | 24 |  |  | (41 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 167 |  |  | 158 |  |  | 158 |  |  | 186 |  |  | (470 | ) |  | 199 |  |
| Income tax expense | — |  |  | — |  |  | — |  |  | (18 | ) |  | — |  |  | (18 | ) |
| Income from continuing operations | 167 |  |  | 158 |  |  | 158 |  |  | 168 |  |  | (470 | ) |  | 181 |  |
| Loss from discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | (16 | ) |  | — |  |  | (16 | ) |
| Net income | 167 |  |  | 158 |  |  | 158 |  |  | 152 |  |  | (470 | ) |  | 165 |  |
| Less: noncontrolling interest in subsidiaries net loss | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 167 |  |  | $ | 158 |  |  | $ | 158 |  |  | $ | 154 |  |  | $ | (470 | ) |  | $ | 167 |  |

[0000833444-16-000172:notes:70]
[same as prior period, unchanged from 0000833444-16-000120:notes:67]

[0000833444-16-000172:notes:71]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 167 |  |  | $ | 158 |  |  | $ | 158 |  |  | $ | 152 |  |  | $ | (470 | ) |  | $ | 165 |  |
| Other comprehensive (loss) income, net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | (176 | ) |  | — |  |  | 16 |  |  | (192 | ) |  | 176 |  |  | (176 | ) |
| Defined benefit and post retirement plans | 4 |  |  | — |  |  | — |  |  | 4 |  |  | (4 | ) |  | 4 |  |
| Total other comprehensive (loss) income, net of tax | (172 | ) |  | — |  |  | 16 |  |  | (188 | ) |  | 172 |  |  | (172 | ) |
| Comprehensive (loss) income | (5 | ) |  | 158 |  |  | 174 |  |  | (36 | ) |  | (298 | ) |  | (7 | ) |
| Less: comprehensive loss attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Comprehensive (loss) income attributable to Tyco ordinary shareholders | $ | (5 | ) |  | $ | 158 |  |  | $ | 174 |  |  | $ | (34 | ) |  | $ | (298 | ) |  | $ | (5 | ) |

[0000833444-16-000172:notes:72]
For the Six Months Ended March 25, 2016

[0000833444-16-000172:notes:73]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 4,707 |  |  | $ | — |  |  | $ | 4,707 |  |
| Cost of product sales | — |  |  | — |  |  | — |  |  | 1,930 |  |  | — |  |  | 1,930 |  |
| Cost of services | — |  |  | — |  |  | — |  |  | 1,042 |  |  | — |  |  | 1,042 |  |
| Selling, general and administrative expenses | 4 |  |  | — |  |  | 1 |  |  | 1,170 |  |  | — |  |  | 1,175 |  |
| Merger costs | — |  |  | — |  |  | 10 |  |  | 16 |  |  | — |  |  | 26 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | — |  |  | 16 |  |  | — |  |  | 16 |  |
| Operating (loss) income | (4 | ) |  | — |  |  | (11 | ) |  | 533 |  |  | — |  |  | 518 |  |
| Interest income | — |  |  | — |  |  | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Interest expense | — |  |  | — |  |  | (45 | ) |  | (1 | ) |  | — |  |  | (46 | ) |
| Other (expense) income, net | — |  |  | — |  |  | (166 | ) |  | 1 |  |  | — |  |  | (165 | ) |
| Equity in net income of subsidiaries | 163 |  |  | 160 |  |  | 335 |  |  | — |  |  | (658 | ) |  | — |  |
| Intercompany interest and fees | 65 |  |  | — |  |  | 47 |  |  | (112 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 224 |  |  | 160 |  |  | 160 |  |  | 429 |  |  | (658 | ) |  | 315 |  |
| Income tax expense | (2 | ) |  | — |  |  | — |  |  | (97 | ) |  | — |  |  | (99 | ) |
| Income from continuing operations | 222 |  |  | 160 |  |  | 160 |  |  | 332 |  |  | (658 | ) |  | 216 |  |
| Income from discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Net income | 222 |  |  | 160 |  |  | 160 |  |  | 337 |  |  | (658 | ) |  | 221 |  |
| Less: noncontrolling interest in subsidiaries net loss | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 222 |  |  | $ | 160 |  |  | $ | 160 |  |  | $ | 338 |  |  | $ | (658 | ) |  | $ | 222 |  |

[0000833444-16-000172:notes:74]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 222 |  |  | $ | 160 |  |  | $ | 160 |  |  | $ | 337 |  |  | $ | (658 | ) |  | $ | 221 |  |
| Other comprehensive income, net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | 1 |  |  | — |  |  | 1 |  |  | — |  |  | (1 | ) |  | 1 |  |
| Defined benefit and post retirement plans | 8 |  |  | — |  |  | — |  |  | 8 |  |  | (8 | ) |  | 8 |  |
| Unrealized gain on marketable securities and derivative instruments, net of tax | 3 |  |  | — |  |  | — |  |  | 3 |  |  | (3 | ) |  | 3 |  |
| Total other comprehensive income, net of tax | 12 |  |  | — |  |  | 1 |  |  | 11 |  |  | (12 | ) |  | 12 |  |
| Comprehensive income | 234 |  |  | 160 |  |  | 161 |  |  | 348 |  |  | (670 | ) |  | 233 |  |
| Less: comprehensive loss attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Comprehensive income attributable to Tyco ordinary shareholders | $ | 234 |  |  | $ | 160 |  |  | $ | 161 |  |  | $ | 349 |  |  | $ | (670 | ) |  | $ | 234 |  |

[0000833444-16-000172:notes:75]
For the Six Months Ended March 27, 2015

[0000833444-16-000172:notes:76]
|  | TycoInternationalplc |  | TycoFire & Security Finance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 4,908 |  |  | $ | — |  |  | $ | 4,908 |  |
| Cost of product sales | — |  |  | — |  |  | — |  |  | 2,021 |  |  | — |  |  | 2,021 |  |
| Cost of services | — |  |  | — |  |  | — |  |  | 1,097 |  |  | — |  |  | 1,097 |  |
| Selling, general and administrative expenses | 5 |  |  | — |  |  | 1 |  |  | 1,294 |  |  | — |  |  | 1,300 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | — |  |  | 70 |  |  | — |  |  | 70 |  |
| Operating (loss) income | (5 | ) |  | — |  |  | (1 | ) |  | 426 |  |  | — |  |  | 420 |  |
| Interest income | — |  |  | — |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Interest expense | — |  |  | — |  |  | (48 | ) |  | (1 | ) |  | — |  |  | (49 | ) |
| Other income, net | — |  |  | — |  |  | 2 |  |  | 1 |  |  | — |  |  | 3 |  |
| Equity in net income of subsidiaries | 295 |  |  | 291 |  |  | 287 |  |  | — |  |  | (873 | ) |  | — |  |
| Intercompany interest and fees | 39 |  |  | — |  |  | 51 |  |  | (90 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 329 |  |  | 291 |  |  | 291 |  |  | 343 |  |  | (873 | ) |  | 381 |  |
| Income tax expense | — |  |  | — |  |  | — |  |  | (37 | ) |  | — |  |  | (37 | ) |
| Income from continuing operations | 329 |  |  | 291 |  |  | 291 |  |  | 306 |  |  | (873 | ) |  | 344 |  |
| Loss from discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | (18 | ) |  | — |  |  | (18 | ) |
| Net income | 329 |  |  | 291 |  |  | 291 |  |  | 288 |  |  | (873 | ) |  | 326 |  |
| Less: noncontrolling interest in subsidiaries net loss | — |  |  | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 329 |  |  | $ | 291 |  |  | $ | 291 |  |  | $ | 291 |  |  | $ | (873 | ) |  | $ | 329 |  |

[0000833444-16-000172:notes:77]
|  | TycoInternationalplc |  | TycoFire & Security Finance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 329 |  |  | $ | 291 |  |  | $ | 291 |  |  | $ | 288 |  |  | $ | (873 | ) |  | $ | 326 |  |
| Other comprehensive (loss) income, net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | (374 | ) |  | — |  |  | 15 |  |  | (389 | ) |  | 374 |  |  | (374 | ) |
| Defined benefit and post retirement plans | 9 |  |  | — |  |  | — |  |  | 9 |  |  | (9 | ) |  | 9 |  |
| Total other comprehensive (loss) income, net of tax | (365 | ) |  | — |  |  | 15 |  |  | (380 | ) |  | 365 |  |  | (365 | ) |
| Comprehensive (loss) income | (36 | ) |  | 291 |  |  | 306 |  |  | (92 | ) |  | (508 | ) |  | (39 | ) |
| Less: comprehensive loss attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Comprehensive (loss) income attributable to Tyco ordinary shareholders | $ | (36 | ) |  | $ | 291 |  |  | $ | 306 |  |  | $ | (89 | ) |  | $ | (508 | ) |  | $ | (36 | ) |

[0000833444-16-000172:notes:78]
[same as prior period, unchanged from 0000833444-16-000120:notes:69]

[0000833444-16-000172:notes:79]
As of March 25, 2016

[0000833444-16-000172:notes:80]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 345 |  |  | $ | — |  |  | $ | 345 |  |
| Accounts receivable, net | — |  |  | — |  |  | — |  |  | 1,722 |  |  | — |  |  | 1,722 |  |
| Inventories | — |  |  | — |  |  | — |  |  | 670 |  |  | — |  |  | 670 |  |
| Intercompany receivables | 15 |  |  | — |  |  | 496 |  |  | 7,629 |  |  | (8,140 | ) |  | — |  |
| Prepaid expenses and other current assets | 1 |  |  | — |  |  | 58 |  |  | 805 |  |  | — |  |  | 864 |  |
| Deferred income taxes | — |  |  | — |  |  | — |  |  | 62 |  |  | — |  |  | 62 |  |
| Total Current Assets | 16 |  |  | — |  |  | 554 |  |  | 11,233 |  |  | (8,140 | ) |  | 3,663 |  |
| Property, plant and equipment, net | — |  |  | — |  |  | — |  |  | 1,189 |  |  | — |  |  | 1,189 |  |
| Goodwill | — |  |  | — |  |  | — |  |  | 4,460 |  |  | — |  |  | 4,460 |  |
| Intangible assets, net | — |  |  | — |  |  | — |  |  | 1,025 |  |  | — |  |  | 1,025 |  |
| Investment in subsidiaries | 11,086 |  |  | 11,343 |  |  | 16,373 |  |  | — |  |  | (38,802 | ) |  | — |  |
| Intercompany loans receivable | — |  |  | — |  |  | 2,937 |  |  | 5,100 |  |  | (8,037 | ) |  | — |  |
| Other assets | 1 |  |  | — |  |  | 50 |  |  | 1,223 |  |  | — |  |  | 1,274 |  |
| Total Assets | $ | 11,103 |  |  | $ | 11,343 |  |  | $ | 19,914 |  |  | $ | 24,230 |  |  | $ | (54,979 | ) |  | $ | 11,611 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Loans payable and current maturities of long-term debt | $ | — |  |  | $ | — |  |  | $ | 400 |  |  | $ | — |  |  | $ | — |  |  | $ | 400 |  |
| Accounts payable | 2 |  |  | — |  |  | — |  |  | 795 |  |  | — |  |  | 797 |  |
| Accrued and other current liabilities | 89 |  |  | — |  |  | 96 |  |  | 1,458 |  |  | — |  |  | 1,643 |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 393 |  |  | — |  |  | 393 |  |
| Intercompany payables | 3,704 |  |  | — |  |  | 3,931 |  |  | 505 |  |  | (8,140 | ) |  | — |  |
| Total Current Liabilities | 3,795 |  |  | — |  |  | 4,427 |  |  | 3,151 |  |  | (8,140 | ) |  | 3,233 |  |
| Long-term debt | — |  |  | — |  |  | 2,158 |  |  | 1 |  |  | — |  |  | 2,159 |  |
| Intercompany loans payable | 3,166 |  |  | — |  |  | 1,934 |  |  | 2,937 |  |  | (8,037 | ) |  | — |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 285 |  |  | — |  |  | 285 |  |
| Other liabilities | — |  |  | — |  |  | 52 |  |  | 1,704 |  |  | — |  |  | 1,756 |  |
| Total Liabilities | 6,961 |  |  | — |  |  | 8,571 |  |  | 8,078 |  |  | (16,177 | ) |  | 7,433 |  |
| Tyco Shareholders' Equity: |  |  |  |  |  |  |  |  |  |  |  |
| Ordinary shares | 4 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |
| Ordinary shares held in treasury | (15 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (15 | ) |
| Other shareholders' equity | 4,153 |  |  | 11,343 |  |  | 11,343 |  |  | 16,116 |  |  | (38,802 | ) |  | 4,153 |  |
| Total Tyco Shareholders' Equity | 4,142 |  |  | 11,343 |  |  | 11,343 |  |  | 16,116 |  |  | (38,802 | ) |  | 4,142 |  |
| Nonredeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 36 |  |  | — |  |  | 36 |  |
| Total Equity | 4,142 |  |  | 11,343 |  |  | 11,343 |  |  | 16,152 |  |  | (38,802 | ) |  | 4,178 |  |
| Total Liabilities and Equity | $ | 11,103 |  |  | $ | 11,343 |  |  | $ | 19,914 |  |  | $ | 24,230 |  |  | $ | (54,979 | ) |  | $ | 11,611 |  |

[0000833444-16-000172:notes:81]
[same as prior period, unchanged from 0000833444-16-000120:notes:72]

[0000833444-16-000172:notes:82]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,401 |  |  | $ | — |  |  | $ | 1,401 |  |
| Accounts receivable, net | — |  |  | — |  |  | — |  |  | 1,732 |  |  | — |  |  | 1,732 |  |
| Inventories | — |  |  | — |  |  | — |  |  | 624 |  |  | — |  |  | 624 |  |
| Intercompany receivables | 15 |  |  | — |  |  | 332 |  |  | 6,508 |  |  | (6,855 | ) |  | — |  |
| Prepaid expenses and other current assets | — |  |  | — |  |  | 63 |  |  | 691 |  |  | — |  |  | 754 |  |
| Deferred income taxes | — |  |  | — |  |  | — |  |  | 62 |  |  | — |  |  | 62 |  |
| Assets held for sale | — |  |  | — |  |  | — |  |  | 102 |  |  | — |  |  | 102 |  |
| Total Current Assets | 15 |  |  | — |  |  | 395 |  |  | 11,120 |  |  | (6,855 | ) |  | 4,675 |  |
| Property, plant and equipment, net | — |  |  | — |  |  | — |  |  | 1,177 |  |  | — |  |  | 1,177 |  |
| Goodwill | — |  |  | — |  |  | — |  |  | 4,234 |  |  | — |  |  | 4,234 |  |
| Intangible assets, net | — |  |  | — |  |  | — |  |  | 863 |  |  | — |  |  | 863 |  |
| Investment in subsidiaries | 10,885 |  |  | 11,148 |  |  | 16,001 |  |  | — |  |  | (38,034 | ) |  | — |  |
| Intercompany loans receivable | — |  |  | — |  |  | 2,942 |  |  | 5,066 |  |  | (8,008 | ) |  | — |  |
| Other assets | 1 |  |  | — |  |  | 44 |  |  | 1,327 |  |  | — |  |  | 1,372 |  |
| Total Assets | $ | 10,901 |  |  | $ | 11,148 |  |  | $ | 19,382 |  |  | $ | 23,787 |  |  | $ | (52,897 | ) |  | $ | 12,321 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Loans payable and current maturities of long-term debt | $ | — |  |  | $ | — |  |  | $ | 967 |  |  | $ | 20 |  |  | $ | — |  |  | $ | 987 |  |
| Accounts payable | 1 |  |  | — |  |  | — |  |  | 773 |  |  | — |  |  | 774 |  |
| Accrued and other current liabilities | 88 |  |  | — |  |  | 61 |  |  | 1,512 |  |  | — |  |  | 1,661 |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 380 |  |  | — |  |  | 380 |  |
| Intercompany payables | 3,616 |  |  | — |  |  | 2,892 |  |  | 347 |  |  | (6,855 | ) |  | — |  |
| Liabilities held for sale | — |  |  | — |  |  | — |  |  | 50 |  |  | — |  |  | 50 |  |
| Total Current Liabilities | 3,705 |  |  | — |  |  | 3,920 |  |  | 3,082 |  |  | (6,855 | ) |  | 3,852 |  |
| Long-term debt | — |  |  | — |  |  | 2,158 |  |  | 1 |  |  | — |  |  | 2,159 |  |
| Intercompany loans payable | 3,155 |  |  | — |  |  | 1,911 |  |  | 2,942 |  |  | (8,008 | ) |  | — |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 303 |  |  | — |  |  | 303 |  |
| Other liabilities | — |  |  | — |  |  | 245 |  |  | 1,686 |  |  | — |  |  | 1,931 |  |
| Total Liabilities | 6,860 |  |  | — |  |  | 8,234 |  |  | 8,014 |  |  | (14,863 | ) |  | 8,245 |  |
| Tyco Shareholders' Equity: |  |  |  |  |  |  |  |  |  |  |  |
| Ordinary shares | 4 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |
| Other shareholders' equity | 4,037 |  |  | 11,148 |  |  | 11,148 |  |  | 15,738 |  |  | (38,034 | ) |  | 4,037 |  |
| Total Tyco Shareholders' Equity | 4,041 |  |  | 11,148 |  |  | 11,148 |  |  | 15,738 |  |  | (38,034 | ) |  | 4,041 |  |
| Nonredeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 35 |  |  | — |  |  | 35 |  |
| Total Equity | 4,041 |  |  | 11,148 |  |  | 11,148 |  |  | 15,773 |  |  | (38,034 | ) |  | 4,076 |  |
| Total Liabilities and Equity | $ | 10,901 |  |  | $ | 11,148 |  |  | $ | 19,382 |  |  | $ | 23,787 |  |  | $ | (52,897 | ) |  | $ | 12,321 |  |

[0000833444-16-000172:notes:83]
[same as prior period, unchanged from 0000833444-16-000120:notes:74]

[0000833444-16-000172:notes:84]
|  | TycoInternational plc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | 160 |  |  | $ | — |  |  | $ | 701 |  |  | $ | (548 | ) |  | $ | — |  |  | $ | 313 |  |
| Net cash used in discontinued operating activities | — |  |  | — |  |  | — |  |  | (11 | ) |  | — |  |  | (11 | ) |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | — |  |  | (143 | ) |  | — |  |  | (143 | ) |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | — |  |  | (314 | ) |  | — |  |  | (314 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases | — |  |  | — |  |  | — |  |  | (11 | ) |  | — |  |  | (11 | ) |
| Divestiture of businesses, net of cash divested | — |  |  | — |  |  | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Net decrease in intercompany loans | — |  |  | — |  |  | 28 |  |  | — |  |  | (28 | ) |  | — |  |
| Sales and maturities of investments including restricted investments | — |  |  | — |  |  | 5 |  |  | 3 |  |  | — |  |  | 8 |  |
| Purchases of investments including restricted investments | — |  |  | — |  |  | — |  |  | (7 | ) |  | — |  |  | (7 | ) |
| Decrease in restricted cash | — |  |  | — |  |  | — |  |  | 24 |  |  | — |  |  | 24 |  |
| Other | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net cash provided by (used in) investing activities | — |  |  | — |  |  | 33 |  |  | (438 | ) |  | (28 | ) |  | (433 | ) |
| Net cash provided by discontinued investing activities | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short-term debt | — |  |  | — |  |  | 2,498 |  |  | — |  |  | — |  |  | 2,498 |  |
| Repayment of short-term debt | — |  |  | — |  |  | (2,098 | ) |  | — |  |  | — |  |  | (2,098 | ) |
| Repayment of current portion of long-term debt | — |  |  | — |  |  | (1,134 | ) |  | — |  |  | — |  |  | (1,134 | ) |
| Proceeds from exercise of share options | 26 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 26 |  |
| Dividends paid | (174 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (174 | ) |
| Net intercompany loan repayments | — |  |  | — |  |  | — |  |  | (28 | ) |  | 28 |  |  | — |  |
| Transfer to discontinued operations | — |  |  | — |  |  | — |  |  | (7 | ) |  | — |  |  | (7 | ) |
| Payment of contingent consideration | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Debt financing costs | — |  |  | — |  |  | — |  |  | (23 | ) |  | — |  |  | (23 | ) |
| Other | (12 | ) |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (13 | ) |
| Net cash used in financing activities | (160 | ) |  | — |  |  | (734 | ) |  | (60 | ) |  | 28 |  |  | (926 | ) |
| Net cash provided by discontinued financing activities | — |  |  | — |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Effect of currency translation on cash | — |  |  | — |  |  | — |  |  | (10 | ) |  | — |  |  | (10 | ) |
| Net decrease in cash and cash equivalents | — |  |  | — |  |  | — |  |  | (1,056 | ) |  | — |  |  | (1,056 | ) |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | — |  |  | 1,401 |  |  | — |  |  | 1,401 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 345 |  |  | $ | — |  |  | $ | 345 |  |

[0000833444-16-000172:notes:85]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | 20 |  |  | $ | — |  |  | $ | (504 | ) |  | $ | 746 |  |  | $ | — |  |  | $ | 262 |  |
| Net cash provided by discontinued operating activities | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | — |  |  | (123 | ) |  | — |  |  | (123 | ) |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | — |  |  | (525 | ) |  | — |  |  | (525 | ) |
| Acquisition of dealer generated customer accounts and bulk purchases | — |  |  | — |  |  | — |  |  | (8 | ) |  | — |  |  | (8 | ) |
| Divestiture of businesses, net of cash divested | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Net increase in intercompany loans | — |  |  | — |  |  | (59 | ) |  | — |  |  | 59 |  |  | — |  |
| Sales and maturities of investments including restricted investments | — |  |  | — |  |  | — |  |  | 279 |  |  | — |  |  | 279 |  |
| Purchases of investments including restricted investments | — |  |  | — |  |  | — |  |  | (288 | ) |  | — |  |  | (288 | ) |
| Increase in restricted cash | — |  |  | — |  |  | — |  |  | (39 | ) |  | — |  |  | (39 | ) |
| Other | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Net cash used in investing activities | — |  |  | — |  |  | (59 | ) |  | (703 | ) |  | 59 |  |  | (703 | ) |
| Net cash used in discontinued investing activities | — |  |  | — |  |  | — |  |  | (15 | ) |  | — |  |  | (15 | ) |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Repayment of short-term debt | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Proceeds from issuance of long-term debt | — |  |  | — |  |  | 567 |  |  | — |  |  | — |  |  | 567 |  |
| Proceeds from exercise of share options | 50 |  |  | — |  |  | — |  |  | 7 |  |  | — |  |  | 57 |  |
| Dividends paid | (151 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (151 | ) |
| Repurchase of ordinary shares | — |  |  | — |  |  | — |  |  | (417 | ) |  | — |  |  | (417 | ) |
| Net intercompany loan borrowings | 83 |  |  | — |  |  | — |  |  | (24 | ) |  | (59 | ) |  | — |  |
| Transfer to discontinued operations | — |  |  | — |  |  | — |  |  | (12 | ) |  | — |  |  | (12 | ) |
| Payment of contingent consideration | — |  |  | — |  |  | — |  |  | (23 | ) |  | — |  |  | (23 | ) |
| Debt financing costs | — |  |  | — |  |  | (4 | ) |  | — |  |  | — |  |  | (4 | ) |
| Other | (2 | ) |  | — |  |  | — |  |  | (17 | ) |  | — |  |  | (19 | ) |
| Net cash (used in) provided by financing activities | (20 | ) |  | — |  |  | 563 |  |  | (487 | ) |  | (59 | ) |  | (3 | ) |
| Net cash provided by discontinued financing activities | — |  |  | — |  |  | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Effect of currency translation on cash | — |  |  | — |  |  | — |  |  | (16 | ) |  | — |  |  | (16 | ) |
| Net decrease in cash and cash equivalents | — |  |  | — |  |  | — |  |  | (460 | ) |  | — |  |  | (460 | ) |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | — |  |  | 892 |  |  | — |  |  | 892 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 432 |  |  | $ | — |  |  | $ | 432 |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-16-000172:notes:86]
Debt

[0000833444-16-000172:notes:87]
The carrying value of the Company's debt as of March 25, 2016 and September 25, 2015 is as follows ($ in millions):

[0000833444-16-000172:notes:88]
|  | As of |
|  | March 25, 2016 |  | September 25, 2015 |
| Commercial paper(1) | $ | 400 |  |  | $ | — |  |
| 3.375% public notes due 2015(2) | — |  |  | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 7.0% public notes due 2019(2) | — |  |  | 245 |  |
| 6.875% public notes due 2021(2) | — |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% Euro-denominated public notes due 2025 | 558 |  |  | 558 |  |
| 3.9% public notes due 2026 | 745 |  |  | 745 |  |
| 5.125% public notes due 2045 | 746 |  |  | 746 |  |
| Other (2) | 1 |  |  | 20 |  |
| Total debt | 2,559 |  |  | 3,146 |  |
| Less current portion | 400 |  |  | 987 |  |
| Long-term debt | $ | 2,159 |  |  | $ | 2,159 |  |

[0000833444-16-000172:notes:89]
_______________________________________________________________________________

[0000833444-16-000172:notes:90]
(1)  The current portion of debt as of March 25, 2016 is comprised of $400 million of commercial paper.

[0000833444-16-000172:notes:91]
(2) The current portion of debt as of September 25, 2015 is comprised of $258 million notes due 2015, $245 million notes due 2019, $465 million notes due 2021 and $19 million of Other debt.

[0000833444-16-000172:notes:92]
Fair Value

[0000833444-16-000172:notes:93]
The carrying amount of Tyco's debt subject to the fair value disclosure requirements as of March 25, 2016 and September 25, 2015 was $2,558 million and $3,126 million, respectively. The Company utilizes various valuation methodologies to determine the fair value of its debt, which is primarily dependent on the type of market in which the Company's debt is traded. When available, the Company uses quoted market prices to determine the fair value of its debt that is traded in active markets.  As of March 25, 2016 and September 25, 2015, the fair value of the Company's debt which was actively traded was $2,615 million and $3,291 million, respectively.  As of March 25, 2016 and September 25, 2015, the Company's debt that was subject to the fair value disclosure requirements was all actively traded and is classified as Level 1 in the fair value hierarchy. Additionally, the Company believes the carrying amount of its commercial paper of $400 million as of March 25, 2016 approximates fair value based on the short-term nature of such debt.

[0000833444-16-000172:notes:94]
Fiscal 2016 Debt Repayment

[0000833444-16-000172:notes:95]
On September 14, 2015, the Company and the Company's wholly-owned subsidiary, Tyco International Finance S.A. ("TIFSA") announced the redemption of all of the outstanding $242 million aggregate principal amount of 7.0% notes due 2019 and $462 million aggregate principal amount of 6.875% notes due 2021. On October 14, 2015, TIFSA paid cash of $876 million to complete the redemption, resulting in a loss on extinguishment of $168 million which was recorded in Other expense, net within the Consolidated Statements of Operations during the first quarter of fiscal 2016. The charge is comprised of the make-whole premium of $172 million and the write-off of unamortized debt issuance costs of $1 million, partially offset by the write-off of the unamortized premium of $5 million.

[0000833444-16-000172:notes:96]
On October 15, 2015, the Company repaid $258 million aggregate principal amount of 3.375% notes which matured on such date.

[0000833444-16-000172:notes:97]
Financing in Connection with Proposed Merger with Johnson Controls

[0000833444-16-000172:notes:98]
On March 10, 2016, Tyco International Holding S.à r.l. ("TSARL"), an indirect wholly owned subsidiary of Tyco, entered into a Term Loan Credit Agreement with a syndicate of lenders providing for a senior unsecured term loan facility in the amount of $4 billion to finance the cash consideration for, and fees, expenses and costs incurred in connection with the merger with Johnson Controls, pursuant to the Merger Agreement dated as of January 24, 2016.  Any loans borrowed under the Term Loan Credit Agreement will be made in a single borrowing on the closing date of the facility and will have a maturity of 3.5 years and be denominated in U.S. dollars. The closing of the term loan facility is subject to customary closing conditions and the consummation of the Merger. See Note 1.

[0000833444-16-000172:notes:99]
In addition, on March 10, 2016, TSARL entered into a Multi-Year Senior Unsecured Credit Agreement providing for revolving credit commitments in the aggregate amount of $1 billion (the “Revolving Credit Agreement”). The closing of the revolving credit facility, and TSARL's ability to borrow under the Revolving Credit Agreement remains subject to the satisfaction or waiver of customary conditions, including the consummation of the Merger and the termination of the commitments of the lenders, and payments of all amounts outstanding, under the $1.5 billion Amended and Restated Five-Year Senior Unsecured Credit Agreement dated as of August 7, 2015. The Revolving Credit Agreement has a scheduled maturity date of August 7, 2020 and includes an option for TSARL to request an increase in the aggregate principal amount of the commitments, up to an additional $250 million.

[0000833444-16-000172:notes:100]
Credit Facilities

[0000833444-16-000172:notes:101]
On August 7, 2015, TIFSA entered into an Amended and Restated Five-Year Senior Unsecured Credit Agreement in the aggregate amount of $1.5 billion (the “2015 Credit Agreement”). The 2015 Credit Agreement amends and restates TIFSA's existing Five-Year Senior Unsecured Credit Agreement, dated June 22, 2012 (the “2012 Credit Agreement”), which provided for revolving credit commitments in the aggregate amount of $1 billion, and was scheduled to expire on June 22, 2017.  The 2015 Credit Agreement will be terminated upon completion of the Merger and replaced with the $1 billion credit facility as discussed above.

[0000833444-16-000172:notes:102]
As a result of entering into the 2015 Credit Agreement, the Company's committed revolving credit facility totaled $1.5 billion as of March 25, 2016. This revolving credit facility may be used for working capital, capital expenditures and general corporate purposes. As of March 25, 2016 and September 25, 2015, there were no amounts drawn under the Company's revolving credit facility. Interest under the revolving credit facility is variable and is calculated by reference to LIBOR or an alternate base rate.

[0000833444-16-000172:notes:103]
TIFSA's revolving credit facility contains customary terms and conditions, and financial covenants that limit the ratio of the Company's debt to earnings before interest, taxes, depreciation, and amortization and that limit our ability to incur subsidiary debt or grant liens on its property. The indentures contain customary covenants including limits on negative pledges, subsidiary debt and sale/leaseback transactions. None of these covenants are considered restrictive to the Company's business.

[0000833444-16-000172:notes:104]
Commercial Paper

[0000833444-16-000172:notes:105]
From time to time, TIFSA may issue commercial paper for general corporate purposes. The maximum aggregate amount of unsecured commercial paper notes available to be issued, on a private placement basis, under the commercial paper program is $1.5 billion as of March 25, 2016.  As of March 25, 2016 and September 25, 2015, TIFSA had $400 million and nil of commercial paper outstanding, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-16-000172:notes:106]
[same as prior period, unchanged from 0000833444-16-000120:notes:96]

[0000833444-16-000172:notes:107]
During the quarter ended December 25, 2015, the Company issued its annual share-based compensation grants. The total number of awards issued was approximately 3.7 million, of which 2.6 million were stock options, 0.5 million were restricted unit awards and 0.6 million were performance share unit awards. The options and restricted stock units vest in equal annual installments over a period of 4 years, and the performance share unit awards, which are restricted share awards that vest depending upon attainment of various levels of performance, generally vest in their entirety 3 years from the grant date, and are determined by the Compensation and Human Resources Committee of the Board. The weighted-average grant-date fair value of the stock options, restricted unit awards and performance share unit awards was $7.18, $36.08 and $37.16, respectively. The weighted-average assumptions used in the Black-Scholes option pricing model included an expected stock price volatility of 26%, a risk free interest rate of 1.60%, an expected annual dividend per share of $0.82 and an expected option life of 5.48 years.

[0000833444-16-000172:notes:108]
[same as prior period, unchanged from 0000833444-16-000120:notes:98]

[0000833444-16-000172:notes:109]
[same as prior period, unchanged from 0000833444-16-000120:notes:99]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-16-000172:notes:110]
[same as prior period, unchanged from 0000833444-16-000120:notes:100]

[0000833444-16-000172:notes:111]
[same as prior period, unchanged from 0000833444-16-000120:notes:101]

[0000833444-16-000172:notes:112]
[same as prior period, unchanged from 0000833444-16-000120:notes:102]

[0000833444-16-000172:notes:113]
During the second quarter of fiscal 2016, the Company completed the sale of its Australian fire protection business, included within its ROW Integrated Solutions & Services segment. The assets and liabilities of this business have been presented separately as held for sale within the Consolidated Balance Sheets as of September 25, 2015. The Company recorded a pre-tax loss of $75 million related to the sale for the six months ended March 25, 2016. This loss included a $57 million write-down to fair value, less costs to sell, which was recorded during the first quarter of fiscal 2016. Also included in the loss for the six month period was the write-off of a cumulative translation loss of $31 million, of which $24 million was provided for during the first quarter of fiscal 2016. This business has not been presented in discontinued operations within the Consolidated Statements of Operations, as the criteria to be presented as a discontinued operation were not satisfied.

[0000833444-16-000172:notes:114]
During the second quarter of fiscal 2016, the Company completed the sale of a business within its Global Products segment. The assets and liabilities have not been presented separately as held for sale within the Consolidated Balance Sheets as the amounts were not material to the presentation of all periods. A pre-tax loss of approximately $17 million was recorded in Selling, general and administrative expenses within the Company’s Consolidated Statements of Operations during the fourth quarter of fiscal 2015 which represented the Company's best estimate to write-down the business to fair value, less costs to sell. Upon completing the sale, the Company recorded an immaterial gain. This business has not been presented in discontinued operations as the amounts were not material to the Consolidated Financial Statements.

[0000833444-16-000172:notes:115]
In addition, during the second quarter of fiscal 2016, the Company completed the sale of another business within the ROW Integrated Solutions & Services segment and realized a loss that was not material. This business is accounted for as held for sale within the Consolidated Balance Sheets as of September 25, 2015, and its results of operations have been presented as discontinued operations within the Consolidated Statements of Operations for the quarters and six months ended March 25, 2016 and March 27, 2015.

[0000833444-16-000172:notes:116]
During the first quarter of fiscal 2016, the Company recorded a pre-tax gain of $17 million resulting from the transfer to Pentair Ltd. (formerly known as Tyco Flow Control International Ltd.) of Tyco's equity interest in a joint venture related to the Company's former Flow Control business as repayment of a loan established at the time of the 2012 Separation. This gain was recorded in Income (loss) from discontinued operations, net of income taxes, within the Consolidated Statements of Operations for the quarter ended December 25, 2015.

[0000833444-16-000172:notes:117]
[same as prior period, unchanged from 0000833444-16-000120:notes:105]

[0000833444-16-000172:notes:118]
During the quarter ended March 27, 2015, the Company concluded that several businesses in the ROW Installation & Services segment which it intended to sell met the criteria to be classified as held for sale. The Company completed the sale of these businesses during fiscal 2015.  To the extent the criteria required to be presented as a discontinued operation have been satisfied, the businesses results of operations have been presented as such on the Consolidated Statements of Operations during the quarters and six months ended March 27, 2015.

[0000833444-16-000172:notes:119]
[same as prior period, unchanged from 0000833444-16-000120:notes:108]

[0000833444-16-000172:notes:120]
During the second quarter of fiscal 2016, the Company recorded a net loss of $17 million in Selling, general and administrative expenses within the Company's Consolidated Statements of Operations, primarily related to the loss on sale of the Australia fire protection business, as described above. The Company recorded a net divestiture loss of $22 million during the second quarter of fiscal 2015, related to a business in the ROW Integrated Solutions & Services segment which was not presented within discontinued operations, as described above.

[0000833444-16-000172:notes:121]
During the six months ended March 25, 2016, the Company recorded a net loss of $69 million in Selling, general and administrative expenses within the Company's Consolidated Statements of Operations, primarily due to the sale of its Australian fire protection business, as described above. The Company recorded a net divestiture loss of $23 million during the six months ended March 27, 2015.

[0000833444-16-000172:notes:122]
[same as prior period, unchanged from 0000833444-16-000120:notes:110]

[0000833444-16-000172:notes:123]
[same as prior period, unchanged from 0000833444-16-000120:notes:111]

[0000833444-16-000172:notes:124]
|  | For the Quarters Ended |  | For the Six Months Ended |
|  | March 25, 2016 |  | March 27, 2015 |  | March 25, 2016 |  | March 27, 2015 |
| Net revenue | $ | — |  |  | $ | 5 |  |  | $ | 1 |  |  | $ | 10 |  |
| Pre-tax loss from discontinued operations | (1 | ) |  | (6 | ) |  | (2 | ) |  | (9 | ) |
| Pre-tax gain on sale of discontinued operations | — |  |  | — |  |  | 17 |  |  | 1 |  |
| Income tax benefit (expense) (1) | 2 |  |  | (10 | ) |  | (10 | ) |  | (10 | ) |
| Income (loss) from discontinued operations, net of income taxes | $ | 1 |  |  | $ | (16 | ) |  | $ | 5 |  |  | $ | (18 | ) |

[0000833444-16-000172:notes:125]
(1)  Income tax expense for the six months ended March 25, 2016 includes $12 million related to the Company’s settlement of an income tax matter in the first quarter of fiscal 2016 pertaining to its divested ADT Korea business for the 2012 period. This matter is unrelated to the liability established of $212 million during fiscal 2014 which relates to the indemnification for certain tax related matters in connection with the sale. The Company continues to maintain such liability until the matter is resolved.

[0000833444-16-000172:notes:126]
Balance sheet information for the assets and liabilities of businesses classified as held for sale as of September 25, 2015 was as follows ($ in millions):

[0000833444-16-000172:notes:127]
|  | As of |
|  | September 25, 2015 |
| Accounts receivable, net | $ | 44 |  |
| Inventories | 3 |  |
| Prepaid expenses and other current assets | 22 |  |
| Deferred income taxes | 1 |  |
| Property, plant and equipment, net | 13 |  |
| Goodwill | 3 |  |
| Intangible assets, net | 16 |  |
| Total assets | $ | 102 |  |
| Accounts payable | 12 |  |
| Accrued and other current liabilities | 26 |  |
| Deferred revenue | 2 |  |
| Other liabilities | 10 |  |
| Total liabilities | $ | 50 |  |

[0000833444-16-000172:notes:128]
[same as prior period, unchanged from 0000833444-16-000120:notes:116]


## us-gaap:EarningsPerShareTextBlock

[0000833444-16-000172:notes:129]
[same as prior period, unchanged from 0000833444-16-000120:notes:117]

[0000833444-16-000172:notes:130]
[same as prior period, unchanged from 0000833444-16-000120:notes:118]

[0000833444-16-000172:notes:131]
|  | For the Quarter Ended March 25, 2016 |  | For the Quarter Ended March 27, 2015 |
|  | Income |  | Shares |  | Per ShareAmount |  | Income |  | Shares |  | Per ShareAmount |
| Basic earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 145 |  |  | 425 |  |  | $ | 0.34 |  |  | $ | 183 |  |  | 420 |  |  | $ | 0.44 |  |
| Share options and restricted share awards | — |  |  | 3 |  |  |  |  | — |  |  | 7 |  |  |  |
| Diluted earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations attributable to Tyco ordinary shareholders, giving effect to dilutive adjustments | $ | 145 |  |  | 428 |  |  | $ | 0.33 |  |  | $ | 183 |  |  | 427 |  |  | $ | 0.43 |  |

[0000833444-16-000172:notes:132]
|  | For the Six Months Ended March 25, 2016 |  | For the Six Months Ended March 27, 2015 |
|  | Income |  | Shares |  | Per ShareAmount |  | Income |  | Shares |  | Per ShareAmount |
| Basic earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 217 |  |  | 424 |  |  | $ | 0.51 |  |  | $ | 347 |  |  | 420 |  |  | $ | 0.83 |  |
| Share options and restricted share awards | — |  |  | 4 |  |  |  |  | — |  |  | 7 |  |  |  |
| Diluted earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations attributable to Tyco ordinary shareholders, giving effect to dilutive adjustments | $ | 217 |  |  | 428 |  |  | $ | 0.51 |  |  | $ | 347 |  |  | 427 |  |  | $ | 0.81 |  |

[0000833444-16-000172:notes:133]
The computation of diluted earnings per share for the quarter and six months ended March 25, 2016 excludes the effect of the potential exercise of share options to purchase approximately 6 million shares for both periods and excludes restricted stock units of approximately 2 million shares for both periods because the effect would be anti-dilutive.

[0000833444-16-000172:notes:134]
The computation of diluted earnings per share for the quarter and six months ended March 27, 2015 excludes the effect of the potential exercise of share options to purchase approximately 3 million shares for both periods and excludes restricted stock units of approximately 1 million shares for both periods because the effect would be anti-dilutive.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000833444-16-000172:notes:135]
The following table presents the Company's hierarchy for its assets measured at fair value on a recurring basis as of March 25, 2016 and September 25, 2015 ($ in millions):

[0000833444-16-000172:notes:136]
|  |  |  |  |  |  |  | Consolidated Balance SheetClassification |
|  | As of March 25, 2016 |  | Cash and Cash Equivalents |  | Prepaids andOther CurrentAssets |  | Other Assets |
| Investment Assets: | Level 1 |  | Level 2 |  | Total |  |  |  |
| Cash equivalents | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |  | $ | 20 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Exchange traded funds (fixed income) (1) | 185 |  |  | — |  |  | 185 |  |  | — |  |  | 29 |  |  | 156 |  |
| Exchange traded funds (equity) (1) | 80 |  |  | — |  |  | 80 |  |  | — |  |  | — |  |  | 80 |  |
| Trading securities: |  |  |  |  |  |  |  |  |  |  |  |
| Exchange traded funds (equity) | 56 |  |  | — |  |  | 56 |  |  | — |  |  | 56 |  |  | — |  |
|  | $ | 341 |  |  | $ | — |  |  | $ | 341 |  |  | $ | 20 |  |  | $ | 85 |  |  | $ | 236 |  |

[0000833444-16-000172:notes:137]
[same as prior period, unchanged from 0000833444-16-000120:notes:124]

[0000833444-16-000172:notes:138]
(1) Classified as restricted investments.  See Note 11.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000833444-16-000172:notes:139]
[same as prior period, unchanged from 0000833444-16-000120:notes:126]

[0000833444-16-000172:notes:140]
The Company's financial instruments consist primarily of cash and cash equivalents, accounts receivable, investments, accounts payable, debt and derivative financial instruments. The fair value of cash, accounts receivable, and accounts payable approximated book value as of March 25, 2016 and September 25, 2015. The fair value of derivative financial instruments was not material to any of the periods presented. See below for the fair value of cash equivalents and investments and Note 9 for the fair value of debt.

[0000833444-16-000172:notes:141]
[same as prior period, unchanged from 0000833444-16-000120:notes:128]

[0000833444-16-000172:notes:142]
In the normal course of business, Tyco is exposed to market risk arising from changes in currency exchange rates, interest rates and commodity prices. The Company may use derivative financial instruments to manage exposures to foreign currency, interest rate and commodity risks. The Company's objective for utilizing derivative financial instruments is to manage these risks using the most effective methods to eliminate or reduce the impacts of these exposures. The Company does not use derivative financial instruments for trading or speculative purposes. As of and during the six months ended March 25, 2016, the Company did not hold or enter into any commodity derivative instruments or interest rate swaps.

[0000833444-16-000172:notes:143]
For derivative instruments that are designated and qualified as hedging instruments for accounting purposes, the Company documents and links the relationships between the hedging instruments and hedged items.  The Company also assesses and documents at the hedge's inception whether the derivatives used in hedging transactions are effective in offsetting changes in fair values associated with the hedged items. During the quarter ended March 27, 2015, the Company designated its 2025 Euro notes as a net investment hedge of the Company’s investments in certain of its international subsidiaries that use the Euro as their functional currency and intercompany permanent loans in order to reduce the volatility caused by changes in foreign currency exchange rates of the Euro with respect to the U.S. Dollar. During the three and six months ended March 25, 2016, the change in the carrying value due to remeasurement of the 2025 Euro notes resulted in a net loss of $13 million and nil, respectively, reported in Accumulated other comprehensive loss within the Consolidated Statement of Shareholders' Equity. During the quarter and six months ended March 27, 2015, the change in the carrying value due to remeasurement of the 2025 Euro notes resulted in a $20 million gain reported in Accumulated other comprehensive loss on the Consolidated Balance Sheet. This hedge did not result in any hedge ineffectiveness for the quarters and six months ended March 25, 2016 and March 27, 2015.

[0000833444-16-000172:notes:144]
[same as prior period, unchanged from 0000833444-16-000120:notes:131]

[0000833444-16-000172:notes:145]
As of March 25, 2016 and September 25, 2015, the total gross notional amount of the Company's foreign exchange contracts was $570 million and $365 million, respectively. The fair value of these derivative financial instruments and impact of such changes in the fair value was not material to the Consolidated Balance Sheets as of March 25, 2016 and September 25, 2015 or Consolidated Statements of Operations and Consolidated Statements of Cash Flows for the quarters and six months ended March 25, 2016 and March 27, 2015.

[0000833444-16-000172:notes:146]
[same as prior period, unchanged from 0000833444-16-000120:notes:133]

[0000833444-16-000172:notes:147]
The use of derivative financial instruments exposes the Company to counterparty credit risk.  Tyco has established policies and procedures to limit its exposure to counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association master netting agreements with substantially all of its counterparties.  The Company's derivative contracts do not contain any credit risk related contingent features and do not require collateral or other security to be furnished by the Company or the counterparties.  The Company's exposure to credit risk associated with its derivative instruments is measured on an individual counterparty basis, as well as by groups of counterparties that share similar attributes.  The Company does not anticipate any non-performance by any of its counterparties, and the concentration of risk with financial institutions does not present significant credit risk to the Company. The maximum amount of loss that the Company would incur as of March 25, 2016 without giving consideration to the effects of legally enforceable master netting agreements was not material.

[0000833444-16-000172:notes:148]
[same as prior period, unchanged from 0000833444-16-000120:notes:135]

[0000833444-16-000172:notes:149]
[same as prior period, unchanged from 0000833444-16-000120:notes:136]

[0000833444-16-000172:notes:150]
[same as prior period, unchanged from 0000833444-16-000120:notes:137]

[0000833444-16-000172:notes:151]
[same as prior period, unchanged from 0000833444-16-000120:notes:138]

[0000833444-16-000172:notes:152]
[same as prior period, unchanged from 0000833444-16-000120:notes:139]

[0000833444-16-000172:notes:153]
During the quarters ended March 25, 2016 and March 27, 2015, the Company did not have any significant transfers between levels within the fair value hierarchy.

[0000833444-16-000172:notes:154]
The Company recorded unrealized gains related to available-for-sale securities of $3 million and nil for the quarters ended March 25, 2016 and March 27, 2015, respectively, and $5 million and nil for the six months ended March 25, 2016 and March 27, 2015, respectively, within Accumulated other comprehensive loss.

[0000833444-16-000172:notes:155]
Unrealized losses related to trading securities were $1 million and unrealized gains were $1 million for the quarters ended March 25, 2016 and March 27, 2015, respectively. Unrealized gains were $2 million and $4 million for the six months ended March 25, 2016 and March 27, 2015, respectively, which are recorded within Other (expense) income, net within the Consolidated Statements of Operations.

[0000833444-16-000172:notes:156]
[same as prior period, unchanged from 0000833444-16-000120:notes:142]

[0000833444-16-000172:notes:157]
The Company had $1.3 billion and $1.4 billion of intercompany loans designated as permanent in nature as of March 25, 2016 and September 25, 2015, respectively.  Additionally, for the quarters ended March 25, 2016 and March 27, 2015, the Company recorded cumulative translation losses of $25 million and $75 million, respectively, through Accumulated other comprehensive loss related to these loans. For the six months ended March 25, 2016 and March 27, 2015, the Company recorded cumulative translation losses of $59 million and $145 million, respectively, through Accumulated other comprehensive loss related to these loans.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-16-000172:notes:158]
[same as prior period, unchanged from 0000833444-16-000120:notes:144]

[0000833444-16-000172:notes:159]
[same as prior period, unchanged from 0000833444-16-000120:notes:145]

[0000833444-16-000172:notes:160]
[same as prior period, unchanged from 0000833444-16-000120:notes:146]

[0000833444-16-000172:notes:161]
|  | NA Integrated Solutions &Services |  | ROWIntegrated Solutions &Services |  | GlobalProducts |  | Total |
| Gross goodwill | $ | 2,102 |  |  | $ | 1,969 |  |  | $ | 1,809 |  |  | $ | 5,880 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of September 26, 2014 | 1,976 |  |  | 901 |  |  | 1,242 |  |  | 4,119 |  |
| 2015 activity: |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions / purchase accounting adjustments | 23 |  |  | 50 |  |  | 274 |  |  | 347 |  |
| Currency translation | (29 | ) |  | (167 | ) |  | (36 | ) |  | (232 | ) |
| Gross goodwill | $ | 2,096 |  |  | $ | 1,852 |  |  | $ | 2,047 |  |  | $ | 5,995 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of September 25, 2015 | 1,970 |  |  | 784 |  |  | 1,480 |  |  | 4,234 |  |
| 2016 activity: |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions / purchase accounting adjustments | 69 |  |  | 182 |  |  | — |  |  | 251 |  |
| Currency translation | 1 |  |  | (20 | ) |  | (6 | ) |  | (25 | ) |
| Gross goodwill | $ | 2,166 |  |  | $ | 2,014 |  |  | $ | 2,041 |  |  | $ | 6,221 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of March 25, 2016 | $ | 2,040 |  |  | $ | 946 |  |  | $ | 1,474 |  |  | $ | 4,460 |  |

[0000833444-16-000172:notes:162]
[same as prior period, unchanged from 0000833444-16-000120:notes:148]

[0000833444-16-000172:notes:163]
Intangible asset amortization expense for the quarters ended March 25, 2016 and March 27, 2015 was $25 million and $21 million, respectively. Intangible asset amortization expense for the six months ended March 25, 2016 and March 27, 2015 was $48 million and $41 million, respectively.

[0000833444-16-000172:notes:164]
The estimated aggregate amortization expense on intangible assets is expected to be approximately $53 million for the remainder of 2016, $95 million for 2017, $91 million for 2018, $85 million for 2019, and $396 million for 2020 and thereafter.


## us-gaap:GuaranteesTextBlock

[0000833444-16-000172:notes:165]
[same as prior period, unchanged from 0000833444-16-000120:notes:151]

[0000833444-16-000172:notes:166]
[same as prior period, unchanged from 0000833444-16-000120:notes:152]

[0000833444-16-000172:notes:167]
There are certain guarantees or indemnifications extended among Tyco, Covidien, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 Separation and Distribution Agreements and Tax Sharing Agreements. These guarantees primarily relate to certain contingent tax liabilities included in the Tax Sharing Agreements. See Note 6.

[0000833444-16-000172:notes:168]
In addition, Tyco historically provided support in the form of financial and/or performance guarantees to various Covidien, TE Connectivity, ADT and Tyco Flow Control operating entities. In connection with both the 2012 and 2007 Separations, the Company worked with the guarantee counterparties to cancel or assign these guarantees to Covidien, TE Connectivity, ADT or Pentair, as appropriate. To the extent these guarantees were not assigned prior to the Separation dates, Tyco remained as the guarantor, but was typically indemnified by the former subsidiary. The Company's obligations related to the 2012 Separation were $3 million, which were included in Other liabilities within the Company's Consolidated Balance Sheets as of both March 25, 2016 and September 25, 2015, with an offset to Tyco's shareholders' equity on the 2012 Separation date. The Company's obligations related to the 2007 Separation were $3 million, which were included in Other liabilities within the Company's Consolidated Balance Sheets as of both March 25, 2016 and September 25, 2015, with an offset to Tyco's shareholders' equity on the 2007 Separation date.

[0000833444-16-000172:notes:169]
In disposing of assets or businesses, the Company or its subsidiaries often provides representations, warranties and/or indemnities to cover various risks including, for example, unknown damage to the assets, environmental risks involved in the sale of real estate, liability to investigate and remediate environmental contamination at waste disposal sites and manufacturing facilities and unidentified tax liabilities and legal fees related to periods prior to disposition. The Company has no reason to believe that these contingencies, if realized, would have a material adverse effect on the Company's financial position, results of operations or cash flows. The Company has recorded liabilities for known indemnifications included as part of environmental liabilities. See Note 11 for further information on environmental matters.

[0000833444-16-000172:notes:170]
[same as prior period, unchanged from 0000833444-16-000120:notes:156]

[0000833444-16-000172:notes:171]
The changes in the carrying amount of the Company's warranty accrual from September 25, 2015 to March 25, 2016 were as follows ($ millions):

[0000833444-16-000172:notes:172]
| Balance as of September 25, 2015 | $ | 29 |  |
| Warranties issued | 4 |  |
| Changes in estimates | (1 | ) |
| Settlements | (3 | ) |
| Balance as of March 25, 2016 | $ | 29 |  |

[0000833444-16-000172:notes:173]
Warranty accruals for businesses that are included in Liabilities held for sale within the Consolidated Balance Sheets are excluded from the table above.  See Note 3.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-16-000172:notes:174]
[same as prior period, unchanged from 0000833444-16-000120:notes:160]

[0000833444-16-000172:notes:175]
Tyco did not have a significant change to its unrecognized tax benefits during the quarter ended March 25, 2016.

[0000833444-16-000172:notes:176]
[same as prior period, unchanged from 0000833444-16-000120:notes:162]

[0000833444-16-000172:notes:177]
| Jurisdiction | Years OpenTo Audit |
| Australia | 2004-2015 |
| Canada | 2006-2015 |
| Germany | 2006-2015 |
| Ireland | 2011-2015 |
| Switzerland | 2006-2015 |
| United Kingdom | 2013-2015 |
| United States | 1997-2015 |

[0000833444-16-000172:notes:178]
[same as prior period, unchanged from 0000833444-16-000120:notes:164]

[0000833444-16-000172:notes:179]
At each balance sheet date, the Company evaluates whether it is more likely than not that Tyco's deferred tax assets will be realized and if sufficient future taxable income will be available by assessing current period and projected operating results and other pertinent data. As of March 25, 2016, Tyco recorded deferred tax assets of approximately $212 million, which is comprised of $2.3 billion gross deferred tax assets net of $2.1 billion valuation allowances.

[0000833444-16-000172:notes:180]
[same as prior period, unchanged from 0000833444-16-000120:notes:166]

[0000833444-16-000172:notes:181]
[same as prior period, unchanged from 0000833444-16-000120:notes:167]

[0000833444-16-000172:notes:182]
[same as prior period, unchanged from 0000833444-16-000120:notes:168]

[0000833444-16-000172:notes:183]
[same as prior period, unchanged from 0000833444-16-000120:notes:169]

[0000833444-16-000172:notes:184]
[same as prior period, unchanged from 0000833444-16-000120:notes:170]

[0000833444-16-000172:notes:185]
Assuming the tentative resolution is finalized, Tyco does not expect to recognize any additional charges related to the resolution, as it had previously recorded sufficient reserves with respect to this controversy and its obligations under the Tax Sharing Agreements. In the second quarter of fiscal 2016, the Company paid $120 million to TE Connectivity and $2 million to Covidien, which was subsequently paid to the IRS, in connection with the tentative resolution.

[0000833444-16-000172:notes:186]
[same as prior period, unchanged from 0000833444-16-000120:notes:172]

[0000833444-16-000172:notes:187]
In addition to dealing with tax liabilities for periods prior to the respective Separations, the 2012 and 2007 Tax Sharing Agreements contain sharing provisions to address the contingencies that the 2012 or 2007 Separations, or internal transactions related thereto, may be deemed taxable by U.S. or non U.S. taxing authorities. In the event the 2012 Separation is determined to be taxable and such determination was the result of actions taken after the 2012 Separations by Tyco, ADT or Pentair, the party responsible for such failure would be responsible for all taxes imposed on each company as a result thereof. If such determination is not the result of actions taken by Tyco, ADT or Pentair after the 2012 Separation, then Tyco, ADT and Pentair would be responsible for any taxes imposed on any of the companies as a result of such determination in the same manner and in the same proportions as described above. Similar provisions exist in the 2007 Tax Sharing Agreement. If either of the 2007 or 2012 Separation, or internal transactions taken in anticipation thereof, were deemed taxable, the associated liability could be significant. Tyco is responsible for all of its own taxes that are not shared pursuant to the 2012 and 2007 Tax Sharing Agreements' sharing formulas. In addition, Pentair and ADT, and Covidien and TE Connectivity are responsible for their tax liabilities that are not subject to the 2012 or 2007 Tax Sharing Agreements' sharing formula.

[0000833444-16-000172:notes:188]
[same as prior period, unchanged from 0000833444-16-000120:notes:174]

[0000833444-16-000172:notes:189]
In addition to the amounts above, pursuant to the terms of the 2012 Separation and Distribution Agreement, Tyco, ADT and Pentair are each responsible for issuing their own shares upon employee exercise of a stock option award or vesting of a restricted unit award. However, the 2012 Tax Sharing Agreement provides that any allowable compensation tax deduction for such awards is to be claimed by the employee's current employer. The 2012 Tax Sharing Agreement requires the employer claiming a tax deduction for shares issued by the other companies to pay a percentage of the allowable tax deduction to the company issuing the equity. During the quarter and six months ended March 25, 2016, Tyco made a $15 million net payment to Pentair and a $1 million net payment to ADT in connection with deductions claimed for Pentair and ADT shares issued to Company employees. Payments made to Pentair and ADT for the six months ended March 27, 2015 were not material.

[0000833444-16-000172:notes:190]
[same as prior period, unchanged from 0000833444-16-000120:notes:175]

[0000833444-16-000172:notes:191]
[same as prior period, unchanged from 0000833444-16-000120:notes:176]


## us-gaap:InventoryDisclosureTextBlock

[0000833444-16-000172:notes:192]
[same as prior period, unchanged from 0000833444-16-000120:notes:177]

[0000833444-16-000172:notes:193]
[same as prior period, unchanged from 0000833444-16-000120:notes:178]

[0000833444-16-000172:notes:194]
|  | As of |
|  | March 25, 2016 |  | September 25, 2015 |
| Purchased materials and manufactured parts | $ | 183 |  |  | $ | 165 |  |
| Work in process | 77 |  |  | 84 |  |
| Finished goods | 410 |  |  | 375 |  |
| Inventories | $ | 670 |  |  | $ | 624 |  |

[0000833444-16-000172:notes:195]
[same as prior period, unchanged from 0000833444-16-000120:notes:180]


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-16-000172:notes:196]
On January 24, 2016, Tyco entered into a Merger Agreement with Johnson Controls. See Note 1. The Company expects to incur transaction related costs ("Merger Costs") in connection with activities taken in anticipation of the Merger, primarily related to financing, investment banking, advisory, legal, valuation, and other professional fees, and retention related costs for certain Tyco employees. The Company incurred pre-tax merger costs within continuing operations of $26 million during the quarter and six months ended March 25, 2016 primarily related to financing, advisory and professional fees. The Company received no tax benefits during the quarter and six months ended March 25, 2016 related to these charges.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-16-000172:notes:197]
[same as prior period, unchanged from 0000833444-16-000120:notes:181]

[0000833444-16-000172:notes:198]
[same as prior period, unchanged from 0000833444-16-000120:notes:182]

[0000833444-16-000172:notes:199]
|  | U.S. Plans |
|  | For the Quarters Ended |  | For the Six Months Ended |
|  | March 25, 2016 |  | March 27, 2015 |  | March 25, 2016 |  | March 27, 2015 |
| Service cost | $ | 2 |  |  | $ | 2 |  |  | $ | 4 |  |  | $ | 4 |  |
| Interest cost | 8 |  |  | 9 |  |  | 16 |  |  | 18 |  |
| Expected return on plan assets | (12 | ) |  | (14 | ) |  | (24 | ) |  | (28 | ) |
| Amortization of net actuarial loss | 3 |  |  | 2 |  |  | 6 |  |  | 4 |  |
| Net periodic (benefit) cost | $ | 1 |  |  | $ | (1 | ) |  | $ | 2 |  |  | $ | (2 | ) |

[0000833444-16-000172:notes:200]
|  | Non-U.S. Plans |
|  | For the Quarters Ended |  | For the Six Months Ended |
|  | March 25, 2016 |  | March 27, 2015 |  | March 25, 2016 |  | March 27, 2015 |
| Service cost | $ | 2 |  |  | $ | 3 |  |  | $ | 4 |  |  | $ | 5 |  |
| Interest cost | 10 |  |  | 13 |  |  | 21 |  |  | 26 |  |
| Expected return on plan assets | (17 | ) |  | (19 | ) |  | (35 | ) |  | (39 | ) |
| Amortization of net actuarial loss | 3 |  |  | 3 |  |  | 7 |  |  | 7 |  |
| Net periodic benefit | $ | (2 | ) |  | $ | — |  |  | $ | (3 | ) |  | $ | (1 | ) |

[0000833444-16-000172:notes:201]
Effective September 26, 2015, the Company changed the approach used to measure service and interest costs for pension benefits.  For fiscal 2015, the Company measured service and interest costs utilizing a single weighted-average discount rate derived from the yield curve used to measure the Company’s plan obligations. For fiscal 2016, the Company elected to measure service and interest costs by applying the specific spot rates along the yield curve over the projected cash flow period.  The Company believes the new approach provides a more precise measurement of service and interest costs by improving the correlation between projected benefit cash flows to the corresponding spot rates on the yield curves. The Company estimates its periodic pension costs for both its U.S. and non-U.S. plans will be reduced by approximately $6 million each in fiscal 2016 as a result of the change. The Company has accounted for this change as a change in accounting estimate and, accordingly, has accounted for it on a prospective basis.

[0000833444-16-000172:notes:202]
[same as prior period, unchanged from 0000833444-16-000120:notes:186]

[0000833444-16-000172:notes:203]
The Company's funding policy is to make contributions in accordance with the laws and customs of the various countries in which it operates and to make discretionary voluntary contributions from time to time. The Company anticipates that it will contribute $3 million for U.S. plans and $25 million for non-U.S. plans during fiscal 2016.

[0000833444-16-000172:notes:204]
During the quarter ended March 25, 2016, the Company made required contributions of $1 million to its U.S. pension plans and $2 million to its non-U.S. pension plans. During the six months ended March 25, 2016, the Company made required contributions of $1 million to its U.S. pension plans and $13 million to its non-U.S. pension plans.  The Company did not make any voluntary contributions to its U.S. plans during the quarter and six months ended March 25, 2016.  The Company made a voluntary contribution of $4 million to its non-U.S. plans during the quarter and six months ended March 25, 2016.

[0000833444-16-000172:notes:205]
[same as prior period, unchanged from 0000833444-16-000120:notes:189]


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000833444-16-000172:notes:206]
[same as prior period, unchanged from 0000833444-16-000120:notes:190]

[0000833444-16-000172:notes:207]
[same as prior period, unchanged from 0000833444-16-000120:notes:191]

[0000833444-16-000172:notes:208]
|  | As of |
|  | March 25, 2016 |  | September 25, 2015 |
| Land | $ | 33 |  |  | $ | 33 |  |
| Buildings | 429 |  |  | 405 |  |
| Subscriber systems | 1,802 |  |  | 1,933 |  |
| Machinery and equipment | 1,281 |  |  | 1,252 |  |
| Construction in progress | 103 |  |  | 81 |  |
| Accumulated depreciation | (2,459 | ) |  | (2,527 | ) |
| Property, plant and equipment, net | $ | 1,189 |  |  | $ | 1,177 |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000833444-16-000172:notes:209]
[same as prior period, unchanged from 0000833444-16-000120:notes:193]

[0000833444-16-000172:notes:210]
During fiscal 2016, the Company identified and pursued additional opportunities for cost savings through restructuring activities and workforce reductions to improve operating efficiencies across the Company's businesses. The Company expects to incur restructuring and restructuring related charges between $35 million and $50 million in fiscal 2016, which does not include repositioning charges, as described below.

[0000833444-16-000172:notes:211]
[same as prior period, unchanged from 0000833444-16-000120:notes:195]

[0000833444-16-000172:notes:212]
|  | For the Quarters Ended |  | For the Six Months Ended |
|  | March 25, 2016 |  | March 27, 2015 |  | March 25, 2016 |  | March 27, 2015 |
| 2016 actions | $ | 6 |  |  | $ | — |  |  | $ | 15 |  |  | $ | — |  |
| 2015 actions | (2 | ) |  | 9 |  |  | 1 |  |  | 58 |  |
| 2014 and prior actions | 1 |  |  | 3 |  |  | 1 |  |  | 12 |  |
| Total restructuring and asset impairment charges, net | $ | 5 |  |  | $ | 12 |  |  | $ | 17 |  |  | $ | 70 |  |
| Charges reflected in SG&A | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |
| Charges reflected in restructuring and asset impairments, net | 4 |  |  | 12 |  |  | 16 |  |  | 70 |  |

[0000833444-16-000172:notes:213]
[same as prior period, unchanged from 0000833444-16-000120:notes:197]

[0000833444-16-000172:notes:214]
Restructuring and asset impairment charges, net, during the quarter and six months ended March 25, 2016 related to the 2016 actions are as follows ($ in millions):

[0000833444-16-000172:notes:215]
|  | For the Quarter Ended March 25, 2016 |
|  | EmployeeSeverance andBenefits |  | Charges Reflected in SG&A |  | Total |
| ROW Integrated Solutions & Services | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| Global Products | 2 |  |  | 1 |  |  | 3 |  |
| Corporate and Other | 1 |  |  | — |  |  | 1 |  |
| Total | $ | 5 |  |  | $ | 1 |  |  | $ | 6 |  |

[0000833444-16-000172:notes:216]
|  | For the Six Months Ended March 25, 2016 |
|  | EmployeeSeverance andBenefits |  | Facility Exit and Other Charges |  | Charges Reflected in SG&A |  | Total |
| NA Integrated Solutions & Services | $ | 2 |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |
| ROW Integrated Solutions & Services | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Global Products | 4 |  |  | 1 |  |  | 1 |  |  | 6 |  |
| Corporate and Other | 4 |  |  | — |  |  | — |  |  | 4 |  |
| Total | $ | 13 |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 15 |  |

[0000833444-16-000172:notes:217]
The rollforward of the reserves from September 25, 2015 to March 25, 2016 is as follows ($ in millions):

[0000833444-16-000172:notes:218]
| Balance as of September 25, 2015 | $ | — |  |
| Charges | 15 |  |
| Reversals | (1 | ) |
| Utilization | (7 | ) |
| Balance as of March 25, 2016 | $ | 7 |  |

[0000833444-16-000172:notes:219]
[same as prior period, unchanged from 0000833444-16-000120:notes:203]

[0000833444-16-000172:notes:220]
Restructuring and asset impairment charges, net, during the quarters and six months ended March 25, 2016 and March 27, 2015 related to the 2015 actions are as follows ($ in millions):

[0000833444-16-000172:notes:221]
|  | For the Quarter Ended March 25, 2016 |  | For the Quarter Ended March 27, 2015 |
|  | EmployeeSeverance andBenefits |  | EmployeeSeverance andBenefits |
| NA Integrated Solutions & Services | $ | (1 | ) |  | $ | 4 |  |
| ROW Integrated Solutions & Services | — |  |  | 4 |  |
| Global Products | — |  |  | 1 |  |
| Corporate and Other | (1 | ) |  | — |  |
| Total | $ | (2 | ) |  | $ | 9 |  |

[0000833444-16-000172:notes:222]
|  | For the Six Months Ended March 25, 2016 |
|  | EmployeeSeverance andBenefits |
| NA Integrated Solutions & Services | $ | 1 |  |
| Total | $ | 1 |  |

[0000833444-16-000172:notes:223]
|  | For the Six Months Ended March 27, 2015 |
|  | EmployeeSeverance andBenefits |  | Facility Exit and Other Charges |  | Total |
| NA Integrated Solutions & Services | $ | 26 |  |  | $ | — |  |  | $ | 26 |  |
| ROW Integrated Solutions & Services | 14 |  |  | 5 |  |  | 19 |  |
| Global Products | 3 |  |  | — |  |  | 3 |  |
| Corporate and Other | 10 |  |  | — |  |  | 10 |  |
| Total | $ | 53 |  |  | $ | 5 |  |  | $ | 58 |  |

[0000833444-16-000172:notes:224]
[same as prior period, unchanged from 0000833444-16-000120:notes:206]

[0000833444-16-000172:notes:225]
|  | EmployeeSeverance andBenefits |  | Facility Exitand OtherCharges |  | Charges Reflected in SG&A |  | Total |
| NA Integrated Solutions & Services | $ | 42 |  |  | $ | 3 |  |  | $ | 1 |  |  | $ | 46 |  |
| ROW Integrated Solutions & Services | 81 |  |  | 9 |  |  | 1 |  |  | 91 |  |
| Global Products | 21 |  |  | 1 |  |  | (1 | ) |  | 21 |  |
| Corporate and Other | 20 |  |  | 1 |  |  | — |  |  | 21 |  |
| Total | $ | 164 |  |  | $ | 14 |  |  | $ | 1 |  |  | $ | 179 |  |

[0000833444-16-000172:notes:226]
| Balance as of September 25, 2015 | $ | 117 |  |
| Charges | 6 |  |
| Reversals | (5 | ) |
| Utilization | (31 | ) |
| Currency translation | (1 | ) |
| Balance as of March 25, 2016 | $ | 86 |  |

[0000833444-16-000172:notes:227]
Restructuring reserves for businesses that are included in Liabilities held for sale within the Consolidated Balance Sheets are excluded from the table above.  See Note 3.

[0000833444-16-000172:notes:228]
[same as prior period, unchanged from 0000833444-16-000120:notes:209]

[0000833444-16-000172:notes:229]
The Company continues to maintain restructuring reserves related to actions initiated prior to fiscal 2015. The total amount of these reserves was $32 million and $38 million as of March 25, 2016 and September 25, 2015, respectively. The Company incurred $1 million and $3 million of net restructuring charges and utilized $4 million and $13 million for the quarters ended March 25, 2016 and March 27, 2015, respectively, related to 2014 and prior actions. The Company incurred $1 million and $12 million of net restructuring charges and utilized $10 million and $29 million for the six months ended March 25, 2016 and March 27, 2015, respectively, related to 2014 and prior actions. The aggregate remaining reserves relate to employee severance and benefits as well as facility exit costs for long-term non-cancelable lease obligations primarily within the Company's NA Integrated Solutions & Services and ROW Integrated Solutions & Services segments.

[0000833444-16-000172:notes:230]
[same as prior period, unchanged from 0000833444-16-000120:notes:211]

[0000833444-16-000172:notes:231]
[same as prior period, unchanged from 0000833444-16-000120:notes:212]

[0000833444-16-000172:notes:232]
The Company has initiated certain global actions designed to reduce its cost structure and improve future profitability by streamlining operations and better aligning functions, which the Company refers to as repositioning actions. These actions may or may not lead to a future restructuring action. During the quarters ended March 25, 2016 and March 27, 2015, the Company recorded net repositioning charges of $5 million and $17 million, respectively, and $11 million and $34 million for the six months ended March 25, 2016 and March 27, 2015, respectively, primarily related to professional fees which have been reflected in Selling, general and administrative expenses within the Consolidated Statements of Operations.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000833444-16-000172:notes:233]
A summary of the changes in each component of Accumulated other comprehensive loss, net of tax, for the six months ended March 25, 2016 and March 27, 2015 are as follows ($ in millions):

[0000833444-16-000172:notes:234]
|  | CurrencyTranslationAdjustments |  | Unrealized Gain(Loss) onMarketableSecurities andDerivativeInstruments |  | RetirementPlans |  | Accumulated OtherComprehensive Loss |
| Balance as of September 25, 2015 | $ | (1,233 | ) |  | $ | (9 | ) |  | $ | (599 | ) |  | $ | (1,841 | ) |
| Other comprehensive income, net of tax | (28 | ) |  | 3 |  |  | — |  |  | (25 | ) |
| Amounts reclassified from accumulated other comprehensive income, net of tax | 29 |  |  | — |  |  | 8 |  |  | 37 |  |
| Net current period other comprehensive income | $ | 1 |  |  | $ | 3 |  |  | $ | 8 |  |  | $ | 12 |  |
| Balance as of March 25, 2016 | $ | (1,232 | ) |  | $ | (6 | ) |  | $ | (591 | ) |  | $ | (1,829 | ) |

[0000833444-16-000172:notes:235]
|  | CurrencyTranslationAdjustments |  | RetirementPlans |  | Accumulated OtherComprehensive Loss |
| Balance as of September 26, 2014 | $ | (693 | ) |  | $ | (532 | ) |  | $ | (1,225 | ) |
| Other comprehensive loss, net of tax | (374 | ) |  | — |  |  | (374 | ) |
| Amounts reclassified from accumulated other comprehensive income, net of tax | — |  |  | 9 |  |  | 9 |  |
| Net current period other comprehensive (loss) income | $ | (374 | ) |  | $ | 9 |  |  | $ | (365 | ) |
| Balance as of March 27, 2015 | $ | (1,067 | ) |  | $ | (523 | ) |  | $ | (1,590 | ) |


## us-gaap:ScheduleOfComprehensiveIncomeLossTableTextBlock

[0000833444-16-000172:notes:236]
[same as prior period, unchanged from 0000833444-16-000120:notes:217]

[0000833444-16-000172:notes:237]
|  | For the Quarters Ended |  | For the Six Months Ended |
|  | March 25, 2016 |  | March 27, 2015 |  | March 25, 2016 |  | March 27, 2015 |
| Net income | $ | 145 |  |  | $ | 165 |  |  | $ | 221 |  |  | $ | 326 |  |
| Foreign currency translation (1) | 15 |  |  | (176 | ) |  | (28 | ) |  | (374 | ) |
| Liquidation of foreign entities (2) | 29 |  |  | — |  |  | 29 |  |  | — |  |
| Foreign currency translation | 44 |  |  | (176 | ) |  | 1 |  |  | (374 | ) |
| Amortization of net actuarial losses (3) | 6 |  |  | 5 |  |  | 13 |  |  | 11 |  |
| Income tax expense | (3 | ) |  | (1 | ) |  | (5 | ) |  | (2 | ) |
| Defined benefit and post retirement plans, net of tax | 3 |  |  | 4 |  |  | 8 |  |  | 9 |  |
| Unrealized gain on marketable securities and derivative instruments (4) | 3 |  |  | — |  |  | 5 |  |  | — |  |
| Income tax expense | (1 | ) |  | — |  |  | (2 | ) |  | — |  |
| Unrealized gain on marketable securities and derivative instruments, net of tax | 2 |  |  | — |  |  | 3 |  |  | — |  |
| Total other comprehensive income (loss), net of tax | 49 |  |  | (172 | ) |  | 12 |  |  | (365 | ) |
| Comprehensive income (loss) | 194 |  |  | (7 | ) |  | 233 |  |  | (39 | ) |
| Less: comprehensive loss attributable to noncontrolling interests | (1 | ) |  | (2 | ) |  | (1 | ) |  | (3 | ) |
| Comprehensive income (loss) attributable to Tyco ordinary shareholders | $ | 195 |  |  | $ | (5 | ) |  | $ | 234 |  |  | $ | (36 | ) |

[0000833444-16-000172:notes:238]
(1) Includes loss of $13 million and nil related to the net investment hedge for the quarter and six months ended March 25, 2016, respectively. Includes gain of $20 million related to the net investment hedge for both the quarter and six months ended March 27, 2015.  See Note 10.

[0000833444-16-000172:notes:239]
(2) During the quarter ended March 25, 2016, $31 million of cumulative translation losses were transferred from currency translation adjustments as a result of the sale of a foreign entity. Of this amount, $24 million was applied against a provision for cumulative translation losses within the Consolidated Balance Sheets which was established during the first quarter of fiscal 2016 and $7 million was transferred to Selling, general and administrative expense within the Consolidated Statements of Operations. Additionally, during the quarter and six months ended March 25, 2016, $2 million of cumulative translation gains were transferred from currency translation adjustments and are included in Income (loss) from discontinued operations, net of income taxes within the Consolidated Statements of Operations as a result of the sale of another foreign entity.

[0000833444-16-000172:notes:240]
(3) Reclassified to net periodic (benefit) cost. See Note 12.

[0000833444-16-000172:notes:241]
(4) When sold, the gain (loss) will be reclassified to realized gain (loss) on marketable securities and derivative instruments and be recorded in Other (expense) income, net within the Consolidated Statements of Operations.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-16-000172:notes:242]
[same as prior period, unchanged from 0000833444-16-000120:notes:222]

[0000833444-16-000172:notes:243]
Effective for the first quarter of fiscal 2016, the Company elected to present operating income by segment, as well as Corporate and Other, excluding restructuring and repositioning charges, net.  Restructuring and repositioning charges, net, are shown in aggregate. This presentation is consistent with how management reviews the businesses, makes investing and resource decisions and assesses operating performance. Comparative periods presented have been reclassified to conform with the current period presentation.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-16-000172:notes:244]
[same as prior period, unchanged from 0000833444-16-000120:notes:224]

[0000833444-16-000172:notes:245]
[same as prior period, unchanged from 0000833444-16-000120:notes:225]

[0000833444-16-000172:notes:246]
As of March 25, 2016 and September 25, 2015, the Company's authorized share capital amounted to $11,000,000 and €40,000, divided into 1,000,000,000 ordinary shares with a par value of $0.01 per share, 100,000,000 preferred shares with a par value of $0.01 per share and 40,000 ordinary A shares with a par value of €1.00 per share.  The authorized share capital includes 40,000 ordinary A shares with a par value of €1.00 per share in order to satisfy statutory requirements for the incorporation of all Irish public limited companies. Tyco Ireland may issue shares subject to the maximum prescribed by its authorized share capital contained in its memorandum of association. In connection with the re-domicile to Ireland, the Company canceled all the outstanding treasury shares, including shares held by subsidiaries, with an offsetting reduction in Additional paid in capital.

[0000833444-16-000172:notes:247]
[same as prior period, unchanged from 0000833444-16-000120:notes:227]

[0000833444-16-000172:notes:248]
The Company issued one authorized ordinary share in exchange for each ordinary share of Tyco Switzerland to the former shareholders of Tyco Switzerland.  All ordinary shares issued at the effective time of the re-domicile were issued as fully paid-up and non-assessable. See Note 1.

[0000833444-16-000172:notes:249]
[same as prior period, unchanged from 0000833444-16-000120:notes:229]

[0000833444-16-000172:notes:250]
[same as prior period, unchanged from 0000833444-16-000120:notes:230]

[0000833444-16-000172:notes:251]
[same as prior period, unchanged from 0000833444-16-000120:notes:231]

[0000833444-16-000172:notes:252]
On March 14, 2016, the Company declared a quarterly dividend of $0.205 per share, payable on May 18, 2016 to shareholders of record on April 22, 2016. On December 8, 2015, the Company declared a quarterly dividend of $0.205 per share, paid on February 17, 2016 to shareholders of record on January 22, 2016. On September 3, 2015, the Company declared a quarterly dividend of $0.205 per share, paid on November 12, 2015 to shareholders of record on October 23, 2015.

[0000833444-16-000172:notes:253]
On March 4, 2015, the Board of Directors approved a quarterly dividend $0.205 per ordinary share payable on May 20, 2015 to shareholders of record on April 24, 2015.

[0000833444-16-000172:notes:254]
As previously disclosed in the 2015 Form 10-K, the Company presented dividends declared of $86 million as a reduction of Additional paid in capital within the Company’s Consolidated Statements of Shareholders’ Equity for the six months ended March 27, 2015. For the year ended September 25, 2015, the Company corrected this presentation to present dividends declared for the periods subsequent to the re-domicile to Ireland as a reduction of Accumulated Earnings within the Consolidated Statement of Shareholder’s Equity to conform the presentation to its stand-alone statutory financial statements prepared under Irish GAAP. The Irish Companies Act (2014) does not permit dividends to be paid from share capital, including share premium. This reclassification had no effect on net revenue, operating income (loss), net income (loss), cash flows and total equity. Accordingly, the Company has reclassed its presentation of dividends declared for the six months ended March 27, 2015 included herein.

[0000833444-16-000172:notes:255]
[same as prior period, unchanged from 0000833444-16-000120:notes:234]

[0000833444-16-000172:notes:256]
The Company's Board of Directors approved $1.75 billion and $1 billion share repurchase programs in March 2014 and September 2014, respectively.  No shares were repurchased during the quarters ended March 25, 2016 and March 27, 2015 and the six months ended March 25, 2016.  During the six months ended March 27, 2015, the Company repurchased a total of approximately 10 million shares for approximately $417 million which completed the $1.75 billion share repurchase program.  As of March 25, 2016, a total of approximately $1 billion in share repurchase authority remained outstanding.

[0000833444-16-000172:notes:257]
[same as prior period, unchanged from 0000833444-16-000120:notes:236]
