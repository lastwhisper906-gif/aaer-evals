# JCI note change history — 0000833444-16-000120 → 0000833444-16-000172


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-04-29):
[0000833444-16-000172:note_history:1]
Tyco is involved in various stages of investigation and cleanup related to environmental remediation matters at a number of sites. The ultimate cost of site cleanup is difficult to predict given the uncertainties regarding the extent of the required cleanup, the interpretation of applicable laws and regulations and alternative cleanup methods. As of March 25, 2016, Tyco concluded that it was probable that it would incur remedial costs in the range of approximately $21 million to $70 million. As of March 25, 2016, Tyco concluded that the best estimate within this range is approximately $31 million, of which $11 million is included in Accrued and other current liabilities and $20 million is included in Other liabilities within the Company's Consolidated Balance Sheet.
  (was, 2016-01-29, similarity 0.9829):
[0000833444-16-000120:note_history:1]
Tyco is involved in various stages of investigation and cleanup related to environmental remediation matters at a number of sites. The ultimate cost of site cleanup is difficult to predict given the uncertainties regarding the extent of the required cleanup, the interpretation of applicable laws and regulations and alternative cleanup methods. As of December 25, 2015, Tyco concluded that it was probable that it would incur remedial costs in the range of approximately $22 million to $71 million. As of December 25, 2015, Tyco concluded that the best estimate within this range is approximately $32 million, of which $11 million is included in Accrued and other current liabilities and $21 million is included in Other liabilities within the Company's Consolidated Balance Sheet.

- changed (2016-04-29):
[0000833444-16-000172:note_history:2]
As previously disclosed, the majority of the liabilities described above relate to ongoing remediation efforts at a facility in the Company's Global Products segment located in Marinette, Wisconsin, which the Company acquired in 1990 in connection with its acquisition of, among other things, the Ansul product line. As of March 25, 2016, the Company concluded that its remaining remediation and monitoring costs related to the Marinette facility were in the range of approximately $13 million to $45 million. The Company's best estimate within that range is approximately $21 million, of which $9 million is included in Accrued and other current liabilities and $12 million is included in Other liabilities within the Company's Consolidated Balance Sheet.  Although the Company has recorded its best estimate of the costs that it will incur to remediate and monitor contamination at the Marinette facility, it is possible that technological, regulatory or enforcement developments, the results of environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows.
  (was, 2016-01-29, similarity 0.9947):
[0000833444-16-000120:note_history:2]
As previously disclosed, the majority of the liabilities described above relate to ongoing remediation efforts at a facility in the Company's Global Products segment located in Marinette, Wisconsin, which the Company acquired in 1990 in connection with its acquisition of, among other things, the Ansul product line. As of December 25, 2015, the Company concluded that its remaining remediation and monitoring costs related to the Marinette facility were in the range of approximately $14 million to $46 million. The Company's best estimate within that range is approximately $22 million, of which $9 million is included in Accrued and other current liabilities and $13 million is included in Other liabilities within the Company's Consolidated Balance Sheet.  Although the Company has recorded its best estimate of the costs that it will incur to remediate and monitor contamination at the Marinette facility, it is possible that technological, regulatory or enforcement developments, the results of environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows.

- changed (2016-04-29):
[0000833444-16-000172:note_history:3]
As of March 25, 2016, the Company has determined that there were approximately 3,100 claims pending against its subsidiaries, primarily Grinnell. This amount reflects the Company's current estimate of the number of viable claims made against Grinnell and includes adjustments for claims that are not actively being prosecuted, identify incorrect defendants, are duplicative of other actions or for which the Company is indemnified by third parties.
  (was, 2016-01-29, similarity 0.7916):
[0000833444-16-000120:note_history:3]
As of December 25, 2015, the Company has determined that there were approximately 3,100 claims pending against its subsidiaries, primarily Grinnell. This amount reflects the Company's current estimate of the number of viable claims made against Grinnell and includes adjustments for claims that are not actively being prosecuted, identify incorrect defendants, are duplicative of other actions or for which the Company is indemnified by third parties. Yarway Corporation is no longer a subsidiary of the Company and, as of August 2015, is no longer consolidated. Consequently, any claims pending against the Yarway Corporation are excluded from the claims pending above.

- changed (2016-04-29):
[0000833444-16-000172:note_history:4]
As of March 25, 2016, the Company's estimated asbestos related net liability recorded within the Company's Consolidated Balance Sheet is $24 million. The net liability within the Consolidated Balance Sheet is comprised of a liability for pending and future claims and related defense costs of $500 million, of which $10 million is recorded in Accrued and other current liabilities, and $490 million is recorded in Other liabilities. The Company also maintains separate cash, investment and other assets within the Consolidated Balance Sheet of $476 million, of which $37 million is recorded in Prepaid expenses and other current assets, and $439 million is recorded in Other assets. Assets include $3 million of cash and $265 million of investments, which have all been designated as restricted.  As of September 25, 2015, the Company's estimated net liability recorded within the Company's Consolidated Balance Sheet was $28 million. The net liability was comprised of a liability for pending and future claims and related defense costs of $515 million, of which $23 million was recorded in Accrued and other current liabilities, and $492 million was recorded in Other liabilities.  The Company also maintained separate cash, investment and other assets within the Consolidated Balance Sheet of $487 million, of which $38 million was recorded in Prepaid expenses and other current assets, and $449 million was recorded in Other assets. Assets included $11 million of cash and $263 million of investments, which were all designated as restricted.
  (was, 2016-01-29, similarity 0.9957):
[0000833444-16-000120:note_history:4]
As of December 25, 2015, the Company's estimated asbestos related net liability recorded within the Company's Consolidated Balance Sheet is $27 million. The net liability within the Consolidated Balance Sheet is comprised of a liability for pending and future claims and related defense costs of $508 million, of which $19 million is recorded in Accrued and other current liabilities, and $489 million is recorded in Other liabilities. The Company also maintains separate cash, investment and other assets within the Consolidated Balance Sheet of $481 million, of which $44 million is recorded in Prepaid expenses and other current assets, and $437 million is recorded in Other assets. Assets include $6 million of cash and $267 million of investments, which have all been designated as restricted.  As of September 25, 2015, the Company's estimated net liability recorded within the Company's Consolidated Balance Sheet was $28 million. The net liability was comprised of a liability for pending and future claims and related defense costs of $515 million, of which $23 million was recorded in Accrued and other current liabilities, and $492 million was recorded in Other liabilities.  The Company also maintained separate cash, investment and other assets within the Consolidated Balance Sheet of $487 million, of which $38 million was recorded in Prepaid expenses and other current assets, and $449 million was recorded in Other assets. Assets included $11 million of cash and $263 million of investments, which were all designated as restricted.

- changed (2016-04-29):
[0000833444-16-000172:note_history:5]
Assuming the tentative resolution is finalized, Tyco does not expect to recognize any additional charges related to the resolution, as it had previously recorded sufficient reserves with respect to this controversy and its obligations under the Tax Sharing Agreements. The Company made a payment of $120 million to TE Connectivity and $2 million to Covidien, which was subsequently paid to the IRS, during the second quarter of fiscal 2016 in connection with the tentative resolution. See Note 6.
  (was, 2016-01-29, similarity 0.6095):
[0000833444-16-000120:note_history:5]
Assuming the tentative resolution is finalized, Tyco does not expect to recognize any additional charges related to the resolution, as it had previously recorded sufficient reserves with respect to this controversy and its obligations under the Tax Sharing Agreements. Payment is expected to be made to the IRS, and among Tyco, Covidien and TE Connectivity, within the next six months. See Note 5.

- added (2016-04-29):
[0000833444-16-000172:note_history:6]
On March 1, 2016, a putative class action lawsuit, Wandel v. Tyco International plc, et al., Docket No. C-000010-16, was filed in the Superior Court of New Jersey naming Tyco, the individual members of its board of directors, Johnson Controls and Merger Sub as defendants. The complaint alleges that Tyco’s directors breached their fiduciary duties and exercised their powers as directors in a manner oppressive to the public shareholders of Tyco in violation of Irish law by, among other things, failing to take steps to maximize shareholder value and failing to protect against purported conflicts of interest. The complaint further alleges that Tyco, Johnson Controls and Merger Sub aided and abetted Tyco’s directors in the breach of their fiduciary duties. The complaint seeks, among other things, to enjoin the merger. The Company believes that the claims asserted by the complaint are not valid.

- removed (2016-04-29):
[0000833444-16-000120:note_history:7]
Legacy Matters Related to Former Management

- removed (2016-04-29):
[0000833444-16-000120:note_history:8]
As previously reported, in recent years, the Company has definitively resolved several lawsuits involving disputes with former management, including Dennis Kozlowski, the Company's former chief executive officer, and Mark Swartz, the Company's former chief financial officer.

- removed (2016-04-29):
[0000833444-16-000120:note_history:9]
In the first quarter of fiscal 2015, the Company reached a definitive agreement with Mark Swartz to resolve all outstanding disputes, and received approximately $12 million in cash from Mr. Swartz, $5 million of which was shared pursuant to the terms of a legacy class action lawsuit, resulting in a net recovery of $7 million for the Company, which was recorded in Selling, general and administrative expenses within the Consolidated Statement of Operations. The cash received has been classified as restricted.

- removed (2016-04-29):
[0000833444-16-000120:note_history:10]
Yarway

- removed (2016-04-29):
[0000833444-16-000120:note_history:11]
As previously disclosed, on August 19, 2015, the Chapter 11 bankruptcy plan of Yarway Corporation, a former indirect wholly-owned subsidiary of the Company became effective and the Company contributed approximately $325 million in cash to the Yarway Trust and each of the Company Protected Parties (as such term is defined in the plan) received the benefit of a release from Yarway and an injunction under section 524(g) of the Bankruptcy Code permanently enjoining the assertion of Yarway asbestos claims against those parties. As a result of the effectiveness of the Chapter 11 plan, ownership of the Yarway Corporation was transferred to the Yarway Trust and it was deconsolidated from the Company. Upon deconsolidation, the Company recorded a $4 million loss, which is included in Selling, general and administrative expenses within the Company's Consolidated Statement of Operations during the year ended September 25, 2015.

- removed (2016-04-29):
[0000833444-16-000120:note_history:12]
As previously disclosed, SimplexGrinnell LP (“SG”), a subsidiary of the Company in the North America Integrated Solutions & Services segment, has been named as a defendant in lawsuits in several jurisdictions seeking damages for SG’s alleged failure to pay prevailing wages and for other pay-related claims.  Through the first quarter of fiscal 2015, the Company had recorded a total of approximately $17 million in charges related to these lawsuits, which was recorded in the Cost of services within the Consolidated Statement of Operations.  During the quarter ended March 27, 2015, the Company agreed in principle to settle all outstanding lawsuits for a total of approximately $14 million.


## tyc:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesAndNewAccountingPronouncementsTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-04-29):
[0000833444-16-000172:note_history:13]
Basis of Presentation—The Consolidated Financial Statements included herein are unaudited, but in the opinion of management, such financial statements include all adjustments, consisting of normal recurring adjustments, necessary to summarize fairly the Company's financial position, results of operations and cash flows for the interim period. The unaudited Consolidated Financial Statements include the consolidated results of Tyco International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Tyco and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Tyco"). The unaudited Consolidated Financial Statements have been prepared in United States dollars ("USD") and in accordance with the instructions to Form 10-Q under the Securities and Exchange Act of 1934, as amended. The results reported in these unaudited Consolidated Financial Statements should not be taken as indicative of results that may be expected for the entire year.  These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K for the fiscal year ended September 25, 2015 (the "2015 Form 10-K") and Current Report filed on Form 8-K filed on March 11, 2016 which recast the Company's consolidated financial statements for each of the three years in the period ended September 25, 2015 to reflect changes in the presentation of operating income by segment. The information included in this Form 8-K was presented for informational purposes only and does not amend or restate the Company’s audited consolidated financial statements, which were included in its 2015 Form 10-K, and did not affect the Company’s previously reported net income, earnings per share, cash flows, operating income or assets or liabilities for any of the periods presented therein.
  (was, 2016-01-29, similarity 0.792):
[0000833444-16-000120:note_history:13]
Basis of Presentation—The Consolidated Financial Statements included herein are unaudited, but in the opinion of management, such financial statements include all adjustments, consisting of normal recurring adjustments, necessary to summarize fairly the Company's financial position, results of operations and cash flows for the interim period. The unaudited Consolidated Financial Statements include the consolidated results of Tyco International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Tyco and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Tyco"). The unaudited Consolidated Financial Statements have been prepared in United States dollars ("USD") and in accordance with the instructions to Form 10-Q under the Securities and Exchange Act of 1934, as amended. The results reported in these unaudited Consolidated Financial Statements should not be taken as indicative of results that may be expected for the entire year.  These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K for the fiscal year ended September 25, 2015 (the "2015 Form 10-K").

- changed (2016-04-29):
[0000833444-16-000172:note_history:14]
References to 2016 and 2015 are to Tyco's fiscal quarters ending March 25, 2016 and March 27, 2015, respectively, unless otherwise indicated.  The Company has a 52- or 53-week fiscal year that ends on the last Friday in September.  Fiscal 2016 is a 53-week year as compared with fiscal 2015, which was 52 weeks, with the additional week occurring in the fourth quarter of fiscal 2016.  The Company's results for the quarters and six months ended March 25, 2016 and March 27, 2015 both consisted of 13 weeks and 26 weeks, respectively.
  (was, 2016-01-29, similarity 0.8282):
[0000833444-16-000120:note_history:14]
References to 2016 and 2015 are to Tyco's fiscal quarters ending December 25, 2015 and December 26, 2014, respectively, unless otherwise indicated.  The Company has a 52- or 53-week fiscal year that ends on the last Friday in September.  Fiscal 2016 is a 53-week year as compared with fiscal 2015, which was 52 weeks, with the additional week occurring in the fourth quarter of fiscal 2016.  The Company's results for the three months ended December 25, 2015 and December 26, 2014 both consisted of 13 weeks.

- added (2016-04-29):
[0000833444-16-000172:note_history:15]
Proposed Merger with Johnson Controls, Inc.— On January 24, 2016, Tyco entered into an Agreement and Plan of Merger (the “Merger Agreement”) with Johnson Controls, Inc., a Wisconsin corporation (“Johnson Controls”), and certain other parties named therein, including Jagara Merger Sub LLC, a Wisconsin limited liability company and indirect wholly owned subsidiary of Tyco (“Merger Sub”). Pursuant to the Merger Agreement and subject to the terms and conditions set forth therein, Merger Sub will merge with and into Johnson Controls (the “Merger”), with Johnson Controls surviving the Merger as an indirect wholly owned subsidiary of Tyco. At the effective time of the Merger, Tyco will change its name to “Johnson Controls plc” and will trade under the ticker symbol “JCI.” Following such time, Tyco is referred to below as the “Combined Company.”

- added (2016-04-29):
[0000833444-16-000172:note_history:16]
As a result of the Merger, each outstanding share of Johnson Controls common stock (the “Johnson Controls Shares”), other than shares held by Johnson Controls, its subsidiaries, Tyco or Merger Sub, will be converted into the right to receive (subject to proration as described below), at the holder’s election, either: (i) one (1) (the “Exchange Ratio”) ordinary share of the Combined Company (the “Share Consideration”); or (ii) an amount in cash equal to $34.88 (the “Cash Consideration”). Elections will be prorated so that Johnson Controls shareholders will receive in the aggregate approximately $3.864 billion of cash in the Merger (the “Aggregate Cash Consideration”). Holders that do not make an election will be treated as having elected to receive the Share Consideration. The Exchange Ratio takes into account the effects of a Tyco share consolidation contemplated by the Merger Agreement whereby, immediately prior to the Merger, every issued and unissued ordinary share of Tyco (each, a “Tyco Share”) will be consolidated into 0.955 of a share of Tyco.

- added (2016-04-29):
[0000833444-16-000172:note_history:17]
The completion of the Merger is subject to certain closing conditions, including, among others, (i) the approval and adoption of the Merger Agreement by holders of two-thirds of the Johnson Controls Shares entitled to vote on such matter, (ii) the approval by the Tyco shareholders, at a special meeting of the Tyco shareholders (the “Tyco Special Meeting”) of (A) the issuance of Tyco shares in connection with the Merger, (B) the Tyco share consolidation and (C) the increase in Tyco’s authorized share capital, in each case, by a majority of the votes cast on these matters at the Tyco Special Meeting, and of certain amendments to Tyco’s articles of association, including a change of its name to “Johnson Controls plc,” by at least 75% of the votes cast on these matters at the Tyco Special Meeting (clause (ii), collectively, the “Tyco Shareholder Approvals”), (iii) the expiration or termination of any waiting period applicable to the Merger under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, the consent of, or filing with, certain specified antitrust authorities, and certain other customary regulatory approvals, and (iv) Tyco’s obtaining the financing required to close the Merger on the terms set forth in the Merger Agreement.

- added (2016-04-29):
[0000833444-16-000172:note_history:18]
The Merger Agreement contains specified termination rights, including, among others, the right of either party to terminate the Merger Agreement (i) if the requisite shareholder approvals have not been obtained, (ii) if the board of directors of the other party effects a change of recommendation, (iii) if the closing has not occurred by October 24, 2016, subject to extension to January 24, 2017 in certain circumstances, (iv) in response to certain intervening events (subject to the limitations set forth in the Merger Agreement) or (v) if there is a material breach by the other party of any of its representations, warranties or covenants, subject to certain conditions.

- added (2016-04-29):
[0000833444-16-000172:note_history:19]
Tyco has entered into a senior unsecured term loan facility in the amount of $4 billion to finance the cash consideration for, and fees, expenses and costs incurred in connection with, the merger. In addition, the Company has entered into a revolving credit agreement in the amount of $1 billion, which is intended to replace Tyco's existing $1.5 billion revolving credit agreement. Tyco's ability to draw down on both the term loan facility and the new revolving credit agreement are contingent on the consummation of the merger with Johnson Controls. See Note 9.

- changed (2016-04-29):
[0000833444-16-000172:note_history:20]
Change of Jurisdiction— On May 30, 2014, Tyco entered into a Merger Agreement with Tyco International plc, a newly-formed Irish public limited company and a wholly-owned subsidiary of Tyco ("Tyco Ireland").  Under the Merger Agreement with Tyco Ireland, Tyco merged with and into Tyco Ireland, with Tyco Ireland being the surviving company. This resulted in Tyco Ireland becoming Tyco's publicly-traded parent company and changed the jurisdiction of organization of Tyco from Switzerland to Ireland. Tyco's shareholders received one ordinary share of Tyco Ireland for each ordinary share of Tyco held immediately prior to the re-domicile to Ireland. The re-domicile to Ireland became effective on November 17, 2014.
  (was, 2016-01-29, similarity 0.9723):
[0000833444-16-000120:note_history:20]
Change of Jurisdiction— On May 30, 2014, Tyco entered into a Merger Agreement ("Merger Agreement") with Tyco International plc, a newly-formed Irish public limited company and a wholly-owned subsidiary of Tyco ("Tyco Ireland").  Under the Merger Agreement, Tyco merged with and into Tyco Ireland, with Tyco Ireland being the surviving company. This resulted in Tyco Ireland becoming Tyco's publicly-traded parent company and changed the jurisdiction of organization of Tyco from Switzerland to Ireland. Tyco's shareholders received one ordinary share of Tyco Ireland for each ordinary share of Tyco held immediately prior to the re-domicile to Ireland. The re-domicile to Ireland became effective on November 17, 2014.

- changed (2016-04-29):
[0000833444-16-000172:note_history:21]
Effective for the first quarter of fiscal 2016, the Company has elected to present operating income by segment, as well as Corporate and Other, excluding restructuring and repositioning charges, net.  Restructuring and repositioning charges, net, are shown in aggregate. This presentation is consistent with how management reviews the businesses, makes investing and resource decisions and assesses operating performance. See Note 15.
  (was, 2016-01-29, similarity 0.9389):
[0000833444-16-000120:note_history:21]
Effective for the first quarter of fiscal 2016, the Company has elected to present operating income by segment, as well as Corporate and Other, excluding restructuring and repositioning charges, net.  Restructuring and repositioning charges, net, are shown in aggregate. This measure of segment operating income (loss) is consistent with how management reviews the businesses, makes investing and resource decisions and assesses operating performance. See Note 14.

- added (2016-04-29):
[0000833444-16-000172:note_history:22]
During the second quarter of fiscal 2016, the Company completed the sale of its Australian fire protection business, included in the ROW Integrated Solutions & Services segment. The assets and liabilities related to this business were classified as held for sale as of September 25, 2015.  Its results of operations are included in continuing operations, as the criteria to be presented as a discontinued operation were not satisfied. See Note 3.

- changed (2016-04-29):
[0000833444-16-000172:note_history:23]
Recently Adopted Accounting Pronouncements— In April 2014, the Financial Accounting Standards Board ("FASB") issued authoritative guidance to change the criteria for reporting discontinued operations. Under the new guidance, only disposals representing a strategic shift that has or will have a major effect on the Company's operations and financial results should be reported as discontinued operations, with expanded disclosures. The guidance became effective for Tyco in the first quarter of fiscal 2016. The Company considers both qualitative and quantitative factors when assessing whether a disposed business represents a strategic shift that will have a major effect on the Company's operations and financial results. The Company considers the level (e.g. individual business or product line, reporting unit or reportable segment) and geographic impact (e.g. country, region, worldwide) of the disposal group. In addition, the Company considers the significance of the disposed business on certain financial measures when assessing whether or not such disposal has a major effect on the Company's operations and financial results. The adoption of this guidance did not have a material impact on the Company's financial position, results of operations or cash flows. During fiscal 2016, the divestiture of the Company's Australian fire protection business did not meet the criteria set forth in the new guidance and therefore was not classified as a discontinued operation. See Note 3.
  (was, 2016-01-29, similarity 0.9893):
[0000833444-16-000120:note_history:23]
Recently Adopted Accounting Pronouncements - In April 2014, the Financial Accounting Standards Board ("FASB") issued authoritative guidance to change the criteria for reporting discontinued operations. Under the new guidance, only disposals representing a strategic shift that has or will have a major effect on the Company's operations and financial results should be reported as discontinued operations, with expanded disclosures. The guidance became effective for Tyco in the first quarter of fiscal 2016. The Company considers both qualitative and quantitative factors when assessing whether a disposed business represents a strategic shift that will have a major effect on the Company's operations and financial results. The Company considers the level (e.g. individual business or product line, reporting unit or reportable segment) and geographic impact (e.g. country, region, worldwide) of the disposal group. In addition, the Company considers the significance of the disposed business on certain financial measures when assessing whether or not such disposal has a major effect on the Company's operations and financial results. The adoption of this guidance did not have a material impact on the Company's financial position, results of operations or cash flows. During the first quarter of fiscal 2016, the planned divestiture of the Company's Australian fire protection business did not meet the criteria set forth in the new guidance and therefore was not classified as a discontinued operation.  See Note 2.

- changed (2016-04-29):
[0000833444-16-000172:note_history:24]
Recently Issued Accounting Pronouncements— In May 2014, the FASB issued authoritative guidance for revenue from contracts with customers, which provides a single comprehensive revenue recognition model to apply in determining how and when to recognize revenue. The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. When applying the new revenue model to contracts with customers the guidance requires five steps to be applied, which include: 1) identify the contract(s) with a customer, 2) identify the performance obligations in the contract, 3) determine the transaction price, 4) allocate the transaction price to the performance obligations in the contract and 5) recognize revenue when (or as) the entity satisfies a performance obligation. The guidance also requires quantitative and qualitative disclosures that are more comprehensive than existing standards. The disclosures are intended to enable financial statement users to understand the nature, timing and uncertainty of revenue and the related cash flow. The new standard permits either the full retrospective method or the modified retrospective method of adoption. In August 2015, the FASB issued authoritative guidance to defer the effective date of this guidance, which for Tyco will be the first quarter of fiscal 2019, with early adoption permitted beginning the first quarter of fiscal 2018. In March 2016, the FASB issued additional authoritative guidance clarifying its implementation guidance on principal versus agent considerations when determining whether to report revenue gross versus net. The Company is in the process of assessing the impact the guidance is expected to have upon adoption, including determining the adoption method.
  (was, 2016-01-29, similarity 0.8283):
[0000833444-16-000120:note_history:24]
Recently Issued Accounting Pronouncements - In May 2014, the FASB issued authoritative guidance for revenue from contracts with customers, which provides a single comprehensive revenue recognition model to apply in determining how and when to recognize revenue. The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. When applying the new revenue model to contracts with customers the guidance requires five steps to be applied, which include: 1) identify the contract(s) with a customer, 2) identify the performance obligations in the contract, 3) determine the transaction price, 4) allocate the transaction price to the performance obligations in the contract and 5) recognize revenue when (or as) the entity satisfies a performance obligation. The guidance also requires quantitative and qualitative disclosures that are more comprehensive than existing standards. The disclosures are intended to enable financial statement users to understand the nature, timing and uncertainty of revenue and the related cash flow. The new standard allows for both retrospective and prospective methods of adoption. In August 2015, the FASB issued authoritative guidance to defer the effective date of this guidance, which for Tyco will be the first quarter of fiscal 2019, with early adoption permitted beginning the first quarter of fiscal 2018.  The Company is in the process of determining the adoption method and assessing the impact the guidance is expected to have upon adoption.

- changed (2016-04-29):
[0000833444-16-000172:note_history:25]
In November 2015, the FASB issued authoritative guidance intended to simplify the presentation of deferred income taxes.  Under the new guidance, deferred tax liabilities and deferred tax assets are to be classified as noncurrent in a classified statement of financial position.  The current requirement that deferred tax liabilities and assets of a tax-paying component of an entity be offset and presented as a single amount is not affected by the amendments in this update. This guidance is effective for Tyco in the first quarter of fiscal 2018, with early adoption permitted on a prospective or retrospective basis. The Company plans to adopt this guidance as of September 30, 2016 and does not expect the guidance to have a material impact on its financial statements.
  (was, 2016-01-29, similarity 0.8367):
[0000833444-16-000120:note_history:25]
In November 2015, the FASB issued authoritative guidance intended to simplify the presentation of deferred income taxes.  Under the new guidance, deferred tax liabilities and deferred tax assets are to be classified as noncurrent in a classified statement of financial position.  The current requirement that deferred tax liabilities and assets of a tax-paying component of an entity be offset and presented as a single amount is not affected by the amendments in this update. This guidance is effective for Tyco in the first quarter of fiscal 2018, with early adoption permitted on a prospective or retrospective basis.  The Company is currently assessing the impact, if any, the guidance may have upon adoption and the timing of adopting this new guidance.

- added (2016-04-29):
[0000833444-16-000172:note_history:26]
In February 2016, the FASB issued authoritative guidance requiring the recognition of lease assets and lease liabilities by lessees for those leases previously classified as operating leases. The guidance requires quantitative and qualitative disclosures that are more comprehensive than existing standards. The disclosures are intended to enable financial statement users to understand the amount, timing and uncertainty of cash flows arising from leases. This guidance is effective for Tyco in the first quarter of fiscal 2020 with early adoption permitted. The amendments are required to be applied by means of a modified retrospective approach. The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- added (2016-04-29):
[0000833444-16-000172:note_history:27]
In March 2016, the FASB amended its authoritative guidance for employee share-based payment transactions by simplifying several aspects of the accounting for employee share-based payment awards, including the accounting for income taxes, withholding taxes and forfeitures, as well as classification on the statement of cash flows. The amended guidance is effective for Tyco in the first quarter of fiscal 2018 with early adoption permitted.  The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- removed (2016-04-29):
[0000833444-16-000120:note_history:28]
During the first quarter of fiscal 2016, the Company approved a plan to divest its Australian fire protection business, included in the ROW Integrated Solutions & Services segment. The assets and liabilities related to this business were classified as held for sale for all periods presented.  Its results of operations are included in continuing operations, as the criteria to be presented as a discontinued operation were not satisfied. The sale of the business was completed in the second quarter of fiscal 2016.

- removed (2016-04-29):
[0000833444-16-000120:note_history:29]
During the second quarter of fiscal 2015, the Company approved a plan to sell a business in its ROW Integrated Solutions & Services segment which the Company expects to complete during the second quarter of fiscal 2016. The assets and liabilities of this business are classified as held for sale, and its results of operations are presented as discontinued operations for all periods presented. See Note 2.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-04-29):
[0000833444-16-000172:note_history:30]
Basis of Presentation—The Consolidated Financial Statements included herein are unaudited, but in the opinion of management, such financial statements include all adjustments, consisting of normal recurring adjustments, necessary to summarize fairly the Company's financial position, results of operations and cash flows for the interim period. The unaudited Consolidated Financial Statements include the consolidated results of Tyco International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Tyco and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Tyco"). The unaudited Consolidated Financial Statements have been prepared in United States dollars ("USD") and in accordance with the instructions to Form 10-Q under the Securities and Exchange Act of 1934, as amended. The results reported in these unaudited Consolidated Financial Statements should not be taken as indicative of results that may be expected for the entire year.  These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K for the fiscal year ended September 25, 2015 (the "2015 Form 10-K") and Current Report filed on Form 8-K filed on March 11, 2016 which recast the Company's consolidated financial statements for each of the three years in the period ended September 25, 2015 to reflect changes in the presentation of operating income by segment. The information included in this Form 8-K was presented for informational purposes only and does not amend or restate the Company’s audited consolidated financial statements, which were included in its 2015 Form 10-K, and did not affect the Company’s previously reported net income, earnings per share, cash flows, operating income or assets or liabilities for any of the periods presented therein.
  (was, 2016-01-29, similarity 0.792):
[0000833444-16-000120:note_history:30]
Basis of Presentation—The Consolidated Financial Statements included herein are unaudited, but in the opinion of management, such financial statements include all adjustments, consisting of normal recurring adjustments, necessary to summarize fairly the Company's financial position, results of operations and cash flows for the interim period. The unaudited Consolidated Financial Statements include the consolidated results of Tyco International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Tyco and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Tyco"). The unaudited Consolidated Financial Statements have been prepared in United States dollars ("USD") and in accordance with the instructions to Form 10-Q under the Securities and Exchange Act of 1934, as amended. The results reported in these unaudited Consolidated Financial Statements should not be taken as indicative of results that may be expected for the entire year.  These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K for the fiscal year ended September 25, 2015 (the "2015 Form 10-K").


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-04-29):
[0000833444-16-000172:note_history:31]
The carrying value of the Company's debt as of March 25, 2016 and September 25, 2015 is as follows ($ in millions):
  (was, 2016-01-29, similarity 0.9577):
[0000833444-16-000120:note_history:31]
The carrying value of the Company's debt as of December 25, 2015 and September 25, 2015 is as follows ($ in millions):

- added (2016-04-29):
[0000833444-16-000172:note_history:32]
|  | As of |
|  | March 25, 2016 |  | September 25, 2015 |
| Commercial paper(1) | $ | 400 |  |  | $ | — |  |
| 3.375% public notes due 2015(2) | — |  |  | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 7.0% public notes due 2019(2) | — |  |  | 245 |  |
| 6.875% public notes due 2021(2) | — |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% Euro-denominated public notes due 2025 | 558 |  |  | 558 |  |
| 3.9% public notes due 2026 | 745 |  |  | 745 |  |
| 5.125% public notes due 2045 | 746 |  |  | 746 |  |
| Other (2) | 1 |  |  | 20 |  |
| Total debt | 2,559 |  |  | 3,146 |  |
| Less current portion | 400 |  |  | 987 |  |
| Long-term debt | $ | 2,159 |  |  | $ | 2,159 |  |

- changed (2016-04-29):
[0000833444-16-000172:note_history:33]
(1)  The current portion of debt as of March 25, 2016 is comprised of $400 million of commercial paper.
  (was, 2016-01-29, similarity 0.8288):
[0000833444-16-000120:note_history:33]
(1)  The current portion of debt as of December 25, 2015 is comprised of $151 million of commercial paper and $1 million of Other debt.

- changed (2016-04-29):
[0000833444-16-000172:note_history:34]
The carrying amount of Tyco's debt subject to the fair value disclosure requirements as of March 25, 2016 and September 25, 2015 was $2,558 million and $3,126 million, respectively. The Company utilizes various valuation methodologies to determine the fair value of its debt, which is primarily dependent on the type of market in which the Company's debt is traded. When available, the Company uses quoted market prices to determine the fair value of its debt that is traded in active markets.  As of March 25, 2016 and September 25, 2015, the fair value of the Company's debt which was actively traded was $2,615 million and $3,291 million, respectively.  As of March 25, 2016 and September 25, 2015, the Company's debt that was subject to the fair value disclosure requirements was all actively traded and is classified as Level 1 in the fair value hierarchy. Additionally, the Company believes the carrying amount of its commercial paper of $400 million as of March 25, 2016 approximates fair value based on the short-term nature of such debt.
  (was, 2016-01-29, similarity 0.9739):
[0000833444-16-000120:note_history:34]
The carrying amount of Tyco's debt subject to the fair value disclosure requirements as of December 25, 2015 and September 25, 2015 was $2,296 million and $3,126 million, respectively. The Company utilizes various valuation methodologies to determine the fair value of its debt, which is primarily dependent on the type of market in which the Company's debt is traded. When available, the Company uses quoted market prices to determine the fair value of its debt that is traded in active markets.  As of December 25, 2015 and September 25, 2015, the fair value of the Company's debt which was actively traded was $2,318 million and $3,291 million, respectively.  As of December 25, 2015 and September 25, 2015, the Company's debt that was subject to the fair value disclosure requirements was all actively traded and is classified as Level 1 in the fair value hierarchy. Additionally, the Company believes the carrying amount of its commercial paper of $151 million as of December 25, 2015 approximates fair value based on the short-term nature of such debt.

- added (2016-04-29):
[0000833444-16-000172:note_history:35]
Financing in Connection with Proposed Merger with Johnson Controls

- added (2016-04-29):
[0000833444-16-000172:note_history:36]
On March 10, 2016, Tyco International Holding S.à r.l. ("TSARL"), an indirect wholly owned subsidiary of Tyco, entered into a Term Loan Credit Agreement with a syndicate of lenders providing for a senior unsecured term loan facility in the amount of $4 billion to finance the cash consideration for, and fees, expenses and costs incurred in connection with the merger with Johnson Controls, pursuant to the Merger Agreement dated as of January 24, 2016.  Any loans borrowed under the Term Loan Credit Agreement will be made in a single borrowing on the closing date of the facility and will have a maturity of 3.5 years and be denominated in U.S. dollars. The closing of the term loan facility is subject to customary closing conditions and the consummation of the Merger. See Note 1.

- added (2016-04-29):
[0000833444-16-000172:note_history:37]
In addition, on March 10, 2016, TSARL entered into a Multi-Year Senior Unsecured Credit Agreement providing for revolving credit commitments in the aggregate amount of $1 billion (the “Revolving Credit Agreement”). The closing of the revolving credit facility, and TSARL's ability to borrow under the Revolving Credit Agreement remains subject to the satisfaction or waiver of customary conditions, including the consummation of the Merger and the termination of the commitments of the lenders, and payments of all amounts outstanding, under the $1.5 billion Amended and Restated Five-Year Senior Unsecured Credit Agreement dated as of August 7, 2015. The Revolving Credit Agreement has a scheduled maturity date of August 7, 2020 and includes an option for TSARL to request an increase in the aggregate principal amount of the commitments, up to an additional $250 million.

- changed (2016-04-29):
[0000833444-16-000172:note_history:38]
On August 7, 2015, TIFSA entered into an Amended and Restated Five-Year Senior Unsecured Credit Agreement in the aggregate amount of $1.5 billion (the “2015 Credit Agreement”). The 2015 Credit Agreement amends and restates TIFSA's existing Five-Year Senior Unsecured Credit Agreement, dated June 22, 2012 (the “2012 Credit Agreement”), which provided for revolving credit commitments in the aggregate amount of $1 billion, and was scheduled to expire on June 22, 2017.  The 2015 Credit Agreement will be terminated upon completion of the Merger and replaced with the $1 billion credit facility as discussed above.
  (was, 2016-01-29, similarity 0.8622):
[0000833444-16-000120:note_history:38]
On August 7, 2015, TIFSA entered into an Amended and Restated Five-Year Senior Unsecured Credit Agreement in the aggregate amount of $1.5 billion (the “2015 Credit Agreement”). The 2015 Credit Agreement amends and restates TIFSA's existing Five-Year Senior Unsecured Credit Agreement, dated June 22, 2012 (the “2012 Credit Agreement”), which provided for revolving credit commitments in the aggregate amount of $1.0 billion, and was scheduled to expire on June 22, 2017.

- changed (2016-04-29):
[0000833444-16-000172:note_history:39]
As a result of entering into the 2015 Credit Agreement, the Company's committed revolving credit facility totaled $1.5 billion as of March 25, 2016. This revolving credit facility may be used for working capital, capital expenditures and general corporate purposes. As of March 25, 2016 and September 25, 2015, there were no amounts drawn under the Company's revolving credit facility. Interest under the revolving credit facility is variable and is calculated by reference to LIBOR or an alternate base rate.
  (was, 2016-01-29, similarity 0.9735):
[0000833444-16-000120:note_history:39]
As a result of entering into the 2015 Credit Agreement, the Company's committed revolving credit facility totaled $1.5 billion as of December 25, 2015. This revolving credit facility may be used for working capital, capital expenditures and general corporate purposes. As of December 25, 2015 and September 25, 2015, there were no amounts drawn under the Company's revolving credit facility. Interest under the revolving credit facility is variable and is calculated by reference to LIBOR or an alternate base rate.

- changed (2016-04-29):
[0000833444-16-000172:note_history:40]
From time to time, TIFSA may issue commercial paper for general corporate purposes. The maximum aggregate amount of unsecured commercial paper notes available to be issued, on a private placement basis, under the commercial paper program is $1.5 billion as of March 25, 2016.  As of March 25, 2016 and September 25, 2015, TIFSA had $400 million and nil of commercial paper outstanding, respectively.
  (was, 2016-01-29, similarity 0.9368):
[0000833444-16-000120:note_history:40]
From time to time, TIFSA may issue commercial paper for general corporate purposes. The maximum aggregate amount of unsecured commercial paper notes available to be issued, on a private placement basis, under the commercial paper program is $1.5 billion as of December 25, 2015.  As of December 25, 2015 and September 25, 2015, TIFSA had $151 million and nil of commercial paper outstanding, respectively.

- removed (2016-04-29):
[0000833444-16-000120:note_history:41]
|  | As of |
|  | December 25, 2015 |  | September 25, 2015 |
| Commercial paper | $ | 151 |  |  | $ | — |  |
| 3.375% public notes due 2015 | — |  |  | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 7.0% public notes due 2019 | — |  |  | 245 |  |
| 6.875% public notes due 2021 | — |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% Euro-denominated public notes due 2025 | 545 |  |  | 558 |  |
| 3.9% public notes due 2026 | 745 |  |  | 745 |  |
| 5.125% public notes due 2045 | 746 |  |  | 746 |  |
| Other | 2 |  |  | 20 |  |
| Total debt | 2,298 |  |  | 3,146 |  |
| Less current portion (1)(2) | 152 |  |  | 987 |  |
| Long-term debt | $ | 2,146 |  |  | $ | 2,159 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-04-29):
[0000833444-16-000172:note_history:42]
The carrying value of the Company's debt as of March 25, 2016 and September 25, 2015 is as follows ($ in millions):
  (was, 2016-01-29, similarity 0.9577):
[0000833444-16-000120:note_history:42]
The carrying value of the Company's debt as of December 25, 2015 and September 25, 2015 is as follows ($ in millions):

- added (2016-04-29):
[0000833444-16-000172:note_history:43]
|  | As of |
|  | March 25, 2016 |  | September 25, 2015 |
| Commercial paper(1) | $ | 400 |  |  | $ | — |  |
| 3.375% public notes due 2015(2) | — |  |  | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 7.0% public notes due 2019(2) | — |  |  | 245 |  |
| 6.875% public notes due 2021(2) | — |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% Euro-denominated public notes due 2025 | 558 |  |  | 558 |  |
| 3.9% public notes due 2026 | 745 |  |  | 745 |  |
| 5.125% public notes due 2045 | 746 |  |  | 746 |  |
| Other (2) | 1 |  |  | 20 |  |
| Total debt | 2,559 |  |  | 3,146 |  |
| Less current portion | 400 |  |  | 987 |  |
| Long-term debt | $ | 2,159 |  |  | $ | 2,159 |  |

- changed (2016-04-29):
[0000833444-16-000172:note_history:44]
(1)  The current portion of debt as of March 25, 2016 is comprised of $400 million of commercial paper.
  (was, 2016-01-29, similarity 0.8288):
[0000833444-16-000120:note_history:44]
(1)  The current portion of debt as of December 25, 2015 is comprised of $151 million of commercial paper and $1 million of Other debt.

- removed (2016-04-29):
[0000833444-16-000120:note_history:45]
|  | As of |
|  | December 25, 2015 |  | September 25, 2015 |
| Commercial paper | $ | 151 |  |  | $ | — |  |
| 3.375% public notes due 2015 | — |  |  | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 7.0% public notes due 2019 | — |  |  | 245 |  |
| 6.875% public notes due 2021 | — |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% Euro-denominated public notes due 2025 | 545 |  |  | 558 |  |
| 3.9% public notes due 2026 | 745 |  |  | 745 |  |
| 5.125% public notes due 2045 | 746 |  |  | 746 |  |
| Other | 2 |  |  | 20 |  |
| Total debt | 2,298 |  |  | 3,146 |  |
| Less current portion (1)(2) | 152 |  |  | 987 |  |
| Long-term debt | $ | 2,146 |  |  | $ | 2,159 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2016-04-29):
[0000833444-16-000120:note_history:46]
On January 24, 2016, Tyco entered into an Agreement and Plan of Merger (the “Merger Agreement”) with Johnson Controls, Inc., a Wisconsin corporation (“JCI”), and certain other parties named therein, including Jagara Merger Sub LLC, a Wisconsin limited liability company and indirect wholly owned subsidiary of Tyco (“Merger Sub”). Pursuant to the Merger Agreement and subject to the terms and conditions set forth therein, Merger Sub will merge with and into JCI (the “Merger”), with JCI surviving the Merger as an indirect wholly owned subsidiary of Tyco. At the effective time of the Merger, Tyco will change its name to “Johnson Controls plc” and will trade under the ticker symbol “JCI.” Following such time, Tyco is referred to below as the “Combined Company.”

- removed (2016-04-29):
[0000833444-16-000120:note_history:47]
As a result of the Merger, each outstanding share of JCI common stock (the “JCI Shares”), other than shares held by JCI, its subsidiaries, Tyco or Merger Sub, will be converted into the right to receive (subject to proration as described below), at the holder’s election, either: (i) one (1) (the “Exchange Ratio”) ordinary share of the Combined Company (the “Share Consideration”); or (ii) an amount in cash equal to $34.88 (the “Cash Consideration”). Elections will be prorated so that JCI shareholders will receive in the aggregate approximately $3.864 billion of cash in the Merger (the “Aggregate Cash Consideration”). Holders that do not make an election will be treated as having elected to receive the Share Consideration. The Exchange Ratio takes into account the effects of a Tyco share consolidation contemplated by the Merger Agreement whereby, immediately prior to the Merger, every issued and unissued ordinary share of Tyco (each, a “Tyco Share”) will be consolidated into 0.955 of a share of Tyco.

- removed (2016-04-29):
[0000833444-16-000120:note_history:48]
The completion of the Merger is subject to certain closing conditions, including, among others, (i) the approval and adoption of the Merger Agreement by holders of two-thirds of the JCI Shares entitled to vote on such matter, (ii) the approval by the Tyco shareholders, at a special meeting of the Tyco shareholders (the “Tyco Special Meeting”) of (A) the issuance of Tyco shares in connection with the Merger, (B) the Tyco share consolidation and (C) the increase in Tyco’s authorized share capital, in each case, by a majority of the votes cast on these matters at the Tyco Special Meeting, and of certain amendments to Tyco’s articles of association, including a change of its name to “Johnson Controls plc,” by at least 75% of the votes cast on these matters at the Tyco Special Meeting (clause (ii), collectively, the “Tyco Shareholder Approvals”), (iii) the expiration or termination of any waiting period applicable to the Merger under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, the consent of, or filing with, certain specified antitrust authorities, and certain other customary regulatory approvals, and (iv) Tyco’s obtaining the financing required to close the Merger on the terms set forth in the Merger Agreement.

- removed (2016-04-29):
[0000833444-16-000120:note_history:49]
The Merger Agreement contains specified termination rights, including, among others, the right of either party to terminate the Merger Agreement (i) if the requisite shareholder approvals have not been obtained, (ii) if the board of directors of the other party effects a change of recommendation, (iii) if the closing has not occurred by October 24, 2016, subject to extension to January 24, 2017 in certain circumstances, (iv) in response to certain intervening events (subject to the limitations set forth in the Merger Agreement) or (v) if there is a material breach by the other party of any of its representations, warranties or covenants, subject to certain conditions.

- removed (2016-04-29):
[0000833444-16-000120:note_history:50]
Tyco expects to finance the cash consideration for the Merger and fees and expenses related to the transactions with up to $4 billion of debt financing. Citigroup Global Markets, Inc. (“CGMI”) is providing committed bridge financing in connection with the Merger.

- removed (2016-04-29):
[0000833444-16-000120:note_history:51]
In connection with the contemplated debt financing, TIFSA entered into a commitment letter (the “Term Loan Commitment Letter”) with CGMI, dated as of January 24, 2016, pursuant to which CGMI has, subject to the terms and conditions set forth in the Term Loan Commitment Letter, (i) agreed to use commercially reasonable efforts to arrange a syndicate of lenders that will participate in a three-and-a-half year senior unsecured term loan facility (the “Term Facility,” and the provision of such funds as set forth in the Term Loan Commitment Letter, the “Term Financing”) in an aggregate principal amount of up to $4 billion and (ii) committed to provide up to $400 million of the Term Facility. The Term Facility is available to finance all or a portion of the cash consideration for the Merger and to pay fees and expenses related to the transactions. The borrower under the Term Facility will be Tyco International Holding S.a.r.l. (the “Borrower”), a Luxembourg company and a direct wholly-owned subsidiary of TIFSA.

- removed (2016-04-29):
[0000833444-16-000120:note_history:52]
In connection with the contemplated debt financing, TIFSA also entered into a commitment letter (the “Bridge Commitment Letter”) with CGMI, dated as of January 24, 2016, pursuant to which CGMI has committed to provide to the Borrower, subject to the terms and conditions set forth in the Bridge Commitment Letter, the full amount of a 364-day $4 billion senior unsecured bridge loan facility (the “Bridge Facility,” and the provision of such funds as set forth in the Bridge Commitment Letter, the “Bridge Financing”). The Bridge Facility is available to finance all or a portion of the cash consideration for the Merger and to pay fees and expenses related to the transactions to the extent that the Term Facility is not available to finance such amounts.

- removed (2016-04-29):
[0000833444-16-000120:note_history:53]
The commitments with respect to both the Term Financing and the Bridge Financing are subject to certain customary closing conditions, including, in the case of the Term Financing, the receipt of commitments from other lenders for the remainder of the Term Facility not committed by CGMI, and in the case of both the Term Financing and the Bridge Financing, the consummation of the Merger in accordance with the terms of the Merger Agreement. Both the Term Facility and the Bridge Facility will contain certain representations and warranties, certain affirmative covenants, certain negative covenants, a financial covenant, and events of default, in each case applicable to the Borrower and, where appropriate, its subsidiaries, that are customarily required for similar financings. In addition, the Bridge Financing will be subject to certain customary mandatory commitment reduction and prepayment events triggered by receipt of proceeds of debt and equity issuances and material asset sales, subject to customary exceptions, and the commitments for the Bridge Financing will be automatically reduced by the amount of commitments for the Term Facility, once the Borrower enters into definitive agreements for such term financing.
