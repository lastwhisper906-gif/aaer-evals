# JCI MD&A — 0000833444-16-000172


## mdna

[0000833444-16-000172:mdna:1]
[same as prior period, unchanged from 0000833444-16-000120:mdna:1]

[0000833444-16-000172:mdna:2]
[same as prior period, unchanged from 0000833444-16-000120:mdna:2]

[0000833444-16-000172:mdna:3]
[same as prior period, unchanged from 0000833444-16-000120:mdna:3]

[0000833444-16-000172:mdna:4]
[same as prior period, unchanged from 0000833444-16-000120:mdna:4]

[0000833444-16-000172:mdna:5]
References to 2016 and 2015 are to Tyco's fiscal quarters ending March 25, 2016 and March 27, 2015, respectively, unless otherwise indicated.  The Company has a 52- or 53-week fiscal year that ends on the last Friday in September. Fiscal 2016 is a 53-week year as compared with fiscal 2016, which was 52 weeks, with the additional week occurring in the fourth quarter of fiscal 2016. The Company's results for the quarters and six months ended March 25, 2016 and March 27, 2015 both consisted of 13 weeks and 26 weeks, respectively.

[0000833444-16-000172:mdna:6]
[same as prior period, unchanged from 0000833444-16-000120:mdna:9]

[0000833444-16-000172:mdna:7]
[same as prior period, unchanged from 0000833444-16-000120:mdna:10]

[0000833444-16-000172:mdna:8]
[same as prior period, unchanged from 0000833444-16-000120:mdna:11]

[0000833444-16-000172:mdna:9]
[same as prior period, unchanged from 0000833444-16-000120:mdna:12]

[0000833444-16-000172:mdna:10]
[same as prior period, unchanged from 0000833444-16-000120:mdna:13]

[0000833444-16-000172:mdna:11]
[same as prior period, unchanged from 0000833444-16-000120:mdna:14]

[0000833444-16-000172:mdna:12]
Effective for the first quarter of fiscal 2016, the Company has elected to present operating income by segment, as well as Corporate and Other, excluding restructuring and repositioning charges, net.  Restructuring and repositioning charges, net, are shown in aggregate. This presentation is consistent with how management reviews the businesses, makes investing and resource decisions and assesses operating performance. See Note 15 to the unaudited Consolidated Financial Statements.

[0000833444-16-000172:mdna:13]
During the second quarter of fiscal 2016, the Company completed the sale of its Australian fire protection business, included in the ROW Integrated Solutions & Services segment. The assets and liabilities related to this business were classified as held for sale as of September 25, 2015.  Its results of operations are included in continuing operations, as the criteria to be presented as a discontinued operation were not satisfied. See Note 3 to the unaudited Consolidated Financial Statements.

[0000833444-16-000172:mdna:14]
[same as prior period, unchanged from 0000833444-16-000120:mdna:18]

[0000833444-16-000172:mdna:15]
Proposed Merger with Johnson Controls, Inc.

[0000833444-16-000172:mdna:16]
On January 24, 2016, Tyco and Johnson Controls, Inc. announced that they have entered into a definitive merger agreement under which Johnson Controls, Inc. ("Johnson Controls"), a global multi-industrial company, will combine with Tyco. Under the terms of the agreement, which was unanimously approved by both companies’ Boards of Directors, Johnson Controls shareholders will own approximately 56% of the equity of the combined company and receive aggregate cash consideration of approximately $3.9 billion. Current Tyco shareholders will own approximately 44% of the equity of the combined company.

[0000833444-16-000172:mdna:17]
Under the terms of the proposed transaction, the businesses of Johnson Controls and Tyco will be combined under Tyco International plc, which will be renamed “Johnson Controls plc.” The companies expect that shares of the combined company will be listed on the New York Stock Exchange and trade under the “JCI” ticker. Upon the closing of the transaction, the combined company is expected to maintain Tyco’s Irish legal domicile and global headquarters in Cork, Ireland. The primary operational headquarters in North America for the combined company will be in Milwaukee, where Johnson Controls has been based.

[0000833444-16-000172:mdna:18]
Immediately prior to the merger, Tyco will effect a reverse stock split so that Tyco shareholders will receive a fixed exchange ratio of 0.955 shares for each of their existing Tyco shares. Johnson Controls shareholders may elect to receive either one share of the combined company for each of their Johnson Controls shares or cash equal to $34.88 per share. Elections by Johnson Controls shareholders are subject to proration such that an aggregate of approximately $3.9 billion cash is paid in the merger.

[0000833444-16-000172:mdna:19]
The completion of the transaction is subject to customary closing conditions, including regulatory approvals and approval by both Johnson Controls and Tyco shareholders. See Notes 1 and 2 to the unaudited Consolidated Financial Statements.

[0000833444-16-000172:mdna:20]
Tyco has entered into a senior unsecured term loan facility in the amount of $4 billion to finance the cash consideration for, and fees, expenses and costs incurred in connection with, the merger. In addition, the Company has entered into a revolving credit agreement in the amount of $1 billion, which is intended to replace Tyco's existing $1.5 billion revolving credit agreement. Tyco's ability to draw down on both the term loan facility and the new revolving credit agreement are contingent on the consummation of the merger with Johnson Controls. See Note 9 to the unaudited Consolidated Financial Statements.

[0000833444-16-000172:mdna:21]
Tentative Settlement with IRS

[0000833444-16-000172:mdna:22]
On January 15, 2016, Tyco entered into Stipulations of Settled Issues with the IRS intended to resolve all disputes related to the intercompany debt issues for the 1997 - 2000 audit cycle currently before the U.S. Tax Court. The Stipulations of Settled Issues are contingent upon the IRS Appeals Division applying the same settlement to all intercompany debt issues on appeal for subsequent audit cycles (2001 - 2007) and, if applicable, review by the United States Congress Joint Committee on Taxation. If finalized, the tentative resolution would cover all aspects of the controversy before the U.S. Tax Court described above and before the Appeals Division of the IRS, and would result in a total cash payment to the IRS in the range of $475 million to $525 million, which includes all interest and penalties. This payment would be subject to the sharing formula in each Tax Sharing Agreement, and would be shared among Tyco, Covidien and TE Connectivity 27%, 42% and 31%, respectively, with neither ADT nor Pentair being responsible for any payment related to this amount. Assuming the tentative resolution is finalized, Tyco does not expect to recognize any additional charges related to the resolution, as it had previously recorded sufficient reserves with respect to this controversy and its obligations under the Tax Sharing Agreements. The Company made a payment of $120 million to TE Connectivity and $2 million to Covidien, which was subsequently paid to the IRS, during the second quarter of fiscal 2016 in connection with the tentative resolution. See Note 6 to the unaudited Consolidated Financial Statements.

[0000833444-16-000172:mdna:23]
Acquisitions

[0000833444-16-000172:mdna:24]
The Company continues to make strategic acquisitions and investments to complement its core businesses.  During the first quarter of fiscal 2016, the Company made an additional investment of approximately $128 million in the Company's joint venture, Tyco UAE, with its local partner Suwaidi Engineering Group in the United Arab Emirates ("UAE"). Tyco UAE is a leading provider of fire, security and integrated solutions and services in the UAE and also has operations in Qatar and Oman.  Effective with the date of this transaction, the Company consolidated 100% of Tyco UAE, which is recorded in the Company's ROW Integrated Solutions & Services segment. As a result of this transaction, the Company recorded a net gain of $111 million recorded in Selling, general and administrative expenses within the Company's Consolidated Statements of Operations. In addition, during the second quarter of fiscal 2016, the Company completed the acquisition of ShopperTrak, a leading global provider of retail consumer behavior insights and location-based analytics, for approximately $176 million in cash. The financial results of this business have been reported in the NA Integrated Solutions & Services and ROW Integrated Solutions & Services segments. See Note 5 to the unaudited Consolidated Financial Statements.

[0000833444-16-000172:mdna:25]
Divestitures

[0000833444-16-000172:mdna:26]
The Company continuously assesses the strategic fit of its various businesses and pursues the divestiture of certain businesses included within the Company's portfolio which do not align with the Company's long-term strategy. During the second quarter of fiscal 2016, the Company completed the sale of its Australian fire protection business within its ROW Integrated Solutions & Services segment. As a result, the Company incurred a loss of $75 million for the six months ended March 25, 2016 including an $18 million loss realized in the second quarter of fiscal 2016. The loss was recorded in Selling, general and administrative expenses within the Company’s Consolidated Statements of Operations. See Note 3 to the unaudited Consolidated Financial Statements.

[0000833444-16-000172:mdna:27]
Long-term Debt Redemption and Repayment

[0000833444-16-000172:mdna:28]
On September 14, 2015, the Company and TIFSA announced the redemption of all of the outstanding $242 million aggregate principal amount of 7.0% notes due 2019 and $462 million aggregate principal amount of 6.875% notes due 2021. On October 14, 2015, TIFSA paid cash of $876 million to complete the redemption, resulting in a loss on extinguishment of $168 million which was recorded in Other expense, net within the Consolidated Statements of Operations during the first quarter of fiscal 2016. On October 15, 2015, the Company repaid at maturity $258 million aggregate principal amount of 3.375% notes which matured on such date. See Note 9 to the unaudited Consolidated Financial Statements.

[0000833444-16-000172:mdna:29]
[same as prior period, unchanged from 0000833444-16-000120:mdna:26]

[0000833444-16-000172:mdna:30]
We are a leading global provider of security products and services, fire detection and suppression products and services and life safety products. We utilize our extensive global footprint of approximately 900 locations, including manufacturing facilities, service and distribution centers, monitoring centers and sales offices, to provide solutions and localized expertise to our global customer base. We provide an extensive range of product and service offerings to over 3 million customers in more than 100 countries through multiple channels. Our revenues are broadly diversified across the United States and Canada (collectively “North America”); Central America and South America (collectively “Latin America”); Europe, the Middle East, and Africa (collectively “EMEA”) and the Asia-Pacific geographic areas. The following chart reflects our net revenue by geographic area for the six months ended March 25, 2016.

[0000833444-16-000172:mdna:31]
Six Months Ended March 25, 2016

[0000833444-16-000172:mdna:32]
[same as prior period, unchanged from 0000833444-16-000120:mdna:29]

[0000833444-16-000172:mdna:33]
[same as prior period, unchanged from 0000833444-16-000120:mdna:30]

[0000833444-16-000172:mdna:34]
[same as prior period, unchanged from 0000833444-16-000120:mdna:31]

[0000833444-16-000172:mdna:35]
[same as prior period, unchanged from 0000833444-16-000120:mdna:32]

[0000833444-16-000172:mdna:36]
[same as prior period, unchanged from 0000833444-16-000120:mdna:33]

[0000833444-16-000172:mdna:37]
[same as prior period, unchanged from 0000833444-16-000120:mdna:34]

[0000833444-16-000172:mdna:38]
[same as prior period, unchanged from 0000833444-16-000120:mdna:35]

[0000833444-16-000172:mdna:39]
[same as prior period, unchanged from 0000833444-16-000120:mdna:36]

[0000833444-16-000172:mdna:40]
[same as prior period, unchanged from 0000833444-16-000120:mdna:37]

[0000833444-16-000172:mdna:41]
Because we are a global business, with approximately 50% of our revenue generated outside of the United States, and because our financial statements are prepared in U.S. Dollars, the results of our operations are impacted by changes in foreign currency exchange rates. During the first half of fiscal 2016, the U.S. Dollar has remained strong against the currencies of most of the significant non-U.S. jurisdictions where we operate. The most significant impact on our results has been due to the strengthening of the U.S. Dollar as compared to the Euro and the Canadian Dollar, which has unfavorably impacted our revenue and operating income during fiscal 2015 and 2016.

[0000833444-16-000172:mdna:42]
In addition, the Company sells its products and services into the high-hazard, heavy industrial sector. Revenue from this market vertical is spread across each of the Company’s segments, with the most significant exposure in the United Kingdom in the ROW Integrated Solutions & Services segment and in the Fire Protection Products business in the Global Products segment. As a result of recent volatility in oil prices, this market vertical has seen significant changes in spending patterns, in particular with respect to capital expenditures. The revenue tied to this market vertical was unfavorably impacted during fiscal 2015, and we expect weakness in this sector to continue during fiscal 2016.

[0000833444-16-000172:mdna:43]
51

[0000833444-16-000172:mdna:44]
[same as prior period, unchanged from 0000833444-16-000120:mdna:41]

[0000833444-16-000172:mdna:45]
[same as prior period, unchanged from 0000833444-16-000120:mdna:42]

[0000833444-16-000172:mdna:46]
|  | For the Quarters Ended |  | For the Six Months Ended |
| ($ in millions) | March 25, 2016 |  | March 27, 2015 |  | March 25, 2016 |  | March 27, 2015 |
| Net revenue | $ | 2,331 |  |  | $ | 2,430 |  |  | $ | 4,707 |  |  | $ | 4,908 |  |
| Net revenue decline | (4.1 | )% |  | N/A |  |  | (4.1 | )% |  | N/A |  |
| Organic revenue decline | (1.0 | )% |  | N/A |  |  | (0.4 | )% |  | N/A |  |
| Segment operating income | $ | 289 |  |  | $ | 306 |  |  | $ | 651 |  |  | $ | 629 |  |
| Segment operating margin | 12.4 | % |  | 12.6 | % |  | 13.8 | % |  | 12.8 | % |
| Corporate and Other | $ | (54 | ) |  | $ | (56 | ) |  | $ | (105 | ) |  | $ | (105 | ) |
| Restructuring and repositioning charges, net | (10 | ) |  | (29 | ) |  | (28 | ) |  | (104 | ) |
| Operating income | 225 |  |  | 221 |  |  | 518 |  |  | 420 |  |
| Operating margin | 9.7 | % |  | 9.1 | % |  | 11.0 | % |  | 8.6 | % |
| Interest income | $ | 4 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | 7 |  |
| Interest expense | (22 | ) |  | (25 | ) |  | (46 | ) |  | (49 | ) |
| Other (expense) income, net | — |  |  | (1 | ) |  | (165 | ) |  | 3 |  |
| Income tax expense | (63 | ) |  | (18 | ) |  | (99 | ) |  | (37 | ) |
| Income from continuing operations attributable to Tyco ordinary shareholders | 145 |  |  | 183 |  |  | 217 |  |  | 347 |  |

[0000833444-16-000172:mdna:47]
[same as prior period, unchanged from 0000833444-16-000120:mdna:45]

[0000833444-16-000172:mdna:48]
Net revenue for the quarter ended March 25, 2016 decreased by $99 million, or 4.1%, to $2,331 million as compared to net revenue of $2,430 million for the quarter ended March 27, 2015.  Changes in foreign currency exchange rates had an unfavorable impact of $101 million, or 4.2%, on net revenue, primarily in our ROW Integrated Solutions & Services segment, and to a lesser extent, in our Global Products segment.  In addition, divestitures had an unfavorable impact of $65 million, or 2.7%, primarily in the ROW Integrated Solutions & Services segment. On an organic basis, net revenue declined by $23 million, or 1.0%, year over year, primarily as a result of declines in our Global Products and to a lesser extent, ROW Integrated Solutions & Services segments, partially offset by modest growth in our NA Integrated Solutions & Services segment. Net revenue was favorably impacted by acquisitions that contributed $90 million, or 3.7%, primarily within our ROW Integrated Solutions & Services segment.

[0000833444-16-000172:mdna:49]
Net revenue for the six months ended March 25, 2016 decreased by $201 million, or 4.1%, to $4,707 million as compared to net revenue of $4,908 million for the six months ended March 27, 2015. Changes in foreign currency exchange rates had an unfavorable impact of $253 million, or 5.2%, on net revenue, primarily in our ROW Integrated Solutions & Services segment, and to a lesser extent, in our Global Products segment. In addition, divestitures had an unfavorable impact of $88 million, or 1.8% primarily in the ROW Integrated Solutions & Services segment. On an organic basis, net revenue declined by $21 million, or 0.4%, year over year, primarily as a result of declines in our Global Products and to a lesser extent, ROW Integrated Solutions & Services segments, partially offset by growth in our NA Integrated Solutions & Services segment. Net revenue was favorably impacted by acquisitions that contributed $161 million, or 3.3%, primarily within our ROW Integrated Solutions & Services and Global Products segments.

[0000833444-16-000172:mdna:50]
[same as prior period, unchanged from 0000833444-16-000120:mdna:47]

[0000833444-16-000172:mdna:51]
The significant components of cost of product sales include material costs, labor and overhead costs, product shipping and warehousing costs. The significant components of cost of services include labor and employee related costs, depreciation expense, costs associated with our equipment and fleet of vehicles, telecommunication costs and material costs. The significant components of SG&A include compensation and compensation related costs, facility and maintenance expenses and professional fees. SG&A for the quarter ended March 25, 2016 also includes divestiture charges, net of $17 million. SG&A for the six months ended March 25, 2016 includes a net gain on an equity investment of $111 million, partially offset by divestiture charges, net, of $69 million.  See Notes 3 and 5 to the unaudited Consolidated Financial Statements.

[0000833444-16-000172:mdna:52]
Merger Costs

[0000833444-16-000172:mdna:53]
The Company incurred merger costs of $26 million for the quarter and six months ended March 25, 2016 in connection with the proposed merger with Johnson Controls. These costs primarily relate to financing, advisory, and professional fees. See Note 2 to the unaudited Consolidated Financial Statements.

[0000833444-16-000172:mdna:54]
The Company currently estimates that, upon the effective time of the merger, transaction-related costs incurred by the Company related to the merger, including the fees and expenses incurred through March 25, 2016, will be approximately $105 million. This amount includes estimated transaction costs to be incurred by the Company and settled on or about the closing of the merger under signed agreements that had been executed as of March 24, 2016, which primarily relate to financing, investment banking, advisory, legal, valuation, and other professional fees, and retention related costs for certain Tyco employees. Not included in these cost estimates are employee- or integration-related costs such as severance, restructuring or other costs anticipated to be incurred to achieve ongoing operating synergies following the completion of the merger. The transaction costs related to the merger are preliminary estimates only, are inherently uncertain, and could differ materially from actual results.

[0000833444-16-000172:mdna:55]
[same as prior period, unchanged from 0000833444-16-000120:mdna:49]

[0000833444-16-000172:mdna:56]
The Company continues to identify and pursue opportunities for cost savings through restructuring activities and workforce reductions to improve operating efficiencies across the Company's businesses and corporate functions. Accordingly, the Company has initiated certain global actions designed to reduce its cost structure and improve future profitability by streamlining operations and better aligning functions, which the Company refers to as repositioning actions. These actions may or may not lead to a future restructuring action. During fiscal 2015, the Company recorded restructuring and repositioning charges of $289 million, of which $29 million and $104 million were recorded during the quarter and six months ended March 27, 2015, respectively. The Company expects to incur restructuring and repositioning charges, net between $70 million and $85 million in fiscal 2016.  The Company recorded restructuring and repositioning charges, net of $10 million and $28 million during the quarter and six months ended March 25, 2016, respectively. See Note 4 to the unaudited Consolidated Financial Statements.

[0000833444-16-000172:mdna:57]
[same as prior period, unchanged from 0000833444-16-000120:mdna:51]

[0000833444-16-000172:mdna:58]
Operating income for the quarter ended March 25, 2016 increased by $4 million, or 1.8%, to $225 million, as compared to operating income of $221 million for the quarter ended March 27, 2015. Factors that impacted operating income were a $19 million reduction in restructuring and repositioning charges, net, legacy legal gains of $19 million, and a $5 million reduction in net divestiture charges.  These were partially offset by $26 million in merger costs related to the proposed merger with Johnson Controls. Changes in foreign currency exchange rates had an unfavorable impact on operating income of $11 million, or 5.0%.

[0000833444-16-000172:mdna:59]
Operating income for the six months ended March 25, 2016 increased by $98 million, or 23.3%, to $518 million, as compared to operating income of $420 million for the six months ended March 27, 2015. In connection with the additional investment in our UAE joint venture, we recorded a net gain of $111 million within Selling, general and administrative expenses relating to the Company's previously held equity method investment in the joint venture. See Note 5 to the unaudited Consolidated Financial Statements. Operating income also increased due to a $76 million reduction in restructuring and repositioning charges, net, and an increase in legacy legal gains of $12 million. Operating income also benefited from previous productivity initiatives. These items were partially offset by an increase of $46 million of divestiture charges, net, primarily related to the loss on the sale of our Australian fire protection business, as well as $26 million in merger costs related to the proposed merger with Johnson Controls. See Notes 2 and 3 to the unaudited Consolidated Financial Statements. Changes in foreign currency exchange rates also had an unfavorable impact on operating income of $25 million, or 6.0%.

[0000833444-16-000172:mdna:60]
Key items impacting operating income for the quarters and six months ended March 25, 2016 and March 27, 2015, respectively, are as follows:

[0000833444-16-000172:mdna:61]
|  | For the Quarters Ended |  | For the Six Months Ended |
| ($ in millions) | March 25, 2016 |  | March 27, 2015 |  | March 25, 2016 |  | March 27, 2015 |
| Gain on equity investment, net | $ | — |  |  | $ | — |  |  | $ | (111 | ) |  | $ | — |  |
| Legacy legal gains | (19 | ) |  | — |  |  | (19 | ) |  | (7 | ) |
| Divestiture charges, net | 17 |  |  | 22 |  |  | 69 |  |  | 23 |  |
| Restructuring and repositioning charges, net | 10 |  |  | 29 |  |  | 28 |  |  | 104 |  |
| Merger costs | 26 |  |  | — |  |  | 26 |  |  | — |  |
| Unfavorable impact of foreign currency | 11 |  |  | N/A |  |  | 25 |  |  | N/A |  |

[0000833444-16-000172:mdna:62]
[same as prior period, unchanged from 0000833444-16-000120:mdna:55]

[0000833444-16-000172:mdna:63]
Interest income was $4 million for both quarters ended March 25, 2016 and March 27, 2015.  Interest income was $8 million and $7 million for the six months ended March 25, 2016 and March 27, 2015, respectively.

[0000833444-16-000172:mdna:64]
Interest expense was $22 million and $25 million for the quarters ended March 25, 2016 and March 27, 2015, respectively. Interest expense was $46 million and $49 million for the six months ended March 25, 2016 and March 27, 2015, respectively.  The decrease in interest expense for both periods was due to the impact of the debt refinancing during the first quarter of fiscal 2016.  See Note 9 to the unaudited Consolidated Financial Statements.

[0000833444-16-000172:mdna:65]
[same as prior period, unchanged from 0000833444-16-000120:mdna:58]

[0000833444-16-000172:mdna:66]
Significant components of other (expense) income, net for the quarters and six months ended March 25, 2016 and March 27, 2015 are as follows:

[0000833444-16-000172:mdna:67]
|  | For the Quarters Ended |  | For the Six Months Ended |
| ($ in millions) | March 25, 2016 |  | March 27, 2015 |  | March 25, 2016 |  | March 27, 2015 |
| Loss on extinguishment of debt (see Note 9 to the unaudited Consolidated Financial Statements) | $ | — |  |  | $ | — |  |  | $ | (168 | ) |  | $ | — |  |
| 2012 Tax Sharing Agreement loss (see Note 6 to the unaudited Consolidated Financial Statements) | — |  |  | (4 | ) |  | — |  |  | (2 | ) |
| 2007 Tax Sharing Agreement gain (see Note 6 to the unaudited Consolidated Financial Statements) | — |  |  | 1 |  |  | — |  |  | — |  |
| Other | — |  |  | 2 |  | 3 |  | 5 |
|  | $ | — |  |  | $ | (1 | ) |  | $ | (165 | ) |  | $ | 3 |  |

[0000833444-16-000172:mdna:68]
[same as prior period, unchanged from 0000833444-16-000120:mdna:61]

[0000833444-16-000172:mdna:69]
Our effective income tax rate was 30.4% and 9.0% during the quarters ended March 25, 2016 and March 27, 2015, respectively.  The increase in our effective tax rate in the current period was primarily due to merger costs which do not generate a tax benefit and tax charges in connection with the divestiture of the Australian Fire Protection business. The prior period was favorably impacted by a decrease in valuation allowances on the basis of management's reassessment of the amount of its deferred tax assets that are more likely than not to be realized resulting from the impact of restructuring actions and tax law changes in a non-U.S. jurisdiction.

[0000833444-16-000172:mdna:70]
Our effective income tax rate was 31.4% and 9.7% during the six months ended March 25, 2016 and March 27, 2015, respectively.  The increase in our effective tax rate in the six month period was primarily due to the same factors impacting the quarter, in addition to a non-recurring loss on debt extinguishment for which the related deferred tax benefits will not be realized.

[0000833444-16-000172:mdna:71]
The rate can vary from quarter to quarter due to discrete items, such as the settlement of income tax audits and changes in tax laws, as well as recurring factors such as the geographic mix of income before taxes.  The Company has operations and a taxable presence in nearly 60 countries outside the U.S.  All of these countries have a tax rate that is lower than the rate in the U.S.  The countries in which the Company has a material presence that have lower tax rates compared to the U.S. include Canada, Australia, Ireland, Germany, Switzerland and the United Kingdom.  The Company's ability to obtain a benefit from lower tax rates outside the U.S. is dependent on its relative levels of income in countries outside the U.S. and on the statutory tax rates and tax laws in these countries.  Based on the dispersion of the Company's non-U.S. income and management’s assessment of the likelihood and magnitude of any potential change to statutory tax rates or tax laws affecting the Company, any such changes are not expected to materially affect the Company's income tax provision or net income, aside from any one-time adjustment to reflect the impact of the change in the tax rate to the Company's deferred tax balances.

[0000833444-16-000172:mdna:72]
[same as prior period, unchanged from 0000833444-16-000120:mdna:65]

[0000833444-16-000172:mdna:73]
The following chart reflects our net revenue by operating segment, as well as the percent of net revenue by operating segment, for the quarters and six months ended March 25, 2016 and March 27, 2015, respectively.

[0000833444-16-000172:mdna:74]
[same as prior period, unchanged from 0000833444-16-000120:mdna:67]

[0000833444-16-000172:mdna:75]
[same as prior period, unchanged from 0000833444-16-000120:mdna:68]

[0000833444-16-000172:mdna:76]
Financial information for NA Integrated Solutions & Services for the quarters and six months ended March 25, 2016 and March 27, 2015 is as follows:

[0000833444-16-000172:mdna:77]
|  | For the Quarters Ended |  | For the Six Months Ended |
| ($ in millions) | March 25, 2016 |  | March 27, 2015 |  | March 25, 2016 |  | March 27, 2015 |
| Net revenue | $ | 947 |  |  | $ | 944 |  |  | $ | 1,900 |  |  | $ | 1,895 |  |
| Net revenue growth | 0.3 | % |  | N/A |  |  | 0.3 | % |  | N/A |  |
| Organic revenue growth | 0.4 | % |  | N/A |  |  | 1.0 | % |  | N/A |  |
| Segment operating income | $ | 131 |  |  | $ | 125 |  |  | $ | 263 |  |  | $ | 254 |  |
| Segment operating margin | 13.8 | % |  | 13.2 | % |  | 13.8 | % |  | 13.4 | % |

[0000833444-16-000172:mdna:78]
[same as prior period, unchanged from 0000833444-16-000120:mdna:153]

[0000833444-16-000172:mdna:79]
[same as prior period, unchanged from 0000833444-16-000120:mdna:71]

[0000833444-16-000172:mdna:80]
[same as prior period, unchanged from 0000833444-16-000120:mdna:72]

[0000833444-16-000172:mdna:81]
| Factors Contributing to Year-Over-Year Change |  | Second QuarterFiscal 2016 Compared toSecond QuarterFiscal 2015 |  | Year to DateFiscal 2016 Compared toYear to DateFiscal 2015 |
| Organic revenue growth |  | $ | 4 |  |  | $ | 19 |  |
| Acquisitions |  | 9 |  |  | 12 |  |
| Impact of foreign currency |  | (10 | ) |  | (26 | ) |
| Total change |  | $ | 3 |  |  | $ | 5 |  |

[0000833444-16-000172:mdna:82]
Net revenue increased $3 million, or 0.3%, to $947 million for the quarter ended March 25, 2016 as compared to $944 million for the quarter ended March 27, 2015. On an organic basis, net revenue grew by $4 million, or 0.4%, from the comparable quarter, with growth driven by integrated solutions revenue, as service revenue remained consistent with the prior year. Net revenue was also favorably impacted by $9 million, or 1.0%, due to acquisitions, primarily related to the ShopperTrak acquisition that closed in the second quarter of fiscal 2016. Changes in foreign currency exchange rates unfavorably impacted net revenue by $10 million, or 1.1%.

[0000833444-16-000172:mdna:83]
Net revenue increased $5 million, or 0.3%, to $1,900 million for the six months ended March 25, 2016 as compared to $1,895 million for the six months ended March 27, 2015. On an organic basis, net revenue grew by $19 million, or 1.0%, from the comparable period, with growth in both integrated solutions and service revenue, and in particular, in the retail, commercial and institutional vertical markets. Net revenue was also favorably impacted by $12 million, or 0.6%, primarily due to the ShopperTrak acquisition and several acquisitions made during fiscal 2015. Changes in foreign currency exchange rates unfavorably impacted net revenue by $26 million, or 1.4%.

[0000833444-16-000172:mdna:84]
[same as prior period, unchanged from 0000833444-16-000120:mdna:75]

[0000833444-16-000172:mdna:85]
Segment operating income for the quarter ended March 25, 2016 increased $6 million, or 4.8%, to $131 million, as compared to segment operating income of $125 million for the quarter ended March 27, 2015. Operating income was favorably impacted by improved execution and the benefit of previous productivity initiatives, partially offset by higher amortization expense resulting from recent acquisitions.

[0000833444-16-000172:mdna:86]
Segment operating income for the six months ended March 25, 2016 increased $9 million, or 3.5%, to $263 million, as compared to segment operating income of $254 million for the six months ended March 27, 2015. Operating income was favorably impacted by improved execution and the benefit of previous productivity initiatives, partially offset by higher amortization expense resulting from recent acquisitions.

[0000833444-16-000172:mdna:87]
[same as prior period, unchanged from 0000833444-16-000120:mdna:77]

[0000833444-16-000172:mdna:88]
Financial information for ROW Integrated Solutions & Services for the quarters and six months ended March 25, 2016 and March 27, 2015 is as follows:

[0000833444-16-000172:mdna:89]
|  | For the Quarters Ended |  | For the Six Months Ended |
| ($ in millions) | March 25, 2016 |  | March 27, 2015 |  | March 25, 2016 |  | March 27, 2015 |
| Net revenue | $ | 768 |  |  | $ | 847 |  |  | $ | 1,580 |  |  | $ | 1,763 |  |
| Net revenue decline | (9.3 | )% |  | N/A |  |  | (10.4 | )% |  | N/A |  |
| Organic revenue decline | (1.0 | )% |  | N/A |  |  | (1.1 | )% |  | N/A |  |
| Segment operating income | $ | 57 |  |  | $ | 67 |  |  | $ | 190 |  |  | $ | 156 |  |
| Segment operating margin | 7.4 | % |  | 7.9 | % |  | 12.0 | % |  | 8.8 | % |

[0000833444-16-000172:mdna:90]
56

[0000833444-16-000172:mdna:91]
[same as prior period, unchanged from 0000833444-16-000120:mdna:80]

[0000833444-16-000172:mdna:92]
[same as prior period, unchanged from 0000833444-16-000120:mdna:81]

[0000833444-16-000172:mdna:93]
| Factors Contributing to Year-Over-Year Change |  | Second QuarterFiscal 2016 Compared toSecond QuarterFiscal 2015 |  | Year to DateFiscal 2016 Compared toYear to DateFiscal 2015 |
| Organic revenue decline |  | $ | (8 | ) |  | $ | (18 | ) |
| Acquisitions |  | 64 |  |  | 93 |  |
| Divestitures |  | (62 | ) |  | (84 | ) |
| Impact of foreign currency |  | (73 | ) |  | (174 | ) |
| Total change |  | $ | (79 | ) |  | $ | (183 | ) |

[0000833444-16-000172:mdna:94]
Net revenue decreased $79 million, or 9.3%, to $768 million for the quarter ended March 25, 2016 as compared to $847 million for the quarter ended March 27, 2015. Changes in foreign currency exchange rates unfavorably impacted net revenue by $73 million, or 8.6%. On an organic basis, net revenue declined by $8 million, or 1.0%, driven by a decline in integrated solutions revenue, partially offset by growth in services revenue. The organic revenue decline was primarily within Asia and the United Kingdom and was driven by pressure within the high-hazard, heavy industrial sector. These declines were partially offset by organic revenue growth in our growth markets and to a lesser extent, Continental Europe. In addition, divestitures in the Pacific region and Asia had an unfavorable impact of $62 million, or 7.3%. Net revenue was favorably impacted by $64 million, or 7.6%, due to acquisitions primarily within growth markets and retail solutions.

[0000833444-16-000172:mdna:95]
Net revenue decreased $183 million, or 10.4%, to $1,580 million for the six months ended March 25, 2016 as compared to $1,763 million for the six months ended March 27, 2015. Changes in foreign currency exchange rates unfavorably impacted net revenue by $174 million, or 9.9%. On an organic basis, net revenue declined by $18 million, or 1.1%, driven by a decline in integrated solutions revenue, partially offset by growth in services revenue. The organic revenue decline was primarily in the United Kingdom, Asia and the Pacific region as a result of pressure within the high-hazard, heavy industrial sector. These declines were partially offset by organic revenue growth in our growth markets and to a lesser extent, Continental Europe. In addition, divestitures in the Pacific region and Asia had an unfavorable impact of $84 million, or 4.8%. Net revenue was favorably impacted by $93 million, or 5.3%, due to acquisitions primarily within growth markets and retail solutions.

[0000833444-16-000172:mdna:96]
[same as prior period, unchanged from 0000833444-16-000120:mdna:85]

[0000833444-16-000172:mdna:97]
Segment operating income for the quarter ended March 25, 2016 decreased $10 million, or 14.9%, to $57 million as compared to segment operating income of $67 million for the quarter ended March 27, 2015. Segment operating income decreased primarily due to the $9 million, or 13.4%, unfavorable impact of changes in foreign currency exchange rates and higher amortization expense primarily due to recent acquisitions. These decreases are partially offset by a reduction in divestiture charges, net of $4 million, and the benefit of previous productivity initiatives.

[0000833444-16-000172:mdna:98]
Segment operating income for the six months ended March 25, 2016 increased $34 million, or 21.8%, to $190 million as compared to segment operating income of $156 million for the six months ended March 27, 2015. In connection with the additional investment in our UAE joint venture, we recorded a net gain of $111 million within Selling, general and administrative expenses relating to the Company's previously held equity method investment in the joint venture. See Note 5 to the unaudited Consolidated Financial Statements. To a lesser extent, segment operating income increased due to the benefit of previous productivity initiatives. These items were partially offset by an increase of $49 million of divestiture charges, net, primarily related to the loss on sale of our Australian fire protection business. See Note 3 to the unaudited Consolidated Financial Statements. In addition, changes in foreign currency exchange rates had an unfavorable impact on segment operating income of $18 million, or 11.5%.

[0000833444-16-000172:mdna:99]
Key items impacting segment operating income for the quarters and six months ended March 25, 2016 and March 27, 2015, respectively, are as follows:

[0000833444-16-000172:mdna:100]
|  | For the Quarters Ended |  | For the Six Months Ended |
| ($ in millions) | March 25, 2016 |  | March 27, 2015 |  | March 25, 2016 |  | March 27, 2015 |
| Divestiture charges, net | $ | 18 |  |  | $ | 22 |  |  | $ | 72 |  |  | $ | 23 |  |
| Gain on equity investment, net | — |  |  | — |  |  | (111 | ) |  | — |  |
| Unfavorable impact of foreign currency | 9 |  |  | N/A |  |  | 18 |  |  | N/A |  |

[0000833444-16-000172:mdna:101]
57

[0000833444-16-000172:mdna:102]
[same as prior period, unchanged from 0000833444-16-000120:mdna:89]

[0000833444-16-000172:mdna:103]
Financial information for Global Products for the quarters and six months ended March 25, 2016 and March 27, 2015 is as follows:

[0000833444-16-000172:mdna:104]
|  | For the Quarters Ended |  | For the Six Months Ended |
| ($ in millions) | March 25, 2016 |  | March 27, 2015 |  | March 25, 2016 |  | March 27, 2015 |
| Net revenue | $ | 616 |  |  | $ | 639 |  |  | $ | 1,227 |  |  | $ | 1,250 |  |
| Net revenue decline | (3.6 | )% |  | N/A |  |  | (1.8 | )% |  | N/A |  |
| Organic revenue decline | (3.0 | )% |  | N/A |  |  | (1.8 | )% |  | N/A |  |
| Segment operating income | $ | 101 |  |  | $ | 114 |  |  | $ | 198 |  |  | $ | 219 |  |
| Segment operating margin | 16.4 | % |  | 17.8 | % |  | 16.1 | % |  | 17.5 | % |

[0000833444-16-000172:mdna:105]
[same as prior period, unchanged from 0000833444-16-000120:mdna:92]

[0000833444-16-000172:mdna:106]
[same as prior period, unchanged from 0000833444-16-000120:mdna:93]

[0000833444-16-000172:mdna:107]
| Factors Contributing to Year-Over-Year Change |  | Second QuarterFiscal 2016 Compared toSecond QuarterFiscal 2015 |  | Year to DateFiscal 2016 Compared toYear to DateFiscal 2015 |
| Organic revenue decline |  | $ | (19 | ) |  | $ | (22 | ) |
| Acquisitions |  | 17 |  |  | 56 |  |
| Divestitures |  | (3 | ) |  | (4 | ) |
| Impact of foreign currency |  | (18 | ) |  | (53 | ) |
| Total change |  | $ | (23 | ) |  | $ | (23 | ) |

[0000833444-16-000172:mdna:108]
Net revenue decreased $23 million, or 3.6%, to $616 million for the quarter ended March 25, 2016 as compared to $639 million for the quarter ended March 27, 2015. On an organic basis, net revenue declined by $19 million, or 3.0%, driven by life safety products due to increased shipments of Scott Air-Paks in the comparable period in the prior year as well as fire protection products related to the high-hazard, heavy industrial sector. Net revenue was unfavorably impacted by changes in foreign currency exchange rates of $18 million, or 2.8%. Net revenue was favorably impacted during the quarter ended March 25, 2016 by $17 million, or 2.7%, from acquisitions, primarily related to the Industrial Safety Technologies acquisition within our life safety business in fiscal 2015.

[0000833444-16-000172:mdna:109]
Net revenue decreased $23 million, or 1.8%, to $1,227 million for the six months ended March 25, 2016 as compared to $1,250 million for the six months ended March 27, 2015. On an organic basis, net revenue declined by $22 million, or 1.8%, driven by the timing of increased shipments of Scott Air-Paks in our life safety business in the comparable period in the prior year, and to a lesser extent, our fire products business, partially offset by organic growth in our security products business. Net revenue was unfavorably impacted by changes in foreign currency exchange rates of $53 million, or 4.2%. Net revenue was favorably impacted during the six months ended March 25, 2016 by $56 million, or 4.5%, from acquisitions, primarily related to the Industrial Safety Technologies acquisition within our life safety business in fiscal 2015.

[0000833444-16-000172:mdna:110]
[same as prior period, unchanged from 0000833444-16-000120:mdna:97]

[0000833444-16-000172:mdna:111]
Segment operating income for the quarter ended March 25, 2016 decreased by $13 million, or 11.4% to $101 million, as compared to segment operating income of $114 million for the quarter ended March 27, 2015. Segment operating income decreased due to product mix and the decline in revenue. In addition, operating income was negatively impacted by higher amortization expense primarily due to acquisitions made during the prior year.

[0000833444-16-000172:mdna:112]
Segment operating income for the six months ended March 25, 2016 decreased by $21 million, or 9.6% to $198 million, as compared to segment operating income of $219 million for the six months ended March 27, 2015. Segment operating income decreased due to product mix and the decline in revenue. In addition, changes in foreign currency exchange rates had an unfavorable impact on segment operating income of $5 million, or 2.3%.

[0000833444-16-000172:mdna:113]
[same as prior period, unchanged from 0000833444-16-000120:mdna:99]

[0000833444-16-000172:mdna:114]
Corporate expense, excluding restructuring and repositioning charges, net, was $54 million and $56 million for the quarters ended March 25, 2016 and March 27, 2015, respectively.  Corporate expense for the current quarter includes merger costs of $26 million related to the proposed merger with Johnson Controls, partially offset by a $19 million gain related to favorable developments in the legacy Sonitrol insurance matter previously disclosed by the Company and the benefit of productivity initiatives and cost containment actions.

[0000833444-16-000172:mdna:115]
Corporate expense, excluding restructuring and repositioning charges, net, was $105 million for both the six months ended March 25, 2016 and March 27, 2015. Corporate expense for the six months of fiscal 2016 includes merger costs of $26 million related to the proposed merger with Johnson Controls, partially offset by a $12 million increase in legacy legal gains and the benefit of productivity initiatives and cost containment actions.

[0000833444-16-000172:mdna:116]
Key items included in corporate expense for the quarters and six months ended March 25, 2016 and March 27, 2015, respectively, are as follows:

[0000833444-16-000172:mdna:117]
|  | For the Quarters Ended |  | For the Six Months Ended |
| ($ in millions) | March 25, 2016 |  | March 27, 2015 |  | March 25, 2016 |  | March 27, 2015 |
| Merger costs | $ | 26 |  |  | $ | — |  |  | $ | 26 |  |  | $ | — |  |
| Legacy legal gains | (19 | ) |  | — |  |  | (19 | ) |  | (7 | ) |

[0000833444-16-000172:mdna:118]
[same as prior period, unchanged from 0000833444-16-000120:mdna:103]

[0000833444-16-000172:mdna:119]
The preparation of the unaudited Consolidated Financial Statements in conformity with U.S. GAAP requires management to use judgment in making estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of contingent assets and liabilities and the reported amounts of revenue and expenses. We believe that our accounting policies for depreciation and amortization methods of security monitoring-related assets, revenue recognition, loss contingencies, income taxes, goodwill and indefinite-lived intangible assets, long-lived assets and pension and postretirement benefits are based on, among other things, judgments and assumptions made by management that include inherent risks and uncertainties.

[0000833444-16-000172:mdna:120]
Effective September 26, 2015, we changed the approach used to measure service and interest costs for pension benefits. For fiscal 2016, we elected to measure service and interest costs by applying the specific spot rates along the yield curve over the projected cash flow period. Management believes the new approach provides a more precise measurement of service and interest costs by improving the correlation between projected benefit cash flows to the corresponding spot rates on the yield curves. We have accounted for this change as a change in accounting estimate and, accordingly, have accounted for it on a prospective basis. See Note 12 to the unaudited Consolidated Financial Statements.

[0000833444-16-000172:mdna:121]
Other than the change in approach with respect to pension benefits, during fiscal 2016, there have been no significant changes to the Company's accounting policies or in the underlying accounting assumptions and estimates used in the above critical accounting policies from those disclosed in the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K filed with the SEC on November 13, 2015 for the fiscal year ended September 25, 2015. See Note 1 to the unaudited Consolidated Financial Statements for recently issued and adopted accounting standards.

[0000833444-16-000172:mdna:122]
[same as prior period, unchanged from 0000833444-16-000120:mdna:105]

[0000833444-16-000172:mdna:123]
[same as prior period, unchanged from 0000833444-16-000120:mdna:106]

[0000833444-16-000172:mdna:124]
The primary source of funds to finance our operations and capital expenditures is cash generated by operations. In addition, we maintain a $1.5 billion commercial paper program, backed up by a committed revolving credit facility, and have access to equity and debt capital from public and private sources. We continue to balance our operating, investing, and financing uses of cash through investments and acquisitions in our core businesses, dividends, and share repurchases.  In addition, we believe our available cash, amounts available under our credit facility, commercial paper program and cash provided by operating activities will be adequate to cover our operational, capital and other business needs in the foreseeable future. To the extent it is necessary for us to finance our cash needs through the issuance of commercial paper, by accessing our committed revolving credit facility, or through other public or private sources, our cost of funding may increase depending on market conditions at the time of such borrowing.

[0000833444-16-000172:mdna:125]
Additionally, the Company has entered into a senior unsecured term loan facility in the amount of $4 billion to finance the cash consideration for, and fees, expenses and costs incurred in connection with, the merger. In addition, the Company has

[0000833444-16-000172:mdna:126]
entered into a revolving credit agreement in the amount of $1 billion, which is intended to replace the Company's existing $1.5 billion revolving credit agreement. Tyco's ability to draw down on both the term loan facility and the new revolving credit agreement are contingent on the consummation of the merger with Johnson Controls. See Note 9 to the unaudited Consolidated Financial Statements.

[0000833444-16-000172:mdna:127]
As of March 25, 2016 and September 25, 2015, our cash and cash equivalents, short- and long-term debt at carrying value, and Tyco shareholder's equity are as follows:

[0000833444-16-000172:mdna:128]
|  | As of |  | Credit Availability as of |
| ($ in millions) | March 25, 2016 |  | September 25, 2015 |  | March 25, 2016 (2) |
| Cash and cash equivalents | $ | 345 |  |  | $ | 1,401 |  |  | $ | — |  |
| Total debt (excluding revolving credit facility) | 2,559 |  |  | 3,146 |  |  | — |  |
| Revolving credit facility | — |  |  | — |  |  | 1,500 |  |
| Total Tyco shareholders' equity | 4,142 |  |  | 4,041 |  |  | — |  |
| Total debt as a % of total capital (1) | 38.2 | % |  | 43.8 | % |  | N/A |  |

[0000833444-16-000172:mdna:129]
(1) Total capital represents the aggregate amount of total debt and total shareholders' equity which was $6,701 million and $7,187 million as of March 25, 2016 and September 25, 2015, respectively.

[0000833444-16-000172:mdna:130]
(2) Excludes amounts available under merger related debt financing as described above.

[0000833444-16-000172:mdna:131]
Significant uses of capital that are expected in the near- to mid-term include expenditures for (i) capital expenditures and dealer investments in annual amounts expected to approximate 3% to 3.5% of total revenues, (ii) the funding of potential tax liabilities or settlements (see Note 6 to the unaudited Consolidated Financial Statements), including with respect to the divestiture of our ADT Korea business, (iii) estimated restructuring payments, of which $111 million has been accrued as a current liability as of March 25, 2016 (see Note 4 to the unaudited Consolidated Financial Statements), (iv) quarterly dividend payments, of which $87 million has been accrued as of March 25, 2016 (see Note 13 to the unaudited Consolidated Financial Statements), and (v) merger related items. The Company intends to fund these capital uses through a combination of available cash, cash generated from operations, borrowing in the commercial paper market or under its revolving credit facility, and borrowing in public or private markets for debt securities. In addition, the Company intends, in its discretion, to pursue strategically important acquisitions, may repurchase its shares from time to time and may engage in other capital market activities, in each case depending on a number of factors, including the Company’s strategic priorities, its financial condition and results of operations, the capital requirements of the Company’s businesses, industry and capital markets factors and other relevant factors.

[0000833444-16-000172:mdna:132]
[same as prior period, unchanged from 0000833444-16-000120:mdna:112]

[0000833444-16-000172:mdna:133]
Our cash flows from operating, investing and financing from continuing operations for the six months ended March 25, 2016 and March 27, 2015 are summarized below:

[0000833444-16-000172:mdna:134]
|  | For the Six Months Ended |
| ($ in millions) | March 25, 2016 |  | March 27, 2015 |
| Net cash provided by operating activities | $ | 313 |  |  | $ | 262 |  |
| Net cash used in investing activities | (433 | ) |  | (703 | ) |
| Net cash used in financing activities | (926 | ) |  | (3 | ) |

[0000833444-16-000172:mdna:135]
[same as prior period, unchanged from 0000833444-16-000120:mdna:115]

[0000833444-16-000172:mdna:136]
Cash flow from operating activities can fluctuate significantly from period to period as working capital needs and the timing of payments for items such as restructuring activities, asbestos activities, pension funding, income taxes, merger costs and other items impact reported cash flow.

[0000833444-16-000172:mdna:137]
The net change in working capital decreased operating cash flow by $297 million in the six months ended March 25, 2016. The significant changes in working capital included a $133 million decrease in accrued and other liabilities, a $122 million decrease in tax sharing agreement, net, a $56 million increase in inventories, a $54 million increase in contracts in process, and a $30 million increase in prepaid expenses and other assets, partially offset by a $38 million decrease in accounts receivable.

[0000833444-16-000172:mdna:138]
The net change in working capital decreased operating cash flow by $311 million in the six months ended March 27, 2015. The significant changes in working capital included an $87 million decrease in accounts payable, a $66 million increase in prepaid expense and other current assets, a $64 million increase in inventories, a $56 million decrease in accrued and other liabilities, and a $30 million increase in contracts in process.

[0000833444-16-000172:mdna:139]
During the six months ended March 25, 2016 and March 27, 2015, we paid approximately $48 million and $55 million, respectively, in cash related to restructuring activities. During the six months ended March 25, 2016 and March 27, 2015, we paid approximately $35 million and $16 million, respectively, in cash related to repositioning activities.

[0000833444-16-000172:mdna:140]
During the six months ended March 25, 2016 and March 27, 2015, we made net payments related to asbestos liabilities of $10 million and $8 million, respectively.

[0000833444-16-000172:mdna:141]
During the six months ended March 25, 2016 and March 27, 2015, we made payments related to environmental remediation activities for a facility located in Marinette, Wisconsin, of $2 million and $8 million, respectively.

[0000833444-16-000172:mdna:142]
During the six months ended March 25, 2016 and March 27, 2015, we paid merger related expenses of $8 million and nil, respectively, related to the proposed merger with Johnson Controls.

[0000833444-16-000172:mdna:143]
During the six months ended March 25, 2016 and March 27, 2015, we made required contributions of $1 million and $4 million, respectively, to our U.S. pension plans and $13 million and $9 million, respectively, to our non-U.S. pension plans. We anticipate that we will contribute $3 million to our U.S. plans and $25 million to our non-U.S. plans during fiscal 2016.  During the six months ended March 25, 2016, we made voluntary contributions to our non-U.S. pension plan of $4 million.

[0000833444-16-000172:mdna:144]
Income taxes paid, net of refunds, related to continuing operations were $24 million and $65 million during the six months ended March 25, 2016 and March 27, 2015, respectively.

[0000833444-16-000172:mdna:145]
Net interest paid related to continuing operations was $52 million and $42 million for the six months ended March 25, 2016 and March 27, 2015, respectively.

[0000833444-16-000172:mdna:146]
[same as prior period, unchanged from 0000833444-16-000120:mdna:124]

[0000833444-16-000172:mdna:147]
[same as prior period, unchanged from 0000833444-16-000120:mdna:125]

[0000833444-16-000172:mdna:148]
We made capital expenditures of $143 million and $123 million for the six months ended March 25, 2016 and March 27, 2015, respectively.  The level of capital expenditures in fiscal 2016 is expected to exceed the spending levels in fiscal 2015 and is also expected to exceed depreciation expense.

[0000833444-16-000172:mdna:149]
During the six months ended March 25, 2016, total consideration for acquisitions was $314 million, which was comprised of $358 million of cash paid, including $5 million to settle pre-existing matters and $6 million for pre-paid agency commissions, net of cash acquired of $33 million, which primarily related to our additional investment in the UAE joint venture in our ROW Integrated Solutions & Services segment and the acquisition of ShopperTrak in our NA Integrated Solutions & Services and ROW Integrated Solutions & Services segments. During the six months ended March 27, 2015, we paid cash for acquisitions totaling $525 million, net of $26 million cash acquired, primarily related to acquisitions in in our ROW Integrated Solutions & Services and Global Products segments.

[0000833444-16-000172:mdna:150]
During the six months ended March 25, 2016, we had net sales and maturities of investments, including restricted investments, of $1 million. During the six months ended March 27, 2015, our time deposits of $275 million matured, and we made purchases of $288 million of investments, primarily consisting of exchange traded equity and fixed income funds, which are classified as available-for-sale investments and are restricted as to use.

[0000833444-16-000172:mdna:151]
During the six months ended March 25, 2016, our restricted cash decreased by $24 million, primarily due to the release of $14 million that was shared pursuant to the terms of a legacy class action lawsuit involving disputes with former management and a decrease of $9 million pertaining to the asbestos-related qualified settlement fund. During the six months ended March 27, 2015, our restricted cash increased by $39 million. This increase was primarily driven by an increase of $14 million pertaining to the asbestos-related qualified settlement fund, $13 million of restricted cash related to an acquisition, and $12 million of cash received from former management, which was required to be shared pursuant to the terms of a legacy class action lawsuit.

[0000833444-16-000172:mdna:152]
[same as prior period, unchanged from 0000833444-16-000120:mdna:130]

[0000833444-16-000172:mdna:153]
[same as prior period, unchanged from 0000833444-16-000120:mdna:131]

[0000833444-16-000172:mdna:154]
During the six months ended March 25, 2016, we repaid a total of approximately $1,134 million of current portion of long-term debt.  On October 14, 2015, the Company redeemed its outstanding $242 million aggregate principal amount 7.0% notes due 2019 and $462 million aggregate principal amount 6.875% notes due 2021, which were classified as current as of September 25, 2015, for total cash of $876 million, which included a make-whole premium of $172 million. Also, on October 15, 2015, the Company repaid $258 million aggregate principal amount of 3.375% notes due 2015, which matured on such date.

[0000833444-16-000172:mdna:155]
During the six months ended March 25, 2016 and March 27, 2015, we paid debt financing costs of $23 million and $4 million, respectively.

[0000833444-16-000172:mdna:156]
In addition, during the six months ended March 25, 2016, we issued commercial paper of $2,498 million, $2,098 million of which was repaid during the period. As of March 25, 2016 and September 25, 2015, TIFSA had commercial paper outstanding of $400 million and nil, respectively. The maximum aggregate amount of unsecured commercial paper notes available to be issued, on a private placement basis, under the commercial paper program is $1.5 billion as of March 25, 2016. As of March 25, 2016 and September 25, 2015, there were no amounts drawn under the Company's revolving credit facility. See Note 9 to the unaudited Consolidated Financial Statements.

[0000833444-16-000172:mdna:157]
During the six months ended March 27, 2015, TIFSA issued €500 million aggregate principal amount of public notes due 2025, which resulted in proceeds of $567 million.

[0000833444-16-000172:mdna:158]
Pursuant to our share repurchase program, we may repurchase Tyco shares from time to time in open market purchases at prevailing market prices, in negotiated transactions off the market, or pursuant to an approved trading plan in accordance with applicable regulations. During the six months ended March 25, 2016, we did not repurchase shares. During the six months ended March 27, 2015, we repurchased approximately 10 million ordinary shares for approximately $417 million.

[0000833444-16-000172:mdna:159]
During the six months ended March 25, 2016 and March 27, 2015, we paid cash dividends of approximately $174 million and $151 million, respectively.

[0000833444-16-000172:mdna:160]
During the six months ended March 27, 2015, we paid contingent consideration of $23 million which related to the successful transfer of a business license in China to Tyco. Contingent consideration paid during the six months ended March 25, 2016 was not material.

[0000833444-16-000172:mdna:161]
[same as prior period, unchanged from 0000833444-16-000120:mdna:136]

[0000833444-16-000172:mdna:162]
Commitments and Contingencies

[0000833444-16-000172:mdna:163]
For a detailed discussion of contingencies related to tax and litigation matters, see Notes 6 and 11 to the unaudited Consolidated Financial Statements.

[0000833444-16-000172:mdna:164]
[same as prior period, unchanged from 0000833444-16-000120:mdna:139]

[0000833444-16-000172:mdna:165]
We had a backlog of unfilled orders of $4,655 million and $4,562 million as of March 25, 2016 and September 25, 2015, respectively.

[0000833444-16-000172:mdna:166]
[same as prior period, unchanged from 0000833444-16-000120:mdna:141]

[0000833444-16-000172:mdna:167]
|  | NA Integrated Solutions & Services |  | ROW Integrated Solutions & Services |  | GlobalProducts |  | Total |
| As of September 25, 2015 |  |  |  |  |  |  |  |
| Backlog | $ | 1,035 |  |  | $ | 820 |  |  | $ | 195 |  |  | $ | 2,050 |  |
| Recurring revenue in force | 1,229 |  |  | 1,013 |  |  | — |  |  | 2,242 |  |
| Deferred revenue | 235 |  |  | 35 |  |  | — |  |  | 270 |  |
| Total Backlog | $ | 2,499 |  |  | $ | 1,868 |  |  | $ | 195 |  |  | $ | 4,562 |  |
| As of March 25, 2016 |  |  |  |  |  |  |  |  |  |  |  |
| Backlog | $ | 1,113 |  |  | $ | 950 |  |  | $ | 173 |  |  | $ | 2,236 |  |
| Recurring revenue in force | 1,236 |  |  | 927 |  |  | — |  |  | 2,163 |  |
| Deferred revenue | 226 |  |  | 30 |  |  | — |  |  | 256 |  |
| Total Backlog | $ | 2,575 |  |  | $ | 1,907 |  |  | $ | 173 |  |  | $ | 4,655 |  |

[0000833444-16-000172:mdna:168]
Total backlog increased $93 million, or 2.0%, to $4,655 million as of March 25, 2016 compared to $4,562 million as of September 25, 2015. Acquisitions during fiscal 2016 contributed approximately $163 million, or 3.6%, to total backlog, primarily related to our UAE business. In addition, backlog also increased in our NA Integrated Solutions & Services and ROW Integrated Solutions & Service segments. These increases were partially offset by divestitures, primarily related to our Australia fire protection business in our ROW Integrated Solutions & Services segment during fiscal 2016, which had an unfavorable impact of $101 million, or 2.2% to total backlog. In addition, changes in foreign currency had an unfavorable impact to total backlog of $71 million, or 1.6%, primarily in our ROW Integrated Solutions & Services segment.

[0000833444-16-000172:mdna:169]
[same as prior period, unchanged from 0000833444-16-000120:mdna:144]

[0000833444-16-000172:mdna:170]
[same as prior period, unchanged from 0000833444-16-000120:mdna:145]

[0000833444-16-000172:mdna:171]
There are certain guarantees or indemnifications extended among Tyco, Covidien, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 Separation and Distribution Agreements and the Tax Sharing Agreements. The guarantees primarily relate to certain contingent tax liabilities included in the Tax Sharing Agreements. At the time of the 2007 and 2012 Separations, we recorded liabilities necessary to recognize the fair value of such guarantees and indemnifications. See Note 6 to the unaudited Consolidated Financial Statements. In addition, prior to the 2007 and 2012 Separations we provided support in the form of financial and/or performance guarantees to various Covidien, TE Connectivity, ADT and Tyco Flow Control operating entities. To the extent these guarantees were not assigned in connection with the 2007 and 2012 Separations, we remained as the guarantor, but were typically indemnified by the former subsidiary. See Note 18 to the unaudited Consolidated Financial Statements.

[0000833444-16-000172:mdna:172]
In disposing of assets or businesses, we often provide representations, warranties and/or indemnities to cover various risks including, for example, unknown damage to the assets, environmental risks involved in the sale of real estate, liability to investigate and remediate environmental contamination at waste disposal sites and manufacturing facilities, and unidentified tax and other liabilities related to periods prior to disposition. We have no reason to believe that these uncertainties would have a

[0000833444-16-000172:mdna:173]
material adverse effect on our financial position, results of operations or cash flows. We have recorded liabilities for known indemnifications included as part of environmental liabilities. See Note 11 to the unaudited Consolidated Financial Statements.

[0000833444-16-000172:mdna:174]
[same as prior period, unchanged from 0000833444-16-000120:mdna:149]

[0000833444-16-000172:mdna:175]
For a detailed discussion of guarantees and indemnifications, see Note 18 to the unaudited Consolidated Financial Statements.

[0000833444-16-000172:mdna:176]
[same as prior period, unchanged from 0000833444-16-000120:mdna:151]

[0000833444-16-000172:mdna:177]
In an effort to provide investors with additional information regarding our results as determined by U.S. GAAP, we also disclose the non-U.S. GAAP measure of organic revenue growth (decline). We believe that this measure is useful to investors in evaluating our operating performance for the periods presented. When read in conjunction with our U.S. GAAP revenue, it enables investors to better evaluate our operations without giving effect to fluctuations in foreign exchange rates and acquisition and divestiture activity, either of which may be significant from period to period. In addition, organic revenue growth (decline) is a factor we use in internal evaluations of the overall performance of our business. This measure is not a financial measure under U.S. GAAP and should not be considered as a substitute for revenue as determined in accordance with U.S. GAAP, and it may not be comparable to similarly titled measures reported by other companies. Organic revenue growth (decline) presented herein is defined as revenue growth (decline) excluding the effects of foreign currency fluctuations, acquisitions and divestitures and other changes that may not reflect underlying results and trends. Our organic growth (decline) calculations incorporate an estimate of prior year reported net revenue associated with acquired entities that have been fully integrated within the first year, and exclude prior year net revenue associated with entities that do not meet the criteria for discontinued operations which have been divested within the past year ("adjusted number"). We calculate the rate of organic growth (decline) based on the adjusted number to better reflect the rate of growth (decline) of the combined business, in the case of acquisitions, or the remaining business, in the case of dispositions. We base the rate of organic growth (decline) for acquired businesses that are not fully integrated within the first year upon unadjusted historical net revenue.  Foreign currency fluctuations are calculated by subtracting (i) the U.S. dollar equivalent of local currencies for the current period using monthly weighted average exchange rates for the prior period from (ii) the U.S. dollar equivalent of local currencies for the current period using monthly weighted average exchange rates for the current period. We may use organic revenue growth (decline) as a component of our compensation programs.

[0000833444-16-000172:mdna:178]
[same as prior period, unchanged from 0000833444-16-000120:mdna:154]

[0000833444-16-000172:mdna:179]
Quarter Ended March 25, 2016

[0000833444-16-000172:mdna:180]
|  | Net Revenue for the Quarter Ended March 27, 2015 |  | Base YearAdjustmentsDivestitures / Other |  | AdjustedFiscal 2015Base Revenue |  | ForeignCurrency |  | Acquisitions |  | OrganicRevenue |  | OrganicGrowth (Decline)Percentage(1) |  | Net Revenue for the Quarter Ended March 25, 2016 |
|  | ($ in millions) |
| NA Integrated Solutions & Services | $ | 944 |  |  | $ | — |  |  | $ | 944 |  |  | $ | (10 | ) |  | $ | 9 |  |  | $ | 4 |  |  | 0.4 | % |  | $ | 947 |  |
| ROW Integrated Solutions & Services | 847 |  |  | (62 | ) |  | 785 |  |  | (73 | ) |  | 64 |  |  | (8 | ) |  | (1.0 | )% |  | 768 |  |
| Global Products | 639 |  |  | (3 | ) |  | 636 |  |  | (18 | ) |  | 17 |  |  | (19 | ) |  | (3.0 | )% |  | 616 |  |
| Total Net Revenue | $ | 2,430 |  |  | $ | (65 | ) |  | $ | 2,365 |  |  | $ | (101 | ) |  | $ | 90 |  |  | $ | (23 | ) |  | (1.0 | )% |  | $ | 2,331 |  |

[0000833444-16-000172:mdna:181]
[same as prior period, unchanged from 0000833444-16-000120:mdna:157]

[0000833444-16-000172:mdna:182]
64

[0000833444-16-000172:mdna:183]
Six Months Ended March 25, 2016

[0000833444-16-000172:mdna:184]
|  | Net Revenue for the Six Months Ended March 27, 2015 |  | Base YearAdjustmentsDivestitures / Other |  | AdjustedFiscal 2015Base Revenue |  | ForeignCurrency |  | Acquisitions |  | OrganicRevenue |  | OrganicGrowth (Decline)Percentage(1) |  | Net Revenue for the Six Months Ended March 25, 2016 |
|  | ($ in millions) |
| NA Integrated Solutions & Services | $ | 1,895 |  |  | $ | — |  |  | $ | 1,895 |  |  | $ | (26 | ) |  | $ | 12 |  |  | $ | 19 |  |  | 1.0 | % |  | $ | 1,900 |  |
| ROW Integrated Solutions & Services | 1,763 |  |  | (84 | ) |  | 1,679 |  |  | (174 | ) |  | 93 |  |  | (18 | ) |  | (1.1 | )% |  | 1,580 |  |
| Global Products | 1,250 |  |  | (4 | ) |  | 1,246 |  |  | (53 | ) |  | 56 |  |  | (22 | ) |  | (1.8 | )% |  | 1,227 |  |
| Total Net Revenue | $ | 4,908 |  |  | $ | (88 | ) |  | $ | 4,820 |  |  | $ | (253 | ) |  | $ | 161 |  |  | $ | (21 | ) |  | (0.4 | )% |  | $ | 4,707 |  |

[0000833444-16-000172:mdna:185]
| (1) | Organic revenue growth (decline) percentage based on adjusted fiscal 2015 base revenue. |

[0000833444-16-000172:mdna:186]
[same as prior period, unchanged from 0000833444-16-000120:mdna:163]

[0000833444-16-000172:mdna:187]
[same as prior period, unchanged from 0000833444-16-000120:mdna:164]

[0000833444-16-000172:mdna:188]
[same as prior period, unchanged from 0000833444-16-000120:mdna:165]

[0000833444-16-000172:mdna:189]
[same as prior period, unchanged from 0000833444-16-000120:mdna:166]

[0000833444-16-000172:mdna:190]
[same as prior period, unchanged from 0000833444-16-000120:mdna:167]

[0000833444-16-000172:mdna:191]
| • | the outcome of litigation, arbitrations and governmental proceedings; |

[0000833444-16-000172:mdna:192]
| • | effect of income tax audits, litigation, settlements and appeals; |

[0000833444-16-000172:mdna:193]
[same as prior period, unchanged from 0000833444-16-000120:mdna:170]

[0000833444-16-000172:mdna:194]
[same as prior period, unchanged from 0000833444-16-000120:mdna:171]

[0000833444-16-000172:mdna:195]
[same as prior period, unchanged from 0000833444-16-000120:mdna:172]

[0000833444-16-000172:mdna:196]
[same as prior period, unchanged from 0000833444-16-000120:mdna:173]

[0000833444-16-000172:mdna:197]
[same as prior period, unchanged from 0000833444-16-000120:mdna:174]

[0000833444-16-000172:mdna:198]
[same as prior period, unchanged from 0000833444-16-000120:mdna:175]

[0000833444-16-000172:mdna:199]
[same as prior period, unchanged from 0000833444-16-000120:mdna:176]

[0000833444-16-000172:mdna:200]
[same as prior period, unchanged from 0000833444-16-000120:mdna:177]

[0000833444-16-000172:mdna:201]
[same as prior period, unchanged from 0000833444-16-000120:mdna:178]

[0000833444-16-000172:mdna:202]
[same as prior period, unchanged from 0000833444-16-000120:mdna:179]

[0000833444-16-000172:mdna:203]
[same as prior period, unchanged from 0000833444-16-000120:mdna:180]

[0000833444-16-000172:mdna:204]
[same as prior period, unchanged from 0000833444-16-000120:mdna:181]

[0000833444-16-000172:mdna:205]
[same as prior period, unchanged from 0000833444-16-000120:mdna:183]

[0000833444-16-000172:mdna:206]
65

[0000833444-16-000172:mdna:207]
[same as prior period, unchanged from 0000833444-16-000120:mdna:184]

[0000833444-16-000172:mdna:208]
[same as prior period, unchanged from 0000833444-16-000120:mdna:185]

[0000833444-16-000172:mdna:209]
| • | natural events such as severe weather, fires, floods and earthquakes; |

[0000833444-16-000172:mdna:210]
| • | acts of terrorism, cyber-attacks or our inability to maintain adequate security related information networks and data; |

[0000833444-16-000172:mdna:211]
| • | our ability to complete the proposed combination with Johnson Controls on anticipated terms and timing, including obtaining shareholder and regulatory approvals, anticipated tax treatment, unforeseen liabilities, future capital expenditures, revenues, expenses, earnings, synergies, economic performance, indebtedness, financial condition, losses, future prospects, business and management strategies for the management, expansion and growth of the new combined company’s operations; and |

[0000833444-16-000172:mdna:212]
| • | assuming the proposed merger with Johnson Controls is completed, the ability of us and Johnson Controls to integrate our businesses successfully and to achieve anticipated synergies, changes in tax laws or interpretations, access to available financing, potential litigation relating to the proposed transaction, and the risk that disruptions from the proposed transaction will harm our business. |
