# JCI 8-K — 0000833444-16-000167 filed 2016-04-29

## item codes, every 8-K on or before 2016-04-29

- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2016-04-29

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-16-000167:8k_2_02:1]
EX-99.1
2
exhibit991-q216.htm
EXHIBIT 99.1

[0000833444-16-000167:8k_2_02:2]
8-K

[0000833444-16-000167:8k_2_02:3]
| Investor Contacts: |  | Media Contact: |  |
| Antonella Franzen |  | Stephen Wasdick |  |
| +1-609-720-4665 |  | +1-609-806-2262 |  |
| afranzen@tyco.com |  | swasdick@tyco.com |  |
| Ryan Edelman |  |  |  |
| +1-609-720-4545 |  |  |  |
| redelman@tyco.com |  |  |  |

[0000833444-16-000167:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-16-000167:8k_2_02:5]
TYCO REPORTS SECOND QUARTER 2016 EARNINGS FROM CONTINUING OPERATIONS

[0000833444-16-000167:8k_2_02:6]
BEFORE SPECIAL ITEMS OF $0.45 PER SHARE AND GAAP EARNINGS OF $0.33 PER SHARE

[0000833444-16-000167:8k_2_02:7]
| • | Confirms that plans are on track for its strategic merger with Johnson Controls to create a global leader in building products and technology, integrated solutions and energy storage |

[0000833444-16-000167:8k_2_02:8]
| • | Enhances business portfolio with acquisition of ShopperTrak to expand retail analytics solutions, and divestiture of Australian fire detection and protection business |

[0000833444-16-000167:8k_2_02:9]
| • | Expands pipeline with 7% orders growth in the quarter, and backlog increases 2% on quarter sequential basis, both excluding the impact of foreign currency and divestitures |

[0000833444-16-000167:8k_2_02:10]
| • | Achieves 126% adjusted free cash flow conversion rate in the quarter |

[0000833444-16-000167:8k_2_02:11]
| • | Provides guidance for third quarter 2016 EPS before special items of $0.52 - $0.54 |

[0000833444-16-000167:8k_2_02:12]
| • | Tightens guidance range for full-year EPS before special items to $2.05 - $2.10 from previous $2.05 - $2.20 |

[0000833444-16-000167:8k_2_02:13]
CORK, Ireland, April 29, 2016 - Tyco (NYSE: TYC) today reported $0.33 in GAAP diluted earnings per share (EPS) from continuing operations for the fiscal second quarter of 2016 and diluted EPS from continuing operations before special items of $0.45, compared to previous guidance of $0.44 to $0.46.  Revenue of $2.3 billion in the quarter decreased 4% versus the prior year, primarily due to a 4% negative impact of the stronger U.S. dollar against foreign currencies.  Organic revenue declined 1% in the quarter, with acquisitions contributing 4 percentage points of growth, which was partially offset by a 3 percentage point impact related to divestitures.

[0000833444-16-000167:8k_2_02:14]
"I am pleased with the progress on our planned merger with Johnson Controls to create the global leader in building products and technology, integrated solutions and energy storage," said Tyco Chief Executive Officer George R. Oliver.  "Our integration teams are making great strides, and I am more excited and confident than ever about the value creation potential of the merger for customers, shareholders and employees."

[0000833444-16-000167:8k_2_02:15]
“While ongoing sluggish economic conditions in key sectors put pressure on our short-cycle product markets in the second quarter, our continued focus on productivity initiatives enabled our Integrated Solutions & Services teams to deliver better than expected margin performance.  We have made significant improvements in the fundamentals of our business.  We are investing for future growth through a dedicated focus on service and installation within our North American fire and security business, continued product innovation and our commercial excellence initiatives.  As a result of these initiatives, our order pipeline and backlog continue to build, which positions us well for increased growth in the second half," Mr. Oliver added.

[0000833444-16-000167:8k_2_02:16]
(Income and EPS amounts are attributable to Tyco ordinary shareholders)

[0000833444-16-000167:8k_2_02:17]
($ millions, except per-share amounts)

[0000833444-16-000167:8k_2_02:18]
|  |  | Q2 2016 |  | Q2 2015 |  | % Change |  |
| Revenue |  | $ | 2,331 |  |  | $ | 2,430 |  |  | (4 | )% |  |
| Segment Operating Income |  | $ | 289 |  |  | $ | 306 |  |  | (6 | )% |  |
| Restructuring and Repositioning |  | $ | (10 | ) |  | $ | (29 | ) |  | (66 | )% |  |
| Operating Income |  | $ | 225 |  |  | $ | 221 |  |  | 2 | % |  |
| Income from Continuing Operations |  | $ | 145 |  |  | $ | 183 |  |  | (21 | )% |  |
| GAAP Diluted EPS from Continuing Operations |  | $ | 0.33 |  |  | $ | 0.43 |  |  | (23 | )% |  |
| Special Items |  | $ | 0.12 |  |  | $ | 0.07 |  |  |  |  |
| Segment Operating Income Before Special Items |  | $ | 311 |  |  | $ | 331 |  |  | (6 | )% |  |
| Restructuring and Repositioning Before Special Items |  | $ | (16 | ) |  | $ | (29 | ) |  | (45 | )% |  |
| Income from Continuing Ops Before Special Items |  | $ | 192 |  |  | $ | 215 |  |  | (11 | )% |  |
| Diluted EPS from Continuing Ops Before Special Items |  | $ | 0.45 |  |  | $ | 0.50 |  |  | (10 | )% |  |

[0000833444-16-000167:8k_2_02:19]
Organic revenue, free cash flow, adjusted free cash flow, operating income, segment operating income, and diluted EPS from continuing operations before special items are non-GAAP financial measures and are described below.  For a reconciliation of these non-GAAP measures, see the attached tables. Additional schedules as well as second quarter review slides can be found in the Investor Relations section of Tyco’s website at http://investors.tyco.com.

[0000833444-16-000167:8k_2_02:20]
SEGMENT RESULTS

[0000833444-16-000167:8k_2_02:21]
The financial results presented in the tables below are in accordance with GAAP unless otherwise indicated.  All dollar amounts are pre-tax and stated in millions.  All comparisons are to the fiscal second quarter of 2015 unless otherwise indicated.

[0000833444-16-000167:8k_2_02:22]
North America Integrated Solutions & Services

[0000833444-16-000167:8k_2_02:23]
|  |  | Q2 2016 |  | Q2 2015 |  | % Change |  |
| Revenue |  | $ | 947 |  |  | $ | 944 |  |  | — | % |  |
| Operating Income |  | $ | 131 |  |  | $ | 125 |  |  | 5 | % |  |
| Operating Margin |  | 13.8 | % |  | 13.2 | % |  |  |  |
| Special Items |  | $ | — |  |  | $ | — |  |  |  |  |
| Operating Income Before Special Items |  | $ | 131 |  |  | $ | 125 |  |  | 5 | % |  |
| Operating Margin Before Special Items |  | 13.8 | % |  | 13.2 | % |  |  |  |

[0000833444-16-000167:8k_2_02:24]
Revenue of $947 million was up slightly compared to the prior year.  Modest organic revenue growth was driven by 1% growth in integrated solutions and flat service revenue.  Acquisition growth of 1% was offset by the weakening of the Canadian dollar.  Backlog of $2.57 billion increased 4% year over year and 2% on a quarter sequential basis, excluding the impact of foreign currency.

[0000833444-16-000167:8k_2_02:25]
Operating income for the quarter was $131 million and the operating margin before special items improved 60 basis points to 13.8%, including a 20 basis point headwind related to non-cash purchase accounting.  Underlying operations improved 80 basis points, driven by improved execution and productivity benefits.

[0000833444-16-000167:8k_2_02:26]
Rest of World Integrated Solutions & Services

[0000833444-16-000167:8k_2_02:27]
|  |  | Q2 2016 |  | Q2 2015 |  | % Change |  |
| Revenue |  | $ | 768 |  |  | $ | 847 |  |  | (9 | )% |  |
| Operating Income |  | $ | 57 |  |  | $ | 67 |  |  | (15 | )% |  |
| Operating Margin |  | 7.4 | % |  | 7.9 | % |  |  |  |
| Special Items |  | $ | (20 | ) |  | $ | (23 | ) |  |  |  |
| Operating Income Before Special Items |  | $ | 77 |  |  | $ | 90 |  |  | (14 | )% |  |
| Operating Margin Before Special Items |  | 10.0 | % |  | 10.6 | % |  |  |  |

[0000833444-16-000167:8k_2_02:28]
Revenue of $768 million decreased 9% compared to the prior year, driven by a 9% unfavorable impact from foreign currency exchange rates.  Organic revenue declined 1%, as 1% growth in service was more than offset by a 3% decline in integrated solutions.  Acquisition growth of 8% was mostly offset by a 7% decline related to divestitures.  Backlog of $1.91 billion increased 13% year over year, partly driven by acquisition activity, and 3% on a quarter sequential basis, excluding the impact of foreign currency and divestitures.

[0000833444-16-000167:8k_2_02:29]
Operating income for the quarter was $57 million and the operating margin was 7.4%.  Special items of $20 million consisted primarily of a loss on divestitures.  Before special items, operating income was $77 million and the operating margin was 10.0%.  The operating margin declined 60 basis points, including a 40 basis point impact related to non-cash purchase accounting.  Underlying operations declined 20 basis points driven by the mix of revenue decline, partially offset by productivity benefits.

[0000833444-16-000167:8k_2_02:30]
Global Products

[0000833444-16-000167:8k_2_02:31]
|  |  | Q2 2016 |  | Q2 2015 |  | % Change |  |
| Revenue |  | $ | 616 |  |  | $ | 639 |  |  | (4 | )% |  |
| Operating Income |  | $ | 101 |  |  | $ | 114 |  |  | (11 | )% |  |
| Operating Margin |  | 16.4 | % |  | 17.8 | % |  |  |  |
| Special Items |  | $ | (2 | ) |  | $ | (2 | ) |  |  |  |
| Operating Income Before Special Items |  | $ | 103 |  |  | $ | 116 |  |  | (11 | )% |  |
| Operating Margin Before Special Items |  | 16.7 | % |  | 18.2 | % |  |  |  |

[0000833444-16-000167:8k_2_02:32]
Revenue of $616 million decreased 4% compared to the prior year.  Organic revenue declined 3%, driven by Life Safety Products due to increased Air-Pak X3 shipments during the comparable quarter in the prior year, as well as softness in Fire Protection Products related to the high-hazard heavy industrial sector.  Acquisitions contributed 3 percentage points of growth, which was fully offset by changes in foreign currency exchange rates.  A divestiture negatively impacted revenue by 1%.

[0000833444-16-000167:8k_2_02:33]
Operating income for the quarter was $101 million and the operating margin was 16.4%.  Before special items, operating income was $103 million and the operating margin was 16.7%.  The 150 basis point decline in operating margin included a 50 basis point headwind related to non-cash purchase accounting.  The underlying margin decline of 100 basis points was driven by the decline in revenue and a lower mix of higher-margin products.

[0000833444-16-000167:8k_2_02:34]
OTHER ITEMS

[0000833444-16-000167:8k_2_02:35]
| • | Cash from operating activities was $124 million and free cash flow was $46 million, which included a cash outflow of $196 million from special items primarily related to the IRS litigation and prior year restructuring and repositioning activities. Adjusted free cash flow for the quarter was $242 million representing an adjusted free cash flow conversion rate of 126% for the second quarter and 111% for the six months ending March 25, 2016. The company completed the quarter with $345 million in cash and cash equivalents. |

[0000833444-16-000167:8k_2_02:36]
| • | Corporate expense for the quarter was $46 million before special items and $54 million on a GAAP basis. |

[0000833444-16-000167:8k_2_02:37]
| • | Restructuring and repositioning charges were $16 million before the reversal of $6 million of prior-period charges treated as special items, compared to $29 million for the prior year period. |

[0000833444-16-000167:8k_2_02:38]
| • | The tax rate before special items was 17.3% for the quarter. |

[0000833444-16-000167:8k_2_02:39]
| • | As disclosed on April 21, Tyco and Johnson Controls confirmed their merger plans and that the combined company expects to deliver $650 million in operational and global tax synergies over the first three years after closing. The transaction, which is subject to customary closing conditions, including regulatory approvals and approval by both Johnson Controls and Tyco shareholders, is expected to be completed on or around October 1, 2016. |

[0000833444-16-000167:8k_2_02:40]
| • | As previously announced, during the quarter the company completed the acquisition of ShopperTrak, a leading global provider of retail traffic insights and location-based analytics, for approximately $175 million in cash. This business currently generates approximately $75 million in annual revenue. |

[0000833444-16-000167:8k_2_02:41]
| • | As previously announced, during the quarter the company divested its fire detection and protection business in Australia. In fiscal year 2015, this business had revenue of approximately $260 million. |

[0000833444-16-000167:8k_2_02:42]
ABOUT TYCO

[0000833444-16-000167:8k_2_02:43]
Tyco (NYSE: TYC) is the world’s largest pure-play fire protection and security company. Tyco provides more than three million customers around the globe with the latest fire protection and security products and services. Tyco has over 57,000 employees in more than 900 locations across 50 countries serving various end markets, including commercial, institutional, governmental, retail, industrial, energy, residential and small business. For more information, visit www.tyco.com.

[0000833444-16-000167:8k_2_02:44]
CONFERENCE CALL AND WEBCAST

[0000833444-16-000167:8k_2_02:45]
Management will discuss the company’s second quarter results for 2016 during a conference call and webcast today beginning at 8:00 a.m. Eastern time (ET).  Today’s conference call for investors can be accessed in the following ways:

[0000833444-16-000167:8k_2_02:46]
| • | Live via webcast - through the Investor Relations section of Tyco’s website at http://investors.tyco.com, |

[0000833444-16-000167:8k_2_02:47]
| • | Live via telephone (for “listen-only” participants and those who would like to ask a question) - by dialing 800-857-9797 (in the United States) or 517-308-9029 (outside the United States), passcode “Tyco”, |

[0000833444-16-000167:8k_2_02:48]
| • | Replay via telephone - by dialing 888-568-0738 (in the United States) or 402-998-1493 (outside the United States), passcode 2577, from 10:00 a.m. (ET) on April 29, 2016, until 11:59 p.m. (ET) on May 6, 2016, and |

[0000833444-16-000167:8k_2_02:49]
| • | Replay via webcast - through the “Presentations & Webcasts” link on the Investor Relations section of Tyco’s website: http://investors.tyco.com. |

[0000833444-16-000167:8k_2_02:50]
NON-GAAP MEASURES

[0000833444-16-000167:8k_2_02:51]
Organic revenue, free cash flow (outflow) (FCF), and income from continuing operations, earnings per share (EPS) from continuing operations, operating income and segment operating income, in each case “before special items,” are non-GAAP measures and should not be considered replacements for GAAP results.

[0000833444-16-000167:8k_2_02:52]
Organic revenue is a useful measure used by the company to measure the underlying results and trends in the business. The difference between reported net revenue (the most comparable GAAP measure) and organic revenue (the non-GAAP measure) consists of the impact from foreign currency, acquisitions and divestitures, and other changes that either do not reflect the underlying results and trends of the Company’s businesses or are not completely under management’s control. There are limitations associated with organic revenue, such as the fact that, as presented herein, the metric may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using organic revenue in combination with the GAAP numbers. Organic revenue may be used as a component in the company’s incentive compensation plans.

[0000833444-16-000167:8k_2_02:53]
FCF is a useful measure of the company's cash that permits management and investors to gain insight into the number that management employs to measure cash that is free from any significant existing obligation and is available to service debt and make investments. The difference between Cash Flows from Operating Activities (the most comparable GAAP measure) and FCF (the non-GAAP measure) consists mainly of significant cash flows that the company believes are useful to identify. It, or a measure that is based on it, may be used as a component in the company's incentive compensation plans. The difference reflects the impact from:

[0000833444-16-000167:8k_2_02:54]
| • | net capital expenditures, |

[0000833444-16-000167:8k_2_02:55]
| • | dealer generated accounts and bulk accounts purchased, |

[0000833444-16-000167:8k_2_02:56]
| • | cash paid for purchase accounting and holdback liabilities, and |

[0000833444-16-000167:8k_2_02:57]
| • | voluntary pension contributions. |

[0000833444-16-000167:8k_2_02:58]
Capital expenditures and dealer generated and bulk accounts purchased are subtracted because they represent long-term investments that are required for normal business activities. Cash paid for purchase accounting and holdback liabilities is subtracted because these cash outflows are not available for general corporate uses. Voluntary pension contributions are added because this activity is driven by economic financing decisions rather than operating activity. In addition, the company presents adjusted free cash flow, which is free cash flow, adjusted to exclude the cash impact of the special items highlighted below. This number provides information to investors regarding the cash impact of certain items management believes are useful to identify, as described below.

[0000833444-16-000167:8k_2_02:59]
The limitation associated with using these cash flow metrics is that they adjust for cash items that are ultimately within management's and the Board of Directors' discretion to direct and therefore may imply that there is less or more cash that is available for the company's programs than the most comparable GAAP measure. Furthermore, these non-GAAP metrics may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using FCF in combination with the GAAP cash flow numbers.

[0000833444-16-000167:8k_2_02:60]
The company has presented its income and EPS from continuing operations, operating income and segment operating income before special items. Special items include charges and gains related to divestitures, acquisitions, restructurings, impairments, certain changes to accounting methodologies, legacy legal and tax charges and other income or charges that may mask the underlying operating results and/or business trends of the company or business segment, as applicable. The company utilizes these measures to assess overall operating performance and segment level core operating performance, as well as to provide insight to management in evaluating overall and segment operating plan execution and underlying market conditions. The Company also presents its effective tax rate as adjusted for special items for consistency, and presents corporate expense excluding special items. One or more of these measures may be used as components in the company's incentive compensation plans. These measures are useful for investors because they may permit more meaningful comparisons of the company's underlying operating results and business trends between periods. The difference between income and EPS from continuing operations before special items and income and EPS from continuing operations (the most comparable GAAP measures) consists of the impact of the special items noted above on the applicable GAAP measure. The limitation of these measures is that they exclude the impact (which may be material) of items that increase or decrease the company's reported GAAP metrics, and these non-GAAP metrics may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using the non-GAAP measures in combination with the most comparable GAAP measures in order to better understand the amounts, character and impact of any increase or decrease on reported results.

[0000833444-16-000167:8k_2_02:61]
The company provides general corporate services to its segments and those costs are reported in the "Corporate and Other" segment. This segment's operating income (loss) is presented as "Corporate Expense." Segment Operating Income represents Tyco’s operating income excluding the Corporate and Other segment, and reflects the results of Tyco’s three operating segments. Segment Operating Income before special items reflects GAAP operating income adjusted for the special items noted in the paragraph above.

[0000833444-16-000167:8k_2_02:62]
NO OFFER OR SOLICITATION

[0000833444-16-000167:8k_2_02:63]
This communication is not intended to and does not constitute an offer to sell or the solicitation of an offer to subscribe for or buy or an invitation to purchase or subscribe for any securities or the solicitation of any

[0000833444-16-000167:8k_2_02:64]
vote or approval in any jurisdiction, nor shall there be any sale, issuance or transfer of securities in any jurisdiction in contravention of applicable law.

[0000833444-16-000167:8k_2_02:65]
ADDITIONAL INFORMATION AND WHERE TO FIND IT

[0000833444-16-000167:8k_2_02:66]
In connection with the proposed transaction between Johnson Controls, Inc. (“Johnson Controls”) and Tyco International plc (“Tyco”), Tyco has filed with the U.S. Securities and Exchange Commission (the “SEC”) a registration statement on Form S-4 that includes a preliminary joint proxy statement of Johnson Controls and Tyco that also constitutes a preliminary prospectus of Tyco (the “Joint Proxy Statement/Prospectus”). These materials are not yet final and will be amended. Johnson Controls and Tyco plan to mail to their respective shareholders the definitive Joint Proxy Statement/Prospectus in connection with the transaction after the registration statement has become effective. INVESTORS AND SECURITY HOLDERS OF JOHNSON CONTROLS AND TYCO ARE URGED TO READ THE JOINT PROXY STATEMENT/PROSPECTUS AND OTHER RELEVANT DOCUMENTS FILED OR TO BE FILED WITH THE SEC CAREFULLY WHEN THEY BECOME AVAILABLE BECAUSE THEY WILL CONTAIN IMPORTANT INFORMATION ABOUT JOHNSON CONTROLS, TYCO, THE TRANSACTION AND RELATED MATTERS. Investors and security holders will be able to obtain free copies of the Joint Proxy Statement/Prospectus and other documents filed with the SEC by Johnson Controls and Tyco through the website maintained by the SEC at www.sec.gov. In addition, investors and security holders will be able to obtain free copies of the documents filed with the SEC by Johnson Controls by contacting Johnson Controls Shareholder Services at Shareholder.Services@jci.com or by calling (800) 524-6220 and will be able to obtain free copies of the documents filed with the SEC by Tyco by contacting Tyco Investor Relations at Investorrelations@Tyco.com or by calling (609) 720-4333.

[0000833444-16-000167:8k_2_02:67]
PARTICIPANTS IN THE SOLICITATION

[0000833444-16-000167:8k_2_02:68]
Johnson Controls, Tyco and certain of their respective directors, executive officers and employees may be considered participants in the solicitation of proxies in connection with the proposed transaction. Information regarding the persons who may, under the rules of the SEC, be deemed participants in the solicitation of the respective shareholders of Johnson Controls and Tyco in connection with the proposed transactions, including a description of their direct or indirect interests, by security holdings or otherwise, will be set forth in the Joint Proxy Statement/Prospectus when it is filed with the SEC. Information regarding Johnson Controls’ directors and executive officers is contained in Johnson Controls’ proxy statement for its 2016 annual meeting of shareholders, which was filed with the SEC on December 14, 2015. Information regarding Tyco’s directors and executive officers is contained in Tyco’s proxy statement for its 2016 annual meeting of shareholders, which was filed with the SEC on January 15, 2016.

[0000833444-16-000167:8k_2_02:69]
FORWARD-LOOKING STATEMENTS

[0000833444-16-000167:8k_2_02:70]
This press release contains a number of forward-looking statements. In many cases forward-looking statements are identified by words, and variations of words, such as "anticipate", "estimate", "believe", "commit", "confident", "continue", "could", "intend", "may", "plan", "potential", "predict", "positioned", "should", "will", "expect", "objective", "projection", "forecast", "goal", "guidance", "outlook", "effort", "target", and other similar words. However, the absence of these words does not mean the statements are not forward-looking. Examples of forward-looking statements include, but are not limited to, revenue, operating income, earnings per share and other financial projections, statements regarding the health and growth prospects of the industries and end markets in which Tyco operates, the leadership, resources, potential, priorities, and opportunities for Tyco in the future, Tyco's credit profile, capital allocation priorities and other capital market related activities, statements regarding Tyco's acquisition, divestiture, restructuring and other productivity initiatives, and statements regarding Tyco’s proposed merger with Johnson Controls and related transactions.

[0000833444-16-000167:8k_2_02:71]
STATEMENT REQUIRED BY THE IRISH TAKEOVER RULES

[0000833444-16-000167:8k_2_02:72]
The directors of Tyco International plc accept responsibility for the information contained in this communication.  To the best of their knowledge and belief (having taken all reasonable care to ensure such is the case), the information contained in this communication is in accordance with the facts and does not omit anything likely to affect the import of such information.

[0000833444-16-000167:8k_2_02:73]
NOT FOR RELEASE, PUBLICATION OR DISTRIBUTION, IN WHOLE OR IN PART, IN, INTO OR FROM ANY JURISDICTION WHERE TO DO SO WOULD CONSTITUTE A VIOLATION OF THE RELEVANT LAWS OR REGULATIONS OF SUCH JURISDICTION.

[0000833444-16-000167:8k_2_02:74]
This communication is not intended to be and is not a prospectus for the purposes of Part 23 of the Companies Act 2014 of Ireland (the “2014 Act”), Prospectus (Directive 2003/71/EC) Regulations 2005 (S.I. No. 324 of 2005) of Ireland (as amended from time to time) or the Prospectus Rules issued by the Central Bank of Ireland pursuant to section 1363 of the 2014 Act, and the Central Bank of Ireland (“CBI”) has not approved this communication.

[0000833444-16-000167:8k_2_02:75]
# # #

[0000833444-16-000167:8k_2_02:76]
TYCO INTERNATIONAL PLC

[0000833444-16-000167:8k_2_02:77]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0000833444-16-000167:8k_2_02:78]
(in millions, except per share data)

[0000833444-16-000167:8k_2_02:79]
(Unaudited)

[0000833444-16-000167:8k_2_02:80]
|  | Quarters Ended |  | Six Months Ended |
|  | March 25, 2016 |  | March 27, 2015 |  | March 25, 2016 |  | March 27, 2015 |
| Revenue from product sales | $ | 1,398 |  |  | $ | 1,458 |  |  | $ | 2,806 |  |  | $ | 2,946 |  |
| Service revenue | 933 |  |  | 972 |  |  | 1,901 |  |  | 1,962 |  |
| Net revenue | 2,331 |  |  | 2,430 |  |  | 4,707 |  |  | 4,908 |  |
| Cost of product sales | 968 |  |  | 999 |  |  | 1,930 |  |  | 2,021 |  |
| Cost of services | 506 |  |  | 550 |  |  | 1,042 |  |  | 1,097 |  |
| Selling, general and administrative expenses | 602 |  |  | 648 |  |  | 1,175 |  |  | 1,300 |  |
| Merger costs | 26 |  |  | — |  |  | 26 |  |  | — |  |
| Restructuring and asset impairment charges, net | 4 |  |  | 12 |  |  | 16 |  |  | 70 |  |
| Operating income | 225 |  |  | 221 |  |  | 518 |  |  | 420 |  |
| Interest income | 4 |  |  | 4 |  |  | 8 |  |  | 7 |  |
| Interest expense | (22 | ) |  | (25 | ) |  | (46 | ) |  | (49 | ) |
| Other (expense) income, net | — |  |  | (1 | ) |  | (165 | ) |  | 3 |  |
| Income from continuing operations before income taxes | 207 |  |  | 199 |  |  | 315 |  |  | 381 |  |
| Income tax expense | (63 | ) |  | (18 | ) |  | (99 | ) |  | (37 | ) |
| Income from continuing operations | 144 |  |  | 181 |  |  | 216 |  |  | 344 |  |
| Income (loss) from discontinued operations, net of income taxes | 1 |  |  | (16 | ) |  | 5 |  |  | (18 | ) |
| Net income | 145 |  |  | 165 |  |  | 221 |  |  | 326 |  |
| Less: noncontrolling interest in subsidiaries net loss | (1 | ) |  | (2 | ) |  | (1 | ) |  | (3 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 146 |  |  | $ | 167 |  |  | $ | 222 |  |  | $ | 329 |  |
| Amounts attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 145 |  |  | $ | 183 |  |  | $ | 217 |  |  | $ | 347 |  |
| Income (loss) from discontinued operations | 1 |  |  | (16 | ) |  | 5 |  |  | (18 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 146 |  |  | $ | 167 |  |  | $ | 222 |  |  | $ | 329 |  |
| Basic earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 0.34 |  |  | $ | 0.44 |  |  | $ | 0.51 |  |  | $ | 0.83 |  |
| (Loss) income from discontinued operations | — |  |  | (0.04 | ) |  | 0.01 |  |  | (0.05 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 0.34 |  |  | $ | 0.40 |  |  | $ | 0.52 |  |  | $ | 0.78 |  |
| Diluted earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 0.33 |  |  | $ | 0.43 |  |  | $ | 0.51 |  |  | $ | 0.81 |  |
| Income (loss) from discontinued operations | 0.01 |  |  | (0.04 | ) |  | 0.01 |  |  | (0.04 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 0.34 |  |  | $ | 0.39 |  |  | $ | 0.52 |  |  | $ | 0.77 |  |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |  |  |
| Basic | 425 |  |  | 420 |  |  | 424 |  |  | 420 |  |
| Diluted | 428 |  |  | 427 |  |  | 428 |  |  | 427 |  |

[0000833444-16-000167:8k_2_02:81]
Note: These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K filed on November 13, 2015 and Form 8-K filed on March 11, 2016 for the fiscal year ended September 25, 2015.

[0000833444-16-000167:8k_2_02:82]
TYCO INTERNATIONAL PLC

[0000833444-16-000167:8k_2_02:83]
RESULTS OF SEGMENTS

[0000833444-16-000167:8k_2_02:84]
(in millions)

[0000833444-16-000167:8k_2_02:85]
(Unaudited)

[0000833444-16-000167:8k_2_02:86]
|  |  | Quarters Ended |  |  |  | Six Months Ended |  |  |
|  |  | March 25, 2016 |  |  |  | March 27, 2015 |  |  |  | March 25, 2016 |  |  |  | March 27, 2015 |  |  |
| Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| NA Integrated Solutions & Services |  | $ | 947 |  |  |  |  |  | $ | 944 |  |  |  |  |  | $ | 1,900 |  |  |  |  |  | $ | 1,895 |  |  |  |  |
| ROW Integrated Solutions & Services |  | 768 |  |  |  |  |  | 847 |  |  |  |  |  | 1,580 |  |  |  |  |  | 1,763 |  |  |  |  |
| Global Products |  | 616 |  |  |  |  |  | 639 |  |  |  |  |  | 1,227 |  |  |  |  |  | 1,250 |  |  |  |  |
| Total Net Revenue |  | $ | 2,331 |  |  |  |  |  | $ | 2,430 |  |  |  |  |  | $ | 4,707 |  |  |  |  |  | $ | 4,908 |  |  |  |  |
| Operating Income and Margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| NA Integrated Solutions & Services |  | $ | 131 |  |  | 13.8 | % |  | $ | 125 |  |  | 13.2 | % |  | $ | 263 |  |  | 13.8 | % |  | $ | 254 |  |  | 13.4 | % |
| ROW Integrated Solutions & Services |  | 57 |  |  | 7.4 | % |  | 67 |  |  | 7.9 | % |  | 190 |  |  | 12.0 | % |  | 156 |  |  | 8.8 | % |
| Global Products |  | 101 |  |  | 16.4 | % |  | 114 |  |  | 17.8 | % |  | 198 |  |  | 16.1 | % |  | 219 |  |  | 17.5 | % |
| Segment operating income |  | 289 |  |  | 12.4 | % |  | 306 |  |  | 12.6 | % |  | 651 |  |  | 13.8 | % |  | 629 |  |  | 12.8 | % |
| Corporate and Other expense |  | (54 | ) |  | N/M |  |  | (56 | ) |  | N/M |  |  | (105 | ) |  | N/M |  |  | (105 | ) |  | N/M |  |
| Restructuring and repositioning charges, net |  | (10 | ) |  | N/M |  |  | (29 | ) |  | N/M |  |  | (28 | ) |  | N/M |  |  | (104 | ) |  | N/M |  |
| Operating income |  | $ | 225 |  |  | 9.7 | % |  | $ | 221 |  |  | 9.1 | % |  | $ | 518 |  |  | 11.0 | % |  | $ | 420 |  |  | 8.6 | % |

[0000833444-16-000167:8k_2_02:87]
TYCO INTERNATIONAL PLC

[0000833444-16-000167:8k_2_02:88]
CONSOLIDATED BALANCE SHEETS

[0000833444-16-000167:8k_2_02:89]
(in millions)

[0000833444-16-000167:8k_2_02:90]
(Unaudited)

[0000833444-16-000167:8k_2_02:91]
|  |  | March 25, 2016 |  | September 25, 2015 |
| Assets |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 345 |  |  | $ | 1,401 |  |
| Accounts receivable, net |  | 1,722 |  |  | 1,732 |  |
| Inventories |  | 670 |  |  | 624 |  |
| Prepaid expenses and other current assets |  | 864 |  |  | 754 |  |
| Deferred income taxes |  | 62 |  |  | 62 |  |
| Assets held for sale |  | — |  |  | 102 |  |
| Total Current Assets |  | 3,663 |  |  | 4,675 |  |
| Property, plant and equipment, net |  | 1,189 |  |  | 1,177 |  |
| Goodwill |  | 4,460 |  |  | 4,234 |  |
| Intangible assets, net |  | 1,025 |  |  | 863 |  |
| Other assets |  | 1,274 |  |  | 1,372 |  |
| Total Assets |  | $ | 11,611 |  |  | $ | 12,321 |  |
| Liabilities and Equity |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |
| Loans payable and current maturities of long-term debt |  | $ | 400 |  |  | $ | 987 |  |
| Accounts payable |  | 797 |  |  | 774 |  |
| Accrued and other current liabilities |  | 1,643 |  |  | 1,661 |  |
| Deferred revenue |  | 393 |  |  | 380 |  |
| Liabilities held for sale |  | — |  |  | 50 |  |
| Total Current Liabilities |  | 3,233 |  |  | 3,852 |  |
| Long-term debt |  | 2,159 |  |  | 2,159 |  |
| Deferred revenue |  | 285 |  |  | 303 |  |
| Other liabilities |  | 1,756 |  |  | 1,931 |  |
| Total Liabilities |  | 7,433 |  |  | 8,245 |  |
| Total Tyco shareholders' equity |  | 4,142 |  |  | 4,041 |  |
| Nonredeemable noncontrolling interest |  | 36 |  |  | 35 |  |
| Total Equity |  | 4,178 |  |  | 4,076 |  |
| Total Liabilities and Equity |  | $ | 11,611 |  |  | $ | 12,321 |  |

[0000833444-16-000167:8k_2_02:92]
Note: These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K filed on November 13, 2015 and Form 8-K filed on March 11, 2016 for the fiscal year ended September 25, 2015.

[0000833444-16-000167:8k_2_02:93]
TYCO INTERNATIONAL PLC

[0000833444-16-000167:8k_2_02:94]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000833444-16-000167:8k_2_02:95]
(in millions)

[0000833444-16-000167:8k_2_02:96]
(Unaudited)

[0000833444-16-000167:8k_2_02:97]
|  |  | For the Quarters Ended |  | For the Six Months Ended |
|  |  | March 25, 2016 |  | March 27, 2015 |  | March 25, 2016 |  | March 27, 2015 |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Tyco ordinary shareholders |  | $ | 146 |  |  | $ | 167 |  |  | $ | 222 |  |  | $ | 329 |  |
| Noncontrolling interest in subsidiaries net loss |  | (1 | ) |  | (2 | ) |  | (1 | ) |  | (3 | ) |
| (Income) loss from discontinued operations, net of income taxes |  | (1 | ) |  | 16 |  |  | (5 | ) |  | 18 |  |
| Income from continuing operations |  | 144 |  |  | 181 |  |  | 216 |  |  | 344 |  |
| Adjustments to reconcile net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  | 84 |  |  | 81 |  |  | 167 |  |  | 171 |  |
| Non-cash compensation expense |  | 12 |  |  | 15 |  |  | 27 |  |  | 30 |  |
| Deferred income taxes |  | 45 |  |  | (23 | ) |  | 62 |  |  | (29 | ) |
| Provision for losses on accounts receivable and inventory |  | 17 |  |  | 18 |  |  | 29 |  |  | 34 |  |
| Loss on extinguishment of debt |  | — |  |  | — |  |  | 168 |  |  | — |  |
| Legacy legal matters |  | (19 | ) |  | — |  |  | (19 | ) |  | — |  |
| Loss on divestitures, net |  | 17 |  |  | 22 |  |  | 69 |  |  | 23 |  |
| Loss (gain) on investments, net |  | 1 |  |  | (3 | ) |  | (114 | ) |  | (7 | ) |
| Other non-cash items |  | — |  |  | 6 |  |  | 5 |  |  | 7 |  |
| Changes in assets and liabilities, net of the effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | 9 |  |  | 29 |  |  | 38 |  |  | 22 |  |
| Contracts in progress |  | (45 | ) |  | (38 | ) |  | (54 | ) |  | (30 | ) |
| Inventories |  | (22 | ) |  | (21 | ) |  | (56 | ) |  | (64 | ) |
| Prepaid expenses and other assets |  | 18 |  |  | (41 | ) |  | (30 | ) |  | (66 | ) |
| Accounts payable |  | 1 |  |  | (46 | ) |  | 2 |  |  | (87 | ) |
| Accrued and other liabilities |  | (92 | ) |  | (27 | ) |  | (133 | ) |  | (56 | ) |
| Tax sharing agreement, net |  | (122 | ) |  | — |  |  | (122 | ) |  | — |  |
| Income taxes, net |  | 2 |  |  | 3 |  |  | 13 |  |  | 1 |  |
| Other |  | 74 |  |  | 11 |  |  | 45 |  |  | (31 | ) |
| Net cash provided by operating activities |  | 124 |  |  | 167 |  |  | 313 |  |  | 262 |  |
| Net cash (used in) provided by discontinued operating activities |  | (13 | ) |  | 2 |  |  | (11 | ) |  | 3 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures |  | (75 | ) |  | (57 | ) |  | (143 | ) |  | (123 | ) |
| Acquisition of businesses, net of cash acquired |  | (176 | ) |  | (373 | ) |  | (314 | ) |  | (525 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases |  | (7 | ) |  | (4 | ) |  | (11 | ) |  | (8 | ) |
| Divestiture of businesses, net of cash divested |  | 9 |  |  | (1 | ) |  | 9 |  |  | (1 | ) |
| Sales and maturities of investments including restricted investments |  | 7 |  |  | 4 |  |  | 8 |  |  | 279 |  |
| Purchases of investments including restricted investments |  | — |  |  | (287 | ) |  | (7 | ) |  | (288 | ) |
| Decrease (increase) in restricted cash |  | 19 |  |  | 6 |  |  | 24 |  |  | (39 | ) |
| Other |  | 1 |  |  | 2 |  |  | 1 |  |  | 2 |  |
| Net cash used in investing activities |  | (222 | ) |  | (710 | ) |  | (433 | ) |  | (703 | ) |
| Net cash provided by (used in) discontinued investing activities |  | 4 |  |  | — |  |  | 4 |  |  | (15 | ) |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short-term debt |  | 1,681 |  |  | — |  |  | 2,498 |  |  | — |  |
| Repayment of short-term debt |  | (1,432 | ) |  | (1 | ) |  | (2,098 | ) |  | (1 | ) |
| Repayment of current portion of long-term debt |  | — |  |  | — |  |  | (1,134 | ) |  | — |  |
| Proceeds from issuance of long-term debt |  | — |  |  | 567 |  |  | — |  |  | 567 |  |
| Proceeds from exercise of share options |  | 15 |  |  | 24 |  |  | 26 |  |  | 57 |  |
| Dividends paid |  | (87 | ) |  | (76 | ) |  | (174 | ) |  | (151 | ) |
| Repurchase of ordinary shares |  | — |  |  | — |  |  | — |  |  | (417 | ) |
| Transfer (to) from discontinued operations |  | (9 | ) |  | 2 |  |  | (7 | ) |  | (12 | ) |
| Payment of contingent consideration |  | (1 | ) |  | — |  |  | (1 | ) |  | (23 | ) |
| Debt financing costs |  | (22 | ) |  | (4 | ) |  | (23 | ) |  | (4 | ) |
| Other |  | (2 | ) |  | (4 | ) |  | (13 | ) |  | (19 | ) |
| Net cash provided by (used in) financing activities |  | 143 |  |  | 508 |  |  | (926 | ) |  | (3 | ) |
| Net cash provided by (used in) discontinued financing activities |  | 9 |  |  | (2 | ) |  | 7 |  |  | 12 |  |
| Effect of currency translation on cash |  | (1 | ) |  | (6 | ) |  | (10 | ) |  | (16 | ) |
| Net decrease in cash and cash equivalents |  | 44 |  |  | (41 | ) |  | (1,056 | ) |  | (460 | ) |
| Cash and cash equivalents at beginning of period |  | 301 |  |  | 473 |  |  | 1,401 |  |  | 892 |  |
| Cash and cash equivalents at end of period |  | $ | 345 |  |  | $ | 432 |  |  | $ | 345 |  |  | $ | 432 |  |

[0000833444-16-000167:8k_2_02:98]
|  |  | For the Quarters Ended |  | For the Six Months Ended |
|  |  | March 25, 2016 |  | March 27, 2015 |  | March 25, 2016 |  | March 27, 2015 |
| Reconciliation to "Free Cash Flow": |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 124 |  |  | $ | 167 |  |  | $ | 313 |  |  | $ | 262 |  |
| Capital expenditures, net |  | (74 | ) |  | (55 | ) |  | (142 | ) |  | (120 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases |  | (7 | ) |  | (4 | ) |  | (11 | ) |  | (8 | ) |
| Payment of contingent consideration |  | (1 | ) |  | (1 | ) |  | (1 | ) |  | (24 | ) |
| Voluntary pension contributions |  | 4 |  |  | — |  |  | 4 |  |  | — |  |
| Free Cash Flow |  | $ | 46 |  |  | $ | 107 |  |  | $ | 163 |  |  | $ | 110 |  |
| Reconciliation to "Adjusted Free Cash Flow": |  |  |  |  |  |  |  |  |
| IRS litigation costs |  | $ | — |  |  | $ | — |  |  | $ | 3 |  |  | $ | — |  |
| Separation costs |  | — |  |  | — |  |  | — |  |  | 3 |  |
| Restructuring and repositioning costs (FY15 and prior) |  | 23 |  |  | 37 |  |  | 68 |  |  | 71 |  |
| Environmental remediation payments |  | 1 |  |  | 1 |  |  | 2 |  |  | 8 |  |
| Legal settlements |  | 14 |  |  | — |  |  | 14 |  |  | (12 | ) |
| Net asbestos payments |  | 8 |  |  | 3 |  |  | 10 |  |  | 8 |  |
| Merger costs |  | 8 |  |  | — |  |  | 8 |  |  | — |  |
| Cash payment to ADT Resi / Pentair |  | 16 |  |  | 1 |  |  | 16 |  |  | 1 |  |
| Cash payment to Covidien / TE Connectivity |  | 122 |  |  | — |  |  | 122 |  |  | — |  |
| Acquisition / integration costs |  | 4 |  |  | 2 |  |  | 5 |  |  | 3 |  |
| Special Items |  | $ | 196 |  |  | $ | 44 |  |  | $ | 248 |  |  | $ | 82 |  |
| Adjusted Free Cash Flow |  | $ | 242 |  |  | $ | 151 |  |  | $ | 411 |  |  | $ | 192 |  |

[0000833444-16-000167:8k_2_02:99]
Note: Free cash flow is a non-GAAP measure.  See description of non-GAAP measures contained in this release.

[0000833444-16-000167:8k_2_02:100]
TYCO INTERNATIONAL PLC

[0000833444-16-000167:8k_2_02:101]
ORGANIC GROWTH RECONCILIATION - REVENUE

[0000833444-16-000167:8k_2_02:102]
(in millions)

[0000833444-16-000167:8k_2_02:103]
(Unaudited)

[0000833444-16-000167:8k_2_02:104]
|  |  |  |  | Quarter Ended March 25, 2016 |  |  |  |  |
|  |  |  |  | Base Year |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Net Revenue for the Quarter Ended March 27, 2015 |  | Adjustments |  | Adjusted Fiscal 2015 BaseRevenue |  |  |  |  |  |  |  |  |  |  |  |  |  | Net Revenue for the Quarter Ended March 25, 2016 |
|  |  |  | Divestitures / Other |  |  | Foreign Currency |  | Acquisitions |  | Organic Revenue(1) |  |
| NA Integrated Solutions & Services |  | $ | 944 |  |  | $ | — |  |  | — | % |  | $ | 944 |  |  | $ | (10 | ) |  | (1.1 | )% |  | $ | 9 |  |  | 1.0 | % |  | $ | 4 |  |  | 0.4 | % |  | $ | 947 |  |  | 0.3 | % |
| ROW Integrated Solutions & Services |  | 847 |  |  | (62 | ) |  | (7.3 | )% |  | 785 |  |  | (73 | ) |  | (8.6 | )% |  | 64 |  |  | 7.6 | % |  | (8 | ) |  | (1.0 | )% |  | 768 |  |  | (9.3 | )% |
| Global Products |  | 639 |  |  | (3 | ) |  | (0.5 | )% |  | 636 |  |  | (18 | ) |  | (2.8 | )% |  | 17 |  |  | 2.7 | % |  | (19 | ) |  | (3.0 | )% |  | 616 |  |  | (3.6 | )% |
| Total Net Revenue |  | $ | 2,430 |  |  | $ | (65 | ) |  | (2.7 | )% |  | $ | 2,365 |  |  | $ | (101 | ) |  | (4.2 | )% |  | $ | 90 |  |  | 3.7 | % |  | $ | (23 | ) |  | (1.0 | )% |  | $ | 2,331 |  |  | (4.1 | )% |

[0000833444-16-000167:8k_2_02:105]
|  | (1) Organic revenue growth percentage based on adjusted fiscal 2015 base revenue. |

[0000833444-16-000167:8k_2_02:106]
|  |  |  |  | Six Months Ended March 25, 2016 |  |  |  |  |
|  |  |  |  | Base Year |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Net Revenue for the Six Months Ended March 27, 2015 |  | Adjustments |  | Adjusted Fiscal 2015 BaseRevenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Net Revenue for the Six Months Ended March 25, 2016 |
|  |  |  | Divestitures / Other |  |  | Foreign Currency |  | Acquisitions |  |  | Organic Revenue (1) |  |
| NA Integrated Solutions & Services |  | $ | 1,895 |  |  | $ | — |  |  | — | % |  | $ | 1,895 |  |  | $ | (26 | ) |  | (1.4 | )% |  | $ | 12 |  |  | 0.6 | % |  |  | $ | 19 |  |  | 1.0 | % |  | $ | 1,900 |  |  | 0.3 | % |
| ROW Integrated Solutions & Services |  | 1,763 |  |  | (84 | ) |  | (4.8 | )% |  | 1,679 |  |  | (174 | ) |  | (9.9 | )% |  | 93 |  |  | 5.3 | % |  |  | (18 | ) |  | (1.1 | )% |  | 1,580 |  |  | (10.4 | )% |
| Global Products |  | 1,250 |  |  | (4 | ) |  | (0.3 | )% |  | 1,246 |  |  | (53 | ) |  | (4.2 | )% |  | 56 |  |  | 4.5 | % |  |  | (22 | ) |  | (1.8 | )% |  | 1,227 |  |  | (1.8 | )% |
| Total Net Revenue |  | $ | 4,908 |  |  | $ | (88 | ) |  | (1.8 | )% |  | $ | 4,820 |  |  | $ | (253 | ) |  | (5.2 | )% |  | $ | 161 |  |  | 3.3 | % |  |  | $ | (21 | ) |  | (0.4 | )% |  | $ | 4,707 |  |  | (4.1 | )% |

[0000833444-16-000167:8k_2_02:107]
|  | (1) Organic revenue growth percentage based on adjusted fiscal 2015 base revenue. |

[0000833444-16-000167:8k_2_02:108]
Earnings Per Share Summary

[0000833444-16-000167:8k_2_02:109]
(Unaudited)

[0000833444-16-000167:8k_2_02:110]
|  |  | Quarter Ended |  | Quarter Ended |
|  |  | March 25, 2016 |  | March 27, 2015 |
| Diluted EPS from Continuing Operations Attributable to Tyco Shareholders (GAAP) |  | $ | 0.33 |  |  | $ | 0.43 |  |
| expense / (benefit) |  |  |  |  |
| Restructuring and repositioning reversals (FY15 and prior) |  | (0.01 | ) |  | — |  |
| Merger costs |  | 0.06 |  |  | — |  |
| (Gains) / losses on divestitures, net included in SG&A |  | 0.08 |  |  | 0.06 |  |
| Legacy legal items |  | (0.03 | ) |  | — |  |
| 2012 Tax Sharing Agreement |  | — |  |  | 0.01 |  |
| Total Before Special Items |  | $ | 0.45 |  |  | $ | 0.50 |  |

[0000833444-16-000167:8k_2_02:111]
Note:  Sum of EPS before special items does not equal total due to rounding.

[0000833444-16-000167:8k_2_02:112]
Tyco International plc

[0000833444-16-000167:8k_2_02:113]
For the Quarter Ended March 25, 2016

[0000833444-16-000167:8k_2_02:114]
(in millions, except per share data)

[0000833444-16-000167:8k_2_02:115]
(Unaudited)

[0000833444-16-000167:8k_2_02:116]
expense / (benefit)

[0000833444-16-000167:8k_2_02:117]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | NA Integrated Solutions& Services |  |  |  | ROW Integrated Solutions & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  | $947 |  |  |  |  |  | $768 |  |  |  |  |  | $616 |  |  |  |  |  | $2,331 |  |  |  |  | $— |  |  |  |  |  | $2,331 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | NA Integrated Solutions& Services |  | Margin |  | ROW Integrated Solutions & Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome | Margin |  | Corporateand Other |  | Restructuring and Repositioning |  | Total OperatingIncome | Margin |  | Interest (Expense), net |  | Other (Expense) Income, net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  | $131 |  |  | 13.8 | % |  |  | $57 |  |  | 7.4 | % |  |  | $101 |  |  | 16.4 | % |  |  | $289 |  | 12.4 | % |  |  | ($54 | ) |  |  | ($10 | ) |  |  | $225 |  | 9.7 | % |  |  | ($18 | ) |  |  | $— |  |  |  | ($63 | ) |  |  | $— |  |  |  | $1 |  |  | $145 |  |  | $0.33 |  |
| Amortization of acquired backlog included in revenue |  |  |  |  | 2 |  |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  | — |  |
| Restructuring and repositioning reversals (FY15 and prior) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (6 | ) |  | (6 | ) |  |  |  |  |  |  | 2 |  |  |  |  |  | (4 | ) | (0.01 | ) |
| Merger costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 26 |  |  |  |  | 26 |  |  |  |  |  |  |  |  |  |  |  |  | 26 |  | 0.06 |  |
| (Gains) / losses on divestitures, net included in SG&A |  |  |  |  | 18 |  |  |  |  |  |  |  |  | 18 |  |  |  | (1 | ) |  |  |  | 17 |  |  |  |  |  |  |  | 16 |  |  |  |  |  | 33 |  | 0.08 |  |
| Acquisition / integration costs |  |  |  |  |  |  |  |  | 2 |  |  |  |  | 2 |  |  |  | 1 |  |  |  |  | 3 |  |  |  |  |  |  |  | (2 | ) |  |  |  |  | 1 |  | — |  |
| Legacy legal items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (19 | ) |  |  |  | (19 | ) |  |  |  |  |  |  | 7 |  |  |  |  |  | (12 | ) | (0.03 | ) |
| IRS litigation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Total Before Special Items |  | $131 |  |  | 13.8 | % |  |  | $77 |  |  | 10.0 | % |  |  | $103 |  |  | 16.7 | % |  |  | $311 |  | 13.3 | % |  |  | ($46 | ) |  |  | ($16 | ) |  |  | $249 |  | 10.7 | % |  |  | ($18 | ) |  |  | $— |  |  |  | ($40 | ) |  |  | $— |  |  |  | $1 |  |  | $192 |  |  | $0.45 |  |
| Note: Sum of EPS before special items does not equal total due to rounding. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  | 428 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 428 |  |

[0000833444-16-000167:8k_2_02:118]
Tyco International plc

[0000833444-16-000167:8k_2_02:119]
For the Quarter Ended March 27, 2015

[0000833444-16-000167:8k_2_02:120]
(in millions, except per share data)

[0000833444-16-000167:8k_2_02:121]
(Unaudited)

[0000833444-16-000167:8k_2_02:122]
expense / (benefit)

[0000833444-16-000167:8k_2_02:123]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Integrated Solutions& Services |  |  |  | ROW Integrated Solutions & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $944 |  |  |  |  |  | $847 |  |  |  |  |  | $639 |  |  |  |  |  | $2,430 |  |  |  |  |  | $— |  |  |  |  |  | $2,430 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Integrated Solutions& Services |  | Margin |  | ROW Integrated Solutions & Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Restructuring and Repositioning |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other Income, net |  | Income Tax (Expense) |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $125 |  |  | 13.2 | % |  |  | $67 |  |  | 7.9 | % |  |  | $114 |  |  | 17.8 | % |  |  | $306 |  |  | 12.6 | % |  |  | ($56 | ) |  |  | ($29 | ) |  |  | $221 |  |  | 9.1 | % |  |  | ($21 | ) |  |  | ($1 | ) |  |  | ($18 | ) |  |  | $2 |  |  |  | $183 |  |  | $0.43 |  |
| (Gains) / losses on divestitures, net included in SG&A |  |  |  |  |  | 22 |  |  |  |  |  |  |  |  | 22 |  |  |  |  |  |  |  |  | 22 |  |  |  |  |  |  |  |  |  |  |  |  | 22 |  | 0.06 |  |
| Acquisition / integration costs |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Legacy legal items |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Amortization of inventory step-up |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 3 |  |  |  |  | 3 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  | 2 |  | — |  |
| IRS litigation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  |  |  |  | 2 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  | 1 |  | — |  |
| 2012 Tax Sharing Agreement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 4 |  |  |  |  |  |  | 4 |  | 0.01 |  |
| Total Before Special Items |  |  | $125 |  |  | 13.2 | % |  |  | $90 |  |  | 10.6 | % |  |  | $116 |  |  | 18.2 | % |  |  | $331 |  |  | 13.6 | % |  |  | ($51 | ) |  |  | ($29 | ) |  |  | $251 |  |  | 10.3 | % |  |  | ($21 | ) |  |  | $3 |  |  |  | ($20 | ) |  |  | $2 |  |  |  | $215 |  |  | $0.50 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 427 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 427 |  |
