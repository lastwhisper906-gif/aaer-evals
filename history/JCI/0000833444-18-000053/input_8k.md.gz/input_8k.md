# JCI 8-K — 0000833444-18-000046 filed 2018-11-08

## item codes, every 8-K on or before 2018-11-20

- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2018-11-20

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-18-000046:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq4fy18.htm
EXHIBIT 99.1

[0000833444-18-000046:8k_2_02:2]
Exhibit

[0000833444-18-000046:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000833444-18-000046:8k_2_02:4]
| CONTACT: | Investors:Antonella Franzen(609) 720-4665Ryan Edelman(609) 720-4545Media:Fraser Engerman(414) 524-2733 | Exhibit 99.1 |

[0000833444-18-000046:8k_2_02:5]
Johnson Controls reports fiscal Q4 2018 and full year earnings

[0000833444-18-000046:8k_2_02:6]
with strong organic revenue growth and free cash flow conversion;

[0000833444-18-000046:8k_2_02:7]
announces an additional $1B share repurchase authorization

[0000833444-18-000046:8k_2_02:8]
_______________________________________________________________________________

[0000833444-18-000046:8k_2_02:9]
| ▪ | GAAP EPS for the quarter of $0.83 per share; $2.32 for the full year, including special items |

[0000833444-18-000046:8k_2_02:10]
| ▪ | Adjusted EPS for the quarter of $0.93, up 7% versus prior year; full year EPS of $2.83, up 9% versus prior year |

[0000833444-18-000046:8k_2_02:11]
| ▪ | Sales in the quarter of $8.4 billion, reflecting overall organic growth of 6%; full year sales of $31.4 billion, up 4% organically |

[0000833444-18-000046:8k_2_02:12]
| ▪ | Buildings organic revenue growth up 8% in the quarter; up 5% for the full year |

[0000833444-18-000046:8k_2_02:13]
| ▪ | Buildings Field orders up 9% organically in the quarter; up 7% for the full year |

[0000833444-18-000046:8k_2_02:14]
| ▪ | Adjusted free cash flow of $1.3 billion in the quarter; $2.3 billion for the full year, representing free cash flow conversion of 88% |

[0000833444-18-000046:8k_2_02:15]
| ▪ | Ongoing strategic review of the Power Solutions business in final stages |

[0000833444-18-000046:8k_2_02:16]
| ▪ | Expect fiscal 2019 adjusted EPS to be in the range of $2.90 to $3.05, representing organic EBIT growth of 8% to 12%; offset by 4% headwind from tax |

[0000833444-18-000046:8k_2_02:17]
________________________________________________________________________________

[0000833444-18-000046:8k_2_02:18]
CORK, Ireland, November 8, 2018 -- Johnson Controls International plc (NYSE: JCI) today reported fiscal fourth quarter 2018 GAAP earnings per share (“EPS”) from continuing operations, including special items, of $0.83.  Excluding these items, adjusted EPS from continuing operations was $0.93, up 7% versus the prior year period (see attached footnotes for non-GAAP reconciliation).

[0000833444-18-000046:8k_2_02:19]
Sales of $8.4 billion increased 3% compared to the prior year.  Excluding the impacts of M&A, foreign currency and lead prices, total sales grew 6% organically.

[0000833444-18-000046:8k_2_02:20]
Page 1 of 18

[0000833444-18-000046:8k_2_02:21]
GAAP earnings before interest and taxes (“EBIT”) was $1.0 billion and EBIT margin was 12.0%. Adjusted EBIT was $1.2 billion and adjusted EBIT margin was 14.0%, up 10 basis points over the prior year.  Excluding the impact of the Scott Safety divestiture, foreign currency and lead prices, the underlying adjusted EBIT margin increased 50 basis points.

[0000833444-18-000046:8k_2_02:22]
The Company announced that the Board of Directors has approved an additional $1 billion share repurchase authorization.  There is currently $900 million remaining on a previous authorization.

[0000833444-18-000046:8k_2_02:23]
“Solid fourth quarter results close out a year of significant progress for Johnson Controls, with positive momentum as we enter fiscal 2019,” said George Oliver, chairman and CEO. “Our teams around the globe successfully delivered on our operating goals, with strong organic growth and cash flow performance.”

[0000833444-18-000046:8k_2_02:24]
“We are in the final stages of the strategic review of our Power Solutions business.  We have assessed multiple options and have made significant progress toward making a final decision.”

[0000833444-18-000046:8k_2_02:25]
“As we look forward to fiscal 2019, we remain focused on driving execution across our portfolio to further enhance our growth trajectory supported by our strong backlog, order momentum and new business wins.  We expect our overall financial performance to continue to improve by intensely focusing on top-line growth, margin expansion and free cash flow conversion,” Oliver continued.

[0000833444-18-000046:8k_2_02:26]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-18-000046:8k_2_02:27]
($ millions, except per-share amounts)

[0000833444-18-000046:8k_2_02:28]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the fiscal fourth quarter and fiscal year of 2017.

[0000833444-18-000046:8k_2_02:29]
Organic sales growth, adjusted segment EBITA, adjusted EBIT, adjusted EPS from continuing operations and adjusted free cash flow are non-GAAP financial measures. For a reconciliation of these non-GAAP measures and detail of the special items, refer to the attached footnotes.  A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-18-000046:8k_2_02:30]
|  |  | GAAP |  | ADJUSTED |  | GAAP |  | ADJUSTED |
|  |  | Q4 2017 |  | Q4 2018 |  | Q4 2017 |  | Q4 2018 |  | FY 2017 |  | FY 2018 |  | FY 2017 |  | FY 2018 |
| Sales |  | $8,136 |  | $8,370 |  | $8,136 |  | $8,370 |  | $30,172 |  | $31,400 |  | $30,138 |  | $31,400 |
| Segment EBITA |  | 1,262 |  | 1,334 |  | 1,335 |  | 1,363 |  | 4,258 |  | 4,555 |  | 4,446 |  | 4,514 |
| EBIT |  | 1,182 |  | 1,001 |  | 1,131 |  | 1,172 |  | 3,054 |  | 3,342 |  | 3,599 |  | 3,722 |
| Net income from continuing operations |  | 875 |  | 771 |  | 813 |  | 870 |  | 1,654 |  | 2,162 |  | 2,459 |  | 2,633 |
| Diluted EPS from continuing operations |  | $0.93 |  | $0.83 |  | $0.87 |  | $0.93 |  | $1.75 |  | $2.32 |  | $2.60 |  | $2.83 |

[0000833444-18-000046:8k_2_02:31]
Page 2 of 18

[0000833444-18-000046:8k_2_02:32]
BUSINESS RESULTS

[0000833444-18-000046:8k_2_02:33]
Building Solutions North America

[0000833444-18-000046:8k_2_02:34]
|  |  | GAAP |  | ADJUSTED |  | GAAP |  | ADJUSTED |
|  |  | Q4 2017 |  | Q4 2018 |  | Q4 2017 |  | Q4 2018 |  | FY 2017 |  | FY 2018 |  | FY 2017 |  | FY 2018 |
| Sales |  | $2,160 |  | $2,324 |  | $2,165 |  | $2,324 |  | $8,341 |  | $8,679 |  | $8,316 |  | $8,679 |
| Segment EBITA |  | $298 |  | $329 |  | $315 |  | $336 |  | $1,039 |  | $1,109 |  | $1,070 |  | $1,134 |
| Segment EBITA margin % |  | 13.8% |  | 14.2% |  | 14.5% |  | 14.5% |  | 12.5% |  | 12.8% |  | 12.9% |  | 13.1% |

[0000833444-18-000046:8k_2_02:35]
Sales in the quarter were $2.3 billion, an increase of 7% versus the prior year.  Excluding M&A and foreign currency, organic sales increased 8% versus the prior year, driven primarily by strong growth in Fire & Security and HVAC & Controls.

[0000833444-18-000046:8k_2_02:36]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 8% year-over-year.  Backlog at the end of the quarter of $5.4 billion increased 6% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-18-000046:8k_2_02:37]
Adjusted segment EBITA was $336 million, up 7% versus the prior year. Adjusted segment EBITA margin of 14.5% was consistent with the prior year as favorable volume leverage as well as cost synergies and productivity savings, were offset by unfavorable mix and salesforce additions.

[0000833444-18-000046:8k_2_02:38]
Sales for the full year were $8.7 billion, representing organic growth of 4% versus the prior year.  Adjusted segment EBITA for the full year was $1.1 billion and adjusted segment EBITA margin expanded 20 basis points year-over-year to 13.1%.

[0000833444-18-000046:8k_2_02:39]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-18-000046:8k_2_02:40]
|  |  | GAAP |  | ADJUSTED |  | GAAP |  | ADJUSTED |
|  |  | Q4 2017 |  | Q4 2018 |  | Q4 2017 |  | Q4 2018 |  | FY 2017 |  | FY 2018 |  | FY 2017 |  | FY 2018 |
| Sales |  | $926 |  | $948 |  | $921 |  | $948 |  | $3,595 |  | $3,696 |  | $3,579 |  | $3,696 |
| Segment EBITA |  | $52 |  | $102 |  | $95 |  | $103 |  | $290 |  | $344 |  | $328 |  | $350 |
| Segment EBITA margin % |  | 5.6% |  | 10.8% |  | 10.3% |  | 10.9% |  | 8.1% |  | 9.3% |  | 9.2% |  | 9.5% |

[0000833444-18-000046:8k_2_02:41]
Page 3 of 18

[0000833444-18-000046:8k_2_02:42]
Sales in the quarter were $948 million, an increase of 3% versus the prior year.  Excluding M&A and foreign currency, organic sales grew 6% versus the prior year driven by stronger service growth. Growth was positive across all regions, led by Europe and Latin America.

[0000833444-18-000046:8k_2_02:43]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 10% year-over-year.  Backlog at the end of the quarter of $1.5 billion increased 9% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-18-000046:8k_2_02:44]
Adjusted segment EBITA was $103 million, up 8% versus the prior year. Adjusted segment EBITA margin of 10.9% expanded 60 basis points over the prior year, including a 30 basis point headwind related to foreign currency.  Adjusting for foreign currency, the underlying margin improved 90 basis points driven by favorable volume and mix as well as the benefit from cost synergies and productivity savings, partially offset by salesforce additions.

[0000833444-18-000046:8k_2_02:45]
Sales for the full year were $3.7 billion, an increase of 3% versus the prior year, with organic growth of 2%.  Adjusted segment EBITA for the full year was $350 million and adjusted segment EBITA margin expanded 30 basis points year-over-year, including a 10 basis point headwind related to foreign currency to 9.5%.

[0000833444-18-000046:8k_2_02:46]
Building Solutions Asia Pacific

[0000833444-18-000046:8k_2_02:47]
|  |  | GAAP |  | ADJUSTED |  | GAAP |  | ADJUSTED |
|  |  | Q4 2017 |  | Q4 2018 |  | Q4 2017 |  | Q4 2018 |  | FY 2017 |  | FY 2018 |  | FY 2017 |  | FY 2018 |
| Sales |  | $677 |  | $689 |  | $677 |  | $689 |  | $2,444 |  | $2,553 |  | $2,445 |  | $2,553 |
| Segment EBITA |  | $108 |  | $105 |  | $109 |  | $105 |  | $323 |  | $347 |  | $332 |  | $347 |
| Segment EBITA margin % |  | 16.0% |  | 15.2% |  | 16.1% |  | 15.2% |  | 13.2% |  | 13.6% |  | 13.6% |  | 13.6% |

[0000833444-18-000046:8k_2_02:48]
Sales in the quarter were $689 million, an increase of 2% versus the prior year.  Excluding M&A and foreign currency, organic sales increased 4% versus the prior year, with double-digit growth in service and modest growth in project installations.

[0000833444-18-000046:8k_2_02:49]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 8% year-over-year.  Backlog at the end of the quarter of $1.5 billion increased 11% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-18-000046:8k_2_02:50]
Adjusted segment EBITA was $105 million, down 4% versus the prior year. Adjusted segment EBITA margin of 15.2% declined 90 basis points over the prior year as the benefit of cost synergies and productivity savings as well as favorable volume was more than offset by salesforce additions and expected underlying margin pressure.

[0000833444-18-000046:8k_2_02:51]
Sales for the full year were $2.6 billion, an increase of 4% versus the prior year, with organic growth of 3%.  Adjusted segment EBITA for the full year was $347 million and adjusted segment EBITA margin of 13.6% was consistent year-over-year, including a 30 basis point headwind related to foreign currency.

[0000833444-18-000046:8k_2_02:52]
Page 4 of 18

[0000833444-18-000046:8k_2_02:53]
Global Products

[0000833444-18-000046:8k_2_02:54]
|  |  | GAAP |  | ADJUSTED |  | GAAP |  | ADJUSTED |
|  |  | Q4 2017 |  | Q4 2018 |  | Q4 2017 |  | Q4 2018 |  | FY 2017 |  | FY 2018 |  | FY 2017 |  | FY 2018 |
| Sales |  | $2,241 |  | $2,222 |  | $2,241 |  | $2,222 |  | $8,455 |  | $8,472 |  | $8,461 |  | $8,472 |
| Segment EBITA |  | $373 |  | $389 |  | $385 |  | $395 |  | $1,179 |  | $1,338 |  | $1,288 |  | $1,251 |
| Segment EBITA margin % |  | 16.6% |  | 17.5% |  | 17.2% |  | 17.8% |  | 13.9% |  | 15.8% |  | 15.2% |  | 14.8% |

[0000833444-18-000046:8k_2_02:55]
Sales in the quarter were $2.2 billion, a decrease of 1% versus the prior year. Excluding M&A and foreign currency, organic sales increased 9% versus the prior year led by high-single digit growth in HVAC & Refrigeration Equipment, high-teens growth in Building Management Systems, and low-double digit growth in Specialty Products.

[0000833444-18-000046:8k_2_02:56]
Adjusted segment EBITA was $395 million, up 3% versus the prior year. Adjusted segment EBITA margin of 17.8% expanded 60 basis points over the prior year, including a 100 basis point headwind related to the divestiture of the Scott Safety business. The underlying margin expanded 160 basis points driven by favorable volume and mix, positive price/cost as well as the benefit of cost synergies and productivity savings, partially offset by ongoing product and channel investments.

[0000833444-18-000046:8k_2_02:57]
Sales for the full year were $8.5 billion, consistent versus the prior year, with organic growth of 7%.  Adjusted segment EBITA for the full year was $1.3 billion and adjusted segment EBITA margin declined 40 basis points year-over-year to 14.8%, including a 100 basis point headwind related to the divestiture of Scott Safety.

[0000833444-18-000046:8k_2_02:58]
Power Solutions

[0000833444-18-000046:8k_2_02:59]
|  |  | GAAP |  | ADJUSTED |  | GAAP |  | ADJUSTED |
|  |  | Q4 2017 |  | Q4 2018 |  | Q4 2017 |  | Q4 2018 |  | FY 2017 |  | FY 2018 |  | FY 2017 |  | FY 2018 |
| Sales |  | $2,132 |  | $2,187 |  | $2,132 |  | $2,187 |  | $7,337 |  | $8,000 |  | $7,337 |  | $8,000 |
| Segment EBITA |  | $431 |  | $409 |  | $431 |  | $424 |  | $1,427 |  | $1,417 |  | $1,428 |  | $1,432 |
| Segment EBITA margin % |  | 20.2% |  | 18.7% |  | 20.2% |  | 19.4% |  | 19.4% |  | 17.7% |  | 19.5% |  | 17.9% |

[0000833444-18-000046:8k_2_02:60]
Sales in the quarter were $2.2 billion, an increase of 3% versus the prior year. Excluding the impact of higher lead pass-through and foreign currency, organic sales increased 2% driven by favorable price and technology mix. Global original equipment battery shipments increased 5%, benefitting from several recent business wins. Aftermarket shipments declined 2% versus a tough prior year comparison. Start-stop battery shipments increased 20% year-over-year, led by strong growth in EMEA, the Americas and China.

[0000833444-18-000046:8k_2_02:61]
Page 5 of 18

[0000833444-18-000046:8k_2_02:62]
Power Solutions adjusted segment EBITA was $424 million, a 2% decline compared to the prior year.  Adjusted segment EBITA margin of 19.4% decreased 80 basis points compared with the prior year, including a 10 basis point headwind related to the impact of higher lead prices and foreign currency. Power Solution’s underlying margin declined 70 basis points as volume leverage and productivity savings were more than offset by unfavorable mix, higher transportation costs and planned incremental investments.

[0000833444-18-000046:8k_2_02:63]
Sales for the full year were $8.0 billion, an increase of 9% versus the prior year, with organic growth of 3%.  Adjusted segment EBITA for the full year was $1.4 billion and adjusted segment EBITA margin declined 160 basis points year-over-year to 17.9%, including a 90 basis point headwind related to the impact of higher lead prices and foreign currency.  Excluding these items, Power Solution’s underlying margin declined 70 basis points.

[0000833444-18-000046:8k_2_02:64]
Corporate

[0000833444-18-000046:8k_2_02:65]
|  |  | GAAP |  | ADJUSTED |  | GAAP |  | ADJUSTED |
|  |  | Q4 2017 |  | Q4 2018 |  | Q4 2017 |  | Q4 2018 |  | FY 2017 |  | FY 2018 |  | FY 2017 |  | FY 2018 |
| Corporate expense |  | ($163) |  | ($142) |  | ($107) |  | ($95) |  | ($768) |  | ($576) |  | ($465) |  | ($408) |

[0000833444-18-000046:8k_2_02:66]
Adjusted Corporate expense was $95 million in the quarter and $408 million for the year, a decrease of 11% and 12%, respectively, compared to the prior year. The decline in both periods primarily reflects cost synergies and productivity savings.

[0000833444-18-000046:8k_2_02:67]
OTHER ITEMS

[0000833444-18-000046:8k_2_02:68]
| • | Cash from operating activities less capex was $1.0 billion for the quarter and $1.5 billion for the year. Adjusted free cash flow was $1.3 billion for the quarter and $2.3 billion for the year. Adjusted free cash flow excludes net cash outflows of $0.3 billion in the quarter and $0.8 billion for the year primarily related to restructuring and integration costs and nonrecurring tax payments. |

[0000833444-18-000046:8k_2_02:69]
| • | During the quarter, the Company repurchased 1.2 million shares for approximately $45 million; fiscal year 2018 share repurchases totaled 7.7 million shares for approximately $300 million. |

[0000833444-18-000046:8k_2_02:70]
| • | New Accounting Standard - ASU No. 2014-09, “Revenue from Contracts with Customers (Topic 606),” which clarifies the principals for recognizing revenue will be adopted by the Company on a modified retrospective basis beginning in the first quarter of fiscal 2019. There is not a material financial impact to Buildings and no material segment EBITA impact for Power Solutions, but battery core return classification increases revenue for Power Solutions resulting in segment EBITA margin rate dilution of approximately 200 basis points. |

[0000833444-18-000046:8k_2_02:71]
Page 6 of 18

[0000833444-18-000046:8k_2_02:72]
FISCAL 2019 GUIDANCE

[0000833444-18-000046:8k_2_02:73]
The Company also announced fiscal 2019 guidance:

[0000833444-18-000046:8k_2_02:74]
| ▪ | Organic revenue growth in the mid-single digits. |

[0000833444-18-000046:8k_2_02:75]
| ▪ | Incremental synergy and productivity savings of $250 million. |

[0000833444-18-000046:8k_2_02:76]
| ▪ | Fiscal 2019 adjusted EPS before special items of $2.90 to $3.05, including a $0.12 headwind from an increased tax rate and an $0.08 headwind related to foreign currency. |

[0000833444-18-000046:8k_2_02:77]
| ▪ | Adjusted free cash flow conversion of approximately 90%, excluding special items. |

[0000833444-18-000046:8k_2_02:78]
###

[0000833444-18-000046:8k_2_02:79]
About Johnson Controls:

[0000833444-18-000046:8k_2_02:80]
Johnson Controls is a global diversified technology and multi industrial leader serving a wide range of customers in more than 150 countries. Our 120,000 employees create intelligent buildings, efficient energy solutions, integrated infrastructure and next generation transportation systems that work seamlessly together to deliver on the promise of smart cities and communities. Our commitment to sustainability dates back to our roots in 1885, with the invention of the first electric room thermostat. We are committed to helping our customers win and creating greater value for all of our stakeholders through strategic focus on our buildings and energy growth platforms. For additional information, please visit http://www.johnsoncontrols.com or follow us @johnsoncontrols on Twitter.

[0000833444-18-000046:8k_2_02:81]
###

[0000833444-18-000046:8k_2_02:82]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-18-000046:8k_2_02:83]
Page 7 of 18

[0000833444-18-000046:8k_2_02:84]
business, the strength of the U.S. or other economies, changes to laws or policies governing foreign trade, including increased tariffs or trade restrictions, automotive vehicle production levels, mix and schedules, energy and commodity prices, the availability of raw materials and component products, currency rates and cancellation of or changes to commercial arrangements, and with respect to the strategic review of the Power Solutions business, uncertainties as to the structure and timing of any transaction and whether it will be completed, the possibility that closing conditions for a transaction may not be satisfied or waived, the impact of the strategic review and any transaction on Johnson Controls and the Power Solutions business on a standalone basis if a transaction is completed, and whether the strategic benefits of any transaction can be achieved. A detailed discussion of risks related to Johnson Controls’ business is included in the section entitled “Risk Factors” in Johnson Controls’ Annual Report on Form 10-K for the 2017 fiscal year filed with the SEC on November 21, 2017, and its Quarterly Reports on Form 10-Q for the quarterly periods ended December 31, 2017, March 31, 2018 and June 30, 2018 filed with the SEC on February 2, 2018, May 3, 2018 and August 2, 2018, respectively, which are and available at www.sec.gov and www.johnsoncontrols.com under the “Investors” tab. Shareholders, potential investors and others should consider these factors in evaluating the forward-looking statements and should not place undue reliance on such statements. The forward-looking statements included in this communication are made only as of the date of this document, unless otherwise specified, and, except as required by law, Johnson Controls assumes no obligation, and disclaims any obligation, to update such statements to reflect events or circumstances occurring after the date of this communication.

[0000833444-18-000046:8k_2_02:85]
###

[0000833444-18-000046:8k_2_02:86]
Non-GAAP Financial Information

[0000833444-18-000046:8k_2_02:87]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include mark-to-market for pension and postretirement plans, transaction/integration/separation costs, restructuring and impairment costs, nonrecurring purchase accounting impacts related to the Tyco merger, restructuring costs and discontinued operations losses in equity income, unfavorable arbitration award, Scott Safety gain on sale and discrete tax items. Financial information regarding adjusted sales, organic sales, adjusted segment EBITA, adjusted segment EBITA margin, adjusted free cash flow and adjusted free cash flow conversion are also presented, which are non-GAAP performance measures. Adjusted segment EBITA excludes special items such as transaction/integration costs and nonrecurring purchase accounting impacts because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.

[0000833444-18-000046:8k_2_02:88]
###

[0000833444-18-000046:8k_2_02:89]
Page 8 of 18

[0000833444-18-000046:8k_2_02:90]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Three Months Ended September 30, |
|  |  | 2018 |  |  | 2017 |
| Net sales | $ | 8,370 |  |  |  | $ | 8,136 |  |
| Cost of sales | 5,851 |  |  |  | 5,623 |  |
|  | Gross profit | 2,519 |  |  |  | 2,513 |  |
| Selling, general and administrative expenses | (1,478 | ) |  |  | (1,253 | ) |
| Restructuring and impairment costs | (105 | ) |  |  | (141 | ) |
| Net financing charges | (109 | ) |  |  | (120 | ) |
| Equity income | 65 |  |  |  | 63 |  |
| Income from continuing operations before income taxes | 892 |  |  |  | 1,062 |  |
| Income tax provision | 67 |  |  |  | 135 |  |
| Income from continuing operations | 825 |  |  |  | 927 |  |
| Loss from discontinued operations, net of tax | — |  |  |  | — |  |
| Net income | 825 |  |  |  | 927 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 54 |  |  |  | 52 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | — |  |
| Net income attributable to JCI | $ | 771 |  |  |  | $ | 875 |  |
| Income from continuing operations | $ | 771 |  |  |  | $ | 875 |  |
| Loss from discontinued operations | — |  |  |  | — |  |
| Net income attributable to JCI | $ | 771 |  |  |  | $ | 875 |  |
| Diluted earnings per share from continuing operations | $ | 0.83 |  |  |  | $ | 0.93 |  |
| Diluted loss per share from discontinued operations | — |  |  |  | — |  |
| Diluted earnings per share | $ | 0.83 |  |  |  | $ | 0.93 |  |
| Diluted weighted average shares | 930.5 |  |  |  | 938.0 |  |
| Shares outstanding at period end | 925.0 |  |  |  | 928.0 |  |

[0000833444-18-000046:8k_2_02:91]
Page 9 of 18

[0000833444-18-000046:8k_2_02:92]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Twelve Months Ended September 30, |
|  |  | 2018 |  |  | 2017 |
| Net sales | $ | 31,400 |  |  |  | $ | 30,172 |  |
| Cost of sales | 22,020 |  |  |  | 20,833 |  |
|  | Gross profit | 9,380 |  |  |  | 9,339 |  |
| Selling, general and administrative expenses | (6,010 | ) |  |  | (6,158 | ) |
| Restructuring and impairment costs | (263 | ) |  |  | (367 | ) |
| Net financing charges | (441 | ) |  |  | (496 | ) |
| Equity income | 235 |  |  |  | 240 |  |
| Income from continuing operations before income taxes | 2,901 |  |  |  | 2,558 |  |
| Income tax provision | 518 |  |  |  | 705 |  |
| Income from continuing operations | 2,383 |  |  |  | 1,853 |  |
| Loss from discontinued operations, net of tax | — |  |  |  | (34 | ) |
| Net income | 2,383 |  |  |  | 1,819 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 221 |  |  |  | 199 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | 9 |  |
| Net income attributable to JCI | $ | 2,162 |  |  |  | $ | 1,611 |  |
| Income from continuing operations | $ | 2,162 |  |  |  | $ | 1,654 |  |
| Loss from discontinued operations | — |  |  |  | (43 | ) |
| Net income attributable to JCI | $ | 2,162 |  |  |  | $ | 1,611 |  |
| Diluted earnings per share from continuing operations | $ | 2.32 |  |  |  | $ | 1.75 |  |
| Diluted loss per share from discontinued operations | — |  |  |  | (0.05 | ) |
| Diluted earnings per share* | $ | 2.32 |  |  |  | $ | 1.71 |  |
| Diluted weighted average shares | 931.7 |  |  |  | 944.6 |  |
| Shares outstanding at period end | 925.0 |  |  |  | 928.0 |  |

[0000833444-18-000046:8k_2_02:93]
* May not sum due to rounding.

[0000833444-18-000046:8k_2_02:94]
Page 10 of 18

[0000833444-18-000046:8k_2_02:95]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | September 30,2018 |  | September 30,2017 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 200 |  |  | $ | 321 |  |
| Accounts receivable - net | 7,065 |  |  | 6,666 |  |
| Inventories | 3,224 |  |  | 3,209 |  |
| Assets held for sale | — |  |  | 189 |  |
| Other current assets | 1,334 |  |  | 1,907 |  |
|  | Current assets | 11,823 |  |  | 12,292 |  |
| Property, plant and equipment - net | 6,171 |  |  | 6,121 |  |
| Goodwill | 19,473 |  |  | 19,688 |  |
| Other intangible assets - net | 6,348 |  |  | 6,741 |  |
| Investments in partially-owned affiliates | 1,301 |  |  | 1,191 |  |
| Noncurrent assets held for sale | — |  |  | 1,920 |  |
| Other noncurrent assets | 3,681 |  |  | 3,931 |  |
|  | Total assets | $ | 48,797 |  |  | $ | 51,884 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 1,341 |  |  | $ | 1,608 |  |
| Accounts payable and accrued expenses | 5,790 |  |  | 5,342 |  |
| Liabilities held for sale | — |  |  | 72 |  |
| Other current liabilities | 4,119 |  |  | 4,832 |  |
|  | Current liabilities | 11,250 |  |  | 11,854 |  |
| Long-term debt | 9,654 |  |  | 11,964 |  |
| Other noncurrent liabilities | 5,435 |  |  | 6,315 |  |
| Noncurrent liabilities held for sale | — |  |  | 173 |  |
| Redeemable noncontrolling interests | — |  |  | 211 |  |
| Shareholders' equity attributable to JCI | 21,164 |  |  | 20,447 |  |
| Noncontrolling interests | 1,294 |  |  | 920 |  |
|  | Total liabilities and equity | $ | 48,797 |  |  | $ | 51,884 |  |

[0000833444-18-000046:8k_2_02:96]
Page 11 of 18

[0000833444-18-000046:8k_2_02:97]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Three Months Ended September 30, |
|  |  |  |  |  |  | 2018 |  |  | 2017 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI | $ | 771 |  |  |  | $ | 875 |  |
| Income from continuing operations attributable to noncontrolling interests | 54 |  |  |  | 52 |  |
| Net income | 825 |  |  |  | 927 |  |
| Adjustments to reconcile net income to cash provided by operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 241 |  |  |  | 269 |  |
|  |  | Pension and postretirement benefit income | (48 | ) |  |  | (384 | ) |
|  |  | Pension and postretirement contributions | (3 | ) |  |  | (72 | ) |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (55 | ) |  |  | (15 | ) |
|  |  | Deferred income taxes | (561 | ) |  |  | 69 |  |
|  |  | Non-cash restructuring and impairment costs | 12 |  |  |  | 8 |  |
|  |  | Other - net | (2 | ) |  |  | 18 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (231 | ) |  |  | (201 | ) |
|  |  |  |  | Inventories | 246 |  |  |  | 187 |  |
|  |  |  |  | Other assets | 90 |  |  |  | (222 | ) |
|  |  |  |  | Restructuring reserves | 55 |  |  |  | 67 |  |
|  |  |  |  | Accounts payable and accrued liabilities | 213 |  |  |  | 826 |  |
|  |  |  |  | Accrued income taxes | 470 |  |  |  | (143 | ) |
|  |  |  |  |  | Cash provided by operating activities | 1,252 |  |  |  | 1,334 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (248 | ) |  |  | (347 | ) |
| Sale of property, plant and equipment | 25 |  |  |  | 10 |  |
| Acquisition of businesses, net of cash acquired | 3 |  |  |  | — |  |
| Business divestitures, net of cash divested | 101 |  |  |  | 40 |  |
| Other - net | 30 |  |  |  | (8 | ) |
|  |  |  |  |  | Cash used by investing activities | (89 | ) |  |  | (305 | ) |
| Financing Activities |  |  |  |  |
| Decrease in short and long-term debt - net | (962 | ) |  |  | (755 | ) |
| Stock repurchases | (45 | ) |  |  | (225 | ) |
| Payment of cash dividends | (240 | ) |  |  | (233 | ) |
| Proceeds from the exercise of stock options | 27 |  |  |  | 27 |  |
| Dividends paid to noncontrolling interests | — |  |  |  | (10 | ) |
| Other - net | (4 | ) |  |  | (3 | ) |
|  |  |  |  |  | Cash used by financing activities | (1,224 | ) |  |  | (1,199 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (22 | ) |  |  | 42 |  |
| Cash held for sale | — |  |  |  | (9 | ) |
| Decrease in cash and cash equivalents | $ | (83 | ) |  |  | $ | (137 | ) |

[0000833444-18-000046:8k_2_02:98]
Page 12 of 18

[0000833444-18-000046:8k_2_02:99]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Twelve Months Ended September 30, |
|  |  |  |  |  |  | 2018 |  |  | 2017 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI | $ | 2,162 |  |  |  | $ | 1,611 |  |
| Income from continuing operations attributable to noncontrolling interests | 221 |  |  |  | 199 |  |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | 9 |  |
| Net income | 2,383 |  |  |  | 1,819 |  |
| Adjustments to reconcile net income to cash provided by operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 1,085 |  |  |  | 1,188 |  |
|  |  | Pension and postretirement benefit income | (156 | ) |  |  | (568 | ) |
|  |  | Pension and postretirement contributions | (57 | ) |  |  | (347 | ) |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (166 | ) |  |  | (181 | ) |
|  |  | Deferred income taxes | (636 | ) |  |  | 1,125 |  |
|  |  | Non-cash restructuring and impairment costs | 42 |  |  |  | 78 |  |
|  |  | Gain on Scott Safety business divestiture | (114 | ) |  |  | — |  |
|  |  | Other - net | 67 |  |  |  | 135 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (513 | ) |  |  | (520 | ) |
|  |  |  |  | Inventories | (92 | ) |  |  | (398 | ) |
|  |  |  |  | Other assets | 26 |  |  |  | (480 | ) |
|  |  |  |  | Restructuring reserves | (8 | ) |  |  | 89 |  |
|  |  |  |  | Accounts payable and accrued liabilities | 15 |  |  |  | 236 |  |
|  |  |  |  | Accrued income taxes | 637 |  |  |  | (2,145 | ) |
|  |  |  |  |  | Cash provided by operating activities | 2,513 |  |  |  | 31 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (1,030 | ) |  |  | (1,343 | ) |
| Sale of property, plant and equipment | 48 |  |  |  | 33 |  |
| Acquisition of businesses, net of cash acquired | (21 | ) |  |  | (6 | ) |
| Business divestitures, net of cash divested | 2,202 |  |  |  | 220 |  |
| Other - net | 16 |  |  |  | (41 | ) |
|  |  |  |  |  | Cash provided (used) by investing activities | 1,215 |  |  |  | (1,137 | ) |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | (2,486 | ) |  |  | 713 |  |
| Debt financing costs | (4 | ) |  |  | (18 | ) |
| Stock repurchases | (300 | ) |  |  | (651 | ) |
| Payment of cash dividends | (954 | ) |  |  | (702 | ) |
| Proceeds from the exercise of stock options | 66 |  |  |  | 157 |  |
| Dividends paid to noncontrolling interests | (46 | ) |  |  | (88 | ) |
| Dividend from Adient spin-off | — |  |  |  | 2,050 |  |
| Cash transferred to Adient related to spin-off | — |  |  |  | (665 | ) |
| Cash paid related to prior acquisitions | — |  |  |  | (75 | ) |
| Other - net | (28 | ) |  |  | (23 | ) |
|  |  |  |  |  | Cash provided (used) by financing activities | (3,752 | ) |  |  | 698 |  |
| Effect of exchange rate changes on cash and cash equivalents | (106 | ) |  |  | 54 |  |
| Change in cash held for sale | 9 |  |  |  | 96 |  |
| Decrease in cash and cash equivalents | $ | (121 | ) |  |  | $ | (258 | ) |

[0000833444-18-000046:8k_2_02:100]
Page 13 of 18

[0000833444-18-000046:8k_2_02:101]
FOOTNOTES

[0000833444-18-000046:8k_2_02:102]
1. Financial Summary

[0000833444-18-000046:8k_2_02:103]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, significant restructuring and impairment costs, and the net mark-to-market adjustments related to pension and postretirement plans.

[0000833444-18-000046:8k_2_02:104]
|  | Three Months Ended September 30, |
| (in millions; unaudited) | 2018 |  | 2017 |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,324 |  |  | $ | 2,324 |  |  | $ | 2,160 |  |  | $ | 2,165 |  |
| Building Solutions EMEA/LA | 948 |  |  | 948 |  |  | 926 |  |  | 921 |  |
| Building Solutions Asia Pacific | 689 |  |  | 689 |  |  | 677 |  |  | 677 |  |
| Global Products | 2,222 |  |  | 2,222 |  |  | 2,241 |  |  | 2,241 |  |
| Total Building Technologies & Solutions | 6,183 |  |  | 6,183 |  |  | 6,004 |  |  | 6,004 |  |
| Power Solutions | 2,187 |  |  | 2,187 |  |  | 2,132 |  |  | 2,132 |  |
| Net sales | $ | 8,370 |  |  | $ | 8,370 |  |  | $ | 8,136 |  |  | $ | 8,136 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 329 |  |  | $ | 336 |  |  | $ | 298 |  |  | $ | 315 |  |
| Building Solutions EMEA/LA | 102 |  |  | 103 |  |  | 52 |  |  | 95 |  |
| Building Solutions Asia Pacific | 105 |  |  | 105 |  |  | 108 |  |  | 109 |  |
| Global Products | 389 |  |  | 395 |  |  | 373 |  |  | 385 |  |
| Total Building Technologies & Solutions | 925 |  |  | 939 |  |  | 831 |  |  | 904 |  |
| Power Solutions | 409 |  |  | 424 |  |  | 431 |  |  | 431 |  |
| Segment EBITA | 1,334 |  |  | 1,363 |  |  | 1,262 |  |  | 1,335 |  |
| Corporate expenses (2) | (142 | ) |  | (95 | ) |  | (163 | ) |  | (107 | ) |
| Amortization of intangible assets (3) | (96 | ) |  | (96 | ) |  | (106 | ) |  | (97 | ) |
| Mark-to-market gain for pension/postretirement plans (4) | 10 |  |  | — |  |  | 330 |  |  | — |  |
| Restructuring and impairment costs (5) | (105 | ) |  | — |  |  | (141 | ) |  | — |  |
| EBIT (6) | 1,001 |  |  | 1,172 |  |  | 1,182 |  |  | 1,131 |  |
| EBIT margin | 12.0 | % |  | 14.0 | % |  | 14.5 | % |  | 13.9 | % |
| Net financing charges (7) | (109 | ) |  | (109 | ) |  | (120 | ) |  | (120 | ) |
| Income from continuing operations before income taxes | 892 |  |  | 1,063 |  |  | 1,062 |  |  | 1,011 |  |
| Income tax provision (8) | (67 | ) |  | (139 | ) |  | (135 | ) |  | (152 | ) |
| Income from continuing operations | 825 |  |  | 924 |  |  | 927 |  |  | 859 |  |
| Income from continuing operations attributable to noncontrolling interests (9) | (54 | ) |  | (54 | ) |  | (52 | ) |  | (46 | ) |
| Net income from continuing operations attributable to JCI | $ | 771 |  |  | $ | 870 |  |  | $ | 875 |  |  | $ | 813 |  |

[0000833444-18-000046:8k_2_02:105]
|  | Twelve Months Ended September 30, |
| (in millions; unaudited) | 2018 |  | 2017 |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 8,679 |  |  | $ | 8,679 |  |  | $ | 8,341 |  |  | $ | 8,316 |  |
| Building Solutions EMEA/LA | 3,696 |  |  | 3,696 |  |  | 3,595 |  |  | 3,579 |  |
| Building Solutions Asia Pacific | 2,553 |  |  | 2,553 |  |  | 2,444 |  |  | 2,445 |  |
| Global Products | 8,472 |  |  | 8,472 |  |  | 8,455 |  |  | 8,461 |  |
| Total Building Technologies & Solutions | 23,400 |  |  | 23,400 |  |  | 22,835 |  |  | 22,801 |  |
| Power Solutions | 8,000 |  |  | 8,000 |  |  | 7,337 |  |  | 7,337 |  |
| Net sales | $ | 31,400 |  |  | $ | 31,400 |  |  | $ | 30,172 |  |  | $ | 30,138 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 1,109 |  |  | $ | 1,134 |  |  | $ | 1,039 |  |  | $ | 1,070 |  |
| Building Solutions EMEA/LA | 344 |  |  | 350 |  |  | 290 |  |  | 328 |  |
| Building Solutions Asia Pacific | 347 |  |  | 347 |  |  | 323 |  |  | 332 |  |
| Global Products | 1,338 |  |  | 1,251 |  |  | 1,179 |  |  | 1,288 |  |
| Total Building Technologies & Solutions | 3,138 |  |  | 3,082 |  |  | 2,831 |  |  | 3,018 |  |
| Power Solutions | 1,417 |  |  | 1,432 |  |  | 1,427 |  |  | 1,428 |  |
| Segment EBITA | 4,555 |  |  | 4,514 |  |  | 4,258 |  |  | 4,446 |  |
| Corporate expenses (2) | (576 | ) |  | (408 | ) |  | (768 | ) |  | (465 | ) |
| Amortization of intangible assets (3) | (384 | ) |  | (384 | ) |  | (489 | ) |  | (382 | ) |
| Mark-to-market gain for pension/postretirement plans (4) | 10 |  |  | — |  |  | 420 |  |  | — |  |
| Restructuring and impairment costs (5) | (263 | ) |  | — |  |  | (367 | ) |  | — |  |
| EBIT (6) | 3,342 |  |  | 3,722 |  |  | 3,054 |  |  | 3,599 |  |
| EBIT margin | 10.6 | % |  | 11.9 | % |  | 10.1 | % |  | 11.9 | % |
| Net financing charges (7) | (441 | ) |  | (441 | ) |  | (496 | ) |  | (479 | ) |
| Income from continuing operations before income taxes | 2,901 |  |  | 3,281 |  |  | 2,558 |  |  | 3,120 |  |
| Income tax provision (8) | (518 | ) |  | (427 | ) |  | (705 | ) |  | (468 | ) |
| Income from continuing operations | 2,383 |  |  | 2,854 |  |  | 1,853 |  |  | 2,652 |  |
| Income from continuing operations attributable to noncontrolling interests (9) | (221 | ) |  | (221 | ) |  | (199 | ) |  | (193 | ) |
| Net income from continuing operations attributable to JCI | $ | 2,162 |  |  | $ | 2,633 |  |  | $ | 1,654 |  |  | $ | 2,459 |  |

[0000833444-18-000046:8k_2_02:106]
Building Technologies & Solutions - Provides facility systems and services including comfort, energy and security management for the non-residential buildings market, and provides heating, ventilating, and air conditioning products and services, security products and services, and fire detection and suppression products and services.

[0000833444-18-000046:8k_2_02:107]
Power Solutions - Services both automotive original equipment manufacturers and the battery aftermarket by providing advanced battery technology, coupled with systems engineering, marketing and service expertise.

[0000833444-18-000046:8k_2_02:108]
Page 14 of 18

[0000833444-18-000046:8k_2_02:109]
(1) The Company's press release contains financial information regarding adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures.  The Company's definition of adjusted segment EBITA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-18-000046:8k_2_02:110]
The following is the three months ended September 30, 2018 and 2017 reconciliation of net sales, segment EBITA and segment EBITA margin as reported to adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-18-000046:8k_2_02:111]
| (in millions) | Building SolutionsNorth America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | Total Building Technologies & Solutions |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales as reported | $ | 2,324 |  |  | $ | 2,160 |  |  | $ | 948 |  |  | $ | 926 |  |  | $ | 689 |  |  | $ | 677 |  |  | $ | 2,222 |  |  | $ | 2,241 |  |  | $ | 6,183 |  |  | $ | 6,004 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring purchase accounting impacts | — |  |  | 5 |  |  | — |  |  | (5 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Adjusted net sales | $ | 2,324 |  |  | $ | 2,165 |  |  | $ | 948 |  |  | $ | 921 |  |  | $ | 689 |  |  | $ | 677 |  |  | $ | 2,222 |  |  | $ | 2,241 |  |  | $ | 6,183 |  |  | $ | 6,004 |  |
| Segment EBITA as reported | $ | 329 |  |  | $ | 298 |  |  | $ | 102 |  |  | $ | 52 |  |  | $ | 105 |  |  | $ | 108 |  |  | $ | 389 |  |  | $ | 373 |  |  | $ | 925 |  |  | $ | 831 |  |
| Segment EBITA margin as reported | 14.2 | % |  | 13.8 | % |  | 10.8 | % |  | 5.6 | % |  | 15.2 | % |  | 16.0 | % |  | 17.5 | % |  | 16.6 | % |  | 15.0 | % |  | 13.8 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Integration costs | 7 |  |  | 18 |  |  | 1 |  |  | 2 |  |  | — |  |  | 2 |  |  | 6 |  |  | 12 |  |  | 14 |  |  | 34 |  |
| Restructuring costs and discontinued operations losses in equity income | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Unfavorable arbitration award | — |  |  | — |  |  | — |  |  | 50 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 50 |  |
| Nonrecurring purchase accounting impacts | — |  |  | (1 | ) |  | — |  |  | (9 | ) |  | — |  |  | (1 | ) |  | — |  |  | — |  |  | — |  |  | (11 | ) |
| Adjusted segment EBITA | $ | 336 |  |  | $ | 315 |  |  | $ | 103 |  |  | $ | 95 |  |  | $ | 105 |  |  | $ | 109 |  |  | $ | 395 |  |  | $ | 385 |  |  | $ | 939 |  |  | $ | 904 |  |
| Adjusted segment EBITA margin | 14.5 | % |  | 14.5 | % |  | 10.9 | % |  | 10.3 | % |  | 15.2 | % |  | 16.1 | % |  | 17.8 | % |  | 17.2 | % |  | 15.2 | % |  | 15.1 | % |

[0000833444-18-000046:8k_2_02:112]
| (in millions) | Total Building Technologies & Solutions |  | Power Solutions |  | Consolidated JCI plc |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales as reported | $ | 6,183 |  |  | $ | 6,004 |  |  | $ | 2,187 |  |  | $ | 2,132 |  |  | $ | 8,370 |  |  | $ | 8,136 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring purchase accounting impacts | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Adjusted net sales | $ | 6,183 |  |  | $ | 6,004 |  |  | $ | 2,187 |  |  | $ | 2,132 |  |  | $ | 8,370 |  |  | $ | 8,136 |  |
| Segment EBITA as reported | $ | 925 |  |  | $ | 831 |  |  | $ | 409 |  |  | $ | 431 |  |  | $ | 1,334 |  |  | $ | 1,262 |  |
| Segment EBITA margin as reported | 15.0 | % |  | 13.8 | % |  | 18.7 | % |  | 20.2 | % |  | 15.9 | % |  | 15.5 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | — |  |  | 8 |  |  | — |  |  | 8 |  |  | — |  |
| Integration costs | 14 |  |  | 34 |  |  | — |  |  | — |  |  | 14 |  |  | 34 |  |
| Restructuring costs and discontinued operations losses in equity income | — |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |  | — |  |
| Unfavorable arbitration award | — |  |  | 50 |  |  | — |  |  | — |  |  | — |  |  | 50 |  |
| Nonrecurring purchase accounting impacts | — |  |  | (11 | ) |  | — |  |  | — |  |  | — |  |  | (11 | ) |
| Adjusted segment EBITA | $ | 939 |  |  | $ | 904 |  |  | $ | 424 |  |  | $ | 431 |  |  | $ | 1,363 |  |  | $ | 1,335 |  |
| Adjusted segment EBITA margin | 15.2 | % |  | 15.1 | % |  | 19.4 | % |  | 20.2 | % |  | 16.3 | % |  | 16.4 | % |

[0000833444-18-000046:8k_2_02:113]
The following is the twelve months ended September 30, 2018 and 2017 reconciliation of net sales, segment EBITA and segment EBITA margin as reported to adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-18-000046:8k_2_02:114]
| (in millions) | Building SolutionsNorth America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | Total Building Technologies & Solutions |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales as reported | $ | 8,679 |  |  | $ | 8,341 |  |  | $ | 3,696 |  |  | $ | 3,595 |  |  | $ | 2,553 |  |  | $ | 2,444 |  |  | $ | 8,472 |  |  | $ | 8,455 |  |  | $ | 23,400 |  |  | $ | 22,835 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring purchase accounting impacts | — |  |  | (25 | ) |  | — |  |  | (16 | ) |  | — |  |  | 1 |  |  | — |  |  | 6 |  |  | — |  |  | (34 | ) |
| Adjusted net sales | $ | 8,679 |  |  | $ | 8,316 |  |  | $ | 3,696 |  |  | $ | 3,579 |  |  | $ | 2,553 |  |  | $ | 2,445 |  |  | $ | 8,472 |  |  | $ | 8,461 |  |  | $ | 23,400 |  |  | $ | 22,801 |  |
| Segment EBITA as reported | $ | 1,109 |  |  | $ | 1,039 |  |  | $ | 344 |  |  | $ | 290 |  |  | $ | 347 |  |  | $ | 323 |  |  | $ | 1,338 |  |  | $ | 1,179 |  |  | $ | 3,138 |  |  | $ | 2,831 |  |
| Segment EBITA margin as reported | 12.8 | % |  | 12.5 | % |  | 9.3 | % |  | 8.1 | % |  | 13.6 | % |  | 13.2 | % |  | 15.8 | % |  | 13.9 | % |  | 13.4 | % |  | 12.4 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | 13 |  |  | — |  |  | 5 |  |  | — |  |  | 2 |  |  | — |  |  | 13 |  |  | — |  |  | 33 |  |
| Integration costs | 25 |  |  | 42 |  |  | 6 |  |  | 6 |  |  | — |  |  | 5 |  |  | 27 |  |  | 25 |  |  | 58 |  |  | 78 |  |
| Scott Safety gain on sale | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (114 | ) |  | — |  |  | (114 | ) |  | — |  |
| Restructuring costs and discontinued operations losses in equity income | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Unfavorable arbitration award | — |  |  | — |  |  | — |  |  | 50 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 50 |  |
| Nonrecurring purchase accounting impacts | — |  |  | (24 | ) |  | — |  |  | (23 | ) |  | — |  |  | 2 |  |  | — |  |  | 71 |  |  | — |  |  | 26 |  |
| Adjusted segment EBITA | $ | 1,134 |  |  | $ | 1,070 |  |  | $ | 350 |  |  | $ | 328 |  |  | $ | 347 |  |  | $ | 332 |  |  | $ | 1,251 |  |  | $ | 1,288 |  |  | $ | 3,082 |  |  | $ | 3,018 |  |
| Adjusted segment EBITA margin | 13.1 | % |  | 12.9 | % |  | 9.5 | % |  | 9.2 | % |  | 13.6 | % |  | 13.6 | % |  | 14.8 | % |  | 15.2 | % |  | 13.2 | % |  | 13.2 | % |

[0000833444-18-000046:8k_2_02:115]
| (in millions) | Total Building Technologies & Solutions |  | Power Solutions |  | Consolidated JCI plc |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net sales as reported | $ | 23,400 |  |  | $ | 22,835 |  |  | $ | 8,000 |  |  | $ | 7,337 |  |  | $ | 31,400 |  |  | $ | 30,172 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring purchase accounting impacts | — |  |  | (34 | ) |  | — |  |  | — |  |  | — |  |  | (34 | ) |
| Adjusted net sales | $ | 23,400 |  |  | $ | 22,801 |  |  | $ | 8,000 |  |  | $ | 7,337 |  |  | $ | 31,400 |  |  | $ | 30,138 |  |
| Segment EBITA as reported | $ | 3,138 |  |  | $ | 2,831 |  |  | $ | 1,417 |  |  | $ | 1,427 |  |  | $ | 4,555 |  |  | $ | 4,258 |  |
| Segment EBITA margin as reported | 13.4 | % |  | 12.4 | % |  | 17.7 | % |  | 19.4 | % |  | 14.5 | % |  | 14.1 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | 33 |  |  | 8 |  |  | 1 |  |  | 8 |  |  | 34 |  |
| Integration costs | 58 |  |  | 78 |  |  | — |  |  | — |  |  | 58 |  |  | 78 |  |
| Scott Safety gain on sale | (114 | ) |  | — |  |  | — |  |  | — |  |  | (114 | ) |  | — |  |
| Restructuring costs and discontinued operations losses in equity income | — |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |  | — |  |
| Unfavorable arbitration award | — |  |  | 50 |  |  | — |  |  | — |  |  | — |  |  | 50 |  |
| Nonrecurring purchase accounting impacts | — |  |  | 26 |  |  | — |  |  | — |  |  | — |  |  | 26 |  |
| Adjusted segment EBITA | $ | 3,082 |  |  | $ | 3,018 |  |  | $ | 1,432 |  |  | $ | 1,428 |  |  | $ | 4,514 |  |  | $ | 4,446 |  |
| Adjusted segment EBITA margin | 13.2 | % |  | 13.2 | % |  | 17.9 | % |  | 19.5 | % |  | 14.4 | % |  | 14.8 | % |

[0000833444-18-000046:8k_2_02:116]
(2) Adjusted Corporate expenses for the three months ended September 30, 2018 excludes $43 million of integration costs and $4 million of transaction costs.  Adjusted Corporate expenses for the twelve months ended September 30, 2018 excludes $154 million of integration costs and $14 million of transaction costs.  Adjusted Corporate expenses for the three months ended September 30, 2017 excludes $56 million of integration costs.  Adjusted Corporate expenses for the twelve months ended September 30, 2017 excludes $241 million of integration costs, $58 million of transaction costs and $4 million of separation costs.

[0000833444-18-000046:8k_2_02:117]
(3) Adjusted amortization of intangible assets for the three and twelve months ended September 30, 2017 excludes $9 million and $107 million, respectively, of nonrecurring asset amortization related to Tyco purchase accounting.

[0000833444-18-000046:8k_2_02:118]
(4) The three and twelve months ended September 30, 2018 pension and postretirement mark-to-market gain of $10 million is excluded from the adjusted non-GAAP results.  The three months ended September 30, 2017 pension and postretirement mark-to-market gain of $330 million and the twelve months ended September 30, 2017 gain of $420 million are excluded from the adjusted non-GAAP results.

[0000833444-18-000046:8k_2_02:119]
(5) The three and twelve months ended September 30, 2018 restructuring and impairment costs of $105 million and $263 million, respectively, are excluded from the adjusted non-GAAP results.  The three and twelve months ended September 30, 2017 restructuring and impairment costs of $141 million and $367 million, respectively, are excluded from the adjusted non-GAAP results.

[0000833444-18-000046:8k_2_02:120]
(6) Management defines earnings before interest and taxes (EBIT) as income from continuing operations before net financing charges, income taxes and noncontrolling interests.

[0000833444-18-000046:8k_2_02:121]
(7) Adjusted net financing charges for the twelve months ended September 30, 2017 exclude $17 million of transaction costs related to the debt exchange offers.

[0000833444-18-000046:8k_2_02:122]
(8) Adjusted income tax provision for the three months ended September 30, 2018 excludes the tax benefits for changes in entity tax status of $139 million, net tax provision changes related to the U.S. Tax Reform legislation of $96 million, restructuring and impairment costs of $14 million, mark-to-market pension and postretirement of $3 million, integration costs of $3 million and transaction costs of $2 million, partially offset by tax provisions related to legal entity restructuring associated with the Power Solutions business of $129 million and valuation allowance adjustments of $56 million.  Adjusted income tax provision for the twelve months ended September 30, 2018 excludes legal entity restructuring associated with the Power Solutions business of $129 million, net tax provision related to the U.S. Tax Reform legislation of $108 million, valuation allowance adjustments of $56 million and Scott Safety gain on sale of $30 million, partially offset by the tax benefits for changes in entity tax status of $139 million, restructuring and impairment costs of $38 million, tax audit settlements of $25 million, integration costs of $24 million, mark-to-market pension and postretirement of $3 million and transaction costs of $3 million.  Adjusted income tax provision for the three months ended September 30, 2017 excludes the tax benefits for tax audit settlements of $191 million, integration costs of $16 million and restructuring and impairment costs of $14 million, partially offset by the tax provisions for the pension and postretirement mark-to-market gain of $90 million, change in deferred tax liability related to the outside basis of certain nonconsolidated subsidiaries of $53 million, change in assertion over permanently reinvested earnings of $33 million, net valuation allowance adjustments in various legal entities of $27 million, and Tyco nonrecurring purchase accounting impacts of $1 million.  Adjusted income tax provision for the twelve months ended September 30, 2017 excludes the non-cash tax charge of $457 million related to establishment of a deferred tax liability on the outside basis difference of the Company’s investment in certain subsidiaries of the Scott Safety business, pension and postretirement mark-to-market gain of $126 million, change in deferred tax liability related to the outside basis of certain nonconsolidated subsidiaries of $53 million, change in assertion over permanently reinvested earnings of $33 million and net valuation allowance adjustments in various legal entities of $27 million, partially offset by the tax benefits of tax audit settlements of $191 million, changes in entity tax status of $101 million, restructuring and impairment costs of $63 million, integration costs of $57 million, Tyco nonrecurring purchase accounting impacts of $35 million and transaction costs of $12 million.

[0000833444-18-000046:8k_2_02:123]
(9) Adjusted income from continuing operations attributable to noncontrolling interests for the three and twelve months ended September 30, 2017 excludes the noncontrolling interest impact of $4 million for mark-to-market pension gain and $2 million for valuation allowance adjustments.

[0000833444-18-000046:8k_2_02:124]
Page 15 of 18

[0000833444-18-000046:8k_2_02:125]
2. Diluted Earnings Per Share Reconciliation

[0000833444-18-000046:8k_2_02:126]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure.  The adjusting items include transaction/integration/separation costs, restructuring costs and discontinued operations losses in equity income, nonrecurring purchase accounting impacts related to the Tyco merger, mark-to-market gain for pension and postretirement plans, Scott Safety gain on sale, restructuring and impairment costs, unfavorable arbitration award and discrete tax items.  The Company excludes these items because they are not considered to be directly related to the underlying operating performance of the Company.  Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-18-000046:8k_2_02:127]
A reconciliation of diluted earnings per share as reported to diluted adjusted earnings per share for the respective periods is shown below (unaudited):

[0000833444-18-000046:8k_2_02:128]
|  | Net Income Attributable to JCI plc |  | Net Income Attributableto JCI plc fromContinuing Operations |
|  | Three Months Ended |  | Three Months Ended |
|  | September 30, |  | September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Earnings per share as reported for JCI plc | $ | 0.83 |  |  | $ | 0.93 |  |  | $ | 0.83 |  |  | $ | 0.93 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction costs | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |
| Related tax impact | — |  |  | — |  |  | — |  |  | — |  |
| Integration costs | 0.06 |  |  | 0.10 |  |  | 0.06 |  |  | 0.10 |  |
| Related tax impact | — |  |  | (0.02 | ) |  | — |  |  | (0.02 | ) |
| Restructuring costs and discontinued operations losses in equity income | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |
| Mark-to-market gain for pension/postretirement plans | (0.01 | ) |  | (0.35 | ) |  | (0.01 | ) |  | (0.35 | ) |
| Related tax impact | — |  |  | 0.10 |  |  | — |  |  | 0.10 |  |
| Restructuring and impairment costs | 0.11 |  |  | 0.15 |  |  | 0.11 |  |  | 0.15 |  |
| Related tax impact | (0.02 | ) |  | (0.01 | ) |  | (0.02 | ) |  | (0.01 | ) |
| Unfavorable arbitration award | — |  |  | 0.05 |  |  | — |  |  | 0.05 |  |
| Discrete tax items | (0.05 | ) |  | (0.08 | ) |  | (0.05 | ) |  | (0.08 | ) |
| Adjusted earnings per share for JCI plc* | $ | 0.93 |  |  | $ | 0.87 |  |  | $ | 0.93 |  |  | $ | 0.87 |  |

[0000833444-18-000046:8k_2_02:129]
* May not sum due to rounding.

[0000833444-18-000046:8k_2_02:130]
|  | Net Income Attributable to JCI plc |  | Net Income Attributableto JCI plc fromContinuing Operations |
|  | Twelve Months Ended |  | Twelve Months Ended |
|  | September 30, |  | September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Earnings per share as reported for JCI plc | $ | 2.32 |  |  | $ | 1.71 |  |  | $ | 2.32 |  |  | $ | 1.75 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction costs | 0.02 |  |  | 0.12 |  |  | 0.02 |  |  | 0.12 |  |
| Related tax impact | — |  |  | (0.01 | ) |  | — |  |  | (0.01 | ) |
| Integration costs | 0.23 |  |  | 0.34 |  |  | 0.23 |  |  | 0.34 |  |
| Related tax impact | (0.03 | ) |  | (0.06 | ) |  | (0.03 | ) |  | 0.06 |  |
| Separation costs | — |  |  | 0.09 |  |  | — |  |  | — |  |
| Restructuring costs and discontinued operations losses in equity income | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |
| Nonrecurring purchase accounting impacts | — |  |  | 0.14 |  |  | — |  |  | 0.14 |  |
| Related tax impact | — |  |  | (0.04 | ) |  | — |  |  | (0.04 | ) |
| Mark-to-market gain for pension/postretirement plans | (0.01 | ) |  | (0.44 | ) |  | (0.01 | ) |  | (0.44 | ) |
| Related tax impact | — |  |  | 0.13 |  |  | — |  |  | 0.13 |  |
| Scott Safety gain on sale | (0.12 | ) |  | — |  |  | (0.12 | ) |  | — |  |
| Related tax impact | 0.03 |  |  | — |  |  | 0.03 |  |  | — |  |
| Restructuring and impairment costs | 0.28 |  |  | 0.39 |  |  | 0.28 |  |  | 0.39 |  |
| Related tax impact | (0.04 | ) |  | (0.07 | ) |  | (0.04 | ) |  | (0.07 | ) |
| Unfavorable arbitration award | — |  |  | 0.05 |  |  | — |  |  | 0.05 |  |
| Discrete tax items | 0.14 |  |  | 0.32 |  |  | 0.14 |  |  | 0.30 |  |
| Adjusted earnings per share for JCI plc* | $ | 2.83 |  |  | $ | 2.67 |  |  | $ | 2.83 |  |  | $ | 2.60 |  |

[0000833444-18-000046:8k_2_02:131]
* May not sum due to rounding.

[0000833444-18-000046:8k_2_02:132]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-18-000046:8k_2_02:133]
|  | Three Months Ended |  | Twelve Months Ended |
|  | September 30, |  | September 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Weighted Average Shares Outstanding for JCI plc |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 924.8 |  |  | 929.4 |  |  | 925.7 |  |  | 935.3 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock |  |  |  |  |  |  |  |
| and unvested performance share awards | 5.7 |  |  | 8.6 |  |  | 6.0 |  |  | 9.3 |  |
| Diluted weighted average shares outstanding | 930.5 |  |  | 938.0 |  |  | 931.7 |  |  | 944.6 |  |

[0000833444-18-000046:8k_2_02:134]
The Company has presented forward-looking statements regarding adjusted EPS from continuing operations, adjusted EBIT organic growth, adjusted EBIT margin, organic adjusted net sales growth and adjusted free cash flow conversion for the full fiscal year of 2019, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts, expenses, income or cash flows from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts that are excluded from these non-GAAP financial measures are a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period, including but not limited to the high variability of the net mark-to-market adjustments related to pension and postretirement plans and the effect of foreign currency exchange fluctuations.  Our fiscal 2019 outlook for organic adjusted net sales growth also excludes the effect of acquisitions and divestitures, and for our Power Solutions business, the impacts of lead price fluctuations.  We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available and management cannot reliably predict all of the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s full year 2019 GAAP financial results.

[0000833444-18-000046:8k_2_02:135]
Page 16 of 18

[0000833444-18-000046:8k_2_02:136]
3. Organic Adjusted Net Sales Growth Reconciliation

[0000833444-18-000046:8k_2_02:137]
The components of the changes in adjusted net sales for the three months ended September 30, 2018 versus the three months ended September 30, 2017, including organic net sales, is shown below (unaudited):

[0000833444-18-000046:8k_2_02:138]
| (in millions) | Adjusted Net Sales for the Three Months Ended September 30, 2017 |  | Base Year Adjustments -Acquisitions and Divestitures |  | Adjusted Base Net Sales for the Three Months Ended September 30, 2017 |  | Foreign Currency |  | Lead Impact |  | Organic Net Sales |  | Adjusted Net Sales for the Three Months EndedSeptember 30, 2018 |
| Building Solutions North America | $ | 2,165 |  |  | $ | — |  |  | 0.0 | % |  | $ | 2,165 |  |  | $ | (8 | ) |  | -0.4 | % |  | $ | — |  |  | 0.0 | % |  | $ | 167 |  |  | 7.7 | % |  | $ | 2,324 |  |  | 7.3 | % |
| Building Solutions EMEA/LA | 921 |  |  | 2 |  |  | 0.2 | % |  | 923 |  |  | (28 | ) |  | -3.0 | % |  | — |  |  | 0.0 | % |  | 53 |  |  | 5.7 | % |  | 948 |  |  | 2.7 | % |
| Building Solutions Asia Pacific | 677 |  |  | (2 | ) |  | -0.3 | % |  | 675 |  |  | (14 | ) |  | -2.1 | % |  | — |  |  | 0.0 | % |  | 28 |  |  | 4.1 | % |  | 689 |  |  | 2.1 | % |
| Global Products | 2,241 |  |  | (189 | ) |  | -8.4 | % |  | 2,052 |  |  | (24 | ) |  | -1.2 | % |  | — |  |  | 0.0 | % |  | 194 |  |  | 9.5 | % |  | 2,222 |  |  | 8.3 | % |
| Total Building Technologies & Solutions | 6,004 |  |  | (189 | ) |  | -3.1 | % |  | 5,815 |  |  | (74 | ) |  | -1.3 | % |  | — |  |  | 0.0 | % |  | 442 |  |  | 7.6 | % |  | 6,183 |  |  | 6.3 | % |
| Power Solutions | 2,132 |  |  | — |  |  | 0.0 | % |  | 2,132 |  |  | (32 | ) |  | -1.5 | % |  | 39 |  |  | 1.8 | % |  | 48 |  |  | 2.3 | % |  | 2,187 |  |  | 2.6 | % |
| Total net sales | $ | 8,136 |  |  | $ | (189 | ) |  | -2.3 | % |  | $ | 7,947 |  |  | $ | (106 | ) |  | -1.3 | % |  | $ | 39 |  |  | 0.5 | % |  | $ | 490 |  |  | 6.2 | % |  | $ | 8,370 |  |  | 5.3 | % |

[0000833444-18-000046:8k_2_02:139]
The components of the changes in adjusted net sales for the twelve months ended September 30, 2018 versus the twelve months ended September 30, 2017, including organic net sales, is shown below (unaudited):

[0000833444-18-000046:8k_2_02:140]
| (in millions) | Adjusted Net Sales for the Twelve Months Ended September 30, 2017 |  | Base Year Adjustments -Acquisitions and Divestitures |  | Adjusted Base Net Sales for the Twelve Months Ended September 30, 2017 |  | Foreign Currency |  | Lead Impact |  | Organic Net Sales |  | Adjusted Net Sales for the Twelve Months EndedSeptember 30, 2018 |
| Building Solutions North America | $ | 8,316 |  |  | $ | — |  |  | 0.0 | % |  | $ | 8,316 |  |  | $ | 20 |  |  | 0.2 | % |  | $ | — |  |  | 0.0 | % |  | $ | 343 |  |  | 4.1 | % |  | $ | 8,679 |  |  | 4.4 | % |
| Building Solutions EMEA/LA | 3,579 |  |  | (78 | ) |  | -2.2 | % |  | 3,501 |  |  | 132 |  |  | 3.8 | % |  | — |  |  | 0.0 | % |  | 63 |  |  | 1.8 | % |  | 3,696 |  |  | 5.6 | % |
| Building Solutions Asia Pacific | 2,445 |  |  | (14 | ) |  | -0.6 | % |  | 2,431 |  |  | 61 |  |  | 2.5 | % |  | — |  |  | 0.0 | % |  | 61 |  |  | 2.5 | % |  | 2,553 |  |  | 5.0 | % |
| Global Products | 8,461 |  |  | (663 | ) |  | -7.8 | % |  | 7,798 |  |  | 103 |  |  | 1.3 | % |  | — |  |  | 0.0 | % |  | 571 |  |  | 7.3 | % |  | 8,472 |  |  | 8.6 | % |
| Total Building Technologies & Solutions | 22,801 |  |  | (755 | ) |  | -3.3 | % |  | 22,046 |  |  | 316 |  |  | 1.4 | % |  | — |  |  | 0.0 | % |  | 1,038 |  |  | 4.7 | % |  | 23,400 |  |  | 6.1 | % |
| Power Solutions | 7,337 |  |  | — |  |  | 0.0 | % |  | 7,337 |  |  | 196 |  |  | 2.7 | % |  | 269 |  |  | 3.7 | % |  | 198 |  |  | 2.7 | % |  | 8,000 |  |  | 9.0 | % |
| Total net sales | $ | 30,138 |  |  | $ | (755 | ) |  | -2.5 | % |  | $ | 29,383 |  |  | $ | 512 |  |  | 1.7 | % |  | $ | 269 |  |  | 0.9 | % |  | $ | 1,236 |  |  | 4.2 | % |  | $ | 31,400 |  |  | 6.9 | % |

[0000833444-18-000046:8k_2_02:141]
4. Adjusted Free Cash Flow Reconciliation

[0000833444-18-000046:8k_2_02:142]
The Company's press release contains financial information regarding free cash flow, adjusted free cash flow and adjusted free cash flow conversion, which are non-GAAP performance measures.  Free cash flow is defined as cash used by operating activities less capital expenditures.  Adjusted free cash flow excludes special items, as included in the table below, because these cash flows are not considered to be directly related to its underlying business.  Adjusted free cash flow conversion is defined as adjusted free cash flow divided by adjusted net income from continuing operations attributable to JCI.  Management believes these non-GAAP measures are useful to investors in understanding the strength of the Company and its ability to generate cash.

[0000833444-18-000046:8k_2_02:143]
The following is the three and twelve months ended September 30, 2018 and 2017 reconciliation of free cash flow, adjusted free cash flow and adjusted free cash flow conversion (unaudited):

[0000833444-18-000046:8k_2_02:144]
| (in billions) | Three Months Ended September 30, 2018 |  | Three Months Ended September 30, 2017 |  | Twelve Months Ended September 30, 2018 |  | Twelve Months Ended September 30, 2017 |
| Cash provided by operating activities | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 2.5 |  |  | $ | — |  |
| Capital expenditures | (0.2 | ) |  | (0.3 | ) |  | (1.0 | ) |  | (1.3 | ) |
| Reported free cash flow* | 1.0 |  |  | 1.0 |  |  | 1.5 |  |  | (1.3 | ) |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction/integration/separation costs | 0.1 |  |  | 0.1 |  |  | 0.3 |  |  | 0.5 |  |
| Nonrecurring tax payments | 0.2 |  |  | — |  |  | 0.3 |  |  | 1.4 |  |
| Adient cash outflow | — |  |  | — |  |  | — |  |  | 0.3 |  |
| Change in control pension payment | — |  |  | — |  |  | — |  |  | 0.2 |  |
| Restructuring payments | — |  |  | — |  |  | 0.2 |  |  | 0.2 |  |
| Total adjusting items | 0.3 |  |  | 0.1 |  |  | 0.8 |  |  | 2.6 |  |
| Adjusted free cash flow | $ | 1.3 |  |  | $ | 1.1 |  |  | $ | 2.3 |  |  | $ | 1.3 |  |
| Adjusted net income from continuing operations |  |  |  |  |  |  |  |
| attributable to JCI | $ | 0.9 |  |  | $ | 0.8 |  |  | $ | 2.6 |  |  | $ | 2.5 |  |
| Adjusted free cash flow conversion | 144 | % |  | 138 | % |  | 88 | % |  | 52 | % |

[0000833444-18-000046:8k_2_02:145]
*May not sum due to rounding

[0000833444-18-000046:8k_2_02:146]
Page 17 of 18

[0000833444-18-000046:8k_2_02:147]
5. Net Debt to Capitalization

[0000833444-18-000046:8k_2_02:148]
The Company provides financial information regarding net debt as a percentage of total capitalization, which is a non-GAAP performance measure.  The Company believes the percentage of total net debt to total capitalization is useful to understanding the Company's financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders.  The following is the September 30, 2018 and September 30, 2017 calculation of net debt as a percentage of total capitalization (unaudited):

[0000833444-18-000046:8k_2_02:149]
| (in millions) | September 30, 2018 |  | September 30, 2017 |
| Short-term debt and current portion of long-term debt | $ | 1,341 |  |  | $ | 1,608 |  |
| Long-term debt | 9,654 |  |  | 11,964 |  |
| Total debt | 10,995 |  |  | 13,572 |  |
| Less: cash and cash equivalents | 200 |  |  | 321 |  |
| Total net debt | 10,795 |  |  | 13,251 |  |
| Shareholders' equity attributable to JCI | 21,164 |  |  | 20,447 |  |
| Total capitalization | $ | 31,959 |  |  | $ | 33,698 |  |
| Total net debt as a % of total capitalization | 33.8 | % |  | 39.3 | % |

[0000833444-18-000046:8k_2_02:150]
6. Mark-to-Market of Pension and Postretirement Plans

[0000833444-18-000046:8k_2_02:151]
The pension and postretirement mark-to-market gain or loss for each period is excluded from adjusted diluted earnings per share.  The three and twelve months ended September 30, 2018 include a mark-to-market gain for pension and postretirement plans of $10 million.  The three and twelve months ended September 30, 2017 include a mark-to-market gain for pension and postretirement plans of $330 million and $420 million, respectively.

[0000833444-18-000046:8k_2_02:152]
7. Divestitures

[0000833444-18-000046:8k_2_02:153]
On March 16, 2017, the Company announced that it signed a definitive agreement to sell its Scott Safety business to 3M for approximately $2.0 billion.  The transaction closed on October 4, 2017.  Net cash proceeds from the transaction approximated $1.9 billion and the Company recorded a net gain of $114 million ($84 million after tax).  Scott Safety is a leader in the design, manufacture and sale of high performance respiratory protection, gas and flame detection, thermal imaging and other critical products for fire services, law enforcement, industrial, oil and gas, chemical, armed forces, and homeland defense end markets.  The Scott Safety business is included within assets held for sale and liabilities held for sale in the accompanying condensed consolidated statement of financial position as of September 30, 2017.

[0000833444-18-000046:8k_2_02:154]
On October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience business from JCI plc to Adient plc and the issuance of ordinary shares of Adient plc directly to holders of JCI plc ordinary shares on a pro rata basis.  Following the separation, Adient plc is now an independent public company trading on the New York Stock Exchange (NYSE) under the symbol "ADNT." The Company did not retain any equity interest in Adient plc.  Beginning in the first quarter of fiscal 2017, Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation.

[0000833444-18-000046:8k_2_02:155]
8. Income Taxes

[0000833444-18-000046:8k_2_02:156]
The Company's effective tax rate from continuing operations before consideration of the transaction/integration/separation costs, restructuring costs and discontinued operations losses in equity income, nonrecurring purchase accounting impacts related to the Tyco merger, mark-to-market gain for pension and postretirement plans, Scott Safety gain on sale, restructuring and impairment costs, an unfavorable arbitration award and discrete tax items for the three and twelve months ending September 30, 2018 and 2017 is approximately 13 percent and 15 percent, respectively.

[0000833444-18-000046:8k_2_02:157]
9. Restructuring

[0000833444-18-000046:8k_2_02:158]
The three and twelve months ended September 30, 2018 include restructuring and impairment costs of $105 million and $263 million, respectively, related primarily to workforce reductions, plant closures and asset impairments in the Building Technologies & Solutions and Power Solutions businesses, and at Corporate.  The three and twelve months ended September 30, 2017 include restructuring and impairment costs of $141 million and $367 million, respectively, related primarily to workforce reductions, plant closures and asset impairments in the Building Technologies & Solutions and Power Solutions businesses, and at Corporate.

[0000833444-18-000046:8k_2_02:159]
Page 18 of 18
