# JCI notes — 0000833444-18-000053


## jci:AssetsandLiabilitiesHeldforSalePolicyTextBlock

[0000833444-18-000053:notes:1]
Assets and Liabilities Held for Sale

[0000833444-18-000053:notes:2]
The Company classifies assets and liabilities (disposal groups) to be sold as held for sale in the period in which all of the following criteria are met: management, having the authority to approve the action, commits to a plan to sell the disposal group; the disposal group is available for immediate sale in its present condition subject only to terms that are usual and customary for sales of such disposal groups; an active program to locate a buyer and other actions required to complete the plan to sell the disposal group have been initiated; the sale of the disposal group is probable, and transfer of the disposal group is expected to qualify for recognition as a completed sale within one year, except if events or circumstances beyond the Company's control extend the period of time required to sell the disposal group beyond one year; the disposal group is being actively marketed for sale at a price that is reasonable in relation to its current fair value; and actions required to complete the plan indicate that it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn.

[0000833444-18-000053:notes:3]
In addition, the Company classifies disposal groups to be disposed of other than by sale (e.g. spin-off) as held for sale in the period the disposal occurs.

[0000833444-18-000053:notes:4]
The Company initially measures a disposal group that is classified as held for sale at the lower of its carrying value or fair value less any costs to sell. Any loss resulting from this measurement is recognized in the period in which the held for sale criteria are met. Conversely, gains are not recognized on the sale of a disposal group until the date of sale. The Company assesses the fair value of a disposal group, less any costs to sell, each reporting period it remains classified as held for sale and reports any subsequent changes as an adjustment to the carrying value of the disposal group, as long as the new carrying value does not exceed the carrying value of the disposal group at the time it was initially classified as held for sale.

[0000833444-18-000053:notes:5]
Upon determining that a disposal group meets the criteria to be classified as held for sale, the Company reports the assets and liabilities of the disposal group, if material, in the line items assets held for sale and liabilities held for sale in the consolidated statements of financial position. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information.


## jci:ComponentsOfNetFinancingChargesTableTextBlock

[0000833444-18-000053:notes:6]
The Company's net financing charges line item in the consolidated statements of income for the years ended September 30, 2018, 2017 and 2016 contained the following components (in millions):

[0000833444-18-000053:notes:7]
|  | Year Ended September 30, |
|  | 2018 |  | 2017 |  | 2016 |
| Interest expense, net of capitalized interest costs | $ | 437 |  |  | $ | 466 |  |  | $ | 293 |  |
| Banking fees and bond cost amortization | 58 |  |  | 67 |  |  | 30 |  |
| Interest income | (29 | ) |  | (19 | ) |  | (12 | ) |
| Net foreign exchange results for financing activities | (25 | ) |  | (18 | ) |  | (22 | ) |
| Net financing charges | $ | 441 |  |  | $ | 496 |  |  | $ | 289 |  |


## jci:DeferredTaxesClassifiedInConsolidatedStatementsOfFinancialPositionTableTextBlock

[0000833444-18-000053:notes:8]
Deferred taxes were classified in the consolidated statements of financial position as follows (in millions):

[0000833444-18-000053:notes:9]
|  | September 30, |
|  | 2018 |  | 2017 |
| Other noncurrent assets | 1,591 |  |  | 2,360 |  |
| Other noncurrent liabilities | (763 | ) |  | (1,733 | ) |
| Net deferred tax asset | $ | 828 |  |  | $ | 627 |  |


## jci:DerivativeAssetsandLiabilitiesEligibleforOffsettingTableTextBlock

[0000833444-18-000053:notes:10]
The gross and net amounts of derivative assets and liabilities were as follows (in millions):

[0000833444-18-000053:notes:11]
|  | Fair Value of Assets |  | Fair Value of Liabilities |
|  | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |  |
| Gross amount recognized | $ | 80 |  |  | $ | 91 |  |  | $ | 3,175 |  |  | $ | 2,105 |  |  |
| Gross amount eligible for offsetting | (12 | ) |  | (16 | ) |  | (12 | ) |  | (16 | ) |  |
| Net amount | $ | 68 |  |  | $ | 75 |  |  | $ | 3,163 |  |  | $ | 2,089 |  |  |


## jci:DisposalGroupIncludingDiscontinuedOperationsIncomeStatementDisclosuresTableTextBlock

[0000833444-18-000053:notes:12]
The following table summarizes the results of Adient, reclassified as discontinued operations for the fiscal years ended September 30, 2017 and 2016 (in millions). As the Adient spin-off occurred on October 31, 2016, there is only one month of Adient results included in the year ended September 30, 2017.

[0000833444-18-000053:notes:13]
|  |  | Year Ended September 30, |
|  |  | 2017 |  | 2016 |
| Net sales |  | $ | 1,434 |  |  | $ | 16,837 |  |
| Income from discontinued operations before income taxes |  | 1 |  |  | 525 |  |
| Provision for income taxes on discontinued operations |  | 35 |  |  | 2,041 |  |
| Income from discontinued operations attributable to noncontrolling interests, net of tax |  | 9 |  |  | 84 |  |
| Loss from discontinued operations |  | $ | (43 | ) |  | $ | (1,600 | ) |


## jci:EquityAttributableToParentAndNoncontrollingInterestsTableTextBlock

[0000833444-18-000053:notes:14]
The following schedules present changes in consolidated equity attributable to Johnson Controls and noncontrolling interests (in millions, net of tax):

[0000833444-18-000053:notes:15]
|  | Equity Attributable to Johnson ControlsInternational plc |  | Equity Attributable to Noncontrolling Interests |  | Total Equity |
| At September 30, 2015 | $ | 10,335 |  |  | $ | 163 |  |  | $ | 10,498 |  |
| Total comprehensive income (loss): |  |  |  |  |  |
| Net income (loss) | (868 | ) |  | 168 |  |  | (700 | ) |
| Foreign currency translation adjustments | (105 | ) |  | 9 |  |  | (96 | ) |
| Realized and unrealized gains (losses) on derivatives | 11 |  |  | (1 | ) |  | 10 |  |
| Unrealized losses on marketable securities | (1 | ) |  | — |  |  | (1 | ) |
| Pension and postretirement plans | (1 | ) |  | — |  |  | (1 | ) |
| Other comprehensive income (loss) | (96 | ) |  | 8 |  |  | (88 | ) |
| Comprehensive income (loss) | (964 | ) |  | 176 |  |  | (788 | ) |
| Other changes in equity: |  |  |  |  |  |
| Result of contribution of Johnson Controls, Inc. to Johnson Controls International plc | 15,808 |  |  | — |  |  | 15,808 |  |
| Cash dividends - common stock ($1.16 per share) | (752 | ) |  | — |  |  | (752 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (93 | ) |  | (93 | ) |
| Repurchases of common stock | (501 | ) |  | — |  |  | (501 | ) |
| Change in noncontrolling interest share | — |  |  | 726 |  |  | 726 |  |
| Other, including options exercised | 192 |  |  | — |  |  | 192 |  |
| At September 30, 2016 | 24,118 |  |  | 972 |  |  | 25,090 |  |
| Total comprehensive income (loss): |  |  |  |  |  |
| Net income | 1,611 |  |  | 164 |  |  | 1,775 |  |
| Foreign currency translation adjustments | 108 |  |  | (18 | ) |  | 90 |  |
| Realized and unrealized gains (losses) on derivatives | (14 | ) |  | 1 |  |  | (13 | ) |
| Realized and unrealized gains on marketable securities | 5 |  |  | — |  |  | 5 |  |
| Other comprehensive income (loss) | 99 |  |  | (17 | ) |  | 82 |  |
| Comprehensive income | 1,710 |  |  | 147 |  |  | 1,857 |  |
| Other changes in equity: |  |  |  |  |  |
| Cash dividends - ordinary shares ($1.00 per share) | (938 | ) |  | — |  |  | (938 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (56 | ) |  | (56 | ) |
| Repurchases of ordinary shares | (651 | ) |  | — |  |  | (651 | ) |
| Change in noncontrolling interest share | — |  |  | (5 | ) |  | (5 | ) |
| Spin-off of Adient | (4,038 | ) |  | (138 | ) |  | (4,176 | ) |
| Other, including options exercised | 246 |  |  | — |  |  | 246 |  |
| At September 30, 2017 | 20,447 |  |  | 920 |  |  | 21,367 |  |
| Total comprehensive income (loss): |  |  |  |  |  |
| Net income | 2,162 |  |  | 186 |  |  | 2,348 |  |
| Foreign currency translation adjustments | (458 | ) |  | (22 | ) |  | (480 | ) |
| Realized and unrealized losses on derivatives | (19 | ) |  | (1 | ) |  | (20 | ) |
| Realized and unrealized gains on marketable securities | 4 |  |  | — |  |  | 4 |  |
| Other comprehensive loss | (473 | ) |  | (23 | ) |  | (496 | ) |
| Comprehensive income | 1,689 |  |  | 163 |  |  | 1,852 |  |
| Other changes in equity: |  |  |  |  |  |
| Cash dividends - ordinary shares ($1.04 per share) | (968 | ) |  | — |  |  | (968 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (43 | ) |  | (43 | ) |
| Repurchases of ordinary shares | (300 | ) |  | — |  |  | (300 | ) |
| Change in noncontrolling interest share | — |  |  | 23 |  |  | 23 |  |
| Adoption of ASU 2016-09 | 179 |  |  | — |  |  | 179 |  |
| Reclassification from redeemable noncontrolling interest | — |  |  | 231 |  |  | 231 |  |
| Other, including options exercised | 117 |  |  | — |  |  | 117 |  |
| At September 30, 2018 | $ | 21,164 |  |  | $ | 1,294 |  |  | $ | 22,458 |  |


## jci:FutureMinimumCapitalAndOperatingLeasePaymentsAndRelatedPresentValueOfCapitalLeasePaymentsTableTextBlock

[0000833444-18-000053:notes:16]
Future minimum capital and operating lease payments and the related present value of capital lease payments at September 30, 2018 were as follows (in millions):

[0000833444-18-000053:notes:17]
|  | CapitalLeases |  | OperatingLeases |
| 2019 | $ | 5 |  |  | $ | 348 |  |
| 2020 | 6 |  |  | 284 |  |
| 2021 | 6 |  |  | 208 |  |
| 2022 | 15 |  |  | 152 |  |
| 2023 | 2 |  |  | 111 |  |
| After 2023 | 9 |  |  | 97 |  |
| Total minimum lease payments | 43 |  |  | $ | 1,200 |  |
| Interest | (7 | ) |  |  |
| Present value of net minimum lease payments | $ | 36 |  |  |  |


## jci:HedgeForecastedPurchasesTableTextBlock

[0000833444-18-000053:notes:18]
The Company had the following outstanding contracts to hedge forecasted commodity purchases (in metric tons):

[0000833444-18-000053:notes:19]
|  |  | Volume Outstanding as of |
| Commodity |  | September 30, 2018 |  | September 30, 2017 |
| Copper |  | 3,175 |  |  | 1,962 |  |
| Polypropylene |  | 15,868 |  |  | 19,563 |  |
| Lead |  | 49,066 |  |  | 24,705 |  |
| Aluminum |  | 3,381 |  |  | 2,169 |  |
| Tin |  | 3,076 |  |  | 1,715 |  |


## jci:ScheduleOfIntangibleAssetsTableTextBlock

[0000833444-18-000053:notes:20]
The Company’s other intangible assets, primarily from business acquisitions valued based on independent appraisals, consisted of (in millions):

[0000833444-18-000053:notes:21]
|  | September 30, 2018 |  | September 30, 2017 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Amortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,334 |  |  | $ | (266 | ) |  | $ | 1,068 |  |  | $ | 1,328 |  |  | $ | (137 | ) |  | $ | 1,191 |  |
| Customer relationships | 3,078 |  |  | (664 | ) |  | 2,414 |  |  | 3,168 |  |  | (486 | ) |  | 2,682 |  |
| Miscellaneous | 496 |  |  | (200 | ) |  | 296 |  |  | 389 |  |  | (147 | ) |  | 242 |  |
| Total amortized intangible assets | 4,908 |  |  | (1,130 | ) |  | 3,778 |  |  | 4,885 |  |  | (770 | ) |  | 4,115 |  |
| Unamortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/tradenames | 2,448 |  |  | — |  |  | 2,448 |  |  | 2,483 |  |  | — |  |  | 2,483 |  |
| Miscellaneous | 122 |  |  | — |  |  | 122 |  |  | 143 |  |  | — |  |  | 143 |  |
|  | 2,570 |  |  | — |  |  | 2,570 |  |  | 2,626 |  |  | — |  |  | 2,626 |  |
| Total intangible assets | $ | 7,478 |  |  | $ | (1,130 | ) |  | $ | 6,348 |  |  | $ | 7,511 |  |  | $ | (770 | ) |  | $ | 6,741 |  |


## jci:ScheduleofFairValueofConsiderationTransferredTableTextBlock

[0000833444-18-000053:notes:22]
The following table summarizes the total fair value of consideration transferred:

[0000833444-18-000053:notes:23]
| (in millions, except for share consolidation ratio and share data) |  |  |
| Number of Tyco shares outstanding at September 2, 2016 |  | 427,181,743 |  |
| Tyco share consolidation ratio |  | 0.955 |  |
| Tyco ordinary shares outstanding following the share consolidation and immediately prior to the Merger |  | 407,958,565 |  |
| JCI Inc. converted share price (1) |  | $ | 47.67 |  |
| Fair value of equity portion of the Merger consideration |  | $ | 19,447 |  |
| Fair value of Tyco equity awards |  | 224 |  |
| Total fair value of consideration transferred |  | $ | 19,671 |  |

[0000833444-18-000053:notes:24]
| (1) | Amount equals JCI Inc. closing share price and market capitalization at September 2, 2016 ($45.45 and $29,012 million, respectively) adjusted for the Tyco $3,864 million cash contribution used to purchase 110.8 million shares of JCI Inc. common stock for $34.88 per share. |


## jci:ScheduleofsharebasedpaymentawardperformancesharevaluationassumptionsTableTextBlock

[0000833444-18-000053:notes:25]
|  | Year Ended September 30, |
|  | 2018 |  | 2017 |
| Risk-free interest rate | 1.92% |  | 1.40% |
| Expected volatility of the Company’s stock | 21.70% |  | 21.00% |


## jci:ShareBasedCompensationArrangementByShareBasedPaymentAwardFairValueAssumptionsInStockAppreciationRightsTableTextBlock

[0000833444-18-000053:notes:26]
The assumptions used to determine the fair value of the SAR awards at September 30, 2018 were as follows:

[0000833444-18-000053:notes:27]
| Expected life of SAR (years) | 0.4 - 5.1 |
| Risk-free interest rate | 2.29% - 2.94% |
| Expected volatility of the Company’s stock | 23.70% |
| Expected dividend yield on the Company’s stock | 2.78% |


## jci:SharesoutstandingasoftheMergerdateTableTextBlock

[0000833444-18-000053:notes:28]
The shares outstanding as of the Merger date were calculated as follows (in millions, except share consolidation ratio and per share data):

[0000833444-18-000053:notes:29]
| Pre-merger Tyco shares outstanding |  | 427.2 |  |
| Share consolidation ratio |  | 0.955 |  |
| Post-share consolidation Tyco shares |  | 408.0 |  |
| Johnson Controls, Inc. shares outstanding |  | 638.3 |  |
| Cash contributed by Tyco used to purchase shares of Johnson Controls, Inc. |  | $ | 3,864 |  |
| Johnson Controls, Inc. per share consideration |  | $ | 34.88 |  |
| Reduction in shares due to cash consideration paid by Tyco |  | (110.8 | ) |
| Adjusted Johnson Controls, Inc. shares outstanding (1:1 exchange ratio) |  | 527.5 |  |
| Shares outstanding at September 2, 2016 |  | 935.5 |  |
| Par value |  | $ | 9 |  |


## jci:SubscriberSystemAssetsDealerIntangiblesandRelatedDeferredRevenueAccountsPolicyTextBlock

[0000833444-18-000053:notes:30]
Subscriber System Assets, Dealer Intangibles and Related Deferred Revenue Accounts

[0000833444-18-000053:notes:31]
The Building Technologies & Solutions business considers assets related to the acquisition of new customers in its electronic security business in three asset categories: internally generated residential subscriber systems outside of North America, internally generated commercial subscriber systems (collectively referred to as subscriber system assets) and customer accounts acquired through the ADT dealer program, primarily outside of North America (referred to as dealer intangibles). Subscriber system assets include installed property, plant and equipment for which the Company retains ownership and deferred costs directly related to the customer acquisition and system installation. Subscriber system assets represent capitalized equipment (e.g. security control panels, touchpad, motion detectors, window sensors, and other equipment) and installation costs associated with electronic security monitoring arrangements under which the Company retains ownership of the security system assets in a customer's place of business, or outside of North America, residence. Installation costs represent costs incurred to prepare the asset for its intended use. The Company pays property taxes on the subscriber system assets and upon customer termination, may retrieve such assets. These assets embody a probable future economic benefit as they generate future monitoring revenue for the Company.

[0000833444-18-000053:notes:32]
Costs related to the subscriber system equipment and installation are categorized as property, plant and equipment rather than deferred costs. Deferred costs associated with subscriber system assets represent direct and incremental selling expenses (such as commissions) related to acquiring the customer. Commissions related to up-front consideration paid by customers in connection with the establishment of the monitoring arrangement are determined based on a percentage of the up-front fees and do not exceed deferred revenue. Such deferred costs are recorded as other current and noncurrent assets within the consolidated statements of financial position.

[0000833444-18-000053:notes:33]
Subscriber system assets and any deferred revenue resulting from the customer acquisition are accounted for over the expected life of the subscriber. In certain geographical areas where the Company has a large number of customers that behave in a similar manner over time, the Company accounts for subscriber system assets and related deferred revenue using pools, with separate pools for the components of subscriber system assets and any related deferred revenue based on the same month and year of acquisition. The Company depreciates its pooled subscriber system assets and related deferred revenue using a straight-line method with lives up to 12 years and considering customer attrition. The Company uses a straight-line method with a 15-year life for non-pooled subscriber system assets (primarily in Europe, Latin America and Asia) and related deferred revenue, with remaining balances written off upon customer termination.

[0000833444-18-000053:notes:34]
Certain contracts and related customer relationships result from purchasing residential security monitoring contracts from an external network of independent dealers who operate under the ADT dealer program, primarily outside of North America. Acquired contracts and related customer relationships are recorded at their contractually determined purchase price.

[0000833444-18-000053:notes:35]
During the first 6 months (12 months in certain circumstances) after the purchase of the customer contract, any cancellation of monitoring service, including those that result from customer payment delinquencies, results in a chargeback by the Company to the dealer for the full amount of the contract purchase price. The Company records the amount charged back to the dealer as a reduction of the previously recorded intangible asset.

[0000833444-18-000053:notes:36]
Intangible assets arising from the ADT dealer program described above are amortized in pools determined by the same month and year of contract acquisition on a straight-line basis over the period of the customer relationship. The estimated useful life of dealer intangibles ranges from 12 to 15 years.


## jci:SummarizedBalanceSheetInformationNonConsolidatedPartiallyOwnedAffiliatesTableTextBlock

[0000833444-18-000053:notes:37]
Summarized balance sheet data as of September 30 is as follows (in millions):

[0000833444-18-000053:notes:38]
|  | 2018 |  | 2017 |
| Current assets | $ | 4,307 |  |  | $ | 4,034 |  |
| Noncurrent assets | 1,654 |  |  | 1,513 |  |
| Total assets | $ | 5,961 |  |  | $ | 5,547 |  |
| Current liabilities | $ | 2,718 |  |  | $ | 2,470 |  |
| Noncurrent liabilities | 459 |  |  | 478 |  |
| Noncontrolling interests | 39 |  |  | 33 |  |
| Shareholders’ equity | 2,745 |  |  | 2,566 |  |
| Total liabilities and shareholders’ equity | $ | 5,961 |  |  | $ | 5,547 |  |


## jci:SummarizedIncomeStatementInformationNonConsolidatedPartiallyOwnedAffiliatesTableTextBlock

[0000833444-18-000053:notes:39]
Summarized income statement data for the years ended September 30 is as follows (in millions):

[0000833444-18-000053:notes:40]
|  | 2018 |  | 2017 |  | 2016 |
| Net sales | $ | 7,686 |  |  | $ | 6,445 |  |  | $ | 5,329 |  |
| Gross profit | 1,855 |  |  | 1,510 |  |  | 1,323 |  |
| Net income | 547 |  |  | 517 |  |  | 415 |  |
| Income attributable to noncontrolling interests | 10 |  |  | 11 |  |  | 16 |  |
| Net income attributable to the entity | 537 |  |  | 506 |  |  | 399 |  |


## us-gaap:AssetImpairmentChargesTextBlock

[0000833444-18-000053:notes:41]
IMPAIRMENT OF LONG-LIVED ASSETS

[0000833444-18-000053:notes:42]
The Company reviews long-lived assets, including tangible assets and other intangible assets with definitive lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of software to be sold, leased, or marketed." ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. ASC 350-30 requires intangible assets acquired in a business combination that are used in research and development activities be considered indefinite lived until the completion or abandonment of the associated research and development efforts. During the period that those assets are considered indefinite lived, they shall not be amortized but shall be tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired. If the carrying amount of an intangible asset exceeds its fair value, an entity shall recognize an impairment loss in an amount equal to that excess. ASC 985-20 requires the unamortized capitalized costs of a computer software product be compared to the net realizable value of that product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset shall be written off.

[0000833444-18-000053:notes:43]
In fiscal 2018, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2018. As a result, the Company reviewed the long-lived assets for impairment and recorded $42 million of asset impairment charges within restructuring and impairment costs in the consolidated statements of income. Of the total impairment charges, $31 million related to the Global Products segment, $6 million related to the Power Solutions segment and $5 million related to Corporate assets. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-18-000053:notes:44]
In fiscal 2017, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2017. As a result, the Company reviewed the long-lived assets for impairment and recorded $77 million of asset impairment charges within restructuring and impairment costs on the consolidated statements of income. Of the total impairment charges, $30 million related to the Building Solutions North America segment, $20 million related to the Global Products segment, $19 million related to Corporate assets, $7 million related to the Power Solutions segment and $1 million related to the Building Solutions Asia Pacific segment. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-18-000053:notes:45]
In fiscal 2016, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2016. As a result, the Company reviewed the long-lived assets for impairment and recorded $103 million of asset impairment charges within restructuring and impairment costs on the consolidated statements of income. Of the total impairment charges, $64 million related to the Power Solutions segment, $24 million related to Corporate assets, $8 million related to the Global Products segment, $4 million related to the Building Solutions Asia Pacific segment and $3 million related to the Building Solutions EMEA/LA segment.  In addition, the Company recorded $87 million of asset impairments within discontinued operations related to Adient in fiscal 2016. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-18-000053:notes:46]
At September 30, 2018, 2017 and 2016, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets. Refer to Note 1, "Summary of Significant Accounting Policies," and Note 7, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for discussion of the Company’s goodwill impairment testing.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000833444-18-000053:notes:47]
The following unaudited pro forma information assumes the acquisition had occurred on October 1, 2014, and had been included in the Company's consolidated statement of income for fiscal year 2016.

[0000833444-18-000053:notes:48]
|  |  | Year Ended September 30, |
| (in millions) |  | 2016 |
| Pro forma net sales |  | $ | 29,647 |  |
| Pro forma net income from continuing operations |  | 1,143 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000833444-18-000053:notes:49]
Cash and Cash Equivalents

[0000833444-18-000053:notes:50]
The Company considers all highly liquid investments with an original maturity of three months or less when purchased to be cash equivalents.

[0000833444-18-000053:notes:51]
Restricted Cash

[0000833444-18-000053:notes:52]
At September 30, 2018, the Company held restricted cash of approximately $15 million, of which $6 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. At September 30, 2017, the Company held restricted cash of approximately $31 million, of which $22 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-18-000053:notes:53]
COMMITMENTS AND CONTINGENCIES

[0000833444-18-000053:notes:54]
Environmental Matters

[0000833444-18-000053:notes:55]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of September 30, 2018, reserves for environmental liabilities totaled $42 million, of which $11 million was recorded within other current liabilities and $31 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $51 million at September 30, 2017, of which $10 million was recorded within other current liabilities and $41 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At September 30, 2018 and 2017, the Company recorded conditional asset retirement obligations of $45 million and $61 million, respectively.

[0000833444-18-000053:notes:56]
Asbestos Matters

[0000833444-18-000053:notes:57]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-18-000053:notes:58]
As of September 30, 2018, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $173 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $550 million, of which $55 million was recorded in other current liabilities and $495 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $377 million, of which $33 million was recorded in other current assets and $344 million was recorded in other noncurrent assets. Assets included $6 million of cash and $281 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2018 was $90 million. As of September 30, 2017, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $181 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $573 million, of which $48 million was recorded in other current liabilities and $525 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $392 million, of which $53 million was recorded in other current assets and $339 million was recorded in other noncurrent assets. Assets included $22 million of cash and $269 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2017 was $101 million.

[0000833444-18-000053:notes:59]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-18-000053:notes:60]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-18-000053:notes:61]
Insurable Liabilities

[0000833444-18-000053:notes:62]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At September 30, 2018 and 2017, the insurable liabilities totaled $417 million and $445 million, respectively, of which $95 million and $122 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $300 million and $301 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at September 30, 2018 was $26 million, of which $6 million was recorded within other current assets and $20 million was recorded within other noncurrent assets. The amount of such receivables recorded at September 30, 2017 was $46 million, of which $31 million was recorded within other current assets and $15 million was recorded within other noncurrent assets. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-18-000053:notes:63]
Arbitration Award

[0000833444-18-000053:notes:64]
In September 2017, the Company was subject to an unfavorable arbitration award of approximately $50 million relating to a contractual dispute with a subcontractor used by the Company at an airport construction project in Doha, Qatar. In connection with the unfavorable arbitration award, the Company recorded a charge of $50 million within selling, general and administrative expenses on the consolidated statements of income in the fourth quarter of fiscal 2017. The airport project is being managed by a steering committee. The Company and the subcontractor were working jointly to document claims for increased costs against the steering committee when the subcontractor initiated the arbitration proceeding against the Company. Pursuant to its arbitration proceeding against the Company, the subcontractor sought to recover costs it alleges it incurred due to project delays, additional work and related financing costs. The Company has filed annulment proceedings with respect to the arbitration award in the local court in Qatar. In October 2018, the annulment proceeding was dismissed by the court. While the award remains outstanding, a portion of the balance will accrue interest at a statutory rate of 9.56%.

[0000833444-18-000053:notes:65]
In a related action, the Company has initiated an arbitration claim against the steering committee related to costs it incurred in connection with delays of the airport construction project, including costs related to the above award. The arbitrator is expected to issue a decision on the Company’s claims against the steering committee by the end of the first quarter of fiscal 2019.

[0000833444-18-000053:notes:66]
Aqueous Film-Forming Foam ("AFFF") Litigation

[0000833444-18-000053:notes:67]
Two of our subsidiaries, Chemguard, Inc. ("Chemguard") and Tyco Fire Products L.P. ("Tyco Fire Products"), have been named, along with other defendant manufacturers, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluorinated ("PFAS") compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued regulatory limits, however; while those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

[0000833444-18-000053:notes:68]
Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination. The Company is named in 19 putative class actions in federal and state courts in six states as set forth below:

[0000833444-18-000053:notes:69]
Colorado

[0000833444-18-000053:notes:70]
| • | District of Colorado - Bell et al. v. The 3M Company et al., filed September 18, 2016. |

[0000833444-18-000053:notes:71]
| • | District of Colorado - Davis et al. v. The 3M Company et al., filed September 22, 2016. |

[0000833444-18-000053:notes:72]
The above cases have been consolidated in the U.S. District Court for the District of Colorado, and a hearing on the plaintiffs’ motion for class certification is expected in 2018 with a trial date schedule for April 2019.

[0000833444-18-000053:notes:73]
Delaware

[0000833444-18-000053:notes:74]
| • | District of Delaware - Anderson v. The 3M Company et al., filed May 18, 2018 in the United States District Court District of Delaware. |

[0000833444-18-000053:notes:75]
| • | District of Delaware - Grubb v. The 3M Company et al., filed October 30, 2018 in the United States District Court District of Delaware. |

[0000833444-18-000053:notes:76]
Massachusetts

[0000833444-18-000053:notes:77]
| • | District of Massachusetts - Civitarese et al. v. The 3M Company et al., filed April 18, 2018 in the United States District Court of Massachusetts. |

[0000833444-18-000053:notes:78]
Washington

[0000833444-18-000053:notes:79]
| • | Eastern District of Washington - Ackerman et al. v. The 3M Company et al., filed April 5, 2018 in the United States District Court, Eastern District of Washington. |

[0000833444-18-000053:notes:80]
New York

[0000833444-18-000053:notes:81]
| • | Eastern District of New York - Green et al. v. The 3M Company et al., filed March 27, 2017 in Supreme Court of the State of New York, Suffolk County, prior to removal to federal court. |

[0000833444-18-000053:notes:82]
| • | Southern District of New York - Adamo et al. v. The Port Authority of NY and NJ et al., filed August 11, 2017 in Supreme Court of the State of New York, Orange County, prior to removal to federal court. |

[0000833444-18-000053:notes:83]
| • | Southern District of New York - Fogarty et al. v. The Port Authority of NY and NJ et al., filed August 11, 2017 in Supreme Court of the State of New York, Orange County, prior to removal to federal court. |

[0000833444-18-000053:notes:84]
| • | Southern District of New York - Miller et al. v. The Port Authority of NY and NJ et al., filed August 11, 2017 in Supreme Court of the State of New York, Orange County, prior to removal to federal court. |

[0000833444-18-000053:notes:85]
| • | Eastern District of New York - Singer et al. v. The 3M Company et al., filed October 10, 2017, in Supreme Court of the State of New York, Suffolk County, prior to removal to federal court. |

[0000833444-18-000053:notes:86]
| • | Eastern District of New York - Shipman et al. v. The 3M Company et al., filed March 21, 2018, in Supreme Court of the State of New York, Suffolk County, prior to removal to federal court. |

[0000833444-18-000053:notes:87]
| • | Eastern District of New York - Py et al. v. The 3M Company et al., filed April 26, 2018, in Supreme Court of the State of New York, Suffolk County, prior to removal to federal court. |

[0000833444-18-000053:notes:88]
| • | Supreme Court of the State of New York, Dutchess County - County of Dutchess v. 3M Company et al. - filed October 12, 2018. |

[0000833444-18-000053:notes:89]
Pennsylvania

[0000833444-18-000053:notes:90]
| • | Eastern District of Pennsylvania - Bates et al. v. The 3M Company et al., filed September 15, 2016. |

[0000833444-18-000053:notes:91]
| • | Eastern District of Pennsylvania - Grande et al. v. The 3M Company et al., filed October 13, 2016. |

[0000833444-18-000053:notes:92]
| • | Eastern District of Pennsylvania - Yockey et al. v. The 3M Company et al., filed October 24, 2016. |

[0000833444-18-000053:notes:93]
| • | Eastern District of Pennsylvania - Fearnley et al. v. The 3M Company et al., filed December 9, 2016. |

[0000833444-18-000053:notes:94]
The above cases have been consolidated in the U.S. District Court for the Eastern District of Pennsylvania. The defendants' motion to dismiss the complaint in the consolidated proceeding was denied without prejudice and the cases are currently stayed pending the appeal of an action in which the Company is not a party.

[0000833444-18-000053:notes:95]
In September of 2018, the Company filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation seeking to consolidate all existing and future federal cases into one jurisdiction. A hearing on this petition is set for November 29, 2018.

[0000833444-18-000053:notes:96]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. 3M Co., No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites.

[0000833444-18-000053:notes:97]
In addition, there are approximately 55 individual or “mass” actions pending in federal court in Colorado (41 cases), New York (4 cases) and Pennsylvania (10 cases) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York and 14 plaintiffs in Pennsylvania.  The Company is also on notice of approximately 629 other possible individual product liability claims and 3 possible municipal claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters, and, under Pennsylvania’s procedural rules, they may or may not result in lawsuits.

[0000833444-18-000053:notes:98]
Chemguard and Tyco Fire Products are also defendants in three municipal cases pending in the U.S. District Court for the District of Massachusetts: Town of Barnstable v. the 3M. Co., et al, (filed Nov. 21, 2016), County of Barnstable v. the 3M. Co., et al, (filed January 9, 2017) and City of Westfield v. the 3M Co., et al., (filed on February 24, 2018), as well as two municipal cases pending in the Eastern District of New York: Suffolk County Water Auth. v. 3M Co. (filed November 30, 2017) and Hampton Bays Water Dist. v. 3M Co. (filed Feb. 21, 2018), one municipal case pending in the Southern District of New York: City of Newburgh v. United States et al. (filed August 6, 2018), one municipal case pending in the Southern District of Ohio: City of Dayton v. The 3M Company et al. (filed October 3, 2018), one municipal case styled as a class action (discussed above) in the Supreme Court for the State of New York, Dutchess County: Dutchess County v. The 3M Company et al. (filed October 12, 2018), one municipal case pending in the Southern District of Florida, City of Stuart v. the 3M Company et al. (filed October 18, 2018), one municipal case filed in the Superior Court of the State of Arizona, County of Pima: City of Tuscon and Town of Marana v. The 3M Company et al. (filed November 8, 2018), one municipal case filed in the U.S. District Court for the District of New Jersey: New Jersey-American Water Company, Inc. v. The 3M Company et al., (filed November 8, 2018), and one municipal case pending in the Northern District of Florida: Emerald Coast Utilities Auth. v. 3M Co. (filed June 22, 2018). These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property. The defendants have filed motions to dismiss in County of Barnstable, City of Westfield, Suffolk County Water Authority, and Hampton Bays Water Authority.

[0000833444-18-000053:notes:99]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly resulting from the use of those products at the Peterson Air Force Base. In addition, three water districts in Pennsylvania, Horsham Water and Sewer Authority, Warminster Municipal Authority, and Warrington Township have filed praecipes for summons against Chemguard and Tyco Fire Products and other AFFF manufacturers relating to alleged PFOS and PFOA contamination.  These praecipes are not active suits, but have the effect of tolling the statute of limitations.

[0000833444-18-000053:notes:100]
Other AFFF Matters

[0000833444-18-000053:notes:101]
Tyco Fire Products, in coordination with the Wisconsin Department of Natural Resources ("WDNR") and the Wisconsin Department of Health Services ("DHS"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin.  In connection with the assessment, PFOS and PFOA have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC.  Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working closely with WDNR and DHS to develop interim measures to remove these compounds from certain areas where they have been detected.

[0000833444-18-000053:notes:102]
The Company is vigorously defending these cases and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.

[0000833444-18-000053:notes:103]
Other  Matters

[0000833444-18-000053:notes:104]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000833444-18-000053:notes:105]
Loss Contingencies

[0000833444-18-000053:notes:106]
Accruals are recorded for various contingencies including legal proceedings, environmental matters, self-insurance and other claims that arise in the normal course of business. The accruals are based on judgment, the probability of losses and, where applicable, the consideration of opinions of internal and/or external legal counsel and actuarially determined estimates. Additionally, the Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-18-000053:notes:107]
The Company is subject to laws and regulations relating to protecting the environment. The Company provides for expenses associated with environmental remediation obligations when such amounts are probable and can be reasonably estimated. Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements.

[0000833444-18-000053:notes:108]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company records receivables from third party insurers when recovery has been determined to be probable. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-18-000053:notes:109]
Asbestos-Related Contingencies and Insurance Receivables

[0000833444-18-000053:notes:110]
The Company and certain of its subsidiaries along with numerous other companies are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from  2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-18-000053:notes:111]
In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable. The Company's estimate of asbestos-related insurance recoveries represents estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims discounted to present value. In determining the amount of insurance recoverable, the Company considers available insurance, allocation methodologies, solvency and creditworthiness of the insurers. Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements for a discussion on management's judgments applied in the recognition and measurement of asbestos-related assets and liabilities.


## us-gaap:ConsolidationPolicyTextBlock

[0000833444-18-000053:notes:112]
Principles of Consolidation

[0000833444-18-000053:notes:113]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries that are consolidated in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). All significant intercompany transactions have been eliminated. The results of companies acquired or disposed of during the year are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company’s interest exceeds 20% and the Company does not have a controlling interest.

[0000833444-18-000053:notes:114]
Under certain criteria as provided for in Financial Accounting Standards Board ("FASB") ASC 810, "Consolidation," the Company may consolidate a partially-owned affiliate. To determine whether to consolidate a partially-owned affiliate, the Company first determines if the entity is a variable interest entity ("VIE"). An entity is considered to be a VIE if it has one of the following characteristics: 1) the entity is thinly capitalized; 2) residual equity holders do not control the entity; 3) equity holders are shielded from economic losses or do not participate fully in the entity’s residual economics; or 4) the entity was established with non-substantive voting. If the entity meets one of these characteristics, the Company then determines if it is the primary beneficiary of the VIE. The party with the power to direct activities of the VIE that most significantly impact the VIE’s economic performance and the potential to absorb benefits or losses that could be significant to the VIE is considered the primary beneficiary and consolidates the VIE. If the entity is not considered a VIE, then the Company applies the voting interest model to determine whether or not the Company shall consolidate the partially-owned affiliate.

[0000833444-18-000053:notes:115]
Consolidated VIEs

[0000833444-18-000053:notes:116]
Based upon the criteria set forth in ASC 810, the Company has determined that it was not the primary beneficiary in any VIEs for the reporting period ended September 30, 2018 and that it was the primary beneficiary in one VIE for the reporting period ended September 30, 2017, as the Company absorbed significant economics of the entity and had the power to direct the activities that are considered most significant to the entity.

[0000833444-18-000053:notes:117]
In fiscal 2012, a pre-existing VIE accounted for under the equity method was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The Company acquired additional interests in two of the reorganized group entities. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company was considered the primary beneficiary of one of the entities due to the Company’s power pertaining to decisions over significant activities of the entity. As such, this VIE was consolidated within the Company’s consolidated statements of financial position as of September 30, 2017. During the fiscal year ended September 30, 2018, certain joint venture agreements were amended and, as a result, the Company can no longer make key operating decisions considered to be most significant to the VIE. As such, the Company is no longer considered the primary beneficiary of this entity, and the Company deconsolidated the entity during the fiscal year ended September 30, 2018. The impact of the entity on the Company’s consolidated statements of income for the years ended September 30, 2018, 2017 and 2016 was not material.

[0000833444-18-000053:notes:118]
The carrying amounts and classification of assets (none of which are restricted) and liabilities included in the Company’s consolidated statements of financial position for the consolidated VIE is as follows (in millions):

[0000833444-18-000053:notes:119]
|  | September 30, |
|  | 2017 |
| Current assets | $ | 2 |  |
| Noncurrent assets | 53 |  |
| Total assets | $ | 55 |  |
| Current liabilities | $ | 6 |  |
| Noncurrent liabilities | 42 |  |
| Total liabilities | $ | 48 |  |

[0000833444-18-000053:notes:120]
The Company did not have a significant variable interest in any other consolidated VIEs for the presented reporting periods.

[0000833444-18-000053:notes:121]
Nonconsolidated VIEs

[0000833444-18-000053:notes:122]
As mentioned previously within the "Consolidated VIEs" section above, in fiscal 2012, a pre-existing VIE was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The VIEs are named as co-obligors under a third party debt agreement in the amount of $155 million, maturing in fiscal 2020, under which a VIE could become subject to paying more than its allocated share of the third party debt in the event of bankruptcy of one or more of the other co-obligors. The other co-obligors, all related parties in which the Company is an equity investor, consist of the remaining group entities involved in the reorganization. As part of the overall reorganization transaction, the Company has also provided financial support to the group entities in the form of loans totaling $38 million, which are subordinate to the third party debt agreement. The Company is a significant customer of certain co-obligors, resulting in a remote possibility of loss. Additionally, the Company is subject to a floor guaranty expiring in fiscal 2022; in the event that the other owner party no longer owns any part of the group entities due to sale or transfer, the Company has guaranteed that the proceeds received from the sale or transfer will not be less than $25 million. The Company has partnered with the group entities to design and manufacture battery components for the Power Solutions business. The Company is not considered to be the primary beneficiary of three of the entities as of September 30, 2018 and two of the entities as of September 30, 2017, as the Company cannot make key operating decisions considered to be most significant to the VIEs. Therefore, the entities are accounted for under the equity method of accounting as the Company’s interest exceeds 20% and the Company does not have a controlling interest. The Company’s maximum exposure to loss includes the partially-owned affiliate investment balance of $43 million and $65 million at September 30, 2018 and 2017, respectively, as well as the subordinated loan from the Company, third party debt agreement and floor guaranty mentioned above. Current liabilities due to the VIEs are not material and represent normal course of business trade payables for all presented periods.

[0000833444-18-000053:notes:123]
The Company did not have a significant variable interest in any other nonconsolidated VIEs for the presented reporting periods.


## us-gaap:DebtDisclosureTextBlock

[0000833444-18-000053:notes:124]
DEBT AND FINANCING ARRANGEMENTS

[0000833444-18-000053:notes:125]
Short-term debt consisted of the following (in millions):

[0000833444-18-000053:notes:126]
|  | September 30, |
|  | 2018 |  | 2017 |
| Bank borrowings and commercial paper | $ | 1,315 |  |  | $ | 1,214 |  |
| Weighted average interest rate on short-term debt outstanding | 2.8 | % |  | 1.6 | % |

[0000833444-18-000053:notes:127]
In connection with the Tyco Merger, JCI Inc. replaced its $2.5 billion committed five-year credit facility scheduled to mature in August 2018 with a $2.0 billion committed four-year credit facility scheduled to mature in August 2020. Additionally, TSarl, a wholly-owned subsidiary of Johnson Controls, entered into a $1.0 billion committed four-year credit facility scheduled to mature in August 2020.  The TSarl facility was increased to $1.25 billion in March 2018. The facilities are used to support the Company's outstanding commercial paper. There were no draws on either committed credit facilities during the fiscal years ended September 30, 2018 and 2017. Commercial paper outstanding as of September 30, 2018 and 2017 was $879 million and $954 million, respectively.

[0000833444-18-000053:notes:128]
In March 2018, the Company entered into a 364-day $250 million committed revolving credit facility scheduled to expire in March 2019. As of September 30, 2018, there were no draws on the facility.

[0000833444-18-000053:notes:129]
In March 2018, a 364-day $150 million committed revolving credit facility expired. The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2019. As of September 30, 2018, there were no draws on the facility.

[0000833444-18-000053:notes:130]
In February 2018, a 364-day $150 million committed revolving credit facility expired. The Company entered into a new $150 million committed revolving credit facility scheduled to expire in February 2019. As of September 30, 2018, there were no draws on the facility.

[0000833444-18-000053:notes:131]
In January 2018, a 364-day $250 million committed revolving credit facility expired. The Company entered into a new $200 million committed revolving credit facility scheduled to expire in January 2019. As of September 30, 2018, there were no draws on the facility.

[0000833444-18-000053:notes:132]
In December 2017, the Company repaid a 364-day 150 million euro floating rate term loan, plus accrued interest, scheduled to mature in September 2018.

[0000833444-18-000053:notes:133]
Long-term debt consisted of the following (in millions; due dates by fiscal year):

[0000833444-18-000053:notes:134]
|  | September 30, |
|  | 2018 |  | 2017 |
| Unsecured notes |  |  |  |
| JCI plc - 1.4% due in 2018 ($259 million par value) | $ | — |  |  | $ | 259 |  |
| JCI Inc. - 1.4% due in 2018 ($41 million par value) | — |  |  | 42 |  |
| JCI plc - 3.75% due in 2018 ($49 million par value) | — |  |  | 49 |  |
| Tyco International Finance S.A. ("TIFSA") - 3.75% due in 2018 ($18 million par value) | — |  |  | 18 |  |
| JCI plc - 5.00% due in 2020 ($453 million par value) | 452 |  |  | 452 |  |
| JCI Inc. - 5.00% due in 2020 ($47 million par value) | 47 |  |  | 47 |  |
| JCI plc - 0.00% due in 2021 (€750 million par value) | 868 |  |  | — |  |
| JCI plc - 4.25% due in 2021 ($447 million par value) | 446 |  |  | 446 |  |
| JCI Inc. - 4.25% due in 2021 ($53 million par value) | 53 |  |  | 53 |  |
| JCI plc - 3.75% due in 2022 ($428 million par value) | 427 |  |  | 427 |  |
| JCI Inc. - 3.75% due in 2022 ($22 million par value) | 22 |  |  | 22 |  |
| JCI plc - 4.625% due in 2023 ($35 million par value) | 37 |  |  | 38 |  |
| TIFSA - 4.625% due in 2023 ($7 million par value) | 8 |  |  | 8 |  |
| JCI plc - 1.00% due in 2023 (€1,000 million par value) | 1,154 |  |  | 1,171 |  |
| JCI plc - 3.625% due in 2024 ($468 million par value) | 468 |  |  | 468 |  |
| JCI Inc. - 3.625% due in 2024 ($31 million par value) | 31 |  |  | 31 |  |
| JCI plc - 1.375% due in 2025 (€423 million par value) | 501 |  |  | 510 |  |
| TIFSA - 1.375% due in 2025 (€58 million par value) | 69 |  |  | 70 |  |
| JCI plc - 3.90% due in 2026 ($698 million par value) | 755 |  |  | 763 |  |
| TIFSA - 3.90% due in 2026 ($51 million par value) | 52 |  |  | 53 |  |
| JCI plc - 6.00% due in 2036 ($392 million par value) | 388 |  |  | 388 |  |
| JCI Inc. - 6.00% due in 2036 ($8 million par value) | 8 |  |  | 8 |  |
| JCI plc - 5.70% due in 2041 ($270 million par value) | 269 |  |  | 269 |  |
| JCI Inc. - 5.70% due in 2041 ($30 million par value) | 30 |  |  | 30 |  |
| JCI plc - 5.25% due in 2042 ($242 million par value) | 242 |  |  | 242 |  |
| JCI Inc. - 5.25% due in 2042 ($8 million par value) | 8 |  |  | 8 |  |
| JCI plc - 4.625% due in 2044 ($445 million par value) | 441 |  |  | 441 |  |
| JCI Inc. - 4.625% due in 2044 ($6 million par value) | 6 |  |  | 6 |  |
| JCI plc - 5.125% due in 2045 ($727 million par value) | 867 |  |  | 872 |  |
| TIFSA - 5.125% due in 2045 ($23 million par value) | 23 |  |  | 23 |  |
| JCI plc - 6.95% due in 2046 ($121 million par value) | 121 |  |  | 121 |  |
| JCI Inc. - 6.95% due in 2046 ($4 million par value) | 4 |  |  | 4 |  |
| JCI plc - 4.50% due in 2047 ($500 million par value) | 496 |  |  | 495 |  |
| JCI plc - 4.95% due in 2064 ($435 million par value) | 434 |  |  | 434 |  |
| JCI Inc. - 4.95% due in 2064 ($15 million par value) | 15 |  |  | 15 |  |
| TSarl - Term Loan A - LIBOR plus 1.25% due in 2020 | 364 |  |  | 3,700 |  |
| TSarl - Term Loan B - €215 million; EURIBOR plus 0.62% due in 2020 | 250 |  |  | — |  |
| JCI plc - Term Loan - 35 billion yen; LIBOR JPY plus 0.40% due in 2022 | 309 |  |  | 311 |  |
| Capital lease obligations | 36 |  |  | 19 |  |
| Other | 23 |  |  | 90 |  |
| Gross long-term debt | 9,724 |  |  | 12,403 |  |
| Less: current portion | 26 |  |  | 394 |  |
| Less: debt issuance costs | 44 |  |  | 45 |  |
| Net long-term debt | $ | 9,654 |  |  | $ | 11,964 |  |

[0000833444-18-000053:notes:135]
The installments of long-term debt maturing in subsequent fiscal years are: 2019 - $26 million; 2020 - $1,118 million; 2021 - $1,371 million; 2022 - $772 million; 2023 - $1,201 million; 2024 and thereafter - $5,236 million. The Company’s long-term debt includes various financial covenants, none of which are expected to restrict future operations.

[0000833444-18-000053:notes:136]
Total interest paid on both short and long-term debt for the fiscal years ended September 30, 2018, 2017 and 2016 was $415 million, $448 million and $319 million, respectively. The Company used financial instruments to manage its interest rate exposure in fiscal 2016 and the first quarter of 2017 (see Note 10, "Derivative Instruments and Hedging Activities," and Note 11, "Fair Value Measurements," of the notes to consolidated financial statements). These instruments affected the weighted average interest rate of the Company’s debt and interest expense.

[0000833444-18-000053:notes:137]
Financing Arrangements

[0000833444-18-000053:notes:138]
Financing in connection with Tyco Merger and subsequent activities

[0000833444-18-000053:notes:139]
Simultaneously with the closing of the Tyco Merger on September 2, 2016, TSarl borrowed $4.0 billion under the Term Loan Credit Agreement dated as of March 10, 2016 with a syndicate of lenders, providing for a three and a half year senior unsecured term loan facility to finance the cash consideration for, and fees, expenses and costs incurred in connection with the Merger. During fiscal 2017, the Company partially repaid $300 million of the $4.0 billion floating rate term loan scheduled to expire in March 2020. In October 2017, the Company completed the previously announced sale of its Scott Safety business to 3M. Net cash proceeds from the transaction of approximately $1.9 billion were used to repay a significant portion of the TSarl $4.0 billion of merger related debt. In March 2018, the Company repaid $26 million in principal amount, plus accrued interest. In April 2018, the Company refinanced approximately $400 million of the TSarl merger related debt with commercial paper. In July 2018, the Company refinanced approximately $250 million in principal amount of the TSarl merger related debt with a 364-day $250 million floating rate term loan scheduled to mature in July 2019.  In September 2018, the Company repaid approximately $450 million in principal amount, plus accrued interest, and refinanced approximately $250 million of the TSarl merger related debt with an 18-month 215 million euro floating rate term loan scheduled to mature in March 2020.

[0000833444-18-000053:notes:140]
Other financing arrangements

[0000833444-18-000053:notes:141]
In January 2018, the Company retired $67 million in principal amount, plus accrued interest, of its 3.75% fixed rate notes that expired in January 2018.

[0000833444-18-000053:notes:142]
In November 2017, the Company issued 750 million euro in principal amount of 0.0% senior unsecured fixed rate notes due in December 2020. Proceeds from the issuance were used to repay existing debt and for other general corporate purposes.

[0000833444-18-000053:notes:143]
In November 2017, the Company retired $300 million in principal amount, plus accrued interest, of its 1.4% fixed rate notes that expired in November 2017.

[0000833444-18-000053:notes:144]
Net Financing Charges


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-18-000053:notes:145]
DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES

[0000833444-18-000053:notes:146]
The Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities, stock-based compensation liabilities and interest rates. Under Company policy, the use of derivatives is restricted to those intended for hedging purposes; the use of any derivative instrument for speculative purposes is strictly prohibited. A description of each type of derivative utilized by the Company to manage risk is included in the following paragraphs. In addition, refer to Note 11, "Fair Value Measurements," of the notes to consolidated financial statements for information related to the fair value measurements and valuation methods utilized by the Company for each derivative type.

[0000833444-18-000053:notes:147]
Cash Flow Hedges

[0000833444-18-000053:notes:148]
The Company has global operations and participates in the foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange hedge contracts. The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates at September 30, 2018 and 2017.

[0000833444-18-000053:notes:149]
The Company selectively hedges anticipated transactions that are subject to commodity price risk, primarily using commodity hedge contracts, to minimize overall price risk associated with the Company’s purchases of lead, copper, tin, aluminum and polypropylene in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. As cash flow hedges, hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions, typically sales, occur and affect earnings. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in commodity prices at September 30, 2018 and 2017.

[0000833444-18-000053:notes:150]
Fair Value Hedges

[0000833444-18-000053:notes:151]
The Company selectively uses interest rate swaps to reduce market risk associated with changes in interest rates for its fixed-rate bonds. As fair value hedges, the interest rate swaps and related debt balances are valued under a market approach using publicized swap curves. Changes in the fair value of the swap and hedged portion of the debt are recorded in the consolidated statements of income. As of September 30, 2016, the Company had four fixed to floating interest rate swaps totaling $400 million to hedge the coupon of its 2.6% notes that matured in December 2016, three fixed to floating interest rate swaps totaling $300 million to hedge the coupon of its 1.4% notes maturing November 2017 and one fixed to floating interest rate swap totaling $150 million to hedge the coupon of its 7.125% notes maturing in July 2017. In December 31, 2016, the remaining four outstanding interest rate swaps were terminated. The Company had no interest rate swaps outstanding at September 30, 2018 and 2017.

[0000833444-18-000053:notes:152]
Net Investment Hedges

[0000833444-18-000053:notes:153]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company’s net investments globally. At September 30, 2018, the Company had one billion euro, 750 million euro, 423 million euro, and 58 million euro in bonds and a 215 million euro term loan designated as net investment hedges in the Company's net investment in Europe and 35 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan. At September 30, 2017, the Company had one billion euro, 423 million euro and 58 million euro bonds designated as net investment hedges in the Company's net investment in Europe and 35 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan.

[0000833444-18-000053:notes:154]
Derivatives Not Designated as Hedging Instruments

[0000833444-18-000053:notes:155]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount. As of September 30, 2018, the Company hedged approximately 1.8 million of its ordinary shares, which have a cost basis of $73 million. As of September 30, 2017 the Company hedged approximately 1.4 million of its ordinary shares, which have a cost basis of $58 million.

[0000833444-18-000053:notes:156]
The Company also holds certain foreign currency forward contracts which do not qualify for hedge accounting treatment. The change in fair value of foreign currency exchange derivatives not designated as hedging instruments under ASC 815 are recorded in the consolidated statements of income.

[0000833444-18-000053:notes:157]
Fair Value of Derivative Instruments

[0000833444-18-000053:notes:158]
The following table presents the location and fair values of derivative instruments and hedging activities included in the Company’s consolidated statements of financial position (in millions):

[0000833444-18-000053:notes:159]
|  | Derivatives and Hedging ActivitiesDesignated as Hedging Instrumentsunder ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instrumentsunder ASC 815 |
|  | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 6 |  |  | $ | 27 |  |  | $ | 10 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | 9 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Equity swap | — |  |  | — |  |  | 63 |  |  | 55 |  |
| Total assets | $ | 7 |  |  | $ | 36 |  |  | $ | 73 |  |  | $ | 55 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 10 |  |  | $ | 21 |  |  | $ | 2 |  |  | $ | 25 |  |
| Commodity derivatives | 14 |  |  | 1 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 3,149 |  |  | 2,058 |  |  | — |  |  | — |  |
| Total liabilities | $ | 3,173 |  |  | $ | 2,080 |  |  | $ | 2 |  |  | $ | 25 |  |

[0000833444-18-000053:notes:160]
Counterparty Credit Risk

[0000833444-18-000053:notes:161]
The use of derivative financial instruments exposes the Company to counterparty credit risk. The Company has established policies and procedures to limit the potential for counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association ("ISDA") master netting agreements with substantially all of its counterparties. The Company's derivative contracts do not contain any credit risk related contingent features and do not require collateral or other security to be furnished by the Company or the counterparties. The Company's exposure to credit risk associated with its derivative instruments is measured on an individual counterparty basis, as well as by groups of counterparties that share similar attributes. The Company does not anticipate any non-performance by any of its counterparties, and the concentration of risk with financial institutions does not present significant credit risk to the Company.

[0000833444-18-000053:notes:162]
The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position. Collateral is generally not required of the Company or the counterparties under the master netting agreements. As of September 30, 2018 and 2017, no cash collateral was received or pledged under the master netting agreements.

[0000833444-18-000053:notes:163]
Derivatives Impact on the Statements of Income and Statements of Comprehensive Income

[0000833444-18-000053:notes:164]
The following table presents the pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges for the fiscal years ended September 30, 2018, 2017 and 2016 (in millions):

[0000833444-18-000053:notes:165]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Year Ended September 30, |
|  | 2018 |  | 2017 |  | 2016 |
| Foreign currency exchange derivatives |  | $ | 2 |  |  | $ | (1 | ) |  | $ | (18 | ) |
| Commodity derivatives |  | (14 | ) |  | 14 |  |  | 3 |  |
| Total |  | $ | (12 | ) |  | $ | 13 |  |  | $ | (15 | ) |

[0000833444-18-000053:notes:166]
The following table presents the location and amount of the pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income for the fiscal years ended September 30, 2018, 2017 and 2016 (in millions):

[0000833444-18-000053:notes:167]
| Derivatives in ASC 815 Cash FlowHedging Relationships |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Year Ended September 30, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 4 |  |  | $ | 25 |  |  | $ | 9 |  |
| Foreign currency exchange derivatives |  | Loss from discontinued operations |  | — |  |  | — |  |  | (30 | ) |
| Commodity derivatives |  | Cost of sales |  | 12 |  |  | 8 |  |  | (12 | ) |
| Forward treasury locks |  | Net financing charges |  | — |  |  | — |  |  | 1 |  |
| Total |  |  |  | $ | 16 |  |  | $ | 33 |  |  | $ | (32 | ) |

[0000833444-18-000053:notes:168]
The following table presents the location and amount of pre-tax gains (losses) on fair value hedges recognized in the Company’s consolidated statements of income for the fiscal years ended September 30, 2018, 2017 and 2016 (in millions):

[0000833444-18-000053:notes:169]
| Derivatives in ASC 815 Fair Value Hedging Relationships |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Year Ended September 30, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Interest rate swap |  | Net financing charges |  | $ | — |  |  | $ | (1 | ) |  | $ | (5 | ) |
| Fixed rate debt swapped to floating |  | Net financing charges |  | — |  |  | 2 |  |  | 5 |  |
| Total |  |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |

[0000833444-18-000053:notes:170]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income for the fiscal years ended September 30, 2018, 2017 and 2016 (in millions):

[0000833444-18-000053:notes:171]
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Year Ended September 30, |
|  |  | 2018 |  | 2017 |  | 2016 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 5 |  |  | $ | (1 | ) |  | $ | (20 | ) |
| Foreign currency exchange derivatives |  | Net financing charges |  | 33 |  |  | 44 |  |  | 21 |  |
| Foreign currency exchange derivatives |  | Income tax provision |  | (3 | ) |  | (3 | ) |  | 4 |  |
| Foreign currency exchange derivatives |  | Loss from discontinued operations |  | — |  |  | 5 |  |  | (30 | ) |
| Equity swap |  | Selling, general and administrative |  | (8 | ) |  | (3 | ) |  | 14 |  |
| Total |  |  |  | $ | 27 |  |  | $ | 42 |  |  | $ | (11 | ) |

[0000833444-18-000053:notes:172]
The pre-tax gains (losses) recorded in foreign currency translation adjustment ("CTA") within other comprehensive income (loss) related to net investment hedges were $45 million, $(138) million and $(82) million for the years ended September 30, 2018, 2017 and 2016, respectively. For the years ended September 30, 2018, 2017 and 2016, no gains or losses were reclassified from CTA into income for the Company’s outstanding net investment hedges.


## us-gaap:DerivativesPolicyTextBlock

[0000833444-18-000053:notes:173]
Derivative Financial Instruments

[0000833444-18-000053:notes:174]
The Company has written policies and procedures that place all financial instruments under the direction of Corporate treasury and restrict all derivative transactions to those intended for hedging purposes. The use of financial instruments for speculative purposes is strictly prohibited. The Company selectively uses financial instruments to manage the market risk from changes in foreign exchange rates, commodity prices, stock-based compensation liabilities and interest rates.

[0000833444-18-000053:notes:175]
The fair values of all derivatives are recorded in the consolidated statements of financial position. The change in a derivative’s fair value is recorded each period in current earnings or accumulated other comprehensive income ("AOCI"), depending on whether the derivative is designated as part of a hedge transaction and if so, the type of hedge transaction. See Note 10, "Derivative Instruments and Hedging Activities," and Note 11, "Fair Value Measurements," of the notes to consolidated financial statements for disclosure of the Company’s derivative instruments and hedging activities.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-18-000053:notes:176]
STOCK-BASED COMPENSATION

[0000833444-18-000053:notes:177]
On September 2, 2016, the shareholders of the Company approved the Johnson Controls International plc 2012 Share and Incentive Plan (the "Plan"). The original effective date of this Plan was October 1, 2012. The Plan was amended and restated as of November 17, 2014 and was amended and restated again in connection with the Merger that was consummated on September 2, 2016 (the “Amendment Effective Date”). The amendment and restatement is intended to reflect the assumption into this Plan of the remaining share reserves under the Johnson Controls, Inc. 2012 Omnibus Incentive Plan and the Johnson Controls, Inc. 2003 Stock Plan for Outside Directors (the “Legacy Johnson Controls Plans”) as of the Amendment Effective Date. Following the Amendment Effective Date, no further awards may be made under the Legacy Johnson Controls Plans. The types of awards authorized by the Plan comprise of stock options, stock appreciation rights, performance shares, performance units and other stock-based awards. The Compensation Committee of the Company's Board of Directors will determine the types of awards to be granted to individual participants and the terms and conditions of the awards. The Plan provides that 76 million shares of the Company's common stock are reserved for issuance under the 2012 Plan, and 45 million shares remain available for issuance at September 30, 2018.

[0000833444-18-000053:notes:178]
Pursuant to the Merger Agreement, outstanding stock options held by Tyco employees on September 2, 2016 (the “Merger Date”) were converted into options to acquire the Company's shares using a 0.955-for-one share consolidation ratio in a manner designed to preserve the intrinsic value of such awards. In addition, pursuant to the Merger Agreement, nonvested restricted stock held by Tyco employees on the Merger Date were converted into nonvested restricted stock of the Company using the 0.955-for-one share consolidation ratio in a manner designed to preserve the intrinsic value of such awards. Outstanding performance share awards held by Tyco employees on the Merger Date were converted to nonvested restricted stock of the Company at the target performance level, and adjusted to reflect the 0.955-for-one consolidation ratio. Except for the conversion of stock options, nonvested restricted stock and performance share awards discussed herein, the material terms of the awards remained unchanged. The modifications made to the awards upon the Merger Date constituted modifications under the authoritative guidance for accounting for stock compensation. This guidance requires the Company to revalue the awards upon the Merger close and allocate the revised fair value between purchase consideration and continuing expense based on the ratio of service performed through the Merger Date over the total service period of the awards. The revised fair value allocated to post-merger services resulted in incremental expense which is recognized over the remaining service period of the awards. The portion of Tyco awards earned as of the Merger Date included as purchase consideration was $224 million. The total value of Tyco awards not earned as of the Merger Date was $101 million, which will be expensed over the remaining future vesting period.  Refer to Note 2, “Merger Transaction,” of the notes to consolidated financial statements for further information regarding the Merger.

[0000833444-18-000053:notes:179]
Pursuant to the Merger Agreement, outstanding stock options held by JCI Inc. employees on the Merger Date were converted one-for-one into options to acquire the Company's shares in a manner designed to preserve the intrinsic value of such awards. In addition, pursuant to the Merger Agreement, nonvested restricted stock held by JCI Inc. employees on the Merger Date was converted one-for-one into nonvested restricted stock of the Company in a manner designed to preserve the intrinsic value of such awards. Outstanding performance share awards held by JCI Inc. employees on the Merger Date were converted to nonvested restricted stock of the Company based on certain performance factors. Except for the conversion of stock options, nonvested restricted stock and performance share awards discussed herein, the material terms of the awards remained unchanged, and no incremental fair value resulted from the conversion. References to the Company’s stock throughout Note 12 refer to stock of JCI Inc. prior to the Merger Date and to stock of the Company subsequent to the Merger Date.

[0000833444-18-000053:notes:180]
In connection with the Adient spin-off, pursuant to the Employee Matters Agreement between the Company and Adient, outstanding stock options and SARs held on October 31, 2016 (the “Spin Date”) by employees remaining with the Company were converted into options and SARs of the Company using a 1.085317-for-one share ratio, which is based on the pre-spin and post-spin closing prices of the Company’s ordinary shares. The exercise prices for options and SARs were converted using the inverse ratio in a manner designed to preserve the intrinsic value of such awards. In addition, pursuant to the Employee Matters Agreement, nonvested restricted stock held on the Spin Date by employees remaining with the Company were converted into nonvested restricted stock of the Company using the 1.085317-for-one share ratio in a manner designed to preserve the intrinsic value of such awards. There were no performance share awards outstanding as of the Spin Date. Employees remaining with the Company did not receive stock-based compensation awards of Adient as a result of the spin-off. Except for the conversion of awards and related exercise prices discussed herein, the material terms of the awards remained unchanged. No incremental fair value resulted from the conversion of the awards; therefore, no additional compensation expense was recorded related to the award modification.

[0000833444-18-000053:notes:181]
Also in connection with the spin-off transaction, pursuant to the Employee Matters Agreement, employees of Adient were entitled to receive stock-based compensation awards of the Company and Adient in replacement of previously outstanding awards of the Company granted prior to the Spin Date. These awards include stock options, stock appreciation rights and nonvested restricted stock. Upon the Spin Date, the existing awards held by Adient employees were converted into new awards of the Company and Adient on a pro rata basis and further adjusted based on a formula designed to preserve the intrinsic value of such awards. Additional compensation expense, if any, resulting from the modification of awards held by Adient employees is to be recorded by Adient.

[0000833444-18-000053:notes:182]
The Company has four share-based compensation plans, which are described below. For the fiscal years ended September 30, 2018 and 2017, compensation cost charged against income for continuing operations, excluding the offsetting impact of outstanding equity swaps, for those plans was approximately $98 million and $134 million, respectively, all of which was recorded in selling, general and administrative expenses. For the fiscal year ended September 30, 2016, compensation cost charged against income for continuing operations, excluding the offsetting impact of outstanding equity swaps, for those plans was approximately $160 million, of which $121 million was recorded in selling, general and administrative expenses and $39 million was recorded in restructuring and impairment costs.

[0000833444-18-000053:notes:183]
The Company has elected to utilize the alternative transition method for calculating the tax effects of stock-based compensation.  The total income tax benefit recognized for continuing operations in the consolidated statements of income for share-based compensation arrangements was approximately $25 million, $53 million and $56 million for the fiscal years ended September 30, 2018, 2017 and 2016, respectively.  The tax expense from the exercise and vesting of equity settled awards was $3 million for the fiscal year ended September 30, 2018 and recorded as part of the income tax provision upon adoption of ASU 2016-09 during the first quarter of fiscal 2018. The tax benefit from the exercise and vesting of equity settled awards was $4 million and $11 million for the fiscal years ended 2017 and 2016, respectively, and were recorded in capital in excess of par value.  The Company does not settle stock options granted under share-based payment arrangements to cash.

[0000833444-18-000053:notes:184]
Stock Options

[0000833444-18-000053:notes:185]
Stock options are granted with an exercise price equal to the market price of the Company’s stock at the date of grant. Stock option awards typically vest between two and three years after the grant date and expire ten years from the grant date.

[0000833444-18-000053:notes:186]
The fair value of each option is estimated on the date of grant using a Black-Scholes option valuation model that uses the assumptions noted in the following table. The expected life of options represents the period of time that options granted are expected to be outstanding, assessed separately for executives and non-executives. The risk-free interest rate for periods during the contractual life of the option is based on the U.S. Treasury yield curve in effect at the time of grant. For fiscal 2018, the expected volatility is based on the historical volatility of the Company's stock after the Adient spin-off blended with the historical volatility of certain peer companies' stock prior to the Adient spin-off over the most recent period corresponding to the expected life as of the grant date. For fiscal 2017, the expected volatility is based on historical volatility of certain peer companies over the most recent period corresponding to the expected life as of the grant date. For fiscal 2016, the expected volatility is based on the historical volatility of the Company's stock and other factors. The expected dividend yield is based on the expected annual dividend as a percentage of the market value of the Company’s ordinary shares as of the grant date. The Company uses historical data to estimate option exercises and employee terminations within the valuation model.

[0000833444-18-000053:notes:187]
|  | Year Ended September 30, |
|  | 2018 |  | 2017 |  | 2016 |
| Expected life of option (years) | 6.5 |  | 4.75 & 6.5 |  | 6.4 |
| Risk-free interest rate | 2.28% |  | 1.23% - 1.93% |  | 1.64% - 1.70% |
| Expected volatility of the Company’s stock | 23.70% |  | 24.60% |  | 36.00% |
| Expected dividend yield on the Company’s stock | 2.78% |  | 2.21% |  | 2.11% |

[0000833444-18-000053:notes:188]
A summary of stock option activity at September 30, 2018, and changes for the year then ended, is presented below:

[0000833444-18-000053:notes:189]
|  | WeightedAverageOption Price |  | SharesSubject toOption |  | WeightedAverageRemainingContractualLife (years) |  | AggregateIntrinsicValue(in millions) |
| Outstanding, September 30, 2017 | $ | 32.76 |  |  | 19,730,443 |  |  |  |  |  |
| Granted | 37.32 |  |  | 1,376,807 |  |  |  |  |  |
| Exercised | 24.24 |  |  | (2,733,159 | ) |  |  |  |  |
| Forfeited or expired | 38.62 |  |  | (538,029 | ) |  |  |  |  |
| Outstanding, September 30, 2018 | $ | 34.24 |  |  | 17,836,062 |  |  | 4.2 |  | $ | 84 |  |
| Exercisable, September 30, 2018 | $ | 31.22 |  |  | 14,329,210 |  |  | 3.3 |  | $ | 84 |  |

[0000833444-18-000053:notes:190]
The weighted-average grant-date fair value of options granted during the fiscal years ended September 30, 2018, 2017 and 2016 was $7.04, $7.81 and $13.14, respectively.

[0000833444-18-000053:notes:191]
The total intrinsic value of options exercised during the fiscal years ended September 30, 2018, 2017 and 2016 was approximately $38 million, $81 million and $39 million, respectively.

[0000833444-18-000053:notes:192]
In conjunction with the exercise of stock options granted, the Company received cash payments for the fiscal years ended September 30, 2018, 2017 and 2016 of approximately $66 million, $157 million and $70 million, respectively.

[0000833444-18-000053:notes:193]
At September 30, 2018, the Company had approximately $13 million of total unrecognized compensation cost related to nonvested stock options granted for continuing operations. That cost is expected to be recognized over a weighted-average period of 1.6 years.

[0000833444-18-000053:notes:194]
Stock Appreciation Rights ("SARs")

[0000833444-18-000053:notes:195]
SARs vest under the same terms and conditions as stock option awards; however, they are settled in cash for the difference between the market price on the date of exercise and the exercise price. As a result, SARs are recorded in the Company’s consolidated statements of financial position as a liability until the date of exercise.

[0000833444-18-000053:notes:196]
The fair value of each SAR award is estimated using a similar method described for stock options. The fair value of each SAR award is recalculated at the end of each reporting period and the liability and expense are adjusted based on the new fair value.

[0000833444-18-000053:notes:197]
A summary of SAR activity at September 30, 2018, and changes for the year then ended, is presented below:

[0000833444-18-000053:notes:198]
|  | WeightedAverageSAR Price |  | SharesSubject toSAR |  | WeightedAverageRemainingContractualLife (years) |  | AggregateIntrinsicValue(in millions) |
| Outstanding, September 30, 2017 | $ | 27.02 |  |  | 893,311 |  |  |  |  |  |
| Granted | 25.78 |  |  | 12,119 |  |  |  |  |  |
| Exercised | 26.13 |  |  | (256,900 | ) |  |  |  |  |
| Forfeited or expired | 26.09 |  |  | (21,829 | ) |  |  |  |  |
| Outstanding, September 30, 2018 | $ | 27.39 |  |  | 626,701 |  |  | 3.2 |  | $ | 5 |  |
| Exercisable, September 30, 2018 | $ | 26.52 |  |  | 590,556 |  |  | 3.1 |  | $ | 5 |  |

[0000833444-18-000053:notes:199]
In conjunction with the exercise of SARs granted, the Company made payments of $3 million, $4 million and $8 million during the fiscal years ended September 30, 2018, 2017 and 2016, respectively.

[0000833444-18-000053:notes:200]
Restricted (Nonvested) Stock / Units

[0000833444-18-000053:notes:201]
The Plan provides for the award of restricted stock or restricted stock units to certain employees. These awards are typically share settled unless the employee is a non-U.S. employee or elects to defer settlement until retirement at which point the award would be settled in cash. Restricted awards typically vest over a period of three years from the grant date. The Plan allows for different vesting terms on specific grants with approval by the Board of Directors. The fair value of each share-settled restricted award is based on the closing market value of the Company’s ordinary shares on the date of grant. The fair value of each cash-settled restricted award is recalculated at the end of each reporting period based on the closing market value of the Company's ordinary shares at the end of the reporting period, and the liability and expense are adjusted based on the new fair value.

[0000833444-18-000053:notes:202]
A summary of the status of the Company’s nonvested restricted stock awards at September 30, 2018, and changes for the fiscal year then ended, is presented below:

[0000833444-18-000053:notes:203]
|  | WeightedAveragePrice |  | Shares/UnitsSubject toRestriction |
| Nonvested, September 30, 2017 | $ | 44.48 |  |  | 6,961,706 |  |
| Granted | 37.21 |  |  | 2,274,160 |  |
| Vested | 39.84 |  |  | (3,819,581 | ) |
| Forfeited | 39.38 |  |  | (414,768 | ) |
| Nonvested, September 30, 2018 | $ | 45.14 |  |  | 5,001,517 |  |

[0000833444-18-000053:notes:204]
At September 30, 2018, the Company had approximately $80 million of total unrecognized compensation cost related to nonvested restricted stock arrangements granted for continuing operations. That cost is expected to be recognized over a weighted-average period of 1.8 years.

[0000833444-18-000053:notes:205]
Performance Share Awards

[0000833444-18-000053:notes:206]
The Plan permits the grant of performance-based share unit ("PSU") awards. The PSUs are generally contingent on the achievement of pre-determined performance goals over a three-year performance period as well as on the award holder's continuous employment until the vesting date. The PSUs are also indexed to the achievement of specified levels of total shareholder return versus a peer group over the performance period. Each PSU that is earned will be settled with shares of the Company's ordinary shares following the completion of the performance period, unless the award holder elected to defer a portion or all of the award until retirement which would then be settled in cash.

[0000833444-18-000053:notes:207]
The fair value of each PSU is estimated on the date of grant using a Monte Carlo simulation that uses the assumptions noted in the following table. The risk-free interest rate for periods during the contractual life of the PSU is based on the U.S. Treasury yield curve in effect at the time of grant. For fiscal 2018, the expected volatility is based on the historical volatility of the Company's stock after the Adient spin-off blended with the historical volatility of certain peer companies' stock prior to the Adient spin-off over the most recent three-year period as of the grant date. For fiscal 2017, the expected volatility is based on historical volatility of certain peer companies over the most recent three-year period as of the grant date.

[0000833444-18-000053:notes:208]
A summary of the status of the Company’s nonvested PSUs at September 30, 2018, and changes for the fiscal year then ended, is presented below:

[0000833444-18-000053:notes:209]
|  | WeightedAveragePrice |  | Shares/UnitsSubject toPSU |
| Nonvested, September 30, 2017 | $ | 43.24 |  |  | 1,119,388 |  |
| Granted | 37.36 |  |  | 496,478 |  |
| Forfeited | 43.97 |  |  | (203,576 | ) |
| Nonvested, September 30, 2018 | $ | 41.07 |  |  | 1,412,290 |  |


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-18-000053:notes:210]
DISCONTINUED OPERATIONS

[0000833444-18-000053:notes:211]
As discussed in Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements, on October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience business from Johnson Controls to Adient plc. The Company did not retain any equity interest in Adient plc. During the first quarter of fiscal 2017, the Company determined that Adient met the criteria to be classified as a discontinued operation and, as a result, Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation, and assets and liabilities are classified as assets and liabilities held for sale. The Company did not allocate any general corporate overhead to discontinued operations.

[0000833444-18-000053:notes:212]
For the fiscal year ended September 30, 2017, the income from discontinued operations before income taxes included separation costs of $79 million. For the fiscal year ended September 30, 2016, the income from discontinued operations before income taxes included separation costs ($418 million), significant restructuring and impairment costs ($332 million), and net mark-to market losses on pension and postretirement plans ($110 million).

[0000833444-18-000053:notes:213]
For the fiscal year ended September 30, 2017, the effective tax rate was more than the Irish statutory rate of 12.5% primarily due to the tax impacts of separation costs and Adient spin-off related tax expense, partially offset by non-U.S. tax rate differentials.

[0000833444-18-000053:notes:214]
In preparation for the spin-off of the Automotive Experience business in the first quarter of fiscal 2017, the Company incurred incremental tax expense of $95 million in fiscal 2016. The Company also completed substantial business reorganizations which resulted in total tax charges of $1,891 million in fiscal 2016. Included in this amount is the tax charge provided for in the third quarter of fiscal 2016 of $85 million for changes in entity tax status and the charge provided for in the second quarter of fiscal 2016 of $780 million for income tax expense on foreign undistributed earnings of certain non-U.S. subsidiaries.

[0000833444-18-000053:notes:215]
In fiscal 2016, the Company did provide U.S. income tax expense related to the restructuring and repatriation of cash for certain non-U.S. subsidiaries in connection with the Automotive Experience planned spin-off. At September 30, 2016 the Company needed to complete the final steps of Automotive Experience restructuring and, as a result, the Company provided deferred taxes of $24 million for the U.S. income tax expense on outside basis differences that reversed upon the completion of the restructuring.

[0000833444-18-000053:notes:216]
The following table summarizes depreciation and amortization, capital expenditures, and significant operating and investing non-cash items related to Adient for the fiscal years ended September 30, 2017 and 2016 (in millions):

[0000833444-18-000053:notes:217]
|  |  | Year Ended September 30, |
|  |  | 2017 |  | 2016 |
| Depreciation and amortization |  | $ | 29 |  |  | $ | 331 |  |
| Pension and postretirement benefit expense |  | — |  |  | 113 |  |
| Equity in earnings of partially-owned affiliates |  | (31 | ) |  | (357 | ) |
| Deferred income taxes |  | 562 |  |  | (476 | ) |
| Non-cash restructuring and impairment costs |  | — |  |  | 87 |  |
| Equity-based compensation |  | 1 |  |  | 16 |  |
| Accrued income taxes |  | (808 | ) |  | — |  |
| Other |  | — |  |  | (2 | ) |
| Capital expenditures |  | (91 | ) |  | (395 | ) |

[0000833444-18-000053:notes:218]
During the second quarter of fiscal 2017, the Company signed a definitive agreement to sell its Scott Safety business of the Global Products segment to 3M Company. The transaction closed on October 4, 2017. The assets and liabilities of this business are presented as held for sale in the consolidated statements of financial position as of September 30, 2017. The business did not meet the criteria to be classified as a discontinued operation as the divestiture of the Scott Safety business did not have a major effect on the Company’s operations and financial results.

[0000833444-18-000053:notes:219]
The following table summarizes the carrying value of the Scott Safety assets and liabilities held for sale at September 30, 2017 (in millions):

[0000833444-18-000053:notes:220]
|  |  | September 30, 2017 |  |
| Cash |  | $ | 9 |  |
| Accounts receivable - net |  | 100 |  |
| Inventories |  | 75 |  |
| Other current assets |  | 5 |  |
| Assets held for sale |  | $ | 189 |  |
| Property, plant and equipment - net |  | $ | 79 |  |
| Goodwill |  | 1,248 |  |
| Other intangible assets - net |  | 592 |  |
| Other noncurrent assets |  | 1 |  |
| Noncurrent assets held for sale |  | $ | 1,920 |  |
| Accounts payable |  | $ | 37 |  |
| Accrued compensation and benefits |  | 10 |  |
| Other current liabilities |  | 25 |  |
| Liabilities held for sale |  | $ | 72 |  |
| Other noncurrent liabilities |  | $ | 173 |  |
| Noncurrent liabilities held for sale |  | $ | 173 |  |


## us-gaap:EarningsPerSharePolicyTextBlock

[0000833444-18-000053:notes:221]
Earnings Per Share

[0000833444-18-000053:notes:222]
The Company presents both basic and diluted earnings per share ("EPS") amounts. Basic EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of common shares outstanding during the reporting period. Diluted EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of common shares and common equivalent shares outstanding during the reporting period that are calculated using the treasury stock method for stock options, unvested restricted stock and unvested performance share awards. See Note 13, "Earnings per Share," of the notes to consolidated financial statements for the calculation of earnings per share.


## us-gaap:EarningsPerShareTextBlock

[0000833444-18-000053:notes:223]
EARNINGS PER SHARE

[0000833444-18-000053:notes:224]
The Company presents both basic and diluted EPS amounts. Basic EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares outstanding during the reporting period. Diluted EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares and ordinary equivalent shares outstanding during the reporting period that are calculated using the treasury stock method for stock options, unvested restricted stock and unvested performance share awards. The treasury stock method assumes that the Company uses the proceeds from the exercise of stock option awards to repurchase ordinary shares at the average market price during the period. The assumed proceeds under the treasury stock method include the purchase price that the grantee will pay in the future and compensation cost for future service that the Company has not yet recognized.  For unvested restricted stock and unvested performance share awards, assumed proceeds under the treasury stock method would include unamortized compensation cost.

[0000833444-18-000053:notes:225]
The following table reconciles the numerators and denominators used to calculate basic and diluted earnings per share (in millions):

[0000833444-18-000053:notes:226]
|  | Year Ended September 30, |
|  | 2018 |  | 2017 |  | 2016 |
| Income (loss) Available to Ordinary Shareholders |  |  |  |  |  |
| Income from continuing operations | $ | 2,162 |  |  | $ | 1,654 |  |  | $ | 732 |  |
| Loss from discontinued operations | — |  |  | (43 | ) |  | (1,600 | ) |
| Basic and diluted income (loss) available to shareholders | $ | 2,162 |  |  | $ | 1,611 |  |  | $ | (868 | ) |
| Weighted Average Shares Outstanding |  |  |  |  |  |
| Basic weighted average shares outstanding | 925.7 |  |  | 935.3 |  |  | 667.4 |  |
| Effect of dilutive securities: |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 6.0 |  |  | 9.3 |  |  | 5.2 |  |
| Diluted weighted average shares outstanding | 931.7 |  |  | 944.6 |  |  | 672.6 |  |
| Antidilutive Securities |  |  |  |  |  |
| Options to purchase shares | 1.5 |  |  | 0.2 |  |  | — |  |

[0000833444-18-000053:notes:227]
During the three months ended September 30, 2018 and 2017, the Company declared a dividend of $0.26 and $0.25, respectively, per share. During the twelve months ended September 30, 2018 and 2017, the Company declared four quarterly dividends totaling $1.04 and $1.00, respectively, per share.  The company pays all dividends in the month subsequent to the end of each fiscal quarter.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0000833444-18-000053:notes:228]
NONCONSOLIDATED PARTIALLY-OWNED AFFILIATES

[0000833444-18-000053:notes:229]
Investments in the net assets of nonconsolidated partially-owned affiliates are stated in the "Investments in partially-owned affiliates" line in the consolidated statements of financial position as of September 30, 2018 and 2017. Equity in the net income of nonconsolidated partially-owned affiliates is stated in the "Equity income" line in the consolidated statements of income for the years ended September 30, 2018, 2017 and 2016.

[0000833444-18-000053:notes:230]
The following table presents summarized financial data for the Company’s nonconsolidated partially-owned affiliates. The amounts included in the table below represent 100% of the results of continuing operations of such nonconsolidated partially-owned affiliates accounted for under the equity method.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-18-000053:notes:231]
FAIR VALUE MEASUREMENTS

[0000833444-18-000053:notes:232]
ASC 820, "Fair Value Measurement," defines fair value as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. ASC 820 also establishes a three-level fair value hierarchy that prioritizes information used in developing assumptions when pricing an asset or liability as follows:

[0000833444-18-000053:notes:233]
Level 1: Observable inputs such as quoted prices in active markets for identical assets or liabilities;

[0000833444-18-000053:notes:234]
Level 2: Quoted prices in active markets for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active, or inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and

[0000833444-18-000053:notes:235]
Level 3: Unobservable inputs where there is little or no market data, which requires the reporting entity to develop its own assumptions.

[0000833444-18-000053:notes:236]
ASC 820 requires the use of observable market data, when available, in making fair value measurements. When inputs used to measure fair value fall within different levels of the hierarchy, the level within which the fair value measurement is categorized is based on the lowest level input that is significant to the fair value measurement.

[0000833444-18-000053:notes:237]
Recurring Fair Value Measurements

[0000833444-18-000053:notes:238]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value as of September 30, 2018 and 2017 (in millions):

[0000833444-18-000053:notes:239]
|  | Fair Value Measurements Using: |
|  | Total as ofSeptember 30, 2018 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 16 |  |  | $ | — |  |  | $ | 16 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Exchange traded funds (fixed income)1 | 14 |  |  | 14 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Investments in marketable common stock | 4 |  |  | 4 |  |  | — |  |  | — |  |
| Deferred compensation plan assets | 100 |  |  | 100 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 148 |  |  | 148 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 119 |  |  | 119 |  |  | — |  |  | — |  |
| Equity swap | 63 |  |  | — |  |  | 63 |  |  | — |  |
| Total assets | $ | 465 |  |  | $ | 385 |  |  | $ | 80 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 12 |  |  | $ | — |  |  | $ | 12 |  |  | $ | — |  |
| Commodity derivatives | 14 |  |  | — |  |  | 14 |  |  | — |  |
| Total liabilities | $ | 26 |  |  | $ | — |  |  | $ | 26 |  |  | $ | — |  |

[0000833444-18-000053:notes:240]
|  | Fair Value Measurements Using: |
|  | Total as ofSeptember 30, 2017 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 27 |  |  | $ | — |  |  | $ | 27 |  |  | $ | — |  |
| Commodity derivatives | 9 |  |  | — |  |  | 9 |  |  | — |  |
| Exchange traded funds (fixed income)1 | 14 |  |  | 14 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Investments in marketable common stock | 10 |  |  | 10 |  |  | — |  |  | — |  |
| Deferred compensation plan assets | 92 |  |  | 92 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 155 |  |  | 155 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 100 |  |  | 100 |  |  | — |  |  | — |  |
| Equity swap | 55 |  |  | — |  |  | 55 |  |  | — |  |
| Total assets | $ | 462 |  |  | $ | 371 |  |  | $ | 91 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 46 |  |  | $ | — |  |  | $ | 46 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Total liabilities | $ | 47 |  |  | $ | — |  |  | $ | 47 |  |  | $ | — |  |

[0000833444-18-000053:notes:241]
1Classified as restricted investments for payment of asbestos liabilities. See Note 22, "Commitments and Contingencies" of the notes to consolidated financial statements for further details.

[0000833444-18-000053:notes:242]
Valuation Methods

[0000833444-18-000053:notes:243]
Foreign currency exchange derivatives: The foreign currency exchange derivatives are valued under a market approach using publicized spot and forward prices.

[0000833444-18-000053:notes:244]
Commodity derivatives: The commodity derivatives are valued under a market approach using publicized prices, where available, or dealer quotes.

[0000833444-18-000053:notes:245]
Equity swaps: The equity swaps are valued under a market approach as the fair value of the swaps is equal to the Company’s stock price at the reporting period date.

[0000833444-18-000053:notes:246]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices.

[0000833444-18-000053:notes:247]
Investments in marketable common stock and exchange traded funds: Investments in marketable common stock and exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. The Company recorded unrealized gains of $23 million and unrealized losses of $15 million on these investments as of September 30, 2018 within AOCI in the consolidated statements of financial position. The Company recorded unrealized gains of $10 million and unrealized losses of $6 million as of September 30, 2017 within AOCI in the consolidated statements of financial position. During the fiscal year ended September 30, 2018, the Company sold certain marketable common stock for approximately $3 million. As a result, the Company recorded $2 million of realized gains within selling, general and administrative expenses.

[0000833444-18-000053:notes:248]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. The fair value of long-term debt was $9.6 billion and $12.7 billion at September 30, 2018 and 2017, respectively. The fair value of public debt was $8.6 billion at September 30, 2018 and 2017, which was determined primarily using market quotes classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was $1.0 billion and $4.1 billion at September 30, 2018 and 2017 respectively, which was determined based on quoted market prices for similar instruments classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:FiniteLivedAndIndefiniteLivedIntangibleAssetsAcquiredAsPartOfBusinessCombinationTableTextBlock

[0000833444-18-000053:notes:249]
The purchase price allocation to identifiable intangible assets acquired are as follows:

[0000833444-18-000053:notes:250]
|  |  | Fair Value (in millions) |  | Weighted Average Life (in years) |
| Customer relationships |  | $ | 2,280 |  |  | 12 |
| Completed technology |  | 1,650 |  |  | 11 |
| Other definite-lived intangibles |  | 214 |  |  | 7 |
| Indefinite-lived trademarks |  | 2,080 |  |  |  |
| Other indefinite-lived intangibles |  | 90 |  |  |  |
| In-process research and development |  | 70 |  |  |  |
| Total identifiable intangible assets |  | $ | 6,384 |  |  |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000833444-18-000053:notes:251]
Foreign Currency Translation

[0000833444-18-000053:notes:252]
Substantially all of the Company’s international operations use the respective local currency as the functional currency. Assets and liabilities of international entities have been translated at period-end exchange rates, and income and expenses have been translated using average exchange rates for the period. Monetary assets and liabilities denominated in non-functional currencies are adjusted to reflect period-end exchange rates. The aggregate transaction gains (losses), net of the impact of foreign currency hedges, included in net income for the years ended September 30, 2018, 2017 and 2016 were $(5) million, $94 million and $(95) million, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-18-000053:notes:253]
GOODWILL AND OTHER INTANGIBLE ASSETS

[0000833444-18-000053:notes:254]
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the fiscal years ended September 30, 2018 and 2017 were as follows (in millions):

[0000833444-18-000053:notes:255]
|  | September 30, 2016 |  | BusinessAcquisitions |  | BusinessDivestitures |  | Currency Translation and Other |  | September 30, 2017 |
| Building Technologies & Solutions |  |  |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 9,734 |  |  | $ | (147 | ) |  | $ | — |  |  | $ | 50 |  |  | $ | 9,637 |  |
| Building Solutions EMEA/LA | 1,981 |  |  | (37 | ) |  | — |  |  | 68 |  |  | 2,012 |  |
| Building Solutions Asia Pacific | 1,260 |  |  | (14 | ) |  | (2 | ) |  | 11 |  |  | 1,255 |  |
| Global Products | 6,963 |  |  | (58 | ) |  | (1,267 | ) |  | 49 |  |  | 5,687 |  |
| Power Solutions | 1,086 |  |  | — |  |  | — |  |  | 11 |  |  | 1,097 |  |
| Total | $ | 21,024 |  |  | $ | (256 | ) |  | $ | (1,269 | ) |  | $ | 189 |  |  | $ | 19,688 |  |
|  | September 30, 2017 |  | BusinessAcquisitions |  | BusinessDivestitures |  | Currency Translation and Other |  | September 30, 2018 |
| Building Technologies & Solutions |  |  |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 9,637 |  |  | $ | — |  |  | $ | — |  |  | $ | (34 | ) |  | $ | 9,603 |  |
| Building Solutions EMEA/LA | 2,012 |  |  | 1 |  |  | — |  |  | (63 | ) |  | 1,950 |  |
| Building Solutions Asia Pacific | 1,255 |  |  | — |  |  | — |  |  | (20 | ) |  | 1,235 |  |
| Global Products | 5,687 |  |  | 14 |  |  | (35 | ) |  | (73 | ) |  | 5,593 |  |
| Power Solutions | 1,097 |  |  | — |  |  | — |  |  | (5 | ) |  | 1,092 |  |
| Total | $ | 19,688 |  |  | $ | 15 |  |  | $ | (35 | ) |  | $ | (195 | ) |  | $ | 19,473 |  |

[0000833444-18-000053:notes:256]
The fiscal 2017 Global Products business divestiture amount includes $1,248 million of goodwill transferred to noncurrent assets held for sale on the consolidated statements of financial position for the sale of the Scott Safety business. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's assets and liabilities held for sale.

[0000833444-18-000053:notes:257]
At September 30, 2016, accumulated goodwill impairment charges included $47 million related to the Building Solutions EMEA/LA - Latin America reporting unit.

[0000833444-18-000053:notes:258]
There were no goodwill impairments resulting from fiscal 2018 and 2017 annual impairment tests. No reporting unit was determined to be at risk of failing step one of the goodwill impairment test. The Company continuously monitors for events and circumstances that could negatively impact the key assumptions in determining fair value, including long-term revenue growth projections, profitability, discount rates, recent market valuations from transactions by comparable companies, volatility in the Company's market capitalization, and general industry, market and macro-economic conditions. It is possible that future changes in such circumstances, or in the variables associated with the judgments, assumptions and estimates used in assessing the fair value of the reporting unit, would require the Company to record a non-cash impairment charge.

[0000833444-18-000053:notes:259]
The assumptions included in the impairment tests require judgment, and changes to these inputs could impact the results of the calculations. The primary assumptions used in the impairment tests were management's projections of future cash flows. Although the Company's cash flow forecasts are based on assumptions that are considered reasonable by management and consistent with the plans and estimates management is using to operate the underlying businesses, there are significant judgments in determining the expected future cash flows attributable to a reporting unit.

[0000833444-18-000053:notes:260]
Refer to Note 2, "Merger Transaction," of the notes to consolidated financial statements for additional information of intangibles recorded as a result of the Tyco Merger.

[0000833444-18-000053:notes:261]
Amortization of other intangible assets included within continuing operations for the fiscal years ended September 30, 2018, 2017 and 2016 was $384 million, $489 million and $116 million, respectively. Excluding the impact of any future acquisitions, the Company anticipates amortization for fiscal 2019, 2020, 2021, 2022 and 2023 will be approximately $406 million, $394 million, $391 million, $378 million and $364 million, respectively. There were no indefinite-lived intangible asset impairments resulting from fiscal 2018, 2017 and 2016 annual impairment tests.


## us-gaap:GuaranteesTextBlock

[0000833444-18-000053:notes:262]
GUARANTEES

[0000833444-18-000053:notes:263]
Certain of the Company's subsidiaries at the business segment level have guaranteed the performance of third-parties and provided financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from the current fiscal year through the completion of such transactions and would typically be triggered in the event of nonperformance. Performance under the guarantees, if required, would not have a material effect on the Company's financial position, results of operations or cash flows.

[0000833444-18-000053:notes:264]
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. A typical warranty program requires that the Company replace defective products within a specified time period from the date of sale. The Company records an estimate for future warranty-related costs based on actual historical return rates and other known factors. Based on analysis of return rates and other factors, the Company’s warranty provisions are adjusted as necessary. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different than those estimates.

[0000833444-18-000053:notes:265]
The Company’s product warranty liability for continuing operations is recorded in the consolidated statements of financial position in deferred revenue and other current liabilities if the warranty is less than one year and in other noncurrent liabilities if the warranty extends longer than one year.

[0000833444-18-000053:notes:266]
The changes in the carrying amount of the Company’s total product warranty liability, including extended warranties for which deferred revenue is recorded, for the fiscal years ended September 30, 2018 and 2017 were as follows (in millions):

[0000833444-18-000053:notes:267]
|  | Year EndedSeptember 30, |
|  | 2018 |  | 2017 |
| Balance at beginning of period | $ | 409 |  |  | $ | 374 |  |
| Accruals for warranties issued during the period | 309 |  |  | 312 |  |
| Accruals from acquisitions and divestitures (1) | — |  |  | 7 |  |
| Accruals related to pre-existing warranties (including changes in estimates) | (26 | ) |  | (4 | ) |
| Settlements made (in cash or in kind) during the period | (297 | ) |  | (280 | ) |
| Currency translation | (3 | ) |  | — |  |
| Balance at end of period | $ | 392 |  |  | $ | 409 |  |

[0000833444-18-000053:notes:268]
(1) The year ended September 30, 2017 includes $13 million of product warranties transferred to liabilities held for sale on the consolidated statements of financial position. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's disposal groups classified as held for sale.

[0000833444-18-000053:notes:269]
As a result of the Tyco Merger in the fourth quarter of fiscal 2016, the Company recorded, as part of the acquired liabilities of Tyco, $290 million of post sale contingent tax indemnification liabilities which is generally recorded within other noncurrent liabilities in the consolidated statements of financial position. The liabilities are recorded at fair value and relate to certain tax related matters borne by the buyer of previously divested subsidiaries of Tyco which Tyco has indemnified certain parties and the amounts are probable of being paid. At September 30, 2018 and 2017, the Company recorded liabilities of $255 million and $290 million, respectively. Of the $255 million recorded as of September 30, 2018, $235 million is related to prior divested businesses and the remainder relates to Tyco’s tax sharing agreements from its 2007 and 2012 spin-off transactions. These are certain guarantees or indemnifications extended among Tyco, Medtronic, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 separation and tax sharing agreements.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0000833444-18-000053:notes:270]
Goodwill and Indefinite-Lived Intangible Assets

[0000833444-18-000053:notes:271]
Goodwill reflects the cost of an acquisition in excess of the fair values assigned to identifiable net assets acquired. The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s reportable segments or one level below the reportable segments in certain instances, using a fair value method based on management’s judgments and assumptions or third party valuations. The fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. In estimating the fair value, the Company uses multiples of earnings based on the average of published multiples of earnings of comparable entities with similar operations and economic characteristics and applies to the Company's average of historical and future financial results. In certain instances, the Company uses discounted cash flow analyses or estimated sales price to further support the fair value estimates. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The estimated fair value is then compared with the carrying amount of the reporting unit, including recorded goodwill. The Company is subject to financial statement risk to the extent that the carrying amount exceeds the estimated fair value. During the fourth quarter of fiscal 2018, the Company changed the date of its annual goodwill impairment test from September 30 to July 31. The change was made to more closely align the impairment testing date with the Company’s long-term planning and forecasting process. The change in the annual impairment testing date did not delay, accelerate or avoid an impairment charge. The Company has determined this change in accounting principle is preferable and does not result in adjustments to the Company’s financial statements when applied retrospectively.  Refer to Note 7, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for information regarding the goodwill impairment testing performed in the fourth quarters of fiscal years 2018, 2017 and 2016.

[0000833444-18-000053:notes:272]
Indefinite-lived intangible assets are also subject to at least annual impairment testing. Indefinite-lived intangible assets primarily consist of trademarks and tradenames and are tested for impairment using a relief-from-royalty method. A considerable amount of management judgment and assumptions are required in performing the impairment tests.

[0000833444-18-000053:notes:273]
Impairment of Long-Lived Assets

[0000833444-18-000053:notes:274]
The Company reviews long-lived assets, including tangible assets and other intangible assets with definitive lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of software to be sold, leased, or marketed."  ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. ASC 350-30 requires intangible assets acquired in a business combination that are used in research and development activities to be considered indefinite lived until the completion or abandonment of the associated research and development efforts. During the period that those assets are considered indefinite lived, they shall not be amortized but shall be tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired.  If the carrying amount of an intangible asset exceeds its fair value, an entity shall recognize an impairment loss in an amount equal to that excess. ASC 985-20 requires the unamortized capitalized costs of a computer software product be compared to the net realizable value of that product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset shall be written off. Refer to Note 17, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for information regarding the impairment testing performed in fiscal years 2018, 2017 and 2016.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-18-000053:notes:275]
INCOME TAXES

[0000833444-18-000053:notes:276]
For fiscal 2018 and 2017, the more significant components of the Company’s income tax provision from continuing operations are as follows (in millions):

[0000833444-18-000053:notes:277]
|  | Year Ended September 30, |
|  | 2018 |  | 2017 |
| Tax expense at Ireland statutory rate | $ | 363 |  |  | $ | 320 |  |
| U.S. state income tax, net of federal benefit | 24 |  |  | 23 |  |
| Income subject to the U.S. federal tax rate | 16 |  |  | (188 | ) |
| Income subject to rates different than the statutory rate | (164 | ) |  | 256 |  |
| Reserve and valuation allowance adjustments | 31 |  |  | (164 | ) |
| Impact of acquisitions and divestitures | 145 |  |  | 475 |  |
| U.S. Tax Reform discrete items | 108 |  |  | — |  |
| Restructuring and impairment costs | (5 | ) |  | (17 | ) |
| Income tax provision | $ | 518 |  |  | $ | 705 |  |

[0000833444-18-000053:notes:278]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. The effective rate is above the statutory rate of 12.5% for fiscal 2018 primarily due to the discrete net impacts of U.S. Tax Reform, final income tax effects of the completed divestiture of the Scott Safety business, legal entity restructuring associated with the Power Solutions business, valuation allowance adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives, tax audit closures and tax benefits due to changes in entity tax status. The effective rate is above the statutory rate of 12.5% for fiscal 2017 primarily due to the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries related to the divestiture of the Scott Safety business, the income tax effects of pension mark-to-market gains and tax rate differentials, partially offset by the jurisdictional mix of significant restructuring and impairment costs, Tyco Merger transaction and integration costs, purchase accounting adjustments, tax audit closures, a tax benefit due to changes in entity tax status and the benefits of continuing global tax planning initiatives.

[0000833444-18-000053:notes:279]
For fiscal 2016, the more significant components of the Company’s income tax provision from continuing operations are as follows (in millions):

[0000833444-18-000053:notes:280]
|  | Year Ended September 30, |
|  | 2016 |
| Tax expense at U.S. federal statutory rate | $ | 371 |  |
| State income taxes, net of federal benefit | (6 | ) |
| Foreign income tax expense at different rates and foreign losses without tax benefits | (122 | ) |
| U.S. tax on foreign income | (194 | ) |
| U.S. credits and incentives | (14 | ) |
| Impact of acquisitions and divestitures | 163 |  |
| Restructuring and impairment costs | 28 |  |
| Other | (29 | ) |
| Income tax provision | $ | 197 |  |

[0000833444-18-000053:notes:281]
The U.S. federal statutory tax rate is being used as a comparison since the Company was a U.S. domiciled company for 11 months of fiscal 2016. The effective rate is below the U.S. statutory rate for fiscal 2016 primarily due to the benefits of continuing global tax planning initiatives and foreign tax rate differentials, partially offset by the jurisdictional mix of restructuring and impairment costs, and the tax impacts of the Merger and integration related costs.

[0000833444-18-000053:notes:282]
Valuation Allowances

[0000833444-18-000053:notes:283]
The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary.

[0000833444-18-000053:notes:284]
In the fourth quarter of fiscal 2018, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering feasible tax planning initiatives and other positive and negative evidence, the Company determined that it was more likely than not that certain deferred tax assets primarily within Germany would not be realized. Therefore, the Company recorded $56 million of valuation allowances as income tax expense in the three month period ended September 30, 2018.

[0000833444-18-000053:notes:285]
In the fourth quarter of fiscal 2017, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering tax planning initiatives and other positive and negative evidence, the Company determined that it was more likely than not that certain deferred tax assets primarily in Canada, China and Mexico would not be able to be realized, and it was more likely than not that certain deferred tax assets in Germany would be realized. Therefore, the Company recorded $27 million of net valuation allowances as income tax expense in the three month period ended September 30, 2017.

[0000833444-18-000053:notes:286]
As a result of the Tyco Merger in the fourth quarter of fiscal 2016, the Company recorded as part of the acquired liabilities of Tyco $2.4 billion of valuation allowances. Also in the fourth quarter of fiscal 2016, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering tax planning initiatives and other positive and negative evidence, the Company determined that no other material changes were needed to its valuation allowances. Therefore, there was no impact to income tax expense due to valuation allowance changes in the three month period or year ended September 30, 2016.

[0000833444-18-000053:notes:287]
Uncertain Tax Positions

[0000833444-18-000053:notes:288]
The Company is subject to income taxes in the U.S. and numerous foreign jurisdictions. Judgment is required in determining its worldwide provision for income taxes and recording the related assets and liabilities. In the ordinary course of the Company’s business, there are many transactions and calculations where the ultimate tax determination is uncertain. The Company is regularly under audit by tax authorities.

[0000833444-18-000053:notes:289]
At September 30, 2018, the Company had gross tax effected unrecognized tax benefits for continuing operations of $2,379 million of which $2,246 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2018 was approximately $119 million (net of tax benefit).

[0000833444-18-000053:notes:290]
At September 30, 2017, the Company had gross tax effected unrecognized tax benefits for continuing operations of $2,173 million of which $2,047 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2017 was approximately $99 million (net of tax benefit).

[0000833444-18-000053:notes:291]
At September 30, 2016, the Company had gross tax effected unrecognized tax benefits for continuing operations of $1,706 million of which $1,604 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2016 was approximately $84 million (net of tax benefit).

[0000833444-18-000053:notes:292]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0000833444-18-000053:notes:293]
|  | Year Ended September 30, |
|  | 2018 |  | 2017 |  | 2016 |
| Beginning balance, October 1 | $ | 2,173 |  |  | $ | 1,706 |  |  | $ | 1,052 |  |
| Additions for tax positions related to the current year | 444 |  |  | 613 |  |  | 442 |  |
| Additions for tax positions of prior years | 7 |  |  | 116 |  |  | 15 |  |
| Reductions for tax positions of prior years | (201 | ) |  | (44 | ) |  | (66 | ) |
| Settlements with taxing authorities | (19 | ) |  | (95 | ) |  | (104 | ) |
| Statute closings and audit resolutions | (25 | ) |  | (264 | ) |  | (30 | ) |
| Acquisition of business | — |  |  | 141 |  |  | 397 |  |
| Ending balance, September 30 | $ | 2,379 |  |  | $ | 2,173 |  |  | $ | 1,706 |  |

[0000833444-18-000053:notes:294]
During fiscal 2018, the Company settled tax examinations impacting fiscal years 2010 to fiscal 2012 which resulted in a $25 million net benefit to income tax expense.

[0000833444-18-000053:notes:295]
During fiscal 2017, the Company settled a significant number of tax examinations impacting fiscal years 2006 to fiscal 2014. In the fourth quarter of fiscal 2017, income tax audit resolutions resulted in a net $191 million benefit to income tax expense.

[0000833444-18-000053:notes:296]
In the U.S., fiscal years 2015 through 2016 are currently under exam by the Internal Revenue Service ("IRS") for certain legal entities. Additionally, the Company is currently under exam in the following major non-U.S. jurisdictions for continuing operations:

[0000833444-18-000053:notes:297]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2017 |
| China |  | 2008 - 2016 |
| France |  | 2010 - 2012; 2015-2016 |
| Germany |  | 2007 - 2016 |
| Spain |  | 2010 - 2012 |
| United Kingdom |  | 2012 - 2015 |

[0000833444-18-000053:notes:298]
It is reasonably possible that certain tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact to tax expense.

[0000833444-18-000053:notes:299]
Other Tax Matters

[0000833444-18-000053:notes:300]
In the fourth quarter of fiscal 2018, the Company recorded a tax benefit of $139 million due to changes in entity tax status.

[0000833444-18-000053:notes:301]
In the fourth quarter of fiscal 2018, the Company recorded a tax charge of $129 million due to legal entity restructuring associated with the Power Solutions business.

[0000833444-18-000053:notes:302]
In the first quarter of fiscal 2018, the Company completed the sale of its Scott Safety business to 3M Company. In connection with the sale, the Company recorded a pre-tax gain of $114 million and income tax expense of $30 million. In addition, during fiscal 2017, the Company recorded a discrete non-cash tax charge of $490 million related to establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries of the Scott Safety business. Refer to Note 3, "Acquisitions and Divestitures," and Note 4, "Discontinued Operations," of the notes to consolidated financial statements for additional information.

[0000833444-18-000053:notes:303]
During fiscal 2018 and 2017, the Company recorded transaction and integration costs of $234 million and $428 million, respectively. These costs generated tax benefits of $27 million and $69 million, respectively, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-18-000053:notes:304]
During fiscal 2018, 2017 and 2016, the Company incurred significant charges for restructuring and impairment costs of $263 million, $367 million and $288 million, respectively. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. These costs generated tax benefits of $38 million, $63 million and $76 million, respectively, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-18-000053:notes:305]
During fiscal 2018, 2017 and 2016, the Company recorded pension mark-to-market gains (losses) of $10 million, $420 million and $(393) million, respectively. These gains generated tax expense (benefit) of $(3) million, $126 million and $(119) million, respectively, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-18-000053:notes:306]
In the fourth quarter of fiscal 2017, the Company recorded a tax charge of $53 million due to a change in the deferred tax liability related to the outside basis of certain nonconsolidated subsidiaries.

[0000833444-18-000053:notes:307]
In the first quarter of fiscal 2017, the Company recorded a discrete tax benefit of $101 million due to changes in entity tax status.

[0000833444-18-000053:notes:308]
During the fourth quarter of fiscal 2016, the Company completed its Merger with Tyco. As a result of that transaction, the Company incurred incremental tax expense of $137 million. In preparation for the spin-off of the Automotive Experience business in the first quarter of fiscal 2017, the Company incurred incremental tax expense for continuing operations of $26 million in fiscal 2016.

[0000833444-18-000053:notes:309]
As a result of the Tyco Merger in the fourth quarter of fiscal 2016, the Company recorded as part of the acquired liabilities of Tyco $290 million of post sale contingent tax indemnification liabilities which is generally recorded within other noncurrent liabilities in the consolidated statements of financial position. The liabilities are recorded at fair value and relate to certain tax related matters borne by the buyer of previously divested subsidiaries of Tyco which Tyco has indemnified certain parties and the amounts are probable of being paid. At September 30, 2018 and 2017, the Company recorded liabilities of $255 million and $290 million, respectively. Of the $255 million recorded as of September 30, 2018, $235 million is related to prior divested businesses and the remainder relates to Tyco’s tax sharing agreements from its 2007 and 2012 spin-off transactions. These are certain guarantees or indemnifications extended among Tyco, Medtronic, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 separation and tax sharing agreements.

[0000833444-18-000053:notes:310]
Impacts of Tax Legislation and Change in Statutory Tax Rates

[0000833444-18-000053:notes:311]
On December 22, 2017, the “Tax Cuts and Jobs Act” (H.R. 1) was enacted and significantly revises U.S. corporate income tax by, among other things, lowering corporate income tax rates, imposing a one-time transition tax on deemed repatriated earnings of non-U.S. subsidiaries, and implementing a territorial tax system and various base erosion minimum tax provisions.

[0000833444-18-000053:notes:312]
In connection with the Company’s analysis of the impact of the U.S. tax law changes, which is provisional and subject to change, the Company recorded a net tax charge of $108 million during fiscal 2018.  This provisional net tax charge arises from a benefit of $108 million due to the remeasurement of U.S. deferred tax assets and liabilities, offset by the Company’s tax charge relating to the one-time transition tax on deemed repatriated earnings, inclusive of all relevant taxes, of $216 million. The Company’s estimated benefit of the remeasurement of U.S. deferred tax assets and liabilities increased from $101 million as of December 31, 2017 to $108 million as of September 30, 2018 due to calculation refinement of the Company’s estimated impact. The Company remeasured certain deferred tax assets and liabilities based on the rates at which they are expected to reverse in the future. The Company’s tax charge for transition tax decreased from $305 million as of December 31, 2017 to $216 million as of September 30, 2018 due to further analysis of the Company’s post-1986 non-U.S. earnings and profits (“E&P”) previously deferred from U.S. federal taxation and refinement of the estimated impact of tax law changes.

[0000833444-18-000053:notes:313]
Based on the effective dates of certain aspects of the U.S. tax law changes, various applicable impacts of the enacted legislation could not be finalized as of September 30, 2018.  While the Company made reasonable estimates of the impact of the transition tax, the final impact of the U.S. tax law changes may differ from these estimated impacts, due to, future treasury regulations, tax law technical corrections, notices, rulings, refined computations, and other items. The Company will finalize such provisional amounts within the time period prescribed by Staff Accounting Bulletin 118.

[0000833444-18-000053:notes:314]
During the fiscal years ended 2018, 2017 and 2016, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-18-000053:notes:315]
Continuing Operations

[0000833444-18-000053:notes:316]
Components of the provision for income taxes on continuing operations were as follows (in millions):

[0000833444-18-000053:notes:317]
|  | Year Ended September 30, |
|  | 2018 |  | 2017 |  | 2016 |
| Current |  |  |  |  |  |
| U.S. federal | $ | 515 |  |  | $ | (225 | ) |  | $ | 169 |  |
| U.S. state | 34 |  |  | (6 | ) |  | 5 |  |
| Non-U.S. | 605 |  |  | 373 |  |  | 788 |  |
|  | 1,154 |  |  | 142 |  |  | 962 |  |
| Deferred |  |  |  |  |  |
| U.S. federal | (284 | ) |  | 593 |  |  | (321 | ) |
| U.S. state | (11 | ) |  | 41 |  |  | (15 | ) |
| Non-U.S. | (341 | ) |  | (71 | ) |  | (429 | ) |
|  | (636 | ) |  | 563 |  |  | (765 | ) |
| Income tax provision | $ | 518 |  |  | $ | 705 |  |  | $ | 197 |  |

[0000833444-18-000053:notes:318]
Consolidated U.S. income from continuing operations before income taxes and noncontrolling interests for the fiscal years ended September 30, 2018, 2017 and 2016 was income of $773 million, $868 million and $943 million, respectively. Consolidated non-U.S. income from continuing operations before income taxes and noncontrolling interests for the fiscal years ended September 30, 2018, 2017 and 2016 was income of $2,128 million, $1,690 million and $119 million, respectively.

[0000833444-18-000053:notes:319]
Income taxes paid for the fiscal years ended September 30, 2018, 2017 and 2016 were $517 million, $1,756 million and $1,388 million, respectively. At September 30, 2018 and 2017, the Company recorded within the consolidated statements of financial position in other current liabilities approximately $336 million and $625 million, respectively, of accrued income tax liabilities.

[0000833444-18-000053:notes:320]
The Company has not provided U.S. or non-U.S. income taxes on approximately $19.5 billion of outside basis differences of consolidated subsidiaries of Johnson Controls International plc. The Company is indefinitely reinvested in these basis differences. The reduction of the outside basis differences via the sale or liquidation of these subsidiaries and/or distributions could create taxable income. The Company's intent is to reduce the outside basis differences only when it would be tax efficient. Given the numerous ways in which the basis differences may be reduced, it is not practicable to estimate the amount of unrecognized withholding taxes and deferred tax liability on the outside basis differences. In fiscal 2018, due to U.S. Tax Reform, the Company provided income tax related to the change in the Company’s assertion over the outside basis difference of certain non-U.S. subsidiaries owned directly or indirectly by U.S. subsidiaries. Under U.S. Tax Reform, the U.S. has enacted a tax system that provides an exemption for dividends received by U.S. corporations from 10% or more owned non-U.S. corporations. However, certain non-U.S, U.S. state and withholding taxes may still apply when closing an outside basis difference via distribution or other transactions.

[0000833444-18-000053:notes:321]
Temporary differences and carryforwards which gave rise to deferred tax assets and liabilities included (in millions):

[0000833444-18-000053:notes:322]
|  | September 30, |
|  | 2018 |  | 2017 |
| Deferred tax assets |  |  |  |
| Accrued expenses and reserves | $ | 490 |  |  | $ | 891 |  |
| Employee and retiree benefits | 193 |  |  | 373 |  |
| Net operating loss and other credit carryforwards | 6,510 |  |  | 5,130 |  |
| Research and development | 93 |  |  | 188 |  |
| Other, net | — |  |  | 26 |  |
|  | 7,286 |  |  | 6,608 |  |
| Valuation allowances | (5,195 | ) |  | (3,838 | ) |
|  | 2,091 |  |  | 2,770 |  |
| Deferred tax liabilities |  |  |  |
| Property, plant and equipment | 172 |  |  | 247 |  |
| Subsidiaries, joint ventures and partnerships | 306 |  |  | 789 |  |
| Intangible assets | 713 |  |  | 1,107 |  |
| Other, net | 72 |  |  | — |  |
|  | 1,263 |  |  | 2,143 |  |
| Net deferred tax asset | $ | 828 |  |  | $ | 627 |  |

[0000833444-18-000053:notes:323]
At September 30, 2018, the Company had available net operating loss carryforwards of approximately $24.3 billion, of which $13.5 billion will expire at various dates between 2019 and 2038, and the remainder has an indefinite carryforward period. The Company had available U.S. foreign tax credit carryforwards at September 30, 2018 of $624 million which may be carried back to fiscal period 2016 or which will otherwise expire at various dates between 2020 and 2024. The valuation allowance, generally, is for loss carryforwards for which realization is uncertain because it is unlikely that the losses will be realized given the lack of sustained profitability and/or limited carryforward periods in certain countries.

[0000833444-18-000053:notes:324]
During the first quarter of 2018, the Company adopted ASU 2016-09. As a result, the Company recognized deferred tax assets of $179 million in the consolidated statements of financial position related to certain operating loss carryforwards resulting from the exercise of employee stock options and restricted stock vestings on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of October 1, 2017.


## us-gaap:IncomeTaxPolicyTextBlock

[0000833444-18-000053:notes:325]
Income Taxes

[0000833444-18-000053:notes:326]
Deferred tax liabilities and assets are recognized for the expected future tax consequences of events that have been reflected in the consolidated financial statements. Deferred tax liabilities and assets are determined based on the differences between the book and tax basis of particular assets and liabilities and operating loss carryforwards, using tax rates in effect for the years in which the differences are expected to reverse. A valuation allowance is provided to reduce the carrying or book value of deferred tax assets if, based upon the available evidence, including consideration of tax planning strategies, it is more-likely-than-not that some or all of the deferred tax assets will not be realized. Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-18-000053:notes:327]
INVENTORIES

[0000833444-18-000053:notes:328]
Inventories consisted of the following (in millions):

[0000833444-18-000053:notes:329]
|  | September 30, |
|  | 2018 |  | 2017 |
| Raw materials and supplies | $ | 990 |  |  | $ | 919 |  |
| Work-in-process | 545 |  |  | 567 |  |
| Finished goods | 1,689 |  |  | 1,723 |  |
| Inventories | $ | 3,224 |  |  | $ | 3,209 |  |


## us-gaap:InventoryPolicyTextBlock

[0000833444-18-000053:notes:330]
Inventories

[0000833444-18-000053:notes:331]
Inventories are stated at the lower of cost or market using the first-in, first-out ("FIFO") method. Finished goods and work-in-process inventories include material, labor and manufacturing overhead costs.


## us-gaap:LeasesOfLesseeDisclosureTextBlock

[0000833444-18-000053:notes:332]
LEASES

[0000833444-18-000053:notes:333]
Certain administrative and production facilities and equipment are leased under long-term agreements. Most leases contain renewal options for varying periods, and certain leases include options to purchase the leased property during or at the end of the lease term. Leases generally require the Company to pay for insurance, taxes and maintenance of the property. Leased capital assets included in net property, plant and equipment, primarily buildings and improvements, were $32 million and $17 million at September 30, 2018 and 2017, respectively.

[0000833444-18-000053:notes:334]
Other facilities and equipment are leased under arrangements that are accounted for as operating leases. Total rental expense for continuing and discontinued operations for the fiscal years ended September 30, 2018, 2017 and 2016 was $467 million, $502 million and $402 million, respectively.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-18-000053:notes:335]
MERGER TRANSACTION

[0000833444-18-000053:notes:336]
As discussed in Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements, JCI Inc. and Tyco completed the Merger on September 2, 2016. The Merger was accounted for as a reverse acquisition using the acquisition method of accounting in accordance with ASC 805, "Business Combinations." Based on the structure of the Merger and other activities contemplated by the Merger Agreement, relative outstanding share ownership, the composition of the Company's board of directors and the designation of certain senior management positions of the Company, JCI Inc. was the accounting acquirer for financial reporting purposes.

[0000833444-18-000053:notes:337]
Immediately prior to the Merger and in connection therewith, Tyco shareholders received 0.955 ordinary shares of Tyco (which shares are now referred to as shares of the Company, or “Company ordinary shares”) for each Tyco ordinary share they held by virtue of a 0.955-for-one share consolidation. In the Merger, each outstanding share of common stock, par value $1.00 per share, of JCI Inc. (“JCI Inc. common stock”) (other than shares held by JCI Inc., Tyco and certain of their subsidiaries) was converted into the right to receive either the cash consideration or the share consideration (each as described below), at the election of the holder, subject to proration procedures described in the Merger Agreement and applicable withholding taxes.  The election to receive the cash consideration was undersubscribed. As a result, holders of shares of JCI Inc. common stock that elected to receive the share consideration and holders of shares of JCI Inc. common stock that made no election (or failed to properly make an election) became entitled to receive, for each such share of JCI Inc. common stock, $5.7293 in cash, without interest, and 0.8357 Company ordinary shares, subject to applicable withholding taxes. Holders of shares of JCI Inc. common stock that elected to receive the cash consideration became entitled to receive, for each such share of JCI Inc. common stock, $34.88 in cash, without interest, subject to applicable withholding taxes.  In the Merger, JCI Inc. shareholders received, in the aggregate, approximately $3.864 billion in cash. Immediately after the closing of, and giving effect to, the Merger, former JCI Inc. shareholders owned approximately 56% of the issued and outstanding Company ordinary shares and former Tyco stockholders owned approximately 44% of the issued and outstanding Company ordinary shares.

[0000833444-18-000053:notes:338]
Tyco is a leading global provider of security products and services as well as fire detection and suppression products and services. The acquisition of Tyco brings together best-in-class product, technology and service capabilities across controls, fire, security, HVAC and power solutions to serve various end-markets including large institutions, commercial buildings, retail, industrial, small business and residential.  The combination of the Tyco and JCI Inc. buildings platforms creates immediate opportunities for near-term growth through cross-selling, complementary branch and channel networks, and expanded global reach for established businesses. The new Company also benefits by combining innovation capabilities and pipelines involving new products, advanced solutions for smart buildings and cities, value-added services driven by advanced data and analytics.

[0000833444-18-000053:notes:339]
Fair Value of Consideration Transferred

[0000833444-18-000053:notes:340]
The total fair value of consideration transferred was approximately $19.7 billion. Total consideration is comprised of the equity value of the Tyco shares that were outstanding as of September 2, 2016 and the portion of Tyco's share awards and share options earned as of September 2, 2016 ($224 million). Share awards and share options not earned ($101 million) as of September 2, 2016 will be expensed over the remaining future vesting period.

[0000833444-18-000053:notes:341]
Fair Value of Assets Acquired and Liabilities Assumed

[0000833444-18-000053:notes:342]
The Company accounted for the Merger with Tyco as a business combination using the acquisition method of accounting. The assets acquired and liabilities assumed were recorded at their respective fair values as of the acquisition date.  Fair value estimates are based on a complex series of judgments about future events and uncertainties and rely heavily on estimates and assumptions. The judgments used to determine the estimated fair value assigned to each class of assets acquired and liabilities assumed, as well as asset lives, can materially impact the Company's results of operations.

[0000833444-18-000053:notes:343]
The fair values of the assets acquired and liabilities assumed are as follows (in millions):

[0000833444-18-000053:notes:344]
| Cash and cash equivalents |  | $ | 489 |  |
| Accounts receivable |  | 2,034 |  |
| Inventories |  | 807 |  |
| Other current assets |  | 617 |  |
| Property, plant, and equipment - net |  | 1,216 |  |
| Goodwill |  | 16,105 |  |
| Intangible assets - net |  | 6,384 |  |
| Other noncurrent assets |  | 536 |  |
| Total assets acquired |  | $ | 28,188 |  |
| Short-term debt |  | $ | 462 |  |
| Accounts payable |  | 725 |  |
| Accrued compensation and benefits |  | 312 |  |
| Other current liabilities |  | 1,481 |  |
| Long-term debt |  | 6,416 |  |
| Long-term deferred tax liabilities |  | 718 |  |
| Long-term pension and postretirement benefits |  | 774 |  |
| Other noncurrent liabilities |  | 1,456 |  |
| Total liabilities acquired |  | $ | 12,344 |  |
| Noncontrolling interests |  | 37 |  |
| Net assets acquired |  | $ | 15,807 |  |
| Cash consideration paid to JCI Inc. shareholders |  | 3,864 |  |
| Total fair value of consideration transferred |  | $ | 19,671 |  |

[0000833444-18-000053:notes:345]
In connection with the Merger, the Company recorded goodwill of $16.1 billion, which is attributable primarily to expected synergies, expanded market opportunities, and other benefits that the Company believes will result from combining its operations with the operations of Tyco. Goodwill has been allocated to the reporting units within Building Technologies & Solutions business based on the expected benefits from the Merger. The Company recorded a net reduction in goodwill of $258 million in fiscal 2017 related to purchase price allocations. The goodwill created in the Merger is not deductible for tax purposes.

[0000833444-18-000053:notes:346]
Actual and Pro Forma Impact

[0000833444-18-000053:notes:347]
The Company's consolidated financial statements for the fiscal year ended September 30, 2016 include Tyco's results of operations from the acquisition date of September 2, 2016 through September 30, 2016. Net sales and net income (loss) from continuing operations attributable to Tyco during this period and included in the Company's consolidated financial statements for the fiscal year ended September 30, 2016 total $808 million and ($48) million, respectively.

[0000833444-18-000053:notes:348]
In order to reflect the occurrence of the acquisition on October 1, 2014 as required, the unaudited pro forma results include adjustments to reflect, among other things, the amortization of the inventory step-up, the incremental intangible asset amortization to be incurred based on the preliminary values of each identifiable intangible asset,  the change in timing of defined benefit plans' mark-to-market gain or loss recognition, the change in timing of transaction and restructuring costs, and interest expense from debt financing obtained to fund the cash consideration paid to JCI Inc. shareholders. These pro forma amounts are not necessarily indicative of the results that would have been obtained if the acquisition had occurred as of the beginning of the period presented or that may occur in the future, and does not reflect future synergies, integration costs, or other such costs or savings. Additional information regarding fiscal 2016 pro forma information can be found in the Form 8-K filed by the Company with the SEC on November 8, 2016 under Item 7.01, “Regulation FD Disclosure.”

[0000833444-18-000053:notes:349]
ACQUISITIONS AND DIVESTITURES

[0000833444-18-000053:notes:350]
Fiscal Year 2018

[0000833444-18-000053:notes:351]
During fiscal 2018, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $21 million, all of which was paid as of September 30, 2018. The acquisitions in the aggregate were not material to the Company’s consolidated financial statements. In connection with the acquisitions, the Company recorded goodwill of $14 million within the Global Products segment and $1 million within the Building Solutions EMEA/LA segment.

[0000833444-18-000053:notes:352]
In the first quarter of fiscal 2018, the Company completed the sale of its Scott Safety business to 3M Company. The selling price, net of cash divested, was $2.0 billion, all of which was received as of September 30, 2018. In connection with the sale, the Company recorded a pre-tax gain of $114 million within selling, general and administrative expenses in the consolidated statements of income and reduced goodwill in assets held for sale by $1.2 billion. The gain, net of tax, recorded was $84 million. Net cash proceeds from the transaction of approximately $1.9 billion were used to repay a significant portion of the Tyco International Holding S.a.r.L.'s ("TSarl") $4.0 billion of merger-related debt. The Scott Safety business is included in the Global Products segment and was reported within assets and liabilities held for sale in the consolidated statements of financial position as of September 30, 2017. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further disclosure related to the Company's net assets held for sale.

[0000833444-18-000053:notes:353]
Also during fiscal 2018, the Company completed certain divestitures primarily within the Global Products business. The combined selling price was $204 million, all of which was received as of September 30, 2018. In connection with the divestitures, the Company reduced goodwill by $35 million. The divestitures were not material to the Company's consolidated financial statements.

[0000833444-18-000053:notes:354]
Fiscal Year 2017

[0000833444-18-000053:notes:355]
During fiscal 2017, the Company completed three acquisitions for a combined purchase price, net of cash acquired, of $9 million, $6 million of which was paid as of September 30, 2017. The acquisitions in the aggregate were not material to the Company’s consolidated financial statements. In connection with the acquisitions, the Company recorded goodwill of $2 million.

[0000833444-18-000053:notes:356]
In the second quarter of fiscal 2017, the Company completed the sale of its ADT security business in South Africa within the Building Solutions EMEA/LA segment. The selling price, net of cash divested, was $129 million, all of which was received as of September 30, 2017. In connection with the sale, the Company reduced goodwill in assets held for sale by $92 million. The divestiture was not material to the Company's consolidated financial statements.

[0000833444-18-000053:notes:357]
During fiscal 2017, the Company completed two divestitures for a combined selling price, net of cash divested, of $44 million, of which $40 million was received as of September 30, 2017. The divestitures were not material to the Company's consolidated financial statements. In connection with the divestitures, the Company reduced goodwill by $19 million and $2 million in the Global Products segment and in the Building Solutions Asia Pacific segment, respectively.

[0000833444-18-000053:notes:358]
During fiscal 2017, the Company completed one additional divestiture for a sales price of $4 million, all of which was received as of September 30, 2017. The divestiture decreased the Company's ownership from a controlling to noncontrolling interest, and as a result, the Company deconsolidated cash of $5 million. The divestiture was not material to the Company's consolidated financial statements.

[0000833444-18-000053:notes:359]
During fiscal 2017, the Company received $52 million in net cash proceeds related to prior year business divestitures and paid $75 million related to prior year business acquisitions.

[0000833444-18-000053:notes:360]
Fiscal Year 2016

[0000833444-18-000053:notes:361]
On October 1, 2015, the Company formed a joint venture with Hitachi to expand its Building Technologies & Solutions product offerings. The Company acquired a 60% ownership interest in the new entity for approximately $208 million ($638 million purchase price less cash acquired of $430 million), $133 million of which was paid as of September 30, 2016. In connection with the acquisition, the Company recorded goodwill of $253 million related to purchase price allocations.

[0000833444-18-000053:notes:362]
Also during fiscal 2016, the Company completed two additional acquisitions for a combined purchase price, net of cash acquired, of $6 million, $3 million of which was paid as of September 30, 2016. The acquisitions in aggregate were not material to the Company's consolidated financial statements. In connection with the acquisitions, the Company recorded goodwill of $6 million. One of the acquisitions increased the Company's ownership from a noncontrolling to controlling interest. As a result, the Company recorded a non-cash gain of $4 million in equity income for the Global Products segment to adjust the Company's existing equity investment in the partially-owned affiliate to fair value.

[0000833444-18-000053:notes:363]
In the fourth quarter of fiscal 2016, the Company completed two divestitures for a combined sales price of $39 million, net of cash divested of $13 million. None of the sales proceeds were received as of September 30, 2016. The divestitures were not material to the Company's consolidated financial statements. In connection with the divestitures, the Company reduced goodwill by $16 million in the Global Products segment.

[0000833444-18-000053:notes:364]
In the third quarter of fiscal 2016, the Company completed a divestiture for a sales price of $16 million, all of which was received as of September 30, 2016. The divestiture was not material to the Company's consolidated financial statements. In connection with the divestiture, the Company reduced goodwill by $3 million in the Building Solutions North America segment.

[0000833444-18-000053:notes:365]
During fiscal 2016, the Company received $29 million in net cash proceeds related to prior year business divestitures.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000833444-18-000053:notes:366]
New Accounting Pronouncements

[0000833444-18-000053:notes:367]
Recently Adopted Accounting Pronouncements

[0000833444-18-000053:notes:368]
On August 17, 2018, the U.S. Securities and Exchange Commission  ("SEC") issued the final rule under SEC Release No. 33-10532, "Disclosure Update and Simplification," that amends certain of its disclosure requirements that have become redundant, duplicative, overlapping, outdated or superseded.  The amendments include removing the requirement to disclose the historical and pro forma ratio of earnings to fixed charges (Exhibit 12) and replacing the requirement to disclose the high and low trading prices of entity's ordinary shares with a requirement to disclose the ticker symbol of its shares. Additionally, the final rule extends to interim periods the annual disclosure requirement of presenting changes in each caption of stockholders' equity and the amount of dividends per share. These disclosures are required to be provided for the current and comparative year-to-date interim periods. The final rule is effective for all filings on or after November 5, 2018. The Company has adopted all relevant disclosure requirements for its annual report on Form 10-K for the year ended September 30, 2018.

[0000833444-18-000053:notes:369]
In March 2018, the FASB issued ASU No. 2018-05, "Income Taxes (Topic 740): Amendments to SEC Paragraphs Pursuant to SEC Staff Accounting Bulletin No. 118," to add various SEC paragraphs pursuant to the issuance of SEC Staff Accounting Bulletin No. 118 ("SAB 118") to ASC 740 "Income Taxes." SAB 118 was issued by the SEC in December 2017 to provide immediate guidance for accounting implications of U.S. Tax Reform under the "Tax Cuts and Jobs Act" in the period of enactment. SAB 118 provides for a provisional one year measurement period for entities to finalize their accounting for certain income tax effects related to the "Tax Cuts and Jobs Act." The Company applied this guidance to its consolidated financial statements and related disclosures beginning in the quarter ended December 31, 2017. Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements for further information.

[0000833444-18-000053:notes:370]
In August 2017, the FASB issued ASU No. 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities." The ASU more closely aligns the results of hedge accounting with risk management activities through amendments to the designation and measurement guidance to better reflect a Company's hedging strategy and effectiveness. During the quarter ended December 31, 2017, the Company early adopted ASU 2017-12. The adoption of this guidance did not have a material impact on the Company's consolidated financial statements.

[0000833444-18-000053:notes:371]
Recently Issued Accounting Pronouncements

[0000833444-18-000053:notes:372]
In March 2017, the FASB issued ASU No. 2017-07, "Compensation—Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost." The ASU requires the service cost component of net periodic benefit cost to be presented with other compensation costs. The other components of net periodic benefit cost are required to be presented in the income statement separately from the service cost component and outside a subtotal of income from operations, if one is presented. The ASU also allows only the service cost component of net periodic benefit cost to be eligible for capitalization. The guidance will be effective for the Company for the quarter ending December 31, 2018. Early adoption is permitted as of the beginning of an annual period for which financial statements (interim or annual) have not been issued or made available for issuance. The guidance will be effective retrospectively except for the capitalization of the service cost component which should be applied prospectively. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements as the Company does not present a subtotal of income from operations within its consolidated statements of income.

[0000833444-18-000053:notes:373]
In November 2016, the FASB issued ASU No. 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force)." The ASU requires amounts generally described as restricted cash and restricted cash equivalents to be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. The guidance will be effective for the Company for the quarter ending December 31, 2018, with early adoption permitted. The amendments in this update should be applied retrospectively to all periods presented. The impact of this guidance for the Company will depend on the levels of restricted cash balances in the periods presented. As of September 30, 2016, the Company had approximately $2.0 billion of restricted cash related to restricted proceeds deposited into escrow from the issuance of $2.0 billion aggregate principal of unsecured, unsubordinated notes by Adient Global Holdings Ltd., that were released upon the completion of the Adient spin-off in October 2016. Upon adoption of ASU 2016-18, the restricted proceeds will be presented in the fiscal 2016 consolidated statements of cash flow as a financing activity inflow, and the release of the restricted proceeds will be presented in the fiscal 2017 consolidated statements of cash flow as a financing activity outflow. The impact of adoption of this standard on fiscal 2018 consolidated statements of cash flow is not expected to be material as the restricted cash balance at September 30, 2018 is $15 million.

[0000833444-18-000053:notes:374]
In October 2016, the FASB issued ASU No. 2016-16, "Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory." The ASU requires the tax effects of all intra-entity sales of assets other than inventory to be recognized in the period in which the transaction occurs. The guidance will be effective for the Company for the quarter ending December 31, 2018, with early adoption permitted but only in the first interim period of a fiscal year. The changes are required to be applied by means of a cumulative-effect adjustment recorded in retained earnings as of the beginning of the fiscal year of adoption. The Company expects that the cumulative effect of the adoption of ASU 2016-16 will result in a reduction to retained earnings of approximately $550 million.

[0000833444-18-000053:notes:375]
In August 2016, the FASB issued ASU No. 2016-15, "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments." ASU No. 2016-15 provides clarification guidance on eight specific cash flow presentation issues in order to reduce the diversity in practice. ASU No. 2016-15 will be effective for the Company for the quarter ending December 31, 2018, with early adoption permitted. The guidance should be applied retrospectively to all periods presented, unless deemed impracticable, in which case prospective application is permitted. The adoption of this guidance is expected to have an impact on the presentation of equity swap funding and settlement activities since the activity will change from an operating activity to an investing activity. The Company does not expect any other significant impacts as a result of adopting this standard.

[0000833444-18-000053:notes:376]
In February 2016, the FASB issued ASU No. 2016-02, "Leases (Topic 842)." ASU No. 2016-02 requires recognition of operating leases as lease assets and liabilities on the balance sheet, and disclosure of key information about leasing arrangements. The original standard was effective retrospectively for the Company for the quarter ending December 31, 2019 with early adoption permitted; however in July 2018 the FASB issued ASU No. 2018-11, "Leases (Topic 842): Targeted Improvements," which provides an additional transition method that permits changes to be applied by means of a cumulative-effect adjustment recorded in retained earnings as of the beginning of the fiscal year of adoption. The Company has elected this transition method at the adoption date of October 1, 2019. The Company has started the assessment process by evaluating the population of leases under the revised definition of what qualifies as a leased asset. The Company is the lessee under various agreements for facilities and equipment that are currently accounted for as operating leases. The new guidance will require the Company to record operating leases on the balance sheet with a right-of-use asset and corresponding liability for future payment obligations. Additionally in January 2018, the FASB issued ASU No. 2018-01, "Leases (Topic 842): Land Easement Practical Expedient for Transition to Topic 842," which provides an optional transition practical expedient for existing or expired land easements that were not previously recorded as leases. The Company expects the new guidance will have a material impact on its consolidated statements of financial position for the addition of right-of-use assets and lease liabilities, but the Company does not expect it to have a material impact on its consolidated statements of income and its consolidated statements of cash flows.

[0000833444-18-000053:notes:377]
In January 2016, the FASB issued ASU No. 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." ASU No. 2016-01 amends certain aspects of recognition, measurement, presentation and disclosure of financial instruments, including marketable securities. ASU No. 2016-01 will be effective for the Company for the quarter ending December 31, 2018, and early adoption is not permitted, with certain exceptions. The changes are required to be applied by means of a cumulative-effect adjustment on the balance sheet as of the beginning of the fiscal year of adoption. Additionally in February 2018, the FASB issued ASU No. 2018-03, "Technical Corrections and Improvements to Financial Instruments-Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities," which provides additional clarification on certain topics addressed in ASU No. 2016-01. ASU No. 2018-01 will be effective for the Company when ASU No. 2016-01 is adopted. The impact of this guidance for the Company will depend on the magnitude of the unrealized gains and losses on the Company's marketable securities investments. The impact to beginning retained earnings as a result of the adoption of this guidance is not expected to be material.

[0000833444-18-000053:notes:378]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers (Topic 606)." ASU No. 2014-09 clarifies the principles for recognizing revenue when an entity either enters into a contract with customers to transfer goods or services or enters into a contract for the transfer of non-financial assets. The original standard was effective retrospectively for the Company for the quarter ending December 31, 2017; however in August 2015, the FASB issued ASU No. 2015-14, "Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date," which defers the effective date of ASU No. 2014-09 by one-year for all entities. The new standard will become effective retrospectively for the Company for the quarter ending December 31, 2018, with early adoption permitted, but not before the original effective date. Additionally, in March 2016, the FASB issued ASU No. 2016-08, "Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net)," in April 2016, the FASB issued ASU No. 2016-10, "Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing," in May 2016, the FASB issued ASU No. 2016-12, "Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients," and in December 2016, the FASB issued ASU No. 2016-20, "Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers," all of which provide additional clarification on certain topics addressed in ASU No. 2014-09. ASU No. 2016-08, ASU No. 2016-10, ASU No. 2016-12 and ASU No. 2016-20 follow the same implementation guidelines as ASU No. 2014-09 and ASU No. 2015-14. The Company has elected to adopt the new revenue guidance as of October 1, 2018 using the modified retrospective approach. The Company has completed its evaluation of the new revenue recognition standard and has assessed the impact on its consolidated financial statements. Based on the Company’s evaluation of current contracts and significant revenue streams, revenue recognition is expected to be mostly consistent under both the current and new standard, with the exception of the Power Solutions business. Within the Power Solutions business, certain customers return battery cores which will be included in the transaction price as noncash consideration under the new revenue standard. This change is expected to result in an increase to annual Power Solutions revenue of approximately 10% - 15% and an immaterial impact to gross profit. The Company does not expect the new revenue standard will have a material impact on its consolidated statements of financial position or its consolidated statements of cash flows. Upon adoption of the new revenue recognition guidance, the Company expects to record approximately $35 million to beginning retained earnings, which relates primarily to deferred revenue recorded for certain battery core returns that represent a material right provided to customers.

[0000833444-18-000053:notes:379]
Other recently issued accounting pronouncements are not expected to have a material impact on the Company's consolidated

[0000833444-18-000053:notes:380]
financial statements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-18-000053:notes:381]
RETIREMENT PLANS

[0000833444-18-000053:notes:382]
Pension Benefits

[0000833444-18-000053:notes:383]
The Company has non-contributory defined benefit pension plans covering certain U.S. and non-U.S. employees. The benefits provided are primarily based on years of service and average compensation or a monthly retirement benefit amount. Certain of the Company’s U.S. pension plans have been amended to prohibit new participants from entering the plans and no longer accrue benefits. Funding for U.S. pension plans equals or exceeds the minimum requirements of the Employee Retirement Income Security Act of 1974. Funding for non-U.S. plans observes the local legal and regulatory limits. Also, the Company makes contributions to union-trusteed pension funds for construction and service personnel.

[0000833444-18-000053:notes:384]
For pension plans with accumulated benefit obligations ("ABO") that exceed plan assets, the projected benefit obligation ("PBO"), ABO and fair value of plan assets of those plans were $5,166 million, $5,072 million and $4,525 million, respectively, as of September 30, 2018 and $5,564 million, $5,465 million and $4,715 million, respectively, as of September 30, 2017.

[0000833444-18-000053:notes:385]
In fiscal 2018, total employer contributions to the defined benefit pension plans were $53 million, of which $18 million were voluntary contributions made by the Company. The Company expects to contribute approximately $85 million in cash to its defined benefit pension plans in fiscal 2019. Projected benefit payments from the plans as of September 30, 2018 are estimated as follows (in millions):

[0000833444-18-000053:notes:386]
| 2019 | $ | 317 |  |
| 2020 | 304 |  |
| 2021 | 304 |  |
| 2022 | 312 |  |
| 2023 | 316 |  |
| 2024-2028 | 1,628 |  |

[0000833444-18-000053:notes:387]
Postretirement Benefits

[0000833444-18-000053:notes:388]
The Company provides certain health care and life insurance benefits for eligible retirees and their dependents primarily in the U.S. and Canada. Most non-U.S. employees are covered by government sponsored programs, and the cost to the Company is not significant.

[0000833444-18-000053:notes:389]
Eligibility for coverage is based on meeting certain years of service and retirement age qualifications. These benefits may be subject to deductibles, co-payment provisions and other limitations, and the Company has reserved the right to modify these benefits. Effective January 31, 1994, the Company modified certain U.S. salaried plans to place a limit on the Company’s cost of future annual retiree medical benefits at no more than 150% of the 1993 cost.

[0000833444-18-000053:notes:390]
The health care cost trend assumption does not have a significant effect on the amounts reported.

[0000833444-18-000053:notes:391]
In fiscal 2018, total employer contributions to the postretirement plans were $4 million. The Company expects to contribute approximately $15 million in cash to its postretirement plans in fiscal 2019. Projected benefit payments from the plans as of September 30, 2018 are estimated as follows (in millions):

[0000833444-18-000053:notes:392]
| 2019 | $ | 19 |  |
| 2020 | 19 |  |
| 2021 | 19 |  |
| 2022 | 18 |  |
| 2023 | 18 |  |
| 2024-2028 | 74 |  |

[0000833444-18-000053:notes:393]
In December 2003, the U.S. Congress enacted the Medicare Prescription Drug, Improvement and Modernization Act of 2003 ("Act") for employers sponsoring postretirement care plans that provide prescription drug benefits. The Act introduces a prescription drug benefit under Medicare as well as a federal subsidy to sponsors of retiree health care benefit plans providing a benefit that is at least actuarially equivalent to Medicare Part D.1. Under the Act, the Medicare subsidy amount is received directly by the plan sponsor and not the related plan. Further, the plan sponsor is not required to use the subsidy amount to fund postretirement benefits and may use the subsidy for any valid business purpose. Projected subsidy receipts are estimated to be approximately $2 million per year over the next ten years.

[0000833444-18-000053:notes:394]
Defined Contribution Plans

[0000833444-18-000053:notes:395]
The Company sponsors various defined contribution savings plans that allow employees to contribute a portion of their pre-tax and/or after-tax income in accordance with plan specified guidelines. Under specified conditions, the Company will contribute to certain savings plans based on predetermined percentages of compensation earned by the employee and/or will match a percentage of the employee contributions up to certain limits. Defined contribution plan contributions charged to expense for continuing and discontinued operations amounted to $205 million, $190 million and $179 million for the fiscal years ended 2018, 2017 and 2016, respectively.

[0000833444-18-000053:notes:396]
Multiemployer Benefit Plans

[0000833444-18-000053:notes:397]
The Company contributes to multiemployer benefit plans based on obligations arising from collective bargaining agreements related to certain of its hourly employees in the U.S. These plans provide retirement benefits to participants based on their service to contributing employers. The benefits are paid from assets held in trust for that purpose. The trustees typically are responsible for determining the level of benefits to be provided to participants as well as for such matters as the investment of the assets and the administration of the plans.

[0000833444-18-000053:notes:398]
The risks of participating in these multiemployer benefit plans are different from single-employer benefit plans in the following aspects:

[0000833444-18-000053:notes:399]
| • | Assets contributed to the multiemployer benefit plan by one employer may be used to provide benefits to employees of other participating employers. |

[0000833444-18-000053:notes:400]
| • | If a participating employer stops contributing to the multiemployer benefit plan, the unfunded obligations of the plan may be borne by the remaining participating employers. |

[0000833444-18-000053:notes:401]
| • | If the Company stops participating in some of its multiemployer benefit plans, the Company may be required to pay those plans an amount based on its allocable share of the underfunded status of the plan, referred to as a withdrawal liability. |

[0000833444-18-000053:notes:402]
The Company participates in approximately 290 multiemployer benefit plans, primarily related to its Building Technologies & Solutions business in the U.S., none of which are individually significant to the Company. The number of employees covered by the Company’s multiemployer benefit plans has remained consistent over the past three years, and there have been no significant changes that affect the comparability of fiscal 2018, 2017 and 2016 contributions. The Company recognizes expense for the contractually-required contribution for each period. The Company contributed $68 million, $67 million and $46 million to multiemployer benefit plans in fiscal 2018, 2017 and 2016, respectively.

[0000833444-18-000053:notes:403]
Based on the most recent information available, the Company believes that the present value of actuarial accrued liabilities in certain of these multiemployer benefit plans may exceed the value of the assets held in trust to pay benefits. Currently, the Company is not aware of any significant multiemployer benefits plans for which it is probable or reasonably possible that the Company will be obligated to make up any shortfall in funds. Moreover, if the Company were to exit certain markets or otherwise cease making contributions to these funds, the Company could trigger a withdrawal liability. Currently, the Company is not aware of any multiemployer benefit plans for which it is probable or reasonably possible that the Company will have a significant withdrawal liability. Any accrual for a shortfall or withdrawal liability will be recorded when it is probable that a liability exists and it can be reasonably estimated.

[0000833444-18-000053:notes:404]
Plan Assets

[0000833444-18-000053:notes:405]
The Company’s investment policies employ an approach whereby a mix of equities, fixed income and alternative investments are used to maximize the long-term return of plan assets for a prudent level of risk. The investment portfolio primarily contains a diversified blend of equity and fixed income investments. Equity investments are diversified across U.S. and non-U.S. stocks, as well as growth, value and small to large capitalizations. Fixed income investments include corporate and government issues, with short-, mid- and long-term maturities, with a focus on investment grade when purchased and a target duration close to that of the plan liability. Investment and market risks are measured and monitored on an ongoing basis through regular investment portfolio reviews, annual liability measurements and periodic asset/liability studies. The majority of the real estate component of the portfolio is invested in a diversified portfolio of high-quality, operating properties with cash yields greater than the targeted appreciation. Investments in other alternative asset classes, including hedge funds and commodities, diversify the expected investment returns relative to the equity and fixed income investments. As a result of the Company's diversification strategies, there are no significant concentrations of risk within the portfolio of investments.

[0000833444-18-000053:notes:406]
The Company’s actual asset allocations are in line with target allocations. The Company rebalances asset allocations as appropriate, in order to stay within a range of allocation for each asset category.

[0000833444-18-000053:notes:407]
The expected return on plan assets is based on the Company’s expectation of the long-term average rate of return of the capital markets in which the plans invest. The average market returns are adjusted, where appropriate, for active asset management returns. The expected return reflects the investment policy target asset mix and considers the historical returns earned for each asset category.

[0000833444-18-000053:notes:408]
The Company’s plan assets at September 30, 2018 and 2017, by asset category, are as follows (in millions):

[0000833444-18-000053:notes:409]
|  | Fair Value Measurements Using: |
| Asset Category | Total as ofSeptember 30, 2018 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| U.S. Pension |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 23 |  |  | $ | 2 |  |  | $ | 21 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 430 |  |  | 309 |  |  | 121 |  |  | — |  |
| Small-Cap | 282 |  |  | 282 |  |  | — |  |  | — |  |
| International - Developed | 411 |  |  | 365 |  |  | 46 |  |  | — |  |
| International - Emerging | 94 |  |  | 80 |  |  | 14 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 333 |  |  | 307 |  |  | 26 |  |  | — |  |
| Corporate/Other | 1,183 |  |  | 1,119 |  |  | 64 |  |  | — |  |
| Total Investments in the Fair Value Hierarchy | 2,756 |  |  | $ | 2,464 |  |  | $ | 292 |  |  | $ | — |  |
| Investments Measured at Net Asset Value, as Practical Expedient: |  |  |  |  |  |  |  |
| Real Estate Investments Measured at Net Asset Value* | 290 |  |  |  |  |  |  |  |
| Total Plan Assets | $ | 3,046 |  |  |  |  |  |  |  |
| Non-U.S. Pension |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 44 |  |  | $ | 43 |  |  | $ | 1 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 235 |  |  | 24 |  |  | 211 |  |  | — |  |
| International - Developed | 319 |  |  | 59 |  |  | 260 |  |  | — |  |
| International - Emerging | 15 |  |  | 1 |  |  | 14 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 830 |  |  | 80 |  |  | 750 |  |  | — |  |
| Corporate/Other | 545 |  |  | 301 |  |  | 244 |  |  | — |  |
| Hedge Fund | 82 |  |  | — |  |  | 82 |  |  | — |  |
| Real Estate | 26 |  |  | 26 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy | 2,096 |  |  | $ | 534 |  |  | $ | 1,562 |  |  | $ | — |  |
| Investments Measured at Net Asset Value, as Practical Expedient: |  |  |  |  |  |  |  |
| Real Estate Investments Measured at Net Asset Value* | 21 |  |  |  |  |  |  |  |
| Total Plan Assets | $ | 2,117 |  |  |  |  |  |  |  |
| Postretirement |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 13 |  |  | $ | 13 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 26 |  |  | — |  |  | 26 |  |  | — |  |
| Small-Cap | 8 |  |  | — |  |  | 8 |  |  | — |  |
| International - Developed | 20 |  |  | — |  |  | 20 |  |  | — |  |
| International - Emerging | 9 |  |  | — |  |  | 9 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 20 |  |  | — |  |  | 20 |  |  | — |  |
| Corporate/Other | 55 |  |  | — |  |  | 55 |  |  | — |  |
| Commodities | 14 |  |  | — |  |  | 14 |  |  | — |  |
| Real Estate | 9 |  |  | — |  |  | 9 |  |  | — |  |
| Total Plan Assets | $ | 174 |  |  | $ | 13 |  |  | $ | 161 |  |  | $ | — |  |

[0000833444-18-000053:notes:410]
|  | Fair Value Measurements Using: |
| Asset Category | Total as ofSeptember 30, 2017 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| U.S. Pension |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 70 |  |  | $ | 2 |  |  | $ | 68 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 652 |  |  | 375 |  |  | 277 |  |  | — |  |
| Small-Cap | 281 |  |  | 281 |  |  | — |  |  | — |  |
| International - Developed | 649 |  |  | 569 |  |  | 80 |  |  | — |  |
| International - Emerging | 51 |  |  | 24 |  |  | 27 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 270 |  |  | 243 |  |  | 27 |  |  | — |  |
| Corporate/Other | 917 |  |  | 851 |  |  | 66 |  |  | — |  |
| Total Investments in the Fair Value Hierarchy | 2,890 |  |  | $ | 2,345 |  |  | $ | 545 |  |  | $ | — |  |
| Investments Measured at Net Asset Value, as Practical Expedient: |  |  |  |  |  |  |  |  |
| Real Estate Investments Measured at Net Asset Value* | 275 |  |  |  |  |  |  |  |
| Total Plan Assets | $ | 3,165 |  |  |  |  |  |  |  |
| Non-U.S. Pension |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 55 |  |  | $ | 45 |  |  | $ | 10 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 242 |  |  | 18 |  |  | 224 |  |  | — |  |
| Mid-Cap | 2 |  |  | 2 |  |  | — |  |  | — |  |
| International - Developed | 517 |  |  | 58 |  |  | 459 |  |  | — |  |
| International - Emerging | 13 |  |  | — |  |  | 13 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 618 |  |  | 74 |  |  | 544 |  |  | — |  |
| Corporate/Other | 569 |  |  | 292 |  |  | 277 |  |  | — |  |
| Hedge Fund | 112 |  |  | — |  |  | 112 |  |  | — |  |
| Real Estate | 24 |  |  | 24 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy | 2,152 |  |  | $ | 513 |  |  | $ | 1,639 |  |  | $ | — |  |
| Investments Measured at Net Asset Value, as Practical Expedient: |  |  |  |  |  |  |  |
| Real Estate Investments Measured at Net Asset Value* | 29 |  |  |  |  |  |  |  |
| Total Plan Assets | $ | 2,181 |  |  |  |  |  |  |  |
| Postretirement |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 3 |  |  | $ | — |  |  | $ | 3 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 28 |  |  | — |  |  | 28 |  |  | — |  |
| Small-Cap | 9 |  |  | — |  |  | 9 |  |  | — |  |
| International - Developed | 21 |  |  | — |  |  | 21 |  |  | — |  |
| International - Emerging | 11 |  |  | — |  |  | 11 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 21 |  |  | — |  |  | 21 |  |  | — |  |
| Corporate/Other | 59 |  |  | — |  |  | 59 |  |  | — |  |
| Commodities | 15 |  |  | — |  |  | 15 |  |  | — |  |
| Real Estate | 10 |  |  | — |  |  | 10 |  |  | — |  |
| Total Plan Assets | $ | 177 |  |  | $ | — |  |  | $ | 177 |  |  | $ | — |  |

[0000833444-18-000053:notes:411]
* The fair value of certain investments in real estate do not have a readily determinable fair value and requires the fund managers to independently arrive at fair value by calculating net asset value ("NAV") per share. In order to calculate NAV per share, the fund managers value the real estate investments using any one, or a combination of, the following methods: independent third party appraisals, discounted cash flow analysis of net cash flows projected to be generated by the investment and recent sales of comparable investments. Assumptions used to revalue the properties are updated every quarter. Due to the fact that the fund managers calculate NAV per share, the Company utilizes a practical expedient for measuring the fair value of its real-estate investments, as provided for under ASC 820, "Fair Value Measurement." In applying the practical expedient, the Company is not required to further adjust the NAV provided by the fund manager in order to determine the fair value of its investment as the NAV per share is calculated in a manner consistent with the measurement principles of ASC 946, "Financial Services - Investment Companies," and as of the Company's measurement date. The Company believes this is an appropriate methodology to obtain the fair value of these assets. For the component of the real estate portfolio under development, the investments are carried at cost until they are completed and valued by a third party appraiser. In accordance with ASU No. 2015-07, "Disclosures for Investments in Certain Entities That Calculate Net Asset Value per Share (or Its Equivalent)," investments for which fair value is measured using the net asset value per share practical expedient should be disclosed separate from the fair value hierarchy. The fair value amounts presented in this table are intended to permit reconciliation of total plan assets to the amounts presented in the notes to consolidated financial statements.

[0000833444-18-000053:notes:412]
The following is a description of the valuation methodologies used for assets measured at fair value.  Certain assets are held within commingled funds which are valued at the unitized NAV or percentage of the net asset value as determined by the manager of the fund. These values are based on the fair value of the underlying net assets owned by the fund.

[0000833444-18-000053:notes:413]
Cash and Cash Equivalents: The fair value of cash is valued at cost.

[0000833444-18-000053:notes:414]
Equity Securities: The fair value of equity securities is determined by direct quoted market prices. The underlying holdings are direct quoted market prices on regulated financial exchanges.

[0000833444-18-000053:notes:415]
Fixed Income Securities: The fair value of fixed income securities is determined by direct or indirect quoted market prices. If indirect quoted market prices are utilized, the value of assets held in separate accounts is not published, but the investment managers report daily the underlying holdings. The underlying holdings are direct quoted market prices on regulated financial exchanges.

[0000833444-18-000053:notes:416]
Commodities: The fair value of the commodities is determined by quoted market prices of the underlying holdings on regulated financial exchanges.

[0000833444-18-000053:notes:417]
Hedge Funds: The fair value of hedge funds is accounted for by the custodian. The custodian obtains valuations from underlying managers based on market quotes for the most liquid assets and alternative methods for assets that do not have sufficient trading activity to derive prices. The Company and custodian review the methods used by the underlying managers to value the assets. The Company believes this is an appropriate methodology to obtain the fair value of these assets.

[0000833444-18-000053:notes:418]
Real Estate: The fair value of real estate is determined by quoted market prices of the underlying Real Estate Investment Trusts

[0000833444-18-000053:notes:419]
("REITs"), which are securities traded on an open exchange.

[0000833444-18-000053:notes:420]
The methods described above may produce a fair value calculation that may not be indicative of net realizable value or reflective of future fair values. Furthermore, while the Company believes its valuation methods are appropriate and consistent with other market participants, the use of different methodologies or assumptions to determine the fair value of certain financial instruments could result in a different fair value measurement at the reporting date.

[0000833444-18-000053:notes:421]
There were no Level 3 assets as of September 30, 2018 or 2017 or any Level 3 asset activity during fiscal 2018 or 2017.

[0000833444-18-000053:notes:422]
Funded Status

[0000833444-18-000053:notes:423]
The table that follows contains the ABO and reconciliations of the changes in the PBO, the changes in plan assets and the funded status (in millions):

[0000833444-18-000053:notes:424]
|  | Pension Benefits |  | PostretirementBenefits |
|  | U.S. Plans |  | Non-U.S. Plans |  |
| September 30, | 2018 |  | 2017 |  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Accumulated Benefit Obligation | $ | 3,154 |  |  | $ | 3,382 |  |  | $ | 2,444 |  |  | $ | 2,618 |  |  | $ | — |  |  | $ | — |  |
| Change in Projected Benefit Obligation |  |  |  |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of year | 3,419 |  |  | 4,169 |  |  | 2,721 |  |  | 3,522 |  |  | 214 |  |  | 242 |  |
| Service cost | 15 |  |  | 18 |  |  | 23 |  |  | 32 |  |  | 2 |  |  | 2 |  |
| Interest cost | 105 |  |  | 113 |  |  | 57 |  |  | 48 |  |  | 7 |  |  | 6 |  |
| Plan participant contributions | — |  |  | — |  |  | 2 |  |  | 3 |  |  | 6 |  |  | 4 |  |
| Adient spin-off impact | — |  |  | (18 | ) |  | — |  |  | (619 | ) |  | — |  |  | (17 | ) |
| Actuarial (gain) loss | (70 | ) |  | (131 | ) |  | (67 | ) |  | (194 | ) |  | 1 |  |  | (1 | ) |
| Amendments made during the year | — |  |  | — |  |  | — |  |  | — |  |  | (8 | ) |  | — |  |
| Benefits and settlements paid | (278 | ) |  | (732 | ) |  | (130 | ) |  | (116 | ) |  | (24 | ) |  | (25 | ) |
| Estimated subsidy received | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 2 |  |
| Curtailment | — |  |  | — |  |  | (2 | ) |  | (19 | ) |  | — |  |  | — |  |
| Other | — |  |  | — |  |  | (4 | ) |  | (2 | ) |  | (1 | ) |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | (58 | ) |  | 66 |  |  | (2 | ) |  | 1 |  |
| Projected benefit obligation at end of year | $ | 3,191 |  |  | $ | 3,419 |  |  | $ | 2,542 |  |  | $ | 2,721 |  |  | $ | 196 |  |  | $ | 214 |  |
| Change in Plan Assets |  |  |  |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year | $ | 3,165 |  |  | $ | 3,293 |  |  | $ | 2,181 |  |  | $ | 2,536 |  |  | $ | 177 |  |  | $ | 196 |  |
| Actual return on plan assets | 152 |  |  | 334 |  |  | 69 |  |  | 94 |  |  | 6 |  |  | 14 |  |
| Adient spin-off impact | — |  |  | (16 | ) |  | — |  |  | (440 | ) |  | — |  |  | (13 | ) |
| Employer and employee contributions | 7 |  |  | 286 |  |  | 48 |  |  | 59 |  |  | 15 |  |  | 5 |  |
| Benefits paid | (153 | ) |  | (394 | ) |  | (88 | ) |  | (86 | ) |  | (24 | ) |  | (25 | ) |
| Settlement payments | (125 | ) |  | (338 | ) |  | (42 | ) |  | (30 | ) |  | — |  |  | — |  |
| Other | — |  |  | — |  |  | (2 | ) |  | (2 | ) |  | — |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | (49 | ) |  | 50 |  |  | — |  |  | — |  |
| Fair value of plan assets at end of year | $ | 3,046 |  |  | $ | 3,165 |  |  | $ | 2,117 |  |  | $ | 2,181 |  |  | $ | 174 |  |  | $ | 177 |  |
| Funded status | $ | (145 | ) |  | $ | (254 | ) |  | $ | (425 | ) |  | $ | (540 | ) |  | $ | (22 | ) |  | $ | (37 | ) |
| Amounts recognized in the statement of financial position consist of: |
| Prepaid benefit cost | $ | 63 |  |  | $ | 46 |  |  | $ | 26 |  |  | $ | 27 |  |  | $ | 61 |  |  | $ | 64 |  |
| Accrued benefit liability | (208 | ) |  | (300 | ) |  | (451 | ) |  | (567 | ) |  | (83 | ) |  | (101 | ) |
| Net amount recognized | $ | (145 | ) |  | $ | (254 | ) |  | $ | (425 | ) |  | $ | (540 | ) |  | $ | (22 | ) |  | $ | (37 | ) |
| Weighted Average Assumptions (1) |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate (2) | 4.10 | % |  | 3.80 | % |  | 2.45 | % |  | 2.40 | % |  | 3.80 | % |  | 3.70 | % |
| Rate of compensation increase | 3.50 | % |  | 3.20 | % |  | 2.95 | % |  | 2.90 | % |  | NA |  |  | NA |  |

[0000833444-18-000053:notes:425]
| (1) | Plan assets and obligations are determined based on a September 30 measurement date at September 30, 2018 and 2017. |

[0000833444-18-000053:notes:426]
| (2) | The Company considers the expected benefit payments on a plan-by-plan basis when setting assumed discount rates. As a result, the Company uses different discount rates for each plan depending on the plan jurisdiction, the demographics of participants and the expected timing of benefit payments. For the U.S. pension and postretirement plans, the Company uses a discount rate provided by an independent third party calculated based on an appropriate mix of high quality bonds. For the non-U.S. pension and postretirement plans, the Company consistently uses the relevant country specific benchmark indices for determining the various discount rates. The Company has elected to utilize a full yield curve approach in the estimation of service and interest components of net periodic benefit cost (credit) for pension and other postretirement for plans that utilize a yield curve approach. The full yield curve approach applies the specific spot rates along the yield curve used in the determination of the benefit obligation to the relevant projected cash flows. |

[0000833444-18-000053:notes:427]
Accumulated Other Comprehensive Income

[0000833444-18-000053:notes:428]
The amounts in AOCI on the consolidated statements of financial position, exclusive of tax impacts, that have not yet been recognized as components of net periodic benefit cost at September 30, 2018 and 2017 related to pension and postretirement benefits are not significant.

[0000833444-18-000053:notes:429]
The amounts in AOCI expected to be recognized as components of net periodic benefit cost (credit) over the next fiscal related to pension and postretirement benefits are not significant.

[0000833444-18-000053:notes:430]
Net Periodic Benefit Cost

[0000833444-18-000053:notes:431]
The table that follows contains the components of net periodic benefit cost (in millions):

[0000833444-18-000053:notes:432]
|  | Pension Benefits |  | Postretirement Benefits |
|  | U.S. Plans |  | Non-U.S. Plans |  |
| Year ended September 30, | 2018 |  | 2017 |  | 2016 |  | 2018 |  | 2017 |  | 2016 |  | 2018 |  | 2017 |  | 2016 |
| Components of Net Periodic Benefit Cost (Credit): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost | $ | 15 |  |  | $ | 18 |  |  | $ | 16 |  |  | $ | 23 |  |  | $ | 32 |  |  | $ | 30 |  |  | $ | 2 |  |  | $ | 2 |  |  | $ | 2 |  |
| Interest cost | 105 |  |  | 113 |  |  | 104 |  |  | 57 |  |  | 48 |  |  | 44 |  |  | 7 |  |  | 6 |  |  | 6 |  |
| Expected return on plan assets | (229 | ) |  | (229 | ) |  | (191 | ) |  | (114 | ) |  | (92 | ) |  | (61 | ) |  | (10 | ) |  | (10 | ) |  | (10 | ) |
| Net actuarial (gain) loss | 7 |  |  | (220 | ) |  | 268 |  |  | (22 | ) |  | (195 | ) |  | 237 |  |  | 5 |  |  | (5 | ) |  | (2 | ) |
| Amortization of prior service cost (credit) | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | — |  |  | (1 | ) |
| Curtailment gain | — |  |  | — |  |  | — |  |  | (2 | ) |  | (19 | ) |  | — |  |  | — |  |  | — |  |  | — |  |
| Settlement (gain) loss | — |  |  | (16 | ) |  | 11 |  |  | — |  |  | (1 | ) |  | 6 |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (credit) | (102 | ) |  | (334 | ) |  | 208 |  |  | (58 | ) |  | (227 | ) |  | 257 |  |  | 4 |  |  | (7 | ) |  | (5 | ) |
| Net periodic benefit (cost) credit related to discontinued operations | — |  |  | — |  |  | (1 | ) |  | — |  |  | — |  |  | (111 | ) |  | — |  |  | — |  |  | (1 | ) |
| Net periodic benefit cost (credit) included in continuing operations | $ | (102 | ) |  | $ | (334 | ) |  | $ | 207 |  |  | $ | (58 | ) |  | $ | (227 | ) |  | $ | 146 |  |  | $ | 4 |  |  | $ | (7 | ) |  | $ | (6 | ) |
| Expense Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate | 3.80 | % |  | 3.70 | % |  | 4.40 | % |  | 2.40 | % |  | 1.90 | % |  | 3.10 | % |  | 3.70 | % |  | 3.30 | % |  | 3.75 | % |
| Expected return on plan assets | 7.50 | % |  | 7.50 | % |  | 7.50 | % |  | 5.35 | % |  | 4.60 | % |  | 4.50 | % |  | 5.65 | % |  | 5.60 | % |  | 5.45 | % |
| Rate of compensation increase | 3.20 | % |  | 3.20 | % |  | 3.25 | % |  | 2.90 | % |  | 2.65 | % |  | 3.30 | % |  | NA |  |  | NA |  |  | NA |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000833444-18-000053:notes:433]
PROPERTY, PLANT AND EQUIPMENT

[0000833444-18-000053:notes:434]
Property, plant and equipment consisted of the following (in millions):

[0000833444-18-000053:notes:435]
|  | September 30, |
|  | 2018 |  | 2017 |
| Buildings and improvements | $ | 2,537 |  |  | $ | 2,445 |  |
| Subscriber systems | 573 |  |  | 571 |  |
| Machinery and equipment | 6,049 |  |  | 5,572 |  |
| Construction in progress | 1,324 |  |  | 1,252 |  |
| Land | 363 |  |  | 373 |  |
| Total property, plant and equipment | 10,846 |  |  | 10,213 |  |
| Less: accumulated depreciation | (4,675 | ) |  | (4,092 | ) |
| Property, plant and equipment - net | $ | 6,171 |  |  | $ | 6,121 |  |

[0000833444-18-000053:notes:436]
Interest costs capitalized during the fiscal years ended September 30, 2018, 2017 and 2016 were $29 million, $27 million and $19 million, respectively. Accumulated depreciation related to capital leases at September 30, 2018 and 2017 was $16 million and $13 million, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000833444-18-000053:notes:437]
Property, Plant and Equipment

[0000833444-18-000053:notes:438]
Property, plant and equipment are recorded at cost. Depreciation is provided over the estimated useful lives of the respective assets using the straight-line method for financial reporting purposes and accelerated methods for income tax purposes. The estimated useful lives generally range from 3 to 40 years for buildings and improvements, subscriber systems up to 15 years, and from 3 to 15 years for machinery and equipment. The Company capitalizes interest on borrowings during the active construction period of major capital projects. Capitalized interest is added to the cost of the underlying assets and is amortized over the useful lives of the assets.


## us-gaap:ReceivablesPolicyTextBlock

[0000833444-18-000053:notes:439]
Receivables

[0000833444-18-000053:notes:440]
Receivables consist of amounts billed and currently due from customers and unbilled costs and accrued profits related to revenues on long-term contracts that have been recognized for accounting purposes but not yet billed to customers. The Company extends credit to customers in the normal course of business and maintains an allowance for doubtful accounts resulting from the inability or unwillingness of customers to make required payments. The allowance for doubtful accounts is based on historical experience, existing economic conditions and any specific customer collection issues the Company has identified. The Company enters into supply chain financing programs to sell certain accounts receivable without recourse to third-party financial institutions. Sales of accounts receivable are reflected as a reduction of accounts receivable on the consolidated statements of financial position and the proceeds are included in cash flows from operating activities in the consolidated statements of cash flows.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-18-000053:notes:441]
RELATED PARTY TRANSACTIONS

[0000833444-18-000053:notes:442]
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-18-000053:notes:443]
The net sales to and purchases from related parties included in the consolidated statements of income were $958 million and $203 million, respectively, for fiscal 2018; $1,004 million and $195 million, respectively, for fiscal 2017; and $928 million and $184 million, respectively, for fiscal 2016.

[0000833444-18-000053:notes:444]
The following table sets forth the amount of accounts receivable due from and payable to related parties in the consolidated statements of financial position (in millions):

[0000833444-18-000053:notes:445]
|  |  | September 30, |
|  |  | 2018 |  | 2017 |
| Receivable from related parties |  | $ | 103 |  |  | $ | 131 |  |
| Payable to related parties |  | 75 |  |  | 50 |  |

[0000833444-18-000053:notes:446]
The Company has also provided financial support to certain of its VIE's, see Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements for additional information.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-18-000053:notes:447]
SIGNIFICANT RESTRUCTURING AND IMPAIRMENT COSTS

[0000833444-18-000053:notes:448]
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company commits to restructuring plans as necessary.

[0000833444-18-000053:notes:449]
In fiscal 2018, the Company committed to a significant restructuring plan (2018 Plan) and recorded $263 million of restructuring and impairment costs in the consolidated statements of income. This was the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. Of the restructuring and impairment costs recorded, $113 million related to the Global Products segment, $56 million related to the Building Solutions EMEA/LA segment, $50 million related to Corporate, $20 million related to the Building Solutions North America segment, $16 million related to the Building Solutions Asia Pacific segment and $8 million related to the Power Solutions segment. The restructuring actions are expected to be substantially complete in 2020.

[0000833444-18-000053:notes:450]
The following table summarizes the changes in the Company’s 2018 Plan reserve, included within other current liabilities in

[0000833444-18-000053:notes:451]
the consolidated statements of financial position (in millions):

[0000833444-18-000053:notes:452]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | Total |
| Original reserve | $ | 209 |  |  | $ | 42 |  |  | $ | 12 |  |  | $ | 263 |  |
| Utilized—cash | (45 | ) |  | — |  |  | (2 | ) |  | (47 | ) |
| Utilized—noncash | — |  |  | (42 | ) |  | — |  |  | (42 | ) |
| Balance at September 30, 2018 | $ | 164 |  |  | $ | — |  |  | $ | 10 |  |  | $ | 174 |  |

[0000833444-18-000053:notes:453]
In fiscal 2017, the Company committed to a significant restructuring plan (2017 Plan) and recorded $367 million of restructuring and impairment costs in the consolidated statements of income. This is the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. Of the restructuring and impairment costs recorded, $166 million related to Corporate, $74 million related to the Building Solutions EMEA/LA segment, $59 million related to the Building Solutions North America segment, $32 million related to the Global Products segment, $20 million related to the Power Solutions segment and $16 million related to the Building Solutions Asia Pacific segment. The restructuring actions are expected to be substantially complete in fiscal 2019.

[0000833444-18-000053:notes:454]
The following table summarizes the changes in the Company’s 2017 Plan reserve, included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-18-000053:notes:455]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original Reserve | $ | 276 |  |  | $ | 77 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 367 |  |
| Utilized—cash | (75 | ) |  | — |  |  | — |  |  | — |  |  | (75 | ) |
| Utilized—noncash | — |  |  | (77 | ) |  | (1 | ) |  | — |  |  | (78 | ) |
| Adjustment to restructuring reserves | 25 |  |  | — |  |  | — |  |  | — |  |  | 25 |  |
| Balance at September 30, 2017 | $ | 226 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |  | $ | 239 |  |
| Utilized—cash | (152 | ) |  | — |  |  | (6 | ) |  | — |  |  | (158 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Balance at September 30, 2018 | $ | 74 |  |  | $ | — |  |  | $ | 7 |  |  | $ | (1 | ) |  | $ | 80 |  |

[0000833444-18-000053:notes:456]
In fiscal 2016, the Company committed to a significant restructuring plan (2016 Plan) and recorded $288 million of restructuring and impairment costs in the consolidated statements of income. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments and change-in-control payments. Of the restructuring and impairment costs recorded, $161 million related to Corporate, $66 million related to the Power Solutions segment, $44 million related to the Global Products segment and $17 million related to the Building Solutions EMEA/LA segment. The restructuring actions are expected to be substantially complete in fiscal 2019. Included in the reserve is $56 million of committed restructuring actions taken by Tyco for liabilities assumed as part of the Tyco acquisition.

[0000833444-18-000053:notes:457]
Additionally, the Company recorded $332 million of restructuring and impairment costs within discontinued operations related to Adient in fiscal 2016.

[0000833444-18-000053:notes:458]
The following table summarizes the changes in the Company’s 2016 Plan reserve, included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-18-000053:notes:459]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original Reserve | $ | 368 |  |  | $ | 190 |  |  | $ | 62 |  |  | $ | — |  |  | $ | 620 |  |
| Acquired Tyco restructuring reserves | 78 |  |  | — |  |  | — |  |  | — |  |  | 78 |  |
| Utilized—cash | (32 | ) |  | — |  |  | — |  |  | — |  |  | (32 | ) |
| Utilized—noncash | — |  |  | (190 | ) |  | (32 | ) |  | 1 |  |  | (221 | ) |
| Balance at September 30, 2016 | $ | 414 |  |  | $ | — |  |  | $ | 30 |  |  | $ | 1 |  |  | $ | 445 |  |
| Adient spin-off impact | (194 | ) |  | — |  |  | (22 | ) |  | — |  |  | (216 | ) |
| Utilized—cash | (86 | ) |  | — |  |  | (2 | ) |  | — |  |  | (88 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Adjustment to restructuring reserves | (25 | ) |  | — |  |  | — |  |  | — |  |  | (25 | ) |
| Transfer to liabilities held for sale | (3 | ) |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Adjustment to acquired Tyco restructuring reserves | (22 | ) |  | — |  |  | — |  |  | — |  |  | (22 | ) |
| Balance at September 30, 2017 | $ | 84 |  |  | $ | — |  |  | $ | 6 |  |  | $ | 2 |  |  | $ | 92 |  |
| Utilized—cash | (17 | ) |  | — |  |  | (2 | ) |  | — |  |  | (19 | ) |
| Balance at September 30, 2018 | $ | 67 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 2 |  |  | $ | 73 |  |

[0000833444-18-000053:notes:460]
The Company's fiscal 2018, 2017 and 2016 restructuring plans included workforce reductions of approximately 11,500 employees (9,100 for the Building Technologies & Solutions business, 2,200 for Corporate and 200 for Power Solutions). Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of September 30, 2018, approximately 4,900 of the employees have been separated from the Company pursuant to the restructuring plans. In addition, the restructuring plans included twelve plant closures in the Building Technologies & Solutions business. As of September 30, 2018, seven of the twelve plants have been closed.

[0000833444-18-000053:notes:461]
Company management closely monitors its overall cost structure and continually analyzes each of its businesses for opportunities to consolidate current operations, improve operating efficiencies and locate facilities in close proximity to customers. This ongoing analysis includes a review of its manufacturing, engineering and purchasing operations, as well as the overall global footprint for all its businesses.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000833444-18-000053:notes:462]
Revenue Recognition

[0000833444-18-000053:notes:463]
The Building Technologies & Solutions business recognizes revenue from certain long-term contracts over the contractual period under the percentage-of-completion ("POC") method of accounting. This method of accounting recognizes sales and gross profit as work is performed based on the relationship between actual costs incurred and total estimated costs at completion. Recognized revenues that will not be billed under the terms of the contract until a later date are recorded primarily in accounts receivable. Likewise, contracts where billings to date have exceeded recognized revenues are recorded primarily in deferred revenue. Costs and earnings in excess of billings related to these contracts were $1,054 million and $908 million at September 30, 2018 and 2017, respectively. Billings in excess of costs and earnings related to these contracts were $535 million and $451 million at September 30, 2018 and 2017, respectively. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. Sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated contract losses are recorded when identified. Claims against customers are recognized as revenue upon settlement. The use of the POC method of accounting involves considerable use of estimates in determining revenues, costs and profits and in assigning the amounts to accounting periods. The periodic reviews have not resulted in adjustments that were significant to the Company’s results of operations. The Company continually evaluates all of the assumptions, risks and uncertainties inherent with the application of the POC method of accounting.

[0000833444-18-000053:notes:464]
The Building Technologies & Solutions business enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized on a straight-line basis over the respective contract term.

[0000833444-18-000053:notes:465]
The Building Technologies & Solutions business also sells certain HVAC and refrigeration products and services in bundled arrangements, where multiple products and/or services are involved. Significant deliverables within these arrangements include equipment, commissioning, service labor and extended warranties. Approximately four to twelve months separate the timing of the first deliverable until the last piece of equipment is delivered, and there may be extended warranty arrangements with duration of one to five years commencing upon the end of the standard warranty period. In addition, the Building Technologies & Solutions business sells security monitoring systems that may have multiple elements, including equipment, installation, monitoring services and maintenance agreements. Revenues associated with sale of equipment and related installations are recognized once delivery, installation and customer acceptance is completed, while the revenue for monitoring and maintenance services are recognized as services are rendered. In accordance with Accounting Standards Update ("ASU") No. 2009-13, "Revenue Recognition (Topic 605): Multiple-Deliverable Revenue Arrangements - A Consensus of the FASB Emerging Issues Task Force," the Company divides bundled arrangements into separate deliverables and revenue is allocated to each deliverable based on the relative selling price method. In order to estimate relative selling price, market data and transfer price studies are utilized. Revenue recognized for security monitoring equipment and installation is limited to the lesser of their allocated amounts under the estimated selling price hierarchy or the non-contingent up-front consideration received at the time of installation, since collection of future amounts under the arrangement with the customer is contingent upon the delivery of monitoring and maintenance services. For transactions in which the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized on a straight-line basis over the contract term. Non-refundable fees received in connection with the initiation of a monitoring contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the customer relationship.

[0000833444-18-000053:notes:466]
In all other cases, the Company recognizes revenue at the time title passes to the customer or as services are performed.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000833444-18-000053:notes:467]
The following schedules present changes in AOCI attributable to Johnson Controls (in millions, net of tax):

[0000833444-18-000053:notes:468]
|  | Year Ended September 30, 2018 |  | Year Ended September 30, 2017 |  | Year Ended September 30, 2016 |
| Foreign currency translation adjustments |  |  |  |  |  |
| Balance at beginning of period | $ | (481 | ) |  | $ | (1,152 | ) |  | $ | (1,047 | ) |
| Aggregate adjustment for the period (net of tax effect of $(3), $1 and $(43)) * | (458 | ) |  | 108 |  |  | (105 | ) |
| Adient spin-off impact (net of tax effect of $0) | — |  |  | 563 |  |  | — |  |
| Balance at end of period | (939 | ) |  | (481 | ) |  | (1,152 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |  |  |
| Balance at beginning of period | 6 |  |  | 4 |  |  | (7 | ) |
| Current period changes in fair value (net of tax effect of $(4), $4 and $(5)) | (8 | ) |  | 9 |  |  | (10 | ) |
| Reclassification to income (net of tax effect of $(5), $(10) and $11) ** | (11 | ) |  | (23 | ) |  | 21 |  |
| Adient spin-off impact (net of tax effect of $0, $6, and $0) | — |  |  | 16 |  |  | — |  |
| Balance at end of period | (13 | ) |  | 6 |  |  | 4 |  |
| Realize and unrealized gains (losses) on marketable securities |  |  |  |  |  |
| Balance at beginning of period | 4 |  |  | (1 | ) |  | — |  |
| Current period changes in fair value (net of tax effect of $1, $1 and $0) | 5 |  |  | 5 |  |  | (1 | ) |
| Reclassification to income (net of tax effect of $(1), $0 and $0) *** | (1 | ) |  | — |  |  | — |  |
| Balance at end of period | 8 |  |  | 4 |  |  | (1 | ) |
| Pension and postretirement plans |  |  |  |  |  |
| Balance at beginning of period | (2 | ) |  | (4 | ) |  | (3 | ) |
| Reclassification to income (net of tax effect of $0) **** | — |  |  | — |  |  | (1 | ) |
| Adient spin-off impact (net of tax effect of $0) | — |  |  | 2 |  |  | — |  |
| Balance at end of period | (2 | ) |  | (2 | ) |  | (4 | ) |
| Accumulated other comprehensive loss, end of period | $ | (946 | ) |  | $ | (473 | ) |  | $ | (1,153 | ) |

[0000833444-18-000053:notes:469]
*      During fiscal 2018, $12 million of cumulative CTA was recognized as part of the divestiture-related gain recognized as part of the divestiture of Scott Safety.

[0000833444-18-000053:notes:470]
**   Refer to Note 10, "Derivative Instruments and Hedging Activities," of the notes to consolidated financial statements for disclosure of the line items on the consolidated statements of income affected by reclassifications from AOCI into income related to derivatives.

[0000833444-18-000053:notes:471]
***  During fiscal 2018, the Company sold certain marketable common stock for approximately $3 million. As a result, the Company recorded $2 million of realized gains within selling, general and administrative expenses.

[0000833444-18-000053:notes:472]
****  Refer to Note 15, "Retirement Plans," of the notes to consolidated financial statements for disclosure of the components of the Company's net periodic benefit costs associated with its defined benefit pension and postretirement plans. For the year ended September 30, 2016 the amounts reclassified from AOCI into income for pension and postretirement plans were primarily recorded in selling, general and administrative expenses on the consolidated statements of income.


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000833444-18-000053:notes:473]
Financial information relating to the Company’s operations by geographic area is as follows (in millions):

[0000833444-18-000053:notes:474]
|  | Year Ended September 30, |
|  | 2018 |  | 2017 |  | 2016 |
| Net Sales |  |  |  |  |  |
| United States | $ | 14,625 |  |  | $ | 14,495 |  |  | $ | 9,633 |  |
| China | 2,166 |  |  | 2,046 |  |  | 1,620 |  |
| Japan | 1,903 |  |  | 1,816 |  |  | 1,805 |  |
| Germany | 1,961 |  |  | 1,779 |  |  | 1,430 |  |
| United Kingdom | 1,139 |  |  | 928 |  |  | 291 |  |
| Mexico | 909 |  |  | 840 |  |  | 639 |  |
| Other foreign | 5,692 |  |  | 5,408 |  |  | 3,602 |  |
| Other European countries | 3,005 |  |  | 2,860 |  |  | 1,817 |  |
| Total | $ | 31,400 |  |  | $ | 30,172 |  |  | $ | 20,837 |  |
| Long-Lived Assets (Year-end) |  |  |  |  |  |
| United States | $ | 3,216 |  |  | $ | 3,155 |  |  | $ | 2,880 |  |
| China | 766 |  |  | 535 |  |  | 484 |  |
| Japan | 209 |  |  | 180 |  |  | 188 |  |
| Germany | 275 |  |  | 290 |  |  | 287 |  |
| United Kingdom | 73 |  |  | 109 |  |  | 103 |  |
| Mexico | 531 |  |  | 489 |  |  | 457 |  |
| Other foreign | 659 |  |  | 821 |  |  | 785 |  |
| Other European countries | 442 |  |  | 542 |  |  | 448 |  |
| Total | $ | 6,171 |  |  | $ | 6,121 |  |  | $ | 5,632 |  |

[0000833444-18-000053:notes:475]
Net sales attributed to geographic locations are based on the location of the assets producing the sales. Long-lived assets by geographic location consist of net property, plant and equipment.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000833444-18-000053:notes:476]
Financial information relating to the Company’s reportable segments is as follows (in millions):

[0000833444-18-000053:notes:477]
|  | Year Ended September 30, |
|  | 2018 |  | 2017 |  | 2016 |
| Net Sales |  |  |  |  |  |
| Building Technologies & Solutions |  |  |  |  |  |
| Building Solutions North America | $ | 8,679 |  |  | $ | 8,341 |  |  | $ | 4,687 |  |
| Building Solutions EMEA/LA | 3,696 |  |  | 3,595 |  |  | 1,613 |  |
| Building Solutions Asia Pacific | 2,553 |  |  | 2,444 |  |  | 1,736 |  |
| Global Products | 8,472 |  |  | 8,455 |  |  | 6,148 |  |
|  | 23,400 |  |  | 22,835 |  |  | 14,184 |  |
| Power Solutions | 8,000 |  |  | 7,337 |  |  | 6,653 |  |
| Total net sales | $ | 31,400 |  |  | $ | 30,172 |  |  | $ | 20,837 |  |

[0000833444-18-000053:notes:478]
|  | Year Ended September 30, |
|  | 2018 |  | 2017 |  | 2016 |
| Segment EBITA |  |  |  |  |  |
| Building Technologies & Solutions |  |  |  |  |  |
| Building Solutions North America (1) | $ | 1,109 |  |  | $ | 1,039 |  |  | $ | 494 |  |
| Building Solutions EMEA/LA (2) | 344 |  |  | 290 |  |  | 74 |  |
| Building Solutions Asia Pacific (3) | 347 |  |  | 323 |  |  | 222 |  |
| Global Products (4) | 1,338 |  |  | 1,179 |  |  | 637 |  |
|  | 3,138 |  |  | 2,831 |  |  | 1,427 |  |
| Power Solutions (5) | 1,417 |  |  | 1,427 |  |  | 1,327 |  |
| Total segment EBITA | $ | 4,555 |  |  | $ | 4,258 |  |  | $ | 2,754 |  |
| Amortization of intangible assets | (384 | ) |  | (489 | ) |  | (116 | ) |
| Corporate expenses (6) | (576 | ) |  | (768 | ) |  | (607 | ) |
| Net financing charges | (441 | ) |  | (496 | ) |  | (289 | ) |
| Restructuring and impairment costs | (263 | ) |  | (367 | ) |  | (288 | ) |
| Net mark-to-market adjustments on pension and postretirement plans | 10 |  |  | 420 |  |  | (393 | ) |
| Income from continuing operations before income taxes | $ | 2,901 |  |  | $ | 2,558 |  |  | $ | 1,061 |  |

[0000833444-18-000053:notes:479]
|  | September 30, |
|  | 2018 |  | 2017 |  | 2016 |
| Assets |  |  |  |  |  |
| Building Technologies & Solutions (7) |  |  |  |  |  |
| Building Solutions North America (8) | $ | 15,384 |  |  | $ | 15,228 |  |  | $ | 15,554 |  |
| Building Solutions EMEA/LA (9) | 4,997 |  |  | 4,885 |  |  | 4,649 |  |
| Building Solutions Asia Pacific (10) | 2,743 |  |  | 2,575 |  |  | 2,521 |  |
| Global Products (11) | 14,261 |  |  | 14,018 |  |  | 15,782 |  |
|  | 37,385 |  |  | 36,706 |  |  | 38,506 |  |
| Power Solutions (12) | 7,996 |  |  | 7,894 |  |  | 6,793 |  |
| Assets held for sale | — |  |  | 2,109 |  |  | 13,186 |  |
| Unallocated | 3,416 |  |  | 5,175 |  |  | 4,694 |  |
| Total | $ | 48,797 |  |  | $ | 51,884 |  |  | $ | 63,179 |  |

[0000833444-18-000053:notes:480]
|  | Year Ended September 30, |
|  | 2018 |  | 2017 |  | 2016 |
| Depreciation/Amortization |  |  |  |  |  |
| Building Technologies & Solutions |  |  |  |  |  |
| Building Solutions North America | $ | 236 |  |  | $ | 272 |  |  | $ | 49 |  |
| Building Solutions EMEA/LA | 110 |  |  | 140 |  |  | 14 |  |
| Building Solutions Asia Pacific | 28 |  |  | 37 |  |  | 11 |  |
| Global Products | 390 |  |  | 410 |  |  | 230 |  |
|  | 764 |  |  | 859 |  |  | 304 |  |
| Power Solutions | 256 |  |  | 236 |  |  | 238 |  |
| Corporate | 65 |  |  | 64 |  |  | 80 |  |
| Discontinued Operations | — |  |  | 29 |  |  | 331 |  |
| Total | $ | 1,085 |  |  | $ | 1,188 |  |  | $ | 953 |  |

[0000833444-18-000053:notes:481]
|  | Year Ended September 30, |
|  | 2018 |  | 2017 |  | 2016 |
| Capital Expenditures |  |  |  |  |  |
| Building Technologies & Solutions |  |  |  |  |  |
| Building Solutions North America | $ | 114 |  |  | $ | 107 |  |  | $ | 16 |  |
| Building Solutions EMEA/LA | 73 |  |  | 98 |  |  | 19 |  |
| Building Solutions Asia Pacific | 26 |  |  | 27 |  |  | 7 |  |
| Global Products | 307 |  |  | 421 |  |  | 304 |  |
|  | 520 |  |  | 653 |  |  | 346 |  |
| Automotive Experience |  |  |  |  |  |
| Seating | — |  |  | 62 |  |  | 392 |  |
| Interiors | — |  |  | 1 |  |  | 3 |  |
|  | — |  |  | 63 |  |  | 395 |  |
| Power Solutions | 372 |  |  | 481 |  |  | 357 |  |
| Corporate | 138 |  |  | 146 |  |  | 151 |  |
| Total | $ | 1,030 |  |  | $ | 1,343 |  |  | $ | 1,249 |  |

[0000833444-18-000053:notes:482]
| (1) | Building Solutions North America segment EBITA for the year ended September 30, 2018 and 2017 excludes $20 million and $59 million, respectively, of restructuring and impairment costs. |

[0000833444-18-000053:notes:483]
| (2) | Building Solutions EMEA/LA segment EBITA for the years ended September 30, 2018, 2017 and 2016 excludes $56 million, $74 million and $17 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2018, 2017 and 2016, EMEA/LA segment EBITA includes $1 million, $5 million and $11 million, respectively, of equity income. |

[0000833444-18-000053:notes:484]
| (3) | Building Solutions Asia Pacific segment EBITA for the year ended September 30, 2018 and 2017 excludes $16 million and $16 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2018, 2017 and 2016, Asia Pacific segment EBITA includes $1 million, $1 million and $1 million, respectively, of equity income. |

[0000833444-18-000053:notes:485]
| (4) | Global Products segment EBITA for the years ended September 30, 2018, 2017 and 2016 excludes $113 million, $32 million and $44 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2018, 2017 and 2016, Global Products segment EBITA includes $175 million, $151 million and $114 million, respectively, of equity income. |

[0000833444-18-000053:notes:486]
| (5) | Power Solutions segment EBITA for the years ended September 30, 2018, 2017 and 2016 excludes $8 million, $20 million and $66 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2018, 2017 and 2016, Power Solutions segment EBITA includes $58 million, $83 million and $48 million, respectively, of equity income. |

[0000833444-18-000053:notes:487]
| (6) | Corporate expenses for the years ended September 30, 2018, 2017 and 2016 excludes $50 million, $166 million and $161 million, respectively, of restructuring and impairment costs. |

[0000833444-18-000053:notes:488]
| (7) | Prior year amounts exclude assets held for sale. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's disposal groups classified as held for sale. |

[0000833444-18-000053:notes:489]
| (8) | Buildings Solutions North America assets as of September 2018, 2017 and 2016, include $8 million, $8 million and $7 million, respectively, of investments in partially-owned affiliates. |

[0000833444-18-000053:notes:490]
| (9) | Building Solutions EMEA/LA assets as of September 30, 2018, 2017 and 2016, include $99 million, $107 million and $103 million, respectively, of investments in partially-owned affiliates. |

[0000833444-18-000053:notes:491]
| (10) | Building Solutions Asia Pacific assets as of September 30, 2018 include $1 million of investments in partially-owned affiliates. |

[0000833444-18-000053:notes:492]
| (11) | Global Products assets as of September 30, 2018, 2017 and 2016, include $740 million, $629 million and $513 million, respectively, of investments in partially-owned affiliates. |

[0000833444-18-000053:notes:493]
| (12) | Power Solutions assets as of September 30, 2018, 2017 and 2016, include $453 million, $447 million and $367 million, respectively, of investments in partially-owned affiliates. |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000833444-18-000053:notes:494]
JOHNSON CONTROLS INTERNATIONAL PLC AND SUBSIDIARIES

[0000833444-18-000053:notes:495]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0000833444-18-000053:notes:496]
(In millions)

[0000833444-18-000053:notes:497]
| Year Ended September 30, | 2018 |  | 2017 |  | 2016 |
| Accounts Receivable - Allowance for Doubtful Accounts |  |  |  |  |  |
| Balance at beginning of period | $ | 182 |  |  | $ | 173 |  |  | $ | 70 |  |
| Provision charged to costs and expenses | 40 |  |  | 39 |  |  | 45 |  |
| Reserve adjustments | (24 | ) |  | (9 | ) |  | (8 | ) |
| Accounts charged off | (21 | ) |  | (41 | ) |  | (25 | ) |
| Acquisition of businesses | — |  |  | 18 |  |  | 91 |  |
| Currency translation | — |  |  | 2 |  |  | — |  |
| Balance at end of period | $ | 177 |  |  | $ | 182 |  |  | $ | 173 |  |
| Deferred Tax Assets - Valuation Allowance |  |  |  |  |  |
| Balance at beginning of period | $ | 3,838 |  |  | $ | 3,400 |  |  | $ | 1,151 |  |
| Allowance provision for new operating and other loss carryforwards | 1,665 |  |  | 542 |  |  | 121 |  |
| Allowance provision benefits | (308 | ) |  | (157 | ) |  | (331 | ) |
| Acquisition of businesses | — |  |  | 53 |  |  | 2,459 |  |
| Balance at end of period | $ | 5,195 |  |  | $ | 3,838 |  |  | $ | 3,400 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-18-000053:notes:498]
SEGMENT INFORMATION

[0000833444-18-000053:notes:499]
ASC 280, "Segment Reporting," establishes the standards for reporting information about segments in financial statements. In applying the criteria set forth in ASC 280, the Company has determined that it has five reportable segments for financial reporting purposes. The Company’s five reportable segments are presented in the context of its two primary businesses - Building Technologies & Solutions and Power Solutions.

[0000833444-18-000053:notes:500]
Building Technologies & Solutions

[0000833444-18-000053:notes:501]
| • | Building Solutions North America designs, sells, installs, and services HVAC and controls systems, integrated electronic security systems (including monitoring), and integrated fire detection and suppression systems for commercial, industrial, retail, small business, institutional and governmental customers in North America. Building Solutions North America also provides energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and control systems, to non-residential building and industrial applications in the North American marketplace. |

[0000833444-18-000053:notes:502]
| • | Building Solutions EMEA/LA designs, sells, installs, and services HVAC, controls, refrigeration, integrated electronic security, integrated fire detection and suppression systems, and provides technical services to markets in Europe, the Middle East, Africa and Latin America. |

[0000833444-18-000053:notes:503]
| • | Building Solutions Asia Pacific designs, sells, installs, and services HVAC, controls, refrigeration, integrated electronic security, integrated fire detection and suppression systems, and provides technical services to the Asia Pacific marketplace. |

[0000833444-18-000053:notes:504]
| • | Global Products designs and produces heating and air conditioning for residential and commercial applications, and markets products and refrigeration systems to replacement and new construction market customers globally. The Global Products business also designs, manufactures and sells fire protection and security products, including intrusion security, anti-theft devices, and access control and video management systems, for commercial, industrial, retail, residential, small business, institutional and governmental customers worldwide. Global Products also includes the Johnson Controls-Hitachi joint venture, which was formed October 1, 2015, and included the Scott Safety business, prior to its sale on October 4, 2017. |

[0000833444-18-000053:notes:505]
Power Solutions

[0000833444-18-000053:notes:506]
Power Solutions services both automotive original equipment manufacturers and the battery aftermarket by providing advanced battery technology, coupled with systems engineering, marketing and service expertise.

[0000833444-18-000053:notes:507]
Management evaluates the performance of its business segments primarily on segment earnings before interest, taxes and amortization ("EBITA"), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, significant restructuring and impairment costs, and the net mark-to-market adjustments related to pension and postretirement plans.

[0000833444-18-000053:notes:508]
In fiscal years 2018, 2017 and 2016, no customer exceeded 10% of consolidated net sales.

[0000833444-18-000053:notes:509]
Geographic Segments


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000833444-18-000053:notes:510]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0000833444-18-000053:notes:511]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company," "Johnson Controls" or "JCI plc").

[0000833444-18-000053:notes:512]
Nature of Operations

[0000833444-18-000053:notes:513]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global diversified technology and multi industrial leader serving a wide range of customers in more than 150 countries. The Company creates intelligent buildings, efficient energy solutions, integrated infrastructure and next generation transportation systems that work seamlessly together to deliver on the promise of smart cities and communities. The Company is committed to helping our customers win and creating greater value for all of its stakeholders through strategic focus on our buildings and energy growth platforms.

[0000833444-18-000053:notes:514]
In the fourth quarter of fiscal 2016, Johnson Controls, Inc. ("JCI Inc.") and Tyco International plc ("Tyco") completed their combination with JCI Inc. merging with a wholly-owned, indirect subsidiary of Tyco (the "Merger"). Following the Merger, Tyco changed its name to “Johnson Controls International plc” and JCI Inc. is a wholly-owned subsidiary of Johnson Controls International plc. The Merger was accounted for as a reverse acquisition using the acquisition method of accounting in accordance with Accounting Standards Codification ("ASC") 805, "Business Combinations." JCI Inc. was the accounting acquirer for financial reporting purposes. Accordingly, the historical consolidated financial statements of JCI Inc. for periods prior to this transaction are considered to be the historic financial statements of the Company.

[0000833444-18-000053:notes:515]
On October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience Business from Johnson Controls to Adient plc and the issuance of ordinary shares of Adient directly to holders of Johnson Controls ordinary shares on a pro rata basis. Prior to the open of business on October 31, 2016, each of the Company's shareholders received one ordinary share of Adient plc for every ten ordinary shares of Johnson Controls held as of the close of business on October 19, 2016, the record date for the distribution. Company shareholders received cash in lieu of fractional shares of Adient, if any. Following the separation and distribution, Adient plc is now an independent public company trading on the New York Stock Exchange ("NYSE") under the symbol "ADNT." The Company did not retain any equity interest in Adient plc. Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-18-000053:notes:516]
The Building Technologies & Solutions ("Buildings") business is a global market leader in engineering, developing, manufacturing and installing building products and systems around the world, including heating, ventilating, air-conditioning ("HVAC") equipment, HVAC controls, energy-management systems, security systems, fire detection systems and fire suppression solutions. The Buildings business further serves customers by providing technical services (in the HVAC, security and fire-protection space), energy-management consulting and data-driven solutions via its data-enabled business. Finally, the Company has a strong presence in the North American residential air conditioning and heating systems market and is a global market leader in industrial refrigeration products.

[0000833444-18-000053:notes:517]
The Power Solutions business is a leading global supplier of lead-acid automotive batteries for virtually every type of passenger car, light truck and utility vehicle. The Company serves both automotive original equipment manufacturers and the general vehicle battery aftermarket. The Company also supplies advanced battery technologies to power start-stop, hybrid and electric vehicles.

[0000833444-18-000053:notes:518]
Use of Estimates

[0000833444-18-000053:notes:519]
The preparation of consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0000833444-18-000053:notes:520]
Fair Value of Financial Instruments

[0000833444-18-000053:notes:521]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. See Note 10, "Derivative Instruments and Hedging Activities," and Note 11, "Fair Value Measurements," of the notes to consolidated financial statements for fair value of financial instruments, including derivative instruments, hedging activities and long-term debt.

[0000833444-18-000053:notes:522]
Research and Development Costs

[0000833444-18-000053:notes:523]
Expenditures for research activities relating to product development and improvement are charged against income as incurred and included within selling, general and administrative expenses for continuing operations in the consolidated statements of income. Such expenditures for the years ended September 30, 2018, 2017 and 2016 were $380 million, $360 million and $158 million, respectively.

[0000833444-18-000053:notes:524]
Investments

[0000833444-18-000053:notes:525]
The Company invests in debt and equity securities which are classified as available for sale and are marked to market at the end of each accounting period. Unrealized gains and losses on these securities, other than the deferred compensation plan assets, are recognized in AOCI within the consolidated statement of shareholders' equity unless an unrealized loss is deemed to be other than temporary, in which case such loss is charged to earnings. The deferred compensation plan assets are marked to market at the end of each accounting period and all unrealized gains and losses are recorded in the consolidated statements of income.

[0000833444-18-000053:notes:526]
Pension and Postretirement Benefits

[0000833444-18-000053:notes:527]
The Company utilizes a mark-to-market approach for recognizing pension and postretirement benefit expenses, including measuring the market related value of plan assets at fair value and recognizing actuarial gains and losses in the fourth quarter of each fiscal year or at the date of a remeasurement event. Refer to Note 15, "Retirement Plans," of the notes to consolidated financial statements for disclosure of the Company's pension and postretirement benefit plans.

[0000833444-18-000053:notes:528]
Retrospective Changes

[0000833444-18-000053:notes:529]
Certain amounts as of September 30, 2017 and 2016 have been revised to conform to the current year's presentation.

[0000833444-18-000053:notes:530]
In March 2016, the FASB issued Accounting Standards Update ("ASU") No. 2016-09, "Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting." ASU No. 2016-09 impacts certain aspects of the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the statements of cash flows. During the quarter ended December 31, 2017, the Company adopted ASU No. 2016-09. As a result, the Company recognized deferred tax assets of $179 million in the consolidated statements of financial position related to certain operating loss carryforwards resulting from the exercise of employee stock options and vested restricted stock on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of October 1, 2017. Additionally, employee withholding taxes paid to taxing authorities for equity-based compensation transactions, previously classified as cash flows from operating activities, were reclassified to financing activities in the consolidated statements of cash flows for the fiscal years ended September 30, 2017 and 2016 for comparative purposes. The remaining provisions of ASU No. 2016-09 did not have a material impact on the Company's consolidated financial statements.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-18-000053:notes:531]
EQUITY AND NONCONTROLLING INTERESTS

[0000833444-18-000053:notes:532]
Share Capital

[0000833444-18-000053:notes:533]
In September 2016, as a result of the Tyco Merger and further discussed within Note 2, "Merger Transaction," of the notes to  consolidated financial statements, each outstanding share of common stock, par value $1.00 per share, of JCI Inc. common stock (other than shares held by JCI Inc., Tyco and certain of their subsidiaries) was converted into the right to receive either cash or share consideration.

[0000833444-18-000053:notes:534]
Dividends

[0000833444-18-000053:notes:535]
The authority to declare and pay dividends is vested in the Board of Directors. The timing, declaration and payment of future dividends to holders of the Company's ordinary shares will be determined by the Company's Board of Directors and will depend upon many factors, including the Company's financial condition and results of operations, the capital requirements of the Company's businesses, industry practice and any other relevant factors.

[0000833444-18-000053:notes:536]
Under Irish law, dividends may only be paid (and share repurchases and redemptions must generally be funded) out of "distributable reserves." The creation of distributable reserves was accomplished by way of a capital reduction, which the Irish High Court approved on December 18, 2014 and as acquired in conjunction with the Tyco Merger.

[0000833444-18-000053:notes:537]
Share Repurchase Program

[0000833444-18-000053:notes:538]
Following the Tyco Merger, the Company adopted, subject to the ongoing existence of sufficient distributable reserves, the existing Tyco International plc $1 billion share repurchase program in September 2016. In December 2017, the Company's Board of Directors approved a $1 billion increase to its share repurchase authorization. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. During fiscal year 2018, the Company repurchased approximately $300 million of its shares. As of September 30, 2018, approximately $1.0 billion remains available under the share repurchase program. In November 2018, the Company's Board of Directors approved a $1 billion  increase to its share repurchase authorization. During fiscal year 2017, the Company repurchased approximately $651 million of its shares. There were no shares repurchased between the closing of the Merger and September 30, 2016. Prior to the Merger, during fiscal year 2016, the Company repurchased approximately $501 million of its shares under JCI Inc.'s $3.65 billion share repurchase program.

[0000833444-18-000053:notes:539]
Other comprehensive income includes activity relating to discontinued operations. The following schedules present changes in consolidated equity attributable to Johnson Controls and noncontrolling interests (in millions, net of tax):

[0000833444-18-000053:notes:540]
As previously disclosed, during the quarter ended December 31, 2017, the Company adopted ASU No. 2016-09. As a result, the Company recognized deferred tax assets of $179 million related to certain operating loss carryforwards resulting from the exercise of employee stock options and restricted stock vestings on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of October 1, 2017.

[0000833444-18-000053:notes:541]
On October 31, 2016, the Company completed the Adient spin-off. As a result of the spin-off, the Company divested net assets of approximately $4.0 billion.

[0000833444-18-000053:notes:542]
The equity attributable to Johnson Controls International plc increased by $15.8 billion as a result of the Tyco Merger in fiscal 2016. The increase is primarily due to an increase to equity of $19.7 billion resulting from the total fair value of consideration transferred, partially offset by a decrease of $3.9 billion resulting from cash contributed by Tyco used to purchase shares of Johnson Controls, Inc.

[0000833444-18-000053:notes:543]
On October 1, 2015, the Company formed a joint venture with Hitachi. In connection with the acquisition, the Company recorded equity attributable to noncontrolling interests of $679 million. Also, in connection with the Tyco Merger, the Company recorded equity attributable to noncontrolling interests of $34 million.

[0000833444-18-000053:notes:544]
The Company consolidates certain subsidiaries in which the noncontrolling interest party has within their control the right to require the Company to redeem all or a portion of its interest in the subsidiary. The redeemable noncontrolling interests are reported at their estimated redemption value. Any adjustment to the redemption value impacts retained earnings but does not impact net income. Redeemable noncontrolling interests which are redeemable only upon future events, the occurrence of which is not currently probable, are recorded at carrying value. As of September 30, 2018, the Company does not have any subsidiaries for which the noncontrolling interest party has within their control the right to require the Company to redeem any portion of its interests.

[0000833444-18-000053:notes:545]
The following schedules present changes in the redeemable noncontrolling interests (in millions):

[0000833444-18-000053:notes:546]
|  | Year Ended September 30, 2018 |  | Year Ended September 30, 2017 |  | Year Ended September 30, 2016 |
| Beginning balance, September 30 | $ | 211 |  |  | $ | 234 |  |  | $ | 212 |  |
| Net income | 35 |  |  | 44 |  |  | 48 |  |
| Foreign currency translation adjustments | (3 | ) |  | 13 |  |  | 2 |  |
| Realized and unrealized losses on derivatives | (9 | ) |  | (1 | ) |  | (1 | ) |
| Dividends | (3 | ) |  | (43 | ) |  | (27 | ) |
| Reclassification to noncontrolling interest | (231 | ) |  | — |  |  | — |  |
| Spin-off of Adient | — |  |  | (36 | ) |  | — |  |
| Ending balance, September 30 | $ | — |  |  | $ | 211 |  |  | $ | 234 |  |


## us-gaap:SubsequentEventsTextBlock

[0000833444-18-000053:notes:547]
SUBSEQUENT EVENT

[0000833444-18-000053:notes:548]
On November 13, 2018, the Company entered into a Stock and Asset Purchase Agreement (“Purchase Agreement”) with BCP Acquisitions LLC (“Purchaser”). The Purchaser is a newly-formed entity controlled by investment funds managed by Brookfield Capital Partners LLC. Pursuant to the Purchase Agreement, on the terms and subject to the conditions therein, the Company has agreed to sell, and Purchaser has agreed to acquire, the Company’s Power Solutions business for a purchase price of $13.2 billion. Net cash proceeds are expected to be $11.4 billion after tax and transaction-related expenses. The transaction is expected to close by June 30, 2019, subject to customary closing conditions and required regulatory approvals. The operating results of the Power Solutions business will be reported as a discontinued operation beginning in the first quarter of fiscal 2019.
