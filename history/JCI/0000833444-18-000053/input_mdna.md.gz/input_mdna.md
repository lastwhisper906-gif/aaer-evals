# JCI MD&A — 0000833444-18-000053


## mdna

[0000833444-18-000053:mdna:1]
| ITEM 7 | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0000833444-18-000053:mdna:2]
General

[0000833444-18-000053:mdna:3]
The Company operates in two primary businesses: Building Technologies & Solutions and Power Solutions. Building Technologies & Solutions provides facility systems and services including comfort and energy management for the residential and non-residential buildings markets, security products and services, and fire detection and suppression products and services. Power Solutions designs and manufactures automotive batteries for the replacement and original equipment markets.

[0000833444-18-000053:mdna:4]
This discussion summarizes the significant factors affecting the consolidated operating results, financial condition and liquidity of the Company for the three-year period ended September 30, 2018. This discussion should be read in conjunction with Item 8, the consolidated financial statements and the notes to consolidated financial statements.

[0000833444-18-000053:mdna:5]
FISCAL YEAR 2018 COMPARED TO FISCAL YEAR 2017

[0000833444-18-000053:mdna:6]
Net Sales

[0000833444-18-000053:mdna:7]
|  | Year Ended September 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Net sales | $ | 31,400 |  |  | $ | 30,172 |  |  | 4 | % |

[0000833444-18-000053:mdna:8]
The increase in consolidated net sales was due to higher sales in the Building Technologies & Solutions business ($1,004 million), the favorable impact of foreign currency translation ($512 million) and higher sales in the Power Solutions business ($467 million), partially offset by lower sales due to business divestitures ($755 million). The increased sales in the Building Technologies & Solutions business, net of divestitures, primarily related to higher volumes across all segments. Increased sales in the Power Solutions business primarily resulted from the impact of higher lead costs on pricing as well as favorable pricing and product mix. Excluding the impact of foreign currency translation, impact of lead costs on pricing and business divestitures, consolidated net sales also increased 4% as compared to the prior year. Refer to the segment analysis below within Item 7 for a discussion of net sales by segment.

[0000833444-18-000053:mdna:9]
Cost of Sales / Gross Profit

[0000833444-18-000053:mdna:10]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Cost of sales | $ | 22,020 |  |  | $ | 20,833 |  |  | 6 | % |
| Gross profit | 9,380 |  |  | 9,339 |  |  | — | % |
| % of sales | 29.9 | % |  | 31.0 | % |  |  |

[0000833444-18-000053:mdna:11]
Cost of sales increased in fiscal 2018 as compared to fiscal 2017, and gross profit as a percentage of sales decreased by 110 basis points. Gross profit in the Building Technologies & Solutions business increased due to prior year nonrecurring purchase accounting adjustments ($68 million), and higher volumes and favorable mix across all segments, partially offset by business divestitures and higher operating costs. Gross profit in the Power Solutions business was impacted by higher operating costs primarily driven by efforts to satisfy customer demand, partially offset by favorable pricing and product mix. Net mark-to-market adjustments on

[0000833444-18-000053:mdna:12]
pension and postretirement plans had a net unfavorable year-over-year impact on cost of sales of $88 million ($16 million charge in fiscal 2018 compared to a $72 million gain in fiscal 2017) primarily due to a decrease in U.S. investment returns. Foreign currency translation had an unfavorable impact on cost of sales of approximately $383 million. Refer to the segment analysis below within Item 7 for a discussion of segment earnings before interest, taxes and amortization ("EBITA") by segment.

[0000833444-18-000053:mdna:13]
Selling, General and Administrative Expenses

[0000833444-18-000053:mdna:14]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Selling, general and administrative expenses | $ | 6,010 |  |  | $ | 6,158 |  |  | -2 | % |
| % of sales | 19.1 | % |  | 20.4 | % |  |  |

[0000833444-18-000053:mdna:15]
Selling, general and administrative expenses ("SG&A") decreased by $148 million year over year, and SG&A as a percentage of sales decreased by 130 basis points. The decrease in SG&A was primarily due to productivity savings and costs synergies, business divestitures and a gain on sale of the Scott Safety business in the Building Technologies & Solutions Global Products segment ($114 million). The net favorable year-over-year impact on SG&A resulting from transaction and integration costs was $177 million. Foreign currency translation had an unfavorable impact on SG&A of $78 million. The net mark-to-market adjustments on pension and postretirement plans had a net unfavorable year-over-year impact on SG&A of $322 million ($26 million gain in fiscal 2018 compared to a $348 million gain in fiscal 2017) primarily due to a decrease in U.S. investment returns. Refer to the segment analysis below within Item 7 for a discussion of segment EBITA by segment.

[0000833444-18-000053:mdna:16]
Restructuring and Impairment Costs

[0000833444-18-000053:mdna:17]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Restructuring and impairment costs | $ | 263 |  |  | $ | 367 |  |  | -28 | % |

[0000833444-18-000053:mdna:18]
Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for further disclosure related to the Company's restructuring plans.

[0000833444-18-000053:mdna:19]
Net Financing Charges

[0000833444-18-000053:mdna:20]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Net financing charges | $ | 441 |  |  | $ | 496 |  |  | -11 | % |

[0000833444-18-000053:mdna:21]
Refer to Note 9, "Debt and Financing Arrangements," of the notes to consolidated financial statements for further disclosure related to the Company's net financing charges.

[0000833444-18-000053:mdna:22]
Equity Income

[0000833444-18-000053:mdna:23]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Equity income | $ | 235 |  |  | $ | 240 |  |  | -2 | % |

[0000833444-18-000053:mdna:24]
The decrease in equity income was primarily due to lower income at partially-owned affiliates in the Power Solutions business, partially offset by higher income at partially-owned affiliates in the Building Technologies & Solutions business. Refer to the segment analysis below within Item 7 for a discussion of segment EBITA by segment.

[0000833444-18-000053:mdna:25]
Income Tax Provision

[0000833444-18-000053:mdna:26]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Income tax provision | $ | 518 |  |  | $ | 705 |  |  | -27 | % |
| Effective tax rate | 18 | % |  | 28 | % |  |  |

[0000833444-18-000053:mdna:27]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. The effective rate is above the statutory rate of 12.5% for fiscal 2018 primarily due to the discrete net impacts of U.S. Tax Reform, final income tax effects of the completed divestiture of the Scott Safety business, legal entity restructuring associated with the Power Solutions business, valuation allowance adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives, tax audit closures and tax benefits due to changes in entity tax status. The effective rate is above the statutory rate of 12.5% for fiscal 2017 primarily due to the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries related to the divestiture of the Scott Safety business, the income tax effects of pension mark-to-market gains and tax rate differentials, partially offset by the jurisdictional mix of significant restructuring and impairment costs, Tyco Merger transaction and integration costs, purchase accounting adjustments, tax audit closures, a tax benefit due to changes in entity tax status and the benefits of continuing global tax planning initiatives. The fiscal 2018 effective tax rate decreased as compared to the fiscal 2017 effective tax rate primarily due to discrete tax items and tax planning initiatives. The fiscal year 2018 and 2017 global tax planning initiatives related primarily to foreign tax credit planning, changes in entity tax status, global financing structures and alignment of the Company's global business functions in a tax efficient manner. Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements for further details.

[0000833444-18-000053:mdna:28]
Valuation Allowances

[0000833444-18-000053:mdna:29]
The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary.

[0000833444-18-000053:mdna:30]
In the fourth quarter of fiscal 2018, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering feasible tax planning initiatives and other positive and negative evidence, the Company determined that  it was more likely than not that certain deferred tax assets primarily within Germany would not be realized. Therefore, the Company recorded $56 million of valuation allowances as income tax expense in the three month period ended September 30, 2018.

[0000833444-18-000053:mdna:31]
In the fourth quarter of fiscal 2017, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering tax planning initiatives and other positive and negative evidence, the Company determined that it was more likely than not that certain deferred tax assets primarily in Canada, China and Mexico would not be able to be realized, and it was more likely than not that certain deferred tax assets in Germany would be realized. Therefore, the Company recorded $27 million of net valuation allowances as income tax expense in the three month period ended September 30, 2017.

[0000833444-18-000053:mdna:32]
Uncertain Tax Positions

[0000833444-18-000053:mdna:33]
The Company is subject to income taxes in the U.S. and numerous non-U.S. jurisdictions. Judgment is required in determining its worldwide provision for income taxes and recording the related assets and liabilities. In the ordinary course of the Company’s business, there are many transactions and calculations where the ultimate tax determination is uncertain. The Company is regularly under audit by tax authorities.

[0000833444-18-000053:mdna:34]
During fiscal 2018, the Company settled tax examinations impacting fiscal years 2010 to fiscal 2012 which resulted in a $25 million net benefit to income tax expense.

[0000833444-18-000053:mdna:35]
During fiscal 2017, the Company settled a significant number of tax examinations impacting fiscal years 2006 to fiscal 2014. In the fourth quarter of fiscal 2017, income tax audit resolutions resulted in a net $191 million benefit to income tax expense.

[0000833444-18-000053:mdna:36]
The Company’s federal income tax returns and certain non-U.S. income tax returns for various fiscal years remain under various stages of audit by the IRS and respective non-U.S. tax authorities. Although the outcome of tax audits is always uncertain,

[0000833444-18-000053:mdna:37]
31

[0000833444-18-000053:mdna:38]
management believes that it has appropriate support for the positions taken on its tax returns and that its annual tax provisions included amounts sufficient to pay assessments, if any, which may be proposed by the taxing authorities. At September 30, 2018, the Company had recorded a liability for its best estimate of the probable loss on certain of its tax positions, the majority of which is included in other noncurrent liabilities in the consolidated statements of financial position. Nonetheless, the amounts ultimately paid, if any, upon resolution of the issues raised by the taxing authorities may differ materially from the amounts accrued for each year.

[0000833444-18-000053:mdna:39]
Other Tax Matters

[0000833444-18-000053:mdna:40]
In the fourth quarter of fiscal 2018, the Company recorded a tax benefit of $139 million due to changes in entity tax status.

[0000833444-18-000053:mdna:41]
In the fourth quarter of fiscal 2018, the Company recorded a tax charge of $129 million due to legal entity restructuring associated with the Power Solutions business.

[0000833444-18-000053:mdna:42]
In the first quarter of fiscal 2018, the Company completed the sale of its Scott Safety business to 3M Company. In connection with the sale, the Company recorded a pre-tax gain of $114 million and income tax expense of $30 million. In addition, during fiscal 2017, the Company recorded a discrete non-cash tax charge of $490 million related to establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries of the Scott Safety business. Refer to Note 3, "Acquisitions and Divestitures," and Note 4, "Discontinued Operations," of the notes to consolidated financial statements for additional information.

[0000833444-18-000053:mdna:43]
During fiscal 2018 and 2017, the Company recorded transaction and integration costs of $234 million and $428 million, respectively. These costs generated tax benefits of $27 million and $69 million, respectively, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-18-000053:mdna:44]
During fiscal 2018 and 2017, the Company incurred significant charges for restructuring and impairment costs of $263 million and $367 million, respectively. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. These costs generated tax benefits of $38 million and $63 million, respectively, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-18-000053:mdna:45]
During fiscal 2018 and 2017, the Company recorded pension mark-to-market gains of $10 million and $420 million, respectively. These gains generated tax expense (benefit) of $(3) million and $126 million, respectively, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-18-000053:mdna:46]
In the fourth quarter of fiscal 2017, the Company recorded a tax charge of $53 million due to a change in the deferred tax liability related to the outside basis of certain nonconsolidated subsidiaries.

[0000833444-18-000053:mdna:47]
In the first quarter of fiscal 2017, the Company recorded a discrete tax benefit of $101 million due to changes in entity tax status.

[0000833444-18-000053:mdna:48]
Impacts of Tax Legislation and Change in Statutory Tax Rates

[0000833444-18-000053:mdna:49]
On December 22, 2017, the “Tax Cuts and Jobs Act” (H.R. 1) was enacted and significantly revises U.S. corporate income tax by, among other things, lowering corporate income tax rates, imposing a one-time transition tax on deemed repatriated earnings of non-U.S. subsidiaries, and implementing a territorial tax system and various base erosion minimum tax provisions.

[0000833444-18-000053:mdna:50]
In connection with the Company’s analysis of the impact of the U.S. tax law changes, which is provisional and subject to change, the Company recorded a net tax charge of $108 million during fiscal 2018. This provisional net tax charge arises from a benefit of $108 million due to the remeasurement of U.S. deferred tax assets and liabilities, offset by the Company’s tax charge relating to the one-time transition tax on deemed repatriated earnings, inclusive of all relevant taxes, of $216 million. The Company’s estimated benefit of the remeasurement of U.S. deferred tax assets and liabilities increased from $101 million as of December 31, 2017 to $108 million as of September 30, 2018 due to calculation refinement of the Company’s estimated impact. The Company remeasured certain deferred tax assets and liabilities based on the rates at which they are expected to reverse in the future. The Company’s tax charge for transition tax decreased from $305 million as of December 31, 2017 to $216 million as of September 30, 2018 due to further analysis of the Company’s post-1986 non-U.S. earnings and profits (“E&P”) previously deferred from U.S. federal taxation and refinement of the estimated impact of tax law changes.

[0000833444-18-000053:mdna:51]
Based on the effective dates of certain aspects of the U.S. tax law changes, various applicable impacts of the enacted legislation could not be finalized as of September 30, 2018.  While the Company made reasonable estimates of the impact of the transition tax, the final impact of the U.S. tax law changes may differ from these estimated impacts, due to, future treasury regulations, tax

[0000833444-18-000053:mdna:52]
law technical corrections, notices, rulings, refined computations, and other items. The Company will finalize such provisional amounts within the time period prescribed by Staff Accounting Bulletin 118.

[0000833444-18-000053:mdna:53]
During the fiscal years ended 2018 and 2017, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-18-000053:mdna:54]
Loss From Discontinued Operations, Net of Tax

[0000833444-18-000053:mdna:55]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Loss from discontinued operations, net of tax | $ | — |  |  | $ | (34 | ) |  | * |

[0000833444-18-000053:mdna:56]
* Measure not meaningful

[0000833444-18-000053:mdna:57]
Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-18-000053:mdna:58]
Income Attributable to Noncontrolling Interests

[0000833444-18-000053:mdna:59]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 221 |  |  | $ | 199 |  |  | 11 | % |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  | 9 |  |  | * |  |

[0000833444-18-000053:mdna:60]
* Measure not meaningful

[0000833444-18-000053:mdna:61]
The increase in income from continuing operations attributable to noncontrolling interests was primarily due to  higher net income related to the Johnson Controls - Hitachi joint venture in the Building Technologies & Solutions business and higher net income at a Power Solutions partially-owned affiliate.

[0000833444-18-000053:mdna:62]
Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

[0000833444-18-000053:mdna:63]
Net Income Attributable to Johnson Controls

[0000833444-18-000053:mdna:64]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Net income attributable to Johnson Controls | $ | 2,162 |  |  | $ | 1,611 |  |  | 34 | % |

[0000833444-18-000053:mdna:65]
The increase in net income attributable to Johnson Controls was primarily due to lower income tax provision due to higher discrete period net tax charges in the prior year, lower SG&A, lower restructuring and impairment costs, lower net financing charges and higher gross profit. Fiscal 2018 diluted earnings per share attributable to Johnson Controls was $2.32 compared to $1.71 in fiscal 2017.

[0000833444-18-000053:mdna:66]
Comprehensive Income Attributable to Johnson Controls

[0000833444-18-000053:mdna:67]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Comprehensive income attributable to Johnson Controls | $ | 1,689 |  |  | $ | 1,710 |  |  | -1 | % |

[0000833444-18-000053:mdna:68]
The decrease in comprehensive income attributable to Johnson Controls was due to a decrease in other comprehensive income attributable to Johnson Controls ($572 million) resulting primarily from unfavorable foreign currency translation adjustments, partially offset by higher net income attributable to Johnson Controls ($551 million). These year-over-year unfavorable foreign currency translation adjustments were primarily driven by the weakening of the British pound and euro currencies against the U.S. dollar.

[0000833444-18-000053:mdna:69]
SEGMENT ANALYSIS

[0000833444-18-000053:mdna:70]
Management evaluates the performance of its business units based primarily on segment EBITA, which is defined as income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, significant restructuring and impairment costs, and net mark-to-market adjustments on pension and postretirement plans.

[0000833444-18-000053:mdna:71]
Building Technologies & Solutions

[0000833444-18-000053:mdna:72]
|  | Net Salesfor the Year EndedSeptember 30, |  |  |  | Segment EBITAfor the Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |  | 2018 |  | 2017 |  | Change |
| Building Solutions North America | $ | 8,679 |  |  | $ | 8,341 |  |  | 4 | % |  | $ | 1,109 |  |  | $ | 1,039 |  |  | 7 | % |
| Building Solutions EMEA/LA | 3,696 |  |  | 3,595 |  |  | 3 | % |  | 344 |  |  | 290 |  |  | 19 | % |
| Building Solutions Asia Pacific | 2,553 |  |  | 2,444 |  |  | 4 | % |  | 347 |  |  | 323 |  |  | 7 | % |
| Global Products | 8,472 |  |  | 8,455 |  |  | — | % |  | 1,338 |  |  | 1,179 |  |  | 13 | % |
|  | $ | 23,400 |  |  | $ | 22,835 |  |  | 2 | % |  | $ | 3,138 |  |  | $ | 2,831 |  |  | 11 | % |

[0000833444-18-000053:mdna:73]
Net Sales:

[0000833444-18-000053:mdna:74]
| • | The increase in Building Solutions North America was due to higher volumes ($343 million) and the favorable impact of foreign currency translation ($20 million), partially offset by the impact of prior year nonrecurring purchase accounting adjustments ($25 million). The increase in volumes was primarily attributable to higher HVAC, controls, fire and security sales. |

[0000833444-18-000053:mdna:75]
| • | The increase in Building Solutions EMEA/LA was due to the favorable impact of foreign currency translation ($132 million), higher volumes ($63 million) and incremental sales related to a business acquisition ($2 million), partially offset by lower volumes related to a business divestiture ($80 million) and the impact of prior year nonrecurring purchase accounting adjustments ($16 million). The increase in volumes was primarily attributable to strong service growth which was positive across all regions led by Europe and Latin America. |

[0000833444-18-000053:mdna:76]
| • | The increase in Building Solutions Asia Pacific was due to higher volumes ($61 million), the favorable impact of foreign currency translation ($61 million) and the impact of prior year nonrecurring purchase accounting adjustments ($1 million), partially offset by lower volumes related to a business divestiture ($14 million). The increase in volumes was primarily attributable to higher service sales. |

[0000833444-18-000053:mdna:77]
| • | The increase in Global Products was due to higher volumes ($571 million), the favorable impact of foreign currency translation ($103 million) and the impact of prior year nonrecurring purchase accounting adjustments ($6 million), partially offset by lower volumes related to business divestitures ($663 million). The increase in volumes was primarily attributable to higher building management, HVAC and refrigeration equipment, and specialty products sales. |

[0000833444-18-000053:mdna:78]
34

[0000833444-18-000053:mdna:79]
Segment EBITA:

[0000833444-18-000053:mdna:80]
| • | The increase in Building Solutions North America was due to favorable volumes / mix ($100 million), prior year integration costs ($42 million), prior year transaction costs ($13 million), and the favorable impact of foreign currency translation ($1 million), partially offset by higher SG&A including incremental salesforce investments ($37 million), current year integration costs ($25 million) and prior year nonrecurring purchase accounting adjustments ($24 million). |

[0000833444-18-000053:mdna:81]
| • | The increase in Building Solutions EMEA/LA was due to a prior year unfavorable arbitration award ($50 million), favorable volumes / mix ($26 million), lower SG&A ($14 million), the favorable impact of foreign currency translation ($7 million), prior year integration costs ($6 million) and prior year transaction costs ($5 million), partially offset by prior year nonrecurring purchase accounting adjustments ($23 million), incremental salesforce investments ($14 million), current year integration costs ($6 million), higher operating costs ($5 million), lower equity income ($4 million) and lower income due to a business divestiture ($2 million). |

[0000833444-18-000053:mdna:82]
| • | The increase in Building Solutions Asia Pacific was due to higher volumes / mix ($33 million), prior year integration costs ($5 million), prior year transaction costs ($2 million), prior year nonrecurring purchase accounting adjustments ($2 million) and the favorable impact of foreign currency translation ($1 million), partially offset by higher SG&A including incremental salesforce investments ($15 million), and unfavorable pricing ($4 million). |

[0000833444-18-000053:mdna:83]
| • | The increase in Global Products was due to favorable volumes / mix ($219 million), a gain on sale of Scott Safety ($114 million), prior year nonrecurring purchase accounting adjustments ($71 million), higher equity income ($25 million), prior year integration costs ($25 million), the favorable impact of foreign currency translation ($20 million) and prior year transaction costs ($13 million). These items were partially offset by lower income due to business divestitures ($167 million), higher SG&A and operating expenses including planned incremental global product and channel investments, partially offset by productivity savings and gains on business divestitures ($134 million), and current year integration costs ($27 million). |

[0000833444-18-000053:mdna:84]
Power Solutions

[0000833444-18-000053:mdna:85]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2018 |  | 2017 |  | Change |
| Net sales | $ | 8,000 |  |  | $ | 7,337 |  |  | 9 | % |
| Segment EBITA | 1,417 |  |  | 1,427 |  |  | -1 | % |

[0000833444-18-000053:mdna:86]
| • | Net sales increased due to the impact of higher lead costs on pricing ($269 million), the favorable impact of foreign currency translation ($196 million), favorable pricing and product mix ($159 million), and higher volumes ($39 million). The increase in volumes was driven by growth in China and an increase in start-stop battery volumes, partially offset by changes in customer demand patterns in North America. Additionally, higher start-stop volumes contributed to favorable product mix. |

[0000833444-18-000053:mdna:87]
| • | Segment EBITA decreased due to higher operating costs primarily driven by efforts to satisfy customer demand including higher transportation costs ($112 million), incremental investments ($31 million), lower equity income ($20 million), current year transaction costs ($8 million), and restructuring costs and discontinued operation losses included in equity income ($7 million), partially offset by lower SG&A from productivity savings and a gain on a business deconsolidation ($104 million), favorable pricing and product mix ($35 million), the favorable impact of foreign currency translation ($22 million), higher volumes ($6 million) and prior year transaction costs ($1 million). |

[0000833444-18-000053:mdna:88]
FISCAL YEAR 2017 COMPARED TO FISCAL YEAR 2016

[0000833444-18-000053:mdna:89]
Net Sales

[0000833444-18-000053:mdna:90]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Net sales | $ | 30,172 |  |  | $ | 20,837 |  |  | 45 | % |

[0000833444-18-000053:mdna:91]
The increase in consolidated net sales was due to higher sales in the Building Technologies & Solutions business ($8,647 million) and Power Solutions business ($667 million), and the favorable impact of foreign currency translation ($21 million). Increased sales resulted from the Tyco Merger, as well as higher volumes in the Global Products segment, the impact of higher lead costs on pricing, and favorable pricing and product mix in the Power Solutions business. Excluding the impact of the Tyco Merger and foreign currency translation, consolidated net sales increased 4% as compared to the prior year. Refer to the segment analysis below within Item 7 for a discussion of net sales by segment.

[0000833444-18-000053:mdna:92]
Cost of Sales / Gross Profit

[0000833444-18-000053:mdna:93]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Cost of sales | $ | 20,833 |  |  | $ | 15,183 |  |  | 37 | % |
| Gross profit | 9,339 |  |  | 5,654 |  |  | 65 | % |
| % of sales | 31.0 | % |  | 27.1 | % |  |  |

[0000833444-18-000053:mdna:94]
Cost of sales increased in fiscal 2017 as compared to fiscal 2016, with gross profit as a percentage of sales increasing by 390 basis points. Gross profit in the Building Technologies & Solutions business included the incremental gross profit related to the Tyco Merger, and higher volumes in the Global Products  segment. Gross profit in the Power Solutions business was favorably impacted by favorable pricing and product mix net of lead cost increases and higher volumes, partially offset by higher operating costs. Net mark-to-market adjustments on pension and postretirement plans had a net favorable year-over-year impact on cost of sales of $169 million ($72 million gain in fiscal 2017 compared to a $97 million charge in fiscal 2016) primarily due to an increase in year-over-year discount rates and favorable U.S. investment returns versus expectations in the current year. Foreign currency translation had an unfavorable impact on cost of sales of approximately $21 million. Refer to the segment analysis below within Item 7 for a discussion of segment EBITA by segment.

[0000833444-18-000053:mdna:95]
Selling, General and Administrative Expenses

[0000833444-18-000053:mdna:96]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Selling, general and administrative expenses | $ | 6,158 |  |  | $ | 4,190 |  |  | 47 | % |
| % of sales | 20.4 | % |  | 20.1 | % |  |  |

[0000833444-18-000053:mdna:97]
SG&A increased by $1,968 million year over year, and SG&A as a percentage of sales increased by 30 basis points. The Building Technologies & Solutions business SG&A increased primarily due to incremental SG&A related to the Tyco Merger, partially offset by productivity savings and cost synergies. Foreign currency translation had an unfavorable impact on SG&A of $5 million. The net unfavorable year-over-year impact on SG&A resulting from transaction, integration and separation costs was $149 million. The net mark-to-market adjustments on pension and postretirement plans had a net favorable year-over-year impact on SG&A of $644 million ($348 million gain in fiscal 2017 compared to a $296 million charge in fiscal 2016) primarily  due to an increase in year-over-year discount rates and favorable U.S. investment returns versus expectations in the current year. Refer to the segment analysis below within Item 7 for a discussion of segment EBITA by segment.

[0000833444-18-000053:mdna:98]
Restructuring and Impairment Costs

[0000833444-18-000053:mdna:99]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Restructuring and impairment costs | $ | 367 |  |  | $ | 288 |  |  | 27 | % |

[0000833444-18-000053:mdna:100]
Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for further disclosure related to the Company's restructuring plans.

[0000833444-18-000053:mdna:101]
Net Financing Charges

[0000833444-18-000053:mdna:102]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Net financing charges | $ | 496 |  |  | $ | 289 |  |  | 72 | % |

[0000833444-18-000053:mdna:103]
Refer to Note 9, "Debt and Financing Arrangements," of the notes to consolidated financial statements for further disclosure related to the Company's net financing charges.

[0000833444-18-000053:mdna:104]
Equity Income

[0000833444-18-000053:mdna:105]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Equity income | $ | 240 |  |  | $ | 174 |  |  | 38 | % |

[0000833444-18-000053:mdna:106]
The increase in equity income was primarily due to higher income at certain partially-owned affiliates of the Power Solutions business and the Johnson Controls - Hitachi joint venture in the Building Technologies & Solutions business. Refer to the segment analysis below within Item 7 for a discussion of segment EBITA by segment.

[0000833444-18-000053:mdna:107]
Income Tax Provision

[0000833444-18-000053:mdna:108]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Income tax provision | $ | 705 |  |  | $ | 197 |  |  | * |
| Effective tax rate | 28 | % |  | 19 | % |  |  |

[0000833444-18-000053:mdna:109]
* Measure not meaningful

[0000833444-18-000053:mdna:110]
The statutory tax rate in Ireland is being used as a comparison for fiscal 2017 since the Company is domiciled in Ireland. The U.S. federal statutory rate is being used as a comparison for fiscal 2016 since the Company was a U.S. domiciled company for 11 months of fiscal 2016. The effective rate is above the statutory rate of 12.5% for fiscal 2017 primarily due to the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries related to the divestiture of the Scott Safety business, the income tax effects of pension mark-to-market gains and tax rate differentials, partially offset by the jurisdictional mix of significant restructuring and impairment costs, Tyco Merger transaction and integration costs, purchase accounting adjustments, tax audit closures, a tax benefit due to changes in entity tax status and the benefits of continuing global tax planning initiatives. The effective rate is below the U.S. statutory rate of 35% for fiscal 2016 primarily due to the benefits of continuing global tax planning initiatives and foreign tax rate differentials, partially offset by the jurisdictional mix of restructuring and impairment costs, and the tax impacts of the Merger and integration related costs. The fiscal 2017 effective tax rate increased as compared to the fiscal 2016 effective tax rate primarily due to the tax effects of transactions ($408 million), and the tax effects of restructuring and impairment costs ($37 million), partially offset by the tax effects of reserve and valuation allowance adjustments ($164 million) and tax planning initiatives. The fiscal year 2017 and 2016 global tax planning initiatives related primarily to foreign tax credit planning, changes in entity tax status, global financing structures and alignment of the Company's global business functions in a tax efficient manner. Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements for further details.

[0000833444-18-000053:mdna:111]
Valuation Allowances

[0000833444-18-000053:mdna:112]
The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary.

[0000833444-18-000053:mdna:113]
In the fourth quarter of fiscal 2017, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering tax planning initiatives and other positive and negative evidence, the Company determined

[0000833444-18-000053:mdna:114]
37

[0000833444-18-000053:mdna:115]
that it was more likely than not that certain deferred tax assets primarily in Canada, China and Mexico would not be able to be realized, and it was more likely than not that certain deferred tax assets in Germany would be realized. Therefore, the Company recorded $27 million of net valuation allowances as income tax expense in the three month period ended September 30, 2017.

[0000833444-18-000053:mdna:116]
In the fourth quarter of fiscal 2016, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering tax planning initiatives and other positive and negative evidence, the Company determined that no other material changes were needed to its valuation allowances.  Therefore, there was no impact to income tax expense due to valuation allowance changes in the three month period or year ended September 30, 2016.

[0000833444-18-000053:mdna:117]
Uncertain Tax Positions

[0000833444-18-000053:mdna:118]
The Company is subject to income taxes in the U.S. and numerous non-U.S. jurisdictions. Judgment is required in determining its worldwide provision for income taxes and recording the related assets and liabilities. In the ordinary course of the Company’s business, there are many transactions and calculations where the ultimate tax determination is uncertain. The Company is regularly under audit by tax authorities.

[0000833444-18-000053:mdna:119]
During fiscal 2017, the Company settled a significant number of tax examinations impacting fiscal years 2006 to fiscal 2014. In the fourth quarter of fiscal 2017, income tax audit resolutions resulted in a net $191 million benefit to income tax expense.

[0000833444-18-000053:mdna:120]
The Company’s federal income tax returns and certain non-U.S. income tax returns for various fiscal years remain under various stages of audit by the IRS and respective non-U.S. tax authorities. Although the outcome of tax audits is always uncertain, management believes that it has appropriate support for the positions taken on its tax returns and that its annual tax provisions included amounts sufficient to pay assessments, if any, which may be proposed by the taxing authorities. At September 30, 2017, the Company had recorded a liability for its best estimate of the probable loss on certain of its tax positions, the majority of which is included in other noncurrent liabilities in the consolidated statements of financial position. Nonetheless, the amounts ultimately paid, if any, upon resolution of the issues raised by the taxing authorities may differ materially from the amounts accrued for each year.

[0000833444-18-000053:mdna:121]
Other Tax Matters

[0000833444-18-000053:mdna:122]
During fiscal 2017, the Company recorded $428 million of transaction and integration costs which generated a $69 million tax benefit.

[0000833444-18-000053:mdna:123]
During fiscal 2017, the Company recorded a discrete non-cash tax charge of $490 million related to establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries of the Scott Safety business. This business is reported as net assets held for sale given the announced sale to 3M Company. Refer to Note 3, "Acquisitions and Divestitures," and Note 4, "Discontinued Operations," of the notes to consolidated financial statements for additional information.

[0000833444-18-000053:mdna:124]
In the fourth quarter of fiscal 2017, the Company recorded a tax charge of $53 million due to a change in the deferred tax liability related to the outside basis of certain nonconsolidated subsidiaries.

[0000833444-18-000053:mdna:125]
In the first quarter of fiscal 2017, the Company recorded a discrete tax benefit of $101 million due to changes in entity tax status.

[0000833444-18-000053:mdna:126]
During fiscal 2017 and 2016, the Company incurred significant charges for restructuring and impairment costs. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. These costs generated tax benefits of $63 million and $76 million, respectively, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-18-000053:mdna:127]
During the fourth quarter of fiscal 2016, the Company completed its merger with Tyco. As a result of that transaction, the Company incurred incremental tax expense of $137 million. In preparation for the spin-off of the Automotive Experience business in the first quarter of fiscal 2017, the Company incurred incremental tax expense for continuing operations of $26 million in fiscal 2016.

[0000833444-18-000053:mdna:128]
Impacts of Tax Legislation and Change in Statutory Tax Rates

[0000833444-18-000053:mdna:129]
On October 13, 2016, the U.S. Treasury and the IRS released final and temporary Section 385 regulations. These regulations address whether certain instruments between related parties are treated as debt or equity.

[0000833444-18-000053:mdna:130]
The "look-through rule," under subpart F of the U.S. Internal Revenue Code, expired for the Company on September 30, 2015. The "look-through rule" had provided an exception to the U.S. taxation of certain income generated by foreign subsidiaries. The

[0000833444-18-000053:mdna:131]
38

[0000833444-18-000053:mdna:132]
rule was extended in December 2015 retroactive to the beginning of the Company’s 2016 fiscal year. The retroactive extension was signed into legislation and was made permanent through the Company's 2020 fiscal year.

[0000833444-18-000053:mdna:133]
During the fiscal years ended 2017 and 2016, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-18-000053:mdna:134]
Loss From Discontinued Operations, Net of Tax

[0000833444-18-000053:mdna:135]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Loss from discontinued operations, net of tax | $ | (34 | ) |  | $ | (1,516 | ) |  | * |

[0000833444-18-000053:mdna:136]
* Measure not meaningful

[0000833444-18-000053:mdna:137]
Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-18-000053:mdna:138]
Income Attributable to Noncontrolling Interests

[0000833444-18-000053:mdna:139]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 199 |  |  | $ | 132 |  |  | 51 | % |
| Income from discontinued operations attributable to noncontrolling interests | 9 |  |  | 84 |  |  | -89 | % |

[0000833444-18-000053:mdna:140]
The increase in income from continuing operations attributable to noncontrolling interests for fiscal 2017 was primarily due to higher net income related to the Johnson Controls - Hitachi joint venture in the Building Technologies & Solutions business.

[0000833444-18-000053:mdna:141]
Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

[0000833444-18-000053:mdna:142]
Net Income (Loss) Attributable to Johnson Controls

[0000833444-18-000053:mdna:143]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Net income (loss) attributable to Johnson Controls | $ | 1,611 |  |  | $ | (868 | ) |  | * |

[0000833444-18-000053:mdna:144]
* Measure not meaningful

[0000833444-18-000053:mdna:145]
The increase in net income (loss) attributable to Johnson Controls was primarily due to incremental operating income as a result of the Tyco Merger and a prior year net loss from discontinued operations, partially offset by an increase in the income tax provision and higher net financing charges. Fiscal 2017 diluted earnings (loss) per share attributable to Johnson Controls was $1.71 compared to ($1.29) in fiscal 2016.

[0000833444-18-000053:mdna:146]
Comprehensive Income (Loss) Attributable to Johnson Controls

[0000833444-18-000053:mdna:147]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Comprehensive income (loss) attributable to Johnson Controls | $ | 1,710 |  |  | $ | (964 | ) |  | * |

[0000833444-18-000053:mdna:148]
* Measure not meaningful

[0000833444-18-000053:mdna:149]
The increase in comprehensive income (loss) attributable to Johnson Controls was due to higher net income (loss) attributable to Johnson Controls ($2,479 million) and an increase in other comprehensive loss attributable to Johnson Controls ($195 million) primarily related to favorable foreign currency translation adjustments. These year-over-year favorable foreign currency translation adjustments were primarily driven by the strengthening of the euro and British pound currencies against the U.S. dollar, partially offset by the weakening of the Japanese yen currency against the U.S. dollar.

[0000833444-18-000053:mdna:150]
Segment Analysis

[0000833444-18-000053:mdna:151]
Management evaluates the performance of its business units based primarily on segment EBITA, which is defined as income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, significant restructuring and impairment costs, and net mark-to-market adjustments on pension and postretirement plans.

[0000833444-18-000053:mdna:152]
Building Technologies & Solutions

[0000833444-18-000053:mdna:153]
|  | Net Salesfor the Year EndedSeptember 30, |  |  |  | Segment EBITAfor the Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Building Solutions North America | $ | 8,341 |  |  | $ | 4,687 |  |  | 78 | % |  | $ | 1,039 |  |  | $ | 494 |  |  | * |  |
| Building Solutions EMEA/LA | 3,595 |  |  | 1,613 |  |  | * |  |  | 290 |  |  | 74 |  |  | * |  |
| Building Solutions Asia Pacific | 2,444 |  |  | 1,736 |  |  | 41 | % |  | 323 |  |  | 222 |  |  | 45 | % |
| Global Products | 8,455 |  |  | 6,148 |  |  | 38 | % |  | 1,179 |  |  | 637 |  |  | 85 | % |
|  | $ | 22,835 |  |  | $ | 14,184 |  |  | 61 | % |  | $ | 2,831 |  |  | $ | 1,427 |  |  | 98 | % |

[0000833444-18-000053:mdna:154]
* Measure not meaningful

[0000833444-18-000053:mdna:155]
Net Sales:

[0000833444-18-000053:mdna:156]
| • | The increase in Building Solutions North America was due to incremental sales related to the Tyco Merger including current year nonrecurring purchase accounting adjustments ($3,689 million), the impact of prior year nonrecurring purchase accounting adjustments ($15 million) and the favorable impact of foreign currency translation ($5 million), partially offset by a prior year business divestiture ($32 million) and lower installation volumes ($23 million). |

[0000833444-18-000053:mdna:157]
| • | The increase in Building Solutions EMEA/LA was due to incremental sales related to the Tyco Merger including current year nonrecurring purchase accounting adjustments ($1,982 million), higher volumes ($7 million), the impact of prior year nonrecurring purchase accounting adjustments ($5 million) and the favorable impact of foreign currency translation ($3 million), partially offset by a business divestiture ($15 million). |

[0000833444-18-000053:mdna:158]
| • | The increase in Building Solutions Asia Pacific was due to incremental sales related to the Tyco Merger including current year nonrecurring purchase accounting adjustments ($653 million), higher volumes of equipment and control systems ($41 million), and higher service volumes ($38 million), partially offset by the unfavorable impact of foreign currency translation ($24 million). The increase in volume was driven by favorable local economic conditions. |

[0000833444-18-000053:mdna:159]
| • | The increase in Global Products was due to incremental sales related to the Tyco Merger including current year nonrecurring purchase accounting adjustments ($2,157 million), higher volumes ($221 million) and the favorable impact of foreign currency translation ($20 million), partially offset by lower volumes related to business divestitures and deconsolidation ($91 million). The increase in volumes was primarily attributable to new product offerings. |

[0000833444-18-000053:mdna:160]
Segment EBITA:

[0000833444-18-000053:mdna:161]
| • | The increase in Building Solutions North America was due to incremental income related to the Tyco Merger ($567 million), the net impact of prior year and current year nonrecurring purchase accounting adjustments ($52 million), favorable mix ($9 million), lower SG&A ($3 million) as a result of productivity and synergy savings net of a prior year gain on business divestiture, the favorable impact of foreign currency translation ($1 million) and prior year transaction costs ($1 million), partially offset by current year integration costs ($42 million), higher operating costs as a result of channel investments ($25 million), current year transaction costs ($13 million), lower volumes ($6 million) and a prior year business divestiture ($2 million). |

[0000833444-18-000053:mdna:162]
| • | The increase in Building Solutions EMEA/LA was due to incremental income related to the Tyco Merger ($221 million), the net impact of prior year and current year nonrecurring purchase accounting adjustments ($33 million), lower SG&A as a result of productivity and synergy savings ($23 million), favorable mix ($7 million), higher volumes ($2 million) and prior year transaction costs ($1 million), partially offset by a current year unfavorable arbitration award ($50 million), current year integration costs ($6 million), lower equity income ($6 million), current year transaction costs ($5 million), the unfavorable impact of foreign currency translation ($3 million) and a prior year business divestiture ($1 million). |

[0000833444-18-000053:mdna:163]
| • | The increase in Building Solutions Asia Pacific was due to incremental income related to the Tyco Merger ($73 million), lower SG&A as a result of productivity savings ($24 million), higher volumes ($20 million) and the favorable impact of foreign currency translation ($1 million), partially offset by unfavorable mix ($6 million), current year integration costs ($5 million), higher operating costs ($4 million) and current year transaction costs ($2 million). |

[0000833444-18-000053:mdna:164]
| • | The increase in Global Products was due to incremental income related to the Tyco Merger ($474 million), higher volumes ($55 million), lower SG&A as a result of productivity and synergy savings ($41 million), higher equity income ($33 million), prior year integration costs ($20 million), prior year transaction costs ($14 million) and lower operating costs ($13 million), partially offset by the net impact of prior year and current year nonrecurring purchase accounting adjustments ($42 million), current year integration costs ($25 million), unfavorable mix ($16 million), current year transaction costs ($13 million), the unfavorable impact of foreign currency translation ($5 million), a prior year gain on acquisition of partially-owned affiliate ($4 million) and business divestitures ($3 million). |

[0000833444-18-000053:mdna:165]
Power Solutions

[0000833444-18-000053:mdna:166]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Net sales | $ | 7,337 |  |  | $ | 6,653 |  |  | 10 | % |
| Segment EBITA | 1,427 |  |  | 1,327 |  |  | 8 | % |

[0000833444-18-000053:mdna:167]
| • | Net sales increased due to the impact of higher lead costs on pricing ($427 million) favorable pricing and product mix ($154 million), higher sales volumes ($86 million) and the favorable impact of foreign currency translation ($17 million). The increase in volumes was driven by start-stop battery volumes and growth in China. Additionally, higher start-stop volumes contributed to favorable product mix. |

[0000833444-18-000053:mdna:168]
| • | Segment EBITA increased due to favorable pricing and product mix net of lead cost increases ($106 million), lower SG&A as a result of productivity savings ($39 million), higher equity income ($28 million), higher volumes ($27 million), prior year restructuring and impairment costs included in equity income ($7 million), prior year transaction costs ($1 million) and the favorable impact of foreign currency translation ($1 million), partially offset by higher operating costs primarily driven by efforts to satisfy growing customer demand ($108 million) and current year transaction costs ($1 million). |

[0000833444-18-000053:mdna:169]
GOODWILL, LONG-LIVED ASSETS AND OTHER INVESTMENTS

[0000833444-18-000053:mdna:170]
Goodwill at September 30, 2018 was $19.5 billion, $0.2 billion lower than the prior year. The decrease was primarily due to the impact of foreign currency translation.

[0000833444-18-000053:mdna:171]
Goodwill reflects the cost of an acquisition in excess of the fair values assigned to identifiable net assets acquired. The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s reportable segments or one level below the reportable segments in certain instances, using a fair value method based on management’s judgments and assumptions or third party valuations. The fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. In estimating the fair value, the Company uses multiples of earnings based on the average of published multiples of earnings of comparable entities with similar operations and economic characteristics and applies to the Company's average of historical and future financial results. In certain instances, the Company uses discounted cash flow analyses or estimated sales price to further support the fair value estimates. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The estimated fair value is then compared with the carrying amount of the reporting unit, including recorded goodwill. The Company is subject to financial statement risk to the extent that the carrying amount exceeds the estimated fair value.

[0000833444-18-000053:mdna:172]
41

[0000833444-18-000053:mdna:173]
The assumptions included in the impairment tests require judgment, and changes to these inputs could impact the results of the calculations. The primary assumptions used in the impairment tests were management's projections of future cash flows. Although the Company's cash flow forecasts are based on assumptions that are considered reasonable by management and consistent with the plans and estimates management is using to operate the underlying businesses, there are significant judgments in determining the expected future cash flows attributable to a reporting unit.

[0000833444-18-000053:mdna:174]
Indefinite-lived other intangible assets are also subject to at least annual impairment testing. A considerable amount of management judgment and assumptions are required in performing the impairment tests.

[0000833444-18-000053:mdna:175]
While the Company believes the judgments and assumptions used in the impairment tests are reasonable and no impairments of goodwill or indefinite-lived assets existed during fiscal years 2018, 2017 and 2016, different assumptions could change the estimated fair values and, therefore, impairment charges could be required, which could be material to the consolidated financial statements.

[0000833444-18-000053:mdna:176]
The Company reviews long-lived assets, including tangible assets and other intangible assets with definitive lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of software to be sold, leased, or marketed."  ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. ASC 350-30 requires intangible assets acquired in a business combination that are used in research and development activities to be considered indefinite lived until the completion or abandonment of the associated research and development efforts. During the period that those assets are considered indefinite lived, they shall not be amortized but shall be tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired.  If the carrying amount of an intangible asset exceeds its fair value, an entity shall recognize an impairment loss in an amount equal to that excess. ASC 985-20 requires the unamortized capitalized costs of a computer software product be compared to the net realizable value of that product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset shall be written off.

[0000833444-18-000053:mdna:177]
In fiscal 2018, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2018. As a result, the Company reviewed the long-lived assets for impairment and recorded $42 million of asset impairment charges within restructuring and impairment costs in the consolidated statements of income. Of the total impairment charges, $31 million related to the Global Products segment, $6 million related to the Power Solutions segment and $5 million related to Corporate assets. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-18-000053:mdna:178]
In fiscal 2017, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2017. As a result, the Company reviewed the long-lived assets for impairment and recorded $77 million of asset impairment charges within restructuring and impairment costs on the consolidated statements of income. Of the total impairment charges, $30 million related to the Building Solutions North America segment, $20 million related to the Global Products segment, $19 million related to Corporate assets, $7 million related to the Power Solutions segment and $1 million related to the Building Solutions Asia Pacific segment. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-18-000053:mdna:179]
In fiscal 2016, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2016. As a result, the Company reviewed the long-lived assets for impairment and recorded $103 million of asset impairment charges within restructuring and impairment costs on the consolidated statements of income. Of the total impairment charges, $64 million related to the Power Solutions segment, $24 million related to Corporate assets, $8 million related to the Global Products segment, $4 million related to the Building Solutions Asia Pacific segment and $3 million related to the Building Solutions EMEA/LA segment.  In addition, the Company recorded $87 million of asset impairments within discontinued operations related to Adient in fiscal 2016. Refer to Note 16, "Significant

[0000833444-18-000053:mdna:180]
Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-18-000053:mdna:181]
Investments in partially-owned affiliates ("affiliates") at September 30, 2018 were $1.3 billion, $0.1 billion higher than the prior year. The increase was primarily due to equity income from partially-owned affiliates in the Power Solutions business and the   Johnson Controls - Hitachi joint venture.

[0000833444-18-000053:mdna:182]
LIQUIDITY AND CAPITAL RESOURCES

[0000833444-18-000053:mdna:183]
Working Capital

[0000833444-18-000053:mdna:184]
|  | September 30, 2018 |  | September 30, 2017 |  |  |
| (in millions) |  |  | Change |
| Current assets | $ | 11,823 |  |  | $ | 12,292 |  |  |  |
| Current liabilities | (11,250 | ) |  | (11,854 | ) |  |  |
|  | 573 |  |  | 438 |  |  | 31 | % |
| Less: Cash | (200 | ) |  | (321 | ) |  |  |
| Add: Short-term debt | 1,315 |  |  | 1,214 |  |  |  |
| Add: Current portion of long-term debt | 26 |  |  | 394 |  |  |  |
| Less: Assets held for sale | — |  |  | (189 | ) |  |  |
| Add: Liabilities held for sale | — |  |  | 72 |  |  |  |
| Working capital (as defined) | $ | 1,714 |  |  | $ | 1,608 |  |  | 7 | % |
| Accounts receivable | $ | 7,065 |  |  | $ | 6,666 |  |  | 6 | % |
| Inventories | 3,224 |  |  | 3,209 |  |  | — | % |
| Accounts payable | 4,644 |  |  | 4,271 |  |  | 9 | % |

[0000833444-18-000053:mdna:185]
| • | The Company defines working capital as current assets less current liabilities, excluding cash, short-term debt, the current portion of long-term debt, and the current portions of assets and liabilities held for sale. Management believes that this measure of working capital, which excludes financing-related items and businesses to be divested, provides a more useful measurement of the Company’s operating performance. |

[0000833444-18-000053:mdna:186]
| • | The increase in working capital at September 30, 2018 as compared to September 30, 2017, was primarily due to an increase in accounts receivable due to organic sales growth, partially offset by an increase in accounts payable due to timing and mix of supplier payments. |

[0000833444-18-000053:mdna:187]
| • | The Company’s days sales in accounts receivable at September 30, 2018 were 66, a slight increase from 65 at September 30, 2017. There has been no significant adverse change in the level of overdue receivables or changes in revenue recognition methods. |

[0000833444-18-000053:mdna:188]
| • | The Company’s inventory turns for the year ended September 30, 2018 were slightly higher than the comparable period ended September 30, 2017 primarily due to changes in inventory production levels. |

[0000833444-18-000053:mdna:189]
| • | Days in accounts payable at September 30, 2018 were 73 days, higher than 70 days at the comparable period ended September 30, 2017. |

[0000833444-18-000053:mdna:190]
43

[0000833444-18-000053:mdna:191]
Cash Flows

[0000833444-18-000053:mdna:192]
|  | Year Ended September 30, |
| (in millions) | 2018 |  | 2017 |
| Cash provided by operating activities | $ | 2,513 |  |  | $ | 31 |  |
| Cash provided (used) by investing activities | 1,215 |  |  | (1,137 | ) |
| Cash provided (used) by financing activities | (3,752 | ) |  | 698 |  |
| Capital expenditures | (1,030 | ) |  | (1,343 | ) |

[0000833444-18-000053:mdna:193]
| • | The increase in cash provided by operating activities was primarily due to favorable movements in working capital balances, higher prior year income tax payments related to the Adient spin-off ($1.2 billion in the first quarter of fiscal 2017), and prior year operating cash outflows in the Automotive Experience business before the Adient spin-off, change in control pension payments and transaction/integration related payments. |

[0000833444-18-000053:mdna:194]
| • | The increase in cash provided by investing activities was primarily due to net cash proceeds received from the Scott Safety business divestiture in the current year and a decrease in capital expenditures. |

[0000833444-18-000053:mdna:195]
| • | The increase in cash used by financing activities was primarily due to higher current year repayments of long-term debt. |

[0000833444-18-000053:mdna:196]
| • | The decrease in capital expenditures in the current year is primarily related to lower capital investments in the current year in the Building Technologies & Solutions and Power Solution businesses, and prior year capital investments in the Automotive Experience business before the Adient spin-off. |

[0000833444-18-000053:mdna:197]
Capitalization

[0000833444-18-000053:mdna:198]
|  | September 30, 2018 |  | September 30, 2017 |  |  |
| (in millions) |  |  | Change |
| Short-term debt | $ | 1,315 |  |  | $ | 1,214 |  |  |  |
| Current portion of long-term debt | 26 |  |  | 394 |  |  |  |
| Long-term debt | 9,654 |  |  | 11,964 |  |  |  |
| Total debt | $ | 10,995 |  |  | $ | 13,572 |  |  | -19 | % |
| Less: cash and cash equivalents | 200 |  |  | 321 |  |  |  |
| Total net debt | $ | 10,795 |  |  | $ | 13,251 |  |  | -19 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 21,164 |  |  | 20,447 |  |  | 4 | % |
| Total capitalization | $ | 31,959 |  |  | $ | 33,698 |  |  | -5 | % |
| Total net debt as a % of total capitalization | 33.8 | % |  | 39.3 | % |  |  |

[0000833444-18-000053:mdna:199]
| • | Net debt and net debt as a percentage of total capitalization are non-GAAP financial measures. The Company believes the percentage of total net debt to total capitalization is useful to understanding the Company’s financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders. |

[0000833444-18-000053:mdna:200]
| • | The Company believes its capital resources and liquidity position at September 30, 2018 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, stock repurchases, minimum pension contributions, debt maturities and any potential acquisitions in fiscal 2019 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company and Tyco International Holding S.a.r.L.'s ("TSarl") are unable to issue commercial paper, they would have the ability to draw on their $2.0 billion and $1.25 billion revolving credit facilities, respectively. Both facilities mature in August 2020. There were no draws on the revolving credit facilities as of September 30, 2018 and 2017. The Company also selectively makes use of short-term credit lines other than its revolving credit facilities at the Company and TSarl. The Company estimates that, as of September 30, 2018, it could borrow up to $2.0 billion based on average borrowing levels during the fourth |

[0000833444-18-000053:mdna:201]
quarter of fiscal 2018 on committed credit lines. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future.

[0000833444-18-000053:mdna:202]
| • | The Company’s debt financial covenant in its revolving credit facility requires a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. TSarl's revolving credit facility contains customary terms and conditions, and a financial covenant that limits the ratio of TSarl's debt to earnings before interest, taxes, depreciation, and amortization as adjusted for certain items set forth in the agreement to 3.5x. TSarl's revolving credit facility also limits its ability to incur subsidiary debt or grant liens on its and its subsidiaries' property. As of September 30, 2018, the Company and TSarl were in compliance with all covenants and other requirements set forth in their credit agreements and the indentures, governing their notes, and expect to remain in compliance for the foreseeable future. None of the Company’s or TSarl's debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the respective borrower's credit rating. |

[0000833444-18-000053:mdna:203]
| • | The Company earns a significant amount of its income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances including a limited accrual related to fiscal 2018 U.S. Tax Reform. In fiscal 2018, due to U.S. Tax Reform, the Company provided income tax related to the change in the Company’s assertion over the outside basis difference of certain non-U.S. subsidiaries owned directly or indirectly by U.S. subsidiaries. Under U.S. Tax Reform, the U.S. has enacted a tax system that provides an exemption for dividends received by U.S. corporations from 10% or more owned non-U.S. corporations. However, certain non-U.S, U.S. state and withholding taxes may still apply when closing an outside basis difference via distribution or other transactions. In addition, in fiscal 2017, the Company provided income tax expense related to a change in the Company’s assertion over the outside basis difference of the Scott Safety business as a result of the pending divestiture as well as the outside basis of certain nonconsolidated subsidiaries. Also, in fiscal 2016, the Company provided income tax expense related to a change in the Company's assertion over a portion of the permanently reinvested earnings as a result of the planned spin-off of the Adient business. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. Except as noted, the Company’s intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at the Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings. |

[0000833444-18-000053:mdna:204]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2018 and recorded $263 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2018 restructuring plan will reduce annual operating costs by approximately $300 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in 2020. For fiscal 2018, the savings, net of execution costs, were approximately 25% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in 2020. The restructuring plan reserve balance of $174 million at September 30, 2018 is expected to be paid in cash. |

[0000833444-18-000053:mdna:205]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2017 and recorded $367 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost |

[0000833444-18-000053:mdna:206]
45

[0000833444-18-000053:mdna:207]
reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2017 restructuring plan will reduce annual operating costs from continuing operations by approximately $280 million, which is primarily the result of lower cost of sales and SG&A expenses due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in fiscal 2019. For fiscal 2018, the savings, net of execution costs, were approximately 85% of the expected annual operating cost reduction. The restructuring actions are expected to be substantially complete in fiscal 2019. The restructuring plan reserve balance of $80 million at September 30, 2018 is expected to be paid in cash.

[0000833444-18-000053:mdna:208]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations to address the softness in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2016 and recorded $288 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments and change-in-control payments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2016 restructuring plan will reduce annual operating costs from continuing operations by approximately $135 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in fiscal 2019. For fiscal 2018, the savings, net of execution costs, were approximately 75% of the expected annual operating cost reduction. The restructuring actions are expected to be substantially complete in fiscal 2019. The restructuring plan reserve balance of $73 million at September 30, 2018 is expected to be paid in cash. |

[0000833444-18-000053:mdna:209]
A summary of the Company’s significant contractual obligations for continuing operations as of September 30, 2018 is as follows (in millions):

[0000833444-18-000053:mdna:210]
|  | Total |  | 2019 |  | 2020-2021 |  | 2022-2023 |  | 2024and Beyond |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Long-term debt(including capital lease obligations)* | $ | 9,724 |  |  | $ | 26 |  |  | $ | 2,489 |  |  | $ | 1,973 |  |  | $ | 5,236 |  |
| Interest on long-term debt(including capital lease obligations)* | 5,399 |  |  | 317 |  |  | 560 |  |  | 476 |  |  | 4,046 |  |
| Operating leases | 1,200 |  |  | 348 |  |  | 492 |  |  | 263 |  |  | 97 |  |
| Purchase obligations | 2,506 |  |  | 1,490 |  |  | 731 |  |  | 262 |  |  | 23 |  |
| Pension and postretirement contributions | 476 |  |  | 100 |  |  | 75 |  |  | 76 |  |  | 225 |  |
| Tax indemnification liabilities** | 255 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total contractual cash obligations | $ | 19,560 |  |  | $ | 2,281 |  |  | $ | 4,347 |  |  | $ | 3,050 |  |  | $ | 9,627 |  |

[0000833444-18-000053:mdna:211]
* Refer to Note 9, "Debt and Financing Arrangements," of the notes to consolidated financial statements for information related to the Company's long-term debt.

[0000833444-18-000053:mdna:212]
** As a result of the Tyco Merger in the fourth quarter of fiscal 2016, the Company recorded as part of the acquired liabilities of Tyco $290 million of post sale contingent tax indemnification liabilities which is generally recorded within other noncurrent liabilities in the consolidated statements of financial position. The liabilities are recorded at fair value and relate to certain tax related matters borne by the buyer of previously divested subsidiaries of Tyco which Tyco has indemnified certain parties and the amounts are probable of being paid. At September 30, 2018 and 2017, the Company recorded liabilities of $255 million and $290 million, respectively. Of the $255 million recorded as of September 30, 2018, $235 million is related to prior divested businesses and the remainder relates to Tyco’s tax sharing agreements from its 2007 and 2012 spin-off transactions.  The payments due by period are not presented due to uncertainty as to when these liabilities will be settled or paid. These are certain guarantees or indemnifications extended among Tyco, Medtronic, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 separation and tax sharing agreements.

[0000833444-18-000053:mdna:213]
46

[0000833444-18-000053:mdna:214]
CRITICAL ACCOUNTING ESTIMATES AND POLICIES

[0000833444-18-000053:mdna:215]
The Company prepares its consolidated financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). This requires management to make estimates and assumptions that affect reported amounts and related disclosures. Actual results could differ from those estimates. The following policies are considered by management to be the most critical in understanding the judgments that are involved in the preparation of the Company’s consolidated financial statements and the uncertainties that could impact the Company’s results of operations, financial position and cash flows.

[0000833444-18-000053:mdna:216]
Revenue Recognition

[0000833444-18-000053:mdna:217]
The Building Technologies & Solutions business recognizes revenue from certain long-term contracts over the contractual period under the percentage-of-completion ("POC") method of accounting. This method of accounting recognizes sales and gross profit as work is performed based on the relationship between actual costs incurred and total estimated costs at completion. Recognized revenues that will not be billed under the terms of the contract until a later date are recorded primarily in accounts receivable. Likewise, contracts where billings to date have exceeded recognized revenues are recorded primarily in deferred revenue. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. Sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. Claims against customers are recognized as revenue upon settlement. The use of the POC method of accounting involves considerable use of estimates in determining revenues, costs and profits and in assigning the amounts to accounting periods. The periodic reviews have not resulted in adjustments that were significant to the Company’s results of operations. The Company continually evaluates all of the assumptions, risks and uncertainties inherent with the application of the POC method of accounting.

[0000833444-18-000053:mdna:218]
The Building Technologies & Solutions business enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized on a straight-line basis over the respective contract term.

[0000833444-18-000053:mdna:219]
The Building Technologies & Solutions business also sells certain heating, ventilating and air conditioning ("HVAC") and refrigeration products and services in bundled arrangements, where multiple products and/or services are involved. Significant deliverables within these arrangements include equipment, commissioning, service labor and extended warranties. Approximately four to twelve months separate the timing of the first deliverable until the last piece of equipment is delivered, and there may be extended warranty arrangements with duration of one to five years commencing upon the end of the standard warranty period. In addition, the Buildings business sells security monitoring systems that may have multiple elements, including equipment, installation, monitoring services and maintenance agreements. Revenues associated with sale of equipment and related installations are recognized once delivery, installation and customer acceptance is completed, while the revenue for monitoring and maintenance services are recognized as services are rendered. In accordance with ASU No. 2009-13, "Revenue Recognition (Topic 605): Multiple-Deliverable Revenue Arrangements - A Consensus of the FASB Emerging Issues Task Force," the Company divides bundled arrangements into separate deliverables and revenue is allocated to each deliverable based on the relative selling price method. In order to estimate relative selling price, market data and transfer price studies are utilized. Revenue recognized for security monitoring equipment and installation is limited to the lesser of their allocated amounts under the estimated selling price hierarchy or the non-contingent up-front consideration received at the time of installation, since collection of future amounts under the arrangement with the customer is contingent upon the delivery of monitoring and maintenance services. For transactions in which the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized on a straight-line basis over the contract term. Non-refundable fees received in connection with the initiation of a monitoring contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the customer relationship.

[0000833444-18-000053:mdna:220]
In all other cases, the Company recognizes revenue at the time title passes to the customer or as services are performed.

[0000833444-18-000053:mdna:221]
47

[0000833444-18-000053:mdna:222]
Goodwill and Indefinite-Lived Intangible Assets

[0000833444-18-000053:mdna:223]
Goodwill reflects the cost of an acquisition in excess of the fair values assigned to identifiable net assets acquired. The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s reportable segments or one level below the reportable segments in certain instances, using a fair value method based on management’s judgments and assumptions or third party valuations. The fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. In estimating the fair value, the Company uses multiples of earnings based on the average of published multiples of earnings of comparable entities with similar operations and economic characteristics and applies to the Company's average of historical and future financial results. In certain instances, the Company uses discounted cash flow analyses or estimated sales price to further support the fair value estimates. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The estimated fair value is then compared with the carrying amount of the reporting unit, including recorded goodwill. The Company is subject to financial statement risk to the extent that the carrying amount exceeds the estimated fair value.  During the fourth quarter of fiscal 2018, the Company changed the date of its annual goodwill impairment test from September 30 to July 31. The change was made to more closely align the impairment testing date with the Company’s long-term planning and forecasting process. The change in the annual impairment testing date did not delay, accelerate or avoid an impairment charge. The Company has determined this change in accounting principle is preferable and does not result in adjustments to the Company’s financial statements when applied retrospectively. Refer to Note 7, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for information regarding the goodwill impairment testing performed in the fourth quarters of fiscal years 2018, 2017 and 2016.

[0000833444-18-000053:mdna:224]
Indefinite-lived intangible assets are also subject to at least annual impairment testing. Indefinite-lived intangible assets consist of trademarks and tradenames and are tested for impairment using a relief-from-royalty method. A considerable amount of management judgment and assumptions are required in performing the impairment tests.

[0000833444-18-000053:mdna:225]
Impairment of Long-Lived Assets

[0000833444-18-000053:mdna:226]
The Company reviews long-lived assets, including tangible assets and other intangible assets with definitive lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of software to be sold, leased, or marketed." ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. ASC 350-30 requires intangible assets acquired in a business combination that are used in research and development activities be considered indefinite lived until the completion or abandonment of the associated research and development efforts. During the period that those assets are considered indefinite lived, they shall not be amortized but shall be tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired. If the carrying amount of an intangible asset exceeds its fair value, an entity shall recognize an impairment loss in an amount equal to that excess. ASC 985-20 requires the unamortized capitalized costs of a computer software product be compared to the net realizable value of that product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset shall be written off. Refer to Note 17, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for information regarding the impairment testing performed in fiscal years 2018, 2017 and 2016.

[0000833444-18-000053:mdna:227]
Employee Benefit Plans

[0000833444-18-000053:mdna:228]
The Company provides a range of benefits to its employees and retired employees, including pensions and postretirement benefits. Plan assets and obligations are measured annually, or more frequently if there is a significant remeasurement event, based on the Company’s measurement date utilizing various actuarial assumptions such as discount rates, assumed rates of return, compensation increases, turnover rates and health care cost trend rates as of that date. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends when appropriate.

[0000833444-18-000053:mdna:229]
The Company utilizes a mark-to-market approach for recognizing pension and postretirement benefit expenses, including measuring the market related value of plan assets at fair value and recognizing actuarial gains and losses in the fourth quarter of each fiscal year or at the date of a remeasurement event. Refer to Note 15, "Retirement Plans," of the notes to consolidated financial statements for disclosure of the Company's pension and postretirement benefit plans.

[0000833444-18-000053:mdna:230]
U.S. GAAP requires that companies recognize in the statement of financial position a liability for defined benefit pension and postretirement plans that are underfunded or unfunded, or an asset for defined benefit pension and postretirement plans that are overfunded. U.S. GAAP also requires that companies measure the benefit obligations and fair value of plan assets that determine a benefit plan’s funded status as of the date of the employer’s fiscal year end.

[0000833444-18-000053:mdna:231]
The Company considers the expected benefit payments on a plan-by-plan basis when setting assumed discount rates. As a result, the Company uses different discount rates for each plan depending on the plan jurisdiction, the demographics of participants and the expected timing of benefit payments. For the U.S. pension and postretirement plans, the Company uses a discount rate provided by an independent third party calculated based on an appropriate mix of high quality bonds. For the non-U.S. pension and postretirement plans, the Company consistently uses the relevant country specific benchmark indices for determining the various discount rates. The Company’s weighted average discount rate on U.S. pension plans was 4.10% and 3.80% at September 30, 2018 and 2017, respectively. The Company’s weighted average discount rate on postretirement plans was 3.80% and 3.70% at September 30, 2018 and 2017, respectively. The Company’s weighted average discount rate on non-U.S. pension plans was 2.45% and 2.40% at September 30, 2018 and 2017, respectively.

[0000833444-18-000053:mdna:232]
In estimating the expected return on plan assets, the Company considers the historical returns on plan assets, adjusted for forward-looking considerations, inflation assumptions and the impact of the active management of the plans’ invested assets. Reflecting the relatively long-term nature of the plans’ obligations, approximately 35% of the plans’ assets are invested in equity securities and 56% in fixed income securities, with the remainder primarily invested in alternative investments. For the years ending September 30, 2018 and 2017, the Company’s expected long-term return on U.S. pension plan assets used to determine net periodic benefit cost was 7.50%. The actual rate of return on U.S. pension plans was below 7.50% in fiscal year 2018 and above 7.50% in fiscal year 2017. For the years ending September 30, 2018 and 2017, the Company’s weighted average expected long-term return on non-U.S. pension plan assets was 5.35% and 4.60%, respectively. The actual rate of return on non-U.S. pension plans was   below 5.35% in fiscal year 2018 and above 4.60% in fiscal year 2017. For the years ending September 30, 2018 and 2017, the Company’s weighted average expected long-term return on postretirement plan assets was 5.65% and 5.60%, respectively. The actual rate of return on postretirement plan assets was below 5.65% in fiscal year 2018 and above 5.60% in fiscal year 2017.

[0000833444-18-000053:mdna:233]
Beginning in fiscal 2019, the Company believes the long-term rate of return will approximate 7.10%, 5.20% and 5.65% for U.S. pension, non-U.S. pension and postretirement plans, respectively. Any differences between actual investment results and the expected long-term asset returns will be reflected in net periodic benefit costs in the fourth quarter of each fiscal year or at the date of a significant remeasurement event. If the Company’s actual returns on plan assets are less than the Company’s expectations, additional contributions may be required.

[0000833444-18-000053:mdna:234]
In fiscal 2018, total employer contributions to the defined benefit pension plans were $53 million, of which $18 million were voluntary contributions made by the Company. The Company expects to contribute approximately $85 million in cash to its defined benefit pension plans in fiscal 2019. In fiscal 2018, total employer contributions to the postretirement plans were $4 million. The Company expects to contribute approximately $15 million in cash to its postretirement plans in fiscal 2019.

[0000833444-18-000053:mdna:235]
Based on information provided by its independent actuaries and other relevant sources, the Company believes that the assumptions used are reasonable; however, changes in these assumptions could impact the Company’s financial position, results of operations or cash flows.

[0000833444-18-000053:mdna:236]
Loss Contingencies

[0000833444-18-000053:mdna:237]
Accruals are recorded for various contingencies including legal proceedings, environmental matters, self-insurance and other claims that arise in the normal course of business. The accruals are based on judgment, the probability of losses and, where applicable, the consideration of opinions of internal and/or external legal counsel and actuarially determined estimates. Additionally, the Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-18-000053:mdna:238]
The Company is subject to laws and regulations relating to protecting the environment. The Company provides for expenses associated with environmental remediation obligations when such amounts are probable and can be reasonably estimated. Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements.

[0000833444-18-000053:mdna:239]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company records receivables from third party insurers when recovery has been determined to be probable. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-18-000053:mdna:240]
Asbestos-Related Contingencies and Insurance Receivables

[0000833444-18-000053:mdna:241]
The Company and certain of its subsidiaries along with numerous other companies are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from  2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-18-000053:mdna:242]
In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable. The Company's estimate of asbestos-related insurance recoveries represents estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims discounted to present value. In determining the amount of insurance recoverable, the Company considers available insurance, allocation methodologies, solvency and creditworthiness of the insurers. Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements for a discussion on management's judgments applied in the recognition and measurement of asbestos-related assets and liabilities.

[0000833444-18-000053:mdna:243]
Product Warranties

[0000833444-18-000053:mdna:244]
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. A typical warranty program requires that the Company replace defective products within a specified time period from the date of sale. The Company records an estimate of future warranty-related costs based on actual historical return rates and other known factors. Based on analysis of return rates and other factors, the Company’s warranty provisions are adjusted as necessary. At September 30, 2018, the Company had recorded $392 million of warranty reserves for continuing operations, including extended warranties for which deferred revenue is recorded. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different than those estimates. Refer to Note 21, "Guarantees," of the notes to consolidated financial statements for disclosure of the Company's product warranty liabilities.

[0000833444-18-000053:mdna:245]
Income Taxes

[0000833444-18-000053:mdna:246]
The Company accounts for income taxes in accordance with ASC 740, "Income Taxes." Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and other loss carryforwards. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company records a valuation allowance that primarily represents non-U.S. operating and other loss carryforwards for which realization is uncertain. Management judgment is required in determining the Company’s provision for income taxes, deferred tax assets and liabilities, and the valuation allowance recorded against the Company’s net deferred tax assets. In calculating the provision for income taxes on an interim basis, the Company uses an estimate of the annual effective tax rate based upon the facts and circumstances known at each interim period. On a quarterly basis, the actual effective tax rate is adjusted as appropriate based upon the actual results as compared to those forecasted at the beginning of the fiscal year.

[0000833444-18-000053:mdna:247]
The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary. At September 30, 2018, the Company had a valuation allowance of $5.2 billion for continuing operations, of which $4.5 billion relates to net operating loss carryforwards primarily in Australia, Belgium, Brazil, China, France, Luxembourg, Spain, Switzerland and the United Kingdom for which sustainable taxable income has not been demonstrated; and $700 million for other deferred tax assets.

[0000833444-18-000053:mdna:248]
The Company is subject to income taxes in the U.S. and numerous non-U.S. jurisdictions. Judgment is required in determining its worldwide provision for income taxes and recording the related assets and liabilities. In the ordinary course of the Company’s business, there are many transactions and calculations where the ultimate tax determination is uncertain. The Company is regularly under audit by tax authorities. At September 30, 2018, the Company had unrecognized tax benefits of $2.4 billion.

[0000833444-18-000053:mdna:249]
The Company does not generally provide additional U.S. or non-U.S. income taxes on outside basis differences of consolidated subsidiaries included in shareholders’ equity attributable to Johnson Controls International plc, except in limited circumstances including anticipated taxation on planned divestitures.  The reduction of the outside basis differences via the sale or liquidation of these subsidiaries and/or distributions could create taxable income.  The Company’s intent is to reduce the outside basis differences only when it would be tax efficient.  Refer to "Capitalization" within the "Liquidity and Capital Resources" section for discussion of U.S. and non-U.S. cash projections.

[0000833444-18-000053:mdna:250]
Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements for the Company's income tax disclosures.

[0000833444-18-000053:mdna:251]
NEW ACCOUNTING PRONOUNCEMENTS

[0000833444-18-000053:mdna:252]
Refer to the "New Accounting Pronouncements" section within Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements.

[0000833444-18-000053:mdna:253]
RISK MANAGEMENT

[0000833444-18-000053:mdna:254]
The Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities, interest rates and stock-based compensation. All hedging transactions are authorized and executed pursuant to clearly defined policies and procedures, which strictly prohibit the use of financial instruments for speculative purposes. At the inception of the hedge, the Company assesses the effectiveness of the hedge instrument and designates the hedge instrument as either (1) a hedge of a recognized asset or liability or of a recognized firm commitment (a fair value hedge), (2) a hedge of a forecasted transaction or of the variability of cash flows to be received or paid related to an unrecognized asset or liability (a cash flow hedge) or (3) a hedge of a net investment in a non-U.S. operation (a net investment hedge). The Company performs hedge effectiveness testing on an ongoing basis depending on the type of hedging instrument used. All other derivatives not designated as hedging instruments under ASC 815, "Derivatives and Hedging," are revalued in the consolidated statements of income.

[0000833444-18-000053:mdna:255]
For all foreign currency derivative instruments designated as cash flow hedges, retrospective effectiveness is tested on a monthly basis using a cumulative dollar offset test. The fair value of the hedged exposures and the fair value of the hedge instruments are revalued, and the ratio of the cumulative sum of the periodic changes in the value of the hedge instruments to the cumulative sum of the periodic changes in the value of the hedge is calculated. The hedge is deemed as highly effective if the ratio is between 80% and 125%. For commodity derivative contracts designated as cash flow hedges, effectiveness is tested using a regression calculation. Ineffectiveness is minimal as the Company aligns most of the critical terms of its derivatives with the supply contracts.

[0000833444-18-000053:mdna:256]
For net investment hedges, the Company assesses its net investment positions in the non-U.S. operations and compares it with the outstanding net investment hedges on a quarterly basis. The hedge is deemed effective if the aggregate outstanding principal of the hedge instruments designated as the net investment hedge in a non-U.S. operation does not exceed the Company’s net investment positions in the respective non-U.S. operation.

[0000833444-18-000053:mdna:257]
The Company selectively uses interest rate swaps to reduce market risk associated with changes in interest rates for its fixed-rate bonds. At September 30, 2018, the Company did not have any outstanding interest rate swaps.  The Company assesses retrospective and prospective effectiveness and records any measured ineffectiveness in the consolidated statements of income on a monthly basis.

[0000833444-18-000053:mdna:258]
Equity swaps and any other derivative instruments not designated as hedging instruments under ASC 815 require no assessment of effectiveness.

[0000833444-18-000053:mdna:259]
A discussion of the Company’s accounting policies for derivative financial instruments is included in Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements, and further disclosure relating to derivatives and hedging activities is included in Note 10, "Derivative Instruments and Hedging Activities," and Note 11, "Fair Value Measurements," of the notes to consolidated financial statements.

[0000833444-18-000053:mdna:260]
51

[0000833444-18-000053:mdna:261]
Foreign Exchange

[0000833444-18-000053:mdna:262]
The Company has manufacturing, sales and distribution facilities around the world and thus makes investments and enters into transactions denominated in various foreign currencies. In order to maintain strict control and achieve the benefits of the Company’s global diversification, foreign exchange exposures for each currency are netted internally so that only its net foreign exchange exposures are, as appropriate, hedged with financial instruments.

[0000833444-18-000053:mdna:263]
The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. The Company primarily enters into foreign currency exchange contracts to reduce the earnings and cash flow impact of the variation of non-functional currency denominated receivables and payables. Gains and losses resulting from hedging instruments offset the foreign exchange gains or losses on the underlying assets and liabilities being hedged. The maturities of the forward exchange contracts generally coincide with the settlement dates of the related transactions. Realized and unrealized gains and losses on these contracts are recognized in the same period as gains and losses on the hedged items. The Company also selectively hedges anticipated transactions that are subject to foreign exchange exposure, primarily with foreign currency exchange contracts, which are designated as cash flow hedges in accordance with ASC 815.

[0000833444-18-000053:mdna:264]
The Company has entered into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of debt obligations are reflected in the accumulated other comprehensive income ("AOCI") account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally.

[0000833444-18-000053:mdna:265]
At September 30, 2018 and 2017, the Company estimates that an unfavorable 10% change in the exchange rates would have decreased net unrealized gains by approximately $212 million and $330 million, respectively.

[0000833444-18-000053:mdna:266]
Interest Rates

[0000833444-18-000053:mdna:267]
From time to time, the Company may use interest rate swaps to offset its exposure to interest rate movements. In accordance with ASC 815, these outstanding swaps qualify and are designated as fair value hedges. The Company had no outstanding interest rate swaps at September 30, 2018 and 2017, respectively. A 10% increase in the average cost of the Company’s variable rate debt would have resulted in an unfavorable change in pre-tax interest expense of approximately $5 million and $13 million for the year ended September 30, 2018 and 2017, respectively.

[0000833444-18-000053:mdna:268]
Commodities

[0000833444-18-000053:mdna:269]
The Company uses commodity hedge contracts in the financial derivatives market in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. As a cash flow hedge, gains and losses resulting from the hedging instruments offset the gains or losses on purchases of the underlying commodities that will be used in the business. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities.

[0000833444-18-000053:mdna:270]
ENVIRONMENTAL, HEALTH AND SAFETY AND OTHER MATTERS

[0000833444-18-000053:mdna:271]
The Company’s global operations are governed by environmental laws and worker safety laws. Under various circumstances, these laws impose civil and criminal penalties and fines, as well as injunctive and remedial relief, for noncompliance and require remediation at sites where Company-related substances have been released into the environment.

[0000833444-18-000053:mdna:272]
The Company has expended substantial resources globally, both financial and managerial, to comply with applicable environmental laws and worker safety laws and to protect the environment and workers. The Company believes it is in substantial compliance with such laws and maintains procedures designed to foster and ensure compliance. However, the Company has been, and in the future may become, the subject of formal or informal enforcement actions or proceedings regarding noncompliance with such laws or the remediation of Company-related substances released into the environment. Such matters typically are resolved with regulatory authorities through commitments to compliance, abatement or remediation programs and in some cases payment of penalties. Historically, neither such commitments nor penalties imposed on the Company have been material.

[0000833444-18-000053:mdna:273]
Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements for additional information.

[0000833444-18-000053:mdna:274]
QUARTERLY FINANCIAL DATA

[0000833444-18-000053:mdna:275]
| (in millions, except per share data)(quarterly amounts unaudited) | FirstQuarter |  | SecondQuarter |  | ThirdQuarter |  | FourthQuarter |  | FullYear |
| 2018 |  |  |  |  |  |  |  |  |  |
| Net sales | $ | 7,435 |  |  | $ | 7,475 |  |  | $ | 8,120 |  |  | $ | 8,370 |  |  | $ | 31,400 |  |
| Gross profit | 2,169 |  |  | 2,220 |  |  | 2,472 |  |  | 2,519 |  |  | 9,380 |  |
| Net income (1) | 271 |  |  | 483 |  |  | 804 |  |  | 825 |  |  | 2,383 |  |
| Net income attributable to Johnson Controls | 230 |  |  | 438 |  |  | 723 |  |  | 771 |  |  | 2,162 |  |
| Earnings per share (2) |  |  |  |  |  |  |  |  |  |
| Basic | 0.25 |  |  | 0.47 |  |  | 0.78 |  |  | 0.83 |  |  | 2.34 |  |
| Diluted | 0.25 |  |  | 0.47 |  |  | 0.78 |  |  | 0.83 |  |  | 2.32 |  |
| 2017 |  |  |  |  |  |  |  |  |  |
| Net sales | $ | 7,086 |  |  | $ | 7,267 |  |  | $ | 7,683 |  |  | $ | 8,136 |  |  | $ | 30,172 |  |
| Gross profit | 2,114 |  |  | 2,281 |  |  | 2,431 |  |  | 2,513 |  |  | 9,339 |  |
| Net income (loss) (3) | 378 |  |  | (115 | ) |  | 629 |  |  | 927 |  |  | 1,819 |  |
| Net income (loss) attributable to Johnson Controls | 329 |  |  | (148 | ) |  | 555 |  |  | 875 |  |  | 1,611 |  |
| Earnings (loss) per share (2) |  |  |  |  |  |  |  |  |  |
| Basic | 0.35 |  |  | (0.16 | ) |  | 0.59 |  |  | 0.94 |  |  | 1.72 |  |
| Diluted | 0.35 |  |  | (0.16 | ) |  | 0.59 |  |  | 0.93 |  |  | 1.71 |  |

[0000833444-18-000053:mdna:276]
| (1) | The fiscal 2018 first quarter net income includes a $114 million gain on sale of Scott Safety, $158 million of significant restructuring and impairment costs, and $50 million of transaction and integration costs. The fiscal 2018 second quarter net income includes $64 million of transaction and integration costs. The fiscal 2018 third quarter net income includes $51 million of transaction and integration costs. The fiscal 2018 fourth quarter net income includes $10 million of net mark-to-market gains on pension and postretirement plans, $105 million of significant restructuring and impairment costs, and $69 million of transaction and integration costs. The preceding amounts are stated on a pre-tax and pre-noncontrolling interest impact basis. |

[0000833444-18-000053:mdna:277]
| (2) | Due to the use of the weighted-average shares outstanding for each quarter for computing earnings per share, the sum of the quarterly per share amounts may not equal the per share amount for the year. |

[0000833444-18-000053:mdna:278]
| (3) | The fiscal 2017 first quarter net income includes $117 million of mark-to-market gains on pension plans, $78 million of significant restructuring and impairment costs, and $213 million of transaction, integration and separation costs. The fiscal 2017 second quarter net loss includes $18 million of mark-to-market gains on pension plans, $99 million of significant restructuring and impairment costs, and $138 million of transaction and integration costs. The fiscal 2017 third quarter net income includes $45 million of mark-to-market losses on pension plans, $49 million of significant restructuring and impairment costs, and $70 million of transaction and integration costs The fiscal 2017 fourth quarter net income includes $330 million of net mark-to-market gains on pension and postretirement plans, $141 million of significant restructuring and impairment costs, $90 million of integration costs and $50 million for an unfavorable arbitration award. The preceding amounts are stated on a pre-tax and pre-noncontrolling interest impact basis and include both continuing and discontinued operations activity. |
