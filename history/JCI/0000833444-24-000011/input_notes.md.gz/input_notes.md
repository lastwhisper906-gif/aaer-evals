# JCI notes — 0000833444-24-000011


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-24-000011:notes:1]
BASIS OF PRESENTATION
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company," or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2023 filed with the SEC on December 14, 2023. The results of operations for the three-month period ended December 31, 2023 are not necessarily indicative of results for the Company’s 2024 fiscal year because of seasonal and other factors.

[0000833444-24-000011:notes:2]
[same as prior period, unchanged from 0000833444-23-000030:notes:3]

[0000833444-24-000011:notes:3]
[same as prior period, unchanged from 0000833444-23-000030:notes:4]

[0000833444-24-000011:notes:4]
[same as prior period, unchanged from 0000833444-23-000030:notes:5]

[0000833444-24-000011:notes:5]
[same as prior period, unchanged from 0000833444-23-000030:notes:6]

[0000833444-24-000011:notes:6]
[same as prior period, unchanged from 0000833444-23-000030:notes:7]

[0000833444-24-000011:notes:7]
[same as prior period, unchanged from 0000833444-23-000030:notes:8]

[0000833444-24-000011:notes:8]
Prior Period Revision – Statement of Cash Flows

[0000833444-24-000011:notes:9]
The Company revised the amounts previously reported as net proceeds from borrowings with maturities less than three months and proceeds from debt for certain short-term debt transactions that were incorrectly presented on a net basis within the financing activities section of the consolidated statements of cash flows for the three months ended December 30, 2022. 
The revision did not change cash provided by financing activities or the total decrease in cash, cash equivalents and restricted cash. The Company does not believe the impact of the incorrect presentation was material.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000833444-24-000011:notes:10]
NEW ACCOUNTING STANDARDS
Recently Adopted Accounting Pronouncements

[0000833444-24-000011:notes:11]
In September 2022, the FASB issued ASU 2022-04, "Disclosure of Supplier Finance Program Obligations," which is intended to enhance the transparency surrounding the use of supplier finance programs. Supplier finance programs may also be referred to as reverse factoring, payables finance, or structured payables arrangements. The amendments require a buyer that uses supplier finance programs to make annual disclosures about the program’s key terms, the balance sheet presentation of related amounts, the confirmed amount outstanding at the end of the period, and associated rollforward information. Only the amount outstanding at the end of the period must be disclosed in interim periods. The Company adopted the new disclosures, other than the rollforward disclosure, as required at the beginning of fiscal 2024. The rollforward disclosure will be adopted as required at the beginning of fiscal 2025.

[0000833444-24-000011:notes:12]
The Company maintains agreements with third-party financial institutions who offer voluntary supply chain financing ("SCF") programs to its suppliers. The SCF programs enable suppliers to sell their receivables to third-party financial institutions and receive payments earlier than the negotiated commercial terms between the suppliers and the Company, which generally range from 90 to 120 days. Suppliers sell receivables to third-party financial institutions on terms negotiated between the supplier and the respective third-party financial institution. The Company remains obligated to make payments under the terms of the original commercial arrangement regardless of whether the supplier receivable is sold, and does not pledge any assets as security or provide other forms of guarantees for the committed payment to the third-party financial institutions.

[0000833444-24-000011:notes:13]
Amounts outstanding related to SCF programs are included in accounts payable in the consolidated statements of financial position. Accounts payable included in the SCF programs were approximately $559 million and $566 million as of December 31, 2023, and September 30, 2023, respectively.

[0000833444-24-000011:notes:14]
Recently Issued Accounting Pronouncements

[0000833444-24-000011:notes:15]
In December 2023, the FASB issued ASU 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures," which is intended to enhance the transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. The amendments require that on an annual basis, entities disclose specific categories in the rate reconciliation and provide additional information for reconciling items that meet a quantitative threshold. In addition, the amendments require that entities disclose additional information about income taxes paid as well as additional disclosures of pretax income and income tax expense, and remove the requirement to disclose certain items that are no longer considered cost beneficial or relevant. The Company expects to adopt the new annual disclosures as required for fiscal 2026.

[0000833444-24-000011:notes:16]
In November 2023, the FASB issued ASU 2023-07, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures," which is intended to improve reportable segment disclosures, primarily through enhanced disclosures about significant segment expenses. In addition, the amendments enhance interim disclosure requirements, clarify circumstances in which an entity can disclose multiple segment measures of profit or loss, provide new segment disclosure requirements for entities with a single reportable segment and contain other disclosure requirements. The Company expects to adopt the new annual disclosures as required for fiscal 2025 and the interim disclosures as required beginning with the first quarter of fiscal 2026.

[0000833444-24-000011:notes:17]
Other recently issued accounting pronouncements are not expected to have a material impact on the Company's consolidated financial statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-24-000011:notes:18]
ACQUISITIONS AND DIVESTITURES
During the three months ended December 31, 2022, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $105 million, of which $79 million was paid as of December 31, 2022. In connection with the acquisitions, the Company recorded goodwill of $53 million within the Global Products segment and $2 million within the Building Solutions EMEA/LA segment.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-24-000011:notes:19]
ASSETS AND LIABILITIES HELD FOR SALE
During the three months ended December 31, 2022, the Company recorded impairment charges primarily due to reductions in the estimated fair values of its Global Retail business of $228 million and a business in the Building Solutions Asia Pacific segment of $60 million. Both businesses were classified as held for sale as of December 31, 2022. All of the impairments were recorded within restructuring and impairment costs in the consolidated statements of income.

[0000833444-24-000011:notes:20]
No assets and liabilities were classified as held for sale as of December 31, 2023 or September 30, 2023.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-24-000011:notes:21]
REVENUE RECOGNITION
Disaggregated Revenue

[0000833444-24-000011:notes:22]
[same as prior period, unchanged from 0000833444-23-000030:notes:26]

[0000833444-24-000011:notes:23]
|  |  | Three Months Ended December 31, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,518 |  |  | $ | 969 |  |  | $ | 2,487 |  |  | $ | 1,451 |  |  | $ | 916 |  |  | $ | 2,367 |  |
| Building Solutions EMEA/LA |  | 572 |  |  | 466 |  |  | 1,038 |  |  | 552 |  |  | 423 |  |  | 975 |  |
| Building Solutions Asia Pacific |  | 337 |  |  | 170 |  |  | 507 |  |  | 473 |  |  | 173 |  |  | 646 |  |
| Global Products |  | 2,062 |  |  | — |  |  | 2,062 |  |  | 2,080 |  |  | — |  |  | 2,080 |  |
| Total |  | $ | 4,489 |  |  | $ | 1,605 |  |  | $ | 6,094 |  |  | $ | 4,556 |  |  | $ | 1,512 |  |  | $ | 6,068 |  |

[0000833444-24-000011:notes:24]
[same as prior period, unchanged from 0000833444-23-000030:notes:29]

[0000833444-24-000011:notes:25]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| HVAC |  | $ | 1,418 |  |  | $ | 1,440 |  |  |  |  |  |
| Fire & Security |  | 547 |  |  | 570 |  |  |  |  |  |
| Industrial Refrigeration |  | 97 |  |  | 70 |  |  |  |  |  |
| Total |  | $ | 2,062 |  |  | $ | 2,080 |  |  |  |  |  |

[0000833444-24-000011:notes:26]
[same as prior period, unchanged from 0000833444-23-000030:notes:31]

[0000833444-24-000011:notes:27]
[same as prior period, unchanged from 0000833444-23-000030:notes:32]

[0000833444-24-000011:notes:28]
[same as prior period, unchanged from 0000833444-23-000030:notes:33]

[0000833444-24-000011:notes:29]
|  |  | Location of contract balances |  | December 31, 2023 |  | September 30, 2023 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,170 |  |  | $ | 2,370 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 4 |  |  | 12 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,122 |  |  | 1,996 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 306 |  |  | 297 |  |  |  |

[0000833444-24-000011:notes:30]
For the three months ended December 31, 2023 and 2022, the Company recognized revenue of $889 million and $846 million, respectively, that was included in the beginning of period contract liability balance.

[0000833444-24-000011:notes:31]
[same as prior period, unchanged from 0000833444-23-000030:notes:36]

[0000833444-24-000011:notes:32]
[same as prior period, unchanged from 0000833444-23-000030:notes:37]

[0000833444-24-000011:notes:33]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of December 31, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $19.9 billion, of which approximately 64% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.

[0000833444-24-000011:notes:34]
[same as prior period, unchanged from 0000833444-23-000030:notes:39]

[0000833444-24-000011:notes:35]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when these costs are recoverable. These costs consist primarily of sales commissions and design costs that relate to a contract or an anticipated contract that the Company expects to recover. Costs to obtain or fulfill a contract are capitalized and amortized over the period of contract performance.

[0000833444-24-000011:notes:36]
[same as prior period, unchanged from 0000833444-23-000030:notes:41]

[0000833444-24-000011:notes:37]
|  |  | December 31, 2023 |  | September 30, 2023 |  |  |
| Other current assets |  | $ | 183 |  |  | $ | 156 |  |  |  |
| Other noncurrent assets |  | 215 |  |  | 224 |  |  |  |
| Total |  | $ | 398 |  |  | $ | 380 |  |  |  |

[0000833444-24-000011:notes:38]
During the three months ended December 31, 2023 and 2022, the Company recognized amortization expense of $57 million and $61 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three months ended December 31, 2023 and 2022.


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0000833444-24-000011:notes:39]
ACCOUNTS RECEIVABLEThe Company sold $702 million and $409 million of accounts receivable under factoring agreements during the three months ended December 31, 2023 and 2022, respectively. Previously sold receivables still outstanding were $761 million and $681 million as of December 31, 2023 and September 30, 2023, respectively.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-24-000011:notes:40]
INVENTORIES
Inventories consisted of the following (in millions):

[0000833444-24-000011:notes:41]
|  | December 31, 2023 |  | September 30, 2023 |
| Raw materials and supplies | $ | 1,252 |  |  | $ | 1,203 |  |
| Work-in-process | 248 |  |  | 226 |  |
| Finished goods | 1,506 |  |  | 1,347 |  |
| Inventories | $ | 3,006 |  |  | $ | 2,776 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-24-000011:notes:42]
GOODWILL AND OTHER INTANGIBLE ASSETS
The changes in the carrying amount of goodwill in each of the Company’s reportable segments were as follows (in millions):

[0000833444-24-000011:notes:43]
|  |  | Three Months Ended December 31, 2023 |
|  |  | Building Solutions North America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | Total |
| Goodwill |  | $ | 10,040 |  |  | $ | 1,932 |  |  | $ | 1,179 |  |  | $ | 5,750 |  |  | 18,901 |  |
| Accumulated impairment loss |  | (659) |  |  | (47) |  |  | — |  |  | (259) |  |  | (965) |  |
| Balance at beginning of period |  | 9,381 |  |  | 1,885 |  |  | 1,179 |  |  | 5,491 |  |  | 17,936 |  |
| Foreign currency translation and other |  | 15 |  |  | 76 |  |  | 38 |  |  | 59 |  |  | 188 |  |
| Balance at end of period |  | $ | 9,396 |  |  | $ | 1,961 |  |  | $ | 1,217 |  |  | $ | 5,550 |  |  | $ | 18,124 |  |

[0000833444-24-000011:notes:44]
[same as prior period, unchanged from 0000833444-23-000030:notes:49]

[0000833444-24-000011:notes:45]
[same as prior period, unchanged from 0000833444-23-000030:notes:52]

[0000833444-24-000011:notes:46]
|  | December 31, 2023 |  | September 30, 2023 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Definite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,587 |  |  | $ | (849) |  |  | $ | 738 |  |  | $ | 1,575 |  |  | $ | (806) |  |  | $ | 769 |  |
| Customer relationships | 3,076 |  |  | (1,571) |  |  | 1,505 |  |  | 3,047 |  |  | (1,496) |  |  | 1,551 |  |
| Miscellaneous | 921 |  |  | (462) |  |  | 459 |  |  | 889 |  |  | (435) |  |  | 454 |  |
|  | 5,584 |  |  | (2,882) |  |  | 2,702 |  |  | 5,511 |  |  | (2,737) |  |  | 2,774 |  |
| Indefinite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,133 |  |  | — |  |  | 2,133 |  |  | 2,114 |  |  | — |  |  | 2,114 |  |
| Total intangible assets | $ | 7,717 |  |  | $ | (2,882) |  |  | $ | 4,835 |  |  | $ | 7,625 |  |  | $ | (2,737) |  |  | $ | 4,888 |  |

[0000833444-24-000011:notes:47]
Amortization of other intangible assets for the three months ended December 31, 2023 and 2022 was $122 million and $104 million, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000833444-24-000011:notes:48]
LEASES
The following table presents supplemental consolidated statement of financial position information (in millions):

[0000833444-24-000011:notes:49]
|  | Location of lease balances |  | December 31, 2023 |  | September 30, 2023 |
| Operating lease right-of-use assets | Other noncurrent assets |  | $ | 1,389 |  |  | $ | 1,389 |  |
| Operating lease liabilities - current | Other current liabilities |  | 327 |  |  | 318 |  |
| Operating lease liabilities - noncurrent | Other noncurrent liabilities |  | 1,079 |  |  | 1,086 |  |

[0000833444-24-000011:notes:50]
The following table presents supplemental noncash operating lease activity (in millions):

[0000833444-24-000011:notes:51]
|  |  |  |  | Three Months Ended December 31, |  |  |
|  |  |  |  |  |  | 2023 |  | 2022 |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  |  |  |  |  | $ | 77 |  |  | $ | 110 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-24-000011:notes:52]
DEBT AND FINANCING ARRANGEMENTS
Short-term debt consisted of the following (in millions):

[0000833444-24-000011:notes:53]
|  | December 31, |  | September 30, |
|  | 2023 |  | 2023 |
| Commercial paper | $ | 1,383 |  |  | $ | 200 |  |
| Term loans | 598 |  |  | 159 |  |
| Bank borrowings | 17 |  |  | 26 |  |
|  | $ | 1,998 |  |  | $ | 385 |  |
| Weighted average interest rate on short-term debt outstanding | 4.4 | % |  | 5.1 | % |

[0000833444-24-000011:notes:54]
As of December 31, 2023, the Company had syndicated committed revolving credit facilities of $2.5 billion which is scheduled to expire in December 2028 and $500 million which is scheduled to expire in December 2024. There were no draws on the facilities as of December 31, 2023.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-24-000011:notes:55]
DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES
The Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities and interest rates. Under Company policy, the use of derivatives is restricted to those intended for hedging purposes; the use of any derivative instrument for speculative purposes is strictly prohibited. A description of each type of derivative utilized by the Company to manage risk is included in the following paragraphs. In addition, refer to Note 12, "Fair Value Measurements," of the notes to the consolidated financial statements for information related to the fair value measurements and valuation methods utilized by the Company for each derivative type.

[0000833444-24-000011:notes:56]
[same as prior period, unchanged from 0000833444-23-000030:notes:78]

[0000833444-24-000011:notes:57]
[same as prior period, unchanged from 0000833444-23-000030:notes:79]

[0000833444-24-000011:notes:58]
The Company enters into forward-starting interest-rate swaps in conjunction with anticipated note issuances. Forward-starting interest swaps are terminated when the anticipated notes are issued. As of December 31, 2023 and September 30, 2023, $600 million of forward-starting interest swaps were outstanding on an $800 million anticipated note issuance. Accumulated amounts recorded in accumulated other comprehensive income (loss) ("AOCI") as of the date of the note issuance are amortized to interest expense over the life of the related note to reflect the difference between the swap's reference rate and the fixed rate of the note.

[0000833444-24-000011:notes:59]
[same as prior period, unchanged from 0000833444-23-000030:notes:80]

[0000833444-24-000011:notes:60]
[same as prior period, unchanged from 0000833444-23-000030:notes:82]

[0000833444-24-000011:notes:61]
|  |  | Volume Outstanding as of |
| Commodity |  | December 31, 2023 |  | September 30, 2023 |
| Copper |  | 3,062 |  |  | 2,812 |  |
| Aluminum |  | 5,973 |  |  | 5,976 |  |

[0000833444-24-000011:notes:62]
Cash flow hedges under ASC 815, "Derivatives and Hedging," that hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates and commodity prices during the three months ended December 31, 2023 and 2022.

[0000833444-24-000011:notes:63]
[same as prior period, unchanged from 0000833444-23-000030:notes:86]

[0000833444-24-000011:notes:64]
The Company enters into cross-currency interest rate swaps and foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the cross-currency interest rate swaps and debt obligations are reflected in the AOCI account within shareholders’equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally.

[0000833444-24-000011:notes:65]
[same as prior period, unchanged from 0000833444-23-000030:notes:88]

[0000833444-24-000011:notes:66]
|  |  | December 31, |  | September 30, |
|  | 2023 |  | 2023 |
| Euro-denominated bonds designated as net investment hedges in Europe |  | € | 2.9 |  |  | € | 2.9 |  |
| Yen-denominated debt designated as a net investment hedge in Japan |  | ¥ | 30 |  |  | ¥ | 30 |  |
| US dollar vs. Yen cross-currency interest rate swap designated as a net investment hedge in Japan |  | ¥ | 14 |  |  | ¥ | 14 |  |

[0000833444-24-000011:notes:67]
[same as prior period, unchanged from 0000833444-23-000030:notes:90]

[0000833444-24-000011:notes:68]
The Company holds certain foreign currency forward contracts not designated as hedging instruments under ASC 815 to hedge foreign currency exposure resulting from monetary assets and liabilities denominated in nonfunctional currencies. The changes in fair value of these foreign currency forward exchange derivatives are recorded in the consolidated statements of income where they offset foreign currency transactional gains and losses on the nonfunctional currency denominated assets and liabilities being hedged.

[0000833444-24-000011:notes:69]
[same as prior period, unchanged from 0000833444-23-000030:notes:92]

[0000833444-24-000011:notes:70]
[same as prior period, unchanged from 0000833444-23-000030:notes:93]

[0000833444-24-000011:notes:71]
|  | Derivatives and Hedging Activities Designated as Hedging Instruments |  | Derivatives and Hedging Activities NotDesignated as Hedging Instruments |
|  | December 31, |  | September 30, |  | December 31, |  | September 30, |
|  | 2023 |  | 2023 |  | 2023 |  | 2023 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 14 |  |  | $ | 16 |  |  | $ | — |  |  | $ | 13 |  |
| Interest rate swaps | — |  |  | 22 |  |  | — |  |  | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Cross-currency interest rate swap | — |  |  | 5 |  |  | — |  |  | — |  |
| Total assets | $ | 15 |  |  | $ | 43 |  |  | $ | — |  |  | $ | 13 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 31 |  |  | $ | 20 |  |  | $ | 30 |  |  | $ | 5 |  |
| Interest rate swaps | 14 |  |  | — |  |  | — |  |  | — |  |
| Commodity derivatives | — |  |  | 2 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 3,394 |  |  | 3,253 |  |  | — |  |  | — |  |
| Total liabilities | $ | 3,439 |  |  | $ | 3,275 |  |  | $ | 30 |  |  | $ | 5 |  |

[0000833444-24-000011:notes:72]
[same as prior period, unchanged from 0000833444-23-000030:notes:95]

[0000833444-24-000011:notes:73]
The use of derivative financial instruments exposes the Company to counterparty credit risk. The Company has established policies and procedures to limit the potential for counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association ("ISDA") master netting agreements with substantially all of its counterparties. The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position.

[0000833444-24-000011:notes:74]
[same as prior period, unchanged from 0000833444-23-000030:notes:98]

[0000833444-24-000011:notes:75]
[same as prior period, unchanged from 0000833444-23-000030:notes:99]

[0000833444-24-000011:notes:76]
|  |  | Fair Value of Assets |  |  |  | Fair Value of Liabilities |  |  |
|  |  | December 31, |  | September 30, |  |  |  | December 31, |  | September 30, |  |  |
|  |  | 2023 |  | 2023 |  |  |  | 2023 |  | 2023 |  |  |
| Gross amount recognized |  | $ | 15 |  |  | $ | 56 |  |  |  |  | $ | 3,469 |  |  | $ | 3,280 |  |  |  |
| Gross amount eligible for offsetting |  | (14) |  |  | (19) |  |  |  |  | (14) |  |  | (19) |  |  |  |
| Net amount |  | $ | 1 |  |  | $ | 37 |  |  |  |  | $ | 3,455 |  |  | $ | 3,261 |  |  |  |

[0000833444-24-000011:notes:77]
[same as prior period, unchanged from 0000833444-23-000030:notes:101]

[0000833444-24-000011:notes:78]
[same as prior period, unchanged from 0000833444-23-000030:notes:102]

[0000833444-24-000011:notes:79]
| Derivatives in Cash Flow Hedging Relationships |  | Three Months Ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Foreign currency exchange derivatives |  | $ | (13) |  |  | $ | (21) |  |  |  |  |  |
| Commodity derivatives |  | 1 |  |  | 4 |  |  |  |  |  |
| Interest rate swaps |  | (35) |  |  | — |  |  |  |  |  |
| Total |  | $ | (47) |  |  | $ | (17) |  |  |  |  |  |

[0000833444-24-000011:notes:80]
[same as prior period, unchanged from 0000833444-23-000030:notes:104]

[0000833444-24-000011:notes:81]
| Derivatives in Cash Flow Hedging Relationships |  | Location of Gain (Loss) Reclassified from AOCI into Income |  | Three Months Ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (1) |  |  | $ | 9 |  |  |  |  |  |
| Commodity derivatives |  | Cost of sales |  | (3) |  |  | (6) |  |  |  |  |  |
| Total |  |  |  | $ | (4) |  |  | $ | 3 |  |  |  |  |  |

[0000833444-24-000011:notes:82]
[same as prior period, unchanged from 0000833444-23-000030:notes:106]

[0000833444-24-000011:notes:83]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months Ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (5) |  |  | $ | 2 |  |  |  |  |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | (43) |  |  | 79 |  |  |  |  |  |
| Total |  |  |  | $ | (48) |  |  | $ | 81 |  |  |  |  |  |

[0000833444-24-000011:notes:84]
Pre-tax losses on net investment hedges recorded as foreign currency translation adjustments ("CTA") within other comprehensive income (loss) were $145 million and $269 million for the three months ended December 31, 2023 and 2022, respectively. No gains or losses were reclassified from CTA into income during the three months ended December 31, 2023 and 2022.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-24-000011:notes:85]
FAIR VALUE MEASUREMENTS
ASC 820, "Fair Value Measurement," defines fair value as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. ASC 820 also establishes a three-level fair value hierarchy that prioritizes information used in developing assumptions when pricing an asset or liability as follows:

[0000833444-24-000011:notes:86]
[same as prior period, unchanged from 0000833444-23-000030:notes:111]

[0000833444-24-000011:notes:87]
[same as prior period, unchanged from 0000833444-23-000030:notes:112]

[0000833444-24-000011:notes:88]
[same as prior period, unchanged from 0000833444-23-000030:notes:113]

[0000833444-24-000011:notes:89]
[same as prior period, unchanged from 0000833444-23-000030:notes:114]

[0000833444-24-000011:notes:90]
[same as prior period, unchanged from 0000833444-23-000030:notes:115]

[0000833444-24-000011:notes:91]
[same as prior period, unchanged from 0000833444-23-000030:notes:116]

[0000833444-24-000011:notes:92]
|  | Fair Value Measurements Using: |
|  | Total as of December 31, 2023 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 14 |  |  | $ | — |  |  | $ | 14 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 47 |  |  | 47 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)(1) | 82 |  |  | 82 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)(1) | 169 |  |  | 169 |  |  | — |  |  | — |  |
| Total assets | $ | 313 |  |  | $ | 298 |  |  | $ | 15 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 61 |  |  | $ | — |  |  | $ | 61 |  |  | $ | — |  |
| Interest rate swaps | 14 |  |  | — |  |  | 14 |  |  | — |  |
| Contingent earn-out liabilities | 55 |  |  | — |  |  | — |  |  | 55 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 50 |  |  | — |  |  | — |  |  | 50 |  |
| Total liabilities | $ | 180 |  |  | $ | — |  |  | $ | 75 |  |  | $ | 105 |  |

[0000833444-24-000011:notes:93]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2023 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 29 |  |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |
| Interest rate swaps | 22 |  |  | — |  |  | 22 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Cross-currency interest rate swap | 5 |  |  | — |  |  | 5 |  |  | — |  |
| Deferred compensation plan assets | 45 |  |  | 45 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)(1) | 76 |  |  | 76 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)(1) | 155 |  |  | 155 |  |  | — |  |  | — |  |
| Total assets | $ | 332 |  |  | $ | 276 |  |  | $ | 56 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 25 |  |  | $ | — |  |  | $ | 25 |  |  | $ | — |  |
| Commodity derivatives | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Contingent earn-out liabilities | 48 |  |  | — |  |  | — |  |  | 48 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 76 |  |  | — |  |  | — |  |  | 76 |  |
| Total liabilities | $ | 151 |  |  | $ | — |  |  | $ | 27 |  |  | $ | 124 |  |

[0000833444-24-000011:notes:94]
(1)  Classified as restricted investments for payment of asbestos liabilities. See Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further details.

[0000833444-24-000011:notes:95]
[same as prior period, unchanged from 0000833444-23-000030:notes:120]

[0000833444-24-000011:notes:96]
| Balance at September 30, 2023 | $ | 124 |  |  |
| Payments | (19) |  |  |
| Reduction for change in estimates | (1) |  |  |
| Currency translation | 1 |  |  |
| Balance at December 31, 2023 | $ | 105 |  |  |

[0000833444-24-000011:notes:97]
[same as prior period, unchanged from 0000833444-23-000030:notes:122]

[0000833444-24-000011:notes:98]
[same as prior period, unchanged from 0000833444-23-000030:notes:124]

[0000833444-24-000011:notes:99]
[same as prior period, unchanged from 0000833444-23-000030:notes:128]

[0000833444-24-000011:notes:100]
Cross-currency interest rate swaps: The fair value of cross-currency interest rate swaps represents the difference between the swap's reference rate and exchange rate and the interest and exchange rates for a similar instrument as of the reporting period. Cross-currency interest rate swaps are valued under a market approach using publicized prices.

[0000833444-24-000011:notes:101]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds

[0000833444-24-000011:notes:102]
which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices. Unrealized gains (losses) on the deferred compensation plan assets are recognized in the consolidated statements of income where they offset unrealized gains and losses on the related deferred compensation plan liability.

[0000833444-24-000011:notes:103]
Exchange traded funds: Investments in exchange traded funds are valued using a market approach based on  quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. Refer to Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further information.

[0000833444-24-000011:notes:104]
[same as prior period, unchanged from 0000833444-23-000030:notes:123]

[0000833444-24-000011:notes:105]
Interest rate swaps: The fair value of interest rate swaps represent the difference between the swap's reference rate and the interest rate for a similar instrument as of the reporting period. Interest rate swaps are valued under a market approach using publicized prices.

[0000833444-24-000011:notes:106]
The following table presents the portion of unrealized gains recognized in the consolidated statements of income that relate to equity securities still held at December 31, 2023 and 2022 (in millions):

[0000833444-24-000011:notes:107]
|  |  | Three Months Ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Deferred compensation plan assets |  | $ | 4 |  |  | $ | 3 |  |  |  |  |  |
| Investments in exchange traded funds |  | 22 |  |  | 11 |  |  |  |  |  |

[0000833444-24-000011:notes:108]
All of the gains on investments in exchange traded funds related to restricted investments.

[0000833444-24-000011:notes:109]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values.

[0000833444-24-000011:notes:110]
The fair value of long-term debt at December 31, 2023 and September 30, 2023 was as follows (in billions):

[0000833444-24-000011:notes:111]
|  |  | December 31, |  | September 30, |  |
|  | 2023 |  | 2023 |  |
| Public debt |  | $ | 7.8 |  |  | $ | 7.1 |  |  |
| Other long-term debt |  | 0.4 |  |  | 0.4 |  |  |
| Total fair value of long-term debt |  | $ | 8.2 |  |  | $ | 7.5 |  |  |

[0000833444-24-000011:notes:112]
The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000833444-24-000011:notes:113]
[same as prior period, unchanged from 0000833444-23-000030:notes:132]

[0000833444-24-000011:notes:114]
Interest rate swaps: The fair value of interest rate swaps represent the difference between the swap's reference rate and the interest rate for a similar instrument as of the reporting period. Interest rate swaps are valued under a market approach using publicized prices.
The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-24-000011:notes:115]
STOCK-BASED COMPENSATION
The Johnson Controls International plc 2021 Equity and Incentive Plan authorizes stock options, stock appreciation rights, restricted (non-vested) stock/units, performance share units and other stock-based awards. The Compensation and Talent Development Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. Awards are typically granted annually in the Company’s fiscal first quarter.

[0000833444-24-000011:notes:116]
[same as prior period, unchanged from 0000833444-23-000030:notes:135]

[0000833444-24-000011:notes:117]
|  | Three Months Ended December 31, |  |  |
|  | 2023 |  |  |  | 2022 |  |  |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |
| Restricted stock/units | 1,741,102 |  |  | $ | 53.52 |  |  |  |  | 1,614,493 |  |  | $ | 66.73 |  |  |  |
| Performance shares | 370,307 |  |  | 54.13 |  |  |  |  | 339,191 |  |  | 79.54 |  |  |  |
| Stock options | 652,702 |  |  | 13.74 |  |  |  |  | 570,140 |  |  | 18.21 |  |  |  |

[0000833444-24-000011:notes:118]
[same as prior period, unchanged from 0000833444-23-000030:notes:137]

[0000833444-24-000011:notes:119]
[same as prior period, unchanged from 0000833444-23-000030:notes:138]

[0000833444-24-000011:notes:120]
|  | Three Months Ended December 31, |
|  | 2023 |  | 2022 |
| Risk-free interest rate | 4.21% |  | 4.04% |
| Expected volatility of the Company’s stock | 27.2% |  | 33.5% |

[0000833444-24-000011:notes:121]
[same as prior period, unchanged from 0000833444-23-000030:notes:140]

[0000833444-24-000011:notes:122]
[same as prior period, unchanged from 0000833444-23-000030:notes:141]

[0000833444-24-000011:notes:123]
|  | Three Months Ended December 31, |
|  | 2023 |  | 2022 |
| Expected life of option (years) | 5.7 |  | 5.8 |
| Risk-free interest rate | 3.86% |  | 3.59% |
| Expected volatility of the Company’s stock | 29.8% |  | 29.4% |
| Expected dividend yield on the Company’s stock | 2.77% |  | 2.10% |


## us-gaap:EarningsPerShareTextBlock

[0000833444-24-000011:notes:124]
EARNINGS PER SHARE
The following table reconciles the numerators and denominators used to calculate basic and diluted earnings per share (in millions):

[0000833444-24-000011:notes:125]
|  | Three Months Ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Net income attributable to Johnson Controls | $ | 374 |  |  | $ | 118 |  |  |  |  |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 680.7 |  |  | 687.0 |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 1.7 |  |  | 3.3 |  |  |  |  |  |
| Diluted weighted average shares outstanding | 682.4 |  |  | 690.3 |  |  |  |  |  |
| Antidilutive Securities |  |  |  |  |  |  |  |
| Stock options and unvested restricted stock | 0.6 |  |  | 0.3 |  |  |  |  |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-24-000011:notes:126]
EQUITY 
Share repurchase program

[0000833444-24-000011:notes:127]
During the three months ended December 31, 2022, the Company repurchased and immediately retired $154 million of its ordinary shares. No shares were repurchased during the three months ended December 31, 2023.

[0000833444-24-000011:notes:128]
As of December 31, 2023, approximately $3.0 billion remains available under the Company's share repurchase program, which was approved by the Company's Board of Directors in March 2021. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice.

[0000833444-24-000011:notes:129]
[same as prior period, unchanged from 0000833444-23-000030:notes:147]

[0000833444-24-000011:notes:130]
[same as prior period, unchanged from 0000833444-23-000030:notes:148]

[0000833444-24-000011:notes:131]
|  | Three Months Ended December 31, |
|  | 2023 |  | 2022 |
| Foreign currency translation adjustments |  |  |  |
| Balance at beginning of period | $ | (970) |  |  | $ | (901) |  |
| Aggregate adjustment for the period | 61 |  |  | 59 |  |
| Balance at end of period | (909) |  |  | (842) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | 15 |  |  | (11) |  |
| Current period changes in fair value | (43) |  |  | (11) |  |
| Reclassification to income (1) | 4 |  |  | (3) |  |
| Net tax impact | 1 |  |  | 3 |  |
| Balance at end of period | (23) |  |  | (22) |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | — |  |  | 1 |  |
| Reclassification to income | (1) |  |  | (1) |  |
| Balance at end of period | (1) |  |  | — |  |
| Accumulated other comprehensive loss, end of period | $ | (933) |  |  | $ | (864) |  |

[0000833444-24-000011:notes:132]
[same as prior period, unchanged from 0000833444-23-000030:notes:151]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-24-000011:notes:133]
PENSION AND RETIREMENT PLANS
The components of the Company’s net periodic benefit cost (credit) associated with its defined benefit pension and postretirement plans, which are primarily recorded in selling, general and administrative expenses in the consolidated statements of income, are shown in the tables below in accordance with ASC 715, "Compensation – Retirement Benefits" (in millions):

[0000833444-24-000011:notes:134]
|  | U.S. Pension Plans |  |
|  | Three Months Ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Interest cost | $ | 20 |  |  | $ | 21 |  |  |  |  |  |
| Expected return on plan assets | (30) |  |  | (34) |  |  |  |  |  |
| Net actuarial loss | — |  |  | 8 |  |  |  |  |  |
| Net periodic benefit credit | $ | (10) |  |  | $ | (5) |  |  |  |  |  |

[0000833444-24-000011:notes:135]
|  | Non-U.S. Pension Plans |
|  | Three Months Ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Service cost | $ | 4 |  |  | $ | 3 |  |  |  |  |  |
| Interest cost | 17 |  |  | 16 |  |  |  |  |  |
| Expected return on plan assets | (18) |  |  | (18) |  |  |  |  |  |
| Net periodic benefit cost | $ | 3 |  |  | $ | 1 |  |  |  |  |  |

[0000833444-24-000011:notes:136]
|  | Postretirement Benefits |
|  | Three Months Ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Interest cost | $ | 1 |  |  | $ | 1 |  |  |  |  |  |
| Expected return on plan assets | (2) |  |  | (2) |  |  |  |  |  |
| Amortization of prior service credit | (1) |  |  | (1) |  |  |  |  |  |
| Net periodic benefit credit | $ | (2) |  |  | $ | (2) |  |  |  |  |  |

[0000833444-24-000011:notes:137]
During the three months ended December 31, 2022, the amount of cumulative fiscal 2023 lump sum payouts triggered a remeasurement event for certain U.S. pension plans resulting in the recognition of net actuarial losses of $8 million, primarily due to decreases in discount rates, partially offset by favorable plan asset performance.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-24-000011:notes:138]
RESTRUCTURING AND RELATED COSTS
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company commits to various restructuring activities as necessary. Restructuring activities generally result in charges for workforce reductions, plant closures, asset impairments and other related costs which are reported as restructuring and impairment costs in the Company’s consolidated statements of income. The Company expects the restructuring activities to reduce cost of sales and selling, general and administrative expenses ("SG&A") due to reduced employee-related costs, depreciation and amortization expense.

[0000833444-24-000011:notes:139]
In the third and fourth quarters of fiscal 2023, the Company developed a restructuring plan which included workforce reductions and other actions focused on continued scaling of SG&A expenses to its planned growth. Additional restructuring charges related to this plan were recorded in the three months ended December 31, 2023 and are expected in subsequent quarters.

[0000833444-24-000011:notes:140]
[same as prior period, unchanged from 0000833444-23-000030:notes:161]

[0000833444-24-000011:notes:141]
|  | Three Months Ended December 31, 2023 |  |  |  |  |
| Building Solutions North America | $ | 4 |  |  |  |  |  |
| Building Solutions EMEA/LA | 13 |  |  |  |  |  |
| Global Products | 21 |  |  |  |  |  |
| Corporate | 1 |  |  |  |  |  |
| Total | $ | 39 |  |  |  |  |  |

[0000833444-24-000011:notes:142]
The following table summarizes changes in the restructuring reserve, which is included within other current liabilities in the consolidated statements of financial position, for restructuring actions taken in the year ended September 30, 2023 and three months ended December 31, 2023 (in millions):

[0000833444-24-000011:notes:143]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  |  |  | Total |
| Restructuring and related costs | $ | 204 |  |  | $ | 38 |  |  | $ | 34 |  |  |  |  | $ | 276 |  |
| Utilized—cash | (111) |  |  | — |  |  | (19) |  |  |  |  | (130) |  |
| Utilized—noncash | — |  |  | (38) |  |  | (3) |  |  |  |  | (41) |  |
| Balance at September 30, 2023 | 93 |  |  | — |  |  | 12 |  |  |  |  | 105 |  |
| Additional restructuring and related costs | 29 |  |  | 9 |  |  | 1 |  |  |  |  | 39 |  |
| Utilized—cash | (38) |  |  | — |  |  | — |  |  |  |  | (38) |  |
| Utilized—noncash | — |  |  | (9) |  |  | — |  |  |  |  | (9) |  |
| Balance at December 31, 2023 | $ | 84 |  |  | $ | — |  |  | $ | 13 |  |  |  |  | $ | 97 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-24-000011:notes:144]
INCOME TAXES
In calculating the provision for income taxes, the Company uses an estimate of the annual effective tax rate based upon the facts and circumstances known at each interim period. On a quarterly basis, the actual effective tax rate is adjusted, as appropriate, based upon changed facts and circumstances, if any, as compared to those forecasted at the beginning of the fiscal year and each interim period thereafter.

[0000833444-24-000011:notes:145]
[same as prior period, unchanged from 0000833444-23-000030:notes:166]

[0000833444-24-000011:notes:146]
For the three months ended December 31, 2023, the Company's effective tax rate was (0.2%) and was lower than the statutory tax rate of 12.5% primarily due to Swiss tax reform and the benefits of continuing global tax planning, partially offset by the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain consolidated subsidiaries and tax rate differentials.

[0000833444-24-000011:notes:147]
For the three months ended December 31, 2022, the Company's effective tax rate was 8.2% and was lower than the statutory tax rate of 12.5% primarily due to impairment and restructuring charges and the benefits of continuing global tax planning initiatives, partially offset by tax rate differentials.

[0000833444-24-000011:notes:148]
[same as prior period, unchanged from 0000833444-23-000030:notes:172]

[0000833444-24-000011:notes:149]
[same as prior period, unchanged from 0000833444-23-000030:notes:173]

[0000833444-24-000011:notes:150]
[same as prior period, unchanged from 0000833444-23-000030:notes:174]

[0000833444-24-000011:notes:151]
At September 30, 2023, the Company had gross tax-effected unrecognized tax benefits of $2.2 billion, of which $1.6 billion, if recognized, would impact the effective tax rate. Accrued interest, net at September 30, 2023 was approximately $335 million (net of tax benefit). Interest accrued during the three months ended December 31, 2023 and 2022 was approximately $31 million (net of tax benefit) and approximately $26 million (net of tax benefit), respectively. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-24-000011:notes:152]
In the U.S., fiscal years 2017 through 2018 are currently under appeal with the Internal Revenue Service (“IRS”) for certain legal entities. In addition, fiscal years 2016 through 2019 are also under exam by the IRS in relation to a separate consolidated filing group. Additionally, the Company is currently under exam in the following major non-U.S. jurisdictions:

[0000833444-24-000011:notes:153]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2022 |
| Germany |  | 2007 - 2021 |
| Luxembourg |  | 2017 - 2018 |
| Mexico |  | 2015 - 2019 |
| United Kingdom |  | 2014 - 2015; 2018; 2020 - 2021 |

[0000833444-24-000011:notes:154]
It is reasonably possible that tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense. Based upon the circumstances surrounding these examinations, the impact is not currently quantifiable.

[0000833444-24-000011:notes:155]
[same as prior period, unchanged from 0000833444-23-000030:notes:180]

[0000833444-24-000011:notes:156]
The Company recorded restructuring and impairment costs of $39 million, which generated a $7 million tax benefit, during the three months ended December 31, 2023 and $345 million, which generated a $52 million tax benefit, during the three months ended December 31, 2022.

[0000833444-24-000011:notes:157]
Tax expenses and benefits for the above transactions reflect the Company’s current tax positions in the impacted jurisdictions. Refer to Note 17, “Restructuring and Related Costs,” of the notes to the consolidated financial statements for additional information.

[0000833444-24-000011:notes:158]
Impacts of Tax Legislation

[0000833444-24-000011:notes:159]
On September 11, 2023, the Schaffhausen parliament approved a partial revision of the cantonal act on direct taxation: Immediate Minimum Taxation Measure (“IMTM”). On November 19, 2023, IMTM was approved in a public referendum in the canton of Schaffhausen, was published in the cantonal official gazette on December 8, 2023, and is effective starting January 1, 2024. The IMTM increased Switzerland's combined statutory income tax rate to approximately 15%. As a result, in the three months ended December 31, 2023, the Company recorded a noncash discrete net tax benefit of $80 million due to the remeasurement of deferred tax assets and liabilities related to Switzerland and the canton of Schaffhausen.

[0000833444-24-000011:notes:160]
On August 16, 2022, the U.S. enacted the Inflation Reduction Act (“IRA”) which, among other things, creates a new book minimum tax of at least 15% of consolidated GAAP pre-tax income for corporations with average book income in excess of $1 billion. The book minimum tax is first applicable in fiscal year 2024, however, this provision does not have a material impact on the Company's effective tax rate.
During the three months ended December 31, 2023 and 2022, tax legislation was adopted in various other jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-24-000011:notes:161]
SEGMENT INFORMATION
ASC 280, "Segment Reporting," establishes the standards for reporting information about segments in financial statements. In applying the criteria set forth in ASC 280, the Company has determined that it has four reportable segments for financial reporting purposes.

[0000833444-24-000011:notes:162]
The Company conducts its business through four business segments:

[0000833444-24-000011:notes:163]
•Building Solutions North America which operates in the United States and Canada;

[0000833444-24-000011:notes:164]
•Building Solutions EMEA/LA which operates in Europe, the Middle East, Africa and Latin America;

[0000833444-24-000011:notes:165]
•Building Solutions Asia Pacific which operates in Asia Pacific; and

[0000833444-24-000011:notes:166]
•Global Products which operates worldwide and includes the Johnson Controls-Hitachi joint venture.

[0000833444-24-000011:notes:167]
The Building Solutions segments:

[0000833444-24-000011:notes:168]
•Design, sell, install and service HVAC, controls, building management, refrigeration, integrated electronic security and integrated fire-detection and suppression systems; and

[0000833444-24-000011:notes:169]
•Provide energy-efficiency solutions and technical services, including data-driven "smart building" solutions as well as inspection, scheduled maintenance, and repair and replacement of mechanical and controls systems.

[0000833444-24-000011:notes:170]
The Global Products segment designs, manufactures and sells:

[0000833444-24-000011:notes:171]
•HVAC equipment, controls software and software services for residential and commercial applications;

[0000833444-24-000011:notes:172]
•Refrigeration equipment and controls;

[0000833444-24-000011:notes:173]
•Fire protection and suppression; and

[0000833444-24-000011:notes:174]
•Security products, including intrusion security, anti-theft devices, access control, and video surveillance and management systems.

[0000833444-24-000011:notes:175]
The Company’s segments provide products and services to commercial, institutional, industrial, data center, governmental and residential customers.

[0000833444-24-000011:notes:176]
[same as prior period, unchanged from 0000833444-23-000030:notes:189]

[0000833444-24-000011:notes:177]
[same as prior period, unchanged from 0000833444-23-000030:notes:190]

[0000833444-24-000011:notes:178]
|  | Net Sales |
|  | Three Months Ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Building Solutions North America | $ | 2,487 |  |  | $ | 2,367 |  |  |  |  |  |
| Building Solutions EMEA/LA | 1,038 |  |  | 975 |  |  |  |  |  |
| Building Solutions Asia Pacific | 507 |  |  | 646 |  |  |  |  |  |
| Global Products | 2,062 |  |  | 2,080 |  |  |  |  |  |
| Total net sales | $ | 6,094 |  |  | $ | 6,068 |  |  |  |  |  |

[0000833444-24-000011:notes:179]
|  | Segment EBITA |
|  | Three Months Ended December 31, |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| Building Solutions North America | $ | 285 |  |  | $ | 267 |  |  |  |  |  |
| Building Solutions EMEA/LA | 80 |  |  | 75 |  |  |  |  |  |
| Building Solutions Asia Pacific | 46 |  |  | 68 |  |  |  |  |  |
| Global Products | 369 |  |  | 382 |  |  |  |  |  |
| Total segment EBITA | 780 |  |  | 792 |  |  |  |  |  |
| Corporate expenses | 139 |  |  | 109 |  |  |  |  |  |
| Amortization of intangible assets | 122 |  |  | 104 |  |  |  |  |  |
| Restructuring and impairment costs | 39 |  |  | 345 |  |  |  |  |  |
| Net mark-to-market gains | (22) |  |  | (3) |  |  |  |  |  |
| Net financing charges | 99 |  |  | 67 |  |  |  |  |  |
| Income before income taxes | $ | 403 |  |  | $ | 170 |  |  |  |  |  |


## us-gaap:GuaranteesTextBlock

[0000833444-24-000011:notes:180]
GUARANTEES
Certain of the Company's subsidiaries at the business segment level guarantee the performance of third parties and provide financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from the current fiscal year through the completion of such transactions and would typically be triggered in the event of nonperformance. Performance under the guarantees, if required, would not have a material effect on the Company's financial position, results of operations or cash flows.

[0000833444-24-000011:notes:181]
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. A typical warranty program requires that the Company repair or replace defective products within a specified time period from the date of sale. The Company records an estimate for future warranty-related costs based on actual historical costs to repair or replace products and other known factors. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different than those estimates.

[0000833444-24-000011:notes:182]
The Company’s product warranty liability is recorded in the consolidated statements of financial position in other current liabilities for estimated costs to be incurred within 12 months and in other non-current liabilities for estimated costs to be incurred in more than one year.

[0000833444-24-000011:notes:183]
[same as prior period, unchanged from 0000833444-23-000030:notes:196]

[0000833444-24-000011:notes:184]
|  | Three Months Ended December 31, 2023 |  |  |
| Balance at beginning of period | $ | 203 |  |  |  |
| Accruals for warranties issued during the period | 30 |  |  |  |
| Settlements made (in cash or in kind) during the period | (27) |  |  |  |
| Currency translation | 3 |  |  |  |
| Balance at end of period | $ | 209 |  |  |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-24-000011:notes:185]
COMMITMENTS AND CONTINGENCIES
Environmental Matters

[0000833444-24-000011:notes:186]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-24-000011:notes:187]
|  | December 31, 2023 |  | September 30, 2023 |
| Other current liabilities | $ | 31 |  |  | $ | 31 |  |
| Other noncurrent liabilities | 201 |  |  | 211 |  |
| Total reserves for environmental liabilities | $ | 232 |  |  | $ | 242 |  |

[0000833444-24-000011:notes:188]
The Company periodically examines whether the contingent liabilities related to the environmental matters described below are probable and reasonably estimable based on experience and ongoing developments in those matters, including continued study and analysis of ongoing remediation obligations. The Company expects that it will pay the amounts recorded over an estimated period of up to 20 years. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals for environmental liabilities at this time.

[0000833444-24-000011:notes:189]
A substantial portion of the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to fire-fighting foams containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).

[0000833444-24-000011:notes:190]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. On July 18, 2023, Tyco Fire Products announced that it plans to discontinue the production and sale of fluorinated firefighting foams by June 2024, including AFFF products, and will transition to non-fluorinated foam alternatives.

[0000833444-24-000011:notes:191]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency (“EPA”) to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

[0000833444-24-000011:notes:192]
Tyco Fire Products is operating and monitoring at the FTC a Groundwater Extraction and Treatment System ("GETS"), a permanent groundwater remediation system that extracts groundwater containing PFAS, treats it using advanced filtration systems, and returns the treated water to the environment. Tyco Fire Products has also completed the removal and disposal of PFAS-affected soil from the FTC. The Company's reserves for continued remediation of the FTC, the Stanton Street Facility and surrounding areas in Marinette and Peshtigo are based on estimates of costs associated with the long-term

[0000833444-24-000011:notes:193]
remediation actions, including the continued operation of the GETS, the implementation of long-term drinking water solutions for the area impacted by groundwater migrating from the FTC, continued monitoring and testing of groundwater monitoring wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

[0000833444-24-000011:notes:194]
PFOA, PFOS, and other PFAS compounds are being studied by EPA and other environmental and health agencies and researchers. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. In March 2023, EPA announced a proposed National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR proposes establishing legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion for each of PFOA and PFOS. The EPA has stated that it intends to propose two rules relating to PFAS under the Resource Conservation and Recovery Act (“RCRA”): one rule would list four PFAS (PFOA, PFOS, PFBS, and GenX) as “hazardous constituents,” and a second rule would clarify that hazardous constituents are subject to RCRA's corrective action program.

[0000833444-24-000011:notes:195]
In August 2022, EPA published a proposed rule that would designate PFOA and PFOS as “hazardous substances” under Comprehensive Environmental Response, Compensation and Liability Act ("CERCLA"). In April 2023, EPA issued an Advanced Notice of Proposed Rulemaking ("ANPR") seeking input on whether it should expand the proposed rule to designate as "hazardous substances" under CERCLA: (1) seven additional PFAS; (2) the precursors to PFOA, PFOS, and the seven additional PFAS; or (3) entire categories of PFAS. The EPA indicated that it anticipates finalizing the regulation by March 2024.

[0000833444-24-000011:notes:196]
It is not possible to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in soil, groundwater and drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000833444-24-000011:notes:197]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $10 million and $13 million at December 31, 2023 and September 30, 2023, respectively.

[0000833444-24-000011:notes:198]
FTC-Related Matters

[0000833444-24-000011:notes:199]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water in February 2022, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. The WDNR initiated a rulemaking proceeding that would establish groundwater quality standards for PFOA, PFOS, perfluorobutane sulfonic acid and its potassium salt (“PFBS”) and hexafluoropropylene oxide dimer acid and its ammonium salt (“HFPO-DA”). Pursuant to state law, the WDNR has stopped work on the proposed rule and notified the state legislature that, following economic analysis, the proposed costs would exceed statutory thresholds. As a result, the state legislature is required to authorize the WDNR to allow the rulemaking to continue.

[0000833444-24-000011:notes:200]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and

[0000833444-24-000011:notes:201]
spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. The WDNR issued a further letter regarding the issue on November 4, 2019. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to that date. On April 10, 2023, the WDNR issued a third “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids in the Marinette region. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions, including the potential assessment of penalties.

[0000833444-24-000011:notes:202]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR's requests. The parties are proceeding with fact discovery and the court has set a trial date of December 3, 2024.

[0000833444-24-000011:notes:203]
In October 2022, the Town of Peshtigo filed a tort action in Wisconsin state court against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and ChemDesign, Inc. relating to environmental matters at the FTC (Town of Peshtigo v. Tyco Fire Products L.P. et al., Case No. 2022CV000234 (filed October 18, 2022 in Circuit Court in Marinette County, Wisconsin)). The Town alleges that use of AFFF products at the FTC caused contamination of water supplies in Peshtigo. The Town seeks monetary penalties and an injunction ordering abatement of PFAS contamination in Peshtigo. The case has been removed to federal court and transferred to a multi-district litigation ("MDL") before the United States District Court for the District of South Carolina.

[0000833444-24-000011:notes:204]
In November 2022, individuals filed six actions in Dane County, Wisconsin alleging personal injury and/or property damage against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and other unaffiliated defendants related to environmental matters at the FTC. Plaintiffs allege that use of AFFF products at the FTC and activities by third parties unrelated to the Company contaminated nearby drinking water sources, surface waters, and other natural resources and properties, including their personal properties. The individuals seek monetary damages for their personal injury and/or property damage. These lawsuits have been transferred to the MDL. Subsequently, several additional plaintiffs have direct-filed in the MDL complaints with similar allegations.

[0000833444-24-000011:notes:205]
These FTC-related lawsuits are presently at the beginning stages of litigation. The Company is vigorously defending each of these cases and believes that it has meritorious defenses, but it is presently unable to predict the duration, scope, or outcome of these actions.

[0000833444-24-000011:notes:206]
Aqueous Film-Forming Foam ("AFFF") Matters

[0000833444-24-000011:notes:207]
AFFF Litigation

[0000833444-24-000011:notes:208]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including

[0000833444-24-000011:notes:209]
damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-24-000011:notes:210]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to the MDL. Additional cases have been identified for transfer to or are being directly filed in the MDL.

[0000833444-24-000011:notes:211]
AFFF Putative Class Actions

[0000833444-24-000011:notes:212]
Chemguard and Tyco Fire Products are named in 44 pending putative class actions in federal courts originating from 16 states and territories. All of these cases have been direct-filed in or transferred to the MDL. Tyco Fire Products was also recently named in a class action in British Columbia, Canada.

[0000833444-24-000011:notes:213]
AFFF Individual or Mass Actions

[0000833444-24-000011:notes:214]
There are more than 6,000 individual or “mass” actions pending that were filed in state or federal courts originating from 52 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 6,000 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly-filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona, Illinois and Virginia.

[0000833444-24-000011:notes:215]
Tyco and Chemguard are also periodically notified by other individuals that they may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-24-000011:notes:216]
AFFF Municipal and Water Provider Cases

[0000833444-24-000011:notes:217]
Chemguard and Tyco Fire Products have been named as defendants in more than 770 cases in federal and state courts involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 35 states and territories. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation. The MDL court set the first case for trial on June 5, 2023 (City of Stuart (Florida) v. 3M Co. et al.). On April 26, 2023, the parties entered a stipulation dismissing Chemguard with prejudice from the City of Stuart case, and on May 4, 2023 the parties entered into a stipulation dismissing Tyco with prejudice from the City of Stuart case. On June 5, 2023, the MDL court continued the trial date for the City of Stuart case, and the parties remaining in that case later reached settlement. The parties in the MDL designated four additional plaintiffs as water provider bellwether cases and conducted initial discovery into those cases. On December 19, 2023, the MDL court selected two of those cases to proceed into additional discovery. The parties have also identified 25 personal injury bellwether cases, which have entered into the first phase of bellwether discovery.

[0000833444-24-000011:notes:218]
Tyco and Chemguard are also periodically notified by other municipal entities that those entities may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-24-000011:notes:219]
AFFF State or U.S. Territory Attorneys General Litigation

[0000833444-24-000011:notes:220]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in

[0000833444-24-000011:notes:221]
Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-24-000011:notes:222]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-24-000011:notes:223]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. The State’s case has been removed to federal court and transferred to the MDL. The State of Alaska has also named a number of manufacturers and other defendants, including affiliates of the Company, as third-party defendants in two cases brought by individuals against the State. These two cases have also been transferred to the MDL.

[0000833444-24-000011:notes:224]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL. In October 2022, the Attorney General filed two similar lawsuits in the superior courts of the State of North Carolina regarding alleged PFAS damages at two additional locations. These two cases have also been removed to federal court and transferred to the MDL.

[0000833444-24-000011:notes:225]
In addition, 31 other states and territories have filed 33 lawsuits against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of each of those State's environmental and natural resources allegedly resulting from the manufacture, storage, sale, distribution, marketing, and use of PFAS-containing AFFF within each respective State. The states and territories are: Arkansas, Arizona, California, Colorado, Connecticut, Delaware, the District of Columbia, Florida, Hawaii, Illinois, Kentucky, Massachusetts, Maryland, Maine, Michigan, Mississippi, New Hampshire, New Jersey, New Mexico, Ohio, Oregon, Rhode Island, South Carolina, Tennessee, Texas, Vermont, Washington, Wisconsin, Guam, the Northern Mariana Islands, and Puerto Rico. All of these complaints, other than Hawaii and Connecticut, have been removed to federal court and transferred to the MDL. The Hawaii complaint has been removed to federal court and it is anticipated that it will be transferred to the MDL. It is anticipated that the Connecticut complaint will be removed to federal court and transferred to the MDL.

[0000833444-24-000011:notes:226]
Other AFFF Related Matters

[0000833444-24-000011:notes:227]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

[0000833444-24-000011:notes:228]
In October 2022, the Red Cliff Band of Lake Superior Chippewa Indians (a federally recognized tribe) filed a lawsuit in the United States District Court for the Western District of Wisconsin against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota. This complaint has been transferred to the MDL.

[0000833444-24-000011:notes:229]
In July 2023, the Fond du Lac Band of Lake Superior Chippewa (a federally recognized tribe) direct-filed a lawsuit in the MDL against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota.

[0000833444-24-000011:notes:230]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. In September 2022, the AFFF MDL Court declined to grant summary judgment on the government contractor defense, ruling that various factual issues relevant to the defense must be decided by a jury rather than the Court. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin and a federal district court in South Carolina. The insurance litigation involves numerous factual and legal issues and remains at a relatively early stage. There are numerous factual and legal issues to be resolved in connection with these claims. The Company is presently unable to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

[0000833444-24-000011:notes:231]
Asbestos Matters

[0000833444-24-000011:notes:232]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-24-000011:notes:233]
The following table presents the location and amount of asbestos-related assets and liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-24-000011:notes:234]
|  | December 31, 2023 |  | September 30, 2023 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 359 |  |  | 364 |  |
| Total asbestos-related liabilities | 417 |  |  | 422 |  |
| Other current assets | 27 |  |  | 28 |  |
| Other noncurrent assets | 294 |  |  | 273 |  |
| Total asbestos-related assets | 321 |  |  | 301 |  |
| Net asbestos-related liabilities | $ | 96 |  |  | $ | 121 |  |

[0000833444-24-000011:notes:235]
The following table presents the components of asbestos-related assets (in millions):

[0000833444-24-000011:notes:236]
|  | December 31, 2023 |  | September 30, 2023 |
| Restricted |  |  |  |
| Cash | $ | 19 |  |  | $ | 20 |  |
| Investments | 252 |  |  | 231 |  |
| Total restricted assets | 271 |  |  | 251 |  |
| Insurance receivables for asbestos-related liabilities | 50 |  |  | 50 |  |
| Total asbestos-related assets | $ | 321 |  |  | $ | 301 |  |

[0000833444-24-000011:notes:237]
The amounts recorded for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption may impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-24-000011:notes:238]
Self-Insured Liabilities

[0000833444-24-000011:notes:239]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage a portion of its insurable liabilities.

[0000833444-24-000011:notes:240]
The following table presents the location and amount of self-insured liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-24-000011:notes:241]
|  | December 31, 2023 |  | September 30, 2023 |
| Other current liabilities | $ | 87 |  |  | $ | 86 |  |
| Accrued compensation and benefits | 22 |  |  | 21 |  |
| Other noncurrent liabilities | 219 |  |  | 226 |  |
| Total self-insured liabilities | $ | 328 |  |  | $ | 333 |  |

[0000833444-24-000011:notes:242]
The following table presents the location and amount of insurance receivables in the Company's consolidated statements of financial position (in millions):

[0000833444-24-000011:notes:243]
|  | December 31, 2023 |  | September 30, 2023 |
| Other current assets | $ | 6 |  |  | $ | 6 |  |
| Other noncurrent assets | 14 |  |  | 14 |  |
| Total insurance receivables | $ | 20 |  |  | $ | 20 |  |

[0000833444-24-000011:notes:244]
Other Matters

[0000833444-24-000011:notes:245]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to the Company, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock

[0000833444-24-000011:notes:246]
The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):
