# JCI 8-K — 0000833444-24-000007 filed 2024-01-30

## item codes, every 8-K on or before 2024-01-30

- 2024-01-30 0000833444-24-000007 — 2.02, 9.01
- 2024-01-16 0000833444-24-000004 — 5.02, 9.01
- 2023-12-12 0000833444-23-000044 — 2.02, 9.01
- 2023-12-08 0000833444-23-000042 — 5.02
- 2023-11-13 0000833444-23-000038 — 8.01
- 2023-09-27 0000833444-23-000036 — 8.01
- 2023-09-08 0000833444-23-000033 — 5.02
- 2023-08-21 0001193125-23-217018 — 8.01, 9.01
- 2023-08-07 0001193125-23-205014 — 8.01, 9.01
- 2023-08-02 0000833444-23-000028 — 2.02, 9.01
- 2023-05-23 0001193125-23-151889 — 8.01, 9.01
- 2023-05-05 0000833444-23-000011 — 2.02, 9.01
- 2023-03-14 0000833444-23-000007 — 5.07
- 2023-02-01 0000833444-23-000003 — 2.02, 9.01
- 2022-12-22 0000833444-22-000047 — 5.02
- 2022-12-09 0000833444-22-000045 — 5.02
- 2022-11-03 0000833444-22-000038 — 2.02, 9.01
- 2022-09-14 0001193125-22-244741 — 8.01, 9.01
- 2022-09-07 0001193125-22-240030 — 8.01, 9.01
- 2022-08-04 0000833444-22-000034 — 2.02, 9.01
- 2022-07-06 0000833444-22-000029 — 5.02, 9.01
- 2022-06-30 0000833444-22-000027 — 5.02
- 2022-05-04 0000833444-22-000014 — 2.02, 9.01
- 2022-03-11 0001193125-22-073382 — 5.07
- 2022-02-15 0000833444-22-000010 — 5.02
- 2022-02-02 0000833444-22-000003 — 2.02, 9.01
- 2021-12-10 0000833444-21-000050 — 5.02
- 2021-11-05 0000833444-21-000043 — 2.02, 9.01
- 2021-09-16 0001193125-21-275152 — 1.01, 8.01, 9.01
- 2021-07-30 0000833444-21-000038 — 2.02, 9.01
- 2021-05-03 0000833444-21-000023 — 8.01
- 2021-04-30 0000833444-21-000017 — 2.02, 9.01
- 2021-03-11 0000833444-21-000013 — 5.02, 5.07, 9.01
- 2021-02-17 0001193125-21-045768 — 7.01, 9.01
- 2021-01-29 0000833444-21-000009 — 2.02, 9.01
- 2021-01-07 0000833444-21-000004 — 7.01
- 2020-11-03 0000833444-20-000043 — 2.02, 9.01
- 2020-09-15 0001193125-20-246240 — 1.01, 8.01, 9.01
- 2020-09-11 0001193125-20-244119 — 1.01, 8.01, 9.01
- 2020-08-18 0000833444-20-000038 — 5.02, 9.01
- 2020-07-31 0000833444-20-000034 — 2.02, 9.01
- 2020-06-12 0000833444-20-000020 — 8.01
- 2020-05-01 0000833444-20-000013 — 2.02, 9.01
- 2020-03-12 0000833444-20-000010 — 5.02
- 2020-03-06 0000833444-20-000008 — 5.07
- 2020-01-31 0000833444-20-000003 — 2.02, 9.01
- 2019-12-06 0001193125-19-308301 — 1.01, 1.02, 2.03, 9.01
- 2019-11-07 0000833444-19-000048 — 5.02, 9.01
- 2019-11-07 0000833444-19-000046 — 2.02, 9.01
- 2019-08-21 0000833444-19-000043 — 8.01
- 2019-07-31 0000833444-19-000038 — 2.02, 9.01
- 2019-07-23 0000833444-19-000035 — 5.02, 8.01, 9.01
- 2019-07-02 0000833444-19-000033 — 1.02, 8.01
- 2019-06-05 0001193125-19-165565 — 8.01
- 2019-05-30 0001193125-19-160205 — 8.01, 9.01
- 2019-05-16 0001193125-19-148262 — 8.01, 9.01
- 2019-05-07 0001193125-19-139826 — 5.04, 9.01
- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2024-01-30

- 2023-11-29 0000833444-23-000040 — NT 10-K, for the period ended 2023-09-30
- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-24-000007:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq1fy24.htm
EX-99.1

[0000833444-24-000007:8k_2_02:2]
Document

[0000833444-24-000007:8k_2_02:3]
Exhibit 99.1

[0000833444-24-000007:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-24-000007:8k_2_02:5]
Johnson Controls Reports Solid Q1 Results; Updates FY24 Guidance

[0000833444-24-000007:8k_2_02:6]
________________________________________________________________________________

[0000833444-24-000007:8k_2_02:7]
▪Q1 reported sales were flat versus prior year and declined 1% organically

[0000833444-24-000007:8k_2_02:8]
▪Q1 GAAP EPS of $0.55; Q1 Adjusted EPS of $0.51

[0000833444-24-000007:8k_2_02:9]
▪Q1 Orders +1% organically year-over-year

[0000833444-24-000007:8k_2_02:10]
▪Building Solutions backlog of $12.1 billion, increased 7% organically year-over-year

[0000833444-24-000007:8k_2_02:11]
▪Updates FY24 Adjusted EPS before special items of ~$3.60 to $3.75 from prior range of ~$3.65 to $3.80

[0000833444-24-000007:8k_2_02:12]
▪Early stages of pursuing strategic alternatives for non-commercial businesses

[0000833444-24-000007:8k_2_02:13]
______________________________________________________________________________

[0000833444-24-000007:8k_2_02:14]
CORK, Ireland — Jan. 30, 2024 — Johnson Controls International plc (NYSE: JCI), a global leader for smart, healthy and sustainable buildings, today reported fiscal first quarter 2024 GAAP earnings per share (“EPS”) from continuing operations of $0.55. Excluding special items, adjusted EPS from continuing operations was $0.51 (see attached footnotes for non-GAAP reconciliation).

[0000833444-24-000007:8k_2_02:15]
Sales in the quarter of $6.1 billion were flat compared to the prior year on an as reported basis and declined 1% organically. GAAP net income from continuing operations was $374 million. Adjusted net income from continuing operations was $350 million.

[0000833444-24-000007:8k_2_02:16]
“We continued to position Johnson Controls for the future, delivering solid first quarter results and appointing Marc Vandiepenbeeck as CFO,” said Johnson Controls Chairman and CEO George Oliver. “Our value proposition of making buildings smarter, healthier and more sustainable is resonating with our customers and translating into record backlog. After managing through a temporary cyber disruption and the seasonality of the first quarter, we are entering the new calendar year with accelerating momentum.”

[0000833444-24-000007:8k_2_02:17]
Mr. Oliver continued, “The management team continues to simplify and transform the company into a comprehensive solutions provider for commercial buildings.  As part of the continuous evaluation of our portfolio, we are in the early stages of pursuing strategic alternatives of our non-commercial businesses, in line with our objective to maximize value to our shareholders.”

[0000833444-24-000007:8k_2_02:18]
Page 1 of 16

[0000833444-24-000007:8k_2_02:19]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-24-000007:8k_2_02:20]
($ millions, except per-share amounts)

[0000833444-24-000007:8k_2_02:21]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the fiscal first quarter of 2023.

[0000833444-24-000007:8k_2_02:22]
Organic sales growth, adjusted segment EBITA, adjusted corporate expense, adjusted net income from continuing operations, adjusted EPS from continuing operations, cash provided by operating activities from continuing operations, excluding JC Capital, and adjusted free cash flow are non-GAAP financial measures. For a reconciliation of non-GAAP measures and detail of the special items, refer to the attached footnotes.

[0000833444-24-000007:8k_2_02:23]
This press release includes forward-looking statements regarding organic revenue growth, adjusted segment EBITA margin improvement and adjusted EPS, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as mark-to-market adjustments. Organic revenue growth excludes the effect of acquisitions, divestitures and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s fiscal 2024 second quarter and full year GAAP financial results.

[0000833444-24-000007:8k_2_02:24]
A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-24-000007:8k_2_02:25]
Page 2 of 16

[0000833444-24-000007:8k_2_02:26]
SEGMENT RESULTS

[0000833444-24-000007:8k_2_02:27]
Building Solutions North America

[0000833444-24-000007:8k_2_02:28]
|  |  | Fiscal Q1 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  |  |  |  |  |  |
| Sales |  | $2,367 |  | $2,487 |  | $2,367 |  | $2,487 |  |  |  |  |  |  |
| Segment EBITA |  | 267 |  | 285 |  | 267 |  | 285 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 11.3% |  | 11.5% |  | 11.3% |  | 11.5% |  |  |  |  |  |  |

[0000833444-24-000007:8k_2_02:29]
Sales in the quarter of $2.5 billion increased 5% versus the prior year. Organic sales increased 4% over the prior year led by double-digit growth in Applied HVAC & Controls.

[0000833444-24-000007:8k_2_02:30]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 6% year-over-year. Backlog at the end of the quarter of $8.4 billion increased 11% compared to the prior year, excluding M&A and adjusted for foreign currency.

[0000833444-24-000007:8k_2_02:31]
Segment EBITA was $285 million, up 7% versus the prior year. Segment EBITA margin of 11.5% expanded 20 basis points versus the prior year led by higher margin backlog conversion and continued growth in Services.

[0000833444-24-000007:8k_2_02:32]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-24-000007:8k_2_02:33]
|  |  | Fiscal Q1 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  |  |  |  |  |  |
| Sales |  | $975 |  | $1,038 |  | $975 |  | $1,038 |  |  |  |  |  |  |
| Segment EBITA |  | 75 |  | 80 |  | 75 |  | 80 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 7.7% |  | 7.7% |  | 7.7% |  | 7.7% |  |  |  |  |  |  |

[0000833444-24-000007:8k_2_02:34]
Sales in the quarter of $1.0 billion increased 6% versus the prior year. Organic sales grew 2% versus the prior year led by strength in Applied HVAC & Controls, Fire & Security, and high-single digit growth in Service.

[0000833444-24-000007:8k_2_02:35]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 5% year-over-year. Backlog at the end of the quarter of $2.4 billion increased 10% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-24-000007:8k_2_02:36]
Page 3 of 16

[0000833444-24-000007:8k_2_02:37]
Segment EBITA was $80 million, up 7% versus the prior year. Segment EBITA margin of 7.7% was flat versus the prior year as the growth in Service was offset by the conversion of lower margin Install backlog.

[0000833444-24-000007:8k_2_02:38]
Building Solutions Asia Pacific

[0000833444-24-000007:8k_2_02:39]
|  |  | Fiscal Q1 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  |  |  |  |  |  |
| Sales |  | $646 |  | $507 |  | $646 |  | $507 |  |  |  |  |  |  |
| Segment EBITA |  | 68 |  | 46 |  | 68 |  | 46 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 10.5% |  | 9.1% |  | 10.5% |  | 9.1% |  |  |  |  |  |  |

[0000833444-24-000007:8k_2_02:40]
Sales in the quarter of $507 million declined 22% versus the prior year. Organic sales declined 21% versus the prior year as mid single-digit Service growth was more than offset by accelerating weakness in China.

[0000833444-24-000007:8k_2_02:41]
Orders in the quarter, excluding M&A and adjusted for foreign currency, declined 31% year-over-year. Backlog at the end of the quarter of $1.3 billion decreased 21% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-24-000007:8k_2_02:42]
Segment EBITA was $46 million, down 32% versus the prior year. Segment EBITA margin of 9.1% declined 140 basis points versus the prior year primarily related to declines in the Install business in China.

[0000833444-24-000007:8k_2_02:43]
Page 4 of 16

[0000833444-24-000007:8k_2_02:44]
Global Products

[0000833444-24-000007:8k_2_02:45]
|  |  | Fiscal Q1 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  |  |  |  |  |  |
| Sales |  | $2,080 |  | $2,062 |  | $2,080 |  | $2,062 |  |  |  |  |  |  |
| Segment EBITA |  | 382 |  | 369 |  | 422 |  | 369 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 18.4% |  | 17.9% |  | 20.3% |  | 17.9% |  |  |  |  |  |  |

[0000833444-24-000007:8k_2_02:46]
Sales in the quarter of $2.1 billion declined 1% versus the prior year. Organic sales were down 1% versus the prior year as growth in Applied and Light Commercial HVAC was offset by declines in global Residential HVAC.

[0000833444-24-000007:8k_2_02:47]
Segment EBITA was $369 million, down 3% versus the prior year. Segment EBITA margin of 17.9% declined 50 basis points versus the prior year as the result of unfavorable manufacturing absorption and mix. Adjusted segment EBITA in Q1 2023 excluded the impact of an uninsured loss associated with a fire at a leased warehouse facility.

[0000833444-24-000007:8k_2_02:48]
Corporate

[0000833444-24-000007:8k_2_02:49]
|  |  | Fiscal Q1 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  |  |  |  |  |  |
| Corporate Expense |  | ($109) |  | ($139) |  | ($82) |  | ($116) |  |  |  |  |  |  |

[0000833444-24-000007:8k_2_02:50]
Corporate expense was $139 million in the quarter, an increase of 28% compared to the prior year. Adjusted Corporate expense in Q1 2024 excluded certain one-time cyber incident-related costs and in Q1 2023 excluded certain transaction/separation costs.

[0000833444-24-000007:8k_2_02:51]
OTHER Q1 ITEMS

[0000833444-24-000007:8k_2_02:52]
▪Cash used by operating activities from continuing operations was $246 million, while cash used by operating activities from continuing operations, excluding JC Capital, was $158 million. Capital expenditures were $92 million, resulting in adjusted free cash flow from continuing operations of $(250) million. This was favorable by $180 million compared to Q1 2023.

[0000833444-24-000007:8k_2_02:53]
▪The Company paid dividends of approximately $252 million during Q1 2024.

[0000833444-24-000007:8k_2_02:54]
Page 5 of 16

[0000833444-24-000007:8k_2_02:55]
▪The Company recorded pre-tax restructuring and impairment costs of $39 million, primarily comprised of severance charges related to ongoing restructuring actions.

[0000833444-24-000007:8k_2_02:56]
▪The Company recorded a net discrete period tax benefit of $57 million related to benefits from Swiss cantonal tax reform partially offset by a provision related to a change in indefinite reinvestment assertion for certain subsidiaries.

[0000833444-24-000007:8k_2_02:57]
SECOND QUARTER GUIDANCE

[0000833444-24-000007:8k_2_02:58]
The Company initiated fiscal 2024 second quarter guidance:

[0000833444-24-000007:8k_2_02:59]
▪Organic revenue ~flat year-over-year

[0000833444-24-000007:8k_2_02:60]
▪Adjusted segment EBITA margin of ~14.5%

[0000833444-24-000007:8k_2_02:61]
▪Adjusted EPS before special items of ~$0.74 to $0.78

[0000833444-24-000007:8k_2_02:62]
FULL YEAR GUIDANCE

[0000833444-24-000007:8k_2_02:63]
The Company updated fiscal 2024 full year EPS guidance:

[0000833444-24-000007:8k_2_02:64]
▪Organic revenue growth up ~MSD year-over-year

[0000833444-24-000007:8k_2_02:65]
▪Adjusted segment EBITA margin improvement of ~50 to 75 basis points, year-over-year (previously guided to ~25+ basis points improvement)

[0000833444-24-000007:8k_2_02:66]
▪Adjusted EPS before special items of ~$3.60 to $3.75 from prior range of ~$3.65 to $3.80

[0000833444-24-000007:8k_2_02:67]
CONFERENCE CALL & WEBCAST INFO

[0000833444-24-000007:8k_2_02:68]
Johnson Controls will host a conference call to discuss this quarter’s results at 8:30 a.m. ET today, which can be accessed by dialing 844-763-8274 (in the United States) or +1-412-717-9224 (outside the United States), or via webcast. A slide presentation will accompany the prepared remarks and has been posted on the investor relations section of the Johnson Controls website at https://investors.johnsoncontrols.com/news-and-events/events-and-presentations. A replay will be made available approximately two hours following the conclusion of the conference call.

[0000833444-24-000007:8k_2_02:69]
About Johnson Controls

[0000833444-24-000007:8k_2_02:70]
At Johnson Controls (NYSE:JCI), we transform the environments where people live, work, learn and play. As the global leader in smart, healthy and sustainable buildings, our mission is to reimagine the performance of buildings to serve people, places and the planet.

[0000833444-24-000007:8k_2_02:71]
Building on a proud history of nearly 140 years of innovation, we deliver the blueprint of the future for industries such as healthcare, schools, data centers, airports, stadiums, manufacturing and beyond through OpenBlue, our comprehensive digital offering.

[0000833444-24-000007:8k_2_02:72]
Page 6 of 16

[0000833444-24-000007:8k_2_02:73]
Today, with a global team of 100,000 experts in more than 150 countries, Johnson Controls offers the world`s largest portfolio of building technology and software as well as service solutions from some of the most trusted names in the industry.

[0000833444-24-000007:8k_2_02:74]
Visit www.johnsoncontrols.com for more information and follow @Johnson Controls on social platforms.

[0000833444-24-000007:8k_2_02:75]
JOHNSON CONTROLS CONTACTS:

[0000833444-24-000007:8k_2_02:76]
| INVESTOR CONTACTS: | MEDIA CONTACT: |  |  |  |
| Jim Lucas | Danielle Canzanella |  |  |  |
| Direct: +1 651.391.3182 | Direct: +1 203.499.8297 |  |  |  |
| Email: jim.lucas@jci.com | Email: danielle.canzanella@jci.com |  |  |  |
| Michael Gates |  |  |  |  |
| Direct: +1 414.524.5785 |  |  |  |  |
| Email: michael.j.gates@jci.com |  |  |  |  |

[0000833444-24-000007:8k_2_02:77]
###

[0000833444-24-000007:8k_2_02:78]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-24-000007:8k_2_02:79]
Page 7 of 16

[0000833444-24-000007:8k_2_02:80]
material weakness; maintaining and improving the capacity, reliability and security of Johnson Controls enterprise information technology infrastructure; the ability to manage the lifecycle cybersecurity risk in the development, deployment and operation of Johnson Controls digital platforms and services; changes to laws or policies governing foreign trade, including economic sanctions, tariffs, foreign exchange and capital controls, import/export controls or other trade restrictions; fluctuations in currency exchange rates; changes or uncertainty in laws, regulations, rates, policies, or interpretations that impact Johnson Controls business operations or tax status; the ability to adapt to global climate change, climate change regulation and successfully meet Johnson Controls public sustainability commitments; the outcome of litigation and governmental proceedings; the risk of infringement or expiration of intellectual property rights; Johnson Controls ability to manage disruptions caused by catastrophic or geopolitical events, such as natural disasters, armed conflict, political change, climate change, pandemics and outbreaks of contagious diseases and other adverse public health developments; the ability of Johnson Controls to drive organizational improvement;  any delay or inability of Johnson Controls to realize the expected benefits and synergies of recent portfolio transactions; the ability to hire and retain senior management and other key personnel; the tax treatment of recent portfolio transactions; significant transaction costs and/or unknown liabilities associated with such transactions; labor shortages, work stoppages, union negotiations, labor disputes and other matters associated with the labor force; and the cancellation of or changes to commercial arrangements. A detailed discussion of risks related to Johnson Controls business is included in the section entitled “Risk Factors” in Johnson Controls Annual Report on Form 10-K for the fiscal year filed with the SEC, which is available at www.sec.gov and www.johnsoncontrols.com under the “Investors” tab. The description of certain of these risks is supplemented in Item 1A of Part II of Johnson Controls subsequently filed Quarterly Reports on Form 10-Q. Shareholders, potential investors and others should consider these factors in evaluating the forward-looking statements and should not place undue reliance on such statements. The forward-looking statements included in this communication are made only as of the date of this document, unless otherwise specified, and, except as required by law, Johnson Controls assumes no obligation, and disclaims any obligation, to update such statements to reflect events or circumstances occurring after the date of this communication.

[0000833444-24-000007:8k_2_02:81]
###

[0000833444-24-000007:8k_2_02:82]
Non-GAAP Financial Information

[0000833444-24-000007:8k_2_02:83]
This press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include restructuring and impairment costs, net mark-to-market adjustments, certain transaction/separation costs, cyber incident costs, warehouse fire loss, and discrete tax items. Financial information regarding organic sales growth, adjusted segment EBITA, adjusted segment EBITA margin, adjusted Corporate expense, cash provided by operating activities from continuing operations, excluding JC Capital, adjusted free cash flow, and adjusted net income from continuing operations are also presented, which are non-GAAP performance measures. Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of Johnson Controls. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.  For further information on the calculation of the non-GAAP measures and a reconciliation of these non-GAAP measures, refer to the attached footnotes.

[0000833444-24-000007:8k_2_02:84]
###

[0000833444-24-000007:8k_2_02:85]
Page 8 of 16

[0000833444-24-000007:8k_2_02:86]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |  |
|  |  | Three Months Ended December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Net sales | $ | 6,094 |  |  |  | $ | 6,068 |  |  |
| Cost of sales | 4,102 |  |  |  | 3,977 |  |  |
|  | Gross profit | 1,992 |  |  |  | 2,091 |  |  |
| Selling, general and administrative expenses | 1,513 |  |  |  | 1,571 |  |  |
| Restructuring and impairment costs | 39 |  |  |  | 345 |  |  |
| Net financing charges | 99 |  |  |  | 67 |  |  |
| Equity income | 62 |  |  |  | 62 |  |  |
| Income before income taxes | 403 |  |  |  | 170 |  |  |
| Income tax provision (benefit) | (1) |  |  |  | 14 |  |  |
| Net income | 404 |  |  |  | 156 |  |  |
| Less: Income attributable to noncontrolling interests | 30 |  |  |  | 38 |  |  |
| Net income attributable to JCI | $ | 374 |  |  |  | $ | 118 |  |  |
| Diluted earnings per share | $ | 0.55 |  |  |  | $ | 0.17 |  |  |
| Diluted weighted average shares | 682.4 |  |  |  | 690.3 |  |  |
| Shares outstanding at period end | 681.5 |  |  |  | 687.2 |  |  |

[0000833444-24-000007:8k_2_02:87]
Page 9 of 16

[0000833444-24-000007:8k_2_02:88]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | December 31,2023 |  | September 30,2023 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 1,801 |  |  | $ | 835 |  |
| Accounts receivable - net | 6,045 |  |  | 6,006 |  |
| Inventories | 3,006 |  |  | 2,776 |  |
| Other current assets | 1,202 |  |  | 1,120 |  |
|  | Current assets | 12,054 |  |  | 10,737 |  |
| Property, plant and equipment - net | 3,131 |  |  | 3,136 |  |
| Goodwill | 18,124 |  |  | 17,936 |  |
| Other intangible assets - net | 4,835 |  |  | 4,888 |  |
| Investments in partially-owned affiliates | 1,144 |  |  | 1,056 |  |
| Other noncurrent assets | 4,693 |  |  | 4,489 |  |
|  | Total assets | $ | 43,981 |  |  | $ | 42,242 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 2,650 |  |  | $ | 1,030 |  |
| Accounts payable and accrued expenses | 4,910 |  |  | 5,226 |  |
| Other current liabilities | 4,849 |  |  | 4,828 |  |
|  | Current liabilities | 12,409 |  |  | 11,084 |  |
| Long-term debt | 7,959 |  |  | 7,818 |  |
| Other noncurrent liabilities | 5,739 |  |  | 5,646 |  |
| Shareholders' equity attributable to JCI | 16,698 |  |  | 16,545 |  |
| Noncontrolling interests | 1,176 |  |  | 1,149 |  |
|  | Total liabilities and equity | $ | 43,981 |  |  | $ | 42,242 |  |

[0000833444-24-000007:8k_2_02:89]
Page 10 of 16

[0000833444-24-000007:8k_2_02:90]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Three Months Ended December 31, |
|  |  |  |  |  |  | 2023 |  |  | 2022 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI | $ | 374 |  |  |  | $ | 118 |  |
| Income attributable to noncontrolling interests | 30 |  |  |  | 38 |  |
| Net income | 404 |  |  |  | 156 |  |
| Adjustments to reconcile net income to cash used by operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 231 |  |  |  | 203 |  |
|  |  | Pension and postretirement benefit income | (10) |  |  |  | (6) |  |
|  |  | Pension and postretirement contributions | (6) |  |  |  | (9) |  |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (56) |  |  |  | (56) |  |
|  |  | Deferred income taxes | (70) |  |  |  | (92) |  |
|  |  | Noncash restructuring and impairment costs | 9 |  |  |  | 294 |  |
|  |  | Other - net | 8 |  |  |  | 3 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | 61 |  |  |  | (88) |  |
|  |  |  |  | Inventories | (203) |  |  |  | (348) |  |
|  |  |  |  | Other assets | (191) |  |  |  | (68) |  |
|  |  |  |  | Restructuring reserves | (14) |  |  |  | 14 |  |
|  |  |  |  | Accounts payable and accrued liabilities | (414) |  |  |  | (338) |  |
|  |  |  |  | Accrued income taxes | 5 |  |  |  | 39 |  |
|  |  |  |  |  | Cash used by operating activities | (246) |  |  |  | (296) |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (92) |  |  |  | (134) |  |
| Acquisition of businesses, net of cash acquired | (2) |  |  |  | (79) |  |
| Other - net | 20 |  |  |  | 24 |  |
|  |  |  |  |  | Cash used by investing activities | (74) |  |  |  | (189) |  |
| Financing Activities |  |  |  |  |
| Increase in short and long-term debt - net | 1,530 |  |  |  | 420 |  |
| Stock repurchases and retirements | — |  |  |  | (154) |  |
| Payment of cash dividends | (252) |  |  |  | (241) |  |
| Other - net | (50) |  |  |  | (16) |  |
|  |  |  |  |  | Cash provided by financing activities | 1,228 |  |  |  | 9 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 60 |  |  |  | (14) |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | $ | 968 |  |  |  | $ | (490) |  |

[0000833444-24-000007:8k_2_02:91]
Page 11 of 16

[0000833444-24-000007:8k_2_02:92]
FOOTNOTES

[0000833444-24-000007:8k_2_02:93]
1. Financial Summary

[0000833444-24-000007:8k_2_02:94]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net mark-to-market adjustments related to restricted asbestos investments and pension and postretirement plans, restructuring and impairment costs and net financing charges.

[0000833444-24-000007:8k_2_02:95]
| (in millions; unaudited) | Three Months Ended December 31, |
|  | 2023 |  | 2022 |
|  | Actual |  | AdjustedNon-GAAP |  | Actual |  | AdjustedNon-GAAP |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 285 |  |  | $ | 285 |  |  | $ | 267 |  |  | $ | 267 |  |
| Building Solutions EMEA/LA | 80 |  |  | 80 |  |  | 75 |  |  | 75 |  |
| Building Solutions Asia Pacific | 46 |  |  | 46 |  |  | 68 |  |  | 68 |  |
| Global Products | $ | 369 |  |  | $ | 369 |  |  | $ | 382 |  |  | $ | 422 |  |
| Net income attributable to JCI | $ | 374 |  |  | $ | 350 |  |  | $ | 118 |  |  | $ | 463 |  |
| Income attributable to noncontrolling interests (2) | 30 |  |  | 32 |  |  | 38 |  |  | 38 |  |
| Net Income | 404 |  |  | 382 |  |  | 156 |  |  | 501 |  |
| Less: Income tax benefit (provision) (3) | 1 |  |  | (61) |  |  | (14) |  |  | (78) |  |
| Income before income taxes | 403 |  |  | 443 |  |  | 170 |  |  | 579 |  |
| Net financing charges | 99 |  |  | 99 |  |  | 67 |  |  | 67 |  |
| EBIT (4) | $ | 502 |  |  | $ | 542 |  |  | $ | 237 |  |  | $ | 646 |  |
| EBIT margin (4) | 8.2 | % |  | 8.9 | % |  | 3.9 | % |  | 10.6 | % |

[0000833444-24-000007:8k_2_02:96]
(1) The Company's press release contains financial information regarding adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures. The Company's definition of adjusted segment EBITA excludes other non-recurring items that are not considered to be directly related to the underlying operating performance of its businesses. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-24-000007:8k_2_02:97]
The following is the three months ended December 31, 2023 and 2022 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-24-000007:8k_2_02:98]
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building SolutionsAsia Pacific |  | Global Products |  |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  |
| Segment EBITA as reported | $ | 285 |  |  | $ | 267 |  |  | $ | 80 |  |  | $ | 75 |  |  | $ | 46 |  |  | $ | 68 |  |  | $ | 369 |  |  | $ | 382 |  |  |
| Segment EBITA margin as reported (5) | 11.5 | % |  | 11.3 | % |  | 7.7 | % |  | 7.7 | % |  | 9.1 | % |  | 10.5 | % |  | 17.9 | % |  | 18.4 | % |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Warehouse fire loss | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 40 |  |  |
| Adjusted segment EBITA | $ | 285 |  |  | $ | 267 |  |  | $ | 80 |  |  | $ | 75 |  |  | $ | 46 |  |  | $ | 68 |  |  | $ | 369 |  |  | $ | 422 |  |  |
| Adjusted segment EBITA margin (5) | 11.5 | % |  | 11.3 | % |  | 7.7 | % |  | 7.7 | % |  | 9.1 | % |  | 10.5 | % |  | 17.9 | % |  | 20.3 | % |  |

[0000833444-24-000007:8k_2_02:99]
(2) Adjusted income attributable to noncontrolling interests for the three months ended December 31, 2023 excludes impact from restructuring and impairment costs of $2 million.

[0000833444-24-000007:8k_2_02:100]
(3) Adjusted income tax provision for the three months ended December 31, 2023 excluded tax benefits related to Switzerland tax reform of $80 million and  the net tax benefit of pre-tax adjusting items of $5 million, partially offset by tax provisions related to China APB23 adjustments of $23 million. Adjusted income tax provision for the three months ended December 31, 2022 excludes the net tax benefit of pre-tax adjusting items of $64 million.

[0000833444-24-000007:8k_2_02:101]
(4) Management defines earnings before interest and taxes (EBIT) as income before net financing charges, income taxes and noncontrolling interests. EBIT margin is defined as EBIT divided by net sales. EBIT and EBIT margin are non-GAAP performance measures. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company. A reconciliation of net income to EBIT is shown earlier within this footnote. Adjusted EBIT for the three months ended December 31, 2023 excludes restructuring and impairment costs of $39 million, net mark-to-market gains on restricted asbestos investments of $22 million and certain cyber incident costs of $23 million. Adjusted EBIT for the three months ended December 31, 2022 excludes restructuring and impairment costs of $345 million, net mark-to-market gains on restricted asbestos investments and pension and postretirement plans of $3 million and certain transaction/separation costs of $27 million.

[0000833444-24-000007:8k_2_02:102]
(5) Segment EBITA margin is defined as segment EBITA divided by segment net sales, as disclosed in the Company's press release.

[0000833444-24-000007:8k_2_02:103]
The Company's press release and earnings presentation include forward-looking statements regarding organic revenue growth, adjusted segment EBITA margin improvement, adjusted free cash flow and adjusted EPS, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as mark-to-market adjustments. Organic revenue growth excludes the effect of acquisitions, divestitures and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s fiscal 2024 second quarter and full year GAAP financial results.

[0000833444-24-000007:8k_2_02:104]
Page 12 of 16

[0000833444-24-000007:8k_2_02:105]
2.  Diluted Earnings Per Share Reconciliation

[0000833444-24-000007:8k_2_02:106]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items shown in the table below are excluded because these items are not considered to be directly related to the underlying operating performance of the Company. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-24-000007:8k_2_02:107]
A reconciliation of diluted earnings per share as reported to adjusted diluted earnings per share for the respective periods is shown below (unaudited):

[0000833444-24-000007:8k_2_02:108]
|  | Net Income Attributableto JCI plc |  |  |  |  |  |
|  | Three Months Ended |  |  |  |  |  |
|  | December 31, |  |  |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |  |  |  |  |  |
| Earnings per share as reported for JCI plc | $ | 0.55 |  |  | $ | 0.17 |  |  |  |  |  |  |  |  |  |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | (0.03) |  |  | — |  |  |  |  |  |  |  |  |  |  |
| Related tax impact | 0.01 |  |  | — |  |  |  |  |  |  |  |  |  |  |
| Restructuring and impairment costs | 0.05 |  |  | 0.50 |  |  |  |  |  |  |  |  |  |  |
| Related tax impact | (0.01) |  |  | (0.08) |  |  |  |  |  |  |  |  |  |  |
| Transaction/separation costs | — |  |  | 0.04 |  |  |  |  |  |  |  |  |  |  |
| Cyber incident costs | 0.03 |  |  | — |  |  |  |  |  |  |  |  |  |  |
| Warehouse fire loss | — |  |  | 0.06 |  |  |  |  |  |  |  |  |  |  |
| Related tax impact | — |  |  | (0.01) |  |  |  |  |  |  |  |  |  |  |
| Net discrete tax items | (0.08) |  |  | — |  |  |  |  |  |  |  |  |  |  |
| Adjusted earnings per share for JCI plc* | $ | 0.51 |  |  | $ | 0.67 |  |  |  |  |  |  |  |  |  |  |

[0000833444-24-000007:8k_2_02:109]
* May not sum due to rounding

[0000833444-24-000007:8k_2_02:110]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-24-000007:8k_2_02:111]
|  | Three Months Ended |  |  |  |  |  |  |
|  | December 31, |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |  |  |  |  |
| Weighted average shares outstanding for JCI plc |  |  |  |  |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 680.7 |  |  | 687.0 |  |  |  |  |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock |  |  |  |  |  |  |  |  |  |  |  |
| and unvested performance share awards | 1.7 |  |  | 3.3 |  |  |  |  |  |  |  |  |  |
| Diluted weighted average shares outstanding | 682.4 |  |  | 690.3 |  |  |  |  |  |  |  |  |  |

[0000833444-24-000007:8k_2_02:112]
Page 13 of 16

[0000833444-24-000007:8k_2_02:113]
3. Organic Growth Reconciliation

[0000833444-24-000007:8k_2_02:114]
The components of the change in net sales for the three months ended December 31, 2023 versus the three months ended December 31, 2022, including organic growth, are shown below (unaudited):

[0000833444-24-000007:8k_2_02:115]
| (in millions) | Net Sales for the Three Months Ended December 31, 2022 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the Three Months EndedDecember 31, 2022 |  | Acquisitions |  | Organic Growth |  | Net Sales for the Three Months EndedDecember 31, 2023 |
| Building Solutions North America | $ | 2,367 |  |  | $ | — |  | — |  |  | $ | 6 |  | — |  |  | $ | 2,373 |  |  | $ | 16 |  | 1 | % |  | $ | 98 |  | 4 | % |  | $ | 2,487 |  | 5 | % |
| Building Solutions EMEA/LA | 975 |  |  | — |  | — |  |  | 42 |  | 4 | % |  | 1,017 |  |  | 3 |  | — |  |  | 18 |  | 2 | % |  | 1,038 |  | 6 | % |
| Building Solutions Asia Pacific | 646 |  |  | (17) |  | -3 | % |  | (10) |  | -2 | % |  | 619 |  |  | 19 |  | 3 | % |  | (131) |  | -21 | % |  | 507 |  | -22 | % |
| Total Building Solutions | 3,988 |  |  | (17) |  | — |  |  | 38 |  | 1 | % |  | 4,009 |  |  | 38 |  | 1 | % |  | (15) |  | — |  |  | 4,032 |  | 1 | % |
| Global Products | 2,080 |  |  | (2) |  | — |  |  | (10) |  | — |  |  | 2,068 |  |  | 22 |  | 1 | % |  | (28) |  | -1 | % |  | 2,062 |  | -1 | % |
| Total net sales | $ | 6,068 |  |  | $ | (19) |  | — |  |  | $ | 28 |  | — |  |  | $ | 6,077 |  |  | $ | 60 |  | 1 | % |  | $ | (43) |  | -1 | % |  | $ | 6,094 |  | — |  |

[0000833444-24-000007:8k_2_02:116]
The components of the change in total service revenue for the three months ended December 31, 2023 versus the three months ended December 31, 2022, including organic growth, is shown below (unaudited):

[0000833444-24-000007:8k_2_02:117]
| (in millions) | Service Revenuefor theThree Months EndedDecember 31, 2022 |  | Base Year Adjustments -Divestitures and Other |  | Base Year Adjustments-Foreign Currency |  | Adjusted Base ServiceRevenue for theThree Months EndedDecember 31, 2022 |  | Acquisitions |  | Organic Growth |  | Service Revenuefor the Three Months EndedDecember 31, 2023 |
| Building Solutions North America | $ | 916 |  |  | $ | — |  | — |  |  | $ | 1 |  | — |  |  | $ | 917 |  |  | $ | 14 |  | 2 | % |  | $ | 38 |  | 4 | % |  | $ | 969 |  | 6 | % |
| Building Solutions EMEA/LA | 423 |  |  | (1) |  | — |  |  | 8 |  | 2 | % |  | 430 |  |  | 2 |  | — |  |  | 34 |  | 8 | % |  | 466 |  | 10 | % |
| Building Solutions Asia Pacific | 173 |  |  | (17) |  | -10 | % |  | (2) |  | -1 | % |  | 154 |  |  | 8 |  | 5 | % |  | 8 |  | 5 | % |  | 170 |  | -2 | % |
| Total Business Solutions | 1,512 |  |  | (18) |  | -1 | % |  | 7 |  | — |  |  | 1,501 |  |  | 24 |  | 2 | % |  | 80 |  | 5 | % |  | 1,605 |  | 6 | % |
| Global Products | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  |  | — |  | — |  |  | — |  | — |  |  | — |  | — |  |
| Total service revenue | $ | 1,512 |  |  | $ | (18) |  | -1 | % |  | $ | 7 |  | — |  |  | $ | 1,501 |  |  | $ | 24 |  | 2 | % |  | $ | 80 |  | 5 | % |  | $ | 1,605 |  | 6 | % |

[0000833444-24-000007:8k_2_02:118]
The components of the change in total install revenue for the three months ended December 31, 2023 versus the three months ended December 31, 2022, including organic growth, is shown below (unaudited):

[0000833444-24-000007:8k_2_02:119]
| (in millions) | Install Revenue for the Three Months Ended December 31, 2022 |  | Base Year Adjustments -Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base Install Revenue for the Three Months EndedDecember 31, 2022 |  | Acquisitions |  | Organic Growth |  | Install Revenue for theThree Months EndedDecember 31, 2023 |
| Building Solutions North America | $ | 1,451 |  |  | $ | — |  | — |  |  | $ | 5 |  | — |  |  | $ | 1,456 |  |  | $ | 2 |  | — |  |  | $ | 60 |  | 4 | % |  | $ | 1,518 |  | 5 | % |
| Building Solutions EMEA/LA | 552 |  | 1 | — |  |  | 34 | 6 | % |  | 587 |  | 1 | — |  |  | (16) |  | -3 | % |  | 572 | 4 | % |
| Building Solutions Asia Pacific | 473 |  | — |  | — |  |  | (8) |  | -2 | % |  | 465 |  | 11 | 2 | % |  | (139) |  | -30 | % |  | 337 | -29 | % |
| Total Building Solutions | 2,476 |  |  | 1 |  | — |  |  | 31 |  | 1 | % |  | 2,508 |  |  | 14 |  | 1 | % |  | (95) |  | -4 | % |  | 2,427 |  | -2 | % |
| Global Products | 2,080 |  |  | (2) |  | — |  |  | (10) |  | — |  |  | 2,068 |  |  | 22 | 1 | % |  | (28) |  | -1 | % |  | 2,062 |  | -1 | % |
| Total install revenue | $ | 4,556 |  |  | $ | (1) |  | — |  |  | $ | 21 |  | — |  |  | $ | 4,576 |  |  | $ | 36 |  | 1 | % |  | $ | (123) |  | -3 | % |  | $ | 4,489 |  | -1 | % |

[0000833444-24-000007:8k_2_02:120]
Page 14 of 16

[0000833444-24-000007:8k_2_02:121]
4.   Adjusted Free Cash Flow Conversion

[0000833444-24-000007:8k_2_02:122]
The Company's press release contains financial information regarding adjusted free cash flow and adjusted free cash flow conversion, which are non-GAAP performance measures. We also present below free cash flow conversion from the GAAP measure of net income attributable to JCI. Effective January 1, 2023, the Company has excluded the impact of its financing entity, JC Capital, from the calculation of adjusted free cash flow. Management believes this provides a more true representation of the Company’s operational ability to convert cash, without the contrary impact from financing activities. The impact on interim and annual periods prior to January 1, 2023 was not material. JC Capital cash flows that are excluded from the calculation of adjusted free cash flow primarily include activity associated with finance/notes receivables and inventory and/or capital expenditures related to lease arrangements. JC Capital net income that is excluded is primarily related to interest income on the finance/notes receivable and profit recognized on arrangements with sales-type lease components.

[0000833444-24-000007:8k_2_02:123]
Adjusted free cash flow is defined as cash provided (used) by operating activities, excluding JC Capital, less capital expenditures, excluding JC Capital. Free cash flow conversion from net income is defined as free cash flow divided by net income attributable to JCI. Adjusted free cash flow conversion is defined as free cash flow divided by adjusted net income attributable to JCI, excluding JC Capital. Management believes these non-GAAP measures are useful to investors in understanding the strength of the Company and its ability to generate cash. These non-GAAP measures can also be used to evaluate our ability to generate cash flow from operations and the impact that this cash flow has on our liquidity.

[0000833444-24-000007:8k_2_02:124]
The following is the three months ended December 31, 2023 and 2022 calculation of free cash flow and adjusted free cash flow (unaudited):

[0000833444-24-000007:8k_2_02:125]
|  | Three Months EndedDecember 31, 2023 |  | Three Months EndedDecember 31, 2022 |  |  |  |  |
| (in millions) | Consolidated JCI plc |  | Consolidated JCI plc,excluding JC Capital |  | Consolidated JCI plc |  | Consolidated JCI plc,excluding JC Capital |  |  |  |  |  |  |
| Cash used by operating activities | $ | (246) |  | $ | (158) |  | $ | (296) |  | $ | (296) |  |  |  |  |  |  |
| Capital expenditures | (92) |  | (92) |  | (134) |  | (134) |  |  |  |  |  |  |
| Free cash flow / Adjusted free cash flow (excluding JC Capital) | $ | (338) |  | $ | (250) |  | $ | (430) |  | $ | (430) |  |  |  |  |  |  |

[0000833444-24-000007:8k_2_02:126]
The following is the three months ended December 31, 2023 and 2022 calculation of free cash flow conversion from net income and adjusted free cash flow conversion (unaudited):

[0000833444-24-000007:8k_2_02:127]
|  | Three Months EndedDecember 31, 2023 |  | Three Months EndedDecember 31, 2022 |
| (in millions) | Consolidated JCI plc |  | Consolidated JCI plc,excluding JC Capital |  | Consolidated JCI plc |  | Consolidated JCI plc,excluding JC Capital |
| Net income attributable to JCI | $ | 374 |  | $ | 372 |  | $ | 118 |  | $ | 118 |
| Free cash flow conversion from net income | -90% |  | -67% |  | -364% |  | -364% |
| Adjusted net income attributable to JCI | $ | 350 |  | $ | 348 |  | $ | 463 |  | $ | 463 |
| Adjusted free cash flow conversion | -97% |  | -72% |  | -93% |  | -93% |

[0000833444-24-000007:8k_2_02:128]
Page 15 of 16

[0000833444-24-000007:8k_2_02:129]
5.  Debt Ratios

[0000833444-24-000007:8k_2_02:130]
The Company's earnings presentation provides financial information regarding net debt to adjusted EBITDA, which is a non-GAAP performance measure. We also present below net debt to income before income taxes. The Company believes these ratios are useful to understanding the Company's financial condition as they provide an overview of the extent to which the Company relies on external debt financing for its funding and are a measure of risk to its shareholders. The following is the December 31, 2023, September 30, 2023, and December 31, 2022 calculation of net debt to income before income taxes and net debt to adjusted EBITDA (unaudited):

[0000833444-24-000007:8k_2_02:131]
| (in millions) | December 31, 2023 |  | September 30, 2023 |  | December 31, 2022 |  |  |
| Short-term debt and current portion of long-term debt | $ | 2,650 |  |  | $ | 1,030 |  |  | $ | 1,963 |  |  |  |
| Long-term debt | 7,959 |  |  | 7,818 |  |  | 7,784 |  |  |  |
| Total debt | 10,609 |  |  | 8,848 |  |  | 9,747 |  |  |  |
| Less: cash and cash equivalents | 1,801 |  |  | 835 |  |  | 1,509 |  |  |  |
| Total net debt | $ | 8,808 |  |  | $ | 8,013 |  |  | $ | 8,238 |  |  |  |
| Last twelve months income before income taxes | $ | 1,943 |  |  | $ | 1,710 |  |  | $ | 1,390 |  |  |  |
| Total net debt to income before income taxes | 4.5x |  | 4.7x |  | 5.9x |  |  |
| Last twelve months adjusted EBITDA | $ | 4,051 |  |  | $ | 4,127 |  |  | $ | 3,783 |  |  |  |
| Total net debt to adjusted EBITDA | 2.2x |  | 1.9x |  | 2.2x |  |  |

[0000833444-24-000007:8k_2_02:132]
The following is the last twelve months ended December 31, 2023, September 30, 2023, and December 31, 2022 reconciliation of net income to adjusted EBIT and adjusted EBITDA, which are non-GAAP performance measures (unaudited):

[0000833444-24-000007:8k_2_02:133]
| (in millions) | Last Twelve MonthsEndedDecember 31, 2023 |  | Last Twelve MonthsEndedSeptember 30, 2023 |  | Last Twelve MonthsEndedDecember 31, 2022 |  |  |
| Net income | $ | 2,281 |  |  | $ | 2,033 |  |  | $ | 1,460 |  |  |  |
| Income tax benefit | (338) |  |  | (323) |  |  | (70) |  |  |  |
| Net financing charges | 313 |  |  | 281 |  |  | 227 |  |  |  |
| EBIT | 2,256 |  |  | 1,991 |  |  | 1,617 |  |  |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | 73 |  |  | 92 |  |  | 20 |  |  |  |
| Restructuring and impairment costs | 758 |  |  | 1,064 |  |  | 1,017 |  |  |  |
| Environmental remediation and related reserves adjustment | — |  |  | — |  |  | 255 |  |  |  |
| Silent-Aire other nonrecurring costs | — |  |  | — |  |  | 6 |  |  |  |
| Silent-Aire earn-out adjustment | (30) |  |  | (30) |  |  | (43) |  |  |  |
| Charges attributable to the suspension of operations in Russia | — |  |  | — |  |  | 11 |  |  |  |
| Warehouse fire loss | — |  |  | 40 |  |  | 40 |  |  |  |
| Cyber incident costs | 23 |  |  | — |  |  | — |  |  |  |
| Transaction/separation costs | 95 |  |  | 122 |  |  | 57 |  |  |  |
| Adjusted EBIT (1) | 3,175 |  |  | 3,279 |  |  | 2,980 |  |  |  |
| Depreciation and amortization | 876 |  |  | 848 |  |  | 803 |  |  |  |
| Adjusted EBITDA (1) | $ | 4,051 |  |  | $ | 4,127 |  |  | $ | 3,783 |  |  |  |

[0000833444-24-000007:8k_2_02:134]
(1) The Company's definition of adjusted EBIT and adjusted EBITDA excludes special items that are not considered to be directly related to the underlying operating performance of its businesses. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-24-000007:8k_2_02:135]
6.  Income Taxes

[0000833444-24-000007:8k_2_02:136]
The Company's effective tax rate excluding net mark-to-market adjustments, restructuring and impairment costs, discrete tax items, certain transaction/separation costs, cyber incident costs and warehouse fire loss for the three months ending December 31, 2023 and December 31, 2022 is approximately 13.75% and 13.5%, respectively.

[0000833444-24-000007:8k_2_02:137]
Page 16 of 16
