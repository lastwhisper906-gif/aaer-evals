# JCI note change history — 0000833444-23-000030 → 0000833444-24-000011


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-01-30):
[0000833444-24-000011:note_history:1]
|  | December 31, 2023 |  | September 30, 2023 |
| Other current liabilities | $ | 31 |  |  | $ | 31 |  |
| Other noncurrent liabilities | 201 |  |  | 211 |  |
| Total reserves for environmental liabilities | $ | 232 |  |  | $ | 242 |  |
  (was, 2023-08-02, similarity 0.9706):
[0000833444-23-000030:note_history:1]
|  | June 30, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 38 |  |  | $ | 66 |  |
| Other noncurrent liabilities | 214 |  |  | 220 |  |
| Total reserves for environmental liabilities | $ | 252 |  |  | $ | 286 |  |

- changed (2024-01-30):
[0000833444-24-000011:note_history:2]
The Company periodically examines whether the contingent liabilities related to the environmental matters described below are probable and reasonably estimable based on experience and ongoing developments in those matters, including continued study and analysis of ongoing remediation obligations. The Company expects that it will pay the amounts recorded over an estimated period of up to 20 years. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals for environmental liabilities at this time.
  (was, 2023-08-02, similarity 0.6162):
[0000833444-23-000030:note_history:2]
The Company periodically examines whether the contingent liabilities related to the environmental matters described below are probable and reasonably estimable based on experience and ongoing developments in those matters, including continued study and analysis of ongoing remediation obligations. During the three months ended September 30, 2022, with the assistance of independent environmental consultants and taking into consideration investigation and remediation actions previously completed, new information available to the Company during the fourth quarter of fiscal 2022 and ongoing discussions with the Wisconsin Department of Natural Resources ("WDNR"), the Company completed a comprehensive long-term analysis and cost assessment related to the Company’s ongoing environmental remediation obligations. As a result of this analysis, the Company increased its accrual for environmental liabilities by $228 million in the fourth quarter of fiscal 2022, which are recorded on an undiscounted basis. The Company expects that it will pay the amounts recorded over an estimated period of up to 20 years. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals for environmental liabilities at this time.

- added (2024-01-30):
[0000833444-24-000011:note_history:3]
A substantial portion of the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to fire-fighting foams containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).

- added (2024-01-30):
[0000833444-24-000011:note_history:4]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. On July 18, 2023, Tyco Fire Products announced that it plans to discontinue the production and sale of fluorinated firefighting foams by June 2024, including AFFF products, and will transition to non-fluorinated foam alternatives.

- changed (2024-01-30):
[0000833444-24-000011:note_history:5]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency (“EPA”) to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.
  (was, 2023-08-02, similarity 0.9692):
[0000833444-23-000030:note_history:5]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency (“EPA”) to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the WDNR to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

- added (2024-01-30):
[0000833444-24-000011:note_history:6]
Tyco Fire Products is operating and monitoring at the FTC a Groundwater Extraction and Treatment System ("GETS"), a permanent groundwater remediation system that extracts groundwater containing PFAS, treats it using advanced filtration systems, and returns the treated water to the environment. Tyco Fire Products has also completed the removal and disposal of PFAS-affected soil from the FTC. The Company's reserves for continued remediation of the FTC, the Stanton Street Facility and surrounding areas in Marinette and Peshtigo are based on estimates of costs associated with the long-term

- added (2024-01-30):
[0000833444-24-000011:note_history:7]
remediation actions, including the continued operation of the GETS, the implementation of long-term drinking water solutions for the area impacted by groundwater migrating from the FTC, continued monitoring and testing of groundwater monitoring wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

- added (2024-01-30):
[0000833444-24-000011:note_history:8]
PFOA, PFOS, and other PFAS compounds are being studied by EPA and other environmental and health agencies and researchers. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. In March 2023, EPA announced a proposed National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR proposes establishing legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion for each of PFOA and PFOS. The EPA has stated that it intends to propose two rules relating to PFAS under the Resource Conservation and Recovery Act (“RCRA”): one rule would list four PFAS (PFOA, PFOS, PFBS, and GenX) as “hazardous constituents,” and a second rule would clarify that hazardous constituents are subject to RCRA's corrective action program.

- added (2024-01-30):
[0000833444-24-000011:note_history:9]
In August 2022, EPA published a proposed rule that would designate PFOA and PFOS as “hazardous substances” under Comprehensive Environmental Response, Compensation and Liability Act ("CERCLA"). In April 2023, EPA issued an Advanced Notice of Proposed Rulemaking ("ANPR") seeking input on whether it should expand the proposed rule to designate as "hazardous substances" under CERCLA: (1) seven additional PFAS; (2) the precursors to PFOA, PFOS, and the seven additional PFAS; or (3) entire categories of PFAS. The EPA indicated that it anticipates finalizing the regulation by March 2024.

- added (2024-01-30):
[0000833444-24-000011:note_history:10]
It is not possible to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in soil, groundwater and drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- changed (2024-01-30):
[0000833444-24-000011:note_history:11]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $10 million and $13 million at December 31, 2023 and September 30, 2023, respectively.
  (was, 2023-08-02, similarity 0.9817):
[0000833444-23-000030:note_history:11]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $13 million and $17 million at June 30, 2023 and September 30, 2022, respectively.

- added (2024-01-30):
[0000833444-24-000011:note_history:12]
FTC-Related Matters

- changed (2024-01-30):
[0000833444-24-000011:note_history:13]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water in February 2022, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. The WDNR initiated a rulemaking proceeding that would establish groundwater quality standards for PFOA, PFOS, perfluorobutane sulfonic acid and its potassium salt (“PFBS”) and hexafluoropropylene oxide dimer acid and its ammonium salt (“HFPO-DA”). Pursuant to state law, the WDNR has stopped work on the proposed rule and notified the state legislature that, following economic analysis, the proposed costs would exceed statutory thresholds. As a result, the state legislature is required to authorize the WDNR to allow the rulemaking to continue.
  (was, 2023-08-02, similarity 0.6237):
[0000833444-23-000030:note_history:13]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water in February 2022, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. In December 2022, the Governor of Wisconsin and WDNR approved a scope statement setting out parameters for the WDNR to draft a final rule regarding groundwater quality standards for PFOA and PFOS. The WDNR is now in the process of drafting the rule.

- added (2024-01-30):
[0000833444-24-000011:note_history:14]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and

- changed (2024-01-30):
[0000833444-24-000011:note_history:15]
spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. The WDNR issued a further letter regarding the issue on November 4, 2019. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to that date. On April 10, 2023, the WDNR issued a third “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids in the Marinette region. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions, including the potential assessment of penalties.
  (was, 2023-08-02, similarity 0.7944):
[0000833444-23-000030:note_history:15]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. Tyco Fire Products responded to the WDNR’s letter by requesting additional necessary information. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 3, 2019 letter. The WDNR issued a further letter regarding the issue on November 4, 2019. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to that date. Tyco Fire Products responded to the WDNR’s September 2021 notice by the December 27, 2021 deadline set by WDNR and submitted additional updates to WDNR on October 25, 2022 and February 16, 2023. On April 10, 2023, the WDNR issued a third “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids in the Marinette region. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

- changed (2024-01-30):
[0000833444-24-000011:note_history:16]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR's requests. The parties are proceeding with fact discovery and the court has set a trial date of December 3, 2024.
  (was, 2023-08-02, similarity 0.8903):
[0000833444-23-000030:note_history:16]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR’s requests. The parties are proceeding with fact discovery and the court has set a trial date of December 3, 2024. The Company is vigorously defending this civil enforcement action and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

- changed (2024-01-30):
[0000833444-24-000011:note_history:17]
In October 2022, the Town of Peshtigo filed a tort action in Wisconsin state court against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and ChemDesign, Inc. relating to environmental matters at the FTC (Town of Peshtigo v. Tyco Fire Products L.P. et al., Case No. 2022CV000234 (filed October 18, 2022 in Circuit Court in Marinette County, Wisconsin)). The Town alleges that use of AFFF products at the FTC caused contamination of water supplies in Peshtigo. The Town seeks monetary penalties and an injunction ordering abatement of PFAS contamination in Peshtigo. The case has been removed to federal court and transferred to a multi-district litigation ("MDL") before the United States District Court for the District of South Carolina.
  (was, 2023-08-02, similarity 0.8808):
[0000833444-23-000030:note_history:17]
In October 2022, the Town of Peshtigo filed a tort action in Wisconsin state court against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and ChemDesign, Inc. relating to environmental matters at the FTC (Town of Peshtigo v. Tyco Fire Products L.P. et al., Case No. 2022CV000234 (filed October 18, 2022 in Circuit Court in Marinette County, Wisconsin)). The Town alleges that use of AFFF products at the FTC caused contamination of water supplies in Peshtigo. The Town seeks monetary penalties and an injunction ordering abatement of PFAS contamination in Peshtigo. The case has been removed to federal court and transferred to a multi-district litigation ("MDL") before the United States District Court for the District of South Carolina. The Company plans to vigorously defend against this case and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

- changed (2024-01-30):
[0000833444-24-000011:note_history:18]
In November 2022, individuals filed six actions in Dane County, Wisconsin alleging personal injury and/or property damage against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and other unaffiliated defendants related to environmental matters at the FTC. Plaintiffs allege that use of AFFF products at the FTC and activities by third parties unrelated to the Company contaminated nearby drinking water sources, surface waters, and other natural resources and properties, including their personal properties. The individuals seek monetary damages for their personal injury and/or property damage. These lawsuits have been transferred to the MDL. Subsequently, several additional plaintiffs have direct-filed in the MDL complaints with similar allegations.
  (was, 2023-08-02, similarity 0.8555):
[0000833444-23-000030:note_history:18]
In November 2022, individuals filed six actions in Dane County, Wisconsin alleging personal injury and/or property damage against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and other unaffiliated defendants related to environmental matters at the FTC. Plaintiffs allege that use of AFFF products at the FTC and activities by third parties unrelated to the Company contaminated nearby drinking water sources, surface waters, and other natural resources and properties, including their personal properties. The individuals seek monetary damages for their personal injury and/or property damage. These lawsuits have been transferred to the MDL. Subsequently, several additional plaintiffs have direct-filed in the MDL complaints with similar allegations. These lawsuits are presently at the beginning stages of litigation. The Company is vigorously defending these cases and believes that it has meritorious defenses, but the Company is presently unable to predict the duration, scope, or outcome of this action.

- added (2024-01-30):
[0000833444-24-000011:note_history:19]
These FTC-related lawsuits are presently at the beginning stages of litigation. The Company is vigorously defending each of these cases and believes that it has meritorious defenses, but it is presently unable to predict the duration, scope, or outcome of these actions.

- changed (2024-01-30):
[0000833444-24-000011:note_history:20]
Aqueous Film-Forming Foam ("AFFF") Matters
  (was, 2023-08-02, similarity 0.8506):
[0000833444-23-000030:note_history:20]
Aqueous Film-Forming Foam ("AFFF") Litigation

- added (2024-01-30):
[0000833444-24-000011:note_history:21]
AFFF Litigation

- changed (2024-01-30):
[0000833444-24-000011:note_history:22]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including
  (was, 2023-08-02, similarity 0.8779):
[0000833444-23-000030:note_history:22]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

- added (2024-01-30):
[0000833444-24-000011:note_history:23]
damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

- changed (2024-01-30):
[0000833444-24-000011:note_history:24]
Chemguard and Tyco Fire Products are named in 44 pending putative class actions in federal courts originating from 16 states and territories. All of these cases have been direct-filed in or transferred to the MDL. Tyco Fire Products was also recently named in a class action in British Columbia, Canada.
  (was, 2023-08-02, similarity 0.7069):
[0000833444-23-000030:note_history:24]
Chemguard and Tyco Fire Products are named in 41 pending putative class actions in federal courts originating from 16 states and territories. All but one of these cases have been direct-filed in or transferred to the MDL and it is anticipated that the remaining case will be transferred to the MDL.

- changed (2024-01-30):
[0000833444-24-000011:note_history:25]
There are more than 6,000 individual or “mass” actions pending that were filed in state or federal courts originating from 52 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 6,000 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly-filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona, Illinois and Virginia.
  (was, 2023-08-02, similarity 0.9775):
[0000833444-23-000030:note_history:25]
There are more than 4,700 individual or “mass” actions pending that were filed in state or federal courts originating from 52 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 4,700 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona and Illinois.

- changed (2024-01-30):
[0000833444-24-000011:note_history:26]
Chemguard and Tyco Fire Products have been named as defendants in more than 770 cases in federal and state courts involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 35 states and territories. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation. The MDL court set the first case for trial on June 5, 2023 (City of Stuart (Florida) v. 3M Co. et al.). On April 26, 2023, the parties entered a stipulation dismissing Chemguard with prejudice from the City of Stuart case, and on May 4, 2023 the parties entered into a stipulation dismissing Tyco with prejudice from the City of Stuart case. On June 5, 2023, the MDL court continued the trial date for the City of Stuart case, and the parties remaining in that case later reached settlement. The parties in the MDL designated four additional plaintiffs as water provider bellwether cases and conducted initial discovery into those cases. On December 19, 2023, the MDL court selected two of those cases to proceed into additional discovery. The parties have also identified 25 personal injury bellwether cases, which have entered into the first phase of bellwether discovery.
  (was, 2023-08-02, similarity 0.6833):
[0000833444-23-000030:note_history:26]
MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation. The MDL court set the first case for trial on June 5, 2023 (City of Stuart (Florida) v. 3M Co. et al.). On April 26, 2023, the parties entered a stipulation dismissing Chemguard with prejudice from the City of Stuart case, and on May 4, 2023 the parties entered into a stipulation dismissing Tyco with prejudice from the City of Stuart case. On June 5, 2023, the MDL court continued the trial date for the City of Stuart case, and the parties remaining in that case later reached settlement. The parties in the MDL are working to identify potential water provider and personal injury cases for additional bellwether phases.

- changed (2024-01-30):
[0000833444-24-000011:note_history:27]
AFFF State or U.S. Territory Attorneys General Litigation
  (was, 2023-08-02, similarity 0.832):
[0000833444-23-000030:note_history:27]
State or U.S. Territory Attorneys General Litigation related to AFFF

- changed (2024-01-30):
[0000833444-24-000011:note_history:28]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in
  (was, 2023-08-02, similarity 0.704):
[0000833444-23-000030:note_history:28]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al. No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

- added (2024-01-30):
[0000833444-24-000011:note_history:29]
Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

- changed (2024-01-30):
[0000833444-24-000011:note_history:30]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.
  (was, 2023-08-02, similarity 0.999):
[0000833444-23-000030:note_history:30]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al. (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al. (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al. (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

- changed (2024-01-30):
[0000833444-24-000011:note_history:31]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL. In October 2022, the Attorney General filed two similar lawsuits in the superior courts of the State of North Carolina regarding alleged PFAS damages at two additional locations. These two cases have also been removed to federal court and transferred to the MDL.
  (was, 2023-08-02, similarity 0.9658):
[0000833444-23-000030:note_history:31]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL. In October 2022, the Attorney General filed two similar lawsuits in the superior courts of the State of North Carolina regarding alleged PFAS damages at two additional locations. It is anticipated that these two cases will be removed to federal court and transferred to the MDL.

- added (2024-01-30):
[0000833444-24-000011:note_history:32]
In addition, 31 other states and territories have filed 33 lawsuits against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of each of those State's environmental and natural resources allegedly resulting from the manufacture, storage, sale, distribution, marketing, and use of PFAS-containing AFFF within each respective State. The states and territories are: Arkansas, Arizona, California, Colorado, Connecticut, Delaware, the District of Columbia, Florida, Hawaii, Illinois, Kentucky, Massachusetts, Maryland, Maine, Michigan, Mississippi, New Hampshire, New Jersey, New Mexico, Ohio, Oregon, Rhode Island, South Carolina, Tennessee, Texas, Vermont, Washington, Wisconsin, Guam, the Northern Mariana Islands, and Puerto Rico. All of these complaints, other than Hawaii and Connecticut, have been removed to federal court and transferred to the MDL. The Hawaii complaint has been removed to federal court and it is anticipated that it will be transferred to the MDL. It is anticipated that the Connecticut complaint will be removed to federal court and transferred to the MDL.

- added (2024-01-30):
[0000833444-24-000011:note_history:33]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. In September 2022, the AFFF MDL Court declined to grant summary judgment on the government contractor defense, ruling that various factual issues relevant to the defense must be decided by a jury rather than the Court. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin and a federal district court in South Carolina. The insurance litigation involves numerous factual and legal issues and remains at a relatively early stage. There are numerous factual and legal issues to be resolved in connection with these claims. The Company is presently unable to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

- added (2024-01-30):
[0000833444-24-000011:note_history:34]
|  | December 31, 2023 |  | September 30, 2023 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 359 |  |  | 364 |  |
| Total asbestos-related liabilities | 417 |  |  | 422 |  |
| Other current assets | 27 |  |  | 28 |  |
| Other noncurrent assets | 294 |  |  | 273 |  |
| Total asbestos-related assets | 321 |  |  | 301 |  |
| Net asbestos-related liabilities | $ | 96 |  |  | $ | 121 |  |

- added (2024-01-30):
[0000833444-24-000011:note_history:35]
|  | December 31, 2023 |  | September 30, 2023 |
| Restricted |  |  |  |
| Cash | $ | 19 |  |  | $ | 20 |  |
| Investments | 252 |  |  | 231 |  |
| Total restricted assets | 271 |  |  | 251 |  |
| Insurance receivables for asbestos-related liabilities | 50 |  |  | 50 |  |
| Total asbestos-related assets | $ | 321 |  |  | $ | 301 |  |

- changed (2024-01-30):
[0000833444-24-000011:note_history:36]
The amounts recorded for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption may impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.
  (was, 2023-08-02, similarity 0.995):
[0000833444-23-000030:note_history:36]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption may impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

- changed (2024-01-30):
[0000833444-24-000011:note_history:37]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage a portion of its insurable liabilities.
  (was, 2023-08-02, similarity 0.9543):
[0000833444-23-000030:note_history:37]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage its self-insured liabilities.

- changed (2024-01-30):
[0000833444-24-000011:note_history:38]
|  | December 31, 2023 |  | September 30, 2023 |
| Other current liabilities | $ | 87 |  |  | $ | 86 |  |
| Accrued compensation and benefits | 22 |  |  | 21 |  |
| Other noncurrent liabilities | 219 |  |  | 226 |  |
| Total self-insured liabilities | $ | 328 |  |  | $ | 333 |  |
  (was, 2023-08-02, similarity 0.9752):
[0000833444-23-000030:note_history:38]
|  | June 30, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 77 |  |  | $ | 89 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 232 |  |  | 230 |  |
| Total self-insured liabilities | $ | 331 |  |  | $ | 341 |  |

- changed (2024-01-30):
[0000833444-24-000011:note_history:39]
|  | December 31, 2023 |  | September 30, 2023 |
| Other current assets | $ | 6 |  |  | $ | 6 |  |
| Other noncurrent assets | 14 |  |  | 14 |  |
| Total insurance receivables | $ | 20 |  |  | $ | 20 |  |
  (was, 2023-08-02, similarity 0.9718):
[0000833444-23-000030:note_history:39]
|  | June 30, 2023 |  | September 30, 2022 |
| Other current assets | $ | 10 |  |  | $ | 10 |  |
| Other noncurrent assets | 20 |  |  | 20 |  |
| Total insurance receivables | $ | 30 |  |  | $ | 30 |  |

- changed (2024-01-30):
[0000833444-24-000011:note_history:40]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to the Company, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.
  (was, 2023-08-02, similarity 0.9905):
[0000833444-23-000030:note_history:40]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.

- removed (2024-01-30):
[0000833444-23-000030:note_history:41]
A substantial portion of the increase to the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to fire-fighting foams containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The increase in reserves was recorded as a result of several events that occurred in the three months ended September 30, 2022, including the completion and testing of the Groundwater Extraction and Treatment System (“GETS”) at the FTC (as further discussed below), the completion of resident surveys in Peshtigo regarding long-term drinking water solutions, correspondence with regulators on planned remediation activities, finalization of cost estimates for system upgrades and related long-term run rate costs in response to new permit requirements at the Stanton Street Facility, and the development of additional information through ongoing investigation and analysis. These events allowed the Company to develop estimates of costs associated with the long-term remediation actions expected to be performed over an estimated period of up to 20 years, including the continued operation of the GETS, the implementation of long-term drinking water solutions, continued monitoring and testing of the wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

- removed (2024-01-30):
[0000833444-23-000030:note_history:42]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports, or elsewhere. In May 2021, as part of Tyco Fire Products’ ongoing investigation and remediation program, the WDNR approved Tyco Fire Products’ proposed GETS, a permanent groundwater remediation system that extracts groundwater containing PFAS, treats it using advanced filtration systems, and returns the treated water to the environment. Tyco Fire Products has completed construction of the GETS, which is now in operation. Tyco Fire Products has also completed the removal and disposal of PFAS-affected soil from the FTC. Tyco Fire Products is also in the process of implementing a long-term drinking water solution in the form of deep aquifer private drinking wells for certain Peshtigo residents. On July 18, 2023, Tyco Fire Products announced that it plans to

- removed (2024-01-30):
[0000833444-23-000030:note_history:43]
discontinue the production and sale of fluorinated firefighting foams by June 2024, including AFFF products, and will transition to non-fluorinated foam alternatives.

- removed (2024-01-30):
[0000833444-23-000030:note_history:44]
PFOA, PFOS, and other PFAS compounds are being studied by EPA and other environmental and health agencies and researchers. EPA initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water and in June 2022 an updated set of interim health advisory levels for PFOA and PFOS in drinking water, as well as final health advisory levels for two other types of PFAS (PFBS and GenX chemicals). In November 2022, EPA added a class definition of PFAS to the final version of EPA's fifth Contaminant Candidate List ("CCL 5"), which is a list of substances not currently subject to national drinking water regulation, but which EPA believes may require future regulation. In March 2023, EPA announced a proposed National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR proposes establishing legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion for each of PFOA and PFOS. EPA indicated that it anticipates finalizing the regulation by the end of 2023.

- removed (2024-01-30):
[0000833444-23-000030:note_history:45]
In October 2021, EPA released its "PFAS Strategic Roadmap: EPA's Commitments to Action 2021-2024." The 2021-2024 Roadmap sets timelines by which EPA plans to take specific actions, including, among other items, publishing a national PFAS testing strategy, proposing to designate PFOA and PFOS as Comprehensive Environmental Response, Compensation and Liability Act (“CERCLA”) hazardous substances, restricting PFAS discharges from industrial sources through Effluent Limitations Guidelines, publishing the final toxicity assessment for five additional PFAS, requiring water systems to test for 29 PFAS under the Safe Drinking Water Act, and publishing improved analytical methods in eight different environmental matrices to monitor 40 PFAS present in wastewater and stormwater discharges. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains. In August 2022, EPA published a proposed rule that would designate PFOA and PFOS as “hazardous substances” under CERCLA. In April 2023, EPA issued an Advanced Notice of Proposed Rulemaking ("ANPR") seeking input on whether it should expand the proposed rule to designate as "hazardous substances" under CERCLA: (1) seven additional PFAS; (2) the precursors to PFOA, PFOS, and the seven additional PFAS; or (3) entire categories of PFAS.

- removed (2024-01-30):
[0000833444-23-000030:note_history:46]
It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial

- removed (2024-01-30):
[0000833444-23-000030:note_history:47]
condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- removed (2024-01-30):
[0000833444-23-000030:note_history:48]
FTC-Related Remediation and Litigation

- removed (2024-01-30):
[0000833444-23-000030:note_history:49]
Chemguard and Tyco Fire Products have been named as defendants in more than 600 cases involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 33 states. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the

- removed (2024-01-30):
[0000833444-23-000030:note_history:50]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. The 3M Company et al., No. G-4801-CI-021804752-000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio. The lawsuit seeks to recover costs and natural resource damages associated with the contamination. This lawsuit has been removed to the United States District Court for the Northern District of Ohio and transferred to the MDL.

- removed (2024-01-30):
[0000833444-23-000030:note_history:51]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.). All three of these suits have been removed to federal court and transferred to the MDL.

- removed (2024-01-30):
[0000833444-23-000030:note_history:52]
In September 2019, the government of Guam filed a lawsuit in the superior court of Guam against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting

- removed (2024-01-30):
[0000833444-23-000030:note_history:53]
from the use of firefighting foams at various locations within its jurisdiction. This complaint has been removed to federal court and transferred to the MDL.

- removed (2024-01-30):
[0000833444-23-000030:note_history:54]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.

- removed (2024-01-30):
[0000833444-23-000030:note_history:55]
In August 2020, Attorney General of the State of Michigan filed two substantially similar lawsuits—one in federal court and one in state court—against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within the State. The federal action has been transferred to the MDL, and the state court action has been removed to federal court and transferred to the MDL.

- removed (2024-01-30):
[0000833444-23-000030:note_history:56]
In December 2020, the State of Mississippi filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State.  This complaint was direct-filed in the MDL in South Carolina.

- removed (2024-01-30):
[0000833444-23-000030:note_history:57]
In February 2022, the Attorney General of the State of Colorado filed a lawsuit in Colorado state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources, public health, and State property allegedly resulting from the use of firefighting foams at various locations throughout the State. This complaint has been removed to federal court and transferred to the MDL.

- removed (2024-01-30):
[0000833444-23-000030:note_history:58]
In April 2022, the Attorney General of the State of Florida filed a lawsuit in Florida state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage to the State’s natural resources and public health allegedly resulting from the use of firefighting foams at various locations throughout the State. This complaint has been removed to federal court and transferred to the MDL.

- removed (2024-01-30):
[0000833444-23-000030:note_history:59]
In May 2022, the Attorney General of the Commonwealth of Massachusetts filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s natural resources, property, residents, and consumers allegedly resulting from the use of firefighting foams at various locations throughout the State.  This complaint was direct-filed in the MDL in South Carolina.

- removed (2024-01-30):
[0000833444-23-000030:note_history:60]
In July 2022, the Attorney General of the State of Wisconsin filed a lawsuit in Wisconsin state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage to the State’s natural resources and public health allegedly resulting, in part, from the use of firefighting foams at various locations throughout the State. This complaint has been removed to federal court and transferred to the MDL.

- removed (2024-01-30):
[0000833444-23-000030:note_history:61]
In November 2022, the Attorney General of the State of California filed a lawsuit in California state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the manufacture, use, marketing, or sale of PFAS-containing products, including firefighting foams, at various locations throughout the State. This complaint has been removed to federal court and transferred to the MDL.

- removed (2024-01-30):
[0000833444-23-000030:note_history:62]
In March 2023, the Attorney General of the State of Maine filed a lawsuit in Maine state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of the State’s natural resources allegedly resulting from the manufacture, distribution, release, promotion, sale, and use of PFAS-containing AFFF within the state. This complaint has been removed to federal court and transferred to the MDL.

- removed (2024-01-30):
[0000833444-23-000030:note_history:63]
In March 2023, the Attorney General of the State of Illinois filed a lawsuit in Illinois state court against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of the State’s environmental and natural resources allegedly resulting from the manufacture, storage, sale, distribution, marketing, and use of PFAS-containing AFFF within the State. This complaint has been removed to federal court, and the JPML is considering Illinois's opposition to transfer to the MDL.

- removed (2024-01-30):
[0000833444-23-000030:note_history:64]
In May and June 2023, eleven other states and territories filed lawsuits, ten in their respective state courts, and one direct-filed in the MDL, against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of Arizona v. The 3M Company et al.; State of Arkansas v. The 3M Company et al.; Commonwealth of Kentucky v. The 3M Company et al.; State of Maryland v. The 3M Company et al.; State of New Mexico v. The 3M Company et al.; State of Oregon v. The 3M Company et al.; Commonwealth of Puerto Rico v. The 3M Company et al.; State of Rhode Island v. The 3M Company et al.; State of Tennessee v. The 3M Company et al.; State of Texas v. The 3M Company et al.; State of Washington v. The 3M Company et al.). It is anticipated the ten state court-filed complaints will be removed to federal court and transferred to the MDL.

- removed (2024-01-30):
[0000833444-23-000030:note_history:65]
In July 2023, the Attorney General of the District of Columbia filed a lawsuit in superior court in the District, against a number of manufacturers, including affiliates of the Company, with respect to PFAS damage of the District’s natural resources and public health allegedly resulting from the manufacture, distribution, release, and use of PFAS-containing AFFF within and adjacent to it (District of Columbia v. The 3M Company et al.). It is anticipated that this complaint will be removed to federal court and transferred to the MDL.

- removed (2024-01-30):
[0000833444-23-000030:note_history:66]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity

- removed (2024-01-30):
[0000833444-23-000030:note_history:67]
available to government contractors that produced products for the United States government pursuant to the government’s specifications. In September 2022, the AFFF MDL Court declined to grant summary judgment on the government contractor defense, ruling that various factual issues relevant to the defense must be decided by a jury rather than the Court. Tyco and Chemguard have insurance that has been in place for many years and the Company is pursuing this coverage for these matters in the event the Company is required to pay claims. However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

- removed (2024-01-30):
[0000833444-23-000030:note_history:68]
The Company estimates the asbestos-related liability for pending and future claims and related defense costs on a discounted basis. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable.

- removed (2024-01-30):
[0000833444-23-000030:note_history:69]
|  | June 30, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 363 |  |  | 380 |  |
| Total asbestos-related liabilities | 421 |  |  | 438 |  |
| Other current assets | 34 |  |  | 37 |  |
| Other noncurrent assets | 283 |  |  | 263 |  |
| Total asbestos-related assets | 317 |  |  | 300 |  |
| Net asbestos-related liabilities | $ | 104 |  |  | $ | 138 |  |

- removed (2024-01-30):
[0000833444-23-000030:note_history:70]
|  | June 30, 2023 |  | September 30, 2022 |
| Restricted |  |  |  |
| Cash | $ | 26 |  |  | $ | 6 |  |
| Investments | 240 |  |  | 239 |  |
| Total restricted assets | 266 |  |  | 245 |  |
| Insurance receivables for asbestos-related liabilities | 51 |  |  | 55 |  |
| Total asbestos-related assets | $ | 317 |  |  | $ | 300 |  |

- removed (2024-01-30):
[0000833444-23-000030:note_history:71]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be paid by Company affiliates). Estimated asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be paid through 2068. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and

- removed (2024-01-30):
[0000833444-23-000030:note_history:72]
dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-01-30):
[0000833444-24-000011:note_history:73]
|  | December 31, 2023 |  | September 30, 2023 |
| Other current liabilities | $ | 31 |  |  | $ | 31 |  |
| Other noncurrent liabilities | 201 |  |  | 211 |  |
| Total reserves for environmental liabilities | $ | 232 |  |  | $ | 242 |  |
  (was, 2023-08-02, similarity 0.9706):
[0000833444-23-000030:note_history:73]
|  | June 30, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 38 |  |  | $ | 66 |  |
| Other noncurrent liabilities | 214 |  |  | 220 |  |
| Total reserves for environmental liabilities | $ | 252 |  |  | $ | 286 |  |

- added (2024-01-30):
[0000833444-24-000011:note_history:74]
|  | December 31, 2023 |  | September 30, 2023 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 359 |  |  | 364 |  |
| Total asbestos-related liabilities | 417 |  |  | 422 |  |
| Other current assets | 27 |  |  | 28 |  |
| Other noncurrent assets | 294 |  |  | 273 |  |
| Total asbestos-related assets | 321 |  |  | 301 |  |
| Net asbestos-related liabilities | $ | 96 |  |  | $ | 121 |  |

- added (2024-01-30):
[0000833444-24-000011:note_history:75]
|  | December 31, 2023 |  | September 30, 2023 |
| Restricted |  |  |  |
| Cash | $ | 19 |  |  | $ | 20 |  |
| Investments | 252 |  |  | 231 |  |
| Total restricted assets | 271 |  |  | 251 |  |
| Insurance receivables for asbestos-related liabilities | 50 |  |  | 50 |  |
| Total asbestos-related assets | $ | 321 |  |  | $ | 301 |  |

- changed (2024-01-30):
[0000833444-24-000011:note_history:76]
|  | December 31, 2023 |  | September 30, 2023 |
| Other current liabilities | $ | 87 |  |  | $ | 86 |  |
| Accrued compensation and benefits | 22 |  |  | 21 |  |
| Other noncurrent liabilities | 219 |  |  | 226 |  |
| Total self-insured liabilities | $ | 328 |  |  | $ | 333 |  |
  (was, 2023-08-02, similarity 0.9752):
[0000833444-23-000030:note_history:76]
|  | June 30, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 77 |  |  | $ | 89 |  |
| Accrued compensation and benefits | 22 |  |  | 22 |  |
| Other noncurrent liabilities | 232 |  |  | 230 |  |
| Total self-insured liabilities | $ | 331 |  |  | $ | 341 |  |

- changed (2024-01-30):
[0000833444-24-000011:note_history:77]
|  | December 31, 2023 |  | September 30, 2023 |
| Other current assets | $ | 6 |  |  | $ | 6 |  |
| Other noncurrent assets | 14 |  |  | 14 |  |
| Total insurance receivables | $ | 20 |  |  | $ | 20 |  |
  (was, 2023-08-02, similarity 0.9718):
[0000833444-23-000030:note_history:77]
|  | June 30, 2023 |  | September 30, 2022 |
| Other current assets | $ | 10 |  |  | $ | 10 |  |
| Other noncurrent assets | 20 |  |  | 20 |  |
| Total insurance receivables | $ | 30 |  |  | $ | 30 |  |

- removed (2024-01-30):
[0000833444-23-000030:note_history:78]
|  | June 30, 2023 |  | September 30, 2022 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 363 |  |  | 380 |  |
| Total asbestos-related liabilities | 421 |  |  | 438 |  |
| Other current assets | 34 |  |  | 37 |  |
| Other noncurrent assets | 283 |  |  | 263 |  |
| Total asbestos-related assets | 317 |  |  | 300 |  |
| Net asbestos-related liabilities | $ | 104 |  |  | $ | 138 |  |

- removed (2024-01-30):
[0000833444-23-000030:note_history:79]
|  | June 30, 2023 |  | September 30, 2022 |
| Restricted |  |  |  |
| Cash | $ | 26 |  |  | $ | 6 |  |
| Investments | 240 |  |  | 239 |  |
| Total restricted assets | 266 |  |  | 245 |  |
| Insurance receivables for asbestos-related liabilities | 51 |  |  | 55 |  |
| Total asbestos-related assets | $ | 317 |  |  | $ | 300 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-01-30):
[0000833444-24-000011:note_history:80]
BASIS OF PRESENTATION
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company," or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2023 filed with the SEC on December 14, 2023. The results of operations for the three-month period ended December 31, 2023 are not necessarily indicative of results for the Company’s 2024 fiscal year because of seasonal and other factors.
  (was, 2023-08-02, similarity 0.9755):
[0000833444-23-000030:note_history:80]
Basis of Presentation
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company," or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2022 filed with the SEC on November 15, 2022. The results of operations for the three and nine month periods ended June 30, 2023 are not necessarily indicative of results for the Company’s 2023 fiscal year because of seasonal and other factors.

- added (2024-01-30):
[0000833444-24-000011:note_history:81]
Prior Period Revision – Statement of Cash Flows

- changed (2024-01-30):
[0000833444-24-000011:note_history:82]
The Company revised the amounts previously reported as net proceeds from borrowings with maturities less than three months and proceeds from debt for certain short-term debt transactions that were incorrectly presented on a net basis within the financing activities section of the consolidated statements of cash flows for the three months ended December 30, 2022. 
The revision did not change cash provided by financing activities or the total decrease in cash, cash equivalents and restricted cash. The Company does not believe the impact of the incorrect presentation was material.
  (was, 2023-08-02, similarity 0.639):
[0000833444-23-000030:note_history:82]
Prior Period Revision – Statement of Cash Flows
The Company revised the amounts previously reported as net proceeds from borrowings with maturities less than three months and proceeds from debt for certain short-term debt transactions that were incorrectly presented on a net basis within the financing activities section of the consolidated statements of cash flows for the nine months ended June 30, 2022. Interim and annual amounts for the year ended September 30, 2022 and annual amounts for the years ended September 30, 2021 and 2020 were similarly impacted. Prior period amounts will be revised with future Quarterly Reports on Form 10-Q and Annual Report on Form 10-K filings. Cash provided by financing activities and the total increase (decrease) in cash, cash equivalents and restricted cash were unchanged for all affected periods. The Company does not believe the impact of incorrect presentation is material to any periods.

- removed (2024-01-30):
[0000833444-23-000030:note_history:83]
Assets and liabilities of the Global Retail business which were classified as held for sale in prior periods have been reclassified to conform with the current period presentation. Refer to Note 4, "Assets and Liabilities Held for Sale," of the notes to the consolidated financial statements for further details.

- removed (2024-01-30):
[0000833444-23-000030:note_history:84]
Restricted Cash

- removed (2024-01-30):
[0000833444-23-000030:note_history:85]
Restricted cash relates to amounts restricted for payment of asbestos liabilities and certain litigation and environmental matters. Restricted cash is recorded primarily within other current assets in the consolidated statements of financial position and totaled $86 million and $35 million at June 30, 2023 and September 30, 2022, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-01-30):
[0000833444-24-000011:note_history:86]
|  | December 31, |  | September 30, |
|  | 2023 |  | 2023 |
| Commercial paper | $ | 1,383 |  |  | $ | 200 |  |
| Term loans | 598 |  |  | 159 |  |
| Bank borrowings | 17 |  |  | 26 |  |
|  | $ | 1,998 |  |  | $ | 385 |  |
| Weighted average interest rate on short-term debt outstanding | 4.4 | % |  | 5.1 | % |

- added (2024-01-30):
[0000833444-24-000011:note_history:87]
As of December 31, 2023, the Company had syndicated committed revolving credit facilities of $2.5 billion which is scheduled to expire in December 2028 and $500 million which is scheduled to expire in December 2024. There were no draws on the facilities as of December 31, 2023.

- removed (2024-01-30):
[0000833444-23-000030:note_history:88]
|  | June 30, |  | September 30, |
|  | 2023 |  | 2022 |
| Bank borrowings | $ | 23 |  |  | $ | 10 |  |
| Commercial paper | — |  |  | 172 |  |
| Term loans | 163 |  |  | 487 |  |
|  | $ | 186 |  |  | $ | 669 |  |
| Weighted average interest rate on short-term debt outstanding | 3.8 | % |  | 0.5 | % |

- removed (2024-01-30):
[0000833444-23-000030:note_history:89]
As of June 30, 2023, the Company had a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in November 2023. As of June 30, 2023, there were no draws on the facilities.

- removed (2024-01-30):
[0000833444-23-000030:note_history:90]
Financing Activity

- removed (2024-01-30):
[0000833444-23-000030:note_history:91]
The Company entered into the following financing activities during the current fiscal year:

- removed (2024-01-30):
[0000833444-23-000030:note_history:92]
•October 2022

- removed (2024-01-30):
[0000833444-23-000030:note_history:93]
–Repaid a €200 million ($196 million as of September 30, 2022) term loan with an interest rate of EURIBOR plus 0.5%

- removed (2024-01-30):
[0000833444-23-000030:note_history:94]
–Issued a €150 million ($163 million as of March 31, 2023) term loan with an interest rate of EURIBOR plus 0.7% which is due in April 2024

- removed (2024-01-30):
[0000833444-23-000030:note_history:95]
•January 2023 - Repaid $32 million of outstanding 4.625% Notes due 2023

- removed (2024-01-30):
[0000833444-23-000030:note_history:96]
•March 2023

- removed (2024-01-30):
[0000833444-23-000030:note_history:97]
–Repaid a €150 million ($147 million as of September 30, 2022) term loan with an interest rate of 0.0%

- removed (2024-01-30):
[0000833444-23-000030:note_history:98]
–Repaid a €135 million ($133 million as of September 30, 2022) term loan with an interest rate of EURIBOR plus 0.5%

- removed (2024-01-30):
[0000833444-23-000030:note_history:99]
–Issued a €150 million ($163 million as of March 31, 2023) term loan with an interest rate of EURIBOR plus 0.4% which is due March 2024

- removed (2024-01-30):
[0000833444-23-000030:note_history:100]
•May 2023 - Together with its wholly owned subsidiary, Tyco Fire & Security Finance S.C.A., co-issued an €800 million ($868 million as of June 30, 2023) bond with an interest rate of 4.25% which is due May 2035.

- removed (2024-01-30):
[0000833444-23-000030:note_history:101]
Net Financing Charges

- removed (2024-01-30):
[0000833444-23-000030:note_history:102]
Net financing charges consisted of the following (in millions):

- removed (2024-01-30):
[0000833444-23-000030:note_history:103]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Interest expense, net of capitalized interest costs | $ | 79 |  |  | $ | 54 |  |  | $ | 219 |  |  | $ | 165 |  |
| Other financing charges | 13 |  |  | 6 |  |  | 34 |  |  | 16 |  |
| Interest income | (10) |  |  | (2) |  |  | (17) |  |  | (5) |  |
| Net foreign exchange results for financing activities | (2) |  |  | (9) |  |  | (18) |  |  | (23) |  |
| Net financing charges | $ | 80 |  |  | $ | 49 |  |  | $ | 218 |  |  | $ | 153 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2024-01-30):
[0000833444-24-000011:note_history:104]
The fair value of long-term debt at December 31, 2023 and September 30, 2023 was as follows (in billions):

- added (2024-01-30):
[0000833444-24-000011:note_history:105]
|  |  | December 31, |  | September 30, |  |
|  | 2023 |  | 2023 |  |
| Public debt |  | $ | 7.8 |  |  | $ | 7.1 |  |  |
| Other long-term debt |  | 0.4 |  |  | 0.4 |  |  |
| Total fair value of long-term debt |  | $ | 8.2 |  |  | $ | 7.5 |  |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-01-30):
[0000833444-24-000011:note_history:106]
|  | December 31, |  | September 30, |
|  | 2023 |  | 2023 |
| Commercial paper | $ | 1,383 |  |  | $ | 200 |  |
| Term loans | 598 |  |  | 159 |  |
| Bank borrowings | 17 |  |  | 26 |  |
|  | $ | 1,998 |  |  | $ | 385 |  |
| Weighted average interest rate on short-term debt outstanding | 4.4 | % |  | 5.1 | % |

- removed (2024-01-30):
[0000833444-23-000030:note_history:107]
|  | June 30, |  | September 30, |
|  | 2023 |  | 2022 |
| Bank borrowings | $ | 23 |  |  | $ | 10 |  |
| Commercial paper | — |  |  | 172 |  |
| Term loans | 163 |  |  | 487 |  |
|  | $ | 186 |  |  | $ | 669 |  |
| Weighted average interest rate on short-term debt outstanding | 3.8 | % |  | 0.5 | % |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-01-30):
[0000833444-24-000011:note_history:108]
|  |  | Three Months Ended December 31, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,518 |  |  | $ | 969 |  |  | $ | 2,487 |  |  | $ | 1,451 |  |  | $ | 916 |  |  | $ | 2,367 |  |
| Building Solutions EMEA/LA |  | 572 |  |  | 466 |  |  | 1,038 |  |  | 552 |  |  | 423 |  |  | 975 |  |
| Building Solutions Asia Pacific |  | 337 |  |  | 170 |  |  | 507 |  |  | 473 |  |  | 173 |  |  | 646 |  |
| Global Products |  | 2,062 |  |  | — |  |  | 2,062 |  |  | 2,080 |  |  | — |  |  | 2,080 |  |
| Total |  | $ | 4,489 |  |  | $ | 1,605 |  |  | $ | 6,094 |  |  | $ | 4,556 |  |  | $ | 1,512 |  |  | $ | 6,068 |  |

- changed (2024-01-30):
[0000833444-24-000011:note_history:109]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| HVAC |  | $ | 1,418 |  |  | $ | 1,440 |  |  |  |  |  |
| Fire & Security |  | 547 |  |  | 570 |  |  |  |  |  |
| Industrial Refrigeration |  | 97 |  |  | 70 |  |  |  |  |  |
| Total |  | $ | 2,062 |  |  | $ | 2,080 |  |  |  |  |  |
  (was, 2023-08-02, similarity 0.7105):
[0000833444-23-000030:note_history:109]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC |  | $ | 1,973 |  |  | $ | 1,889 |  |  | $ | 5,170 |  |  | $ | 5,030 |  |
| Fire & Security |  | 626 |  |  | 610 |  |  | 1,819 |  |  | 1,732 |  |
| Industrial Refrigeration |  | 88 |  |  | 72 |  |  | 246 |  |  | 175 |  |
| Total |  | $ | 2,687 |  |  | $ | 2,571 |  |  | $ | 7,235 |  |  | $ | 6,937 |  |

- removed (2024-01-30):
[0000833444-23-000030:note_history:110]
|  |  | Three Months Ended June 30, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,636 |  |  | $ | 1,029 |  |  | $ | 2,665 |  |  | $ | 1,481 |  |  | $ | 945 |  |  | $ | 2,426 |  |
| Building Solutions EMEA/LA |  | 571 |  |  | 474 |  |  | 1,045 |  |  | 537 |  |  | 415 |  |  | 952 |  |
| Building Solutions Asia Pacific |  | 537 |  |  | 199 |  |  | 736 |  |  | 493 |  |  | 172 |  |  | 665 |  |
| Global Products |  | 2,687 |  |  | — |  |  | 2,687 |  |  | 2,571 |  |  | — |  |  | 2,571 |  |
| Total |  | $ | 5,431 |  |  | $ | 1,702 |  |  | $ | 7,133 |  |  | $ | 5,082 |  |  | $ | 1,532 |  |  | $ | 6,614 |  |

- removed (2024-01-30):
[0000833444-23-000030:note_history:111]
|  |  | Nine Months Ended June 30, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 4,641 |  |  | $ | 2,911 |  |  | $ | 7,552 |  |  | $ | 4,123 |  |  | $ | 2,682 |  |  | $ | 6,805 |  |
| Building Solutions EMEA/LA |  | 1,705 |  |  | 1,346 |  |  | 3,051 |  |  | 1,617 |  |  | 1,252 |  |  | 2,869 |  |
| Building Solutions Asia Pacific |  | 1,489 |  |  | 560 |  |  | 2,049 |  |  | 1,442 |  |  | 521 |  |  | 1,963 |  |
| Global Products |  | 7,235 |  |  | — |  |  | 7,235 |  |  | 6,937 |  |  | — |  |  | 6,937 |  |
| Total |  | $ | 15,070 |  |  | $ | 4,817 |  |  | $ | 19,887 |  |  | $ | 14,119 |  |  | $ | 4,455 |  |  | $ | 18,574 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-01-30):
[0000833444-24-000011:note_history:112]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of December 31, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $19.9 billion, of which approximately 64% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.
  (was, 2023-08-02, similarity 0.994):
[0000833444-23-000030:note_history:112]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of June 30, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $19.2 billion, of which approximately 65% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.

- changed (2024-01-30):
[0000833444-24-000011:note_history:113]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when these costs are recoverable. These costs consist primarily of sales commissions and design costs that relate to a contract or an anticipated contract that the Company expects to recover. Costs to obtain or fulfill a contract are capitalized and amortized over the period of contract performance.
  (was, 2023-08-02, similarity 0.9829):
[0000833444-23-000030:note_history:113]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when these costs are recoverable. These costs consist primarily of sales commissions and design costs that relate to a contract or an anticipated contract that we expect to recover. Costs to obtain or fulfill a contract are capitalized and amortized over the period of contract performance.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2024-01-30):
[0000833444-24-000011:note_history:114]
|  |  | Three Months Ended December 31, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,518 |  |  | $ | 969 |  |  | $ | 2,487 |  |  | $ | 1,451 |  |  | $ | 916 |  |  | $ | 2,367 |  |
| Building Solutions EMEA/LA |  | 572 |  |  | 466 |  |  | 1,038 |  |  | 552 |  |  | 423 |  |  | 975 |  |
| Building Solutions Asia Pacific |  | 337 |  |  | 170 |  |  | 507 |  |  | 473 |  |  | 173 |  |  | 646 |  |
| Global Products |  | 2,062 |  |  | — |  |  | 2,062 |  |  | 2,080 |  |  | — |  |  | 2,080 |  |
| Total |  | $ | 4,489 |  |  | $ | 1,605 |  |  | $ | 6,094 |  |  | $ | 4,556 |  |  | $ | 1,512 |  |  | $ | 6,068 |  |

- changed (2024-01-30):
[0000833444-24-000011:note_history:115]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| HVAC |  | $ | 1,418 |  |  | $ | 1,440 |  |  |  |  |  |
| Fire & Security |  | 547 |  |  | 570 |  |  |  |  |  |
| Industrial Refrigeration |  | 97 |  |  | 70 |  |  |  |  |  |
| Total |  | $ | 2,062 |  |  | $ | 2,080 |  |  |  |  |  |
  (was, 2023-08-02, similarity 0.7105):
[0000833444-23-000030:note_history:115]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC |  | $ | 1,973 |  |  | $ | 1,889 |  |  | $ | 5,170 |  |  | $ | 5,030 |  |
| Fire & Security |  | 626 |  |  | 610 |  |  | 1,819 |  |  | 1,732 |  |
| Industrial Refrigeration |  | 88 |  |  | 72 |  |  | 246 |  |  | 175 |  |
| Total |  | $ | 2,687 |  |  | $ | 2,571 |  |  | $ | 7,235 |  |  | $ | 6,937 |  |

- added (2024-01-30):
[0000833444-24-000011:note_history:116]
|  |  | Location of contract balances |  | December 31, 2023 |  | September 30, 2023 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,170 |  |  | $ | 2,370 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 4 |  |  | 12 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,122 |  |  | 1,996 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 306 |  |  | 297 |  |  |  |

- changed (2024-01-30):
[0000833444-24-000011:note_history:117]
For the three months ended December 31, 2023 and 2022, the Company recognized revenue of $889 million and $846 million, respectively, that was included in the beginning of period contract liability balance.
  (was, 2023-08-02, similarity 0.6491):
[0000833444-23-000030:note_history:117]
For the three months ended June 30, 2023 and 2022, the Company recognized revenue of $222 million and $193 million, respectively, that was included in the beginning of period contract liability balance. For the nine months ended June 30, 2023 and 2022, the Company recognized revenue of $1,387 million and $1,252 million, respectively, that was included in the beginning of period contract liability balance

- changed (2024-01-30):
[0000833444-24-000011:note_history:118]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of December 31, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $19.9 billion, of which approximately 64% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.
  (was, 2023-08-02, similarity 0.994):
[0000833444-23-000030:note_history:118]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of June 30, 2023, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $19.2 billion, of which approximately 65% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.

- changed (2024-01-30):
[0000833444-24-000011:note_history:119]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when these costs are recoverable. These costs consist primarily of sales commissions and design costs that relate to a contract or an anticipated contract that the Company expects to recover. Costs to obtain or fulfill a contract are capitalized and amortized over the period of contract performance.
  (was, 2023-08-02, similarity 0.9829):
[0000833444-23-000030:note_history:119]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when these costs are recoverable. These costs consist primarily of sales commissions and design costs that relate to a contract or an anticipated contract that we expect to recover. Costs to obtain or fulfill a contract are capitalized and amortized over the period of contract performance.

- changed (2024-01-30):
[0000833444-24-000011:note_history:120]
|  |  | December 31, 2023 |  | September 30, 2023 |  |  |
| Other current assets |  | $ | 183 |  |  | $ | 156 |  |  |  |
| Other noncurrent assets |  | 215 |  |  | 224 |  |  |  |
| Total |  | $ | 398 |  |  | $ | 380 |  |  |  |
  (was, 2023-08-02, similarity 0.9721):
[0000833444-23-000030:note_history:120]
|  |  | June 30, 2023 |  | September 30, 2022 |  |  |
| Other current assets |  | $ | 159 |  |  | $ | 139 |  |  |  |
| Other noncurrent assets |  | 212 |  |  | 174 |  |  |  |
| Total |  | $ | 371 |  |  | $ | 313 |  |  |  |

- changed (2024-01-30):
[0000833444-24-000011:note_history:121]
During the three months ended December 31, 2023 and 2022, the Company recognized amortization expense of $57 million and $61 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three months ended December 31, 2023 and 2022.
  (was, 2023-08-02, similarity 0.643):
[0000833444-23-000030:note_history:121]
During the three months ended June 30, 2023 and 2022, the Company recognized amortization expense of $66 million and $48 million, respectively, related to costs to obtain or fulfill a contract. During the nine months ended June 30, 2023 and 2022, the Company recognized amortization expense of $188 million and $145 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and nine months ended June 30, 2023 and 2022.

- removed (2024-01-30):
[0000833444-23-000030:note_history:122]
|  |  | Three Months Ended June 30, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,636 |  |  | $ | 1,029 |  |  | $ | 2,665 |  |  | $ | 1,481 |  |  | $ | 945 |  |  | $ | 2,426 |  |
| Building Solutions EMEA/LA |  | 571 |  |  | 474 |  |  | 1,045 |  |  | 537 |  |  | 415 |  |  | 952 |  |
| Building Solutions Asia Pacific |  | 537 |  |  | 199 |  |  | 736 |  |  | 493 |  |  | 172 |  |  | 665 |  |
| Global Products |  | 2,687 |  |  | — |  |  | 2,687 |  |  | 2,571 |  |  | — |  |  | 2,571 |  |
| Total |  | $ | 5,431 |  |  | $ | 1,702 |  |  | $ | 7,133 |  |  | $ | 5,082 |  |  | $ | 1,532 |  |  | $ | 6,614 |  |

- removed (2024-01-30):
[0000833444-23-000030:note_history:123]
|  |  | Nine Months Ended June 30, |
|  |  | 2023 |  | 2022 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 4,641 |  |  | $ | 2,911 |  |  | $ | 7,552 |  |  | $ | 4,123 |  |  | $ | 2,682 |  |  | $ | 6,805 |  |
| Building Solutions EMEA/LA |  | 1,705 |  |  | 1,346 |  |  | 3,051 |  |  | 1,617 |  |  | 1,252 |  |  | 2,869 |  |
| Building Solutions Asia Pacific |  | 1,489 |  |  | 560 |  |  | 2,049 |  |  | 1,442 |  |  | 521 |  |  | 1,963 |  |
| Global Products |  | 7,235 |  |  | — |  |  | 7,235 |  |  | 6,937 |  |  | — |  |  | 6,937 |  |
| Total |  | $ | 15,070 |  |  | $ | 4,817 |  |  | $ | 19,887 |  |  | $ | 14,119 |  |  | $ | 4,455 |  |  | $ | 18,574 |  |

- removed (2024-01-30):
[0000833444-23-000030:note_history:124]
|  |  | Location of contract balances |  | June 30, 2023 |  | September 30, 2022 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,080 |  |  | $ | 2,067 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 79 |  |  | 79 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 1,918 |  |  | 1,804 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 292 |  |  | 282 |  |  |  |
