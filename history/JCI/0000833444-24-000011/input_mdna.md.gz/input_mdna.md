# JCI MD&A — 0000833444-24-000011


## mdna

[0000833444-24-000011:mdna:1]
[same as prior period, unchanged from 0000833444-23-000030:mdna:1]

[0000833444-24-000011:mdna:2]
[same as prior period, unchanged from 0000833444-23-000030:mdna:2]

[0000833444-24-000011:mdna:3]
[same as prior period, unchanged from 0000833444-23-000030:mdna:3]

[0000833444-24-000011:mdna:4]
[same as prior period, unchanged from 0000833444-23-000030:mdna:4]

[0000833444-24-000011:mdna:5]
[same as prior period, unchanged from 0000833444-23-000030:mdna:5]

[0000833444-24-000011:mdna:6]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including residential and commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions powered by its OpenBlue software platform and capabilities. The Company partners with customers by leveraging its broad product portfolio and digital capabilities powered by OpenBlue, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency, enhance security, create healthy environments and reduce greenhouse gas emissions.

[0000833444-24-000011:mdna:7]
The following information should be read in conjunction with the September 30, 2023 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in the Company's Annual Report on Form 10-K for the year ended September 30, 2023 filed with the SEC on December 14, 2023. References in the following discussion and analysis to "Three Months," "First Quarter" or similar language refer to the three months ended December 31, 2023 compared to the three months ended December 31, 2022.

[0000833444-24-000011:mdna:8]
[same as prior period, unchanged from 0000833444-23-000030:mdna:9]

[0000833444-24-000011:mdna:9]
Much of the demand for the Company’s products and solutions is driven by construction, facility expansion, retrofit and maintenance projects within the commercial, institutional, industrial, data center, governmental and residential sectors. Construction projects are heavily dependent on general economic conditions, localized demand for real estate and the availability of credit, public funding or other financing sources. Positive or negative fluctuations in construction, industrial facility expansion, retrofit activity, maintenance projects and other capital investments in buildings within the sectors that the Company serves, as well as availability of credit, financing or funding for such projects, could have a corresponding impact on the Company’s financial condition, results of operations and cash flows. During the three months ended December 31, 2023, the Company observed a softening of economic conditions in China, negatively impacting the performance of the Building Solutions Asia Pacific segment. The Company expects economic conditions in China to remain soft throughout the remainder of fiscal 2024, which could impact the performance of the Building Solutions Asia Pacific segment.

[0000833444-24-000011:mdna:10]
As a result of the Company’s global presence, a significant portion of its revenues and expenses is denominated in currencies other than the U.S. dollar. The Company is therefore subject to non-U.S. currency risks and non-U.S. exchange exposure. While the Company employs financial instruments to hedge some of its transactional foreign exchange exposure, these activities do not insulate it completely from those exposures. In addition, the currency exposure from the translation of non-U.S. dollar functional currency subsidiaries are not able to be hedged. Exchange rates can be volatile and a substantial weakening or strengthening of foreign currencies against the U.S. dollar could increase or reduce the Company’s profit margin, respectively, and impact the comparability of results from period to period. During the three months ended December 31, 2023, revenue and profits were positively impacted by movements in foreign exchange rates against the U.S. dollar.

[0000833444-24-000011:mdna:11]
[same as prior period, unchanged from 0000833444-23-000030:mdna:12]

[0000833444-24-000011:mdna:12]
The Company has experienced, and could continue to experience, increased material cost inflation and component shortages, as well as disruptions and delays in its supply chain, as a result of global macroeconomic trends, including increased global demand, geopolitical and economic tensions, including the conflict between Russia and Ukraine and Israel and Hamas, and labor shortages. Actions taken by the Company to mitigate supply chain disruptions and inflation, including expanding and

[0000833444-24-000011:mdna:13]
redistributing its supplier network, supplier financing, price increases and productivity improvements, have generally been successful in offsetting some, but not all, of the impact of these trends. The collective impact of these trends has been favorable to revenue due to increased demand and price increases to offset inflation, while negatively impacting margins due to supply chain disruptions and cost pressures. The Company has observed improved margins as supply chain disruptions have largely been resolved and higher priced backlog is converted to sales, but this improvement has been offset by lower volumes. Although the Company has experienced recent improvement, further disruptions, shortages and cost increases could occur in the future, the effect of which will depend on the Company’s ability to successfully mitigate and offset the impact of these events.

[0000833444-24-000011:mdna:14]
The extent to which the Company’s results of operations and financial condition are impacted by these and other factors in the future will depend on developments that are highly uncertain and cannot be predicted. See the section entitled "Risk Factors" in Johnson Controls' Annual Report on Form 10-K for the year ended September 30, 2023 filed with the United States Securities and Exchange Commission ("SEC") on December 14, 2023.

[0000833444-24-000011:mdna:15]
Cybersecurity Incident

[0000833444-24-000011:mdna:16]
During the weekend of September 23, 2023, the Company experienced a cybersecurity incident impacting its internal information technology ("IT") infrastructure and applications. The incident was detected shortly after receiving reports of outages to certain of the Company’s systems. Promptly after detecting the issue, the Company implemented its incident management and response plan and business continuity plans, including implementing remediation measures to mitigate the impact of the incident and restore affected systems and functions. The Company also engaged leading cybersecurity experts and other specialized consultants to assist in its investigation and remediation of the incident, as well as the restoration of impacted applications and systems. The Company’s investigation and remediation efforts remain ongoing, including the analysis of data accessed, exfiltrated or otherwise impacted during the cybersecurity incident. Based on the information reviewed to date, the Company believes the unauthorized activity has been contained and has not observed evidence of any impact to its digital products, services and solutions, including OpenBlue and Metasys.

[0000833444-24-000011:mdna:17]
The cybersecurity incident consisted of unauthorized access, data exfiltration and deployment of ransomware by a third party to a portion of the Company’s internal IT infrastructure. The incident caused disruptions and limitation of access to portions of the Company’s business applications supporting aspects of the Company’s operations and corporate functions, which disruptions and limitations continued into the early portion of the first quarter of fiscal 2024. To date, the Company has restored the impacted applications and systems.

[0000833444-24-000011:mdna:18]
The impact on net income for the three months ended December 31, 2023 of lost and deferred revenues, net of revenues deferred at the end of fiscal 2023 and recognized in the first quarter of fiscal 2024, and expenses during the quarter was approximately $27 million. These impacts were primarily attributable to expenses associated with the response to, and remediation of, the incident, and are net of insurance recoveries.

[0000833444-24-000011:mdna:19]
The Company expects to incur additional expenses associated with the response to, and remediation of, the incident throughout fiscal 2024, most of which the Company expects to incur in the first half of the year. These expenses include third-party expenditures, including IT recovery and forensic experts and others performing professional services to investigate and remediate the incident, as well as incremental operating expenses incurred from the resulting disruption to the Company’s business operations. Further, the cybersecurity incident caused disruptions to certain of the Company’s billing systems, which negatively impacted cash provided from operations during the first quarter of fiscal 2024. The overall impact of the cybersecurity incident in fiscal 2024 is not expected to be material to net income, net of insurance recoveries, or cash flows from continuing operations; however, the timing of recognizing the insurance recoveries may differ from the timing of recognizing the associated expenses.

[0000833444-24-000011:mdna:20]
The Company maintains insurance covering certain losses associated with cybersecurity incidents. The Company currently expects that a substantial portion of its direct costs incurred related to containing, investigating and remediating the incident, as well as business interruption losses, will be reimbursed through insurance recoveries.

[0000833444-24-000011:mdna:21]
[same as prior period, unchanged from 0000833444-23-000030:mdna:17]

[0000833444-24-000011:mdna:22]
In the third and fourth quarters of fiscal 2023, the Company developed a restructuring plan which included workforce reductions and other actions focused on continued scaling of selling, general and administrative expenses ("SG&A") to its planned growth. The costs of the plan were recorded to restructuring and impairment costs in the consolidated statements of

[0000833444-24-000011:mdna:23]
38

[0000833444-24-000011:mdna:24]
income. An additional $39 million of restructuring charges related to this plan were incurred in the three months ended December 31, 2023. Additional restructuring charges are expected in subsequent quarters. The Company expects savings from the restructuring initiatives to be substantially offset by incremental ongoing operating costs and investments to grow the business.

[0000833444-24-000011:mdna:25]
[same as prior period, unchanged from 0000833444-23-000030:mdna:19]

[0000833444-24-000011:mdna:26]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  |  |  |  |  |  |
| Net sales | $ | 6,094 |  |  | $ | 6,068 |  |  | — | % |  |  |  |  |  |  |

[0000833444-24-000011:mdna:27]
The increase in consolidated net sales for the three-month period ended December 31, 2023 was due to the net impact of acquisitions and divestitures ($41 million) and the favorable impact of foreign currency translation ($28 million), partially offset by lower organic sales ($43 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales decreased 1% as compared to the prior year, primarily attributable to lower volumes, partially offset by higher pricing. Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-24-000011:mdna:28]
[same as prior period, unchanged from 0000833444-23-000030:mdna:23]

[0000833444-24-000011:mdna:29]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  |  |  |  |  |  |
| Cost of sales | $ | 4,102 |  |  | $ | 3,977 |  |  | 3 | % |  |  |  |  |  |  |
| Gross profit | 1,992 |  |  | 2,091 |  |  | -5 | % |  |  |  |  |  |  |
| % of sales | 32.7 | % |  | 34.5 | % |  |  |  |  |  |  |  |  |

[0000833444-24-000011:mdna:30]
Cost of sales increased and gross profit decreased for the three-month period ended December 31, 2023, and gross profit as a percentage of sales decreased by 180 basis points. Gross profit and gross profit as a percentage of sales both decreased due to lower volumes, partially offset by favorable price/cost. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA").

[0000833444-24-000011:mdna:31]
[same as prior period, unchanged from 0000833444-23-000030:mdna:28]

[0000833444-24-000011:mdna:32]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  |  |  |  |  |  |
| Selling, general and administrative expenses | $ | 1,513 |  |  | $ | 1,571 |  |  | -4 | % |  |  |  |  |  |  |
| % of sales | 24.8 | % |  | 25.9 | % |  |  |  |  |  |  |  |  |

[0000833444-24-000011:mdna:33]
SG&A for the three-month period ended December 31, 2023 decreased $58 million, and SG&A as a percentage of sales decreased by 110 basis points. The decrease in SG&A was primarily due to nonrecurring costs incurred during the prior year including a loss associated with a fire at a leased warehouse facility and one-time transaction and separation costs, and higher mark-to-market gains, partially offset by costs recognized in the first quarter of fiscal 2024 related to the cybersecurity incident. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA.

[0000833444-24-000011:mdna:34]
39

[0000833444-24-000011:mdna:35]
[same as prior period, unchanged from 0000833444-23-000030:mdna:32]

[0000833444-24-000011:mdna:36]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  |  |  |  |  |  |
| Restructuring and impairment costs | $ | 39 |  |  | $ | 345 |  |  | -89 | % |  |  |  |  |  |  |

[0000833444-24-000011:mdna:37]
Restructuring and impairment costs for the three-month period ended December 31, 2023 included $39 million in severance and other charges resulting from restructuring initiatives.

[0000833444-24-000011:mdna:38]
Restructuring and impairment costs for the three-month period ended December 31, 2022 included $288 million of impairment costs related to the North America and Global Retail business which was previously classified as held-for-sale and $57 million in severance and other charges resulting from restructuring initiatives.

[0000833444-24-000011:mdna:39]
Refer to Note 4, "Assets and Liabilities Held for Sale," and Note 17, "Restructuring and Related Costs," of the notes to the consolidated financial statements for further disclosure related to the Company's restructuring plans and impairment costs.

[0000833444-24-000011:mdna:40]
[same as prior period, unchanged from 0000833444-23-000030:mdna:40]

[0000833444-24-000011:mdna:41]
|  | Three Months Ended December 31, |  |  |  |
|  | 2023 |  | 2022 |  | Change |  |  |  |
| Interest expense, net of capitalized interest costs | $ | 91 |  |  | $ | 69 |  |  | 32 | % |  |  |  |
| Other financing charges | 24 |  |  | 10 |  |  | 140 | % |  |  |  |
| Interest income | (5) |  |  | (4) |  |  | 25 | % |  |  |  |
| Net foreign exchange results for financing activities | (11) |  |  | (8) |  |  | 38 | % |  |  |  |
| Net financing charges | $ | 99 |  |  | $ | 67 |  |  | 48 | % |  |  |  |

[0000833444-24-000011:mdna:42]
Refer to Note 10, "Debt and Financing Arrangements," of the notes to the consolidated financial statements for further disclosure related to the Company's debt.

[0000833444-24-000011:mdna:43]
[same as prior period, unchanged from 0000833444-23-000030:mdna:46]

[0000833444-24-000011:mdna:44]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  |  |  |  |  |  |
| Income tax (benefit) provision | $ | (1) |  |  | $ | 14 |  |  | * |  |  |  |  |  |  |
| Effective tax rate | (0.2 | %) |  | 8.2 | % |  |  |  |  |  |  |  |  |

[0000833444-24-000011:mdna:45]
[same as prior period, unchanged from 0000833444-23-000030:mdna:48]

[0000833444-24-000011:mdna:46]
The decrease in the effective tax rate for the three-month period ended December 31, 2023 was primarily due to Swiss tax reform and the benefits of continuing global tax planning, partially offset by the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain consolidated subsidiaries and tax rate differentials. Refer to Note 18, "Income Taxes," of the notes to the consolidated financial statements for further detail.

[0000833444-24-000011:mdna:47]
[same as prior period, unchanged from 0000833444-23-000030:mdna:63]

[0000833444-24-000011:mdna:48]
[same as prior period, unchanged from 0000833444-23-000030:mdna:64]

[0000833444-24-000011:mdna:49]
[same as prior period, unchanged from 0000833444-23-000030:mdna:65]

[0000833444-24-000011:mdna:50]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,487 |  |  | $ | 2,367 |  |  | 5 | % |  |  |  |  |  |  |
| Building Solutions EMEA/LA | 1,038 |  |  | 975 |  |  | 6 | % |  |  |  |  |  |  |
| Building Solutions Asia Pacific | 507 |  |  | 646 |  |  | -22 | % |  |  |  |  |  |  |
| Global Products | 2,062 |  |  | 2,080 |  |  | -1 | % |  |  |  |  |  |  |
|  | $ | 6,094 |  |  | $ | 6,068 |  |  | — | % |  |  |  |  |  |  |

[0000833444-24-000011:mdna:51]
•The increase in Building Solutions North America was primarily due to organic growth, including higher prices ($98 million), incremental sales related to business acquisitions ($16 million) and the favorable impact of foreign currency translation ($6 million). Excluding the impacts of foreign currency translation and business acquisitions and divestitures, sales growth was led by double-digit growth in Applied HVAC & Controls.

[0000833444-24-000011:mdna:52]
•The increase in Building Solutions EMEA/LA was primarily due to the favorable impact of foreign currency translation ($42 million), organic growth, including higher prices ($18 million) and incremental sales related to business acquisitions ($6 million). Excluding the impacts of foreign currency translation and business acquisitions and divestitures, sales growth was led by continued momentum in Applied HVAC & Controls and Fire & Security, led by high-single digit growth in Service.

[0000833444-24-000011:mdna:53]
•The decrease in Building Solutions Asia Pacific was primarily due to organic sales declines ($131 million) and the unfavorable impact of foreign currency translation ($10 million). Excluding the impacts of foreign currency translation and business acquisitions and divestitures, sales decreased as mid single-digit Service growth was more than offset by accelerating weakness in the China Install business.

[0000833444-24-000011:mdna:54]
•The decrease in Global Products was due to the net impact of lower volumes and higher prices ($28 million) and the unfavorable impact of foreign currency translation ($10 million), partially offset by the net impact of business acquisitions and divestitures ($20 million). Excluding the impacts of foreign currency translation and business acquisitions and divestitures, sales decreased as low single-digit growth in Commercial HVAC was more than offset by declines in global Residential sales.

[0000833444-24-000011:mdna:55]
[same as prior period, unchanged from 0000833444-23-000030:mdna:77]

[0000833444-24-000011:mdna:56]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  |  |  |  |  |  |
| Building Solutions North America | $ | 285 |  |  | $ | 267 |  |  | 7 | % |  |  |  |  |  |  |
| Building Solutions EMEA/LA | 80 |  |  | 75 |  |  | 7 | % |  |  |  |  |  |  |
| Building Solutions Asia Pacific | 46 |  |  | 68 |  |  | -32 | % |  |  |  |  |  |  |
| Global Products | 369 |  |  | 382 |  |  | -3 | % |  |  |  |  |  |  |

[0000833444-24-000011:mdna:57]
•The increase in Building Solutions North America was primarily due to favorable price/cost as higher margin backlog converted to sales and continued growth in Service.

[0000833444-24-000011:mdna:58]
•The increase in Building Solutions EMEA/LA was primarily due to growth in Service.

[0000833444-24-000011:mdna:59]
•The decrease in Building Solutions Asia Pacific was primarily due to continued weakness in the China Install business.

[0000833444-24-000011:mdna:60]
•The decrease in Global Products was primarily due to lower volumes driving unfavorable manufacturing absorption and unfavorable mix, partially offset by favorable price and an uninsured loss associated with a fire at a leased warehouse facility in the prior year.

[0000833444-24-000011:mdna:61]
[same as prior period, unchanged from 0000833444-23-000030:mdna:89]

[0000833444-24-000011:mdna:62]
The Company’s backlog is applicable to its sales of systems and services. At December 31, 2023, the backlog was $13.7 billion, of which $12.1 billion was attributable to the building solutions (field) business. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-24-000011:mdna:63]
At December 31, 2023, remaining performance obligations were $19.9 billion, which is $6.2 billion higher than the Company's backlog of $13.7 billion. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-24-000011:mdna:64]
[same as prior period, unchanged from 0000833444-23-000030:mdna:93]

[0000833444-24-000011:mdna:65]
[same as prior period, unchanged from 0000833444-23-000030:mdna:94]

[0000833444-24-000011:mdna:66]
[same as prior period, unchanged from 0000833444-23-000030:mdna:95]

[0000833444-24-000011:mdna:67]
[same as prior period, unchanged from 0000833444-23-000030:mdna:96]

[0000833444-24-000011:mdna:68]
[same as prior period, unchanged from 0000833444-23-000030:mdna:97]

[0000833444-24-000011:mdna:69]
[same as prior period, unchanged from 0000833444-23-000030:mdna:98]

[0000833444-24-000011:mdna:70]
|  | December 31, |  | September 30, |  |  |
| (in millions) | 2023 |  | 2023 |  | Change |
| Current assets | $ | 12,054 |  |  | $ | 10,737 |  |  |  |
| Current liabilities | (12,409) |  |  | (11,084) |  |  |  |
| Working capital | $ | (355) |  |  | $ | (347) |  |  | 2 | % |
| Accounts receivable - net | $ | 6,045 |  |  | $ | 6,006 |  |  | 1 | % |
| Inventories | 3,006 |  |  | 2,776 |  |  | 8 | % |
| Accounts payable | 3,976 |  |  | 4,268 |  |  | (7 | %) |

[0000833444-24-000011:mdna:71]
•Working capital is approximately flat at December 31, 2023 as compared to September 30, 2023. The seasonal increase in inventory, the reduction in accounts payable due to timing, and the increase in cash was offset by higher current borrowings.

[0000833444-24-000011:mdna:72]
[same as prior period, unchanged from 0000833444-23-000030:mdna:107]

[0000833444-24-000011:mdna:73]
|  |  | Three Months Ended December 31, |
| (in millions) |  | 2023 |  | 2022 |
| Cash used by operating activities |  | $ | (246) |  |  | $ | (296) |  |
| Cash used by investing activities |  | (74) |  |  | (189) |  |
| Cash provided by financing activities |  | 1,228 |  |  | 9 |  |

[0000833444-24-000011:mdna:74]
•Cash used by operating activities was relatively consistent with prior year due to the seasonal usage of cash in the first fiscal quarter of the year.

[0000833444-24-000011:mdna:75]
•The decrease in cash used by investing activities was primarily due to lower capital expenditures and acquisitions.

[0000833444-24-000011:mdna:76]
•The increase in cash provided by financing activities was primarily due to increases in commercial paper and other short-term debt and the lack of share repurchases in the three months ended December 31, 2023.

[0000833444-24-000011:mdna:77]
[same as prior period, unchanged from 0000833444-23-000030:mdna:112]

[0000833444-24-000011:mdna:78]
|  | December 31, |  | September 30, |  |  |
| (in millions) | 2023 |  | 2023 |  |  |
| Short-term debt | $ | 1,998 |  |  | $ | 385 |  |  |  |
| Current portion of long-term debt | 652 |  |  | 645 |  |  |  |
| Long-term debt | 7,959 |  |  | 7,818 |  |  |  |
| Total debt | 10,609 |  |  | 8,848 |  |  |  |
| Less: Cash and cash equivalents | 1,801 |  |  | 835 |  |  |  |
| Net debt | $ | 8,808 |  |  | $ | 8,013 |  |  |  |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders ("Equity") | $ | 16,698 |  |  | $ | 16,545 |  |  |  |
| Total capitalization (Total debt plus Equity) | 27,307 |  |  | 25,393 |  |  |  |
| Net capitalization (Net debt plus Equity) | 25,506 |  |  | 24,558 |  |  |  |
| Total debt as a % of Total capitalization | 38.9 | % |  | 34.8 | % |  |  |
| Net debt as a % of Net capitalization | 34.5 | % |  | 32.6 | % |  |  |

[0000833444-24-000011:mdna:79]
•Net debt and net debt as a percentage of net capitalization are non-GAAP financial measures. The Company believes the percentage of net debt to net capitalization is useful to understanding the Company’s financial condition as it provides a view of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders.

[0000833444-24-000011:mdna:80]
[same as prior period, unchanged from 0000833444-23-000030:mdna:115]

[0000833444-24-000011:mdna:81]
•As of December 31, 2023, approximately $3.0 billion remains available under the Company's share repurchase authorization, which does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. The Company expects to repurchase outstanding shares from time to time depending on market conditions, alternate uses of capital, liquidity, and the economic environment.

[0000833444-24-000011:mdna:82]
•The Company declared a dividend of $0.37 per common share in the quarter ended December 31, 2023 and intends to continue paying dividends throughout fiscal 2024.

[0000833444-24-000011:mdna:83]
•The Company believes its capital resources and liquidity position, including cash and cash equivalents of $1.8 billion at December 31, 2023, are adequate to fund operations and meet its obligations for the foreseeable future. The Company expects requirements for working capital, capital expenditures, dividends, minimum pension contributions, debt maturities and any potential acquisitions or stock repurchases in the remainder of fiscal 2024 will be funded from operations, supplemented by short- and long-term borrowings, if required.

[0000833444-24-000011:mdna:84]
–The Company manages its short-term debt position in the U.S. and euro commercial paper and bank loan markets. Commercial paper outstanding totaled $1.4 billion as of December 31, 2023 and $0.2 billion as of September 30, 2023.

[0000833444-24-000011:mdna:85]
[same as prior period, unchanged from 0000833444-23-000030:mdna:121]

[0000833444-24-000011:mdna:86]
–The Company also has the ability to draw on its $2.5 billion revolving credit facility which is scheduled to expire in December 2028 or its $0.5 billion revolving credit facility which is scheduled to expire in December 2024. There were no draws on the revolving credit facilities as of December 31, 2023 and September 30, 2023.

[0000833444-24-000011:mdna:87]
•The Company's ability to access the global capital markets and the related cost of financing is dependent upon, among other factors, the Company's credit ratings. As of December 31, 2023, the Company's credit ratings and outlook were as follows:

[0000833444-24-000011:mdna:88]
[same as prior period, unchanged from 0000833444-23-000030:mdna:124]

[0000833444-24-000011:mdna:89]
[same as prior period, unchanged from 0000833444-23-000030:mdna:125]

[0000833444-24-000011:mdna:90]
•Financial covenants in the Company's revolving credit facilities requires a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of December 31, 2023, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures governing its notes, and expects to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-24-000011:mdna:91]
•The Company earns a significant amount of its income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances. However, in the first quarter of fiscal 2024, the Company provided income tax expense related to a change in the Company's assertion over the outside basis differences of the Company’s investment in certain consolidated subsidiaries. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. The Company's intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the

[0000833444-24-000011:mdna:92]
Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at its Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings.

[0000833444-24-000011:mdna:93]
[same as prior period, unchanged from 0000833444-23-000030:mdna:130]

[0000833444-24-000011:mdna:94]
•Refer to Note 10, "Debt and Financing Arrangements," of the notes to the consolidated financial statements for additional information on debt balances and items impacting capitalization.

[0000833444-24-000011:mdna:95]
[same as prior period, unchanged from 0000833444-23-000030:mdna:132]

[0000833444-24-000011:mdna:96]
[same as prior period, unchanged from 0000833444-23-000030:mdna:133]

[0000833444-24-000011:mdna:97]
•€500 million aggregate principal amount of 0.375% Senior Notes due 2027

[0000833444-24-000011:mdna:98]
•€600 million aggregate principal amount of 3.000% Senior Notes due 2028

[0000833444-24-000011:mdna:99]
•$625 million aggregate principal amount of 1.750% Senior Notes due 2030

[0000833444-24-000011:mdna:100]
•$500 million aggregate principal amount of 2.000% Sustainability-Linked Senior Notes due 2031

[0000833444-24-000011:mdna:101]
•€500 million aggregate principal amount of 1.000% Senior Notes due 2032

[0000833444-24-000011:mdna:102]
•$400 million aggregate principal amount of 4.900% Senior Notes due 2032

[0000833444-24-000011:mdna:103]
•€800 million aggregate principal amount of 4.25% Senior Notes due 2035

[0000833444-24-000011:mdna:104]
[same as prior period, unchanged from 0000833444-23-000030:mdna:141]

[0000833444-24-000011:mdna:105]
The following table presents the Net loss attributable to the Parent Company and TFSCA (collectively, the "Obligor Group") and the net income (loss) attributable to intercompany transactions between the Obligor Group and subsidiaries of the Parent Company other than TFSCA (collectively, the "Non-Obligor Subsidiaries") which are excluded from the Net loss attributable to the Obligor Group (in millions):

[0000833444-24-000011:mdna:106]
|  |  | Three Months Ended December 31, 2023 |  | Year EndedSeptember 30, 2023 |  |
| Net loss attributable to the Obligor Group |  | $ | (146) |  |  | $ | (458) |  |  |
| Net income (loss) attributable to intercompany transactions |  | 139 |  |  | (139) |  |  |

[0000833444-24-000011:mdna:107]
The Obligor Group does not have sales, gross profit or amounts attributable to noncontrolling interests.

[0000833444-24-000011:mdna:108]
The following table presents summarized balance sheet information of the Obligor Group and intercompany balances between the Obligor Group and the Non-Obligor Subsidiaries which are excluded from the Obligor Group amounts (in millions):

[0000833444-24-000011:mdna:109]
|  |  | Obligor Group |  | Intercompany Balances |
|  |  | December 31, 2023 |  | September 30, 2023 |  | December 31, 2023 |  | September 30, 2023 |
| Current assets |  | $ | 1,081 |  |  | $ | 26 |  |  | $ | 422 |  |  | $ | 5,608 |  |
| Noncurrent assets |  | 243 |  |  | 270 |  |  | 8,030 |  |  | 1,882 |  |
| Current liabilities |  | 4,647 |  |  | 3,652 |  |  | 2,981 |  |  | 9,289 |  |
| Noncurrent liabilities |  | 7,722 |  |  | 7,585 |  |  | 9,483 |  |  | 3,462 |  |

[0000833444-24-000011:mdna:110]
The same accounting policies as described in Note 1, "Summary of Significant Accounting Policies," of the Company's Annual Report on 10-K for the year ended September 30, 2023 are used by the Parent Company and each of its subsidiaries in connection with the summarized financial information presented above.

[0000833444-24-000011:mdna:111]
[same as prior period, unchanged from 0000833444-23-000030:mdna:153]

[0000833444-24-000011:mdna:112]
[same as prior period, unchanged from 0000833444-23-000030:mdna:154]

[0000833444-24-000011:mdna:113]
[same as prior period, unchanged from 0000833444-23-000030:mdna:155]

[0000833444-24-000011:mdna:114]
The Company prepares its consolidated financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). This requires management to make estimates and assumptions that affect reported amounts and related disclosures. Actual results could differ from those estimates. The Company’s critical accounting estimates requiring significant judgement that could materially impact the Company's results of operations, financial position and cash flows are described in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in the Company’s Annual Report on Form 10-K for the year ended September 30, 2023. Since the date of the Company’s most recent Annual Report, there have been no material changes in the Company’s critical accounting estimates or assumptions.
