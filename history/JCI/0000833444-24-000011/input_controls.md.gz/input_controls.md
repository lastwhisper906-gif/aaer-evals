# JCI 10-Q controls and the auditor's report


## item_4_controls

[0000833444-24-000011:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0000833444-24-000011:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0000833444-24-000011:item_4_controls:3]
The Company’s management, with the participation of the Company’s Chief Executive Officer and Chief Financial Officer, has evaluated the effectiveness of the Company’s disclosure controls and procedures (as such term is defined in Rule 13a-15(e) under the Securities Exchange Act of 1934, as amended (the "Exchange Act")) as of December 31, 2023. The Company’s disclosure controls and procedures are designed to ensure that information required to be disclosed by the Company in the reports it files or submits under the Exchange Act, is recorded, processed, summarized and reported, within the time periods specified in the Commissions’ rules and forms, and that such information is accumulated and communicated to the Company’s management, including the Company’s Chief Executive Officer and Chief Financial Officer, as appropriate to allow timely decisions regarding required disclosure.

[0000833444-24-000011:item_4_controls:4]
Based on such evaluations, the Company’s Chief Executive Officer and Chief Financial Officer have concluded that, as of December 31, 2023, the Company’s disclosure controls and procedures were not effective because of the material weakness in its internal control over financial reporting discussed below and described in the Company's Annual Report on Form 10-K for the year ended September 30, 2023. Notwithstanding the material weakness in internal control over financial reporting, management believes and has concluded that the consolidated financial statements included in this Quarterly Report on Form 10-Q fairly present, in all material respects, the Company’s financial position, results of operations and cash flows for the periods presented in conformity with U.S. generally accepted accounting principles.

[0000833444-24-000011:item_4_controls:5]
46

[0000833444-24-000011:item_4_controls:6]
Remediation Plan for Material Weakness in Internal Control Over Financial Reporting

[0000833444-24-000011:item_4_controls:7]
The Company is committed to remediating the above noted material weakness and has actively implemented measures designed to help ensure the material weakness is remediated as soon as possible. Although some remediation measures have been completed, other actions with respect to the Company’s remediation plan are ongoing and include, among other things, the following:

[0000833444-24-000011:item_4_controls:8]
•engaging security specialists to assist in the review, assessment and remediation of the Company's IT controls;

[0000833444-24-000011:item_4_controls:9]
•additional strengthening of access requirements and unauthorized access detection to the Company's financial reporting systems; and

[0000833444-24-000011:item_4_controls:10]
•implementing additional procedures to facilitate more effective backup and recovery of the Company's financial reporting systems.

[0000833444-24-000011:item_4_controls:11]
Though the remediation plan is subject to continual review and revision, the Company expects the remediation plan described above will address the identified material weakness. The remediation plan is subject to oversight by the Audit Committee of the Board of Directors and the identified material weakness will not be considered remediated until the remediation plan has been fully implemented, the applicable controls operate for a sufficient period of time, and the Company has concluded that newly implemented controls are operating effectively.

[0000833444-24-000011:item_4_controls:12]
Changes in Internal Control Over Financial Reporting

[0000833444-24-000011:item_4_controls:13]
There have been no significant changes in the Company’s internal control over financial reporting during the three months ended December 31, 2023 that have materially affected, or are reasonably likely to materially affect, the Company’s internal control over financial reporting.
