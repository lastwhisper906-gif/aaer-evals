# JCI MD&A — 0000833444-21-000046


## mdna

[0000833444-21-000046:mdna:1]
ITEM 7    MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000833444-21-000046:mdna:2]
General

[0000833444-21-000046:mdna:3]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, healthy and sustainable buildings, serving a wide range of customers in more than 150 countries. The Company’s products, services, systems and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-21-000046:mdna:4]
The Company is a global leader in engineering, manufacturing and commissioning building products and systems, including residential and commercial HVAC equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions powered by its OpenBlue software platform and capabilities. The Company partners with customers by leveraging its broad product portfolio and digital capabilities powered by OpenBlue, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency and reduce greenhouse gas emissions.

[0000833444-21-000046:mdna:5]
This discussion summarizes the significant factors affecting the consolidated operating results, financial condition and liquidity of the Company for the fiscal year ended September 30, 2021. This discussion should be read in conjunction with Item 8, the consolidated financial statements and the notes to consolidated financial statements. A detailed discussion of the 2020 to 2019

[0000833444-21-000046:mdna:6]
year-over-year changes are not included herein and can be found in the Management's Discussion and Analysis section in the Company's 2020 Annual Report on Form 10-K filed November 16, 2020 under the heading "Fiscal year 2020 compared to fiscal year 2019," which is incorporated herein by reference.

[0000833444-21-000046:mdna:7]
Macroeconomic Trends

[0000833444-21-000046:mdna:8]
Much of the demand for installation of the Company’s products and solutions is driven by commercial and residential construction and industrial facility expansion and maintenance projects. Commercial and residential construction projects are heavily dependent on general economic conditions, localized demand for commercial and residential real estate and availability of credit. Positive or negative fluctuations in commercial and residential construction, industrial facility expansion and maintenance projects and other capital investments in buildings could have a corresponding impact on the Company’s financial condition, results of operations and cash flows.

[0000833444-21-000046:mdna:9]
As a result of the Company’s global presence, a significant portion of its revenues and expenses is denominated in currencies other than the U.S. dollar. The Company is therefore subject to non-U.S. currency risks and non-U.S. exchange exposure. While the Company employs financial instruments to hedge some of its transactional foreign exchange exposure, these activities do not insulate it completely from those exposures. Exchange rates can be volatile and a substantial weakening or strengthening of foreign currencies against the U.S. dollar could increase or reduce the Company’s profit margin in various locations outside of the U.S. and impact the comparability of results from period to period.

[0000833444-21-000046:mdna:10]
The Company continues to observe trends demonstrating increased interest and demand for safe, efficient and sustainable buildings, and seeks to capitalize on these trends to drive growth by developing and delivering technologies and solutions to create smart and healthy buildings. In 2020, the Company launched its software platform, OpenBlue, enabling enterprises to manage all aspects of their physical spaces delivering sustainability, new occupant experiences, and safety and security by combining the Company’s building expertise with cutting-edge technology, including AI-powered service solutions such as remote diagnostics, predictive maintenance, compliance monitoring and advanced risk assessments. The Company continues to leverage its install base, together with data-driven products and services to offer outcome-based solutions to customers with a focus on generating accelerated growth in services and recurring revenue for the Company. In January 2021, the Company committed to invest 75 percent of its new product research and development in climate-related innovation to develop sustainable products and services.

[0000833444-21-000046:mdna:11]
The Company has experienced, and expects to continue to experience, increased input material cost inflation and component shortages, as well as disruptions and delays in its supply chain, as a result of global macroeconomic trends (including increased global demand), government-mandated actions in response to COVID-19 and labor shortages. Actions taken by the Company to mitigate supply chain disruptions and inflation, including expanding and redistributing its supplier network, supplier financing, price increases and productivity improvements, have generally been successful in offsetting some, but not all, of the impact of these trends. As a result, these trends have negatively impacted the Company’s revenue and margins. The Company expects that these trends will continue in fiscal year 2022. Therefore, the Company could experience further disruptions, shortages and price increases in the future, the effect of which will depend on the Company’s ability to successfully mitigate and offset the impact of these events.

[0000833444-21-000046:mdna:12]
Impact of COVID-19 pandemic

[0000833444-21-000046:mdna:13]
The global outbreak of COVID-19 severely restricted the level of economic activity around the world and caused a significant contraction in the global economy.

[0000833444-21-000046:mdna:14]
The Company’s affiliates, employees, suppliers, customers and others have been and may continue to be restricted or prevented from conducting normal business activities, including as a result of shutdowns, travel restrictions and other actions that may be requested or mandated by governmental authorities. Although shutdown orders and similar restrictions have been lifted in many jurisdictions in conjunction with the global distribution of vaccines, challenges in achieving sufficient vaccination levels and the spread of new variants of COVID-19 have caused some governments to extend or reinstitute restrictions in impacted areas. During fiscal 2021, the Company’s facilities generally operated at normal levels.

[0000833444-21-000046:mdna:15]
The Company continues to focus its efforts on preserving the health and safety of its employees and customers, as well as maintaining the continuity of its operations. The Company modified its business practices in response to the COVID-19 outbreak, including restricting non-essential employee travel, implementing remote work protocols, and limiting physical participation in meetings, events and conferences. The Company also instituted preventive measures at its facilities, including enhanced health and safety protocols, temperature screening, requiring face coverings for all unvaccinated employees and encouraging employees to follow similar protocols when away from work. The Company has adopted and implemented a

[0000833444-21-000046:mdna:16]
multifaceted framework to guide its decision making as it reopens its offices and facilities to employees, and will continue to monitor and audit its facilities to ensure that they are in compliance with the Company’s COVID-19 safety requirements.

[0000833444-21-000046:mdna:17]
The Company initially experienced a decline in demand and volumes in its global businesses as a result of the impact of efforts to contain the spread of COVID-19. Specifically, during portions of fiscal 2020, the Company experienced lower demand due to restricted access to customer sites to perform service and installation work as well as reduced discretionary capital spending by the Company's customers. In fiscal 2021, the Company has experienced increases in both demand and volumes as governments have distributed vaccines and lifted COVID-19-related restrictions, leading to increases in retrofit activity and, to a lesser extent, commercial building construction. The global pandemic has also provided the Company with the opportunity to help its customers prepare to re-open by delivering solutions and support that enhance the safety and increase the efficiency of their operations. As a result of the pandemic, the Company has seen an increase in demand for its products and solutions that promote building health and optimize customers’ infrastructure, including thermal cameras, indoor air quality, location-based services for contact tracing and touchless access control.

[0000833444-21-000046:mdna:18]
However, the Company continues to be influenced by COVID-19-related trends impacting site access and the labor force, which have and may continue to negatively impact the Company’s revenues and margins. Challenges in reaching sufficient vaccination levels and the introduction of new variants of COVID-19 have caused some governments to extend or reinstitute lockdowns and similar restrictive measures, which, in some cases, have limited the Company’s ability to access customer sites to install and maintain its products and deliver services. In addition, the Company has experienced and continues to experience labor shortages at certain facilities as the Company expands its production capacity to meet increased customer demand. Although the Company is mitigating these shortages through focused recruitment efforts and competitive compensation packages, the Company could continue to experience such shortages in the future. Recently, the U.S. Government has promulgated orders mandating vaccinations or regular COVID-19 testing for large employers and federal contractors. The Company’s efforts to comply with these mandates, including requiring that some or all of its employees be fully vaccinated against COVID-19, could result in increased labor attrition or disruption, and could adversely impact the Company’s ability to deliver services to our U.S. federal government customers and potentially other customers.

[0000833444-21-000046:mdna:19]
The extent to which the COVID-19 pandemic continues to impact the Company’s results of operations and financial condition will depend on future developments that are highly uncertain and cannot be predicted, including the resurgence of COVID-19 and its variants in regions recovering from the impacts of the pandemic, the effectiveness of COVID-19 vaccines and the speed at which populations are vaccinated around the globe, the impact of COVID-19 on economic activity, and regulatory actions taken to contain its impact on public health and the global economy. See Part I, Item 1A, of this Annual Report on Form 10-K for an additional discussion of risks related to COVID-19.

[0000833444-21-000046:mdna:20]
Restructuring and Cost Optimization Initiatives

[0000833444-21-000046:mdna:21]
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company has committed to various restructuring plans. In fiscal 2021, the Company announced its plans to optimize its cost structure through broad-based SG&A actions focused on simplification, standardization and centralization, with the intent to deliver annualized savings of $300 million by fiscal 2023. Additionally, the Company announced cost of sales actions to drive $250 million in annual run rate savings by fiscal 2023. For more information on the Company’s restructuring plans, see “Liquidity and Capital Resources—Restructuring.”

[0000833444-21-000046:mdna:22]
FISCAL YEAR 2021 COMPARED TO FISCAL YEAR 2020

[0000833444-21-000046:mdna:23]
Net Sales

[0000833444-21-000046:mdna:24]
|  | Year Ended September 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |
| Net sales | $ | 23,668 |  |  | $ | 22,317 |  |  | 6 | % |

[0000833444-21-000046:mdna:25]
The increase in net sales was due to higher organic sales ($932 million), the favorable impact of foreign currency translation ($447 million) and incremental sales from acquisitions ($253 million), partially offset by lower sales due to business divestitures ($275 million) and the impact of nonrecurring purchase accounting adjustments ($6 million). Excluding the impact of foreign currency translation, business acquisitions and divestitures and nonrecurring adjustments, consolidated net sales increased 4% as compared to the prior year, primarily attributable to the increased demand generated by the COVID-19 pandemic recovery. Refer to the "Segment Analysis" below within Item 7 for a discussion of net sales by segment.

[0000833444-21-000046:mdna:26]
31

[0000833444-21-000046:mdna:27]
Cost of Sales / Gross Profit

[0000833444-21-000046:mdna:28]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |
| Cost of sales | $ | 15,609 |  |  | $ | 14,906 |  |  | 5 | % |
| Gross profit | 8,059 |  |  | 7,411 |  |  | 9 | % |
| % of sales | 34.1 | % |  | 33.2 | % |  |  |

[0000833444-21-000046:mdna:29]
Cost of sales and gross profit both increased and gross profit as a percentage of sales increased by 90 basis points. Gross profit increased due to organic sales growth, favorable year-over-year impact of net pension mark-to-market adjustments ($207 million) and business acquisitions, partially offset by the unfavorable impact of foreign currency translation ($307 million) and business divestitures. Refer to the "Segment Analysis" below within Item 7 for a discussion of segment earnings before interest, taxes and amortization ("EBITA").

[0000833444-21-000046:mdna:30]
Selling, General and Administrative Expenses

[0000833444-21-000046:mdna:31]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |
| Selling, general and administrative expenses | $ | 5,258 |  |  | $ | 5,665 |  |  | -7 | % |
| % of sales | 22.2 | % |  | 25.4 | % |  |  |

[0000833444-21-000046:mdna:32]
Selling, general and administrative expenses ("SG&A") decreased by $407 million, and SG&A as a percentage of sales decreased by 320 basis points. The decrease in SG&A was primarily due to favorable year-over-year impact of net mark-to-market adjustments on pension plans ($453 million) and favorable impacts of cost mitigation actions and reductions in discretionary spend in the current year, partially offset by the unfavorable impact of foreign currency translation ($97 million). Refer to the "Segment Analysis" below within Item 7 for a discussion of segment EBITA.

[0000833444-21-000046:mdna:33]
Restructuring and Impairment Costs

[0000833444-21-000046:mdna:34]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |
| Restructuring and impairment costs | $ | 242 |  |  | $ | 783 |  |  | -69 | % |

[0000833444-21-000046:mdna:35]
Refer to Note 17, "Significant Restructuring and Impairment Costs," Note 18, "Impairment of Long-Lived Assets," and Note 8, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for further disclosure related to the Company's restructuring plans and impairment costs.

[0000833444-21-000046:mdna:36]
Net Financing Charges

[0000833444-21-000046:mdna:37]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |
| Net financing charges | $ | 206 |  |  | $ | 231 |  |  | -11 | % |

[0000833444-21-000046:mdna:38]
Refer to Note 10, "Debt and Financing Arrangements," of the notes to consolidated financial statements for further disclosure related to the Company's net financing charges.

[0000833444-21-000046:mdna:39]
Equity Income

[0000833444-21-000046:mdna:40]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |
| Equity income | $ | 261 |  |  | $ | 171 |  |  | 53 | % |

[0000833444-21-000046:mdna:41]
The increase in equity income was primarily due to higher income at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture. Foreign currency translation had a favorable impact on equity income of $12 million. Refer to the "Segment Analysis" below within Item 7 for a discussion of segment EBITA.

[0000833444-21-000046:mdna:42]
Income Tax Provision

[0000833444-21-000046:mdna:43]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |
| Income tax provision | $ | 868 |  |  | $ | 108 |  |  | * |
| Effective tax rate | 33 | % |  | 12 | % |  |  |

[0000833444-21-000046:mdna:44]
* Measure not meaningful

[0000833444-21-000046:mdna:45]
The statutory tax rate in Ireland of 12.5% is being used as a comparison since the Company is domiciled in Ireland.

[0000833444-21-000046:mdna:46]
For fiscal 2021, the effective tax rate for continuing operations was 33% and was higher than the statutory tax rate primarily due to the tax impacts of an intercompany transfer of certain of the Company’s intellectual property rights, valuation allowance adjustments, the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives.

[0000833444-21-000046:mdna:47]
For fiscal 2020, the effective rate for continuing operations was 12% and was lower than the statutory tax rate primarily due to tax audit reserve adjustments, the income tax effects of mark-to-market adjustments, valuation allowance adjustments and the benefits of continuing global tax planning initiatives, partially offset by a discrete tax charge related to the remeasurement of deferred tax assets and liabilities as a result of Swiss tax reform, the tax impact of an impairment charge and tax rate differentials.

[0000833444-21-000046:mdna:48]
The fiscal 2021 effective tax rate increased as compared to fiscal 2020 primarily due to the discrete tax items. The fiscal year 2021 and 2020 global tax planning initiatives related primarily to changes in entity tax status, global financing structures and alignment of the Company's global business functions in a tax efficient manner. Refer to Note 19, "Income Taxes," of the notes to consolidated financial statements for further details.

[0000833444-21-000046:mdna:49]
In October 2021, 136 out of 140 countries in the Organization for Economic Co-operation and Development ("OECD") Inclusive Framework on Base Erosion and Profit Shifting ("IF"), including Ireland, politically committed to potentially fundamental changes to the international corporate tax system, including the potential implementation of a global minimum corporate tax rate. While the details of these pronouncements presently remain unclear and timing of implementation uncertain, the impact of local country IF adoption could have a material impact on our effective tax rate in future periods. It is also possible that jurisdictions in which we do business could react to such IF developments unilaterally by enacting tax legislation that could adversely affect us or our affiliates.

[0000833444-21-000046:mdna:50]
Income From Discontinued Operations, Net of Tax

[0000833444-21-000046:mdna:51]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |
| Income from discontinued operations, net of tax | $ | 124 |  |  | $ | — |  |  | * |

[0000833444-21-000046:mdna:52]
* Measure not meaningful

[0000833444-21-000046:mdna:53]
Refer to Note 3, "Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-21-000046:mdna:54]
33

[0000833444-21-000046:mdna:55]
Income Attributable to Noncontrolling Interests

[0000833444-21-000046:mdna:56]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 233 |  |  | $ | 164 |  |  | 42 | % |

[0000833444-21-000046:mdna:57]
The increase in income from continuing operations attributable to noncontrolling interests was primarily due to higher net income at certain partially-owned affiliates within the Global Products segment.

[0000833444-21-000046:mdna:58]
Net Income Attributable to Johnson Controls

[0000833444-21-000046:mdna:59]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |
| Net income attributable to Johnson Controls | $ | 1,637 |  |  | $ | 631 |  |  | * |

[0000833444-21-000046:mdna:60]
* Measure not meaningful

[0000833444-21-000046:mdna:61]
The increase in net income attributable to Johnson Controls was primarily due to higher gross profit, lower restructuring and impairment costs and lower SG&A, partially offset by higher income tax provision. Fiscal 2021 diluted earnings per share attributable to Johnson Controls was $2.27 compared to $0.84 in fiscal 2020.

[0000833444-21-000046:mdna:62]
Comprehensive Income Attributable to Johnson Controls

[0000833444-21-000046:mdna:63]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |
| Comprehensive income attributable to Johnson Controls | $ | 1,979 |  |  | $ | 650 |  |  | * |

[0000833444-21-000046:mdna:64]
* Measure not meaningful

[0000833444-21-000046:mdna:65]
The increase in comprehensive income attributable to Johnson Controls was due to higher net income attributable to Johnson Controls ($1,006 million) and an increase in other comprehensive income attributable to Johnson Controls ($323 million) resulting primarily from foreign currency translation adjustments. The favorable foreign currency translation adjustments were primarily driven by the strengthening of the Brazilian real, Canadian dollar and Mexican peso against the U.S. dollar in the current year.

[0000833444-21-000046:mdna:66]
SEGMENT ANALYSIS

[0000833444-21-000046:mdna:67]
Management evaluates the performance of its business units based primarily on segment EBITA, which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and net mark-to-market adjustments related to pension and postretirement plans and restricted asbestos investments.

[0000833444-21-000046:mdna:68]
|  | Net Salesfor the Year EndedSeptember 30, |  |  |  | Segment EBITAfor the Year EndedSeptember 30, |  |  |
| (in millions) | 2021 |  | 2020 |  | Change |  | 2021 |  | 2020 |  | Change |
| Building Solutions North America | $ | 8,685 |  |  | $ | 8,605 |  |  | 1 | % |  | $ | 1,204 |  |  | $ | 1,157 |  |  | 4 | % |
| Building Solutions EMEA/LA | 3,727 |  |  | 3,440 |  |  | 8 | % |  | 391 |  |  | 338 |  |  | 16 | % |
| Building Solutions Asia Pacific | 2,654 |  |  | 2,403 |  |  | 10 | % |  | 349 |  |  | 319 |  |  | 9 | % |
| Global Products | 8,602 |  |  | 7,869 |  |  | 9 | % |  | 1,441 |  |  | 1,134 |  |  | 27 | % |
|  | $ | 23,668 |  |  | $ | 22,317 |  |  | 6 | % |  | $ | 3,385 |  |  | $ | 2,948 |  |  | 15 | % |

[0000833444-21-000046:mdna:69]
Net Sales:

[0000833444-21-000046:mdna:70]
•The increase in Building Solutions North America was due to the favorable impact of foreign currency translation ($49 million), higher volumes ($27 million) and incremental sales related to business acquisitions ($4 million). The increase in volumes was primarily attributable to a strong recovery in service sales across all domains, partially offset by a modest decline in installation sales driven by a decline in the new construction market.

[0000833444-21-000046:mdna:71]
•The increase in Building Solutions EMEA/LA was primarily attributable to the favorable impact of foreign currency translation ($135 million), higher volumes ($115 million) and incremental sales related to business acquisitions ($37 million). The increase in volumes was primarily attributable to higher service and, to a lesser extent, installation sales. By region, growth in Europe was partially offset by a decline in the Middle East.

[0000833444-21-000046:mdna:72]
•The increase in Building Solutions Asia Pacific was due to favorable volumes ($143 million) and the favorable impact of foreign currency translation ($117 million), partially offset by business divestitures ($9 million). The increase in volumes was primarily attributable to higher installation and service sales. Growth was led by a strong recovery in China.

[0000833444-21-000046:mdna:73]
•The increase in Global Products was due to favorable volumes ($647 million), incremental sales related to business acquisitions ($212 million) and the favorable impact of foreign currency translation ($146 million),  partially offset by business divestitures ($266 million) and the impact of nonrecurring purchase accounting adjustments ($6 million). The increase in volumes was primarily attributable to growth across Commercial and Residential HVAC as well as Fire & Security products. This growth was partially offset by a decline in Industrial Refrigeration.

[0000833444-21-000046:mdna:74]
Segment EBITA:

[0000833444-21-000046:mdna:75]
•The increase in Building Solutions North America was due to favorable volumes and productivity savings, net of prior year temporary cost mitigation actions ($31 million), prior year integration costs ($11 million) and the favorable impact of foreign currency translation ($5 million).

[0000833444-21-000046:mdna:76]
•The increase in Building Solutions EMEA/LA was due to favorable volumes and productivity savings, net of prior year temporary cost mitigation actions ($41 million), the favorable impact of foreign currency translation ($7 million), higher income due to business acquisitions ($5 million) and prior year integration costs ($2 million), partially offset by lower equity income ($2 million).

[0000833444-21-000046:mdna:77]
•The increase in Building Solutions Asia Pacific was due to the favorable impact of foreign currency translation ($13 million), favorable volumes, net of prior year temporary cost mitigation actions ($12 million) and prior year integration costs ($7 million), partially offset by lower income due to business divestitures ($2 million).

[0000833444-21-000046:mdna:78]
•The increase in Global Products was due to favorable volumes and productivity savings, net of prior year temporary cost mitigation actions ($176 million), higher equity income ($72 million) driven primarily by certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture, a prior year compensation charge related to a noncontrolling interest acquisition ($39 million), the favorable impact of foreign currency translation ($30 million), prior year integration costs ($13 million) and incremental income related to business acquisitions ($13 million), partially offset by lower income due to business divestitures ($23 million) and Silent-Aire transaction costs and nonrecurring purchase accounting adjustments ($13 million).

[0000833444-21-000046:mdna:79]
LIQUIDITY AND CAPITAL RESOURCES

[0000833444-21-000046:mdna:80]
Working Capital

[0000833444-21-000046:mdna:81]
|  | September 30,2021 |  | September 30,2020 |  |  |
| (in millions) |  |  | Change |
| Current assets | $ | 9,998 |  |  | $ | 10,053 |  |  |  |
| Current liabilities | (9,098) |  |  | (8,248) |  |  |  |
|  | 900 |  |  | 1,805 |  |  | -50 | % |
| Less: Cash and cash equivalents | (1,336) |  |  | (1,951) |  |  |  |
| Add: Short-term debt | 8 |  |  | 31 |  |  |  |
| Add: Current portion of long-term debt | 226 |  |  | 262 |  |  |  |
| Working capital (as defined) | $ | (202) |  |  | $ | 147 |  |  | * |
| Accounts receivable - net | $ | 5,613 |  |  | $ | 5,294 |  |  | 6 | % |
| Inventories | 2,057 |  |  | 1,773 |  |  | 16 | % |
| Accounts payable | 3,746 |  |  | 3,120 |  |  | 20 | % |

[0000833444-21-000046:mdna:82]
* Measure not meaningful

[0000833444-21-000046:mdna:83]
•The Company defines working capital as current assets less current liabilities, excluding cash and cash equivalents, short-term debt, the current portion of long-term debt, and the current portions of assets and liabilities held for sale. Management believes that this measure of working capital, which excludes financing-related items and businesses to be divested, provides a more useful measurement of the Company’s operating performance.

[0000833444-21-000046:mdna:84]
•The decrease in working capital at September 30, 2021 as compared to September 30, 2020, was primarily due to an increase in accounts payable, accrued compensation and benefits liabilities, deferred revenue and lower income tax assets, partially offset by an increase in accounts receivable, an increase in inventory, and the favorable resolution of certain post-closing working capital and net debt adjustments related to the Power Solutions sale.

[0000833444-21-000046:mdna:85]
•The Company’s days sales in accounts receivable at September 30, 2021 were 58, a decrease from 63 at September 30, 2020. There has been no significant adverse change in the level of overdue receivables or significant changes in revenue recognition methods.

[0000833444-21-000046:mdna:86]
•The Company’s inventory turns for the year ended September 30, 2021 were lower than the comparable period ended September 30, 2020 primarily due to changes in inventory production levels.

[0000833444-21-000046:mdna:87]
•Days in accounts payable at September 30, 2021 were 76 days, higher from 69 days for the comparable period ended September 30, 2020, primarily due to timing.

[0000833444-21-000046:mdna:88]
Cash Flows From Continuing Operations

[0000833444-21-000046:mdna:89]
|  | Year Ended September 30, |
| (in millions) | 2021 |  | 2020 |
| Cash provided by operating activities | $ | 2,551 |  |  | $ | 2,479 |  |
| Cash used by investing activities | (1,090) |  |  | (258) |  |
| Cash used by financing activities | (2,131) |  |  | (2,824) |  |

[0000833444-21-000046:mdna:90]
•The increase in cash provided by operating activities was primarily due to favorable changes in accounts payable and accrued liabilities and higher pre-tax income, net of non-cash adjustments, partially offset by prior year income tax refunds and increases in accounts receivable and inventory.

[0000833444-21-000046:mdna:91]
•The increase in cash used by investing activities was primarily due to higher cash payments made for Silent-Aire and other acquisitions.

[0000833444-21-000046:mdna:92]
•The decrease in cash used by financing activities was primarily due to lower levels of share repurchases in fiscal year 2021, partially offset by lower long-term debt borrowings, net of repayments.

[0000833444-21-000046:mdna:93]
Capitalization

[0000833444-21-000046:mdna:94]
|  | September 30,2021 |  | September 30,2020 |  |  |
| (in millions) |  |  | Change |
| Short-term debt | $ | 8 |  |  | $ | 31 |  |  |  |
| Current portion of long-term debt | 226 |  |  | 262 |  |  |  |
| Long-term debt | 7,506 |  |  | 7,526 |  |  |  |
| Total debt | 7,740 |  |  | 7,819 |  |  | -1 | % |
| Less: Cash and cash equivalents | 1,336 |  |  | 1,951 |  |  |  |
| Total net debt | 6,404 |  |  | 5,868 |  |  | 9 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 17,562 |  |  | 17,447 |  |  | 1 | % |
| Total capitalization | $ | 23,966 |  |  | $ | 23,315 |  |  | 3 | % |
| Total net debt as a % of total capitalization | 26.7 | % |  | 25.2 | % |  |  |

[0000833444-21-000046:mdna:95]
•Net debt and net debt as a percentage of total capitalization are non-GAAP financial measures. The Company believes the percentage of total net debt to total capitalization is useful to understanding the Company’s financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders.

[0000833444-21-000046:mdna:96]
•The Company's material cash requirements primarily consist of working capital requirements, repayments of long-term debt and related interest, operating leases, dividends, capital expenditures and potential acquisitions and stock repurchases.

[0000833444-21-000046:mdna:97]
•Refer to Note 10, "Debt and Financing Arrangements," of the notes to consolidated financial statements for additional information on debt obligations and maturities. Interest payable on long-term debt was $218 million due in the twelve months following September 30, 2021 and $3,468 million due thereafter.

[0000833444-21-000046:mdna:98]
•Refer to Note 9, "Leases," of the notes to consolidated financial statements for additional information on lease obligations and maturities.

[0000833444-21-000046:mdna:99]
•As of September 30, 2021, purchase obligations were $1,276 million payable in the next twelve months and $168 million payable thereafter. These purchase obligations represent commitments under enforceable and legally binding agreements, and do not represent the entire anticipated purchases in the future.

[0000833444-21-000046:mdna:100]
•As of September 30, 2021, the Company expects to contribute $45 million and $495 million to the global pension and postretirement plans in the next twelve months and thereafter, respectively.

[0000833444-21-000046:mdna:101]
•As of September 30, 2021, approximately $5.1 billion remains available under the Company's share repurchase authorization, which does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. The Company expects to repurchase outstanding shares from time to time depending on market conditions, alternate uses of capital, liquidity and economic environment.

[0000833444-21-000046:mdna:102]
•In the second quarter of fiscal 2021, the Company raised its annual dividend to $1.08 per share. The Company intends to continue paying quarterly dividends in fiscal 2022.

[0000833444-21-000046:mdna:103]
•The Company believes its capital resources and liquidity position at September 30, 2021 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, stock repurchases, minimum pension contributions, debt maturities and any potential acquisitions in fiscal 2022 will continue to be funded

[0000833444-21-000046:mdna:104]
from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company is unable to issue commercial paper, it would have the ability to draw on its $2.5 billion revolving credit facility which expires in December 2024 or its $0.5 billion 364-day revolving credit facility which expires in December 2021. There were no draws on the revolving credit facilities as of September 30, 2021 and 2020. The Company also selectively makes use of short-term credit lines other than its revolving credit facility. The Company, as of September 30, 2020, could borrow up to $3.0 billion based on committed credit lines. In addition, the Company held cash and cash equivalents of $1.3 billion as of September 30, 2021. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future.

[0000833444-21-000046:mdna:105]
•The Company's ability to access the global capital markets and the related cost of financing is dependent upon, among other factors, the Company's credit ratings. As of September 30, 2021, the Company's credit ratings and outlook were as follows:

[0000833444-21-000046:mdna:106]
| Rating Agency |  | Short-Term Rating |  | Long-Term Rating |  | Outlook |
| S&P |  | A-2 |  | BBB+ |  | Stable |
| Moody's |  | P-2 |  | Baa2 |  | Stable |

[0000833444-21-000046:mdna:107]
The security ratings set forth above are issued by unaffiliated third party rating agencies and are not a recommendation to buy, sell or hold securities. The ratings may be subject to revision or withdrawal by the assigning rating organization at any time.

[0000833444-21-000046:mdna:108]
•In September 2021, the Company and its wholly-owned subsidiary, Tyco Fire & Security Finance S.C.A. (“TFSCA”), issued $500 million of sustainability-linked senior notes with an initial interest rate of 2.0%, which are due in 2031. Beginning in March 2026, the interest rate payable on the note will be increased by an additional 12.5 basis points per annum if the Scope 1 and Scope 2 emissions sustainability performance target is not met and an additional 12.5 basis points per annum if the Scope 3 emissions sustainability performance target is not met. The proceeds were used for general corporate purposes, including the repayment of near-term indebtedness. In September 2021, the Company repaid $193 million of notes which were due in December 2021 and a €200 million  bank term loan which was issued in March 2021 and due in March 2022. The Company repaid $257 million in principal amount, plus accrued interest, of 4.25% fixed rate notes when they expired in March 2021. Additionally, during the fiscal year 2021 the Company repaid €43 million in principal amount, plus accrued interest, of 1.0% fixed rate notes which were due in September 2023.

[0000833444-21-000046:mdna:109]
•Financial covenants in the Company's revolving credit facilities requires a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of ASC 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of September 30, 2021, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures, governing its outstanding notes, and expect to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-21-000046:mdna:110]
•The Company earns a significant amount of its income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances. However, in fiscal 2019, the Company provided income tax expense related to a change in the Company's assertion over the outside basis differences of the Company’s investment in certain subsidiaries as a result of the planned divestiture of the Power Solutions business. Except as noted, the Company’s intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at the Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital

[0000833444-21-000046:mdna:111]
38

[0000833444-21-000046:mdna:112]
through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings.

[0000833444-21-000046:mdna:113]
•The Company may from time to time purchase our outstanding debt through open market purchases, privately negotiated transactions or otherwise. Purchases or retirement of debt, if any, will depend on prevailing market conditions, liquidity requirements, contractual restrictions and other factors. The amounts involved may be material.

[0000833444-21-000046:mdna:114]
•Refer to Note 10, "Debt and Financing Arrangements," of the notes to consolidated financial statements for additional information on items impacting capitalization.

[0000833444-21-000046:mdna:115]
Restructuring

[0000833444-21-000046:mdna:116]
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company has committed to various restructuring plans. Restructuring plans generally result in charges for workforce reductions, plant closures, asset impairments and other related costs which are reported as restructuring and impairment costs in the Company’s consolidated statements of income. The Company expects the restructuring actions to reduce cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense.

[0000833444-21-000046:mdna:117]
•In fiscal 2021, the Company announced its plans to optimize its cost structure through broad-based SG&A actions focused on simplification, standardization and centralization, with the intent to deliver annualized savings of $300 million by fiscal 2023. Additionally, the Company announced cost of sales actions to drive $250 million in annual run rate savings by fiscal 2023. The one-time pre-tax costs associated with these actions are estimated to be approximately $385 million across all segments and at Corporate. During the year ended September 30, 2021, the Company recorded $242 million of costs resulting from the 2021 restructuring plan. The restructuring action is expected to be substantially complete in fiscal 2023. The Company has outstanding restructuring reserves of $65 million at September 30, 2021, all of which is expected to be paid in cash.

[0000833444-21-000046:mdna:118]
•In fiscal 2020, the Company recorded $297 million of costs resulting from the 2020 restructuring plan. The Company currently estimates that upon completion of the restructuring action, the fiscal 2020 restructuring plans will reduce annual operating costs for continuing operations by approximately $430 million.  The annual restructuring activities are substantially completed, and final payments are expected to be made in fiscal 2022. The Company has outstanding restructuring reserves of $37 million at September 30, 2021, all of which is expected to be paid in cash.

[0000833444-21-000046:mdna:119]
Co-Issued Securities: Summarized Financial Information

[0000833444-21-000046:mdna:120]
The following information is provided in compliance with Rule 13-01 of Regulation S-X under the Securities Exchange Act of 1934 with respect to the (i) $625 million aggregate principal amount of 1.750% Senior Notes due 2030 (the “2030 Notes”), (ii) €500 million aggregate principal amount of 0.375% Senior Notes due 2027 (the “2027 Notes”), (iii) €500 million aggregate principal amount of 1.000% Senior Notes due 2032 (the “2032 Notes”) and (iv) $500 million aggregate principal amount of 2.000% Sustainability-Linked Senior Notes due 2031 (the “2031 Notes” and together with the 2032 Notes, the 2030 Notes and the 2027 Notes, the “Notes”), each issued by Johnson Controls International plc ("Parent Company") and TFSCA, a corporate partnership limited by shares (société en commandite par actions) incorporated and organized under the laws of the Grand Duchy of Luxembourg (“Luxembourg”). Refer to Note 10, "Debt and Financing Arrangements," of the notes to consolidated financial statements for additional information.

[0000833444-21-000046:mdna:121]
TFSCA is a wholly-owned consolidated subsidiary of the Company that is 99.996% owned directly by the Parent Company and 0.004% owned by TFSCA’s sole general partner and manager, Tyco Fire & Security S.à r.l., which is itself wholly-owned by the Company. The Notes are the Parent Company’s and TFSCA’s unsecured, unsubordinated obligations. The Parent Company is incorporated and organized under the laws of Ireland and TFSCA is incorporated and organized under the laws of Luxembourg. The bankruptcy, insolvency, administrative, debtor relief and other laws of Luxembourg or Ireland, as applicable, may be materially different from, or in conflict with, those of the United States, including in the areas of rights of creditors, priority of governmental and other creditors, ability to obtain post-petition interest and duration of the proceeding. The application of these laws, or any conflict among them, could adversely affect noteholders’ ability to enforce their rights under the Notes in those jurisdictions or limit any amounts that they may receive.

[0000833444-21-000046:mdna:122]
The following tables set forth summarized financial information of the Parent Company and TFSCA (collectively, the “Obligor Group”) on a combined basis after intercompany transactions have been eliminated, including adjustments to remove the receivable and payable balances, investment in, and equity in earnings from, those subsidiaries of the Parent Company other than TFSCA (collectively, the "Non-Obligor Subsidiaries").

[0000833444-21-000046:mdna:123]
The following table presents summarized income statement information for the year ended September 30, 2021 (in millions):

[0000833444-21-000046:mdna:124]
|  |  | Year Ended |  |
|  |  | September 30, 2021 |  |
| Net sales |  | $ | — |  |  |
| Gross profit |  | — |  |  |
| Loss from continuing operations |  | (212) |  |  |
| Net loss |  | (212) |  |  |
| Income attributable to noncontrolling interests |  | — |  |  |
| Net loss attributable to the entity |  | (212) |  |  |

[0000833444-21-000046:mdna:125]
40

[0000833444-21-000046:mdna:126]
Excluded from the table above are the intercompany transactions between the Obligor Group and Non-Obligor Subsidiaries as follows (in millions):

[0000833444-21-000046:mdna:127]
|  |  | Year Ended |  |
|  |  | September 30, 2021 |  |
| Net sales |  | $ | — |  |  |
| Gross profit |  | — |  |  |
| Income from continuing operations |  | 223 |  |  |
| Net income |  | 223 |  |  |
| Income attributable to noncontrolling interests |  | — |  |  |
| Net income attributable to the entity |  | 223 |  |  |

[0000833444-21-000046:mdna:128]
The following table presents summarized balance sheet information as of September 30, 2021 (in millions):

[0000833444-21-000046:mdna:129]
|  |  | September 30, 2021 |  |
| Current assets |  | $ | 1,036 |  |  |
| Noncurrent assets |  | 280 |  |  |
| Current liabilities |  | 1,825 |  |  |
| Noncurrent liabilities |  | 7,260 |  |  |
| Noncontrolling interests |  | — |  |  |

[0000833444-21-000046:mdna:130]
Excluded from the table above are the intercompany balances between the Obligor Group and Non-Obligor Subsidiaries as follows (in millions):

[0000833444-21-000046:mdna:131]
|  |  | September 30, 2021 |  |
| Current assets |  | $ | 465 |  |  |
| Noncurrent assets |  | 2,992 |  |  |
| Current liabilities |  | 1,660 |  |  |
| Noncurrent liabilities |  | 7,199 |  |  |
| Noncontrolling interests |  | — |  |  |

[0000833444-21-000046:mdna:132]
The same accounting policies as described in Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements are used by the Parent Company and each of its subsidiaries in connection with the summarized financial information presented above.

[0000833444-21-000046:mdna:133]
CRITICAL ACCOUNTING ESTIMATES

[0000833444-21-000046:mdna:134]
The Company prepares its consolidated financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). This requires management to make estimates and assumptions that affect reported amounts and related disclosures. Actual results could differ from those estimates. The following estimates are considered by management to be the most critical to the understanding of the Company's consolidated financial statements as they require significant judgments that could materially impact the Company’s results of operations, financial position and cash flows.

[0000833444-21-000046:mdna:135]
Revenue Recognition

[0000833444-21-000046:mdna:136]
The Company recognizes revenue from certain long-term contracts on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. Total estimated costs at completion are based primarily on estimated purchase contract terms, historical performance trends and other economic projections.  Factors that may result in a change to these estimates include unforeseen engineering problems, construction delays, the performance of subcontractors and major material suppliers, and weather conditions. As a result, changes to the original estimates may be required during the life of the contract. Such estimates are reviewed monthly and any adjustments to the measure of completion are recognized as adjustments to sales and gross profit using the cumulative catch-up method. Estimated losses are recorded when identified.

[0000833444-21-000046:mdna:137]
For agreements with multiple performance obligations, the Company allocates the transaction price of the contract to each performance obligation using the best estimate of the standalone selling price of each distinct good or service in the contract.  In order to estimate relative selling price, market data and transfer price studies are utilized. If the standalone selling price is not directly observable, the Company estimates the standalone selling price using an adjusted market assessment approach or expected cost plus margin approach.

[0000833444-21-000046:mdna:138]
The Company considers the contractual consideration payable by the customer and assesses variable consideration that may affect the total transaction price, including discounts, rebates, refunds, credits or other similar sources of variable consideration, when determining the transaction price of each contract. The Company includes variable consideration in the estimated transaction price when it is probable that significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. These estimates are based on the amount of consideration that the Company expects to be entitled to.

[0000833444-21-000046:mdna:139]
Goodwill and Indefinite-Lived Intangible Assets

[0000833444-21-000046:mdna:140]
The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s reportable segments or one level below the reportable segments in certain instances, using a fair value method based on management’s judgments and assumptions or third party valuations. The fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. In estimating the fair value, the Company uses the multiples of earnings approach based on the average of published multiples of earnings of comparable entities with similar operations and economic characteristics that are applied to the Company's average of historical and future financial results. In certain instances, the Company uses discounted cash flow analyses or estimated sales price to further support the fair value estimates. The assumptions included in the impairment tests require judgment, and changes to these inputs could impact the results of the calculations. The key assumptions used in the impairment tests were management's projections of future cash flows, weighted-average cost of capital and long-term growth rates. Although the Company's cash flow forecasts are based on assumptions that are considered reasonable by management and consistent with the plans and estimates management is using to operate the underlying businesses, there are significant judgments in determining the expected future cash flows attributable to a reporting unit.

[0000833444-21-000046:mdna:141]
Based on the fiscal 2021 annual impairment test, there were no goodwill impairments and no reporting unit was determined to be at risk of failing the goodwill impairment test.

[0000833444-21-000046:mdna:142]
Indefinite-lived intangible assets are also subject to at least annual impairment testing. Indefinite-lived intangible assets primarily consist of trademarks and trade names and are tested for impairment using a relief-from-royalty method. A considerable amount of management judgment and assumptions are required in performing the impairment tests. The key assumptions used in the impairment tests were long-term revenue growth projections,  weighted-average cost of capital and general industry, market and macro-economic conditions.

[0000833444-21-000046:mdna:143]
There were no indefinite-lived intangible asset impairments resulting from the fiscal 2021 annual impairment test. The estimated fair values of all indefinite-lived intangibles substantially exceeded their carrying values, with the exception of the indefinite-lived trademark related to the Company's Asia Pacific subscriber businesses. The estimated fair value of the Asia Pacific indefinite-lived trademark was consistent with its carrying value of $38 million as of September 30, 2021.

[0000833444-21-000046:mdna:144]
The Company continuously monitors for events and circumstances that could negatively impact the key assumptions in determining fair value.  While the Company believes the judgments and assumptions used in the goodwill and indefinite-lived intangible impairment tests are reasonable, different assumptions or changes in general industry, market and macro-economic conditions, including a more prolonged and/or severe COVID-19 pandemic, could change the estimated fair values and, therefore, future impairment charges could be required, which could be material to the consolidated financial statements.

[0000833444-21-000046:mdna:145]
Employee Benefit Plans

[0000833444-21-000046:mdna:146]
The Company provides a range of benefits to its employees and retired employees, including pensions and postretirement benefits. Plan assets and obligations are measured annually, or more frequently if there is a significant remeasurement event, based on the Company’s measurement date utilizing various actuarial assumptions such as discount rates, assumed rates of return, compensation increases and health care cost trend rates as of that date. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends when appropriate.

[0000833444-21-000046:mdna:147]
42

[0000833444-21-000046:mdna:148]
The Company utilizes a mark-to-market approach for recognizing pension and postretirement benefit expenses, including measuring the market related value of plan assets at fair value and recognizing actuarial gains and losses in the fourth quarter of each fiscal year or at the date of a remeasurement event. Refer to Note 16, "Retirement Plans," of the notes to consolidated financial statements for disclosure of the Company's pension and postretirement benefit plans.

[0000833444-21-000046:mdna:149]
U.S. GAAP requires that companies recognize in the statement of financial position a liability for defined benefit pension and postretirement plans that are underfunded or unfunded, or an asset for defined benefit pension and postretirement plans that are over funded. U.S. GAAP also requires that companies measure the benefit obligations and fair value of plan assets that determine a benefit plan’s funded status as of the date of the employer’s fiscal year end.

[0000833444-21-000046:mdna:150]
The Company considers the expected benefit payments on a plan-by-plan basis when setting assumed discount rates. As a result, the Company uses different discount rates for each plan depending on the plan jurisdiction, the demographics of participants and the expected timing of benefit payments. For the U.S. pension and postretirement plans, the Company uses a discount rate provided by an independent third party calculated based on an appropriate mix of high quality bonds. For the non-U.S. pension and postretirement plans, the Company consistently uses the relevant country specific benchmark indices for determining the various discount rates. The Company’s weighted average discount rate on U.S. pension plans was 2.50% and 2.25% at September 30, 2021 and 2020, respectively. The Company’s weighted average discount rate on postretirement plans was 2.30% and 1.90% at September 30, 2021 and 2020, respectively. The Company’s weighted average discount rate on non-U.S. pension plans was 1.80% and 1.35% at September 30, 2021 and 2020, respectively.

[0000833444-21-000046:mdna:151]
In estimating the expected return on plan assets, the Company considers the historical returns on plan assets, adjusted for forward-looking considerations, inflation assumptions and the impact of the active management of the plans’ invested assets. Reflecting the relatively long-term nature of the plans’ obligations, approximately 20% of the plans’ assets are invested in equity securities and 68% in fixed income securities, with the remainder primarily invested in alternative investments. For the years ending September 30, 2021 and 2020, the Company’s expected long-term return on U.S. pension plan assets used to determine net periodic benefit cost was 6.50% and 6.90%, respectively. The actual rate of return on U.S. pension plans was above 6.50% in fiscal year 2021 and above 6.90% in fiscal year 2020. For the years ending September 30, 2021 and 2020, the Company’s weighted average expected long-term return on non-U.S. pension plan assets was 4.90% and 5.20%, respectively. The actual rate of return on non-U.S. pension plans was above 4.90% in fiscal year 2021 and below 5.20% in fiscal year 2020. For the years ending September 30, 2021 and 2020, the Company’s weighted average expected long-term return on postretirement plan assets was 5.30% and 5.70%, respectively. The actual rate of return on postretirement plan assets was above 5.30% in fiscal year 2021 and below 5.70% in fiscal year 2020.

[0000833444-21-000046:mdna:152]
Beginning in fiscal 2022, the Company believes the long-term rate of return will approximate 7.00%, 3.70% and 5.30% for U.S. pension, non-U.S. pension and postretirement plans, respectively. Any differences between actual investment results and the expected long-term asset returns will be reflected in net periodic benefit costs in the fourth quarter of each fiscal year or at the date of a significant remeasurement event. If the Company’s actual returns on plan assets are less than the Company’s expectations, additional contributions may be required.

[0000833444-21-000046:mdna:153]
In fiscal 2021, total employer contributions for continuing operations to the defined benefit pension plans were $65 million, none of which were voluntary contributions made by the Company. The Company expects to contribute approximately $42 million in cash to its defined benefit pension plans in fiscal 2022. In fiscal 2021, total employer contributions for continuing operations to the postretirement plans were $3 million. The Company expects to contribute approximately $3 million in cash to its postretirement plans in fiscal 2022.

[0000833444-21-000046:mdna:154]
Based on information provided by its independent actuaries and other relevant sources, the Company believes that the assumptions used are reasonable; however, changes in these assumptions could impact the Company’s financial position, results of operations or cash flows.

[0000833444-21-000046:mdna:155]
The mark-to-market adjustments represent actuarial gains (losses) arising from changes in actuarial assumptions and actuarial experiences different from those assumed that are used to value the plan assets and the benefit obligations. The primary factors contributing to actuarial gains (losses) are changes in the discount rate used to value benefit obligations and the difference between expected and actual returns on plan assets. As such, the mark-to-market adjustments are highly volatile and are difficult to forecast. Mark-to-market adjustments were $365 million, $(295) million and $(630) million for the fiscal years ended September 30, 2021, 2020 and 2019, respectively.

[0000833444-21-000046:mdna:156]
The following chart illustrates the estimated increases (decreases) in projected benefit obligation and future ongoing pension expense, which excludes any potential mark-to-market adjustments, assuming an increase of 25 basis points in the key assumptions for our pension plans (in millions):

[0000833444-21-000046:mdna:157]
|  | Pension Benefits |
|  | U.S. Plans |  | Non-U.S. Plans |
|  | Change in Projected Benefit Obligation |  | Change in Ongoing Pension Expense |  | Change in Projected Benefit Obligation |  | Change in Ongoing Pension Expense |
| Discount rate | $ | (51) |  |  | $ | 5 |  |  | $ | (84) |  |  | $ | 4 |  |
| Expected return on plan assets | — |  |  | (6) |  |  | — |  |  | (5) |  |

[0000833444-21-000046:mdna:158]
A 25 basis point change in the discount rate would not have a material impact on our post-retirement benefit plan obligations.

[0000833444-21-000046:mdna:159]
Loss Contingencies

[0000833444-21-000046:mdna:160]
Accruals are recorded for various contingencies including legal proceedings, environmental matters, self-insurance and other claims that arise in the normal course of business. The accruals are based on judgment, the probability of losses and, where applicable, the consideration of opinions of internal and/or external legal counsel and actuarially determined estimates. Additionally, the Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-21-000046:mdna:161]
The Company is subject to laws and regulations relating to protecting the environment. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. The Company provides for expenses associated with environmental remediation obligations when such amounts are probable and can be reasonably estimated. The Company provides for expenses associated with environmental remediation obligations when such amounts are probable and can be reasonably estimated. Refer to Note 23, "Commitments and Contingencies," of the notes to consolidated financial statements.

[0000833444-21-000046:mdna:162]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company records receivables from third party insurers when recovery has been determined to be probable. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-21-000046:mdna:163]
Asbestos-Related Contingencies and Insurance Receivables

[0000833444-21-000046:mdna:164]
The Company and certain of its subsidiaries along with numerous other companies are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The

[0000833444-21-000046:mdna:165]
Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-21-000046:mdna:166]
In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable. The Company's estimate of asbestos-related insurance recoveries represents estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims discounted to present value. In determining the amount of insurance recoverable, the Company considers available insurance, allocation methodologies, solvency and creditworthiness of the insurers. Refer to Note 23, "Commitments and Contingencies," of the notes to consolidated financial statements for a discussion on management's judgments applied in the recognition and measurement of asbestos-related assets and liabilities.

[0000833444-21-000046:mdna:167]
Income Taxes

[0000833444-21-000046:mdna:168]
The Company accounts for income taxes in accordance with ASC 740, "Income Taxes." Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and other loss carryforwards. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company records a valuation allowance that primarily represents non-U.S. operating and other loss carryforwards for which realization is uncertain. Management judgment is required in determining the Company’s provision for income taxes, deferred tax assets and liabilities, and the valuation allowance recorded against the Company’s net deferred tax assets.

[0000833444-21-000046:mdna:169]
The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary. At September 30, 2021, the Company had a valuation allowance of $5.9 billion for continuing operations, of which $5.2 billion relates to net operating loss carryforwards primarily in France, Germany, Ireland, Luxembourg, Mexico, Spain, United Kingdom and the U.S. for which sustainable taxable income has not been demonstrated; and $0.7 billion for other deferred tax assets.

[0000833444-21-000046:mdna:170]
The Company’s federal income tax returns and certain non-U.S. income tax returns for various fiscal years remain under various stages of audit by the IRS and respective non-U.S. tax authorities. Although the outcome of tax audits is always uncertain, management believes that it has appropriate support for the positions taken on its tax returns and that its annual tax provisions included amounts sufficient to pay assessments, if any, which may be proposed by the taxing authorities. At September 30, 2021, the Company had recorded a liability of $2.7 billion for its best estimate of the probable loss on certain of its tax positions, the majority of which is included in other noncurrent liabilities in the consolidated statements of financial position. Nonetheless, the amounts ultimately paid, if any, upon resolution of the issues raised by the taxing authorities may differ materially from the amounts accrued for each year.

[0000833444-21-000046:mdna:171]
The Company does not generally provide additional U.S. or non-U.S. income taxes on outside basis differences of consolidated subsidiaries included in shareholders’ equity attributable to Johnson Controls International plc, except in limited circumstances including anticipated taxation on planned divestitures. The reduction of the outside basis differences via the sale or liquidation of these subsidiaries and/or distributions could create taxable income. The Company’s intent is to reduce the outside basis differences only when it would be tax efficient.  Refer to "Capitalization" within the "Liquidity and Capital Resources" section for discussion of U.S. and non-U.S. cash projections.

[0000833444-21-000046:mdna:172]
Refer to Note 19, "Income Taxes," of the notes to consolidated financial statements for the Company's income tax disclosures.

[0000833444-21-000046:mdna:173]
NEW ACCOUNTING PRONOUNCEMENTS

[0000833444-21-000046:mdna:174]
Refer to the "New Accounting Pronouncements" section within Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements.

[0000833444-21-000046:mdna:175]
RISK MANAGEMENT

[0000833444-21-000046:mdna:176]
The Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities and stock-based compensation. All hedging transactions are authorized and executed pursuant to clearly defined policies and procedures, which strictly prohibit the use of financial instruments for speculative purposes. At the inception of the

[0000833444-21-000046:mdna:177]
hedge, the Company assesses the effectiveness of the hedge instrument and designates the hedge instrument as either (1) a hedge of a recognized asset or liability or of a recognized firm commitment (a fair value hedge), (2) a hedge of a forecasted transaction or of the variability of cash flows to be received or paid related to an unrecognized asset or liability (a cash flow hedge) or (3) a hedge of a net investment in a non-U.S. operation (a net investment hedge). The Company performs hedge effectiveness testing on an ongoing basis depending on the type of hedging instrument used. All other derivatives not designated as hedging instruments under ASC 815, "Derivatives and Hedging," are revalued in the consolidated statements of income.

[0000833444-21-000046:mdna:178]
For all foreign currency derivative instruments designated as cash flow hedges, retrospective effectiveness is tested on a monthly basis using a cumulative dollar offset test. The fair value of the hedged exposures and the fair value of the hedge instruments are revalued, and the ratio of the cumulative sum of the periodic changes in the value of the hedge instruments to the cumulative sum of the periodic changes in the value of the hedge is calculated. The hedge is deemed as highly effective if the ratio is between 80% and 125%. For commodity derivative contracts designated as cash flow hedges, effectiveness is tested using a regression calculation. Ineffectiveness is minimal as the Company aligns most of the critical terms of its derivatives with the supply contracts.

[0000833444-21-000046:mdna:179]
For net investment hedges, the Company assesses its net investment positions in the non-U.S. operations and compares it with the outstanding net investment hedges on a quarterly basis. The hedge is deemed effective if the aggregate outstanding principal of the hedge instruments designated as the net investment hedge in a non-U.S. operation does not exceed the Company’s net investment positions in the respective non-U.S. operation.

[0000833444-21-000046:mdna:180]
Equity swaps and any other derivative instruments not designated as hedging instruments under ASC 815 require no assessment of effectiveness.

[0000833444-21-000046:mdna:181]
A discussion of the Company’s accounting policies for derivative financial instruments is included in Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements, and further disclosure relating to derivatives and hedging activities is included in Note 11, "Derivative Instruments and Hedging Activities," and Note 12, "Fair Value Measurements," of the notes to consolidated financial statements.

[0000833444-21-000046:mdna:182]
Foreign Exchange

[0000833444-21-000046:mdna:183]
The Company has manufacturing, sales and distribution facilities around the world and thus makes investments and enters into transactions denominated in various foreign currencies. In order to maintain strict control and achieve the benefits of the Company’s global diversification, foreign exchange exposures for each currency are netted internally so that only its net foreign exchange exposures are, as appropriate, hedged with financial instruments.

[0000833444-21-000046:mdna:184]
The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. The Company primarily enters into foreign currency exchange contracts to reduce the earnings and cash flow impact of the variation of non-functional currency denominated receivables and payables. Gains and losses resulting from hedging instruments offset the foreign exchange gains or losses on the underlying assets and liabilities being hedged. The maturities of the forward exchange contracts generally coincide with the settlement dates of the related transactions. Realized and unrealized gains and losses on these contracts are recognized in the same period as gains and losses on the hedged items. The Company also selectively hedges anticipated transactions that are subject to foreign exchange exposure, primarily with foreign currency exchange contracts, which are designated as cash flow hedges in accordance with ASC 815.

[0000833444-21-000046:mdna:185]
The Company has entered into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of debt obligations are reflected in the accumulated other comprehensive income ("AOCI") account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally.

[0000833444-21-000046:mdna:186]
At September 30, 2021 and 2020, the Company estimates that an unfavorable 10% change in the exchange rates would have decreased net unrealized gains by approximately $213 million and $363 million, respectively.

[0000833444-21-000046:mdna:187]
Interest Rates

[0000833444-21-000046:mdna:188]
Substantially all of the Company's outstanding debt has fixed interest rates. A 10% increase in the average cost of the Company’s variable rate debt would have had an immaterial impact on pre-tax interest expense for the years ended September 30, 2021 and 2020.

[0000833444-21-000046:mdna:189]
Commodities

[0000833444-21-000046:mdna:190]
The Company uses commodity hedge contracts in the financial derivatives market in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. As a cash flow hedge, gains and losses resulting from the hedging instruments offset the gains or losses on purchases of the underlying commodities that will be used in the business. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities.

[0000833444-21-000046:mdna:191]
ENVIRONMENTAL, HEALTH AND SAFETY AND OTHER MATTERS

[0000833444-21-000046:mdna:192]
The Company’s global operations are governed by environmental laws and worker safety laws. Under various circumstances, these laws impose civil and criminal penalties and fines, as well as injunctive and remedial relief, for noncompliance and require remediation at sites where Company-related substances have been released into the environment.

[0000833444-21-000046:mdna:193]
The Company has expended substantial resources globally, both financial and managerial, to comply with applicable environmental laws and worker safety laws and to protect the environment and workers. The Company believes it is in substantial compliance with such laws and maintains procedures designed to foster and ensure compliance. However, the Company has been, and in the future may become, the subject of formal or informal enforcement actions or proceedings regarding noncompliance with such laws or the remediation of Company-related substances released into the environment. Such matters typically are resolved with regulatory authorities through commitments to compliance, abatement or remediation programs and in some cases payment of penalties. Historically, neither such commitments nor penalties imposed on the Company have been material.

[0000833444-21-000046:mdna:194]
Refer to Note 23, "Commitments and Contingencies," of the notes to consolidated financial statements for additional information.
