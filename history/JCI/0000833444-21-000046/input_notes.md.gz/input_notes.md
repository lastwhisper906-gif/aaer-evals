# JCI notes — 0000833444-21-000046


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000833444-21-000046:notes:1]
Portions of the definitive Proxy Statement to be delivered to shareholders in connection with the annual general meeting of shareholders to be held on March 9, 2022 are incorporated by reference into Part III.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000833444-21-000046:notes:2]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company," "Johnson Controls" or "JCI plc").

[0000833444-21-000046:notes:3]
Nature of Operations

[0000833444-21-000046:notes:4]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global diversified technology and multi-industrial leader, serving a wide range of customers in more than 150 countries. The Company’s products and solutions enable smart, energy efficient, sustainable buildings that work seamlessly together to advance the safety, comfort and intelligence of spaces to power its customers’ mission. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-21-000046:notes:5]
In 2019, the Company sold its Power Solutions business to BCP Acquisitions LLC ("Purchaser"), an entity controlled by investment funds managed by Brookfield Capital Partners LLC, completing the Company’s transformation into a pure-play building technologies and solutions provider. The transaction closed on April 30, 2019 with net cash proceeds of $11.6 billion after tax and transaction-related expenses. Refer to Note 3, "Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-21-000046:notes:6]
The Company is a global leader in engineering, manufacturing and commissioning building products and systems, including residential and commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, repair, retrofit and replacement of equipment (in the HVAC, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions powered by its digital platforms and capabilities.

[0000833444-21-000046:notes:7]
Principles of Consolidation

[0000833444-21-000046:notes:8]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries that are consolidated in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). All significant intercompany transactions have been eliminated. The results of companies acquired or disposed of during the year are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company’s interest exceeds 20% and the Company does not have a controlling interest.

[0000833444-21-000046:notes:9]
The Company consolidates variable interest entities ("VIE") in which the Company has the power to direct the significant activities of the entity and the obligation to absorb losses or receive benefits from the entity that may be significant. The Company did not have a significant variable interest in any consolidated or nonconsolidated VIEs in its continuing operations for the presented reporting periods.

[0000833444-21-000046:notes:10]
Use of Estimates

[0000833444-21-000046:notes:11]
The preparation of consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0000833444-21-000046:notes:12]
Fair Value of Financial Instruments

[0000833444-21-000046:notes:13]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. See Note 11, "Derivative Instruments and Hedging Activities," and Note 12, "Fair Value Measurements," of the notes to consolidated financial statements for fair value of financial instruments, including derivative instruments, hedging activities and long-term debt.

[0000833444-21-000046:notes:14]
Assets and Liabilities Held for Sale

[0000833444-21-000046:notes:15]
The Company classifies assets and liabilities (disposal groups) to be sold as held for sale in the period in which all of the following criteria are met: management, having the authority to approve the action, commits to a plan to sell the disposal group; the disposal group is available for immediate sale in its present condition subject only to terms that are usual and customary for sales of such disposal groups; an active program to locate a buyer and other actions required to complete the plan to sell the disposal group have been initiated; the sale of the disposal group is probable, and transfer of the disposal group is expected to qualify for recognition as a completed sale within one year, except if events or circumstances beyond the Company's control extend the period of time required to sell the disposal group beyond one year; the disposal group is being actively marketed for sale at a price that is reasonable in relation to its current fair value; and actions required to complete the plan indicate that it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn.

[0000833444-21-000046:notes:16]
The Company initially measures a disposal group that is classified as held for sale at the lower of its carrying value or fair value less any costs to sell. Any loss resulting from this measurement is recognized in the period in which the held for sale criteria are met. Conversely, gains are not recognized on the sale of a disposal group until the date of sale. The Company assesses the fair value of a disposal group, less any costs to sell, each reporting period it remains classified as held for sale and reports any subsequent changes as an adjustment to the carrying value of the disposal group, as long as the new carrying value does not exceed the carrying value of the disposal group at the time it was initially classified as held for sale.

[0000833444-21-000046:notes:17]
Upon determining that a disposal group meets the criteria to be classified as held for sale, the Company reports the assets and liabilities of the disposal group, if material, in the line items assets held for sale and liabilities held for sale in the consolidated statements of financial position. Refer to Note 3, "Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-21-000046:notes:18]
Cash and Cash Equivalents

[0000833444-21-000046:notes:19]
The Company considers all highly liquid investments with an original maturity of three months or less when purchased to be cash equivalents.

[0000833444-21-000046:notes:20]
Restricted Cash

[0000833444-21-000046:notes:21]
At September 30, 2021 and September 30, 2020, the Company held restricted cash of approximately $6 million and $9 million, respectively all of which was recorded within other current assets in the consolidated statements of financial position. These amounts related to cash restricted for payment of asbestos liabilities.

[0000833444-21-000046:notes:22]
Receivables

[0000833444-21-000046:notes:23]
Receivables consist of amounts billed and currently due from customers and unbilled costs and accrued profits related to revenues on long-term contracts that have been recognized for accounting purposes but not yet billed to customers. The Company extends credit to customers in the normal course of business and maintains an allowance for expected credit losses resulting from the inability or unwillingness of customers to make required payments. The allowance for expected credit losses is based on historical experience, existing economic conditions, reasonable and supportable forecasts, and any specific customer collection issues the Company has identified. The Company enters into various factoring agreements to sell certain accounts receivable to third-party financial institutions. For ease of administration, the Company collects customer payments related to certain factored receivables on behalf of the financial institutions but otherwise maintains no other continuing involvement with respect to the factored receivables. Sales of accounts receivable are reflected as a reduction of accounts receivable in the consolidated statements of financial position and the proceeds are included in cash flows from operating activities in the consolidated statements of cash flows.

[0000833444-21-000046:notes:24]
Inventories

[0000833444-21-000046:notes:25]
Inventories are stated at the lower of cost or net realizable value using the first-in, first-out ("FIFO") method. Finished goods and work-in-process inventories include material, labor and manufacturing overhead costs.

[0000833444-21-000046:notes:26]
Property, Plant and Equipment

[0000833444-21-000046:notes:27]
Property, plant and equipment are recorded at cost. Depreciation is provided over the estimated useful lives of the respective assets using the straight-line method for financial reporting purposes and accelerated methods for income tax purposes. The estimated useful lives generally range from 3 to 40 years for buildings and improvements, subscriber systems up to 15 years,

[0000833444-21-000046:notes:28]
and from 3 to 15 years for machinery and equipment. The Company capitalizes interest on borrowings during the active construction period of major capital projects. Capitalized interest is added to the cost of the underlying assets and is amortized over the useful lives of the assets.

[0000833444-21-000046:notes:29]
Goodwill and Indefinite-Lived Intangible Assets

[0000833444-21-000046:notes:30]
Goodwill reflects the cost of an acquisition in excess of the fair values assigned to identifiable net assets acquired. The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s reportable segments or one level below the reportable segments in certain instances, using a fair value method based on management’s judgments and assumptions or third party valuations. The fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. In estimating the fair value, the Company uses the multiples of earnings approach based on the average of published multiples of earnings of comparable entities with similar operations and economic characteristics and applies the multiples to the Company's average of historical and future financial results for each reporting unit. In certain instances, the Company uses discounted cash flow analyses or estimated sales price to further support the fair value estimates. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The estimated fair value is then compared with the carrying amount of the reporting unit, including recorded goodwill. The Company is subject to financial statement risk to the extent that the carrying amount exceeds the estimated fair value. Refer to Note 8, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for information regarding the goodwill impairment testing performed in fiscal years 2021, 2020 and 2019.

[0000833444-21-000046:notes:31]
Indefinite-lived intangible assets are also subject to at least annual impairment testing. Indefinite-lived intangible assets primarily consist of trademarks and trade names and are tested for impairment using a relief-from-royalty method. A considerable amount of management judgment and assumptions are required in performing the impairment tests.

[0000833444-21-000046:notes:32]
Leases

[0000833444-21-000046:notes:33]
Lessee arrangements

[0000833444-21-000046:notes:34]
The Company leases certain administrative, production and other facilities, fleet vehicles, information technology equipment and other equipment under arrangements that are accounted for as operating leases. The Company determines whether an arrangement contains a lease at contract inception based on whether the arrangement involves the use of a physically distinct identified asset and whether the Company has the right to obtain substantially all of the economic benefits from the use of the asset throughout the period as well as the right to direct the use of the asset.

[0000833444-21-000046:notes:35]
Right-of-use assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent its obligation to make lease payments arising from the lease. Right-of-use assets and the corresponding lease liabilities are recognized at commencement date based on the present value of lease payments for all leases with terms longer than twelve months. As the majority of the Company's leases do not provide an implicit interest rate, to determine the present value of lease payments, the Company uses its incremental borrowing rate based on information available on the lease commencement date and uses the implicit rate when readily determinable.  The Company determines its incremental borrowing rate based on a comparable market yield curve consistent with its credit rating, term of the lease and relative economic environment. The Company has elected to combine lease and nonlease components for its leases.

[0000833444-21-000046:notes:36]
Lessor arrangements

[0000833444-21-000046:notes:37]
The Company's monitoring services and maintenance agreements within its security business that include subscriber system assets for which the Company retains ownership contain both lease and nonlease components. The Company has elected to combine lease and nonlease components for these arrangements where the timing and pattern of transfer of the lease and nonlease components are the same and the lease component would be classified as an operating lease if accounted for separately. The Company has concluded that in these arrangements the nonlease components are the predominant characteristic, and as a result, the combined component is accounted for under the revenue guidance.

[0000833444-21-000046:notes:38]
Impairment of Long-Lived Assets

[0000833444-21-000046:notes:39]
The Company reviews long-lived assets, including right-of-use assets under operating leases, other tangible assets and intangible assets with definitive lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with

[0000833444-21-000046:notes:40]
ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of Software to be Sold, Leased, or Marketed."

[0000833444-21-000046:notes:41]
The Company groups assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluates the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. Intangible assets acquired in a business combination that are used in research and development activities are considered indefinite-lived until the completion or abandonment of the associated research and development efforts. During the period that those assets are considered indefinite lived, they are not amortized but are tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired.  If the carrying amount of an intangible asset exceeds its fair value, the Company recognizes an impairment loss in an amount equal to that excess. Unamortized capitalized costs of a computer software product are compared to the net realizable value of the product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset is written off. Refer to Note 18, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for information regarding the impairment testing performed in fiscal years 2021, 2020 and 2019.

[0000833444-21-000046:notes:42]
Revenue Recognition

[0000833444-21-000046:notes:43]
The Company recognizes revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. The Company does not adjust the promised amount of consideration for the effects of a significant financing component as at contract inception the Company expects to receive the payment within twelve months of transfer of goods or services.

[0000833444-21-000046:notes:44]
The Company enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized over time on a straight-line basis over the respective contract term.

[0000833444-21-000046:notes:45]
The Company also sells certain HVAC and refrigeration products and services in bundled arrangements with multiple performance obligations, such as equipment, commissioning, service labor and extended warranties. Approximately four to twelve months separate the timing of the first deliverable until the last piece of equipment is delivered, and there may be extended warranty arrangements with duration of one to five years commencing upon the end of the standard warranty period. In addition, the Company sells security monitoring systems that may have multiple performance obligations, including equipment, installation, monitoring services and maintenance agreements. Revenues associated with the sale of equipment and related installations are recognized over time on a cost-to-cost input method, while the revenue for monitoring and maintenance services are recognized over time as services are rendered. The transaction price is allocated to each performance obligation based on the relative selling price method. In order to estimate relative selling price, market data and transfer price studies are utilized. If the standalone selling price is not directly observable, the Company estimates the standalone selling price using an adjusted market assessment approach or expected cost plus margin approach. For transactions in which the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized over time on a straight-line basis over the contract term. Non-refundable fees received in connection with the initiation of a monitoring contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the contract.

[0000833444-21-000046:notes:46]
In all other cases, the Company recognizes revenue at the point in time when control over the goods or services transfers to the customer.

[0000833444-21-000046:notes:47]
The Company considers the contractual consideration payable by the customer and assesses variable consideration that may affect the total transaction price, including discounts, rebates, refunds, credits or other similar sources of variable consideration, when determining the transaction price of each contract. The Company includes variable consideration in the estimated transaction price when it is probable that significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. These estimates are based on the amount of consideration that the Company expects to be entitled to.

[0000833444-21-000046:notes:48]
Shipping and handling costs billed to customers are included in sales and the related costs are included in cost of sales when control transfers to the customer. The Company presents amounts collected from customers for sales and other taxes net of the related amounts remitted.

[0000833444-21-000046:notes:49]
Subscriber System Assets, Dealer Intangibles and Related Deferred Revenue Accounts

[0000833444-21-000046:notes:50]
The Company considers assets related to the acquisition of new customers in its electronic security business in three asset categories: internally generated residential subscriber systems outside of North America, internally generated commercial subscriber systems (collectively referred to as subscriber system assets) and customer accounts acquired through the ADT dealer program, primarily outside of North America (referred to as dealer intangibles). Subscriber system assets include installed property, plant and equipment for which the Company retains ownership and deferred costs directly related to the customer acquisition and system installation. Subscriber system assets represent capitalized equipment (e.g. security control panels, touch pad, motion detectors, window sensors, and other equipment) and installation costs associated with electronic security monitoring arrangements under which the Company retains ownership of the security system assets in a customer's place of business, or outside of North America, residence. Installation costs represent costs incurred to prepare the asset for its intended use. The Company pays property taxes on the subscriber system assets and upon customer termination, may retrieve such assets. These assets embody a probable future economic benefit as they generate future monitoring revenue for the Company.

[0000833444-21-000046:notes:51]
Costs related to the subscriber system equipment and installation are categorized as property, plant and equipment rather than deferred costs. Deferred costs associated with subscriber system assets represent direct and incremental selling expenses (such as commissions) related to acquiring the customer. Commissions related to up-front consideration paid by customers in connection with the establishment of the monitoring arrangement are determined based on a percentage of the up-front fees and do not exceed deferred revenue. Such deferred costs are recorded as other current and noncurrent assets within the consolidated statements of financial position.

[0000833444-21-000046:notes:52]
Subscriber system assets and any deferred revenue resulting from the customer acquisition are accounted for over the expected life of the subscriber. In certain geographical areas where the Company has a large number of customers that behave in a similar manner over time, the Company accounts for subscriber system assets and related deferred revenue using pools, with separate pools for the components of subscriber system assets and any related deferred revenue based on the same month and year of acquisition. The Company depreciates its pooled subscriber system assets and related deferred revenue using a straight-line method with lives up to 12 years and considering customer attrition. The Company uses a straight-line method with a 15-year life for non-pooled subscriber system assets (primarily in Europe, Latin America and Asia) and related deferred revenue, with remaining balances written off upon customer termination.

[0000833444-21-000046:notes:53]
Certain contracts and related customer relationships result from purchasing residential security monitoring contracts from an external network of independent dealers who operate under the ADT dealer program, primarily outside of North America. Acquired contracts and related customer relationships are recorded at their contractually determined purchase price.

[0000833444-21-000046:notes:54]
During the first 6 months (12 months in certain circumstances) after the purchase of the customer contract, any cancellation of monitoring service, including those that result from customer payment delinquencies, results in a chargeback by the Company to the dealer for the full amount of the contract purchase price. The Company records the amount charged back to the dealer as a reduction of the previously recorded intangible asset.

[0000833444-21-000046:notes:55]
Intangible assets arising from the ADT dealer program described above are amortized in pools determined by the same month and year of contract acquisition on a straight-line basis over the period of the customer relationship. The estimated useful life of dealer intangibles ranges from 12 to 15 years.

[0000833444-21-000046:notes:56]
Research and Development Costs

[0000833444-21-000046:notes:57]
Expenditures for research activities relating to product development and improvement are charged against income as incurred and included within selling, general and administrative expenses for continuing operations in the consolidated statements of income. Such expenditures for the years ended September 30, 2021, 2020 and 2019 were $275 million, $274 million and $319 million, respectively.

[0000833444-21-000046:notes:58]
Earnings Per Share

[0000833444-21-000046:notes:59]
The Company presents both basic and diluted EPS amounts. Basic EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares outstanding during the reporting period. Diluted EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares and ordinary equivalent shares outstanding during the reporting period that are calculated using the treasury stock method for stock options, unvested restricted stock and unvested performance share awards. The treasury stock method assumes that the Company uses the proceeds from the exercise of stock option awards to repurchase ordinary shares at the average market price during the period. The assumed proceeds under the treasury stock method include the purchase price that the grantee will pay in the future and compensation cost for future service that the Company has not yet recognized. For unvested restricted stock and unvested performance share awards, assumed proceeds under the treasury stock method include unamortized compensation cost. See Note 14, "Earnings per Share," of the notes to consolidated financial statements for the calculation of earnings per share.

[0000833444-21-000046:notes:60]
Foreign Currency Translation

[0000833444-21-000046:notes:61]
Substantially all of the Company’s international operations use the respective local currency as the functional currency. Assets and liabilities of international entities have been translated at period-end exchange rates, and income and expenses have been translated using average exchange rates for the period. Monetary assets and liabilities denominated in non-functional currencies are adjusted to reflect period-end exchange rates. The aggregate transaction gains (losses), net of the impact of foreign currency hedges, included in income from continuing operations for the years ended September 30, 2021, 2020 and 2019 were $56 million, $(32) million and $(10) million, respectively.

[0000833444-21-000046:notes:62]
Derivative Financial Instruments

[0000833444-21-000046:notes:63]
The Company has written policies and procedures that place all financial instruments under the direction of Corporate treasury and restrict all derivative transactions to those intended for hedging purposes. The use of financial instruments for speculative purposes is strictly prohibited. The Company selectively uses financial instruments to manage the market risk from changes in foreign exchange rates, commodity prices, stock-based compensation liabilities and interest rates.

[0000833444-21-000046:notes:64]
The fair values of all derivatives are recorded in the consolidated statements of financial position. The change in a derivative’s fair value is recorded each period in current earnings or accumulated other comprehensive income ("AOCI"), depending on whether the derivative is designated as part of a hedge transaction and if so, the type of hedge transaction. See Note 11, "Derivative Instruments and Hedging Activities," and Note 12, "Fair Value Measurements," of the notes to consolidated financial statements for disclosure of the Company’s derivative instruments and hedging activities.

[0000833444-21-000046:notes:65]
Investments

[0000833444-21-000046:notes:66]
The Company invests in debt and equity securities which are marked to market at the end of each accounting period. Unrealized gains and losses on these securities are recognized in the Company's consolidated statements of income. The deferred compensation plan assets are marked to market at the end of each accounting period and all unrealized gains and losses are recorded in the consolidated statements of income.

[0000833444-21-000046:notes:67]
Pension and Postretirement Benefits

[0000833444-21-000046:notes:68]
The Company utilizes a mark-to-market approach for recognizing pension and postretirement benefit expenses, including measuring the market related value of plan assets at fair value and recognizing actuarial gains and losses in the fourth quarter of each fiscal year or at the date of a remeasurement event. Refer to Note 16, "Retirement Plans," of the notes to consolidated financial statements for disclosure of the Company's pension and postretirement benefit plans.

[0000833444-21-000046:notes:69]
Loss Contingencies

[0000833444-21-000046:notes:70]
Accruals are recorded for various contingencies including legal proceedings, environmental matters, self-insurance and other claims that arise in the normal course of business. The accruals are based on judgment, the probability of losses and, where applicable, the consideration of opinions of internal and/or external legal counsel and actuarially determined estimates. Additionally, the Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-21-000046:notes:71]
The Company is subject to laws and regulations relating to protecting the environment. The Company provides for expenses associated with environmental remediation obligations when such amounts are probable and can be reasonably estimated. Refer to Note 23, "Commitments and Contingencies," of the notes to consolidated financial statements.

[0000833444-21-000046:notes:72]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company records receivables from third party insurers when recovery has been determined to be probable. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-21-000046:notes:73]
Asbestos-Related Contingencies and Insurance Receivables

[0000833444-21-000046:notes:74]
The Company and certain of its subsidiaries along with numerous other companies are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-21-000046:notes:75]
In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable. The Company's estimate of asbestos-related insurance recoveries represents estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims discounted to present value. In determining the amount of insurance recoverable, the Company considers available insurance, allocation methodologies, solvency and creditworthiness of the insurers. Refer to Note 23, "Commitments and Contingencies," of the notes to consolidated financial statements for a discussion on management's judgments applied in the recognition and measurement of asbestos-related assets and liabilities.

[0000833444-21-000046:notes:76]
Income Taxes

[0000833444-21-000046:notes:77]
Deferred tax liabilities and assets are recognized for the expected future tax consequences of events that have been reflected in the consolidated financial statements. Deferred tax liabilities and assets are determined based on the differences between the book and tax basis of particular assets and liabilities and operating loss carryforwards, using tax rates in effect for the years in which the differences are expected to reverse. A valuation allowance is provided to reduce the carrying or book value of deferred tax assets if, based upon the available evidence, including consideration of tax planning strategies, it is more-likely-than-not that some or all of the deferred tax assets will not be realized. Refer to Note 19, "Income Taxes," of the notes to consolidated financial statements.

[0000833444-21-000046:notes:78]
Retrospective Changes

[0000833444-21-000046:notes:79]
Certain amounts as of September 30, 2020 and 2019 have been revised to conform to the current year's presentation.

[0000833444-21-000046:notes:80]
New Accounting Pronouncements

[0000833444-21-000046:notes:81]
Recently Adopted Accounting Pronouncements

[0000833444-21-000046:notes:82]
In June 2016, the FASB issued ASU No. 2016-13, "Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments." ASU No. 2016-13 and its related amendments replace the previous expected credit loss methodology with a new incurred loss methodology. The new standard applies to financial instruments, including, but not limited to, trade receivables. Under the new standard, companies must consider historical information, current conditions and a reasonable forecast period when estimating credit losses. The Company adopted ASU No. 2016-13 and the related amendments

[0000833444-21-000046:notes:83]
effective October 1, 2020. The adoption did not have a material impact on the Company's consolidated financial statements. Refer to Note 5, “Accounts Receivable, Net,” of the notes to the consolidated financial statements for further information.

[0000833444-21-000046:notes:84]
Recently Issued Accounting Pronouncements

[0000833444-21-000046:notes:85]
In October 2021, the FASB issued ASU No. 2021-08, “Business Combinations (Topic 805), Accounting for Contract Assets and Contract Liabilities from Contracts with Customers,” which requires contract assets and contract liabilities (e.g. deferred revenue) acquired in a business combination to be recognized and measured by the acquirer on the acquisition date in accordance with ASC 606, “Revenue from Contracts with Customers.” Generally, this new guidance will result in the acquirer recognizing contract assets and contract liabilities at the same amounts recorded by the acquiree. Historically, such amounts were recognized by the acquirer at fair value in acquisition accounting. The guidance should be applied prospectively to acquisitions occurring on or after the effective date. The guidance is effective for fiscal years beginning after December 15, 2022, including interim periods within those fiscal years (October 1, 2023 for the Company). Early adoption is permitted, including in interim periods, for any financial statements that have not yet been issued. The impact of the new standard will depend on the magnitude of future acquisitions.

[0000833444-21-000046:notes:86]
Other recently issued accounting pronouncements are not expected to have a material impact on the Company's consolidated financial statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-21-000046:notes:87]
ACQUISITIONS AND DIVESTITURES
Fiscal Year 2021

[0000833444-21-000046:notes:88]
Silent-Aire Acquisition

[0000833444-21-000046:notes:89]
In May 2021, the Company completed its acquisition of Silent-Aire, a global leader in hyperscale data center cooling and modular critical infrastructure solutions, for approximately $755 million, net of cash acquired, which is comprised of an upfront net cash payment of approximately $661 million, the estimated fair value of contingent earn-out liabilities of approximately $86 million and a working capital adjustment of $8 million. The contingent earn-out liabilities are based upon the achievement of certain defined operating results in each of the three years following the acquisition, with a maximum payout of approximately $250 million. The fair value of contingent earn-out liabilities is reassessed on a quarterly basis and could differ materially from the initial estimates. Subsequent changes in the estimated fair value of contingent earn-out liabilities will be recorded in the consolidated statements of income when incurred. The earn-out payments that are less than or equal to the contingent earn-out liabilities on the acquisition date are reflected as financing cash outflows and amounts paid in excess of the contingent earn-out liabilities on the acquisition date are reflected as operating cash outflows. The Silent-Aire business is reported within the Global Products segment.

[0000833444-21-000046:notes:90]
In connection with the acquisition, the Company recorded goodwill of $244 million in the Global Products segment. Goodwill is attributable primarily to expected synergies, expanded market opportunities and other benefits that the Company believes will result from combining its operations with the operations of Silent-Aire. The goodwill created in the acquisition is not deductible for tax purposes.

[0000833444-21-000046:notes:91]
The fair values of the assets acquired and liabilities assumed related to Silent-Aire are as follows (in millions):

[0000833444-21-000046:notes:92]
| Cash and cash equivalents |  | $ | 5 |  |
| Accounts receivable |  | 141 |  |
| Inventories |  | 60 |  |
| Other current assets |  | 4 |  |
| Property, plant, and equipment - net |  | 33 |  |
| Goodwill |  | 244 |  |
| Intangible assets - net |  | 497 |  |
| Other noncurrent assets |  | 84 |  |
| Total assets acquired |  | $ | 1,068 |  |
| Accounts payable |  | 62 |  |
| Accrued compensation and benefits |  | 6 |  |
| Deferred revenue |  | 32 |  |
| Other current liabilities |  | 12 |  |
| Other noncurrent liabilities |  | 196 |  |
| Total liabilities acquired |  | $ | 308 |  |
| Net assets acquired |  | $ | 760 |  |

[0000833444-21-000046:notes:93]
The purchase price allocation to identifiable intangible assets acquired related to Silent-Aire are as follows:

[0000833444-21-000046:notes:94]
|  |  | Fair Value (in millions) |  | Weighted Average Life (in years) |
| Customer relationships |  | $ | 291 |  |  | 19 |
| Technology |  | 116 |  |  | 13 |
| Other definite-lived intangibles |  | 23 |  |  | 1 |
| Indefinite-lived trademarks |  | 67 |  |  |  |
| Total identifiable intangible assets |  | $ | 497 |  |  |  |

[0000833444-21-000046:notes:95]
Other acquisitions and divestitures

[0000833444-21-000046:notes:96]
During fiscal 2021, the Company completed certain additional acquisitions for a combined purchase price, net of cash acquired, of $81 million, of which $64 million was paid as of September 30, 2021. In connection with these acquisitions and final purchase price allocation adjustments from fiscal 2020 acquisitions, the Company recorded goodwill of $35 million within the Building Solutions EMEA/LA segment and $21 million within the Building Solutions North America segment. The acquisitions were not material to the Company's consolidated financial statements.

[0000833444-21-000046:notes:97]
During fiscal 2021, the Company completed certain divestitures within the Buildings Solutions Asia Pacific segment. The combined selling price was $27 million, of which $19 million was received as of September 30, 2021. In connection with the divestitures, the Company reduced goodwill by $7 million.

[0000833444-21-000046:notes:98]
Fiscal Year 2020

[0000833444-21-000046:notes:99]
During fiscal 2020, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $82 million, of which $77 million was paid as of September 30, 2020. In connection with the acquisitions, the Company recorded goodwill of $35 million within the Building Solutions EMEA/LA segment and $21 million within the Global Products segment. The acquisitions were not material to the Company's consolidated financial statements.

[0000833444-21-000046:notes:100]
Additionally, in the fourth quarter of fiscal 2020, the Company acquired additional ownership interest in one of its consolidated subsidiaries within the Global Products segment for a purchase price of $132 million, all of which was paid as of September 30, 2020. In connection with this transaction, the Company recorded a compensation charge of $39 million related to the cash settlement of equity awards.

[0000833444-21-000046:notes:101]
In the fourth quarter of fiscal 2020, the Company completed certain divestitures within the Global Products and Building Solutions Asia Pacific segments. The combined selling price, net of cash divested, was $152 million, of which $135 million was received as of September 30, 2021. In connection with the divestitures, the Company reduced goodwill by $11 million within the Building Solutions Asia Pacific segment. The divestitures were not material to the Company's consolidated financial statements.

[0000833444-21-000046:notes:102]
Fiscal Year 2019

[0000833444-21-000046:notes:103]
On April 30, 2019, the Company completed the sale of its Power Solutions business to BCP Acquisitions LLC for a purchase price of $13.2 billion. The net cash proceeds after tax and transaction-related expenses were $11.6 billion. In connection with the sale, the Company recorded a gain, net of transaction and other costs, of $5.2 billion ($4.0 billion after tax), subject to post-closing working capital and net debt adjustments, within income from discontinued operations, net of tax, in the consolidated statements of income. Refer to Note 3, "Discontinued Operations," of the notes to consolidated financial statements for further disclosure related to the Company's discontinued operations.

[0000833444-21-000046:notes:104]
During fiscal 2019, the Company completed certain divestitures within the Global Products and Building Solutions EMEA/LA segments. The combined selling price was $18 million, $16 million of which was received as of September 30, 2019. In connection with the sale, the Company reduced goodwill by $1 million within the Building Solutions EMEA/LA segment. The divestitures were not material to the Company's consolidated financial statements. 
During fiscal 2019, the Company completed certain acquisitions for a combined purchase price of $32 million, $25 million of which was paid as of September 30, 2019. In connection with the acquisitions, the Company recorded goodwill of $11 million within the Global Products segment, $8 million within the Building Solutions Asia Pacific segment, and $6 million within the Building Solutions EMEA/LA segment. The acquisitions were not material to the Company's consolidated financial statements.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-21-000046:notes:105]
DISCONTINUED OPERATIONS
Power Solutions

[0000833444-21-000046:notes:106]
On April 30, 2019, the Company completed the sale of its Power Solutions business, which met the criteria to be classified as a discontinued operation, to BCP Acquisitions LLC for a purchase price of $13.2 billion. The net cash proceeds after tax and transaction-related expenses were $11.6 billion. In connection with the sale, the Company recorded a gain, net of transaction and other costs, of $5.2 billion ($4.0 billion after tax), subject to post-closing working capital and net debt adjustments, within income from discontinued operations, net of tax, in the consolidated statements of income. In December 2020, the favorable resolution of certain post-closing working capital and net debt adjustments resulted in income from discontinued operations, net of tax, of $124 million due to a reversal of a reserve established in connection with the sale of Power Solutions.

[0000833444-21-000046:notes:107]
The following table summarizes the results of Power Solutions which are classified as discontinued operations for the fiscal years ended September 30, 2021, 2020 and 2019 (in millions).

[0000833444-21-000046:notes:108]
|  |  |  | Year Ended September 30, |  |
|  |  |  | 2021 |  | 2020 |  | 2019 |  |  |  |
| Net sales |  |  | $ | — |  |  | $ | — |  |  | $ | 5,001 |  |  |  |  |
| Income from discontinued operations before income taxes |  |  | 150 |  |  | — |  | 6,039 |  |  |  |  |
| Provision for income taxes on discontinued operations |  |  | (26) |  |  | — |  | (1,441) |  |  |  |  |
| Income from discontinued operations attributable to noncontrolling interests, net of tax |  |  | — |  |  | — |  | (24) |  |  |  |  |
| Income from discontinued operations |  |  | $ | 124 |  |  | $ | — |  |  | $ | 4,574 |  |  |  |  |

[0000833444-21-000046:notes:109]
For the fiscal year ended September 30, 2019, income from discontinued operations before income taxes included a gain on sale of the Power Solutions business, net of transaction and other costs, of $5.2 billion and a favorable impact of $117 million for ceasing depreciation and amortization expense as the business was held for sale.

[0000833444-21-000046:notes:110]
For the fiscal year ended September 30, 2019, the effective tax rate was more than the Irish statutory rate of 12.5% primarily due to the tax impacts of the divestiture of the Power Solutions business and tax rate differentials. 
Assets and Liabilities Held for Sale During the third quarter of fiscal 2020, the Company determined that certain assets of the Building Solutions Asia Pacific segment met the criteria to be classified as held for sale. The estimated fair value, less costs to sell, of these assets was $156 million at September 30, 2021 and $147 million at September 30, 2020.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-21-000046:notes:111]
REVENUE RECOGNITION
Disaggregated Revenue

[0000833444-21-000046:notes:112]
The following table presents the Company's revenues disaggregated by segment and by products and systems versus services revenue for the years ended September 30, 2021 and 2020 (in millions):

[0000833444-21-000046:notes:113]
|  |  | Year Ended September 30, |
|  |  | 2021 |  | 2020 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 5,312 |  |  | $ | 3,373 |  |  | $ | 8,685 |  |  | $ | 5,371 |  |  | $ | 3,234 |  |  | $ | 8,605 |  |
| Building Solutions EMEA/LA |  | 1,772 |  |  | 1,955 |  |  | 3,727 |  |  | 1,644 |  |  | 1,796 |  |  | 3,440 |  |
| Building Solutions Asia Pacific |  | 1,516 |  |  | 1,138 |  |  | 2,654 |  |  | 1,369 |  |  | 1,034 |  |  | 2,403 |  |
| Global Products |  | 8,602 |  |  | — |  |  | 8,602 |  |  | 7,869 |  |  | — |  |  | 7,869 |  |
| Total |  | $ | 17,202 |  |  | $ | 6,466 |  |  | $ | 23,668 |  |  | $ | 16,253 |  |  | $ | 6,064 |  |  | $ | 22,317 |  |

[0000833444-21-000046:notes:114]
The following table presents further disaggregation of Global Products segment revenues by product type for the years ended September 30, 2021 and 2020 (in millions):

[0000833444-21-000046:notes:115]
|  |  | Year Ended September 30, |
|  |  | 2021 |  | 2020 |
| HVAC |  | $ | 6,173 |  |  | $ | 5,685 |  |
| Fire & Security |  | 2,192 |  |  | 1,957 |  |
| Industrial Refrigeration |  | 237 |  |  | 227 |  |
| Total |  | $ | 8,602 |  |  | $ | 7,869 |  |

[0000833444-21-000046:notes:116]
Contract Balances

[0000833444-21-000046:notes:117]
Contract assets relate to the Company’s right to consideration for performance obligations satisfied but not billed and consist of unbilled receivables and costs in excess of billings. Contract liabilities relate to customer payments received in advance of satisfaction of performance obligations under the contract. Contract liabilities consist of deferred revenue. Contract balances are classified as assets or liabilities on a contract-by-contract basis at the end of each reporting period.

[0000833444-21-000046:notes:118]
The following table presents the location and amount of contract balances in the Company's consolidated statements of financial position (in millions):

[0000833444-21-000046:notes:119]
|  |  |  |  | September 30, |  |  |
|  |  | Location of contract balances |  | 2021 |  | 2020 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,718 |  |  | $ | 1,395 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 99 |  |  | 104 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,637) |  |  | (1,435) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (269) |  |  | (245) |  |  |  |
| Total |  |  |  | $ | (89) |  |  | $ | (181) |  |  |  |

[0000833444-21-000046:notes:120]
For the year ended September 30, 2021, the Company recognized revenue of approximately $1.2 billion that was included in the beginning of period contract liability balance. For the year ended September 30, 2020, the Company recognized revenue of approximately $1.3 billion that was included in the beginning of period contract liability balance.

[0000833444-21-000046:notes:121]
Performance Obligations

[0000833444-21-000046:notes:122]
A performance obligation is a distinct good, service, or bundle of goods and services promised in a contract. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When contracts with customers require significant and complex integration, contain goods or services which are highly interdependent or interrelated, or are goods or services which significantly modify or customize other promises in the contracts and, therefore, are not distinct, then the entire contract is accounted for as a single performance obligation. For any contracts with multiple performance obligations, the contract’s transaction price is allocated to each performance obligation based on the estimated relative standalone selling price of each distinct good or service in the contract. For product sales, each product sold to a customer typically represents a distinct performance obligation.

[0000833444-21-000046:notes:123]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of September 30, 2021, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $16.1 billion, of which approximately 60% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with average initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

[0000833444-21-000046:notes:124]
Costs to Obtain or Fulfill a Contract

[0000833444-21-000046:notes:125]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when these costs are recoverable. These costs consist primarily of sales commissions and bid/proposal costs. Costs to obtain or fulfill a contract are capitalized and amortized to revenue over the period of contract performance.

[0000833444-21-000046:notes:126]
The following table presents the location and amount of costs to obtain or fulfill a contract recorded in the Company's consolidated statements of financial position (in millions):

[0000833444-21-000046:notes:127]
|  |  | September 30, |  |  |
|  |  | 2021 |  | 2020 |  |  |
| Other current assets |  | $ | 149 |  |  | $ | 119 |  |  |  |
| Other noncurrent assets |  | 117 |  |  | 104 |  |  |  |
| Total |  | $ | 266 |  |  | $ | 223 |  |  |  |

[0000833444-21-000046:notes:128]
During the year ended September 30, 2021, the Company recognized amortization of $173 million related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the year ended September 30, 2021. During the year ended September 30, 2020, the Company recognized amortization of $162 million related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the year ended September 30, 2020.


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0000833444-21-000046:notes:129]
ACCOUNTS RECEIVABLEReceivables consist of amounts billed and currently due from customers and unbilled costs and accrued profits related to revenues on long-term contracts that have been recognized for accounting purposes but not yet billed to customers. The Company extends credit to customers in the normal course of business and maintains an allowance for expected credit losses resulting from the inability or unwillingness of customers to make required payments. The allowance for expected credit losses is based on historical experience, existing economic conditions, reasonable and supportable forecasts, and any specific customer collection issues the Company has identified. The Company evaluates the reasonableness of the allowance for credit losses on a quarterly basis. The Company enters into various factoring agreements to sell certain accounts receivable to third-party financial institutions. For ease of administration, the Company collects customer payments related to certain factored receivables on behalf of the financial institutions but otherwise maintains no other continuing involvement with respect to the factored receivables. During the year ended September 30, 2021, the Company sold $129 million of accounts receivable under such factoring agreements, and the costs of factoring such receivables were not material. As of September 30, 2021, the outstanding amount of accounts receivable sold under the factoring agreements was $127 million. No receivables were factored under such agreements in fiscal 2020. Sales of accounts receivable are reflected as a reduction of accounts receivable in the 
consolidated statements of financial position and the proceeds are included in cash flows from operating activities in the consolidated statements of cash flows.

[0000833444-21-000046:notes:130]
Accounts receivable, net consisted of the following (in millions):

[0000833444-21-000046:notes:131]
|  |  | September 30, |  |  |
|  |  | 2021 |  | 2020 |  |  |
| Accounts receivable |  | $ | 5,723 |  |  | $ | 5,467 |  |  |  |
| Less: Allowance for expected credit losses (1) |  | (110) |  |  | (173) |  |  |  |
| Accounts receivable, net |  | $ | 5,613 |  |  | $ | 5,294 |  |  |  |

[0000833444-21-000046:notes:132]
(1) Allowance for doubtful accounts as of September 30, 2020, prior to the adoption of ASU 2016-13.

[0000833444-21-000046:notes:133]
The changes in the allowance for expected credit losses related to accounts receivable for the year ended September 30, 2021 were as follows (in millions):

[0000833444-21-000046:notes:134]
|  |  | Year Ended September 30, 2021 |
| Balance as of September 30, 2020 |  | $ | 173 |  |  |
| Provision for expected credit losses |  | (3) |  |  |
| Write-offs charged against the allowance for expected credit losses |  | (65) |  |  |
| Currency translation |  | 1 |  |  |
| Other (including impact of adoption of ASU 2016-13) |  | 4 |  |  |
| Balance as of September 30, 2021 |  | $ | 110 |  |  |


## us-gaap:InventoryDisclosureTextBlock

[0000833444-21-000046:notes:135]
INVENTORIES
Inventories consisted of the following (in millions):

[0000833444-21-000046:notes:136]
|  | September 30, |
|  | 2021 |  | 2020 |
| Raw materials and supplies | $ | 769 |  |  | $ | 629 |  |
| Work-in-process | 166 |  |  | 142 |  |
| Finished goods | 1,122 |  |  | 1,002 |  |
| Inventories | $ | 2,057 |  |  | $ | 1,773 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000833444-21-000046:notes:137]
PROPERTY, PLANT AND EQUIPMENT
Property, plant and equipment consisted of the following (in millions):

[0000833444-21-000046:notes:138]
|  | September 30, |
|  | 2021 |  | 2020 |
| Buildings and improvements | $ | 1,313 |  |  | $ | 1,351 |  |
| Subscriber systems | 802 |  |  | 679 |  |
| Machinery and equipment | 3,669 |  |  | 3,332 |  |
| Construction in progress | 500 |  |  | 327 |  |
| Land | 231 |  |  | 241 |  |
| Total property, plant and equipment | 6,515 |  |  | 5,930 |  |
| Less: Accumulated depreciation | (3,287) |  |  | (2,871) |  |
| Property, plant and equipment - net | $ | 3,228 |  |  | $ | 3,059 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-21-000046:notes:139]
GOODWILL AND OTHER INTANGIBLE ASSETS
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the fiscal years ended September 30, 2021 and 2020 were as follows (in millions):

[0000833444-21-000046:notes:140]
|  | September 30, 2019 |  | BusinessAcquisitions |  | BusinessDivestitures |  | Impairments |  | Currency Translation and Other |  | September 30, 2020 |
| Building Solutions North America | $ | 9,588 |  |  | $ | — |  |  | $ | — |  |  | $ | (424) |  |  | $ | (4) |  |  | $ | 9,160 |  |
| Building Solutions EMEA/LA | 1,849 |  |  | 35 |  |  | — |  |  | — |  |  | 83 |  |  | 1,967 |  |
| Building Solutions Asia Pacific | 1,194 |  |  | — |  |  | (11) |  |  | — |  |  | 43 |  |  | 1,226 |  |
| Global Products | 5,547 |  |  | 21 |  |  | — |  |  | — |  |  | 11 |  |  | 5,579 |  |
| Total | $ | 18,178 |  |  | $ | 56 |  |  | $ | (11) |  |  | $ | (424) |  |  | $ | 133 |  |  | $ | 17,932 |  |
|  | September 30, 2020 |  | BusinessAcquisitions |  | BusinessDivestitures |  | Impairments |  | Currency Translation and Other |  | September 30, 2021 |
| Building Solutions North America | $ | 9,160 |  |  | $ | 21 |  |  | $ | — |  |  | $ | — |  |  | $ | 34 |  |  | $ | 9,215 |  |
| Building Solutions EMEA/LA | 1,967 |  |  | 35 |  |  | — |  |  | — |  |  | 19 |  |  | 2,021 |  |
| Building Solutions Asia Pacific | 1,226 |  |  | — |  |  | (7) |  |  | — |  |  | 21 |  |  | 1,240 |  |
| Global Products | 5,579 |  |  | 244 |  |  | — |  |  | — |  |  | 36 |  |  | 5,859 |  |
| Total | $ | 17,932 |  |  | $ | 300 |  |  | $ | (7) |  |  | $ | — |  |  | $ | 110 |  |  | $ | 18,335 |  |

[0000833444-21-000046:notes:141]
At September 30, 2019, accumulated goodwill impairment charges included $47 million related to the Building Solutions EMEA/LA - Latin America reporting unit.

[0000833444-21-000046:notes:142]
The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. There were no goodwill impairments resulting from the fiscal 2021 and 2020 annual impairment tests.  No reporting unit was determined to be at risk of failing the goodwill impairment test as of September 30, 2021.

[0000833444-21-000046:notes:143]
During fiscal 2020, the Company considered the deterioration in general economic and market conditions due to the COVID-19 pandemic and its impact on each of the Company’s reporting units’ performance. Due to declines in cash flow projections of the North America Retail reporting unit in the third quarter of fiscal 2020 as a result of the COVID-19 pandemic, the Company concluded a triggering event occurred requiring assessment of impairment for its North America Retail reporting unit. As a result, the Company recorded a non-cash impairment charge of $424 million within restructuring and impairment costs in the consolidated statements of income in the third quarter of fiscal 2020, which was determined by comparing the carrying amount of a reporting unit to its fair value in accordance with ASU No. 2017-04, "Intangible - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment," which the Company early adopted. The North America Retail reporting unit has a remaining goodwill balance of $235 million at September 30, 2021. The Company used a discounted cash flow model to estimate the fair value of the reporting unit. Other than management's internal projections of future cash flows, the primary assumptions used in the model were the weighted-average cost of capital and long-term growth rates, which are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." Although the Company's cash flow forecasts are based on assumptions that are considered reasonable by management and consistent with the plans and estimates management is using to operate the underlying business, there was significant judgment in determining the expected future cash flows attributable to the North America Retail reporting unit.

[0000833444-21-000046:notes:144]
The Company’s other intangible assets, primarily from business acquisitions valued based on independent appraisals, consisted of (in millions):

[0000833444-21-000046:notes:145]
|  | September 30, 2021 |  | September 30, 2020 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Definite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,464 |  |  | $ | (629) |  |  | $ | 835 |  |  | $ | 1,332 |  |  | $ | (497) |  |  | $ | 835 |  |
| Customer relationships | 3,097 |  |  | (1,191) |  |  | 1,906 |  |  | 2,773 |  |  | (969) |  |  | 1,804 |  |
| Miscellaneous | 750 |  |  | (354) |  |  | 396 |  |  | 657 |  |  | (268) |  |  | 389 |  |
|  | 5,311 |  |  | (2,174) |  |  | 3,137 |  |  | 4,762 |  |  | (1,734) |  |  | 3,028 |  |
| Indefinite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/tradenames | 2,332 |  |  | — |  |  | 2,332 |  |  | 2,248 |  |  | — |  |  | 2,248 |  |
| Miscellaneous | 80 |  |  | — |  |  | 80 |  |  | 80 |  |  | — |  |  | 80 |  |
|  | 2,412 |  |  | — |  |  | 2,412 |  |  | 2,328 |  |  | — |  |  | 2,328 |  |
| Total intangible assets | $ | 7,723 |  |  | $ | (2,174) |  |  | $ | 5,549 |  |  | $ | 7,090 |  |  | $ | (1,734) |  |  | $ | 5,356 |  |

[0000833444-21-000046:notes:146]
The Company reviews indefinite-lived intangible assets for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. Indefinite-lived intangible assets primarily consist of trademarks and tradenames and are tested for impairment using a relief-from-royalty method.

[0000833444-21-000046:notes:147]
There were no indefinite-lived intangible asset impairments resulting from fiscal 2021 and 2020 annual impairment tests. For fiscal 2021, the estimated fair values of all indefinite-lived intangibles substantially exceeded their carrying values, with the exception of the indefinite-lived trademarks related to the Company's Asia Pacific subscriber businesses. The estimated fair value for the Asia Pacific indefinite-lived trademark was consistent with its carrying value of $38 million.

[0000833444-21-000046:notes:148]
During the second and third quarters of fiscal 2020, the Company determined that it had a triggering event at each reporting period end requiring assessment of impairment for certain of its indefinite-lived intangible assets due to declines in revenue directly attributable to the COVID-19 pandemic. As a result, the Company recorded an impairment charge of $62 million related primarily to the Company's retail business indefinite-lived intangible assets within restructuring and impairment costs in the consolidated statements of income in the second quarter of fiscal 2020. No further impairment was required to be recorded in the third quarter of fiscal 2020 as a result of the completed impairment assessment. 
Amortization of other intangible assets included within continuing operations for the fiscal years ended September 30, 2021, 2020 and 2019 was $435 million, $386 million and $377 million, respectively. Excluding the impact of any future acquisitions, the Company anticipates amortization for fiscal 2022, 2023, 2024, 2025 and 2026 will be approximately $457 million, $439 million, $424 million, $403 million and $335 million, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000833444-21-000046:notes:149]
LEASES
The Company adopted ASU 2016-02, "Leases (Topic 842)" and the related amendments using a modified-retrospective approach as of October 1, 2019.

[0000833444-21-000046:notes:150]
Most leases contain options to renew or terminate the lease. Right-of-use assets and lease liabilities reflect only the options which the Company is reasonably certain to exercise. Lease expense is recognized on a straight-line basis over the lease term.

[0000833444-21-000046:notes:151]
The Company has certain real estate leases that contain variable lease payments which are based on changes in the Consumer Price Index (CPI). Additionally, the Company’s leases generally require it to pay for fuel, maintenance, repair, insurance and taxes. These payments are not included in the right-of-use asset or lease liability and are expensed as incurred.

[0000833444-21-000046:notes:152]
The following table presents the Company’s lease costs for the fiscal years ended September 30, 2021 and 2020 (in millions):

[0000833444-21-000046:notes:153]
|  |  | Year Ended September 30, |  |
|  |  | 2021 |  | 2020 |  |
| Operating lease cost |  | $ | 384 |  |  | $ | 399 |  |  |
| Variable lease cost |  | 130 |  |  | 145 |  |  |
| Total lease costs |  | $ | 514 |  |  | $ | 544 |  |  |

[0000833444-21-000046:notes:154]
Total rental expense for continuing operations for the fiscal year ended September 30, 2019 was $452 million.

[0000833444-21-000046:notes:155]
The following table presents supplemental consolidated statement of financial position information as of September 30, 2021 and 2020 (in millions):

[0000833444-21-000046:notes:156]
|  |  |  | September 30, |
|  | Location of lease balances |  | 2021 |  | 2020 |
| Operating lease right-of-use assets | Other noncurrent assets |  | $ | 1,376 |  |  | $ | 1,190 |  |
| Operating lease liabilities - current | Other current liabilities |  | 319 |  |  | 332 |  |
| Operating lease liabilities - noncurrent | Other noncurrent liabilities |  | 1,055 |  |  | 875 |  |
| Weighted-average remaining lease term |  |  | 7 years |  | 6 years |
| Weighted-average discount rate |  |  | 1.8 | % |  | 2.2 | % |

[0000833444-21-000046:notes:157]
The following table presents supplemental cash flow information related to operating leases for the fiscal years ended September 30, 2021 and 2020 (in millions):

[0000833444-21-000046:notes:158]
|  |  | Year Ended September 30, |  |
|  |  | 2021 |  | 2020 |  |
| Cash paid for amounts included in the measurement of lease liability: |  |  |  |  |  |
| Operating cash outflows from operating leases |  | $ | 398 |  |  | $ | 397 |  |  |
| Noncash operating lease activity: |  |  |  |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  | 515 |  |  | 467 |  |  |

[0000833444-21-000046:notes:159]
The following table presents maturities of operating lease liabilities as of September 30, 2021 (in millions):

[0000833444-21-000046:notes:160]
|  |  | September 30, 2021 |
| 2022 |  | $ | 337 |  |
| 2023 |  | 275 |  |
| 2024 |  | 226 |  |
| 2025 |  | 164 |  |
| 2026 |  | 115 |  |
| After 2026 |  | 353 |  |
| Total operating lease payments |  | 1,470 |  |
| Less: Interest |  | (96) |  |
| Present value of lease payments |  | $ | 1,374 |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-21-000046:notes:161]
DEBT AND FINANCING ARRANGEMENTS
Short-term debt consisted of the following (in millions):

[0000833444-21-000046:notes:162]
|  | September 30, |
|  | 2021 |  | 2020 |
| Bank borrowings | $ | 8 |  |  | $ | 31 |  |
| Weighted average interest rate on short-term debt outstanding | 0.2 | % |  | 3.4 | % |

[0000833444-21-000046:notes:163]
The Company had no commercial paper outstanding as of September 30, 2021 and 2020.

[0000833444-21-000046:notes:164]
As of September 30, 2021, the Company has a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2021. As of September 30, 2021, there were no draws on the facilities.

[0000833444-21-000046:notes:165]
Long-term debt consisted of the following (in millions; due dates by fiscal year):

[0000833444-21-000046:notes:166]
|  | September 30, |
|  | 2021 |  | 2020 |
| Unsecured notes |  |  |  |
| JCI plc - 4.25% due in 2021 ($204 million par value) | $ | — |  |  | $ | 204 |  |
| JCI Inc. - 4.25% due in 2021 ($53 million par value) | — |  |  | 53 |  |
| JCI plc - 3.75% due in 2022 ($171 million par value) | — |  |  | 171 |  |
| JCI Inc. - 3.75% due in 2022 ($22 million par value) | — |  |  | 22 |  |
| JCI plc - 4.625% due in 2023 ($25 million par value) | 25 |  |  | 26 |  |
| Tyco International Finance S.A. ("TIFSA") - 4.625% due in 2023 ($7 million par value) | 7 |  |  | 7 |  |
| JCI plc - 1.00% due in 2023 (€846 million par value) | 980 |  |  | 1,039 |  |
| JCI plc - 3.625% due in 2024 ($453 million par value) | 453 |  |  | 453 |  |
| JCI Inc. - 3.625% due in 2024 ($31 million par value) | 31 |  |  | 31 |  |
| JCI plc - 1.375% due in 2025 (€423 million par value) | 496 |  |  | 503 |  |
| TIFSA - 1.375% due in 2025 (€54 million par value) | 63 |  |  | 64 |  |
| JCI plc - 3.90% due in 2026 ($487 million par value) | 510 |  |  | 516 |  |
| TIFSA - 3.90% due in 2026 ($51 million par value) | 51 |  |  | 51 |  |
| JCI plc and Tyco Fire & Security Finance S.C.A. ("TFSCA") - 0.375% due in 2027 (€500 million par value) | 577 |  |  | 583 |  |
| JCI plc and TFSCA - 1.75% due in 2030 ($625 million par value) | 623 |  |  | 623 |  |
| JCI plc and TFSCA - 2.00% due in 2031 ($500 million par value) | 496 |  |  | — |  |
| JCI plc and TFSCA - 1.00% due in 2032 (€500 million par value) | 578 |  |  | 584 |  |
| JCI plc - 6.00% due in 2036 ($342 million par value) | 339 |  |  | 339 |  |
| JCI Inc. - 6.00% due in 2036 ($8 million par value) | 8 |  |  | 8 |  |
| JCI plc - 5.70% due in 2041 ($190 million par value) | 189 |  |  | 189 |  |
| JCI Inc. - 5.70% due in 2041 ($30 million par value) | 30 |  |  | 30 |  |
| JCI plc - 5.25% due in 2042 ($155 million par value) | 155 |  |  | 155 |  |
| JCI Inc. - 5.25% due in 2042 ($6 million par value) | 6 |  |  | 6 |  |
| JCI plc - 4.625% due in 2044 ($444 million par value) | 441 |  |  | 441 |  |
| JCI Inc. - 4.625% due in 2044 ($6 million par value) | 6 |  |  | 6 |  |
| JCI plc - 5.125% due in 2045 ($477 million par value) | 560 |  |  | 564 |  |
| TIFSA - 5.125% due in 2045 ($23 million par value) | 22 |  |  | 22 |  |
| JCI plc - 6.95% due in 2046 ($32 million par value) | 32 |  |  | 32 |  |
| JCI Inc. - 6.95% due in 2046 ($4 million par value) | 4 |  |  | 4 |  |
| JCI plc - 4.50% due in 2047 ($500 million par value) | 496 |  |  | 496 |  |
| JCI plc - 4.95% due in 2064 ($341 million par value) | 340 |  |  | 340 |  |
| JCI Inc. - 4.95% due in 2064 ($15 million par value) | 15 |  |  | 15 |  |
| JCI plc - Term Loan - ¥25 billion; LIBOR JPY plus 0.40% due in 2022 | 223 |  |  | 237 |  |
| Other | 8 |  |  | 8 |  |
| Gross long-term debt | 7,764 |  |  | 7,822 |  |
| Less: current portion | 226 |  |  | 262 |  |
| Less: debt issuance costs | 32 |  |  | 34 |  |
| Net long-term debt | $ | 7,506 |  |  | $ | 7,526 |  |

[0000833444-21-000046:notes:167]
The following table presents maturities of long-term debt as of September 30, 2021 (in millions):

[0000833444-21-000046:notes:168]
| 2022 |  | $ | 226 |  |
| 2023 |  | 1,012 |  |
| 2024 |  | 484 |  |
| 2025 |  | 559 |  |
| 2026 |  | 561 |  |
| After 2026 |  | 4,922 |  |
| Total |  | $ | 7,764 |  |

[0000833444-21-000046:notes:169]
The Company’s long-term debt includes various financial covenants, none of which are expected to restrict future operations.

[0000833444-21-000046:notes:170]
Total interest paid on both short and long-term debt for continuing operations for the fiscal years ended September 30, 2021, 2020 and 2019 was $242 million, $247 million and $369 million, respectively.

[0000833444-21-000046:notes:171]
Financing Arrangements

[0000833444-21-000046:notes:172]
In September 2021, the Company and its wholly owned subsidiary, TFSCA issued $500 million of sustainability-linked bonds with an initial interest rate of 2.0%, which are due in 2031. Beginning in March 2026, the interest rate payable on the note will be increased by an additional 12.5 basis points per annum if the Scope 1 and Scope 2 emissions sustainability performance target is not met and an additional 12.5 basis points per annum if the Scope 3 emissions sustainability performance target is not met. The proceeds were used for general corporate purposes, including the repayment of near-term indebtedness.

[0000833444-21-000046:notes:173]
In September 2021, the Company repaid $193 million of 3.75% notes which were due in December 2021, and a €200 million bank term loan which was issued in March 2021 and due in March 2022.

[0000833444-21-000046:notes:174]
The Company repaid $257 million in principal amount, plus accrued interest, of 4.25% fixed rate notes when they expired in March 2021.

[0000833444-21-000046:notes:175]
Additionally, during fiscal year 2021, the Company repaid €43 million in principal amount, plus accrued interest, of 1.0% fixed rate notes which were due in September 2023.

[0000833444-21-000046:notes:176]
Net Financing Charges

[0000833444-21-000046:notes:177]
The Company's net financing charges line item in the consolidated statements of income for the years ended September 30, 2021, 2020 and 2019 contained the following components (in millions):

[0000833444-21-000046:notes:178]
|  | Year Ended September 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Interest expense, net of capitalized interest costs | $ | 219 |  |  | $ | 240 |  |  | $ | 335 |  |
| Banking and other fees and amortization of bond costs, premiums and discounts | 25 |  |  | 26 |  |  | 28 |  |
| Loss on debt extinguishment | — |  |  | — |  |  | 60 |  |
| Interest income | (9) |  |  | (23) |  |  | (61) |  |
| Net foreign exchange results for financing activities | (29) |  |  | (12) |  |  | (12) |  |
| Net financing charges | $ | 206 |  |  | $ | 231 |  |  | $ | 350 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-21-000046:notes:179]
DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIESThe Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities, stock-based compensation liabilities and interest rates. Under Company policy, the use of derivatives is restricted to those intended for hedging purposes; the use of any derivative instrument for speculative purposes is strictly prohibited. A description of each type of derivative utilized by the Company to manage risk is included in the following paragraphs. In addition, refer to Note 12, "Fair Value Measurements," of the notes to consolidated financial statements for information related to the fair value measurements and valuation methods utilized by the Company for each derivative type.
Cash Flow Hedges

[0000833444-21-000046:notes:180]
The Company has global operations and participates in foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange hedge contracts. The Company hedges 70% to 90% of the notional amount of each of its known foreign exchange transactional exposures.

[0000833444-21-000046:notes:181]
The Company selectively hedges anticipated transactions that are subject to commodity price risk, primarily using commodity hedge contracts, to minimize overall price risk associated with the Company’s purchases of copper and aluminum in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities.

[0000833444-21-000046:notes:182]
As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the fiscal years ended September 30, 2021 and 2020.

[0000833444-21-000046:notes:183]
The Company had the following outstanding contracts to hedge forecasted commodity purchases (in metric tons):

[0000833444-21-000046:notes:184]
|  |  | Volume Outstanding as of |
| Commodity |  | September 30, 2021 |  | September 30, 2020 |
| Copper |  | 2,656 |  |  | 2,497 |  |
| Aluminum |  | 5,159 |  |  | 3,036 |  |

[0000833444-21-000046:notes:185]
In April 2021, the Company entered into two forward-starting interest rate swaps with a combined notional amount of $500 million, in conjunction with its anticipated $500 million note issuance. In September 2021, the Company terminated the swaps as the debt was issued. The fair value of each interest rate swap, which is the difference between the swap's reference rate and the fixed rate of the note issuance, will be amortized to interest expense over the life of the respective note issuance.

[0000833444-21-000046:notes:186]
Net Investment Hedges

[0000833444-21-000046:notes:187]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company’s net investments globally. At September 30, 2021, the Company had 2.3 billion of euro-denominated bonds designated as net investment hedges in Europe and 25 billion of yen-denominated debt designated as a net investment hedge in Japan. At September 30, 2020, the Company had 2.4 billion of euro-denominated bonds designated as net investment hedges in Europe and 25 billion of yen-denominated debt designated as a net investment hedge in Japan.

[0000833444-21-000046:notes:188]
Derivatives Not Designated as Hedging Instruments

[0000833444-21-000046:notes:189]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount. The Company hedged approximately 0.3 million of its ordinary shares, which have a cost basis of $23 million, as of September 30, 2021 and  approximately 1.4 million ordinary shares, which had a cost basis of $60 million, as of September 30, 2020.

[0000833444-21-000046:notes:190]
The Company also holds certain foreign currency forward contracts for which hedge accounting treatment was not elected. The change in fair value of foreign currency exchange derivatives not designated as hedging instruments under ASC 815 are recorded in the consolidated statements of income.

[0000833444-21-000046:notes:191]
Fair Value of Derivative Instruments

[0000833444-21-000046:notes:192]
The following table presents the location and fair values of derivative instruments and hedging activities included in the Company’s consolidated statements of financial position (in millions):

[0000833444-21-000046:notes:193]
|  | Derivatives and Hedging ActivitiesDesignated as Hedging Instrumentsunder ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instrumentsunder ASC 815 |
|  | September 30, 2021 |  | September 30, 2020 |  | September 30, 2021 |  | September 30, 2020 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 15 |  |  | $ | 10 |  |  | $ | 17 |  |  | $ | 17 |  |
| Commodity derivatives | 2 |  |  | 2 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Equity swap | — |  |  | — |  |  | 23 |  |  | 58 |  |
| Total assets | $ | 17 |  |  | $ | 12 |  |  | $ | 40 |  |  | $ | 75 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 11 |  |  | $ | 10 |  |  | $ | 6 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 2,918 |  |  | 3,010 |  |  | — |  |  | — |  |
| Total liabilities | $ | 2,930 |  |  | $ | 3,020 |  |  | $ | 6 |  |  | $ | — |  |

[0000833444-21-000046:notes:194]
Counterparty Credit Risk

[0000833444-21-000046:notes:195]
The use of derivative financial instruments exposes the Company to counterparty credit risk. The Company has established policies and procedures to limit the potential for counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association ("ISDA") master netting agreements with substantially all of its counterparties. The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position.

[0000833444-21-000046:notes:196]
The Company's derivative contracts do not contain any credit risk related contingent features and do not require collateral or other security to be furnished by the Company or the counterparties. The Company's exposure to credit risk associated with its derivative instruments is measured on an individual counterparty basis, as well as by groups of counterparties that share similar attributes. The Company does not anticipate any non-performance by any of its counterparties, and the concentration of risk with financial institutions does not present significant credit risk to the Company.

[0000833444-21-000046:notes:197]
The gross and net amounts of derivative assets and liabilities were as follows (in millions):

[0000833444-21-000046:notes:198]
|  | Fair Value of Assets |  | Fair Value of Liabilities |
|  | September 30, 2021 |  | September 30, 2020 |  | September 30, 2021 |  | September 30, 2020 |  |
| Gross amount recognized | $ | 57 |  |  | $ | 87 |  |  | $ | 2,936 |  |  | $ | 3,020 |  |  |
| Gross amount eligible for offsetting | (16) |  |  | (10) |  |  | (16) |  |  | (10) |  |  |
| Net amount | $ | 41 |  |  | $ | 77 |  |  | $ | 2,920 |  |  | $ | 3,010 |  |  |

[0000833444-21-000046:notes:199]
Derivatives Impact on the Statements of Income and Statements of Comprehensive Income

[0000833444-21-000046:notes:200]
The following table presents the pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges for the fiscal years ended September 30, 2021, 2020 and 2019 (in millions):

[0000833444-21-000046:notes:201]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Year Ended September 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Foreign currency exchange derivatives |  | $ | 15 |  |  | $ | 1 |  |  | $ | 2 |  |
| Commodity derivatives |  | 4 |  |  | 6 |  |  | (4) |  |
| Interest rate swap |  | (21) |  |  | — |  |  | — |  |
| Total |  | $ | (2) |  |  | $ | 7 |  |  | $ | (2) |  |

[0000833444-21-000046:notes:202]
The following table presents the location and amount of the pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income for the fiscal years ended September 30, 2021, 2020 and 2019 (in millions):

[0000833444-21-000046:notes:203]
| Derivatives in ASC 815 Cash FlowHedging Relationships |  | Location of Gain (Loss)Reclassified from AOCI into Income |  | Year Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 11 |  |  | $ | (5) |  |  | $ | 4 |  |
| Commodity derivatives |  | Cost of sales |  | 3 |  |  | 2 |  |  | (4) |  |
| Commodity derivatives |  | Income from discontinued operations |  | — |  |  | — |  |  | (10) |  |
| Total |  |  |  | $ | 14 |  |  | $ | (3) |  |  | $ | (10) |  |

[0000833444-21-000046:notes:204]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income for the fiscal years ended September 30, 2021, 2020 and 2019 (in millions):

[0000833444-21-000046:notes:205]
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Year Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (6) |  |  | $ | (1) |  |  | $ | (8) |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | 174 |  |  | 87 |  |  | (60) |  |
| Foreign currency exchange derivatives |  | Selling, general and administrative |  | (2) |  |  | — |  |  | — |  |
| Foreign currency exchange derivatives |  | Income tax provision |  | (1) |  |  | — |  |  | (1) |  |
| Foreign currency exchange derivatives |  | Income from discontinued operations |  | — |  |  | — |  |  | 52 |  |
| Equity swap |  | Selling, general and administrative |  | 28 |  |  | (4) |  |  | 14 |  |
| Total |  |  |  | $ | 193 |  |  | $ | 82 |  |  | $ | (3) |  |

[0000833444-21-000046:notes:206]
The pre-tax gains (losses) recorded in foreign currency translation adjustment ("CTA") within other comprehensive income (loss) related to net investment hedges were $42 million, $(172) million and $145 million for the years ended September 30, 2021, 2020 and 2019, respectively. For the years ended September 30, 2021, 2020 and 2019, no gains or losses were reclassified from CTA into income for the Company’s outstanding net investment hedges.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-21-000046:notes:207]
FAIR VALUE MEASUREMENTS
ASC 820, "Fair Value Measurement," defines fair value as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. ASC 820 also establishes a three-level fair value hierarchy that prioritizes information used in developing assumptions when pricing an asset or liability as follows:

[0000833444-21-000046:notes:208]
Level 1: Observable inputs such as quoted prices in active markets for identical assets or liabilities;

[0000833444-21-000046:notes:209]
Level 2: Quoted prices in active markets for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active, or inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and

[0000833444-21-000046:notes:210]
Level 3: Unobservable inputs where there is little or no market data, which requires the reporting entity to develop its own assumptions.

[0000833444-21-000046:notes:211]
ASC 820 requires the use of observable market data, when available, in making fair value measurements. When inputs used to measure fair value fall within different levels of the hierarchy, the level within which the fair value measurement is categorized is based on the lowest level input that is significant to the fair value measurement.

[0000833444-21-000046:notes:212]
Recurring Fair Value Measurements

[0000833444-21-000046:notes:213]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value as of September 30, 2021 and 2020 (in millions):

[0000833444-21-000046:notes:214]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2021 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 32 |  |  | $ | — |  |  | $ | 32 |  |  | $ | — |  |
| Commodity derivatives | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 63 |  |  | 63 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 146 |  |  | 146 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 168 |  |  | 168 |  |  | — |  |  | — |  |
| Equity swap | 23 |  |  | — |  |  | 23 |  |  | — |  |
| Total assets | $ | 434 |  |  | $ | 377 |  |  | $ | 57 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 17 |  |  | $ | — |  |  | $ | 17 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Contingent earn-out liabilities | 32 |  |  | — |  |  | $ | — |  |  | 32 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 50 |  |  | — |  |  | — |  |  | 50 |  |
| Total liabilities | $ | 100 |  |  | $ | — |  |  | $ | 18 |  |  | $ | 82 |  |

[0000833444-21-000046:notes:215]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2020 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 27 |  |  | $ | — |  |  | $ | 27 |  |  | $ | — |  |
| Exchange traded funds (fixed income)1 | 19 |  |  | 19 |  |  | — |  |  | — |  |
| Commodity derivatives | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 63 |  |  | 63 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 143 |  |  | 143 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 129 |  |  | 129 |  |  | — |  |  | — |  |
| Equity swap | 58 |  |  | — |  |  | 58 |  |  | — |  |
| Total assets | $ | 441 |  |  | $ | 354 |  |  | $ | 87 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |
| Total liabilities | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |

[0000833444-21-000046:notes:216]
1Classified as restricted investments for payment of asbestos liabilities. See Note 23, "Commitments and Contingencies" of the notes to consolidated financial statements for further details.

[0000833444-21-000046:notes:217]
Valuation Methods

[0000833444-21-000046:notes:218]
Foreign currency exchange derivatives: The foreign currency exchange derivatives are valued under a market approach using publicized spot and forward prices.

[0000833444-21-000046:notes:219]
Commodity derivatives: The commodity derivatives are valued under a market approach using publicized prices, where available, or dealer quotes.

[0000833444-21-000046:notes:220]
Equity swaps: The equity swaps are valued under a market approach as the fair value of the swaps is equal to the Company’s stock price at the reporting period date.

[0000833444-21-000046:notes:221]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices. Unrealized gains (losses) on the deferred compensation plan assets are recognized in the consolidated statements of income where they offset unrealized gains and losses on the related deferred compensation plan liability.

[0000833444-21-000046:notes:222]
Investments in exchange traded funds: Investments in exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. Refer to Note 23, "Commitments and Contingencies," of the notes to consolidated financial statements for further information.

[0000833444-21-000046:notes:223]
Contingent earn-out liabilities:  The contingent earn-out liabilities related to the Silent-Aire acquisition were established using a Monte Carlo simulation based on the forecasted operating results and the earn-out formula specified in the purchase agreement.

[0000833444-21-000046:notes:224]
The following table presents the portion of unrealized gains (losses) recognized in the consolidated statements of income for the years ended September 30, 2021 and 2020 that relate to equity securities still held at September 30, 2021 and 2020 (in millions):

[0000833444-21-000046:notes:225]
|  |  | Year Ended September 30, |  |
|  | 2021 |  | 2020 |  |
| Deferred compensation plan assets |  | $ | 7 |  |  | $ | 1 |  |  |
| Investments in exchange traded funds |  | 37 |  |  | 21 |  |  |

[0000833444-21-000046:notes:226]
All of the gains and losses on investments in exchange traded funds related to restricted investments. 
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. At September 30, 2021, the fair value of long-term debt was $8.5 billion, including public debt of $8.3 billion and other long-term debt of $0.2 billion. At September 30, 2020, the fair value of long-term debt was $8.6 billion, including public debt of $8.4 billion and other long-term debt of $0.2 billion. The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy.  The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-21-000046:notes:227]
STOCK-BASED COMPENSATION
On March 10, 2021, the shareholders of the Company approved the Johnson Controls International plc 2021 Equity and Incentive Plan, which terminated the 2012 Share and Incentive Plan, as amended in September 2016 (collectively, the "Plans"). The Plans authorize stock options, stock appreciation rights, restricted (non-vested) stock/units, performance shares, performance units and other stock-based awards. The Compensation and Talent Development Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. As of September 30, 2021, there were 55 million shares of the Company's common stock reserved and 54 million shares available for issuance under the 2021 Equity and Incentive Plan.

[0000833444-21-000046:notes:228]
The Company has four share-based compensation awards, which are described below. For the fiscal years ended September 30, 2021, 2020 and 2019, compensation cost charged against income for continuing operations, excluding the offsetting impact of outstanding equity swaps, for those plans was approximately $97 million, $66 million and $103 million, respectively, all of which was recorded in selling, general and administrative expenses.

[0000833444-21-000046:notes:229]
The total income tax benefit recognized for continuing operations in the consolidated statements of income for share-based compensation arrangements was approximately $24 million, $16 million and $26 million for the fiscal years ended September 30, 2021, 2020 and 2019, respectively.  The tax impact from the exercise and vesting of equity settled awards was $12 million of tax benefit, less than $1 million of tax benefit and $6 million of tax expense for the fiscal years ended September 30, 2021, 2020 and 2019, respectively. The Company does not settle stock options granted under share-based payment arrangements to cash.

[0000833444-21-000046:notes:230]
Stock Options

[0000833444-21-000046:notes:231]
Stock options are granted with an exercise price equal to the market price of the Company’s stock at the date of grant. Stock option awards typically vest between two and three years after the grant date and expire ten years from the grant date.

[0000833444-21-000046:notes:232]
The fair value of each option is estimated on the date of grant using a Black-Scholes option valuation model that uses the assumptions noted in the following table. The expected life of options represents the period of time that options granted are expected to be outstanding, assessed separately for executives and non-executives. The risk-free interest rate for periods during the contractual life of the option is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility of the Company's stock since October 2016 blended with the historical volatility of certain peer companies' stock prior to October 2016 over the most recent period corresponding to the expected life as of the grant date. The expected dividend yield is based on the expected annual dividend as a percentage of the market value of the Company’s ordinary shares as of the grant date. The Company uses historical data to estimate option exercises and employee terminations within the valuation model.

[0000833444-21-000046:notes:233]
|  | Year Ended September 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Expected life of option (years) | 6.5 |  | 6.5 |  | 6.4 |
| Risk-free interest rate | 0.60% |  | 1.67% |  | 2.77% |
| Expected volatility of the Company’s stock | 27.60% |  | 22.40% |  | 21.80% |
| Expected dividend yield on the Company’s stock | 2.28% |  | 2.49% |  | 3.29% |

[0000833444-21-000046:notes:234]
A summary of stock option activity at September 30, 2021, and changes for the year then ended, is presented below:

[0000833444-21-000046:notes:235]
|  | WeightedAverageOption Price |  | SharesSubject toOption |  | WeightedAverageRemainingContractualLife (years) |  | AggregateIntrinsicValue(in millions) |
| Outstanding, September 30, 2020 | $ | 37.14 |  |  | 10,114,905 |  |  |  |  |  |
| Granted | 45.69 |  |  | 932,678 |  |  |  |  |  |
| Exercised | 36.70 |  |  | (4,840,511) |  |  |  |  |  |
| Forfeited or expired | 37.16 |  |  | (256,061) |  |  |  |  |  |
| Outstanding, September 30, 2021 | $ | 38.84 |  |  | 5,951,011 |  |  | 5.9 |  | $ | 174 |  |
| Exercisable, September 30, 2021 | $ | 37.01 |  |  | 3,536,889 |  |  | 4.3 |  | $ | 110 |  |

[0000833444-21-000046:notes:236]
The weighted-average grant-date fair value of options granted during the fiscal years ended September 30, 2021, 2020 and 2019 was $9.36, $7.29 and $5.56, respectively.

[0000833444-21-000046:notes:237]
The total intrinsic value of options exercised during the fiscal years ended September 30, 2021, 2020 and 2019 was approximately $94 million, $30 million and $73 million, respectively.

[0000833444-21-000046:notes:238]
In conjunction with the exercise of stock options, the Company received cash payments for the fiscal years ended September 30, 2021, 2020 and 2019 of approximately $178 million, $75 million and $171 million, respectively.

[0000833444-21-000046:notes:239]
At September 30, 2021, the Company had approximately $10 million of total unrecognized compensation cost related to non-vested stock options granted for continuing operations which is expected to be recognized over a weighted-average period of 1.6 years.

[0000833444-21-000046:notes:240]
Stock Appreciation Rights ("SARs")

[0000833444-21-000046:notes:241]
SARs vest under the same terms and conditions as stock option awards; however, they are settled in cash for the difference between the market price on the date of exercise and the exercise price. As a result, SARs are recorded in the Company’s consolidated statements of financial position as a liability until the date of exercise.

[0000833444-21-000046:notes:242]
The fair value of each SAR award is estimated using a similar method described for stock options. The fair value of each SAR award is recalculated at the end of each reporting period and the liability and expense are adjusted based on the new fair value.

[0000833444-21-000046:notes:243]
The assumptions used to determine the fair value of the SAR awards at September 30, 2021 were as follows:

[0000833444-21-000046:notes:244]
| Expected life of SAR (years) | 0.01 - 4.29 |
| Risk-free interest rate | 0.07% - 0.88% |
| Expected volatility of the Company’s stock | 27.60% |
| Expected dividend yield on the Company’s stock | 2.28% |

[0000833444-21-000046:notes:245]
A summary of SAR activity at September 30, 2021, and changes for the year then ended, is presented below:

[0000833444-21-000046:notes:246]
|  | WeightedAverageSAR Price |  | SharesSubject toSAR |  | WeightedAverageRemainingContractualLife (years) |  | AggregateIntrinsicValue(in millions) |
| Outstanding, September 30, 2020 | $ | 30.14 |  |  | 212,637 |  |  |  |  |  |
| Granted | 45.69 |  |  | 35,254 |  |  |  |  |  |
| Exercised | 28.16 |  |  | (88,600) |  |  |  |  |  |
| Forfeited or expired | 32.45 |  |  | (18,708) |  |  |  |  |  |
| Outstanding, September 30, 2021 | $ | 34.99 |  |  | 140,583 |  |  | 3.1 |  | $ | 5 |  |
| Exercisable, September 30, 2021 | $ | 31.40 |  |  | 105,329 |  |  | 1.0 |  | $ | 4 |  |

[0000833444-21-000046:notes:247]
In conjunction with the exercise of SARs granted, the Company made payments of $3 million, $2 million and $3 million during the fiscal years ended September 30, 2021, 2020 and 2019, respectively.

[0000833444-21-000046:notes:248]
Restricted (Non-vested) Stock / Units

[0000833444-21-000046:notes:249]
Restricted stock or restricted stock units are typically share settled unless the employee is a non-U.S. employee, in which case the awards are settled in cash. Restricted awards typically vest over a period of three years from the grant date. The Plans allow for different vesting terms on specific grants with approval by the Compensation and Talent Development Committee. The fair value of each share-settled restricted award is based on the closing market value of the Company’s ordinary shares on the date of grant. The fair value of each cash-settled restricted award is recalculated at the end of each reporting period based on the closing market value of the Company's ordinary shares at the end of the reporting period, and the liability and expense are adjusted based on the new fair value.

[0000833444-21-000046:notes:250]
A summary of non-vested restricted stock awards at September 30, 2021, and changes for the fiscal year then ended, is presented below:

[0000833444-21-000046:notes:251]
|  | WeightedAveragePrice |  | Shares/UnitsSubject toRestriction |
| Non-vested, September 30, 2020 | $ | 38.58 |  |  | 3,229,879 |  |
| Granted | 48.29 |  |  | 1,865,566 |  |
| Vested | 37.80 |  |  | (1,439,284) |  |
| Forfeited | 41.32 |  |  | (321,724) |  |
| Non-vested, September 30, 2021 | $ | 44.06 |  |  | 3,334,437 |  |

[0000833444-21-000046:notes:252]
At September 30, 2021, the Company had approximately $103 million of total unrecognized compensation cost related to non-vested restricted stock arrangements granted for continuing operations which is expected to be recognized over a weighted-average period of 2.0 years.

[0000833444-21-000046:notes:253]
Performance Share Awards

[0000833444-21-000046:notes:254]
Performance-based share unit ("PSU") awards are generally contingent on the achievement of predetermined performance goals over a performance period of three years as well as on the award holder's continuous employment until the vesting date. The PSUs are also indexed to the achievement of specified levels of total shareholder return versus a peer group over the performance period. Each PSU that is earned is settled with shares of the Company's ordinary shares following the completion of the performance period.

[0000833444-21-000046:notes:255]
The fair value of each PSU is estimated on the date of grant using a Monte Carlo simulation that uses the assumptions noted in the following table. The risk-free interest rate for periods during the contractual life of the PSU is based on the U.S. Treasury yield curve in effect at the time of grant. For fiscal years ended 2021 and 2020, the expected volatility is based on the historical volatility of the Company's stock over the most recent three-year period as of the grant date. For fiscal year ended 2019, the

[0000833444-21-000046:notes:256]
expected volatility is based on the historical volatility of the Company's stock since October 2016 blended with the historical volatility of certain peer companies' stock prior to October 2016 over the most recent three-year period as of the grant date.

[0000833444-21-000046:notes:257]
|  | Year Ended September 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Risk-free interest rate | 0.20% |  | 1.60% |  | 2.76% |
| Expected volatility of the Company’s stock | 30.90% |  | 21.80% |  | 22.90% |

[0000833444-21-000046:notes:258]
A summary of the status of the Company’s non-vested PSUs at September 30, 2021, and changes for the fiscal year then ended, is presented below:

[0000833444-21-000046:notes:259]
|  | WeightedAveragePrice |  | Shares/UnitsSubject toPSU |
| Non-vested, September 30, 2020 | $ | 39.06 |  |  | 1,617,944 |  |
| Granted | 50.53 |  |  | 410,934 |  |
| Vested | 38.75 |  |  | (789,129) |  |
| Forfeited | 41.86 |  |  | (43,431) |  |
| Non-vested, September 30, 2021 | $ | 43.11 |  |  | 1,196,318 |  |

[0000833444-21-000046:notes:260]
At September 30, 2021, the Company had approximately $29 million of total unrecognized compensation cost related to non-vested performance-based share unit awards granted for continuing operations which is expected to be recognized over a weighted-average period of 1.8 years.


## us-gaap:EarningsPerShareTextBlock

[0000833444-21-000046:notes:261]
EARNINGS PER SHARE
The following table reconciles the numerators and denominators used to calculate basic and diluted earnings per share (in millions):

[0000833444-21-000046:notes:262]
|  | Year Ended September 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Income Available to Ordinary Shareholders |  |  |  |  |  |
| Income from continuing operations | $ | 1,513 |  |  | $ | 631 |  |  | $ | 1,100 |  |
| Income from discontinued operations | 124 |  |  | — |  |  | 4,574 |  |
| Basic and diluted income available to shareholders | $ | 1,637 |  |  | $ | 631 |  |  | $ | 5,674 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |
| Basic weighted average shares outstanding | 716.6 |  |  | 751.0 |  |  | 870.2 |  |
| Effect of dilutive securities: |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 4.5 |  |  | 2.6 |  |  | 4.1 |  |
| Diluted weighted average shares outstanding | 721.1 |  |  | 753.6 |  |  | 874.3 |  |
| Antidilutive Securities |  |  |  |  |  |
| Options to purchase shares | — |  |  | 1.4 |  |  | 1.4 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-21-000046:notes:263]
EQUITY AND NONCONTROLLING INTERESTS
Dividends

[0000833444-21-000046:notes:264]
The authority to declare and pay dividends is vested in the Board of Directors. The timing, declaration and payment of future dividends to holders of the Company's ordinary shares is determined by the Company's Board of Directors and depends upon many factors, including the Company's financial condition and results of operations, the capital requirements of the Company's businesses, industry practice and any other relevant factors.

[0000833444-21-000046:notes:265]
Under Irish law, dividends may only be paid (and share repurchases and redemptions must generally be funded) out of "distributable reserves." The creation of distributable reserves was accomplished by way of a capital reduction, which the Irish High Court approved on December 18, 2014 and as acquired in conjunction with the Merger.

[0000833444-21-000046:notes:266]
Share Repurchase Program

[0000833444-21-000046:notes:267]
In March 2021, the Company's Board of Directors approved a $4.0 billion increase to the Company's share repurchase authorization, adding to the $2.0 billion remaining as of December 31, 2020 under the prior share repurchase authorization approved in 2019. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. As of September 30, 2021, approximately $5.1 billion remains available under the share repurchase program.

[0000833444-21-000046:notes:268]
During fiscal year 2021, the Company repurchased and retired approximately $1,307 million of its ordinary shares. During fiscal year 2020, the Company repurchased and retired approximately $2,204 million of its ordinary shares. During fiscal year 2019, the Company repurchased approximately $5,983 million of its ordinary shares, of which $4,035 million of its ordinary shares were purchased through a publicly announced "modified Dutch auction" tender offer and immediately retired, and $1,948 million of its ordinary shares were purchased on an open market and retired in the fourth quarter of fiscal 2019.

[0000833444-21-000046:notes:269]
Other comprehensive income includes activity relating to discontinued operations. The following schedules present changes in consolidated equity attributable to Johnson Controls and noncontrolling interests (in millions, net of tax):

[0000833444-21-000046:notes:270]
|  | Equity Attributable to Johnson ControlsInternational plc |  | Equity Attributable to Noncontrolling Interests |  | Total Equity |
| At September 30, 2018 | $ | 21,164 |  |  | $ | 1,294 |  |  | 22,458 |  |
| Total comprehensive income (loss): |  |  |  |  |  |
| Net income | 5,674 |  |  | 213 |  |  | 5,887 |  |
| Foreign currency translation adjustments | (325) |  |  | (17) |  |  | (342) |  |
| Realized and unrealized gains (losses) on derivatives | 7 |  |  | (1) |  |  | 6 |  |
| Pension and postretirement plans | (6) |  |  | — |  |  | (6) |  |
| Other comprehensive loss | (324) |  |  | (18) |  |  | (342) |  |
| Comprehensive income | 5,350 |  |  | 195 |  |  | 5,545 |  |
| Other changes in equity: |  |  |  |  |  |
| Cash dividends - ordinary shares ($1.04 per share) | (887) |  |  | — |  |  | (887) |  |
| Dividends attributable to noncontrolling interests | — |  |  | (132) |  |  | (132) |  |
| Repurchases and retirements of ordinary shares | (5,983) |  |  | — |  |  | (5,983) |  |
| Divestiture of Power Solutions | 483 |  |  | (295) |  |  | 188 |  |
| Adoption of ASC 606 | (45) |  |  | — |  |  | (45) |  |
| Adoption of ASU 2016-16 | (546) |  |  | — |  |  | (546) |  |
| Other, including options exercised | 230 |  |  | 1 |  |  | 231 |  |
| At September 30, 2019 | 19,766 |  |  | 1,063 |  |  | 20,829 |  |
| Total comprehensive income: |  |  |  |  |  |
| Net income | 631 |  |  | 164 |  |  | 795 |  |
| Foreign currency translation adjustments | 7 |  |  | 18 |  |  | 25 |  |
| Realized and unrealized gains on derivatives | 4 |  |  | 4 |  |  | 8 |  |
| Pension and postretirement plans | 8 |  |  | — |  |  | 8 |  |
| Other comprehensive income | 19 |  |  | 22 |  |  | 41 |  |
| Comprehensive income | 650 |  |  | 186 |  |  | 836 |  |
| Other changes in equity: |  |  |  |  |  |
| Cash dividends - ordinary shares ($1.04 per share) | (780) |  |  | — |  |  | (780) |  |
| Dividends attributable to noncontrolling interests | — |  |  | (114) |  |  | (114) |  |
| Repurchases and retirements of ordinary shares | (2,204) |  |  | — |  |  | (2,204) |  |
| Change in noncontrolling interest share | (83) |  |  | (49) |  |  | (132) |  |
| Adoption of ASC 842 | (5) |  |  | — |  |  | (5) |  |
| Other, including options exercised | 103 |  |  | — |  |  | 103 |  |
| At September 30, 2020 | 17,447 |  |  | 1,086 |  |  | 18,533 |  |
| Total comprehensive income (loss): |  |  |  |  |  |
| Net income | 1,637 |  |  | 233 |  |  | 1,870 |  |
| Foreign currency translation adjustments | 357 |  |  | 19 |  |  | 376 |  |
| Realized and unrealized gains (losses) on derivatives | (19) |  |  | 1 |  |  | (18) |  |
| Pension and postretirement plans | 4 |  |  | — |  |  | 4 |  |
| Other comprehensive income | 342 |  |  | 20 |  |  | 362 |  |
| Comprehensive income | 1,979 |  |  | 253 |  |  | 2,232 |  |
| Other changes in equity: |  |  |  |  |  |
| Cash dividends - ordinary shares ($1.07 per share) | (771) |  |  | — |  |  | (771) |  |
| Dividends attributable to noncontrolling interests | — |  |  | (142) |  |  | (142) |  |
| Repurchases and retirements of ordinary shares | (1,307) |  |  | — |  |  | (1,307) |  |
| Change in noncontrolling interest share | (8) |  |  | (6) |  |  | (14) |  |
| Adoption of ASU 2016-13 | (4) |  |  | — |  |  | (4) |  |
| Other, including options exercised | 226 |  |  | — |  |  | 226 |  |
| At September 30, 2021 | $ | 17,562 |  |  | $ | 1,191 |  |  | $ | 18,753 |  |

[0000833444-21-000046:notes:271]
The Company adopted ASU 2016-13 "Financial Instruments - Credit Losses" effective October 1, 2020.  As a result the Company recorded $4 million to beginning retained earnings.

[0000833444-21-000046:notes:272]
The Company adopted ASC 842, "Leases" effective October 1, 2019.  As a result, the Company recorded $5 million to beginning retained earnings, which relates primarily to adoption day impairment of previously exited facilities.

[0000833444-21-000046:notes:273]
The Company adopted ASC 606, "Revenue from Contracts with Customers" effective October 1, 2018. As a result, the Company recorded $45 million to beginning retained earnings, which relates primarily to deferred revenue recorded for the Power Solutions business for certain battery core returns that represent a material right provided to customers.

[0000833444-21-000046:notes:274]
The Company adopted ASU 2016-16, "Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other Than Inventory" effective October 1, 2018. As a result, the Company recognized deferred taxes of $546 million related to the tax effects of all intra-entity sales of assets other than inventory on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of October 1, 2018.

[0000833444-21-000046:notes:275]
The following schedules present changes in AOCI attributable to Johnson Controls (in millions, net of tax):

[0000833444-21-000046:notes:276]
|  | Year Ended September 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Foreign currency translation adjustments |  |  |  |  |  |
| Balance at beginning of period | $ | (778) |  |  | $ | (785) |  |  | $ | (939) |  |
| Divestiture of Power Solutions | — |  |  | — |  |  | 479 |  |
| Aggregate adjustment for the period (net of tax effect of $0, $1 and $0) | 357 |  |  | 7 |  |  | (325) |  |
| Balance at end of period | (421) |  |  | (778) |  |  | (785) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |  |  |
| Balance at beginning of period | 2 |  |  | (2) |  |  | (13) |  |
| Divestiture of Power Solutions (net of tax effect of $0, $0 and $1) | — |  |  | — |  |  | 4 |  |
| Current period changes in fair value (net of tax effect of $5, $1 and $(1)) | (8) |  |  | 3 |  |  | (1) |  |
| Reclassification to income (net of tax effect of $(3), $0 and $2) (1) | (11) |  |  | 1 |  |  | 8 |  |
| Balance at end of period | (17) |  |  | 2 |  |  | (2) |  |
| Realized and unrealized gains (losses) on marketable securities |  |  |  |  |  |
| Balance at beginning of period | — |  |  | — |  |  | 8 |  |
| Adoption of ASU 2016-01 (2) | — |  |  | — |  |  | (8) |  |
| Balance at end of period | — |  |  | — |  |  | — |  |
| Pension and postretirement plans |  |  |  |  |  |
| Balance at beginning of period | — |  |  | (8) |  |  | (2) |  |
| Reclassification to income (net of tax effect of $0, $(1) and $0) | (3) |  |  | (1) |  |  | — |  |
| Other changes (net of tax effect of $(1), $4 and $0) | 7 |  |  | 9 |  |  | (6) |  |
| Balance at end of period | 4 |  |  | — |  |  | (8) |  |
| Accumulated other comprehensive loss, end of period | $ | (434) |  |  | $ | (776) |  |  | $ | (795) |  |

[0000833444-21-000046:notes:277]
(1)   Refer to Note 11, "Derivative Instruments and Hedging Activities," of the notes to consolidated financial statements for disclosure of the line items in the consolidated statements of income affected by reclassifications from AOCI into income related to derivatives.
(2)   The Company adopted ASU 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities" effective October 1, 2018 and, as a result, reclassified $8 million of unrealized gains on marketable securities to retained earnings.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-21-000046:notes:278]
RETIREMENT PLANS
Pension Benefits

[0000833444-21-000046:notes:279]
The Company has non-contributory defined benefit pension plans covering certain U.S. and non-U.S. employees. The benefits provided are primarily based on years of service and average compensation or a monthly retirement benefit amount. Certain of the Company’s U.S. pension plans have been amended to prohibit new participants from entering the plans and no longer accrue benefits. Funding for U.S. pension plans equals or exceeds the minimum requirements of the Employee Retirement Income Security Act of 1974. Funding for non-U.S. plans observes the local legal and regulatory limits. Also, the Company makes contributions to union-trusteed pension funds for construction and service personnel.

[0000833444-21-000046:notes:280]
Information for pension plans with accumulated benefit obligations ("ABO") in excess of plan assets (in millions):

[0000833444-21-000046:notes:281]
|  |  | September 30, |  |
|  |  | 2021 |  | 2020 |  |
| Accumulated benefit obligation |  | $ | 4,402 |  |  | $ | 5,539 |  |  |
| Fair value of plan assets |  | 3,841 |  |  | 4,528 |  |  |

[0000833444-21-000046:notes:282]
Information for pension plans with projected benefit obligations ("PBO") in excess of plan assets (in millions):

[0000833444-21-000046:notes:283]
|  |  | September 30, |  |
|  |  | 2021 |  | 2020 |  |
| Projected benefit obligation |  | $ | 4,519 |  |  | $ | 5,643 |  |  |
| Fair value of plan assets |  | 3,954 |  |  | 4,570 |  |  |

[0000833444-21-000046:notes:284]
In fiscal 2021, total employer contributions to the defined benefit pension plans were $65 million, none of which were voluntary contributions made by the Company. The Company expects to contribute approximately $42 million in cash to its defined benefit pension plans in fiscal 2022. Projected benefit payments from the plans as of September 30, 2021 are estimated as follows (in millions):

[0000833444-21-000046:notes:285]
| 2022 | $ | 329 |  |
| 2023 | 298 |  |
| 2024 | 285 |  |
| 2025 | 280 |  |
| 2026 | 284 |  |
| 2027 - 2031 | 1,387 |  |

[0000833444-21-000046:notes:286]
Postretirement Benefits

[0000833444-21-000046:notes:287]
The Company provides certain health care and life insurance benefits for eligible retirees and their dependents primarily in the U.S. and Canada. Most non-U.S. employees are covered by government sponsored programs, and the cost to the Company is not significant.

[0000833444-21-000046:notes:288]
Eligibility for coverage is based on meeting certain years of service and retirement age qualifications. These benefits may be subject to deductibles, co-payment provisions and other limitations, and the Company has reserved the right to modify these benefits.

[0000833444-21-000046:notes:289]
The health care cost trend assumption does not have a significant effect on the amounts reported.

[0000833444-21-000046:notes:290]
Information for postretirement plans with accumulated postretirement benefit obligations ("APBO") in excess of plan assets (in millions):

[0000833444-21-000046:notes:291]
|  |  | September 30, |  |
|  |  | 2021 |  | 2020 |  |
| Accumulated postretirement benefit obligation |  | $ | 96 |  |  | $ | 105 |  |  |
| Fair value of plan assets |  | 38 |  |  | 34 |  |  |

[0000833444-21-000046:notes:292]
In fiscal 2021, total employer contributions to the postretirement plans were $3 million. The Company expects to contribute approximately $3 million in cash to its postretirement plans in fiscal 2022 for continuing operations. Projected benefit payments from the plans as of September 30, 2021 are estimated as follows (in millions):

[0000833444-21-000046:notes:293]
| 2022 | $ | 11 |  |
| 2023 | 11 |  |
| 2024 | 11 |  |
| 2025 | 10 |  |
| 2026 | 10 |  |
| 2027 - 2031 | 38 |  |

[0000833444-21-000046:notes:294]
The Medicare Prescription Drug, Improvement and Modernization Act of 2003 ("Act") includes a prescription drug benefit under Medicare as well as a federal subsidy to sponsors of retiree health care benefit plans providing a benefit that is at least actuarially equivalent to Medicare Part D.1. Under the Act, the Medicare subsidy amount is received directly by the plan sponsor and not the related plan. Further, the plan sponsor is not required to use the subsidy amount to fund postretirement benefits and may use the subsidy for any valid business purpose. Projected subsidy receipts are estimated to be less than $1 million per year over the next ten years.

[0000833444-21-000046:notes:295]
Defined Contribution Plans

[0000833444-21-000046:notes:296]
The Company sponsors various defined contribution savings plans that allow employees to contribute a portion of their pre-tax and/or after-tax income in accordance with plan specified guidelines. Under specified conditions, the Company will contribute to certain savings plans based on predetermined percentages of compensation earned by the employee and/or will match a percentage of the employee contributions up to certain limits. The Company temporarily suspended contributions in fiscal 2021 and 2020 in response to the COVID-19 pandemic. Defined contribution plan contributions charged to expense for continuing and discontinued operations amounted to $118 million, $104 million and $198 million for the fiscal years ended 2021, 2020 and 2019, respectively.

[0000833444-21-000046:notes:297]
Multiemployer Benefit Plans

[0000833444-21-000046:notes:298]
The Company contributes to multiemployer benefit plans based on obligations arising from collective bargaining agreements related to certain of its hourly employees in the U.S. These plans provide retirement benefits to participants based on their service to contributing employers. The benefits are paid from assets held in trust for that purpose. The trustees typically are responsible for determining the level of benefits to be provided to participants as well as for such matters as the investment of the assets and the administration of the plans.

[0000833444-21-000046:notes:299]
The risks of participating in these multiemployer benefit plans are different from single-employer benefit plans in the following aspects:

[0000833444-21-000046:notes:300]
•Assets contributed to the multiemployer benefit plan by one employer may be used to provide benefits to employees of other participating employers.

[0000833444-21-000046:notes:301]
•If a participating employer stops contributing to the multiemployer benefit plan, the unfunded obligations of the plan may be borne by the remaining participating employers.

[0000833444-21-000046:notes:302]
•If the Company stops participating in some of its multiemployer benefit plans, the Company may be required to pay those plans an amount based on its allocable share of the underfunded status of the plan, referred to as a withdrawal liability.

[0000833444-21-000046:notes:303]
The Company participates in approximately 275 multiemployer benefit plans, none of which are individually significant to the Company. The number of employees covered by the Company’s multiemployer benefit plans has remained consistent over the past three years, and there have been no significant changes that affect the comparability of fiscal 2021, 2020 and 2019 contributions. The Company recognizes expense for the contractually-required contribution for each period. The Company contributed $67 million, $66 million and $69 million to multiemployer benefit plans in fiscal 2021, 2020 and 2019, respectively.

[0000833444-21-000046:notes:304]
Based on the most recent information available, the Company believes that the present value of actuarial accrued liabilities in certain of these multiemployer benefit plans may exceed the value of the assets held in trust to pay benefits. Currently, the Company is not aware of any significant multiemployer benefit plans for which it is probable or reasonably possible that the Company will be obligated to make up any shortfall in funds. Moreover, if the Company were to exit certain markets or otherwise cease making contributions to these funds, the Company could trigger a withdrawal liability. Currently, the Company is not aware of any multiemployer benefit plans for which it is probable or reasonably possible that the Company will have a significant withdrawal liability. Any accrual for a shortfall or withdrawal liability will be recorded when it is probable that a liability exists and it can be reasonably estimated.

[0000833444-21-000046:notes:305]
Plan Assets

[0000833444-21-000046:notes:306]
The Company’s investment policies employ an approach whereby a mix of equities, fixed income and alternative investments are used to maximize the long-term return of plan assets for a prudent level of risk. The investment portfolio primarily contains a diversified blend of equity and fixed income investments. Equity investments are diversified across U.S. and non-U.S. stocks, as well as growth, value and small to large capitalization. Fixed income investments include corporate and government issues, with short-, mid- and long-term maturities, with a focus on investment grade when purchased and a target duration close to that of the plan liability. Investment and market risks are measured and monitored on an ongoing basis through regular investment portfolio reviews, annual liability measurements and periodic asset/liability studies. The majority of the real estate component of the portfolio is invested in a diversified portfolio of high-quality, operating properties with cash yields greater than the targeted appreciation. Investments in other alternative asset classes, including hedge funds and commodities, diversify the expected investment returns relative to the equity and fixed income investments. As a result of the Company's diversification strategies, there are no significant concentrations of risk within the portfolio of investments.

[0000833444-21-000046:notes:307]
The Company’s actual asset allocations are in line with target allocations. The Company rebalances asset allocations as appropriate, in order to stay within a range of allocation for each asset category.

[0000833444-21-000046:notes:308]
The expected return on plan assets is based on the Company’s expectation of the long-term average rate of return of the capital markets in which the plans invest. The average market returns are adjusted, where appropriate, for active asset management returns. The expected return reflects the investment policy target asset mix and considers the historical returns earned for each asset category.

[0000833444-21-000046:notes:309]
The Company’s plan assets at September 30, 2021 and 2020, by asset category, are as follows (in millions):

[0000833444-21-000046:notes:310]
|  | Fair Value Measurements Using: |
| Asset Category | Total as of September 30, 2021 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| U.S. Pension |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 75 |  |  | $ | — |  |  | $ | 75 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 185 |  |  | 185 |  |  | — |  |  | — |  |
| Small-Cap | 215 |  |  | 215 |  |  | — |  |  | — |  |
| International - Developed | 182 |  |  | 182 |  |  | — |  |  | — |  |
| International - Emerging | 34 |  |  | 34 |  |  | — |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 286 |  |  | 98 |  |  | 188 |  |  | — |  |
| Corporate/Other | 1,279 |  |  | 1,279 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy | 2,256 |  |  | $ | 1,993 |  |  | $ | 263 |  |  | $ | — |  |
| Real Estate Investments Measured at Net Asset Value* | 280 |  |  |  |  |  |  |  |
| Due to Broker | (77) |  |  |  |  |  |  |  |
| Total Plan Assets | $ | 2,459 |  |  |  |  |  |  |  |
| Non-U.S. Pension |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 151 |  |  | $ | 151 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 197 |  |  | 23 |  |  | 174 |  |  | — |  |
| International - Developed | 128 |  |  | 30 |  |  | 98 |  |  | — |  |
| International - Emerging | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 1,123 |  |  | 77 |  |  | 1,046 |  |  | — |  |
| Corporate/Other | 597 |  |  | 320 |  |  | 277 |  |  | — |  |
| Hedge Fund | 27 |  |  | — |  |  | 27 |  |  | — |  |
| Real Estate | 14 |  |  | 14 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy | 2,239 |  |  | $ | 615 |  |  | $ | 1,624 |  |  | $ | — |  |
| Real Estate Investments Measured at Net Asset Value* | 105 |  |  |  |  |  |  |  |
| Total Plan Assets | $ | 2,344 |  |  |  |  |  |  |  |
| Postretirement |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 5 |  |  | $ | 5 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 24 |  |  | — |  |  | 24 |  |  | — |  |
| Small-Cap | 8 |  |  | — |  |  | 8 |  |  | — |  |
| International - Developed | 19 |  |  | — |  |  | 19 |  |  | — |  |
| International - Emerging | 12 |  |  | — |  |  | 12 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 20 |  |  | — |  |  | 20 |  |  | — |  |
| Corporate/Other | 56 |  |  | — |  |  | 56 |  |  | — |  |
| Commodities | 17 |  |  | — |  |  | 17 |  |  | — |  |
| Real Estate | 11 |  |  | — |  |  | 11 |  |  | — |  |
| Total Plan Assets | $ | 172 |  |  | $ | 5 |  |  | $ | 167 |  |  | $ | — |  |

[0000833444-21-000046:notes:311]
|  | Fair Value Measurements Using: |
| Asset Category | Total as of September 30, 2020 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| U.S. Pension |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 36 |  |  | $ | — |  |  | $ | 36 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 198 |  |  | 198 |  |  | — |  |  | — |  |
| Small-Cap | 255 |  |  | 255 |  |  | — |  |  | — |  |
| International - Developed | 220 |  |  | 220 |  |  | — |  |  | — |  |
| International - Emerging | 33 |  |  | 33 |  |  | — |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 382 |  |  | 159 |  |  | 223 |  |  | — |  |
| Corporate/Other | 1,386 |  |  | 1,386 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy | 2,510 |  |  | $ | 2,251 |  |  | $ | 259 |  |  | $ | — |  |
| Real Estate Investments Measured at Net Asset Value* | 276 |  |  |  |  |  |  |  |
| Due to Broker | (80) |  |  |  |  |  |  |  |
| Total Plan Assets | $ | 2,706 |  |  |  |  |  |  |  |
| Non-U.S. Pension |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 178 |  |  | $ | 178 |  |  | $ | — |  |  | $ | — |  |
| Large-Cap | 357 |  |  | 23 |  |  | 334 |  |  | — |  |
| International - Developed | 226 |  |  | 52 |  |  | 174 |  |  | — |  |
| International - Emerging | 4 |  |  | — |  |  | 4 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 704 |  |  | 64 |  |  | 640 |  |  | — |  |
| Corporate/Other | 652 |  |  | 321 |  |  | 331 |  |  | — |  |
| Hedge Fund | 49 |  |  | — |  |  | 49 |  |  | — |  |
| Real Estate | 27 |  |  | 27 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy | 2,197 |  |  | $ | 665 |  |  | $ | 1,532 |  |  | $ | — |  |
| Real Estate Investments Measured at Net Asset Value* | 16 |  |  |  |  |  |  |  |
| Total Plan Assets | $ | 2,213 |  |  |  |  |  |  |  |
| Postretirement |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 5 |  |  | $ | 5 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 23 |  |  | — |  |  | 23 |  |  | — |  |
| Small-Cap | 7 |  |  | — |  |  | 7 |  |  | — |  |
| International - Developed | 16 |  |  | — |  |  | 16 |  |  | — |  |
| International - Emerging | 10 |  |  | — |  |  | 10 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 19 |  |  | — |  |  | 19 |  |  | — |  |
| Corporate/Other | 53 |  |  | — |  |  | 53 |  |  | — |  |
| Commodities | 12 |  |  | — |  |  | 12 |  |  | — |  |
| Real Estate | 8 |  |  | — |  |  | 8 |  |  | — |  |
| Total Plan Assets | $ | 153 |  |  | $ | 5 |  |  | $ | 148 |  |  | $ | — |  |

[0000833444-21-000046:notes:312]
* The fair value of certain investments in real estate do not have a readily determinable fair value and requires the fund managers to independently arrive at fair value by calculating net asset value ("NAV") per share. In order to calculate NAV per

[0000833444-21-000046:notes:313]
share, the fund managers value the real estate investments using any one, or a combination of, the following methods: independent third party appraisals, discounted cash flow analysis of net cash flows projected to be generated by the investment and recent sales of comparable investments. Assumptions used to revalue the properties are updated every quarter. Due to the fact that the fund managers calculate NAV per share, the Company utilizes a practical expedient for measuring the fair value of its real-estate investments, as provided for under ASC 820, "Fair Value Measurement." In applying the practical expedient, the Company is not required to further adjust the NAV provided by the fund manager in order to determine the fair value of its investment as the NAV per share is calculated in a manner consistent with the measurement principles of ASC 946, "Financial Services - Investment Companies," and as of the Company's measurement date. The Company believes this is an appropriate methodology to obtain the fair value of these assets. For the component of the real estate portfolio under development, the investments are carried at cost until they are completed and valued by a third party appraiser. In accordance with ASU No. 2015-07, "Disclosures for Investments in Certain Entities That Calculate Net Asset Value per Share (or Its Equivalent)," investments for which fair value is measured using the net asset value per share practical expedient should be disclosed separate from the fair value hierarchy. The fair value amounts presented in this table are intended to permit reconciliation of total plan assets to the amounts presented in the notes to consolidated financial statements.

[0000833444-21-000046:notes:314]
The following is a description of the valuation methodologies used for assets measured at fair value. Certain assets are held within commingled funds which are valued at the unitized NAV or percentage of the net asset value as determined by the manager of the fund. These values are based on the fair value of the underlying net assets owned by the fund.

[0000833444-21-000046:notes:315]
Cash and Cash Equivalents: The fair value of cash and cash equivalents is valued at cost.

[0000833444-21-000046:notes:316]
Equity Securities: The fair value of equity securities is determined by direct quoted market prices. The underlying holdings are direct quoted market prices on regulated financial exchanges.

[0000833444-21-000046:notes:317]
Fixed Income Securities: The fair value of fixed income securities is determined by direct or indirect quoted market prices. If indirect quoted market prices are utilized, the value of assets held in separate accounts is not published, but the investment managers report daily the underlying holdings. The underlying holdings are direct quoted market prices on regulated financial exchanges.

[0000833444-21-000046:notes:318]
Commodities: The fair value of the commodities is determined by quoted market prices of the underlying holdings on regulated financial exchanges.

[0000833444-21-000046:notes:319]
Hedge Funds: The fair value of hedge funds is accounted for by the custodian. The custodian obtains valuations from underlying managers based on market quotes for the most liquid assets and alternative methods for assets that do not have sufficient trading activity to derive prices. The Company and custodian review the methods used by the underlying managers to value the assets. The Company believes this is an appropriate methodology to obtain the fair value of these assets.

[0000833444-21-000046:notes:320]
Real Estate: The fair value of real estate is determined by quoted market prices of the underlying Real Estate Investment Trusts

[0000833444-21-000046:notes:321]
("REITs"), which are securities traded on an open exchange.

[0000833444-21-000046:notes:322]
The methods described above may produce a fair value calculation that may not be indicative of net realizable value or reflective of future fair values. Furthermore, while the Company believes its valuation methods are appropriate and consistent with other market participants, the use of different methodologies or assumptions to determine the fair value of certain financial instruments could result in a different fair value measurement at the reporting date.

[0000833444-21-000046:notes:323]
There were no Level 3 assets as of September 30, 2021 or 2020 or any Level 3 asset activity during fiscal 2021 or 2020.

[0000833444-21-000046:notes:324]
Funded Status

[0000833444-21-000046:notes:325]
The table that follows contains the ABO and reconciliations of the changes in the PBO, the changes in plan assets and the funded status (in millions):

[0000833444-21-000046:notes:326]
|  | Pension Benefits |  | PostretirementBenefits |
|  | U.S. Plans |  | Non-U.S. Plans |  |
| September 30, | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Accumulated Benefit Obligation | $ | 2,629 |  |  | $ | 3,217 |  |  | $ | 2,540 |  |  | $ | 2,627 |  |  | $ | — |  |  | $ | — |  |
| Change in Projected Benefit Obligation |  |  |  |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of year | $ | 3,217 |  |  | $ | 3,115 |  |  | $ | 2,726 |  |  | $ | 2,652 |  |  | $ | 146 |  |  | $ | 174 |  |
| Service cost | — |  |  | — |  |  | 27 |  |  | 25 |  |  | 1 |  |  | 1 |  |
| Interest cost | 47 |  |  | 67 |  |  | 32 |  |  | 36 |  |  | 2 |  |  | 4 |  |
| Plan participant contributions | — |  |  | — |  |  | 3 |  |  | 3 |  |  | 3 |  |  | 4 |  |
| Other divestitures | — |  |  | — |  |  | — |  |  | (2) |  |  | — |  |  | — |  |
| Actuarial (gain) loss | (52) |  |  | 298 |  |  | (103) |  |  | 7 |  |  | (13) |  |  | (3) |  |
| Amendments made during the year | — |  |  | — |  |  | (6) |  |  | — |  |  | — |  |  | (13) |  |
| Benefits and settlements paid | (583) |  |  | (263) |  |  | (124) |  |  | (109) |  |  | (17) |  |  | (21) |  |
| Estimated subsidy received | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |
| Curtailment | — |  |  | — |  |  | (3) |  |  | (8) |  |  | — |  |  | — |  |
| Other | — |  |  | — |  |  | (2) |  |  | 4 |  |  | — |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | 75 |  |  | 118 |  |  | 1 |  |  | (1) |  |
| Projected benefit obligation at end of year | $ | 2,629 |  |  | $ | 3,217 |  |  | $ | 2,625 |  |  | $ | 2,726 |  |  | $ | 123 |  |  | $ | 146 |  |
| Change in Plan Assets |  |  |  |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year | $ | 2,706 |  |  | $ | 2,736 |  |  | $ | 2,213 |  |  | $ | 2,098 |  |  | $ | 153 |  |  | $ | 163 |  |
| Actual return on plan assets | 333 |  |  | 228 |  |  | 125 |  |  | 75 |  |  | 30 |  |  | 4 |  |
| Employer and employee contributions | 3 |  |  | 5 |  |  | 65 |  |  | 56 |  |  | 6 |  |  | 7 |  |
| Benefits paid | (108) |  |  | (112) |  |  | (79) |  |  | (73) |  |  | (17) |  |  | (21) |  |
| Settlement payments | (475) |  |  | (151) |  |  | (45) |  |  | (36) |  |  | — |  |  | — |  |
| Other | — |  |  | — |  |  | (1) |  |  | — |  |  | — |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | 66 |  |  | 93 |  |  | — |  |  | — |  |
| Fair value of plan assets at end of year | $ | 2,459 |  |  | $ | 2,706 |  |  | $ | 2,344 |  |  | $ | 2,213 |  |  | $ | 172 |  |  | $ | 153 |  |
| Funded status | $ | (170) |  |  | $ | (511) |  |  | $ | (281) |  |  | $ | (513) |  |  | $ | 49 |  |  | $ | 7 |  |
| Amounts recognized in the statement of financial position consist of: |
| Prepaid benefit cost | $ | 44 |  |  | $ | 32 |  |  | $ | 79 |  |  | $ | 29 |  |  | $ | 107 |  |  | $ | 78 |  |
| Accrued benefit liability | (214) |  |  | (543) |  |  | (360) |  |  | (542) |  |  | (58) |  |  | (71) |  |
| Net amount recognized | $ | (170) |  |  | $ | (511) |  |  | $ | (281) |  |  | $ | (513) |  |  | $ | 49 |  |  | $ | 7 |  |
| Weighted Average Assumptions (1) |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate (2) | 2.50 | % |  | 2.25 | % |  | 1.80 | % |  | 1.35 | % |  | 2.30 | % |  | 1.90 | % |
| Rate of compensation increase | N/A |  | N/A |  | 2.85 | % |  | 2.75 | % |  | N/A |  | N/A |
| Interest crediting rate | N/A |  | N/A |  | 1.45 | % |  | 1.50 | % |  | N/A |  | N/A |

[0000833444-21-000046:notes:327]
(1)    Plan assets and obligations are determined based on a September 30 measurement date at September 30, 2021 and 2020.

[0000833444-21-000046:notes:328]
(2)    The Company considers the expected benefit payments on a plan-by-plan basis when setting assumed discount rates. As a result, the Company uses different discount rates for each plan depending on the plan jurisdiction, the demographics of participants and the expected timing of benefit payments. For the U.S. pension and postretirement

[0000833444-21-000046:notes:329]
plans, the Company uses a discount rate provided by an independent third party calculated based on an appropriate mix of high quality bonds. For the non-U.S. pension and postretirement plans, the Company consistently uses the relevant country specific benchmark indices for determining the various discount rates. The Company has elected to utilize a full yield curve approach in the estimation of service and interest components of net periodic benefit cost (credit) for pension and other postretirement for plans that utilize a yield curve approach. The full yield curve approach applies the specific spot rates along the yield curve used in the determination of the benefit obligation to the relevant projected cash flows.

[0000833444-21-000046:notes:330]
The fiscal 2021 net actuarial gains related to changes in the benefit obligation were the result of the increase in the discount rates globally. The fiscal 2020 net actuarial losses related to changes in the benefit obligation were primarily driven by the decrease in the U.S. discount rates.

[0000833444-21-000046:notes:331]
Accumulated Other Comprehensive Income

[0000833444-21-000046:notes:332]
The amounts in AOCI in the consolidated statements of financial position, exclusive of tax impacts, that have not yet been recognized as components of net periodic benefit credit at September 30, 2021 and 2020 related to pension and postretirement benefits are $8 million and $5 million, respectively.

[0000833444-21-000046:notes:333]
Net Periodic Benefit Cost

[0000833444-21-000046:notes:334]
The table that follows contains the components of net periodic benefit costs, which are primarily recorded in selling, general and administrative expenses in the consolidated statements of income (in millions):

[0000833444-21-000046:notes:335]
|  | Pension Benefits |  | Postretirement Benefits |
|  | U.S. Plans |  | Non-U.S. Plans |  |
| Year ended September 30, | 2021 |  | 2020 |  | 2019 |  | 2021 |  | 2020 |  | 2019 |  | 2021 |  | 2020 |  | 2019 |
| Components of Net Periodic Benefit Cost (Credit): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost | $ | — |  |  | $ | — |  |  | $ | 8 |  |  | $ | 27 |  |  | $ | 25 |  |  | $ | 22 |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 1 |  |
| Interest cost | 47 |  |  | 67 |  |  | 108 |  |  | 32 |  |  | 36 |  |  | 54 |  |  | 2 |  |  | 4 |  |  | 6 |  |
| Expected return on plan assets | (171) |  |  | (180) |  |  | (199) |  |  | (112) |  |  | (111) |  |  | (105) |  |  | (8) |  |  | (9) |  |  | (9) |  |
| Net actuarial (gain) loss | (214) |  |  | 244 |  |  | 361 |  |  | (115) |  |  | 43 |  |  | 236 |  |  | (35) |  |  | 2 |  |  | 17 |  |
| Amortization of prior service cost (credit) | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  | — |  |  | (4) |  |  | (3) |  |  | — |  |
| Curtailment gain | — |  |  | — |  |  | — |  |  | (3) |  |  | (8) |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Settlement (gain) loss | — |  |  | 6 |  |  | 13 |  |  | (1) |  |  | — |  |  | 4 |  |  | — |  |  | — |  |  | — |  |
| Special termination benefit cost | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (credit) | (338) |  |  | 137 |  |  | 291 |  |  | (169) |  |  | (14) |  |  | 211 |  |  | (44) |  |  | (5) |  |  | 15 |  |
| Net periodic benefit cost related to discontinued operations | — |  |  | — |  |  | (2) |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (credit) included in continuing operations | $ | (338) |  |  | $ | 137 |  |  | $ | 289 |  |  | $ | (169) |  |  | $ | (14) |  |  | $ | 211 |  |  | $ | (44) |  |  | $ | (5) |  |  | $ | 15 |  |
| Expense Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate | 2.25 | % |  | 2.95 | % |  | 4.10 | % |  | 1.35 | % |  | 1.50 | % |  | 2.45 | % |  | 1.90 | % |  | 2.65 | % |  | 3.80 | % |
| Expected return on plan assets | 6.50 | % |  | 6.90 | % |  | 7.10 | % |  | 4.90 | % |  | 5.20 | % |  | 5.20 | % |  | 5.30 | % |  | 5.70 | % |  | 5.65 | % |
| Rate of compensation increase | N/A |  | N/A |  | 3.50 | % |  | 2.75 | % |  | 2.80 | % |  | 2.95 | % |  | N/A |  | N/A |  | N/A |
| Interest crediting rate | N/A |  | N/A |  | N/A |  | 1.50 | % |  | 1.50 | % |  | 1.55 | % |  | N/A |  | N/A |  | N/A |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-21-000046:notes:336]
SIGNIFICANT RESTRUCTURING AND IMPAIRMENT COSTS
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company commits to various restructuring plans as necessary. Restructuring plans generally result in charges for workforce reductions, plant closures, asset impairments and other related costs which are reported as restructuring and impairment costs in the Company’s consolidated statements of income. The other related costs consist primarily of consulting costs incurred as a direct result of the restructuring initiatives. The Company expects the restructuring actions to reduce cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense.

[0000833444-21-000046:notes:337]
In fiscal 2021, the Company committed to a significant restructuring plan ("2021 Plan"). During the year ended September 30, 2021, the Company recorded $242 million of restructuring and impairment costs in the consolidated statements of income. The total amount expected to be incurred for this restructuring plan is $385 million across all segments and at Corporate. Of the restructuring and impairment costs recorded in the year ended September 30, 2021, $91 million related to the Global Products segment, $70 million related to the Building Solutions North America segment, $29 million related to the Building Solutions EMEA/LA segment, $28 million related to the Building Solutions Asia Pacific segment and $24 million related to Corporate.

[0000833444-21-000046:notes:338]
The following table summarizes the changes in the Company’s 2021 Plan reserve, included primarily within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-21-000046:notes:339]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | Total |
| Original reserve | $ | 68 |  |  | $ | 98 |  |  | $ | 76 |  |  | $ | 242 |  |
| Utilized—cash | (28) |  |  | — |  |  | (51) |  |  | (79) |  |
| Utilized—noncash | — |  |  | (98) |  |  | — |  |  | (98) |  |
| Balance at September 30, 2021 | $ | 40 |  |  | $ | — |  |  | $ | 25 |  |  | $ | 65 |  |

[0000833444-21-000046:notes:340]
In fiscal 2020, the Company committed to a significant restructuring plan ("2020 Plan") and recorded $297 million of restructuring and impairment costs in the consolidated statements of income. This is the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. Of the restructuring and impairment costs recorded, $136 million related to the Global Products segment, $64 million related to the Building Solutions North America segment, $49 million related to the Building Solutions Asia Pacific segment, $43 million related to the Building Solutions EMEA/LA segment and $5 million related to Corporate. The restructuring actions were substantially complete in fiscal 2021.

[0000833444-21-000046:notes:341]
The following table summarizes the changes in the Company’s 2020 Plan reserve, included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-21-000046:notes:342]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | Total |
| Original reserve | $ | 196 |  |  | $ | 96 |  |  | $ | 5 |  |  | $ | 297 |  |
| Utilized—cash | (92) |  |  | — |  |  | (3) |  |  | (95) |  |
| Utilized—noncash | — |  |  | (96) |  |  | — |  |  | (96) |  |
| Currency translation | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Balance at September 30, 2020 | 106 |  |  | — |  |  | 2 |  |  | 108 |  |
| Utilized—cash | (69) |  |  | — |  |  | (2) |  |  | (71) |  |
| Balance at September 30, 2021 | $ | 37 |  |  | $ | — |  |  | $ | — |  |  | $ | 37 |  |

[0000833444-21-000046:notes:343]
Also included in restructuring and impairment costs in the consolidated statements of income in fiscal 2020 are goodwill impairment related to the North America Retail reporting unit of $424 million and indefinite-lived intangible asset impairments of $62 million. Refer to Note 8, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for further information regarding these impairments.  
The Company's fiscal 2021 and 2020 restructuring plans included workforce reductions of approximately 10,000 employees. Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of September 30, 2021, approximately 7,800 of the employees have been separated from the Company pursuant to the restructuring plans.Company management closely monitors its overall cost structure and continually analyzes each of its businesses for opportunities to consolidate current operations, improve operating efficiencies and locate facilities in close proximity to customers. This ongoing analysis includes a review of its manufacturing, engineering and purchasing operations, as well as the overall global footprint for all its businesses.


## us-gaap:AssetImpairmentChargesTextBlock

[0000833444-21-000046:notes:344]
IMPAIRMENT OF LONG-LIVED ASSETS
In fiscal 2021, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2021. As a result, the Company reviewed the long-lived assets for impairment and recorded $98 million of asset impairment charges within restructuring and impairment costs in the consolidated statements of income. Of the total impairment charges, $50 million related to the Global Products segment, $33 million related to the Building Solutions North America segment, $6 million related to Corporate assets, $5 million related to the Building Solutions EMEA/LA segment and $4 million related to the Building Solutions Asia Pacific segment. Refer to Note 17, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement.

[0000833444-21-000046:notes:345]
In fiscal 2020, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets caused by the economic impacts of the COVID-19 pandemic on the North America Retail asset group. The Company performed a quantitative impairment analysis and determined there was no impairment of long-lived assets as of September 30, 2020.

[0000833444-21-000046:notes:346]
In fiscal 2020, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2020. As a result, the Company reviewed the long-lived assets for impairment and recorded $81 million of asset impairment charges within restructuring and impairment costs in the consolidated statements of income. Of these impairment charges, $42 million related to the Global Products segment, $24 million related to the Building Solutions Asia Pacific segment and $15 million related to the Building Solutions North America segment. The impairments were primarily measured under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-21-000046:notes:347]
In fiscal 2019 and again in 2020, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with the plans to dispose of a business within its Global Products segment that met the criteria to be classified as held for sale. Assets and liabilities held for sale are required to be recorded at the lower of carrying value or fair value less any costs to sell. Accordingly, the Company recorded impairment charges of $250 million, including $15 million in fiscal 2020 and $235 million in fiscal 2019, within restructuring and impairment costs in the consolidated statements of income to write down the carrying value of the assets held for sale to fair value less any costs to sell. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-21-000046:notes:348]
Refer to Note 17, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-21-000046:notes:349]
At September 30, 2021, 2020 and 2019, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets. Refer to Note 1, "Summary of Significant Accounting Policies," and Note 8, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for discussion of the Company’s goodwill and indefinite-lived intangibles impairment testing.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-21-000046:notes:350]
INCOME TAXES
The more significant components of the Company’s income tax provision from continuing operations are as follows (in millions):

[0000833444-21-000046:notes:351]
|  | Year Ended September 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Tax expense at Ireland statutory rate | $ | 327 |  |  | $ | 113 |  |  | $ | 132 |  |
| U.S. state income tax, net of federal benefit | 34 |  |  | 8 |  |  | 15 |  |
| Income subject to the U.S. federal tax rate | 3 |  |  | (92) |  |  | (110) |  |
| Income subject to rates different than the statutory rate | 30 |  |  | 99 |  |  | 38 |  |
| Reserve and valuation allowance adjustments | 66 |  |  | (70) |  |  | (284) |  |
| Intercompany intellectual property transfer | 417 |  |  | — |  |  | — |  |
| Restructuring and impairment costs | (9) |  |  | 50 |  |  | (24) |  |
| Income tax provision (benefit) | $ | 868 |  |  | $ | 108 |  |  | $ | (233) |  |

[0000833444-21-000046:notes:352]
The statutory tax rate in Ireland of 12.5% is being used as a comparison since the Company is domiciled in Ireland.

[0000833444-21-000046:notes:353]
For fiscal 2021, the effective tax rate for continuing operations was 33% and was higher than the statutory tax rate primarily due to the tax impacts of an intercompany transfer of certain of the Company’s intellectual property rights, valuation allowance adjustments, the income tax effects of mark-to-market adjustments and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives.

[0000833444-21-000046:notes:354]
For fiscal 2020, the effective tax rate for continuing operations was 12% and was lower than the statutory tax rate primarily due to tax audit reserve adjustments, the income tax effects of mark-to-market adjustments, valuation allowance adjustments and the benefits of continuing global tax planning initiatives, partially offset by a discrete tax charge related to the remeasurement of deferred tax assets and liabilities as a result of Swiss tax reform, the tax impact of an impairment charge and tax rate differentials.

[0000833444-21-000046:notes:355]
For fiscal 2019, the effective rate for continuing operations was below the statutory rate primarily due to tax audit reserve adjustments, the income tax effects of mark-to-market adjustments, a tax indemnification reserve release, the tax benefits of an asset held for sale impairment charge and continuing global tax planning initiatives, partially offset by valuation allowance adjustments as a result of tax law changes, a discrete tax charge related to newly enacted regulations related to U.S. Tax Reform and tax rate differentials.

[0000833444-21-000046:notes:356]
Valuation Allowances

[0000833444-21-000046:notes:357]
The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary.

[0000833444-21-000046:notes:358]
In the fourth quarter of fiscal 2021, as a result of an intercompany transfer of certain of the Company’s intellectual property rights, the Company determined that it is more likely than not that certain deferred tax assets of Switzerland would be realized, and it was more likely than not that certain deferred tax assets of Canada would not be realized. The valuation allowance adjustments resulted in a $39 million net benefit to income tax expense in the three month period ended September 30, 2021.

[0000833444-21-000046:notes:359]
In the second quarter of fiscal 2021, due to changes in forecasted taxable income, the Company recorded a discrete tax charge of $105 million related to valuation allowances on certain Mexico deferred tax assets now considered unrealizable.

[0000833444-21-000046:notes:360]
In the fourth quarter of fiscal 2020, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering feasible tax planning initiatives and other positive and negative evidence, the Company determined that it was more likely than not that certain deferred tax assets primarily within the U.S. would not be realized, and it is more likely than not that certain deferred tax assets of Canada would be realized. The valuation allowance adjustments resulted in a $26 million net benefit to income tax expense in the three month period ended September 30, 2020.

[0000833444-21-000046:notes:361]
In the fourth quarter of fiscal 2019, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering feasible tax planning initiatives and other positive and negative evidence, the Company determined that it was more likely than not that certain deferred tax assets primarily within the U.S., Belgium, Japan and the United Kingdom would not be realized, and it is more likely than not that certain deferred tax assets of the U.S. and France will be realized. The valuation allowance adjustments resulted in an immaterial net impact to income tax expense for the three-month period ended September 30, 2019.

[0000833444-21-000046:notes:362]
In the first quarter of fiscal 2019, as a result of changes to U.S. tax law, the Company recorded a discrete tax charge of $76 million related to valuation allowances on certain U.S. deferred tax assets.

[0000833444-21-000046:notes:363]
Uncertain Tax Positions

[0000833444-21-000046:notes:364]
The Company is subject to income taxes in the U.S. and numerous non-U.S. jurisdictions. Judgment is required in determining its worldwide provision for income taxes and recording the related assets and liabilities. In the ordinary course of the Company’s business, there are many transactions and calculations where the ultimate tax determination is uncertain. The Company is regularly under audit by tax authorities.

[0000833444-21-000046:notes:365]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0000833444-21-000046:notes:366]
|  | Year Ended September 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Beginning balance, October 1 | $ | 2,528 |  |  | $ | 2,451 |  |  | $ | 2,358 |  |
| Additions for tax positions related to the current year | 240 |  |  | 128 |  |  | 433 |  |
| Additions for tax positions of prior years | 33 |  |  | 129 |  |  | 347 |  |
| Reductions for tax positions of prior years | (6) |  |  | (27) |  |  | (88) |  |
| Settlements with taxing authorities | (24) |  |  | (54) |  |  | — |  |
| Statute closings and audit resolutions | (45) |  |  | (99) |  |  | (599) |  |
| Ending balance, September 30 | $ | 2,726 |  |  | $ | 2,528 |  |  | $ | 2,451 |  |

[0000833444-21-000046:notes:367]
The amount of gross tax effected unrecognized tax benefits that, if recognized, would impact the effective tax rate was $2,268 million, $2,132 million, and $2,121 million as of September 30, 2021, 2020 and 2019, respectively. Total net accrued interest was approximately $252 million, $205 million, and $181 million (net of tax benefit) at September 30, 2021, 2020 and 2019, respectively.

[0000833444-21-000046:notes:368]
During fiscal 2020, tax audit resolutions resulted in a $44 million net benefit to income tax expense.

[0000833444-21-000046:notes:369]
During fiscal 2019, the Company settled tax examinations impacting fiscal years 2015 to 2016 and adjusted various tax audit reserves which resulted in a $586 million net benefit to income tax expense in the fourth quarter. In the third quarter of fiscal 2019, the Company recorded a discrete charge related to newly enacted regulations related to U.S. Tax Reform and a discrete charge related to non-U.S. tax examinations which impacted the Company’s reserves for uncertain tax positions resulting in a $226 million net charge to income tax expense.

[0000833444-21-000046:notes:370]
In the U.S., fiscal years 2017 through 2018 are currently under exam by the Internal Revenue Service (“IRS”) for certain legal entities. Additionally, the Company is currently under exam in the following major non-U.S. jurisdictions for continuing operations:

[0000833444-21-000046:notes:371]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2020 |
| China |  | 2017 - 2019 |
| Germany |  | 2007 - 2018 |
| Luxembourg |  | 2017 - 2018 |
| Mexico |  | 2015 - 2020 |
| United Kingdom |  | 2014 - 2015, 2017 - 2018 |

[0000833444-21-000046:notes:372]
It is reasonably possible that certain tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense. Based upon the circumstances surrounding these examinations, the impact is not currently quantifiable.

[0000833444-21-000046:notes:373]
Other Tax Matters

[0000833444-21-000046:notes:374]
In the fourth quarter of fiscal 2021, the Company completed an intercompany transfer of certain of the Company’s intellectual property rights which resulted in a net tax charge of $417 million.

[0000833444-21-000046:notes:375]
During fiscal 2021, the Company incurred charges for restructuring and impairment costs for continuing operations of $242 million. Refer to Note 17, "Significant Restructuring and Impairment Costs," and Note 18, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for additional information. These costs generated tax benefits of $39 million, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-21-000046:notes:376]
During fiscal 2021, 2020 and 2019, the Company recorded mark-to-market gains (losses) of $402 million, $(274) million and $(618) million, respectively. These gains (losses) generated tax expense (benefit) of $93 million, $(65) million and $(130) million, respectively, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-21-000046:notes:377]
During fiscal 2020, the Company incurred charges for restructuring and impairment costs for continuing operations of $783 million. Refer to Note 8, "Goodwill and Other Intangible Assets," Note 17, "Significant Restructuring and Impairment Costs," and Note 18, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for additional information. These costs generated tax benefits of $48 million, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-21-000046:notes:378]
During fiscal 2020 and 2019, the Company recorded transaction and integration costs for continuing operations of $135 million and $317 million, respectively. These costs generated tax benefits of $18 million and $35 million, respectively, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-21-000046:notes:379]
During fiscal 2019, the Company recorded a $235 million impairment charge related to assets held for sale. Refer to Note 18, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for further information regarding the impairment charge. The impairment charge generated a $53 million tax benefit.  Also during fiscal 2019, the Company released a $226 million tax indemnification reserve, which was recorded within selling, general and administrative expenses in the consolidated statements of income. The reserve release generated no income tax expense.

[0000833444-21-000046:notes:380]
Impacts of Tax Legislation and Change in Statutory Tax Rates

[0000833444-21-000046:notes:381]
On March 27, 2020, in response to the COVID-19 pandemic, the “Coronavirus Aid, Relief and Economic Security Act” (“CARES”) was signed into law by the President of the United States. The CARES Act includes, among other things, U.S. corporate income tax provisions related to net operating loss carryback periods, alternative minimum tax credits, modifications to interest deduction limitations and technical corrections on tax depreciation methods for qualified improvement property. A majority of non-U.S. countries have also introduced various COVID-19 related corporate income tax relief provisions.  The Company does not expect either the U.S. or non-U.S. corporate income tax provisions to have a material effect on its financial statements.

[0000833444-21-000046:notes:382]
In the first quarter of fiscal 2020, the Company recorded a noncash discrete tax charge of $30 million due to the remeasurement of deferred tax assets and liabilities related to Switzerland and the canton of Schaffhausen. On September 28, 2018, the Swiss Parliament approved the Federal Act on Tax Reform and AHV Financing (“TRAF”), which was subsequently approved by the Swiss electorate on May 19, 2019. During the fourth quarter of fiscal 2019, the Swiss Federal Council enacted TRAF which became effective for the Company on January 1, 2020. The impacts of the federal enactment did not have a material impact to the Company’s financial statements. TRAF also provides for parameters which enable the Swiss cantons to adjust tax rates and establish new regulations for companies. As of September 30, 2019, the canton of Schaffhausen had not concluded its public referendum; however, the enactment did occur during the first quarter of fiscal 2020.

[0000833444-21-000046:notes:383]
During the fiscal years ended 2021, 2020 and 2019, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-21-000046:notes:384]
Continuing Operations

[0000833444-21-000046:notes:385]
Selected income tax data related to continuing operations were as follows (in millions):

[0000833444-21-000046:notes:386]
|  | Year Ended September 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Components of income (loss) from continuing operations before income taxes: |  |  |  |  |  |
| U.S. | $ | 543 |  |  | $ | (385) |  |  | $ | (259) |  |
| Non-U.S. | 2,071 |  |  | 1,288 |  |  | 1,315 |  |
| Income from continuing operations before income taxes | $ | 2,614 |  |  | $ | 903 |  |  | $ | 1,056 |  |
| Components of the provision (benefit) for income taxes: |  |  |  |  |  |
| Current |  |  |  |  |  |
| U.S. federal | $ | 459 |  |  | $ | 309 |  |  | $ | (1,025) |  |
| U.S. state | 108 |  |  | 72 |  |  | (33) |  |
| Non-U.S. | 265 |  |  | 264 |  |  | 213 |  |
|  | 832 |  |  | 645 |  |  | (845) |  |
| Deferred |  |  |  |  |  |
| U.S. federal | (7) |  |  | (382) |  |  | 412 |  |
| U.S. state | 46 |  |  | (43) |  |  | 84 |  |
| Non-U.S. | (3) |  |  | (112) |  |  | 116 |  |
|  | 36 |  |  | (537) |  |  | 612 |  |
| Income tax provision (benefit) | $ | 868 |  |  | $ | 108 |  |  | $ | (233) |  |
| Income taxes paid (refunded) | $ | 504 |  |  | $ | (386) |  |  | $ | 377 |  |

[0000833444-21-000046:notes:387]
At September 30, 2021 and 2020, the Company recorded within the consolidated statements of financial position in other current assets approximately $120 million and $252 million, respectively, of income tax assets. At September 30, 2021 and 2020, the Company recorded within the consolidated statements of financial position in other current liabilities approximately $201 million and $243 million, respectively, of accrued income tax liabilities.

[0000833444-21-000046:notes:388]
The Company has not provided U.S. or non-U.S. income taxes on approximately $22.8 billion of outside basis differences of consolidated subsidiaries of Johnson Controls International plc. The Company is indefinitely reinvested in these basis differences. The reduction of the outside basis differences via the sale or liquidation of these subsidiaries and/or distributions could create taxable income. The Company's intent is to reduce the outside basis differences only when it would be tax efficient. Given the numerous ways in which the basis differences may be reduced, it is not practicable to estimate the amount of unrecognized withholding taxes and deferred tax liability on the outside basis differences.

[0000833444-21-000046:notes:389]
Deferred taxes were classified in the consolidated statements of financial position as follows (in millions):

[0000833444-21-000046:notes:390]
|  | September 30, |
|  | 2021 |  | 2020 |
| Other noncurrent assets | $ | 755 |  |  | $ | 862 |  |
| Other noncurrent liabilities | (443) |  |  | (385) |  |
| Net deferred tax asset | $ | 312 |  |  | $ | 477 |  |

[0000833444-21-000046:notes:391]
Temporary differences and carryforwards which gave rise to deferred tax assets and liabilities included (in millions):

[0000833444-21-000046:notes:392]
|  | September 30, |
|  | 2021 |  | 2020 |
| Deferred tax assets |  |  |  |
| Accrued expenses and reserves | $ | 407 |  |  | $ | 474 |  |
| Employee and retiree benefits | 148 |  |  | 286 |  |
| Property, plant and equipment | 369 |  |  | 182 |  |
| Net operating loss and other credit carryforwards | 6,293 |  |  | 6,306 |  |
| Research and development | 42 |  |  | 112 |  |
| Operating lease liabilities | 334 |  |  | 304 |  |
| Other, net | 28 |  |  | 99 |  |
|  | 7,621 |  |  | 7,763 |  |
| Valuation allowances | (5,853) |  |  | (5,518) |  |
|  | 1,768 |  |  | 2,245 |  |
| Deferred tax liabilities |  |  |  |
| Subsidiaries, joint ventures and partnerships | 346 |  |  | 730 |  |
| Intangible assets | 776 |  |  | 734 |  |
| Operating lease right-of-use assets | 334 |  |  | 304 |  |
|  | 1,456 |  |  | 1,768 |  |
| Net deferred tax asset | $ | 312 |  |  | $ | 477 |  |

[0000833444-21-000046:notes:393]
At September 30, 2021, the Company had available net operating loss carryforwards of approximately $23.7 billion, of which $13.2 billion will expire at various dates between 2022 and 2041, and the remainder has an indefinite carryforward period. The Company had available U.S. foreign tax credit carryforwards at September 30, 2021 of $35 million which will expire in 2030. The valuation allowance, generally, is for loss and credit carryforwards for which realization is uncertain because it is unlikely that the losses and/or credits will be realized given the lack of sustained profitability and/or limited carryforward periods in certain countries.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-21-000046:notes:394]
SEGMENT INFORMATION
ASC 280, "Segment Reporting," establishes the standards for reporting information about segments in financial statements. In applying the criteria set forth in ASC 280, the Company has determined that it has four reportable segments for financial reporting purposes.

[0000833444-21-000046:notes:395]
Building Solutions North America:   Building Solutions North America designs, sells, installs and services HVAC, controls, building management, refrigeration, integrated electronic security and integrated fire-detection and suppression systems for commercial, industrial, retail, small business, institutional and governmental customers in the United States and Canada. Building Solutions North America also provides energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and controls systems, as well as data-driven “smart building” solutions, to non-residential building and industrial applications in the United States and Canadian marketplace.

[0000833444-21-000046:notes:396]
Building Solutions EMEA/LA: Building Solutions EMEA/LA designs, sells, installs, and services HVAC, controls, building management, refrigeration, integrated electronic security, integrated fire-detection and suppression systems, and provides technical services, including data-driven “smart building” solutions, to markets in Europe, the Middle East, Africa and Latin America.

[0000833444-21-000046:notes:397]
Building Solutions Asia Pacific: Building Solutions Asia Pacific designs, sells, installs, and services HVAC, controls, building management, refrigeration, integrated electronic security, integrated fire-detection and suppression systems, and provides technical services, including data-driven “smart building” solutions, to the Asia Pacific marketplace.

[0000833444-21-000046:notes:398]
Global Products: Global Products designs, manufactures and sells HVAC equipment, controls software and software services for residential and commercial applications to commercial, industrial, retail, residential, small business, institutional and

[0000833444-21-000046:notes:399]
governmental customers worldwide. In addition, Global Products designs, manufactures and sells refrigeration equipment and controls globally. The Global Products business also designs, manufactures and sells fire protection, fire suppression and security products, including intrusion security, anti-theft devices, access control, and video surveillance and management systems, for commercial, industrial, retail, residential, small business, institutional and governmental customers worldwide. Global Products includes the Johnson Controls-Hitachi joint venture.

[0000833444-21-000046:notes:400]
Management evaluates the performance of its business segments primarily on segment earnings before interest, taxes and amortization ("EBITA"), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and net mark-to-market adjustments related to pension and postretirement plans and restricted asbestos investments.

[0000833444-21-000046:notes:401]
Financial information relating to the Company’s reportable segments is as follows (in millions):

[0000833444-21-000046:notes:402]
|  | Year Ended September 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Net Sales |  |  |  |  |  |
| Building Solutions North America | $ | 8,685 |  |  | $ | 8,605 |  |  | $ | 9,031 |  |
| Building Solutions EMEA/LA | 3,727 |  |  | 3,440 |  |  | 3,655 |  |
| Building Solutions Asia Pacific | 2,654 |  |  | 2,403 |  |  | 2,658 |  |
| Global Products | 8,602 |  |  | 7,869 |  |  | 8,624 |  |
| Total net sales | $ | 23,668 |  |  | $ | 22,317 |  |  | $ | 23,968 |  |

[0000833444-21-000046:notes:403]
|  | Year Ended September 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Segment EBITA |  |  |  |  |  |
| Building Solutions North America (1) | $ | 1,204 |  |  | $ | 1,157 |  |  | $ | 1,153 |  |
| Building Solutions EMEA/LA (2) | 391 |  |  | 338 |  |  | 368 |  |
| Building Solutions Asia Pacific (3) | 349 |  |  | 319 |  |  | 341 |  |
| Global Products (4) | 1,441 |  |  | 1,134 |  |  | 1,179 |  |
| Total segment EBITA | $ | 3,385 |  |  | $ | 2,948 |  |  | $ | 3,041 |  |
| Amortization of intangible assets | (435) |  |  | (386) |  |  | (377) |  |
| Corporate expenses (5) | (290) |  |  | (371) |  |  | (405) |  |
| Net financing charges | (206) |  |  | (231) |  |  | (350) |  |
| Restructuring and impairment costs | (242) |  |  | (783) |  |  | (235) |  |
| Net mark-to-market adjustments | 402 |  |  | (274) |  |  | (618) |  |
| Income from continuing operations before income taxes | $ | 2,614 |  |  | $ | 903 |  |  | $ | 1,056 |  |

[0000833444-21-000046:notes:404]
|  | September 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Assets |  |  |  |  |  |
| Building Solutions North America (6) | $ | 15,317 |  |  | $ | 15,215 |  |  | $ | 15,562 |  |
| Building Solutions EMEA/LA (7) | 5,241 |  |  | 4,989 |  |  | 4,786 |  |
| Building Solutions Asia Pacific (8) | 2,783 |  |  | 2,720 |  |  | 2,657 |  |
| Global Products (9) | 15,328 |  |  | 13,882 |  |  | 13,945 |  |
|  | 38,669 |  |  | 36,806 |  |  | 36,950 |  |
| Assets held for sale | 156 |  |  | 147 |  |  | 158 |  |
| Unallocated | 3,065 |  |  | 3,862 |  |  | 5,179 |  |
| Total | $ | 41,890 |  |  | $ | 40,815 |  |  | $ | 42,287 |  |

[0000833444-21-000046:notes:405]
|  | Year Ended September 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Depreciation/Amortization |  |  |  |  |  |
| Building Solutions North America | $ | 245 |  |  | $ | 233 |  |  | $ | 233 |  |
| Building Solutions EMEA/LA | 103 |  |  | 102 |  |  | 112 |  |
| Building Solutions Asia Pacific | 25 |  |  | 24 |  |  | 23 |  |
| Global Products | 432 |  |  | 414 |  |  | 396 |  |
|  | 805 |  |  | 773 |  |  | 764 |  |
| Corporate | 40 |  |  | 49 |  |  | 61 |  |
| Continuing Operations | 845 |  |  | 822 |  |  | 825 |  |
| Discontinued Operations | — |  |  | — |  |  | 32 |  |
| Total | $ | 845 |  |  | $ | 822 |  |  | $ | 857 |  |

[0000833444-21-000046:notes:406]
|  | Year Ended September 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Capital Expenditures |  |  |  |  |  |
| Building Solutions North America | $ | 87 |  |  | $ | 93 |  |  | $ | 119 |  |
| Building Solutions EMEA/LA | 128 |  |  | 99 |  |  | 93 |  |
| Building Solutions Asia Pacific | 31 |  |  | 36 |  |  | 26 |  |
| Global Products | 265 |  |  | 191 |  |  | 310 |  |
|  | 511 |  |  | 419 |  |  | 548 |  |
| Corporate | 41 |  |  | 24 |  |  | 38 |  |
| Continuing Operations | 552 |  |  | 443 |  |  | 586 |  |
| Discontinued Operations | — |  |  | — |  |  | 197 |  |
| Total | $ | 552 |  |  | $ | 443 |  |  | $ | 783 |  |

[0000833444-21-000046:notes:407]
(1)Building Solutions North America segment EBITA for the year ended September 30, 2021 and 2020 excludes $70 million and $520 million, respectively, of restructuring and impairment costs. For the year ended September 30, 2021, Building Solutions North America includes $5 million of equity income. For the year ended September 30, 2020, Building Solutions North America includes $1 million of equity losses.

[0000833444-21-000046:notes:408]
(2)Building Solutions EMEA/LA segment EBITA for the years ended September 30, 2021 and 2020 excludes $29 million and $59 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2021, 2020 and 2019, Building Solutions EMEA/LA segment EBITA includes $5 million, $6 million and $12 million, respectively, of equity income.

[0000833444-21-000046:notes:409]
(3)Building Solutions Asia Pacific segment EBITA for the year ended September 30, 2021 and 2020 excludes $28 million and $56 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2021, 2020 and 2019, Building Solutions Asia Pacific segment EBITA includes $1 million, less than $1 million and less than $1 million, respectively, of equity income.

[0000833444-21-000046:notes:410]
(4)Global Products segment EBITA for the years ended September 30, 2021, 2020 and 2019 excludes $91 million, $143 million and $235 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2021, 2020 and 2019, Global Products segment EBITA includes $250 million, $166 million and $179 million, respectively, of equity income.

[0000833444-21-000046:notes:411]
(5)Corporate expenses for the year ended September 30, 2021 and 2020 excludes $24 million and $5 million, respectively, of restructuring and impairment costs.

[0000833444-21-000046:notes:412]
(6)Buildings Solutions North America assets as of September 30, 2021, 2020 and 2019 include $8 million, $7 million and $8 million, respectively, of investments in partially-owned affiliates.

[0000833444-21-000046:notes:413]
(7)Building Solutions EMEA/LA assets as of September 30, 2021, 2020 and 2019 include $111 million, $108 million and $109 million, respectively, of investments in partially-owned affiliates.

[0000833444-21-000046:notes:414]
(8)Building Solutions Asia Pacific assets as of September 30, 2021, 2020 and 2019 include $2 million, $2 million, and $6 million, respectively, of investments in partially-owned affiliates.

[0000833444-21-000046:notes:415]
(9)Global Products assets as of September 30, 2021, 2020 and 2019 include $945 million, $797 million and $730 million, respectively, of investments in partially-owned affiliates.

[0000833444-21-000046:notes:416]
In fiscal years 2021, 2020 and 2019, no customer exceeded 10% of consolidated net sales.

[0000833444-21-000046:notes:417]
Geographic Segments

[0000833444-21-000046:notes:418]
Financial information relating to the Company’s operations by geographic area is as follows (in millions):

[0000833444-21-000046:notes:419]
|  | Year Ended September 30, |
|  | 2021 |  | 2020 |  | 2019 |
| Net Sales |  |  |  |  |  |
| United States | $ | 11,577 |  |  | $ | 11,371 |  |  | $ | 11,973 |  |
| Europe | 4,069 |  |  | 3,523 |  |  | 3,697 |  |
| Asia Pacific | 5,748 |  |  | 5,285 |  |  | 5,888 |  |
| Other Non-U.S. | 2,274 |  |  | 2,138 |  |  | 2,410 |  |
| Total | $ | 23,668 |  |  | $ | 22,317 |  |  | $ | 23,968 |  |
| Long-Lived Assets (Year-end) |  |  |  |  |  |
| United States | $ | 1,638 |  |  | $ | 1,713 |  |  | $ | 1,824 |  |
| Europe | 436 |  |  | 278 |  |  | 261 |  |
| Asia Pacific | 727 |  |  | 667 |  |  | 866 |  |
| Other Non-U.S. | 427 |  |  | 401 |  |  | 397 |  |
| Total | $ | 3,228 |  |  | $ | 3,059 |  |  | $ | 3,348 |  |

[0000833444-21-000046:notes:420]
In fiscal 2021, the Company changed the basis for the net sales attribution to geographic areas from the location of the assets producing the sales to the location where the sale originated to better align with the Company’s business activities. The prior year amounts have been revised to conform to the current year presentation. Long-lived assets by geographic location consist of net property, plant and equipment.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0000833444-21-000046:notes:421]
NONCONSOLIDATED PARTIALLY-OWNED AFFILIATES  Investments in the net assets of nonconsolidated partially-owned affiliates are stated in the "Investments in partially-owned affiliates" line in the consolidated statements of financial position as of September 30, 2021 and 2020. Equity in the net income of nonconsolidated partially-owned affiliates is stated in the "Equity income" line in the consolidated statements of income for the years ended September 30, 2021, 2020 and 2019.
The table below presents aggregated summarized financial data for the Company’s nonconsolidated partially-owned affiliates which were considered significant subsidiaries in fiscal 2019, but not in fiscal 2021 or 2020 due to the adoption of SEC Final Rule Release No. 33-10786. The summarized income statement data for the year ended September 30, 2019 included in the table below represents 100% of the results of such nonconsolidated partially-owned affiliates accounted for under the equity method (in millions):

[0000833444-21-000046:notes:422]
|  |  |  | Year Ended September 30, 2019 |
| Net sales |  |  | $ | 3,882 |  |  |  |
| Gross profit |  |  | 1,070 |  |  |  |
| Net income |  |  | 411 |  |  |  |
| Income attributable to noncontrolling interests |  |  | 13 |  |  |  |
| Net income attributable to the entity |  |  | 398 |  |  |  |


## us-gaap:GuaranteesTextBlock

[0000833444-21-000046:notes:423]
GUARANTEES
Certain of the Company's subsidiaries at the business segment level have guaranteed the performance of third-parties and provided financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from the current fiscal year through the completion of such transactions and would typically be triggered in the event of nonperformance. Performance under the guarantees, if required, would not have a material effect on the Company's financial position, results of operations or cash flows.

[0000833444-21-000046:notes:424]
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. A typical warranty program requires that the Company replace defective products within a specified time period from the date of sale. The Company records an estimate for future warranty-related costs based on actual historical return rates and other known factors. Based on analysis of return rates and other factors, the Company’s warranty provisions are adjusted as necessary. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different than those estimates.

[0000833444-21-000046:notes:425]
The Company’s product warranty liability for continuing operations is recorded in the consolidated statements of financial position in other current liabilities if the warranty is less than one year and in other noncurrent liabilities if the warranty extends longer than one year.

[0000833444-21-000046:notes:426]
The changes in the carrying amount of the Company’s total product warranty liability for continuing operations for the fiscal years ended September 30, 2021 and 2020 were as follows (in millions). Extended warranty for which deferred revenue is recorded is not included in the table below, but rather included within the contract balances table in the Note 4, "Revenue Recognition," of the notes to consolidated financial statements for all periods presented.

[0000833444-21-000046:notes:427]
|  | Year EndedSeptember 30, |
|  | 2021 |  | 2020 |
| Balance at beginning of period | $ | 167 |  |  | $ | 156 |  |
| Accruals for warranties issued during the period | 91 |  |  | 71 |  |
| Accruals related to pre-existing warranties | 11 |  |  | 9 |  |
| Settlements made (in cash or in kind) during the period | (77) |  |  | (71) |  |
| Currency translation | — |  |  | 2 |  |
| Balance at end of period | $ | 192 |  |  | $ | 167 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-21-000046:notes:428]
COMMITMENTS AND CONTINGENCIES
Environmental Matters

[0000833444-21-000046:notes:429]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of September 30, 2021, reserves for environmental liabilities for continuing operations totaled $102 million, of which $48 million was recorded within other current liabilities and $54 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $130 million at September 30, 2020, of which $61 million was recorded within other current liabilities and $69 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.

[0000833444-21-000046:notes:430]
Tyco Fire Products L.P. (“Tyco Fire Products”), in coordination with the Wisconsin Department of Natural Resources ("WDNR"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin. In connection with the assessment, perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluoroalkyl substances ("PFAS") have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC. Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working with WDNR to address these issues insofar as they related to this migration.

[0000833444-21-000046:notes:431]
During the third quarter of 2019, the Company increased its environmental reserves, which included $140 million related to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The Company is not able to estimate a possible loss or range of loss in excess of the established accruals at this time.

[0000833444-21-000046:notes:432]
A substantial portion of the increased reserves relates to remediation resulting from the use of fire-fighting foams containing PFAS at the FTC. The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The reserve was recorded in the quarter ended June 30, 2019 following a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR.

[0000833444-21-000046:notes:433]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. On August 22, 2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation. On November 6, 2020, WDNR received further recommendations from WDHS regarding individual standards for 12 additional PFAS and a combined standard for four additional PFAS, PFOA, and PFOS.

[0000833444-21-000046:notes:434]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. Tyco Fire Products voluntarily responded to the WDNR’s letter to request additional necessary information. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 3, 2019 letter. The letter stated that “if you fail to take the actions required by Wis. Stat. § 292.11 to address this contamination, the DNR will move forward under Wis. Stat. § 292.31 to implement the SI workplan and evaluate further environmental enforcement actions and cost recovery under Wis. Stat. § 292.31(8).” The WDNR issued a further letter regarding the issue on November 4, 2019. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to date. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

[0000833444-21-000046:notes:435]
In May 2021, as part of Tyco Fire Products’ ongoing investigation and remediation program, WDNR approved Tyco Fire Products’ proposed Groundwater Extraction and Treatment System (“GETS”), a permanent groundwater remediation system that will extract groundwater that contains PFAS, treat it using advanced filtration systems, and return the treated water to the

[0000833444-21-000046:notes:436]
environment. Tyco Fire Products has commenced construction on the GETS. Tyco Fire Products also has started the process of removing PFAS-affected soil from the FTC.

[0000833444-21-000046:notes:437]
In December 2020, the Company received a notice from the Wisconsin Department of Justice (“WDOJ”) that the WDOJ was considering a potential civil enforcement action against the Company relating to environmental matters at the FTC including, but not limited to, the investigation and remediation of PFAS at or near the FTC as discussed above and the Company’s alleged failure to timely report the presence of PFAS chemicals at the FTC. Such enforcement action could seek civil monetary penalties and/or injunctive relief. The Company is presently unable to predict the duration, scope, or results of any potential civil enforcement action that may result, the consequences of any such action, or the nature of any resolution of these potential claims with the WDOJ.

[0000833444-21-000046:notes:438]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”) manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. The increase in the reserve related to the Stanton Street Facility in the third quarter of 2019 was recorded following a further review of the Consent Order, which resulted in the identification of several structural upgrades needed to preserve the effectiveness of prior remediation efforts. In addition to ongoing remediation activities, the Company is also working with the WDNR to investigate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation of PFAS in the Marinette region.

[0000833444-21-000046:notes:439]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. The Company recorded conditional asset retirement obligations for continuing operations of $29 million at both September 30, 2021 and 2020.

[0000833444-21-000046:notes:440]
Asbestos Matters

[0000833444-21-000046:notes:441]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-21-000046:notes:442]
As of September 30, 2021, the Company's estimated asbestos-related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $80 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $458 million, of which $58 million was recorded in other current liabilities and $400 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $378 million, of which $13 million was recorded in other current assets and $365 million was recorded in other noncurrent assets. Assets included $6 million of cash and $314 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2021 was $58 million.

[0000833444-21-000046:notes:443]
As of September 30, 2020, the Company's estimated asbestos-related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $115 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $483 million, of which $49 million was recorded in other current liabilities and $434 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $368 million, of which $39 million was recorded in other current assets and $329 million was recorded in other noncurrent assets. Assets included $9 million of cash and $291 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2020 was $68 million.

[0000833444-21-000046:notes:444]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos- related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-21-000046:notes:445]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-21-000046:notes:446]
Insurable Liabilities

[0000833444-21-000046:notes:447]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At September 30, 2021 and 2020, the insurable liabilities totaled $325 million and $363 million, respectively, of which $77 million and $83 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $226 million and $258 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at September 30, 2021 were $20 million, of which $5 million was recorded within other current assets and $15 million was recorded within other noncurrent assets, respectively. The amount of such receivables recorded at September 30, 2020 were $21 million, of which $5 million was recorded within other current assets and $16 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-21-000046:notes:448]
Aqueous Film-Forming Foam ("AFFF") Litigation

[0000833444-21-000046:notes:449]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard

[0000833444-21-000046:notes:450]
and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-21-000046:notes:451]
PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but had initially stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. The EPA also announced in January 2021 that it will issue an advance notice of proposed rulemaking to solicit public comment on whether the agency should take additional regulatory steps to address PFAS contamination, including designating PFOA and PFOS and other PFAS as hazardous substances under the Comprehensive Environmental Response, Compensation, and Liability Act and seeking comment on whether PFOA and PFOS and other PFAS should be subject to regulation as hazardous waste under the Resource Conservation and Recovery Act. The Agency reissued those actions in February 2021. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

[0000833444-21-000046:notes:452]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to or are being directly filed in the MDL.

[0000833444-21-000046:notes:453]
AFFF Putative Class Actions

[0000833444-21-000046:notes:454]
Chemguard and Tyco Fire Products are named in 32 putative class actions in federal courts originating from Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington, New Hampshire, South Carolina, the District of Columbia, Guam, West Virginia, Michigan, Texas and South Dakota. All of these cases except one have been direct-filed in or transferred to the MDL.

[0000833444-21-000046:notes:455]
AFFF Individual or Mass Actions

[0000833444-21-000046:notes:456]
There are more than 1,700 individual or “mass” actions pending that were filed in state or federal court in various states including California, Colorado, New York, Pennsylvania, New Mexico, Missouri, Arizona, Texas, and South Carolina against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 1,700 other plaintiffs. All but fourteen of these matters have been transferred to or directly-filed in the MDL: One case filed in federal court in West Virginia has been tagged for transfer to the MDL. Two cases initially filed in state court in Alaska have been removed to federal court and tagged for transfer to the MDL. Nine cases have recently been filed in state court in New York, and it is anticipated that they will be removed to federal court and transferred to the MDL. One case, Young v. Chemguard et al., was filed in superior court in Maricopa County, Arizona, removed to the United States District Court, District of Arizona, and tagged to the MDL, but was remanded to state court prior to being transferred to the MDL. The decision to remand the case to state court is currently being appealed. The final case, Forbach et al. v. Chemguard et al., was filed in superior court in Coconino County, Arizona, and is proceeding to initial discovery.

[0000833444-21-000046:notes:457]
Many of the additional filed actions were directly filed in South Carolina by plaintiffs who were among the 660 plaintiffs the Company had previously disclosed to have made filings in Pennsylvania state court.

[0000833444-21-000046:notes:458]
AFFF Municipal Cases

[0000833444-21-000046:notes:459]
Chemguard and Tyco Fire Products have been named as defendants in approximately 144 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Alabama, Arizona, California, Colorado, Connecticut, Florida, Idaho, Illinois, Kentucky, Louisiana, Maryland, Massachusetts, Michigan, New Jersey, New York, North Carolina, Ohio, Pennsylvania, Virginia, Washington, West Virginia, Wisconsin, the District of Columbia, and several municipalities or water providers from various states who direct-filed complaints in South Carolina. All but nine of these cases have been transferred to or directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.

[0000833444-21-000046:notes:460]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly resulting from the use of those products at the Peterson Air Force Base.

[0000833444-21-000046:notes:461]
State or U.S. Territory Attorneys General Litigation related to AFFF

[0000833444-21-000046:notes:462]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-21-000046:notes:463]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-21-000046:notes:464]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. The 3M Company et al., No. G-4801-CI-021804752-000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio. The lawsuit seeks to recover costs and natural resource damages associated with the contamination. This lawsuit has been removed to the United States District Court for the Northern District of Ohio and transferred to the MDL.

[0000833444-21-000046:notes:465]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.). All three of these suits have been removed to federal court and transferred to the MDL.

[0000833444-21-000046:notes:466]
In September 2019, the government of Guam filed a lawsuit in the superior court of Guam against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-21-000046:notes:467]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-21-000046:notes:468]
In August 2020, Attorney General of the State of Michigan filed two substantially similar lawsuits—one in federal court and one in state court—against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within the State.  The federal action has been transferred to the MDL, and the state court action has been removed to federal court and transferred to the MDL.

[0000833444-21-000046:notes:469]
In December 2020, the State of Mississippi filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. This complaint was direct-filed in the MDL in South Carolina.

[0000833444-21-000046:notes:470]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. The State’s case has been removed to federal court and transferred to the MDL. The State of Alaska has also named a number of manufacturers and other defendants, including affiliates of the Company, as third-party defendants in two cases brought by individuals against the State. These two cases have been removed to federal court and tagged for transfer to the MDL.

[0000833444-21-000046:notes:471]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. It is anticipated that these four cases will be removed to federal court and tagged for transfer to the MDL.

[0000833444-21-000046:notes:472]
AFFF Matters Related to the Tyco Fire Products Fire Technology Center in Marinette, Wisconsin

[0000833444-21-000046:notes:473]
Tyco Fire Products and Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFAS (including PFOA/PFOS) contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. On January 7, 2021, the parties agreed to settle the lawsuit. The court conducted a hearing regarding the proposed settlement in May 2021 and issued a final order approving an amended settlement agreement and dismissing the case with prejudice in August 2021. The final settlement provides that Tyco will pay up to $15 million to compensate Town of Peshtigo residents who live in the area affected by PFAS from the FTC for claims related to loss of real property value and/or exposure. The settlement does not constitute an admission of wrongdoing by Tyco or Chemguard.

[0000833444-21-000046:notes:474]
Other AFFF Related Matters

[0000833444-21-000046:notes:475]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

[0000833444-21-000046:notes:476]
The Company is vigorously defending the above matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications.  Tyco and Chemguard have insurance that has been in place for many years and the Company is pursuing this coverage for these matters. However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.
Other Matters The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-21-000046:notes:477]
RELATED PARTY TRANSACTIONS
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-21-000046:notes:478]
The following table presents net sales to and purchases from related parties for the years ended September 30, 2021, 2020 and 2019 (in millions):

[0000833444-21-000046:notes:479]
|  |  | Year Ended September 30, |
|  |  | 2021 |  | 2020 |  | 2019 |
| Net sales to related parties |  | $ | 185 |  |  | $ | 194 |  |  | $ | 217 |  |
| Purchases from related parties |  | 185 |  |  | 85 |  |  | 66 |  |

[0000833444-21-000046:notes:480]
The following table presents receivables from and payables to related parties in the consolidated statements of financial position (in millions):

[0000833444-21-000046:notes:481]
|  |  | September 30, |
|  |  | 2021 |  | 2020 |
| Receivable from related parties |  | $ | 73 |  |  | $ | 48 |  |
| Payable to related parties |  | 45 |  |  | 11 |  |

[0000833444-21-000046:notes:482]
Additionally, the Company leases certain facilities used in its operations from a related party. As of September 30, 2021, the right-of-use asset associated with these leases was $11 million and the lease liability was $10 million. Amounts paid for these leases were not material.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000833444-21-000046:notes:483]
JOHNSON CONTROLS INTERNATIONAL PLC AND SUBSIDIARIES

[0000833444-21-000046:notes:484]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0000833444-21-000046:notes:485]
(In millions)

[0000833444-21-000046:notes:486]
| Year Ended September 30, | 2021 |  | 2020 |  | 2019 |
| Accounts Receivable - Allowance for Expected Credit Losses (1) |  |  |  |  |  |
| Balance at beginning of period | $ | 173 |  |  | $ | 173 |  |  | $ | 169 |  |
| Provision (income) charged to costs and expenses | (3) |  |  | 20 |  |  | 37 |  |
| Accounts charged off, net of recoveries | (65) |  |  | (21) |  |  | (21) |  |
| Divestiture of businesses | — |  |  | — |  |  | (10) |  |
| Currency translation | 1 |  |  | 1 |  |  | (2) |  |
| Other (including impact of adoption of ASU 2016-13) | 4 |  |  | — |  |  | — |  |
| Balance at end of period | $ | 110 |  |  | $ | 173 |  |  | $ | 173 |  |
| Deferred Tax Assets - Valuation Allowance |  |  |  |  |  |
| Balance at beginning of period | $ | 5,518 |  |  | $ | 5,068 |  |  | $ | 5,088 |  |
| Allowance provision for new operating and other loss carryforwards | 505 |  |  | 624 |  |  | 195 |  |
| Allowance provision (benefits) | (170) |  |  | (174) |  |  | (215) |  |
| Balance at end of period | $ | 5,853 |  |  | $ | 5,518 |  |  | $ | 5,068 |  |

[0000833444-21-000046:notes:487]
(1) Allowance for doubtful accounts as of September 30, 2020 and 2019, prior to the adoption of ASU 2016-13.
