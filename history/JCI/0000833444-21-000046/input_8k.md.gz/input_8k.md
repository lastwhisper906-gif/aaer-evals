# JCI 8-K — 0000833444-21-000043 filed 2021-11-05

## item codes, every 8-K on or before 2021-11-15

- 2021-11-05 0000833444-21-000043 — 2.02, 9.01
- 2021-09-16 0001193125-21-275152 — 1.01, 8.01, 9.01
- 2021-07-30 0000833444-21-000038 — 2.02, 9.01
- 2021-05-03 0000833444-21-000023 — 8.01
- 2021-04-30 0000833444-21-000017 — 2.02, 9.01
- 2021-03-11 0000833444-21-000013 — 5.02, 5.07, 9.01
- 2021-02-17 0001193125-21-045768 — 7.01, 9.01
- 2021-01-29 0000833444-21-000009 — 2.02, 9.01
- 2021-01-07 0000833444-21-000004 — 7.01
- 2020-11-03 0000833444-20-000043 — 2.02, 9.01
- 2020-09-15 0001193125-20-246240 — 1.01, 8.01, 9.01
- 2020-09-11 0001193125-20-244119 — 1.01, 8.01, 9.01
- 2020-08-18 0000833444-20-000038 — 5.02, 9.01
- 2020-07-31 0000833444-20-000034 — 2.02, 9.01
- 2020-06-12 0000833444-20-000020 — 8.01
- 2020-05-01 0000833444-20-000013 — 2.02, 9.01
- 2020-03-12 0000833444-20-000010 — 5.02
- 2020-03-06 0000833444-20-000008 — 5.07
- 2020-01-31 0000833444-20-000003 — 2.02, 9.01
- 2019-12-06 0001193125-19-308301 — 1.01, 1.02, 2.03, 9.01
- 2019-11-07 0000833444-19-000048 — 5.02, 9.01
- 2019-11-07 0000833444-19-000046 — 2.02, 9.01
- 2019-08-21 0000833444-19-000043 — 8.01
- 2019-07-31 0000833444-19-000038 — 2.02, 9.01
- 2019-07-23 0000833444-19-000035 — 5.02, 8.01, 9.01
- 2019-07-02 0000833444-19-000033 — 1.02, 8.01
- 2019-06-05 0001193125-19-165565 — 8.01
- 2019-05-30 0001193125-19-160205 — 8.01, 9.01
- 2019-05-16 0001193125-19-148262 — 8.01, 9.01
- 2019-05-07 0001193125-19-139826 — 5.04, 9.01
- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2021-11-15

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-21-000043:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq4fy21.htm
EX-99.1

[0000833444-21-000043:8k_2_02:2]
Document

[0000833444-21-000043:8k_2_02:3]
Exhibit 99.1

[0000833444-21-000043:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-21-000043:8k_2_02:5]
Johnson Controls reports solid fourth quarter and full year results; Initiates FY22 guidance

[0000833444-21-000043:8k_2_02:6]
________________________________________________________________________________

[0000833444-21-000043:8k_2_02:7]
▪Q4 GAAP EPS of $0.38; Adjusted EPS of $0.88, up 16% versus prior year; full year GAAP EPS of $2.10; Adjusted EPS of $2.65, up 18% versus prior year

[0000833444-21-000043:8k_2_02:8]
▪Reported Q4 sales +7% versus prior year; +5% organic

[0000833444-21-000043:8k_2_02:9]
▪Q4 Orders +9% year-over-year, with strong underlying momentum; Backlog of $10.1 billion increased 10% organically year-over-year

[0000833444-21-000043:8k_2_02:10]
▪Q4 and full year cash provided by operating activities of $0.5 billion and $2.6 billion, respectively; Q4 and full year adjusted free cash flow of $0.3 billion and $2.0 billion, respectively, representing 105% conversion for the year

[0000833444-21-000043:8k_2_02:11]
▪Completed approximately $300 million of planned share repurchases in Q4; $1.3 billion for full year

[0000833444-21-000043:8k_2_02:12]
▪Initiates fiscal 2022 adjusted EPS guidance of $3.22 to $3.32, an increase of 22 to 25% year-over-year; fiscal Q1 adjusted EPS guided to $0.52 to $0.54, an increase of 21 to 26% year-over-year

[0000833444-21-000043:8k_2_02:13]
________________________________________________________________________________

[0000833444-21-000043:8k_2_02:14]
CORK, Ireland, November 5, 2021 -- Johnson Controls International plc (NYSE: JCI), the global leader for smart, healthy and sustainable buildings, today reported fiscal fourth quarter 2021 GAAP earnings per share (“EPS”) from continuing operations, including special items, of $0.38. Excluding these items, adjusted EPS from continuing operations was $0.88, up 16% versus the prior year period (see attached footnotes for non-GAAP reconciliation).

[0000833444-21-000043:8k_2_02:15]
Sales of $6.4 billion increased 7% compared to the prior year on an as reported basis, and up 5% organically. GAAP net income from continuing operations was $269 million. Adjusted net income from continuing operations of $628 million increased 12% versus the prior year. Earnings before interest and taxes (“EBIT”) was $853 million and EBIT margin was 13.3%. Adjusted EBIT was $827 million and adjusted EBIT margin was 12.9%, consistent with prior year results.

[0000833444-21-000043:8k_2_02:16]
“Fiscal 2021 was a pivotal year in the transformation of Johnson Controls, from a traditional buildings systems integrator into a smart buildings solutions leader,” said George Oliver, chairman and CEO. “Our teams navigated an incredibly challenging environment, delivering solid financial performance while continuing to advance our strategic commitments,” Oliver continued.

[0000833444-21-000043:8k_2_02:17]
“Although supply chain disruptions and inflation headwinds are expected to continue near term, I am excited and encouraged by the pace of demand in many of our end markets and our record backlogs, both of which position us well for fiscal 2022. Looking ahead, we are intensifying our focus on accelerating our growth capabilities, leveraging innovative technologies, driving higher attachment of recurring services and capitalizing on our vectors of growth. Our OpenBlue digital platform is transforming our engagement with customers, and our ability to address arguably the most-pressing issues in buildings history – net zero carbon emissions and healthy environments. In addition, our cost programs are well underway and will help to boost profitability as conditions normalize,” Oliver added.

[0000833444-21-000043:8k_2_02:18]
Page 1 of 18

[0000833444-21-000043:8k_2_02:19]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-21-000043:8k_2_02:20]
($ millions, except per-share amounts)

[0000833444-21-000043:8k_2_02:21]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the fourth fiscal quarter and full fiscal year of 2020.

[0000833444-21-000043:8k_2_02:22]
Organic sales, adjusted sales, total segment EBITA, adjusted segment EBITA, adjusted corporate expense, EBIT, adjusted EBIT, adjusted net income from continuing operations, adjusted EPS from continuing operations, free cash flow and free cash flow conversion are non-GAAP financial measures. For a reconciliation of these non-GAAP measures and detail of the special items, refer to the attached footnotes. A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-21-000043:8k_2_02:23]
|  | Fiscal Q4 |  |  | Fiscal Year |
|  | GAAP | Adjusted |  |  | GAAP | Adjusted |
|  | 2020 | 2021 | 2020 | 2021 |  |  | 2020 | 2021 | 2020 | 2021 |
| Sales | $5,954 | $6,392 | $5,954 | $6,395 |  |  | $22,317 | $23,668 | $22,317 | $23,674 |
| Segment EBITA | 869 | 1,012 | 926 | 1,018 |  |  | 2,948 | 3,385 | 3,020 | 3,398 |
| EBIT | 583 | 853 | 770 | 827 |  |  | 1,134 | 2,820 | 2,365 | 2,683 |
| Net income fromcontinuing operations | 441 | 269 | 563 | 628 |  |  | 631 | 1,513 | 1,688 | 1,910 |
| Diluted EPS fromcontinuing operations | $0.60 | $0.38 | $0.76 | $0.88 |  |  | $0.84 | $2.10 | $2.24 | $2.65 |

[0000833444-21-000043:8k_2_02:24]
Page 2 of 18

[0000833444-21-000043:8k_2_02:25]
SEGMENT RESULTS

[0000833444-21-000043:8k_2_02:26]
Building Solutions North America

[0000833444-21-000043:8k_2_02:27]
|  | Fiscal Q4 |  | Fiscal Year |
|  | GAAP | Adjusted |  | GAAP | Adjusted |
|  | 2020 | 2021 | 2020 | 2021 |  | 2020 | 2021 | 2020 | 2021 |
| Sales | $2,243 | $2,347 | $2,243 | $2,347 |  | $8,605 | $8,685 | $8,605 | $8,685 |
| Segment EBITA | 341 | 357 | 345 | 357 |  | 1,157 | 1,204 | 1,168 | 1,204 |
| Segment EBITA Margin % | 15.2% | 15.2% | 15.4% | 15.2% |  | 13.4% | 13.9% | 13.6% | 13.9% |

[0000833444-21-000043:8k_2_02:28]
Sales in the quarter of $2.3 billion increased 5% versus the prior year. Organic sales increased 4% over the prior year, led by high-single digit growth in Service with solid growth across HVAC & Controls, Fire & Security and Performance Infrastructure.

[0000833444-21-000043:8k_2_02:29]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 11% year-over-year. Backlog at the end of the quarter of $6.5 billion increased 10% compared to the prior year, excluding M&A and adjusted for foreign currency.

[0000833444-21-000043:8k_2_02:30]
Adjusted segment EBITA was $357 million, up 3% versus the prior year. Adjusted segment EBITA margin of 15.2% declined 20 basis points versus the prior year as the benefit of volume leverage, favorable mix and the SG&A actions taken this year were more than offset by the non-recurrence of the temporary cost mitigation actions taken in the prior year.

[0000833444-21-000043:8k_2_02:31]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-21-000043:8k_2_02:32]
|  | Fiscal Q4 |  | Fiscal Year |
|  | GAAP | Adjusted |  | GAAP | Adjusted |
|  | 2020 | 2021 | 2020 | 2021 |  | 2020 | 2021 | 2020 | 2021 |
| Sales | $906 | $962 | $906 | $962 |  | $3,440 | $3,727 | $3,440 | $3,727 |
| Segment EBITA | 101 | 107 | 103 | 107 |  | 338 | 391 | 340 | 391 |
| Segment EBITA Margin % | 11.1% | 11.1% | 11.4% | 11.1% |  | 9.8% | 10.5% | 9.9% | 10.5% |

[0000833444-21-000043:8k_2_02:33]
Sales in the quarter of $962 million increased 6% versus the prior year. Organic sales grew 3% versus the prior year led by continued strong demand in Service activity. Growth was  led by Fire & Security and

[0000833444-21-000043:8k_2_02:34]
Page 3 of 18

[0000833444-21-000043:8k_2_02:35]
Industrial Refrigeration. By region, Europe and Latin America experienced strong growth while the Middle East remained under pressure.

[0000833444-21-000043:8k_2_02:36]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 7% year-over-year. Backlog at the end of the quarter of $1.9 billion increased 15% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-21-000043:8k_2_02:37]
Adjusted segment EBITA was $107 million, up 4% versus the prior year. Adjusted segment EBITA margin of 11.1% declined 30 basis points over the prior year, as the prior year included the favorable benefit related to a gain on sale.  Excluding this benefit, the underlying margin performance improved year-over-year as favorable mix and the SG&A actions taken this year more than offset the non-recurrence of the other temporary cost mitigation actions taken in the prior year.

[0000833444-21-000043:8k_2_02:38]
Building Solutions Asia Pacific

[0000833444-21-000043:8k_2_02:39]
|  | Fiscal Q4 |  | Fiscal Year |
|  | GAAP | Adjusted |  | GAAP | Adjusted |
|  | 2020 | 2021 | 2020 | 2021 |  | 2020 | 2021 | 2020 | 2021 |
| Sales | $661 | $724 | $661 | $724 |  | $2,403 | $2,654 | $2,403 | $2,654 |
| Segment EBITA | 90 | 112 | 97 | 112 |  | 319 | 349 | 326 | 349 |
| Segment EBITA Margin % | 13.6% | 15.5% | 14.7% | 15.5% |  | 13.3% | 13.1% | 13.6% | 13.1% |

[0000833444-21-000043:8k_2_02:40]
Sales in the quarter of $724 million increased 10% versus the prior year. Organic sales grew 7% versus the prior year with solid growth in both service and project installations, driven by strong growth in Commercial Applied HVAC & Controls. China remains the primary source of growth, with the rest of Asia mixed due to ongoing lockdown restrictions in many regions.

[0000833444-21-000043:8k_2_02:41]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 4% year-over-year. Backlog at the end of the quarter of $1.8 billion increased 4% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-21-000043:8k_2_02:42]
Adjusted segment EBITA was $112 million, increased 15% versus the prior year. Adjusted segment EBITA margin of 15.5% expanded 80 basis points versus the prior year driven by a favorable reserve adjustment. Excluding this benefit, underlying margin was down year-over-year as volume leverage and net productivity was offset by unfavorable mix and price / cost.

[0000833444-21-000043:8k_2_02:43]
Page 4 of 18

[0000833444-21-000043:8k_2_02:44]
Global Products

[0000833444-21-000043:8k_2_02:45]
|  | Fiscal Q4 |  | Fiscal Year |
|  | GAAP | Adjusted |  | GAAP | Adjusted |
|  | 2020 | 2021 | 2020 | 2021 |  | 2020 | 2021 | 2020 | 2021 |
| Sales | $2,144 | $2,359 | $2,144 | $2,362 |  | $7,869 | $8,602 | $7,869 | $8,608 |
| Segment EBITA | 337 | 436 | 381 | 442 |  | 1,134 | 1,441 | 1,186 | 1,454 |
| Segment EBITA Margin % | 15.7% | 18.5% | 17.8% | 18.7% |  | 14.4% | 16.8% | 15.1% | 16.9% |

[0000833444-21-000043:8k_2_02:46]
Sales in the quarter of $2.4 billion increased 10% versus the prior year. Organic sales grew 7% versus the prior year driven by strong growth across Commercial and Residential HVAC and Fire & Security products.

[0000833444-21-000043:8k_2_02:47]
Adjusted segment EBITA was $442 million, up 16% versus the prior year. Adjusted segment EBITA margin of 18.7% expanded 90 basis points versus the prior year as volume leverage, positive mix, increased equity income and the benefit of SG&A actions taken this year more than offset the non-recurrence of the temporary cost mitigation actions taken in the prior year as well as price cost pressure.

[0000833444-21-000043:8k_2_02:48]
Corporate

[0000833444-21-000043:8k_2_02:49]
|  | Fiscal Q4 |  | Fiscal Year |
|  | GAAP | Adjusted |  | GAAP | Adjusted |
|  | 2020 | 2021 | 2020 | 2021 |  | 2020 | 2021 | 2020 | 2021 |
| Corporate Expense | ($68) | ($83) | ($58) | ($83) |  | ($371) | ($290) | ($269) | ($290) |

[0000833444-21-000043:8k_2_02:50]
Adjusted Corporate expense was $83 million in the quarter, an increase of 43% compared to the prior  year, driven primarily by the non-recurrence of the temporary cost mitigation actions taken in the prior year.

[0000833444-21-000043:8k_2_02:51]
OTHER ITEMS

[0000833444-21-000043:8k_2_02:52]
▪For the quarter, cash provided by operating activities from continuing operations was $0.5 billion and capital expenditures were $0.2 billion, resulting in free cash flow from continuing operations of $0.3 billion.

[0000833444-21-000043:8k_2_02:53]
▪For the full year, cash provided by operating activities from continuing operations was $2.6 billion and capital expenditures were $0.6 billion, resulting in free cash flow from continuing operations of $2.0 billion, representing 105% conversion.

[0000833444-21-000043:8k_2_02:54]
Page 5 of 18

[0000833444-21-000043:8k_2_02:55]
▪During the quarter, the Company repurchased approximately 4.2 million shares for $306 million.  For the full year, the Company repurchased 23.5 million shares for $1.3 billion.

[0000833444-21-000043:8k_2_02:56]
▪In September, the Company established an integrated sustainable finance framework and issued its first sustainability-linked bond that align with greenhouse gas emissions reduction targets, issuing $500 million in ten-year senior notes.

[0000833444-21-000043:8k_2_02:57]
▪During the quarter, the Company recorded a tax charge of $417 million related to the tax impacts of an intra-entity sale of certain of the Company’s intellectual property as well as a tax benefit of $39 million related to valuation allowance adjustments.

[0000833444-21-000043:8k_2_02:58]
▪During the quarter, the Company recorded net pre-tax mark-to-market gains of $106 million related primarily to the remeasurement of the Company’s pension and postretirement benefit plans.

[0000833444-21-000043:8k_2_02:59]
▪During the quarter, the Company recorded pre-tax restructuring and impairment costs of $67 million and acquisition related charges of $13 million.

[0000833444-21-000043:8k_2_02:60]
FIRST QUARTER GUIDANCE

[0000833444-21-000043:8k_2_02:61]
The Company announced fiscal 2022 first quarter guidance:

[0000833444-21-000043:8k_2_02:62]
▪Organic revenue up mid-single digits year-over-year

[0000833444-21-000043:8k_2_02:63]
▪Adjusted segment EBITA margin expansion of 40 to 50 basis points, year-over-year

[0000833444-21-000043:8k_2_02:64]
▪Adjusted EPS before special items of $0.52 to $0.54; represents 21 to 26% growth year-over-year

[0000833444-21-000043:8k_2_02:65]
FULL YEAR GUIDANCE

[0000833444-21-000043:8k_2_02:66]
The Company initiated fiscal 2022 full year guidance:

[0000833444-21-000043:8k_2_02:67]
▪Organic revenue growth of mid-to-high single digits year-over-year

[0000833444-21-000043:8k_2_02:68]
▪Adjusted segment EBITA margin expansion of 70 to 80 basis points, year-over-year

[0000833444-21-000043:8k_2_02:69]
▪Adjusted EPS before special items of $3.22 to $3.32; represents 22 to 25% growth year-over-year

[0000833444-21-000043:8k_2_02:70]
CONFERENCE CALL & WEBCAST INFO

[0000833444-21-000043:8k_2_02:71]
Johnson Controls will host a conference call to discuss this quarter’s results at 8:30 a.m. ET today, which can be accessed by dialing 888-324-9610 (in the United States) or 630-395-0255 (outside the United States), or via webcast. The passcode is “Johnson Controls”. A slide presentation will accompany the prepared remarks and has been posted on the investor relations section of the Johnson Controls website at https://investors.johnsoncontrols.com/news-and-events/events-and-presentations. A replay will be made available approximately two hours following the conclusion of the conference call.

[0000833444-21-000043:8k_2_02:72]
Page 6 of 18

[0000833444-21-000043:8k_2_02:73]
About Johnson Controls:

[0000833444-21-000043:8k_2_02:74]
At Johnson Controls (NYSE:JCI) we transform the environments where people live, work, learn and play. As the global leader in smart, healthy and sustainable buildings, our mission is to reimagine the performance of buildings to serve people, places and the planet.

[0000833444-21-000043:8k_2_02:75]
With a history of more than 135 years of innovation, Johnson Controls delivers the blueprint of the future for industries such as healthcare, schools, data centers, airports, stadiums, manufacturing and beyond through its comprehensive digital offering OpenBlue. With a global team of 100,000 experts in more than 150 countries, Johnson Controls offers the world`s largest portfolio of building technology, software as well as service solutions with some of the most trusted names in the industry. For more information, visit www.johnsoncontrols.com or follow us @johnsoncontrols on Twitter.

[0000833444-21-000043:8k_2_02:76]
JOHNSON CONTROLS CONTACTS:

[0000833444-21-000043:8k_2_02:77]
| INVESTOR CONTACTS: | MEDIA CONTACTS: |  |  |  |
| Antonella Franzen | Chaz Bickers |  |  |  |
| Direct: 609.720.4665 | Direct: 224.307.0655 |  |  |  |
| Email: antonella.franzen@jci.com | Email: charles.norman.bickers@jci.com |  |  |  |
| Ryan Edelman |  |  |  |  |
| Direct: 609.720.4545 |  |  |  |  |
| Email: ryan.edelman@jci.com |  |  |  |  |

[0000833444-21-000043:8k_2_02:78]
###

[0000833444-21-000043:8k_2_02:79]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-21-000043:8k_2_02:80]
Page 7 of 18

[0000833444-21-000043:8k_2_02:81]
developments, such as the COVID-19 pandemic; the strength of the U.S. or other economies; changes or uncertainty in laws, regulations, rates, policies or interpretations that impact Johnson Controls’ business operations or tax status; the ability to develop or acquire new products and technologies that achieve market acceptance and meet applicable regulatory requirements; changes to laws or policies governing foreign trade, including increased tariffs or trade restrictions; maintaining the capacity, reliability and security of Johnson Controls’ enterprise information technology infrastructure; the ability to manage the lifecycle cybersecurity risk in the development, deployment and operation of Johnson Controls’ digital platforms and services; the risk of infringement or expiration of intellectual property rights; any delay or inability of Johnson Controls to realize the expected benefits and synergies of recent portfolio transactions; the outcome of litigation and governmental proceedings; the ability to hire and retain senior management and other key personnel; the tax treatment of recent portfolio transactions; significant transaction costs and/or unknown liabilities associated with such transactions; fluctuations in currency exchange rates; labor shortages, work stoppages, union negotiations, labor disputes and other matters associated with the labor force; and the cancellation of or changes to commercial arrangements. A detailed discussion of risks related to Johnson Controls’ business is included in the section entitled “Risk Factors” in Johnson Controls’ Annual Report on Form 10-K for the 2020 fiscal year filed with the SEC on November 16, 2020, which is available at www.sec.gov and www.johnsoncontrols.com under the “Investors” tab. Shareholders, potential investors and others should consider these factors in evaluating the forward-looking statements and should not place undue reliance on such statements. The forward-looking statements included in this communication are made only as of the date of this document, unless otherwise specified, and, except as required by law, Johnson Controls assumes no obligation, and disclaims any obligation, to update such statements to reflect events or circumstances occurring after the date of this communication.

[0000833444-21-000043:8k_2_02:82]
###

[0000833444-21-000043:8k_2_02:83]
Non-GAAP Financial Information

[0000833444-21-000043:8k_2_02:84]
This press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include restructuring and impairment costs, integration costs, an acquisition related compensation charge, net mark-to-market adjustments, Silent-Aire transaction costs and other nonrecurring costs, Power Solutions divestiture reserve adjustment and discrete tax items. Financial information regarding organic sales, adjusted sales, EBIT, EBIT margin, adjusted EBIT, adjusted EBIT margin, total segment EBITA, adjusted segment EBITA, adjusted segment EBITA margin, adjusted corporate expense, free cash flow, free cash flow conversion and adjusted net income from continuing operations are also presented, which are non-GAAP performance measures. Adjusted segment EBITA excludes special items such as integration costs, an acquisition related compensation charge, Silent-Aire transaction costs and other nonrecurring costs because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.  For further information on the calculation of the non-GAAP measures and a reconciliation of these non-GAAP measures, refer to the attached footnotes.

[0000833444-21-000043:8k_2_02:85]
###

[0000833444-21-000043:8k_2_02:86]
Page 8 of 18

[0000833444-21-000043:8k_2_02:87]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |  |
|  |  | Three Months Ended September 30, |  |
|  |  | 2021 |  |  | 2020 |  |
| Net sales | $ | 6,392 |  |  |  | $ | 5,954 |  |  |
| Cost of sales | 4,201 |  |  |  | 3,979 |  |  |
|  | Gross profit | 2,191 |  |  |  | 1,975 |  |  |
| Selling, general and administrative expenses | (1,344) |  |  |  | (1,453) |  |  |
| Restructuring and impairment costs | (67) |  |  |  | — |  |  |
| Net financing charges | (47) |  |  |  | (62) |  |  |
| Equity income | 73 |  |  |  | 61 |  |  |
| Income from continuing operations before income taxes | 806 |  |  |  | 521 |  |  |
| Income tax provision | 490 |  |  |  | 31 |  |  |
| Income from continuing operations | 316 |  |  |  | 490 |  |  |
| Income from discontinued operations, net of tax | — |  |  |  | — |  |  |
| Net income | 316 |  |  |  | 490 |  |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 47 |  |  |  | 49 |  |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | — |  |  |
| Net income attributable to JCI | $ | 269 |  |  |  | $ | 441 |  |  |
| Income from continuing operations | $ | 269 |  |  |  | $ | 441 |  |  |
| Income from discontinued operations | — |  |  |  | — |  |  |
| Net income attributable to JCI | $ | 269 |  |  |  | $ | 441 |  |  |
| Diluted earnings per share from continuing operations | $ | 0.38 |  |  |  | $ | 0.60 |  |  |
| Diluted earnings per share from discontinued operations | — |  |  |  | — |  |  |
| Diluted earnings per share | $ | 0.38 |  |  |  | $ | 0.60 |  |  |
| Diluted weighted average shares | 717.0 |  |  |  | 738.1 |  |  |
| Shares outstanding at period end | 708.7 |  |  |  | 726.2 |  |  |

[0000833444-21-000043:8k_2_02:88]
Page 9 of 18

[0000833444-21-000043:8k_2_02:89]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Twelve Months Ended September 30, |
|  |  | 2021 |  |  | 2020 |
| Net sales | $ | 23,668 |  |  |  | $ | 22,317 |  |
| Cost of sales | 15,609 |  |  |  | 14,906 |  |
|  | Gross profit | 8,059 |  |  |  | 7,411 |  |
| Selling, general and administrative expenses | (5,258) |  |  |  | (5,665) |  |
| Restructuring and impairment costs | (242) |  |  |  | (783) |  |
| Net financing charges | (206) |  |  |  | (231) |  |
| Equity income | 261 |  |  |  | 171 |  |
| Income from continuing operations before income taxes | 2,614 |  |  |  | 903 |  |
| Income tax provision | 868 |  |  |  | 108 |  |
| Income from continuing operations | 1,746 |  |  |  | 795 |  |
| Income from discontinued operations, net of tax | 124 |  |  |  | — |  |
| Net income | 1,870 |  |  |  | 795 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 233 |  |  |  | 164 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | — |  |
| Net income attributable to JCI | $ | 1,637 |  |  |  | $ | 631 |  |
| Income from continuing operations | $ | 1,513 |  |  |  | $ | 631 |  |
| Income from discontinued operations | 124 |  |  |  | — |  |
| Net income attributable to JCI | $ | 1,637 |  |  |  | $ | 631 |  |
| Diluted earnings per share from continuing operations | $ | 2.10 |  |  |  | $ | 0.84 |  |
| Diluted earnings per share from discontinued operations | 0.17 |  |  |  | — |  |
| Diluted earnings per share | $ | 2.27 |  |  |  | $ | 0.84 |  |
| Diluted weighted average shares | 721.1 |  |  |  | 753.6 |  |
| Shares outstanding at period end | 708.7 |  |  |  | 726.2 |  |

[0000833444-21-000043:8k_2_02:90]
Page 10 of 18

[0000833444-21-000043:8k_2_02:91]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | September 30,2021 |  | September 30,2020 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 1,336 |  |  | $ | 1,951 |  |
| Accounts receivable - net | 5,613 |  |  | 5,294 |  |
| Inventories | 2,057 |  |  | 1,773 |  |
| Other current assets | 992 |  |  | 1,035 |  |
|  | Current assets | 9,998 |  |  | 10,053 |  |
| Property, plant and equipment - net | 3,228 |  |  | 3,059 |  |
| Goodwill | 18,335 |  |  | 17,932 |  |
| Other intangible assets - net | 5,549 |  |  | 5,356 |  |
| Investments in partially-owned affiliates | 1,066 |  |  | 914 |  |
| Noncurrent assets held for sale | 156 |  |  | 147 |  |
| Other noncurrent assets | 3,558 |  |  | 3,354 |  |
|  | Total assets | $ | 41,890 |  |  | $ | 40,815 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 234 |  |  | $ | 293 |  |
| Accounts payable and accrued expenses | 4,754 |  |  | 3,958 |  |
| Other current liabilities | 4,110 |  |  | 3,997 |  |
|  | Current liabilities | 9,098 |  |  | 8,248 |  |
| Long-term debt | 7,506 |  |  | 7,526 |  |
| Other noncurrent liabilities | 6,533 |  |  | 6,508 |  |
| Shareholders' equity attributable to JCI | 17,562 |  |  | 17,447 |  |
| Noncontrolling interests | 1,191 |  |  | 1,086 |  |
|  | Total liabilities and equity | $ | 41,890 |  |  | $ | 40,815 |  |

[0000833444-21-000043:8k_2_02:92]
Page 11 of 18

[0000833444-21-000043:8k_2_02:93]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Three Months Ended September 30, |
|  |  |  |  |  |  | 2021 |  |  | 2020 |
| Operating Activities |  |  |  |  |
| Net income from continuing operations attributable to JCI | $ | 269 |  |  |  | $ | 441 |  |
| Income from continuing operations attributable to noncontrolling interests | 47 |  |  |  | 49 |  |
| Net income from continuing operations | 316 |  |  |  | 490 |  |
| Adjustments to reconcile net income from continuing operations to cash provided by |  |  |  |  |
| operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 218 |  |  |  | 206 |  |
|  |  | Pension and postretirement benefit expense (income) | (158) |  |  |  | 76 |  |
|  |  | Pension and postretirement contributions | (28) |  |  |  | (18) |  |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (51) |  |  |  | (45) |  |
|  |  | Deferred income taxes | 30 |  |  |  | (389) |  |
|  |  | Non-cash restructuring and impairment costs | 4 |  |  |  | — |  |
|  |  | Other - net | 29 |  |  |  | (39) |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | 14 |  |  |  | 106 |  |
|  |  |  |  | Inventories | (15) |  |  |  | 250 |  |
|  |  |  |  | Other assets | (134) |  |  |  | 68 |  |
|  |  |  |  | Restructuring reserves | (17) |  |  |  | (87) |  |
|  |  |  |  | Accounts payable and accrued liabilities | (41) |  |  |  | 14 |  |
|  |  |  |  | Accrued income taxes | 362 |  |  |  | 348 |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 529 |  |  |  | 980 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (228) |  |  |  | (96) |  |
| Acquisition of businesses, net of cash acquired | (18) |  |  |  | (18) |  |
| Business divestitures, net of cash divested | — |  |  |  | 135 |  |
| Other - net | 42 |  |  |  | 30 |  |
|  |  |  |  |  | Cash provided (used) by investing activities from continuing operations | (204) |  |  |  | 51 |  |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | 36 |  |  |  | (422) |  |
| Stock repurchases and retirements | (306) |  |  |  | (737) |  |
| Payment of cash dividends | (192) |  |  |  | (194) |  |
| Dividends paid to noncontrolling interests | (9) |  |  |  | (47) |  |
| Proceeds from the exercise of stock options | 18 |  |  |  | 33 |  |
| Cash paid to acquire a noncontrolling interest | — |  |  |  | (132) |  |
| Employee equity-based compensation withholding taxes | (3) |  |  |  | (1) |  |
| Other - net | (25) |  |  |  | (8) |  |
|  |  |  |  |  | Cash used by financing activities from continuing operations | (481) |  |  |  | (1,508) |  |
| Discontinued Operations |  |  |  |  |
| Net cash used by operating activities | (8) |  |  |  | (5) |  |
| Net cash provided by investing activities | — |  |  |  | — |  |
| Net cash provided by financing activities | — |  |  |  | — |  |
|  |  |  |  |  | Net cash flows used by discontinued operations | (8) |  |  |  | (5) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 49 |  |  |  | 87 |  |
| Changes in cash held for sale | — |  |  |  | — |  |
| Decrease in cash, cash equivalents and restricted cash | $ | (115) |  |  |  | $ | (395) |  |

[0000833444-21-000043:8k_2_02:94]
Page 12 of 18

[0000833444-21-000043:8k_2_02:95]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Twelve Months Ended September 30, |
|  |  |  |  |  |  | 2021 |  |  | 2020 |
| Operating Activities |  |  |  |  |
| Net income from continuing operations attributable to JCI | $ | 1,513 |  |  |  | $ | 631 |  |
| Income from continuing operations attributable to noncontrolling interests | 233 |  |  |  | 164 |  |
| Net income from continuing operations | 1,746 |  |  |  | 795 |  |
| Adjustments to reconcile net income from continuing operations to cash provided by |  |  |  |  |
| operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 845 |  |  |  | 822 |  |
|  |  | Pension and postretirement benefit expense (income) | (551) |  |  |  | 118 |  |
|  |  | Pension and postretirement contributions | (68) |  |  |  | (61) |  |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (117) |  |  |  | (36) |  |
|  |  | Deferred income taxes | 36 |  |  |  | (537) |  |
|  |  | Non-cash restructuring and impairment costs | 98 |  |  |  | 582 |  |
|  |  | Other - net | (9) |  |  |  | (16) |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (143) |  |  |  | 534 |  |
|  |  |  |  | Inventories | (219) |  |  |  | 45 |  |
|  |  |  |  | Other assets | (164) |  |  |  | (52) |  |
|  |  |  |  | Restructuring reserves | (44) |  |  |  | (29) |  |
|  |  |  |  | Accounts payable and accrued liabilities | 813 |  |  |  | (717) |  |
|  |  |  |  | Accrued income taxes | 328 |  |  |  | 1,031 |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 2,551 |  |  |  | 2,479 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (552) |  |  |  | (443) |  |
| Acquisition of businesses, net of cash acquired | (725) |  |  |  | (77) |  |
| Business divestitures, net of cash divested | 19 |  |  |  | 135 |  |
| Other - net | 168 |  |  |  | 127 |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (1,090) |  |  |  | (258) |  |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | (28) |  |  |  | 385 |  |
| Stock repurchases and retirements | (1,307) |  |  |  | (2,204) |  |
| Payment of cash dividends | (762) |  |  |  | (790) |  |
| Proceeds from the exercise of stock options | 178 |  |  |  | 75 |  |
| Dividends paid to noncontrolling interests | (142) |  |  |  | (114) |  |
| Cash paid to acquire a noncontrolling interest | (14) |  |  |  | (132) |  |
| Employee equity-based compensation withholding taxes | (33) |  |  |  | (34) |  |
| Other - net | (23) |  |  |  | (10) |  |
|  |  |  |  |  | Cash used by financing activities from continuing operations | (2,131) |  |  |  | (2,824) |  |
| Discontinued Operations |  |  |  |  |
| Net cash used by operating activities | (64) |  |  |  | (260) |  |
| Net cash used by investing activities | — |  |  |  | — |  |
| Net cash used by financing activities | — |  |  |  | (113) |  |
|  |  |  |  |  | Net cash flows used by discontinued operations | (64) |  |  |  | (373) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 116 |  |  |  | 115 |  |
| Changes in cash held for sale | — |  |  |  | — |  |
| Decrease in cash, cash equivalents and restricted cash | $ | (618) |  |  |  | $ | (861) |  |

[0000833444-21-000043:8k_2_02:96]
Page 13 of 18

[0000833444-21-000043:8k_2_02:97]
FOOTNOTES

[0000833444-21-000043:8k_2_02:98]
1. Financial Summary

[0000833444-21-000043:8k_2_02:99]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and the net mark-to-market adjustments related to restricted asbestos investments and pension and postretirement plans. The financial results shown below are for continuing operations and exclude the Power Solutions business.

[0000833444-21-000043:8k_2_02:100]
| (in millions; unaudited) | Three Months Ended September 30, |
|  | 2021 |  | 2020 |
|  | Actual |  | AdjustedNon-GAAP |  | Actual |  | AdjustedNon-GAAP |
| Net sales (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,347 |  |  | $ | 2,347 |  |  | $ | 2,243 |  |  | $ | 2,243 |  |
| Building Solutions EMEA/LA | 962 |  |  | 962 |  |  | 906 |  |  | 906 |  |
| Building Solutions Asia Pacific | 724 |  |  | 724 |  |  | 661 |  |  | 661 |  |
| Global Products | 2,359 |  |  | 2,362 |  |  | 2,144 |  |  | 2,144 |  |
| Net sales | $ | 6,392 |  |  | $ | 6,395 |  |  | $ | 5,954 |  |  | $ | 5,954 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 357 |  |  | $ | 357 |  |  | $ | 341 |  |  | $ | 345 |  |
| Building Solutions EMEA/LA | 107 |  |  | 107 |  |  | 101 |  |  | 103 |  |
| Building Solutions Asia Pacific | 112 |  |  | 112 |  |  | 90 |  |  | 97 |  |
| Global Products | 436 |  |  | 442 |  |  | 337 |  |  | 381 |  |
| Segment EBITA | 1,012 |  |  | 1,018 |  |  | 869 |  |  | 926 |  |
| Corporate expenses (2) | (83) |  |  | (83) |  |  | (68) |  |  | (58) |  |
| Amortization of intangible assets (3) | (115) |  |  | (108) |  |  | (98) |  |  | (98) |  |
| Net mark-to-market adjustments (4) | 106 |  |  | — |  |  | (120) |  |  | — |  |
| Restructuring and impairment costs (5) | (67) |  |  | — |  |  | — |  |  | — |  |
| EBIT (6) | 853 |  |  | 827 |  |  | 583 |  |  | 770 |  |
| EBIT margin | 13.3 | % |  | 12.9 | % |  | 9.8 | % |  | 12.9 | % |
| Net financing charges | (47) |  |  | (47) |  |  | (62) |  |  | (62) |  |
| Income from continuing operations before income taxes | 806 |  |  | 780 |  |  | 521 |  |  | 708 |  |
| Income tax provision (7) | (490) |  |  | (105) |  |  | (31) |  |  | (96) |  |
| Income from continuing operations | 316 |  |  | 675 |  |  | 490 |  |  | 612 |  |
| Income from continuing operations attributable to noncontrolling interests | (47) |  |  | (47) |  |  | (49) |  |  | (49) |  |
| Net income from continuing operations attributable to JCI | $ | 269 |  |  | $ | 628 |  |  | $ | 441 |  |  | $ | 563 |  |

[0000833444-21-000043:8k_2_02:101]
| (in millions; unaudited) | Twelve Months Ended September 30, |
|  | 2021 |  | 2020 |
|  | Actual |  | AdjustedNon-GAAP |  | Actual |  | AdjustedNon-GAAP |
| Net sales (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 8,685 |  |  | $ | 8,685 |  |  | $ | 8,605 |  |  | $ | 8,605 |  |
| Building Solutions EMEA/LA | 3,727 |  |  | 3,727 |  |  | 3,440 |  |  | 3,440 |  |
| Building Solutions Asia Pacific | 2,654 |  |  | 2,654 |  |  | 2,403 |  |  | 2,403 |  |
| Global Products | 8,602 |  |  | 8,608 |  |  | 7,869 |  |  | 7,869 |  |
| Net sales | $ | 23,668 |  |  | $ | 23,674 |  |  | $ | 22,317 |  |  | $ | 22,317 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 1,204 |  |  | $ | 1,204 |  |  | $ | 1,157 |  |  | $ | 1,168 |  |
| Building Solutions EMEA/LA | 391 |  |  | 391 |  |  | 338 |  |  | 340 |  |
| Building Solutions Asia Pacific | 349 |  |  | 349 |  |  | 319 |  |  | 326 |  |
| Global Products | 1,441 |  |  | 1,454 |  |  | 1,134 |  |  | 1,186 |  |
| Segment EBITA | 3,385 |  |  | 3,398 |  |  | 2,948 |  |  | 3,020 |  |
| Corporate expenses (2) | (290) |  |  | (290) |  |  | (371) |  |  | (269) |  |
| Amortization of intangible assets (3) | (435) |  |  | (425) |  |  | (386) |  |  | (386) |  |
| Net mark-to-market adjustments (4) | 402 |  |  | — |  |  | (274) |  |  | — |  |
| Restructuring and impairment costs (5) | (242) |  |  | — |  |  | (783) |  |  | — |  |
| EBIT (6) | 2,820 |  |  | 2,683 |  |  | 1,134 |  |  | 2,365 |  |
| EBIT margin | 11.9 | % |  | 11.3 | % |  | 5.1 | % |  | 10.6 | % |
| Net financing charges | (206) |  |  | (206) |  |  | (231) |  |  | (231) |  |
| Income from continuing operations before income taxes | 2,614 |  |  | 2,477 |  |  | 903 |  |  | 2,134 |  |
| Income tax provision (7) | (868) |  |  | (334) |  |  | (108) |  |  | (288) |  |
| Income from continuing operations | 1,746 |  |  | 2,143 |  |  | 795 |  |  | 1,846 |  |
| Income from continuing operations attributable to noncontrolling interests | (233) |  |  | (233) |  |  | (164) |  |  | (158) |  |
| Net income from continuing operations attributable to JCI | $ | 1,513 |  |  | $ | 1,910 |  |  | $ | 631 |  |  | $ | 1,688 |  |

[0000833444-21-000043:8k_2_02:102]
(1) The Company's press release contains financial information regarding adjusted net sales, segment EBITA, adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures. The Company's definition of adjusted net sales and adjusted segment EBITA excludes special items because these items are not considered to be directly related to the underlying operating performance of its businesses. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-21-000043:8k_2_02:103]
A reconciliation of segment EBITA to income from continuing operations is shown earlier within this footnote. The following is the three months ended September 30, 2021 and 2020 reconciliation of net sales, segment EBITA and segment EBITA margin as reported to adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-21-000043:8k_2_02:104]
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | ConsolidatedJCI plc |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales as reported | $ | 2,347 |  |  | $ | 2,243 |  |  | $ | 962 |  |  | $ | 906 |  |  | $ | 724 |  |  | $ | 661 |  |  | $ | 2,359 |  |  | $ | 2,144 |  |  | $ | 6,392 |  |  | $ | 5,954 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring Silent-Aire purchase accounting impacts | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |  | — |  |
| Adjusted net sales | $ | 2,347 |  |  | $ | 2,243 |  |  | $ | 962 |  |  | $ | 906 |  |  | $ | 724 |  |  | $ | 661 |  |  | $ | 2,362 |  |  | $ | 2,144 |  |  | $ | 6,395 |  |  | $ | 5,954 |  |
| Segment EBITA as reported | $ | 357 |  |  | $ | 341 |  |  | $ | 107 |  |  | $ | 101 |  |  | $ | 112 |  |  | $ | 90 |  |  | $ | 436 |  |  | $ | 337 |  |  | $ | 1,012 |  |  | $ | 869 |  |
| Segment EBITA margin as reported | 15.2 | % |  | 15.2 | % |  | 11.1 | % |  | 11.1 | % |  | 15.5 | % |  | 13.6 | % |  | 18.5 | % |  | 15.7 | % |  | 15.8 | % |  | 14.6 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring Silent-Aire purchase accounting impacts and transaction costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 6 |  |  | — |  |  | 6 |  |  | — |  |
| Integration costs | — |  |  | 4 |  |  | — |  |  | 2 |  |  | — |  |  | 7 |  |  | — |  |  | 5 |  |  | — |  |  | 18 |  |
| Acquisition related compensation charge | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 39 |  |  | — |  |  | 39 |  |
| Adjusted segment EBITA | $ | 357 |  |  | $ | 345 |  |  | $ | 107 |  |  | $ | 103 |  |  | $ | 112 |  |  | $ | 97 |  |  | $ | 442 |  |  | $ | 381 |  |  | $ | 1,018 |  |  | $ | 926 |  |
| Adjusted segment EBITA margin | 15.2 | % |  | 15.4 | % |  | 11.1 | % |  | 11.4 | % |  | 15.5 | % |  | 14.7 | % |  | 18.7 | % |  | 17.8 | % |  | 15.9 | % |  | 15.6 | % |

[0000833444-21-000043:8k_2_02:105]
Page 14 of 18

[0000833444-21-000043:8k_2_02:106]
The following is the twelve months ended September 30, 2021 and 2020 reconciliation of net sales, segment EBITA and segment EBITA margin as reported to adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-21-000043:8k_2_02:107]
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | ConsolidatedJCI plc |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales as reported | $ | 8,685 |  |  | $ | 8,605 |  |  | $ | 3,727 |  |  | $ | 3,440 |  |  | $ | 2,654 |  |  | $ | 2,403 |  |  | $ | 8,602 |  |  | $ | 7,869 |  |  | $ | 23,668 |  |  | $ | 22,317 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring Silent-Aire purchase accounting impacts | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 6 |  |  | — |  |  | 6 |  |  | — |  |
| Adjusted net sales | $ | 8,685 |  |  | $ | 8,605 |  |  | $ | 3,727 |  |  | $ | 3,440 |  |  | $ | 2,654 |  |  | $ | 2,403 |  |  | $ | 8,608 |  |  | $ | 7,869 |  |  | $ | 23,674 |  |  | $ | 22,317 |  |
| Segment EBITA as reported | $ | 1,204 |  |  | $ | 1,157 |  |  | $ | 391 |  |  | $ | 338 |  |  | $ | 349 |  |  | $ | 319 |  |  | $ | 1,441 |  |  | $ | 1,134 |  |  | $ | 3,385 |  |  | $ | 2,948 |  |
| Segment EBITA margin as reported | 13.9 | % |  | 13.4 | % |  | 10.5 | % |  | 9.8 | % |  | 13.1 | % |  | 13.3 | % |  | 16.8 | % |  | 14.4 | % |  | 14.3 | % |  | 13.2 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring Silent-Aire purchase accounting impacts and transaction costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 13 |  |  | — |  |  | 13 |  |  | — |  |
| Integration costs | — |  |  | 11 |  |  | — |  |  | 2 |  |  | — |  |  | 7 |  |  | — |  |  | 13 |  |  | — |  |  | 33 |  |
| Acquisition related compensation charge | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 39 |  |  | — |  |  | 39 |  |
| Adjusted segment EBITA | $ | 1,204 |  |  | $ | 1,168 |  |  | $ | 391 |  |  | $ | 340 |  |  | $ | 349 |  |  | $ | 326 |  |  | $ | 1,454 |  |  | $ | 1,186 |  |  | $ | 3,398 |  |  | $ | 3,020 |  |
| Adjusted segment EBITA margin | 13.9 | % |  | 13.6 | % |  | 10.5 | % |  | 9.9 | % |  | 13.1 | % |  | 13.6 | % |  | 16.9 | % |  | 15.1 | % |  | 14.4 | % |  | 13.5 | % |

[0000833444-21-000043:8k_2_02:108]
(2) Adjusted Corporate expenses excludes special items because these costs are not considered to be directly related to the underlying operating performance of the Company's business. Adjusted Corporate expenses for the three months ended September 30, 2020 excludes $10 million of integration costs. Adjusted Corporate expenses for the twelve months ended September 30, 2020 excludes $102 million of integration costs.

[0000833444-21-000043:8k_2_02:109]
(3) Adjusted amortization of intangible assets for the three months ended September 30, 2021 excludes $7 million of nonrecurring asset amortization related to Silent-Aire purchase accounting. Adjusted amortization of intangible assets for the twelve months ended September 30, 2021 excludes $10 million of nonrecurring asset amortization related to Silent-Aire purchase accounting.

[0000833444-21-000043:8k_2_02:110]
(4) The three months ended September 30, 2021 exclude the net mark-to-market adjustments on restricted investments and pension and postretirement plans of $106 million. The twelve months ended September 30, 2021 exclude the net mark-to-market adjustments on restricted investments and pension and postretirement plans of $402 million. The three months ended September 30, 2020 exclude the net mark-to-market adjustments on restricted investments and pension and postretirement plans of $120 million. The twelve months ended September 30, 2020 exclude the net mark-to-market adjustments on restricted investments and pension and postretirement plans of $274 million.

[0000833444-21-000043:8k_2_02:111]
(5) Restructuring and impairment costs for the three months ended September 30, 2021 of $67 million are excluded from the adjusted non-GAAP results. Restructuring and impairment costs for the twelve months ended September 30, 2021 of $242 million are excluded from the adjusted non-GAAP results. Restructuring and impairment costs for the twelve months ended September 30, 2020 of $783 million are excluded from the adjusted non-GAAP results. The restructuring actions and impairment costs related primarily to workforce reductions, plant closures and asset impairments.

[0000833444-21-000043:8k_2_02:112]
(6) Management defines earnings before interest and taxes (EBIT) as income from continuing operations before net financing charges, income taxes and noncontrolling interests. EBIT is a non-GAAP performance measure. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company. A reconciliation of EBIT to income from continuing operations is shown earlier within this footnote.

[0000833444-21-000043:8k_2_02:113]
(7) Adjusted income tax provision for the three months ended September 30, 2021 excludes tax provisions from an intra-entity sale of certain of the Company's intellectual property of $417 million and net mark-to-market adjustments of $18 million, partially offset by tax benefits related to valuation allowance adjustments of $39 million, restructuring and impairment costs of $9 million, and Silent-Aire nonrecurring purchase accounting of $2 million. Adjusted income tax provision for the twelve months ended September 30, 2021 excludes tax provisions from an intra-entity sale of certain of the Company's intellectual property of $417 million, a Mexico valuation allowance adjustment $105 million, and net mark-to-market adjustments of $93 million, partially offset by tax benefits related to other valuation allowance adjustments of $39 million, restructuring and impairment costs of $39 million, and Silent-Aire nonrecurring purchase accounting of $3 million. Adjusted income tax provision for the three months ended September 30, 2020 excludes tax benefits from net mark-to-market adjustments of $27 million, valuation allowance adjustments of $26 million, an acquisition related compensation charge of $9 million and integration costs of $3 million. Adjusted income tax provision for the twelve months ended September 30, 2020 excludes tax benefits from net mark-to-market adjustments of $65 million, restructuring and impairment costs of $48 million, tax audit reserve adjustments of $44 million, valuation allowance adjustments of $26 million, integration costs of $18 million and an acquisition related compensation charge of $9 million, partially offset by tax provisions related to Switzerland tax reform of $30 million.

[0000833444-21-000043:8k_2_02:114]
Page 15 of 18

[0000833444-21-000043:8k_2_02:115]
2.  Diluted Earnings Per Share Reconciliation

[0000833444-21-000043:8k_2_02:116]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include integration costs, net mark-to-market adjustments, an acquisition related compensation charge, restructuring and impairment costs, Silent-Aire transaction costs and other nonrecurring costs, Power Solutions divestiture reserve adjustment and discrete tax items. The Company excludes these items because they are not considered to be directly related to the underlying operating performance of the Company. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-21-000043:8k_2_02:117]
A reconciliation of diluted earnings per share as reported to adjusted diluted earnings per share for the respective periods is shown below (unaudited):

[0000833444-21-000043:8k_2_02:118]
|  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc from Continuing Operations |  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc fromContinuing Operations |
|  | Three Months Ended |  | Three Months Ended |  | Twelve Months Ended |  | Twelve Months Ended |
|  | September 30, |  | September 30, |  | September 30, |  | September 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Earnings per share as reported for JCI plc | $ | 0.38 |  |  | $ | 0.60 |  |  | $ | 0.38 |  |  | $ | 0.60 |  |  | $ | 2.27 |  |  | $ | 0.84 |  |  | $ | 2.10 |  |  | $ | 0.84 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Integration costs | — |  |  | 0.04 |  |  | — |  |  | 0.04 |  |  | — |  |  | 0.18 |  |  | — |  |  | 0.18 |  |
| Related tax impact | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (0.02) |  |  | — |  |  | (0.02) |  |
| Acquisition related compensation charge | — |  |  | 0.05 |  | — |  |  | 0.05 |  | — |  |  | 0.05 |  |  | — |  |  | 0.05 |  |
| Related tax impact | — |  |  | (0.01) |  |  | — |  |  | (0.01) |  |  | — |  |  | (0.01) |  |  | — |  |  | (0.01) |  |
| Net mark-to-market adjustments | (0.15) |  |  | 0.16 |  |  | (0.15) |  |  | 0.16 |  |  | (0.56) |  |  | 0.36 |  |  | (0.56) |  |  | 0.36 |  |
| Related tax impact | 0.03 |  |  | (0.04) |  |  | 0.03 |  |  | (0.04) |  |  | 0.13 |  |  | (0.09) |  |  | 0.13 |  |  | (0.09) |  |
| Restructuring and impairment costs | 0.09 |  |  | — |  |  | 0.09 |  |  | — |  |  | 0.34 |  |  | 1.04 |  |  | 0.34 |  |  | 1.04 |  |
| Related tax impact | (0.01) |  |  | — |  |  | (0.01) |  |  | — |  |  | (0.05) |  |  | (0.06) |  |  | (0.05) |  |  | (0.06) |  |
| NCI impact of restructuring and impairment costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (0.01) |  |  | — |  |  | (0.01) |  |
| Silent-Aire transaction costs and other nonrecurring costs | 0.02 |  |  | — |  |  | 0.02 |  |  | — |  |  | 0.03 |  |  | — |  |  | 0.03 |  |  | — |  |
| Power Solutions divestiture reserve adjustment | — |  |  | — |  |  | — |  |  | — |  |  | (0.17) |  |  | — |  |  | — |  |  | — |  |
| Discrete tax items | 0.53 |  |  | (0.04) |  |  | 0.53 |  |  | (0.04) |  |  | 0.67 |  |  | (0.05) |  |  | 0.67 |  |  | (0.05) |  |
| NCI impact of discrete tax items | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |
| Adjusted earnings per share for JCI plc* | $ | 0.88 |  |  | $ | 0.76 |  |  | $ | 0.88 |  |  | $ | 0.76 |  |  | $ | 2.65 |  |  | $ | 2.24 |  |  | $ | 2.65 |  |  | $ | 2.24 |  |

[0000833444-21-000043:8k_2_02:119]
* May not sum due to rounding

[0000833444-21-000043:8k_2_02:120]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-21-000043:8k_2_02:121]
|  | Three Months Ended |  | Twelve Months Ended |  |  |  |  |
|  | September 30, |  | September 30, |  |  |  |  |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |  |  |  |  |
| Weighted average shares outstanding for JCI plc |  |  |  |  |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 711.7 |  |  | 735.2 |  |  | 716.6 |  |  | 751.0 |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock |  |  |  |  |  |  |  |  |  |  |  |
| and unvested performance share awards | 5.3 |  |  | 2.9 |  |  | 4.5 |  |  | 2.6 |  |  |  |  |  |
| Diluted weighted average shares outstanding | 717.0 |  |  | 738.1 |  |  | 721.1 |  |  | 753.6 |  |  |  |  |  |

[0000833444-21-000043:8k_2_02:122]
The Company has presented forward-looking statements regarding adjusted corporate expense, adjusted EPS, organic revenue, adjusted EBITA margin and free cash flow conversion, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts, expenses, income or cash flows from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts that are excluded from these non-GAAP financial measures are a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period, including but not limited to the high variability of the net mark-to-market adjustments and the effect of foreign currency exchange fluctuations. Our fiscal 2022 full year and first quarter guidance for organic revenue also excludes the effect of acquisitions, divestitures and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available and management cannot reliably predict all of the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s full year and first quarter 2022 GAAP financial results.

[0000833444-21-000043:8k_2_02:123]
3. Organic Growth Reconciliation

[0000833444-21-000043:8k_2_02:124]
The components of the changes in adjusted net sales for the three months ended September 30, 2021 versus the three months ended September 30, 2020, including organic growth, are shown below (unaudited):

[0000833444-21-000043:8k_2_02:125]
| (in millions) | Adjusted Net Sales for the Three Months Ended September 30, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the ThreeMonths EndedSeptember 30, 2020 |  | Acquisitions |  | Organic Growth |  | Adjusted Net Sales for the Three Months EndedSeptember 30, 2021 |
| Building Solutions North America | $ | 2,243 |  |  | $ | — |  | — |  |  | $ | 12 |  | 1 | % |  | $ | 2,255 |  |  | $ | 4 |  | — |  |  | $ | 88 |  | 4 | % |  | $ | 2,347 |  | 5 | % |
| Building Solutions EMEA/LA | 906 |  |  | — |  | — |  |  | 16 |  | 2 | % |  | 922 |  |  | 14 |  | 2 | % |  | 26 |  | 3 | % |  | 962 |  | 6 | % |
| Building Solutions Asia Pacific | 661 |  |  | (2) |  | — |  |  | 18 |  | 2 | % |  | 677 |  |  | — |  | — |  |  | 47 |  | 7 | % |  | 724 |  | 10 | % |
| Total field | 3,810 |  |  | (2) |  | — |  |  | 46 |  | 3 | % |  | 3,854 |  |  | 18 |  | — |  |  | 161 |  | 4 | % |  | 4,033 |  | 6 | % |
| Global Products | 2,144 |  |  | (79) |  | -4 | % |  | 11 |  | 1 | % |  | 2,076 |  |  | 132 |  | 6 | % |  | 154 |  | 7 | % |  | 2,362 |  | 10 | % |
| Total net sales | $ | 5,954 |  |  | $ | (81) |  | -1 | % |  | $ | 57 |  | 1 | % |  | $ | 5,930 |  |  | $ | 150 |  | 3 | % |  | $ | 315 |  | 5 | % |  | $ | 6,395 |  | 7 | % |

[0000833444-21-000043:8k_2_02:126]
Page 16 of 18

[0000833444-21-000043:8k_2_02:127]
The components of the changes in adjusted net sales for the twelve months ended September 30, 2021 versus the twelve months ended September 30, 2020, including organic growth, are shown below (unaudited):

[0000833444-21-000043:8k_2_02:128]
| (in millions) | Adjusted Net Sales for the Twelve Months Ended September 30, 2020 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base NetSales for the Twelve Months EndedSeptember 30, 2020 |  | Acquisitions |  | Organic Growth |  | Adjusted Net Sales for the Three Months EndedSeptember 30, 2021 |
| Building Solutions North America | $ | 8,605 |  |  | $ | — |  | — |  |  | $ | 49 |  | 1 | % |  | $ | 8,654 |  |  | $ | 4 |  | — |  |  | $ | 27 |  | — |  |  | $ | 8,685 |  | 1 | % |
| Building Solutions EMEA/LA | 3,440 |  | — |  | — |  |  | 135 | 4 | % |  | 3,575 |  |  | 37 |  | 1 | % |  | 115 |  | 3 | % |  | 3,727 |  | 8 | % |
| Building Solutions Asia Pacific | 2,403 |  | (9) |  | — |  |  | 117 | 5 | % |  | 2,511 |  |  | — |  | — |  |  | 143 |  | 6 | % |  | 2,654 |  | 10 | % |
| Total field | 14,448 |  | (9) | — |  |  | 301 |  | 2 | % |  | 14,740 |  |  | 41 |  | — |  |  | 285 |  | 2 | % |  | 15,066 |  | 4 | % |
| Global Products | 7,869 |  | (266) |  | -3 | % |  | 146 | 2 | % |  | 7,749 |  |  | 212 |  | 3 | % |  | 647 |  | 8 | % |  | 8,608 |  | 9 | % |
| Total net sales | $ | 22,317 |  |  | $ | (275) |  | -1 | % |  | $ | 447 |  | 2 | % |  | $ | 22,489 |  |  | $ | 253 |  | 1 | % |  | $ | 932 |  | 4 | % |  | $ | 23,674 |  | 6 | % |

[0000833444-21-000043:8k_2_02:129]
4.   Free Cash Flow Conversion

[0000833444-21-000043:8k_2_02:130]
The Company's press release contains financial information regarding free cash flow, adjusted free cash flow and adjusted free cash flow conversion, which are non-GAAP performance measures. Free cash flow is defined as cash provided by operating activities less capital expenditures. Fiscal 2020 adjusted free cash flow excludes special items, as included in the table below, because these cash flows were not considered to be directly related to its underlying businesses. For fiscal 2021, there were no items excluded from the calculation of adjusted free cash flow. Adjusted free cash flow conversion is defined as adjusted free cash flow divided by adjusted net income attributable to JCI. Management believes these non-GAAP measures are useful to investors in understanding the strength of the Company and its ability to generate cash. This non-GAAP measure can also be used to evaluate our ability to generate cash flow from operations and the impact that this cash flow has on our liquidity.

[0000833444-21-000043:8k_2_02:131]
The following is the three months and twelve months ended September 30, 2021 and 2020 reconciliation of free cash flow, adjusted free cash flow and adjusted free cash flow conversion for continuing operations (unaudited):

[0000833444-21-000043:8k_2_02:132]
|  | Three Months Ended September 30, |  | Twelve Months Ended September 30, |  |  |  |  |  |  |  |  |
| (in millions) | 2021 |  | 2020 |  | 2021 |  | 2020 |  |  |  |  |  |  |  |  |
| Cash provided by operating activities from continuing |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| operations | $ | 529 |  | $ | 980 |  | $ | 2,551 |  | $ | 2,479 |  |  |  |  |  |  |  |  |
| Capital expenditures | (228) |  | (96) |  | (552) |  | (443) |  |  |  |  |  |  |  |  |
| Reported free cash flow | 301 |  | 884 |  | 1,999 |  | 2,036 |  |  |  |  |  |  |  |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Transaction/integration costs | — |  | 77 |  | — |  | 241 |  |  |  |  |  |  |  |  |
| Restructuring payments | — |  | 87 |  | — |  | 230 |  |  |  |  |  |  |  |  |
| Nonrecurring tax payments (refunds) | — |  | — |  | — |  | (565) |  |  |  |  |  |  |  |  |
| Total adjusting items | — |  | 164 |  | — |  | (94) |  |  |  |  |  |  |  |  |
| Adjusted free cash flow | $ | 301 |  | $ | 1,048 |  | $ | 1,999 |  | $ | 1,942 |  |  |  |  |  |  |  |  |
| Adjusted net income from continuing operations |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| attributable to JCI | $ | 628 |  | $ | 563 |  | $ | 1,910 |  | $ | 1,688 |  |  |  |  |  |  |  |  |
| Adjusted free cash flow conversion | 48 | % |  | 186 | % |  | 105 | % |  | 115 | % |  |  |  |  |  |  |  |  |

[0000833444-21-000043:8k_2_02:133]
5.  Net Debt to EBITDA

[0000833444-21-000043:8k_2_02:134]
The Company provides financial information regarding net debt to adjusted EBITDA, which is a non-GAAP performance measure. The Company believes the total net debt to adjusted EBITDA ratio is useful to understanding the Company's financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders. The following is the September 30, 2021 calculation of net debt to adjusted EBITDA (unaudited):

[0000833444-21-000043:8k_2_02:135]
| (in millions) | September 30, 2021 |  |  |
| Short-term debt and current portion of long-term debt | $ | 234 |  |  |  |
| Long-term debt | 7,506 |  |  |  |
| Total debt | 7,740 |  |  |  |
| Less: cash and cash equivalents | 1,336 |  |  |  |
| Total net debt | $ | 6,404 |  |  |  |
| Last twelve months adjusted EBITDA | $ | 3,518 |  |  |  |
| Total net debt to adjusted EBITDA | 1.8x |  |  |

[0000833444-21-000043:8k_2_02:136]
The following is the last twelve months ended September 30, 2021 reconciliation of income from continuing operations to adjusted EBIT and adjusted EBITDA, which are non-GAAP performance measures (unaudited):

[0000833444-21-000043:8k_2_02:137]
| (in millions) | Last Twelve MonthsEndedSeptember 30, 2021 |  |  |
| Income from continuing operations | $ | 1,746 |  |  |  |
| Income tax provision | 868 |  |  |  |
| Net financing charges | 206 |  |  |  |
| EBIT | 2,820 |  |  |  |
| Adjusting items: |  |  |  |
| Net mark-to-market adjustments | (402) |  |  |  |
| Restructuring and impairment costs | 242 |  |  |  |
| Silent-Aire transaction and other nonrecurring costs | 23 |  |  |  |
| Adjusted EBIT (1) | 2,683 |  |  |  |
| Depreciation and amortization | 835 |  |  |  |
| Adjusted EBITDA (1) | $ | 3,518 |  |  |  |

[0000833444-21-000043:8k_2_02:138]
(1) The Company's definition of adjusted EBIT and adjusted EBITDA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its businesses. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-21-000043:8k_2_02:139]
Page 17 of 18

[0000833444-21-000043:8k_2_02:140]
6.  Trade Working Capital as a Percentage of Net Sales

[0000833444-21-000043:8k_2_02:141]
The Company provides financial information regarding trade working capital as a percentage of net sales, which is a non-GAAP performance measure. Trade working capital is defined as current assets less current liabilities, excluding cash and cash equivalents, short-term debt, the current portion of long-term debt, the current portion of assets and liabilities held for sale, accrued compensation and benefits, and other current assets and liabilities. Management believes this non-GAAP measure, which excludes financing-related items, non-trade related items and businesses to be divested, is a more useful measurement of the Company's operating performance. The following is the September 30, 2021 and September 30, 2020 calculation of trade working capital as a percentage of net sales (unaudited):

[0000833444-21-000043:8k_2_02:142]
| (in millions) | September 30, 2021 |  | September 30, 2020 |
| Current assets | $ | 9,998 |  |  | $ | 10,053 |  |
| Current liabilities | (9,098) |  |  | (8,248) |  |
| Total working capital | 900 |  |  | 1,805 |  |
| Less: cash and cash equivalents | (1,336) |  |  | (1,951) |  |
| Less: other current assets | (992) |  |  | (1,035) |  |
| Add: short-term debt | 8 |  |  | 31 |  |
| Add: current portion of long-term debt | 226 |  |  | 262 |  |
| Add: accrued compensation and benefits | 1,008 |  |  | 838 |  |
| Add: other current liabilities | 2,473 |  |  | 2,562 |  |
| Trade working capital | $ | 2,287 |  |  | $ | 2,512 |  |
| Last twelve months net sales | $ | 23,668 |  |  | $ | 22,317 |  |
| Trade working capital as a percentage of net sales | 9.7 | % |  | 11.3 | % |

[0000833444-21-000043:8k_2_02:143]
7.  Income Taxes

[0000833444-21-000043:8k_2_02:144]
The Company's effective tax rate from continuing operations before consideration of transaction/integration costs, net mark-to-market adjustments, Silent-Aire nonrecurring purchase accounting, restructuring and impairment costs, acquisition related compensation charge, and discrete tax items for the three and twelve months ending September 30, 2021 and September 30, 2020 is approximately 13.5%.

[0000833444-21-000043:8k_2_02:145]
8.  Restructuring and Impairment Costs

[0000833444-21-000043:8k_2_02:146]
The three months ended September 30, 2021 include restructuring and impairment costs of $67 million related primarily to workforce reductions, asset impairments and other related costs. The twelve months ended September 30, 2021 include restructuring and impairment costs of $242 million related primarily to workforce reductions, asset impairments and other related costs. The twelve months ended September 30, 2020 include restructuring and impairment costs of $783 million related primarily to workforce reductions, plant closures, asset impairments, and indefinite-lived intangible asset and goodwill impairments primarily related to the Company's retail business.

[0000833444-21-000043:8k_2_02:147]
Page 18 of 18
