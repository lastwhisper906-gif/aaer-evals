# JCI MD&A — 0000833444-17-000044


## mdna

[0000833444-17-000044:mdna:1]
[same as prior period, unchanged from 0000833444-17-000016:mdna:1]

[0000833444-17-000044:mdna:2]
[same as prior period, unchanged from 0000833444-17-000016:mdna:2]

[0000833444-17-000044:mdna:3]
[same as prior period, unchanged from 0000833444-17-000016:mdna:3]

[0000833444-17-000044:mdna:4]
[same as prior period, unchanged from 0000833444-17-000016:mdna:4]

[0000833444-17-000044:mdna:5]
[same as prior period, unchanged from 0000833444-17-000016:mdna:5]

[0000833444-17-000044:mdna:6]
[same as prior period, unchanged from 0000833444-17-000016:mdna:6]

[0000833444-17-000044:mdna:7]
In the fourth quarter of fiscal 2016, Johnson Controls, Inc. ("JCI Inc.") and Tyco completed their combination, with JCI Inc. merging with a wholly owned, indirect subsidiary of Tyco (the "Merger"). Following the Merger, Tyco changed its name to “Johnson Controls International plc” and JCI Inc. is a wholly-owned subsidiary of Johnson Controls International plc. The Merger was accounted for as a reverse acquisition using the acquisition method of accounting in accordance with Accounting Standards Codification ("ASC") 805, "Business Combinations." JCI Inc. was the accounting acquirer for financial reporting purposes.

[0000833444-17-000044:mdna:8]
Accordingly, the historical consolidated financial statements of JCI Inc. for periods prior to this transaction are considered to be the historic financial statements of the Company. Refer to Note 3, "Merger Transaction," of the notes to consolidated financial statements for additional information.

[0000833444-17-000044:mdna:9]
[same as prior period, unchanged from 0000833444-17-000016:mdna:9]

[0000833444-17-000044:mdna:10]
On October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience Business from Johnson Controls to Adient plc ("Adient") and the issuance of ordinary shares of Adient directly to holders of Johnson Controls ordinary shares on a pro rata basis. Prior to the open of business on October 31, 2016, each of the Company's shareholders received one ordinary share of Adient plc for every 10 ordinary shares of Johnson Controls held as of the close of business on October 19, 2016, the record date for the distribution. Company shareholders received cash in lieu of fractional shares of Adient, if any. Following the separation and distribution, Adient plc is now an independent public company trading on the New York Stock Exchange (NYSE) under the symbol "ADNT." The Company did not retain any equity interest in Adient plc. Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation.

[0000833444-17-000044:mdna:11]
[same as prior period, unchanged from 0000833444-17-000016:mdna:11]

[0000833444-17-000044:mdna:12]
[same as prior period, unchanged from 0000833444-17-000016:mdna:12]

[0000833444-17-000044:mdna:13]
[same as prior period, unchanged from 0000833444-17-000016:mdna:13]

[0000833444-17-000044:mdna:14]
The following information should be read in conjunction with the September 30, 2016 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in our Annual Report on Form 10-K for the year ended September 30, 2016 filed with the SEC on November 23, 2016, portions of which (including Part I, Item 1. Business and Item 3. Legal Proceedings, and the following items from Part II of the Annual Report: Item 6. Selected Financial Data, Item 7. Management’s Discussion and Analysis, and Item 8. Financial Statements and Supplementary Data) were recast in the Company's Current Report on Form 8-K filed with the SEC on February 23, 2017. References in the following discussion and analysis to "Three Months"(or similar language) refer to the three months ended June 30, 2017 compared to the three months ended June 30, 2016, while references to "Year-to-Date" refer to the nine months ended June 30, 2017 compared to the nine months ended June 30, 2016.

[0000833444-17-000044:mdna:15]
[same as prior period, unchanged from 0000833444-17-000016:mdna:21]

[0000833444-17-000044:mdna:16]
[same as prior period, unchanged from 0000833444-17-000016:mdna:15]

[0000833444-17-000044:mdna:17]
The Company believes its capital resources and liquidity position at June 30, 2017 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, stock repurchases, minimum pension contributions, debt maturities and any potential acquisitions in fiscal 2017 will continue be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets.  In the event the Company and its wholly-owned indirect subsidiary, Tyco International Holding S.à.r.l ("TSarl"), are unable to issue commercial paper, they would have the ability to draw on their $2.0 billion and $1.0 billion revolving credit facilities, respectively. Both facilities mature in August 2020. There were no draws on the revolving credit facilities as of June 30, 2017. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future.

[0000833444-17-000044:mdna:18]
The Company’s debt financial covenant in its revolving credit facility require a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification (ASC) 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. TSarl's, revolving credit facility contains customary terms and conditions, and a financial covenant that limits the ratio of TSarl's debt to earnings before interest, taxes, depreciation, and amortization as adjusted for certain items set forth in the agreement to 3.5x. The TSarl's revolving credit facility also limits its ability to incur subsidiary debt or grant liens on its and its subsidiaries' property. As of June 30, 2017, the Company and TSarl were in compliance with all covenants and other requirements set forth in their credit agreements and the indentures, governing their notes, and expect to remain in compliance for the foreseeable future. None of the Company’s or TSarl's debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the respective borrower's credit rating.

[0000833444-17-000044:mdna:19]
The key financial assumptions used in calculating the Company’s pension liability are determined annually, or whenever plan assets and liabilities are re-measured as required under accounting principles generally accepted in the U.S., including the expected rate of return on its plan assets. In fiscal 2017, the Company believes the long-term rate of return will approximate 7.50%, 3.40% and 5.60% for U.S. pension, non-U.S. pension and postretirement plans, respectively. During the first nine months of fiscal 2017, the Company made approximately $275 million in total pension and postretirement contributions. In total, the Company expects to contribute approximately $317 million in cash to its defined benefit pension plans in fiscal 2017. The Company expects to contribute $4 million in cash to its postretirement plans in fiscal 2017.

[0000833444-17-000044:mdna:20]
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2017 and recorded $226 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and  asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2017 restructuring plan will reduce annual operating costs from continuing operations by approximately $225 million, which is primarily the result of lower cost of sales and selling, general and administrative expenses due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in fiscal 2018. For fiscal 2017, the savings from continuing operations, net of execution costs, are expected to be approximately 50% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in fiscal 2018. The restructuring plan reserve balance of $108 million at June 30, 2017 is expected to be paid in cash.

[0000833444-17-000044:mdna:21]
[same as prior period, unchanged from 0000833444-17-000016:mdna:20]

[0000833444-17-000044:mdna:22]
58

[0000833444-17-000044:mdna:23]
the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in fiscal 2018. The restructuring plan reserve balance of $163 million at June 30, 2017 is expected to be paid in cash.

[0000833444-17-000044:mdna:24]
[same as prior period, unchanged from 0000833444-17-000016:mdna:23]

[0000833444-17-000044:mdna:25]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Net sales | $ | 7,683 |  |  | $ | 5,154 |  |  | 49 | % |  | $ | 22,036 |  |  | $ | 14,583 |  |  | 51 | % |

[0000833444-17-000044:mdna:26]
The increase in consolidated net sales for the three months ended June 30, 2017 was due to higher sales in the Building Technologies & Solutions business ($2,469 million) and the Power Solutions business ($95 million), partially offset by the unfavorable impact of foreign currency translation ($35 million). Incremental sales resulted from the Tyco Merger, the impact of higher lead costs on pricing in the Power Solutions business and higher volumes across all Building Efficiency segments. Excluding the impacts of the Tyco Merger and foreign currency translation, consolidated net sales increased 4% as compared to the prior year. Refer to the "Segment Analysis" below within Item 2 for a discussion of net sales by segment.

[0000833444-17-000044:mdna:27]
The increase in consolidated net sales for the nine months ended June 30, 2017 was due to higher sales in the Building Technologies & Solutions business ($7,089 million) and the Power Solutions business ($383 million), partially offset by the unfavorable impact of foreign currency translation ($19 million). Incremental sales resulted from the Tyco Merger, the impact of higher lead costs on pricing in the Power Solutions business and higher volumes across all Building Efficiency segments. Excluding the impacts of the Tyco Merger and foreign currency translation, consolidated net sales increased 4% as compared to the prior year. Refer to the "Segment Analysis" below within Item 2 for a discussion of net sales by segment.

[0000833444-17-000044:mdna:28]
[same as prior period, unchanged from 0000833444-17-000016:mdna:27]

[0000833444-17-000044:mdna:29]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Cost of sales | $ | 5,252 |  |  | $ | 3,732 |  |  | 41 | % |  | $ | 15,210 |  |  | $ | 10,617 |  |  | 43 | % |
| Gross profit | 2,431 |  |  | 1,422 |  |  | 71 | % |  | 6,826 |  |  | 3,966 |  |  | 72 | % |
| % of sales | 31.6 | % |  | 27.6 | % |  |  |  | 31.0 | % |  | 27.2 | % |  |  |

[0000833444-17-000044:mdna:30]
Cost of sales for the three month period ended June 30, 2017 increased as compared to the three month period ended June 30, 2016, and gross profit as a percentage of sales increased by 400 basis points primarily as a result of the Tyco Merger. Gross profit in the Building Technologies & Solutions business increased due to the incremental gross profit related to the Tyco Merger and higher volumes across all Building Efficiency segments. Gross profit in the Power Solutions business was impacted by favorable pricing and product mix net of lead cost increases, partially offset by higher operating costs. Net mark-to-market adjustments on pension plans had an unfavorable impact on cost of sales of $3 million primarily due to a decrease in discount rates. Foreign currency translation had a favorable impact on cost of sales of approximately $24 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment earnings before interest, taxes and amortization (EBITA) by segment.

[0000833444-17-000044:mdna:31]
Cost of sales for the nine month period ended June 30, 2017 increased as compared to the nine month period ended June 30, 2016, and gross profit as a percentage of sales increased by 380 basis points primarily as a result of the Tyco Merger. Gross profit in the Building Technologies & Solutions business increased due to the incremental gross profit related to the Tyco Merger and higher volumes in the Building Efficiency Asia segment, partially offset by higher operating costs in the Building Efficiency Systems and Service North America and Asia segments as a result of product and channel investments. Gross profit in the Power Solutions business was impacted by favorable pricing and product mix net of lead cost increases, partially offset by higher operating costs. Net mark-to-market adjustments on pension plans had a favorable impact on cost of sales of $12 million primarily due to an increase in discount rates. Foreign currency translation had a favorable impact on cost of sales of approximately $9 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-17-000044:mdna:32]
[same as prior period, unchanged from 0000833444-17-000016:mdna:31]

[0000833444-17-000044:mdna:33]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Selling, general and administrative expenses | $ | 1,609 |  |  | $ | 895 |  |  | 80 | % |  | $ | 4,905 |  |  | $ | 2,641 |  |  | 86 | % |
| % of sales | 20.9 | % |  | 17.4 | % |  |  |  | 22.3 | % |  | 18.1 | % |  |  |

[0000833444-17-000044:mdna:34]
Selling, general and administrative expenses (SG&A) for the three month period ended June 30, 2017 increased 80% as compared to the three month period ended June 30, 2016. The increase in SG&A was primarily due to incremental SG&A related to the Tyco Merger and net mark-to-market adjustments on pension plans, partially offset by productivity savings and costs synergies. The net mark-to-market adjustments had an unfavorable impact on SG&A of $42 million primarily due to a decrease in discount rates. Foreign currency translation had a favorable impact on SG&A of $4 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-17-000044:mdna:35]
SG&A for the nine month period ended June 30, 2017 increased 86% as compared to the nine month period ended June 30, 2016. The increase in SG&A was primarily due to incremental SG&A related to the Tyco Merger, partially offset by productivity savings and costs synergies as well as net mark-to-market adjustments on pension plans. The net mark-to-market adjustments had a favorable impact on SG&A of $78 million primarily due to an increase in discount rates. Foreign currency translation had an unfavorable impact on SG&A of $3 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-17-000044:mdna:36]
[same as prior period, unchanged from 0000833444-17-000016:mdna:35]

[0000833444-17-000044:mdna:37]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Restructuring and impairment costs | $ | 49 |  |  | $ | 27 |  |  | 81 | % |  | $ | 226 |  |  | $ | 87 |  |  | * |

[0000833444-17-000044:mdna:38]
[same as prior period, unchanged from 0000833444-17-000016:mdna:37]

[0000833444-17-000044:mdna:39]
[same as prior period, unchanged from 0000833444-17-000016:mdna:38]

[0000833444-17-000044:mdna:40]
[same as prior period, unchanged from 0000833444-17-000016:mdna:39]

[0000833444-17-000044:mdna:41]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Net financing charges | $ | 124 |  |  | $ | 65 |  |  | 91 | % |  | $ | 376 |  |  | $ | 202 |  |  | 86 | % |

[0000833444-17-000044:mdna:42]
Net financing charges were higher for the three month period ended June 30, 2017 primarily due to higher interest rates, and higher average borrowing levels as a result of the debt assumed with the Tyco Merger and new debt issuances in the second quarter of fiscal 2017. Net financing charges were higher for the nine month period ended June 30, 2017 primarily due to higher interest rates, higher average borrowing levels as a result of the debt assumed with the Tyco Merger and new debt issuances in the second quarter of fiscal 2017, and debt exchange offer fees.

[0000833444-17-000044:mdna:43]
[same as prior period, unchanged from 0000833444-17-000016:mdna:42]

[0000833444-17-000044:mdna:44]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Equity income | $ | 69 |  |  | $ | 45 |  |  | 53 | % |  | $ | 177 |  |  | $ | 127 |  |  | 39 | % |

[0000833444-17-000044:mdna:45]
The increase in equity income for the three and nine months ended June 30, 2017 was primarily due to higher income at certain partially-owned affiliates of the Power Solutions business and the Johnson Controls - Hitachi (JCH) joint venture in the Building Technologies & Solutions business. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-17-000044:mdna:46]
[same as prior period, unchanged from 0000833444-17-000016:mdna:45]

[0000833444-17-000044:mdna:47]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Income tax provision | $ | 89 |  |  | $ | 78 |  |  | 14 | % |  | $ | 570 |  |  | $ | 202 |  |  | * |
| Effective tax rate | 12 | % |  | 16 | % |  |  |  | 38 | % |  | 17 | % |  |  |

[0000833444-17-000044:mdna:48]
[same as prior period, unchanged from 0000833444-17-000016:mdna:47]

[0000833444-17-000044:mdna:49]
[same as prior period, unchanged from 0000833444-17-000016:mdna:48]

[0000833444-17-000044:mdna:50]
The U.S. federal statutory tax rate is being used as a comparison since the Company was a U.S. domiciled company for 11 months of 2016 and due to the Company's current legal entity structure. For the three months ended June 30, 2017, the Company's effective tax rate for continuing operations was 12%.  The effective tax rate was lower than the U.S. federal statutory rate of 35% primarily due to the benefits of continuing global tax planning initiatives and non-U.S. tax rate differentials, partially offset by the jurisdictional mix of Tyco Merger transaction and integration costs. For the nine months ended June 30, 2017, the Company's effective tax rate for continuing operations was 38%. The effective tax rate was higher than the U.S. federal statutory rate of 35% primarily due to the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries related to the pending divestiture of the Scott Safety business, the jurisdictional mix of significant restructuring and impairment costs, and Tyco Merger transaction / integration costs and purchase accounting impacts, partially offset by the benefits of continuing global tax planning initiatives, non-U.S. tax rate differentials and a tax benefit due to changes in entity tax status. For the three and nine months ended June 30, 2016, the Company's effective tax rate for continuing operations was 16% and 17%, respectively. The effective rate was lower than the U.S. federal statutory rate of 35% primarily due to the benefits of continuing global tax planning initiatives and non-U.S. tax rate differentials, partially offset by the tax impact of transaction and separation costs. The effective tax rate for the nine months ended June 30, 2017, increased as compared to the nine months ended June 30, 2016, primarily due to the discrete tax items described below, partially offset by tax planning initiatives. The global tax planning initiatives related primarily to foreign tax credit planning, global financing structures and alignment of our global business functions in a tax efficient manner.

[0000833444-17-000044:mdna:51]
In the third quarter of fiscal 2017, the Company recorded $70 million of transaction and integration costs which generated an $11 million tax benefit.

[0000833444-17-000044:mdna:52]
In the third quarter of fiscal 2017, the Company recorded $49 million of significant restructuring and impairment costs. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $15 million tax benefit.

[0000833444-17-000044:mdna:53]
[same as prior period, unchanged from 0000833444-17-000016:mdna:67]

[0000833444-17-000044:mdna:54]
[same as prior period, unchanged from 0000833444-17-000016:mdna:50]

[0000833444-17-000044:mdna:55]
[same as prior period, unchanged from 0000833444-17-000016:mdna:51]

[0000833444-17-000044:mdna:56]
[same as prior period, unchanged from 0000833444-17-000016:mdna:53]

[0000833444-17-000044:mdna:57]
[same as prior period, unchanged from 0000833444-17-000016:mdna:54]

[0000833444-17-000044:mdna:58]
[same as prior period, unchanged from 0000833444-17-000016:mdna:55]

[0000833444-17-000044:mdna:59]
[same as prior period, unchanged from 0000833444-17-000016:mdna:56]

[0000833444-17-000044:mdna:60]
In the third quarter of fiscal 2016, the Company recorded $27 million of significant restructuring and impairment costs. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $12 million tax benefit, which was impacted by the geographic mix and the Company’s current tax position in these jurisdictions.

[0000833444-17-000044:mdna:61]
[same as prior period, unchanged from 0000833444-17-000016:mdna:57]

[0000833444-17-000044:mdna:62]
Income (Loss) From Discontinued Operations, Net of Tax

[0000833444-17-000044:mdna:63]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Income (loss) from discontinued operations, net of tax | $ | — |  |  | $ | 57 |  |  | * |  | $ | (34 | ) |  | $ | (481 | ) |  | * |

[0000833444-17-000044:mdna:64]
[same as prior period, unchanged from 0000833444-17-000016:mdna:60]

[0000833444-17-000044:mdna:65]
[same as prior period, unchanged from 0000833444-17-000016:mdna:61]

[0000833444-17-000044:mdna:66]
[same as prior period, unchanged from 0000833444-17-000016:mdna:62]

[0000833444-17-000044:mdna:67]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 74 |  |  | $ | 55 |  |  | 35 | % |  | $ | 147 |  |  | $ | 116 |  |  | 27 | % |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  | 21 |  |  | * |  |  | 9 |  |  | 61 |  |  | -85 | % |

[0000833444-17-000044:mdna:68]
[same as prior period, unchanged from 0000833444-17-000016:mdna:64]

[0000833444-17-000044:mdna:69]
The increase in income from continuing operations attributable to noncontrolling interests for the three and nine months ended June 30, 2017, was primarily due to higher net income related to the JCH joint venture in the Building Technologies & Solutions business.

[0000833444-17-000044:mdna:70]
[same as prior period, unchanged from 0000833444-17-000016:mdna:66]

[0000833444-17-000044:mdna:71]
Net Income Attributable to Johnson Controls

[0000833444-17-000044:mdna:72]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Net income attributable to Johnson Controls | $ | 555 |  |  | $ | 383 |  |  | 45 | % |  | $ | 736 |  |  | $ | 303 |  |  | * |

[0000833444-17-000044:mdna:73]
[same as prior period, unchanged from 0000833444-17-000016:mdna:70]

[0000833444-17-000044:mdna:74]
The increase in net income attributable to Johnson Controls for the three months ended June 30, 2017 was primarily due to incremental operating income as a result of the Tyco Merger, partially offset by higher net financing charges. Diluted earnings per share attributable to Johnson Controls for the three months ended June 30, 2017 and 2016 was $0.59.

[0000833444-17-000044:mdna:75]
The increase in net income attributable to Johnson Controls for the nine months ended June 30, 2017 was primarily due to incremental operating income as a result of the Tyco Merger and a prior year loss from discontinued operations, partially offset by an increase in the income tax provision and higher net financing charges. Diluted earnings per share attributable to Johnson Controls for the nine months ended June 30, 2017 was $0.78 compared to $0.47 for the nine months ended June 30, 2016.

[0000833444-17-000044:mdna:76]
Comprehensive Income Attributable to Johnson Controls

[0000833444-17-000044:mdna:77]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Comprehensive income attributable to Johnson Controls | $ | 813 |  |  | $ | 248 |  |  | * |  | $ | 579 |  |  | $ | 186 |  |  | * |

[0000833444-17-000044:mdna:78]
[same as prior period, unchanged from 0000833444-17-000016:mdna:74]

[0000833444-17-000044:mdna:79]
The increase in comprehensive income attributable to Johnson Controls for the three months ended June 30, 2017 was primarily due to an increase in other comprehensive income attributable to Johnson Controls ($393 million) resulting primarily from favorable foreign currency translation adjustments and higher net income attributable to Johnson Controls ($172 million). These year-over-year favorable foreign currency translation adjustments were primarily driven by the strengthening of the euro currency against the U.S. dollar.

[0000833444-17-000044:mdna:80]
The increase in comprehensive income attributable to Johnson Controls for the nine months ended June 30, 2017 was primarily due to higher net income attributable to Johnson Controls ($433 million), partially offset by a decrease in other comprehensive loss attributable to Johnson Controls ($40 million) resulting primarily from unfavorable foreign currency translation adjustments. These year-over-year unfavorable foreign currency translation adjustments were primarily driven by the weakening of the Japanese yen currency against the U.S. dollar.

[0000833444-17-000044:mdna:81]
[same as prior period, unchanged from 0000833444-17-000016:mdna:77]

[0000833444-17-000044:mdna:82]
[same as prior period, unchanged from 0000833444-17-000016:mdna:78]

[0000833444-17-000044:mdna:83]
[same as prior period, unchanged from 0000833444-17-000016:mdna:80]

[0000833444-17-000044:mdna:84]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Building Efficiency |  |  |  |  |  |  |  |  |  |  |  |
| Systems and Service North America | $ | 1,128 |  |  | $ | 1,113 |  |  | 1 | % |  | $ | 3,103 |  |  | $ | 3,131 |  |  | -1 | % |
| Products North America | 698 |  |  | 690 |  |  | 1 | % |  | 1,826 |  |  | 1,793 |  |  | 2 | % |
| Asia | 1,456 |  |  | 1,361 |  |  | 7 | % |  | 3,671 |  |  | 3,515 |  |  | 4 | % |
| Rest of World | 456 |  |  | 471 |  |  | -3 | % |  | 1,278 |  |  | 1,302 |  |  | -2 | % |
|  | 3,738 |  |  | 3,635 |  |  | 3 | % |  | 9,878 |  |  | 9,741 |  |  | 1 | % |
| Tyco | 2,336 |  |  | — |  |  | * |  |  | 6,953 |  |  | — |  |  | * |  |
|  | $ | 6,074 |  |  | $ | 3,635 |  |  | 67 | % |  | $ | 16,831 |  |  | $ | 9,741 |  |  | 73 | % |

[0000833444-17-000044:mdna:85]
[same as prior period, unchanged from 0000833444-17-000016:mdna:82]

[0000833444-17-000044:mdna:86]
[same as prior period, unchanged from 0000833444-17-000016:mdna:83]

[0000833444-17-000044:mdna:87]
| • | The increase in Systems and Service North America was due to higher volumes of controls systems and service ($22 million), partially offset by a prior year business divestiture ($4 million) and the unfavorable impact of foreign currency translation ($3 million). The increase in volumes was primarily attributable to market growth. |

[0000833444-17-000044:mdna:88]
| • | The increase in Products North America was due to higher volumes ($12 million), partially offset by a prior year business divestiture ($2 million) and the unfavorable impact of foreign currency translation ($2 million). The increase in volumes was primarily attributable to new product offerings. |

[0000833444-17-000044:mdna:89]
| • | The increase in Asia was due to higher volumes of equipment and control systems ($119 million) and higher service volumes ($4 million), partially offset by the unfavorable impact of foreign currency translation ($17 million) and lower volumes related to a business deconsolidation ($11 million). The increase in volumes was primarily due to new product offerings and favorable local market conditions. |

[0000833444-17-000044:mdna:90]
| • | The decrease in Rest of World was due to a prior year business divestiture ($11 million), the unfavorable impact of foreign currency translation ($8 million) and lower volumes in Latin America ($3 million), partially offset by higher volumes in Europe ($5 million) and in the Middle East ($2 million). |

[0000833444-17-000044:mdna:91]
| • | The increase in Tyco was due to incremental sales related to the Tyco Merger ($2,336 million). |

[0000833444-17-000044:mdna:92]
[same as prior period, unchanged from 0000833444-17-000016:mdna:89]

[0000833444-17-000044:mdna:93]
| • | The decrease in Systems and Service North America was due to a prior year business divestiture ($32 million), partially offset by higher volumes of controls systems and service ($4 million). |

[0000833444-17-000044:mdna:94]
| • | The increase in Products North America was due to higher volumes ($44 million), partially offset by a prior year business divestiture ($7 million) and the unfavorable impact of foreign currency translation ($4 million). The increase in volumes was primarily attributable to market share changes and new product offerings. |

[0000833444-17-000044:mdna:95]
| • | The increase in Asia was due to higher volumes of equipment and control systems ($136 million), higher service volumes ($25 million) and the favorable impact of foreign currency translation ($24 million), partially offset by lower volumes related to a business deconsolidation ($29 million). The increase in volumes was primarily due to new product offerings and favorable local market conditions. |

[0000833444-17-000044:mdna:96]
| • | The decrease in Rest of World was due to a prior year business divestiture ($27 million), the unfavorable impact of foreign currency translation ($19 million) and lower volumes in the Middle East ($15 million), partially offset by higher volumes in Europe ($30 million) and Latin America ($7 million). |

[0000833444-17-000044:mdna:97]
| • | The increase in Tyco was due to incremental sales related to the Tyco Merger ($6,953 million). |

[0000833444-17-000044:mdna:98]
[same as prior period, unchanged from 0000833444-17-000016:mdna:96]

[0000833444-17-000044:mdna:99]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Building Efficiency |  |  |  |  |  |  |  |  |  |  |  |
| Systems and Service North America | $ | 126 |  |  | $ | 142 |  |  | -11 | % |  | $ | 291 |  |  | $ | 342 |  |  | -15 | % |
| Products North America | 98 |  |  | 96 |  |  | 2 | % |  | 192 |  |  | 176 |  |  | 9 | % |
| Asia | 246 |  |  | 180 |  |  | 37 | % |  | 483 |  |  | 368 |  |  | 31 | % |
| Rest of World | 26 |  |  | 22 |  |  | 18 | % |  | 25 |  |  | 29 |  |  | -14 | % |
|  | 496 |  |  | 440 |  |  | 13 | % |  | 991 |  |  | 915 |  |  | 8 | % |
| Tyco | 416 |  |  | — |  |  | * |  |  | 1,009 |  |  | — |  |  | * |  |
|  | $ | 912 |  |  | $ | 440 |  |  | * |  |  | $ | 2,000 |  |  | $ | 915 |  |  | * |  |

[0000833444-17-000044:mdna:100]
[same as prior period, unchanged from 0000833444-17-000016:mdna:98]

[0000833444-17-000044:mdna:101]
[same as prior period, unchanged from 0000833444-17-000016:mdna:99]

[0000833444-17-000044:mdna:102]
| • | The decrease in Systems and Service North America was due to a prior year gain on business divestiture ($14 million), higher selling, general and administrative expenses ($5 million), current year transaction costs ($2 million) and current year integration costs ($1 million), partially offset by higher volumes ($6 million). |

[0000833444-17-000044:mdna:103]
| • | The increase in Products North America was due to favorable mix ($5 million), higher volumes ($3 million) and higher equity income ($1 million), partially offset by higher selling, general and administrative expenses ($4 million), current year transaction costs ($2 million) and current year integration costs ($1 million). |

[0000833444-17-000044:mdna:104]
| • | The increase in Asia was due to higher volumes ($35 million), higher equity income ($9 million), lower operating costs ($7 million), prior year integration costs ($7 million), lower selling, general and administrative expenses ($6 million), and favorable mix ($4 million), partially offset by the unfavorable impact of foreign currency translation ($2 million). |

[0000833444-17-000044:mdna:105]
| • | The increase in Rest of World was due to lower selling, general and administrative expenses ($5 million), lower operating costs ($3 million) and higher volumes ($1 million), partially offset by a prior year business divestiture ($2 million), the unfavorable impact of foreign currency translation ($2 million) and current year transaction costs ($1 million). |

[0000833444-17-000044:mdna:106]
| • | The increase in Tyco was due to incremental income related to the Tyco Merger ($405 million) and the impact of nonrecurring purchasing accounting adjustments ($24 million), partially offset by current year integration costs ($12 million) and current year transaction costs ($1 million). |

[0000833444-17-000044:mdna:107]
[same as prior period, unchanged from 0000833444-17-000016:mdna:105]

[0000833444-17-000044:mdna:108]
| • | The decrease in Systems and Service North America was due to higher operating costs as a result of channel investments ($29 million), a prior year gain on business divestiture ($14 million), current year transaction costs ($5 million), current |

[0000833444-17-000044:mdna:109]
[same as prior period, unchanged from 0000833444-17-000016:mdna:121]

[0000833444-17-000044:mdna:110]
year integration costs ($4 million) and a prior year business divestiture ($2 million), partially offset by lower selling, general and administrative expenses ($3 million).

[0000833444-17-000044:mdna:111]
| • | The increase in Products North America was due to lower operating costs as a result of cost reduction initiatives ($15 million), higher volumes ($10 million), and favorable mix ($7 million), partially offset by current year transaction costs ($5 million), current year integration costs ($5 million), higher selling, general and administrative expenses ($4 million), and the unfavorable impact of foreign currency translation ($2 million). |

[0000833444-17-000044:mdna:112]
| • | The increase in Asia was due to higher volumes ($44 million), lower selling, general and administrative expenses as a result of productivity and synergy savings ($32 million), higher equity income ($23 million), prior year integration costs ($15 million), prior year transaction costs ($10 million), and favorable mix ($4 million), partially offset by higher operating costs due to product investments ($11 million) and the unfavorable impact of foreign currency translation ($2 million). |

[0000833444-17-000044:mdna:113]
| • | The decrease in Rest of World was due to lower equity income ($8 million), a prior year gain on acquisition of a partially-owned affiliate ($4 million), the unfavorable impact of foreign currency translation ($4 million), a prior year business divestiture ($3 million), current year integration costs ($1 million) and current year transaction costs ($1 million), partially offset by lower selling, general and administrative expenses as a result of productivity and synergy savings ($14 million), and higher volumes ($3 million). |

[0000833444-17-000044:mdna:114]
| • | The increase in Tyco was due to incremental income related to the Tyco Merger ($1,102 million), partially offset by the impact of nonrecurring purchasing accounting adjustments ($37 million), current year integration costs ($35 million) and current year transaction costs ($21 million). |

[0000833444-17-000044:mdna:115]
[same as prior period, unchanged from 0000833444-17-000016:mdna:111]

[0000833444-17-000044:mdna:116]
|  | Three Months EndedJune 30, |  |  |  | Nine Months EndedJune 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Net sales | $ | 1,609 |  |  | $ | 1,519 |  |  | 6 | % |  | $ | 5,205 |  |  | $ | 4,842 |  |  | 7 | % |
| Segment EBITA | 304 |  |  | 280 |  |  | 9 | % |  | 996 |  |  | 922 |  |  | 8 | % |

[0000833444-17-000044:mdna:117]
[same as prior period, unchanged from 0000833444-17-000016:mdna:113]

[0000833444-17-000044:mdna:118]
| • | Net sales increased due to the impact of higher lead costs on pricing ($124 million), and favorable pricing and product mix ($27 million), partially offset by lower volumes ($56 million) and the unfavorable impact of foreign currency translation ($5 million). The decrease in volumes was driven by changes in customer demand patterns in Europe and North America, partially offset by an increase in start-stop battery volumes. Additionally, higher start-stop volumes contributed to favorable product mix. |

[0000833444-17-000044:mdna:119]
| • | Segment EBITA increased due to favorable pricing and product mix net of lead cost increases ($41 million), lower selling, general and administrative expenses as a result of productivity savings ($15 million), higher equity income ($12 million) and prior year transaction costs ($1 million), partially offset by higher operating costs primarily driven by efforts to satisfy customer demand ($27 million), lower volumes ($15 million) and the unfavorable impact of foreign currency translation ($3 million). |

[0000833444-17-000044:mdna:120]
[same as prior period, unchanged from 0000833444-17-000016:mdna:116]

[0000833444-17-000044:mdna:121]
| • | Net sales increased due to the impact of higher lead costs on pricing ($298 million), and favorable pricing and product mix ($85 million), partially offset by the unfavorable impact of foreign currency translation ($20 million). Higher start-stop volumes contributed to favorable product mix. |

[0000833444-17-000044:mdna:122]
| • | Segment EBITA increased due to favorable pricing and product mix net of lead cost increases ($81 million), higher equity income ($30 million), lower selling, general and administrative expenses as a result of productivity savings ($24 million), and prior year transaction costs ($1 million), partially offset by higher operating costs primarily driven by efforts to satisfy customer demand ($56 million), the unfavorable impact of foreign currency translation ($5 million) and transaction costs ($1 million). |

[0000833444-17-000044:mdna:123]
[same as prior period, unchanged from 0000833444-17-000016:mdna:119]

[0000833444-17-000044:mdna:124]
The Company's backlog relating to the Building Technologies & Solutions business is applicable to its sales of systems and services. At June 30, 2017, the backlog was $8.4 billion and reflects harmonization of the Company's method for determining backlog subsequent to the Tyco Merger. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned during the fiscal year.

[0000833444-17-000044:mdna:125]
[same as prior period, unchanged from 0000833444-17-000016:mdna:122]

[0000833444-17-000044:mdna:126]
[same as prior period, unchanged from 0000833444-17-000016:mdna:123]

[0000833444-17-000044:mdna:127]
|  | June 30, |  | September 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Current assets | $ | 13,962 |  |  | $ | 17,109 |  |  |  |
| Current liabilities | (11,515 | ) |  | (16,331 | ) |  |  |
|  | 2,447 |  |  | 778 |  |  | * |  |
| Less: Cash | (458 | ) |  | (579 | ) |  |  |
| Add: Short-term debt | 1,956 |  |  | 1,078 |  |  |  |
| Add: Current portion of long-term debt | 543 |  |  | 628 |  |  |  |
| Less: Assets held for sale | (2,082 | ) |  | (5,812 | ) |  |  |
| Add: Liabilities held for sale | 247 |  |  | 4,276 |  |  |  |
| Working capital (as defined) | $ | 2,653 |  |  | $ | 369 |  |  | * |  |
| Accounts receivable - net | $ | 6,443 |  |  | $ | 6,394 |  |  | 1 | % |
| Inventories | 3,384 |  |  | 2,888 |  |  | 17 | % |
| Accounts payable | 3,764 |  |  | 4,000 |  |  | -6 | % |
| * Measure not meaningful |  |  |  |  |  |

[0000833444-17-000044:mdna:128]
[same as prior period, unchanged from 0000833444-17-000016:mdna:125]

[0000833444-17-000044:mdna:129]
| • | Excluding the impact of amounts classified as held for sale, the increase in working capital at June 30, 2017, as compared to September 30, 2016, was primarily due to income tax payments related to the Adient spin-off, an increase in inventory to meet anticipated customer demand and a decrease in accounts payable due to timing and mix of supplier payments. |

[0000833444-17-000044:mdna:130]
| • | The Company’s days sales in accounts receivable at June 30, 2017 were 65 days, higher than 61 days at September 30, 2016. There have been no changes in revenue recognition methods. Increased volumes in certain of the segments and seasonality contributed to the increase. |

[0000833444-17-000044:mdna:131]
| • | The Company’s inventory turns for the three months ended June 30, 2017 were significantly lower than the comparable period ended September 30, 2016, primarily due to a build of Power Solutions inventory levels to meet customer demand. |

[0000833444-17-000044:mdna:132]
| • | Days in accounts payable at June 30, 2017 were 63 days, lower than 69 days at the comparable period ended September 30, 2016 due primarily to the mix of payables. |

[0000833444-17-000044:mdna:133]
67

[0000833444-17-000044:mdna:134]
[same as prior period, unchanged from 0000833444-17-000016:mdna:130]

[0000833444-17-000044:mdna:135]
|  |  | Nine Months EndedJune 30, |
| (in millions) |  | 2017 |  | 2016 |
| Cash provided (used) by operating activities |  | $ | (1,321 | ) |  | $ | 696 |  |
| Cash used by investing activities |  | (832 | ) |  | (871 | ) |
| Cash provided by financing activities |  | 1,915 |  |  | 40 |  |
| Capital expenditures |  | (996 | ) |  | (822 | ) |

[0000833444-17-000044:mdna:136]
| • | The increase in cash used by operating activities for the nine months ended June 30, 2017 was primarily due to higher income tax payments primarily due to the Adient spin-off ($1.2 billion in the first quarter of fiscal 2017) and the movement in trade working capital balances. |

[0000833444-17-000044:mdna:137]
| • | The decrease in cash used by investing activities for the nine months ended June 30, 2017 was primarily due to cash received from a business divestiture in the current year and cash paid for the JCH joint venture in the prior year, partially offset by an increase in capital expenditures. |

[0000833444-17-000044:mdna:138]
| • | The increase in cash provided by financing activities for the nine months ended June 30, 2017 was primarily due to the net dividend proceeds from the Adient spin-off and an increase in current year borrowings. |

[0000833444-17-000044:mdna:139]
| • | The increase in capital expenditures for the nine months ended June 30, 2017 primarily relates to Tyco capital investments in the current year and higher capital investments in the Building Efficiency and Power Solutions businesses. |

[0000833444-17-000044:mdna:140]
[same as prior period, unchanged from 0000833444-17-000016:mdna:136]

[0000833444-17-000044:mdna:141]
[same as prior period, unchanged from 0000833444-17-000016:mdna:137]

[0000833444-17-000044:mdna:142]
[same as prior period, unchanged from 0000833444-17-000016:mdna:138]

[0000833444-17-000044:mdna:143]
[same as prior period, unchanged from 0000833444-17-000016:mdna:139]

[0000833444-17-000044:mdna:144]
[same as prior period, unchanged from 0000833444-17-000016:mdna:140]

[0000833444-17-000044:mdna:145]
In the first, second and third quarters of fiscal 2017, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2017. As a result, the Company reviewed the long-lived assets for impairment and recorded $69 million of asset impairment charges within restructuring and impairment costs on the consolidated statements of income, of which $15 million was recorded in the first quarter, $23 million was recorded in the second quarter and $31 million was recorded in the third quarter. Of the total impairment charges, $27 million related to the Tyco segment, $20 million related to the Building Efficiency Products North America segment, $17

[0000833444-17-000044:mdna:146]
million related to Corporate assets, $4 million related to the Power Solutions segment, and $1 million related to the Building Efficiency Systems and Services North America segment. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-17-000044:mdna:147]
In the second and third quarters of fiscal 2016, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2016. As a result, the Company reviewed the long-lived assets for impairment and recorded $65 million of asset impairment charges within restructuring and impairment costs on the consolidated statements of income, of which $15 million was recorded in the second quarter and $50 million was recorded in the third quarter. Of the total impairment charge, $50 million related to Corporate assets, $8 million related to the Building Efficiency Products North America segment, $4 million related to the Building Efficiency Asia segment and $3 million related to the Building Efficiency Rest of World segment. In addition, the Company recorded $15 million of asset impairments within discontinued operations related to Adient in fiscal 2016. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-17-000044:mdna:148]
At June 30, 2017 and 2016, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets

[0000833444-17-000044:mdna:149]
[same as prior period, unchanged from 0000833444-17-000016:mdna:145]

[0000833444-17-000044:mdna:150]
|  | June 30, |  | September 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Short-term debt | $ | 1,956 |  |  | $ | 1,078 |  |  |  |
| Current portion of long-term debt | 543 |  |  | 628 |  |  |  |
| Long-term debt | 11,772 |  |  | 11,053 |  |  |  |
| Total debt | 14,271 |  |  | 12,759 |  |  | 12 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 19,731 |  |  | 24,118 |  |  | -18 | % |
| Total capitalization | $ | 34,002 |  |  | $ | 36,877 |  |  | -8 | % |
| Total debt as a % of total capitalization | 42 | % |  | 35 | % |  |  |

[0000833444-17-000044:mdna:151]
[same as prior period, unchanged from 0000833444-17-000016:mdna:147]

[0000833444-17-000044:mdna:152]
[same as prior period, unchanged from 0000833444-17-000016:mdna:148]

[0000833444-17-000044:mdna:153]
| • | In connection with the Tyco Merger, on December 28, 2016, the Company completed its offers to exchange all validly tendered and accepted notes of certain series (the "existing notes") issued by JCI Inc. or Tyco International Finance S.A. ("TIFSA"), as applicable, each of which is a wholly owned subsidiary of the Company, for new notes (the New Notes) to be issued by the Company, and the related solicitation of consents to amend the indentures governing the existing notes (the offers to exchange and the related consent solicitation together the "exchange offers"). Pursuant to the exchange offers, the Company exchanged approximately $5.6 billion of $6.0 billion in aggregate principal amount of dollar denominated notes and approximately 423 million euro of 500 million euro in aggregate principal amount of euro denominated notes. All validly tendered and accepted existing notes have been canceled. Immediately following such cancellation, $380.9 million aggregate |

[0000833444-17-000044:mdna:154]
[same as prior period, unchanged from 0000833444-17-000016:mdna:169]

[0000833444-17-000044:mdna:155]
principal amount of existing notes (not including the TIFSA Euro Notes) remained outstanding across seventeen series of dollar-denominated existing notes and 77.4 million euro aggregate principal amount of TIFSA Euro Notes remained outstanding across one series. In connection with the settlement of the exchange offers, the New Notes were registered under the Securities Act of 1933 and their terms are described in the Company’s Prospectus dated December 19, 2016, as filed with the SEC under Rule 424(b)(3) of the Act on that date. The issuance of the New Notes occurred on December 28, 2016. The New Notes are unsecured and unsubordinated obligations of the Company and will rank equally with all other unsecured and unsubordinated indebtedness of the Company issued from time to time.

[0000833444-17-000044:mdna:156]
| • | In June 2017, the Company partially repaid $135 million of the $4.0 billion floating rate term loan scheduled to mature in March 2020. |

[0000833444-17-000044:mdna:157]
[same as prior period, unchanged from 0000833444-17-000016:mdna:152]

[0000833444-17-000044:mdna:158]
| • | In March 2017, the Company entered into a 364-day $150 million committed revolving credit facility scheduled to expire in March 2018. As of June 30, 2017, there were no draws on the facility. |

[0000833444-17-000044:mdna:159]
[same as prior period, unchanged from 0000833444-17-000016:mdna:154]

[0000833444-17-000044:mdna:160]
[same as prior period, unchanged from 0000833444-17-000016:mdna:155]

[0000833444-17-000044:mdna:161]
[same as prior period, unchanged from 0000833444-17-000016:mdna:156]

[0000833444-17-000044:mdna:162]
| • | In February 2017, the Company entered into a 364-day $150 million committed revolving credit facility scheduled to expire in February 2018. As of June 30, 2017, there were no draws on the facility. |

[0000833444-17-000044:mdna:163]
| • | In January 2017, the Company entered into a 364-day $250 million committed revolving credit facility scheduled to expire in January 2018. As of June 30, 2017, there were no draws on the facility outstanding. |

[0000833444-17-000044:mdna:164]
[same as prior period, unchanged from 0000833444-17-000016:mdna:159]

[0000833444-17-000044:mdna:165]
[same as prior period, unchanged from 0000833444-17-000016:mdna:160]

[0000833444-17-000044:mdna:166]
| • | In December 2016, a $100 million committed revolving credit facility expired. There were no draws on the facility. |

[0000833444-17-000044:mdna:167]
[same as prior period, unchanged from 0000833444-17-000016:mdna:162]

[0000833444-17-000044:mdna:168]
| • | In November 2016, a $35 million committed revolving credit facility expired. There were no draws on the facility. |

[0000833444-17-000044:mdna:169]
[same as prior period, unchanged from 0000833444-17-000016:mdna:164]

[0000833444-17-000044:mdna:170]
[same as prior period, unchanged from 0000833444-17-000016:mdna:165]

[0000833444-17-000044:mdna:171]
[same as prior period, unchanged from 0000833444-17-000016:mdna:166]

[0000833444-17-000044:mdna:172]
70

[0000833444-17-000044:mdna:173]
| • | The Company also selectively makes use of short-term credit lines other than its revolving credit facilities at the Company and TSarl. The Company estimates that, as of June 30, 2017, it could borrow up to $1.4 billion based on average borrowing levels during the quarter on committed credit lines. |

[0000833444-17-000044:mdna:174]
| • | The Company believes its capital resources and liquidity position at June 30, 2017 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, stock repurchases, minimum pension contributions, debt maturities and any potential acquisitions in the remainder of fiscal 2017 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company and TSarl are unable to issue commercial paper, they would have the ability to draw on their $2.0 billion and $1.0 billion revolving credit facilities, respectively. Both facilities mature in August 2020. There were no draws on the revolving credit facility as of June 30, 2017 and September 30, 2016. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future. |

[0000833444-17-000044:mdna:175]
[same as prior period, unchanged from 0000833444-17-000016:mdna:171]

[0000833444-17-000044:mdna:176]
| • | The Company’s debt financial covenant in its revolving credit facility require a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification (ASC) 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. TSarl's, revolving credit facility contains customary terms and conditions, and a financial covenant that limits the ratio of TSarl's debt to earnings before interest, taxes, depreciation, and amortization as adjusted for certain items set forth in the agreement to 3.5x. The TSarl's revolving credit facility also limits its ability to incur subsidiary debt or grant liens on its and its subsidiaries' property. As of June 30, 2017, the Company and TSarl were in compliance with all covenants and other requirements set forth in their credit agreements and the indentures, governing their notes, and expect to remain in compliance for the foreseeable future. None of the Company’s or TSarl's debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the respective borrower's credit rating. |

[0000833444-17-000044:mdna:177]
[same as prior period, unchanged from 0000833444-17-000016:mdna:186]

[0000833444-17-000044:mdna:178]
[same as prior period, unchanged from 0000833444-17-000016:mdna:173]

[0000833444-17-000044:mdna:179]
Recently Adopted Accounting Pronouncements

[0000833444-17-000044:mdna:180]
In October 2016, the FASB issued Accounting Standards Update (ASU) No. 2016-17, "Consolidations (Topic 810): Interests Held through Related Parties that are under Common Control." The ASU changes how a single decision maker of a VIE that holds indirect interest in the entity through related parties that are under common control determines whether it is the primary beneficiary of the VIE. The new guidance amends ASU 2015-02, "Consolidation (Topic 810): Amendments to the Consolidation Analysis" issued in February 2015. ASU No. 2016-17 was effective for the Company for the quarter ending December 31, 2016. The adoption of this guidance did not have an impact on the Company's consolidated financial statements.

[0000833444-17-000044:mdna:181]
In May 2015, the FASB issued ASU No. 2015-07, "Disclosures for Investments in Certain Entities That Calculate Net Asset Value per Share (or Its Equivalent)." ASU No. 2015-07 removes the requirement to categorize within the fair value hierarchy all investments for which fair value is measured using the net asset value per share practical expedient. Such investments should be disclosed separate from the fair value hierarchy. ASU No. 2015-07 was effective retrospectively for the Company for the quarter ending December 31, 2016. The adoption of this guidance did not have an impact on the Company's consolidated financial statements, but did impact pension asset disclosures.

[0000833444-17-000044:mdna:182]
In April 2015, the FASB issued ASU No. 2015-03, "Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs." ASU No. 2015-03 requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the debt liability. ASU No. 2015-03 was effective retrospectively for the Company for the quarter ending December 31, 2016. The adoption of this guidance did not have a significant impact on the Company's consolidated financial statements.

[0000833444-17-000044:mdna:183]
In February 2015, the FASB issued ASU No. 2015-02, "Consolidation (Topic 810): Amendments to the Consolidation Analysis." ASU No. 2015-02 amends the analysis performed to determine whether a reporting entity should consolidate certain types of legal entities. ASU No. 2015-02 was effective retrospectively for the Company for the quarter ending December 31, 2016. The adoption of this guidance did not have an impact on the Company's consolidated financial statements.

[0000833444-17-000044:mdna:184]
Recently Issued Accounting Pronouncements

[0000833444-17-000044:mdna:185]
In May 2017, the FASB issued ASU No. 2017-09, "Compensation — Stock Compensation (Topic 718): Scope of Modification Accounting." The ASU provides guidance about which changes to the terms or conditions of a share-based payment award require a reporting entity to apply modification accounting. ASU No. 2017-09 will be effective prospectively for the Company for the quarter ending December 31, 2018, with early adoption permitted. The impact of this guidance for the Company is dependent on any future share-based payment award changes, should they occur.

[0000833444-17-000044:mdna:186]
In March 2017, the FASB issued ASU No. 2017-07, "Compensation—Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost." The ASU requires the service cost component of net periodic benefit cost to be presented with other compensation costs. The other components of net periodic benefit cost are required to be presented in the income statement separately from the service cost component and outside a subtotal of income from operations, if one is presented. The ASU also allows only the service cost component of net periodic benefit cost to be eligible for capitalization. The guidance will be effective for the Company for the quarter ending December 31, 2018. Early adoption is permitted as of the beginning of an annual period for which financial statements (interim or annual) have not been issued or made available for issuance. The guidance will be effective retrospectively except for the capitalization of the service cost component which should be applied prospectively. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements.

[0000833444-17-000044:mdna:187]
In January 2017, the FASB issued ASU No. 2017-04, "Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment," which eliminates the requirement to calculate the implied fair value of goodwill to measure a goodwill impairment charge (Step 2) from the goodwill impairment test. Instead, an impairment charge will equal the amount by which a reporting unit’s carrying amount exceeds its fair value, not to exceed the amount of goodwill allocated to the reporting unit. The guidance will be effective prospectively for the Company for the quarter ending December 31, 2020, with early adoption permitted after January 1, 2017. The impact of this guidance for the Company will depend on the outcomes of future goodwill impairment tests.

[0000833444-17-000044:mdna:188]
In November 2016, the FASB issued ASU No. 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force)." The ASU requires amounts generally described as restricted cash and restricted cash

[0000833444-17-000044:mdna:189]
72

[0000833444-17-000044:mdna:190]
equivalents to be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. The guidance will be effective for the Company for the quarter ending December 31, 2018, with early adoption permitted. The amendments in this update should be applied retrospectively to all periods presented. The impact of this guidance for the Company will depend on the levels of restricted cash balances in the periods presented.

[0000833444-17-000044:mdna:191]
In October 2016, the FASB issued ASU No. 2016-16, "Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory." The ASU requires the tax effects of all intra-entity sales of assets other than inventory to be recognized in the period in which the transaction occurs. The guidance will be effective for the Company for the quarter ending December 31, 2018, with early adoption permitted but only in the first interim period of a fiscal year. The changes are required to be applied by means of a cumulative-effect adjustment recorded in retained earnings as of the beginning of the fiscal year of adoption. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-17-000044:mdna:192]
In August 2016, the FASB issued ASU No. 2016-15, "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments." ASU No. 2016-15 provides clarification guidance on eight specific cash flow presentation issues in order to reduce the diversity in practice. ASU No. 2016-15 will be effective for the Company for the quarter ending December 31, 2018, with early adoption permitted. The guidance should be applied retrospectively to all periods presented, unless deemed impracticable, in which case prospective application is permitted. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-17-000044:mdna:193]
In June 2016, the FASB issued ASU No. 2016-13, "Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments." ASU No. 2016-13 changes the impairment model for financial assets measured at amortized cost, requiring presentation at the net amount expected to be collected. The measurement of expected credit losses is based upon historical experience, current conditions, and reasonable and supportable forecasts. Available-for-sale debt securities with unrealized losses will now be recorded through an allowance for credit losses. ASU No. 2016-13 will be effective for the Company for the quarter ended December 31, 2020, with early adoption permitted for the quarter ended December 31, 2019. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements.

[0000833444-17-000044:mdna:194]
In March 2016, the FASB issued ASU No. 2016-09, "Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting." ASU No. 2016-09 impacts certain aspects of the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the statements of cash flows. ASU No. 2016-09 will be effective for the Company for the quarter ending December 31, 2017, with early adoption permitted. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-17-000044:mdna:195]
In March 2016, the FASB issued ASU No. 2016-07, "Investments - Equity Method and Joint Ventures (Topic 323): Simplifying the Transition to the Equity Method of Accounting." ASU No. 2016-07 eliminates the requirement for an investment that qualifies for the use of the equity method of accounting as a result of an increase in the level of ownership or degree of influence to adjust the investment, results of operations and retained earnings retrospectively. ASU No. 2016-07 will be effective prospectively for the Company for increases in the level of ownership interest or degree of influence that result in the adoption of the equity method that occur during or after the quarter ending December 31, 2017, with early adoption permitted. The impact of this guidance for the Company is dependent on any future increases in the level of ownership interest or degree of influence that result in the adoption of the equity method.

[0000833444-17-000044:mdna:196]
In February 2016, the FASB issued ASU No. 2016-02, "Leases (Topic 842)." ASU No. 2016-02 requires recognition of operating leases as lease assets and liabilities on the balance sheet, and disclosure of key information about leasing arrangements. ASU No. 2016-02 will be effective retrospectively for the Company for the quarter ending December 31, 2019, with early adoption permitted. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.  The Company has started the assessment process by evaluating the population of leases under the revised definition of what qualifies as a leased asset. The Company is the lessee under various agreements for facilities and equipment that are currently accounted for as operating leases. The new guidance will require the Company to record operating leases on the balance sheet with a right-of-use asset and corresponding liability for future payment obligations. The Company expects the new guidance will have a material impact on its consolidated statements of financial position for the addition of right-of-use assets and lease liabilities, but the Company does not expect it to have a material impact on its consolidated statements of income.

[0000833444-17-000044:mdna:197]
In January 2016, the FASB issued ASU No. 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." ASU No. 2016-01 amends certain aspects of recognition, measurement, presentation and disclosure of financial instruments, including marketable securities. ASU No. 2016-01 will be effective for the Company for the quarter ending December 31, 2018, and early adoption is not permitted, with certain exceptions. The changes

[0000833444-17-000044:mdna:198]
73

[0000833444-17-000044:mdna:199]
are required to be applied by means of a cumulative-effect adjustment on the balance sheet as of the beginning of the fiscal year of adoption. The impact of this guidance for the Company will depend on the magnitude of the unrealized gains and losses on the Company's marketable securities investments.

[0000833444-17-000044:mdna:200]
In July 2015, the FASB issued ASU No. 2015-11, "Simplifying the Measurement of Inventory." ASU No. 2015-11 requires inventory that is recorded using the first-in, first-out method to be measured at the lower of cost or net realizable value. ASU No. 2015-11 will be effective prospectively for the Company for the quarter ending December 31, 2017, with early adoption permitted. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements.

[0000833444-17-000044:mdna:201]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers (Topic 606)." ASU No. 2014-09 clarifies the principles for recognizing revenue when an entity either enters into a contract with customers to transfer goods or services or enters into a contract for the transfer of non-financial assets. The original standard was effective retrospectively for the Company for the quarter ending December 31, 2017; however in August 2015, the FASB issued ASU No. 2015-14, "Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date," which defers the effective date of ASU No. 2014-09 by one-year for all entities. The new standard will become effective retrospectively for the Company for the quarter ending December 31, 2018, with early adoption permitted, but not before the original effective date. Additionally, in March 2016, the FASB issued ASU No. 2016-08, "Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net)," in April 2016, the FASB issued ASU No. 2016-10, "Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing," in May 2016, the FASB issued ASU No. 2016-12, "Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients," and in December 2016, the FASB issued ASU No. 2016-20, "Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers," all of which provide additional clarification on certain topics addressed in ASU No. 2014-09. ASU No. 2016-08, ASU No. 2016-10, ASU No. 2016-12 and ASU No. 2016-20 follow the same implementation guidelines as ASU No. 2014-09 and ASU No. 2015-14. The Company has elected to adopt the new revenue guidance as of October 1, 2018.  In preparation for adoption of the new guidance, the Company has reviewed representative samples of contracts and other forms of agreements with customers globally and is in the process of evaluating the impact of the new revenue standard. Based on its procedures to date, the Company cannot quantify the potential impact the new revenue standard will have to its consolidated financial statements.  The Company will decide which retrospective application to apply once its revenue standard assessment is finalized.
