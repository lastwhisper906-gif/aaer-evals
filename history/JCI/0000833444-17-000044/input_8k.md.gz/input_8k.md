# JCI 8-K — 0000833444-17-000042 filed 2017-07-27

## item codes, every 8-K on or before 2017-08-03

- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2017-08-03

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-17-000042:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq3fy17.htm
EXHIBIT 99.1

[0000833444-17-000042:8k_2_02:2]
Exhibit

[0000833444-17-000042:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000833444-17-000042:8k_2_02:4]
| CONTACT: | Investors:Antonella Franzen(609) 720-4665Ryan Edelman(609) 720-4545Media:Fraser Engerman(414) 524-2733 | Exhibit 99.1 |

[0000833444-17-000042:8k_2_02:5]
Johnson Controls reports third quarter earnings

[0000833444-17-000042:8k_2_02:6]
________________________________________________________________________________

[0000833444-17-000042:8k_2_02:7]
| ▪ | GAAP earnings of $0.59 per share including special items |

[0000833444-17-000042:8k_2_02:8]
| ▪ | Adjusted EPS from continuing operations of $0.71, up 16 percent versus prior year |

[0000833444-17-000042:8k_2_02:9]
| ▪ | Adjusted sales of $7.7 billion, reflecting organic growth of 1 percent versus prior year |

[0000833444-17-000042:8k_2_02:10]
| ▪ | Adjusted EBIT margin expansion of 150 basis points year-over-year, to 13.0 percent |

[0000833444-17-000042:8k_2_02:11]
| ▪ | Fourth quarter adjusted EPS from continuing operations guidance range of $0.86 to $0.88, a 13 percent to 16 percent increase year-over-year |

[0000833444-17-000042:8k_2_02:12]
| ▪ | 2017 adjusted EPS from continuing operations guidance range of $2.60 to $2.62, a 13 percent increase year-over-year |

[0000833444-17-000042:8k_2_02:13]
________________________________________________________________________________

[0000833444-17-000042:8k_2_02:14]
CORK, Ireland, Jul. 27, 2017 -- Johnson Controls International, plc (NYSE: JCI) today reported fiscal third quarter 2017 GAAP earnings per share (“EPS”) from continuing operations, including special items, of $0.59 (see attached footnotes for non-GAAP reconciliation).  Excluding these items, adjusted EPS from continuing operations was $0.71, up 16 percent versus the prior year period.

[0000833444-17-000042:8k_2_02:15]
Adjusted sales of $7.7 billion increased 1 percent compared to the prior year on a combined basis.  Excluding the impacts from net acquisition and divestiture activity, as well as foreign exchange and changes in lead prices, total company sales also grew 1 percent organically.

[0000833444-17-000042:8k_2_02:16]
GAAP earnings before interest and taxes (“EBIT”) was $842 million and the EBIT margin was 11.0 percent. Adjusted EBIT was $1.0 billion, up 15 percent over last year with adjusted EBIT margin expansion of 150 basis points, to 13.0 percent.

[0000833444-17-000042:8k_2_02:17]
“Strong margin expansion, primarily related to the benefit of cost synergies and productivity initiatives, drove our year-over-year double-digit EPS growth in the quarter,” said Alex Molinaroli, Johnson Controls chairman & CEO.  “Although we continue to make significant strides with the merger integration, we have fallen short of our revenue growth expectations for the year and are guiding our full year adjusted earnings per share to the low end of the range previously provided.  Given the very complex merger integration, I am very proud of what our global teams

[0000833444-17-000042:8k_2_02:18]
Page 1 of 16

[0000833444-17-000042:8k_2_02:19]
have accomplished to capture near term synergies and establish a strong strategic platform that will ultimately drive global growth and continued margin expansion across our businesses,” Molinaroli added.

[0000833444-17-000042:8k_2_02:20]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders                                                             ($ millions, except per-share amounts)

[0000833444-17-000042:8k_2_02:21]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the third quarter of 2016, which are adjusted to reflect the combination of Johnson Controls’ historical Building Efficiency business with historical Tyco results of operations as if these businesses had been operated together during the periods presented, along with certain other adjustments.  For additional information, see the unaudited supplemental financial information included in the Current Report on Form 8-K filed by Johnson Controls with the SEC on Nov. 8, 2016 as well as the attached footnotes.  The spin-off of Adient plc occurred on Oct. 31, 2016 and the results of this business are reported in discontinued operations for all historical periods presented.

[0000833444-17-000042:8k_2_02:22]
|  |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q3 2017 |  | Q3 2017 |  | Q3 2016 |  | Change |
|  |  |  |  |  |  | (Combined) |  |  |
| Sales |  | $7,683 |  | $7,669 |  | $7,597 |  | +1% |
| Segment EBITA |  | 1,216 |  | 1,212 |  | 1,126 |  | +8% |
| EBIT |  | 842 |  | 1,000 |  | 872 |  | +15% |
| Net income from continuing operations |  | 555 |  | 671 |  | 576 |  | +16% |
| Diluted EPS from continuing operations |  | $0.59 |  | $0.71 |  | $0.61 |  | +16% |

[0000833444-17-000042:8k_2_02:23]
Organic adjusted sales growth, adjusted segment EBITA, adjusted EBIT, and adjusted EPS from continuing operations are non-GAAP financial measures. For a reconciliation of these non-GAAP measures and detail of the special items, refer to the attached footnotes.  A slide presentation reviewing third quarter results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-17-000042:8k_2_02:24]
Page 2 of 16

[0000833444-17-000042:8k_2_02:25]
BUSINESS RESULTS

[0000833444-17-000042:8k_2_02:26]
Building Technologies & Solutions ("Buildings")

[0000833444-17-000042:8k_2_02:27]
|  |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q3 2017 |  | Q3 2017 |  | Q3 2016 |  | Change |
|  |  |  |  |  |  | (Combined) |  |  |
| Sales |  | $6,074 |  | $6,060 |  | $6,078 |  | — |
| Segment EBITA |  | $912 |  | $908 |  | $845 |  | +7% |
| Segment EBITA margin % |  | 15.0% |  | 15.0% |  | 13.9% |  | +110bps |

[0000833444-17-000042:8k_2_02:28]
Buildings sales in the third quarter of 2017 were $6.1 billion, essentially flat versus the prior year quarter.  Excluding net M&A and foreign exchange, organic sales increased 2 percent versus the prior year, reflecting 1 percent growth in our field businesses and 4 percent growth in product sales.

[0000833444-17-000042:8k_2_02:29]
Orders in the quarter, excluding M&A and adjusted for foreign exchange, increased 1 percent year-over-year, with flat orders in the field businesses and 4 percent growth in products.  Backlog at the end of the quarter of $8.4 billion was 3 percent higher year-over-year, excluding M&A and adjusted for foreign exchange.

[0000833444-17-000042:8k_2_02:30]
Buildings adjusted segment EBITA was $908 million, up 7 percent versus the prior year.  Adjusted segment EBITA margin of 15.0 percent improved 110 basis points over the prior year as the benefit of cost synergies and productivity savings, as well as modest volume leverage and favorable mix, more than offset planned product and channel investments.

[0000833444-17-000042:8k_2_02:31]
Power Solutions

[0000833444-17-000042:8k_2_02:32]
|  |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q3 2017 |  | Q3 2017 |  | Q3 2016 |  | Change |
|  |  |  |  |  |  | (Combined) |  |  |
| Sales |  | $1,609 |  | $1,609 |  | $1,519 |  | +6% |
| Segment EBITA |  | $304 |  | $304 |  | $281 |  | +8% |
| Segment EBITA margin % |  | 18.9% |  | 18.9% |  | 18.5% |  | +40bps |

[0000833444-17-000042:8k_2_02:33]
Power Solutions sales in the third quarter of 2017 were $1.6 billion, an increase of 6 percent versus the prior year.  Excluding the impact of higher lead pass-through and foreign exchange, organic sales declined 2 percent versus the prior year, as favorable technology mix was more than offset by lower unit volumes across most regions.  Global original equipment battery shipments declined 6 percent and aftermarket shipments declined 2 percent compared to the prior year.  Start-Stop battery shipments increased 17 percent year-over-year, led by growth in China and the Americas.

[0000833444-17-000042:8k_2_02:34]
Power Solutions adjusted segment EBITA was $304 million, up 8 percent from the prior year, due to favorable product mix and productivity savings, partially offset by lower volumes.  Excluding the impact of foreign exchange and lead, adjusted segment EBITA increased 7 percent.  Adjusted segment EBITA margin of 18.9 percent increased 40 basis points compared with the prior year, including a 120 basis point headwind related to the impact of lead.  Excluding the impact of lead, adjusted segment EBITA margin increased 160 basis points year-over-year.

[0000833444-17-000042:8k_2_02:35]
Page 3 of 16

[0000833444-17-000042:8k_2_02:36]
Corporate

[0000833444-17-000042:8k_2_02:37]
|  |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q3 2017 |  | Q3 2017 |  | Q3 2016 |  | Change |
|  |  |  |  |  |  | (Combined) |  |  |
| Corporate expense |  | $(172) |  | $(122) |  | $(145) |  | 16% |

[0000833444-17-000042:8k_2_02:38]
Adjusted corporate expense was $122 million in the third quarter, an improvement of 16 percent compared to the prior year driven primarily by cost synergies and productivity initiatives.

[0000833444-17-000042:8k_2_02:39]
OTHER ITEMS

[0000833444-17-000042:8k_2_02:40]
| • | During the quarter, the Company repurchased 7.3 million shares for $307 million. Year-to-date, the Company has repurchased a total of 10.2M shares for $426 million. The Company expects to complete $650 to $750 million of share repurchases during fiscal 2017. |

[0000833444-17-000042:8k_2_02:41]
| • | The Company expects the sale of the Scott Safety business to 3M to close in the first quarter of fiscal 2018. The net cash proceeds from the transaction are expected to approximate $1.8 to $1.9 billion, and will be used to repay a portion of the Tyco International Holding Sarl’s (“TSarl”) $4.0 billion of merger-related debt. |

[0000833444-17-000042:8k_2_02:42]
###

[0000833444-17-000042:8k_2_02:43]
About Johnson Controls

[0000833444-17-000042:8k_2_02:44]
Johnson Controls is a global diversified technology and multi industrial leader serving a wide range of customers in more than 150 countries. Our 120,000 employees create intelligent buildings, efficient energy solutions, integrated infrastructure and next generation transportation systems that work seamlessly together to deliver on the promise of smart cities and communities. Our commitment to sustainability dates back to our roots in 1885, with the invention of the first electric room thermostat. We are committed to helping our customers win and creating greater value for all of our stakeholders through strategic focus on our buildings and energy growth platforms. For additional information, please visit http://www.johnsoncontrols.com or follow us @johnsoncontrols on Twitter.

[0000833444-17-000042:8k_2_02:45]
###

[0000833444-17-000042:8k_2_02:46]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-17-000042:8k_2_02:47]
Page 4 of 16

[0000833444-17-000042:8k_2_02:48]
forward-looking statements, including, among others, risks related to: any delay or inability of Johnson Controls to realize the expected benefits and synergies of recent portfolio transactions such as the merger with Tyco and the spin-off of Adient, changes in tax laws, regulations, rates, policies or interpretations, the loss of key senior management, the tax treatment of recent portfolio transactions, significant transaction costs and/or unknown liabilities associated with such transactions, the outcome of actual or potential litigation relating to such transactions, the risk that disruptions from recent transactions will harm Johnson Controls’ business, the strength of the U.S. or other economies, automotive vehicle production levels, mix and schedules, energy and commodity prices, the availability of raw materials and component products, currency exchange rates, and cancellation of or changes to commercial arrangements. A detailed discussion of risks related to Johnson Controls’ business is included in the section entitled “Risk Factors” in Johnson Controls’ Annual Report on Form 10-K for the 2016 year filed with the SEC on November 23, 2016, and in the quarterly reports on Form 10-Q filed with the SEC after such date, and available at www.sec.gov and www.johnsoncontrols.com under the “Investors” tab. Shareholders, potential investors and others should consider these factors in evaluating the forward-looking statements and should not place undue reliance on such statements. The forward-looking statements included in this communication are made only as of the date of this document, unless otherwise specified, and, except as required by law, Johnson Controls assumes no obligation, and disclaims any obligation, to update such statements to reflect events or circumstances occurring after the date of this communication.

[0000833444-17-000042:8k_2_02:49]
###

[0000833444-17-000042:8k_2_02:50]
Non GAAP Financial Information

[0000833444-17-000042:8k_2_02:51]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include mark-to-market for pension plans, transaction/integration/separation costs, restructuring and impairment costs, nonrecurring purchase accounting impacts related to the Tyco merger and discrete tax items. Financial information regarding adjusted sales, organic sales, adjusted segment EBITA and adjusted segment EBITA margin are also presented, which are non-GAAP performance measures. Adjusted segment EBITA excludes special items such as transaction/integration/separation costs and nonrecurring purchase accounting impacts because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.

[0000833444-17-000042:8k_2_02:52]
###

[0000833444-17-000042:8k_2_02:53]
Page 5 of 16

[0000833444-17-000042:8k_2_02:54]
| July 27, 2017JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Three Months Ended June 30, |
|  |  | 2017 |  |  | 2016 |
| Net sales | $ | 7,683 |  |  |  | $ | 5,154 |  |
| Cost of sales | 5,252 |  |  |  | 3,732 |  |
|  | Gross profit | 2,431 |  |  |  | 1,422 |  |
| Selling, general and administrative expenses | (1,609 | ) |  |  | (895 | ) |
| Restructuring and impairment costs | (49 | ) |  |  | (27 | ) |
| Net financing charges | (124 | ) |  |  | (65 | ) |
| Equity income | 69 |  |  |  | 45 |  |
| Income from continuing operations before income taxes | 718 |  |  |  | 480 |  |
| Income tax provision | 89 |  |  |  | 78 |  |
| Income from continuing operations | 629 |  |  |  | 402 |  |
| Income from discontinued operations, net of tax | — |  |  |  | 57 |  |
| Net income | 629 |  |  |  | 459 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 74 |  |  |  | 55 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | 21 |  |
| Net income attributable to JCI | $ | 555 |  |  |  | $ | 383 |  |
| Income from continuing operations | $ | 555 |  |  |  | $ | 347 |  |
| Income from discontinued operations | — |  |  |  | 36 |  |
| Net income attributable to JCI | $ | 555 |  |  |  | $ | 383 |  |
| Diluted earnings per share from continuing operations | $ | 0.59 |  |  |  | $ | 0.53 |  |
| Diluted earnings per share from discontinued operations | — |  |  |  | 0.06 |  |
| Diluted earnings per share | $ | 0.59 |  |  |  | $ | 0.59 |  |
| Diluted weighted average shares | 944.4 |  |  |  | 649.7 |  |
| Shares outstanding at period end | 932.4 |  |  |  | 637.7 |  |

[0000833444-17-000042:8k_2_02:55]
Page 6 of 16

[0000833444-17-000042:8k_2_02:56]
| July 27, 2017JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Nine Months Ended June 30, |
|  |  | 2017 |  |  | 2016 |
| Net sales | $ | 22,036 |  |  |  | $ | 14,583 |  |
| Cost of sales | 15,210 |  |  |  | 10,617 |  |
|  | Gross profit | 6,826 |  |  |  | 3,966 |  |
| Selling, general and administrative expenses | (4,905 | ) |  |  | (2,641 | ) |
| Restructuring and impairment costs | (226 | ) |  |  | (87 | ) |
| Net financing charges | (376 | ) |  |  | (202 | ) |
| Equity income | 177 |  |  |  | 127 |  |
| Income from continuing operations before income taxes | 1,496 |  |  |  | 1,163 |  |
| Income tax provision | 570 |  |  |  | 202 |  |
| Income from continuing operations | 926 |  |  |  | 961 |  |
| Loss from discontinued operations, net of tax | (34 | ) |  |  | (481 | ) |
| Net income | 892 |  |  |  | 480 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 147 |  |  |  | 116 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | 9 |  |  |  | 61 |  |
| Net income attributable to JCI | $ | 736 |  |  |  | $ | 303 |  |
| Income from continuing operations | $ | 779 |  |  |  | $ | 845 |  |
| Loss from discontinued operations | (43 | ) |  |  | (542 | ) |
| Net income attributable to JCI | $ | 736 |  |  |  | $ | 303 |  |
| Diluted earnings per share from continuing operations | $ | 0.82 |  |  |  | $ | 1.30 |  |
| Diluted loss per share from discontinued operations | (0.05 | ) |  |  | (0.83 | ) |
| Diluted earnings per share * | $ | 0.78 |  |  |  | $ | 0.47 |  |
| Diluted weighted average shares | 946.8 |  |  |  | 651.5 |  |
| Shares outstanding at period end | 932.4 |  |  |  | 637.7 |  |

[0000833444-17-000042:8k_2_02:57]
* May not sum due to rounding.

[0000833444-17-000042:8k_2_02:58]
Page 7 of 16

[0000833444-17-000042:8k_2_02:59]
| July 27, 2017JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | June 30,2017 |  | September 30,2016 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 458 |  |  | $ | 579 |  |
| Accounts receivable - net | 6,443 |  |  | 6,394 |  |
| Inventories | 3,384 |  |  | 2,888 |  |
| Assets held for sale | 2,082 |  |  | 5,812 |  |
| Other current assets | 1,595 |  |  | 1,436 |  |
|  | Current assets | 13,962 |  |  | 17,109 |  |
| Property, plant and equipment - net | 5,870 |  |  | 5,632 |  |
| Goodwill | 19,619 |  |  | 21,024 |  |
| Other intangible assets - net | 6,727 |  |  | 7,540 |  |
| Investments in partially-owned affiliates | 1,159 |  |  | 990 |  |
| Noncurrent assets held for sale | — |  |  | 7,374 |  |
| Other noncurrent assets | 3,349 |  |  | 3,510 |  |
|  | Total assets | $ | 50,686 |  |  | $ | 63,179 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 2,499 |  |  | $ | 1,706 |  |
| Accounts payable and accrued expenses | 4,768 |  |  | 5,333 |  |
| Liabilities held for sale | 247 |  |  | 4,276 |  |
| Other current liabilities | 4,001 |  |  | 5,016 |  |
|  | Current liabilities | 11,515 |  |  | 16,331 |  |
| Long-term debt | 11,772 |  |  | 11,053 |  |
| Other noncurrent liabilities | 6,595 |  |  | 6,583 |  |
| Noncurrent liabilities held for sale | — |  |  | 3,888 |  |
| Redeemable noncontrolling interests | 189 |  |  | 234 |  |
| Shareholders' equity attributable to JCI | 19,731 |  |  | 24,118 |  |
| Noncontrolling interests | 884 |  |  | 972 |  |
|  | Total liabilities and equity | $ | 50,686 |  |  | $ | 63,179 |  |

[0000833444-17-000042:8k_2_02:60]
Page 8 of 16

[0000833444-17-000042:8k_2_02:61]
| July 27, 2017JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Three Months Ended June 30, |
|  |  |  |  |  |  | 2017 |  |  | 2016 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI | $ | 555 |  |  |  | $ | 383 |  |
| Income from continuing operations attributable to noncontrolling interests | 74 |  |  |  | 55 |  |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | 21 |  |
| Net income | 629 |  |  |  | 459 |  |
| Adjustments to reconcile net income to cash provided by operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 281 |  |  |  | 235 |  |
|  |  | Pension and postretirement benefit expense (income) | 18 |  |  |  | (13 | ) |
|  |  | Pension and postretirement contributions | (17 | ) |  |  | (41 | ) |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (50 | ) |  |  | 5 |  |
|  |  | Deferred income taxes | (3 | ) |  |  | 5 |  |
|  |  | Non-cash restructuring and impairment costs | 31 |  |  |  | 51 |  |
|  |  | Gain on business divestitures | — |  |  |  | (14 | ) |
|  |  | Other - net | 35 |  |  |  | 16 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (298 | ) |  |  | (188 | ) |
|  |  |  |  | Inventories | (215 | ) |  |  | (65 | ) |
|  |  |  |  | Other assets | (108 | ) |  |  | (181 | ) |
|  |  |  |  | Restructuring reserves | (25 | ) |  |  | 1 |  |
|  |  |  |  | Accounts payable and accrued liabilities | 8 |  |  |  | 268 |  |
|  |  |  |  | Accrued income taxes | (71 | ) |  |  | (463 | ) |
|  |  |  |  |  | Cash provided by operating activities | 215 |  |  |  | 75 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (362 | ) |  |  | (279 | ) |
| Sale of property, plant and equipment | 5 |  |  |  | 14 |  |
| Business divestitures, net of cash divested | — |  |  |  | 14 |  |
| Other - net | (3 | ) |  |  | (3 | ) |
|  |  |  |  |  | Cash used by investing activities | (360 | ) |  |  | (254 | ) |
| Financing Activities |  |  |  |  |
| Increase in short and long-term debt - net | 692 |  |  |  | 935 |  |
| Debt financing costs | (1 | ) |  |  | — |  |
| Stock repurchases | (307 | ) |  |  | (475 | ) |
| Payment of cash dividends | (234 | ) |  |  | (188 | ) |
| Proceeds from the exercise of stock options | 42 |  |  |  | 14 |  |
| Dividends paid to noncontrolling interests | — |  |  |  | (13 | ) |
| Cash paid related to prior acquisitions | (38 | ) |  |  | — |  |
| Other - net | — |  |  |  | 1 |  |
|  |  |  |  |  | Cash provided by financing activities | 154 |  |  |  | 274 |  |
| Effect of exchange rate changes on cash and cash equivalents | 37 |  |  |  | 14 |  |
| Cash held for sale | — |  |  |  | (54 | ) |
| Increase in cash and cash equivalents | $ | 46 |  |  |  | $ | 55 |  |

[0000833444-17-000042:8k_2_02:62]
Page 9 of 16

[0000833444-17-000042:8k_2_02:63]
| July 27, 2017JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Nine Months Ended June 30, |
|  |  |  |  |  |  | 2017 |  |  | 2016 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI | $ | 736 |  |  |  | $ | 303 |  |
| Income from continuing operations attributable to noncontrolling interests | 147 |  |  |  | 116 |  |
| Income from discontinued operations attributable to noncontrolling interests | 9 |  |  |  | 61 |  |
| Net income | 892 |  |  |  | 480 |  |
| Adjustments to reconcile net income to cash provided (used) by operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 919 |  |  |  | 680 |  |
|  |  | Pension and postretirement benefit income | (184 | ) |  |  | (47 | ) |
|  |  | Pension and postretirement contributions | (275 | ) |  |  | (94 | ) |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (166 | ) |  |  | (202 | ) |
|  |  | Deferred income taxes | 1,056 |  |  |  | 336 |  |
|  |  | Non-cash restructuring and impairment costs | 70 |  |  |  | 80 |  |
|  |  | Gain on business divestitures | — |  |  |  | (14 | ) |
|  |  | Other - net | 117 |  |  |  | 68 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (319 | ) |  |  | (113 | ) |
|  |  |  |  | Inventories | (585 | ) |  |  | (233 | ) |
|  |  |  |  | Other assets | (258 | ) |  |  | (47 | ) |
|  |  |  |  | Restructuring reserves | 22 |  |  |  | 68 |  |
|  |  |  |  | Accounts payable and accrued liabilities | (608 | ) |  |  | (43 | ) |
|  |  |  |  | Accrued income taxes | (2,002 | ) |  |  | (223 | ) |
|  |  |  |  |  | Cash provided (used) by operating activities | (1,321 | ) |  |  | 696 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (996 | ) |  |  | (822 | ) |
| Sale of property, plant and equipment | 23 |  |  |  | 28 |  |
| Acquisition of businesses, net of cash acquired | (6 | ) |  |  | (133 | ) |
| Business divestitures, net of cash divested | 180 |  |  |  | 54 |  |
| Other - net | (33 | ) |  |  | 2 |  |
|  |  |  |  |  | Cash used by investing activities | (832 | ) |  |  | (871 | ) |
| Financing Activities |  |  |  |  |
| Increase in short and long-term debt - net | 1,468 |  |  |  | 1,261 |  |
| Debt financing costs | (18 | ) |  |  | — |  |
| Stock repurchases | (426 | ) |  |  | (475 | ) |
| Payment of cash dividends | (469 | ) |  |  | (544 | ) |
| Proceeds from the exercise of stock options | 130 |  |  |  | 34 |  |
| Dividends paid to noncontrolling interests | (78 | ) |  |  | (240 | ) |
| Dividend from Adient spin-off | 2,050 |  |  |  | — |  |
| Cash transferred to Adient related to spin-off | (665 | ) |  |  | — |  |
| Cash paid related to prior acquisitions | (75 | ) |  |  | — |  |
| Other - net | (2 | ) |  |  | 4 |  |
|  |  |  |  |  | Cash provided by financing activities | 1,915 |  |  |  | 40 |  |
| Effect of exchange rate changes on cash and cash equivalents | 12 |  |  |  | 5 |  |
| Cash held for sale | 105 |  |  |  | (76 | ) |
| Decrease in cash and cash equivalents | $ | (121 | ) |  |  | $ | (206 | ) |

[0000833444-17-000042:8k_2_02:64]
Page 10 of 16

[0000833444-17-000042:8k_2_02:65]
July 27, 2017

[0000833444-17-000042:8k_2_02:66]
FOOTNOTES

[0000833444-17-000042:8k_2_02:67]
1. Financial Summary

[0000833444-17-000042:8k_2_02:68]
In the first quarter of fiscal 2017, the Company began evaluating the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, significant restructuring and impairment costs, and the net mark-to-market adjustments related to pension and postretirement plans.  Historical information has been revised to present the comparable periods on a consistent basis.  Also in the first quarter of fiscal 2017, the Company began reporting the Automotive Experience business as a discontinued operation, which required retrospective application to previously reported financial information.  As a result, the segment EBITA amounts shown below are for continuing operations and exclude the Automotive Experience business.  In addition, the financial results for the three and nine months ended June 30, 2016 exclude the Tyco business.

[0000833444-17-000042:8k_2_02:69]
|  | Three Months Ended June 30, |
| (in millions; unaudited) | 2017 |  | 2016 |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales (1) |  |  |  |  |  |  |  |
| Building Technologies & Solutions | $ | 6,074 |  |  | $ | 6,060 |  |  | $ | 3,635 |  |  | $ | 3,635 |  |
| Power Solutions | 1,609 |  |  | 1,609 |  |  | 1,519 |  |  | 1,519 |  |
| Net sales | $ | 7,683 |  |  | $ | 7,669 |  |  | $ | 5,154 |  |  | $ | 5,154 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Technologies & Solutions | $ | 912 |  |  | $ | 908 |  |  | $ | 440 |  |  | $ | 447 |  |
| Power Solutions | 304 |  |  | 304 |  |  | 280 |  |  | 281 |  |
| Segment EBITA | 1,216 |  |  | 1,212 |  |  | 720 |  |  | 728 |  |
| Corporate expenses (2) | (172 | ) |  | (122 | ) |  | (126 | ) |  | (94 | ) |
| Amortization of intangible assets (3) | (108 | ) |  | (90 | ) |  | (22 | ) |  | (22 | ) |
| Mark-to-market loss for pension plans (4) | (45 | ) |  | — |  |  | — |  |  | — |  |
| Restructuring and impairment costs (5) | (49 | ) |  | — |  |  | (27 | ) |  | — |  |
| EBIT (6) | 842 |  |  | 1,000 |  |  | 545 |  |  | 612 |  |
| Net financing charges (7) | (124 | ) |  | (124 | ) |  | (65 | ) |  | (65 | ) |
| Income from continuing operations before income taxes | 718 |  |  | 876 |  |  | 480 |  |  | 547 |  |
| Income tax provision (8) | (89 | ) |  | (131 | ) |  | (78 | ) |  | (94 | ) |
| Income from continuing operations | 629 |  |  | 745 |  |  | 402 |  |  | 453 |  |
| Income from continuing operations attributable to noncontrolling interests (9) | (74 | ) |  | (74 | ) |  | (55 | ) |  | (57 | ) |
| Net income from continuing operations attributable to JCI | $ | 555 |  |  | $ | 671 |  |  | $ | 347 |  |  | $ | 396 |  |

[0000833444-17-000042:8k_2_02:70]
|  | Nine Months Ended June 30, |
| (in millions; unaudited) | 2017 |  | 2016 |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales (1) |  |  |  |  |  |  |  |
| Building Technologies & Solutions | $ | 16,831 |  |  | $ | 16,797 |  |  | $ | 9,741 |  |  | $ | 9,741 |  |
| Power Solutions | 5,205 |  |  | 5,205 |  |  | 4,842 |  |  | 4,842 |  |
| Net sales | $ | 22,036 |  |  | $ | 22,002 |  |  | $ | 14,583 |  |  | $ | 14,583 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Technologies & Solutions | $ | 2,000 |  |  | $ | 2,114 |  |  | $ | 915 |  |  | $ | 940 |  |
| Power Solutions | 996 |  |  | 997 |  |  | 922 |  |  | 923 |  |
| Segment EBITA | 2,996 |  |  | 3,111 |  |  | 1,837 |  |  | 1,863 |  |
| Corporate expenses (2) | (605 | ) |  | (358 | ) |  | (323 | ) |  | (237 | ) |
| Amortization of intangible assets (3) | (383 | ) |  | (285 | ) |  | (62 | ) |  | (62 | ) |
| Mark-to-market gain for pension plans (4) | 90 |  |  | — |  |  | — |  |  | — |  |
| Restructuring and impairment costs (5) | (226 | ) |  | — |  |  | (87 | ) |  | — |  |
| EBIT (6) | 1,872 |  |  | 2,468 |  |  | 1,365 |  |  | 1,564 |  |
| Net financing charges (7) | (376 | ) |  | (359 | ) |  | (202 | ) |  | (202 | ) |
| Income from continuing operations before income taxes | 1,496 |  |  | 2,109 |  |  | 1,163 |  |  | 1,362 |  |
| Income tax provision (8) | (570 | ) |  | (316 | ) |  | (202 | ) |  | (235 | ) |
| Income from continuing operations | 926 |  |  | 1,793 |  |  | 961 |  |  | 1,127 |  |
| Income from continuing operations attributable to noncontrolling interests (9) | (147 | ) |  | (147 | ) |  | (116 | ) |  | (131 | ) |
| Net income from continuing operations attributable to JCI | $ | 779 |  |  | $ | 1,646 |  |  | $ | 845 |  |  | $ | 996 |  |

[0000833444-17-000042:8k_2_02:71]
Building Technologies & Solutions - Provides facility systems and services including comfort, energy and security management for the non-residential buildings market, and provides heating, ventilating, and air conditioning products and services, security products and services, fire detection and suppression products and services, and life safety products for the residential and non-residential building markets.

[0000833444-17-000042:8k_2_02:72]
Power Solutions - Services both automotive original equipment manufacturers and the battery aftermarket by providing advanced battery technology, coupled with systems engineering, marketing and service expertise.

[0000833444-17-000042:8k_2_02:73]
Page 11 of 16

[0000833444-17-000042:8k_2_02:74]
July 27, 2017

[0000833444-17-000042:8k_2_02:75]
(1) The Company's press release contains financial information regarding adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures.  The Company's definition of adjusted segment EBITA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-17-000042:8k_2_02:76]
The following is the three months ended June 30, 2017 and 2016 reconciliation of net sales, segment EBITA and segment EBITA margin as reported to adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-17-000042:8k_2_02:77]
| (in millions) | Building Technologies & Solutions |  | Power Solutions |  | Consolidated JCI plc |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net sales as reported | $ | 6,074 |  |  | $ | 3,635 |  |  | $ | 1,609 |  |  | $ | 1,519 |  |  | $ | 7,683 |  |  | $ | 5,154 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring purchase accounting impacts | (14 | ) |  | — |  |  | — |  |  | — |  |  | (14 | ) |  | — |  |
| Adjusted net sales | $ | 6,060 |  |  | $ | 3,635 |  |  | $ | 1,609 |  |  | $ | 1,519 |  |  | $ | 7,669 |  |  | $ | 5,154 |  |
| Segment EBITA as reported | $ | 912 |  |  | $ | 440 |  |  | $ | 304 |  |  | $ | 280 |  |  | $ | 1,216 |  |  | $ | 720 |  |
| Segment EBITA margin as reported | 15.0 | % |  | 12.1 | % |  | 18.9 | % |  | 18.4 | % |  | 15.8 | % |  | 14.0 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | 6 |  |  | — |  |  | — |  |  | 1 |  |  | 6 |  |  | 1 |  |
| Integration costs | 14 |  |  | 7 |  |  | — |  |  | — |  |  | 14 |  |  | 7 |  |
| Nonrecurring purchase accounting impacts | (24 | ) |  | — |  |  | — |  |  | — |  |  | (24 | ) |  | — |  |
| Adjusted segment EBITA | $ | 908 |  |  | $ | 447 |  |  | $ | 304 |  |  | $ | 281 |  |  | $ | 1,212 |  |  | $ | 728 |  |
| Adjusted segment EBITA margin | 15.0 | % |  | 12.3 | % |  | 18.9 | % |  | 18.5 | % |  | 15.8 | % |  | 14.1 | % |

[0000833444-17-000042:8k_2_02:78]
The following is the nine months ended June 30, 2017 and 2016 reconciliation of net sales, segment EBITA and segment EBITA margin as reported to adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-17-000042:8k_2_02:79]
| (in millions) | Building Technologies & Solutions |  | Power Solutions |  | Consolidated JCI plc |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net sales as reported | $ | 16,831 |  |  | $ | 9,741 |  |  | $ | 5,205 |  |  | $ | 4,842 |  |  | $ | 22,036 |  |  | $ | 14,583 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring purchase accounting impacts | (34 | ) |  | — |  |  | — |  |  | — |  |  | (34 | ) |  | — |  |
| Adjusted net sales | $ | 16,797 |  |  | $ | 9,741 |  |  | $ | 5,205 |  |  | $ | 4,842 |  |  | $ | 22,002 |  |  | $ | 14,583 |  |
| Segment EBITA as reported | $ | 2,000 |  |  | $ | 915 |  |  | $ | 996 |  |  | $ | 922 |  |  | $ | 2,996 |  |  | $ | 1,837 |  |
| Segment EBITA margin as reported | 11.9 | % |  | 9.4 | % |  | 19.1 | % |  | 19.0 | % |  | 13.6 | % |  | 12.6 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | 33 |  |  | 10 |  |  | 1 |  |  | 1 |  |  | 34 |  |  | 11 |  |
| Integration costs | 44 |  |  | 15 |  |  | — |  |  | — |  |  | 44 |  |  | 15 |  |
| Nonrecurring purchase accounting impacts | 37 |  |  | — |  |  | — |  |  | — |  |  | 37 |  |  | — |  |
| Adjusted segment EBITA | $ | 2,114 |  |  | $ | 940 |  |  | $ | 997 |  |  | $ | 923 |  |  | $ | 3,111 |  |  | $ | 1,863 |  |
| Adjusted segment EBITA margin | 12.6 | % |  | 9.6 | % |  | 19.2 | % |  | 19.1 | % |  | 14.1 | % |  | 12.8 | % |

[0000833444-17-000042:8k_2_02:80]
(2) Adjusted Corporate expenses for the three months ended June 30, 2017 excludes $40 million of integration costs and $10 million of transaction costs.  Adjusted Corporate expenses for the nine months ended June 30, 2017 excludes $185 million of integration costs, $58 million of transaction costs and $4 million of separation costs.  Adjusted Corporate expenses for the three months ended June 30, 2016 excludes $21 million of transaction costs and $11 million of separation costs.  Adjusted Corporate expenses for the nine months ended June 30, 2016 excludes $46 million of separation costs and $40 million of transaction costs.

[0000833444-17-000042:8k_2_02:81]
(3) Adjusted amortization of intangible assets for the three and nine months ended June 30, 2017 excludes $18 million and $98 million, respectively, of nonrecurring asset amortization related to Tyco purchase accounting.

[0000833444-17-000042:8k_2_02:82]
Page 12 of 16

[0000833444-17-000042:8k_2_02:83]
July 27, 2017

[0000833444-17-000042:8k_2_02:84]
(4) The three months ended June 30, 2017 pension mark-to-market loss of $45 million and the nine months ended June 30, 2017 pension mark-to-market gain of $90 million due to lump sum payouts for certain U.S. pension plans are excluded from the adjusted non-GAAP results.

[0000833444-17-000042:8k_2_02:85]
(5) The three and nine months ended June 30, 2017 restructuring and impairment charges of $49 million and $226 million, respectively, are excluded from the adjusted non-GAAP results.  The three and nine months ended June 30, 2016 restructuring and impairment charges of $27 million and $87 million, respectively, are excluded from the adjusted non-GAAP results.

[0000833444-17-000042:8k_2_02:86]
(6) Management defines earnings before interest and taxes (EBIT) as income from continuing operations before net financing charges, income taxes and noncontrolling interests.

[0000833444-17-000042:8k_2_02:87]
(7) Adjusted net financing charges for the nine months ended June 30, 2017 exclude $17 million of transaction costs related to the debt exchange offers.

[0000833444-17-000042:8k_2_02:88]
(8) Adjusted income tax provision for the three months ended June 30, 2017 excludes the tax benefits of the pension mark-to-market loss of $18 million, restructuring and impairment costs of $15 million, integration costs of $9 million and transaction costs of $2 million, partially offset by the tax provision for Tyco nonrecurring purchase accounting impacts of $2 million.  Adjusted income tax provision for the nine months ended June 30, 2017 excludes the non-cash tax charge of $457 million related to establishment of a deferred tax liability on the outside basis difference of the Company’s investment in certain subsidiaries of the Scott Safety business and the tax provision for the pension mark-to-market net gain of $36 million, partially offset by the tax benefits of changes in entity tax status of $101 million, restructuring and impairment costs of $49 million, integration costs of $41 million, Tyco nonrecurring purchase accounting impacts of $36 million and transaction costs of $12 million.  Adjusted income tax provision for the three months ended June 30, 2016 excludes the tax benefits of restructuring and impairment costs of $12 million, transaction costs of $3 million and integration costs of $1 million.  Adjusted income tax provision for the nine months ended June 30, 2016 excludes the tax benefits of restructuring and impairment costs of $24 million, transaction costs of $6 million, integration costs of $2 million and separation costs of $1 million.

[0000833444-17-000042:8k_2_02:89]
(9) Adjusted income from continuing operations attributable to noncontrolling interests for the three months ended June 30, 2016 excludes $2 million for the noncontrolling interest impact of integration costs.  Adjusted income from continuing operations attributable to noncontrolling interests for the nine months ended June 30, 2016, excludes $9 million for the noncontrolling interest impact of transaction/integration costs and $6 million for the noncontrolling interest impact of restructuring and impairment costs.

[0000833444-17-000042:8k_2_02:90]
2. 2016 Supplemental Combined Information

[0000833444-17-000042:8k_2_02:91]
As a result of the reverse merger between JCI and Tyco, which closed on September 2, 2016, the Company is providing supplemental combined financial information.  As supplemental information that management believes will be useful to investors, the Company has provided unaudited selected historical information which combines JCI’s historical Building Efficiency business with historical Tyco results of operations as if these businesses had been operated together during the periods presented.

[0000833444-17-000042:8k_2_02:92]
The merger is accounted for as a reverse acquisition with JCI considered to be acquiring Tyco for accounting purposes.  As a result, the amounts reflected in Column A in the below table present the historical results of JCI, revised for the reporting changes described within footnote 1 above.  The amounts in Column B reflect the impact of the special items, as set forth in the notes to the table and within footnote 1 above. The amounts in Column C reflect the inclusion of Tyco’s historical results for the period prior to the merger on an adjusted basis.

[0000833444-17-000042:8k_2_02:93]
For the avoidance of doubt, this supplemental combined information is not intended to be, and was not, prepared on a basis consistent with the unaudited pro forma condensed combined financial information in Exhibit 99.3 to the Company’s Current Report on Form 8-K/A filed October 3, 2016 with the U.S. Securities and Exchange Commission (the “Pro Forma 8-K/A Filing”), which provides the pro forma financial information required by Item 9.01(b) of Form 8-K. The supplemental combined information is intentionally different from, but does not supersede, the pro forma financial information in the Pro Forma 8-K/A Filing.

[0000833444-17-000042:8k_2_02:94]
In addition, the supplemental combined information does not purport to indicate the results that actually would have been obtained had the JCI and Tyco businesses been operated together on the basis of the new segment structure during the periods presented, or which may be realized in the future.

[0000833444-17-000042:8k_2_02:95]
Page 13 of 16

[0000833444-17-000042:8k_2_02:96]
July 27, 2017

[0000833444-17-000042:8k_2_02:97]
Amounts Adjusted for Certain Special Items

[0000833444-17-000042:8k_2_02:98]
The supplemental combined information includes line items, such as net sales, income from continuing operations before income taxes, income tax provision, noncontrolling interest, net income and diluted EPS, that have been adjusted for the special items set forth in the notes to the table. Such amounts should be viewed in addition to, and not in lieu of, net sales, income from continuing operations before income taxes, income tax provision, noncontrolling interest, net income and diluted EPS and other financial measures on an unadjusted basis. In addition, per share amounts presented in the tables take into account the effects of (i) the issuance of ordinary shares to JCI shareholders in connection with the merger, and (ii) the consolidation of Tyco ordinary shares immediately prior to the merger. As a result, share counts reflect shares outstanding as of September 2, 2016 immediately following the consummation of the merger transaction.

[0000833444-17-000042:8k_2_02:99]
The Company’s management believes that these adjusted amounts, when considered together with the unadjusted amounts, provide information that is useful to investors in understanding period-over-period operating results separate and apart from items that may, or could, have a disproportionate positive or negative impact on results in any particular period. The Company’s management also believes that these adjusted amounts enhance the ability of investors to analyze trends in the Company’s underlying business and to better understand the Company’s performance. In addition, the Company may utilize adjusted amounts as guides in forecasting, budgeting and long-term planning processes and to measure operating performance for compensation purposes. Adjusted amounts should be considered in addition to, and not as a substitute for, or superior to, unadjusted amounts.

[0000833444-17-000042:8k_2_02:100]
| (in millions, except per share data; unaudited) |  | Three Months Ended June 30, 2016 |
|  |  | A |  | B |  | C |  | D |
| Net sales |  |  |  |  |  |  |  |  |
| Building Technologies & Solutions |  | $ | 3,635 |  |  | $ | — |  |  | $ | 2,443 |  |  | $ | 6,078 |  |
| Power Solutions |  | 1,519 |  |  | — |  |  | — |  |  | 1,519 |  |
| Net sales |  | $ | 5,154 |  |  | $ | — |  |  | $ | 2,443 |  |  | $ | 7,597 |  |
| Income from continuing operations |  |  |  |  |  |  |  |  |
| Building Technologies & Solutions |  | $ | 440 |  |  | $ | 7 |  |  | $ | 398 |  |  | $ | 845 |  |
| Power Solutions |  | 280 |  |  | 1 |  |  | — |  |  | 281 |  |
| Segment EBITA |  | 720 |  |  | 8 |  |  | 398 |  |  | 1,126 |  |
| Corporate expenses |  | (126 | ) |  | 32 |  |  | (51 | ) |  | (145 | ) |
| Amortization of intangible assets |  | (22 | ) |  | — |  |  | (87 | ) |  | (109 | ) |
| Restructuring and impairment costs |  | (27 | ) |  | 27 |  |  | — |  |  | — |  |
| EBIT |  | 545 |  |  | 67 |  |  | 260 |  |  | 872 |  |
| Net financing charges |  | (65 | ) |  | — |  |  | (45 | ) |  | (110 | ) |
| Income from continuing operations before income taxes |  | 480 |  |  | 67 |  |  | 215 |  |  | 762 |  |
| Income tax provision |  | (78 | ) |  | (16 | ) |  | (36 | ) |  | (130 | ) |
| Noncontrolling interest |  | (55 | ) |  | (2 | ) |  | 1 |  |  | (56 | ) |
| Net income |  | $ | 347 |  |  | $ | 49 |  |  | $ | 180 |  |  | $ | 576 |  |
| Diluted weighted average shares |  | 649.7 |  |  |  |  |  |  | 940 |  |
| Diluted earnings per share |  | $ | 0.53 |  |  |  |  |  |  | $ | 0.61 |  |

[0000833444-17-000042:8k_2_02:101]
| (in millions, except per share data; unaudited) |  | Nine Months Ended June 30, 2016 |
|  |  | A |  | B |  | C |  | D |
| Net sales |  |  |  |  |  |  |  |  |
| Building Technologies & Solutions |  | $ | 9,741 |  |  | $ | — |  |  | $ | 7,138 |  |  | $ | 16,879 |  |
| Power Solutions |  | 4,842 |  |  | — |  |  | — |  |  | 4,842 |  |
| Net sales |  | $ | 14,583 |  |  | $ | — |  |  | $ | 7,138 |  |  | $ | 21,721 |  |
| Income from continuing operations |  |  |  |  |  |  |  |  |
| Building Technologies & Solutions |  | $ | 915 |  |  | $ | 25 |  |  | $ | 1,099 |  |  | $ | 2,039 |  |
| Power Solutions |  | 922 |  |  | 1 |  |  | — |  |  | 923 |  |
| Segment EBITA |  | 1,837 |  |  | 26 |  |  | 1,099 |  |  | 2,962 |  |
| Corporate expenses |  | (323 | ) |  | 86 |  |  | (161 | ) |  | (398 | ) |
| Amortization of intangible assets |  | (62 | ) |  | — |  |  | (260 | ) |  | (322 | ) |
| Restructuring and impairment costs |  | (87 | ) |  | 87 |  |  | — |  |  | — |  |
| EBIT |  | 1,365 |  |  | 199 |  |  | 678 |  |  | 2,242 |  |
| Net financing charges |  | (202 | ) |  | — |  |  | (133 | ) |  | (335 | ) |
| Income from continuing operations before income taxes |  | 1,163 |  |  | 199 |  |  | 545 |  |  | 1,907 |  |
| Income tax provision |  | (202 | ) |  | (33 | ) |  | (89 | ) |  | (324 | ) |
| Noncontrolling interest |  | (116 | ) |  | (15 | ) |  | 2 |  |  | (129 | ) |
| Net income |  | $ | 845 |  |  | $ | 151 |  |  | $ | 458 |  |  | $ | 1,454 |  |
| Diluted weighted average shares |  | 651.5 |  |  |  |  |  |  | 940 |  |
| Diluted earnings per share |  | $ | 1.30 |  |  |  |  |  |  | $ | 1.55 |  |

[0000833444-17-000042:8k_2_02:102]
A - Johnson Controls, as reported.

[0000833444-17-000042:8k_2_02:103]
B - Adjusted to exclude special items because these costs are not considered to be directly related to the underlying operating performance of the Company. Management believes these non-GAAP measures are useful to investors in better understanding the ongoing operations and business trends of the Company.  The special items are described by line item in footnote 1 above.  The income tax provision and noncontrolling interest adjustments are a result of the special items discussed in footnote 1.

[0000833444-17-000042:8k_2_02:104]
C - Includes Tyco adjusted non-GAAP results for the three and nine months ended June 30, 2016, as if the merger occurred October 1, 2015. Tyco’s first three fiscal quarters of 2016 ended on the last Friday of December, March and June, while JCI’s fiscal quarters ended on the last day of each such month. Because the historical statements of income of each company represent full and equivalent quarterly periods, no adjustments were made to align the fiscal quarters.  The income tax provision also includes an adjustment to arrive at an annualized 17% tax rate for fiscal 2016 as a combined company.

[0000833444-17-000042:8k_2_02:105]
D - Combined financial information as if the merger with Tyco was completed on October 1, 2015. Reflects annual 17% tax rate and 940 million share count.

[0000833444-17-000042:8k_2_02:106]
Page 14 of 16

[0000833444-17-000042:8k_2_02:107]
July 27, 2017

[0000833444-17-000042:8k_2_02:108]
3. Organic Adjusted Net Sales Growth Reconciliation

[0000833444-17-000042:8k_2_02:109]
The components of the changes in adjusted net sales for the three months ended June 30, 2017 versus the three months ended June 30, 2016, including organic net sales, is shown below (unaudited):

[0000833444-17-000042:8k_2_02:110]
| (in millions) | Combined Adjusted Net Sales for the Three Months Ended June 30, 2016 |  | Foreign Currency |  | Acquisitions/Divestitures, Net |  | Lead Impact |  | Organic Net Sales |  | Adjusted Net Sales for the Three Months EndedJune 30, 2017 |
| Building Technologies & Solutions | $ | 6,078 |  |  | $ | (76 | ) |  | -1.3 | % |  | $ | (68 | ) |  | -1.1 | % |  | $ | — |  |  | — |  |  | $ | 126 |  |  | 2.1 | % |  | $ | 6,060 |  |  | -0.3 | % |
| Power Solutions | 1,519 |  |  | (5 | ) |  | -0.3 | % |  | — |  |  | — |  |  | 124 |  |  | 8.2 | % |  | (29 | ) |  | -1.9 | % |  | 1,609 |  |  | 5.9 | % |
| Total net sales | $ | 7,597 |  |  | $ | (81 | ) |  | -1.1 | % |  | $ | (68 | ) |  | -0.9 | % |  | $ | 124 |  |  | 1.6 | % |  | $ | 97 |  |  | 1.3 | % |  | $ | 7,669 |  |  | 0.9 | % |

[0000833444-17-000042:8k_2_02:111]
The components of the changes in adjusted net sales for the nine months ended June 30, 2017 versus the nine months ended June 30, 2016, including organic net sales, is shown below (unaudited):

[0000833444-17-000042:8k_2_02:112]
| (in millions) | Combined Adjusted Net Sales for the Nine Months Ended June 30, 2016 |  | Foreign Currency |  | Acquisitions/Divestitures, Net |  | Lead Impact |  | Organic Net Sales |  | Adjusted Net Sales for the Nine Months EndedJune 30, 2017 |
| Building Technologies & Solutions | $ | 16,879 |  |  | $ | (143 | ) |  | -0.8 | % |  | $ | (169 | ) |  | -1.0 | % |  | $ | — |  |  | — |  |  | $ | 230 |  |  | 1.4 | % |  | $ | 16,797 |  |  | -0.5 | % |
| Power Solutions | 4,842 |  |  | (20 | ) |  | -0.4 | % |  | — |  |  | — |  |  | 298 |  |  | 6.2 | % |  | 85 |  |  | 1.8 | % |  | 5,205 |  |  | 7.5 | % |
| Total net sales | $ | 21,721 |  |  | $ | (163 | ) |  | -0.8 | % |  | $ | (169 | ) |  | -0.8 | % |  | $ | 298 |  |  | 1.4 | % |  | $ | 315 |  |  | 1.5 | % |  | $ | 22,002 |  |  | 1.3 | % |

[0000833444-17-000042:8k_2_02:113]
4.  Diluted Earnings Per Share Reconciliation

[0000833444-17-000042:8k_2_02:114]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure.  The adjusting items include transaction/integration/separation costs,  nonrecurring purchase accounting impacts related to the Tyco merger, mark-to-market gain or loss for pension plans, restructuring and impairment costs, and discrete tax items.  The Company excludes these items because they are not considered to be directly related to the underlying operating performance of the Company. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-17-000042:8k_2_02:115]
A reconciliation of diluted earnings per share as reported to diluted adjusted earnings per share for the respective periods is shown below (unaudited):

[0000833444-17-000042:8k_2_02:116]
|  | Net Income Attributableto JCI plc |  | Net Income Attributable toJCI plc from ContinuingOperations |
|  | Three Months Ended |  | Three Months Ended |
|  | June 30, |  | June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Earnings per share as reported for JCI plc | $ | 0.59 |  |  | $ | 0.59 |  |  | $ | 0.59 |  |  | $ | 0.53 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction costs | 0.02 |  |  | 0.03 |  |  | 0.02 |  |  | 0.03 |  |
| Related tax impact | — |  |  | — |  |  | — |  |  | — |  |
| Integration costs | 0.06 |  |  | 0.01 |  |  | 0.06 |  |  | 0.01 |  |
| Related tax impact | (0.01 | ) |  | — |  |  | (0.01 | ) |  | — |  |
| Separation costs | — |  |  | 0.21 |  |  | — |  |  | 0.02 |  |
| Related tax impact | — |  |  | (0.02 | ) |  | — |  |  | — |  |
| Nonrecurring purchase accounting impacts | (0.01 | ) |  | — |  |  | (0.01 | ) |  | — |  |
| Related tax impact | — |  |  | — |  |  | — |  |  | — |  |
| Mark-to-market loss for pension plans | 0.05 |  |  | — |  |  | 0.05 |  |  | — |  |
| Related tax impact | (0.02 | ) |  | — |  |  | (0.02 | ) |  | — |  |
| Restructuring and impairment costs | 0.05 |  |  | 0.16 |  |  | 0.05 |  |  | 0.04 |  |
| Related tax impact | (0.02 | ) |  | (0.04 | ) |  | (0.02 | ) |  | (0.02 | ) |
| Discrete tax items | — |  |  | 0.13 |  |  | — |  |  | — |  |
| Adjusted earnings per share for JCI plc | $ | 0.71 |  |  | $ | 1.07 |  |  | $ | 0.71 |  |  | $ | 0.61 |  |

[0000833444-17-000042:8k_2_02:117]
|  | Net Income Attributableto JCI plc |  | Net Income Attributable toJCI plc from ContinuingOperations |
|  | Nine Months Ended |  | Nine Months Ended |
|  | June 30, |  | June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Earnings per share as reported for JCI plc | $ | 0.78 |  |  | $ | 0.47 |  |  | $ | 0.82 |  |  | $ | 1.30 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction costs | 0.12 |  |  | 0.07 |  |  | 0.12 |  |  | 0.07 |  |
| Related tax impact | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |
| Integration costs | 0.24 |  |  | 0.02 |  |  | 0.24 |  |  | 0.02 |  |
| Related tax impact | (0.04 | ) |  | — |  |  | (0.04 | ) |  | — |  |
| Separation costs | 0.09 |  |  | 0.51 |  |  | — |  |  | 0.07 |  |
| Related tax impact | — |  |  | (0.04 | ) |  | — |  |  | — |  |
| Nonrecurring purchase accounting impacts | 0.14 |  |  | — |  |  | 0.14 |  |  | — |  |
| Related tax impact | (0.04 | ) |  | — |  |  | (0.04 | ) |  | — |  |
| Mark-to-market gain for pension plans | (0.10 | ) |  | — |  |  | (0.10 | ) |  | — |  |
| Related tax impact | 0.04 |  |  | — |  |  | 0.04 |  |  | — |  |
| Restructuring and impairment costs | 0.24 |  |  | 0.50 |  |  | 0.24 |  |  | 0.12 |  |
| Related tax impact | (0.05 | ) |  | (0.06 | ) |  | (0.05 | ) |  | (0.04 | ) |
| Discrete tax items | 0.40 |  |  | 1.33 |  |  | 0.38 |  |  | — |  |
| Adjusted earnings per share for JCI plc * | $ | 1.80 |  |  | $ | 2.78 |  |  | $ | 1.74 |  |  | $ | 1.53 |  |

[0000833444-17-000042:8k_2_02:118]
* May not sum due to rounding.

[0000833444-17-000042:8k_2_02:119]
Page 15 of 16

[0000833444-17-000042:8k_2_02:120]
July 27, 2017

[0000833444-17-000042:8k_2_02:121]
The Company has presented forward-looking statements regarding adjusted EPS from continuing operations for the fourth quarter of 2017 and the full fiscal year of 2017, which is a non-GAAP financial measure. This non–GAAP financial measure is derived by excluding certain amounts, expenses or income from the corresponding financial measure determined in accordance with GAAP. The determination of the amounts that are excluded from this non-GAAP financial measure is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period, including but not limited to the high variability of the net mark-to-market adjustments related to pension and post-retirement plans. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measure to its most directly comparable forward-looking GAAP financial measure because such information is not available and management cannot reliably predict all of the necessary components of such GAAP measure without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s fourth quarter 2017 and full year 2017 GAAP financial results.

[0000833444-17-000042:8k_2_02:122]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-17-000042:8k_2_02:123]
|  | Three Months Ended |  | Nine Months Ended |
|  | June 30, |  | June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Weighted Average Shares Outstanding for JCI plc |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 935.4 |  |  | 644.9 |  |  | 937.2 |  |  | 647.0 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock |  |  |  |  |  |  |  |
| and unvested performance share awards | 9.0 |  |  | 4.8 |  |  | 9.6 |  |  | 4.5 |  |
| Diluted weighted average shares outstanding | 944.4 |  |  | 649.7 |  |  | 946.8 |  |  | 651.5 |  |

[0000833444-17-000042:8k_2_02:124]
5.  Mark-to-Market of Pension and Postretirement Plans

[0000833444-17-000042:8k_2_02:125]
The pension and postretirement mark-to-market gain or loss for each period is excluded from adjusted diluted earnings per share.  The three months ended June 30, 2017 pension mark-to-market loss of $45 million and the nine months ended June 30, 2017 pension mark-to-market gain of $90 million are due to lump sum payouts for certain U.S. pension plans.  There was no mark-to-market gain or loss for pension and postretirement plans in the three or nine months ended June 30, 2016.

[0000833444-17-000042:8k_2_02:126]
6.  Acquisitions and Divestitures

[0000833444-17-000042:8k_2_02:127]
On March 16, 2017, the Company announced that it signed a definitive agreement to sell its Scott Safety business to 3M for approximately $2.0 billion.  Net cash proceeds from the transaction are expected to approximate $1.8 to $1.9 billion.  Scott Safety is a leader in the design, manufacture and sale of high performance respiratory protection, gas and flame detection, thermal imaging and other critical products for fire services, law enforcement, industrial, oil and gas, chemical, armed forces, and homeland defense end markets. The transaction is expected to close in the first quarter of fiscal 2018, subject to customary closing conditions including required regulatory approval.  The Scott Safety business is included within assets held for sale and liabilities held for sale in the accompanying condensed consolidated statement of financial position as of June 30, 2017.

[0000833444-17-000042:8k_2_02:128]
On October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience business from JCI plc to Adient plc and the issuance of ordinary shares of Adient plc directly to holders of JCI plc ordinary shares on a pro rata basis.  Following the separation, Adient plc is now an independent public company trading on the New York Stock Exchange (NYSE) under the symbol "ADNT." The Company did not retain any equity interest in Adient plc.  Beginning in the first quarter of fiscal 2017, Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation.

[0000833444-17-000042:8k_2_02:129]
On September 2, 2016, JCI Inc. and Tyco completed their combination which was announced on January 25, 2016.  The merger is accounted for as a reverse acquisition using the acquisition method of accounting in accordance with Accounting Standards Codification (ASC) 805, "Business Combinations."  JCI Inc. is the accounting acquirer for financial reporting purposes.  Accordingly, the historical consolidated financial statements of JCI Inc. for periods prior to this transaction are considered to be the historical financial statements of the Company.  The total fair value of the consideration transferred was $19.7 billion.  As part of the transaction in the fiscal 2016 fourth quarter, the Company recorded $16.4 billion of goodwill and $6.2 billion of intangible assets, of which $3.9 billion are subject to amortization.

[0000833444-17-000042:8k_2_02:130]
On October 1, 2015, the Company formed a joint venture with Hitachi to expand its legacy Building Efficiency product offerings.  The Company acquired a 60 percent ownership stake in the new entity for approximately $133 million ($563 million purchase price less cash acquired of $430 million).

[0000833444-17-000042:8k_2_02:131]
7. Income Taxes

[0000833444-17-000042:8k_2_02:132]
The Company's effective tax rate from continuing operations before consideration of the transaction/integration/separation costs, nonrecurring purchase accounting impacts related to the Tyco merger, mark-to-market gains or losses for pension plans, restructuring and impairment costs, and discrete tax items for the three months ending June 30, 2017 and 2016 is approximately 15 percent and 17 percent, respectively.  The three months ended June 30, 2016 includes a non-cash tax charge of $85 million ($0.13) in discontinued operations related to changes in entity tax status associated with the spin-off of the Automotive Experience business.

[0000833444-17-000042:8k_2_02:133]
8. Restructuring

[0000833444-17-000042:8k_2_02:134]
The three and nine months ended June 30, 2017 includes restructuring and impairment costs of $49 million and $226 million, respectively, related primarily to workforce reductions, plant closures and asset impairments in the Building Technologies & Solutions and Power Solutions businesses, and at Corporate.  The three and nine months ended June 30, 2016 restructuring and impairment costs of $27 million and $87 million, respectively, related primarily to workforce reductions, plant closures and asset impairments in the Building Technologies & Solutions business and at Corporate.

[0000833444-17-000042:8k_2_02:135]
Page 16 of 16
