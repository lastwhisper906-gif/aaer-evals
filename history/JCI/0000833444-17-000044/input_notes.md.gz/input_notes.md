# JCI notes — 0000833444-17-000044


## jci:ComponentsOfNetFinancingChargesTableTextBlock

[0000833444-17-000044:notes:1]
The Company's net financing charges line item in the consolidated statements of income for the three and nine month periods ended June 30, 2017 and 2016 contained the following components (in millions):

[0000833444-17-000044:notes:2]
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Interest expense, net of capitalized interest costs | $ | 115 |  |  | $ | 66 |  |  | $ | 343 |  |  | $ | 203 |  |
| Banking fees and bond cost amortization | 14 |  |  | 7 |  |  | 55 |  |  | 19 |  |
| Interest income | (4 | ) |  | (4 | ) |  | (16 | ) |  | (8 | ) |
| Net foreign exchange results for financing activities | (1 | ) |  | (4 | ) |  | (6 | ) |  | (12 | ) |
| Net financing charges | $ | 124 |  |  | $ | 65 |  |  | $ | 376 |  |  | $ | 202 |  |

[0000833444-17-000044:notes:3]
Net financing charges for the nine month period ended June 30, 2017 included $17 million of transaction costs related primarily to the debt exchange offers.


## jci:DisposalGroupIncludingDiscontinuedOperationsIncomeStatementDisclosuresTableTextBlock

[0000833444-17-000044:notes:4]
The following table summarizes the results of Adient, reclassified as discontinued operations for the nine month period ended June 30, 2017, and the three and nine month periods ended June 30, 2016 (in millions). As the Adient spin-off occurred on October 31, 2016, there is only one month of Adient results included in the nine month period ended June 30, 2017.

[0000833444-17-000044:notes:5]
|  | Three Months Ended June 30, |  | Nine Months EndedJune 30, |
|  | 2016 |  | 2017 |  | 2016 |
| Net sales | $ | 4,362 |  |  | $ | 1,434 |  |  | $ | 12,893 |  |
| Income from discontinued operations before income taxes | 185 |  |  | 1 |  |  | 520 |  |
| Provision for income taxes on discontinued operations | 128 |  |  | 35 |  |  | 1,001 |  |
| Income from discontinued operations attributable to noncontrolling interests, net of tax | 21 |  |  | 9 |  |  | 61 |  |
| Income (loss) from discontinued operations | $ | 36 |  |  | $ | (43 | ) |  | $ | (542 | ) |


## jci:EquityAttributableToParentAndNoncontrollingInterestsTableTextBlock

[0000833444-17-000044:notes:6]
[same as prior period, unchanged from 0000833444-17-000016:notes:12]

[0000833444-17-000044:notes:7]
|  | Three Months Ended June 30, 2017 |  | Three Months Ended June 30, 2016 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, March 31 | $ | 19,388 |  |  | $ | 813 |  |  | $ | 20,201 |  |  | $ | 9,984 |  |  | $ | 898 |  |  | $ | 10,882 |  |
| Total comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Net income | 555 |  |  | 66 |  |  | 621 |  |  | 383 |  |  | 59 |  |  | 442 |  |
| Foreign currency translation adjustments | 268 |  |  | 3 |  |  | 271 |  |  | (141 | ) |  | 3 |  |  | (138 | ) |
| Realized and unrealized gains (losses) on derivatives | (7 | ) |  | (1 | ) |  | (8 | ) |  | 6 |  |  | (2 | ) |  | 4 |  |
| Realized and unrealized losses on marketable securities | (3 | ) |  | — |  |  | (3 | ) |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | 258 |  |  | 2 |  |  | 260 |  |  | (135 | ) |  | 1 |  |  | (134 | ) |
| Comprehensive income | 813 |  |  | 68 |  |  | 881 |  |  | 248 |  |  | 60 |  |  | 308 |  |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (234 | ) |  | — |  |  | (234 | ) |  | (189 | ) |  | — |  |  | (189 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | — |  |  | (35 | ) |  | (35 | ) |
| Repurchases of ordinary shares | (307 | ) |  | — |  |  | (307 | ) |  | (475 | ) |  | — |  |  | (475 | ) |
| Change in noncontrolling interest share | — |  |  | 3 |  |  | 3 |  |  | — |  |  | 1 |  |  | 1 |  |
| Other, including options exercised | 71 |  |  | — |  |  | 71 |  |  | 31 |  |  | — |  |  | 31 |  |
| Ending balance, June 30 | $ | 19,731 |  |  | $ | 884 |  |  | $ | 20,615 |  |  | $ | 9,599 |  |  | $ | 924 |  |  | $ | 10,523 |  |

[0000833444-17-000044:notes:8]
|  | Nine Months Ended June 30, 2017 |  | Nine Months Ended June 30, 2016 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, September 30 | $ | 24,118 |  |  | $ | 972 |  |  | $ | 25,090 |  |  | $ | 10,376 |  |  | $ | 163 |  |  | $ | 10,539 |  |
| Total comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Net income | 736 |  |  | 127 |  |  | 863 |  |  | 303 |  |  | 129 |  |  | 432 |  |
| Foreign currency translation adjustments | (150 | ) |  | (22 | ) |  | (172 | ) |  | (126 | ) |  | 12 |  |  | (114 | ) |
| Realized and unrealized gains (losses) on derivatives | (13 | ) |  | 1 |  |  | (12 | ) |  | 9 |  |  | (1 | ) |  | 8 |  |
| Realized and unrealized gains on marketable securities | 6 |  |  | — |  |  | 6 |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | (157 | ) |  | (21 | ) |  | (178 | ) |  | (117 | ) |  | 11 |  |  | (106 | ) |
| Comprehensive income | 579 |  |  | 106 |  |  | 685 |  |  | 186 |  |  | 140 |  |  | 326 |  |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (705 | ) |  | — |  |  | (705 | ) |  | (566 | ) |  | — |  |  | (566 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (47 | ) |  | (47 | ) |  | — |  |  | (71 | ) |  | (71 | ) |
| Repurchases of ordinary shares | (426 | ) |  | — |  |  | (426 | ) |  | (475 | ) |  | — |  |  | (475 | ) |
| Change in noncontrolling interest share | — |  |  | (9 | ) |  | (9 | ) |  | — |  |  | 692 |  |  | 692 |  |
| Spin-off of Adient | (4,038 | ) |  | (138 | ) |  | (4,176 | ) |  | — |  |  | — |  |  | — |  |
| Other, including options exercised | 203 |  |  | — |  |  | 203 |  |  | 78 |  |  | — |  |  | 78 |  |
| Ending balance, June 30 | $ | 19,731 |  |  | $ | 884 |  |  | $ | 20,615 |  |  | $ | 9,599 |  |  | $ | 924 |  |  | $ | 10,523 |  |


## jci:OffsettingDerivativeAssetsandLiabilitiesTableTextBlock

[0000833444-17-000044:notes:9]
[same as prior period, unchanged from 0000833444-17-000016:notes:15]

[0000833444-17-000044:notes:10]
|  | Fair Value of Assets |  | Fair Value of Liabilities |
|  | June 30, |  | September 30, |  | June 30, |  | September 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Gross amount recognized | $ | 95 |  |  | $ | 95 |  |  | $ | 1,713 |  |  | $ | 2,980 |  |
| Gross amount eligible for offsetting | (18 | ) |  | (21 | ) |  | (18 | ) |  | (21 | ) |
| Net amount | $ | 77 |  |  | $ | 74 |  |  | $ | 1,695 |  |  | $ | 2,959 |  |


## jci:ScheduleOfIntangibleAssetsTableTextBlock

[0000833444-17-000044:notes:11]
[same as prior period, unchanged from 0000833444-17-000016:notes:17]

[0000833444-17-000044:notes:12]
|  | June 30, 2017 |  | September 30, 2016 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Amortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,231 |  |  | $ | (129 | ) |  | $ | 1,102 |  |  | $ | 1,528 |  |  | $ | (24 | ) |  | $ | 1,504 |  |
| Customer relationships | 3,116 |  |  | (397 | ) |  | 2,719 |  |  | 3,168 |  |  | (226 | ) |  | 2,942 |  |
| Miscellaneous | 526 |  |  | (244 | ) |  | 282 |  |  | 519 |  |  | (130 | ) |  | 389 |  |
| Total amortized intangible assets | 4,873 |  |  | (770 | ) |  | 4,103 |  |  | 5,215 |  |  | (380 | ) |  | 4,835 |  |
| Unamortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,497 |  |  | — |  |  | 2,497 |  |  | 2,555 |  |  | — |  |  | 2,555 |  |
| Miscellaneous | 127 |  |  | — |  |  | 127 |  |  | 150 |  |  | — |  |  | 150 |  |
| Total intangible assets | $ | 7,497 |  |  | $ | (770 | ) |  | $ | 6,727 |  |  | $ | 7,920 |  |  | $ | (380 | ) |  | $ | 7,540 |  |


## jci:ScheduleofFairValueofConsiderationTransferredTableTextBlock

[0000833444-17-000044:notes:13]
[same as prior period, unchanged from 0000833444-17-000016:notes:19]

[0000833444-17-000044:notes:14]
| (in millions, except for share consolidation ratio and share data) |  |  |
| Number of Tyco shares outstanding at September 2, 2016 |  | 427,181,743 |  |
| Tyco share consolidation ratio |  | 0.955 |  |
| Tyco ordinary shares outstanding following the share consolidation and immediately prior to the Merger |  | 407,958,565 |  |
| JCI Inc. converted share price (1) |  | $ | 47.67 |  |
| Fair value of equity portion of the Merger consideration |  | $ | 19,447 |  |
| Fair value of Tyco equity awards |  | 224 |  |
| Total fair value of consideration transferred |  | $ | 19,671 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-17-000044:notes:15]
Commitments and Contingencies

[0000833444-17-000044:notes:16]
Environmental Matters

[0000833444-17-000044:notes:17]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of June 30, 2017, reserves for environmental liabilities totaled $48 million, of which $12 million was recorded within other current liabilities and $36 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $51 million at September 30, 2016. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At June 30, 2017 and September 30, 2016, the Company recorded conditional asset retirement obligations of $72 million and $74 million, respectively.

[0000833444-17-000044:notes:18]
Asbestos Matters

[0000833444-17-000044:notes:19]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-17-000044:notes:20]
As of June 30, 2017, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $147 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $535 million, of which $35 million was recorded in other current liabilities and $500 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $388 million, of which $52 million was recorded in other current assets, and $336 million was recorded in other noncurrent assets. Assets included $28 million of cash and $264 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at June 30, 2017 was $96 million. As of September 30, 2016, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $148 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $548 million, of which $35 million was recorded in other current liabilities and $513 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $400 million, of which $41 million was recorded in other current assets, and $359 million was recorded in other noncurrent assets. Assets included $16 million of cash and $264 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2016 was $120 million. The Company believes that the asbestos related liabilities and insurance related receivables recorded as of June 30, 2017 and September 30, 2016 are appropriate.

[0000833444-17-000044:notes:21]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2069 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2069. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-17-000044:notes:22]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-17-000044:notes:23]
Insurable Liabilities

[0000833444-17-000044:notes:24]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At June 30, 2017 and September 30, 2016, the insurable liabilities for continuing operations totaled $488 million and $422 million, respectively, of which $86 million and $60 million was recorded within other current liabilities, $30 million and $28 million was recorded within accrued compensation and benefits, and $372 million and $334 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at June 30, 2017 was $49 million, of which $30 million was recorded within other current assets and $19 million was recorded within other noncurrent assets. Insurance receivables recorded at September 30, 2016 were $21 million, primarily recorded within other noncurrent assets. The Company maintains captive insurance companies to manage certain of its insurable liabilities.

[0000833444-17-000044:notes:25]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:CondensedFinancialStatementsTextBlock

[0000833444-17-000044:notes:26]
[same as prior period, unchanged from 0000833444-17-000016:notes:32]

[0000833444-17-000044:notes:27]
[same as prior period, unchanged from 0000833444-17-000016:notes:33]

[0000833444-17-000044:notes:28]
The TIFSA public debt securities were assumed as part of the Tyco acquisition. Therefore, no consolidating financial information for the period ended June 30, 2016 is presented related to the guarantee of the TIFSA public debt securities. Additional information regarding TIFSA and TIFSCA for the period ended June 24, 2016 can be found in Tyco's Quarterly report on Form 10-Q filed with the SEC on July 29, 2016.

[0000833444-17-000044:notes:29]
CONDENSED CONSOLIDATING STATEMENT OF INCOME

[0000833444-17-000044:notes:30]
For the Three Months Ended June 30, 2017

[0000833444-17-000044:notes:31]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net sales | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 7,683 |  |  | $ | — |  |  | $ | 7,683 |  |
| Cost of sales | — |  |  | — |  |  |  |  |  | 5,252 |  |  | — |  |  | 5,252 |  |
| Gross profit | — |  |  | — |  |  | — |  |  | 2,431 |  |  | — |  |  | 2,431 |  |
| Selling, general and administrative expenses | (1 | ) |  | — |  |  | — |  |  | (1,608 | ) |  | — |  |  | (1,609 | ) |
| Restructuring and impairment costs | — |  |  | — |  |  | — |  |  | (49 | ) |  | — |  |  | (49 | ) |
| Net financing charges | (59 | ) |  | (1 | ) |  | (3 | ) |  | (61 | ) |  | — |  |  | (124 | ) |
| Equity income | 626 |  |  | 468 |  |  | 68 |  |  | 69 |  |  | (1,162 | ) |  | 69 |  |
| Intercompany interest and fees | (11 | ) |  | 89 |  |  | (5 | ) |  | (73 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 555 |  |  | 556 |  |  | 60 |  |  | 709 |  |  | (1,162 | ) |  | 718 |  |
| Income tax provision | — |  |  | — |  |  | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Net income | 555 |  |  | 556 |  |  | 60 |  |  | 620 |  |  | (1,162 | ) |  | 629 |  |
| Income from continuing operations attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 74 |  |  | — |  |  | 74 |  |
| Net income attributable to Johnson Controls | $ | 555 |  |  | $ | 556 |  |  | $ | 60 |  |  | $ | 546 |  |  | $ | (1,162 | ) |  | $ | 555 |  |

[0000833444-17-000044:notes:32]
CONDENSED CONSOLIDATING STATEMENT OF COMPREHENSIVE INCOME (LOSS)

[0000833444-17-000044:notes:33]
| (in millions) | Johnson ControlsInternationalplc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net income | $ | 555 |  |  | $ | 556 |  |  | $ | 60 |  |  | $ | 620 |  |  | $ | (1,162 | ) |  | $ | 629 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments | 268 |  |  | (30 | ) |  | (4 | ) |  | 319 |  |  | (268 | ) |  | 285 |  |
| Realized and unrealized losses on derivatives | (7 | ) |  | — |  |  | — |  |  | (9 | ) |  | 7 |  |  | (9 | ) |
| Realized and unrealized gains (losses) on marketable securities | (3 | ) |  | — |  |  | (6 | ) |  | 3 |  |  | 3 |  |  | (3 | ) |
| Other comprehensive income (loss) | 258 |  |  | (30 | ) |  | (10 | ) |  | 313 |  |  | (258 | ) |  | 273 |  |
| Total comprehensive income | 813 |  |  | 526 |  |  | 50 |  |  | 933 |  |  | (1,420 | ) |  | 902 |  |
| Comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Comprehensive income attributable to Johnson Controls | $ | 813 |  |  | $ | 526 |  |  | $ | 50 |  |  | $ | 844 |  |  | $ | (1,420 | ) |  | $ | 813 |  |

[0000833444-17-000044:notes:34]
For the Nine Months Ended June 30, 2017

[0000833444-17-000044:notes:35]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net sales | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 22,036 |  |  | $ | — |  |  | $ | 22,036 |  |
| Cost of sales | — |  |  | — |  |  | — |  |  | 15,210 |  |  | — |  |  | 15,210 |  |
| Gross profit | — |  |  | — |  |  | — |  |  | 6,826 |  |  | — |  |  | 6,826 |  |
| Selling, general and administrative expenses | (7 | ) |  | — |  |  | — |  |  | (4,898 | ) |  | — |  |  | (4,905 | ) |
| Restructuring and impairment costs | — |  |  | — |  |  | — |  |  | (226 | ) |  | — |  |  | (226 | ) |
| Net financing charges | (137 | ) |  | (1 | ) |  | (17 | ) |  | (221 | ) |  | — |  |  | (376 | ) |
| Equity income (loss) | 841 |  |  | (32 | ) |  | (433 | ) |  | 177 |  |  | (376 | ) |  | 177 |  |
| Intercompany interest and fees | 39 |  |  | 162 |  |  | 32 |  |  | (233 | ) |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes | 736 |  |  | 129 |  |  | (418 | ) |  | 1,425 |  |  | (376 | ) |  | 1,496 |  |
| Income tax provision | — |  |  | — |  |  | — |  |  | 570 |  |  | — |  |  | 570 |  |
| Income (loss) from continuing operations | 736 |  |  | 129 |  |  | (418 | ) |  | 855 |  |  | (376 | ) |  | 926 |  |
| Income (loss) from sale of intercompany investment, net of tax | — |  |  | — |  |  | (935 | ) |  | — |  |  | 935 |  |  | — |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | — |  |  | (34 | ) |  | — |  |  | (34 | ) |
| Net income (loss) | 736 |  |  | 129 |  |  | (1,353 | ) |  | 821 |  |  | 559 |  |  | 892 |  |
| Income from continuing operations attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 147 |  |  | — |  |  | 147 |  |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Net income (loss) attributable to Johnson Controls | $ | 736 |  |  | $ | 129 |  |  | $ | (1,353 | ) |  | $ | 665 |  |  | $ | 559 |  |  | $ | 736 |  |

[0000833444-17-000044:notes:36]
| (in millions) | Johnson ControlsInternationalplc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net income (loss) | $ | 736 |  |  | $ | 129 |  |  | $ | (1,353 | ) |  | $ | 821 |  |  | $ | 559 |  |  | $ | 892 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments | (150 | ) |  | (37 | ) |  | 22 |  |  | (151 | ) |  | 150 |  |  | (166 | ) |
| Realized and unrealized losses on derivatives | (13 | ) |  | — |  |  | — |  |  | (13 | ) |  | 13 |  |  | (13 | ) |
| Realized and unrealized gains on marketable securities | 6 |  |  | — |  |  | 1 |  |  | 5 |  |  | (6 | ) |  | 6 |  |
| Other comprehensive income (loss) | (157 | ) |  | (37 | ) |  | 23 |  |  | (159 | ) |  | 157 |  |  | (173 | ) |
| Total comprehensive income (loss) | 579 |  |  | 92 |  |  | (1,330 | ) |  | 662 |  |  | 716 |  |  | 719 |  |
| Comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 140 |  |  | — |  |  | 140 |  |
| Comprehensive income (loss) attributable to Johnson Controls | $ | 579 |  |  | $ | 92 |  |  | $ | (1,330 | ) |  | $ | 522 |  |  | $ | 716 |  |  | $ | 579 |  |

[0000833444-17-000044:notes:37]
[same as prior period, unchanged from 0000833444-17-000016:notes:43]

[0000833444-17-000044:notes:38]
As of June 30, 2017

[0000833444-17-000044:notes:39]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | — |  |  | $ | 318 |  |  | $ | 388 |  |  | $ | (248 | ) |  | $ | 458 |  |
| Accounts receivable - net | — |  |  | — |  |  | — |  |  | 6,443 |  |  | — |  |  | 6,443 |  |
| Inventories | — |  |  | — |  |  | — |  |  | 3,384 |  |  | — |  |  | 3,384 |  |
| Intercompany receivables | 1,857 |  |  | 1,786 |  |  | 38 |  |  | 8,279 |  |  | (11,960 | ) |  | — |  |
| Assets held for sale | — |  |  | — |  |  | — |  |  | 2,082 |  |  | — |  |  | 2,082 |  |
| Other current assets | 40 |  |  | — |  |  | 2 |  |  | 1,553 |  |  | — |  |  | 1,595 |  |
| Current assets | $ | 1,897 |  |  | $ | 1,786 |  |  | $ | 358 |  |  | $ | 22,129 |  |  | $ | (12,208 | ) |  | $ | 13,962 |  |
| Property, plant and equipment - net | — |  |  | — |  |  | — |  |  | 5,870 |  |  | — |  |  | 5,870 |  |
| Goodwill | 243 |  |  | — |  |  | 32 |  |  | 19,344 |  |  | — |  |  | 19,619 |  |
| Other intangible assets - net | — |  |  | — |  |  | — |  |  | 6,727 |  |  | — |  |  | 6,727 |  |
| Investments in partially-owned affiliates | — |  |  | — |  |  | — |  |  | 1,159 |  |  | — |  |  | 1,159 |  |
| Investments in affiliates | 18,098 |  |  | 29,456 |  |  | 22,515 |  |  | — |  |  | (70,069 | ) |  | — |  |
| Intercompany loans receivable | 17,862 |  |  | 4,140 |  |  | 2,836 |  |  | 4,688 |  |  | (29,526 | ) |  | — |  |
| Other noncurrent assets | 59 |  |  | — |  |  | 12 |  |  | 3,278 |  |  | — |  |  | 3,349 |  |
| Total assets | $ | 38,159 |  |  | $ | 35,382 |  |  | $ | 25,753 |  |  | $ | 63,195 |  |  | $ | (111,803 | ) |  | $ | 50,686 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | 1,592 |  |  | $ | 76 |  |  | $ | — |  |  | $ | 536 |  |  | $ | (248 | ) |  | $ | 1,956 |  |
| Current portion of long-term debt | 444 |  |  | — |  |  | 18 |  |  | 81 |  |  | — |  |  | 543 |  |
| Accounts payable | — |  |  | — |  |  | — |  |  | 3,764 |  |  | — |  |  | 3,764 |  |
| Accrued compensation and benefits | 1 |  |  | — |  |  | — |  |  | 1,003 |  |  | — |  |  | 1,004 |  |
| Liabilities held for sale | — |  |  | — |  |  | — |  |  | 247 |  |  | — |  |  | 247 |  |
| Intercompany payables | 3,911 |  |  | 1,037 |  |  | 6,001 |  |  | 1,011 |  |  | (11,960 | ) |  | — |  |
| Other current liabilities | 350 |  |  | 3 |  |  | 24 |  |  | 3,624 |  |  | — |  |  | 4,001 |  |
| Current liabilities | 6,298 |  |  | 1,116 |  |  | 6,043 |  |  | 10,266 |  |  | (12,208 | ) |  | 11,515 |  |
| Long-term debt | 7,442 |  |  | — |  |  | 153 |  |  | 4,177 |  |  | — |  |  | 11,772 |  |
| Pension and postretirement benefits | — |  |  | — |  |  | — |  |  | 1,330 |  |  | — |  |  | 1,330 |  |
| Intercompany loans payable | 4,688 |  |  | 17,862 |  |  | — |  |  | 6,976 |  |  | (29,526 | ) |  | — |  |
| Other noncurrent liabilities | — |  |  | — |  |  | 24 |  |  | 5,241 |  |  | — |  |  | 5,265 |  |
| Long-term liabilities | 12,130 |  |  | 17,862 |  |  | 177 |  |  | 17,724 |  |  | (29,526 | ) |  | 18,367 |  |
| Redeemable noncontrolling interests | — |  |  | — |  |  | — |  |  | 189 |  |  | — |  |  | 189 |  |
| Ordinary shares | 9 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 9 |  |
| Ordinary shares held in treasury | (481 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (481 | ) |
| Other shareholders' equity | 20,203 |  |  | 16,404 |  |  | 19,533 |  |  | 34,132 |  |  | (70,069 | ) |  | 20,203 |  |
| Shareholders’ equity attributable to Johnson Controls | 19,731 |  |  | 16,404 |  |  | 19,533 |  |  | 34,132 |  |  | (70,069 | ) |  | 19,731 |  |
| Noncontrolling interests | — |  |  | — |  |  | — |  |  | 884 |  |  | — |  |  | 884 |  |
| Total equity | 19,731 |  |  | 16,404 |  |  | 19,533 |  |  | 35,016 |  |  | (70,069 | ) |  | 20,615 |  |
| Total liabilities and equity | $ | 38,159 |  |  | $ | 35,382 |  |  | $ | 25,753 |  |  | $ | 63,195 |  |  | $ | (111,803 | ) |  | $ | 50,686 |  |

[0000833444-17-000044:notes:40]
[same as prior period, unchanged from 0000833444-17-000016:notes:46]

[0000833444-17-000044:notes:41]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Operating Activities |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided (used) by operating activities | $ | 136 |  |  | $ | — |  |  | $ | 97 |  |  | $ | (1,554 | ) |  | $ | — |  |  | $ | (1,321 | ) |
| Investing Activities |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | — |  |  | (996 | ) |  | — |  |  | (996 | ) |
| Sale of property, plant and equipment | — |  |  | — |  |  | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | (6 | ) |  | — |  |  | — |  |  | (6 | ) |
| Business divestitures | — |  |  | — |  |  | — |  |  | 180 |  |  | — |  |  | 180 |  |
| Changes in long-term investments | — |  |  | — |  |  | (11 | ) |  | (22 | ) |  | — |  |  | (33 | ) |
| Net change in intercompany loans receivable | — |  |  | — |  |  | 10 |  |  | 357 |  |  | (367 | ) |  | — |  |
| Increase in intercompany investment in subsidiaries | (1,924 | ) |  | (1,716 | ) |  | (76 | ) |  | — |  |  | 3,716 |  |  | — |  |
| Net cash used by investing activities | (1,924 | ) |  | (1,716 | ) |  | (83 | ) |  | (458 | ) |  | 3,349 |  |  | (832 | ) |
| Financing Activities |  |  |  |  |  |  |  |  |  |  |  |
| Increase (decrease) in short-term debt - net | 1,592 |  |  | 76 |  |  | — |  |  | (533 | ) |  | (248 | ) |  | 887 |  |
| Increase in long-term debt | 1,544 |  |  | — |  |  | — |  |  | 9 |  |  | — |  |  | 1,553 |  |
| Repayment of long-term debt | (46 | ) |  | — |  |  | (16 | ) |  | (910 | ) |  | — |  |  | (972 | ) |
| Debt financing costs | (17 | ) |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (18 | ) |
| Stock repurchases | (426 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (426 | ) |
| Payment of cash dividends | (469 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (469 | ) |
| Proceeds from the exercise of stock options | 56 |  |  | — |  |  | — |  |  | 74 |  |  | — |  |  | 130 |  |
| Net change in intercompany loans payable | (357 | ) |  | — |  |  | — |  |  | (10 | ) |  | 367 |  |  | — |  |
| Increase in equity from parent | — |  |  | 1,640 |  |  | 76 |  |  | 2,000 |  |  | (3,716 | ) |  | — |  |
| Change in noncontrolling interest share | — |  |  | — |  |  | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Dividends paid to noncontrolling interests | — |  |  | — |  |  | — |  |  | (78 | ) |  | — |  |  | (78 | ) |
| Dividend from Adient spin-off | (87 | ) |  | — |  |  | — |  |  | 2,137 |  |  | — |  |  | 2,050 |  |
| Cash transferred to Adient related to spin-off | — |  |  | — |  |  | — |  |  | (665 | ) |  | — |  |  | (665 | ) |
| Cash paid related to prior acquisitions | — |  |  | — |  |  | — |  |  | (75 | ) |  | — |  |  | (75 | ) |
| Other | (13 | ) |  | — |  |  | — |  |  | 3 |  |  | — |  |  | (10 | ) |
| Net cash provided by financing activities | 1,777 |  |  | 1,716 |  |  | 60 |  |  | 1,959 |  |  | (3,597 | ) |  | 1,915 |  |
| Effect of exchange rate changes on cash and cash equivalents | — |  |  | — |  |  | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Changes in cash held for sale | — |  |  | — |  |  | — |  |  | 105 |  |  | — |  |  | 105 |  |
| Increase (decrease) in cash and cash equivalents | (11 | ) |  | — |  |  | 74 |  |  | 64 |  |  | (248 | ) |  | (121 | ) |
| Cash and cash equivalents at beginning of period | 11 |  |  | — |  |  | 244 |  |  | 324 |  |  | — |  |  | 579 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | — |  |  | $ | 318 |  |  | $ | 388 |  |  | $ | (248 | ) |  | $ | 458 |  |

[0000833444-17-000044:notes:42]
[same as prior period, unchanged from 0000833444-17-000016:notes:48]

[0000833444-17-000044:notes:43]
[same as prior period, unchanged from 0000833444-17-000016:notes:49]


## us-gaap:DebtDisclosureTextBlock

[0000833444-17-000044:notes:44]
Debt and Financing Arrangements

[0000833444-17-000044:notes:45]
Debt exchange

[0000833444-17-000044:notes:46]
In connection with the Tyco Merger, on December 28, 2016, the Company completed its offers to exchange all validly tendered and accepted notes of certain series (the "existing notes") issued by JCI Inc. or Tyco International Finance S.A. ("TIFSA"), as applicable, each of which is a wholly owned subsidiary of the Company, for new notes (the New Notes) to be issued by the Company, and the related solicitation of consents to amend the indentures governing the existing notes (the offers to exchange and the related consent solicitation together the "exchange offers"). Pursuant to the exchange offers, the Company exchanged approximately $5.6 billion of $6.0 billion in aggregate principal amount of dollar denominated notes and approximately 423 million euro of 500 million euro in aggregate principal amount of euro denominated notes. All validly tendered and accepted existing notes have been canceled. Immediately following such cancellation, $380.9 million aggregate principal amount of existing notes (not including the TIFSA Euro Notes) remained outstanding across seventeen series of dollar-denominated existing notes and 77.4 million euro aggregate principal amount of TIFSA Euro Notes remained outstanding across one series. In connection with the settlement of the exchange offers, the New Notes were registered under the Securities Act of 1933 and their terms are described in the Company’s Prospectus dated December 19, 2016, as filed with the SEC under Rule 424(b)(3) of the Act on that date. The issuance of the New Notes occurred on December 28, 2016. The New Notes are unsecured and unsubordinated obligations of the Company and will rank equally with all other unsecured and unsubordinated indebtedness of the Company issued from time to time.

[0000833444-17-000044:notes:47]
Other financing arrangements

[0000833444-17-000044:notes:48]
In June 2017, the Company partially repaid $135 million of the $4.0 billion floating rate term loan scheduled to mature in March 2020.

[0000833444-17-000044:notes:49]
In March 2017, the Company issued one billion euro in principal amount of 1.0% senior unsecured fixed rate notes due in         fiscal 2023. Proceeds from the issuance were used to repay existing debt and for other general corporate purposes.

[0000833444-17-000044:notes:50]
In March 2017, the Company entered into a 364-day $150 million committed revolving credit facility scheduled to expire in March 2018. As of June 30, 2017, there were no draws on the facility.

[0000833444-17-000044:notes:51]
In March 2017, the Company retired $46 million in principal amount, plus accrued interest, of its 2.355% fixed rate notes that matured in March 2017.

[0000833444-17-000044:notes:52]
In March and February 2017, the Company repurchased, at a discount, 15 million euro of its TIFSA 1.375% fixed rate notes, plus accrued interest, scheduled to mature in February 2025.

[0000833444-17-000044:notes:53]
In February 2017, the Company issued $500 million aggregate principal amount of 4.5% senior unsecured fixed rate notes due in fiscal 2047. Proceeds from the issuance were used to repay outstanding commercial paper borrowings and for other general corporate purposes.

[0000833444-17-000044:notes:54]
In February 2017, the Company entered into a 364-day $150 million committed revolving credit facility scheduled to expire in February 2018. As of June 30, 2017, there were no draws on the facility.

[0000833444-17-000044:notes:55]
In January 2017, the Company entered into a 364-day $250 million committed revolving credit facility scheduled to expire                      in January 2018. As of June 30, 2017, there were no draws on the facility outstanding.

[0000833444-17-000044:notes:56]
In December 2016, the Company retired $400 million in principal amount, plus accrued interest, of its 2.6% fixed rate notes that matured in December 2016.

[0000833444-17-000044:notes:57]
In December 2016, the Company entered into a 364-day 100 million euro floating rate term loan scheduled to mature in December 2017. Proceeds from the term loan were used for general corporate purposes. Principal and accrued interest were fully repaid in March 2017.

[0000833444-17-000044:notes:58]
In December 2016, a $100 million committed revolving credit facility expired. There were no draws on the facility.

[0000833444-17-000044:notes:59]
In November 2016, the Company fully repaid its 37 billion yen syndicated floating rate term loan, plus accrued interest, scheduled to mature in June 2020.

[0000833444-17-000044:notes:60]
In November 2016, a $35 million committed revolving credit facility expired. There were no draws on the facility.

[0000833444-17-000044:notes:61]
In October 2016, the Company repaid two ten-month floating rate term loans totaling $325 million, plus accrued interest, scheduled to mature in October 2016.

[0000833444-17-000044:notes:62]
In October 2016, the Company repaid a nine-month $100 million floating rate term loan, plus accrued interest, scheduled to mature in November 2016.

[0000833444-17-000044:notes:63]
In October 2016, the Company repaid a nine-month 100 million euro floating rate term loan, plus accrued interest, scheduled to mature in October 2016.

[0000833444-17-000044:notes:64]
Net Financing Charges


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-17-000044:notes:65]
[same as prior period, unchanged from 0000833444-17-000016:notes:70]

[0000833444-17-000044:notes:66]
[same as prior period, unchanged from 0000833444-17-000016:notes:71]

[0000833444-17-000044:notes:67]
[same as prior period, unchanged from 0000833444-17-000016:notes:72]

[0000833444-17-000044:notes:68]
The Company has global operations and participates in the foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange hedge contracts. The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. As cash flow hedges under ASC 815, "Derivatives and Hedging," the effective portion of the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. Any ineffective portion of the hedge is reflected in the consolidated statements of income. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the three and nine months ended June 30, 2017 and 2016.

[0000833444-17-000044:notes:69]
The Company selectively hedges anticipated transactions that are subject to commodity price risk, primarily using commodity hedge contracts, to minimize overall price risk associated with the Company’s purchases of lead, copper, tin, aluminum and polypropylene in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. As cash flow hedges, the effective portion of the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions, typically sales, occur and affect earnings. Any ineffective portion of the hedge is reflected in the consolidated statements of income. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in commodity prices during the three and nine months ended June 30, 2017 and 2016.

[0000833444-17-000044:notes:70]
[same as prior period, unchanged from 0000833444-17-000016:notes:75]

[0000833444-17-000044:notes:71]
|  |  |  |  | Volume Outstanding as of |
| Commodity |  | Units |  | June 30, 2017 |  | September 30, 2016 |
| Copper |  | Pounds |  | 6,200,000 |  |  | 5,849,000 |  |
| Polypropylene |  | Pounds |  | 18,000,000 |  |  | — |  |
| Lead |  | Metric Tons |  | 8,645 |  |  | 5,185 |  |
| Aluminum |  | Metric Tons |  | 2,860 |  |  | 2,620 |  |
| Tin |  | Metric Tons |  | 2,225 |  |  | 185 |  |

[0000833444-17-000044:notes:72]
[same as prior period, unchanged from 0000833444-17-000016:notes:77]

[0000833444-17-000044:notes:73]
[same as prior period, unchanged from 0000833444-17-000016:notes:78]

[0000833444-17-000044:notes:74]
The Company selectively uses interest rate swaps to reduce market risk associated with changes in interest rates for its fixed-rate bonds. As fair value hedges, the interest rate swaps and related debt balances are valued under a market approach using publicized swap curves. Changes in the fair value of the swap and hedged portion of the debt are recorded in the consolidated statements of income. In the third quarter of fiscal 2014, the Company entered into four fixed to floating interest rate swaps totaling $400 million to hedge the coupon of its 2.6% notes that matured in December 2016, three fixed to floating interest rate swaps totaling $300 million to hedge the coupon of its 1.4% notes maturing November 2017 and one fixed to floating interest rate swap totaling $150 million to hedge the coupon of its 7.125% notes maturing July 2017.  In December 2016, the four remaining outstanding interest rate swaps were terminated. The Company had no interest rate swaps outstanding at June 30, 2017. There were eight interest rate swaps outstanding as of September 30, 2016.

[0000833444-17-000044:notes:75]
[same as prior period, unchanged from 0000833444-17-000016:notes:80]

[0000833444-17-000044:notes:76]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally. At June 30, 2017, the Company had one billion euro and 485 million euro bonds designated as net investment hedges in the Company's net investment in Europe. At September 30, 2016, the Company had 37 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan and one billion euro and 500 million euro bonds designated as net investment hedges in the Company's net investment in Europe.

[0000833444-17-000044:notes:77]
[same as prior period, unchanged from 0000833444-17-000016:notes:82]

[0000833444-17-000044:notes:78]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount. As of June 30, 2017, the Company hedged approximately 1.4 million shares of its ordinary shares. As of  September 30, 2016, the Company had no equity swaps outstanding.

[0000833444-17-000044:notes:79]
[same as prior period, unchanged from 0000833444-17-000016:notes:84]

[0000833444-17-000044:notes:80]
[same as prior period, unchanged from 0000833444-17-000016:notes:85]

[0000833444-17-000044:notes:81]
|  | Derivatives and Hedging Activities Designatedas Hedging Instruments under ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instruments under ASC 815 |
|  | June 30, |  | September 30, |  | June 30, |  | September 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 7 |  |  | $ | 41 |  |  | $ | 26 |  |  | $ | 49 |  |
| Commodity derivatives | 3 |  |  | 4 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Interest rate swaps | — |  |  | 1 |  |  | — |  |  | — |  |
| Equity swap | — |  |  | — |  |  | 59 |  |  | — |  |
| Total assets | $ | 10 |  |  | $ | 46 |  |  | $ | 85 |  |  | $ | 49 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 6 |  |  | $ | 48 |  |  | $ | 13 |  |  | $ | 18 |  |
| Commodity derivatives | 1 |  |  | — |  |  | — |  |  | — |  |
| Liabilities held for sale |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | — |  |  | — |  |  | — |  |  | 5 |  |
| Current portion of long-term debt |  |  |  |  |  |  |  |
| Fixed rate debt swapped to floating | — |  |  | 551 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 1,693 |  |  | 938 |  |  | — |  |  | — |  |
| Fixed rate debt swapped to floating | — |  |  | 301 |  |  | — |  |  | — |  |
| Noncurrent liabilities held for sale |  |  |  |  |  |  |  |
| Foreign currency denominated debt | — |  |  | 1,119 |  |  | — |  |  | — |  |
| Total liabilities | $ | 1,700 |  |  | $ | 2,957 |  |  | $ | 13 |  |  | $ | 23 |  |

[0000833444-17-000044:notes:82]
[same as prior period, unchanged from 0000833444-17-000016:notes:87]

[0000833444-17-000044:notes:83]
[same as prior period, unchanged from 0000833444-17-000016:notes:88]

[0000833444-17-000044:notes:84]
The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position. Collateral is generally not required of the Company or the counterparties under the master netting agreements. As of June 30, 2017 and September 30, 2016, no cash collateral was received or pledged under the master netting agreements.

[0000833444-17-000044:notes:85]
[same as prior period, unchanged from 0000833444-17-000016:notes:90]

[0000833444-17-000044:notes:86]
The following table presents the effective portion of pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges for the three and nine months ended June 30, 2017 and 2016 (in millions):

[0000833444-17-000044:notes:87]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Foreign currency exchange derivatives |  | $ | (3 | ) |  | $ | (5 | ) |  | $ | 3 |  |  | $ | (11 | ) |
| Commodity derivatives |  | 1 |  |  | 1 |  |  | 6 |  |  | — |  |
| Total |  | $ | (2 | ) |  | $ | (4 | ) |  | $ | 9 |  |  | $ | (11 | ) |

[0000833444-17-000044:notes:88]
The following tables present the location and amount of the effective portion of pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income for the three and nine months ended June 30, 2017 and 2016 (in millions):

[0000833444-17-000044:notes:89]
| Derivatives in ASC 815 Cash FlowHedging Relationships |  | Location of Gain (Loss) Reclassifiedfrom AOCI into Income |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 8 |  |  | $ | 2 |  |  | $ | 24 |  |  | $ | 11 |  |
| Foreign currency exchange derivatives |  | Loss from discontinued operations |  | — |  |  | (10 | ) |  | — |  |  | (24 | ) |
| Commodity derivatives |  | Cost of sales |  | 3 |  |  | (2 | ) |  | 7 |  |  | (11 | ) |
| Forward treasury locks |  | Net financing charges |  | — |  |  | — |  |  | — |  |  | 1 |  |
| Total |  |  |  | $ | 11 |  |  | $ | (10 | ) |  | $ | 31 |  |  | $ | (23 | ) |

[0000833444-17-000044:notes:90]
The following table presents the location and amount of pre-tax gains (losses) on fair value hedges recognized in the Company’s consolidated statements of income for the three and nine months ended June 30, 2017 and 2016 (in millions):

[0000833444-17-000044:notes:91]
| Derivatives in ASC 815 Fair ValueHedging Relationships |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Interest rate swap |  | Net financing charges |  | $ | — |  |  | $ | — |  |  | $ | (1 | ) |  | $ | (3 | ) |
| Fixed rate debt swapped to floating |  | Net financing charges |  | — |  |  | — |  |  | 2 |  |  | 3 |  |
| Total |  |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |

[0000833444-17-000044:notes:92]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income for the three and nine months ended June 30, 2017 and 2016 (in millions):

[0000833444-17-000044:notes:93]
|  |  |  |  | Amount of Gain (Loss) Recognized in Income on Derivative |
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (4 | ) |  | $ | 1 |  |  | $ | (1 | ) |  | $ | 4 |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | 51 |  |  | (14 | ) |  | 60 |  |  | (21 | ) |
| Foreign currency exchange derivatives |  | Income tax provision |  | 1 |  |  | 5 |  |  | (2 | ) |  | 5 |  |
| Foreign currency exchange derivatives |  | Income (loss) from discontinued operations |  | — |  |  | (5 | ) |  | 5 |  |  | (16 | ) |
| Equity swap |  | Selling, general and administrative |  | 2 |  |  | 20 |  |  | 2 |  |  | 12 |  |
| Total |  |  |  | $ | 50 |  |  | $ | 7 |  |  | $ | 64 |  |  | $ | (16 | ) |

[0000833444-17-000044:notes:94]
The effective portion of pre-tax gains (losses) recorded in foreign currency translation adjustment ("CTA") within other comprehensive income (loss) related to net investment hedges were $(105) million and $(36) million for the three months ended June 30, 2017 and 2016, respectively. The effective portion of pre-tax gains (losses) recorded in CTA within other comprehensive income (loss) related to net investment hedges were $(77) million and $(62) million for the for the nine months ended June 30, 2017 and 2016, respectively. For the three and nine months ended June 30, 2017 and 2016, no gains or losses were reclassified from CTA into income for the Company’s outstanding net investment hedges, and no gains or losses were recognized in income for the ineffective portion of cash flow hedges.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-17-000044:notes:95]
[same as prior period, unchanged from 0000833444-17-000016:notes:100]

[0000833444-17-000044:notes:96]
References to the Company's stock throughout Note 13 refer to stock of JCI Inc. prior to the Tyco Merger date of September 2, 2016 (the "Merger Date") and to ordinary shares of the Company subsequent to the Merger Date.

[0000833444-17-000044:notes:97]
During September 2016, the Board of Directors of the Company approved amendments to the Johnson Controls International plc 2012 Share and Incentive Plan (the "Plan"). The types of awards authorized by the Plan comprise of stock options, stock appreciation rights, performance shares, performance units and other stock-based compensation awards. The Compensation Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. Awards are typically granted annually in the Company’s fiscal first quarter. A summary of the stock-based awards granted during the nine month periods ended June 30, 2017 and 2016 is presented below:

[0000833444-17-000044:notes:98]
|  | Nine Months Ended June 30, |
|  | 2017 |  | 2016 |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  | Number Granted |  | Weighted Average Grant Date Fair Value |
| Stock options | 2,841,686 |  |  | $ | 7.81 |  |  | 961,705 |  |  | $ | 13.14 |  |
| Stock appreciation rights | 15,693 |  |  | 8.28 |  |  | 54,749 |  |  | 13.15 |  |
| Restricted stock/units | 1,671,677 |  |  | 41.75 |  |  | 2,290,575 |  |  | 43.68 |  |
| Performance shares | 846,725 |  |  | 48.40 |  |  | — |  |  | — |  |

[0000833444-17-000044:notes:99]
[same as prior period, unchanged from 0000833444-17-000016:notes:104]

[0000833444-17-000044:notes:100]
[same as prior period, unchanged from 0000833444-17-000016:notes:105]

[0000833444-17-000044:notes:101]
[same as prior period, unchanged from 0000833444-17-000016:notes:106]

[0000833444-17-000044:notes:102]
|  | Nine Months Ended June 30, |
|  | 2017 |  | 2016 |
| Expected life of option (years) | 4.75 & 6.5 |  | 6.4 |
| Risk-free interest rate | 1.23% - 1.93% |  | 1.64% |
| Expected volatility of the Company’s stock | 24.60% |  | 36.00% |
| Expected dividend yield on the Company’s stock | 2.21% |  | 2.11% |

[0000833444-17-000044:notes:103]
[same as prior period, unchanged from 0000833444-17-000016:notes:108]

[0000833444-17-000044:notes:104]
[same as prior period, unchanged from 0000833444-17-000016:notes:109]

[0000833444-17-000044:notes:105]
[same as prior period, unchanged from 0000833444-17-000016:notes:110]

[0000833444-17-000044:notes:106]
[same as prior period, unchanged from 0000833444-17-000016:notes:111]

[0000833444-17-000044:notes:107]
[same as prior period, unchanged from 0000833444-17-000016:notes:112]

[0000833444-17-000044:notes:108]
[same as prior period, unchanged from 0000833444-17-000016:notes:113]

[0000833444-17-000044:notes:109]
[same as prior period, unchanged from 0000833444-17-000016:notes:114]

[0000833444-17-000044:notes:110]
|  | Nine Months EndedJune 30, 2017 |
| Risk-free interest rate | 1.40% |
| Expected volatility of the Company’s stock | 21.00% |

[0000833444-17-000044:notes:111]
[same as prior period, unchanged from 0000833444-17-000016:notes:116]

[0000833444-17-000044:notes:112]
[same as prior period, unchanged from 0000833444-17-000016:notes:117]

[0000833444-17-000044:notes:113]
[same as prior period, unchanged from 0000833444-17-000016:notes:118]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-17-000044:notes:114]
[same as prior period, unchanged from 0000833444-17-000016:notes:119]

[0000833444-17-000044:notes:115]
[same as prior period, unchanged from 0000833444-17-000016:notes:120]

[0000833444-17-000044:notes:116]
For the nine months ended June 30, 2017, the income from discontinued operations before income taxes included separation costs of $79 million. For the three and nine months ended June 30, 2016, the income from discontinued operations before income taxes included separation costs of $127 million and $287 million, respectively.

[0000833444-17-000044:notes:117]
For the nine months ended June 30, 2017, the effective tax rate was more than the U.S. federal statutory rate of 35% primarily due to the tax impacts of separation costs and Adient spin-off related tax expense, partially offset by non-U.S. tax rate differentials. For the three months ended June 30, 2016, the effective tax rate was more than the U.S. federal statutory rate of 35% primarily due to $85 million of income tax expense for changes in entity status, the jurisdictional mix of restructuring and impairment costs, and the tax impacts of separation costs, partially offset by non-U.S. tax rate differentials. For the nine months ended June 30, 2016, the effective tax rate was more than the U.S. federal statutory rate of 35% primarily due to $780 million of income tax expense recorded on foreign undistributed earnings of certain non-U.S. subsidiaries, $85 million of income tax expense for changes in entity status, the jurisdictional mix of restructuring and impairment costs, and the tax impacts of separation costs, partially offset by non-U.S. tax rate differentials.

[0000833444-17-000044:notes:118]
[same as prior period, unchanged from 0000833444-17-000016:notes:123]

[0000833444-17-000044:notes:119]
The following table summarizes the carrying value of Adient, reclassified as assets and liabilities held for sale at September 30, 2016 (in millions):

[0000833444-17-000044:notes:120]
|  |  | September 30, 2016 |
| Cash |  | $ | 105 |  |
| Cash in escrow related to Adient debt |  | 2,034 |  |
| Accounts receivable - net |  | 2,071 |  |
| Inventories |  | 672 |  |
| Other current assets |  | 756 |  |
| Assets held for sale |  | $ | 5,638 |  |
| Property, plant and equipment - net |  | $ | 2,240 |  |
| Goodwill |  | 2,385 |  |
| Other intangible assets - net |  | 113 |  |
| Investments in partially-owned affiliates |  | 1,745 |  |
| Other noncurrent assets |  | 891 |  |
| Noncurrent assets held for sale |  | $ | 7,374 |  |
| Short-term debt |  | $ | 41 |  |
| Current portion of long-term debt |  | 38 |  |
| Accounts payable |  | 2,764 |  |
| Accrued compensation and benefits |  | 430 |  |
| Other current liabilities |  | 975 |  |
| Liabilities held for sale |  | $ | 4,248 |  |
| Long-term debt |  | $ | 3,441 |  |
| Pension and postretirement benefits |  | 188 |  |
| Other noncurrent liabilities |  | 259 |  |
| Noncurrent liabilities held for sale |  | $ | 3,888 |  |

[0000833444-17-000044:notes:121]
The following table summarizes depreciation and amortization, capital expenditures, and significant operating and investing noncash items related to Adient for the nine month period ended June 30, 2017, and the three and nine month periods ended June 30, 2016 (in millions):

[0000833444-17-000044:notes:122]
|  | Three Months Ended June 30, |  | Nine Months EndedJune 30, |
|  | 2016 |  | 2017 |  | 2016 |
| Depreciation and amortization | $ | 86 |  |  | $ | 29 |  |  | $ | 257 |  |
| Equity in earnings of partially-owned affiliates | (89 | ) |  | (31 | ) |  | (260 | ) |
| Deferred income taxes | (9 | ) |  | 562 |  |  | 756 |  |
| Non-cash restructuring and impairment charges | 1 |  |  | — |  |  | 15 |  |
| Equity-based compensation | 4 |  |  | 1 |  |  | 11 |  |
| Accrued income taxes | — |  |  | (808 | ) |  | — |  |
| Capital expenditures | (96 | ) |  | (91 | ) |  | (271 | ) |

[0000833444-17-000044:notes:123]
[same as prior period, unchanged from 0000833444-17-000016:notes:124]

[0000833444-17-000044:notes:124]
During the second quarter of fiscal 2017, the Company signed a definitive agreement to sell its Scott Safety business of the Tyco segment to 3M Company. The transaction is expected to close in the first quarter of fiscal 2018, subject to customary closing conditions including required regulatory approval. The assets and liabilities of this business were presented as held for sale in the consolidated statements of financial position as of June 30, 2017. The business did not meet the criteria to be classified as a discontinued operation as the divestiture of the Scott Safety business will not have a major effect on the Company’s operations and financial results.

[0000833444-17-000044:notes:125]
The following table summarizes the carrying value of the Tyco segment assets and liabilities held for sale at June 30, 2017 and September 30, 2016 (in millions):

[0000833444-17-000044:notes:126]
|  | June 30, 2017 |  | September 30, 2016 |
| Accounts receivable - net | $ | 101 |  |  | $ | 9 |  |
| Inventories | 73 |  |  | 7 |  |
| Other current assets | 8 |  |  | 3 |  |
| Property, plant and equipment - net | 76 |  |  | 15 |  |
| Goodwill | 1,270 |  |  | 89 |  |
| Other intangible assets - net | 554 |  |  | 30 |  |
| Other noncurrent assets | — |  |  | 4 |  |
| Assets held for sale | $ | 2,082 |  |  | $ | 157 |  |
| Accounts payable | $ | 34 |  |  | $ | 9 |  |
| Accrued compensation and benefits | 10 |  |  | — |  |
| Other current liabilities | 22 |  |  | 19 |  |
| Other noncurrent liabilities | 181 |  |  | — |  |
| Liabilities held for sale | $ | 247 |  |  | $ | 28 |  |

[0000833444-17-000044:notes:127]
[same as prior period, unchanged from 0000833444-17-000016:notes:126]


## us-gaap:EarningsPerShareTextBlock

[0000833444-17-000044:notes:128]
[same as prior period, unchanged from 0000833444-17-000016:notes:127]

[0000833444-17-000044:notes:129]
[same as prior period, unchanged from 0000833444-17-000016:notes:128]

[0000833444-17-000044:notes:130]
[same as prior period, unchanged from 0000833444-17-000016:notes:129]

[0000833444-17-000044:notes:131]
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Income Available to Ordinary Shareholders |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 555 |  |  | $ | 347 |  |  | $ | 779 |  |  | $ | 845 |  |
| Income (loss) from discontinued operations | — |  |  | 36 |  |  | (43 | ) |  | (542 | ) |
| Basic and diluted income available to shareholders | $ | 555 |  |  | $ | 383 |  |  | $ | 736 |  |  | $ | 303 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 935.4 |  |  | 644.9 |  |  | 937.2 |  |  | 647.0 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 9.0 |  |  | 4.8 |  |  | 9.6 |  |  | 4.5 |  |
| Diluted weighted average shares outstanding | 944.4 |  |  | 649.7 |  |  | 946.8 |  |  | 651.5 |  |
| Antidilutive Securities |  |  |  |  |  |  |  |
| Options to purchase shares | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | 0.2 |  |

[0000833444-17-000044:notes:132]
During the three months ended June 30, 2017 and 2016, the Company declared a dividend of $0.25 and $0.29, respectively, per share. During the nine months ended June 30, 2017 and 2016, the Company declared dividends totaling $0.75 and $0.87, respectively, per share. The Company paid all dividends in the month subsequent to the end of each fiscal quarter.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-17-000044:notes:133]
[same as prior period, unchanged from 0000833444-17-000016:notes:133]

[0000833444-17-000044:notes:134]
[same as prior period, unchanged from 0000833444-17-000016:notes:134]

[0000833444-17-000044:notes:135]
[same as prior period, unchanged from 0000833444-17-000016:notes:135]

[0000833444-17-000044:notes:136]
[same as prior period, unchanged from 0000833444-17-000016:notes:136]

[0000833444-17-000044:notes:137]
[same as prior period, unchanged from 0000833444-17-000016:notes:137]

[0000833444-17-000044:notes:138]
[same as prior period, unchanged from 0000833444-17-000016:notes:138]

[0000833444-17-000044:notes:139]
[same as prior period, unchanged from 0000833444-17-000016:notes:139]

[0000833444-17-000044:notes:140]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value as of June 30, 2017 and September 30, 2016 (in millions):

[0000833444-17-000044:notes:141]
|  | Fair Value Measurements Using: |
|  | Total as of June 30, 2017 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 33 |  |  | $ | — |  |  | $ | 33 |  |  | $ | — |  |
| Commodity derivatives | 3 |  |  | — |  |  | 3 |  |  | — |  |
| Exchange traded funds (fixed income)1 | 14 |  |  | 14 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Investments in marketable common stock | 15 |  |  | 15 |  |  | — |  |  | — |  |
| Deferred compensation plan assets | 89 |  |  | 89 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 154 |  |  | 154 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 96 |  |  | 96 |  |  | — |  |  | — |  |
| Equity swap | 59 |  |  | 59 |  |  | — |  |  | — |  |
| Total assets | $ | 463 |  |  | $ | 427 |  |  | $ | 36 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 19 |  |  | $ | — |  |  | $ | 19 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 1,693 |  |  | 1,693 |  |  | — |  |  | — |  |
| Total liabilities | $ | 1,713 |  |  | $ | 1,693 |  |  | $ | 20 |  |  | $ | — |  |

[0000833444-17-000044:notes:142]
[same as prior period, unchanged from 0000833444-17-000016:notes:142]

[0000833444-17-000044:notes:143]
1 Classified as restricted investments for payment of asbestos liabilities. See Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements for further details.

[0000833444-17-000044:notes:144]
[same as prior period, unchanged from 0000833444-17-000016:notes:144]

[0000833444-17-000044:notes:145]
[same as prior period, unchanged from 0000833444-17-000016:notes:145]

[0000833444-17-000044:notes:146]
[same as prior period, unchanged from 0000833444-17-000016:notes:146]

[0000833444-17-000044:notes:147]
[same as prior period, unchanged from 0000833444-17-000016:notes:147]

[0000833444-17-000044:notes:148]
Equity swaps: The equity swaps are valued under a market approach as the fair value of the swaps is equal to the Company’s stock price at the reporting period date.

[0000833444-17-000044:notes:149]
[same as prior period, unchanged from 0000833444-17-000016:notes:148]

[0000833444-17-000044:notes:150]
Investments in marketable common stock and exchange traded funds:  Investments in marketable common stock and exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. There was an unrealized gain recorded on these investments of $5 million as of June 30, 2017 within AOCI in the consolidated statements of financial position. There was an unrealized loss recorded on these investments of $1 million as of September 30, 2016 within AOCI in the consolidated statements of financial position.

[0000833444-17-000044:notes:151]
Foreign currency denominated debt: The Company has entered into a foreign currency denominated debt obligation to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effect of the debt obligation are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally. The foreign denominated debt obligation is remeasured to current exchange rates under a market approach using publicized spot prices. At June 30, 2017, the Company had one billion euro and 485 million euro bonds designated as net investment hedges in the Company's net investment in Europe. At September 30, 2016, the Company had 37 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan and one billion euro and 500 million euro bonds designated as net investment hedges in the Company's net investment in Europe.

[0000833444-17-000044:notes:152]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. The fair value of long-term debt was $12.6 billion and $15.7 billion at June 30, 2017 and September 30, 2016, respectively. The fair value of public debt was $8.7 billion and $9.7 billion, at June 30, 2017 and September 30, 2016, respectively, which was determined primarily using market quotes classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was $3.9 billion and $6.0 billion at June 30, 2017 and September 30, 2016, respectively, which was determined based on quoted market prices for similar instruments classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:FiniteLivedAndIndefiniteLivedIntangibleAssetsAcquiredAsPartOfBusinessCombinationTableTextBlock

[0000833444-17-000044:notes:153]
[same as prior period, unchanged from 0000833444-17-000016:notes:152]

[0000833444-17-000044:notes:154]
|  |  | Preliminary Fair Value (in millions) |  | Weighted Average Life (in years) |
| Customer relationships |  | $ | 2,280 |  |  | 12 |
| Completed technology |  | 1,580 |  |  | 11 |
| Other definite-lived intangibles |  | 214 |  |  | 7 |
| Indefinite-lived trademarks |  | 2,080 |  |  |  |
| Other indefinite-lived intangibles |  | 90 |  |  |  |
| In-process research and development |  | 60 |  |  |  |
| Total identifiable intangible assets |  | $ | 6,304 |  |  |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-17-000044:notes:155]
[same as prior period, unchanged from 0000833444-17-000016:notes:154]

[0000833444-17-000044:notes:156]
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the nine month period ended June 30, 2017 were as follows (in millions):

[0000833444-17-000044:notes:157]
|  |  |  | Business Acquisitions |  | Business Divestitures |  | Currency Translation and Other |  |  |
|  | September 30, |  |  |  |  | June 30, |
|  | 2016 |  |  |  |  | 2017 |
| Building Technologies & Solutions |  |  |  |  |  |  |  |  |  |
| Building Efficiency |  |  |  |  |  |  |  |  |  |
| Systems and Service North America | $ | 975 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 975 |  |
| Products North America | 1,697 |  |  | 1 |  |  | — |  |  | 2 |  |  | 1,700 |  |
| Asia | 657 |  |  | — |  |  | — |  |  | (23 | ) |  | 634 |  |
| Rest of World | 301 |  |  | 1 |  |  | — |  |  | 4 |  |  | 306 |  |
| Tyco | 16,308 |  |  | (160 | ) |  | (1,270 | ) |  | 40 |  |  | 14,918 |  |
| Power Solutions | 1,086 |  |  | — |  |  | — |  |  | — |  |  | 1,086 |  |
| Total | $ | 21,024 |  |  | $ | (158 | ) |  | $ | (1,270 | ) |  | $ | 23 |  |  | $ | 19,619 |  |

[0000833444-17-000044:notes:158]
At September 30, 2016, accumulated goodwill impairment charges included $47 million related to the Building Efficiency Rest of World - Latin America reporting unit. The nine months ended June 30, 2017 Tyco business divestiture amount includes $1,270 million of goodwill transferred to assets held for sale on the consolidated statements of financial position. Refer to Note 5, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's assets and liabilities held for sale.

[0000833444-17-000044:notes:159]
Amortization of other intangible assets included within continuing operations for the three month periods ended June 30, 2017 and 2016 was $108 million and $22 million, respectively. Amortization of other intangible assets included within continuing operations for the nine month periods ended June 30, 2017 and 2016 was $383 million and $62 million, respectively. Excluding the impact of any future acquisitions, the Company anticipates amortization for fiscal 2018, 2019, 2020, 2021 and 2022 will be approximately $389 million, $379 million, $366 million, $367 million and $360 million per year, respectively.


## us-gaap:GuaranteesTextBlock

[0000833444-17-000044:notes:160]
[same as prior period, unchanged from 0000833444-17-000016:notes:159]

[0000833444-17-000044:notes:161]
[same as prior period, unchanged from 0000833444-17-000016:notes:160]

[0000833444-17-000044:notes:162]
[same as prior period, unchanged from 0000833444-17-000016:notes:161]

[0000833444-17-000044:notes:163]
[same as prior period, unchanged from 0000833444-17-000016:notes:162]

[0000833444-17-000044:notes:164]
The changes in the carrying amount of the Company’s total product warranty liability for continuing operations, including extended warranties for which deferred revenue is recorded, for the nine months ended June 30, 2017 and 2016 were as follows (in millions):

[0000833444-17-000044:notes:165]
|  | Nine Months EndedJune 30, |
|  | 2017 |  | 2016 |
| Balance at beginning of period | $ | 374 |  |  | $ | 288 |  |
| Accruals for warranties issued during the period | 221 |  |  | 230 |  |
| Accruals from acquisition and divestitures (1) | 2 |  |  | 53 |  |
| Accruals related to pre-existing warranties | (5 | ) |  | (7 | ) |
| Settlements made (in cash or in kind) during the period | (199 | ) |  | (220 | ) |
| Currency translation | (1 | ) |  | 2 |  |
| Balance at end of period | $ | 392 |  |  | $ | 346 |  |

[0000833444-17-000044:notes:166]
(1) The nine months ended June 30, 2017 includes $13 million of product warranties transferred to liabilities held for sale on the consolidated statements of financial position. Refer to Note 5, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's disposal groups classified as held for sale.

[0000833444-17-000044:notes:167]
As a result of the Tyco Merger in the fourth quarter of fiscal 2016, the Company recorded, as part of the acquired liabilities of Tyco, $290 million of post sale contingent tax indemnification liabilities within other noncurrent liabilities in the consolidated statements of financial position. The liabilities are recorded at fair value and relate to certain tax related matters borne by the buyer of previously divested subsidiaries of Tyco which Tyco has indemnified certain parties and the amounts are probable of being paid. Of the $290 million recorded as of September 30, 2016 and June 30, 2017, $255 million is related to prior divested businesses and the remainder relates to Tyco’s tax sharing agreements from its 2007 and 2012 spin-off transactions. These are certain guarantees or indemnifications extended among Tyco, Medtronic, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 separation and tax sharing agreements. In addition, the Company has recorded  $11 million of tax indemnification liabilities as of June 30, 2017 related to other divestitures.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0000833444-17-000044:notes:168]
[same as prior period, unchanged from 0000833444-17-000016:notes:167]

[0000833444-17-000044:notes:169]
[same as prior period, unchanged from 0000833444-17-000016:notes:168]

[0000833444-17-000044:notes:170]
In the first, second and third quarters of fiscal 2017, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2017. As a result, the Company reviewed the long-lived assets for impairment and recorded $69 million of asset impairment charges within restructuring and impairment costs on the consolidated statements of income, of which $15 million was recorded in the first quarter, $23 million was recorded in the second quarter and $31 million was recorded in the third quarter. Of the total impairment charges, $27 million related to the Tyco segment, $20 million related to the Building Efficiency Products North America segment, $17 million related to Corporate assets, $4 million related to the Power Solutions segment, and $1 million related to the Building Efficiency Systems and Services North America segment. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-17-000044:notes:171]
In the second and third quarters of fiscal 2016, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2016. As a result, the Company reviewed the long-lived assets for impairment and recorded $65 million of asset impairment charges within restructuring and impairment costs on the consolidated statements of income, of which $15 million was recorded in the second quarter and $50 million was recorded in the third quarter. Of the total impairment charge, $50 million related to Corporate assets, $8 million related to the Building Efficiency Products North America segment, $4 million related to the Building Efficiency Asia segment and $3 million related to the Building Efficiency Rest of World segment. In addition, the Company recorded $15 million of asset impairments within discontinued operations related to Adient in fiscal 2016. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-17-000044:notes:172]
At June 30, 2017 and 2016, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-17-000044:notes:173]
[same as prior period, unchanged from 0000833444-17-000016:notes:172]

[0000833444-17-000044:notes:174]
In calculating the provision for income taxes, the Company uses an estimate of the annual effective tax rate based upon the facts and circumstances known at each interim period. On a quarterly basis, the actual effective tax rate is adjusted, as appropriate, based upon changed facts and circumstances, if any, as compared to those forecasted at the beginning of the fiscal year and each interim period thereafter. The U.S. federal statutory tax rate is being used as a comparison since the Company was a U.S. domiciled company for 11 months of 2016 and due to the Company's current legal entity structure. For the three months ended June 30, 2017, the Company's effective tax rate for continuing operations was 12%. The effective tax rate was lower than the U.S. federal statutory rate of 35% primarily due to the benefits of continuing global tax planning initiatives and non-U.S. tax rate differentials, partially offset by the jurisdictional mix of Tyco Merger transaction and integration costs. For the nine months ended June 30, 2017, the Company's effective tax rate for continuing operations was 38%. The effective tax rate was higher than the U.S. federal statutory rate of 35% primarily due to the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries related to the pending divestiture of the Scott Safety business, the jurisdictional mix of significant restructuring and impairment costs, and Tyco Merger transaction /integration costs and purchase accounting impacts, partially offset by the benefits of continuing global tax planning initiatives, non-U.S. tax rate differentials and a tax benefit due to changes in entity tax status. For the three and nine months ended June 30, 2016, the Company's effective tax rate for continuing operations was 16% and 17%, respectively. The effective rate was lower than the U.S. federal statutory rate of 35% primarily due to the benefits of continuing global tax planning initiatives and non-U.S. tax rate differentials, partially offset by the tax impact of transaction and separation costs.

[0000833444-17-000044:notes:175]
[same as prior period, unchanged from 0000833444-17-000016:notes:175]

[0000833444-17-000044:notes:176]
[same as prior period, unchanged from 0000833444-17-000016:notes:176]

[0000833444-17-000044:notes:177]
[same as prior period, unchanged from 0000833444-17-000016:notes:177]

[0000833444-17-000044:notes:178]
At September 30, 2016, exclusive of items included in noncurrent liabilities held for sale, the Company had gross tax effected unrecognized tax benefits of $1,706 million, of which $1,604 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2016 was approximately $55 million (net of tax benefit). The interest and penalties accrued during the nine months ended June 30, 2017 and 2016 were not material. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-17-000044:notes:179]
[same as prior period, unchanged from 0000833444-17-000016:notes:179]

[0000833444-17-000044:notes:180]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2016 |
| Brazil |  | 2011 - 2012 |
| Canada |  | 2012 - 2014 |
| France |  | 2010 - 2015 |
| Germany |  | 2007 - 2015 |
| Spain |  | 2010 - 2014 |
| United Kingdom |  | 2011 - 2014 |

[0000833444-17-000044:notes:181]
It is reasonably possible that certain tax examinations and/or tax litigation will conclude within the next twelve months, which could be up to a $200 million impact to tax expense.

[0000833444-17-000044:notes:182]
[same as prior period, unchanged from 0000833444-17-000016:notes:182]

[0000833444-17-000044:notes:183]
On October 13, 2016, the U.S. Treasury and the IRS released final and temporary Section 385 regulations. These regulations address whether certain instruments between related parties are treated as debt or equity. The Company does not expect that the regulations will have a material impact on its consolidated financial statements.

[0000833444-17-000044:notes:184]
During the nine months ended June 30, 2017 and 2016, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-17-000044:notes:185]
[same as prior period, unchanged from 0000833444-17-000016:notes:185]

[0000833444-17-000044:notes:186]
In the third quarter of fiscal 2017, the Company recorded $70 million of transaction and integration costs which generated an $11 million tax benefit.

[0000833444-17-000044:notes:187]
In the third quarter of fiscal 2017, the Company recorded $49 million of significant restructuring and impairment costs. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $15 million tax benefit.

[0000833444-17-000044:notes:188]
[same as prior period, unchanged from 0000833444-17-000016:notes:186]

[0000833444-17-000044:notes:189]
[same as prior period, unchanged from 0000833444-17-000016:notes:187]

[0000833444-17-000044:notes:190]
[same as prior period, unchanged from 0000833444-17-000016:notes:188]

[0000833444-17-000044:notes:191]
[same as prior period, unchanged from 0000833444-17-000016:notes:189]

[0000833444-17-000044:notes:192]
[same as prior period, unchanged from 0000833444-17-000016:notes:190]

[0000833444-17-000044:notes:193]
[same as prior period, unchanged from 0000833444-17-000016:notes:191]

[0000833444-17-000044:notes:194]
In the third quarter of fiscal 2016, the Company recorded $27 million of significant restructuring and impairment costs.  Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $12 million tax benefit, which was impacted by the geographic mix and the Company’s current tax position in these jurisdictions.

[0000833444-17-000044:notes:195]
[same as prior period, unchanged from 0000833444-17-000016:notes:192]


## us-gaap:InventoryDisclosureTextBlock

[0000833444-17-000044:notes:196]
[same as prior period, unchanged from 0000833444-17-000016:notes:193]

[0000833444-17-000044:notes:197]
[same as prior period, unchanged from 0000833444-17-000016:notes:194]

[0000833444-17-000044:notes:198]
|  | June 30, 2017 |  | September 30, 2016 |
| Raw materials and supplies | $ | 800 |  |  | $ | 852 |  |
| Work-in-process | 683 |  |  | 503 |  |
| Finished goods | 1,901 |  |  | 1,533 |  |
| Inventories | $ | 3,384 |  |  | $ | 2,888 |  |


## us-gaap:LongTermContractsOrProgramsDisclosureTextBlock

[0000833444-17-000044:notes:199]
[same as prior period, unchanged from 0000833444-17-000016:notes:196]

[0000833444-17-000044:notes:200]
The Building Technologies & Solutions business records certain long-term contracts under the percentage-of-completion method of accounting. Under this method, sales and gross profit are recognized as work is performed based on the relationship between actual costs incurred and total estimated costs at completion. The Company records costs and earnings in excess of billings on uncompleted contracts primarily within accounts receivable - net and billings in excess of costs and earnings on uncompleted contracts primarily within other current liabilities in the consolidated statements of financial position. Costs and earnings in excess of billings related to these contracts were $951 million and $841 million at June 30, 2017 and September 30, 2016, respectively. Billings in excess of costs and earnings related to these contracts were $448 million and $431 million at June 30, 2017 and September 30, 2016, respectively.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-17-000044:notes:201]
[same as prior period, unchanged from 0000833444-17-000016:notes:198]

[0000833444-17-000044:notes:202]
[same as prior period, unchanged from 0000833444-17-000016:notes:199]

[0000833444-17-000044:notes:203]
Immediately prior to the Merger and in connection therewith, Tyco shareholders received 0.955 ordinary shares of Tyco (which shares are now referred to as shares of the Company, or “Company ordinary shares”) for each Tyco ordinary share they held by virtue of a 0.955-for-one share consolidation. In the Merger, each outstanding share of common stock, par value $1.00 per share, of JCI Inc. (“JCI Inc. common stock”) (other than shares held by JCI Inc., Tyco and certain of their subsidiaries) was converted into the right to receive either the cash consideration or the share consideration (each as described below), at the election of the holder, subject to proration procedures described in the Merger Agreement and applicable withholding taxes.  The election to receive the cash consideration was undersubscribed. As a result, holders of shares of JCI Inc. common stock that elected to receive the share consideration and holders of shares of JCI Inc. common stock that made no election (or failed to properly make an election) became entitled to receive, for each such share of JCI Inc. common stock, $5.7293 in cash, without interest, and 0.8357 Company ordinary shares, subject to applicable withholding taxes.  Holders of shares of JCI Inc. common stock that elected to receive the cash consideration became entitled to receive, for each such share of JCI Inc. common stock, $34.88 in cash, without interest, subject to applicable withholding taxes.  In the Merger, JCI Inc. shareholders received, in the aggregate, approximately $3.864 billion in cash. Immediately after the closing of, and giving effect to, the Merger, former JCI Inc. shareholders owned approximately 56% of the issued and outstanding Company ordinary shares and former Tyco stockholders owned approximately 44% of the issued and outstanding Company ordinary shares.

[0000833444-17-000044:notes:204]
[same as prior period, unchanged from 0000833444-17-000016:notes:201]

[0000833444-17-000044:notes:205]
[same as prior period, unchanged from 0000833444-17-000016:notes:202]

[0000833444-17-000044:notes:206]
[same as prior period, unchanged from 0000833444-17-000016:notes:203]

[0000833444-17-000044:notes:207]
[same as prior period, unchanged from 0000833444-17-000016:notes:204]

[0000833444-17-000044:notes:208]
[same as prior period, unchanged from 0000833444-17-000016:notes:205]

[0000833444-17-000044:notes:209]
The Company accounted for the Merger with Tyco as a business combination using the acquisition method of accounting. The assets acquired and liabilities assumed were recorded at their preliminary respective fair values as of the acquisition date.

[0000833444-17-000044:notes:210]
[same as prior period, unchanged from 0000833444-17-000016:notes:207]

[0000833444-17-000044:notes:211]
[same as prior period, unchanged from 0000833444-17-000016:notes:208]

[0000833444-17-000044:notes:212]
| Cash and cash equivalents |  | $ | 489 |  |
| Accounts receivable |  | 2,084 |  |
| Inventories |  | 815 |  |
| Other current assets |  | 610 |  |
| Property, plant, and equipment - net |  | 1,219 |  |
| Goodwill |  | 16,203 |  |
| Intangible assets - net |  | 6,304 |  |
| Other noncurrent assets |  | 536 |  |
| Total assets acquired |  | $ | 28,260 |  |
| Short-term debt |  | $ | 462 |  |
| Accounts payable |  | 725 |  |
| Accrued compensation and benefits |  | 312 |  |
| Other current liabilities |  | 1,444 |  |
| Long-term debt |  | 6,416 |  |
| Long-term deferred tax liabilities |  | 847 |  |
| Long-term pension and postretirement benefits |  | 774 |  |
| Other noncurrent liabilities |  | 1,436 |  |
| Total liabilities acquired |  | $ | 12,416 |  |
| Noncontrolling interests |  | 37 |  |
| Net assets acquired |  | $ | 15,807 |  |
| Cash consideration paid to JCI Inc. shareholders |  | 3,864 |  |
| Total fair value of consideration transferred |  | $ | 19,671 |  |

[0000833444-17-000044:notes:213]
In connection with the Merger, the Company recorded goodwill of $16.2 billion, which is attributable primarily to expected synergies, expanded market opportunities, and other benefits that the Company believes will result from combining its operations with the operations of Tyco. The goodwill created in the Merger is not deductible for tax purposes and is subject to potential significant changes as the purchase price allocation is completed. Goodwill has preliminarily been allocated to the Tyco segment based on how the business was reviewed by the Company's Chief Operating Decision Maker as shown in Note 8, "Goodwill and Other Intangible Assets." In connection with the Tyco Merger, the Company recorded a reduction in goodwill of $160 million in the first nine months of fiscal 2017 related to purchase price allocations.

[0000833444-17-000044:notes:214]
[same as prior period, unchanged from 0000833444-17-000016:notes:211]

[0000833444-17-000044:notes:215]
In the first nine months of fiscal 2017, the Company completed three acquisitions for a combined purchase price, net of cash acquired, of $9 million, $6 million of which was paid in the nine months ended June 30, 2017. The acquisitions in the aggregate were not material to the Company’s consolidated financial statements. In connection with the acquisitions, the Company recorded goodwill of $2 million.

[0000833444-17-000044:notes:216]
In the second quarter of fiscal 2017, the Company announced it signed a definitive agreement to sell its Scott Safety business to 3M Company for approximately $2.0 billion. Net cash proceeds from the transaction are expected to approximate $1.8 to $1.9 billion. Scott Safety is a leader in the design, manufacture and sale of high performance respiratory protection, gas and flame detection, thermal imaging and other critical products for fire services, law enforcement, industrial, oil and gas, chemical, armed forces, and homeland defense end markets. The transaction is expected to close in the first quarter of fiscal 2018, subject to customary closing conditions including required regulatory approval. The Scott Safety business is included in the Tyco segment and is reported within assets and liabilities held for sale in the consolidated statements of financial position as of June 30, 2017. Refer to Note 5, "Discontinued Operations," of the notes to consolidated financial statements for further disclosure related to the Company's net assets held for sale.

[0000833444-17-000044:notes:217]
In the second quarter of fiscal 2017, the Company completed the sale of its ADT security business in South Africa within the Tyco segment. The selling price, net of cash divested, was $129 million, all of which was received in the nine months ended June 30, 2017. In connection with the sale, the Company reduced goodwill in assets held for sale by $92 million. The divestiture was not material to the Company's consolidated financial statements.

[0000833444-17-000044:notes:218]
In the first nine months of fiscal 2017, the Company completed one additional divestiture for a sales price of $4 million, all of which was received in the nine months ended June 30, 2017. The divestiture decreased the Company's ownership from a controlling to noncontrolling interest, and as a result, the Company deconsolidated cash of $5 million. The divestiture was not material to the Company's consolidated financial statements.

[0000833444-17-000044:notes:219]
In the first nine months of fiscal 2017, the Company received $52 million in net cash proceeds related to prior year business divestitures.

[0000833444-17-000044:notes:220]
In the first quarter of fiscal 2016, the Company formed a joint venture with Hitachi to expand its Building Efficiency product offerings. The Company acquired a 60% ownership interest in the new entity for approximately $208 million ($638 million purchase price less cash acquired of $430 million), $133 million of which was paid in the nine months ended June 30, 2016 and $75 million was paid in the nine months ended June 30, 2017. In connection with the acquisition, the Company recorded goodwill of $253 million related to purchase price allocations.

[0000833444-17-000044:notes:221]
In the first nine months of fiscal 2016, the Company completed one additional acquisition for a purchase price, net of cash acquired, of $3 million, none of which was paid as of June 30, 2016. The acquisition was not material to the Company's consolidated financial statements. In connection with the acquisition, the Company recorded goodwill of $4 million. The acquisition increased the Company's ownership from a noncontrolling to controlling interest. As a result, the Company recorded a non-cash gain of $4 million in equity income for the Building Efficiency Rest of World segment to adjust the Company's existing equity investment in the partially-owned affiliate to fair value.

[0000833444-17-000044:notes:222]
In the three months ended June 30, 2016, the Company completed a divestiture for a sales price of $16 million, $14 million of which was received as of June 30, 2016. The divestiture was not material to the Company's consolidated financial statements. In connection with the divestiture, the Company recorded a gain of $14 million within selling, general and administrative expenses on the consolidated statements of income and reduced goodwill by $3 million in the Building Efficiency Systems and Service North America segment.

[0000833444-17-000044:notes:223]
In the first nine months of fiscal 2016, the Company received $40 million in cash proceeds related to prior year business divestitures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-17-000044:notes:224]
[same as prior period, unchanged from 0000833444-17-000016:notes:219]

[0000833444-17-000044:notes:225]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (SEC). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2016 filed with the SEC on November 23, 2016, portions of which (including Part I, Item 1. Business and Item 3. Legal Proceedings, and the following items from Part II of the Annual Report: Item 6. Selected Financial Data, Item 7. Management’s Discussion and Analysis, and Item 8. Financial Statements and Supplementary Data) were recast in the Company's Current Report on Form 8-K filed with the SEC on February 23, 2017. The results of operations for the three and nine month periods ended June 30, 2017 are not necessarily indicative of results for the Company’s 2017 fiscal year because of seasonal and other factors.

[0000833444-17-000044:notes:226]
[same as prior period, unchanged from 0000833444-17-000016:notes:221]

[0000833444-17-000044:notes:227]
On September 2, 2016, Johnson Controls, Inc. ("JCI Inc.") and Tyco International plc (“Tyco”) completed their combination pursuant to the Agreement and Plan of Merger (the “Merger Agreement”), dated as of January 24, 2016, as amended by Amendment No. 1, dated as of July 1, 2016, by and among JCI Inc., Tyco and certain other parties named therein, including Jagara Merger Sub LLC, an indirect wholly owned subsidiary of Tyco (“Merger Sub”). Pursuant to the terms of the Merger Agreement, on September 2, 2016, Merger Sub merged with and into JCI Inc., with JCI Inc. being the surviving corporation in the Merger and a wholly owned, indirect subsidiary of Tyco (the “Merger”). Following the Merger, Tyco changed its name to “Johnson Controls International plc.” The Merger changed the jurisdiction of organization from the United States to Ireland. The domicile to Ireland became effective on September 2, 2016.

[0000833444-17-000044:notes:228]
The Merger was accounted for as a reverse acquisition using the acquisition method of accounting in accordance with Accounting Standards Codification ("ASC") 805, "Business Combinations." JCI Inc. was the accounting acquirer for financial reporting purposes. Accordingly, the historical consolidated financial statements of JCI Inc. for periods prior to this transaction are considered to be the historic financial statements of the Company. Refer to Note 3, "Merger Transaction," of the notes to consolidated financial statements for further information.

[0000833444-17-000044:notes:229]
[same as prior period, unchanged from 0000833444-17-000016:notes:224]

[0000833444-17-000044:notes:230]
[same as prior period, unchanged from 0000833444-17-000016:notes:225]

[0000833444-17-000044:notes:231]
[same as prior period, unchanged from 0000833444-17-000016:notes:226]

[0000833444-17-000044:notes:232]
[same as prior period, unchanged from 0000833444-17-000016:notes:227]

[0000833444-17-000044:notes:233]
[same as prior period, unchanged from 0000833444-17-000016:notes:228]

[0000833444-17-000044:notes:234]
Based upon the criteria set forth in ASC 810, the Company has determined that it was the primary beneficiary in one VIE for the reporting period ended June 30, 2017 and three VIEs for the reporting period ended  September 30, 2016, as the Company absorbs significant economics of the entities and has the power to direct the activities that are considered most significant to the entities.

[0000833444-17-000044:notes:235]
[same as prior period, unchanged from 0000833444-17-000016:notes:230]

[0000833444-17-000044:notes:236]
In fiscal 2012, a pre-existing VIE accounted for under the equity method was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The Company acquired additional interests in two of the reorganized group entities. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is considered the primary beneficiary of one of the entities due to the Company’s power pertaining to decisions over significant activities of the entity. As such, this VIE has been consolidated within the Company’s consolidated statements of financial position. The impact of consolidation of the entity on the Company’s consolidated statements of income for the three and nine month periods ended June 30, 2017 and 2016 was not material. The VIE is named as a co-obligor under a third party debt agreement in the amount of $166 million, maturing in fiscal 2020, under which it could become subject to paying more than its allocated share of the third party debt in the event of bankruptcy of one or more of the other co-obligors. The other co-obligors, all related parties in which the Company is an equity investor, consist of the remaining group entities involved in the reorganization. As part of the overall reorganization transaction, the Company has also provided financial support to the group entities in the form of loans totaling $37 million, which are subordinate to the third party debt agreement. The Company is a significant customer of certain co-obligors, resulting in a remote possibility of loss. Additionally, the Company is subject to a floor guaranty expiring in fiscal 2022; in the event that the other owner party no longer owns any part of the group entities due to sale or transfer, the Company has guaranteed that the proceeds received from the sale or transfer will not be less than $25 million. The Company has partnered with the group entities to design and manufacture battery components for the Power Solutions business.

[0000833444-17-000044:notes:237]
[same as prior period, unchanged from 0000833444-17-000016:notes:232]

[0000833444-17-000044:notes:238]
|  | June 30,2017 |  | September 30, 2016 |
| Current assets | $ | 2 |  |  | $ | 284 |  |
| Noncurrent assets | 53 |  |  | 98 |  |
| Total assets | $ | 55 |  |  | $ | 382 |  |
| Current liabilities | $ | 4 |  |  | $ | 230 |  |
| Noncurrent liabilities | 43 |  |  | 29 |  |
| Total liabilities | $ | 47 |  |  | $ | 259 |  |

[0000833444-17-000044:notes:239]
[same as prior period, unchanged from 0000833444-17-000016:notes:234]

[0000833444-17-000044:notes:240]
[same as prior period, unchanged from 0000833444-17-000016:notes:235]

[0000833444-17-000044:notes:241]
As mentioned previously within the "Consolidated VIEs" section above, in fisca1 2012, a pre-existing VIE was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is not considered to be the primary beneficiary of two of the entities as the Company cannot make key operating decisions considered to be most significant to the VIEs. Therefore, the entities are accounted for under the equity method of accounting as the Company’s interest exceeds 20% and the Company does not have a controlling interest. The Company’s maximum exposure to loss includes the partially-owned affiliate investment balances of $63 million  and $59 million at June 30, 2017 and September 30, 2016 respectively, as well as the subordinated loan from the Company, third party debt agreement and floor guaranty mentioned previously within the "Consolidated VIEs" section above. Current liabilities due to the VIEs are not material and represent normal course of business trade payables for all presented periods.

[0000833444-17-000044:notes:242]
[same as prior period, unchanged from 0000833444-17-000016:notes:237]

[0000833444-17-000044:notes:243]
[same as prior period, unchanged from 0000833444-17-000016:notes:238]

[0000833444-17-000044:notes:244]
At June 30, 2017, the Company held restricted cash of approximately $37 million, of which $28 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash restricted for payment of asbestos liabilities. At September 30, 2016, the Company held restricted cash of approximately $88 million, of which $79 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash held in escrow from business divestitures and cash restricted for payment of asbestos liabilities.

[0000833444-17-000044:notes:245]
[same as prior period, unchanged from 0000833444-17-000016:notes:240]

[0000833444-17-000044:notes:246]
[same as prior period, unchanged from 0000833444-17-000016:notes:241]

[0000833444-17-000044:notes:247]
[same as prior period, unchanged from 0000833444-17-000016:notes:242]

[0000833444-17-000044:notes:248]
[same as prior period, unchanged from 0000833444-17-000016:notes:243]

[0000833444-17-000044:notes:249]
In April 2015, the FASB issued Accounting Standards Update (ASU) No. 2015-03, "Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs." ASU No. 2015-03 requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the debt liability.

[0000833444-17-000044:notes:250]
During the quarter ended December 31, 2016, the Company adopted ASU No. 2015-03 and applied the change retrospectively to all periods presented. This change did not have an impact to any period presented on the consolidated statements of income. The financial statement impact of this change for the period ending September 30, 2016 was a decrease to noncurrent assets held for sale of $44 million, a decrease to noncurrent liabilities held for sale of $44 million, a decrease to other noncurrent assets of $30 million and a decrease to long-term debt of $30 million.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-17-000044:notes:251]
[same as prior period, unchanged from 0000833444-17-000016:notes:246]

[0000833444-17-000044:notes:252]
[same as prior period, unchanged from 0000833444-17-000016:notes:247]

[0000833444-17-000044:notes:253]
|  | U.S. Pension Plans |
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Service cost | $ | 4 |  |  | $ | 4 |  |  | $ | 13 |  |  | $ | 12 |  |
| Interest cost | 28 |  |  | 26 |  |  | 85 |  |  | 76 |  |
| Expected return on plan assets | (57 | ) |  | (47 | ) |  | (174 | ) |  | (139 | ) |
| Net actuarial (gain) loss | 45 |  |  | — |  |  | (90 | ) |  | — |  |
| Settlement (gain) loss | 1 |  |  | — |  |  | (8 | ) |  | — |  |
| Net periodic benefit cost (credit) | $ | 21 |  |  | $ | (17 | ) |  | $ | (174 | ) |  | $ | (51 | ) |

[0000833444-17-000044:notes:254]
|  | Non-U.S. Pension Plans |
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Service cost | $ | 8 |  |  | $ | 4 |  |  | $ | 24 |  |  | $ | 9 |  |
| Interest cost | 13 |  |  | 7 |  |  | 36 |  |  | 19 |  |
| Expected return on plan assets | (23 | ) |  | (7 | ) |  | (68 | ) |  | (22 | ) |
| Net periodic benefit cost (credit) | $ | (2 | ) |  | $ | 4 |  |  | $ | (8 | ) |  | $ | 6 |  |

[0000833444-17-000044:notes:255]
|  | Postretirement Benefits |
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Service cost | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 1 |  |
| Interest cost | 1 |  |  | 2 |  |  | 4 |  |  | 5 |  |
| Expected return on plan assets | (2 | ) |  | (3 | ) |  | (7 | ) |  | (7 | ) |
| Amortization of prior service credit | — |  |  | — |  |  | — |  |  | (1 | ) |
| Net periodic benefit credit | $ | (1 | ) |  | $ | — |  |  | $ | (2 | ) |  | $ | (2 | ) |

[0000833444-17-000044:notes:256]
During the three and nine months ended June 30, 2017, the amount of lump sum payouts triggered a remeasurement event for certain U.S. pension plans resulting in the recognition of net actuarial (gains) losses of $45 million and $(90) million, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-17-000044:notes:257]
Related Party Transactions

[0000833444-17-000044:notes:258]
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-17-000044:notes:259]
The net sales to and purchases from related parties for continuing operations included in the consolidated statements of income were $272 million and $64 million, respectively, for the three months ended June 30, 2017; and $277 million and $48 million, respectively, for the three months ended June 30, 2016. The net sales to and purchases from related parties for continuing operations included in the consolidated statements of income were $726 million and $165 million, respectively, for the nine months ended June 30, 2017; and $747 million and $131 million, respectively, for the nine months ended June 30, 2016.

[0000833444-17-000044:notes:260]
The following table sets forth the amount of accounts receivable due from and payable to related parties for continuing operations in the consolidated statements of financial position (in millions):

[0000833444-17-000044:notes:261]
|  |  | June 30, 2017 |  | September 30, 2016 |  |
| Receivable from related parties |  | $ | 99 |  |  | $ | 66 |  |
| Payable to related parties |  | 22 |  |  | 11 |  |

[0000833444-17-000044:notes:262]
The Company has also provided financial support to certain of its VIE's; see Note 1, "Financial Statements," of the notes to consolidated financial statements for additional information.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-17-000044:notes:263]
[same as prior period, unchanged from 0000833444-17-000016:notes:258]

[0000833444-17-000044:notes:264]
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company commits to restructuring plans as necessary.

[0000833444-17-000044:notes:265]
In fiscal 2017, the Company committed to a significant restructuring plan (2017 Plan) and recorded $226 million of restructuring and impairment costs in the consolidated statements of income, of which $78 million was recorded in the first quarter, $99 million was recorded in the second quarter and $49 million was recorded in the third quarter of fiscal 2017. This is the total amount incurred to date for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. Of the restructuring and impairment costs recorded, $79 million related to Corporate, $73 million related to the Tyco segment, $27 million related to the Building Efficiency Products North America segment, $20 million related to the Building Efficiency Rest of World segment, $14 million related to the Building Efficiency Systems and Service North America segment, $9 million related to the Building Efficiency Asia segment and $4 million related to the Power Solutions segment. The restructuring actions are expected to be substantially complete in fiscal 2018.

[0000833444-17-000044:notes:266]
[same as prior period, unchanged from 0000833444-17-000016:notes:261]

[0000833444-17-000044:notes:267]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | Total |
| Original reserve | $ | 62 |  |  | $ | 15 |  |  | $ | 1 |  |  | $ | 78 |  |
| Utilized—noncash | — |  |  | (15 | ) |  | (1 | ) |  | (16 | ) |
| Balance at December 31, 2016 | $ | 62 |  |  | $ | — |  |  | $ | — |  |  | $ | 62 |  |
| Additional restructuring costs | 67 |  |  | 23 |  |  | 9 |  |  | 99 |  |
| Utilized—cash | (13 | ) |  | — |  |  | — |  |  | (13 | ) |
| Utilized—noncash | — |  |  | (23 | ) |  | — |  |  | (23 | ) |
| Balance at March 31, 2017 | $ | 116 |  |  | $ | — |  |  | $ | 9 |  |  | $ | 125 |  |
| Additional restructuring costs | 16 |  |  | 31 |  |  | 2 |  |  | 49 |  |
| Utilized—cash | (34 | ) |  | — |  |  | — |  |  | (34 | ) |
| Utilized—noncash | — |  |  | (31 | ) |  | (1 | ) |  | (32 | ) |
| Balance at June 30, 2017 | $ | 98 |  |  | $ | — |  |  | $ | 10 |  |  | $ | 108 |  |

[0000833444-17-000044:notes:268]
In fiscal 2016, the Company committed to a significant restructuring plan (2016 Plan) and recorded $288 million of restructuring and impairment costs in the consolidated statements of income. This was the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments and change-in-control payments. Of the restructuring and impairment costs recorded, $161 million related to Corporate, $66 million related to the Power Solutions segment, $26 million related to the Building Efficiency Asia segment, $16 million related to the Building Efficiency Rest of World segment, $9 million related to the Building Efficiency Products North America segment, $8 million related to the Tyco segment, and $2 million related to the Building Efficiency Systems and Service North America segment. The restructuring actions are expected to be substantially complete in fiscal 2018. Included in the 2016 Plan is $74 million of committed restructuring actions taken by Tyco for liabilities assumed as part of the Tyco acquisition.

[0000833444-17-000044:notes:269]
[same as prior period, unchanged from 0000833444-17-000016:notes:264]

[0000833444-17-000044:notes:270]
[same as prior period, unchanged from 0000833444-17-000016:notes:265]

[0000833444-17-000044:notes:271]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original reserve | $ | 368 |  |  | $ | 190 |  |  | $ | 62 |  |  | $ | — |  |  | $ | 620 |  |
| Acquired Tyco restructuring reserves | 78 |  |  | — |  |  | — |  |  | — |  |  | 78 |  |
| Utilized—cash | (32 | ) |  | — |  |  | — |  |  | — |  |  | (32 | ) |
| Utilized—noncash | — |  |  | (190 | ) |  | (32 | ) |  | 1 |  |  | (221 | ) |
| Balance at September 30, 2016 | $ | 414 |  |  | $ | — |  |  | $ | 30 |  |  | $ | 1 |  |  | $ | 445 |  |
| Adient spin-off impact | (194 | ) |  | — |  |  | (22 | ) |  | — |  |  | (216 | ) |
| Utilized—cash | (56 | ) |  | — |  |  | (2 | ) |  | — |  |  | (58 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Transfer to liabilities held for sale | (3 | ) |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Adjustment to acquired Tyco restructuring reserves | (4 | ) |  | — |  |  | — |  |  | — |  |  | (4 | ) |
| Balance at June 30, 2017 | $ | 157 |  |  | $ | — |  |  | $ | 6 |  |  | $ | — |  |  | $ | 163 |  |

[0000833444-17-000044:notes:272]
The Company's fiscal 2017 and 2016 restructuring plans included workforce reductions of approximately 5,400 employees (4,300 for the Building Technologies & Solutions business and 1,100 for Corporate). Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of June 30, 2017, approximately 1,400 of the employees have been separated from the Company pursuant to the restructuring plans. In addition, the restructuring plans included twelve plant closures in the Building Technologies & Solutions business. As of June 30, 2017, four of the twelve plants have been closed.

[0000833444-17-000044:notes:273]
[same as prior period, unchanged from 0000833444-17-000016:notes:268]


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000833444-17-000044:notes:274]
[same as prior period, unchanged from 0000833444-17-000016:notes:269]

[0000833444-17-000044:notes:275]
|  | Three Months Ended June 30, |
|  | 2017 |  | 2016 |
| Foreign currency translation adjustments |  |  |  |
| Balance at beginning of period | $ | (1,007 | ) |  | $ | (1,032 | ) |
| Aggregate adjustment for the period (net of tax effect of $(5) and $(5)) | 268 |  |  | (141 | ) |
| Balance at end of period | (739 | ) |  | (1,173 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | 14 |  |  | (4 | ) |
| Current period changes in fair value (net of tax effect of $(1) and $(1)) | (1 | ) |  | (3 | ) |
| Reclassification to income (net of tax effect of $(5) and $1) * | (6 | ) |  | 9 |  |
| Balance at end of period | 7 |  |  | 2 |  |
| Realized and unrealized gains (losses) on marketable securities |  |  |  |
| Balance at beginning of period | 8 |  |  | — |  |
| Current period changes in fair value (net of tax effect of $1) | (3 | ) |  | — |  |
| Balance at end of period | 5 |  |  | — |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (2 | ) |  | (3 | ) |
| Reclassification to income (net of tax effect of $0) ** | — |  |  | — |  |
| Balance at end of period | (2 | ) |  | (3 | ) |
| Accumulated other comprehensive loss, end of period | $ | (729 | ) |  | $ | (1,174 | ) |

[0000833444-17-000044:notes:276]
|  | Nine Months EndedJune 30, |
|  | 2017 |  | 2016 |
| Foreign currency translation adjustments |  |  |  |
| Balance at beginning of period | $ | (1,152 | ) |  | $ | (1,047 | ) |
| Aggregate adjustment for the period (net of tax effect of $0 and $(4)) | (150 | ) |  | (126 | ) |
| Adient spin-off impact (net of tax effect of $0) | 563 |  |  | — |  |
| Balance at end of period | (739 | ) |  | (1,173 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | 4 |  |  | (7 | ) |
| Current period changes in fair value (net of tax effect of $3 and $(2)) | 6 |  |  | (9 | ) |
| Reclassification to income (net of tax effect of $(12) and $5) * | (19 | ) |  | 18 |  |
| Adient spin-off impact (net of tax effect of $6 and $0) | 16 |  |  | — |  |
| Balance at end of period | 7 |  |  | 2 |  |
| Realized and unrealized gains (losses) on marketable securities |  |  |  |
| Balance at beginning of period | (1 | ) |  | — |  |
| Current period changes in fair value (net of tax effect of $1) | 6 |  |  | — |  |
| Balance at end of period | 5 |  |  | — |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (4 | ) |  | (3 | ) |
| Reclassification to income (net of tax effect of $0) ** | — |  |  | (1 | ) |
| Adient spin-off impact (net of tax effect of $0) | 2 |  |  | — |  |
| Other changes (net of tax effect of $0) | — |  |  | 1 |  |
| Balance at end of period | (2 | ) |  | (3 | ) |
| Accumulated other comprehensive loss, end of period | $ | (729 | ) |  | $ | (1,174 | ) |

[0000833444-17-000044:notes:277]
[same as prior period, unchanged from 0000833444-17-000016:notes:272]

[0000833444-17-000044:notes:278]
**  Refer to Note 11, "Pension and Postretirement Plans," of the notes to consolidated financial statements for disclosure of the components of the Company's net periodic benefit costs associated with its defined benefit pension and postretirement plans. For the three and nine months ended June 30, 2016, the amounts reclassified from AOCI into income for pension and postretirement plans were primarily recorded in selling, general and administrative expenses on the consolidated statements of income.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000833444-17-000044:notes:279]
[same as prior period, unchanged from 0000833444-17-000016:notes:274]

[0000833444-17-000044:notes:280]
|  | Net Sales |
|  | Three Months EndedJune 30, |  | Nine Months Ended June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Building Technologies & Solutions |  |  |  |  |  |  |  |
| Building Efficiency |  |  |  |  |  |  |  |
| Systems and Service North America | $ | 1,128 |  |  | $ | 1,113 |  |  | $ | 3,103 |  |  | $ | 3,131 |  |
| Products North America | 698 |  |  | 690 |  |  | 1,826 |  |  | 1,793 |  |
| Asia | 1,456 |  |  | 1,361 |  |  | 3,671 |  |  | 3,515 |  |
| Rest of World | 456 |  |  | 471 |  |  | 1,278 |  |  | 1,302 |  |
|  | 3,738 |  |  | 3,635 |  |  | 9,878 |  |  | 9,741 |  |
| Tyco | 2,336 |  |  | — |  |  | 6,953 |  |  | — |  |
|  | 6,074 |  |  | 3,635 |  |  | 16,831 |  |  | 9,741 |  |
| Power Solutions | 1,609 |  |  | 1,519 |  |  | 5,205 |  |  | 4,842 |  |
| Total net sales | $ | 7,683 |  |  | $ | 5,154 |  |  | $ | 22,036 |  |  | $ | 14,583 |  |

[0000833444-17-000044:notes:281]
|  | Segment EBITA |
|  | Three Months EndedJune 30, |  | Nine Months Ended June 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Building Technologies & Solutions |  |  |  |  |  |  |  |
| Building Efficiency |  |  |  |  |  |  |  |
| Systems and Service North America | $ | 126 |  |  | $ | 142 |  |  | $ | 291 |  |  | $ | 342 |  |
| Products North America | 98 |  |  | 96 |  |  | 192 |  |  | 176 |  |
| Asia | 246 |  |  | 180 |  |  | 483 |  |  | 368 |  |
| Rest of World | 26 |  |  | 22 |  |  | 25 |  |  | 29 |  |
|  | 496 |  |  | 440 |  |  | 991 |  |  | 915 |  |
| Tyco | 416 |  |  | — |  |  | 1,009 |  |  | — |  |
|  | 912 |  |  | 440 |  |  | 2,000 |  |  | 915 |  |
| Power Solutions | 304 |  |  | 280 |  |  | 996 |  |  | 922 |  |
| Segment EBITA | $ | 1,216 |  |  | $ | 720 |  |  | $ | 2,996 |  |  | $ | 1,837 |  |
| Corporate expenses | (172 | ) |  | (126 | ) |  | (605 | ) |  | (323 | ) |
| Amortization of intangible assets | (108 | ) |  | (22 | ) |  | (383 | ) |  | (62 | ) |
| Restructuring and impairment costs | (49 | ) |  | (27 | ) |  | (226 | ) |  | (87 | ) |
| Net mark-to-market adjustments on pension plans | (45 | ) |  | — |  |  | 90 |  |  | — |  |
| Net financing charges | (124 | ) |  | (65 | ) |  | (376 | ) |  | (202 | ) |
| Income from continuing operations before income taxes | $ | 718 |  |  | $ | 480 |  |  | $ | 1,496 |  |  | $ | 1,163 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-17-000044:notes:282]
[same as prior period, unchanged from 0000833444-17-000016:notes:277]

[0000833444-17-000044:notes:283]
[same as prior period, unchanged from 0000833444-17-000016:notes:278]

[0000833444-17-000044:notes:284]
[same as prior period, unchanged from 0000833444-17-000016:notes:279]

[0000833444-17-000044:notes:285]
[same as prior period, unchanged from 0000833444-17-000016:notes:280]

[0000833444-17-000044:notes:286]
[same as prior period, unchanged from 0000833444-17-000016:notes:281]

[0000833444-17-000044:notes:287]
[same as prior period, unchanged from 0000833444-17-000016:notes:282]

[0000833444-17-000044:notes:288]
[same as prior period, unchanged from 0000833444-17-000016:notes:283]

[0000833444-17-000044:notes:289]
[same as prior period, unchanged from 0000833444-17-000016:notes:284]

[0000833444-17-000044:notes:290]
[same as prior period, unchanged from 0000833444-17-000016:notes:285]

[0000833444-17-000044:notes:291]
[same as prior period, unchanged from 0000833444-17-000016:notes:286]

[0000833444-17-000044:notes:292]
[same as prior period, unchanged from 0000833444-17-000016:notes:287]

[0000833444-17-000044:notes:293]
[same as prior period, unchanged from 0000833444-17-000016:notes:288]

[0000833444-17-000044:notes:294]
[same as prior period, unchanged from 0000833444-17-000016:notes:289]

[0000833444-17-000044:notes:295]
[same as prior period, unchanged from 0000833444-17-000016:notes:290]

[0000833444-17-000044:notes:296]
[same as prior period, unchanged from 0000833444-17-000016:notes:291]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-17-000044:notes:297]
[same as prior period, unchanged from 0000833444-17-000016:notes:292]

[0000833444-17-000044:notes:298]
[same as prior period, unchanged from 0000833444-17-000016:notes:293]

[0000833444-17-000044:notes:299]
[same as prior period, unchanged from 0000833444-17-000016:notes:294]

[0000833444-17-000044:notes:300]
[same as prior period, unchanged from 0000833444-17-000016:notes:295]

[0000833444-17-000044:notes:301]
Following the Tyco Merger, the Company adopted, subject to the ongoing existence of sufficient distributable reserves, the existing Tyco International plc $1 billion share repurchase program in September 2016. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. For the three month period ended June 30, 2017 and 2016, the Company repurchased $307 million and $475 million of its shares, respectively. For the nine month periods ended June 30, 2017 and 2016, the Company repurchased $426 million and $475 million of its shares, respectively.

[0000833444-17-000044:notes:302]
[same as prior period, unchanged from 0000833444-17-000016:notes:297]

[0000833444-17-000044:notes:303]
[same as prior period, unchanged from 0000833444-17-000016:notes:298]

[0000833444-17-000044:notes:304]
[same as prior period, unchanged from 0000833444-17-000016:notes:299]

[0000833444-17-000044:notes:305]
|  | Three Months EndedJune 30, |
|  | 2017 |  | 2016 |
| Beginning balance, March 31 | $ | 168 |  |  | $ | 237 |  |
| Net income | 8 |  |  | 17 |  |
| Foreign currency translation adjustments | 14 |  |  | (3 | ) |
| Realized and unrealized losses on derivatives | (1 | ) |  | — |  |
| Ending balance, June 30 | $ | 189 |  |  | $ | 251 |  |

[0000833444-17-000044:notes:306]
|  | Nine Months EndedJune 30, |
|  | 2017 |  | 2016 |
| Beginning balance, September 30 | $ | 234 |  |  | $ | 212 |  |
| Net income | 29 |  |  | 48 |  |
| Foreign currency translation adjustments | 6 |  |  | (1 | ) |
| Realized and unrealized losses on derivatives | (1 | ) |  | (2 | ) |
| Dividends | (43 | ) |  | (6 | ) |
| Spin-off of Adient | (36 | ) |  | — |  |
| Ending balance, June 30 | $ | 189 |  |  | $ | 251 |  |
