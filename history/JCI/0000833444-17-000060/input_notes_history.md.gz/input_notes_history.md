# JCI note change history — 0000833444-17-000016 → 0000833444-17-000044


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-08-03):
[0000833444-17-000044:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of June 30, 2017, reserves for environmental liabilities totaled $48 million, of which $12 million was recorded within other current liabilities and $36 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $51 million at September 30, 2016. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At June 30, 2017 and September 30, 2016, the Company recorded conditional asset retirement obligations of $72 million and $74 million, respectively.
  (was, 2017-05-04, similarity 0.9954):
[0000833444-17-000016:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of March 31, 2017, reserves for environmental liabilities totaled $46 million, of which $9 million was recorded within other current liabilities and $37 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $51 million at  September 30, 2016. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At March 31, 2017 and September 30, 2016, the Company recorded conditional asset retirement obligations of $72 million and $74 million, respectively.

- added (2017-08-03):
[0000833444-17-000044:note_history:2]
As of June 30, 2017, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $147 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $535 million, of which $35 million was recorded in other current liabilities and $500 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $388 million, of which $52 million was recorded in other current assets, and $336 million was recorded in other noncurrent assets. Assets included $28 million of cash and $264 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at June 30, 2017 was $96 million. As of September 30, 2016, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $148 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $548 million, of which $35 million was recorded in other current liabilities and $513 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $400 million, of which $41 million was recorded in other current assets, and $359 million was recorded in other noncurrent assets. Assets included $16 million of cash and $264 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2016 was $120 million. The Company believes that the asbestos related liabilities and insurance related receivables recorded as of June 30, 2017 and September 30, 2016 are appropriate.

- changed (2017-08-03):
[0000833444-17-000044:note_history:3]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At June 30, 2017 and September 30, 2016, the insurable liabilities for continuing operations totaled $488 million and $422 million, respectively, of which $86 million and $60 million was recorded within other current liabilities, $30 million and $28 million was recorded within accrued compensation and benefits, and $372 million and $334 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at June 30, 2017 was $49 million, of which $30 million was recorded within other current assets and $19 million was recorded within other noncurrent assets. Insurance receivables recorded at September 30, 2016 were $21 million, primarily recorded within other noncurrent assets. The Company maintains captive insurance companies to manage certain of its insurable liabilities.
  (was, 2017-05-04, similarity 0.9932):
[0000833444-17-000016:note_history:3]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At March 31, 2017 and September 30, 2016, the insurable liabilities for continuing operations totaled $468 million and $422 million, respectively, of which $86 million and $60 million was recorded within other current liabilities, $32 million and $28 million was recorded within accrued compensation and benefits, and $350 million and $334 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at March 31, 2017 was $48 million, of which $30 million was recorded within other current assets and $18 million was recorded within other noncurrent assets. Insurance receivables recorded at September 30, 2016 were $21 million, primarily recorded within other noncurrent assets. The Company maintains captive insurance companies to manage certain of its insurable liabilities.

- removed (2017-08-03):
[0000833444-17-000016:note_history:4]
As of March 31, 2017, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position is $152 million. The net liability within the consolidated statements of financial position is comprised of a liability for pending and future claims and related defense costs of $540 million, of which $35 million is recorded in other current liabilities and $505 million is recorded in other noncurrent liabilities. The Company also maintains separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $388 million, of which $57 million is recorded in other current assets, and $331 million is recorded in other noncurrent assets. Assets include $33 million of cash and $258 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at March 31, 2017 is $97 million. As of September 30, 2016, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position is $148 million. The net liability within the consolidated statements of financial position is comprised of a liability for pending and future claims and related defense costs of $548 million, of which $35 million is recorded in other current liabilities and $513 million is recorded in other noncurrent liabilities. The Company also maintains separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $400 million, of which $41 million is recorded in other current assets, and $359 million is recorded in other noncurrent assets. Assets include $16 million of cash and $264 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2016 is $120 million. The Company believes that the asbestos related liabilities and insurance related receivables recorded as of March 31, 2017 and September 30, 2016 are appropriate.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-08-03):
[0000833444-17-000044:note_history:5]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (SEC). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2016 filed with the SEC on November 23, 2016, portions of which (including Part I, Item 1. Business and Item 3. Legal Proceedings, and the following items from Part II of the Annual Report: Item 6. Selected Financial Data, Item 7. Management’s Discussion and Analysis, and Item 8. Financial Statements and Supplementary Data) were recast in the Company's Current Report on Form 8-K filed with the SEC on February 23, 2017. The results of operations for the three and nine month periods ended June 30, 2017 are not necessarily indicative of results for the Company’s 2017 fiscal year because of seasonal and other factors.
  (was, 2017-05-04, similarity 0.9831):
[0000833444-17-000016:note_history:5]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (SEC). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2016 filed with the SEC on November 23, 2016, portions of which (including Part I, Item 1. Business and Item 3. Legal Proceedings, and the following items from Part II of the Annual Report: Item 6. Selected Financial Data, Item 7. Management’s Discussion and Analysis, and Item 8. Financial Statements and Supplementary Data) were recast in the Company's Current Report on Form 8-K filed with the SEC on February 23, 2017. The results of operations for the three and six month periods ended March 31, 2017 are not necessarily indicative of results for the Company’s 2017 fiscal year because of seasonal and other factors.

- changed (2017-08-03):
[0000833444-17-000044:note_history:6]
Based upon the criteria set forth in ASC 810, the Company has determined that it was the primary beneficiary in one VIE for the reporting period ended June 30, 2017 and three VIEs for the reporting period ended  September 30, 2016, as the Company absorbs significant economics of the entities and has the power to direct the activities that are considered most significant to the entities.
  (was, 2017-05-04, similarity 0.988):
[0000833444-17-000016:note_history:6]
Based upon the criteria set forth in ASC 810, the Company has determined that it was the primary beneficiary in one VIE for the reporting period ended March 31, 2017 and three VIEs for the reporting period ended  September 30, 2016, as the Company absorbs significant economics of the entities and has the power to direct the activities that are considered most significant to the entities.

- changed (2017-08-03):
[0000833444-17-000044:note_history:7]
In fiscal 2012, a pre-existing VIE accounted for under the equity method was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The Company acquired additional interests in two of the reorganized group entities. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is considered the primary beneficiary of one of the entities due to the Company’s power pertaining to decisions over significant activities of the entity. As such, this VIE has been consolidated within the Company’s consolidated statements of financial position. The impact of consolidation of the entity on the Company’s consolidated statements of income for the three and nine month periods ended June 30, 2017 and 2016 was not material. The VIE is named as a co-obligor under a third party debt agreement in the amount of $166 million, maturing in fiscal 2020, under which it could become subject to paying more than its allocated share of the third party debt in the event of bankruptcy of one or more of the other co-obligors. The other co-obligors, all related parties in which the Company is an equity investor, consist of the remaining group entities involved in the reorganization. As part of the overall reorganization transaction, the Company has also provided financial support to the group entities in the form of loans totaling $37 million, which are subordinate to the third party debt agreement. The Company is a significant customer of certain co-obligors, resulting in a remote possibility of loss. Additionally, the Company is subject to a floor guaranty expiring in fiscal 2022; in the event that the other owner party no longer owns any part of the group entities due to sale or transfer, the Company has guaranteed that the proceeds received from the sale or transfer will not be less than $25 million. The Company has partnered with the group entities to design and manufacture battery components for the Power Solutions business.
  (was, 2017-05-04, similarity 0.9862):
[0000833444-17-000016:note_history:7]
In fiscal 2012, a pre-existing VIE accounted for under the equity method was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The Company acquired additional interests in two of the reorganized group entities. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is considered the primary beneficiary of one of the entities due to the Company’s power pertaining to decisions over significant activities of the entity. As such, this VIE has been consolidated within the Company’s consolidated statements of financial position. The impact of consolidation of the entity on the Company’s consolidated statements of income for the three and six month periods ended March 31, 2017 and 2016 was not material. The VIE is named as a co-obligor under a third party debt agreement in the amount of $168 million, maturing in fiscal 2020, under which it could become subject to paying more than its allocated share of the third party debt in the event of bankruptcy of one or more of the other co-obligors. The other co-obligors, all related parties in which the Company is an equity investor, consist of the remaining group entities involved in the reorganization. As part of the overall reorganization transaction, the Company has also provided financial support to the group entities in the form of loans totaling $37 million, which are subordinate to the third party debt agreement. The Company is a significant customer of certain co-obligors, resulting in a remote possibility of loss. Additionally, the Company is subject to a floor guaranty expiring in fiscal 2022; in the event that the other owner party no longer owns any part of the group entities due to sale or transfer, the Company has guaranteed that the proceeds received from the sale or transfer will not be less than $25 million. The Company has partnered with the group entities to design and manufacture battery components for the Power Solutions business.

- changed (2017-08-03):
[0000833444-17-000044:note_history:8]
|  | June 30,2017 |  | September 30, 2016 |
| Current assets | $ | 2 |  |  | $ | 284 |  |
| Noncurrent assets | 53 |  |  | 98 |  |
| Total assets | $ | 55 |  |  | $ | 382 |  |
| Current liabilities | $ | 4 |  |  | $ | 230 |  |
| Noncurrent liabilities | 43 |  |  | 29 |  |
| Total liabilities | $ | 47 |  |  | $ | 259 |  |
  (was, 2017-05-04, similarity 0.9803):
[0000833444-17-000016:note_history:8]
|  | March 31, 2017 |  | September 30, 2016 |
| Current assets | $ | 2 |  |  | $ | 284 |  |
| Noncurrent assets | 53 |  |  | 98 |  |
| Total assets | $ | 55 |  |  | $ | 382 |  |
| Current liabilities | $ | 3 |  |  | $ | 230 |  |
| Noncurrent liabilities | 44 |  |  | 29 |  |
| Total liabilities | $ | 47 |  |  | $ | 259 |  |

- changed (2017-08-03):
[0000833444-17-000044:note_history:9]
As mentioned previously within the "Consolidated VIEs" section above, in fisca1 2012, a pre-existing VIE was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is not considered to be the primary beneficiary of two of the entities as the Company cannot make key operating decisions considered to be most significant to the VIEs. Therefore, the entities are accounted for under the equity method of accounting as the Company’s interest exceeds 20% and the Company does not have a controlling interest. The Company’s maximum exposure to loss includes the partially-owned affiliate investment balances of $63 million  and $59 million at June 30, 2017 and September 30, 2016 respectively, as well as the subordinated loan from the Company, third party debt agreement and floor guaranty mentioned previously within the "Consolidated VIEs" section above. Current liabilities due to the VIEs are not material and represent normal course of business trade payables for all presented periods.
  (was, 2017-05-04, similarity 0.9963):
[0000833444-17-000016:note_history:9]
As mentioned previously within the "Consolidated VIEs" section above, in fisca1 2012, a pre-existing VIE was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is not considered to be the primary beneficiary of two of the entities as the Company cannot make key operating decisions considered to be most significant to the VIEs. Therefore, the entities are accounted for under the equity method of accounting as the Company’s interest exceeds 20% and the Company does not have a controlling interest. The Company’s maximum exposure to loss includes the partially-owned affiliate investment balances of $62 million  and $59 million at March 31, 2017 and September 30, 2016 respectively, as well as the subordinated loan from the Company, third party debt agreement and floor guaranty mentioned previously within the "Consolidated VIEs" section above. Current liabilities due to the VIEs are not material and represent normal course of business trade payables for all presented periods.

- changed (2017-08-03):
[0000833444-17-000044:note_history:10]
At June 30, 2017, the Company held restricted cash of approximately $37 million, of which $28 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash restricted for payment of asbestos liabilities. At September 30, 2016, the Company held restricted cash of approximately $88 million, of which $79 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash held in escrow from business divestitures and cash restricted for payment of asbestos liabilities.
  (was, 2017-05-04, similarity 0.9947):
[0000833444-17-000016:note_history:10]
At March 31, 2017, the Company held restricted cash of approximately $42 million, of which $33 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash restricted for payment of asbestos liabilities. At September 30, 2016, the Company held restricted cash of approximately $88 million, of which $79 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash held in escrow from business divestitures and cash restricted for payment of asbestos liabilities.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-08-03):
[0000833444-17-000044:note_history:11]
In June 2017, the Company partially repaid $135 million of the $4.0 billion floating rate term loan scheduled to mature in March 2020.

- changed (2017-08-03):
[0000833444-17-000044:note_history:12]
In March 2017, the Company entered into a 364-day $150 million committed revolving credit facility scheduled to expire in March 2018. As of June 30, 2017, there were no draws on the facility.
  (was, 2017-05-04, similarity 0.9741):
[0000833444-17-000016:note_history:12]
In March 2017, the Company entered into a 364-day $150 million committed revolving credit facility scheduled to expire in March 2018. As of March 31, 2017, there were no draws on the facility.

- changed (2017-08-03):
[0000833444-17-000044:note_history:13]
In February 2017, the Company entered into a 364-day $150 million committed revolving credit facility scheduled to expire in February 2018. As of June 30, 2017, there were no draws on the facility.
  (was, 2017-05-04, similarity 0.9749):
[0000833444-17-000016:note_history:13]
In February 2017, the Company entered into a 364-day $150 million committed revolving credit facility scheduled to expire in February 2018. As of March 31, 2017, there were no draws on the facility.

- changed (2017-08-03):
[0000833444-17-000044:note_history:14]
In January 2017, the Company entered into a 364-day $250 million committed revolving credit facility scheduled to expire                      in January 2018. As of June 30, 2017, there were no draws on the facility outstanding.
  (was, 2017-05-04, similarity 0.9763):
[0000833444-17-000016:note_history:14]
In January 2017, the Company entered into a 364-day $250 million committed revolving credit facility scheduled to expire                      in January 2018. As of March 31, 2017, there were no draws on the facility outstanding.

- changed (2017-08-03):
[0000833444-17-000044:note_history:15]
The Company's net financing charges line item in the consolidated statements of income for the three and nine month periods ended June 30, 2017 and 2016 contained the following components (in millions):
  (was, 2017-05-04, similarity 0.9639):
[0000833444-17-000016:note_history:15]
The Company's net financing charges line item in the consolidated statements of income for the three and six month periods ended March 31, 2017 and 2016 contained the following components (in millions):

- changed (2017-08-03):
[0000833444-17-000044:note_history:16]
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Interest expense, net of capitalized interest costs | $ | 115 |  |  | $ | 66 |  |  | $ | 343 |  |  | $ | 203 |  |
| Banking fees and bond cost amortization | 14 |  |  | 7 |  |  | 55 |  |  | 19 |  |
| Interest income | (4 | ) |  | (4 | ) |  | (16 | ) |  | (8 | ) |
| Net foreign exchange results for financing activities | (1 | ) |  | (4 | ) |  | (6 | ) |  | (12 | ) |
| Net financing charges | $ | 124 |  |  | $ | 65 |  |  | $ | 376 |  |  | $ | 202 |  |
  (was, 2017-05-04, similarity 0.7302):
[0000833444-17-000016:note_history:16]
|  | Three Months EndedMarch 31, |  | Six Months EndedMarch 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Interest expense, net of capitalized interest costs | $ | 118 |  |  | $ | 65 |  |  | $ | 228 |  |  | $ | 137 |  |
| Banking fees and bond cost amortization | 11 |  |  | 5 |  |  | 41 |  |  | 12 |  |
| Interest income | (5 | ) |  | (2 | ) |  | (12 | ) |  | (4 | ) |
| Net foreign exchange results for financing activities | (8 | ) |  | 3 |  |  | (5 | ) |  | (8 | ) |
| Net financing charges | $ | 116 |  |  | $ | 71 |  |  | $ | 252 |  |  | $ | 137 |  |

- changed (2017-08-03):
[0000833444-17-000044:note_history:17]
Net financing charges for the nine month period ended June 30, 2017 included $17 million of transaction costs related primarily to the debt exchange offers.
  (was, 2017-05-04, similarity 0.9533):
[0000833444-17-000016:note_history:17]
Net financing charges for the six month period ended March 31, 2017 included $17 million of transaction costs related primarily to the debt exchange offers.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2017-08-03):
[0000833444-17-000044:note_history:18]
The net sales to and purchases from related parties for continuing operations included in the consolidated statements of income were $272 million and $64 million, respectively, for the three months ended June 30, 2017; and $277 million and $48 million, respectively, for the three months ended June 30, 2016. The net sales to and purchases from related parties for continuing operations included in the consolidated statements of income were $726 million and $165 million, respectively, for the nine months ended June 30, 2017; and $747 million and $131 million, respectively, for the nine months ended June 30, 2016.

- changed (2017-08-03):
[0000833444-17-000044:note_history:19]
|  |  | June 30, 2017 |  | September 30, 2016 |  |
| Receivable from related parties |  | $ | 99 |  |  | $ | 66 |  |
| Payable to related parties |  | 22 |  |  | 11 |  |
  (was, 2017-05-04, similarity 0.9686):
[0000833444-17-000016:note_history:19]
|  |  | March 31, 2017 |  | September 30, 2016 |  |
| Receivable from related parties |  | $ | 57 |  |  | $ | 66 |  |
| Payable to related parties |  | 20 |  |  | 11 |  |

- removed (2017-08-03):
[0000833444-17-000016:note_history:20]
The net sales to and purchases from related parties for continuing operations included in the consolidated statements of income were $229 million and $52 million, respectively, for the three months ended March 31, 2017; and $236 million and $45 million, respectively, for the three months ended March 31, 2016. The net sales to and purchases from related parties for continuing operations included in the consolidated statements of income were $454 million and $101 million, respectively, for the six months ended March 31, 2017; and $470 million and $83 million, respectively, for the six months ended March 31, 2016.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2017-08-03):
[0000833444-17-000044:note_history:21]
|  |  | June 30, 2017 |  | September 30, 2016 |  |
| Receivable from related parties |  | $ | 99 |  |  | $ | 66 |  |
| Payable to related parties |  | 22 |  |  | 11 |  |
  (was, 2017-05-04, similarity 0.9686):
[0000833444-17-000016:note_history:21]
|  |  | March 31, 2017 |  | September 30, 2016 |  |
| Receivable from related parties |  | $ | 57 |  |  | $ | 66 |  |
| Payable to related parties |  | 20 |  |  | 11 |  |
