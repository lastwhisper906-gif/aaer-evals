# JCI MD&A — 0000833444-17-000060


## mdna

[0000833444-17-000060:mdna:1]
| ITEM 7 | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0000833444-17-000060:mdna:2]
General

[0000833444-17-000060:mdna:3]
The Company operates in two primary businesses: Building Technologies & Solutions and Power Solutions. Building Technologies & Solutions provides facility systems and services including comfort and energy management for the residential and non-residential buildings markets, security products and services, fire detection and suppression products and services, and life safety products. Power Solutions designs and manufactures automotive batteries for the replacement and original equipment markets.

[0000833444-17-000060:mdna:4]
This discussion summarizes the significant factors affecting the consolidated operating results, financial condition and liquidity of the Company for the three-year period ended September 30, 2017. This discussion should be read in conjunction with Item 8, the consolidated financial statements and the notes to consolidated financial statements.

[0000833444-17-000060:mdna:5]
Effective July 1, 2017, the Company reorganized the reportable segments within its Building Technologies & Solutions business to align with its new management reporting structure and business activities. Prior to this reorganization, Building Technologies & Solutions was comprised of five reportable segments for financial reporting purposes: Systems and Service North America, Products North America, Asia, Rest of World and Tyco. As a result of this change, Building Technologies & Solutions is now comprised of four reportable segments for financial reporting purposes: Building Solutions North America, Building Solutions EMEA/LA, Building Solutions Asia Pacific and Global Products. Historical information has been revised to reflect the new Building Technologies & Solutions reportable segments. Refer to Note 7, “Goodwill and Other Intangible Assets,” and Note 19, “Segment Information,” of the notes to consolidated financial statements for further information.

[0000833444-17-000060:mdna:6]
FISCAL YEAR 2017 COMPARED TO FISCAL YEAR 2016

[0000833444-17-000060:mdna:7]
Net Sales

[0000833444-17-000060:mdna:8]
|  | Year Ended September 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Net sales | $ | 30,172 |  |  | $ | 20,837 |  |  | 45 | % |

[0000833444-17-000060:mdna:9]
The increase in consolidated net sales was due to higher sales in the Building Technologies & Solutions business ($8,647 million) and Power Solutions business ($667 million), and the favorable impact of foreign currency translation ($21 million). Increased sales resulted from the Tyco Merger, as well as higher volumes in the Global Products segment, the impact of higher lead costs on pricing, and favorable pricing and product mix in the Power Solutions business. Excluding the impact of the Tyco Merger and foreign currency translation, consolidated net sales increased 4% as compared to the prior year. Refer to the segment analysis below within Item 7 for a discussion of net sales by segment.

[0000833444-17-000060:mdna:10]
Cost of Sales / Gross Profit

[0000833444-17-000060:mdna:11]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Cost of sales | $ | 20,833 |  |  | $ | 15,183 |  |  | 37 | % |
| Gross profit | 9,339 |  |  | 5,654 |  |  | 65 | % |
| % of sales | 31.0 | % |  | 27.1 | % |  |  |

[0000833444-17-000060:mdna:12]
Cost of sales increased in fiscal 2017 as compared to fiscal 2016, with gross profit as a percentage of sales increasing by 390 basis points. Gross profit in the Building Technologies & Solutions business included the incremental gross profit related to the Tyco Merger, and higher volumes in the Global Products  segment. Gross profit in the Power Solutions business was favorably impacted by favorable pricing and product mix net of lead cost increases and higher volumes, partially offset by higher operating costs. Net mark-to-market adjustments on pension and postretirement plans had a net favorable year-over-year impact on cost of sales of $169 million ($72 million gain in fiscal 2017 compared to a $97 million charge in fiscal 2016) primarily due to an increase in year-over-year discount rates and favorable U.S. investment returns versus expectations in the current year. Foreign currency translation had an unfavorable impact on cost of sales of approximately $21 million. Refer to the segment analysis below within Item 7 for a discussion of segment earnings before interest, taxes and amortization ("EBITA") by segment.

[0000833444-17-000060:mdna:13]
Selling, General and Administrative Expenses

[0000833444-17-000060:mdna:14]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Selling, general and administrative expenses | $ | 6,158 |  |  | $ | 4,190 |  |  | 47 | % |
| % of sales | 20.4 | % |  | 20.1 | % |  |  |

[0000833444-17-000060:mdna:15]
Selling, general and administrative expenses ("SG&A") increased by $1,968 million year over year, and SG&A as a percentage of sales increased by 30 basis points. The Building Technologies & Solutions business SG&A increased primarily due to incremental SG&A related to the Tyco Merger, partially offset by productivity savings and cost synergies. Foreign currency translation had an unfavorable impact on SG&A of $5 million. The net unfavorable year-over-year impact on SG&A resulting from transaction, integration and separation costs was $149 million. The net mark-to-market adjustments on pension and postretirement plans had a net favorable year-over-year impact on SG&A of $644 million ($348 million gain in fiscal 2017 compared to a $296 million charge in fiscal 2016) primarily  due to an increase in year-over-year discount rates and favorable U.S. investment returns versus expectations in the current year. Refer to the segment analysis below within Item 7 for a discussion of segment EBITA by segment.

[0000833444-17-000060:mdna:16]
Restructuring and Impairment Costs

[0000833444-17-000060:mdna:17]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Restructuring and impairment costs | $ | 367 |  |  | $ | 288 |  |  | 27 | % |

[0000833444-17-000060:mdna:18]
Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for further disclosure related to the Company's restructuring plans.

[0000833444-17-000060:mdna:19]
Net Financing Charges

[0000833444-17-000060:mdna:20]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Net financing charges | $ | 496 |  |  | $ | 289 |  |  | 72 | % |

[0000833444-17-000060:mdna:21]
Net financing charges increased in fiscal 2017 as compared to fiscal 2016 primarily due to higher interest rates, higher average borrowing levels as a result of the debt assumed with the Tyco Merger, new debt issuances in the second quarter of fiscal year 2017 and debt exchange offer fees.

[0000833444-17-000060:mdna:22]
Equity Income

[0000833444-17-000060:mdna:23]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Equity income | $ | 240 |  |  | $ | 174 |  |  | 38 | % |

[0000833444-17-000060:mdna:24]
The increase in equity income was primarily due to higher income at certain partially-owned affiliates of the Power Solutions business and the Johnson Controls - Hitachi ("JCH") joint venture in the Building Technologies & Solutions business. Refer to the segment analysis below within Item 7 for a discussion of segment EBITA by segment.

[0000833444-17-000060:mdna:25]
Income Tax Provision

[0000833444-17-000060:mdna:26]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Income tax provision | $ | 705 |  |  | $ | 197 |  |  | * |
| Effective tax rate | 28 | % |  | 19 | % |  |  |

[0000833444-17-000060:mdna:27]
* Measure not meaningful

[0000833444-17-000060:mdna:28]
The U.S. federal statutory tax rate is being used as a comparison since the Company was a U.S. domiciled company for 11 months of 2016 and due to the Company's current legal entity structure. The effective rate is below the U.S. statutory rate for fiscal 2017 primarily due to the benefits of continuing global tax planning initiatives, non-U.S. tax rate differentials, tax audit closures, and a tax benefit due to changes in entity tax status, partially offset by the jurisdictional mix of significant restructuring and impairment costs, Tyco Merger transaction / integration costs and the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries related to the divestiture of the Scott Safety business. The effective rate is below the U.S. statutory rate for fiscal 2016 primarily due to the benefits of continuing global tax planning initiatives and foreign tax rate differentials, partially offset by the jurisdictional mix of restructuring and impairment costs, and the tax impacts of the merger and integration related costs. The fiscal 2017 effective tax rate increased as compared to the fiscal 2016 effective tax rate primarily due to the tax effects of transactions ($408 million), and the tax effects of restructuring and impairment costs ($37 million), partially offset by the tax effects of reserve and valuation allowance adjustments ($164 million) and tax planning initiatives. The fiscal year 2017 and 2016 global tax planning initiatives related primarily to foreign tax credit planning, changes in entity tax status, global financing structures and alignment of the Company's global business functions in a tax efficient manner. Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements for further details.

[0000833444-17-000060:mdna:29]
Valuation Allowances

[0000833444-17-000060:mdna:30]
The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary.

[0000833444-17-000060:mdna:31]
In the fourth quarter of fiscal 2017, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering tax planning initiatives and other positive and negative evidence, the Company determined that it was more likely than not that certain deferred tax assets primarily in Canada, China and Mexico would not be able to be realized, and it was more likely than not that certain deferred tax assets in Germany would be realized. Therefore, the Company recorded $27 million of net valuation allowances as income tax expense in the three month period ended September 30, 2017.

[0000833444-17-000060:mdna:32]
In the fourth quarter of fiscal 2016, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering tax planning initiatives and other positive and negative evidence, the Company determined that no other material changes were needed to its valuation allowances.  Therefore, there was no impact to income tax expense due to valuation allowance changes in the three month period or year ended September 30, 2016.

[0000833444-17-000060:mdna:33]
34

[0000833444-17-000060:mdna:34]
Uncertain Tax Positions

[0000833444-17-000060:mdna:35]
The Company is subject to income taxes in the U.S. and numerous non-U.S. jurisdictions. Judgment is required in determining its worldwide provision for income taxes and recording the related assets and liabilities. In the ordinary course of the Company’s business, there are many transactions and calculations where the ultimate tax determination is uncertain. The Company is regularly under audit by tax authorities.

[0000833444-17-000060:mdna:36]
During fiscal 2017, the Company settled a significant number of tax examinations impacting fiscal years 2006 to fiscal 2014. In the fourth quarter of fiscal 2017, income tax audit resolutions resulted in a net $191 million benefit to income tax expense.

[0000833444-17-000060:mdna:37]
The Company’s federal income tax returns and certain non-U.S. income tax returns for various fiscal years remain under various stages of audit by the IRS and respective non-U.S. tax authorities. Although the outcome of tax audits is always uncertain, management believes that it has appropriate support for the positions taken on its tax returns and that its annual tax provisions included amounts sufficient to pay assessments, if any, which may be proposed by the taxing authorities. At September 30, 2017, the Company had recorded a liability for its best estimate of the probable loss on certain of its tax positions, the majority of which is included in other noncurrent liabilities in the consolidated statements of financial position. Nonetheless, the amounts ultimately paid, if any, upon resolution of the issues raised by the taxing authorities may differ materially from the amounts accrued for each year.

[0000833444-17-000060:mdna:38]
Other Tax Matters

[0000833444-17-000060:mdna:39]
During fiscal 2017, the Company recorded $428 million of transaction and integration costs which generated a $69 million tax benefit.

[0000833444-17-000060:mdna:40]
During fiscal 2017, the Company recorded a discrete non-cash tax charge of $490 million related to establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries of the Scott Safety business. This business is reported as net assets held for sale given the announced sale to 3M Company. Refer to Note 3, "Acquisitions and Divestitures," and Note 4, "Discontinued Operations," of the notes to consolidated financial statements for additional information.

[0000833444-17-000060:mdna:41]
In the fourth quarter of fiscal 2017, the Company recorded a tax charge of $53 million due to a change in the deferred tax liability related to the outside basis of certain nonconsolidated subsidiaries.

[0000833444-17-000060:mdna:42]
In the first quarter of fiscal 2017, the Company recorded a discrete tax benefit of $101 million due to changes in entity tax status.

[0000833444-17-000060:mdna:43]
During fiscal 2017 and 2016, the Company incurred significant charges for restructuring and impairment costs. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. A substantial portion of these charges do not generate a tax benefit due to the Company's current tax position in these jurisdictions and the underlying tax basis in the impaired assets, resulting in $65 million and $28 million incremental tax expense in fiscal 2017 and 2016, respectively.

[0000833444-17-000060:mdna:44]
During the fourth quarter of fiscal 2016, the Company completed its merger with Tyco. As a result of that transaction, the Company incurred incremental tax expense of $137 million. In preparation for the spin-off of the Automotive Experience business in the first quarter of fiscal 2017, the Company incurred incremental tax expense for continuing operations of $26 million in fiscal 2016.

[0000833444-17-000060:mdna:45]
Impacts of Tax Legislation and Change in Statutory Tax Rates

[0000833444-17-000060:mdna:46]
On October 13, 2016, the U.S. Treasury and the IRS released final and temporary Section 385 regulations. These regulations address whether certain instruments between related parties are treated as debt or equity. The Company does not expect that the regulations will have a material impact on its consolidated financial statements.

[0000833444-17-000060:mdna:47]
The "look-through rule," under subpart F of the U.S. Internal Revenue Code, expired for the Company on September 30, 2015. The "look-through rule" had provided an exception to the U.S. taxation of certain income generated by foreign subsidiaries. The rule was extended in December 2015 retroactive to the beginning of the Company’s 2016 fiscal year. The retroactive extension was signed into legislation and was made permanent through the Company's 2020 fiscal year.

[0000833444-17-000060:mdna:48]
During the fiscal years ended 2017 and 2016, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-17-000060:mdna:49]
35

[0000833444-17-000060:mdna:50]
Loss From Discontinued Operations, Net of Tax

[0000833444-17-000060:mdna:51]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Loss from discontinued operations, net of tax | $ | (34 | ) |  | $ | (1,516 | ) |  | * |

[0000833444-17-000060:mdna:52]
* Measure not meaningful

[0000833444-17-000060:mdna:53]
Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-17-000060:mdna:54]
Income Attributable to Noncontrolling Interests

[0000833444-17-000060:mdna:55]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 199 |  |  | $ | 132 |  |  | 51 | % |
| Income from discontinued operations attributable to noncontrolling interests | 9 |  |  | 84 |  |  | -89 | % |

[0000833444-17-000060:mdna:56]
The increase in income from continuing operations attributable to noncontrolling interests for fiscal 2017 was primarily due to higher net income related to the JCH joint venture in the Building Technologies & Solutions business.

[0000833444-17-000060:mdna:57]
Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

[0000833444-17-000060:mdna:58]
Net Income (Loss) Attributable to Johnson Controls

[0000833444-17-000060:mdna:59]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Net income (loss) attributable to Johnson Controls | $ | 1,611 |  |  | $ | (868 | ) |  | * |

[0000833444-17-000060:mdna:60]
* Measure not meaningful

[0000833444-17-000060:mdna:61]
The increase in net income (loss) attributable to Johnson Controls was primarily due to incremental operating income as a result of the Tyco Merger and a prior year net loss from discontinued operations, partially offset by an increase in the income tax provision and higher net financing charges. Fiscal 2017 diluted earnings (loss) per share attributable to Johnson Controls was $1.71 compared to ($1.29) in fiscal 2016.

[0000833444-17-000060:mdna:62]
Comprehensive Income (Loss) Attributable to Johnson Controls

[0000833444-17-000060:mdna:63]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Comprehensive income (loss) attributable to Johnson Controls | $ | 1,710 |  |  | $ | (964 | ) |  | * |

[0000833444-17-000060:mdna:64]
* Measure not meaningful

[0000833444-17-000060:mdna:65]
The increase in comprehensive income (loss) attributable to Johnson Controls was due to higher net income (loss) attributable to Johnson Controls ($2,479 million) and an increase in other comprehensive loss attributable to Johnson Controls ($195 million) primarily related to favorable foreign currency translation adjustments. These year-over-year favorable foreign currency translation adjustments were primarily driven by the strengthening of the euro and British pound currencies against the U.S. dollar, partially offset by the weakening of the Japanese yen currency against the U.S. dollar.

[0000833444-17-000060:mdna:66]
SEGMENT ANALYSIS

[0000833444-17-000060:mdna:67]
Management evaluates the performance of its business units based primarily on segment EBITA, which is defined as income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, significant restructuring and impairment costs, and net mark-to-market adjustments on pension and postretirement plans.

[0000833444-17-000060:mdna:68]
Building Technologies & Solutions

[0000833444-17-000060:mdna:69]
|  | Net Salesfor the Year EndedSeptember 30, |  |  |  | Segment EBITAfor the Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |  | 2017 |  | 2016 |  | Change |
| Building Solutions North America | $ | 8,341 |  |  | $ | 4,687 |  |  | 78 | % |  | $ | 1,039 |  |  | $ | 494 |  |  | * |  |
| Building Solutions EMEA/LA | 3,595 |  |  | 1,613 |  |  | * |  |  | 290 |  |  | 74 |  |  | * |  |
| Building Solutions Asia Pacific | 2,444 |  |  | 1,736 |  |  | 41 | % |  | 323 |  |  | 222 |  |  | 45 | % |
| Global Products | 8,455 |  |  | 6,148 |  |  | 38 | % |  | 1,179 |  |  | 637 |  |  | 85 | % |
|  | $ | 22,835 |  |  | $ | 14,184 |  |  | 61 | % |  | $ | 2,831 |  |  | $ | 1,427 |  |  | 98 | % |

[0000833444-17-000060:mdna:70]
* Measure not meaningful

[0000833444-17-000060:mdna:71]
Net Sales:

[0000833444-17-000060:mdna:72]
| • | The increase in Building Solutions North America was due to incremental sales related to the Tyco Merger including current year nonrecurring purchase accounting adjustments ($3,689 million), the impact of prior year nonrecurring purchase accounting adjustments ($15 million) and the favorable impact of foreign currency translation ($5 million), partially offset by a prior year business divestiture ($32 million) and lower installation volumes ($23 million). |

[0000833444-17-000060:mdna:73]
| • | The increase in Building Solutions EMEA/LA was due to incremental sales related to the Tyco Merger including current year nonrecurring purchase accounting adjustments ($1,982 million), higher volumes ($7 million), the impact of prior year nonrecurring purchase accounting adjustments ($5 million) and the favorable impact of foreign currency translation ($3 million), partially offset by a business divestiture ($15 million). |

[0000833444-17-000060:mdna:74]
| • | The increase in Building Solutions Asia Pacific was due to incremental sales related to the Tyco Merger including current year nonrecurring purchase accounting adjustments ($653 million), higher volumes of equipment and control systems ($41 million), and higher service volumes ($38 million), partially offset by the unfavorable impact of foreign currency translation ($24 million). The increase in volume was driven by favorable local economic conditions. |

[0000833444-17-000060:mdna:75]
| • | The increase in Global Products was due to incremental sales related to the Tyco Merger including current year nonrecurring purchase accounting adjustments ($2,157 million), higher volumes ($221 million) and the favorable impact of foreign currency translation ($20 million), partially offset by lower volumes related to business divestitures and deconsolidation ($91 million). The increase in volumes was primarily attributable to new product offerings. |

[0000833444-17-000060:mdna:76]
Segment EBITA:

[0000833444-17-000060:mdna:77]
| • | The increase in Building Solutions North America was due to incremental income related to the Tyco Merger ($567 million), the net impact of prior year and current year nonrecurring purchase accounting adjustments ($52 million), favorable mix ($9 million), lower selling, general and administrative expenses ($3 million) as a result of productivity and synergy savings net of a prior year gain on business divestiture, the favorable impact of foreign currency translation ($1 million) and prior year transaction costs ($1 million), partially offset by current year integration costs ($42 million), higher operating costs as a result of channel investments ($25 million), current year transaction costs ($13 million), lower volumes ($6 million) and a prior year business divestiture ($2 million). |

[0000833444-17-000060:mdna:78]
| • | The increase in Building Solutions EMEA/LA was due to incremental income related to the Tyco Merger ($221 million), the net impact of prior year and current year nonrecurring purchase accounting adjustments ($33 million), lower selling, general and administrative expenses as a result of productivity and synergy savings ($23 million), favorable mix ($7 million), higher volumes ($2 million) and prior year transaction costs ($1 million), partially offset by a current year unfavorable arbitration award ($50 million), current year integration costs ($6 million), lower equity income ($6 million), |

[0000833444-17-000060:mdna:79]
37

[0000833444-17-000060:mdna:80]
current year transaction costs ($5 million), the unfavorable impact of foreign currency translation ($3 million) and a prior year business divestiture ($1 million).

[0000833444-17-000060:mdna:81]
| • | The increase in Building Solutions Asia Pacific was due to incremental income related to the Tyco Merger ($73 million), lower selling, general and administrative expenses as a result of productivity savings ($24 million), higher volumes ($20 million) and the favorable impact of foreign currency translation ($1 million), partially offset by unfavorable mix ($6 million), current year integration costs ($5 million), higher operating costs ($4 million) and current year transaction costs ($2 million). |

[0000833444-17-000060:mdna:82]
| • | The increase in Global Products was due to incremental income related to the Tyco Merger ($474 million), higher volumes ($55 million), lower selling, general and administrative expenses as a result of productivity and synergy savings ($41 million), higher equity income ($33 million), prior year integration costs ($20 million), prior year transaction costs ($14 million) and lower operating costs ($13 million), partially offset by the net impact of prior year and current year nonrecurring purchase accounting adjustments ($42 million), current year integration costs ($25 million), unfavorable mix ($16 million), current year transaction costs ($13 million), the unfavorable impact of foreign currency translation ($5 million), a prior year gain on acquisition of partially-owned affiliate ($4 million) and business divestitures ($3 million). |

[0000833444-17-000060:mdna:83]
Power Solutions

[0000833444-17-000060:mdna:84]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Net sales | $ | 7,337 |  |  | $ | 6,653 |  |  | 10 | % |
| Segment EBITA | 1,427 |  |  | 1,327 |  |  | 8 | % |

[0000833444-17-000060:mdna:85]
| • | Net sales increased due to the impact of higher lead costs on pricing ($427 million) favorable pricing and product mix ($154 million), higher sales volumes ($86 million) and the favorable impact of foreign currency translation ($17 million). The increase in volumes was driven by start-stop battery volumes and growth in China. Additionally, higher start-stop volumes contributed to favorable product mix. |

[0000833444-17-000060:mdna:86]
| • | Segment EBITA increased due to favorable pricing and product mix net of lead cost increases ($106 million), lower selling, general and administrative expenses as a result of productivity savings ($39 million), higher equity income ($28 million), higher volumes ($27 million), prior year restructuring and impairment costs included in equity income ($7 million), prior year transaction costs ($1 million) and the favorable impact of foreign currency translation ($1 million), partially offset by higher operating costs primarily driven by efforts to satisfy growing customer demand ($108 million) and current year transaction costs ($1 million). |

[0000833444-17-000060:mdna:87]
FISCAL YEAR 2016 COMPARED TO FISCAL YEAR 2015

[0000833444-17-000060:mdna:88]
Net Sales

[0000833444-17-000060:mdna:89]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Net sales | $ | 20,837 |  |  | $ | 17,100 |  |  | 22 | % |

[0000833444-17-000060:mdna:90]
The increase in consolidated net sales was due to higher sales in the Building Technologies & Solutions business ($3,837 million) and Power Solutions business ($243 million), partially offset by the unfavorable impact of foreign currency translation ($343 million). Excluding the unfavorable impact of foreign currency translation, consolidated net sales increased 24% as compared to the prior year. Increased sales resulted from the JCH joint venture and the Tyco Merger, as well as higher volumes in the Building Solutions North America segment, higher global battery shipments and favorable product mix in the Power Solutions business. Refer to the segment analysis below within Item 7 for a discussion of net sales by segment.

[0000833444-17-000060:mdna:91]
38

[0000833444-17-000060:mdna:92]
Cost of Sales / Gross Profit

[0000833444-17-000060:mdna:93]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Cost of sales | $ | 15,183 |  |  | $ | 12,569 |  |  | 21 | % |
| Gross profit | 5,654 |  |  | 4,531 |  |  | 25 | % |
| % of sales | 27.1 | % |  | 26.5 | % |  |  |

[0000833444-17-000060:mdna:94]
Cost of sales increased in fiscal 2016 as compared to fiscal 2015, with gross profit as a percentage of sales increasing by 60 basis points. Foreign currency translation had a favorable impact on cost of sales of approximately $253 million. Gross profit in the Building Technologies & Solutions business included the incremental gross profit related to the JCH joint venture and Tyco Merger, and higher volumes in the Building Solutions North America segment. Gross profit in the Power Solutions business was favorably impacted by higher volumes, and favorable pricing and product mix, partially offset by higher operating costs. Net mark-to-market adjustments on pension and postretirement plans had a net favorable year over year impact on cost of sales of $56 million ($97 million charge in fiscal 2016 compared to a $153 million charge in fiscal 2015) primarily due to the unfavorable U.S. investment returns versus expectations and the adoption of new mortality rate changes in the U.S. in the prior year, partially offset by a decrease in year-over-year discount rates. Refer to the segment analysis below within Item 7 for a discussion of segment EBITA by segment.

[0000833444-17-000060:mdna:95]
Selling, General and Administrative Expenses

[0000833444-17-000060:mdna:96]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Selling, general and administrative expenses | $ | 4,190 |  |  | $ | 3,191 |  |  | 31 | % |
| % of sales | 20.1 | % |  | 18.7 | % |  |  |

[0000833444-17-000060:mdna:97]
SG&A increased by $999 million year over year, and SG&A as a percentage of sales increased by 140 basis points. The net mark-to-market adjustments on pension and postretirement plans had a net unfavorable year over year impact on SG&A of $33 million ($296 million charge in fiscal 2016 compared to a $263 million charge in fiscal 2015) primarily due to a decrease in year-over-year discount rates, partially offset by the unfavorable U.S. investment returns versus expectations and the adoption of new mortality rate changes in the U.S. in the prior year. Additionally, the net unfavorable impact on SG&A resulting from transaction and integration costs was $130 million. Excluding the impact of transaction and integrations costs, the Building Technologies & Solutions business SG&A increased primarily due to incremental SG&A related to the JCH joint venture and Tyco Merger, and product and sales force investments in North America. The Power Solutions business SG&A decreased primarily due to lower employee related expenses and cost reduction initiatives. Foreign currency translation had a favorable impact on SG&A of $44 million. Refer to the segment analysis below within Item 7 for a discussion of segment EBITA by segment.

[0000833444-17-000060:mdna:98]
Restructuring and Impairment Costs

[0000833444-17-000060:mdna:99]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Restructuring and impairment costs | $ | 288 |  |  | $ | 215 |  |  | 34 | % |

[0000833444-17-000060:mdna:100]
Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for further disclosure related to the Company's restructuring plans.

[0000833444-17-000060:mdna:101]
Net Financing Charges

[0000833444-17-000060:mdna:102]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Net financing charges | $ | 289 |  |  | $ | 274 |  |  | 5 | % |

[0000833444-17-000060:mdna:103]
Net financing charges increased in fiscal 2016 as compared to fiscal 2015 primarily due to higher average borrowing levels; in part due to the acquisition of debt as a result of the Tyco Merger.

[0000833444-17-000060:mdna:104]
Equity Income

[0000833444-17-000060:mdna:105]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Equity income | $ | 174 |  |  | $ | 80 |  |  | * |

[0000833444-17-000060:mdna:106]
* Measure not meaningful

[0000833444-17-000060:mdna:107]
The increase in equity income was primarily due to current year income related to partially-owned affiliates of the JCH joint venture in the Building Technologies & Solutions business. Refer to the segment analysis below within Item 7 for a discussion of segment EBITA by segment.

[0000833444-17-000060:mdna:108]
Income Tax Provision

[0000833444-17-000060:mdna:109]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Income tax provision | $ | 197 |  |  | $ | 71 |  |  | * |
| Effective tax rate | 19 | % |  | 8 | % |  |  |

[0000833444-17-000060:mdna:110]
* Measure not meaningful

[0000833444-17-000060:mdna:111]
The U.S. federal statutory tax rate is being used as a comparison since the Company was a U.S. domiciled company in fiscal 2015 and for 11 months of 2016. The effective rate is below the U.S. statutory rate for fiscal 2016 primarily due to the benefits of continuing global tax planning initiatives and foreign tax rate differentials, partially offset by the jurisdictional mix of restructuring and impairment costs, and the tax impacts of the merger and integration related costs. The effective rate is below the U.S. statutory rate for fiscal 2015 primarily due to the benefits of continuing global tax planning initiatives, income in certain non-U.S. jurisdictions with a tax rate lower than the U.S. statutory tax rate and adjustments due to tax audit resolutions. The fiscal 2016 effective tax rate increased as compared to the fiscal 2015 effective tax rate primarily due to the tax effects of transactions ($163 million), reserve and valuation allowance adjustments ($99 million), and the tax effects of restructuring and impairment costs ($28 million), partially offset by tax planning initiatives ($164 million). The fiscal year 2016 and 2015 global tax planning initiatives related primarily to foreign tax credit planning, global financing structures and alignment of the Company's global business functions in a tax efficient manner. Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements for further details.

[0000833444-17-000060:mdna:112]
Valuation Allowances

[0000833444-17-000060:mdna:113]
The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary.

[0000833444-17-000060:mdna:114]
In the fourth quarter of fiscal 2016, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering tax planning initiatives and other positive and negative evidence, the Company determined that no other material changes were needed to its valuation allowances.  Therefore, there was no impact to income tax expense due to valuation allowance changes in the three month period or year ended September 30, 2016.

[0000833444-17-000060:mdna:115]
In the fourth quarter of fiscal 2015, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering tax planning initiatives and other positive and negative evidence, the Company determined that it was more likely than not that certain deferred tax assets primarily within Spain, Germany, and the United Kingdom would not be realized, and was more likely than not that certain deferred tax assets of Poland and Germany would be realized. The impact of the net valuation allowance provision offset the benefit of valuation allowance releases and, as such, there was no net impact to income tax expense in the three month period or year ended September 30, 2015.

[0000833444-17-000060:mdna:116]
40

[0000833444-17-000060:mdna:117]
Uncertain Tax Positions

[0000833444-17-000060:mdna:118]
The Company is subject to income taxes in the U.S. and numerous non-U.S. jurisdictions. Judgment is required in determining its worldwide provision for income taxes and recording the related assets and liabilities. In the ordinary course of the Company’s business, there are many transactions and calculations where the ultimate tax determination is uncertain. The Company is regularly under audit by tax authorities.

[0000833444-17-000060:mdna:119]
During fiscal 2015, the Company settled a significant number of tax examinations in Germany, Mexico and the U.S., impacting fiscal years 1998 to fiscal 2012. The settlement of unrecognized tax benefits included cash payments for approximately $440 million and the loss of various tax attributes. The reduction for tax positions of prior years is substantially related to foreign exchange rates. In the fourth quarter of fiscal 2015, income tax audit resolutions resulted in a net $99 million benefit to income tax expense.

[0000833444-17-000060:mdna:120]
The Company’s federal income tax returns and certain non-U.S. income tax returns for various fiscal years remain under various stages of audit by the IRS and respective non-U.S. tax authorities. Although the outcome of tax audits is always uncertain, management believes that it has appropriate support for the positions taken on its tax returns and that its annual tax provisions included amounts sufficient to pay assessments, if any, which may be proposed by the taxing authorities. At September 30, 2016, the Company had recorded a liability for its best estimate of the probable loss on certain of its tax positions, the majority of which is included in other noncurrent liabilities in the consolidated statements of financial position. Nonetheless, the amounts ultimately paid, if any, upon resolution of the issues raised by the taxing authorities may differ materially from the amounts accrued for each year.

[0000833444-17-000060:mdna:121]
Other Tax Matters

[0000833444-17-000060:mdna:122]
During fiscal 2016 and 2015, the Company incurred significant charges for restructuring and impairment costs. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. A substantial portion of these charges do not generate a tax benefit due to the Company's current tax position in these jurisdictions and the underlying tax basis in the impaired assets, resulting in $28 million incremental tax expense in fiscal 2016.

[0000833444-17-000060:mdna:123]
During the fourth quarter of fiscal 2016, the Company completed its merger with Tyco. As a result of that transaction, the Company incurred incremental tax expense of $137 million. In preparation for the spin-off of the Automotive Experience business in the first quarter of fiscal 2017, the Company incurred incremental tax expense for continuing operations of $26 million in fiscal 2016.

[0000833444-17-000060:mdna:124]
Impacts of Tax Legislation and Change in Statutory Tax Rates

[0000833444-17-000060:mdna:125]
After the fourth quarter of fiscal 2016, on October 13, 2016, the U.S. Treasury and the IRS released final and temporary Section 385 regulations. These regulations address whether certain instruments between related parties are treated as debt or equity. The Company does not expect that the regulations will have a material impact on its consolidated financial statements.

[0000833444-17-000060:mdna:126]
The "look-through rule," under subpart F of the U.S. Internal Revenue Code, expired for the Company on September 30, 2015. The "look-through rule" had provided an exception to the U.S. taxation of certain income generated by foreign subsidiaries. The rule was extended in December 2015 retroactive to the beginning of the Company’s 2016 fiscal year. The retroactive extension was signed into legislation and was made permanent through the Company's 2020 fiscal year.

[0000833444-17-000060:mdna:127]
In the second quarter of fiscal 2015, tax legislation was adopted in Japan which reduced its statutory income tax rate. As a result of the law change, the Company recorded income tax expense of $17 million in the second quarter of fiscal 2015.

[0000833444-17-000060:mdna:128]
During the fiscal years ended 2016 and 2015, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-17-000060:mdna:129]
41

[0000833444-17-000060:mdna:130]
Income (Loss) From Discontinued Operations, Net of Tax

[0000833444-17-000060:mdna:131]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Income (loss) from discontinued operations, net of tax | $ | (1,516 | ) |  | $ | 819 |  |  | * |

[0000833444-17-000060:mdna:132]
* Measure not meaningful

[0000833444-17-000060:mdna:133]
Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-17-000060:mdna:134]
Income Attributable to Noncontrolling Interests

[0000833444-17-000060:mdna:135]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 132 |  |  | $ | 46 |  |  | * |  |
| Income from discontinued operations attributable to noncontrolling interests | 84 |  |  | 70 |  |  | 20 | % |

[0000833444-17-000060:mdna:136]
* Measure not meaningful

[0000833444-17-000060:mdna:137]
The increase in income from continuing operations attributable to noncontrolling interests for fiscal 2016 was primarily due to current year income related to the JCH joint venture in the Building Technologies & Solutions business.

[0000833444-17-000060:mdna:138]
Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

[0000833444-17-000060:mdna:139]
Net Income (Loss) Attributable to Johnson Controls

[0000833444-17-000060:mdna:140]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Net income (loss) attributable to Johnson Controls | $ | (868 | ) |  | $ | 1,563 |  |  | * |

[0000833444-17-000060:mdna:141]
* Measure not meaningful

[0000833444-17-000060:mdna:142]
The decrease in net income (loss) attributable to Johnson Controls was primarily due to a net loss from discontinued operations, higher SG&A primarily due to higher transaction costs in the current year, an increase in the income tax provision, and current year restructuring and impairment costs, partially offset by higher gross profit. Fiscal 2016 diluted earnings (loss) per share attributable to Johnson Controls was ($1.29) compared to $2.36 in fiscal 2015.

[0000833444-17-000060:mdna:143]
Comprehensive Income (Loss) Attributable to Johnson Controls

[0000833444-17-000060:mdna:144]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Comprehensive income (loss) attributable to Johnson Controls | $ | (964 | ) |  | $ | 743 |  |  | * |

[0000833444-17-000060:mdna:145]
* Measure not meaningful

[0000833444-17-000060:mdna:146]
The decrease in comprehensive income (loss) attributable to Johnson Controls was due to lower net income (loss) attributable to Johnson Controls ($2,431 million), partially offset by a decrease in other comprehensive loss attributable to Johnson Controls ($724 million) primarily related to favorable foreign currency translation adjustments. These year-over-year favorable foreign currency translation adjustments were primarily driven by the weakening of the Brazilian real, Canadian dollar, Colombian peso, euro and Japanese currencies against the U.S. dollar in the prior year.

[0000833444-17-000060:mdna:147]
Segment Analysis

[0000833444-17-000060:mdna:148]
Management evaluates the performance of its business units based primarily on segment EBITA, which is defined as income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, significant restructuring and impairment costs, and net mark-to-market adjustments on pension and postretirement plans.

[0000833444-17-000060:mdna:149]
Building Technologies & Solutions

[0000833444-17-000060:mdna:150]
|  | Net Salesfor the Year EndedSeptember 30, |  |  |  | Segment EBITAfor the Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |  | 2016 |  | 2015 |  | Change |
| Building Solutions North America | $ | 4,687 |  |  | $ | 4,270 |  |  | 10 | % |  | $ | 494 |  |  | $ | 416 |  |  | 19 | % |
| Building Solutions EMEA/LA | 1,613 |  |  | 1,549 |  |  | 4 | % |  | 74 |  |  | 45 |  |  | 64 | % |
| Building Solutions Asia Pacific | 1,736 |  |  | 1,651 |  |  | 5 | % |  | 222 |  |  | 211 |  |  | 5 | % |
| Global Products | 6,148 |  |  | 3,040 |  |  | * |  |  | 637 |  |  | 414 |  |  | 54 | % |
|  | $ | 14,184 |  |  | $ | 10,510 |  |  | 35 | % |  | $ | 1,427 |  |  | $ | 1,086 |  |  | 31 | % |

[0000833444-17-000060:mdna:151]
* Measure not meaningful

[0000833444-17-000060:mdna:152]
Net Sales:

[0000833444-17-000060:mdna:153]
| • | The increase in Building Solutions North America was due to incremental sales related to the Tyco Merger ($335 million), and higher volumes of controls systems and service ($172 million), partially offset by lower volumes related to business divestitures ($52 million), the unfavorable impact of foreign currency translation ($23 million) and the impact of nonrecurring purchase accounting adjustments ($15 million). The increase in volumes was primarily attributable to market share gains. |

[0000833444-17-000060:mdna:154]
| • | The increase in Building Solutions EMEA/LA was due to incremental sales related to the Tyco Merger ($195 million) and incremental sales related to a business acquisition ($7 million), partially offset by the unfavorable impact of foreign currency translation ($77 million), lower volumes ($56 million) and the impact of nonrecurring purchase accounting adjustments ($5 million). The net decrease in volumes was primarily attributable to unfavorable local market conditions. |

[0000833444-17-000060:mdna:155]
| • | The increase in Building Solutions Asia Pacific was due to incremental sales related to the Tyco Merger ($68 million) and higher volumes ($65 million), partially offset by the unfavorable impact of foreign currency translation ($48 million). The increase in volumes was primarily driven favorable local economic conditions. |

[0000833444-17-000060:mdna:156]
| • | The increase in Global Products was due to incremental sales related to the JCH joint venture ($2,808 million), incremental sales related to the Tyco Merger ($230 million) and higher volumes ($85 million), partially offset by the unfavorable impact of foreign currency translation ($15 million). The increase in volume was driven by new product offerings. |

[0000833444-17-000060:mdna:157]
Segment EBITA:

[0000833444-17-000060:mdna:158]
| • | The increase in Building Solutions North America was due to incremental income related to the Tyco Merger ($54 million), higher volumes ($38 million), lower selling, general and administrative expenses ($34 million) as a result of restructuring actions and other cost reduction initiatives and a current year gain on business divestiture net of a prior year gain on business divestitures, and prior year transaction and integration costs ($4 million), partially offset by the impact of nonrecurring purchase accounting adjustments ($28 million), unfavorable margin rates ($13 million), lower income due to a prior year business divestiture ($5 million), the unfavorable impact of foreign currency translation ($3 million), a pension settlement loss ($2 million), and current year transaction and integration costs ($1 million). |

[0000833444-17-000060:mdna:159]
| • | The increase in Building Solutions EMEA/LA was due to incremental income related to the Tyco Merger ($24 million), favorable margin rates ($22 million), lower selling, general and administrative expenses ($10 million), and prior year transaction and integration costs ($1 million), partially offset by lower volumes ($12 million), the impact of nonrecurring purchase accounting adjustments ($10 million), lower equity income ($3 million), the unfavorable impact of foreign currency translation ($2 million), and current year transaction and integration costs ($1 million). |

[0000833444-17-000060:mdna:160]
| • | The increase in Building Solutions Asia Pacific was due to lower selling, general and administrative expenses ($20 million), higher volumes ($16 million), incremental income related to the Tyco Merger ($6 million), and prior year transaction and integration costs ($1 million), partially offset by unfavorable margin rates ($22 million), the unfavorable impact of foreign currency translation ($8 million) and the impact of nonrecurring purchase accounting adjustments ($2 million). |

[0000833444-17-000060:mdna:161]
| • | The increase in Global Products was due to incremental income related to the JCH joint venture exclusive of global investments in related products and technologies ($307 million), incremental income related to the Tyco Merger ($51 million), higher volumes ($32 million), prior year transaction and integration costs ($31 million), a gain on a partially-owned affiliate ($4 million) and higher equity income ($1 million), partially offset by higher selling, general and administrative expenses ($116 million) due to global product and related sales force investments and a prior year gain on business divestitures, current year transaction and integration costs ($35 million), nonrecurring purchase accounting adjustments ($29 million), unfavorable margin rates ($16 million), the unfavorable impact of foreign currency translation ($4 million) and a pension settlement loss ($3 million). |

[0000833444-17-000060:mdna:162]
Power Solutions

[0000833444-17-000060:mdna:163]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2016 |  | 2015 |  | Change |
| Net sales | $ | 6,653 |  |  | $ | 6,590 |  |  | 1 | % |
| Segment EBITA | 1,327 |  |  | 1,241 |  |  | 7 | % |

[0000833444-17-000060:mdna:164]
| • | Net sales increased due to higher sales volumes ($246 million), and favorable pricing and product mix ($105 million), partially offset by the unfavorable impact of foreign currency translation ($180 million) and the impact of lower lead costs on pricing ($108 million). The increase in volumes was primarily driven by start-stop battery volumes and growth in China. Additionally, higher start-stop volumes contributed to favorable product mix. |

[0000833444-17-000060:mdna:165]
| • | Segment EBITA increased due to higher volumes ($77 million), favorable pricing and product mix ($55 million), and lower selling, general and administrative expenses due to lower employee related expenses and cost reduction initiatives ($41 million), partially offset by higher operating costs primarily driven by efforts to increase supply to satisfy growing customer demand and launch new capacity in China ($48 million), the unfavorable impact of foreign currency translation ($29 million), restructuring and impairment costs included in equity income ($7 million), a pension settlement loss ($1 million), transaction costs ($1 million) and lower equity income ($1 million). |

[0000833444-17-000060:mdna:166]
GOODWILL, LONG-LIVED ASSETS AND OTHER INVESTMENTS

[0000833444-17-000060:mdna:167]
Goodwill at September 30, 2017 was $19.7 billion, $1.3 billion lower than the prior year. The decrease was primarily due to business divestitures.

[0000833444-17-000060:mdna:168]
Goodwill reflects the cost of an acquisition in excess of the fair values assigned to identifiable net assets acquired. The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s reportable segments or one level below the reportable segments in certain instances, using a fair value method based on management’s judgments and assumptions or third party valuations. The fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. In estimating the fair value, the Company uses multiples of earnings based on the average of historical, published multiples of earnings of comparable entities with similar operations and economic characteristics. In certain instances, the Company uses discounted cash flow analyses or estimated sales price to further support the fair value estimates. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The estimated

[0000833444-17-000060:mdna:169]
44

[0000833444-17-000060:mdna:170]
fair value is then compared with the carrying amount of the reporting unit, including recorded goodwill. The Company is subject to financial statement risk to the extent that the carrying amount exceeds the estimated fair value.

[0000833444-17-000060:mdna:171]
The assumptions included in the impairment tests require judgment, and changes to these inputs could impact the results of the calculations. Other than management's projections of future cash flows, the primary assumptions used in the impairment tests were the weighted-average cost of capital and long-term growth rates. Although the Company's cash flow forecasts are based on assumptions that are considered reasonable by management and consistent with the plans and estimates management is using to operate the underlying businesses, there are significant judgments in determining the expected future cash flows attributable to a reporting unit.

[0000833444-17-000060:mdna:172]
Indefinite-lived other intangible assets are also subject to at least annual impairment testing. A considerable amount of management judgment and assumptions are required in performing the impairment tests. While the Company believes the judgments and assumptions used in the impairment tests are reasonable and no impairments of goodwill or indefinite-lived assets existed during fiscal years 2017, 2016 and 2015, different assumptions could change the estimated fair values and, therefore, impairment charges could be required, which could be material to the consolidated financial statements.

[0000833444-17-000060:mdna:173]
The Company reviews long-lived assets, including property, plant and equipment and other intangible assets with definite lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets" and ASC 985-20, "Costs of software to be sold, leased, or marketed." ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. ASC 985-20 requires the unamortized capitalized costs of a computer software product be compared to the net realizable value of that product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset shall be written off.

[0000833444-17-000060:mdna:174]
In fiscal 2017, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2017. As a result, the Company reviewed the long-lived assets for impairment and recorded $77 million of asset impairment charges within restructuring and impairment costs on the consolidated statements of income. Of the total impairment charges, $30 million related to the Building Solutions North America segment, $20 million related to the Global Products segment, $19 million related to Corporate assets, $7 million related to the Power Solutions segment and $1 million related to the Building Solutions Asia Pacific segment. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-17-000060:mdna:175]
In the second, third and fourth quarters of fiscal 2016, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2016. As a result, the Company reviewed the long-lived assets for impairment and recorded $103 million of asset impairment charges within restructuring and impairment costs on the consolidated statements of income. Of the total impairment charges, $64 million related to the Power Solutions segment, $24 million related to Corporate assets, $8 million related to the Global Products segment, $4 million related to the Building Solutions Asia Pacific segment and $3 million related to the Building Solutions EMEA/LA segment.  In addition, the Company recorded $87 million of asset impairments within discontinued operations related to Adient in fiscal 2016. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-17-000060:mdna:176]
In the fourth quarter of fiscal 2015, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its announced restructuring actions and the intention to spin-off the Automotive Experience business. As a result, the Company reviewed the long-lived assets for impairment and recorded a $156 million impairment charge within restructuring and impairment costs on the consolidated statements of income. Of the total impairment charge, $139 million related to Corporate assets, $16 million related to the Building Solutions EMEA/LA segment and $1 million

[0000833444-17-000060:mdna:177]
45

[0000833444-17-000060:mdna:178]
related to the Building Solutions North America segment.  In addition, the Company recorded $27 million of asset impairments within discontinued operations related to Adient in fiscal 2015. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairment was measured, depending on the asset, either under an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-17-000060:mdna:179]
Investments in partially-owned affiliates ("affiliates") at September 30, 2017 were $1.2 billion, $0.2 billion higher than the prior year. The increase was primarily due to equity income from partially-owned affiliates in the Power Solutions business and the  JCH joint venture.

[0000833444-17-000060:mdna:180]
LIQUIDITY AND CAPITAL RESOURCES

[0000833444-17-000060:mdna:181]
Working Capital

[0000833444-17-000060:mdna:182]
|  | September 30, 2017 |  | September 30, 2016 |  |  |
| (in millions) |  |  | Change |
| Current assets | $ | 12,292 |  |  | $ | 17,109 |  |  |  |
| Current liabilities | (11,854 | ) |  | (16,331 | ) |  |  |
|  | 438 |  |  | 778 |  |  | -44 | % |
| Less: Cash | (321 | ) |  | (579 | ) |  |  |
| Add: Short-term debt | 1,214 |  |  | 1,078 |  |  |  |
| Add: Current portion of long-term debt | 394 |  |  | 628 |  |  |  |
| Less: Assets held for sale | (189 | ) |  | (5,812 | ) |  |  |
| Add: Liabilities held for sale | 72 |  |  | 4,276 |  |  |  |
| Working capital (as defined) | $ | 1,608 |  |  | $ | 369 |  |  | * |  |
| Accounts receivable | $ | 6,666 |  |  | $ | 6,394 |  |  | 4 | % |
| Inventories | 3,209 |  |  | 2,888 |  |  | 11 | % |
| Accounts payable | 4,271 |  |  | 4,000 |  |  | 7 | % |

[0000833444-17-000060:mdna:183]
* Measure not meaningful

[0000833444-17-000060:mdna:184]
| • | The Company defines working capital as current assets less current liabilities, excluding cash, short-term debt, the current portion of long-term debt, and the current portion of assets and liabilities held for sale. Management believes that this measure of working capital, which excludes financing-related items and businesses to be divested, provides a more useful measurement of the Company’s operating performance. |

[0000833444-17-000060:mdna:185]
| • | The increase in working capital at September 30, 2017 as compared to September 30, 2016, was primarily due to current year income tax payments related to the Adient-spin off, an increase in inventory to meet anticipated customer demand and an increase in accounts receivable due to timing of customer receipts, partially offset by an increase in accounts payable due to timing and mix of supplier payments. |

[0000833444-17-000060:mdna:186]
| • | The Company’s days sales in accounts receivable at September 30, 2017 were 65, a slight increase from 63 at September 30, 2016. There has been no significant adverse change in the level of overdue receivables or changes in revenue recognition methods. Increased volumes in certain of the segments contributed to the increase. |

[0000833444-17-000060:mdna:187]
| • | The Company’s inventory turns for the year ended September 30, 2017 were lower than the comparable period ended September 30, 2016 primarily due to a build of Power Solutions inventory levels to meet customer demand. |

[0000833444-17-000060:mdna:188]
| • | Days in accounts payable at September 30, 2017 were 73 days, higher than 69 days at the comparable period ended September 30, 2016. |

[0000833444-17-000060:mdna:189]
46

[0000833444-17-000060:mdna:190]
Cash Flows

[0000833444-17-000060:mdna:191]
|  | Year Ended September 30, |
| (in millions) | 2017 |  | 2016 |
| Cash provided by operating activities | $ | 12 |  |  | $ | 1,895 |  |
| Cash used by investing activities | (1,137 | ) |  | (887 | ) |
| Cash provided (used) by financing activities | 717 |  |  | (933 | ) |
| Capital expenditures | (1,343 | ) |  | (1,249 | ) |

[0000833444-17-000060:mdna:192]
| • | The decrease in cash provided by operating activities was primarily due to higher income tax payments related to the Adient spin-off ($1.2 billion in the first quarter of fiscal 2017) and the movement in trade working capital balances. |

[0000833444-17-000060:mdna:193]
| • | The increase in cash used by investing activities was primarily due to cash acquired in the Tyco Merger in the prior year and an increase in capital expenditures, partially offset by cash received from business divestitures in the current year. |

[0000833444-17-000060:mdna:194]
| • | The increase in cash provided by financing activities was primarily due to the net dividend proceeds from the Adient spin-off, an increase in long-term debt and higher dividends paid to noncontrolling interests related to the JCH joint venture in the prior year, partially offset by a net decrease in short-term debt borrowings. |

[0000833444-17-000060:mdna:195]
| • | The increase in capital expenditures in the current year is primarily related to higher capital investments in the current year in the Building Technologies & Solutions and Power Solutions businesses, partially offset by lower capital investments in the Automotive Experience business due to the Adient spin-off. |

[0000833444-17-000060:mdna:196]
Capitalization

[0000833444-17-000060:mdna:197]
|  | September 30, 2017 |  | September 30, 2016 |  |  |
| (in millions) |  |  | Change |
| Short-term debt | $ | 1,214 |  |  | $ | 1,078 |  |  |  |
| Current portion of long-term debt | 394 |  |  | 628 |  |  |  |
| Long-term debt | 11,964 |  |  | 11,053 |  |  |  |
| Total debt | $ | 13,572 |  |  | $ | 12,759 |  |  | 6 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 20,447 |  |  | 24,118 |  |  | -15 | % |
| Total capitalization | $ | 34,019 |  |  | $ | 36,877 |  |  | -8 | % |
| Total debt as a % of total capitalization | 40 | % |  | 35 | % |  |  |

[0000833444-17-000060:mdna:198]
| • | The Company believes the percentage of total debt to total capitalization is useful to understanding the Company’s financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders. |

[0000833444-17-000060:mdna:199]
| • | Shareholders' equity attributable to Johnson Controls ordinary shareholders decreased as a result of the Adient spin-off in October 2016. Refer to Note 5, "Discontinued Operations," of the notes to consolidated financial statements for further information. |

[0000833444-17-000060:mdna:200]
| • | In connection with the Tyco Merger, on December 28, 2016, the Company completed its offers to exchange all validly tendered and accepted notes of certain series (the existing notes) issued by JCI Inc. or Tyco International Finance S.A. ("TIFSA"), as applicable, each of which is a wholly owned subsidiary of the Company, for new notes (the "New Notes") to be issued by the Company, and the related solicitation of consents to amend the indentures governing the existing notes (the offers to exchange and the related consent solicitation together the "exchange offers"). Pursuant to the exchange offers, the Company exchanged approximately $5.6 billion of $6.0 billion in aggregate principal amount of dollar denominated notes and approximately 423 million euro of 500 million euro in aggregate principal amount of euro denominated notes. All validly tendered and accepted existing notes have been canceled. Immediately following such cancellation, $380.9 million aggregate principal amount of existing notes (not including the TIFSA Euro Notes) remained outstanding across seventeen series of dollar-denominated existing notes and 77.4 million euro aggregate principal amount of TIFSA Euro Notes remained outstanding across one series. In connection with the settlement of the exchange offers, the New Notes |

[0000833444-17-000060:mdna:201]
47

[0000833444-17-000060:mdna:202]
were registered under the Securities Act of 1933 and their terms are described in the Company’s Prospectus dated December 19, 2016, as filed with the SEC under Rule 424(b)(3) of the Act on that date. The issuance of the New Notes occurred on December 28, 2016. The New Notes are unsecured and unsubordinated obligations of the Company and rank equally with all other unsecured and unsubordinated indebtedness of the Company issued from time to time.

[0000833444-17-000060:mdna:203]
| • | In connection with the Tyco Merger on September 2, 2016, JCI Inc., a wholly owned subsidiary of the Company, replaced its $2.5 billion committed five-year credit facility scheduled to mature in August 2018 with a $2.0 billion committed four-year credit facility scheduled to expire in August 2020. Also, in connection with the Tyco Merger on September 2, 2016, Tyco International Holding S.à.r.l ("TSarl"), a wholly owned subsidiary of the Company, entered into a four-year, $1.0 billion revolving credit agreement scheduled to expire in August 2020. The facilities are used to support the Company’s outstanding commercial paper. There were no draws on either committed credit facility during the fiscal year ended September 30, 2017. |

[0000833444-17-000060:mdna:204]
| • | Simultaneously with the closing of the Tyco Merger on September 2, 2016, TSarl borrowed $4.0 billion under the Term Loan Credit Agreement dated as of March 10, 2016 with a syndicate of lenders, providing for a three and a half year senior unsecured term loan facility to finance the cash consideration for, and fees, expenses and costs incurred in connection with the Merger. During fiscal 2017, the Company partially repaid $300 million of the $4.0 billion floating rate term loan scheduled to expire in March 2020. As of September 30, 2017, the outstanding term loan balance was $3.7 billion. In October 2017, the Company completed the previously announced sale of its Scott Safety business to 3M, and net cash proceeds from the transaction of $1.9 billion were used to further repay a significant portion of the $4.0 billion term loan. |

[0000833444-17-000060:mdna:205]
| • | At September 30, 2017, the Company had committed bilateral U.S. dollar denominated revolving credit facilities totaling $550 million, which are scheduled to expire in fiscal 2018. There were no draws on any of these revolving facilities as of September 30, 2017. |

[0000833444-17-000060:mdna:206]
| • | In September 2017, the Company entered into a 364-day 150 million euro, floating rate, term loan scheduled to expire in September 2018. Proceeds from the loan were used for general corporate purposes. |

[0000833444-17-000060:mdna:207]
| • | In September 2017, the Company entered into five-year 35 billion yen syndicated floating rate term loan scheduled to expire in September 2022. Proceeds from the loan were used for general corporate purposes. |

[0000833444-17-000060:mdna:208]
| • | In July 2017, the Company retired $150 million in principal amount, plus accrued interest, of its 7.125% fixed rate notes that expired in July 2017. |

[0000833444-17-000060:mdna:209]
| • | In July 2017, the Company repurchased, at a discount, 4 million euro of its TIFSA 1.375% fixed rate notes, plus accrued interest, scheduled to expire in 2025. |

[0000833444-17-000060:mdna:210]
| • | In March 2017, the Company issued one billion euro in principal amount of 1.0% senior unsecured fixed rate notes due in fiscal 2023. Proceeds from the issuance were used to repay existing debt and for other general corporate purposes. |

[0000833444-17-000060:mdna:211]
| • | In March 2017, the Company entered into a 364-day $150 million committed revolving credit facility scheduled to expire in March 2018. As of September 30, 2017, there were no draws on the facility. |

[0000833444-17-000060:mdna:212]
| • | In March 2017, the Company retired $46 million in principal amount, plus accrued interest, of its 2.355% fixed rate notes that expired in March 2017. |

[0000833444-17-000060:mdna:213]
| • | In March 2017 and February 2017, the Company repurchased, at a discount, 15 million euro of its TIFSA 1.375% fixed rate notes, plus accrued interest, scheduled to expire in February 2025. |

[0000833444-17-000060:mdna:214]
| • | In February 2017, the Company issued $500 million aggregate principal amount of 4.5% senior unsecured fixed rate notes due in fiscal 2047. Proceeds from the issuance were used to repay outstanding commercial paper borrowings and for other general corporate purposes. |

[0000833444-17-000060:mdna:215]
| • | In February 2017, the Company entered into a 364-day $150 million committed revolving credit facility scheduled to expire in February 2018. As of September 30, 2017, there were no draws on the facility. |

[0000833444-17-000060:mdna:216]
| • | In January 2017, the Company entered into a 364-day $250 million committed revolving credit facility scheduled to expire in January 2018. As of September 30, 2017, there were no draws on the facility. |

[0000833444-17-000060:mdna:217]
| • | In December 2016, the Company retired $400 million in principal amount, plus accrued interest, of its 2.6% fixed rate notes that expired in December 2016. |

[0000833444-17-000060:mdna:218]
| • | In December 2016, the Company entered into a 364-day 100 million euro floating rate term loan scheduled to mature in December 2017. Proceeds from the term loan were used for general corporate purposes. Principal and accrued interest were fully repaid in March 2017. |

[0000833444-17-000060:mdna:219]
| • | In December 2016, a $100 million committed revolving credit facility expired. There were no draws on the facility. |

[0000833444-17-000060:mdna:220]
| • | In November 2016, the Company fully repaid its 37 billion yen syndicated floating rate term loan, plus accrued interest, scheduled to expire in June 2020. |

[0000833444-17-000060:mdna:221]
| • | In November 2016, a $35 million committed revolving credit facility expired. There were no draws on the facility. |

[0000833444-17-000060:mdna:222]
| • | In October 2016, the Company repaid two ten-month floating rate term loans totaling $325 million, plus accrued interest, scheduled to expire in October 2016. |

[0000833444-17-000060:mdna:223]
| • | In October 2016, the Company repaid a nine-month $100 million floating rate term loan, plus accrued interest, scheduled to expire in November 2016. |

[0000833444-17-000060:mdna:224]
| • | In October 2016, the Company repaid a nine-month 100 million euro floating rate term loan, plus accrued interest, scheduled to expire in October 2016. |

[0000833444-17-000060:mdna:225]
| • | The Company also selectively makes use of short-term credit lines other than its revolving credit facilities at the Company and TSarl. The Company estimates that, as of September 30, 2017, it could borrow up to $1.4 billion based on average borrowing levels during the year on committed credit lines. |

[0000833444-17-000060:mdna:226]
| • | The Company believes its capital resources and liquidity position at September 30, 2017 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, stock repurchases, minimum pension contributions, debt maturities and any potential acquisitions in fiscal 2018 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company and TSarl are unable to issue commercial paper, they would have the ability to draw on their $2.0 billion and $1.0 billion revolving credit facilities, respectively. Both facilities mature in August 2020. There were no draws on the revolving credit facilities as of September 30, 2017. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future. |

[0000833444-17-000060:mdna:227]
| • | The Company earns a significant amount of its operating income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances. However, in fiscal 2017, the Company provided income tax expense related to a change in the Company’s assertion over the outside basis difference of the Scott Safety business as a result of the pending divestiture as well as the outside basis of certain nonconsolidated subsidiaries. In addition, in fiscal 2016, the Company provided income tax expense related to a change in the Company's assertion over a portion of the permanently reinvested earnings as a result of the planned spin-off of the Automotive Experience business. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. Except as noted, the Company’s intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at the Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings. |

[0000833444-17-000060:mdna:228]
49

[0000833444-17-000060:mdna:229]
| • | The Company’s debt financial covenant in its revolving credit facility requires a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. TSarl's revolving credit facility contains customary terms and conditions, and a financial covenant that limits the ratio of TSarl's debt to earnings before interest, taxes, depreciation, and amortization as adjusted for certain items set forth in the agreement to 3.5x. TSarl's revolving credit facility also limits its ability to incur subsidiary debt or grant liens on its and its subsidiaries' property. As of September 30, 2017, the Company and TSarl were in compliance with all covenants and other requirements set forth in their credit agreements and the indentures, governing their notes, and expect to remain in compliance for the foreseeable future. None of the Company’s or TSarl's debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the respective borrower's credit rating. |

[0000833444-17-000060:mdna:230]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2017 and recorded $367 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2017 restructuring plan will reduce annual operating costs from continuing operations by approximately $280 million, which is primarily the result of lower cost of sales and selling, general and administrative expenses due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in fiscal 2018. For fiscal 2017, the savings, net of execution costs, were approximately 40% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in fiscal 2018. The restructuring plan reserve balance of $239 million at September 30, 2017 is expected to be paid in cash. |

[0000833444-17-000060:mdna:231]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations to address the softness in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2016 and recorded $288 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments and change-in-control payments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2016 restructuring plan will reduce annual operating costs from continuing operations by approximately $135 million, which is primarily the result of lower cost of sales and selling, general and administrative expenses due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized by the end of fiscal 2018. For fiscal 2017, the savings, net of execution costs, were approximately 35% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in fiscal 2018. The restructuring plan reserve balance of $92 million at September 30, 2017 is expected to be paid in cash. |

[0000833444-17-000060:mdna:232]
A summary of the Company’s significant contractual obligations for continuing operations as of September 30, 2017 is as follows (in millions):

[0000833444-17-000060:mdna:233]
|  | Total |  | 2018 |  | 2019-2020 |  | 2021-2022 |  | 2023and Beyond |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Long-term debt(including capital lease obligations)* | $ | 12,403 |  |  | $ | 394 |  |  | $ | 4,228 |  |  | $ | 1,305 |  |  | $ | 6,476 |  |
| Interest on long-term debt(including capital lease obligations)* | 5,731 |  |  | 413 |  |  | 752 |  |  | 503 |  |  | 4,063 |  |
| Operating leases | 954 |  |  | 315 |  |  | 397 |  |  | 157 |  |  | 85 |  |
| Purchase obligations | 2,334 |  |  | 1,830 |  |  | 373 |  |  | 125 |  |  | 6 |  |
| Pension and postretirement contributions | 447 |  |  | 64 |  |  | 76 |  |  | 79 |  |  | 228 |  |
| Tax indemnification liabilities** | 301 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total contractual cash obligations | $ | 22,170 |  |  | $ | 3,016 |  |  | $ | 5,826 |  |  | $ | 2,169 |  |  | $ | 10,858 |  |

[0000833444-17-000060:mdna:234]
50

[0000833444-17-000060:mdna:235]
* Refer to Note 9, "Debt and Financing Arrangements," of the notes to consolidated financial statements for information related to the Company's long-term debt.

[0000833444-17-000060:mdna:236]
** As a result of the Tyco Merger in the fourth quarter of fiscal 2016, the Company recorded as part of the acquired liabilities of Tyco $290 million of post sale contingent tax indemnification liabilities which is generally recorded within other noncurrent liabilities in the consolidated statements of financial position. The liabilities are recorded at fair value and relate to certain tax related matters borne by the buyer of previously divested subsidiaries of Tyco which Tyco has indemnified certain parties and the amounts are probable of being paid. Of the $290 million recorded as of September 30, 2017 and 2016, $255 million is related to prior divested businesses and the remainder relates to Tyco’s tax sharing agreements from its 2007 and 2012 spin-off transactions.  The payments due by period are not presented due to uncertainty as to when these liabilities will be settled or paid. These are certain guarantees or indemnifications extended among Tyco, Medtronic, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 separation and tax sharing agreements. In addition, the Company has recorded $11 million of tax indemnification liabilities as of September 30, 2017 related to other divestitures.

[0000833444-17-000060:mdna:237]
CRITICAL ACCOUNTING ESTIMATES AND POLICIES

[0000833444-17-000060:mdna:238]
The Company prepares its consolidated financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). This requires management to make estimates and assumptions that affect reported amounts and related disclosures. Actual results could differ from those estimates. The following policies are considered by management to be the most critical in understanding the judgments that are involved in the preparation of the Company’s consolidated financial statements and the uncertainties that could impact the Company’s results of operations, financial position and cash flows.

[0000833444-17-000060:mdna:239]
Revenue Recognition

[0000833444-17-000060:mdna:240]
The Building Technologies & Solutions business recognizes revenue from certain long-term contracts over the contractual period under the percentage-of-completion ("POC") method of accounting. This method of accounting recognizes sales and gross profit as work is performed based on the relationship between actual costs incurred and total estimated costs at completion. Recognized revenues that will not be billed under the terms of the contract until a later date are recorded primarily in accounts receivable. Likewise, contracts where billings to date have exceeded recognized revenues are recorded primarily in other current liabilities. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. Sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. Claims against customers are recognized as revenue upon settlement. The use of the POC method of accounting involves considerable use of estimates in determining revenues, costs and profits and in assigning the amounts to accounting periods. The periodic reviews have not resulted in adjustments that were significant to the Company’s results of operations. The Company continually evaluates all of the assumptions, risks and uncertainties inherent with the application of the POC method of accounting.

[0000833444-17-000060:mdna:241]
The Building Technologies & Solutions business enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized on a straight-line basis over the respective contract term.

[0000833444-17-000060:mdna:242]
The Building Technologies & Solutions business also sells certain heating, ventilating and air conditioning ("HVAC") and refrigeration products and services in bundled arrangements, where multiple products and/or services are involved. Significant deliverables within these arrangements include equipment, commissioning, service labor and extended warranties. Approximately four to twelve months separate the timing of the first deliverable until the last piece of equipment is delivered, and there may be extended warranty arrangements with duration of one to five years commencing upon the end of the standard warranty period. In addition, the Buildings business sells security monitoring systems that may have multiple elements, including equipment, installation, monitoring services and maintenance agreements. Revenues associated with sale of equipment and related installations are recognized once delivery, installation and customer acceptance is completed, while the revenue for monitoring and maintenance services are recognized as services are rendered. In accordance with ASU No. 2009-13, "Revenue Recognition (Topic 605): Multiple-Deliverable Revenue Arrangements - A Consensus of the FASB Emerging Issues Task Force," the Company divides bundled arrangements into separate deliverables and revenue is allocated to each deliverable based on the relative selling price method. In order to estimate relative selling price, market data and transfer price studies are utilized. Revenue recognized for security monitoring equipment and installation is limited to the lesser of their allocated amounts under the estimated selling price hierarchy or the non-contingent up-front consideration received at the time of installation, since collection of future amounts under the arrangement with the customer is contingent upon the delivery of monitoring and maintenance services. For transactions in which the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized on a straight-line basis over the contract term. Non-refundable fees received in connection with the initiation of a monitoring

[0000833444-17-000060:mdna:243]
51

[0000833444-17-000060:mdna:244]
contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the customer relationship.

[0000833444-17-000060:mdna:245]
In all other cases, the Company recognizes revenue at the time title passes to the customer or as services are performed.

[0000833444-17-000060:mdna:246]
Goodwill and Indefinite-Lived Intangible Assets

[0000833444-17-000060:mdna:247]
Goodwill reflects the cost of an acquisition in excess of the fair values assigned to identifiable net assets acquired. The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s reportable segments or one level below the reportable segments in certain instances, using a fair value method based on management’s judgments and assumptions or third party valuations. The fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. In estimating the fair value, the Company uses multiples of earnings based on the average of historical, published multiples of earnings of comparable entities with similar operations and economic characteristics. In certain instances, the Company uses discounted cash flow analyses or estimated sales price to further support the fair value estimates. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The estimated fair value is then compared with the carrying amount of the reporting unit, including recorded goodwill. The Company is subject to financial statement risk to the extent that the carrying amount exceeds the estimated fair value. Refer to Note 7, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for information regarding the goodwill impairment testing performed in the fourth quarters of fiscal years 2017, 2016 and 2015.

[0000833444-17-000060:mdna:248]
Indefinite-lived intangible assets are also subject to at least annual impairment testing. Indefinite-lived intangible assets consist of trademarks and tradenames and are tested for impairment using a relief-from-royalty method. A considerable amount of management judgment and assumptions are required in performing the impairment tests.

[0000833444-17-000060:mdna:249]
Impairment of Long-Lived Assets

[0000833444-17-000060:mdna:250]
The Company reviews long-lived assets, including tangible assets and other intangible assets with definitive lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets" and ASC 985-20, "Costs of software to be sold, leased, or marketed." ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. ASC 985-20 requires the unamortized capitalized costs of a computer software product be compared to the net realizable value of that product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset shall be written off.  Refer to Note 17, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for information regarding the impairment testing performed in fiscal years 2017, 2016 and 2015.

[0000833444-17-000060:mdna:251]
Employee Benefit Plans

[0000833444-17-000060:mdna:252]
The Company provides a range of benefits to its employees and retired employees, including pensions and postretirement benefits. Plan assets and obligations are measured annually, or more frequently if there is a remeasurement event, based on the Company’s measurement date utilizing various actuarial assumptions such as discount rates, assumed rates of return, compensation increases, turnover rates and health care cost trend rates as of that date. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends when appropriate.

[0000833444-17-000060:mdna:253]
The Company utilizes a mark-to-market approach for recognizing pension and postretirement benefit expenses, including measuring the market related value of plan assets at fair value and recognizing actuarial gains and losses in the fourth quarter of each fiscal year or at the date of a remeasurement event. Refer to Note 15, "Retirement Plans," of the notes to consolidated financial statements for disclosure of the Company's pension and postretirement benefit plans.

[0000833444-17-000060:mdna:254]
U.S. GAAP requires that companies recognize in the statement of financial position a liability for defined benefit pension and postretirement plans that are underfunded or unfunded, or an asset for defined benefit pension and postretirement plans that are overfunded. U.S. GAAP also requires that companies measure the benefit obligations and fair value of plan assets that determine a benefit plan’s funded status as of the date of the employer’s fiscal year end.

[0000833444-17-000060:mdna:255]
The Company considers the expected benefit payments on a plan-by-plan basis when setting assumed discount rates. As a result, the Company uses different discount rates for each plan depending on the plan jurisdiction, the demographics of participants and the expected timing of benefit payments. For the U.S. pension and postretirement plans, the Company uses a discount rate provided by an independent third party calculated based on an appropriate mix of high quality bonds. For the non-U.S. pension and postretirement plans, the Company consistently uses the relevant country specific benchmark indices for determining the various discount rates. The Company’s discount rate on U.S. pension plans was 3.80% and 3.70% at September 30, 2017 and 2016, respectively. The Company’s discount rate on postretirement plans was 3.70% and 3.30% at September 30, 2017 and 2016, respectively. The Company’s weighted average discount rate on non-U.S. pension plans was 2.40% and 1.90% at September 30, 2017 and 2016, respectively.

[0000833444-17-000060:mdna:256]
In estimating the expected return on plan assets, the Company considers the historical returns on plan assets, adjusted for forward-looking considerations, inflation assumptions and the impact of the active management of the plans’ invested assets. Reflecting the relatively long-term nature of the plans’ obligations, approximately 45% of the plans’ assets are invested in equity securities and 44% in fixed income securities, with the remainder primarily invested in alternative investments. For the years ending September 30, 2017 and 2016, the Company’s expected long-term return on U.S. pension plan assets used to determine net periodic benefit cost was 7.50%. The actual rate of return on U.S. pension plans was above 7.50% in both fiscal years 2017 and 2016. For the years ending September 30, 2017 and 2016, the Company’s weighted average expected long-term return on non-U.S. pension plan assets was 4.60% and 4.50%, respectively. The actual rate of return on non-U.S. pension plans was above 4.60% in fiscal year 2017 and above 4.50% in fiscal year 2016. For the years ending September 30, 2017 and 2016, the Company’s weighted average expected long-term return on postretirement plan assets was 5.60% and 5.45%, respectively. The actual rate of return on postretirement plan assets was above 5.60% in fiscal year 2017 and above 5.45% in fiscal year 2016.

[0000833444-17-000060:mdna:257]
Beginning in fiscal 2018, the Company believes the long-term rate of return will approximate 7.50%, 5.35% and 5.65% for U.S. pension, non-U.S. pension and postretirement plans, respectively. Any differences between actual investment results and the expected long-term asset returns will be reflected in net periodic benefit costs in the fourth quarter of each fiscal year or at the date of a remeasurement event. If the Company’s actual returns on plan assets are less than the Company’s expectations, additional contributions may be required.

[0000833444-17-000060:mdna:258]
In fiscal 2017, total employer contributions to the defined benefit pension plans were $342 million, of which $49 million were voluntary contributions made by the Company. The Company expects to contribute approximately $100 million in cash to its defined benefit pension plans in fiscal 2018. In fiscal 2017, total employer contributions to the postretirement plans were $5 million. The Company expects to contribute approximately $5 million in cash to its postretirement plans in fiscal 2018.

[0000833444-17-000060:mdna:259]
Based on information provided by its independent actuaries and other relevant sources, the Company believes that the assumptions used are reasonable; however, changes in these assumptions could impact the Company’s financial position, results of operations or cash flows.

[0000833444-17-000060:mdna:260]
Loss Contingencies

[0000833444-17-000060:mdna:261]
Accruals are recorded for various contingencies including legal proceedings, environmental matters, self-insurance and other claims that arise in the normal course of business. The accruals are based on judgment, the probability of losses and, where applicable, the consideration of opinions of internal and/or external legal counsel and actuarially determined estimates. Additionally, the Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-17-000060:mdna:262]
The Company is subject to laws and regulations relating to protecting the environment. The Company provides for expenses associated with environmental remediation obligations when such amounts are probable and can be reasonably estimated. Refer to Note 23, "Commitments and Contingencies," of the notes to consolidated financial statements.

[0000833444-17-000060:mdna:263]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-17-000060:mdna:264]
Asbestos-Related Contingencies and Insurance Receivables

[0000833444-17-000060:mdna:265]
The Company and certain of its subsidiaries along with numerous other companies are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from

[0000833444-17-000060:mdna:266]
2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-17-000060:mdna:267]
In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable. The Company's estimate of asbestos-related insurance recoveries represents estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims discounted to present value. In determining the amount of insurance recoverable, the Company considers available insurance, allocation methodologies, solvency and creditworthiness of the insurers. Refer to Note 23, "Commitments and Contingencies," of the notes to consolidated financial statements for a discussion on management's judgments applied in the recognition and measurement of asbestos-related assets and liabilities.

[0000833444-17-000060:mdna:268]
Product Warranties

[0000833444-17-000060:mdna:269]
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. A typical warranty program requires that the Company replace defective products within a specified time period from the date of sale. The Company records an estimate of future warranty-related costs based on actual historical return rates and other known factors. Based on analysis of return rates and other factors, the Company’s warranty provisions are adjusted as necessary. At September 30, 2017, the Company had recorded $409 million of warranty reserves for continuing operations, including extended warranties for which deferred revenue is recorded. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different than those estimates. Refer to Note 21, "Guarantees," of the notes to consolidated financial statements for disclosure of the Company's product warranty liabilities.

[0000833444-17-000060:mdna:270]
Income Taxes

[0000833444-17-000060:mdna:271]
The Company accounts for income taxes in accordance with ASC 740, "Income Taxes." Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and other loss carryforwards. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company records a valuation allowance that primarily represents non-U.S. operating and other loss carryforwards for which realization is uncertain. Management judgment is required in determining the Company’s provision for income taxes, deferred tax assets and liabilities, and the valuation allowance recorded against the Company’s net deferred tax assets. In calculating the provision for income taxes on an interim basis, the Company uses an estimate of the annual effective tax rate based upon the facts and circumstances known at each interim period. On a quarterly basis, the actual effective tax rate is adjusted as appropriate based upon the actual results as compared to those forecasted at the beginning of the fiscal year.

[0000833444-17-000060:mdna:272]
The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary. At September 30, 2017, the Company had a valuation allowance of $3.8 billion for continuing operations, of which $3.2 billion relates to net operating loss carryforwards primarily in Australia, Belgium, Brazil, China, France, Spain, Switzerland, Luxembourg and the United Kingdom for which sustainable taxable income has not been demonstrated; and $610 million for other deferred tax assets.

[0000833444-17-000060:mdna:273]
The Company is subject to income taxes in the U.S. and numerous non-U.S. jurisdictions. Judgment is required in determining its worldwide provision for income taxes and recording the related assets and liabilities. In the ordinary course of the Company’s business, there are many transactions and calculations where the ultimate tax determination is uncertain. The Company is regularly under audit by tax authorities. At September 30, 2017, the Company had unrecognized tax benefits of $2.2 billion for continuing operations.

[0000833444-17-000060:mdna:274]
54

[0000833444-17-000060:mdna:275]
The Company does not generally provide additional U.S. or non-U.S. income taxes on outside basis differences of consolidated subsidiaries included in shareholders’ equity attributable to Johnson Controls International plc, except in limited circumstances including anticipated taxation on planned divestitures.  The reduction of the outside basis differences via the sale or liquidation of these subsidiaries and/or distributions could create taxable income.  The Company’s intent is to reduce the outside basis differences only when it would be tax efficient.  Refer to "Capitalization" within the "Liquidity and Capital Resources" section for discussion of U.S. and non-U.S. cash projections.

[0000833444-17-000060:mdna:276]
Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements for the Company's income tax disclosures.

[0000833444-17-000060:mdna:277]
NEW ACCOUNTING PRONOUNCEMENTS

[0000833444-17-000060:mdna:278]
Refer to the "New Accounting Pronouncements" section within Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements.

[0000833444-17-000060:mdna:279]
RISK MANAGEMENT

[0000833444-17-000060:mdna:280]
The Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities, interest rates and stock-based compensation. All hedging transactions are authorized and executed pursuant to clearly defined policies and procedures, which strictly prohibit the use of financial instruments for speculative purposes. At the inception of the hedge, the Company assesses the effectiveness of the hedge instrument and designates the hedge instrument as either (1) a hedge of a recognized asset or liability or of a recognized firm commitment (a fair value hedge), (2) a hedge of a forecasted transaction or of the variability of cash flows to be received or paid related to an unrecognized asset or liability (a cash flow hedge) or (3) a hedge of a net investment in a non-U.S. operation (a net investment hedge). The Company performs hedge effectiveness testing on an ongoing basis depending on the type of hedging instrument used. All other derivatives not designated as hedging instruments under ASC 815, "Derivatives and Hedging," are revalued in the consolidated statements of income.

[0000833444-17-000060:mdna:281]
For all foreign currency derivative instruments designated as cash flow hedges, retrospective effectiveness is tested on a monthly basis using a cumulative dollar offset test. The fair value of the hedged exposures and the fair value of the hedge instruments are revalued, and the ratio of the cumulative sum of the periodic changes in the value of the hedge instruments to the cumulative sum of the periodic changes in the value of the hedge is calculated. The hedge is deemed as highly effective if the ratio is between 80% and 125%. For commodity derivative contracts designated as cash flow hedges, effectiveness is tested using a regression calculation. Ineffectiveness is minimal as the Company aligns most of the critical terms of its derivatives with the supply contracts.

[0000833444-17-000060:mdna:282]
For net investment hedges, the Company assesses its net investment positions in the non-U.S. operations and compares it with the outstanding net investment hedges on a quarterly basis. The hedge is deemed effective if the aggregate outstanding principal of the hedge instruments designated as the net investment hedge in a non-U.S. operation does not exceed the Company’s net investment positions in the respective non-U.S. operation.

[0000833444-17-000060:mdna:283]
The Company selectively uses interest rate swaps to reduce market risk associated with changes in interest rates for its fixed-rate bonds. At September 30, 2017, the Company did not have any outstanding interest rate swaps.  The Company assesses retrospective and prospective effectiveness and records any measured ineffectiveness in the consolidated statements of income on a monthly basis.

[0000833444-17-000060:mdna:284]
Equity swaps and any other derivative instruments not designated as hedging instruments under ASC 815 require no assessment of effectiveness.

[0000833444-17-000060:mdna:285]
A discussion of the Company’s accounting policies for derivative financial instruments is included in Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements, and further disclosure relating to derivatives and hedging activities is included in Note 10, "Derivative Instruments and Hedging Activities," and Note 11, "Fair Value Measurements," of the notes to consolidated financial statements.

[0000833444-17-000060:mdna:286]
Foreign Exchange

[0000833444-17-000060:mdna:287]
The Company has manufacturing, sales and distribution facilities around the world and thus makes investments and enters into transactions denominated in various foreign currencies. In order to maintain strict control and achieve the benefits of the Company’s global diversification, foreign exchange exposures for each currency are netted internally so that only its net foreign exchange exposures are, as appropriate, hedged with financial instruments.

[0000833444-17-000060:mdna:288]
The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. The Company primarily enters into foreign currency exchange contracts to reduce the earnings and cash flow impact of the variation of non-functional currency denominated receivables and payables. Gains and losses resulting from hedging instruments offset the foreign exchange gains or losses on the underlying assets and liabilities being hedged. The maturities of the forward exchange contracts generally coincide with the settlement dates of the related transactions. Realized and unrealized gains and losses on these contracts are recognized in the same period as gains and losses on the hedged items. The Company also selectively hedges anticipated transactions that are subject to foreign exchange exposure, primarily with foreign currency exchange contracts, which are designated as cash flow hedges in accordance with ASC 815.

[0000833444-17-000060:mdna:289]
The Company has entered into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of debt obligations are reflected in the accumulated other comprehensive income ("AOCI") account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally.

[0000833444-17-000060:mdna:290]
At September 30, 2017 and 2016, the Company estimates that an unfavorable 10% change in the exchange rates would have decreased net unrealized gains by approximately $330 million and $297 million, respectively.

[0000833444-17-000060:mdna:291]
Interest Rates

[0000833444-17-000060:mdna:292]
The Company has used interest rate swaps to offset its exposure to interest rate movements. In accordance with ASC 815, these outstanding swaps qualify and are designated as fair value hedges. The Company had no outstanding interest rate swaps at September 30, 2017 and eight interest rates swaps totaling $850 million outstanding at September 30, 2016. A 10% increase in the average cost of the Company’s variable rate debt would have resulted in an unfavorable change in pre-tax interest expense of approximately $13 million and $11 million for the year ended September 30, 2017 and 2016, respectively.

[0000833444-17-000060:mdna:293]
Commodities

[0000833444-17-000060:mdna:294]
The Company uses commodity hedge contracts in the financial derivatives market in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. As a cash flow hedge, gains and losses resulting from the hedging instruments offset the gains or losses on purchases of the underlying commodities that will be used in the business. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities.

[0000833444-17-000060:mdna:295]
ENVIRONMENTAL, HEALTH AND SAFETY AND OTHER MATTERS

[0000833444-17-000060:mdna:296]
The Company’s global operations are governed by environmental laws and worker safety laws. Under various circumstances, these laws impose civil and criminal penalties and fines, as well as injunctive and remedial relief, for noncompliance and require remediation at sites where Company-related substances have been released into the environment.

[0000833444-17-000060:mdna:297]
The Company has expended substantial resources globally, both financial and managerial, to comply with applicable environmental laws and worker safety laws and to protect the environment and workers. The Company believes it is in substantial compliance with such laws and maintains procedures designed to foster and ensure compliance. However, the Company has been, and in the future may become, the subject of formal or informal enforcement actions or proceedings regarding noncompliance with such laws or the remediation of Company-related substances released into the environment. Such matters typically are resolved with regulatory authorities through commitments to compliance, abatement or remediation programs and in some cases payment of penalties. Historically, neither such commitments nor penalties imposed on the Company have been material.

[0000833444-17-000060:mdna:298]
Refer to Note 23, "Commitments and Contingencies," of the notes to consolidated financial statements for additional information.

[0000833444-17-000060:mdna:299]
QUARTERLY FINANCIAL DATA

[0000833444-17-000060:mdna:300]
| (in millions, except per share data)(quarterly amounts unaudited) | FirstQuarter |  | SecondQuarter |  | ThirdQuarter |  | FourthQuarter |  | FullYear |
| 2017 |  |  |  |  |  |  |  |  |  |
| Net sales | $ | 7,086 |  |  | $ | 7,267 |  |  | $ | 7,683 |  |  | $ | 8,136 |  |  | $ | 30,172 |  |
| Gross profit | 2,114 |  |  | 2,281 |  |  | 2,431 |  |  | 2,513 |  |  | 9,339 |  |
| Net income (loss) (1) | 378 |  |  | (115 | ) |  | 629 |  |  | 927 |  |  | 1,819 |  |
| Net income (loss) attributable to Johnson Controls | 329 |  |  | (148 | ) |  | 555 |  |  | 875 |  |  | 1,611 |  |
| Earnings (loss) per share (2) |  |  |  |  |  |  |  |  |  |
| Basic | 0.35 |  |  | (0.16 | ) |  | 0.59 |  |  | 0.94 |  |  | 1.72 |  |
| Diluted | 0.35 |  |  | (0.16 | ) |  | 0.59 |  |  | 0.93 |  |  | 1.71 |  |
| 2016 |  |  |  |  |  |  |  |  |  |
| Net sales | $ | 4,696 |  |  | $ | 4,733 |  |  | $ | 5,154 |  |  | $ | 6,254 |  |  | $ | 20,837 |  |
| Gross profit | 1,257 |  |  | 1,287 |  |  | 1,422 |  |  | 1,688 |  |  | 5,654 |  |
| Net income (loss) (3) | 490 |  |  | (469 | ) |  | 459 |  |  | (1,132 | ) |  | (652 | ) |
| Net income (loss) attributable to Johnson Controls | 450 |  |  | (530 | ) |  | 383 |  |  | (1,171 | ) |  | (868 | ) |
| Earnings (loss) per share (4) |  |  |  |  |  |  |  |  |  |
| Basic | 0.69 |  |  | (0.82 | ) |  | 0.59 |  |  | (1.61 | ) |  | (1.30 | ) |
| Diluted | 0.69 |  |  | (0.81 | ) |  | 0.59 |  |  | (1.61 | ) |  | (1.29 | ) |

[0000833444-17-000060:mdna:301]
| (1) | The fiscal 2017 first quarter net income includes $117 million of mark-to-market gains on pension plans, $78 million of significant restructuring and impairment costs, and $213 million of transaction, integration and separation costs. The fiscal 2017 second quarter net loss includes $18 million of mark-to-market gains on pension plans, $99 million of significant restructuring and impairment costs, and $138 million of transaction and integration costs. The fiscal 2017 third quarter net income includes $45 million of mark-to-market losses on pension plans, $49 million of significant restructuring and impairment costs, and $70 million of transaction and integration costs The fiscal 2017 fourth quarter net income includes $330 million of net mark-to-market gains on pension and postretirement plans, $141 million of significant restructuring and impairment costs, $90 million of integration costs and $50 million for an unfavorable arbitration award. The preceding amounts are stated on a pre-tax and pre-noncontrolling interest impact basis and include both continuing and discontinued operations activity. |

[0000833444-17-000060:mdna:302]
| (2) | Due to the use of the weighted-average shares outstanding for each quarter for computing earnings per share, the sum of the quarterly per share amounts may not equal the per share amount for the year. |

[0000833444-17-000060:mdna:303]
| (3) | The fiscal 2016 first quarter net income includes $101 million of transaction, integration and separation costs. The fiscal 2016 second quarter net loss includes $229 million of significant restructuring and impairment costs, and $131 million of transaction, integration and separation costs. The fiscal 2016 third quarter net income includes $167 million of transaction, integration, and separation costs, and $102 million of significant restructuring and impairment costs. The fiscal 2016 fourth quarter net loss includes $514 million of net mark-to-market and settlement losses on pension and postretirement plans, $296 million of significant restructuring and impairment costs, and $293 million of transaction, integration and separation costs. The preceding amounts are stated on a pre-tax and pre-noncontrolling interest impact basis and include both continuing and discontinued operations activity. |

[0000833444-17-000060:mdna:304]
| (4) | Basic and diluted earnings (loss) per share will not cross-foot due to the impact of the Tyco Merger on the weighted-average shares included within the earnings per share calculation. |
