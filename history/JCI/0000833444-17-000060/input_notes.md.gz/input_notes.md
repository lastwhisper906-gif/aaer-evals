# JCI notes — 0000833444-17-000060


## jci:AssetsandLiabilitiesHeldforSalePolicyTextBlock

[0000833444-17-000060:notes:1]
Assets and Liabilities Held for Sale

[0000833444-17-000060:notes:2]
The Company classifies assets and liabilities (disposal groups) to be sold as held for sale in the period in which all of the following criteria are met: management, having the authority to approve the action, commits to a plan to sell the disposal group; the disposal group is available for immediate sale in its present condition subject only to terms that are usual and customary for sales of such disposal groups; an active program to locate a buyer and other actions required to complete the plan to sell the disposal group have been initiated; the sale of the disposal group is probable, and transfer of the disposal group is expected to qualify for recognition as a completed sale within one year, except if events or circumstances beyond the Company's control extend the period of time required to sell the disposal group beyond one year; the disposal group is being actively marketed for sale at a price that is reasonable in relation to its current fair value; and actions required to complete the plan indicate that it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn.

[0000833444-17-000060:notes:3]
In addition, the Company classifies disposal groups to be disposed of other than by sale (e.g. spin-off) as held for sale in the period the disposal occurs.

[0000833444-17-000060:notes:4]
The Company initially measures a disposal group that is classified as held for sale at the lower of its carrying value or fair value less any costs to sell. Any loss resulting from this measurement is recognized in the period in which the held for sale criteria are met. Conversely, gains are not recognized on the sale of a disposal group until the date of sale. The Company assesses the fair value of a disposal group, less any costs to sell, each reporting period it remains classified as held for sale and reports any subsequent changes as an adjustment to the carrying value of the disposal group, as long as the new carrying value does not exceed the carrying value of the disposal group at the time it was initially classified as held for sale.

[0000833444-17-000060:notes:5]
Upon determining that a disposal group meets the criteria to be classified as held for sale, the Company reports the assets and liabilities of the disposal group, if material, in the line items assets held for sale and liabilities held for sale in the consolidated statements of financial position. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information.


## jci:ComponentsOfNetFinancingChargesTableTextBlock

[0000833444-17-000060:notes:6]
The Company's net financing charges line item in the consolidated statements of income for the years ended September 30, 2017, 2016 and 2015 contained the following components (in millions):

[0000833444-17-000060:notes:7]
|  | Year Ended September 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Interest expense, net of capitalized interest costs | $ | 466 |  |  | $ | 293 |  |  | $ | 275 |  |
| Banking fees and bond cost amortization | 67 |  |  | 30 |  |  | 21 |  |
| Interest income | (19 | ) |  | (12 | ) |  | (7 | ) |
| Net foreign exchange results for financing activities | (18 | ) |  | (22 | ) |  | (15 | ) |
| Net financing charges | $ | 496 |  |  | $ | 289 |  |  | $ | 274 |  |


## jci:DeferredTaxesClassifiedInConsolidatedStatementsOfFinancialPositionTableTextBlock

[0000833444-17-000060:notes:8]
Deferred taxes were classified in the consolidated statements of financial position as follows (in millions):

[0000833444-17-000060:notes:9]
|  | September 30, |
|  | 2017 |  | 2016 |
| Other noncurrent assets | 2,360 |  |  | 2,467 |  |
| Other noncurrent liabilities | (1,733 | ) |  | (1,542 | ) |
| Net deferred tax asset | $ | 627 |  |  | $ | 925 |  |


## jci:DerivativeAssetsandLiabilitiesEligibleforOffsettingTableTextBlock

[0000833444-17-000060:notes:10]
The gross and net amounts of derivative assets and liabilities were as follows (in millions):

[0000833444-17-000060:notes:11]
|  | Fair Value of Assets |  | Fair Value of Liabilities |
|  | September 30, 2017 |  | September 30, 2016 |  | September 30, 2017 |  | September 30, 2016 |  |
| Gross amount recognized | $ | 91 |  |  | $ | 95 |  |  | $ | 2,105 |  |  | $ | 2,980 |  |  |
| Gross amount eligible for offsetting | (16 | ) |  | (21 | ) |  | (16 | ) |  | (21 | ) |  |
| Net amount | $ | 75 |  |  | $ | 74 |  |  | $ | 2,089 |  |  | $ | 2,959 |  |  |


## jci:DisposalGroupIncludingDiscontinuedOperationsIncomeStatementDisclosuresTableTextBlock

[0000833444-17-000060:notes:12]
The following table summarizes the results of Adient, reclassified as discontinued operations for the fiscal years ended September 30, 2017, 2016 and 2015 (in millions). As the Adient spin-off occurred on October 31, 2016, there is only one month of Adient results included in the year ended September 30, 2017.

[0000833444-17-000060:notes:13]
|  | Year Ended September 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Net sales | $ | 1,434 |  |  | $ | 16,837 |  |  | $ | 20,079 |  |
| Income from discontinued operations before income taxes | 1 |  |  | 525 |  |  | 1,220 |  |
| Provision for income taxes on discontinued operations | 35 |  |  | 2,041 |  |  | 529 |  |
| Income from discontinued operations attributable to noncontrolling interests, net of tax | 9 |  |  | 84 |  |  | 66 |  |
| Income (loss) from discontinued operations | $ | (43 | ) |  | $ | (1,600 | ) |  | $ | 625 |  |


## jci:EquityAttributableToParentAndNoncontrollingInterestsTableTextBlock

[0000833444-17-000060:notes:14]
The following schedules present changes in consolidated equity attributable to Johnson Controls and noncontrolling interests (in millions, net of tax):

[0000833444-17-000060:notes:15]
|  | Equity Attributable to Johnson ControlsInternational plc |  | Equity Attributable to Noncontrolling Interests |  | Total Equity |
| At September 30, 2014 | $ | 11,270 |  |  | $ | 251 |  |  | $ | 11,521 |  |
| Total comprehensive income: |  |  |  |  |  |
| Net income | 1,563 |  |  | 65 |  |  | 1,628 |  |
| Foreign currency translation adjustments | (799 | ) |  | (3 | ) |  | (802 | ) |
| Realized and unrealized losses on derivatives | (11 | ) |  | — |  |  | (11 | ) |
| Pension and postretirement plans | (10 | ) |  | — |  |  | (10 | ) |
| Other comprehensive loss | (820 | ) |  | (3 | ) |  | (823 | ) |
| Comprehensive income | 743 |  |  | 62 |  |  | 805 |  |
| Other changes in equity: |  |  |  |  |  |
| Cash dividends - common stock ($1.04 per share) | (681 | ) |  | — |  |  | (681 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (57 | ) |  | (57 | ) |
| Repurchases of common stock | (1,362 | ) |  | — |  |  | (1,362 | ) |
| Change in noncontrolling interest share | — |  |  | (93 | ) |  | (93 | ) |
| Other, including options exercised | 365 |  |  | — |  |  | 365 |  |
| At September 30, 2015 | 10,335 |  |  | 163 |  |  | 10,498 |  |
| Total comprehensive income (loss): |  |  |  |  |  |
| Net income (loss) | (868 | ) |  | 168 |  |  | (700 | ) |
| Foreign currency translation adjustments | (105 | ) |  | 9 |  |  | (96 | ) |
| Realized and unrealized gains (losses) on derivatives | 11 |  |  | (1 | ) |  | 10 |  |
| Unrealized losses on marketable securities | (1 | ) |  | — |  |  | (1 | ) |
| Pension and postretirement plans | (1 | ) |  | — |  |  | (1 | ) |
| Other comprehensive income (loss) | (96 | ) |  | 8 |  |  | (88 | ) |
| Comprehensive income (loss) | (964 | ) |  | 176 |  |  | (788 | ) |
| Other changes in equity: |  |  |  |  |  |
| Result of contribution of Johnson Controls, Inc. to Johnson Controls International plc | 15,808 |  |  | — |  |  | 15,808 |  |
| Cash dividends - common stock ($1.16 per share) | (752 | ) |  | — |  |  | (752 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (93 | ) |  | (93 | ) |
| Repurchases of common stock | (501 | ) |  | — |  |  | (501 | ) |
| Change in noncontrolling interest share | — |  |  | 726 |  |  | 726 |  |
| Other, including options exercised | 192 |  |  | — |  |  | 192 |  |
| At September 30, 2016 | 24,118 |  |  | 972 |  |  | 25,090 |  |
| Total comprehensive income (loss): |  |  |  |  |  |
| Net income | 1,611 |  |  | 164 |  |  | 1,775 |  |
| Foreign currency translation adjustments | 108 |  |  | (18 | ) |  | 90 |  |
| Realized and unrealized gains (losses) on derivatives | (14 | ) |  | 1 |  |  | (13 | ) |
| Realized and unrealized gains on marketable securities | 5 |  |  | — |  |  | 5 |  |
| Other comprehensive income (loss) | 99 |  |  | (17 | ) |  | 82 |  |
| Comprehensive income | 1,710 |  |  | 147 |  |  | 1,857 |  |
| Other changes in equity: |  |  |  |  |  |
| Cash dividends - ordinary shares ($1.00 per share) | (938 | ) |  | — |  |  | (938 | ) |
| Dividends attributable to noncontrolling interests | — |  |  | (56 | ) |  | (56 | ) |
| Repurchases of ordinary shares | (651 | ) |  | — |  |  | (651 | ) |
| Change in noncontrolling interest share | — |  |  | (5 | ) |  | (5 | ) |
| Spin-off of Adient | (4,038 | ) |  | (138 | ) |  | (4,176 | ) |
| Other, including options exercised | 246 |  |  | — |  |  | 246 |  |
| At September 30, 2017 | $ | 20,447 |  |  | $ | 920 |  |  | $ | 21,367 |  |


## jci:FutureMinimumCapitalAndOperatingLeasePaymentsAndRelatedPresentValueOfCapitalLeasePaymentsTableTextBlock

[0000833444-17-000060:notes:16]
Future minimum capital and operating lease payments and the related present value of capital lease payments at September 30, 2017 were as follows (in millions):

[0000833444-17-000060:notes:17]
|  | CapitalLeases |  | OperatingLeases |
| 2018 | $ | 4 |  |  | $ | 315 |  |
| 2019 | 3 |  |  | 237 |  |
| 2020 | 3 |  |  | 160 |  |
| 2021 | 2 |  |  | 96 |  |
| 2022 | 2 |  |  | 61 |  |
| After 2022 | 9 |  |  | 85 |  |
| Total minimum lease payments | 23 |  |  | $ | 954 |  |
| Interest | (4 | ) |  |  |
| Present value of net minimum lease payments | $ | 19 |  |  |  |


## jci:HedgeForecastedPurchasesTableTextBlock

[0000833444-17-000060:notes:18]
The Company had the following outstanding contracts to hedge forecasted commodity purchases:

[0000833444-17-000060:notes:19]
|  |  |  |  | Volume Outstanding as of |
| Commodity |  | Units |  | September 30, 2017 |  | September 30, 2016 |
| Copper |  | Metric Tons |  | 1,962 |  |  | 2,653 |  |
| Polypropylene |  | Metric Tons |  | 19,563 |  |  | — |  |
| Lead |  | Metric Tons |  | 24,705 |  |  | 5,185 |  |
| Aluminum |  | Metric Tons |  | 2,169 |  |  | 2,620 |  |
| Tin |  | Metric Tons |  | 1,715 |  |  | 185 |  |


## jci:RetrospectiveChangesPolicyTextBlock

[0000833444-17-000060:notes:20]
Retrospective Changes

[0000833444-17-000060:notes:21]
Certain amounts as of September 30, 2016 and 2015 have been revised to conform to the current year's presentation.

[0000833444-17-000060:notes:22]
Effective July 1, 2017, the Company reorganized the reportable segments within its Building Technologies & Solutions business to align with its new management reporting structure and business activities. Prior to this reorganization, Building Technologies & Solutions was comprised of five reportable segments for financial reporting purposes: Systems and Service North America, Products North America, Asia, Rest of World and Tyco. As a result of this change, Building Technologies & Solutions is now comprised of four reportable segments for financial reporting purposes: Building Solutions North America, Building Solutions EMEA/LA, Building Solutions Asia Pacific and Global Products. Refer to Note 7, “Goodwill and Other Intangible Assets,” and Note 19, “Segment Information,” of the notes to consolidated financial statements for further information. The net sales and cost of sales split of products and systems versus services on the consolidated statements of income has also been revised for the Building Technologies & Solutions reorganization.


## jci:ScheduleOfIntangibleAssetsTableTextBlock

[0000833444-17-000060:notes:23]
The Company’s other intangible assets, primarily from business acquisitions valued based on independent appraisals, consisted of (in millions):

[0000833444-17-000060:notes:24]
|  | September 30, 2017 |  | September 30, 2016 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Amortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,328 |  |  | $ | (137 | ) |  | $ | 1,191 |  |  | $ | 1,528 |  |  | $ | (24 | ) |  | $ | 1,504 |  |
| Customer relationships | 3,168 |  |  | (486 | ) |  | 2,682 |  |  | 3,168 |  |  | (226 | ) |  | 2,942 |  |
| Miscellaneous | 389 |  |  | (147 | ) |  | 242 |  |  | 519 |  |  | (130 | ) |  | 389 |  |
| Total amortized intangible assets | 4,885 |  |  | (770 | ) |  | 4,115 |  |  | 5,215 |  |  | (380 | ) |  | 4,835 |  |
| Unamortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,483 |  |  | — |  |  | 2,483 |  |  | 2,555 |  |  | — |  |  | 2,555 |  |
| Miscellaneous | 143 |  |  | — |  |  | 143 |  |  | 150 |  |  | — |  |  | 150 |  |
|  | 2,626 |  |  | — |  |  | 2,626 |  |  | 2,705 |  |  | — |  |  | 2,705 |  |
| Total intangible assets | $ | 7,511 |  |  | $ | (770 | ) |  | $ | 6,741 |  |  | $ | 7,920 |  |  | $ | (380 | ) |  | $ | 7,540 |  |


## jci:ScheduleofFairValueofConsiderationTransferredTableTextBlock

[0000833444-17-000060:notes:25]
The following table summarizes the total fair value of consideration transferred:

[0000833444-17-000060:notes:26]
| (in millions, except for share consolidation ratio and share data) |  |  |
| Number of Tyco shares outstanding at September 2, 2016 |  | 427,181,743 |  |
| Tyco share consolidation ratio |  | 0.955 |  |
| Tyco ordinary shares outstanding following the share consolidation and immediately prior to the Merger |  | 407,958,565 |  |
| JCI Inc. converted share price (1) |  | $ | 47.67 |  |
| Fair value of equity portion of the Merger consideration |  | $ | 19,447 |  |
| Fair value of Tyco equity awards |  | 224 |  |
| Total fair value of consideration transferred |  | $ | 19,671 |  |

[0000833444-17-000060:notes:27]
| (1) | Amount equals JCI Inc. closing share price and market capitalization at September 2, 2016 ($45.45 and $29,012 million, respectively) adjusted for the Tyco $3,864 million cash contribution used to purchase 110.8 million shares of JCI Inc. common stock for $34.88 per share. |


## jci:ScheduleofsharebasedpaymentawardperformancesharevaluationassumptionsTableTextBlock

[0000833444-17-000060:notes:28]
|  | Year Ended September 30, 2017 |
| Risk-free interest rate | 1.40% |
| Expected volatility of the Company's stock | 21.00% |


## jci:ShareBasedCompensationArrangementByShareBasedPaymentAwardFairValueAssumptionsInStockAppreciationRightsTableTextBlock

[0000833444-17-000060:notes:29]
The assumptions used to determine the fair value of the SAR awards at September 30, 2017 were as follows:

[0000833444-17-000060:notes:30]
| Expected life of SAR (years) | 0.5 - 5.5 |
| Risk-free interest rate | 1.06% - 1.98% |
| Expected volatility of the Company’s stock | 24.60% |
| Expected dividend yield on the Company’s stock | 2.21% |


## jci:SubscriberSystemAssetsDealerIntangiblesandRelatedDeferredRevenueAccountsPolicyTextBlock

[0000833444-17-000060:notes:31]
Subscriber System Assets, Dealer Intangibles and Related Deferred Revenue Accounts

[0000833444-17-000060:notes:32]
The Building Technologies & Solutions business considers assets related to the acquisition of new customers in its electronic security business in three asset categories: internally generated residential subscriber systems outside of North America, internally generated commercial subscriber systems (collectively referred to as subscriber system assets) and customer accounts acquired through the ADT dealer program, primarily outside of North America (referred to as dealer intangibles). Subscriber system assets include installed property, plant and equipment for which the Company retains ownership and deferred costs directly related to the customer acquisition and system installation. Subscriber system assets represent capitalized equipment (e.g. security control panels, touchpad, motion detectors, window sensors, and other equipment) and installation costs associated with electronic security monitoring arrangements under which the Company retains ownership of the security system assets in a customer's place of business, or outside of North America, residence. Installation costs represent costs incurred to prepare the asset for its intended use. The Company pays property taxes on the subscriber system assets and upon customer termination, may retrieve such assets. These assets embody a probable future economic benefit as they generate future monitoring revenue for the Company.

[0000833444-17-000060:notes:33]
Costs related to the subscriber system equipment and installation are categorized as property, plant and equipment rather than deferred costs. Deferred costs associated with subscriber system assets represent direct and incremental selling expenses (such as commissions) related to acquiring the customer. Commissions related to up-front consideration paid by customers in connection with the establishment of the monitoring arrangement are determined based on a percentage of the up-front fees and do not exceed deferred revenue. Such deferred costs are recorded as other current and noncurrent assets within the consolidated statements of financial position.

[0000833444-17-000060:notes:34]
Subscriber system assets and any deferred revenue resulting from the customer acquisition are accounted for over the expected life of the subscriber. In certain geographical areas where the Company has a large number of customers that behave in a similar manner over time, the Company accounts for subscriber system assets and related deferred revenue using pools, with separate pools for the components of subscriber system assets and any related deferred revenue based on the same month and year of acquisition. The Company depreciates its pooled subscriber system assets and related deferred revenue using a straight-line method with lives up to 12 years and considering customer attrition. The Company uses a straight-line method with a 15-year life for non-pooled subscriber system assets (primarily in Europe, Latin America and Asia) and related deferred revenue, with remaining balances written off upon customer termination.

[0000833444-17-000060:notes:35]
Certain contracts and related customer relationships result from purchasing residential security monitoring contracts from an external network of independent dealers who operate under the ADT dealer program, primarily outside of North America. Acquired contracts and related customer relationships are recorded at their contractually determined purchase price.

[0000833444-17-000060:notes:36]
During the first 6 months (12 months in certain circumstances) after the purchase of the customer contract, any cancellation of monitoring service, including those that result from customer payment delinquencies, results in a chargeback by the Company to the dealer for the full amount of the contract purchase price. The Company records the amount charged back to the dealer as a reduction of the previously recorded intangible asset.

[0000833444-17-000060:notes:37]
Intangible assets arising from the ADT dealer program described above are amortized in pools determined by the same month and year of contract acquisition on a straight-line basis over the period of the customer relationship. The estimated useful life of dealer intangibles ranges from 12 to 15 years.


## jci:SummarizedBalanceSheetInformationNonConsolidatedPartiallyOwnedAffiliatesTableTextBlock

[0000833444-17-000060:notes:38]
Summarized balance sheet data as of September 30 is as follows (in millions):

[0000833444-17-000060:notes:39]
|  | 2017 |  | 2016 |
| Current assets | $ | 4,034 |  |  | $ | 3,085 |  |
| Noncurrent assets | 1,513 |  |  | 1,436 |  |
| Total assets | $ | 5,547 |  |  | $ | 4,521 |  |
| Current liabilities | $ | 2,470 |  |  | $ | 1,864 |  |
| Noncurrent liabilities | 478 |  |  | 554 |  |
| Noncontrolling interests | 33 |  |  | 41 |  |
| Shareholders’ equity | 2,566 |  |  | 2,062 |  |
| Total liabilities and shareholders’ equity | $ | 5,547 |  |  | $ | 4,521 |  |


## jci:SummarizedIncomeStatementInformationNonConsolidatedPartiallyOwnedAffiliatesTableTextBlock

[0000833444-17-000060:notes:40]
Summarized income statement data for the years ended September 30 is as follows (in millions):

[0000833444-17-000060:notes:41]
|  | 2017 |  | 2016 |  | 2015 |
| Net sales | $ | 6,445 |  |  | $ | 5,329 |  |  | $ | 3,527 |  |
| Gross profit | 1,510 |  |  | 1,323 |  |  | 718 |  |
| Net income | 517 |  |  | 415 |  |  | 195 |  |
| Income attributable to noncontrolling interests | 11 |  |  | 16 |  |  | — |  |
| Net income attributable to the entity | 506 |  |  | 399 |  |  | 195 |  |


## us-gaap:AssetImpairmentChargesTextBlock

[0000833444-17-000060:notes:42]
IMPAIRMENT OF LONG-LIVED ASSETS

[0000833444-17-000060:notes:43]
The Company reviews long-lived assets, including tangible assets and other intangible assets with definitive lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets" and ASC 985-20, "Costs of software to be sold, leased, or marketed." ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. ASC 985-20 requires the unamortized capitalized costs of a computer software product be compared to the net realizable value of that product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset shall be written off.

[0000833444-17-000060:notes:44]
In fiscal 2017, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2017. As a result, the Company reviewed the long-lived assets for impairment and recorded $77 million of asset impairment charges within restructuring and impairment costs on the consolidated statements of income. Of the total impairment charges, $30 million related to the Building Solutions North America segment, $20 million related to the Global Products segment, $19 million related to Corporate assets, $7 million related to the Power Solutions segment and $1 million related to the Building Solutions Asia Pacific segment. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-17-000060:notes:45]
In the second, third and fourth quarters of fiscal 2016, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2016. As a result, the Company reviewed the long-lived assets for impairment and recorded $103 million of asset impairment charges within restructuring and impairment costs on the consolidated statements of income. Of the total impairment charges, $64 million related to the Power Solutions segment, $24 million related to Corporate assets, $8 million related to the Global Products segment, $4 million related to the Building Solutions Asia Pacific segment and $3 million related to the Building Solutions EMEA/LA segment.  In addition, the Company recorded $87 million of asset impairments within discontinued operations related to Adient in fiscal 2016. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured, depending on the asset, under either an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-17-000060:notes:46]
In the fourth quarter of fiscal 2015, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets in conjunction with its announced restructuring actions and the intention to spin-off the Automotive Experience business. As a result, the Company reviewed the long-lived assets for impairment and recorded a $156 million impairment charge within restructuring and impairment costs on the consolidated statements of income. Of the total impairment charge, $139 million related to Corporate assets, $16 million related to the Building Solutions EMEA/LA segment and $1 million related to the Building Solutions North America segment. In addition, the Company recorded $27 million of asset impairments within discontinued operations related to Adient in fiscal 2015. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairment was measured, depending on the asset, either under an income approach utilizing forecasted discounted cash flows or a market approach utilizing an appraisal to determine fair values of the impaired assets. These methods are consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-17-000060:notes:47]
At September 30, 2017,  2016 and 2015, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets. Refer to Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements for discussion of the Company’s goodwill impairment testing.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000833444-17-000060:notes:48]
The following unaudited pro forma information assumes the acquisition had occurred on October 1, 2014, and had been included in the Company's consolidated statements of income for fiscal years 2016 and 2015.

[0000833444-17-000060:notes:49]
|  |  | Year Ended September 30, |
| (in millions) |  | 2016 |  | 2015 |
| Pro forma net sales |  | $ | 29,647 |  |  | $ | 26,908 |  |
| Pro forma net income from continuing operations |  | 1,143 |  |  | 848 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000833444-17-000060:notes:50]
Cash and Cash Equivalents

[0000833444-17-000060:notes:51]
The Company considers all highly liquid investments with an original maturity of three months or less when purchased to be cash equivalents.

[0000833444-17-000060:notes:52]
Restricted Cash

[0000833444-17-000060:notes:53]
At September 30, 2017, the Company held restricted cash of approximately $31 million, of which $22 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash restricted for payment of asbestos liabilities. At September 30, 2016, the Company held restricted cash of approximately $88 million, of which $79 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash held in escrow from business divestitures and cash restricted for payment of asbestos liabilities.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-17-000060:notes:54]
COMMITMENTS AND CONTINGENCIES

[0000833444-17-000060:notes:55]
Environmental Matters

[0000833444-17-000060:notes:56]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of September 30, 2017, reserves for environmental liabilities totaled $51 million, of which $10 million was recorded within other current liabilities and $41 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $51 million at September 30, 2016. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities, primarily in the Power Solutions and Building Technologies & Solutions businesses. At September 30, 2017 and 2016, the Company recorded conditional asset retirement obligations of $61 million and $74 million, respectively.

[0000833444-17-000060:notes:57]
Asbestos Matters

[0000833444-17-000060:notes:58]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-17-000060:notes:59]
As of September 30, 2017, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $181 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $573 million, of which $48 million was recorded in other current liabilities and $525 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $392 million, of which $53 million was recorded in other current assets, and $339 million was recorded in other noncurrent assets. Assets included $22 million of cash and $269 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2017 was $101 million. As of September 30, 2016, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $148 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $548 million, of which $35 million was recorded in other current liabilities and $513 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $400 million, of which $41 million was recorded in other current assets, and $359 million was recorded in other noncurrent assets. Assets included $16 million of cash and $264 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2016 was $120 million.

[0000833444-17-000060:notes:60]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-17-000060:notes:61]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-17-000060:notes:62]
Insurable Liabilities

[0000833444-17-000060:notes:63]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At September 30, 2017 and 2016, the insurable liabilities totaled $445 million and $422 million, respectively, of which $122 million and $60 million was recorded within other current liabilities, $22 million and $28 million was recorded within accrued compensation and benefits, and $301 million and $334 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at September 30, 2017 was $46 million, of which $31 million was recorded within other current assets and $15 million was recorded within other noncurrent assets. Insurance receivables recorded at September 30, 2016 were $21 million, primarily recorded within other noncurrent assets. The Company maintains captive insurance companies to manage certain of its insurable liabilities.

[0000833444-17-000060:notes:64]
Arbitration Award

[0000833444-17-000060:notes:65]
In September 2017, the Company was subject to an unfavorable arbitration award of approximately $50 million relating to a contractual dispute with a subcontractor used by the Company at an airport construction project in Doha, Qatar. In connection with the unfavorable arbitration award, the Company recorded a charge of $50 million within selling, general and administrative expenses on the consolidated statements of income in the fourth quarter of fiscal 2017. The airport project is being managed by a steering committee. The Company and the subcontractor were working jointly to document claims for increased costs against the steering committee when the subcontractor initiated the arbitration proceeding against the Company. Pursuant to its arbitration proceeding against the Company, the subcontractor sought to recover costs it alleges it incurred due to project delays, additional work and related financing costs. While the award remains outstanding, it will accrue interest at a statutory rate of 9.56%.

[0000833444-17-000060:notes:66]
In a related action, the Company has initiated an arbitration claim against the steering committee related to costs it incurred in connection with delays of the airport construction project, including costs related to the above award. The arbitrator is expected to issue a decision on the Company’s claims against the steering committee by the end of fiscal 2018.

[0000833444-17-000060:notes:67]
Aqueous Film-Forming Foam Litigation

[0000833444-17-000060:notes:68]
Two of our subsidiaries, Chemguard, Inc. ("Chemguard") and Tyco Fire Products L.P. ("Tyco Fire Products"), have been named, along with other defendant manufacturers, in a number of class action lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the DOD) and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and that the use of these products by others at various airbases and airports resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports and airbases. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination. As of November 21, 2017, the Company is named in 12 putative class actions in federal courts in three states as set forth below:

[0000833444-17-000060:notes:69]
Colorado

[0000833444-17-000060:notes:70]
| • | District of Colorado - Bell et al. v. The 3M Company et al., filed on September 18, 2016. |

[0000833444-17-000060:notes:71]
| • | District of Colorado - Davis et al. v. The 3M Company et al., filed on September 22, 2016. |

[0000833444-17-000060:notes:72]
The above cases have been consolidated in the U.S. District Court for the District of Colorado, and a hearing on the plaintiffs’ motion for class certification is scheduled for April 2018.

[0000833444-17-000060:notes:73]
New York

[0000833444-17-000060:notes:74]
| • | Eastern District of New York - Green et al. v. The 3M Company et al., filed March 27, 2017 in Supreme Court of the State of New York, Suffolk County, prior to removal to federal court. |

[0000833444-17-000060:notes:75]
| • | Southern District of New York - Adamo et al. v. The Port Authority of NY and NJ et al., filed August 11, 2017 in Supreme Court of the State of New York, Orange County, prior to removal to federal court. |

[0000833444-17-000060:notes:76]
| • | Southern District of New York - Fogarty et al. v. The Port Authority of NY and NJ et al., filed August 11, 2017 in Supreme Court of the State of New York, Orange County, prior to removal to federal court. |

[0000833444-17-000060:notes:77]
| • | Southern District of New York - Miller et al. v. The Port Authority of NY and NJ et al., filed August 11, 2017 in Supreme Court of the State of New York, Orange County, prior to removal to federal court. |

[0000833444-17-000060:notes:78]
| • | Supreme Court of the State of New York, Suffolk County - Singer et al. v. The 3M Company et al., filed October 10, 2017. |

[0000833444-17-000060:notes:79]
Responses to the complaints have not been filed yet in any of the New York actions.

[0000833444-17-000060:notes:80]
Pennsylvania

[0000833444-17-000060:notes:81]
| • | Eastern District of Pennsylvania - Bates et al. v. The 3M Company et al., filed September 15, 2016. |

[0000833444-17-000060:notes:82]
| • | Eastern District of Pennsylvania - Grande et al. v. The 3M Company et al., filed October 13, 2016. |

[0000833444-17-000060:notes:83]
| • | Eastern District of Pennsylvania - Yockey et al. v. The 3M Company et al., filed October 24, 2016. |

[0000833444-17-000060:notes:84]
| • | Eastern District of Pennsylvania - Fearnley et al. v. The 3M Company et al., filed December 9, 2016. |

[0000833444-17-000060:notes:85]
The above cases have been consolidated in the U.S. District Court for the Eastern District of Pennsylvania. Defendants have moved to dismiss the complaint in the consolidated proceeding.

[0000833444-17-000060:notes:86]
In addition to the putative class actions, Chemguard and Tyco Fire Products are also defendants in an action filed by two plaintiffs in the U.S. District Court for the Eastern District of Pennsylvania:  Menkes et al. v. The 3M Company et al., (filed February 7, 2017). The Menkes plaintiffs assert substantive claims and allegations similar to the putative class allegations, but also include personal injury claim. The Company is also on notice of approximately 490 other possible individual product liability claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters, and, under Pennsylvania’s procedural rules, they may or may not result in lawsuits.

[0000833444-17-000060:notes:87]
Chemguard and Tyco Fire Products are also defendants in two cases pending in the U.S. District Court for the District of Massachusetts: Town of Barnstable v. the 3M. Co., et al, (filed Nov. 21, 2016), and County of Barnstable v. the 3M. Co., et al, (filed January 9, 2017).  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at a fire training academy and municipal airport released PFOS and PFOA into the town’s water supply wells, allegedly requiring remediation of the town and county property. The defendants have filed a motion to dismiss in County of Barnstable, which is currently pending before the court.

[0000833444-17-000060:notes:88]
The Company is vigorously defending these cases and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.

[0000833444-17-000060:notes:89]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000833444-17-000060:notes:90]
Loss Contingencies

[0000833444-17-000060:notes:91]
Accruals are recorded for various contingencies including legal proceedings, environmental matters, self-insurance and other claims that arise in the normal course of business. The accruals are based on judgment, the probability of losses and, where applicable, the consideration of opinions of internal and/or external legal counsel and actuarially determined estimates. Additionally, the Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-17-000060:notes:92]
The Company is subject to laws and regulations relating to protecting the environment. The Company provides for expenses associated with environmental remediation obligations when such amounts are probable and can be reasonably estimated. Refer to Note 23, "Commitments and Contingencies," of the notes to consolidated financial statements.

[0000833444-17-000060:notes:93]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company records receivables from third party insurers when recovery has been determined to be probable. The Company maintains captive insurance companies to manage certain of its insurable liabilities.

[0000833444-17-000060:notes:94]
Asbestos-Related Contingencies and Insurance Receivables

[0000833444-17-000060:notes:95]
The Company and certain of its subsidiaries along with numerous other companies are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from  2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-17-000060:notes:96]
In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable. The Company's estimate of asbestos-related insurance recoveries represents estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims discounted to present value. In determining the amount of insurance recoverable, the Company considers available insurance, allocation methodologies, solvency and creditworthiness of the insurers. Refer to Note 23, "Commitments and Contingencies," of the notes to consolidated financial statements for a discussion on management's judgments applied in the recognition and measurement of asbestos-related assets and liabilities.


## us-gaap:CondensedFinancialStatementsTextBlock

[0000833444-17-000060:notes:97]
TYCO INTERNATIONAL FINANCE S.A.

[0000833444-17-000060:notes:98]
TIFSA, a 100% owned subsidiary of the Company, has public debt securities outstanding, which as of September 30, 2016, were fully and unconditionally guaranteed by Johnson Controls and by Tyco Fire & Security Finance S.C.A. ("TIFSCA"), a wholly owned subsidiary of the Company and parent company TIFSA. During the first quarter of fiscal 2017, the guarantees were removed in connection with the previously disclosed debt exchange. The following tables present condensed consolidating financial information for Johnson Controls, TIFSCA, TIFSA and all other subsidiaries. Condensed financial information for the Company, TIFSCA and TIFSA on a stand-alone basis is presented using the equity method of accounting for subsidiaries. The Company has revised investments in affiliates and other shareholders’ equity amounts for TIFSA and TIFSCA as of the year ended September 30, 2016. Within the condensed consolidating statement of financial position, investments in affiliates and other shareholders’ equity for TIFSA and TIFSCA decreased by $1,485 million and $263 million, respectively, with the offset in the consolidating adjustments column. The impact of the changes to the consolidating figures was not significant and had no impact to the consolidated financials of the Company.

[0000833444-17-000060:notes:99]
The TIFSA public debt securities were assumed as part of the Tyco acquisition.  Therefore, no consolidating financial information for the year ended September 30, 2015 is presented related to the guarantee of the TIFSA public debt securities. Additional information regarding TIFSA and TIFSCA for the fiscal year ended September 25, 2015 and the period ended June 24, 2016 can be found in Tyco's Annual Report on Form 10-K filed with the SEC on November 13, 2015 (as recast in part in Tyco's Current Report on Form 8-K filed with the SEC on March 11, 2016) and Tyco's Quarterly report on Form 10-Q filed with the SEC on July 29, 2016, respectively.

[0000833444-17-000060:notes:100]
CONDENSED CONSOLIDATING STATEMENT OF OPERATIONS

[0000833444-17-000060:notes:101]
For the Year Ended September 30, 2017

[0000833444-17-000060:notes:102]
($ in millions)

[0000833444-17-000060:notes:103]
|  | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net sales | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 30,172 |  |  | $ | — |  |  | $ | 30,172 |  |
| Cost of sales | — |  |  | — |  |  | — |  |  | 20,833 |  |  | — |  |  | 20,833 |  |
| Gross profit | — |  |  | — |  |  | — |  |  | 9,339 |  |  | — |  |  | 9,339 |  |
| Selling, general and administrative expenses | (13 | ) |  | — |  |  | — |  |  | (6,145 | ) |  | — |  |  | (6,158 | ) |
| Restructuring and impairment costs | — |  |  | — |  |  | — |  |  | (367 | ) |  | — |  |  | (367 | ) |
| Net financing charges | (179 | ) |  | (1 | ) |  | (19 | ) |  | (297 | ) |  | — |  |  | (496 | ) |
| Equity income (loss) | 1,839 |  |  | 874 |  |  | (35 | ) |  | 240 |  |  | (2,678 | ) |  | 240 |  |
| Intercompany interest and fees | (27 | ) |  | 245 |  |  | 11 |  |  | (229 | ) |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes | 1,620 |  |  | 1,118 |  |  | (43 | ) |  | 2,541 |  |  | (2,678 | ) |  | 2,558 |  |
| Income tax provision | 9 |  |  | — |  |  | — |  |  | 696 |  |  | — |  |  | 705 |  |
| Income (loss) from continuing operations | 1,611 |  |  | 1,118 |  |  | (43 | ) |  | 1,845 |  |  | (2,678 | ) |  | 1,853 |  |
| Loss from sale of intercompany investment, net of tax | — |  |  | — |  |  | (935 | ) |  | — |  |  | 935 |  |  | — |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | — |  |  | (34 | ) |  | — |  |  | (34 | ) |
| Net income (loss) | 1,611 |  |  | 1,118 |  |  | (978 | ) |  | 1,811 |  |  | (1,743 | ) |  | 1,819 |  |
| Income from continuing operations attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 199 |  |  | — |  |  | 199 |  |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Net income (loss) attributable to Johnson Controls | $ | 1,611 |  |  | $ | 1,118 |  |  | $ | (978 | ) |  | $ | 1,603 |  |  | $ | (1,743 | ) |  | $ | 1,611 |  |

[0000833444-17-000060:notes:104]
CONDENSED CONSOLIDATING STATEMENT OF COMPREHENSIVE INCOME

[0000833444-17-000060:notes:105]
| (in millions) | Johnson ControlsInternationalplc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net income (loss) | $ | 1,611 |  |  | $ | 1,118 |  |  | $ | (978 | ) |  | $ | 1,811 |  |  | $ | (1,743 | ) |  | $ | 1,819 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments | 108 |  |  | (54 | ) |  | 20 |  |  | 137 |  |  | (108 | ) |  | 103 |  |
| Realized and unrealized losses on derivatives | (14 | ) |  | — |  |  | — |  |  | (14 | ) |  | 14 |  |  | (14 | ) |
| Realized and unrealized gains (losses) on marketable securities | 5 |  |  | — |  |  | (4 | ) |  | 9 |  |  | (5 | ) |  | 5 |  |
| Other comprehensive income (loss) | 99 |  |  | (54 | ) |  | 16 |  |  | 132 |  |  | (99 | ) |  | 94 |  |
| Total comprehensive income (loss) | 1,710 |  |  | 1,064 |  |  | (962 | ) |  | 1,943 |  |  | (1,842 | ) |  | 1,913 |  |
| Comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 203 |  |  | — |  |  | 203 |  |
| Comprehensive income (loss) attributable to Johnson Controls | $ | 1,710 |  |  | $ | 1,064 |  |  | $ | (962 | ) |  | $ | 1,740 |  |  | $ | (1,842 | ) |  | $ | 1,710 |  |

[0000833444-17-000060:notes:106]
For the Year Ended September 30, 2016

[0000833444-17-000060:notes:107]
|  | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net sales | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 20,837 |  |  | $ | — |  |  | $ | 20,837 |  |
| Cost of sales | — |  |  | — |  |  | — |  |  | 15,183 |  |  | — |  |  | 15,183 |  |
| Gross profit | — |  |  | — |  |  | — |  |  | 5,654 |  |  | — |  |  | 5,654 |  |
| Selling, general and administrative expenses | (2 | ) |  | (2 | ) |  | (1 | ) |  | (4,185 | ) |  | — |  |  | (4,190 | ) |
| Restructuring and impairment costs | — |  |  | — |  |  | — |  |  | (288 | ) |  | — |  |  | (288 | ) |
| Net financing charges | — |  |  | — |  |  | (6 | ) |  | (283 | ) |  | — |  |  | (289 | ) |
| Equity income (loss) | (894 | ) |  | (1,527 | ) |  | (341 | ) |  | 174 |  |  | 2,762 |  |  | 174 |  |
| Intercompany interest and fees | 28 |  |  | — |  |  | 7 |  |  | (35 | ) |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes | (868 | ) |  | (1,529 | ) |  | (341 | ) |  | 1,037 |  |  | 2,762 |  |  | 1,061 |  |
| Income tax provision | — |  |  | — |  |  | — |  |  | 197 |  |  | — |  |  | 197 |  |
| Income (loss) from continuing operations | (868 | ) |  | (1,529 | ) |  | (341 | ) |  | 840 |  |  | 2,762 |  |  | 864 |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | — |  |  | (1,516 | ) |  | — |  |  | (1,516 | ) |
| Net loss | (868 | ) |  | (1,529 | ) |  | (341 | ) |  | (676 | ) |  | 2,762 |  |  | (652 | ) |
| Income from continuing operations attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 132 |  |  | — |  |  | 132 |  |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 84 |  |  | — |  |  | 84 |  |
| Net loss attributable to Johnson Controls | $ | (868 | ) |  | $ | (1,529 | ) |  | $ | (341 | ) |  | $ | (892 | ) |  | $ | 2,762 |  |  | $ | (868 | ) |

[0000833444-17-000060:notes:108]
| (in millions) | Johnson ControlsInternationalplc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net loss | $ | (868 | ) |  | $ | (1,529 | ) |  | $ | (341 | ) |  | $ | (676 | ) |  | $ | 2,762 |  |  | $ | (652 | ) |
| Other comprehensive loss, net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments | (105 | ) |  | — |  |  | — |  |  | (94 | ) |  | 105 |  |  | (94 | ) |
| Realized and unrealized gains on derivatives | 11 |  |  | — |  |  | — |  |  | 9 |  |  | (11 | ) |  | 9 |  |
| Realized and unrealized losses on marketable common stock | (1 | ) |  | — |  |  | — |  |  | (1 | ) |  | 1 |  |  | (1 | ) |
| Pension and postretirement plans | (1 | ) |  | — |  |  | — |  |  | (1 | ) |  | 1 |  |  | (1 | ) |
| Other comprehensive loss | (96 | ) |  | — |  |  | — |  |  | (87 | ) |  | 96 |  |  | (87 | ) |
| Total comprehensive loss | (964 | ) |  | (1,529 | ) |  | (341 | ) |  | (763 | ) |  | 2,858 |  |  | (739 | ) |
| Comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 225 |  |  | — |  |  | 225 |  |
| Comprehensive loss attributable to Johnson Controls | $ | (964 | ) |  | $ | (1,529 | ) |  | $ | (341 | ) |  | $ | (988 | ) |  | $ | 2,858 |  |  | $ | (964 | ) |

[0000833444-17-000060:notes:109]
CONDENSED CONSOLIDATING STATEMENT OF FINANCIAL POSITION

[0000833444-17-000060:notes:110]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | 107 |  |  | $ | 382 |  |  | $ | 718 |  |  | $ | (886 | ) |  | $ | 321 |  |
| Accounts receivable, net | — |  |  | — |  |  | — |  |  | 6,666 |  |  | — |  |  | 6,666 |  |
| Inventories | — |  |  | — |  |  | — |  |  | 3,209 |  |  | — |  |  | 3,209 |  |
| Intercompany receivables | 1,580 |  |  | 1,732 |  |  | 55 |  |  | 4,470 |  |  | (7,837 | ) |  | — |  |
| Assets held for sale | — |  |  | — |  |  | — |  |  | 189 |  |  | — |  |  | 189 |  |
| Other current assets | 14 |  |  | — |  |  | 1 |  |  | 1,892 |  |  | — |  |  | 1,907 |  |
| Current assets | 1,594 |  |  | 1,839 |  |  | 438 |  |  | 17,144 |  |  | (8,723 | ) |  | 12,292 |  |
| Property, plant and equipment - net | — |  |  | — |  |  | — |  |  | 6,121 |  |  | — |  |  | 6,121 |  |
| Goodwill | 243 |  |  | — |  |  | 32 |  |  | 19,413 |  |  | — |  |  | 19,688 |  |
| Other intangible assets - net | — |  |  | — |  |  | — |  |  | 6,741 |  |  | — |  |  | 6,741 |  |
| Investments in partially-owned affiliates | — |  |  | — |  |  | — |  |  | 1,191 |  |  | — |  |  | 1,191 |  |
| Investments in affiliates | 19,487 |  |  | 31,594 |  |  | 21,132 |  |  | — |  |  | (72,213 | ) |  | — |  |
| Intercompany loans receivable | 17,908 |  |  | 4,140 |  |  | 2,836 |  |  | 9,004 |  |  | (33,888 | ) |  | — |  |
| Noncurrent assets held for sale | — |  |  | — |  |  | — |  |  | 1,920 |  |  | — |  |  | 1,920 |  |
| Other noncurrent assets | 56 |  |  | — |  |  | 7 |  |  | 3,868 |  |  | — |  |  | 3,931 |  |
| Total assets | $ | 39,288 |  |  | $ | 37,573 |  |  | $ | 24,445 |  |  | $ | 65,402 |  |  | $ | (114,824 | ) |  | $ | 51,884 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | 1,476 |  |  | $ | — |  |  | $ | — |  |  | $ | 624 |  |  | $ | (886 | ) |  | $ | 1,214 |  |
| Current portion of long-term debt | 307 |  |  | — |  |  | 18 |  |  | 69 |  |  | — |  |  | 394 |  |
| Accounts payable | — |  |  | — |  |  | — |  |  | 4,271 |  |  | — |  |  | 4,271 |  |
| Accrued compensation and benefits | 4 |  |  | — |  |  | — |  |  | 1,067 |  |  | — |  |  | 1,071 |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 1,279 |  |  | — |  |  | 1,279 |  |
| Liabilities held for sale | — |  |  | — |  |  | — |  |  | 72 |  |  | — |  |  | 72 |  |
| Intercompany payables | 4,236 |  |  | 1,055 |  |  | 1,886 |  |  | 660 |  |  | (7,837 | ) |  | — |  |
| Other current liabilities | 324 |  |  | 2 |  |  | 24 |  |  | 3,203 |  |  | — |  |  | 3,553 |  |
| Current liabilities | 6,347 |  |  | 1,057 |  |  | 1,928 |  |  | 11,245 |  |  | (8,723 | ) |  | 11,854 |  |
| Long-term debt | 7,806 |  |  | — |  |  | 152 |  |  | 4,006 |  |  | — |  |  | 11,964 |  |
| Pension and postretirement benefits | — |  |  | — |  |  | — |  |  | 947 |  |  | — |  |  | 947 |  |
| Intercompany loans payable | 4,688 |  |  | 17,908 |  |  | 4,316 |  |  | 6,976 |  |  | (33,888 | ) |  | — |  |
| Noncurrent liabilities held for sale | — |  |  | — |  |  | — |  |  | 173 |  |  | — |  |  | 173 |  |
| Other noncurrent liabilities | — |  |  | — |  |  | 24 |  |  | 5,344 |  |  | — |  |  | 5,368 |  |
| Long-term liabilities | 12,494 |  |  | 17,908 |  |  | 4,492 |  |  | 17,446 |  |  | (33,888 | ) |  | 18,452 |  |
| Redeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 211 |  |  | — |  |  | 211 |  |
| Ordinary shares | 9 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 9 |  |
| Ordinary shares held in treasury | (710 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (710 | ) |
| Other shareholders' equity | 21,148 |  |  | 18,608 |  |  | 18,025 |  |  | 35,580 |  |  | (72,213 | ) |  | 21,148 |  |
| Shareholders’ equity attributable to Johnson Controls | 20,447 |  |  | 18,608 |  |  | 18,025 |  |  | 35,580 |  |  | (72,213 | ) |  | 20,447 |  |
| Noncontrolling interests | — |  |  | — |  |  | — |  |  | 920 |  |  | — |  |  | 920 |  |
| Total equity | 20,447 |  |  | 18,608 |  |  | 18,025 |  |  | 36,500 |  |  | (72,213 | ) |  | 21,367 |  |
| Total liabilities and equity | $ | 39,288 |  |  | $ | 37,573 |  |  | $ | 24,445 |  |  | $ | 65,402 |  |  | $ | (114,824 | ) |  | $ | 51,884 |  |

[0000833444-17-000060:notes:111]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 11 |  |  | $ | — |  |  | $ | 244 |  |  | $ | 324 |  |  | $ | — |  |  | $ | 579 |  |
| Accounts receivable, net | — |  |  | — |  |  | — |  |  | 6,394 |  |  | — |  |  | 6,394 |  |
| Inventories | — |  |  | — |  |  | — |  |  | 2,888 |  |  | — |  |  | 2,888 |  |
| Intercompany receivables | 16 |  |  | — |  |  | 2 |  |  | 6,188 |  |  | (6,206 | ) |  | — |  |
| Assets held for sale | — |  |  | — |  |  | — |  |  | 5,812 |  |  | — |  |  | 5,812 |  |
| Other current assets | 6 |  |  | — |  |  | 1 |  |  | 1,429 |  |  | — |  |  | 1,436 |  |
| Current assets | 33 |  |  | — |  |  | 247 |  |  | 23,035 |  |  | (6,206 | ) |  | 17,109 |  |
| Property, plant and equipment - net | — |  |  | — |  |  | — |  |  | 5,632 |  |  | — |  |  | 5,632 |  |
| Goodwill | — |  |  | — |  |  | 274 |  |  | 20,750 |  |  | — |  |  | 21,024 |  |
| Other intangible assets - net | — |  |  | — |  |  | — |  |  | 7,540 |  |  | — |  |  | 7,540 |  |
| Investments in partially-owned affiliates | — |  |  | — |  |  | — |  |  | 990 |  |  | — |  |  | 990 |  |
| Investments in affiliates | 12,460 |  |  | 31,142 |  |  | 26,421 |  |  | — |  |  | (70,023 | ) |  | — |  |
| Intercompany loans receivable | 18,680 |  |  | — |  |  | 13,336 |  |  | 15,631 |  |  | (47,647 | ) |  | — |  |
| Noncurrent assets held for sale | — |  |  | — |  |  | — |  |  | 7,374 |  |  | — |  |  | 7,374 |  |
| Other noncurrent assets | — |  |  | — |  |  | — |  |  | 3,510 |  |  | — |  |  | 3,510 |  |
| Total assets | $ | 31,173 |  |  | $ | 31,142 |  |  | $ | 40,278 |  |  | $ | 84,462 |  |  | $ | (123,876 | ) |  | $ | 63,179 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,078 |  |  | $ | — |  |  | $ | 1,078 |  |
| Current portion of long-term debt | — |  |  | — |  |  | — |  |  | 628 |  |  | — |  |  | 628 |  |
| Accounts payable | 1 |  |  | — |  |  | — |  |  | 3,999 |  |  | — |  |  | 4,000 |  |
| Accrued compensation and benefits | — |  |  | — |  |  | — |  |  | 1,333 |  |  | — |  |  | 1,333 |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 1,228 |  |  | — |  |  | 1,228 |  |
| Liabilities held for sale | — |  |  | — |  |  | — |  |  | 4,276 |  |  | — |  |  | 4,276 |  |
| Intercompany payables | 3,873 |  |  | — |  |  | 2,315 |  |  | 18 |  |  | (6,206 | ) |  | — |  |
| Other current liabilities | 3 |  |  | 2 |  |  | 32 |  |  | 3,751 |  |  | — |  |  | 3,788 |  |
| Current liabilities | 3,877 |  |  | 2 |  |  | 2,347 |  |  | 16,311 |  |  | (6,206 | ) |  | 16,331 |  |
| Long-term debt | — |  |  | — |  |  | 2,413 |  |  | 8,640 |  |  | — |  |  | 11,053 |  |
| Pension and postretirement benefits | — |  |  | — |  |  | — |  |  | 1,550 |  |  | — |  |  | 1,550 |  |
| Intercompany loans payable | 3,178 |  |  | 18,680 |  |  | 12,453 |  |  | 13,336 |  |  | (47,647 | ) |  | — |  |
| Noncurrent liabilities held for sale | — |  |  | — |  |  | — |  |  | 3,888 |  |  | — |  |  | 3,888 |  |
| Other noncurrent liabilities | — |  |  | — |  |  | 22 |  |  | 5,011 |  |  | — |  |  | 5,033 |  |
| Long-term liabilities | 3,178 |  |  | 18,680 |  |  | 14,888 |  |  | 32,425 |  |  | (47,647 | ) |  | 21,524 |  |
| Redeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 234 |  |  | — |  |  | 234 |  |
| Ordinary shares | 9 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 9 |  |
| Ordinary shares held in treasury | (20 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (20 | ) |
| Other shareholders' equity | 24,129 |  |  | 12,460 |  |  | 23,043 |  |  | 34,520 |  |  | (70,023 | ) |  | 24,129 |  |
| Shareholders’ equity attributable to Johnson Controls | 24,118 |  |  | 12,460 |  |  | 23,043 |  |  | 34,520 |  |  | (70,023 | ) |  | 24,118 |  |
| Noncontrolling interests | — |  |  | — |  |  | — |  |  | 972 |  |  | — |  |  | 972 |  |
| Total equity | 24,118 |  |  | 12,460 |  |  | 23,043 |  |  | 35,492 |  |  | (70,023 | ) |  | 25,090 |  |
| Total liabilities and equity | $ | 31,173 |  |  | $ | 31,142 |  |  | $ | 40,278 |  |  | $ | 84,462 |  |  | $ | (123,876 | ) |  | $ | 63,179 |  |

[0000833444-17-000060:notes:112]
CONDENSED CONSOLIDATING STATEMENT OF CASH FLOWS

[0000833444-17-000060:notes:113]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Operating Activities |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided (used) by operating activities | $ | (129 | ) |  | $ | 182 |  |  | $ | 142 |  |  | $ | (183 | ) |  | $ | — |  |  | $ | 12 |  |
| Investing Activities |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | — |  |  | (1,343 | ) |  | — |  |  | (1,343 | ) |
| Sale of property, plant and equipment | — |  |  | — |  |  | — |  |  | 33 |  |  | — |  |  | 33 |  |
| Acquisition of business, net of cash acquired | — |  |  | — |  |  | (6 | ) |  | — |  |  | — |  |  | (6 | ) |
| Business divestitures | — |  |  | — |  |  | — |  |  | 220 |  |  | — |  |  | 220 |  |
| Changes in long-term investments | — |  |  | — |  |  | (11 | ) |  | (30 | ) |  | — |  |  | (41 | ) |
| Net change in intercompany loans receivable | (300 | ) |  | — |  |  | — |  |  | (640 | ) |  | 940 |  |  | — |  |
| Increase in intercompany investment in subsidiaries | (1,998 | ) |  | (1,716 | ) |  | (100 | ) |  | — |  |  | 3,814 |  |  | — |  |
| Net cash used by investing activities | (2,298 | ) |  | (1,716 | ) |  | (117 | ) |  | (1,760 | ) |  | 4,754 |  |  | (1,137 | ) |
| Financing Activities |  |  |  |  |  |  |  |  |  |  |  |
| Increase (decrease) in short-term debt - net | 1,476 |  |  | — |  |  | — |  |  | (445 | ) |  | (886 | ) |  | 145 |  |
| Increase in long-term debt | 1,856 |  |  | — |  |  | — |  |  | 9 |  |  | — |  |  | 1,865 |  |
| Repayment of long-term debt | (183 | ) |  | — |  |  | (20 | ) |  | (1,094 | ) |  | — |  |  | (1,297 | ) |
| Debt financing costs | (17 | ) |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (18 | ) |
| Stock repurchases | (651 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (651 | ) |
| Payment of cash dividends | (702 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (702 | ) |
| Proceeds from the exercise of stock options | 157 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 157 |  |
| Net change in intercompany loans payable | 583 |  |  | — |  |  | 57 |  |  | 300 |  |  | (940 | ) |  | — |  |
| Increase in equity from parent | — |  |  | 1,641 |  |  | 76 |  |  | 2,097 |  |  | (3,814 | ) |  | — |  |
| Change in noncontrolling interest share | — |  |  | — |  |  | — |  |  | 8 |  |  | — |  |  | 8 |  |
| Dividends paid to noncontrolling interests | — |  |  | — |  |  | — |  |  | (88 | ) |  | — |  |  | (88 | ) |
| Dividends from Adient spin-off | — |  |  | — |  |  | — |  |  | 2,050 |  |  | — |  |  | 2,050 |  |
| Cash transferred to Adient related spin-off | (87 | ) |  | — |  |  | — |  |  | (578 | ) |  | — |  |  | (665 | ) |
| Cash paid to prior acquisitions | — |  |  | — |  |  | — |  |  | (75 | ) |  | — |  |  | (75 | ) |
| Other | (16 | ) |  | — |  |  | — |  |  | 4 |  |  | — |  |  | (12 | ) |
| Net cash provided by financing activities | 2,416 |  |  | 1,641 |  |  | 113 |  |  | 2,187 |  |  | (5,640 | ) |  | 717 |  |
| Effect of currency translation on cash | — |  |  | — |  |  | — |  |  | 54 |  |  | — |  |  | 54 |  |
| Changes in cash held for sale | — |  |  | — |  |  | — |  |  | 96 |  |  | — |  |  | 96 |  |
| Increase (decrease) in cash and cash equivalents | (11 | ) |  | 107 |  |  | 138 |  |  | 394 |  |  | (886 | ) |  | (258 | ) |
| Cash and cash equivalents at beginning of period | 11 |  |  | — |  |  | 244 |  |  | 324 |  |  | — |  |  | 579 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | 107 |  |  | $ | 382 |  |  | $ | 718 |  |  | $ | (886 | ) |  | $ | 321 |  |

[0000833444-17-000060:notes:114]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Operating Activities |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities | $ | 11 |  |  | $ | — |  |  | $ | 639 |  |  | $ | 1,245 |  |  | $ | — |  |  | $ | 1,895 |  |
| Investing Activities |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | — |  |  | (1,249 | ) |  | — |  |  | (1,249 | ) |
| Sale of property, plant and equipment | — |  |  | — |  |  | — |  |  | 32 |  |  | — |  |  | 32 |  |
| Acquisition of business, net of cash acquired | — |  |  | — |  |  | — |  |  | 353 |  |  | — |  |  | 353 |  |
| Business divestitures | — |  |  | — |  |  | — |  |  | 32 |  |  | — |  |  | 32 |  |
| Changes in long-term investments | — |  |  | — |  |  | 57 |  |  | (105 | ) |  | — |  |  | (48 | ) |
| Net change in intercompany loans | — |  |  | — |  |  | 10 |  |  | — |  |  | (10 | ) |  | — |  |
| Other | — |  |  | — |  |  | — |  |  | (7 | ) |  | — |  |  | (7 | ) |
| Net cash provided (used) by investing activities | — |  |  | — |  |  | 67 |  |  | (944 | ) |  | (10 | ) |  | (887 | ) |
| Financing Activities |  |  |  |  |  |  |  |  |  |  |  |
| Increase (decrease) in short-term debt - net | — |  |  | — |  |  | (462 | ) |  | 1,018 |  |  | — |  |  | 556 |  |
| Increase in long-term debt | — |  |  | — |  |  | — |  |  | 1,501 |  |  | — |  |  | 1,501 |  |
| Repayment of long-term debt | — |  |  | — |  |  | — |  |  | (1,299 | ) |  | — |  |  | (1,299 | ) |
| Debt financing costs | — |  |  | — |  |  | — |  |  | (45 | ) |  | — |  |  | (45 | ) |
| Stock repurchases | — |  |  | — |  |  | — |  |  | (501 | ) |  | — |  |  | (501 | ) |
| Payment of cash dividends | — |  |  | — |  |  | — |  |  | (915 | ) |  | — |  |  | (915 | ) |
| Proceeds from the exercise of stock options | 3 |  |  | — |  |  | — |  |  | 67 |  |  | — |  |  | 70 |  |
| Net intercompany loan borrowings (repayments) | — |  |  | — |  |  | — |  |  | (10 | ) |  | 10 |  |  | — |  |
| Cash paid to acquire a noncontrolling interest | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Dividends paid to noncontrolling interests | — |  |  | — |  |  | — |  |  | (306 | ) |  | — |  |  | (306 | ) |
| Other | (3 | ) |  | — |  |  | — |  |  | 11 |  |  | — |  |  | 8 |  |
| Net cash used by financing activities | — |  |  | — |  |  | (462 | ) |  | (481 | ) |  | 10 |  |  | (933 | ) |
| Effect of currency translation on cash | — |  |  | — |  |  | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Changes in cash held for sale | — |  |  | — |  |  | — |  |  | (61 | ) |  | — |  |  | (61 | ) |
| Increase (decrease) in cash and cash equivalents | 11 |  |  | — |  |  | 244 |  |  | (229 | ) |  | — |  |  | 26 |  |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | — |  |  | 553 |  |  | — |  |  | 553 |  |
| Cash and cash equivalents at end of period | $ | 11 |  |  | $ | — |  |  | $ | 244 |  |  | $ | 324 |  |  | $ | — |  |  | $ | 579 |  |


## us-gaap:ConsolidationPolicyTextBlock

[0000833444-17-000060:notes:115]
Principles of Consolidation

[0000833444-17-000060:notes:116]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries that are consolidated in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). All significant intercompany transactions have been eliminated. The results of companies acquired or disposed of during the year are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company’s interest exceeds 20% and the Company does not have a controlling interest.

[0000833444-17-000060:notes:117]
Under certain criteria as provided for in Financial Accounting Standards Board ("FASB") ASC 810, "Consolidation," the Company may consolidate a partially-owned affiliate. To determine whether to consolidate a partially-owned affiliate, the Company first determines if the entity is a variable interest entity ("VIE"). An entity is considered to be a VIE if it has one of the following characteristics: 1) the entity is thinly capitalized; 2) residual equity holders do not control the entity; 3) equity holders are shielded from economic losses or do not participate fully in the entity’s residual economics; or 4) the entity was established with non-substantive voting. If the entity meets one of these characteristics, the Company then determines if it is the primary beneficiary of the VIE. The party with the power to direct activities of the VIE that most significantly impact the VIE’s economic performance and the potential to absorb benefits or losses that could be significant to the VIE is considered the primary beneficiary and consolidates the VIE. If the entity is not considered a VIE, then the Company applies the voting interest model to determine whether or not the Company shall consolidate the partially-owned affiliate.

[0000833444-17-000060:notes:118]
Consolidated VIEs

[0000833444-17-000060:notes:119]
Based upon the criteria set forth in ASC 810, the Company has determined that it was the primary beneficiary in one VIE for the reporting period ended September 30, 2017 and three VIEs for the reporting period ended September 30, 2016, as the Company absorbs significant economics of the entities and has the power to direct the activities that are considered most significant to the entities.

[0000833444-17-000060:notes:120]
Two of the VIEs manufacture products in North America for the automotive industry. The Company funded the entities’ short-term liquidity needs through revolving credit facilities and had the power to direct the activities that were considered most significant to the entities through its key customer supply relationships. These VIEs were divested as a result of the Adient spin-off in the first quarter of fiscal 2017.

[0000833444-17-000060:notes:121]
In fiscal 2012, a pre-existing VIE accounted for under the equity method was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The Company acquired additional interests in two of the reorganized group entities. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is considered the primary beneficiary of one of the entities due to the Company’s power pertaining to decisions over significant activities of the entity. As such, this VIE has been consolidated within the Company’s consolidated statements of financial position. The impact of consolidation of the entity on the Company’s consolidated statements of income for the years ended September 30, 2017, 2016 and 2015 was not material. The VIE is named as a co-obligor under a third party debt agreement of $164 million, maturing in fiscal 2020, under which it could become subject to paying more than its allocated share of the third party debt in the event of bankruptcy of one or more of the other co-obligors. The other co-obligors, all related parties in which the Company is an equity investor, consist of the remaining group entities involved in the reorganization. As part of the overall reorganization transaction, the Company has also provided financial support to the group entities in the form of loans totaling $37 million, which are subordinate to the third party debt agreement. The Company is a significant customer of certain co-obligors, resulting in a remote possibility of loss. Additionally, the Company is subject to a floor guaranty expiring in fiscal 2022; in the event that the other owner party no longer owns any part of the group entities due to sale or transfer, the Company has guaranteed that the proceeds received from the sale or transfer will not be less than $25 million. The Company has partnered with the group entities to design and manufacture battery components for the Power Solutions business.

[0000833444-17-000060:notes:122]
The carrying amounts and classification of assets (none of which are restricted) and liabilities included in the Company’s consolidated statements of financial position for the consolidated VIEs are as follows (in millions):

[0000833444-17-000060:notes:123]
|  | September 30, |
|  | 2017 |  | 2016 |
| Current assets | $ | 2 |  |  | $ | 284 |  |
| Noncurrent assets | 53 |  |  | 98 |  |
| Total assets | $ | 55 |  |  | $ | 382 |  |
| Current liabilities | $ | 6 |  |  | $ | 230 |  |
| Noncurrent liabilities | 42 |  |  | 29 |  |
| Total liabilities | $ | 48 |  |  | $ | 259 |  |

[0000833444-17-000060:notes:124]
The Company did not have a significant variable interest in any other consolidated VIEs for the presented reporting periods.

[0000833444-17-000060:notes:125]
Nonconsolidated VIEs

[0000833444-17-000060:notes:126]
As mentioned previously within the "Consolidated VIEs" section above, in fiscal 2012, a pre-existing VIE was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is not considered to be the primary beneficiary of two of the entities as the Company cannot make key operating decisions considered to be most significant to the VIEs. Therefore, the entities are accounted for under the equity method of accounting as the Company’s interest exceeds 20% and the Company does not have a controlling interest. The Company’s maximum exposure to loss includes the partially-owned affiliate investment balance of $65 million and $59 million at September 30, 2017 and 2016, respectively, as well as the subordinated loan from the Company, third party debt agreement and floor guaranty mentioned previously within the "Consolidated VIEs" section above. Current liabilities due to the VIEs are not material and represent normal course of business trade payables for all presented periods.

[0000833444-17-000060:notes:127]
The Company did not have a significant variable interest in any other nonconsolidated VIEs for the presented reporting periods.


## us-gaap:DebtDisclosureTextBlock

[0000833444-17-000060:notes:128]
DEBT AND FINANCING ARRANGEMENTS

[0000833444-17-000060:notes:129]
Short-term debt consisted of the following (in millions):

[0000833444-17-000060:notes:130]
|  | September 30, |
|  | 2017 |  | 2016 |
| Bank borrowings and commercial paper | $ | 1,214 |  |  | $ | 1,078 |  |
| Weighted average interest rate on short-term debt outstanding | 1.6 | % |  | 1.1 | % |

[0000833444-17-000060:notes:131]
In connection with the Tyco Merger, JCI Inc. replaced its $2.5 billion committed five-year credit facility scheduled to mature in August 2018 with a $2.0 billion committed four-year credit facility scheduled to mature in August 2020. Additionally, TSarl, a wholly-owned subsidiary of Johnson Controls, entered into a $1.0 billion committed four-year credit facility scheduled to mature in August 2020. The facilities are used to support the Company's outstanding commercial paper. There were no draws on either committed credit facilities during the fiscal years ended September 30, 2017 and 2016. Commercial paper outstanding as of September 30, 2017 and 2016 was $954 million and $440 million, respectively.

[0000833444-17-000060:notes:132]
In September 2017, the Company entered into a 364-day 150 million euro, floating rate, term loan scheduled to expire in September 2018. Proceeds from the loan were used for general corporate purposes.

[0000833444-17-000060:notes:133]
In March 2017, the Company entered into a 364-day $150 million committed revolving credit facility scheduled to expire in March 2018. As of September 30, 2017, there were no draws on the facility.

[0000833444-17-000060:notes:134]
In February 2017, the Company entered into a 364-day $150 million committed revolving credit facility scheduled to expire in February 2018. As of September 30, 2017, there were no draws on the facility.

[0000833444-17-000060:notes:135]
In January 2017, the Company entered into a 364-day $250 million committed revolving credit facility scheduled to expire in January 2018. As of September 30, 2017, there were no draws on the facility.

[0000833444-17-000060:notes:136]
In December 2016, the Company entered into a 364-day 100 million euro floating rate term loan scheduled to mature in December 2017. Proceeds from the term loan were used for general corporate purposes. Principal and accrued interest were fully repaid in March 2017.

[0000833444-17-000060:notes:137]
In December 2016, a $100 million committed revolving credit facility expired. There were no draws on the facility.

[0000833444-17-000060:notes:138]
In November 2016, a $35 million committed revolving credit facility expired. There were no draws on the facility.

[0000833444-17-000060:notes:139]
In October 2016, the Company repaid two ten-month floating rate term loans totaling $325 million, plus accrued interest, scheduled to expire in October 2016.

[0000833444-17-000060:notes:140]
In October 2016, the Company repaid a nine-month $100 million floating rate term loan, plus accrued interest, scheduled to expire in November 2016.

[0000833444-17-000060:notes:141]
In October 2016, the Company repaid a nine-month 100 million euro floating rate term loan, plus accrued interest, scheduled to expire in October 2016.

[0000833444-17-000060:notes:142]
Long-term debt consisted of the following (in millions; due dates by fiscal year):

[0000833444-17-000060:notes:143]
|  | September 30, |
|  | 2017 |  | 2016 |
| Unsecured notes |  |  |  |
| JCI Inc. - 7.125% due in 2017 ($150 million par value) | $ | — |  |  | $ | 149 |  |
| JCI Inc. - 2.6% due in 2017 ($400 million par value) | — |  |  | 404 |  |
| JCI Inc. - 2.355% due in 2017 ($46 million par value) | — |  |  | 46 |  |
| JCI plc - 1.4% due in 2018 ($259 million par value) | 259 |  |  | — |  |
| JCI Inc. - 1.4% due in 2018 ($41 million par value in 2017; $300 million par value in 2016) | 42 |  |  | 301 |  |
| JCI plc - 3.75% due in 2018 ($49 million par value) | 49 |  |  | — |  |
| Tyco International Finance S.A. ("TIFSA") - 3.75% due in 2018 ($18 million par value in 2017; $67 million par value in 2016) | 18 |  |  | 69 |  |
| JCI plc - 5.00% due in 2020 ($453 million par value) | 452 |  |  | — |  |
| JCI Inc. - 5.00% due in 2020 ($47 million par value in 2017; $500 million par value in 2016) | 47 |  |  | 499 |  |
| JCI plc - 4.25% due in 2021 ($447 million par value) | 446 |  |  | — |  |
| JCI Inc. - 4.25% due in 2021 ($53 million par value in 2017; $500 million par value in 2016) | 53 |  |  | 498 |  |
| JCI plc - 3.75% due in 2022 ($428 million par value) | 427 |  |  | — |  |
| JCI Inc. - 3.75% due in 2022 ($22 million par value in 2017; $450 million par value in 2016) | 22 |  |  | 448 |  |
| JCI plc - 4.625% due in 2023 ($35 million par value) | 38 |  |  | — |  |
| TIFSA - 4.625% due in 2023 ($7 million par value in 2017; $42 million par value in 2016) | 8 |  |  | 46 |  |
| JCI plc - 1.00% due in 2023 (€1,000 million par value) | 1,171 |  |  | — |  |
| JCI plc - 3.625% due in 2024 ($468 million par value) | 468 |  |  | — |  |
| JCI Inc. - 3.625% due in 2024 ($31 million par value in 2017; $500 million par value in 2016) | 31 |  |  | 500 |  |
| Adient - 3.5% due in 2024 (€1,000 million par value) | — |  |  | 1,119 |  |
| JCI plc - 1.375% due in 2025 (€423 million par value) | 510 |  |  | — |  |
| TIFSA - 1.375% due in 2025 (€58 million par value in 2017; €500 million par value in 2016) | 70 |  |  | 571 |  |
| JCI plc - 3.90% due in 2026 ($698 million par value) | 763 |  |  | — |  |
| TIFSA - 3.90% due in 2026 ($51 million par value in 2017; $750 million par value in 2016) | 53 |  |  | 824 |  |
| Adient - 4.875% due in 2026 ($900 million par value) | — |  |  | 900 |  |
| JCI plc - 6.00% due in 2036 ($392 million par value) | 388 |  |  | — |  |
| JCI Inc. - 6.00% due in 2036 ($8 million par value in 2017; $400 million par value in 2016) | 8 |  |  | 396 |  |
| JCI plc - 5.70% due in 2041 ($270 million par value) | 269 |  |  | — |  |
| JCI Inc. - 5.70% due in 2041 ($30 million par value in 2017; $300 million par value in 2016) | 30 |  |  | 299 |  |
| JCI plc - 5.25% due in 2042 ($242 million par value) | 242 |  |  | — |  |
| JCI Inc. - 5.25% due in 2042 ($8 million par value in 2017; $250 million par value in 2016) | 8 |  |  | 250 |  |
| JCI plc - 4.625% due in 2044 ($445 million par value) | 441 |  |  | — |  |
| JCI Inc. - 4.625% due in 2044 ($6 million par value in 2017; $450 million par value in 2016) | 6 |  |  | 447 |  |
| JCI plc - 5.125% due in 2045 ($727 million par value) | 872 |  |  | — |  |
| TIFSA - 5.125% due in 2045 ($23 million par value in 2017; $750 million par value in 2016) | 23 |  |  | 903 |  |
| JCI plc - 6.95% due in 2046 ($121 million par value) | 121 |  |  | — |  |
| JCI Inc. - 6.95% due in 2046 ($4 million par value in 2017; $125 million par value in 2016) | 4 |  |  | 125 |  |
| JCI plc - 4.50% due in 2047 ($500 million par value) | 495 |  |  | — |  |
| JCI plc - 4.95% due in 2064 ($435 million par value) | 434 |  |  | — |  |
| JCI Inc. - 4.95% due in 2064 ($15 million par value in 2017; $450 million par value in 2016) | 15 |  |  | 449 |  |
| TSarl - Term Loan A - LIBOR plus 1.50% due in 2020 | 3,700 |  |  | 4,000 |  |

[0000833444-17-000060:notes:144]
| Adient - Term Loan A - LIBOR plus 1.005% due in 2021 | — |  |  | 1,500 |  |
| Capital lease obligations | 19 |  |  | 24 |  |
| Other foreign-denominated debt |  |  |  |
| Euro | 43 |  |  | 61 |  |
| Japanese Yen | 311 |  |  | 367 |  |
| Other | 47 |  |  | 39 |  |
| Gross long-term debt | 12,403 |  |  | 15,234 |  |
| Less: current portion | 394 |  |  | 628 |  |
| Less: debt issuance costs | 45 |  |  | 74 |  |
| Less: current portion - liabilities held for sale | — |  |  | 38 |  |
| Less: long-term debt - noncurrent liabilities held for sale | — |  |  | 3,441 |  |
| Net long-term debt | $ | 11,964 |  |  | $ | 11,053 |  |

[0000833444-17-000060:notes:145]
At September 30, 2017, the Company’s other foreign-denominated long-term debt was at fixed and floating rates with a weighted-average interest rate of 1.2%. At September 30, 2016, the Company’s other foreign-denominated long-term debt was at fixed and floating rates with a weighted-average interest rate of 1.3%.

[0000833444-17-000060:notes:146]
The installments of long-term debt maturing in subsequent fiscal years are: 2018 - $394 million; 2019 - $27 million; 2020 - $4,201 million; 2021 - $501 million; 2022 - $804 million; 2023 and thereafter - $6,476 million. The Company’s long-term debt includes various financial covenants, none of which are expected to restrict future operations.

[0000833444-17-000060:notes:147]
Total interest paid on both short and long-term debt for the fiscal years ended September 30, 2017, 2016 and 2015 was $448 million, $319 million and $373 million, respectively. The Company uses financial instruments to manage its interest rate exposure (see Note 10, "Derivative Instruments and Hedging Activities," and Note 11, "Fair Value Measurements," of the notes to consolidated financial statements). These instruments affect the weighted average interest rate of the Company’s debt and interest expense.

[0000833444-17-000060:notes:148]
Financing Arrangements

[0000833444-17-000060:notes:149]
Debt Exchange

[0000833444-17-000060:notes:150]
In connection with the Tyco Merger, on December 28, 2016, the Company completed its offer to exchange all validly tendered and accepted notes of certain series (the “existing notes”) issued by JCI Inc. or TIFSA, as applicable, each of which is a wholly owned subsidiary of the Company, for new notes (the "New Notes") to be issued by the Company, and the related solicitation of consents to amend the indentures governing the existing notes (the offers to exchange and the related consent solicitation together the “exchange offers”). Pursuant to the exchange offers, the Company exchanged approximately $5.6 billion of $6.0 billion in aggregate principal amount of dollar denominated notes and approximately 423 million euro of 500 million euro in aggregate principal amount of euro denominated notes. All validly tendered and accepted existing notes have been canceled. Immediately following such cancellation, $380.9 million aggregate principal amount of existing notes (not including the TIFSA Euro Notes) remained outstanding across seventeen series of dollar-denominated existing notes and 77.4 million euro aggregate principal amount of TIFSA Euro Notes remained outstanding across one series. In connection with the settlement of the exchange offers, the New Notes were registered under the Securities Act of 1933 and their terms are described in the Company’s Prospectus dated December 19, 2016, as filed with the SEC under Rule 424(b)(3) of the Act on that date. The issuance of the New Notes occurred on December 28, 2016. The new notes are unsecured and unsubordinated obligations of the Company and rank equally with all other unsecured and unsubordinated indebtedness of the Company issued from time to time.

[0000833444-17-000060:notes:151]
Financing in connection with Tyco Merger

[0000833444-17-000060:notes:152]
Simultaneously with the closing of the Tyco Merger on September 2, 2016, TSarl borrowed $4.0 billion under the Term Loan Credit Agreement dated as of March 10, 2016 with a syndicate of lenders, providing for a three and a half year senior unsecured term loan facility to finance the cash consideration for, and fees, expenses and costs incurred in connection with the Merger. During fiscal 2017, the Company partially repaid $300 million of the $4.0 billion floating rate term loan scheduled to expire in March 2020. As of September 30, 2017, the outstanding term loan balance was $3.7 billion. In October 2017, the Company completed the previously announced sale of its Scott Safety business to 3M, and net cash proceeds from the transaction of $1.9 billion were used to further repay a significant portion of the $4.0 billion term loan.

[0000833444-17-000060:notes:153]
Financing in connection with Adient spin-off

[0000833444-17-000060:notes:154]
In August 2016, Adient Global Holdings, Ltd. ("AGH"), a wholly-owned subsidiary of the Company, issued a one billion euro, 3.5% fixed rate, 8-year senior unsecured note scheduled to mature in August 2024. AGH also issued a $900 million, 4.875%, 10-year senior unsecured note scheduled to mature in August 2026. The proceeds from the notes were deposited into escrow and released in connection with the spin-off. The notes were not guaranteed by the Company or any of its subsidiaries that are not subsidiaries of Adient following the spin-off. Approximately $1.5 billion of the proceeds were distributed to the Company in connection with the spin-off and approximately $500 million of the proceeds were used for Adient's general corporate purposes.

[0000833444-17-000060:notes:155]
In July 2016, AGH entered into a 5-year, $1.5 billion Term A loan facility and a 5-year, $1.5 billion revolving credit facility scheduled to mature in July 2021. The term loan was fully drawn in August 2016. As of September 30, 2016, there were no draws on the revolving credit facility. Upon completion of the spin-off of Adient, AGH became a wholly-owned subsidiary of Adient. On the date of the spin-off, Adient and certain of its wholly-owned subsidiaries guaranteed the debt, and the guarantees of the Company were automatically released. The Company used the proceeds of the term loan to early repay its four tranches of euro-denominated floating rate credit facilities, totaling 390 million euro, that were outstanding as of September 30, 2016; three term loans of $500 million, $200 million and $125 million that were entered into during fiscal 2016, plus accrued interest, and a $90 million outstanding credit facility.  The remainder of the proceeds were used for general corporate purposes.

[0000833444-17-000060:notes:156]
Other financing arrangements

[0000833444-17-000060:notes:157]
In September 2017, the Company entered into a five-year 35 billion yen syndicated floating rate term loan scheduled to expire in September 2022. Proceeds from the loan were used for general corporate purposes.

[0000833444-17-000060:notes:158]
In July 2017, the Company retired $150 million in principal amount, plus accrued interest, of its 7.125% fixed rate notes that expired in July 2017.

[0000833444-17-000060:notes:159]
In July 2017, the Company repurchased, at a discount, 4 million euro of its TIFSA 1.375% fixed rate notes, plus accrued interest, scheduled to mature in 2025.

[0000833444-17-000060:notes:160]
In March 2017, the Company issued one billion euro in principal amount of 1.0% senior unsecured fixed rate notes due in fiscal 2023. Proceeds from the issuance were used to repay existing debt and for other general corporate purposes.

[0000833444-17-000060:notes:161]
In March 2017, the Company retired $46 million in principal amount, plus accrued interest, of its 2.355% fixed rate notes that expired in March 2017.

[0000833444-17-000060:notes:162]
In March and February 2017, the Company repurchased, at a discount, 15 million euro of its TIFSA 1.375% fixed rate notes, plus accrued interest, scheduled to expire in 2025.

[0000833444-17-000060:notes:163]
In February 2017, the Company issued $500 million aggregate principal amount of 4.5% senior unsecured fixed rate notes due in fiscal 2047. Proceeds from the issuance were used to repay outstanding commercial paper borrowings and for other general corporate purposes.

[0000833444-17-000060:notes:164]
In December 2016, the Company retired $400 million in principal amount, plus accrued interest, of its 2.6% fixed rate notes that expired in December 2016.

[0000833444-17-000060:notes:165]
In November 2016, the Company fully repaid its 37 billion yen syndicated floating rate term loan, plus accrued interest scheduled to expire in June 2020.

[0000833444-17-000060:notes:166]
Net Financing Charges


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-17-000060:notes:167]
DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES

[0000833444-17-000060:notes:168]
The Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities, stock-based compensation liabilities and interest rates. Under Company policy, the use of derivatives is restricted to those intended for hedging purposes; the use of any derivative instrument for speculative purposes is strictly prohibited. A description of each type of derivative utilized by the Company to manage risk is included in the following paragraphs. In addition, refer to Note 11, "Fair Value Measurements," of the notes to consolidated financial statements for information related to the fair value measurements and valuation methods utilized by the Company for each derivative type.

[0000833444-17-000060:notes:169]
Cash Flow Hedges

[0000833444-17-000060:notes:170]
The Company has global operations and participates in the foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange hedge contracts. The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. As cash flow hedges under ASC 815, "Derivatives and Hedging," the effective portion of the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. Any ineffective portion of the hedge is reflected in the consolidated statements of income. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates at September 30, 2017 and 2016.

[0000833444-17-000060:notes:171]
The Company selectively hedges anticipated transactions that are subject to commodity price risk, primarily using commodity hedge contracts, to minimize overall price risk associated with the Company’s purchases of lead, copper, tin, aluminum and polypropylene in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. As cash flow hedges, the effective portion of the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions, typically sales, occur and affect earnings. Any ineffective portion of the hedge is reflected in the consolidated statements of income. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in commodity prices at September 30, 2017 and 2016.

[0000833444-17-000060:notes:172]
Fair Value Hedges

[0000833444-17-000060:notes:173]
The Company selectively uses interest rate swaps to reduce market risk associated with changes in interest rates for its fixed-rate bonds. As fair value hedges, the interest rate swaps and related debt balances are valued under a market approach using publicized swap curves. Changes in the fair value of the swap and hedged portion of the debt are recorded in the consolidated statements of income. In the third quarter of fiscal 2014, the Company entered into four fixed to floating interest rate swaps totaling $400 million to hedge the coupon of its 2.6% notes that matured in December 2016, three fixed to floating interest rate swaps totaling $300 million to hedge the coupon of its 1.4% notes maturing November 2017 and one fixed to floating interest rate swap totaling $150 million to hedge the coupon of its 7.125% notes maturing in July 2017. In December 31, 2016, the remaining four outstanding interest rate swaps were terminated. The Company had no interest rate swaps outstanding at September 30, 2017. There were eight interest rate swaps outstanding as of September 30, 2016.

[0000833444-17-000060:notes:174]
Net Investment Hedges

[0000833444-17-000060:notes:175]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally. At September 30, 2017, the Company had one billion euro, 423 million euro and 58 million euro bonds designated as net investment hedges in the Company's net investment in Europe and 35 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan. At September 30, 2016, the Company had 37 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan and one billion euro and 500 million euro bonds designated as net investment hedges in the Company's net investment in Europe.

[0000833444-17-000060:notes:176]
Derivatives Not Designated as Hedging Instruments

[0000833444-17-000060:notes:177]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount. As of September 30, 2017, the Company hedged approximately 1.4 million of its ordinary shares, which have a cost basis of $58 million. As of September 30, 2016 the Company had no equity swaps outstanding.

[0000833444-17-000060:notes:178]
The Company also holds certain foreign currency forward contracts which do not qualify for hedge accounting treatment. The change in fair value of foreign currency exchange derivatives not designated as hedging instruments under ASC 815 are recorded in the consolidated statements of income.

[0000833444-17-000060:notes:179]
Fair Value of Derivative Instruments

[0000833444-17-000060:notes:180]
The following table presents the location and fair values of derivative instruments and hedging activities included in the Company’s consolidated statements of financial position (in millions):

[0000833444-17-000060:notes:181]
|  | Derivatives and Hedging ActivitiesDesignated as Hedging Instrumentsunder ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instrumentsunder ASC 815 |
|  | September 30, 2017 |  | September 30, 2016 |  | September 30, 2017 |  | September 30, 2016 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 27 |  |  | $ | 41 |  |  | $ | — |  |  | $ | 49 |  |
| Commodity derivatives | 9 |  |  | 4 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Interest rate swaps | — |  |  | 1 |  |  | — |  |  | — |  |
| Equity swap | — |  |  | — |  |  | 55 |  |  | — |  |
| Total assets | $ | 36 |  |  | $ | 46 |  |  | $ | 55 |  |  | $ | 49 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 21 |  |  | $ | 48 |  |  | $ | 25 |  |  | $ | 18 |  |
| Commodity derivatives | 1 |  |  | — |  |  | — |  |  | — |  |
| Liabilities held for sale |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | — |  |  | — |  |  | — |  |  | 5 |  |
| Current portion of long-term debt |  |  |  |  |  |  |  |
| Fixed rate debt swapped to floating | — |  |  | 551 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 2,058 |  |  | 938 |  |  | — |  |  | — |  |
| Fixed rate debt swapped to floating | — |  |  | 301 |  |  | — |  |  | — |  |
| Noncurrent liabilities held for sale |  |  |  |  |  |  |  |
| Foreign currency denominated debt | — |  |  | 1,119 |  |  | — |  |  | — |  |
| Total liabilities | $ | 2,080 |  |  | $ | 2,957 |  |  | $ | 25 |  |  | $ | 23 |  |

[0000833444-17-000060:notes:182]
Counterparty Credit Risk

[0000833444-17-000060:notes:183]
The use of derivative financial instruments exposes the Company to counterparty credit risk. The Company has established policies and procedures to limit the potential for counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association ("ISDA") master netting agreements with substantially all of its counterparties. The Company's derivative contracts do not contain any credit risk related contingent features and do not require collateral or other security to be furnished by the Company or the counterparties. The Company's exposure to credit risk associated with its derivative instruments is measured on an individual counterparty basis, as well as by groups of counterparties that share similar attributes. The Company does not anticipate any non-performance by any of its counterparties, and the concentration of risk with financial institutions does not present significant credit risk to the Company.

[0000833444-17-000060:notes:184]
The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position. Collateral is generally not required of the Company or the counterparties under the master netting agreements. As of September 30, 2017 and 2016, no cash collateral was received or pledged under the master netting agreements.

[0000833444-17-000060:notes:185]
Derivatives Impact on the Statements of Income and Statements of Comprehensive Income

[0000833444-17-000060:notes:186]
The following table presents the effective portion of pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges for the fiscal years ended September 30, 2017, 2016 and 2015 (in millions):

[0000833444-17-000060:notes:187]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Year Ended September 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Foreign currency exchange derivatives |  | $ | (1 | ) |  | $ | (18 | ) |  | $ | (5 | ) |
| Commodity derivatives |  | 14 |  |  | 3 |  |  | (19 | ) |
| Total |  | $ | 13 |  |  | $ | (15 | ) |  | $ | (24 | ) |

[0000833444-17-000060:notes:188]
The following table presents the location and amount of the effective portion of pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income for the fiscal years ended September 30, 2017, 2016 and 2015 (in millions):

[0000833444-17-000060:notes:189]
| Derivatives in ASC 815 Cash FlowHedging Relationships |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Year Ended September 30, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 25 |  |  | $ | 9 |  |  | $ | 25 |  |
| Foreign currency exchange derivatives |  | Income (loss) from discontinued operations |  | — |  |  | (30 | ) |  | (24 | ) |
| Commodity derivatives |  | Cost of sales |  | 8 |  |  | (12 | ) |  | (11 | ) |
| Forward treasury locks |  | Net financing charges |  | — |  |  | $ | 1 |  |  | $ | 1 |  |
| Total |  |  |  | $ | 33 |  |  | $ | (32 | ) |  | $ | (9 | ) |

[0000833444-17-000060:notes:190]
The following table presents the location and amount of pre-tax gains (losses) on fair value hedges recognized in the Company’s consolidated statements of income for the fiscal years ended September 30, 2017, 2016 and 2015 (in millions):

[0000833444-17-000060:notes:191]
| Derivatives in ASC 815 Fair Value Hedging Relationships |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Year Ended September 30, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Interest rate swap |  | Net financing charges |  | $ | (1 | ) |  | $ | (5 | ) |  | $ | 7 |  |
| Fixed rate debt swapped to floating |  | Net financing charges |  | 2 |  |  | 5 |  |  | (7 | ) |
| Total |  |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |

[0000833444-17-000060:notes:192]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income for the fiscal years ended September 30, 2017, 2016 and 2015 (in millions):

[0000833444-17-000060:notes:193]
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Year Ended September 30, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (1 | ) |  | $ | (20 | ) |  | $ | 2 |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | 44 |  |  | 21 |  |  | (37 | ) |
| Foreign currency exchange derivatives |  | Income tax provision |  | (3 | ) |  | 4 |  |  | — |  |
| Foreign currency exchange derivatives |  | Income (loss) from discontinued operations |  | 5 |  |  | (30 | ) |  | 20 |  |
| Equity swap |  | Selling, general and administrative |  | (3 | ) |  | 14 |  |  | (9 | ) |
| Total |  |  |  | $ | 42 |  |  | $ | (11 | ) |  | $ | (24 | ) |

[0000833444-17-000060:notes:194]
The effective portion of pre-tax gains (losses) recorded in foreign currency translation adjustment ("CTA") within other comprehensive income (loss) related to net investment hedges were $(138) million, $(82) million and $16 million for the years ended September 30, 2017, 2016 and 2015, respectively. For the years ended September 30, 2017, 2016 and 2015, no gains or losses were reclassified from CTA into income for the Company’s outstanding net investment hedges, and no gains or losses were recognized in income for the ineffective portion of cash flow hedges.


## us-gaap:DerivativesPolicyTextBlock

[0000833444-17-000060:notes:195]
Derivative Financial Instruments

[0000833444-17-000060:notes:196]
The Company has written policies and procedures that place all financial instruments under the direction of Corporate treasury and restrict all derivative transactions to those intended for hedging purposes. The use of financial instruments for speculative purposes is strictly prohibited. The Company selectively uses financial instruments to manage the market risk from changes in foreign exchange rates, commodity prices, stock-based compensation liabilities and interest rates.

[0000833444-17-000060:notes:197]
The fair values of all derivatives are recorded in the consolidated statements of financial position. The change in a derivative’s fair value is recorded each period in current earnings or accumulated other comprehensive income ("AOCI"), depending on whether the derivative is designated as part of a hedge transaction and if so, the type of hedge transaction. See Note 10, "Derivative Instruments and Hedging Activities," and Note 11, "Fair Value Measurements," of the notes to consolidated financial statements for disclosure of the Company’s derivative instruments and hedging activities.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-17-000060:notes:198]
STOCK-BASED COMPENSATION

[0000833444-17-000060:notes:199]
On September 2, 2016, the shareholders of the Company approved the Johnson Controls International plc 2012 Share and Incentive Plan (the "Plan"). The original effective date of this Plan was October 1, 2012. The Plan was amended and restated as of November 17, 2014 and was amended and restated again in connection with the Merger that was consummated on September 2, 2016 (the “Amendment Effective Date”). The amendment and restatement is intended to reflect the assumption into this Plan of the remaining share reserves under the Johnson Controls, Inc. 2012 Omnibus Incentive Plan and the Johnson Controls, Inc. 2003 Stock Plan for Outside Directors (the “Legacy Johnson Controls Plans”) as of the Amendment Effective Date. Following the Amendment Effective Date, no further awards may be made under the Legacy Johnson Controls Plans. The types of awards authorized by the Plan comprise of stock options, stock appreciation rights, performance shares, performance units and other stock-based awards. The Compensation Committee of the Company's Board of Directors will determine the types of awards to be granted to individual participants and the terms and conditions of the awards. The Plan provides that 76 million shares of the Company's common stock are reserved for issuance under the 2012 Plan, and 41 million shares remain available for issuance at September 30, 2017.

[0000833444-17-000060:notes:200]
Pursuant to the Merger Agreement, outstanding stock options held by Tyco employees on September 2, 2016 (the “Merger Date”) were converted into options to acquire the Company's shares using a 0.955-for-one share consolidation ratio in a manner designed to preserve the intrinsic value of such awards. In addition, pursuant to the Merger Agreement, nonvested restricted stock held by Tyco employees on the Merger Date were converted into nonvested restricted stock of the Company using the 0.955-for-one share consolidation ratio in a manner designed to preserve the intrinsic value of such awards. Outstanding performance share awards held by Tyco employees on the Merger Date were converted to nonvested restricted stock of the Company at the target performance level, and adjusted to reflect the 0.955-for-one consolidation ratio. Except for the conversion of stock options, nonvested restricted stock and performance share awards discussed herein, the material terms of the awards remained unchanged. The modifications made to the awards upon the Merger Date constituted modifications under the authoritative guidance for accounting for stock compensation. This guidance requires the Company to revalue the awards upon the Merger close and allocate the revised fair value between purchase consideration and continuing expense based on the ratio of service performed through the Merger Date over the total service period of the awards. The revised fair value allocated to post-merger services resulted in incremental expense which is recognized over the remaining service period of the awards. The portion of Tyco awards earned as of the Merger Date included as purchase consideration was $224 million. The total value of Tyco awards not earned as of the Merger Date was $101 million, which will be expensed over the remaining future vesting period.  Refer to Note 2, “Merger Transaction,” of the notes to consolidated financial statements for further information regarding the Merger.

[0000833444-17-000060:notes:201]
Pursuant to the Merger Agreement, outstanding stock options held by JCI Inc. employees on the Merger Date were converted one-for-one into options to acquire the Company's shares in a manner designed to preserve the intrinsic value of such awards. In addition, pursuant to the Merger Agreement, nonvested restricted stock held by JCI Inc. employees on the Merger Date was converted one-for-one into nonvested restricted stock of the Company in a manner designed to preserve the intrinsic value of such awards. Outstanding performance share awards held by JCI Inc. employees on the Merger Date were converted to nonvested restricted stock of the Company based on certain performance factors. Except for the conversion of stock options, nonvested restricted stock and performance share awards discussed herein, the material terms of the awards remained unchanged, and no incremental fair value resulted from the conversion. References to the Company’s stock throughout Note 12 refer to stock of JCI Inc. prior to the Merger Date and to stock of the Company subsequent to the Merger Date.

[0000833444-17-000060:notes:202]
In connection with the Adient spin-off, pursuant to the Employee Matters Agreement between the Company and Adient, outstanding stock options and SARs held on October 31, 2016 (the “Spin Date”) by employees remaining with the Company were converted into options and SARs of the Company using a 1.085317-for-one share ratio, which is based on the pre-spin and post-spin closing prices of the Company’s ordinary shares. The exercise prices for options and SARs were converted using the inverse ratio in a manner designed to preserve the intrinsic value of such awards. In addition, pursuant to the Employee Matters Agreement, nonvested restricted stock held on the Spin Date by employees remaining with the Company were converted into nonvested restricted stock of the Company using the 1.085317-for-one share ratio in a manner designed to preserve the intrinsic value of such awards. There were no performance share awards outstanding as of the Spin Date. Employees remaining with the Company did not receive stock-based compensation awards of Adient as a result of the spin-off. Except for the conversion of awards and related exercise prices discussed herein, the material terms of the awards remained unchanged. No incremental fair value resulted from the conversion of the awards; therefore, no additional compensation expense was recorded related to the award modification.

[0000833444-17-000060:notes:203]
Also in connection with the spin-off transaction, pursuant to the Employee Matters Agreement, employees of Adient were entitled to receive stock-based compensation awards of the Company and Adient in replacement of previously outstanding awards of the Company granted prior to the Spin Date. These awards include stock options, SARs and nonvested restricted stock. Upon the Spin Date, the existing awards held by Adient employees were converted into new awards of the Company and Adient on a pro rata basis and further adjusted based on a formula designed to preserve the intrinsic value of such awards. Additional compensation expense, if any, resulting from the modification of awards held by Adient employees is to be recorded by Adient.

[0000833444-17-000060:notes:204]
The Company has four share-based compensation plans, which are described below. For the fiscal year ended September 30, 2017, compensation cost charged against income for continuing operations, excluding the offsetting impact of outstanding equity swaps, for those plans was approximately $134 million, all of which was recorded in selling, general and administrative expenses.  For the fiscal year ended September 30, 2016, compensation cost charged against income for continuing operations, excluding the offsetting impact of outstanding equity swaps, for those plans was approximately $160 million, of which $121 million was recorded in selling, general and administrative expenses and $39 million was recorded in restructuring and impairment costs. For the fiscal year ended September 30, 2015, compensation cost charged against income for continuing operations, excluding the offsetting impact of outstanding equity swaps, for those plans was approximately $69 million, all of which was recorded in selling, general and administrative expenses. The total income tax benefit recognized for continuing operations in the consolidated statements of income for share-based compensation arrangements was approximately $53 million, $56 million and $28 million for the fiscal years ended September 30, 2017, 2016 and 2015, respectively. The Company applies a non-substantive vesting period approach whereby expense is accelerated for those employees that receive awards and are eligible to retire prior to the award vesting.

[0000833444-17-000060:notes:205]
Stock Options

[0000833444-17-000060:notes:206]
Stock options are granted with an exercise price equal to the market price of the Company’s stock at the date of grant. Stock option awards typically vest between two and three years after the grant date and expire ten years from the grant date.

[0000833444-17-000060:notes:207]
The fair value of each option is estimated on the date of grant using a Black-Scholes option valuation model that uses the assumptions noted in the following table. The expected life of options represents the period of time that options granted are expected to be outstanding, assessed separately for executives and non-executives. The risk-free interest rate for periods during the contractual life of the option is based on the U.S. Treasury yield curve in effect at the time of grant. For fiscal 2017, expected volatility is based on historical volatility of certain peer companies over the most recent period corresponding to the expected life as of the grant date. For fiscal 2016 and fiscal 2015, expected volatility is based on the historical volatility of the Company's stock and other factors. The expected dividend yield is based on the expected annual dividend as a percentage of the market value of the Company’s ordinary shares as of the grant date. The Company uses historical data to estimate option exercises and employee terminations within the valuation model.

[0000833444-17-000060:notes:208]
|  | Year Ended September 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Expected life of option (years) | 4.75 & 6.5 |  | 6.4 |  | 6.6 |
| Risk-free interest rate | 1.23% - 1.93% |  | 1.64% - 1.70% |  | 1.61% - 1.93% |
| Expected volatility of the Company’s stock | 24.60% |  | 36.00% |  | 36.00% |
| Expected dividend yield on the Company’s stock | 2.21% |  | 2.11% |  | 2.02% |

[0000833444-17-000060:notes:209]
A summary of stock option activity at September 30, 2017, and changes for the year then ended, is presented below:

[0000833444-17-000060:notes:210]
|  | WeightedAverageOption Price |  | SharesSubject toOption |  | WeightedAverageRemainingContractualLife (years) |  | AggregateIntrinsicValue(in millions) |
| Outstanding, September 30, 2016 | $ | 32.07 |  |  | 22,332,233 |  |  |  |  |  |
| Spin conversion | 31.02 |  |  | 1,547,096 |  |  |  |  |  |
| Granted | 41.73 |  |  | 2,841,686 |  |  |  |  |  |
| Exercised | 28.33 |  |  | (5,919,790 | ) |  |  |  |  |
| Forfeited or expired | 42.33 |  |  | (1,070,782 | ) |  |  |  |  |
| Outstanding, September 30, 2017 | $ | 32.76 |  |  | 19,730,443 |  |  | 4.9 |  | $ | 187 |  |
| Exercisable, September 30, 2017 | $ | 33.16 |  |  | 15,054,034 |  |  | 4.0 |  | $ | 180 |  |

[0000833444-17-000060:notes:211]
The weighted-average grant-date fair value of options granted during the fiscal years ended September 30, 2017, 2016 and 2015 was $7.81, $13.14 and $15.51, respectively.

[0000833444-17-000060:notes:212]
The total intrinsic value of options exercised during the fiscal years ended September 30, 2017, 2016 and 2015 was approximately $81 million, $39 million and $227 million, respectively.

[0000833444-17-000060:notes:213]
In conjunction with the exercise of stock options granted, the Company received cash payments for the fiscal years ended September 30, 2017, 2016 and 2015 of approximately $157 million, $70 million and $275 million, respectively.

[0000833444-17-000060:notes:214]
The Company has elected to utilize the alternative transition method for calculating the tax effects of stock-based compensation. The alternative transition method includes computational guidance to establish the beginning balance of the additional paid-in capital pool ("APIC Pool") related to the tax effects of employee stock-based compensation, and a simplified method to determine the subsequent impact on the APIC Pool for employee stock-based compensation awards that are vested and outstanding upon adoption of ASC 718, "Compensation - Stock Compensation." The tax benefit from the exercise of stock options, which is recorded in capital in excess of par value, was $4 million, $11 million and $59 million for the fiscal years ended September 30, 2017, 2016 and 2015, respectively. The Company does not settle stock options granted under share-based payment arrangements for cash.

[0000833444-17-000060:notes:215]
At September 30, 2017, the Company had approximately $21 million of total unrecognized compensation cost related to nonvested stock options granted for continuing operations. That cost is expected to be recognized over a weighted-average period of 1.9 years.

[0000833444-17-000060:notes:216]
Stock Appreciation Rights ("SARs")

[0000833444-17-000060:notes:217]
SARs vest under the same terms and conditions as stock option awards; however, they are settled in cash for the difference between the market price on the date of exercise and the exercise price. As a result, SARs are recorded in the Company’s consolidated statements of financial position as a liability until the date of exercise.

[0000833444-17-000060:notes:218]
The fair value of each SAR award is estimated using a similar method described for stock options. The fair value of each SAR award is recalculated at the end of each reporting period and the liability and expense are adjusted based on the new fair value.

[0000833444-17-000060:notes:219]
A summary of SAR activity at September 30, 2017, and changes for the year then ended, is presented below:

[0000833444-17-000060:notes:220]
|  | WeightedAverageSAR Price |  | SharesSubject toSAR |  | WeightedAverageRemainingContractualLife (years) |  | AggregateIntrinsicValue(in millions) |
| Outstanding, September 30, 2016 | $ | 30.49 |  |  | 1,201,165 |  |  |  |  |  |
| Spin conversion | 28.06 |  |  | 29,241 |  |  |  |  |  |
| Granted | 41.73 |  |  | 15,693 |  |  |  |  |  |
| Exercised | 29.62 |  |  | (290,378 | ) |  |  |  |  |
| Forfeited or expired | 39.17 |  |  | (62,410 | ) |  |  |  |  |
| Outstanding, September 30, 2017 | $ | 27.02 |  |  | 893,311 |  |  | 3.8 |  | $ | 12 |  |
| Exercisable, September 30, 2017 | $ | 26.40 |  |  | 853,260 |  |  | 3.5 |  | $ | 12 |  |

[0000833444-17-000060:notes:221]
In conjunction with the exercise of SARs granted, the Company made payments of $4 million, $8 million and $19 million during the fiscal years ended September 30, 2017, 2016 and 2015, respectively.

[0000833444-17-000060:notes:222]
Restricted (Nonvested) Stock

[0000833444-17-000060:notes:223]
The Plan provides for the award of restricted stock or restricted stock units to certain employees. These awards are typically share settled unless the employee is a non-U.S. employee or elects to defer settlement until retirement at which point the award would be settled in cash. Restricted awards typically vest after three years from the grant date. The Plan allows for different vesting terms on specific grants with approval by the Board of Directors. The value of restricted awards is based on the closing market value of the Company’s ordinary shares on the date of grant.

[0000833444-17-000060:notes:224]
A summary of the status of the Company’s nonvested restricted stock awards at September 30, 2017, and changes for the fiscal year then ended, is presented below:

[0000833444-17-000060:notes:225]
|  | WeightedAveragePrice |  | Shares/UnitsSubject toRestriction |
| Nonvested, September 30, 2016 | $ | 47.27 |  |  | 9,566,044 |  |
| Spin conversion | 43.88 |  |  | 482,312 |  |
| Granted | 41.66 |  |  | 1,773,465 |  |
| Vested | 40.83 |  |  | (3,045,375 | ) |
| Forfeited | 44.53 |  |  | (1,814,740 | ) |
| Nonvested, September 30, 2017 | $ | 44.48 |  |  | 6,961,706 |  |

[0000833444-17-000060:notes:226]
At September 30, 2017, the Company had approximately $101 million of total unrecognized compensation cost related to nonvested restricted stock arrangements granted for continuing operations. That cost is expected to be recognized over a weighted-average period of 1.7 years.

[0000833444-17-000060:notes:227]
Performance Share Awards

[0000833444-17-000060:notes:228]
The Plan permits the grant of performance-based share unit ("PSU") awards. The PSUs are generally contingent on the achievement of pre-determined performance goals over a three-year performance period as well as on the award holder's continuous employment until the vesting date. The PSUs are also indexed to the achievement of specified levels of total shareholder return versus a peer group over the performance period. Each PSU that is earned will be settled with shares of the Company's ordinary shares following the completion of the performance period, unless the award holder elected to defer a portion or all of the award until retirement which would then be settled in cash.

[0000833444-17-000060:notes:229]
The fair value of each PSU is estimated on the date of grant using a Monte Carlo simulation that uses the assumptions noted in the following table. The risk-free interest rate for periods during the contractual life of the PSU is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on historical volatility of certain peer companies over the most recent three-year period as of the grant date.

[0000833444-17-000060:notes:230]
A summary of the status of the Company’s nonvested PSUs at September 30, 2017, and changes for the fiscal year then ended, is presented below:

[0000833444-17-000060:notes:231]
|  | WeightedAveragePrice |  | Shares/UnitsSubject toPSU |
| Nonvested, September 30, 2016 | $ | — |  |  | — |  |
| Granted | 43.43 |  |  | 1,259,342 |  |
| Forfeited | 44.98 |  |  | (139,954 | ) |
| Nonvested, September 30, 2017 | $ | 43.24 |  |  | 1,119,388 |  |


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-17-000060:notes:232]
DISCONTINUED OPERATIONS

[0000833444-17-000060:notes:233]
Adient

[0000833444-17-000060:notes:234]
As discussed in Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements, on October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience Business from Johnson Controls to Adient plc. The Company did not retain any equity interest in Adient plc. During the first quarter of fiscal 2017, the Company determined that Adient met the criteria to be classified as a discontinued operation and, as a result, Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation, and assets and liabilities are classified as assets and liabilities held for sale. The Company did not allocate any general corporate overhead to discontinued operations.

[0000833444-17-000060:notes:235]
For the fiscal year ended September 30, 2017, the income from discontinued operations before income taxes included separation costs of $79 million. For the fiscal year ended September 30, 2016, the income from discontinued operations before income taxes included separation costs ($418 million), significant restructuring and impairment costs ($332 million), and net mark-to market losses on pension and postretirement plans ($110 million). For the fiscal year ended September 30, 2015, the income from discontinued operations before income taxes included significant restructuring and impairment costs ($182 million), a net gain on a business divestiture ($155 million), transaction and separation costs ($52 million), and net mark-to market losses on pension and postretirement plans ($6 million).

[0000833444-17-000060:notes:236]
For the fiscal year ended September 30, 2017, the effective tax rate was more than the U.S. federal statutory rate of 35% primarily due to the tax impacts of separation costs and Adient spin-off related tax expense, partially offset by non-U.S. tax rate differentials.

[0000833444-17-000060:notes:237]
In preparation for the spin-off of the Automotive Experience business in the first quarter of fiscal 2017, the Company incurred incremental tax expense of $95 million in fiscal 2016. The Company also completed substantial business reorganizations which resulted in total tax charges of $1,891 million in fiscal 2016. Included in this amount is the tax charge provided for in the third quarter of fiscal 2016 of $85 million for changes in entity tax status and the charge provided for in the second quarter of fiscal 2016 of $780 million for income tax expense on foreign undistributed earnings of certain non-U.S. subsidiaries.

[0000833444-17-000060:notes:238]
In fiscal 2016, the Company did provide U.S. income tax expense related to the restructuring and repatriation of cash for certain non-U.S. subsidiaries in connection with the Automotive Experience planned spin-off. At September 30, 2016 the Company needed to complete the final steps of Automotive Experience restructuring and, as a result, the Company provided deferred taxes of $24 million for the U.S. income tax expense on outside basis differences that reversed upon the completion of the restructuring.

[0000833444-17-000060:notes:239]
In the fourth quarter of fiscal 2015, the Company completed its global automotive interiors joint venture with Yanfeng Automotive Trim Systems. Refer to Note 3, "Acquisitions and Divestitures," of the notes to consolidated financial statements for additional information. In connection with the divestiture of the Interiors business, the Company recorded a pre-tax gain on divestiture of $145 million, $38 million net of tax. The tax impact of the gain is due to the jurisdictional mix of gains and losses on the divestiture, which resulted in non-benefited expenses in certain countries and taxable gains in other countries. In addition, in the third and fourth quarters of fiscal 2015, the Company provided income tax expense for repatriation of cash and other tax reserves associated with the Automotive Experience Interiors joint venture transaction, which resulted in a tax charge of $75 million and $223 million, respectively.

[0000833444-17-000060:notes:240]
GWS

[0000833444-17-000060:notes:241]
On March 31, 2015, the Company announced that it had reached a definitive agreement to sell the remainder of the GWS business to CBRE, subject to regulatory and other approvals. The sale closed on September 1, 2015. The agreement includes a 10-year strategic relationship between the Company and CBRE. The Company is the preferred provider of HVAC equipment, building automation systems and related services to the portfolio of real estate and corporate facilities managed globally by CBRE and GWS. The Company also engages GWS for facility management services. The annual cash flows resulting from these activities with the legacy GWS business are not currently significant nor are they expected to become significant in the future.

[0000833444-17-000060:notes:242]
At March 31, 2015, the Company determined that its GWS segment met the criteria to be classified as a discontinued operation, The Company did not allocate any general corporate overhead to discontinued operations.

[0000833444-17-000060:notes:243]
There were no amounts related to the GWS business classified as discontinued operations for the fiscal years ended September 30, 2017 and 2016. The following table summarizes the results of GWS, reclassified as discontinued operations for the fiscal year ended September 30, 2015 (in millions):

[0000833444-17-000060:notes:244]
|  | Year Ended September 30, |
|  | 2015 |
| Net sales | $ | 3,025 |  |
| Income from discontinued operations before income taxes | 1,203 |  |
| Provision for income taxes on discontinued operations | 1,075 |  |
| Income from discontinued operations attributable to noncontrolling interests, net of tax | 4 |  |
| Income from discontinued operations | $ | 124 |  |

[0000833444-17-000060:notes:245]
For the fiscal year ended September 30, 2015, the income from discontinued operations before income taxes included a $940 million gain on divestiture for the remainder of the GWS business, a $200 million gain on divestiture of the Company's interest in two GWS joint ventures and transaction costs of $87 million.

[0000833444-17-000060:notes:246]
The effective tax rate is different than the U.S. statutory rate for fiscal 2015 primarily due to $680 million tax expense for repatriation of cash and other tax reserves, and the tax consequences of the sale of the GWS joint ventures ($73 million) and the remaining business ($297 million).

[0000833444-17-000060:notes:247]
During the second quarter of fiscal 2017, the Company signed a definitive agreement to sell its Scott Safety business of the Global Products segment to 3M Company. The transaction closed on October 4, 2017. The assets and liabilities of this business are presented as held for sale in the consolidated statements of financial position as of September 30, 2017. The business did not meet the criteria to be classified as a discontinued operation as the divestiture of the Scott Safety business will not have a major effect on the Company’s operations and financial results.

[0000833444-17-000060:notes:248]
The following table summarizes the carrying value of the Scott Safety assets and liabilities held for sale at September 30, 2017 (in millions):

[0000833444-17-000060:notes:249]
|  |  | September 30, 2017 |  |
| Cash |  | $ | 9 |  |
| Accounts receivable - net |  | 100 |  |
| Inventories |  | 75 |  |
| Other current assets |  | 5 |  |
| Assets held for sale |  | $ | 189 |  |
| Property, plant and equipment - net |  | $ | 79 |  |
| Goodwill |  | 1,248 |  |
| Other intangible assets - net |  | 592 |  |
| Other noncurrent assets |  | 1 |  |
| Noncurrent assets held for sale |  | $ | 1,920 |  |
| Accounts payable |  | $ | 37 |  |
| Accrued compensation and benefits |  | 10 |  |
| Other current liabilities |  | 25 |  |
| Liabilities held for sale |  | $ | 72 |  |
| Other noncurrent liabilities |  | $ | 173 |  |
| Noncurrent liabilities held for sale |  | $ | 173 |  |

[0000833444-17-000060:notes:250]
The following table summarizes the carrying value of Adient, classified as assets and liabilities held for sale at September 30, 2016 (in millions):

[0000833444-17-000060:notes:251]
|  |  | September 30, 2016 |
| Cash |  | $ | 105 |  |
| Cash in escrow related to Adient debt |  | 2,034 |  |
| Accounts receivable - net |  | 2,071 |  |
| Inventories |  | 672 |  |
| Other current assets |  | 756 |  |
| Assets held for sale |  | $ | 5,638 |  |
| Property, plant and equipment - net |  | $ | 2,240 |  |
| Goodwill |  | 2,385 |  |
| Other intangible assets - net |  | 113 |  |
| Investments in partially-owned affiliates |  | 1,745 |  |
| Other noncurrent assets |  | 891 |  |
| Noncurrent assets held for sale |  | $ | 7,374 |  |
| Short-term debt |  | $ | 41 |  |
| Current portion of long-term debt |  | 38 |  |
| Accounts payable |  | 2,764 |  |
| Accrued compensation and benefits |  | 430 |  |
| Other current liabilities |  | 975 |  |
| Liabilities held for sale |  | $ | 4,248 |  |
| Long-term debt |  | $ | 3,441 |  |
| Pension and postretirement benefits |  | 188 |  |
| Other noncurrent liabilities |  | 259 |  |
| Noncurrent liabilities held for sale |  | $ | 3,888 |  |

[0000833444-17-000060:notes:252]
The following table summarizes depreciation and amortization, capital expenditures, and significant operating and investing non-cash items related to Adient for the fiscal years ended September 30, 2016 and 2015 (in millions):

[0000833444-17-000060:notes:253]
|  |  | Year Ended September 30, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Depreciation and amortization |  | $ | 29 |  |  | $ | 331 |  |  | $ | 333 |  |
| Pension and postretirement benefit expense |  | — |  |  | 113 |  |  | 15 |  |
| Equity in earnings of partially-owned affiliates |  | (31 | ) |  | (357 | ) |  | (295 | ) |
| Deferred income taxes |  | 562 |  |  | (476 | ) |  | (50 | ) |
| Non-cash restructuring and impairment costs |  | — |  |  | 87 |  |  | 27 |  |
| Gain on divestitures |  | — |  |  | — |  |  | (155 | ) |
| Equity-based compensation |  | 1 |  |  | 16 |  |  | 16 |  |
| Accrued income taxes |  | (808 | ) |  | — |  |  | — |  |
| Other |  | — |  |  | (2 | ) |  | (4 | ) |
| Capital expenditures |  | (91 | ) |  | (395 | ) |  | (455 | ) |

[0000833444-17-000060:notes:254]
During the second quarter of fiscal 2017, the Company completed the divestiture of its ADT security business in South Africa within the Building Solutions EMEA/LA segment. The assets and liabilities of this business were presented as held for sale in the consolidated statements of financial position as of September 30, 2016. The business did not meet the criteria to be classified as a discontinued operation.

[0000833444-17-000060:notes:255]
The following table summarizes the carrying value of  ADT security business in South Africa assets and liabilities at  September 30, 2016 (in millions):

[0000833444-17-000060:notes:256]
|  |  | September 30, 2016 |  |
| Accounts receivable - net |  | $ | 9 |  |
| Inventories |  | 7 |  |
| Other current assets |  | 3 |  |
| Property, plant and equipment - net |  | 15 |  |
| Goodwill |  | 89 |  |
| Other intangible assets - net |  | 30 |  |
| Other noncurrent assets |  | 4 |  |
| Assets held for sale |  | $ | 157 |  |
| Accounts payable |  | $ | 9 |  |
| Other current liabilities |  | 19 |  |
| Liabilities held for sale |  | $ | 28 |  |

[0000833444-17-000060:notes:257]
At September 30, 2016, $17 million of certain Corporate assets were classified as held for sale. The assets were sold during the second quarter of fiscal 2017.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000833444-17-000060:notes:258]
Earnings Per Share

[0000833444-17-000060:notes:259]
The Company presents both basic and diluted earnings per share ("EPS") amounts. Basic EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of common shares outstanding during the reporting period. Diluted EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of common shares and common equivalent shares outstanding during the reporting period that are calculated using the treasury stock method for stock options, unvested restricted stock and unvested performance share awards. See Note 13, "Earnings per Share," of the notes to consolidated financial statements for the calculation of earnings per share.


## us-gaap:EarningsPerShareTextBlock

[0000833444-17-000060:notes:260]
EARNINGS PER SHARE

[0000833444-17-000060:notes:261]
The Company presents both basic and diluted EPS amounts. Basic EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares outstanding during the reporting period. Diluted EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares and ordinary equivalent shares outstanding during the reporting period that are calculated using the treasury stock method for stock options, unvested restricted stock and unvested performance share awards. The treasury stock method assumes that the Company uses the proceeds from the exercise of stock option awards to repurchase ordinary shares at the average market price during the period. The assumed proceeds under the treasury stock method include the purchase price that the grantee will pay in the future, compensation cost for future service that the Company has not yet recognized and any windfall tax benefits that would be credited to capital in excess of par value when the award generates a tax deduction. If there would be a shortfall resulting in a charge to capital in excess of par value, such an amount would be a reduction of the proceeds. For unvested restricted stock and unvested performance share awards, assumed proceeds under the treasury stock method would include unamortized compensation cost and windfall tax benefits or shortfalls.

[0000833444-17-000060:notes:262]
The following table reconciles the numerators and denominators used to calculate basic and diluted earnings per share (in millions):

[0000833444-17-000060:notes:263]
|  | Year Ended September 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Income (Loss) Available to Ordinary Shareholders |  |  |  |  |  |
| Income from continuing operations | $ | 1,654 |  |  | $ | 732 |  |  | $ | 814 |  |
| Income (loss) from discontinued operations | (43 | ) |  | (1,600 | ) |  | 749 |  |
| Basic and diluted income (loss) available to shareholders | $ | 1,611 |  |  | $ | (868 | ) |  | $ | 1,563 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |
| Basic weighted average shares outstanding | 935.3 |  |  | 667.4 |  |  | 655.2 |  |
| Effect of dilutive securities: |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 9.3 |  |  | 5.2 |  |  | 6.3 |  |
| Diluted weighted average shares outstanding | 944.6 |  |  | 672.6 |  |  | 661.5 |  |
| Antidilutive Securities |  |  |  |  |  |
| Options to purchase common shares | 0.2 |  |  | — |  |  | 0.4 |  |

[0000833444-17-000060:notes:264]
During the three months ended September 30, 2017 and 2016, the Company declared a dividend of $0.25 and $0.29, respectively, per share. During the twelve months ended September 30, 2017 and 2016, the Company declared four quarterly dividends totaling $1.00 and $1.16, respectively, per share.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0000833444-17-000060:notes:265]
NONCONSOLIDATED PARTIALLY-OWNED AFFILIATES

[0000833444-17-000060:notes:266]
Investments in the net assets of nonconsolidated partially-owned affiliates are stated in the "Investments in partially-owned affiliates" line in the consolidated statements of financial position as of September 30, 2017 and 2016. Equity in the net income of nonconsolidated partially-owned affiliates is stated in the "Equity income" line in the consolidated statements of income for the years ended September 30, 2017, 2016 and 2015.

[0000833444-17-000060:notes:267]
The following table presents summarized financial data for the Company’s nonconsolidated partially-owned affiliates. The amounts included in the table below represent 100% of the results of continuing operations of such nonconsolidated partially-owned affiliates accounted for under the equity method.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-17-000060:notes:268]
FAIR VALUE MEASUREMENTS

[0000833444-17-000060:notes:269]
ASC 820, "Fair Value Measurement," defines fair value as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. ASC 820 also establishes a three-level fair value hierarchy that prioritizes information used in developing assumptions when pricing an asset or liability as follows:

[0000833444-17-000060:notes:270]
Level 1: Observable inputs such as quoted prices in active markets for identical assets or liabilities;

[0000833444-17-000060:notes:271]
Level 2: Quoted prices in active markets for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active, or inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and

[0000833444-17-000060:notes:272]
Level 3: Unobservable inputs where there is little or no market data, which requires the reporting entity to develop its own assumptions.

[0000833444-17-000060:notes:273]
ASC 820 requires the use of observable market data, when available, in making fair value measurements. When inputs used to measure fair value fall within different levels of the hierarchy, the level within which the fair value measurement is categorized is based on the lowest level input that is significant to the fair value measurement.

[0000833444-17-000060:notes:274]
Recurring Fair Value Measurements

[0000833444-17-000060:notes:275]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value as of September 30, 2017 and 2016 (in millions):

[0000833444-17-000060:notes:276]
|  | Fair Value Measurements Using: |
|  | Total as ofSeptember 30, 2017 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 27 |  |  | $ | — |  |  | $ | 27 |  |  | $ | — |  |
| Commodity derivatives | 9 |  |  | — |  |  | 9 |  |  | — |  |
| Exchange traded funds (fixed income)1 | 14 |  |  | 14 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Investments in marketable common stock | 10 |  |  | 10 |  |  | — |  |  | — |  |
| Deferred compensation plan assets | 92 |  |  | 92 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 155 |  |  | 155 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 100 |  |  | 100 |  |  | — |  |  | — |  |
| Equity swap | 55 |  |  | — |  |  | 55 |  |  | — |  |
| Total assets | $ | 462 |  |  | $ | 371 |  |  | $ | 91 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 46 |  |  | $ | — |  |  | $ | 46 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Total liabilities | $ | 47 |  |  | $ | — |  |  | $ | 47 |  |  | $ | — |  |

[0000833444-17-000060:notes:277]
|  | Fair Value Measurements Using: |
|  | Total as ofSeptember 30, 2016 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 90 |  |  | $ | — |  |  | $ | 90 |  |  | $ | — |  |
| Commodity derivatives | 4 |  |  | — |  |  | 4 |  |  | — |  |
| Exchange traded funds (fixed income)1 | 15 |  |  | 15 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Interest rate swaps | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Investments in marketable common stock | 3 |  |  | 3 |  |  | — |  |  | — |  |
| Deferred compensation plan assets | 81 |  |  | 81 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 163 |  |  | 163 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 86 |  |  | 86 |  |  | — |  |  | — |  |
| Total assets | $ | 443 |  |  | $ | 348 |  |  | $ | 95 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 66 |  |  | $ | — |  |  | $ | 66 |  |  | $ | — |  |
| Liabilities held for sale |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | 5 |  |  | — |  |  | 5 |  |  | — |  |
| Current portion of long-term debt |  |  |  |  |  |  |  |
| Fixed rate debt swapped to floating | 551 |  |  | — |  |  | 551 |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Fixed rate debt swapped to floating | 301 |  |  | — |  |  | 301 |  |  | — |  |
| Total liabilities | $ | 923 |  |  | $ | — |  |  | $ | 923 |  |  | $ | — |  |

[0000833444-17-000060:notes:278]
1Classified as restricted investments for payment of asbestos liabilities. See Note 23, "Commitments and Contingencies" of the notes to consolidated financial statements for further details.

[0000833444-17-000060:notes:279]
Valuation Methods

[0000833444-17-000060:notes:280]
Foreign currency exchange derivatives: The foreign currency exchange derivatives are valued under a market approach using publicized spot and forward prices.

[0000833444-17-000060:notes:281]
Commodity derivatives: The commodity derivatives are valued under a market approach using publicized prices, where available, or dealer quotes.

[0000833444-17-000060:notes:282]
Interest rate swaps and related debt: The interest rate swaps and related debt balances are valued under a market approach using publicized swap curves.

[0000833444-17-000060:notes:283]
Equity swaps: The equity swaps are valued under a market approach as the fair value of the swaps is equal to the Company’s stock price at the reporting period date.

[0000833444-17-000060:notes:284]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices.

[0000833444-17-000060:notes:285]
Investments in marketable common stock and exchange traded funds: Investments in marketable common stock and exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. There was an unrealized gain recorded on these investments of $5 million for the year ended September 30, 2017 within AOCI in the consolidated statements of financial position. There was an unrealized loss recorded on these investments of $1 million for the year ended September 30, 2016 within AOCI in the consolidated statements of financial position.

[0000833444-17-000060:notes:286]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. The fair value of long-term debt was $12.7 billion and $15.7 billion at September 30, 2017 and 2016, respectively. The fair value of public debt was $8.6 billion and $9.7 billion at September 30, 2017 and September 30, 2016, respectively, which was determined primarily using market quotes classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was $4.1 billion and $6.0 billion at September 30, 2017 and September 30, 2016, respectively, which was determined based on quoted market prices for similar instruments classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:FiniteLivedAndIndefiniteLivedIntangibleAssetsAcquiredAsPartOfBusinessCombinationTableTextBlock

[0000833444-17-000060:notes:287]
The purchase price allocation to identifiable intangible assets acquired are as follows:

[0000833444-17-000060:notes:288]
|  |  | Fair Value (in millions) |  | Weighted Average Life (in years) |
| Customer relationships |  | $ | 2,280 |  |  | 12 |
| Completed technology |  | 1,650 |  |  | 11 |
| Other definite-lived intangibles |  | 214 |  |  | 7 |
| Indefinite-lived trademarks |  | 2,080 |  |  |  |
| Other indefinite-lived intangibles |  | 90 |  |  |  |
| In-process research and development |  | 70 |  |  |  |
| Total identifiable intangible assets |  | $ | 6,384 |  |  |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000833444-17-000060:notes:289]
Foreign Currency Translation

[0000833444-17-000060:notes:290]
Substantially all of the Company’s international operations use the respective local currency as the functional currency. Assets and liabilities of international entities have been translated at period-end exchange rates, and income and expenses have been translated using average exchange rates for the period. Monetary assets and liabilities denominated in non-functional currencies are adjusted to reflect period-end exchange rates. The aggregate transaction gains (losses), net of the impact of foreign currency hedges, included in net income for the years ended September 30, 2017, 2016 and 2015 were $94 million, $(95) million and $(119) million, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-17-000060:notes:291]
GOODWILL AND OTHER INTANGIBLE ASSETS

[0000833444-17-000060:notes:292]
Effective July 1, 2017, the Company reorganized the reportable segments within its Building Technologies & Solutions business to align with its new management reporting structure and business activities. Historical information has been revised to reflect the new Building Technologies & Solutions reportable segments. Refer to Note 19, "Segment Information," of the notes to consolidated financial statements for further information.

[0000833444-17-000060:notes:293]
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the fiscal years ended September 30, 2017 and 2016 were as follows (in millions):

[0000833444-17-000060:notes:294]
|  | September 30, 2015 |  | BusinessAcquisitions |  | BusinessDivestitures |  | Currency Translation and Other |  | September 30, 2016 |
| Building Technologies & Solutions |  |  |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 930 |  |  | $ | 8,829 |  |  | $ | (3 | ) |  | $ | (22 | ) |  | $ | 9,734 |  |
| Building Solutions EMEA/LA | 195 |  |  | 1,787 |  |  | — |  |  | (1 | ) |  | 1,981 |  |
| Building Solutions Asia Pacific | 310 |  |  | 968 |  |  | — |  |  | (18 | ) |  | 1,260 |  |
| Global Products | 1,943 |  |  | 5,038 |  |  | (16 | ) |  | (2 | ) |  | 6,963 |  |
| Power Solutions | 1,082 |  |  | — |  |  | — |  |  | 4 |  |  | 1,086 |  |
| Total | $ | 4,460 |  |  | $ | 16,622 |  |  | $ | (19 | ) |  | $ | (39 | ) |  | $ | 21,024 |  |
|  | September 30, 2016 |  | BusinessAcquisitions |  | BusinessDivestitures |  | Currency Translation and Other |  | September 30, 2017 |
| Building Technologies & Solutions |  |  |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 9,734 |  |  | $ | (147 | ) |  | $ | — |  |  | $ | 50 |  |  | $ | 9,637 |  |
| Building Solutions EMEA/LA | 1,981 |  |  | (37 | ) |  | — |  |  | 68 |  |  | 2,012 |  |
| Building Solutions Asia Pacific | 1,260 |  |  | (14 | ) |  | (2 | ) |  | 11 |  |  | 1,255 |  |
| Global Products | 6,963 |  |  | (58 | ) |  | (1,267 | ) |  | 49 |  |  | 5,687 |  |
| Power Solutions | 1,086 |  |  | — |  |  | — |  |  | 11 |  |  | 1,097 |  |
| Total | $ | 21,024 |  |  | $ | (256 | ) |  | $ | (1,269 | ) |  | $ | 189 |  |  | $ | 19,688 |  |

[0000833444-17-000060:notes:295]
In connection with the Tyco Merger, the Company recorded goodwill of $16,105 million based on the final purchase price allocation. Refer to Note 2, "Merger Transaction," of the notes to consolidated financial statements for additional information.

[0000833444-17-000060:notes:296]
The fiscal 2017 Global Products business divestiture amount includes $1,248 million of goodwill transferred to noncurrent assets held for sale on the consolidated statements of financial position for the sale of the Scott Safety business. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's assets and liabilities held for sale.

[0000833444-17-000060:notes:297]
At September 30, 2015, accumulated goodwill impairment charges included $47 million related to the Building Solutions EMEA/LA - Latin America reporting unit.

[0000833444-17-000060:notes:298]
At July 1, 2017, the Company assessed goodwill for impairment in the Building Technologies & Solutions business due to the change in reportable segments as described in Note 19, "Segment Information," of the notes to consolidated financial statements. The Company determined that the estimated fair value of each reporting unit exceeded its corresponding carrying amount including recorded goodwill, and as such, no impairment existed at July 1, 2017.

[0000833444-17-000060:notes:299]
There were no goodwill impairments resulting from fiscal 2017 and 2016 annual impairment tests. With the exception of a Building Solutions North America reporting unit that has goodwill as a result of a recent acquisition and is recorded at fair value, no reporting unit was determined to be at risk of failing step one of the goodwill impairment test. The Company continuously monitors for events and circumstances that could negatively impact the key assumptions in determining fair value, including long-term revenue growth projections, profitability, discount rates, recent market valuations from transactions by comparable companies, volatility in the Company's market capitalization, and general industry, market and macro-economic conditions. It is possible that future changes in such circumstances, or in the variables associated with the judgments, assumptions and estimates used in assessing the fair value of the reporting unit, would require the Company to record a non-cash impairment charge.

[0000833444-17-000060:notes:300]
The assumptions included in the impairment tests require judgment, and changes to these inputs could impact the results of the calculations. Other than management's projections of future cash flows, the primary assumptions used in the impairment tests were the weighted-average cost of capital and long-term growth rates. Although the Company's cash flow forecasts are based on assumptions that are considered reasonable by management and consistent with the plans and estimates management is using to operate the underlying businesses, there are significant judgments in determining the expected future cash flows attributable to a reporting unit.

[0000833444-17-000060:notes:301]
Refer to Note 2, "Merger Transaction," of the notes to consolidated financial statements for additional information of intangibles recorded as a result of the Tyco Merger. Given the recent acquisition, the September 30, 2017 carrying amount of the indefinite-lived intangible assets recorded as a result of the Tyco Merger approximate fair value.

[0000833444-17-000060:notes:302]
Amortization of other intangible assets included within continuing operations for the fiscal years ended September 30, 2017, 2016 and 2015 was $489 million, $116 million and $74 million, respectively. Excluding the impact of any future acquisitions, the Company anticipates amortization for fiscal 2018, 2019, 2020, 2021 and 2022 will be approximately $375 million, $375 million, $372 million, $369 million and $360 million, respectively. There were no indefinite-lived intangible asset impairments resulting from fiscal 2017, 2016 and 2015 annual impairment tests.


## us-gaap:GuaranteesTextBlock

[0000833444-17-000060:notes:303]
GUARANTEES

[0000833444-17-000060:notes:304]
Certain of the Company's subsidiaries at the business segment level have guaranteed the performance of third-parties and provided financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from the current fiscal year through the completion of such transactions and would typically be triggered in the event of nonperformance. Performance under the guarantees, if required, would not have a material effect on the Company's financial position, results of operations or cash flows.

[0000833444-17-000060:notes:305]
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. A typical warranty program requires that the Company replace defective products within a specified time period from the date of sale. The Company records an estimate for future warranty-related costs based on actual historical return rates and other known factors. Based on analysis of return rates and other factors, the Company’s warranty provisions are adjusted as necessary. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different than those estimates.

[0000833444-17-000060:notes:306]
The Company’s product warranty liability for continuing operations is recorded in the consolidated statements of financial position in other current liabilities if the warranty is less than one year and in other noncurrent liabilities if the warranty extends longer than one year.

[0000833444-17-000060:notes:307]
The changes in the carrying amount of the Company’s total product warranty liability for continuing operations, including extended warranties for which deferred revenue is recorded, for the fiscal years ended September 30, 2017 and 2016 were as follows (in millions):

[0000833444-17-000060:notes:308]
|  | Year EndedSeptember 30, |
|  | 2017 |  | 2016 |
| Balance at beginning of period | $ | 374 |  |  | $ | 288 |  |
| Accruals for warranties issued during the period | 312 |  |  | 314 |  |
| Accruals from acquisitions and divestitures (1) | 7 |  |  | 83 |  |
| Accruals related to pre-existing warranties (including changes in estimates) | (4 | ) |  | (17 | ) |
| Settlements made (in cash or in kind) during the period | (280 | ) |  | (297 | ) |
| Currency translation | — |  |  | 3 |  |
| Balance at end of period | $ | 409 |  |  | $ | 374 |  |

[0000833444-17-000060:notes:309]
(1) The year ended September 30, 2017 includes $13 million of product warranties transferred to liabilities held for sale on the consolidated statements of financial position. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's disposal groups classified as held for sale.

[0000833444-17-000060:notes:310]
As a result of the Tyco Merger in the fourth quarter of fiscal 2016, the Company recorded, as part of the acquired liabilities of Tyco, $290 million of post sale contingent tax indemnification liabilities which is generally recorded within other noncurrent liabilities in the consolidated statements of financial position. The liabilities are recorded at fair value and relate to certain tax related matters borne by the buyer of previously divested subsidiaries of Tyco which Tyco has indemnified certain parties and the amounts are probable of being paid. Of the $290 million recorded as of September 30, 2017 and 2016, $255 million is related to prior divested businesses and the remainder relates to Tyco’s tax sharing agreements from its 2007 and 2012 spin-off transactions. These are certain guarantees or indemnifications extended among Tyco, Medtronic, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 separation and tax sharing agreements. In addition, the Company has recorded $11 million of tax indemnification liabilities as of September 30, 2017 related to other divestitures.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0000833444-17-000060:notes:311]
Goodwill and Indefinite-Lived Intangible Assets

[0000833444-17-000060:notes:312]
Goodwill reflects the cost of an acquisition in excess of the fair values assigned to identifiable net assets acquired. The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s reportable segments or one level below the reportable segments in certain instances, using a fair value method based on management’s judgments and assumptions or third party valuations. The fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. In estimating the fair value, the Company uses multiples of earnings based on the average of historical, published multiples of earnings of comparable entities with similar operations and economic characteristics. In certain instances, the Company uses discounted cash flow analyses or estimated sales price to further support the fair value estimates. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The estimated fair value is then compared with the carrying amount of the reporting unit, including recorded goodwill. The Company is subject to financial statement risk to the extent that the carrying amount exceeds the estimated fair value. Refer to Note 7, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for information regarding the goodwill impairment testing performed in the fourth quarters of fiscal years 2017, 2016 and 2015.

[0000833444-17-000060:notes:313]
Indefinite-lived intangible assets are also subject to at least annual impairment testing. Indefinite-lived intangible assets primarily consist of trademarks and tradenames and are tested for impairment using a relief-from-royalty method. A considerable amount of management judgment and assumptions are required in performing the impairment tests.

[0000833444-17-000060:notes:314]
Impairment of Long-Lived Assets

[0000833444-17-000060:notes:315]
The Company reviews long-lived assets, including property, plant and equipment and other intangible assets with definite lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets" and ASC 985-20, "Costs of software to be sold, leased, or marketed." ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. ASC 985-20 requires the unamortized capitalized costs of a computer software product be compared to the net realizable value of that product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset shall be written off.  Refer to Note 17, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for information regarding the impairment testing performed in fiscal years 2017, 2016 and 2015.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-17-000060:notes:316]
INCOME TAXES

[0000833444-17-000060:notes:317]
The more significant components of the Company’s income tax provision from continuing operations are as follows (in millions):

[0000833444-17-000060:notes:318]
|  | Year Ended September 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Tax expense at federal statutory rate | $ | 895 |  |  | $ | 371 |  |  | $ | 326 |  |
| State income taxes, net of federal benefit | 23 |  |  | (6 | ) |  | (6 | ) |
| Foreign income tax expense at different rates and foreign losses without tax benefits | (309 | ) |  | (122 | ) |  | (175 | ) |
| U.S. tax on foreign income | (407 | ) |  | (194 | ) |  | 39 |  |
| Reserve and valuation allowance adjustments | (164 | ) |  | — |  |  | (99 | ) |
| U.S. credits and incentives | (3 | ) |  | (14 | ) |  | (7 | ) |
| Impact of acquisitions and divestitures | 571 |  |  | 163 |  |  | — |  |
| Restructuring and impairment costs | 65 |  |  | 28 |  |  | — |  |
| Other | 34 |  |  | (29 | ) |  | (7 | ) |
| Income tax provision | $ | 705 |  |  | $ | 197 |  |  | $ | 71 |  |

[0000833444-17-000060:notes:319]
The U.S. federal statutory tax rate is being used as a comparison since the Company was a U.S. domiciled company in fiscal 2015 and 11 months of 2016 and due to the Company’s current legal entity structure. The effective rate is below the U.S. statutory rate for fiscal 2017 primarily due to the benefits of continuing global tax planning initiatives, non-U.S. tax rate differentials, tax audit closures, and a tax benefit due to changes in entity tax status, partially offset by the jurisdictional mix of significant restructuring and impairment costs, Tyco Merger transaction / integration costs and the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries related to the divestiture of the Scott Safety business. The effective rate is below the U.S. statutory rate for fiscal 2016 primarily due to the benefits of continuing global tax planning initiatives and foreign tax rate differentials, partially offset by the jurisdictional mix of restructuring and impairment costs, and the tax impacts of the Merger and integration related costs. The effective rate is below the U.S. statutory rate for fiscal 2015 primarily due to the benefits of continuing global tax planning initiatives, income in certain non-U.S. jurisdictions with a tax rate lower than the U.S. statutory tax rate and adjustments due to tax audit resolutions.

[0000833444-17-000060:notes:320]
Valuation Allowances

[0000833444-17-000060:notes:321]
The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary.

[0000833444-17-000060:notes:322]
In the fourth quarter of fiscal 2017, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering tax planning initiatives and other positive and negative evidence, the Company determined that it was more likely than not that certain deferred tax assets primarily in Canada, China and Mexico would not be able to be realized, and it was more likely than not that certain deferred tax assets in Germany would be realized. Therefore, the Company recorded $27 million of net valuation allowances as income tax expense in the three month period ended September 30, 2017.

[0000833444-17-000060:notes:323]
As a result of the Tyco Merger in the fourth quarter of fiscal 2016, the Company recorded as part of the acquired liabilities of Tyco $2.4 billion of valuation allowances. Also in the fourth quarter of fiscal 2016, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering tax planning initiatives and other positive and negative evidence, the Company determined that no other material changes were needed to its valuation allowances. Therefore, there was no impact to income tax expense due to valuation allowance changes in the three month period or year ended September 30, 2016.

[0000833444-17-000060:notes:324]
In the fourth quarter of fiscal 2015, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering tax planning initiatives and other positive and negative evidence, the Company determined that it was more likely than not that certain deferred tax assets primarily within Spain, Germany, and the United Kingdom would not be realized, and it is more likely than not that certain deferred tax assets of Poland and Germany will be realized. The impact of the net valuation allowance provision offset the benefit of valuation allowance releases and, as such, there was no net impact to income tax expense in the three month period ended September 30, 2015.

[0000833444-17-000060:notes:325]
Uncertain Tax Positions

[0000833444-17-000060:notes:326]
The Company is subject to income taxes in the U.S. and numerous foreign jurisdictions. Judgment is required in determining its worldwide provision for income taxes and recording the related assets and liabilities. In the ordinary course of the Company’s business, there are many transactions and calculations where the ultimate tax determination is uncertain. The Company is regularly under audit by tax authorities.

[0000833444-17-000060:notes:327]
At September 30, 2017, the Company had gross tax effected unrecognized tax benefits for continuing operations of $2,173 million of which $2,047 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2017 was approximately $99 million (net of tax benefit).

[0000833444-17-000060:notes:328]
At September 30, 2016, the Company had gross tax effected unrecognized tax benefits for continuing operations of $1,706 million of which $1,604 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2016 was approximately $84 million (net of tax benefit).

[0000833444-17-000060:notes:329]
At September 30, 2015, the Company had gross tax effected unrecognized tax benefits for continuing operations of $1,052 million of which $997 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2015 was approximately $33 million (net of tax benefit).

[0000833444-17-000060:notes:330]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0000833444-17-000060:notes:331]
|  | Year Ended September 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Beginning balance, October 1 | $ | 1,706 |  |  | $ | 1,052 |  |  | $ | 1,493 |  |
| Additions for tax positions related to the current year | 613 |  |  | 442 |  |  | 329 |  |
| Additions for tax positions of prior years | 116 |  |  | 15 |  |  | 23 |  |
| Reductions for tax positions of prior years | (44 | ) |  | (66 | ) |  | (111 | ) |
| Settlements with taxing authorities | (95 | ) |  | (104 | ) |  | (541 | ) |
| Statute closings and audit resolutions | (264 | ) |  | (30 | ) |  | (141 | ) |
| Acquisition of business | 141 |  |  | 397 |  |  | — |  |
| Ending balance, September 30 | $ | 2,173 |  |  | $ | 1,706 |  |  | $ | 1,052 |  |

[0000833444-17-000060:notes:332]
During fiscal 2017, the Company settled a significant number of tax examinations impacting fiscal years 2006 to fiscal 2014. In the fourth quarter of fiscal 2017, income tax audit resolutions resulted in a net $191 million benefit to income tax expense.

[0000833444-17-000060:notes:333]
During fiscal 2015, the Company settled a significant number of tax examinations in Germany, Mexico and the U.S., impacting fiscal years 1998 to fiscal 2012. The settlement of unrecognized tax benefits included cash payments for approximately $440 million and the loss of various tax attributes. The reduction for tax positions of prior years is substantially related to foreign exchange rates. In the fourth quarter of fiscal 2015, income tax audit resolutions resulted in a net $99 million benefit to income tax expense.

[0000833444-17-000060:notes:334]
In the U.S., fiscal years 2010 through 2014 are currently under exam by the Internal Revenue Service ("IRS") for certain legal entities. Additionally, the Company is currently under exam in the following major non-U.S. jurisdictions for continuing operations:

[0000833444-17-000060:notes:335]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2016 |
| Brazil |  | 2011 - 2012 |
| Canada |  | 2013 - 2014 |
| China |  | 2008 - 2016 |
| France |  | 2010 - 2015 |
| Germany |  | 2007 - 2015 |
| Japan |  | 2016 |
| Spain |  | 2010 - 2014 |
| Switzerland |  | 2011 - 2014 |
| United Kingdom |  | 2011 - 2014 |

[0000833444-17-000060:notes:336]
It is reasonably possible that certain tax examinations and /or tax litigation will conclude within the next twelve months, which could be up to a $25 million impact to tax expense.

[0000833444-17-000060:notes:337]
Other Tax Matters

[0000833444-17-000060:notes:338]
During fiscal 2017, the Company recorded $428 million of transaction and integration costs which generated a $69 million tax benefit.

[0000833444-17-000060:notes:339]
During fiscal 2017, the Company recorded a discrete non-cash tax charge of $490 million related to establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries of the Scott Safety business. This business is reported as net assets held for sale given the announced sale to 3M Company. Refer to Note 3, "Acquisitions and Divestitures," and Note 4, "Discontinued Operations," of the notes to consolidated financial statements for additional information.

[0000833444-17-000060:notes:340]
In the fourth quarter of fiscal 2017, the Company recorded a tax charge of $53 million due to a change in the deferred tax liability related to the outside basis of certain nonconsolidated subsidiaries.

[0000833444-17-000060:notes:341]
In the first quarter of fiscal 2017, the Company recorded a discrete tax benefit of $101 million due to changes in entity tax status.

[0000833444-17-000060:notes:342]
During fiscal 2017, 2016 and 2015, the Company incurred significant charges for restructuring and impairment costs. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. A substantial portion of these charges do not generate a tax benefit due to the Company's current tax position in these jurisdictions and the underlying tax basis in the impaired assets, resulting in $65 million and $28 million incremental tax expense in fiscal 2017 and 2016, respectively.

[0000833444-17-000060:notes:343]
During the fourth quarter of fiscal 2016, the Company completed its Merger with Tyco. As a result of that transaction, the Company incurred incremental tax expense of $137 million. In preparation for the spin-off of the Automotive Experience business in the first quarter of fiscal 2017, the Company incurred incremental tax expense for continuing operations of $26 million in fiscal 2016.

[0000833444-17-000060:notes:344]
As a result of the Tyco Merger in the fourth quarter of fiscal 2016, the Company recorded as part of the acquired liabilities of Tyco $290 million of post sale contingent tax indemnification liabilities which is generally recorded within other noncurrent liabilities in the consolidated statements of financial position. The liabilities are recorded at fair value and relate to certain tax related matters borne by the buyer of previously divested subsidiaries of Tyco which Tyco has indemnified certain parties and the amounts are probable of being paid. Of the $290 million recorded as of September 30, 2017 and 2016, $255 million is related to prior divested businesses and the remainder relates to Tyco’s tax sharing agreements from its 2007 and 2012 spin-off transactions. These are certain guarantees or indemnifications extended among Tyco, Medtronic, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 separation and tax sharing agreements. In addition, the Company has recorded $11 million of tax indemnification liabilities as of September 30, 2017 related to other divestitures.

[0000833444-17-000060:notes:345]
Impacts of Tax Legislation and Change in Statutory Tax Rates

[0000833444-17-000060:notes:346]
On October 13, 2016, the U.S. Treasury and the IRS released final and temporary Section 385 regulations. These regulations address whether certain instruments between related parties are treated as debt or equity. The Company does not expect that the regulations will have a material impact on its consolidated financial statements.

[0000833444-17-000060:notes:347]
The "look-through rule," under subpart F of the U.S. Internal Revenue Code, expired for the Company on September 30, 2015. The "look-through rule" had provided an exception to the U.S. taxation of certain income generated by non-U.S. subsidiaries. The rule was extended in December 2015 retroactive to the beginning of the Company’s 2016 fiscal year. The retroactive extension was signed into legislation and was made permanent through the Company's 2020 fiscal year.

[0000833444-17-000060:notes:348]
In the second quarter of fiscal 2015, tax legislation was adopted in Japan which reduced its statutory income tax rate. As a result of the law change, the Company recorded income tax expense of $17 million in the second quarter of fiscal 2015.

[0000833444-17-000060:notes:349]
During the fiscal years ended 2017, 2016 and 2015, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-17-000060:notes:350]
Continuing Operations

[0000833444-17-000060:notes:351]
Components of the provision for income taxes on continuing operations were as follows (in millions):

[0000833444-17-000060:notes:352]
|  | Year Ended September 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Current |  |  |  |  |  |
| Federal | $ | (225 | ) |  | $ | 169 |  |  | $ | (688 | ) |
| State | (6 | ) |  | 5 |  |  | (33 | ) |
| Foreign | 373 |  |  | 788 |  |  | 550 |  |
|  | 142 |  |  | 962 |  |  | (171 | ) |
| Deferred |  |  |  |  |  |
| Federal | 593 |  |  | (321 | ) |  | 410 |  |
| State | 41 |  |  | (15 | ) |  | (2 | ) |
| Foreign | (71 | ) |  | (429 | ) |  | (166 | ) |
|  | 563 |  |  | (765 | ) |  | 242 |  |
| Income tax provision | $ | 705 |  |  | $ | 197 |  |  | $ | 71 |  |

[0000833444-17-000060:notes:353]
Consolidated U.S. income from continuing operations before income taxes and noncontrolling interests for the fiscal years ended September 30, 2017, 2016 and 2015 was income of $868 million, $943 million and $418 million, respectively. Consolidated foreign income from continuing operations before income taxes and noncontrolling interests for the fiscal years ended September 30, 2017, 2016 and 2015 was income of $1,690 million, $119 million and $513 million, respectively.

[0000833444-17-000060:notes:354]
Income taxes paid for the fiscal years ended September 30, 2017, 2016 and 2015 were $1,756 million, $1,388 million and $1,163 million, respectively. At September 30, 2017 and 2016, the Company recorded within the consolidated statements of financial position in other current liabilities approximately $625 million and $1,505 million, respectively, of accrued income tax liabilities for continuing operations.

[0000833444-17-000060:notes:355]
The Company has not provided U.S. or non-U.S. income taxes on approximately $16 billion of outside basis differences of consolidated subsidiaries of Johnson Controls International plc.  The reduction of the outside basis differences via the sale or liquidation of these subsidiaries and/or distributions could create taxable income. The Company's intent is to reduce the outside basis differences only when it would be tax efficient. Given the numerous ways in which the basis differences may be reduced, it is not practicable to estimate the amount of unrecognized withholding taxes and deferred tax liability on the outside basis differences. In fiscal 2017, the Company did provide U.S. income tax expense related to the establishment of a deferred tax liability on the outside basis difference of the Company’s investment in certain subsidiaries of the Scott Safety business as a result of the planned divestiture.

[0000833444-17-000060:notes:356]
Temporary differences and carryforwards which gave rise to deferred tax assets and liabilities included (in millions):

[0000833444-17-000060:notes:357]
|  | September 30, |
|  | 2017 |  | 2016 |
| Deferred tax assets |  |  |  |
| Accrued expenses and reserves | $ | 891 |  |  | $ | 1,175 |  |
| Employee and retiree benefits | 13 |  |  | 438 |  |
| Net operating loss and other credit carryforwards | 5,490 |  |  | 4,483 |  |
| Research and development | 188 |  |  | 85 |  |
| Joint ventures and partnerships | — |  |  | 49 |  |
| Other | 26 |  |  | 19 |  |
|  | 6,608 |  |  | 6,249 |  |
| Valuation allowances | (3,838 | ) |  | (3,400 | ) |
|  | 2,770 |  |  | 2,849 |  |
| Deferred tax liabilities |  |  |  |
| Property, plant and equipment | 247 |  |  | 87 |  |
| Subsidiaries, joint ventures and partnerships | 789 |  |  | — |  |
| Intangible assets | 1,107 |  |  | 1,837 |  |
|  | 2,143 |  |  | 1,924 |  |
| Net deferred tax asset | $ | 627 |  |  | $ | 925 |  |

[0000833444-17-000060:notes:358]
At September 30, 2017, the Company had available net operating loss carryforwards of approximately $16.6 billion, of which $6.5 billion will expire at various dates between 2018 and 2037, and the remainder has an indefinite carryforward period. The Company had available U.S. foreign tax credit carryforwards at September 30, 2017 of $468 million which will expire at various dates between 2020 and 2024 or carried back to fiscal period 2016. The valuation allowance, generally, is for loss carryforwards for which realization is uncertain because it is unlikely that the losses will be realized given the lack of sustained profitability and/or limited carryforward periods in certain countries.

[0000833444-17-000060:notes:359]
As of September 30, 2017, deferred tax assets of approximately $180 million relate to certain operating loss carryforwards resulting from the exercise of employee stock options and restricted stock vestings, the tax benefit of which, when recognized, will be accounted for as a credit to additional paid-in capital rather than a reduction of income tax provision. Such amount has been presented within the tax loss and carryforwards line in the table above.


## us-gaap:IncomeTaxPolicyTextBlock

[0000833444-17-000060:notes:360]
Income Taxes

[0000833444-17-000060:notes:361]
Deferred tax liabilities and assets are recognized for the expected future tax consequences of events that have been reflected in the consolidated financial statements. Deferred tax liabilities and assets are determined based on the differences between the book and tax basis of particular assets and liabilities and operating loss carryforwards, using tax rates in effect for the years in which the differences are expected to reverse. A valuation allowance is provided to offset deferred tax assets if, based upon the available evidence, including consideration of tax planning strategies, it is more-likely-than-not that some or all of the deferred tax assets will not be realized. Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-17-000060:notes:362]
INVENTORIES

[0000833444-17-000060:notes:363]
Inventories consisted of the following (in millions):

[0000833444-17-000060:notes:364]
|  | September 30, |
|  | 2017 |  | 2016 |
| Raw materials and supplies | $ | 919 |  |  | $ | 852 |  |
| Work-in-process | 567 |  |  | 503 |  |
| Finished goods | 1,723 |  |  | 1,533 |  |
| Inventories | $ | 3,209 |  |  | $ | 2,888 |  |


## us-gaap:InventoryPolicyTextBlock

[0000833444-17-000060:notes:365]
Inventories

[0000833444-17-000060:notes:366]
Inventories are stated at the lower of cost or market using the first-in, first-out ("FIFO") method. Finished goods and work-in-process inventories include material, labor and manufacturing overhead costs.


## us-gaap:LeasesOfLesseeDisclosureTextBlock

[0000833444-17-000060:notes:367]
LEASES

[0000833444-17-000060:notes:368]
Certain administrative and production facilities and equipment are leased under long-term agreements. Most leases contain renewal options for varying periods, and certain leases include options to purchase the leased property during or at the end of the lease term. Leases generally require the Company to pay for insurance, taxes and maintenance of the property. Leased capital assets included in net property, plant and equipment, primarily buildings and improvements, were $17 million and $23 million at September 30, 2017 and 2016, respectively.

[0000833444-17-000060:notes:369]
Other facilities and equipment are leased under arrangements that are accounted for as operating leases. Total rental expense for continuing and discontinued operations for the fiscal years ended September 30, 2017, 2016 and 2015 was $502 million, $402 million and $413 million, respectively.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-17-000060:notes:370]
MERGER TRANSACTION

[0000833444-17-000060:notes:371]
As discussed in Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements, JCI Inc. and Tyco completed the Merger on September 2, 2016. The Merger was accounted for as a reverse acquisition using the acquisition method of accounting in accordance with ASC 805, "Business Combinations." Based on the structure of the Merger and other activities contemplated by the Merger Agreement, relative outstanding share ownership, the composition of the Company's board of directors and the designation of certain senior management positions of the Company, JCI Inc. was the accounting acquirer for financial reporting purposes.

[0000833444-17-000060:notes:372]
Immediately prior to the Merger and in connection therewith, Tyco shareholders received 0.955 ordinary shares of Tyco (which shares are now referred to as shares of the Company, or “Company ordinary shares”) for each Tyco ordinary share they held by virtue of a 0.955-for-one share consolidation. In the Merger, each outstanding share of common stock, par value $1.00 per share, of JCI Inc. (“JCI Inc. common stock”) (other than shares held by JCI Inc., Tyco and certain of their subsidiaries) was converted into the right to receive either the cash consideration or the share consideration (each as described below), at the election of the holder, subject to proration procedures described in the Merger Agreement and applicable withholding taxes.  The election to receive the cash consideration was undersubscribed. As a result, holders of shares of JCI Inc. common stock that elected to receive the share consideration and holders of shares of JCI Inc. common stock that made no election (or failed to properly make an election) became entitled to receive, for each such share of JCI Inc. common stock, $5.7293 in cash, without interest, and 0.8357 Company ordinary shares, subject to applicable withholding taxes. Holders of shares of JCI Inc. common stock that elected to receive the cash consideration became entitled to receive, for each such share of JCI Inc. common stock, $34.88 in cash, without interest, subject to applicable withholding taxes.  In the Merger, JCI Inc. shareholders received, in the aggregate, approximately $3.864 billion in cash. Immediately after the closing of, and giving effect to, the Merger, former JCI Inc. shareholders owned approximately 56% of the issued and outstanding Company ordinary shares and former Tyco stockholders owned approximately 44% of the issued and outstanding Company ordinary shares.

[0000833444-17-000060:notes:373]
Tyco is a leading global provider of security products and services, fire detection and suppression products and services, and life safety products. The acquisition of Tyco brings together best-in-class product, technology and service capabilities across controls, fire, security, HVAC, power solutions and energy storage, to serve various end-markets including large institutions, commercial buildings, retail, industrial, small business and residential.  The combination of the Tyco and JCI Inc. buildings platforms creates immediate opportunities for near-term growth through cross-selling, complementary branch and channel networks, and expanded global reach for established businesses. The new Company also benefits by combining innovation capabilities and pipelines involving new products, advanced solutions for smart buildings and cities, value-added services driven by advanced data and analytics and connectivity between buildings and energy storage through infrastructure integration.

[0000833444-17-000060:notes:374]
Fair Value of Consideration Transferred

[0000833444-17-000060:notes:375]
The total fair value of consideration transferred was approximately $19.7 billion. Total consideration is comprised of the equity value of the Tyco shares that were outstanding as of September 2, 2016 and the portion of Tyco's share awards and share options earned as of September 2, 2016 ($224 million). Share awards and share options not earned ($101 million) as of September 2, 2016 will be expensed over the remaining future vesting period.

[0000833444-17-000060:notes:376]
Fair Value of Assets Acquired and Liabilities Assumed

[0000833444-17-000060:notes:377]
The Company accounted for the Merger with Tyco as a business combination using the acquisition method of accounting. The assets acquired and liabilities assumed were recorded at their respective fair values as of the acquisition date.  Fair value estimates are based on a complex series of judgments about future events and uncertainties and rely heavily on estimates and assumptions. The judgments used to determine the estimated fair value assigned to each class of assets acquired and liabilities assumed, as well as asset lives, can materially impact the Company's results of operations.

[0000833444-17-000060:notes:378]
The fair values of the assets acquired and liabilities assumed are as follows (in millions):

[0000833444-17-000060:notes:379]
| Cash and cash equivalents |  | $ | 489 |  |
| Accounts receivable |  | 2,034 |  |
| Inventories |  | 807 |  |
| Other current assets |  | 617 |  |
| Property, plant, and equipment - net |  | 1,216 |  |
| Goodwill |  | 16,105 |  |
| Intangible assets - net |  | 6,384 |  |
| Other noncurrent assets |  | 536 |  |
| Total assets acquired |  | $ | 28,188 |  |
| Short-term debt |  | $ | 462 |  |
| Accounts payable |  | 725 |  |
| Accrued compensation and benefits |  | 312 |  |
| Other current liabilities |  | 1,481 |  |
| Long-term debt |  | 6,416 |  |
| Long-term deferred tax liabilities |  | 718 |  |
| Long-term pension and postretirement benefits |  | 774 |  |
| Other noncurrent liabilities |  | 1,456 |  |
| Total liabilities acquired |  | $ | 12,344 |  |
| Noncontrolling interests |  | 37 |  |
| Net assets acquired |  | $ | 15,807 |  |
| Cash consideration paid to JCI Inc. shareholders |  | 3,864 |  |
| Total fair value of consideration transferred |  | $ | 19,671 |  |

[0000833444-17-000060:notes:380]
In connection with the Merger, the Company recorded goodwill of $16.1 billion, which is attributable primarily to expected synergies, expanded market opportunities, and other benefits that the Company believes will result from combining its operations with the operations of Tyco. Goodwill has been allocated to the reporting units within Building Technologies & Solutions business based on the expected benefits from the Merger. The Company recorded a net reduction in goodwill of $258 million in fiscal 2017 related to purchase price allocations. The goodwill created in the Merger is not deductible for tax purposes.

[0000833444-17-000060:notes:381]
Actual and Pro Forma Impact

[0000833444-17-000060:notes:382]
The Company's consolidated financial statements for the fiscal year ended September 30, 2016 include Tyco's results of operations from the acquisition date of September 2, 2016 through September 30, 2016. Net sales and net income (loss) from continuing operations attributable to Tyco during this period and included in the Company's consolidated financial statements for the fiscal year ended September 30, 2016 total $808 million and ($48) million, respectively.

[0000833444-17-000060:notes:383]
In order to reflect the occurrence of the acquisition on October 1, 2014 as required, the unaudited pro forma results include adjustments to reflect, among other things, the amortization of the inventory step-up, the incremental intangible asset amortization to be incurred based on the preliminary values of each identifiable intangible asset,  the change in timing of defined benefit plans' mark-to-market gain or loss recognition, the change in timing of transaction and restructuring costs, and interest expense from debt financing obtained to fund the cash consideration paid to JCI Inc. shareholders. These pro forma amounts are not necessarily indicative of the results that would have been obtained if the acquisition had occurred as of the beginning of the period presented or that may occur in the future, and does not reflect future synergies, integration costs, or other such costs or savings. Additional information regarding fiscal 2016 pro forma information can be found in the Form 8-K filed by the Company with the SEC on November 8, 2016 under Item 7.01, “Regulation FD Disclosure.”

[0000833444-17-000060:notes:384]
ACQUISITIONS AND DIVESTITURES

[0000833444-17-000060:notes:385]
Fiscal Year 2017

[0000833444-17-000060:notes:386]
During fiscal 2017, the Company completed three acquisitions for a combined purchase price, net of cash acquired, of $9 million, $6 million of which was paid as of September 30, 2017. The acquisitions in the aggregate were not material to the Company’s consolidated financial statements. In connection with the acquisitions, the Company recorded goodwill of $2 million.

[0000833444-17-000060:notes:387]
In the fourth quarter of fiscal 2017, the Company completed two divestitures for a combined selling price, net of cash divested, of $44 million, of which $40 million was received as of September 30, 2017. The divestitures were not material to the Company's consolidated financial statements. In connection with the divestitures, the Company recorded a gain of $9 million within selling, general and administrative expenses on the consolidated statements of income and reduced goodwill by $19 million and $2 million in the Global Products segment and in the Building Solutions Asia Pacific segment, respectively.

[0000833444-17-000060:notes:388]
In the second quarter of fiscal 2017, the Company signed a definitive agreement to sell its Scott Safety business to 3M Company for approximately $2.0 billion. The transaction closed on October 4, 2017. Net cash proceeds from the transaction of approximately $1.9 billion were used to repay a significant portion of the Tyco International Holding S.a.r.L.'s ("TSarl") $4.0 billion of merger-related debt. Scott Safety is a leader in high performance respiratory protection, gas and flame detection, thermal imaging and other critical products. The Scott Safety business is included in the Global Products segment and is reported within assets and liabilities held for sale in the consolidated statements of financial position as of September 30, 2017. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further disclosure related to the Company's net assets held for sale.

[0000833444-17-000060:notes:389]
In the second quarter of fiscal 2017, the Company completed the sale of its ADT security business in South Africa within the Building Solutions EMEA/LA segment. The selling price, net of cash divested, was $129 million, all of which was received as of September 30, 2017. In connection with the sale, the Company reduced goodwill in assets held for sale by $92 million. The divestiture was not material to the Company's consolidated financial statements.

[0000833444-17-000060:notes:390]
In the first quarter of fiscal 2017, the Company completed one additional divestiture for a sales price of $4 million, all of which was received as of September 30, 2017. The divestiture decreased the Company's ownership from a controlling to noncontrolling interest, and as a result, the Company deconsolidated cash of $5 million. The divestiture was not material to the Company's consolidated financial statements.

[0000833444-17-000060:notes:391]
During fiscal 2017, the Company received $52 million in net cash proceeds related to prior year business divestitures.

[0000833444-17-000060:notes:392]
Fiscal Year 2016

[0000833444-17-000060:notes:393]
On October 1, 2015, the Company formed a joint venture with Hitachi to expand its Building Technologies & Solutions product offerings. The Company acquired a 60% ownership interest in the new entity for approximately $208 million ($638 million purchase price less cash acquired of $430 million), $133 million of which was paid as of September 30, 2016 and $75 million was paid as of September 30, 2017. In connection with the acquisition, the Company recorded goodwill of $253 million related to purchase price allocations.

[0000833444-17-000060:notes:394]
Also during fiscal 2016, the Company completed two additional acquisitions for a combined purchase price, net of cash acquired, of $6 million, $3 million of which was paid as of September 30, 2016. The acquisitions in aggregate were not material to the Company's consolidated financial statements. In connection with the acquisitions, the Company recorded goodwill of $6 million. One of the acquisitions increased the Company's ownership from a noncontrolling to controlling interest. As a result, the Company recorded a non-cash gain of $4 million in equity income for the Global Products segment to adjust the Company's existing equity investment in the partially-owned affiliate to fair value.

[0000833444-17-000060:notes:395]
In the fourth quarter of fiscal 2016, the Company completed two divestitures for a combined sales price of $39 million, net of cash divested of $13 million. None of the sales proceeds were received as of September 30, 2016. The divestitures were not material to the Company's consolidated financial statements. In connection with the divestitures, the Company recorded a gain of $12 million within selling, general and administrative expenses on the consolidated statements of income and reduced goodwill by $16 million in the Global Products segment.

[0000833444-17-000060:notes:396]
In the third quarter of fiscal 2016, the Company completed a divestiture for a sales price of $16 million, all of which was received as of September 30, 2016. The divestiture was not material to the Company's consolidated financial statements. In connection with the divestiture, the Company recorded a gain of $14 million within selling, general and administrative expenses on the consolidated statements of income and reduced goodwill by $3 million in the Building Solutions North America segment.

[0000833444-17-000060:notes:397]
During fiscal 2016, the Company received $29 million in net cash proceeds related to prior year business divestitures.

[0000833444-17-000060:notes:398]
Fiscal Year 2015

[0000833444-17-000060:notes:399]
During fiscal 2015, the Company completed three acquisitions for a combined purchase price, net of cash acquired, of $47 million, $18 million of which was paid as of September 30, 2015. The acquisitions in the aggregate were not material to the Company’s consolidated financial statements. In connection with the acquisitions, the Company recorded goodwill in assets held for sale of $9 million.

[0000833444-17-000060:notes:400]
In the fourth quarter of fiscal 2015, the Company completed the sale of its Global Workplace Solutions ("GWS") business to CBRE Group Inc. ("CBRE"). The selling price, net of cash divested, was $1.4 billion, all of which was received as of September 30, 2015. In connection with the sale, the Company recorded a $940 million gain, $643 million net of tax, within income (loss) from discontinued operations, net of tax, on the consolidated statements of income and reduced goodwill in assets held for sale by $220 million. At March 31, 2015, the Company determined that the GWS segment met the criteria to be classified as a discontinued operation. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further disclosure related to the Company's discontinued operations.

[0000833444-17-000060:notes:401]
In the fourth quarter of fiscal 2015, the Company completed its global automotive interiors joint venture with Yanfeng Automotive Trim Systems. In connection with the divestiture of the Interiors business, the Company recorded a $145 million gain, $38 million net of tax within income (loss) from discontinued operations, net of tax, on the consolidated statements of income and reduced goodwill in assets held for sale by $21 million.

[0000833444-17-000060:notes:402]
Also during fiscal 2015, the Company completed four additional divestitures for a combined sales price of $119 million, $86 million of which was received as of September 30, 2015. The divestitures were not material to the Company's consolidated financial statements. In connection with the divestitures, the Company recorded a gain of $38 million within selling, general and administrative expenses on the consolidated statements of income and reduced goodwill by $14 million in the Global Products segment, recorded a gain of $10 million within income (loss) from discontinued operations, net of tax,  on the consolidated statements of income and reduced goodwill in assets held for sale by $4 million, and recorded a gain of $7 million within selling, general and administrative expenses on the consolidated statements of income and reduced goodwill by $2 million in the Building Solutions North America segment.

[0000833444-17-000060:notes:403]
In the first nine months of fiscal 2015, the Company adjusted the purchase price allocation of the fiscal 2014 acquisition of Air Distribution Technologies Inc. ("ADTi"). The adjustment was made as a result of a true-up to the purchase price in the amount of $4 million, all of which was paid as of September 30, 2015. Also, in connection with this acquisition, the Company recorded additional goodwill of $34 million in fiscal 2015 related to the final purchase price allocations.

[0000833444-17-000060:notes:404]
In the second quarter of fiscal 2015, the Company completed the sale of its interests in two GWS joint ventures to Brookfield Asset Management, Inc. The selling price, net of cash divested, was $141 million, all of which was received as of September 30, 2015. In connection with the sale, the Company recorded a $200 million gain, $127 million net of tax, within income (loss) from discontinued operations, net of tax, on the consolidated statements of income and reduced goodwill in assets held for sale by $20 million.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000833444-17-000060:notes:405]
New Accounting Pronouncements

[0000833444-17-000060:notes:406]
Recently Adopted Accounting Pronouncements

[0000833444-17-000060:notes:407]
In October 2016, the FASB issued ASU No. 2016-17, "Consolidations (Topic 810): Interests Held through Related Parties that are under Common Control." The ASU changes how a single decision maker of a variable interest entity ("VIE") that holds indirect interest in the entity through related parties that are under common control determines whether it is the primary beneficiary of the VIE. The new guidance amends ASU 2015-02, "Consolidation (Topic 810): Amendments to the Consolidation Analysis" issued in February 2015. ASU No. 2016-17 was effective for the Company for the quarter ending December 31, 2016. The adoption of this guidance did not have an impact on the Company's consolidated financial statements.

[0000833444-17-000060:notes:408]
In March 2016, the FASB issued ASU No. 2016-07, "Investments - Equity Method and Joint Ventures (Topic 323): Simplifying the Transition to the Equity Method of Accounting." ASU No. 2016-07 eliminates the requirement for an investment that qualifies for the use of the equity method of accounting as a result of an increase in the level of ownership or degree of influence to adjust the investment, results of operations and retained earnings retrospectively. During the quarter ended September 30, 2017, the Company early adopted ASU No. 2016-07 and applied it prospectively. The adoption of this guidance did not have an impact on the Company's consolidated financial statements.

[0000833444-17-000060:notes:409]
In May 2015, the FASB issued ASU No. 2015-07, "Disclosures for Investments in Certain Entities That Calculate Net Asset Value per Share (or Its Equivalent)." ASU No. 2015-07 removes the requirement to categorize within the fair value hierarchy all investments for which fair value is measured using the net asset value per share practical expedient. Such investments should be disclosed separate from the fair value hierarchy. ASU No. 2015-07 was effective retrospectively for the Company for the quarter ending December 31, 2016. The adoption of this guidance did not have an impact on the Company's consolidated financial statements, but did impact pension asset disclosures. Refer to Note 15, "Retirement Plans," of the notes to consolidated financial statements for further information.

[0000833444-17-000060:notes:410]
In February 2015, the FASB issued ASU No. 2015-02, "Consolidation (Topic 810): Amendments to the Consolidation Analysis." ASU No. 2015-02 amends the analysis performed to determine whether a reporting entity should consolidate certain types of legal entities. ASU No. 2015-02 was effective retrospectively for the Company for the quarter ending December 31, 2016. The adoption of this guidance did not have an impact on the Company's consolidated financial statements.

[0000833444-17-000060:notes:411]
Recently Issued Accounting Pronouncements

[0000833444-17-000060:notes:412]
In August 2017, the FASB issued ASU No. 2017-12, "Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities." The ASU more closely aligns the results of hedge accounting with risk management activities through amendments to the designation and measurement guidance to better reflect a Company's hedging strategy and effectiveness. ASU 2017-12 is effective for the Company for the quarter ending December 31, 2019. Early adoption is permitted in any interim period. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-17-000060:notes:413]
In May 2017, the FASB issued ASU No. 2017-09, "Compensation — Stock Compensation (Topic 718): Scope of Modification Accounting." The ASU provides guidance about which changes to the terms or conditions of a share-based payment award require a reporting entity to apply modification accounting. ASU No. 2017-09 will be effective prospectively for the Company for the quarter ending December 31, 2018, with early adoption permitted. The impact of this guidance for the Company is dependent on any future share-based payment award changes, should they occur.

[0000833444-17-000060:notes:414]
In March 2017, the FASB issued ASU No. 2017-07, "Compensation—Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost." The ASU requires the service cost component of net periodic benefit cost to be presented with other compensation costs. The other components of net periodic benefit cost are required to be presented in the income statement separately from the service cost component and outside a subtotal of income from operations, if one is presented. The ASU also allows only the service cost component of net periodic benefit cost to be eligible for capitalization. The guidance will be effective for the Company for the quarter ending December 31, 2018. Early adoption is permitted as of the beginning of an annual period for which financial statements (interim or annual) have not been issued or made available for issuance. The guidance will be effective retrospectively except for the capitalization of the service cost component which should be applied prospectively. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements.

[0000833444-17-000060:notes:415]
In January 2017, the FASB issued ASU No. 2017-04, "Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment," which eliminates the requirement to calculate the implied fair value of goodwill to measure a goodwill impairment charge (Step 2) from the goodwill impairment test. Instead, an impairment charge will equal the amount by which a reporting unit’s carrying amount exceeds its fair value, not to exceed the amount of goodwill allocated to the reporting unit. The guidance will be effective prospectively for the Company for the quarter ending December 31, 2020, with early adoption permitted after January 1, 2017. The impact of this guidance for the Company will depend on the outcomes of future goodwill impairment tests.

[0000833444-17-000060:notes:416]
In November 2016, the FASB issued ASU No. 2016-18, "Statement of Cash Flows (Topic 230): Restricted Cash (a consensus of the FASB Emerging Issues Task Force)." The ASU requires amounts generally described as restricted cash and restricted cash equivalents to be included with cash and cash equivalents when reconciling the beginning-of-period and end-of-period total amounts shown on the statement of cash flows. The guidance will be effective for the Company for the quarter ending December 31, 2018, with early adoption permitted. The amendments in this update should be applied retrospectively to all periods presented. The impact of this guidance for the Company will depend on the levels of restricted cash balances in the periods presented.

[0000833444-17-000060:notes:417]
In October 2016, the FASB issued ASU No. 2016-16, "Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory." The ASU requires the tax effects of all intra-entity sales of assets other than inventory to be recognized in the period in which the transaction occurs. The guidance will be effective for the Company for the quarter ending December 31, 2018, with early adoption permitted but only in the first interim period of a fiscal year. The changes are required to be applied by means of a cumulative-effect adjustment recorded in retained earnings as of the beginning of the fiscal year of adoption. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-17-000060:notes:418]
In August 2016, the FASB issued ASU No. 2016-15, "Statement of Cash Flows (Topic 230): Classification of Certain Cash Receipts and Cash Payments." ASU No. 2016-15 provides clarification guidance on eight specific cash flow presentation issues in order to reduce the diversity in practice. ASU No. 2016-15 will be effective for the Company for the quarter ending December 31, 2018, with early adoption permitted. The guidance should be applied retrospectively to all periods presented, unless deem impracticable, in which case prospective application is permitted. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-17-000060:notes:419]
In June 2016, the FASB issued ASU No. 2016-13, "Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments." ASU No. 2016-13 changes the impairment model for financial assets measured at amortized cost, requiring presentation at the net amount expected to be collected. The measurement of expected credit losses is based upon historical experience, current conditions, and reasonable and supportable forecasts. Available-for-sale debt securities with unrealized losses will now be recorded through an allowance for credit losses. ASU No. 2016-13 will be effective for the Company for the quarter ended December 31, 2020, with early adoption permitted for the quarter ended December 31, 2019. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements.

[0000833444-17-000060:notes:420]
In March 2016, the FASB issued ASU No. 2016-09, "Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting." ASU No. 2016-09 impacts certain aspects of the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the statements of cash flows. ASU No. 2016-09 will be effective for the Company for the quarter ending December 31, 2017, with early adoption permitted. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.

[0000833444-17-000060:notes:421]
In February 2016, the FASB issued ASU No. 2016-02, "Leases (Topic 842)." ASU No. 2016-02 requires recognition of operating leases as lease assets and liabilities on the balance sheet, and disclosure of key information about leasing arrangements. ASU No. 2016-02 will be effective retrospectively for the Company for the quarter ending December 31, 2019, with early adoption permitted. The Company is currently assessing the impact adoption of this guidance will have on its consolidated financial statements.  The Company has started the assessment process by evaluating the population of leases under the revised definition of what qualifies as a leased asset. The Company is the lessee under various agreements for facilities and equipment that are currently accounted for as operating leases. The new guidance will require the Company to record operating leases on the balance sheet with a right-of-use asset and corresponding liability for future payment obligations. The Company expects the new guidance will have a material impact on its consolidated statements of financial position for the addition of right-of-use assets and lease liabilities, but the Company does not expect it to have a material impact on its consolidated statements of income.

[0000833444-17-000060:notes:422]
In January 2016, the FASB issued ASU No. 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." ASU No. 2016-01 amends certain aspects of recognition, measurement, presentation and disclosure of financial instruments, including marketable securities. ASU No. 2016-01 will be effective for the Company for the quarter ending December 31, 2018, and early adoption is not permitted, with certain exceptions. The changes are required to be applied by means of a cumulative-effect adjustment on the balance sheet as of the beginning of the fiscal year of adoption. The impact of this guidance for the Company will depend on the magnitude of the unrealized gains and losses on the Company's marketable securities investments.

[0000833444-17-000060:notes:423]
In July 2015, the FASB issued ASU No. 2015-11, "Simplifying the Measurement of Inventory." ASU No. 2015-11 requires inventory that is recorded using the first-in, first-out method to be measured at the lower of cost or net realizable value. ASU No. 2015-11 will be effective prospectively for the Company for the quarter ending December 31, 2017, with early adoption permitted. The adoption of this guidance is not expected to have a significant impact on the Company's consolidated financial statements.

[0000833444-17-000060:notes:424]
In May 2014, the FASB issued ASU No. 2014-09, "Revenue from Contracts with Customers (Topic 606)." ASU No. 2014-09 clarifies the principles for recognizing revenue when an entity either enters into a contract with customers to transfer goods or services or enters into a contract for the transfer of non-financial assets. The original standard was effective retrospectively for the Company for the quarter ending December 31, 2017; however in August 2015, the FASB issued ASU No. 2015-14, "Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date," which defers the effective date of ASU No. 2014-09 by one-year for all entities. The new standard will become effective retrospectively for the Company for the quarter ending December 31, 2018, with early adoption permitted, but not before the original effective date. Additionally, in March 2016, the FASB issued ASU No. 2016-08, "Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net)," in April 2016, the FASB issued ASU No. 2016-10, "Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing," in May 2016, the FASB issued ASU No. 2016-12, "Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients," and in December 2016, the FASB issued ASU No. 2016-20, "Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers," all of which provide additional clarification on certain topics addressed in ASU No. 2014-09. ASU No. 2016-08, ASU No. 2016-10, ASU No. 2016-12 and ASU No. 2016-20 follow the same implementation guidelines as ASU No. 2014-09 and ASU No. 2015-14. The Company has elected to adopt the new revenue guidance as of October 1, 2018 using the modified retrospective approach. In preparation for adoption of the new guidance, the Company has reviewed representative samples of contracts and other forms of agreements with customers globally and is in the process of evaluating the impact of the new revenue standard. Based on its procedures to date, the Company is not in a position today to quantify the potential impact the new revenue standard will have on its consolidated financial statements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-17-000060:notes:425]
RETIREMENT PLANS

[0000833444-17-000060:notes:426]
Pension Benefits

[0000833444-17-000060:notes:427]
The Company has non-contributory defined benefit pension plans covering certain U.S. and non-U.S. employees. The benefits provided are primarily based on years of service and average compensation or a monthly retirement benefit amount. Certain of the Company’s U.S. pension plans have been amended to prohibit new participants from entering the plans and no longer accrue benefits. Funding for U.S. pension plans equals or exceeds the minimum requirements of the Employee Retirement Income Security Act of 1974. Funding for non-U.S. plans observes the local legal and regulatory limits. Also, the Company makes contributions to union-trusteed pension funds for construction and service personnel.

[0000833444-17-000060:notes:428]
For pension plans with accumulated benefit obligations ("ABO") that exceed plan assets, the projected benefit obligation ("PBO"), ABO and fair value of plan assets of those plans were $5,564 million, $5,465 million and $4,715 million, respectively, as of September 30, 2017 and $7,124 million, $6,966 million and $5,234 million, respectively, as of September 30, 2016.

[0000833444-17-000060:notes:429]
In fiscal 2017, total employer contributions to the defined benefit pension plans were $342 million, of which $49 million were voluntary contributions made by the Company. The Company expects to contribute approximately $100 million in cash to its defined benefit pension plans in fiscal 2018. Projected benefit payments from the plans as of September 30, 2017 are estimated as follows (in millions):

[0000833444-17-000060:notes:430]
| 2018 | $ | 332 |  |
| 2019 | 329 |  |
| 2020 | 329 |  |
| 2021 | 330 |  |
| 2022 | 338 |  |
| 2023-2027 | 1,737 |  |

[0000833444-17-000060:notes:431]
Postretirement Benefits

[0000833444-17-000060:notes:432]
The Company provides certain health care and life insurance benefits for eligible retirees and their dependents primarily in the U.S., Canada and Brazil. Most non-U.S. employees are covered by government sponsored programs, and the cost to the Company is not significant.

[0000833444-17-000060:notes:433]
Eligibility for coverage is based on meeting certain years of service and retirement age qualifications. These benefits may be subject to deductibles, co-payment provisions and other limitations, and the Company has reserved the right to modify these benefits. Effective January 31, 1994, the Company modified certain U.S. salaried plans to place a limit on the Company’s cost of future annual retiree medical benefits at no more than 150% of the 1993 cost.

[0000833444-17-000060:notes:434]
The health care cost trend assumption does not have a significant effect on the amounts reported.

[0000833444-17-000060:notes:435]
In fiscal 2017, total employer contributions to the postretirement plans were $5 million. The Company expects to contribute approximately $5 million in cash to its postretirement plans in fiscal 2018. Projected benefit payments from the plans as of September 30, 2017 are estimated as follows (in millions):

[0000833444-17-000060:notes:436]
| 2018 | $ | 19 |  |
| 2019 | 19 |  |
| 2020 | 19 |  |
| 2021 | 19 |  |
| 2022 | 18 |  |
| 2023-2027 | 76 |  |

[0000833444-17-000060:notes:437]
In December 2003, the U.S. Congress enacted the Medicare Prescription Drug, Improvement and Modernization Act of 2003 ("Act") for employers sponsoring postretirement care plans that provide prescription drug benefits. The Act introduces a prescription drug benefit under Medicare as well as a federal subsidy to sponsors of retiree health care benefit plans providing a benefit that is at least actuarially equivalent to Medicare Part D.1. Under the Act, the Medicare subsidy amount is received directly by the plan sponsor and not the related plan. Further, the plan sponsor is not required to use the subsidy amount to fund postretirement benefits and may use the subsidy for any valid business purpose. Projected subsidy receipts are estimated to be approximately $2 million per year over the next ten years.

[0000833444-17-000060:notes:438]
Savings and Investment Plans

[0000833444-17-000060:notes:439]
The Company sponsors various defined contribution savings plans that allow employees to contribute a portion of their pre-tax and/or after-tax income in accordance with plan specified guidelines. Under specified conditions, the Company will contribute to certain savings plans based on the employees’ eligible pay and/or will match a percentage of the employee contributions up to certain limits. Matching contributions charged to expense for continuing and discontinued operations amounted to $138 million, $128 million and $123 million for the fiscal years ended 2017, 2016 and 2015, respectively.

[0000833444-17-000060:notes:440]
Multiemployer Benefit Plans

[0000833444-17-000060:notes:441]
The Company contributes to multiemployer benefit plans based on obligations arising from collective bargaining agreements related to certain of its hourly employees in the U.S. These plans provide retirement benefits to participants based on their service to contributing employers. The benefits are paid from assets held in trust for that purpose. The trustees typically are responsible for determining the level of benefits to be provided to participants as well as for such matters as the investment of the assets and the administration of the plans.

[0000833444-17-000060:notes:442]
The risks of participating in these multiemployer benefit plans are different from single-employer benefit plans in the following aspects:

[0000833444-17-000060:notes:443]
| • | Assets contributed to the multiemployer benefit plan by one employer may be used to provide benefits to employees of other participating employers. |

[0000833444-17-000060:notes:444]
| • | If a participating employer stops contributing to the multiemployer benefit plan, the unfunded obligations of the plan may be borne by the remaining participating employers. |

[0000833444-17-000060:notes:445]
| • | If the Company stops participating in some of its multiemployer benefit plans, the Company may be required to pay those plans an amount based on its allocable share of the underfunded status of the plan, referred to as a withdrawal liability. |

[0000833444-17-000060:notes:446]
The Company participates in approximately 289 multiemployer benefit plans, primarily related to its Building Technologies & Solutions business in the U.S., none of which are individually significant to the Company. The number of employees covered by the Company’s multiemployer benefit plans has remained consistent over the past three years, and there have been no significant changes that affect the comparability of fiscal 2017, 2016 and 2015 contributions. The Company recognizes expense for the contractually-required contribution for each period. The Company contributed $67 million, $46 million and $45 million to multiemployer benefit plans in fiscal 2017, 2016 and 2015, respectively.

[0000833444-17-000060:notes:447]
Based on the most recent information available, the Company believes that the present value of actuarial accrued liabilities in certain of these multiemployer benefit plans may exceed the value of the assets held in trust to pay benefits. Currently, the Company is not aware of any significant multiemployer benefits plans for which it is probable or reasonably possible that the Company will be obligated to make up any shortfall in funds. Moreover, if the Company were to exit certain markets or otherwise cease making contributions to these funds, the Company could trigger a withdrawal liability. Currently, the Company is not aware of any multiemployer benefit plans for which it is probable or reasonably possible that the Company will have a significant withdrawal liability. Any accrual for a shortfall or withdrawal liability will be recorded when it is probable that a liability exists and it can be reasonably estimated.

[0000833444-17-000060:notes:448]
Plan Assets

[0000833444-17-000060:notes:449]
The Company’s investment policies employ an approach whereby a mix of equities, fixed income and alternative investments are used to maximize the long-term return of plan assets for a prudent level of risk. The investment portfolio primarily contains a diversified blend of equity and fixed income investments. Equity investments are diversified across U.S. and non-U.S. stocks, as well as growth, value and small to large capitalizations. Fixed income investments include corporate and government issues, with short-, mid- and long-term maturities, with a focus on investment grade when purchased and a target duration close to that of the plan liability. Investment and market risks are measured and monitored on an ongoing basis through regular investment portfolio reviews, annual liability measurements and periodic asset/liability studies. The majority of the real estate component of the portfolio is invested in a diversified portfolio of high-quality, operating properties with cash yields greater than the targeted appreciation. Investments in other alternative asset classes, including hedge funds and commodities, diversify the expected investment returns relative to the equity and fixed income investments. As a result of our diversification strategies, there are no significant concentrations of risk within the portfolio of investments.

[0000833444-17-000060:notes:450]
The Company’s actual asset allocations are in line with target allocations. The Company rebalances asset allocations as appropriate, in order to stay within a range of allocation for each asset category.

[0000833444-17-000060:notes:451]
The expected return on plan assets is based on the Company’s expectation of the long-term average rate of return of the capital markets in which the plans invest. The average market returns are adjusted, where appropriate, for active asset management returns. The expected return reflects the investment policy target asset mix and considers the historical returns earned for each asset category.

[0000833444-17-000060:notes:452]
The Company’s plan assets at September 30, 2017 and 2016, by asset category, are as follows (in millions):

[0000833444-17-000060:notes:453]
|  | Fair Value Measurements Using: |
| Asset Category | Total as ofSeptember 30, 2017 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| U.S. Pension |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 70 |  |  | $ | 2 |  |  | $ | 68 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 652 |  |  | 375 |  |  | 277 |  |  | — |  |
| Small-Cap | 281 |  |  | 281 |  |  | — |  |  | — |  |
| International - Developed | 649 |  |  | 569 |  |  | 80 |  |  | — |  |
| International - Emerging | 51 |  |  | 24 |  |  | 27 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 270 |  |  | 243 |  |  | 27 |  |  | — |  |
| Corporate/Other | 917 |  |  | 851 |  |  | 66 |  |  | — |  |
| Total Investments in the Fair Value Hierarchy | 2,890 |  |  | $ | 2,345 |  |  | $ | 545 |  |  | $ | — |  |
| Investments Measured at Net Asset Value, as Practical Expedient: |  |  |  |  |  |  |  |
| Real Estate Investments Measured at Net Asset Value* | 275 |  |  |  |  |  |  |  |
| Total Plan Assets | $ | 3,165 |  |  |  |  |  |  |  |
| Non-U.S. Pension |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 55 |  |  | $ | 45 |  |  | $ | 10 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 242 |  |  | 18 |  |  | 224 |  |  | — |  |
| Mid-Cap | 2 |  |  | 2 |  |  | — |  |  | — |  |
| International - Developed | 517 |  |  | 58 |  |  | 459 |  |  | — |  |
| International - Emerging | 13 |  |  | — |  |  | 13 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 618 |  |  | 74 |  |  | 544 |  |  | — |  |
| Corporate/Other | 569 |  |  | 292 |  |  | 277 |  |  | — |  |
| Hedge Fund | 112 |  |  | — |  |  | 112 |  |  | — |  |
| Real Estate | 24 |  |  | 24 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy | 2,152 |  |  | $ | 513 |  |  | $ | 1,639 |  |  | $ | — |  |
| Investments Measured at Net Asset Value, as Practical Expedient: |  |  |  |  |  |  |  |
| Real Estate Investments Measured at Net Asset Value* | 29 |  |  |  |  |  |  |  |
| Total Plan Assets | $ | 2,181 |  |  |  |  |  |  |  |
| Postretirement |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 3 |  |  | $ | — |  |  | $ | 3 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 28 |  |  | — |  |  | 28 |  |  | — |  |
| Small-Cap | 9 |  |  | — |  |  | 9 |  |  | — |  |
| International - Developed | 21 |  |  | — |  |  | 21 |  |  | — |  |
| International - Emerging | 11 |  |  | — |  |  | 11 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 21 |  |  | — |  |  | 21 |  |  | — |  |
| Corporate/Other | 59 |  |  | — |  |  | 59 |  |  | — |  |
| Commodities | 15 |  |  | — |  |  | 15 |  |  | — |  |
| Real Estate | 10 |  |  | — |  |  | 10 |  |  | — |  |
| Total Plan Assets | $ | 177 |  |  | $ | — |  |  | $ | 177 |  |  | $ | — |  |

[0000833444-17-000060:notes:454]
|  | Fair Value Measurements Using: |
| Asset Category | Total as ofSeptember 30, 2016 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| U.S. Pension |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 38 |  |  | $ | 38 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 692 |  |  | 499 |  |  | 193 |  |  | — |  |
| Small-Cap | 267 |  |  | 252 |  |  | 15 |  |  | — |  |
| International - Developed | 655 |  |  | 566 |  |  | 89 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 345 |  |  | 280 |  |  | 65 |  |  | — |  |
| Corporate/Other | 950 |  |  | 633 |  |  | 317 |  |  | — |  |
| Total Investments in the Fair Value Hierarchy | 2,947 |  |  | $ | 2,268 |  |  | $ | 679 |  |  | $ | — |  |
| Investments Measured at Net Asset Value, as Practical Expedient: |  |  |  |  |  |  |  |  |
| Real Estate Investments Measured at Net Asset Value* | 346 |  |  |  |  |  |  |  |
| Total Plan Assets | $ | 3,293 |  |  |  |  |  |  |  |
| Non-U.S. Pension |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 90 |  |  | $ | 59 |  |  | $ | 31 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 317 |  |  | 22 |  |  | 295 |  |  | — |  |
| International - Developed | 453 |  |  | 52 |  |  | 401 |  |  | — |  |
| International - Emerging | 19 |  |  | — |  |  | 19 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 864 |  |  | 164 |  |  | 700 |  |  | — |  |
| Corporate/Other | 561 |  |  | 300 |  |  | 261 |  |  | — |  |
| Hedge Fund | 169 |  |  | — |  |  | 169 |  |  | — |  |
| Real Estate | 11 |  |  | 11 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy | 2,484 |  |  | $ | 608 |  |  | $ | 1,876 |  |  | $ | — |  |
| Investments Measured at Net Asset Value, as Practical Expedient: |  |  |  |  |  |  |  |
| Real Estate Investments Measured at Net Asset Value* | 52 |  |  |  |  |  |  |  |
| Total Plan Assets | $ | 2,536 |  |  |  |  |  |  |  |
| Postretirement |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 7 |  |  | $ | — |  |  | $ | 7 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 31 |  |  | — |  |  | 31 |  |  | — |  |
| Small-Cap | 10 |  |  | — |  |  | 10 |  |  | — |  |
| International - Developed | 23 |  |  | — |  |  | 23 |  |  | — |  |
| International - Emerging | 12 |  |  | — |  |  | 12 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 23 |  |  | — |  |  | 23 |  |  | — |  |
| Corporate/Other | 65 |  |  | — |  |  | 65 |  |  | — |  |
| Commodities | 12 |  |  | — |  |  | 12 |  |  | — |  |
| Real Estate | 13 |  |  | — |  |  | 13 |  |  | — |  |
| Total Plan Assets | $ | 196 |  |  | $ | — |  |  | $ | 196 |  |  | $ | — |  |

[0000833444-17-000060:notes:455]
* The fair value of certain investments in real estate do not have a readily determinable fair value and requires the fund managers to independently arrive at fair value by calculating net asset value ("NAV") per share. In order to calculate NAV per share, the fund managers value the real estate investments using any one, or a combination of, the following methods: independent third party appraisals, discounted cash flow analysis of net cash flows projected to be generated by the investment and recent sales of comparable investments. Assumptions used to revalue the properties are updated every quarter. Due to the fact that the fund managers calculate NAV per share, the Company utilizes a practical expedient for measuring the fair value of its real-estate investments, as provided for under ASC 820, "Fair Value Measurement." In applying the practical expedient, the Company is not required to further adjust the NAV provided by the fund manager in order to determine the fair value of its investment as the NAV per share is calculated in a manner consistent with the measurement principles of ASC 946, "Financial Services - Investment Companies," and as of the Company's measurement date. The Company believes this is an appropriate methodology to obtain the fair value of these assets. For the component of the real estate portfolio under development, the investments are carried at cost until they are completed and valued by a third party appraiser. In accordance with ASU No. 2015-07, "Disclosures for Investments in Certain Entities That Calculate Net Asset Value per Share (or Its Equivalent)," investments for which fair value is measured using the net asset value per share practical expedient should be disclosed separate from the fair value hierarchy. The fair value amounts presented in this table are intended to permit reconciliation of total plan assets to the amounts presented in the notes to consolidated financial statements.

[0000833444-17-000060:notes:456]
The following is a description of the valuation methodologies used for assets measured at fair value.  Certain assets are held within commingled funds which are valued at the unitized NAV or percentage of the net asset value as determined by the manager of the fund. These values are based on the fair value of the underlying net assets owned by the fund.

[0000833444-17-000060:notes:457]
Cash and Cash Equivalents: The fair value of cash is valued at cost.

[0000833444-17-000060:notes:458]
Equity Securities: The fair value of equity securities is determined by direct quoted market prices. The underlying holdings are direct quoted market prices on regulated financial exchanges.

[0000833444-17-000060:notes:459]
Fixed Income Securities: The fair value of fixed income securities is determined by direct or indirect quoted market prices. If indirect quoted market prices are utilized, the value of assets held in separate accounts is not published, but the investment managers report daily the underlying holdings. The underlying holdings are direct quoted market prices on regulated financial exchanges.

[0000833444-17-000060:notes:460]
Commodities: The fair value of the commodities is determined by quoted market prices of the underlying holdings on regulated financial exchanges.

[0000833444-17-000060:notes:461]
Hedge Funds: The fair value of hedge funds is accounted for by the custodian. The custodian obtains valuations from underlying managers based on market quotes for the most liquid assets and alternative methods for assets that do not have sufficient trading activity to derive prices. The Company and custodian review the methods used by the underlying managers to value the assets. The Company believes this is an appropriate methodology to obtain the fair value of these assets.

[0000833444-17-000060:notes:462]
Real Estate: The fair value of Real Estate Investment Trusts ("REITs") is recorded as Level 1 as these securities are traded on an open exchange.

[0000833444-17-000060:notes:463]
The methods described above may produce a fair value calculation that may not be indicative of net realizable value or reflective of future fair values. Furthermore, while the Company believes its valuation methods are appropriate and consistent with other market participants, the use of different methodologies or assumptions to determine the fair value of certain financial instruments could result in a different fair value measurement at the reporting date.

[0000833444-17-000060:notes:464]
There were no Level 3 assets as of September 30, 2017 or 2016 or any Level 3 asset activity during fiscal 2017 or 2016.

[0000833444-17-000060:notes:465]
Funded Status

[0000833444-17-000060:notes:466]
The table that follows contains the ABO and reconciliations of the changes in the PBO, the changes in plan assets and the funded status (in millions):

[0000833444-17-000060:notes:467]
|  | Pension Benefits |  | PostretirementBenefits |
|  | U.S. Plans |  | Non-U.S. Plans |  |
| September 30, | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Accumulated Benefit Obligation | $ | 3,382 |  |  | $ | 4,118 |  |  | $ | 2,618 |  |  | $ | 3,359 |  |  | $ | — |  |  | $ | — |  |
| Change in Projected Benefit Obligation |  |  |  |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of year | 4,169 |  |  | 3,022 |  |  | 3,522 |  |  | 1,447 |  |  | 242 |  |  | 211 |  |
| Service cost | 18 |  |  | 16 |  |  | 32 |  |  | 30 |  |  | 2 |  |  | 2 |  |
| Interest cost | 113 |  |  | 104 |  |  | 48 |  |  | 44 |  |  | 6 |  |  | 6 |  |
| Plan participant contributions | — |  |  | — |  |  | 3 |  |  | 1 |  |  | 4 |  |  | 6 |  |
| Benefit obligations assumed in Tyco acquisition | — |  |  | 974 |  |  | — |  |  | 1,635 |  |  | — |  |  | 30 |  |
| Other acquisitions | — |  |  | — |  |  | — |  |  | 279 |  |  | — |  |  | 2 |  |
| Adient spin-off impact | (18 | ) |  | — |  |  | (619 | ) |  | — |  |  | (17 | ) |  | — |  |
| Actuarial (gain) loss | (131 | ) |  | 355 |  |  | (194 | ) |  | 295 |  |  | (1 | ) |  | 5 |  |
| Benefits and settlements paid | (732 | ) |  | (301 | ) |  | (116 | ) |  | (116 | ) |  | (25 | ) |  | (22 | ) |
| Estimated subsidy received | — |  |  | — |  |  | — |  |  | — |  |  | 2 |  |  | 1 |  |
| Curtailment | — |  |  | — |  |  | (19 | ) |  | — |  |  | — |  |  | — |  |
| Other | — |  |  | (1 | ) |  | (2 | ) |  | (1 | ) |  | — |  |  | 1 |  |
| Currency translation adjustment | — |  |  | — |  |  | 66 |  |  | (92 | ) |  | 1 |  |  | — |  |
| Projected benefit obligation at end of year | $ | 3,419 |  |  | $ | 4,169 |  |  | $ | 2,721 |  |  | $ | 3,522 |  |  | $ | 214 |  |  | $ | 242 |  |
| Change in Plan Assets |  |  |  |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year | $ | 3,293 |  |  | $ | 2,606 |  |  | $ | 2,536 |  |  | $ | 1,177 |  |  | $ | 196 |  |  | $ | 194 |  |
| Actual return on plan assets | 334 |  |  | 267 |  |  | 94 |  |  | 113 |  |  | 14 |  |  | 17 |  |
| Plan assets acquired in Tyco acquisition | — |  |  | 705 |  |  | — |  |  | 1,149 |  |  | — |  |  | — |  |
| Other acquisitions | — |  |  | — |  |  | — |  |  | 180 |  |  | — |  |  | — |  |
| Adient spin-off impact | (16 | ) |  | — |  |  | (440 | ) |  | — |  |  | (13 | ) |  | — |  |
| Employer and employee contributions | 286 |  |  | 16 |  |  | 59 |  |  | 121 |  |  | 5 |  |  | 7 |  |
| Benefits paid | (394 | ) |  | (124 | ) |  | (86 | ) |  | (59 | ) |  | (25 | ) |  | (22 | ) |
| Settlement payments | (338 | ) |  | (177 | ) |  | (30 | ) |  | (57 | ) |  | — |  |  | — |  |
| Other | — |  |  | — |  |  | (2 | ) |  | — |  |  | — |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | 50 |  |  | (88 | ) |  | — |  |  | — |  |
| Fair value of plan assets at end of year | $ | 3,165 |  |  | $ | 3,293 |  |  | $ | 2,181 |  |  | $ | 2,536 |  |  | $ | 177 |  |  | $ | 196 |  |
| Funded status | $ | (254 | ) |  | $ | (876 | ) |  | $ | (540 | ) |  | $ | (986 | ) |  | $ | (37 | ) |  | $ | (46 | ) |
| Amounts recognized in the statement of financial position consist of: |
| Prepaid benefit cost - continuing operations | $ | 46 |  |  | $ | 21 |  |  | $ | 27 |  |  | $ | 25 |  |  | $ | 64 |  |  | $ | 53 |  |
| Prepaid benefit cost - discontinued operations | — |  |  | 1 |  |  | — |  |  | 7 |  |  | — |  |  | — |  |
| Accrued benefit liability - continuing operations | (300 | ) |  | (896 | ) |  | (567 | ) |  | (832 | ) |  | (101 | ) |  | (95 | ) |
| Accrued benefit liability - discontinued operations | — |  |  | (2 | ) |  | — |  |  | (186 | ) |  | — |  |  | (4 | ) |
| Net amount recognized | $ | (254 | ) |  | $ | (876 | ) |  | $ | (540 | ) |  | $ | (986 | ) |  | $ | (37 | ) |  | $ | (46 | ) |
| Weighted Average Assumptions (1) |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate (2) | 3.80 | % |  | 3.70 | % |  | 2.40 | % |  | 1.90 | % |  | 3.70 | % |  | 3.30 | % |
| Rate of compensation increase | 3.20 | % |  | 3.20 | % |  | 2.90 | % |  | 2.75 | % |  | NA |  |  | NA |  |

[0000833444-17-000060:notes:468]
| (1) | Plan assets and obligations are determined based on a September 30 measurement date at September 30, 2017 and 2016. |

[0000833444-17-000060:notes:469]
| (2) | The Company considers the expected benefit payments on a plan-by-plan basis when setting assumed discount rates. As a result, the Company uses different discount rates for each plan depending on the plan jurisdiction, the demographics of participants and the expected timing of benefit payments. For the U.S. pension and postretirement plans, the Company uses a discount rate provided by an independent third party calculated based on an appropriate mix of high quality bonds. For the non-U.S. pension and postretirement plans, the Company consistently uses the relevant country specific benchmark indices for determining the various discount rates. The Company has elected to utilize a full yield curve approach in the estimation of service and interest components of net periodic benefit cost (credit) for pension and other postretirement for plans that utilize a yield curve approach. The full yield curve approach applies the specific spot rates along the yield curve used in the determination of the benefit obligation to the relevant projected cash flows. |

[0000833444-17-000060:notes:470]
Accumulated Other Comprehensive Income

[0000833444-17-000060:notes:471]
The amounts in AOCI on the consolidated statements of financial position, exclusive of tax impacts, that have not yet been recognized as components of net periodic benefit cost at September 30, 2017 and 2016 related to pension and postretirement benefits are not significant.

[0000833444-17-000060:notes:472]
The amounts in AOCI expected to be recognized as components of net periodic benefit cost (credit) over the next fiscal related to pension and postretirement benefits are not significant.

[0000833444-17-000060:notes:473]
Net Periodic Benefit Cost

[0000833444-17-000060:notes:474]
The table that follows contains the components of net periodic benefit cost (in millions):

[0000833444-17-000060:notes:475]
|  | Pension Benefits |  | Postretirement Benefits |
|  | U.S. Plans |  | Non-U.S. Plans |  |
| Year ended September 30, | 2017 |  | 2016 |  | 2015 |  | 2017 |  | 2016 |  | 2015 |  | 2017 |  | 2016 |  | 2015 |
| Components of Net Periodic Benefit Cost (Credit): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost | $ | 18 |  |  | $ | 16 |  |  | $ | 31 |  |  | $ | 32 |  |  | $ | 30 |  |  | $ | 32 |  |  | $ | 2 |  |  | $ | 2 |  |  | $ | 3 |  |
| Interest cost | 113 |  |  | 104 |  |  | 122 |  |  | 48 |  |  | 44 |  |  | 57 |  |  | 6 |  |  | 6 |  |  | 9 |  |
| Expected return on plan assets | (229 | ) |  | (191 | ) |  | (181 | ) |  | (92 | ) |  | (61 | ) |  | (71 | ) |  | (10 | ) |  | (10 | ) |  | (12 | ) |
| Net actuarial (gain) loss | (220 | ) |  | 268 |  |  | 387 |  |  | (195 | ) |  | 237 |  |  | 14 |  |  | (5 | ) |  | (2 | ) |  | 21 |  |
| Amortization of prior service cost (credit) | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | (1 | ) |  | — |  |  | (1 | ) |  | (1 | ) |
| Curtailment gain | — |  |  | — |  |  | — |  |  | (19 | ) |  | — |  |  | (15 | ) |  | — |  |  | — |  |  | — |  |
| Settlement (gain) loss | (16 | ) |  | 11 |  |  | 1 |  |  | (1 | ) |  | 6 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (credit) | (334 | ) |  | 208 |  |  | 360 |  |  | (227 | ) |  | 257 |  |  | 16 |  |  | (7 | ) |  | (5 | ) |  | 20 |  |
| Net periodic benefit (cost) credit related to discontinued operations | — |  |  | (1 | ) |  | (1 | ) |  | — |  |  | (111 | ) |  | 1 |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Net periodic benefit cost (credit) included in continuing operations | $ | (334 | ) |  | $ | 207 |  |  | $ | 359 |  |  | $ | (227 | ) |  | $ | 146 |  |  | $ | 17 |  |  | $ | (7 | ) |  | $ | (6 | ) |  | $ | 19 |  |
| Expense Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate | 3.70 | % |  | 4.40 | % |  | 4.35 | % |  | 1.90 | % |  | 3.10 | % |  | 3.00 | % |  | 3.30 | % |  | 3.75 | % |  | 4.35 | % |
| Expected return on plan assets | 7.50 | % |  | 7.50 | % |  | 7.50 | % |  | 4.60 | % |  | 4.50 | % |  | 4.50 | % |  | 5.60 | % |  | 5.45 | % |  | 5.75 | % |
| Rate of compensation increase | 3.20 | % |  | 3.25 | % |  | 3.25 | % |  | 2.65 | % |  | 3.30 | % |  | 2.60 | % |  | NA |  |  | NA |  |  | NA |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000833444-17-000060:notes:476]
PROPERTY, PLANT AND EQUIPMENT

[0000833444-17-000060:notes:477]
Property, plant and equipment consisted of the following (in millions):

[0000833444-17-000060:notes:478]
|  | September 30, |
|  | 2017 |  | 2016 |
| Buildings and improvements | $ | 2,445 |  |  | $ | 2,107 |  |
| Subscriber systems | 571 |  |  | 448 |  |
| Machinery and equipment | 5,572 |  |  | 5,137 |  |
| Construction in progress | 1,252 |  |  | 990 |  |
| Land | 373 |  |  | 367 |  |
| Total property, plant and equipment | 10,213 |  |  | 9,049 |  |
| Less: accumulated depreciation | (4,092 | ) |  | (3,417 | ) |
| Property, plant and equipment - net | $ | 6,121 |  |  | $ | 5,632 |  |

[0000833444-17-000060:notes:479]
Interest costs capitalized during the fiscal years ended September 30, 2017, 2016 and 2015 were $27 million, $19 million and $25 million, respectively. Accumulated depreciation related to capital leases at September 30, 2017 and 2016 was $13 million and $16 million, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000833444-17-000060:notes:480]
Property, Plant and Equipment

[0000833444-17-000060:notes:481]
Property, plant and equipment are recorded at cost. Depreciation is provided over the estimated useful lives of the respective assets using the straight-line method for financial reporting purposes and accelerated methods for income tax purposes. The estimated useful lives generally range from 3 to 40 years for buildings and improvements, subscriber systems up to 15 years, and from 3 to 15 years for machinery and equipment. The Company capitalizes interest on borrowings during the active construction period of major capital projects. Capitalized interest is added to the cost of the underlying assets and is amortized over the useful lives of the assets.


## us-gaap:ReceivablesPolicyTextBlock

[0000833444-17-000060:notes:482]
Receivables

[0000833444-17-000060:notes:483]
Receivables consist of amounts billed and currently due from customers and unbilled costs and accrued profits related to revenues on long-term contracts that have been recognized for accounting purposes but not yet billed to customers. The Company extends credit to customers in the normal course of business and maintains an allowance for doubtful accounts resulting from the inability or unwillingness of customers to make required payments. The allowance for doubtful accounts is based on historical experience, existing economic conditions and any specific customer collection issues the Company has identified. The Company enters into supply chain financing programs to sell certain accounts receivable without recourse to third-party financial institutions. Sales of accounts receivable are reflected as a reduction of accounts receivable on the consolidated statements of financial position and the proceeds are included in cash flows from operating activities in the consolidated statements of cash flows.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-17-000060:notes:484]
RELATED PARTY TRANSACTIONS

[0000833444-17-000060:notes:485]
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-17-000060:notes:486]
The net sales to and purchases from related parties for continuing operations included in the consolidated statements of income were $954 million and $195 million, respectively, for fiscal 2017; $917 million and $184 million, respectively, for fiscal 2016; and $892 million and $95 million, respectively, for fiscal 2015.

[0000833444-17-000060:notes:487]
The following table sets forth the amount of accounts receivable due from and payable to related parties for continuing operations in the consolidated statements of financial position (in millions):

[0000833444-17-000060:notes:488]
|  |  | September 30, |
|  |  | 2017 |  | 2016 |
| Receivable from related parties |  | $ | 108 |  |  | $ | 72 |  |
| Payable to related parties |  | 50 |  |  | 14 |  |

[0000833444-17-000060:notes:489]
The Company has also provided financial support to certain of its VIE's, see Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements for additional information.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-17-000060:notes:490]
SIGNIFICANT RESTRUCTURING AND IMPAIRMENT COSTS

[0000833444-17-000060:notes:491]
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company commits to restructuring plans as necessary.

[0000833444-17-000060:notes:492]
In fiscal 2017, the Company committed to a significant restructuring plan (2017 Plan) and recorded $367 million of restructuring and impairment costs in the consolidated statements of income. This is the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. Of the restructuring and impairment costs recorded, $166 million related to Corporate, $74 million related to the Building Solutions EMEA/LA segment, $59 million related to the Building Solutions North America segment, $32 million related to the Global Products segment, $20 million related to the Power Solutions segment and $16 million related to the Building Solutions Asia Pacific segment. The restructuring actions are expected to be substantially complete in fiscal 2018.

[0000833444-17-000060:notes:493]
The following table summarizes the changes in the Company’s 2017 Plan reserve, included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-17-000060:notes:494]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original Reserve | $ | 276 |  |  | $ | 77 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 367 |  |
| Utilized—cash | (75 | ) |  | — |  |  | — |  |  | — |  |  | (75 | ) |
| Utilized—noncash | — |  |  | (77 | ) |  | (1 | ) |  | — |  |  | (78 | ) |
| Adjustment to restructuring reserves | 25 |  |  | — |  |  | — |  |  | — |  |  | 25 |  |
| Balance at September 30, 2017 | $ | 226 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |  | $ | 239 |  |

[0000833444-17-000060:notes:495]
In fiscal 2016, the Company committed to a significant restructuring plan (2016 Plan) and recorded $288 million of restructuring and impairment costs in the consolidated statements of income. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments and change-in-control payments. Of the restructuring and impairment costs recorded, $161 million related to Corporate, $66 million related to the Power Solutions segment, $44 million related to the Global Products segment and $17 million related to the Building Solutions EMEA/LA segment. The restructuring actions are expected to be substantially complete in fiscal 2018. Included in the reserve is $56 million of committed restructuring actions taken by Tyco for liabilities assumed as part of the Tyco acquisition.

[0000833444-17-000060:notes:496]
Additionally, the Company recorded $332 million of restructuring and impairment costs within discontinued operations related to Adient in fiscal 2016.

[0000833444-17-000060:notes:497]
The following table summarizes the changes in the Company’s 2016 Plan reserve, included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-17-000060:notes:498]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original Reserve | $ | 368 |  |  | $ | 190 |  |  | $ | 62 |  |  | $ | — |  |  | $ | 620 |  |
| Acquired Tyco restructuring reserves | 78 |  |  | — |  |  | — |  |  | — |  |  | 78 |  |
| Utilized—cash | (32 | ) |  | — |  |  | — |  |  | — |  |  | (32 | ) |
| Utilized—noncash | — |  |  | (190 | ) |  | (32 | ) |  | 1 |  |  | (221 | ) |
| Balance at September 30, 2016 | $ | 414 |  |  | $ | — |  |  | $ | 30 |  |  | $ | 1 |  |  | $ | 445 |  |
| Adient spin-off impact | (194 | ) |  | — |  |  | (22 | ) |  | — |  |  | (216 | ) |
| Utilized—cash | (86 | ) |  | — |  |  | (2 | ) |  | — |  |  | (88 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Adjustment to restructuring reserves | (25 | ) |  | — |  |  | — |  |  | — |  |  | (25 | ) |
| Transfer to liabilities held for sale | (3 | ) |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Adjustment to acquired Tyco restructuring reserves | (22 | ) |  | — |  |  | — |  |  | — |  |  | (22 | ) |
| Balance at September 30, 2017 | $ | 84 |  |  | $ | — |  |  | $ | 6 |  |  | $ | 2 |  |  | $ | 92 |  |

[0000833444-17-000060:notes:499]
The Company's fiscal 2017 and 2016 restructuring plans included workforce reductions of approximately 6,100 employees (4,800 for the Building Technologies & Solutions business, 1,200 for Corporate and 100 for Power Solutions). Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of September 30, 2017, approximately 1,600 of the employees have been separated from the Company pursuant to the restructuring plans. In addition, the restructuring plans included ten plant closures in the Building Technologies & Solutions business. As of September 30, 2017, four of the ten plants have been closed.

[0000833444-17-000060:notes:500]
Company management closely monitors its overall cost structure and continually analyzes each of its businesses for opportunities to consolidate current operations, improve operating efficiencies and locate facilities in close proximity to customers. This ongoing analysis includes a review of its manufacturing, engineering and purchasing operations, as well as the overall global footprint for all its businesses.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000833444-17-000060:notes:501]
Revenue Recognition

[0000833444-17-000060:notes:502]
The Building Technologies & Solutions business records certain long-term contracts under the percentage-of-completion ("POC") method of accounting. Under this method, sales and gross profit are recognized as work is performed based on the relationship between actual costs incurred and total estimated costs at completion. The Company records costs and earnings in excess of billings on uncompleted contracts primarily within accounts receivable and billings in excess of costs and earnings on uncompleted contracts primarily within deferred revenue in the consolidated statements of financial position. Costs and earnings in excess of billings related to these contracts were $908 million and $841 million at September 30, 2017 and 2016, respectively. Billings in excess of costs and earnings related to these contracts were $451 million and $431 million at September 30, 2017 and 2016, respectively. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. Sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. Claims against customers are recognized as revenue upon settlement. The use of the POC method of accounting involves considerable use of estimates in determining revenues, costs and profits and in assigning the amounts to accounting periods. The periodic reviews have not resulted in adjustments that were significant to the Company’s results of operations. The Company continually evaluates all of the assumptions, risks and uncertainties inherent with the application of the POC method of accounting.

[0000833444-17-000060:notes:503]
The Building Technologies & Solutions business enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized on a straight-line basis over the respective contract term.

[0000833444-17-000060:notes:504]
The Building Technologies & Solutions business also sells certain heating, ventilating and air conditioning ("HVAC") and refrigeration products and services in bundled arrangements, where multiple products and/or services are involved. Significant deliverables within these arrangements include equipment, commissioning, service labor and extended warranties. Approximately four to twelve months separate the timing of the first deliverable until the last piece of equipment is delivered, and there may be extended warranty arrangements with duration of one to five years commencing upon the end of the standard warranty period. In addition, the Building Technologies & Solutions business sells security monitoring systems that may have multiple elements, including equipment, installation, monitoring services and maintenance agreements. Revenues associated with sale of equipment and related installations are recognized once delivery, installation and customer acceptance is completed, while the revenue for monitoring and maintenance services are recognized as services are rendered. In accordance with Accounting Standards Update ("ASU") No. 2009-13, "Revenue Recognition (Topic 605): Multiple-Deliverable Revenue Arrangements - A Consensus of the FASB Emerging Issues Task Force," the Company divides bundled arrangements into separate deliverables and revenue is allocated to each deliverable based on the relative selling price method. In order to estimate relative selling price, market data and transfer price studies are utilized. Revenue recognized for security monitoring equipment and installation is limited to the lesser of their allocated amounts under the estimated selling price hierarchy or the non-contingent up-front consideration received at the time of installation, since collection of future amounts under the arrangement with the customer is contingent upon the delivery of monitoring and maintenance services. For transactions in which the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized on a straight-line basis over the contract term. Non-refundable fees received in connection with the initiation of a monitoring contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the customer relationship.

[0000833444-17-000060:notes:505]
In all other cases, the Company recognizes revenue at the time title passes to the customer or as services are performed.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000833444-17-000060:notes:506]
The following schedules present changes in AOCI attributable to Johnson Controls (in millions, net of tax):

[0000833444-17-000060:notes:507]
|  | Year Ended September 30, 2017 |  | Year Ended September 30, 2016 |  | Year Ended September 30, 2015 |
| Foreign currency translation adjustments |  |  |  |  |  |
| Balance at beginning of period | $ | (1,152 | ) |  | $ | (1,047 | ) |  | $ | (248 | ) |
| Aggregate adjustment for the period (net of tax effect of $1, $(43) and $(44)) * | 108 |  |  | (105 | ) |  | (799 | ) |
| Adient spin-off impact (net of tax effect of $0) | 563 |  |  | — |  |  | — |  |
| Balance at end of period | (481 | ) |  | (1,152 | ) |  | (1,047 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |  |  |
| Balance at beginning of period | 4 |  |  | (7 | ) |  | 4 |  |
| Current period changes in fair value (net of tax effect of $4, $(5) and $(7)) | 9 |  |  | (10 | ) |  | (17 | ) |
| Reclassification to income (net of tax effect of $(10), $11 and $3) ** | (23 | ) |  | 21 |  |  | 6 |  |
| Adient spin-off impact (net of tax effect of $6) | 16 |  |  | — |  |  | — |  |
| Balance at end of period | 6 |  |  | 4 |  |  | (7 | ) |
| Realize and unrealized gains (losses) on marketable securities |  |  |  |  |  |
| Balance at beginning of period | (1 | ) |  | — |  |  | — |  |
| Current period changes in fair value (net of tax effect of $1, $0 and $0) | 5 |  |  | (1 | ) |  | — |  |
| Balance at end of period | 4 |  |  | (1 | ) |  | — |  |
| Pension and postretirement plans |  |  |  |  |  |
| Balance at beginning of period | (4 | ) |  | (3 | ) |  | 7 |  |
| Reclassification to income (net of tax effect of $0, $0 and $(3)) *** | — |  |  | (1 | ) |  | (11 | ) |
| Adient spin-off impact (net of tax effect of $0) | 2 |  |  | — |  |  | — |  |
| Other changes (net of tax effect of $0) | — |  |  | — |  |  | 1 |  |
| Balance at end of period | (2 | ) |  | (4 | ) |  | (3 | ) |
| Accumulated other comprehensive loss, end of period | $ | (473 | ) |  | $ | (1,153 | ) |  | $ | (1,057 | ) |

[0000833444-17-000060:notes:508]
*   During fiscal 2015, ($19) million of cumulative CTA were recognized as part of the divestiture-related gain recognized within discontinued operations as a result of the divestiture of GWS.

[0000833444-17-000060:notes:509]
**   Refer to Note 10, "Derivative Instruments and Hedging Activities," of the notes to consolidated financial statements for disclosure of the line items on the consolidated statements of income affected by reclassifications from AOCI into income related to derivatives.

[0000833444-17-000060:notes:510]
***  Refer to Note 15, "Retirement Plans," of the notes to consolidated financial statements for disclosure of the components of the Company's net periodic benefit costs associated with its defined benefit pension and postretirement plans. For the year ended September 30, 2016  the amounts reclassified from AOCI into income for pension and postretirement plans were primarily recorded in selling, general and administrative expenses on the consolidated statements of income. For the year ended September 30, 2015 the amounts reclassified from AOCI into income for pension and postretirement plans were primarily recorded in selling, general and administrative expenses and income (loss) from discontinued operations, net of tax on the consolidated statements of income.


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000833444-17-000060:notes:511]
Financial information relating to the Company’s operations by geographic area is as follows (in millions):

[0000833444-17-000060:notes:512]
|  | Year Ended September 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Net Sales |  |  |  |  |  |
| United States | $ | 14,495 |  |  | $ | 9,633 |  |  | $ | 8,982 |  |
| China | 2,046 |  |  | 1,620 |  |  | 1,350 |  |
| Japan | 1,816 |  |  | 1,805 |  |  | 315 |  |
| Germany | 1,779 |  |  | 1,430 |  |  | 911 |  |
| United Kingdom | 928 |  |  | 291 |  |  | 309 |  |
| Mexico | 840 |  |  | 639 |  |  | 635 |  |
| Other foreign | 5,408 |  |  | 3,602 |  |  | 2,637 |  |
| Other European countries | 2,860 |  |  | 1,817 |  |  | 1,961 |  |
| Total | $ | 30,172 |  |  | $ | 20,837 |  |  | $ | 17,100 |  |
| Long-Lived Assets (Year-end) |  |  |  |  |  |
| United States | $ | 3,155 |  |  | $ | 2,880 |  |  | $ | 2,056 |  |
| China | 535 |  |  | 484 |  |  | 415 |  |
| Japan | 180 |  |  | 188 |  |  | 8 |  |
| Germany | 290 |  |  | 287 |  |  | 304 |  |
| United Kingdom | 109 |  |  | 103 |  |  | 4 |  |
| Mexico | 489 |  |  | 457 |  |  | 368 |  |
| Other foreign | 821 |  |  | 785 |  |  | 252 |  |
| Other European countries | 542 |  |  | 448 |  |  | 276 |  |
| Total | $ | 6,121 |  |  | $ | 5,632 |  |  | $ | 3,683 |  |

[0000833444-17-000060:notes:513]
Net sales attributed to geographic locations are based on the location of the assets producing the sales. Long-lived assets by geographic location consist of net property, plant and equipment.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000833444-17-000060:notes:514]
Financial information relating to the Company’s reportable segments is as follows (in millions):

[0000833444-17-000060:notes:515]
|  | Year Ended September 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Net Sales |  |  |  |  |  |
| Building Technologies & Solutions |  |  |  |  |  |
| Building Solutions North America | $ | 8,341 |  |  | $ | 4,687 |  |  | $ | 4,270 |  |
| Building Solutions EMEA/LA | 3,595 |  |  | 1,613 |  |  | 1,549 |  |
| Building Solutions Asia Pacific | 2,444 |  |  | 1,736 |  |  | 1,651 |  |
| Global Products | 8,455 |  |  | 6,148 |  |  | 3,040 |  |
|  | 22,835 |  |  | 14,184 |  |  | 10,510 |  |
| Power Solutions | 7,337 |  |  | 6,653 |  |  | 6,590 |  |
| Total net sales | $ | 30,172 |  |  | $ | 20,837 |  |  | $ | 17,100 |  |

[0000833444-17-000060:notes:516]
|  | Year Ended September 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Segment EBITA |  |  |  |  |  |
| Building Technologies & Solutions |  |  |  |  |  |
| Building Solutions North America (1) | $ | 1,039 |  |  | $ | 494 |  |  | $ | 416 |  |
| Building Solutions EMEA/LA (2) | 290 |  |  | 74 |  |  | 45 |  |
| Building Solutions Asia Pacific (3) | 323 |  |  | 222 |  |  | 211 |  |
| Global Products (4) | 1,179 |  |  | 637 |  |  | 414 |  |
|  | 2,831 |  |  | 1,427 |  |  | 1,086 |  |
| Power Solutions (5) | 1,427 |  |  | 1,327 |  |  | 1,241 |  |
| Total segment EBITA | $ | 4,258 |  |  | $ | 2,754 |  |  | $ | 2,327 |  |
| Amortization of intangible assets | (489 | ) |  | (116 | ) |  | (74 | ) |
| Corporate expenses (6) | (768 | ) |  | (607 | ) |  | (417 | ) |
| Net financing charges | (496 | ) |  | (289 | ) |  | (274 | ) |
| Restructuring and impairment costs | (367 | ) |  | (288 | ) |  | (215 | ) |
| Net mark-to-market adjustments on pension and postretirement plans | 420 |  |  | (393 | ) |  | (416 | ) |
| Income from continuing operations before income taxes | $ | 2,558 |  |  | $ | 1,061 |  |  | $ | 931 |  |

[0000833444-17-000060:notes:517]
|  | September 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Assets |  |  |  |  |  |
| Building Technologies & Solutions (7) |  |  |  |  |  |
| Building Solutions North America | $ | 15,228 |  |  | $ | 15,554 |  |  | $ | 2,300 |  |
| Building Solutions EMEA/LA (8) | 4,885 |  |  | 4,649 |  |  | 1,022 |  |
| Building Solutions Asia Pacific | 2,575 |  |  | 2,521 |  |  | 978 |  |
| Global Products (9) | 14,018 |  |  | 15,782 |  |  | 5,083 |  |
|  | 36,706 |  |  | 38,506 |  |  | 9,383 |  |
| Power Solutions (10) | 7,894 |  |  | 6,793 |  |  | 6,531 |  |
| Assets held for sale | 2,109 |  |  | 13,186 |  |  | 10,613 |  |
| Unallocated | 5,175 |  |  | 4,694 |  |  | 3,063 |  |
| Total | $ | 51,884 |  |  | $ | 63,179 |  |  | $ | 29,590 |  |

[0000833444-17-000060:notes:518]
|  | Year Ended September 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Depreciation/Amortization |  |  |  |  |  |
| Building Technologies & Solutions |  |  |  |  |  |
| Building Solutions North America | $ | 272 |  |  | $ | 49 |  |  | $ | 24 |  |
| Building Solutions EMEA/LA | 140 |  |  | 14 |  |  | 10 |  |
| Building Solutions Asia Pacific | 37 |  |  | 11 |  |  | 9 |  |
| Global Products | 410 |  |  | 230 |  |  | 138 |  |
|  | 859 |  |  | 304 |  |  | 181 |  |
| Power Solutions | 236 |  |  | 238 |  |  | 286 |  |
| Corporate | 64 |  |  | 80 |  |  | 60 |  |
| Discontinued Operations | 29 |  |  | 331 |  |  | 333 |  |
| Total | $ | 1,188 |  |  | $ | 953 |  |  | $ | 860 |  |

[0000833444-17-000060:notes:519]
|  | Year Ended September 30, |
|  | 2017 |  | 2016 |  | 2015 |
| Capital Expenditures |  |  |  |  |  |
| Building Technologies & Solutions |  |  |  |  |  |
| Building Solutions North America | $ | 107 |  |  | $ | 16 |  |  | $ | 17 |  |
| Building Solutions EMEA/LA | 98 |  |  | 19 |  |  | 17 |  |
| Building Solutions Asia Pacific | 27 |  |  | 7 |  |  | 8 |  |
| Global Products | 421 |  |  | 304 |  |  | 162 |  |
| Global Workplace Solutions | — |  |  | — |  |  | 13 |  |
|  | 653 |  |  | 346 |  |  | 217 |  |
| Automotive Experience |  |  |  |  |  |
| Seating | 62 |  |  | 392 |  |  | 356 |  |
| Interiors | 1 |  |  | 3 |  |  | 99 |  |
|  | 63 |  |  | 395 |  |  | 455 |  |
| Power Solutions | 481 |  |  | 357 |  |  | 252 |  |
| Corporate | 146 |  |  | 151 |  |  | 211 |  |
| Total | $ | 1,343 |  |  | $ | 1,249 |  |  | $ | 1,135 |  |

[0000833444-17-000060:notes:520]
| (1) | Building Solutions North America segment EBITA for the years ended September 30, 2017 and 2015 excludes $59 million and $2 million, respectively, of restructuring and impairment costs. |

[0000833444-17-000060:notes:521]
| (2) | Building Solutions EMEA/LA segment EBITA for the years ended September 30, 2017, 2016 and 2015 excludes $74 million, $17 million and $9 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2017, 2016 and 2015, EMEA/LA segment EBITA includes $5 million, $11 million and $14 million, respectively, of equity income. |

[0000833444-17-000060:notes:522]
| (3) | Building Solutions Asia Pacific segment EBITA for the years ended September 30, 2017 and 2015 excludes $16 million and $7 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2017 and 2016, Asia Pacific segment EBITA includes $1 million and $1 million, respectively, of equity income. |

[0000833444-17-000060:notes:523]
| (4) | Global Products segment EBITA for the years ended September 30, 2017, 2016 and 2015 excludes $32 million, $44 million and $20 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2017, 2016 and 2015, Global Products segment EBITA includes $151 million, $114 million and $9 million, respectively, of equity income. |

[0000833444-17-000060:notes:524]
| (5) | Power Solutions segment EBITA for the years ended September 30, 2017, 2016 and 2015 excludes $20 million, $66 million and $11 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2017, 2016 and 2015, Power Solutions segment EBITA includes $83 million, $48 million and $57 million, respectively, of equity income. |

[0000833444-17-000060:notes:525]
| (6) | Corporate expenses for the years ended September 30, 2017, 2016 and 2015 excludes $166 million, $161 million and $166 million, respectively, of restructuring and impairment costs. |

[0000833444-17-000060:notes:526]
| (7) | Current year and prior year amounts exclude assets held for sale. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's disposal groups classified as held for sale. |

[0000833444-17-000060:notes:527]
| (8) | Building Solutions EMEA/LA assets as of September 30 2017, 2016 and 2015, include $107 million, $103 million and $90 million, respectively, of investments in partially-owned affiliates. |

[0000833444-17-000060:notes:528]
| (9) | Global Products assets as of September 30 2017, 2016 and 2015, include $637 million, $520 million and $64 million, respectively, of investments in partially-owned affiliates. |

[0000833444-17-000060:notes:529]
| (10) | Power Solutions assets as of September 30 2017, 2016 and 2015, include $447 million, $367 million and $343 million, respectively, of investments in partially-owned affiliates. |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000833444-17-000060:notes:530]
JOHNSON CONTROLS INTERNATIONAL PLC AND SUBSIDIARIES

[0000833444-17-000060:notes:531]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0000833444-17-000060:notes:532]
(In millions)

[0000833444-17-000060:notes:533]
| Year Ended September 30, | 2017 |  | 2016 |  | 2015 |
| Accounts Receivable - Allowance for Doubtful Accounts |  |  |  |  |  |
| Balance at beginning of period | $ | 173 |  |  | $ | 70 |  |  | $ | 64 |  |
| Provision charged to costs and expenses | 39 |  |  | 45 |  |  | 27 |  |
| Reserve adjustments | (9 | ) |  | (8 | ) |  | (5 | ) |
| Accounts charged off | (41 | ) |  | (25 | ) |  | (16 | ) |
| Acquisition of businesses | 18 |  |  | 91 |  |  | 1 |  |
| Currency translation | 2 |  |  | — |  |  | (1 | ) |
| Balance at end of period | $ | 182 |  |  | $ | 173 |  |  | $ | 70 |  |
| Deferred Tax Assets - Valuation Allowance |  |  |  |  |  |
| Balance at beginning of period | $ | 3,400 |  |  | $ | 1,151 |  |  | $ | 1,111 |  |
| Allowance provision for new operating and other loss carryforwards | 542 |  |  | 121 |  |  | 23 |  |
| Allowance provision benefits | (157 | ) |  | (331 | ) |  | 17 |  |
| Acquisition of businesses | 53 |  |  | 2,459 |  |  | — |  |
| Balance at end of period | $ | 3,838 |  |  | $ | 3,400 |  |  | $ | 1,151 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-17-000060:notes:534]
SEGMENT INFORMATION

[0000833444-17-000060:notes:535]
ASC 280, "Segment Reporting," establishes the standards for reporting information about segments in financial statements. In applying the criteria set forth in ASC 280, the Company has determined that it has five reportable segments for financial reporting purposes. The Company’s five reportable segments are presented in the context of its two primary businesses - Building Technologies & Solutions and Power Solutions.

[0000833444-17-000060:notes:536]
Effective July 1, 2017, the Company reorganized the reportable segments within its Building Technologies & Solutions business to align with its new management reporting structure and business activities. Prior to this reorganization, Building Technologies & Solutions was comprised of five reportable segments for financial reporting purposes: Systems and Service North America, Products North America, Asia, Rest of World and Tyco. As a result of this change, Building Technologies & Solutions is now comprised of four reportable segments for financial reporting purposes: Building Solutions North America, Building Solutions EMEA/LA, Building Solutions Asia Pacific and Global Products. Historical information has been revised to reflect the new Building Technologies & Solutions reportable segments.

[0000833444-17-000060:notes:537]
A summary of the significant Building Technologies & Solutions reportable segment changes is as follows:

[0000833444-17-000060:notes:538]
| • | The “Systems and Service North America” segment is now part of the new “Building Solutions North America” reportable segment. |

[0000833444-17-000060:notes:539]
| • | The North America Unitary Products business, Air Distribution Technologies business and refrigeration systems business, as well as HVAC products installed for Marine customers, previously included in the “Products North America” segment, are now part of the new reportable segment “Global Products.” The systems and products installation business for U.S. Navy customers, previously included in the “Products North America” segment, is now part of the new “Building Solutions North America” reportable segment. |

[0000833444-17-000060:notes:540]
| • | The systems and service business within the former “Asia” segment is now part of the new “Building Solutions Asia Pacific” reportable segment. The HVAC products manufacturing business and the Johnson Controls-Hitachi joint venture, previously part of the “Asia” segment, are now part of the new “Global Products” reportable segment. |

[0000833444-17-000060:notes:541]
| • | The systems and service businesses in Europe, the Middle East and Latin America within the former “Rest of World” segment are now part of the new “Building Solutions EMEA/LA” reportable segment. The HVAC products manufacturing businesses, previously part of the “Rest of World” segment, are now part of the new “Global Products” reportable segment. |

[0000833444-17-000060:notes:542]
| • | As the Company has integrated the legacy Tyco business with its legacy Building Efficiency business for segment reporting purposes, Tyco is no longer a separate reportable segment. The Tyco businesses are now included throughout the new reportable segments. |

[0000833444-17-000060:notes:543]
Building Technologies & Solutions

[0000833444-17-000060:notes:544]
| • | Building Solutions North America designs, sells, installs, and services HVAC and controls systems, integrated electronic security systems (including monitoring), and integrated fire detection and suppression systems for commercial, industrial, retail, small business, institutional and governmental customers in North America. Building Solutions North America also provides energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and control systems, to non-residential building and industrial applications in the North American marketplace. |

[0000833444-17-000060:notes:545]
| • | Building Solutions EMEA/LA designs, sells, installs, and services HVAC, controls, refrigeration, integrated electronic security, integrated fire detection and suppression systems, and provides technical services to markets in Europe, the Middle East, Africa and Latin America. |

[0000833444-17-000060:notes:546]
| • | Building Solutions Asia Pacific designs, sells, installs, and services HVAC, controls, refrigeration, integrated electronic security, integrated fire detection and suppression systems, and provides technical services to the Asia Pacific marketplace. |

[0000833444-17-000060:notes:547]
| • | Global Products designs and produces heating and air conditioning for residential and commercial applications, and markets products and refrigeration systems to replacement and new construction market customers globally. The Global Products business also designs, manufactures and sells fire protection and security products, including intrusion security, anti-theft devices, breathing apparatus and access control and video management systems, for commercial, industrial, retail, residential, small business, institutional and governmental customers worldwide. Global Products also includes the Johnson Controls-Hitachi joint venture, which was formed October 1, 2015, as well as the Scott Safety business, which was sold on October 4, 2017. |

[0000833444-17-000060:notes:548]
Power Solutions

[0000833444-17-000060:notes:549]
Power Solutions services both automotive original equipment manufacturers and the battery aftermarket by providing advanced battery technology, coupled with systems engineering, marketing and service expertise.

[0000833444-17-000060:notes:550]
Management evaluates the performance of its business segments primarily on segment earnings before interest, taxes and amortization ("EBITA"), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, significant restructuring and impairment costs, and the net mark-to-market adjustments related to pension and postretirement plans.

[0000833444-17-000060:notes:551]
In fiscal years 2017, 2016 and 2015, no customer exceeded 10% of consolidated net sales.

[0000833444-17-000060:notes:552]
Geographic Segments


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000833444-17-000060:notes:553]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0000833444-17-000060:notes:554]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company," "Johnson Controls" or "JCI plc").

[0000833444-17-000060:notes:555]
Nature of Operations

[0000833444-17-000060:notes:556]
On September 2, 2016, Johnson Controls, Inc. ("JCI Inc.") and Tyco International plc ("Tyco") completed their combination pursuant to the Agreement and Plan of Merger (the “Merger Agreement”), dated as of January 24, 2016, as amended by Amendment No. 1, dated as of July 1, 2016, by and among JCI Inc., Tyco and certain other parties named therein, including Jagara Merger Sub LLC, an indirect wholly owned subsidiary of Tyco (“Merger Sub”). Pursuant to the terms of the Merger Agreement, on September 2, 2016, Merger Sub merged with and into JCI Inc., with JCI Inc. being the surviving corporation in the merger and a wholly owned, indirect subsidiary of Tyco (the “Merger”). Following the Merger, Tyco changed its name to “Johnson Controls International plc.” The Merger changed the jurisdiction of organization from the United States to Ireland. The domicile to Ireland became effective on September 2, 2016.

[0000833444-17-000060:notes:557]
The merger was accounted for as a reverse acquisition using the acquisition method of accounting in accordance with Accounting Standards Codification ("ASC") 805, "Business Combinations." JCI Inc. was the accounting acquirer for financial reporting purposes. Accordingly, the historical consolidated financial statements of JCI Inc. for periods prior to this transaction are considered to be the historic financial statements of the Company. Refer to Note 2, "Merger Transaction," of the notes to consolidated financial statements for further information.

[0000833444-17-000060:notes:558]
On October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience Business from Johnson Controls to Adient plc and the issuance of ordinary shares of Adient directly to holders of Johnson Controls ordinary shares on a pro rata basis. Prior to the open of business on October 31, 2016, each of the Company's shareholders received one ordinary share of Adient plc for every ten ordinary shares of Johnson Controls held as of the close of business on October 19, 2016, the record date for the distribution. Company shareholders received cash in lieu of fractional shares of Adient, if any. Following the separation and distribution, Adient plc is now an independent public company trading on the New York Stock Exchange ("NYSE") under the symbol "ADNT". The Company did not retain any equity interest in Adient plc. Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-17-000060:notes:559]
Use of Estimates

[0000833444-17-000060:notes:560]
The preparation of consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0000833444-17-000060:notes:561]
Fair Value of Financial Instruments

[0000833444-17-000060:notes:562]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. See Note 10, "Derivative Instruments and Hedging Activities," and Note 11, "Fair Value Measurements," of the notes to consolidated financial statements for fair value of financial instruments, including derivative instruments, hedging activities and long-term debt.

[0000833444-17-000060:notes:563]
Research and Development Costs

[0000833444-17-000060:notes:564]
Expenditures for research activities relating to product development and improvement are charged against income as incurred and included within selling, general and administrative expenses for continuing operations in the consolidated statements of income. Such expenditures for the years ended September 30, 2017, 2016 and 2015 were $360 million, $158 million and $134 million, respectively.

[0000833444-17-000060:notes:565]
Investments

[0000833444-17-000060:notes:566]
The Company invests in debt and equity securities which are classified as available for sale and are marked to market at the end of each accounting period. Unrealized gains and losses on these securities, other than the deferred compensation plan assets, are recognized in AOCI within the consolidated statement of shareholders' equity unless an unrealized loss is deemed to be other than temporary, in which case such loss is charged to earnings. The deferred compensation plan assets are marked to market at the end of each accounting period and all unrealized gains and losses are recorded in the consolidated statements of income.

[0000833444-17-000060:notes:567]
Pension and Postretirement Benefits

[0000833444-17-000060:notes:568]
The Company utilizes a mark-to-market approach for recognizing pension and postretirement benefit expenses, including measuring the market related value of plan assets at fair value and recognizing actuarial gains and losses in the fourth quarter of each fiscal year or at the date of a remeasurement event. Refer to Note 15, "Retirement Plans," of the notes to consolidated financial statements for disclosure of the Company's pension and postretirement benefit plans.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-17-000060:notes:569]
EQUITY AND NONCONTROLLING INTERESTS

[0000833444-17-000060:notes:570]
Share Capital

[0000833444-17-000060:notes:571]
In September 2016, as a result of the Tyco Merger and further discussed within Note 2, "Merger Transaction," of the notes to  consolidated financial statements, each outstanding share of common stock, par value $1.00 per share, of JCI Inc. common stock (other than shares held by JCI Inc., Tyco and certain of their subsidiaries) was converted into the right to receive either a cash consideration or a share consideration.

[0000833444-17-000060:notes:572]
The shares outstanding as of the Merger date were calculated as follows (in millions, except share consolidation ratio and per share data):

[0000833444-17-000060:notes:573]
| Pre-merger Tyco shares outstanding |  | 427.2 |  |
| Share consolidation ratio |  | 0.955 |  |
| Post-share consolidation Tyco shares |  | 408.0 |  |
| Johnson Controls, Inc. shares outstanding |  | 638.3 |  |
| Cash contributed by Tyco used to purchase shares of Johnson Controls, Inc. |  | $ | 3,864 |  |
| Johnson Controls, Inc. per share consideration |  | $ | 34.88 |  |
| Reduction in shares due to cash consideration paid by Tyco |  | (110.8 | ) |
| Adjusted Johnson Controls, Inc. shares outstanding (1:1 exchange ratio) |  | 527.5 |  |
| Shares outstanding at September 2, 2016 |  | 935.5 |  |
| Par value |  | $ | 9 |  |

[0000833444-17-000060:notes:574]
Dividends

[0000833444-17-000060:notes:575]
The authority to declare and pay dividends is vested in the Board of Directors. The timing, declaration and payment of future dividends to holders of the Company's ordinary shares will be determined by the Company's Board of Directors and will depend upon many factors, including the Company's financial condition and results of operations, the capital requirements of the Company's businesses, industry practice and any other relevant factors.

[0000833444-17-000060:notes:576]
Under Irish law, dividends may only be paid (and share repurchases and redemptions must generally be funded) out of "distributable reserves." The creation of distributable reserves was accomplished by way of a capital reduction, which the Irish High Court approved on December 18, 2014 and as acquired in conjunction with the Tyco Merger.

[0000833444-17-000060:notes:577]
Share Repurchase Program

[0000833444-17-000060:notes:578]
Following the Tyco Merger, the Company adopted, subject to the ongoing existence of sufficient distributable reserves, the existing Tyco International plc $1 billion share repurchase program in September 2016. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. During fiscal year 2017, the Company repurchased approximately $651 million of its shares. As of September 30, 2017, approximately $349 million remains available under the share repurchase program. There were no shares repurchased between the closing of the Merger and September 30, 2016. Prior to the Merger, during fiscal year 2016, the Company repurchased approximately $501 million of its shares under JCI Inc.'s $3.65 billion share repurchase program. During fiscal year  2015, the Company repurchased approximately $1.4 billion of its common stock.

[0000833444-17-000060:notes:579]
Other comprehensive income includes activity relating to discontinued operations. The following schedules present changes in consolidated equity attributable to Johnson Controls and noncontrolling interests (in millions, net of tax):

[0000833444-17-000060:notes:580]
The equity attributable to Johnson Controls International plc increased by $15.8 billion as a result of the Tyco Merger in fiscal 2016. The increase is primarily due to an increase to equity of $19.7 billion resulting from the total fair value of consideration transferred, partially offset by a decrease of $3.9 billion resulting from cash contributed by Tyco used to purchase shares of Johnson Controls, Inc.

[0000833444-17-000060:notes:581]
As previously disclosed, on October 31, 2016, the Company completed the Adient spin-off. As a result of the spin-off, the Company divested net assets of approximately $4.0 billion.

[0000833444-17-000060:notes:582]
As previously disclosed, on October 1, 2015, the Company formed a joint venture with Hitachi. In connection with the acquisition, the Company recorded equity attributable to noncontrolling interests of $679 million. Also, in connection with the Tyco Merger, the Company recorded equity attributable to noncontrolling interests of $34 million.

[0000833444-17-000060:notes:583]
The Company consolidates certain subsidiaries in which the noncontrolling interest party has within their control the right to require the Company to redeem all or a portion of its interest in the subsidiary. The redeemable noncontrolling interests are reported at their estimated redemption value. Any adjustment to the redemption value impacts retained earnings but does not impact net income. Redeemable noncontrolling interests which are redeemable only upon future events, the occurrence of which is not currently probable, are recorded at carrying value.

[0000833444-17-000060:notes:584]
The following schedules present changes in the redeemable noncontrolling interests (in millions):

[0000833444-17-000060:notes:585]
|  | Year Ended September 30, 2017 |  | Year Ended September 30, 2016 |  | Year Ended September 30, 2015 |
| Beginning balance, September 30 | $ | 234 |  |  | $ | 212 |  |  | $ | 194 |  |
| Net income | 44 |  |  | 48 |  |  | 51 |  |
| Foreign currency translation adjustments | 13 |  |  | 2 |  |  | (23 | ) |
| Realized and unrealized gains (losses) on derivatives | (1 | ) |  | (1 | ) |  | 1 |  |
| Dividends | (43 | ) |  | (27 | ) |  | (11 | ) |
| Spin-off of Adient | (36 | ) |  | — |  |  | — |  |
| Ending balance, September 30 | $ | 211 |  |  | $ | 234 |  |  | $ | 212 |  |
