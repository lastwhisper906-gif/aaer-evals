# JCI 8-K — 0001104659-10-003413 filed 2010-01-28

## item codes, every 8-K on or before 2010-01-28

- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2010-01-28

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0001104659-10-003413:8k_2_02:1]
EX-99.1
2
a10-2376_1ex99d1.htm
EX-99.1

[0001104659-10-003413:8k_2_02:2]
Exhibit 99.1

[0001104659-10-003413:8k_2_02:3]
FOR
IMMEDIATE RELEASE

[0001104659-10-003413:8k_2_02:4]
| Contacts: |  | News Media |  | Investor Relations |
|  |  | Paul Fitzhenry |  | Ed Arditte |
|  |  | 609-720-4261 |  | 609-720-4621 |
|  |  |  |  | Antonella Franzen |
|  |  |  |  | 609-720-4665 |

[0001104659-10-003413:8k_2_02:5]
TYCO
INTERNATIONAL REPORTS FIRST QUARTER EARNINGS 
  FROM CONTINUING OPERATIONS BEFORE
SPECIAL ITEMS OF $0.65 PER

[0001104659-10-003413:8k_2_02:6]
SHARE AND GAAP EARNINGS OF $0.63 PER SHARE

[0001104659-10-003413:8k_2_02:7]
(Income and EPS amounts are attributable
to Tyco common shareholders)

[0001104659-10-003413:8k_2_02:8]
($ millions, except per-share
amounts)

[0001104659-10-003413:8k_2_02:9]
|  |  | Q1 2010 |  | Q1 2009 |  | % Change |  |
| Revenue |  | $ | 4,246 |  | $ | 4,426 |  | (4 | )% |
| Income from Continuing Operations |  | $ | 302 |  | $ | 272 |  | 11 | % |
| Diluted EPS from Continuing Operations |  | $ | 0.63 |  | $ | 0.57 |  | 11 | % |
| Special Items |  | $ | (0.02 | ) | $ | (0.04 | ) |  |  |
| Income from Continuing Ops Before Special Items |  | $ | 312 |  | $ | 292 |  | 7 | % |
| Diluted EPS from Continuing Ops Before Special Items |  | $ | 0.65 |  | $ | 0.61 |  | 7 | % |

[0001104659-10-003413:8k_2_02:10]
SCHAFFHAUSEN, Switzerland — January 28, 2010 — Tyco International Ltd. (NYSE: TYC)
today reported $0.63 in diluted earnings per share (EPS) from continuing
operations for the fiscal first quarter of 2010 and diluted EPS from continuing
operations before special items of $0.65 per share.  Revenue in the quarter of $4.25 billion
declined 4% versus the prior year with an organic revenue decline of 9.6%.

[0001104659-10-003413:8k_2_02:11]
1

[0001104659-10-003413:8k_2_02:12]
Cash
from operating activities was $379 million and free cash flow was $79
million.  These amounts include $50
million of cash outflows primarily related to restructuring activities.  In the prior year, cash from operating
activities was $56 million and free cash flow was negative $215 million, each
of which included a cash outflow of $25 million primarily related to
restructuring activities.

[0001104659-10-003413:8k_2_02:13]
Tyco Chairman and Chief
Executive Officer Ed Breen said, “Our operating results for the first quarter
reflect moderately higher revenue than expected as well as the benefits of our
actions to reduce our cost structure in this challenging economic
environment.  Despite the soft economy,
we continue to grow our service and recurring revenue which now represent 40%
of total revenue.”

[0001104659-10-003413:8k_2_02:14]
“We were very pleased to
announce our agreement to acquire Broadview Security last week, which we intend
to combine with our ADT security business. 
This acquisition will provide us with an opportunity to strengthen our
position in the fragmented and highly competitive residential and commercial
security industry,” Breen added.

[0001104659-10-003413:8k_2_02:15]
Organic
revenue, free cash flow and operating income, operating margin, income and diluted
EPS from continuing operations before special items are non-GAAP financial
measures and are described below.  For a
reconciliation of these non-GAAP measures, see the attached tables.  Additional schedules as well as First Quarter
Review slides can be found at www.tyco.com on the Investor
Relations portion of Tyco’s website.

[0001104659-10-003413:8k_2_02:16]
SEGMENT
RESULTS

[0001104659-10-003413:8k_2_02:17]
The
financial results presented in the tables below are in accordance with GAAP
unless otherwise indicated.  Beginning this
quarter, certain businesses and overhead costs were realigned, resulting in
changes to historical segment performance. 
The revenue and operating income results shown below have been adjusted
to reflect these changes.  All dollar
amounts are pre-tax and stated in millions. 
All comparisons are to the fiscal first quarter of 2009 unless otherwise
indicated.

[0001104659-10-003413:8k_2_02:18]
2

[0001104659-10-003413:8k_2_02:19]
ADT Worldwide

[0001104659-10-003413:8k_2_02:20]
|  |  | Q1 2010 |  | Q1 2009 |  | % Change |  |
| Revenue |  | $ | 1,835 |  | $ | 1,811 |  | 1 | % |
| Operating Income |  | $ | 259 |  | $ | 227 |  | 14 | % |
| Operating Margin |  | 14.1 | % | 12.5 | % |  |  |
| Special Items |  | $ | (5 | ) | $ | (1 | ) |  |  |
| Operating Income Before Special Items |  | $ | 264 |  | $ | 228 |  | 16 | % |
| Operating Margin Before Special Items |  | 14.4 | % | 12.6 | % |  |  |

[0001104659-10-003413:8k_2_02:21]
Revenue
of $1.8 billion increased 1% in the quarter with an organic revenue decline of
3%.  Recurring revenue grew 5%
organically on a global basis.  Systems
installation and service revenue declined 13% organically, mostly due to
weakness in North America and Europe, as a result of lower sales to commercial
customers.

[0001104659-10-003413:8k_2_02:22]
Operating
income was $259 million and the operating margin was 14.1%. Operating income
before special items was $264 million and the operating margin before special
items improved 180 basis points to 14.4%. The benefits from restructuring
activities and cost-containment actions and growth in higher-margin recurring
revenue more than offset the impact of the organic revenue decline in systems
installation and service.

[0001104659-10-003413:8k_2_02:23]
Flow
Control

[0001104659-10-003413:8k_2_02:24]
|  |  | Q1 2010 |  | Q1 2009 |  | % Change |  |
| Revenue |  | $ | 923 |  | $ | 959 |  | (4 | )% |
| Operating Income |  | $ | 112 |  | $ | 137 |  | (18 | )% |
| Operating Margin |  | 12.1 | % | 14.3 | % |  |  |
| Special Items |  | $ | (6 | ) | $ | (2 | ) |  |  |
| Operating Income Before Special Items |  | $ | 118 |  | $ | 139 |  | (15 | )% |
| Operating Margin Before Special Items |  | 12.8 | % | 14.5 | % |  |  |

[0001104659-10-003413:8k_2_02:25]
Revenue
of $923 million declined 4% in the quarter with an organic revenue decline of
14%.  Organic revenue declined 15% in the
Valves business, 10% in Water and 14% in Thermal Controls.  Backlog of $1.7 billion decreased 3% on a
quarter sequential basis (a 2% decline excluding the impact of foreign
currency).

[0001104659-10-003413:8k_2_02:26]
Operating
income was $112 million and the operating margin was 12.1%.  Operating income before special items was
$118 million and the operating margin before special items was 12.8%

[0001104659-10-003413:8k_2_02:27]
3

[0001104659-10-003413:8k_2_02:28]
as
the benefits from cost-containment actions and restructuring activities were more
than offset by the impact of the organic revenue decline and product mix.

[0001104659-10-003413:8k_2_02:29]
Fire
Protection Services

[0001104659-10-003413:8k_2_02:30]
|  |  | Q1 2010 |  | Q1 2009 |  | % Change |  |
| Revenue |  | $ | 833 |  | $ | 839 |  | (1 | )% |
| Operating Income |  | $ | 64 |  | $ | 56 |  | 14 | % |
| Operating Margin |  | 7.7 | % | 6.7 | % |  |  |
| Special Items |  | — |  | — |  |  |  |
| Operating Income Before Special Items |  | $ | 64 |  | $ | 56 |  | 14 | % |
| Operating Margin Before Special Items |  | 7.7 | % | 6.7 | % |  |  |

[0001104659-10-003413:8k_2_02:31]
Revenue of $833 million declined 1% in the
quarter with an organic revenue decline of 6%. 
Service revenue declined 2% organically and installation revenue declined
10% driven primarily by softness in the North American and EMEA regions.  Backlog of $1.2 billion decreased 1% on a
quarter sequential basis.

[0001104659-10-003413:8k_2_02:32]
Operating income was $64 million and the
operating margin was 7.7%.  There were no
special items in the quarter.

[0001104659-10-003413:8k_2_02:33]
Electrical
and Metal Products

[0001104659-10-003413:8k_2_02:34]
|  |  | Q1 2010 |  | Q1 2009 |  | % Change |  |
| Revenue |  | $ | 297 |  | $ | 416 |  | (29 | )% |
| Operating Income |  | $ | 23 |  | $ | 27 |  | (15 | )% |
| Operating Margin |  | 7.7 | % | 6.5 | % |  |  |
| Special Items |  | — |  | $ | (2 | ) |  |  |
| Operating Income Before Special Items |  | $ | 23 |  | $ | 29 |  | (21 | )% |
| Operating Margin Before Special Items |  | 7.7 | % | 7.0 | % |  |  |

[0001104659-10-003413:8k_2_02:35]
Revenue of $297 million
declined 29% in the quarter with an organic revenue decline of 30%.   The decline was primarily due to lower
selling prices for both steel and copper products.

[0001104659-10-003413:8k_2_02:36]
Operating income was $23
million and the operating margin was 7.7%. 
Operating income before special items decreased $6 million, despite a $119
million revenue decline as lower volume was almost fully offset by better steel
spreads.  The operating margin before
special items was 7.7%.

[0001104659-10-003413:8k_2_02:37]
4

[0001104659-10-003413:8k_2_02:38]
Safety Products

[0001104659-10-003413:8k_2_02:39]
|  |  | Q1 2010 |  | Q1 2009 |  | % Change |  |
| Revenue |  | $ | 358 |  | $ | 401 |  | (11 | )% |
| Operating Income |  | $ | 54 |  | $ | 80 |  | (33 | )% |
| Operating Margin |  | 15.1 | % | 20.0 | % |  |  |
| Special Items |  | $ | 1 |  | $ | (1 | ) |  |  |
| Operating Income Before Special Items |  | $ | 53 |  | $ | 81 |  | (35 | )% |
| Operating Margin Before Special Items |  | 14.8 | % | 20.2 | % |  |  |

[0001104659-10-003413:8k_2_02:40]
Revenue
of $358 million declined 11% in the quarter. 
Organic revenue declined 14% due to lower volume in the Fire Suppression
and Electronic Security businesses resulting from weaker demand in their end
markets.

[0001104659-10-003413:8k_2_02:41]
Operating
income was $54 million and the operating margin was 15.1%. Operating income
before special items was $53 million and the operating margin before special
items was 14.8%.  The benefits from cost-containment
actions and restructuring activities were more than offset by the impact of the
organic revenue decline and product mix.

[0001104659-10-003413:8k_2_02:42]
OTHER
ITEMS

[0001104659-10-003413:8k_2_02:43]
·      On January 18, 2010, Tyco announced a
definitive agreement to acquire Brinks Home Security Holdings, Inc., now
operating as Broadview Security, in a transaction valued at approximately $2.0
billion.  The transaction is expected to
close in the second half of Tyco’s 2010 fiscal year.

[0001104659-10-003413:8k_2_02:44]
·      On January 15, 2010, the company announced that
its Board of Directors recommended shareholder approval of an annual Swiss Franc
dividend equal to $0.84 per share at the company’s annual general meeting of
shareholders to be held on March 10, 2010. 
The proposed dividend represents a five percent increase over the $0.80 per
share approved by shareholders in 2009.

[0001104659-10-003413:8k_2_02:45]
·      On December 14, 2009, Tyco’s Flow Control
business acquired two Brazilian valve companies in a move to expand its product
and service offerings in Brazil and South America.

[0001104659-10-003413:8k_2_02:46]
·      Corporate expense was $98 million in the quarter and
included special items of $2 million.

[0001104659-10-003413:8k_2_02:47]
·      The company incurred pre-tax charges of $11 million
in the quarter related to restructuring activities.

[0001104659-10-003413:8k_2_02:48]
5

[0001104659-10-003413:8k_2_02:49]
·      Other income in the quarter of $9 million resulted
from the increase in receivables from Covidien and Tyco Electronics related to tax
liabilities for periods prior to Tyco’s separation into three companies in
2007.

[0001104659-10-003413:8k_2_02:50]
·      The tax rate for the quarter was 14.9%.

[0001104659-10-003413:8k_2_02:51]
ABOUT TYCO INTERNATIONAL

[0001104659-10-003413:8k_2_02:52]
Tyco International Ltd. (NYSE:
TYC) is a diversified company that provides vital products and services to
customers around the world.  Tyco is a
leading provider of security products and services, fire protection and
detection products and services, valves and controls, and other industrial
products.  Tyco had 2009 revenue of more
than $17 billion and has more than 100,000 employees worldwide.  More information on Tyco can be found at www.tyco.com.

[0001104659-10-003413:8k_2_02:53]
CONFERENCE CALL AND WEBCAST

[0001104659-10-003413:8k_2_02:54]
Management will discuss the company’s first
quarter results for 2010 and outlook for the second quarter and full year during
a conference call and webcast today beginning at 8:30 a.m. EST.  Today’s conference call for investors can be
accessed in the following ways:

[0001104659-10-003413:8k_2_02:55]
·      At Tyco’s website: http://investors.tyco.com.

[0001104659-10-003413:8k_2_02:56]
·      By telephone: For both “listen-only” participants
and those participants who wish to take part in the question-and-answer portion
of the call, the telephone dial-in number in the United States is (888) 455-5685.  The telephone dial-in number for participants
outside the United States is (773) 799-3896. 
The participant code is TYCO.

[0001104659-10-003413:8k_2_02:57]
·      An audio replay of the conference call will be
available beginning at 11:00 a.m. on January 28, 2010 and ending on February 4,
2010. The dial-in number for participants in the United States is (866) 395-9155.
For participants outside the United States, the replay dial-in number is (203) 369-0497.

[0001104659-10-003413:8k_2_02:58]
NON-GAAP
MEASURES

[0001104659-10-003413:8k_2_02:59]
“Organic revenue,” “free cash flow (outflow)” (FCF), “income
from continuing operations before special items”, “earnings per share (EPS)
from continuing operations before special items”, “operating income before
special items” and “operating margin before special items” are non-GAAP
measures and should not be considered replacements for GAAP results.

[0001104659-10-003413:8k_2_02:60]
Organic revenue is a useful measure used by the company to
measure the underlying results and trends in the business. The difference
between reported net revenue (the most comparable

[0001104659-10-003413:8k_2_02:61]
6

[0001104659-10-003413:8k_2_02:62]
GAAP measure) and organic revenue (the non-GAAP measure)
consists of the impact from foreign currency, acquisitions and divestitures,
and other changes that do not reflect the underlying results and trends (for
example, revenue reclassifications and changes to the fiscal year). Organic
revenue is a useful measure of the company’s performance because it excludes
items that: i) are not completely under management’s control, such as the
impact of foreign currency exchange; or ii) do not reflect the underlying
results of the company’s existing businesses, such as acquisitions and
divestitures. It may be used as a component of the company’s compensation
programs. The limitation of this measure is that it excludes items that have an
impact on the company’s revenue. This limitation is best addressed by using
organic revenue in combination with the GAAP numbers. See the accompanying
tables to this press release for the reconciliation presenting the components
of organic revenue.

[0001104659-10-003413:8k_2_02:63]
FCF is a useful measure of the company’s cash which is free
from any significant existing obligation. The difference between Cash Flows
from Operating Activities (the most comparable GAAP measure) and FCF (the
non-GAAP measure) consists mainly of significant cash flows that the company
believes are useful to identify. FCF permits management and investors to gain
insight into the number that management employs to measure cash that is free
from any significant existing obligation. It, or a measure that is based on it,
may be used as a component in the company’s incentive compensation plans. The
difference reflects the impact from:

[0001104659-10-003413:8k_2_02:64]
·
net capital expenditures,

[0001104659-10-003413:8k_2_02:65]
·
accounts purchased by ADT,

[0001104659-10-003413:8k_2_02:66]
·
cash paid for purchase accounting and holdback liabilities,

[0001104659-10-003413:8k_2_02:67]
·
voluntary pension contributions, and

[0001104659-10-003413:8k_2_02:68]
· the
sale of accounts receivable programs.

[0001104659-10-003413:8k_2_02:69]
Capital expenditures and accounts purchased by ADT are
subtracted because they represent long-term commitments. Cash paid for purchase
accounting and holdback liabilities is subtracted because these cash outflows
are not available for general corporate uses. Voluntary pension contributions
and the impact from the sale of accounts receivable programs are added or
subtracted because this activity is driven by economic financing decisions
rather than operating activity.

[0001104659-10-003413:8k_2_02:70]
The limitation associated with using FCF is that it adjusts
for cash items that are ultimately within management’s and the Board of
Directors’ discretion to direct and therefore may imply that there is less or
more cash that is available for the company’s programs than the most comparable
GAAP measure. This limitation is best addressed by using FCF in combination
with the GAAP cash flow numbers.

[0001104659-10-003413:8k_2_02:71]
FCF as presented herein may not be comparable to similarly
titled measures reported by other companies. The measure should be used in
conjunction with other GAAP financial measures. Investors are urged to read the
company’s financial statements as filed with the Securities and Exchange
Commission, as well as the accompanying tables to this press release that show
all the elements of the GAAP measures of Cash Flows from Operating Activities,
Cash Flows from Investing Activities, Cash Flows from Financing Activities and
a reconciliation of the company’s total cash and cash equivalents for the
period. See the accompanying tables to this press release for a cash flow
statement presented in accordance with GAAP and a reconciliation presenting the
components of FCF.

[0001104659-10-003413:8k_2_02:72]
The company has presented its income and EPS from continuing
operations before special items and operating income and margin before special
items. Special Items include charges and

[0001104659-10-003413:8k_2_02:73]
7

[0001104659-10-003413:8k_2_02:74]
gains related to divestitures, acquisitions, restructurings,
impairments, legacy legal and tax charges and other income or charges that may
mask the underlying operating results and/or business trends of the company or
business segment, as applicable. The company utilizes income and EPS from
continuing operations before special items and operating income and margin
before special items to assess overall operating performance and segment level
core operating performance, as well as to provide insight to management in
evaluating overall and segment operating plan execution and underlying market
conditions. They may be used as components in the company’s incentive
compensation plans. Operating income, operating margin, and income and EPS from
continuing operations before special items are useful measures for investors
because they permit more meaningful comparisons of the company’s underlying
operating results and business trends between periods. The difference between
income and EPS from continuing operations before special items and income and
EPS from continuing operations (the most comparable GAAP measures) consists of
the impact of charges and gains related to divestitures, acquisitions,
restructurings, impairments, legacy legal and tax charges and other income or
charges that may mask the underlying operating results and/or business trends.
Operating income and margin before special items do not reflect any additional
adjustments that are not reflected in income from continuing operations before
special items.  The limitation of these measures is that they exclude the
impact (which may be material) of items that increase or decrease the company’s
reported operating income and margin and operating income and EPS from
continuing operations. This limitation is best addressed by using the non-GAAP
measures in combination with the most comparable GAAP measures in order to
better understand the amounts, character and impact of any increase or decrease
on reported results. Tyco provides general corporate services to its segments
and those costs are reported in the “Corporate and Other” segment. This segment’s
operating income (loss) is presented as “Corporate Expense.”

[0001104659-10-003413:8k_2_02:75]
FORWARD-LOOKING STATEMENTS

[0001104659-10-003413:8k_2_02:76]
#  #  #

[0001104659-10-003413:8k_2_02:77]
8

[0001104659-10-003413:8k_2_02:78]
TYCO INTERNATIONAL LTD.

[0001104659-10-003413:8k_2_02:79]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001104659-10-003413:8k_2_02:80]
(in millions, except per share data)

[0001104659-10-003413:8k_2_02:81]
(Unaudited)

[0001104659-10-003413:8k_2_02:82]
|  |  | Quarters Ended |  |
|  |  | December 25, |  | December 26, |  |
|  |  | 2009 |  | 2008 |  |
| Net revenue |  | $ | 4,246 |  | $ | 4,426 |  |
| Cost of sales |  | 2,681 |  | 2,869 |  |
| Selling, general and administrative expenses |  | 1,140 |  | 1,140 |  |
| Restructuring, net |  | 10 |  | 1 |  |
| Losses on divestitures, net |  | 1 |  | 3 |  |
| Operating income |  | 414 |  | 413 |  |
| Interest income |  | 9 |  | 12 |  |
| Interest expense |  | (76 | ) | (73 | ) |
| Other income, net |  | 9 |  | 4 |  |
| Income from continuing operations before income taxes |  | 356 |  | 356 |  |
| Income taxes |  | (53 | ) | (84 | ) |
| Income from continuing operations |  | 303 |  | 272 |  |
| Income from discontinued operations, net of income taxes |  | — |  | 5 |  |
| Net income |  | 303 |  | 277 |  |
| Less: noncontrolling interest in subsidiaries net income |  | 1 |  | — |  |
| Net income attributable to Tyco common shareholders |  | $ | 302 |  | $ | 277 |  |
| Amounts attributable to Tyco common shareholders |  |  |  |  |  |
| Income from continuing operations |  | $ | 302 |  | $ | 272 |  |
| Income from discontinued operations |  | — |  | 5 |  |
| Net income attributable to Tyco common shareholders |  | $ | 302 |  | $ | 277 |  |
| Basic earnings per share attributable to Tyco common shareholders: |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.64 |  | $ | 0.57 |  |
| Income from discontinued operations |  | — |  | 0.02 |  |
| Net income attributable to Tyco common shareholders |  | $ | 0.64 |  | $ | 0.59 |  |
| Diluted earnings per share attributable to Tyco common shareholders: |  |  |  |  |  |
| Income from continuing operations |  | $ | 0.63 |  | $ | 0.57 |  |
| Income from discontinued operations |  | — |  | 0.01 |  |
| Net income attributable to Tyco common shareholders |  | $ | 0.63 |  | $ | 0.58 |  |
| Weighted-average number of shares outstanding: |  |  |  |  |  |
| Basic |  | 476 |  | 473 |  |
| Diluted |  | 479 |  | 475 |  |

[0001104659-10-003413:8k_2_02:83]
NOTE:    These financial statements should be read in
conjunction with the Consolidated Financial Statements and accompanying notes
contained in the Company’s Annual Report on Form 10-K for the fiscal year
ended September 25, 2009.

[0001104659-10-003413:8k_2_02:84]
TYCO
INTERNATIONAL LTD.

[0001104659-10-003413:8k_2_02:85]
RESULTS OF
SEGMENTS

[0001104659-10-003413:8k_2_02:86]
(in
millions)

[0001104659-10-003413:8k_2_02:87]
(Unaudited)

[0001104659-10-003413:8k_2_02:88]
|  |  | Quarters Ended |  |  |  |
|  |  | December 25, |  |  |  | December 26, |  |  |  |
|  |  | 2009 |  |  |  | 2008 |  |  |  |
| NET REVENUE |  |  |  |  |  |  |  |  |  |
| ADT Worldwide |  | $ | 1,835 |  |  |  | $ | 1,811 |  |  |  |
| Flow Control |  | 923 |  |  |  | 959 |  |  |  |
| Fire Protection Services |  | 833 |  |  |  | 839 |  |  |  |
| Electrical and Metal Products |  | 297 |  |  |  | 416 |  |  |  |
| Safety Products |  | 358 |  |  |  | 401 |  |  |  |
| Corporate and Other |  | — |  |  |  | — |  |  |  |
| Total Net Revenue |  | $ | 4,246 |  |  |  | $ | 4,426 |  |  |  |
| OPERATING INCOME (LOSS) AND MARGIN |  |  |  |  |  |  |  |  |  |
| ADT Worldwide |  | $ | 259 |  | 14.1 | % | $ | 227 |  | 12.5 | % |
| Flow Control |  | 112 |  | 12.1 | % | 137 |  | 14.3 | % |
| Fire Protection Services |  | 64 |  | 7.7 | % | 56 |  | 6.7 | % |
| Electrical and Metal Products |  | 23 |  | 7.7 | % | 27 |  | 6.5 | % |
| Safety Products |  | 54 |  | 15.1 | % | 80 |  | 20.0 | % |
| Corporate and Other |  | (98 | ) | N/M |  | (114 | ) | N/M |  |
| Operating Income and Margin |  | $ | 414 |  | 9.8 | % | $ | 413 |  | 9.3 | % |

[0001104659-10-003413:8k_2_02:89]
TYCO INTERNATIONAL LTD.

[0001104659-10-003413:8k_2_02:90]
CONSOLIDATED BALANCE SHEETS

[0001104659-10-003413:8k_2_02:91]
(in millions)

[0001104659-10-003413:8k_2_02:92]
(Unaudited)

[0001104659-10-003413:8k_2_02:93]
|  |  | December 25, |  | September 25, |  |
|  |  | 2009 |  | 2009 |  |
| Current Assets: |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,473 |  | $ | 2,354 |  |
| Accounts receivable, net |  | 2,499 |  | 2,629 |  |
| Inventories |  | 1,484 |  | 1,443 |  |
| Other current assets |  | 1,364 |  | 1,385 |  |
| Assets held for sale |  | 153 |  | 156 |  |
| Total current assets |  | 7,973 |  | 7,967 |  |
| Property, plant and equipment, net |  | 3,506 |  | 3,497 |  |
| Goodwill |  | 8,786 |  | 8,791 |  |
| Intangible assets, net |  | 2,711 |  | 2,647 |  |
| Other assets |  | 2,625 |  | 2,651 |  |
| Total Assets |  | $ | 25,601 |  | $ | 25,553 |  |
| Current Liabilities: |  |  |  |  |  |
| Short-term debt and current maturities of long-term debt |  | $ | 17 |  | $ | 245 |  |
| Accounts payable |  | 1,159 |  | 1,244 |  |
| Accrued and other current liabilities |  | 2,171 |  | 2,476 |  |
| Deferred revenue |  | 546 |  | 590 |  |
| Liabilities held for sale |  | 154 |  | 161 |  |
| Total current liabilities |  | 4,047 |  | 4,716 |  |
| Long-term debt |  | 4,506 |  | 4,029 |  |
| Other liabilities |  | 3,846 |  | 3,854 |  |
| Total Liabilities |  | 12,399 |  | 12,599 |  |
| Tyco’s shareholders’ equity |  | 13,188 |  | 12,941 |  |
| Noncontrolling interest |  | 14 |  | 13 |  |
| Total Equity |  | 13,202 |  | 12,954 |  |
| Total Liabilities and Equity |  | $ | 25,601 |  | $ | 25,553 |  |

[0001104659-10-003413:8k_2_02:94]
NOTE: These financial statements should be read
in conjunction with the Consolidated Financial Statements and accompanying
notes contained in the Company’s Annual Report on Form 10-K for the fiscal
year ended September 25, 2009.

[0001104659-10-003413:8k_2_02:95]
TYCO
INTERNATIONAL LTD.

[0001104659-10-003413:8k_2_02:96]
CONSOLIDATED
STATEMENTS OF CASH FLOWS

[0001104659-10-003413:8k_2_02:97]
(in
millions)

[0001104659-10-003413:8k_2_02:98]
(Unaudited)

[0001104659-10-003413:8k_2_02:99]
|  |  | Quarters Ended |  |
|  |  | December 25, |  | December 26, |  |
|  |  | 2009 |  | 2008 |  |
| Cash Flows from Operating Activities: |  |  |  |  |  |
| Net income attributable to Tyco common shareholders |  | $ | 302 |  | $ | 277 |  |
| Noncontrolling interests in subsidiaries net income |  | 1 |  | — |  |
| Income from discontinued operations, net of income taxes |  | — |  | (5 | ) |
| Income from continuing operations |  | 303 |  | 272 |  |
| Adjustments to reconcile net cash provided by operating activities: |  |  |  |  |  |
| Depreciation and amortization |  | 287 |  | 275 |  |
| Non-cash compensation expense |  | 31 |  | 29 |  |
| Deferred income taxes |  | 4 |  | (17 | ) |
| Provision for losses on accounts receivable and inventory |  | 34 |  | 34 |  |
| Other non-cash items |  | 3 |  | 18 |  |
| Changes in assets and liabilities, net of the effects of acquisitions and divestitures: |  |  |  |  |  |
| Accounts receivable, net |  | 91 |  | 13 |  |
| Inventories |  | (44 | ) | (151 | ) |
| Other current assets |  | 2 |  | 14 |  |
| Accounts payable |  | (71 | ) | (175 | ) |
| Accrued expenses and other liabilities |  | (216 | ) | (300 | ) |
| Income taxes, net |  | 1 |  | 30 |  |
| Other |  | (46 | ) | 14 |  |
| Net cash provided by operating activities |  | 379 |  | 56 |  |
| Cash Flows from Investing Activities: |  |  |  |  |  |
| Capital expenditures |  | (165 | ) | (159 | ) |
| Proceeds from disposal of assets |  | 16 |  | 2 |  |
| Acquisition of businesses, net of cash acquired |  | (143 | ) | (45 | ) |
| Accounts purchased by ADT |  | (150 | ) | (117 | ) |
| Other |  | 25 |  | 18 |  |
| Net cash used in investing activities |  | (417 | ) | (301 | ) |
| Net cash provided by discontinued investing activities |  | — |  | 3 |  |
| Cash Flows from Financing Activities: |  |  |  |  |  |
| Net proceeds from issuance of debt |  | 248 |  | 106 |  |
| Proceeds from exercise of share options |  | 6 |  | — |  |
| Dividends paid |  | (107 | ) | (95 | ) |
| Repurchase of common shares by subsidiary |  | — |  | (3 | ) |
| Transfers from discontinued operations |  | — |  | 3 |  |
| Other |  | 12 |  | 2 |  |
| Net cash provided by financing activities |  | 159 |  | 13 |  |
| Net cash used in discontinued financing activities |  | — |  | (3 | ) |
| Effect of currency translation on cash |  | (2 | ) | (94 | ) |
| Net increase (decrease) in cash and cash equivalents |  | 119 |  | (326 | ) |
| Cash and cash equivalents at beginning of period |  | 2,354 |  | 1,519 |  |
| Cash and cash equivalents at end of period |  | $ | 2,473 |  | $ | 1,193 |  |
| Reconciliation to “Free Cash Flow”: |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 379 |  | $ | 56 |  |
| Sale of accounts receivable |  | (1 | ) | 3 |  |
| Capital expenditures, net |  | (149 | ) | (157 | ) |
| Accounts purchased by ADT |  | (150 | ) | (117 | ) |
| Free Cash Flow |  | $ | 79 |  | $ | (215 | ) |

[0001104659-10-003413:8k_2_02:100]
NOTE: Free cash flow is a non-GAAP measure.  See description of non-GAAP measures
contained in this release.

[0001104659-10-003413:8k_2_02:101]
TYCO
INTERNATIONAL LTD.

[0001104659-10-003413:8k_2_02:102]
ORGANIC
REVENUE RECONCILIATION

[0001104659-10-003413:8k_2_02:103]
(in
millions)

[0001104659-10-003413:8k_2_02:104]
(Unaudited)

[0001104659-10-003413:8k_2_02:105]
|  |  | Quarter Ended December 25, 2009 |  | Net Revenue for the |  |
|  |  | Net Revenue |  | Foreign Currency |  | Acquisition / (Divestiture) |  | Organic Revenue |  | Quarter Ended December 26, 2008 |  |
| ADT Worldwide |  | $ | 1,835 |  | 1.3 | % | $ | 89 |  | 4.9 | % | $ | (5 | ) | -0.3 | % | $ | (60 | ) | -3.3 | % | $ | 1,811 |  |
| Flow Control |  | 923 |  | -3.8 | % | 96 |  | 10.0 | % | (2 | ) | -0.2 | % | (130 | ) | -13.6 | % | 959 |  |
| Fire Protection Services |  | 833 |  | -0.7 | % | 49 |  | 5.8 | % | (2 | ) | -0.2 | % | (53 | ) | -6.3 | % | 839 |  |
| Electrical and Metal Products |  | 297 |  | -28.6 | % | 12 |  | 2.9 | % | (6 | ) | -1.5 | % | (125 | ) | -30.0 | % | 416 |  |
| Safety Products |  | 358 |  | -10.7 | % | 18 |  | 4.5 | % | (6 | ) | -1.5 | % | (55 | ) | -13.7 | % | 401 |  |
| Total Net Revenue |  | $ | 4,246 |  | -4.1 | % | $ | 264 |  | 6.0 | % | $ | (21 | ) | -0.5 | % | $ | (423 | ) | -9.6 | % | $ | 4,426 |  |

[0001104659-10-003413:8k_2_02:106]
NOTE:  Organic revenue is a
non-GAAP measure.  See description of
non-GAAP measures contained in this release.

[0001104659-10-003413:8k_2_02:107]
Tyco
International Ltd.

[0001104659-10-003413:8k_2_02:108]
Earnings Per Share Summary

[0001104659-10-003413:8k_2_02:109]
(Unaudited)

[0001104659-10-003413:8k_2_02:110]
|  |  | Quarter Ended |  | Quarter Ended |  |
|  |  | Dec. 25, 2009 |  | Dec. 26, 2008 |  |
| Diluted EPS from Continuing Operations Attributable to Tyco Shareholders (GAAP) |  | $ | 0.63 |  | $ | 0.57 |  |
| Restructuring, net |  | 0.02 |  | — |  |
| Restructuring charges in cost of sales and SG&A |  | — |  | 0.01 |  |
| Other additional charges resulting from restructuring actions |  | — |  | — |  |
| Losses on divestitures, net |  | — |  | — |  |
| Intangible impairments |  | — |  | — |  |
| Goodwill impairments |  | — |  | — |  |
| Tax items |  | — |  | 0.01 |  |
| Legacy legal items |  | — |  | 0.02 |  |
| Total Before Special Items |  | $ | 0.65 |  | $ | 0.61 |  |

[0001104659-10-003413:8k_2_02:111]
Tyco
International Ltd.

[0001104659-10-003413:8k_2_02:112]
For the Quarter Ended December 25, 2009

[0001104659-10-003413:8k_2_02:113]
(in
millions, except per share data)

[0001104659-10-003413:8k_2_02:114]
(Unaudited)

[0001104659-10-003413:8k_2_02:115]
|  |  | ADT |  | Flow |  | Fire Protection |  | Electrical & |  | Safety |  | Corporate |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Worldwide |  | Control |  | Services |  | Metal Products |  | Products |  | and Other |  | Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  | $ | 1,835 |  | $ | 923 |  | $ | 833 |  | $ | 297 |  | $ | 358 |  | — |  | $ | 4,246 |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Income |  | Diluted |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | from |  | EPS from |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Continuing |  | Continuing |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  | Operations |  | Operations |  |
|  |  |  |  |  |  | Fire |  | Electrical |  |  |  |  |  | Total |  |  |  |  |  |  |  |  |  | Attributable |  | Attributable |  |
|  |  | ADT |  | Flow |  | Protection |  | & Metal |  | Safety |  | Corporate |  | Operating |  | Interest |  | Other |  | Income |  | Noncontrolling |  | to Tyco |  | to Tyco |  |
|  |  | Worldwide |  | Control |  | Services |  | Products |  | Products |  | and Other |  | Income |  | Expense, net |  | Income, net |  | Taxes |  | Interest |  | Shareholders |  | Shareholders |  |
| As Reported (GAAP) |  | $ | 259 |  | $ | 112 |  | $ | 64 |  | $ | 23 |  | $ | 54 |  | $ | (98 | ) | $ | 414 |  | $ | (67 | ) | $ | 9 |  | $ | (53 | ) | $ | (1 | ) | $ | 302 |  | $ | 0.63 |  |
| Restructuring, net |  | 5 |  | 6 |  | 2 |  |  |  | (3 | ) |  |  | 10 |  |  |  |  |  | (3 | ) |  |  | 7 |  | 0.02 |  |
| Restructuring charges in cost of sales and SG&A |  |  |  |  |  | 1 |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  | 1 |  |  |  |
| Losses on divestitures, net |  |  |  |  |  | (3 | ) |  |  | 2 |  | 2 |  | 1 |  |  |  |  |  | 1 |  |  |  | 2 |  |  |  |
| Total Before Special Items |  | $ | 264 |  | $ | 118 |  | $ | 64 |  | $ | 23 |  | $ | 53 |  | $ | (96 | ) | $ | 426 |  | $ | (67 | ) | $ | 9 |  | $ | (55 | ) | $ | (1 | ) | $ | 312 |  | $ | 0.65 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  | 479 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items |  | 479 |  |

[0001104659-10-003413:8k_2_02:116]
Tyco International Ltd.

[0001104659-10-003413:8k_2_02:117]
For the Quarter Ended December 26,
2008

[0001104659-10-003413:8k_2_02:118]
(in millions, except per share data)

[0001104659-10-003413:8k_2_02:119]
(Unaudited)

[0001104659-10-003413:8k_2_02:120]
|  |  | ADT |  | Flow |  | Fire Protection |  | Electrical & |  | Safety |  | Corporate |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Worldwide |  | Control |  | Services |  | Metal Products |  | Products |  | and Other |  | Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Previously Reported Revenue (GAAP) |  | $ | 1,792 |  | $ | 959 |  | $ | 851 |  | $ | 416 |  | $ | 408 |  | — |  | $ | 4,426 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Segment Realignment |  | 19 |  |  |  | (12 | ) |  |  | (7 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Recasted Revenue (GAAP) |  | $ | 1,811 |  | $ | 959 |  | $ | 839 |  | $ | 416 |  | $ | 401 |  | — |  | $ | 4,426 |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Income |  | Diluted |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | from |  | EPS from |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Continuing |  | Continuing |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  | Operations |  | Operations |  |
|  |  |  |  |  |  | Fire |  | Electrical |  |  |  |  |  | Total |  |  |  |  |  |  |  |  |  | Attributable |  | Attributable |  |
|  |  | ADT |  | Flow |  | Protection |  | & Metal |  | Safety |  | Corporate |  | Operating |  | Interest |  | Other |  | Income |  | Noncontrolling |  | to Tyco |  | to Tyco |  |
|  |  | Worldwide |  | Control |  | Services |  | Products |  | Products |  | and Other |  | Income |  | Expense, net |  | Income, net |  | Taxes |  | Interest |  | Shareholders |  | Shareholders |  |
| As Previously Reported (GAAP) |  | $ | 231 |  | $ | 137 |  | $ | 58 |  | $ | 27 |  | $ | 74 |  | $ | (114 | ) | $ | 413 |  | $ | (61 | ) | $ | 4 |  | $ | (84 | ) |  |  | $ | 272 |  | $ | 0.57 |  |
| Segment Realignment |  | (4 | ) |  |  | (2 | ) |  |  | 6 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| As Reported (GAAP) |  | $ | 227 |  | $ | 137 |  | $ | 56 |  | $ | 27 |  | $ | 80 |  | $ | (114 | ) | $ | 413 |  | $ | (61 | ) | $ | 4 |  | $ | (84 | ) |  |  | $ | 272 |  | $ | 0.57 |  |
| Restructuring, net |  | (1 | ) |  |  |  |  | 1 |  | 1 |  |  |  | 1 |  |  |  |  |  |  |  |  |  | 1 |  |  |  |
| Restructuring charges in cost of sales and SG&A |  | 2 |  | 1 |  |  |  | 1 |  |  |  |  |  | 4 |  |  |  |  |  | (1 | ) |  |  | 3 |  | 0.01 |  |
| Losses on divestitures, net |  |  |  | 1 |  |  |  |  |  |  |  | 2 |  | 3 |  |  |  |  |  | (1 | ) |  |  | 2 |  |  |  |
| Tax items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 6 |  |  |  | 6 |  | 0.01 |  |
| Legacy legal items |  |  |  |  |  |  |  |  |  |  |  | 8 |  | 8 |  |  |  |  |  |  |  |  |  | 8 |  | 0.02 |  |
| Total Before Special Items |  | $ | 228 |  | $ | 139 |  | $ | 56 |  | $ | 29 |  | $ | 81 |  | $ | (104 | ) | $ | 429 |  | $ | (61 | ) | $ | 4 |  | $ | (80 | ) |  |  | $ | 292 |  | $ | 0.61 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  | 475 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items |  | 475 |  |
