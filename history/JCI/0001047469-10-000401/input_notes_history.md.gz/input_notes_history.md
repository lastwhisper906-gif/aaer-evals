# JCI note change history — 0001047469-09-007036 → 0001047469-10-000401


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2010-01-28):
[0001047469-10-000401:note_history:1]
| 10. Commitments and Contingencies In connection with the Separation, the Company entered into a liability sharing agreement regarding certain legal actions that were pending against Tyco prior to the Separation. Under the Separation and Distribution Agreement, the Company, Covidien and Tyco Electronics are jointly and severally liable for the full amount of any judgments resulting from the actions subject to the agreement, which generally relate to legacy matters that are not specific to the business operations of any of the companies. The Separation and Distribution Agreement also provides that the Company will be responsible for 27%, Covidien 42% and Tyco Electronics 31% of payments to resolve these matters, with costs and expenses associated with the management of these contingencies being shared equally among the parties. In addition, under the agreement, the Company will manage and control all the legal matters related to assumed contingent liabilities as described in the Separation and Distribution Agreement, including the defense or settlement thereof, subject to certain limitations. Additionally, at the time of the Separation, the Company, Covidien and Tyco Electronics agreed to allocate responsibility for certain legacy tax claims pursuant to the same formula under the Tax Sharing Agreement. See Note 5. Legacy Securities Matters As previously reported, Tyco and some members of the Company's former senior corporate management are named defendants in a number of lawsuits alleging violations of the disclosure provisions of the federal securities laws. In June 2007, the Company settled 32 purported securities class action lawsuits arising from actions alleged to have been taken by prior management. The June 2007 class action settlement did not purport to resolve all legacy securities cases. During the second quarter of 2009, the Company concluded that its best estimate of probable loss for the legacy securities matters outstanding at the time was $375 million in the aggregate, which the Company recorded as a liability in accrued and other current liabilities in the Consolidated Balance Sheet as of March 27, 2009. Due to the sharing provisions in the Separation and Distribution Agreement, the Company also recorded receivables from Covidien and Tyco Electronics in the amounts of $158 million and $116 million, respectively, which were recorded in other current assets in the Company's Consolidated Balance Sheet as of March 27, 2009. As a result, the Company recorded a net charge of $101 million related to legacy securities matters during the quarter ended March 27, 2009 in selling, general, and administrative expenses in the Consolidated Statements of Operations. In the second half of fiscal 2009, the Company agreed to settle with all of the remaining plaintiffs that had opted-out of the class action settlement as well as plaintiffs who had brought ERISA related claims for a total of $271 million. Pursuant to the Separation and Distribution Agreement, the Company's share of the settlement amount was approximately $73 million, with Covidien and Tyco Electronics responsible for approximately $114 million and $84 million, respectively. This settlement activity did not result in the Company recording a charge to its Consolidated Statements of Operations as the Company had established a reserve for its best estimate of the amount of loss during the second quarter of 2009 as discussed above. Since the June 2007 class action settlement, the Company has resolved all of its significant legal claims stemming from allegations of securities laws violations, with the exception of the matters noted below. The most significant outstanding legacy securities matter is Stumpf v. Tyco International Ltd., which is a class action lawsuit in which the plaintiffs allege that Tyco, among others, violated the disclosure provisions of the federal securities laws. The matter arises from Tyco's July 2000 initial public offering of common stock of TyCom Inc, and alleges that the TyCom registration statement and prospectus relating to the sale of common stock were inaccurate, misleading and failed to disclose facts necessary to make the registration statement and prospectus not misleading. The complaint further alleges the defendants violated securities laws by making materially false and misleading statements and omissions concerning, among other things, executive compensation, TyCom's business prospects and Tyco's and TyCom's finances. The matter is currently in the pre-trial stages of litigation and Tyco intends to vigorously defend this action. In addition to the Stumpf matter, Tyco is a party to several lawsuits involving disputes with former management, among which are affirmative cases brought by Tyco against Mr. Dennis L. Kozlowski, Tyco's former chief executive officer, Mr. Mark Swartz, its former chief financial officer, and Mr. Frank Walsh Jr., a former director. In connection with these affirmative actions, Messrs. Kozlowski and Swartz have made claims seeking amounts allegedly due in connection with their compensation and retention arrangements and under ERISA, and Mr. Walsh has made claims alleging that Tyco is required to indemnify him for his defense costs arising from his role as a Tyco director. Tyco intends to vigorously defend each of these actions. Tyco has reserved its best estimate of probable loss for these legacy matters. However, their ultimate resolution could differ materially from these estimates and could have a material adverse effect on Tyco's financial position, results of operations or cash flows. Environmental Matters Tyco is involved in various stages of investigation and cleanup related to environmental remediation matters at a number of sites. The ultimate cost of site cleanup is difficult to predict given the uncertainties regarding the extent of the required cleanup, the interpretation of applicable laws and regulations and alternative cleanup methods. As of December 25, 2009, Tyco concluded that it was probable that it would incur remedial costs in the range of approximately $28 million to $84 million. As of December 25, 2009, Tyco concluded that the best estimate within this range is approximately $37 million, of which $10 million is included in accrued and other current liabilities and $27 million is included in other liabilities in the Company's Consolidated Balance Sheet. In view of the Company's financial position and reserves for environmental matters, the Company believes that any potential payments of such estimated amounts will not have a material adverse effect on its financial position, results of operations or cash flows. Asbestos Matters The Company and certain of its subsidiaries are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. These cases typically involve product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were attached to or used with asbestos-containing components manufactured by third-parties. Each case typically names between dozens to hundreds of corporate defendants. While the Company has observed an increase in the number of these lawsuits over the past several years, including lawsuits by plaintiffs with mesothelioma-related claims, a large percentage of these suits have not presented viable legal claims and, as a result, have been dismissed by the courts. The Company's strategy has been, and continues to be, to mount a vigorous defense aimed at having unsubstantiated suits dismissed, and, where appropriate, settling suits before trial. Although a large percentage of litigated suits have been dismissed, the Company cannot predict the extent to which it will be successful in resolving lawsuits in the future. Of the lawsuits that have proceeded to trial since 2005, the Company has won or settled all but one case, with that one case returning an adverse jury verdict for approximately $7.7 million, which included both compensatory and punitive damages. The Company has appealed the verdict and believes that it will ultimately be overturned. As of September 25, 2009 and December 25, 2009, there were approximately 4,200 lawsuits pending against the Company and its subsidiaries. Each lawsuit typically includes several claims, and the Company has determined that it had approximately 5,500 claims outstanding as of September 25, 2009, which reflects adjustments for claims that are not actively being prosecuted, identify incorrect defendants or are duplicative of other actions. The number of claims has not significantly changed since September 25, 2009. Annually, the Company performs an analysis to update its estimated asbestos-related assets and liabilities. The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on claim experience over the past five years and covers claims expected to be filed, including related defense costs, over the next seven years on an undiscounted basis. Due to a high degree of uncertainty regarding the pattern and length of time over which claims will be made and other factors, the Company has concluded that estimating the liability beyond the seven year period will not provide a reasonable estimate. The Company's estimate of asbestos-related insurance recoveries represents estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims. In determining the amount of insurance recoverable, the Company considers available insurance, allocation methodologies, solvency and creditworthiness of the insurers. As of December 25, 2009, the Company's estimated net liability of $58 million was recorded within the Company's Consolidated Balance Sheet as a liability for pending and future claims and related defense costs of $235 million, and separately as an asset for insurance recoveries of $177 million. The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on currently available information as well as estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the resolution of coverage issues with insurance carriers, and the solvency risk with respect to the Company's insurance carriers. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. The Company believes that its asbestos-related reserves as of December 25, 2009 are appropriate. However actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results. Compliance Matters As previously reported in the Company's periodic filings, the Company has received and responded to various allegations and other information that certain improper payments were made by the Company's subsidiaries and agents in recent years. For example, two subsidiaries in the Company's Flow Control business in Italy have been charged, along with numerous other parties, in connection with the Milan public prosecutor's investigation into allegedly improper payments made to certain Italian entities, and the Company has reported to German authorities potentially improper conduct involving agents retained by the Company's EMEA water business. The Company has reported to the U.S. Department of Justice ("DOJ") and the SEC the investigative steps and remedial measures that it has taken in response to these allegations and its internal investigations. The Company also informed the DOJ and the SEC that it has retained outside counsel to perform a Company-wide baseline review of its policies, controls and practices with respect to compliance with the Foreign Corrupt Practices Act ("FCPA"), and that it would continue to investigate and make periodic progress reports to these agencies. The Company has and will continue to communicate with the DOJ and SEC to provide updates on the baseline review and follow-up investigations, including, as appropriate, briefings concerning additional instances of potential improper conduct identified by the Company in the course of its ongoing compliance activities. The baseline review, which has been substantially completed, has revealed that some business practices may not comply with Tyco and FCPA requirements, and the Company has initiated discussions with the DOJ and SEC aimed at resolving these matters. While these discussions are ongoing, the Company cannot predict their outcome and cannot estimate the range of potential loss or the form of penalty, if any, that may result from an adverse resolution. It is possible that the Company may be required to pay material fines, consent to injunctions on future conduct, or suffer other criminal or civil penalties or adverse impacts, each of which could have a material adverse effect on the Company's financial position, results of operations or cash flows. Covidien and Tyco Electronics agreed, in connection with the Separation, to cooperate with the Company in its responses regarding these matters. Any judgment required to be paid or settlement or other cost incurred by the Company in connection with the FCPA investigations matters would be subject to the liability sharing provisions of the Separation and Distribution Agreement, which assigned liabilities primarily related to the former Healthcare and Electronics businesses of the Company to Covidien and Tyco Electronics, respectively, and provides that the Company will retain liabilities primarily related to its continuing operations. Any liabilities not primarily related to a particular segment will be shared equally among the Company, Covidien and Tyco Electronics. The German Federal Cartel Office ("FCO") charged in early 2007 that certain German subsidiaries in the Company's Flow Control business had engaged in anti-competitive practices, in particular with regard to its hydrant, valve, street box and fittings business. The Company investigated this matter and determined that the conduct may have violated German anti-trust law. The Company is cooperating with the FCO in its investigation of this violation, which is ongoing. The Company cannot estimate the range of potential loss that may result from this violation. It is possible that the Company may be subject to civil or criminal proceedings and may be required to pay judgments, suffer penalties or incur settlements in amounts that may have a material adverse effect on its financial position, results of operations or cash flows. ERISA Partial Withdrawal Liability Assessment and Demand On June 8, 2007, SimplexGrinnell received a notice alleging that it had partially withdrawn from the National Automatic Sprinkler Industry Pension Fund (the "Fund"). Under Title IV of ERISA, if the Fund can prove that an employer completely or partially withdraws from a multi-employer pension plan such as the Fund, the employer is liable for withdrawal liability equal to its proportionate share of the plan's unfunded vested benefits. The alleged withdrawal results from a 1994 labor dispute between Grinnell Fire Protection Systems, SimplexGrinnell's predecessor, and Road Sprinkler Fitters Local Union No. 669. ERISA requires that payment of withdrawal liability be made in full or in quarterly installments commencing upon receipt of a liability assessment from the plan. A plan's assessment of withdrawal liability generally may be challenged only in arbitration, and ERISA requires that quarterly payments must continue to be made during the pendency of the arbitration. If the employer prevails in arbitration (and any subsequent appeals), its quarterly withdrawal liability payments are refunded with interest. The Fund's total withdrawal liability assessment against SimplexGrinnell is approximately $25 million. The quarterly withdrawal liability payments are $1.1 million, $12.1 million of which had been paid to date. While the ultimate outcome is uncertain, SimplexGrinnell believes that it has strong arguments that no withdrawal liability is owed to the Fund, and it plans to vigorously defend against the Fund's withdrawal liability assessment. The matter is currently in arbitration. The Company has made no provision for this contingency and believes that its quarterly payments are recoverable. Other Matters As previously reported, in 2002, the SEC's Division of Enforcement conducted an investigation related to past accounting practices for dealer connect fees that ADT had charged to its authorized dealers upon purchasing customer accounts. The investigation related to accounting practices employed by the Company's former management, which were discontinued in 2003. Although the Company settled with the SEC in 2006, a number of former dealers and related parties have filed lawsuits against the Company, including a class action lawsuit filed in the District Court of Arapahoe County, Colorado, alleging breach of contract and other claims related to ADT's decision to terminate certain authorized dealers in 2002 and 2003. The trial is scheduled to begin in February 2010. While it is not possible at this time to predict the final outcome of these lawsuits, the Company does not believe these claims will have a material adverse effect on the Company's financial position, results of operations or cash flows. In addition to the foregoing, the Company is subject to claims and suits, including from time to time, contractual disputes and product and general liability claims, incidental to present and former operations, acquisitions and dispositions. With respect to many of these claims, the Company either self-insures or maintains insurance through third-parties, with varying deductibles. While the ultimate outcome of these matters cannot be predicted with certainty, the Company believes that the resolution of any such proceedings, whether the underlying claims are covered by insurance or not, will not have a material adverse effect on the Company's financial condition, results of operations or cash flows beyond amounts recorded for such matters. |

- removed (2010-01-28):
[0001047469-09-007036:note_history:2]
10.    Commitments and Contingencies

- removed (2010-01-28):
[0001047469-09-007036:note_history:3]
In connection with the
Separation, the Company entered into a liability sharing agreement regarding
certain legal actions that were pending against Tyco prior to the Separation.
Under the Separation and Distribution Agreement, the Company, Covidien and Tyco
Electronics are jointly and severally liable for the full amount of any
judgments resulting from the actions subject to the agreement, which generally
relate to legacy matters that are not specific to the business operations of any
of the companies (including Employee Retirement Income Security Act ("ERISA"),
Foreign Corrupt Practices Act ("FCPA") and securities claims). The Separation
and Distribution Agreement also provides that the Company will be responsible
for 27%, Covidien 42% and Tyco Electronics 31% of payments to resolve these
matters, with costs and expenses associated with the management of these
contingencies being shared equally among the parties. In addition, under the
agreement, the Company will manage and control all the legal matters related to
assumed contingent liabilities as described in the Separation and Distribution
Agreement, including the defense or settlement thereof, subject to certain
limitations. Additionally, at the time of the Separation, the Company, Covidien
and Tyco Electronics agreed to allocate responsibility for certain legacy tax
claims pursuant to the same formula under the Tax Sharing Agreement. See
Note 5.

- removed (2010-01-28):
[0001047469-09-007036:note_history:4]
Class Action Settlement and Legacy
Securities Matters

- removed (2010-01-28):
[0001047469-09-007036:note_history:5]
As a result of actions
taken by certain of the Company's former senior corporate management, Tyco and
some members of the Company's former senior corporate management are named
defendants in a number of lawsuits alleging violations of the disclosure
provisions of the federal securities laws. In addition, Tyco, certain of its
current and former employees and some members of the Company's former senior
corporate management are named as defendants in several ERISA class actions. The
Company is generally obligated to indemnify its directors and officers who are
named as defendants in some or all of these matters to the extent required by
Bermuda law.

- removed (2010-01-28):
[0001047469-09-007036:note_history:6]
In 2007, the Company
agreed to settle 32 purported securities class action lawsuits arising from
actions alleged to have been taken by prior management for $2.975 billion,
and the settlement became final in February 2008. Tyco is not subject to any
further liability for the class action settlement. Of this amount, the Company
contributed $803 million, representing its share under the Separation and
Distribution Agreement, to an escrow account established in connection with the
settlement and recorded a current liability of $2.975 billion in the third
quarter of 2007. Since the settlement was agreed to, the Company has recovered
certain amounts from insurers. As a result, the Company recorded
$151 million of recoveries in its Consolidated Statements of Operations
through the end of fiscal 2008. Based on the Separation and Distribution
Agreement, the Company also recorded payables to Covidien and Tyco Electronics
for their portion of the recoveries through such date with an offset to Shareholders' Equity. The Company did not recover
any additional settlements from insurers during the first nine months of 2009.

- removed (2010-01-28):
[0001047469-09-007036:note_history:7]
The class action
settlement did not purport to resolve all legacy securities cases, and several
remain outstanding, including the claims related to the Stumpf matter described below. The settlement
also did not release claims arising under ERISA and related lawsuits, which are
also described below. In addition, as of the opt-out deadline, Tyco had received
opt-out notices from individuals and entities totaling approximately 4% of the
shares owned by class members. A number of these individuals and entities have
filed claims separately against Tyco. Any judgments resulting from such claims
or from claims that are filed in the future would not reduce the class action
settlement amount. Generally, the claims asserted by these plaintiffs include
claims similar to those asserted by the settling defendants; namely, violations
of the disclosure provisions of federal securities laws. Since the class action
settlement became final in February 2008, the Company has agreed to settle
substantially all of the opt-out claims that had subsequently been filed as well
as the ERISA related claims. The Stumpf matter remains outstanding.

- removed (2010-01-28):
[0001047469-09-007036:note_history:8]
During the first half of
fiscal 2009, the Company settled a number of legal matters stemming from alleged
violations of federal securities laws committed by former senior management,
including three lawsuits from plaintiffs that had opted out of the June 2007
class action settlement for an aggregate amount of approximately
$90 million. Pursuant to the Separation and Distribution Agreement, the
Company's share of the settlement amount was approximately $24 million,
with Covidien and Tyco Electronics responsible for approximately
$38 million and $28 million, respectively. The Company recorded the
total settlement amount of $90 million as a liability within the Company's
Consolidated Balance Sheet at March 27, 2009, and recorded a receivable due
from Covidien and Tyco Electronics for their respective portion of the liability
of $38 million and $28 million, respectively, which were recorded in
other current assets in the Company's Consolidated Balance Sheet at
March 27, 2009. As a result, the Company recorded a $24 million charge
to its Consolidated Statement of Operations for the quarter ended March 27,
2009.

- removed (2010-01-28):
[0001047469-09-007036:note_history:9]
At each balance sheet
date, the Company assesses the need for reserves related to its contingent
liabilities in accordance with SFAS No. 5, "Accounting for Contingencies." Prior to the
second quarter of 2009, the Company concluded that it was not possible to
reasonably estimate the amount of loss, or range of loss, if any, that might
result from an adverse resolution of the legacy securities matters described
above. However, in light of the settlements in the second quarter and other
recent settlement activity, the Company concluded that its best estimate of
probable loss for its remaining legacy securities matters (including the
remaining opt-out claims and the Stumpf and ERISA matters described below) was $375 million in the
aggregate, which the Company recorded as a liability in other current
liabilities in the Consolidated Balance Sheet at March 27, 2009. Because
any payments ultimately made in connection with these matters are subject to the
sharing provisions of the Separation and Distribution Agreement described above,
the Company also recorded receivables from Covidien and Tyco Electronics in the
amounts of $158 million and $116 million, respectively, which were
recorded in other current assets in the Company's Consolidated Balance Sheet at
March 27, 2009. As a result, the Company recorded a net charge of
$101 million related to these unresolved legacy securities matters during
the quarter ended March 27, 2009 in selling, general, and administrative
expenses in the Consolidated Statement of Operations.

- removed (2010-01-28):
[0001047469-09-007036:note_history:10]
During the quarter ended
June 26, 2009, the Company agreed to settle with five of the plaintiffs
that had opted-out of the class action settlement for a total of
$199 million. Pursuant to the Separation and Distribution Agreement, the
Company's share of the settlement amount was approximately $54 million,
with Covidien and Tyco Electronics responsible for approximately
$83 million and $62 million, respectively. This settlement activity
did not result in the Company recording a charge to its Consolidated Statement
of Operations for the three months ended June 26, 2009 as the Company had
established a reserve for its best estimate of the amount of loss during the
second quarter of 2009 as discussed above.

- removed (2010-01-28):
[0001047469-09-007036:note_history:11]
Stumpf v. Tyco International Ltd. is a
class action lawsuit in which the plaintiffs assert complaints against Tyco,
among others, based on alleged violations of the disclosure provisions of the
federal securities laws. The matter arises from Tyco's July 2000 initial public
offering of common stock of TyCom Inc, and alleges that the TyCom registration
statement and prospectus relating to the sale of common stock were inaccurate,
misleading and failed to disclose facts necessary to make the registration
statement and prospectus not misleading. The complaint further alleges the
defendants violated securities laws by making materially false and misleading
statements and omissions concerning, among other things, executive compensation,
TyCom's business prospects and Tyco's and TyCom's finances. The matter is
currently in the pre-trial stages of litigation. As discussed above, the Company
has reserved its best estimate of probable loss related to this matter.

- removed (2010-01-28):
[0001047469-09-007036:note_history:12]
Tyco and certain of its
current and former employees, officers and directors, have been named as
defendants in eight class actions brought under ERISA. All eight actions have
been consolidated in the District Court in New Hampshire. The consolidated
complaint purported to bring claims on behalf of the Company's Retirement
Savings and Investment Plans and the participants therein and alleged that the
defendants breached their fiduciary duties under ERISA by negligently
misrepresenting and negligently failing to disclose material information
concerning, among other things, the following: related-party transactions and
executive compensation; the Company's mergers and acquisitions and the
accounting therefor, as well as allegedly undisclosed acquisitions; and
misstatements of the Company's financial results. The complaint also asserted
that the defendants breached their fiduciary duties by allowing the Plans to
invest in the Company's shares when it was not a prudent investment. The
complaints sought recovery of alleged plan losses arising from alleged breaches
of fiduciary duties. On May 14, 2009, the Company agreed to settle this
amount for a total of $70 million, subject to the entry of a final order by
the court approving the settlement. Pursuant to the Separation and Distribution
Agreement, the Company's share of the settlement amount was approximately
$19 million, with Covidien and Tyco Electronics responsible for
approximately $29 million and $22 million, respectively. This
settlement did not result in the Company recording a charge to its Consolidated
Statement of Operations for the three months ended June 26, 2009 as the
Company had established a reserve for its best estimate of the amount of loss
during the second quarter of 2009 as discussed above.

- removed (2010-01-28):
[0001047469-09-007036:note_history:13]
Under the terms of the
Separation and Distribution Agreement, each of Tyco, Covidien and Tyco
Electronics are jointly and severally liable for the full amount of any legacy
securities matters, including the Stumpf matter.

- removed (2010-01-28):
[0001047469-09-007036:note_history:14]
The Company continues to
believe that the accrual remaining at June 26, 2009 is its best estimate
for the remaining unresolved claims. Although the Company has reserved its best
estimate of probable loss related to unresolved legacy securities claims, their
ultimate resolution could differ from this estimate and could have a material adverse effect on
the Company's financial position, results of operations or cash flows.

- removed (2010-01-28):
[0001047469-09-007036:note_history:15]
Investigations

- removed (2010-01-28):
[0001047469-09-007036:note_history:16]
The Company and others
have received various subpoenas and requests from the Securities and Exchange
Commission ("SEC") Division of Enforcement, the United States Department of
Labor, state departments of labor, the General Service Administration and others
seeking the production of voluminous documents in connection with various
investigations into the Company's governance, management, operations, accounting
and related controls. The Company cannot predict when these investigations will
be completed, nor can the Company predict what the results of these
investigations may be. It is possible that the Company will be required to pay
material fines, consent to injunctions on future conduct, lose the ability to
conduct business with government entities or instrumentalities (which in turn
could negatively impact the Company's business with non-governmental customers)
or suffer other penalties or adverse impacts, each of which could have a
material adverse effect on the Company's business. It is not possible to
estimate the amount of loss, or range of possible loss, if any, that might
result from an adverse resolution of these matters.

- removed (2010-01-28):
[0001047469-09-007036:note_history:17]
Environmental Matters

- removed (2010-01-28):
[0001047469-09-007036:note_history:18]
Tyco is involved in
various stages of investigation and cleanup related to environmental remediation
matters at a number of sites. The ultimate cost of site cleanup is difficult to
predict given the uncertainties regarding the extent of the required cleanup,
the interpretation of applicable laws and regulations and alternative cleanup
methods. As of June 26, 2009, Tyco concluded that it was probable that it
would incur remedial costs in the range of approximately $36 million to
$77 million. As of June 26, 2009, Tyco concluded that the best
estimate within this range is approximately $43 million, of which
$10 million is included in accrued and other current liabilities and
$33 million is included in other liabilities in the Company's Consolidated
Balance Sheet. In view of the Company's financial position and reserves for
environmental matters, the Company believes that any potential payments related
to these known environmental liabilities will not have a material adverse effect
on its financial position, results of operations or cash flows.

- removed (2010-01-28):
[0001047469-09-007036:note_history:19]
Asbestos Matters

- removed (2010-01-28):
[0001047469-09-007036:note_history:20]
The Company and some of
its subsidiaries are named as defendants in personal injury lawsuits based on
alleged exposure to asbestos-containing materials. Consistent with the national
trend of increased asbestos-related litigation, the Company has observed an
increase in the number of these lawsuits in the past several years. A limited
number of the cases allege premises liability, based on claims that individuals
were exposed to asbestos while on a subsidiary's property. A majority of the
cases involve product liability claims, based principally on allegations of past
distribution of heat-resistant industrial products incorporating asbestos or the
past distribution of industrial valves that incorporated asbestos-containing
gaskets or packing. Each case typically names between dozens to hundreds of
corporate defendants.

- removed (2010-01-28):
[0001047469-09-007036:note_history:21]
In the Company's
experience, a large percentage of these claims were never substantiated and, as
a result, have been dismissed by the courts. The Company will continue to
vigorously defend the lawsuits that have been filed against it and its
subsidiaries, but cannot predict whether it will be successful in those cases
that proceed to trial. When appropriate, the Company settles claims. Of the
lawsuits that have proceeded to trial since 2008, Tyco has won or settled all
but one case, with that one case returning an adverse jury verdict for
approximately $7.7 million, which included both compensatory and punitive
damages. The Company has appealed the verdict and believes that it will
ultimately be overturned. As of June 26, 2009, there were approximately
4,700 asbestos cases pending against the Company and its subsidiaries.

- removed (2010-01-28):
[0001047469-09-007036:note_history:22]
The Company's estimate of
the liability for pending and future claims is based on claim experience over
the past five years and covers claims expected to be filed over the next seven
years. The Company believes that it has adequate amounts accrued related to
these matters. While it is not possible at this time to determine with certainty
the ultimate outcome of these asbestos-related proceedings, the Company believes
that the final outcome of all known and anticipated future claims, after taking
into account its substantial indemnification rights and insurance coverage, will
not have a material adverse effect on the Company's financial position, results
of operations or cash flows.

- removed (2010-01-28):
[0001047469-09-007036:note_history:23]
Compliance Matters

- removed (2010-01-28):
[0001047469-09-007036:note_history:24]
As previously reported in
the Company's periodic filings, the Company has received and responded to
various allegations and other information that certain improper payments were
made by the Company's subsidiaries in recent years. For example, two
subsidiaries in the Company's Flow Control business in Italy have been charged,
along with numerous other parties, in connection with the Milan public
prosecutor's investigation into allegedly improper payments made to certain
Italian entities, and the Company has reported to German authorities recently
discovered potentially improper conduct involving agents retained by the
Company's EMEA water business. The Company has reported to the U.S. Department
of Justice ("DOJ") and the SEC the investigative steps and remedial measures
that it has taken in response to the allegations and its internal
investigations. The Company also informed the DOJ and the SEC that it has
retained outside counsel to perform a Company-wide baseline review of its
policies, controls and practices with respect to compliance with the FCPA, and
that it would continue to investigate and make periodic progress reports to
these agencies. The Company has and will continue to communicate with the DOJ
and SEC to provide updates on the baseline review and follow-up investigations,
including, as appropriate, briefings concerning additional instances of
potential improper conduct identified by the Company in the course of its
ongoing compliance activities. To date, the baseline review has revealed that
some business practices may not comply with Tyco and FCPA requirements. At this
time, the Company cannot predict the outcome of these matters and other
allegations reported to U.S. and non-U.S. regulatory and law enforcement
authorities and therefore cannot estimate the range of potential loss or extent
of risk, if any, that may result from an adverse resolution of these matters.
However, it is possible that the Company may be required to pay material fines,
consent to injunctions on future conduct, or suffer other penalties or adverse
impacts, each of which could have a material adverse effect on its financial
position, results of operations or cash flows.

- removed (2010-01-28):
[0001047469-09-007036:note_history:25]
Covidien and Tyco
Electronics agreed, in connection with the Separation, to cooperate with the
Company in its responses regarding these matters. Any judgment required to be
paid or settlement or other cost incurred by the Company in connection with the
FCPA investigations matters would be subject to the liability sharing provisions
of the Separation and Distribution Agreement, which assigned liabilities
primarily related to the former Healthcare and Electronics businesses of the
Company to Covidien or Tyco Electronics, respectively, and provides that the
Company will retain liabilities primarily related to its continuing operations.
Any liabilities not primarily related to a particular segment will be shared
equally among the Company, Covidien and Tyco Electronics.

- removed (2010-01-28):
[0001047469-09-007036:note_history:26]
The German Federal Cartel
Office ("FCO") charged in early 2007 that certain German subsidiaries in the
Company's Flow Control business had engaged in anti-competitive practices, in
particular with regard to its hydrant, valve, street box and fittings business.
The Company investigated this matter and determined that the conduct may have
violated German anti-trust law. The Company is cooperating with the FCO in its
investigation of this violation. The Company cannot estimate the range of
potential loss that may result from this violation. It is possible that the
Company may be subject to civil or criminal proceedings and may be required to
pay judgments, suffer penalties or incur settlements in amounts that may have a
material adverse effect on its financial position, results of operations or cash
flows.

- removed (2010-01-28):
[0001047469-09-007036:note_history:27]
ERISA Partial Withdrawal Liability
Assessment and Demand

- removed (2010-01-28):
[0001047469-09-007036:note_history:28]
On June 8, 2007,
SimplexGrinnell received a notice alleging that it had partially withdrawn from
the National Automatic Sprinkler Industry Pension Fund (the "Fund"). Under Title
IV of ERISA, if the Fund can prove that an employer completely or partially
withdraws from a multi-employer pension plan such as the Fund, the employer is
liable for withdrawal liability equal to its proportionate share of the plan's
unfunded vested benefits. The alleged withdrawal results from a 1994 labor
dispute between Grinnell Fire Protection Systems, SimplexGrinnell's predecessor,
and Road Sprinkler Fitters Local Union No. 669.

- removed (2010-01-28):
[0001047469-09-007036:note_history:29]
ERISA requires that
payment of withdrawal liability be made in full or in quarterly installments
commencing upon receipt of a liability assessment from the plan. A plan's
assessment of withdrawal liability generally may be challenged only in
arbitration, and ERISA requires that quarterly payments must continue to be made
during the pendency of the arbitration. If the employer prevails in arbitration
(and any subsequent appeals), its quarterly withdrawal liability payments are
refunded with interest. The Fund's total withdrawal liability assessment against
SimplexGrinnell is approximately $25 million. The quarterly withdrawal
liability payments are $1.1 million, $8.8 million of which had been
paid by June 26, 2009. While the ultimate outcome is uncertain,
SimplexGrinnell believes that it has strong arguments that no withdrawal
liability is owed to the Fund, and it plans to vigorously defend against the
Fund's withdrawal liability assessment. The matter is currently in arbitration.
The Company has made no provision for this contingency and believes that its
quarterly payments are recoverable.

- removed (2010-01-28):
[0001047469-09-007036:note_history:30]
Other Matters

- removed (2010-01-28):
[0001047469-09-007036:note_history:31]
Fitzpatrick
Contractors Limited v. Tyco Fire and Integrated Solutions
(UK) Ltd.    On July 18,
2007, Fitzpatrick Contractors Limited ("FCL") commenced an action against Tyco
Fire and Integrated Solutions (UK) Ltd. in the High Court of Justice, Queen
Bench Division, Technology and Construction Court, United Kingdom, alleging that
Tyco entered into a binding contract in 2002 for the design, manufacture and
installation of mechanical and electrical works for the refurbishment of a
portion of London Transport's Blackwall Tunnel. FCL had sought damages for
breach of contract in the amount of approximately $38 million. The Company
has settled all of the claims related to this matter for total consideration of
13.3 million British Pounds (approximately $20 million).

- removed (2010-01-28):
[0001047469-09-007036:note_history:32]
As previously reported,
in 2002, the SEC's Division of Enforcement conducted an investigation related to
past accounting practices for dealer connect fees that ADT had charged to its
authorized dealers upon purchasing customer accounts. The investigation related
to accounting practices employed by the Company's former management, which were
discontinued in 2003. Although the Company settled with the SEC in 2006, a
number of former dealers and related parties have filed lawsuits against the
Company, including a class action lawsuit filed in the District Court of
Arapahoe County, Colorado, alleging breach of contract and other claims related
to ADT's decision to terminate certain authorized dealers in 2002 and 2003.
While it is not possible at this time to predict the final outcome of these
lawsuits, the Company does not believe these claims will have a material adverse
effect on the Company's financial position, results of operations or cash flows.

- removed (2010-01-28):
[0001047469-09-007036:note_history:33]
In addition to the
foregoing, the Company is subject to claims and suits, including from time to
time, contractual disputes and product and general liability claims, incidental
to present and former operations, acquisitions and dispositions. With respect to
many of these claims, the Company either self-insures or maintains insurance
through third-parties, with varying deductibles. While the ultimate outcome of
these matters cannot be predicted with certainty, we believe that the resolution
of any such proceedings, whether the underlying claims are covered by insurance
or not, will not have a material adverse effect on our financial condition,
results of operations or cash flows beyond amounts recorded for such matters.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2010-01-28):
[0001047469-10-000401:note_history:34]
| 1. Basis of Presentation and Summary of Significant Accounting Policies Basis of Presentation—The unaudited Consolidated Financial Statements include the consolidated results of Tyco International Ltd., a corporation organized under the laws of Switzerland, and its subsidiaries (Tyco and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Tyco"). The financial statements have been prepared in United States dollars ("USD") and in accordance with the instructions to Form 10-Q under the Securities Exchange Act of 1934, as amended. The year end condensed balance sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States of America. These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K for the fiscal year ended September 25, 2009 (the "2009 Form 10-K"). The Consolidated Financial Statements included herein are unaudited, but in the opinion of management, such financial statements include all adjustments, consisting of normal recurring adjustments, necessary to summarize fairly the Company's financial position, results of operations and cash flows for the interim period. The results reported in these Consolidated Financial Statements should not be taken as indicative of results that may be expected for the entire year. Revenue related to the sale of electronic tags and labels utilized in retailer anti-theft systems is classified as revenue from product sales. In reporting periods prior to the first quarter of fiscal 2010, revenue related to the sale of electronic tags and labels utilized in retailer anti-theft systems was misclassified as service revenue. Such item had no effect on net revenue, operating (loss) income, net (loss) income and cash flows. No changes have been made to previously filed financial statements or in the comparative quarterly amounts presented herein, as the effect in prior periods is not material. In the first quarter of fiscal 2009, revenue related to the sale of such electronic tags and labels reflected as service revenue was $77 million and related cost of services was $47 million. References to 2010 and 2009 are to Tyco's fiscal quarters ending December 25, 2009 and December 26, 2008, respectively, unless otherwise indicated. Reclassifications—Certain prior period amounts have been reclassified to conform with the current period presentation. Specifically, the Company has realigned certain business operations in the first quarter of fiscal 2010, resulting in prior period segment amounts being recast. See Note 13. Recently Adopted Accounting Pronouncements—In June 2008, the Financial Accounting Standards Board ("FASB") ratified authoritative guidance for determining whether instruments granted in share-based payment transactions are participating securities. The guidance addresses whether instruments granted in share-based payment awards are participating securities prior to vesting and, therefore, must be included in the earnings allocation in calculating earnings per share under the two-class method. The guidance requires that unvested share-based payment awards that contain non-forfeitable rights to dividends or dividend-equivalents be treated as participating securities in calculating earnings per share. The guidance became effective for Tyco in the first quarter of fiscal 2010, and has been applied retrospectively to prior periods. The adoption did not have a material impact on the Company's historical annual or quarterly basic and diluted earnings per share. See Note 6 for additional information related to the adoption of the guidance. In December 2007, the FASB revised the authoritative guidance for business combinations. The revised guidance retains the underlying concepts of the existing guidance in that business combinations are still accounted for at fair value. However, the accounting for certain other aspects of business combinations will be affected. Acquisition costs will generally be expensed as incurred. Restructuring costs associated with a business combination will generally be expensed subsequent to the acquisition date. In-process research and development will be recorded at fair value as an indefinite-lived intangible at the acquisition date until it is completed or abandoned and its useful life can be determined. Changes in deferred tax asset valuation allowances and uncertain tax positions after the acquisition date will generally impact income tax expense. The revised guidance also expands required disclosures surrounding the nature and financial effects of business combinations. The revised guidance was adopted by the Company in the first quarter of fiscal 2010. The revised guidance is primarily effective for all business combinations beginning in the first quarter of fiscal 2010 and thereafter, and its adoption did not have a material impact on the Company's financial position, results of operations or cash flows for the quarter ended December 25, 2009. In December 2007, the FASB issued authoritative guidance for noncontrolling interests in consolidated financial statements. The guidance requires the recognition of a noncontrolling interest (minority interest prior to the adoption of the guidance) as equity in the Consolidated Financial Statements. The amount of net income attributable to the noncontrolling interest should be included in consolidated net income on the face of the Consolidated Statements of Operations. The guidance also amends certain existing consolidation procedures in order to achieve consistency with the requirements of the revised authoritative guidance for business combinations discussed above. The guidance also includes expanded disclosure requirements regarding the interests of the parent and its noncontrolling interest. The guidance was adopted by Tyco in the first quarter of fiscal 2010 and has been applied retrospectively. The adoption did not have a material impact on the Company's financial position, results of operations or cash flows. In September 2006, the FASB issued authoritative guidance for fair value measurements, which enhances existing guidance for measuring assets and liabilities at fair value. The guidance defines fair value, establishes a framework for measuring fair value and expands disclosure about fair value measurements. In February 2008, the FASB issued authoritative guidance which permitted companies to partially defer the effective date of the guidance for one year for nonfinancial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a nonrecurring basis. During the first quarter of 2009 the Company elected to defer the adoption of the guidance for one year for non-financial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a nonrecurring basis. The guidance became effective for Tyco in the first quarter of 2009 for financial assets and liabilities only. Tyco adopted the fair value provisions relating to nonfinancial assets and liabilities in the first quarter of fiscal 2010. The adoption did not have a material impact on the Company's financial position, results of operations or cash flows. In April 2008, the FASB issued authoritative guidance for determining the useful life of intangible assets. The guidance amends the factors that should be considered in developing renewal or extension assumptions used to determine the useful life of a recognized intangible asset. The guidance became effective for Tyco in the first quarter of fiscal 2010. The adoption did not have a material impact on the Company's financial position, results of operations or cash flows. Recently Issued Accounting Pronouncements—In September 2009, the FASB issued authoritative guidance for the accounting for revenue arrangements with multiple deliverables. The guidance establishes a selling price hierarchy for determining the selling price of a deliverable. The selling price used for each deliverable will be based on vendor-specific objective evidence if available, third-party evidence if vendor-specific objective evidence is not available, or estimated selling price if neither vendor-specific evidence nor third-party evidence is available. The guidance requires arrangements under which multiple revenue generating activities to be performed be allocated at inception. The residual method under the existing accounting guidance has been eliminated. The guidance expands the disclosure requirements related to multiple-deliverable revenue arrangements. The guidance becomes effective for revenue arrangements entered into or materially modified beginning in fiscal 2011, with early adoption permitted. The guidance applies on a prospective basis unless the Company specifically elects to apply the guidance retrospectively. The Company is currently assessing what impact, if any, the guidance will have on its financial position, results of operations or cash flows, as well as the timing of its adoption of the guidance. In June 2009, the FASB issued authoritative guidance which amended the existing guidance for the consolidation of variable interest entities, to address the elimination of the concept of a qualifying special purpose entity. The guidance also replaces the quantitative-based risks and rewards calculation for determining which enterprise has a controlling financial interest in a variable interest entity with an approach focused on identifying which enterprise has the power to direct the activities of a variable interest entity, and the obligation to absorb losses of the entity or the right to receive benefits from the entity. Additionally, the guidance requires any enterprise that holds a variable interest in a variable interest entity to provide enhanced disclosures that will provide users of financial statements with more transparent information about an enterprise's involvement in a variable interest entity. The guidance is effective for Tyco in the first quarter of fiscal 2011. The Company is currently assessing what impact, if any, that the guidance will have on its financial position, results of operations or cash flows. In December 2008, the FASB issued authoritative guidance for employers' disclosures about postretirement benefit plan assets. The guidance requires additional disclosures about plan assets related to an employer's defined benefit pension or other post-retirement plans to enable investors to better understand how investment decisions are made, the major categories of plan assets, the inputs and valuation techniques used to measure the fair value of plan assets, the effect of fair value measurements using significant unobservable inputs (Level 3) on changes in plan assets for the period, and the significant concentrations of risk within plan assets. The disclosure provisions of the guidance are effective for Tyco in fiscal 2010 and will be adopted concurrent with the pension disclosures associated with the Company's annual valuation process during the fourth quarter of fiscal 2010. |

- removed (2010-01-28):
[0001047469-09-007036:note_history:35]
1.    Basis of
Presentation and Summary of Significant Accounting Policies

- removed (2010-01-28):
[0001047469-09-007036:note_history:36]
Basis of
Presentation    The unaudited
Consolidated Financial Statements include the consolidated results of Tyco
International Ltd., a corporation organized under the laws of Switzerland,
and its subsidiaries (Tyco and all its subsidiaries, hereinafter collectively
referred to as the "Company" or "Tyco"). Effective March 17, 2009, the
Company discontinued its existence as a Bermuda corporation as provided in
Section 132G of The Companies Act 1981 of Bermuda and, in accordance with
article 161 of the Swiss Federal Code on International Private Law,
continued its existence as a Swiss corporation under articles 620 et seq.
of the Swiss Federal Code on Obligations (the "Change of Domicile"). The rights
of holders of the Company's common shares are now governed by Swiss law, the
Company's Swiss articles of association and its Swiss organizational
regulations. The articles of association and organizational regulations were
included as exhibits to the Company's current report on Form 8-K filed with
the Securities and Exchange Commission on March 17, 2009. The financial
statements have been prepared in United States dollars ("USD") and in accordance
with the instructions to Form 10-Q under the Securities Exchange Act of
1934, as amended. The year end condensed balance sheet was derived from audited
financial statements, but does not include all disclosures required by
accounting principles generally accepted in the United States of America. These
financial statements should be read in conjunction with the Consolidated
Financial Statements and accompanying notes contained in the Company's Annual
Report on Form 10-K for the fiscal year ended September 26, 2008 (the
"2008 Form 10-K").

- removed (2010-01-28):
[0001047469-09-007036:note_history:37]
The Consolidated
Financial Statements included herein are unaudited, but in the opinion of
management, such financial statements include all adjustments, consisting of
normal recurring adjustments, necessary to summarize fairly the Company's
financial position, results of operations and cash flows for the interim period.
The results reported in these Consolidated Financial Statements should not be
taken as indicative of results that may be expected for the entire year.

- removed (2010-01-28):
[0001047469-09-007036:note_history:38]
References to 2009 and
2008 are to Tyco's fiscal quarters ending June 26, 2009 and June 27,
2008, respectively, unless otherwise indicated.

- removed (2010-01-28):
[0001047469-09-007036:note_history:39]
Reclassifications    Certain prior period amounts have been
reclassified to conform with the current period presentation. During the quarter
ended March 27, 2009, the Company reclassified a business previously
classified as held for sale as the business no longer met the held for sale
criteria (See Note 2). Additionally, the Company has realigned certain
business operations as of September 27, 2008 resulting in certain prior
period amounts being recast within Note 14.

- removed (2010-01-28):
[0001047469-09-007036:note_history:40]
Recently Adopted
Accounting Pronouncements    In May
2009, the Financial Accounting Standards Board ("FASB") issued Statement of Financial Accounting Standards ("SFAS") No. 165, "Subsequent Events". SFAS No. 165 provides
authoritative accounting literature related to evaluating subsequent events that
was previously addressed only in the auditing literature under Auditing Standard
("AU 560"). SFAS No. 165 is similar to the current guidance with some
exceptions that are not intended to result in significant change to current
practice. SFAS No. 165 defines subsequent events and also requires the
disclosure of the date through which an entity has evaluated subsequent events
and the basis for that date. The Company adopted the disclosure provisions of
SFAS No. 165 as of June 26, 2009. The adoption did not have an impact
on the Company's financial position, results of operations or cash flows.

- removed (2010-01-28):
[0001047469-09-007036:note_history:41]
In April 2009, the FASB
issued FASB Staff Position ("FSP") SFAS No. 107-1 and Accounting Principles
Board ("APB") 28-1, "Interim Disclosures about Fair
Value of Financial Instruments." This FSP amends SFAS No. 107, "Disclosures about Fair Value of Financial Instruments" to require disclosures about fair value of financial instruments in
interim financial statements as well as in annual financial statements. This FSP
also amends APB Opinion No. 28, "Interim Financial Reporting" to require
those disclosures in summarized financial information in interim financial
statements. The Company adopted the disclosure provisions of FSP SFAS
No. 107-1 and APB 28-1 as of June 26, 2009. See Note 9 for
additional information related to the adoption of FSP SFAS No. 107-1 and
APB 28-1. The adoption did not have an impact on the Company's financial
position, results of operations or cash flows.

- removed (2010-01-28):
[0001047469-09-007036:note_history:42]
In March 2008, the FASB
issued SFAS No. 161, "Disclosures about Derivative
Instruments and Hedging Activities." SFAS No. 161
is intended to improve financial reporting about derivative instruments and
hedging activities by requiring enhanced disclosures to enable investors to
better understand their effects on an entity's results of operations. The
Company adopted the disclosure provisions of SFAS No. 161 as of
December 27, 2008. See Note 9 for additional information related to
the adoption of SFAS No. 161. The adoption did not have an impact on the
Company's financial position, results of operations or cash flows.

- removed (2010-01-28):
[0001047469-09-007036:note_history:43]
In September 2006, the
FASB issued SFAS No. 157, "Fair Value
Measurements," which enhances existing guidance for
measuring assets and liabilities at fair value. SFAS No. 157 defines fair
value, establishes a framework for measuring fair value and expands disclosure
about fair value measurements. In February 2008, the FASB issued Staff Position
No. 157-2, "Effective Date of FASB Statement
No. 157" which permits companies to partially defer
the effective date of SFAS No. 157 for one year for nonfinancial assets and
liabilities that are recognized or disclosed at fair value in the financial
statements on a nonrecurring basis. During the first quarter of 2009 the Company
elected to defer the adoption of SFAS No. 157 for one year for
non-financial assets and liabilities that are recognized or disclosed at fair
value in the financial statements on a nonrecurring basis. SFAS No. 157
became effective for Tyco in the first quarter of 2009 for financial assets and
liabilities only. The adoption did not have a material impact on the Company's
financial position, results of operations or cash flows. See Note 9 for
additional information related to the adoption of SFAS No. 157. The Company
is currently assessing the impact, if any, that the adoption of SFAS
No. 157 for non-financial assets and liabilities will have on the results
of its operations, financial position and cash flows.

- removed (2010-01-28):
[0001047469-09-007036:note_history:44]
In September 2006, the
FASB issued SFAS No. 158, "Employers' Accounting for
Defined Benefit Pension and Other Postretirement Plans—an amendment of FASB
Statements No. 87, 88, 106 and 132(R)." SFAS
No. 158 requires that employers recognize the funded status of defined
benefit pension and other postretirement benefit plans as a net asset or
liability on the balance sheet and recognize as a component of other
comprehensive income, net of tax, the gains or losses and prior service costs or
credits that arise during the period but are not recognized as a component of
net periodic benefit cost. The Company adopted the recognition and disclosure
provisions of SFAS No. 158 as of September 28, 2007.

- removed (2010-01-28):
[0001047469-09-007036:note_history:45]
SFAS No. 158 also
requires companies to measure plan assets and benefit obligations as of their
fiscal year end. The Company adopted the measurement date provisions of SFAS
No. 158 on September 27, 2008. As a result, Tyco measured its plan
assets and benefit obligations on September 26, 2008 and adjusted its
opening balances of accumulated earnings and accumulated other comprehensive
income for the change in net periodic benefit cost and fair value, respectively,
from the previously used measurement date of August 31, 2008. The adoption
of the measurement date provisions resulted in a net decrease to accumulated
earnings of $5 million, net of an income tax benefit of $2 million, and a net increase to
accumulated other comprehensive income of $61 million, net of income taxes
of $28 million. See Note 11 for additional information related to the
adoption of SFAS No. 158.

- removed (2010-01-28):
[0001047469-09-007036:note_history:46]
In February 2007, the
FASB issued SFAS No. 159, "The Fair Value Option for
Financial Assets and Financial Liabilities." SFAS
No. 159 permits an entity, on a contract-by-contract basis, to make an
irrevocable election to account for certain types of financial instruments and
warranty and insurance contracts at fair value, rather than historical cost,
with changes in the fair value, whether realized or unrealized, recognized in
earnings. SFAS No. 159 became effective for Tyco in the first quarter of
2009. On September 27, 2008, the Company did not elect the fair value
option under SFAS No. 159 for eligible items.

- removed (2010-01-28):
[0001047469-09-007036:note_history:47]
Recently Issued
Accounting Pronouncements    In June
2009, the FASB issued SFAS No. 168, "The FASB
Accounting Standards Codification and the Hierarchy of Generally Accepted
Accounting Principles—a replacement of FASB Statement
No. 162." SFAS No. 168 establishes the FASB
Standards Accounting Codification ("Codification") as the source of
authoritative U.S. generally accepted accounting principles ("GAAP") recognized
by the FASB to be applied to nongovernmental entities, and rules and
interpretive releases of the SEC as authoritative GAAP for SEC registrants. The
Codification will supersede all the existing non-SEC accounting and reporting
standards upon its effective date and subsequently, the FASB will not issue new
standards in the form of Statements, FASB Staff Positions or Emerging Issues
Task Force Abstracts. SFAS No. 168 also replaces FASB Statement
No. 162, "The Hierarchy of Generally Accepted
Accounting Principles" but is not intended to change or
alter existing US GAAP. The Codification, will change the references of
financial standards in effect for Tyco. Beginning in the fourth quarter of
fiscal 2009, all references made to US GAAP will use the new Codification
numbering system prescribed by the FASB. SFAS No. 168 will not have any
impact on the Company's financial position, results of operations and cash
flows.

- removed (2010-01-28):
[0001047469-09-007036:note_history:48]
In June 2009, the FASB
issued SFAS No. 167, "New Consolidation Guidance for
Variable Interest Entities (VIE)", which amends FASB
Interpretation No. ("FIN") 46 (R), "Consolidation of Variable Interest Entities",
to address the elimination of the concept of a qualifying special purpose
entity. SFAS No. 167 also replaces the quantitative-based risks and rewards
calculation for determining which enterprise has a controlling financial
interest in a variable interest entity with an approach focused on identifying
which enterprise has the power to direct the activities of variable interest
entity, and the obligation to absorb losses of the entity or the right to
receive benefits from the entity. Additionally, SFAS No. 167 requires any
enterprise that holds a variable interest in a variable interest entity to
provide enhanced disclosures that will provide users of financial statements
with more transparent information about an enterprise's involvement in a
variable interest entity. SFAS No. 167 is effective for Tyco in the first
quarter of fiscal 2011. The Company is currently assessing what impact, if any,
that SFAS No. 167 will have on its financial position, results of
operations and cash flows.

- removed (2010-01-28):
[0001047469-09-007036:note_history:49]
In June 2008 the FASB
ratified FASB Staff Position ("FSP") No. EITF 03-6-1, "Determining Whether Instruments Granted in Share-Based Payment
Transactions are Participating Securities" (FSP No.
EITF 03-6-1), which addresses whether instruments granted in share-based
payment awards are participating securities prior to vesting and, therefore,
must be included in the earnings allocation in calculating earnings per share
under the two-class method described in SFAS No. 128, "Earnings per Share" (SFAS No. 128). FSP
No. EITF 03-6-1 requires that unvested share-based payment awards that
contain non-forfeitable rights to dividends or dividend-equivalents be treated
as participating securities in calculating earnings per share. FSP No.
EITF 03-6-1 is effective for Tyco starting with the first interim period of
fiscal 2010, and shall be applied retrospectively to all prior periods. The
Company is currently evaluating the effects, if any, that FSP No.
EITF 03-6-1 may have on earnings per share.

- removed (2010-01-28):
[0001047469-09-007036:note_history:50]
In April 2008, the FASB
issued FSP No. 142-3, "Determination of the Useful
Life of Intangible Assets". FSP No. 142-3 amends
the factors that should be considered in developing renewal or extension
assumptions used to determine the useful life of a recognized intangible asset
under SFAS No. 142, "Goodwill and Other Intangible
Assets". FSP No. 142-3 is effective for Tyco in the
first quarter of 2010. The Company is currently assessing what impact, if any,
that FSP No. 142-3 will have on its financial position, results of
operations and cash flows.

- removed (2010-01-28):
[0001047469-09-007036:note_history:51]
In December 2007, the
FASB issued SFAS No. 141 (Revised 2007), "Business
Combinations." SFAS No. 141(R) retains the
underlying concepts of SFAS No. 141 in that business combinations are still
accounted for at fair value. However, the accounting for certain other aspects
of business combinations will be affected. Acquisition costs will generally be
expensed as incurred. Restructuring costs associated with a business combination
will generally be expensed subsequent to the acquisition date. In-process
research and development will be recorded at fair value as an indefinite-lived
intangible at the acquisition date until it is completed or abandoned and its
useful life can be determined. Changes in deferred tax asset valuation
allowances and uncertain tax positions after the acquisition date will generally
impact income tax expense. SFAS No. 141(R) also expands required
disclosures surrounding the nature and financial effects of business
combinations. SFAS No. 141(R) is effective, on a prospective basis, for
Tyco in the first quarter of fiscal 2010.

- removed (2010-01-28):
[0001047469-09-007036:note_history:52]
In December 2007, the
FASB issued SFAS No. 160, "Noncontrolling Interests
in Consolidated Financial Statements—an amendment of ARB
No. 51". SFAS No. 160 requires the recognition
of a noncontrolling interest (minority interest prior to the adoption of SFAS
No. 160) as equity in the Consolidated Financial Statements. The amount of
net income attributable to the noncontrolling interest should be included in
consolidated net income on the face of the statement of income. SFAS
No. 160 also amends certain of Accounting Research Bulletin No. 51's
consolidation procedures in order to achieve consistency with the requirements
of SFAS No. 141R. The statement also includes expanded disclosure
requirements regarding the interests of the parent and its noncontrolling
interest. This statement is effective for Tyco in the first quarter of fiscal
2010. The Company is currently assessing what impact, if any, that SFAS
No. 160 will have on its financial position, results of operations and cash
flows.

- removed (2010-01-28):
[0001047469-09-007036:note_history:53]
In December 2008, the
FASB issued FSP FAS 132(R)-1, "Employers'
Disclosures about Postretirement Benefit Plan Assets".
The FSP requires additional disclosures about plan assets related to an
employer's defined benefit pension or other post-retirement plans to enable
investors to better understand how investment decisions are made, the major
categories of plan assets, the inputs and valuation techniques used to measure
the fair value of plan assets, the effect of fair value measurements using
significant unobservable inputs (Level 3) on changes in plan assets for the
period, and the significant concentrations of risk within plan assets. The
disclosure provisions of FSP FAS 132 (R)-1 are effective for Tyco
in the first quarter of fiscal 2010.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2010-01-28):
[0001047469-10-000401:note_history:54]
|  |  | December 25, 2009 |  | September 25, 2009 |  |
| Commercial paper(2) |  | $ | — |  | $ | 200 |  |
| 6.75% public notes due 2011 |  |  | 516 |  |  | 516 |  |
| 6.375% public notes due 2011 |  |  | 849 |  |  | 849 |  |
| Revolving senior credit facility due 2011 |  |  | — |  |  | — |  |
| Revolving senior credit facility due 2012 |  |  | — |  |  | — |  |
| 6.0% public notes due 2013 |  |  | 655 |  |  | 655 |  |
| 4.125% public notes due 2014 |  |  | 498 |  |  | — |  |
| 8.5% public notes due 2019 |  |  | 750 |  |  | 750 |  |
| 7.0% public notes due 2019 |  |  | 433 |  |  | 434 |  |
| 6.875% public notes due 2021 |  |  | 716 |  |  | 716 |  |
| 7.0% public notes due 2028 |  |  | 7 |  |  | 14 |  |
| 6.875% public notes due 2029 |  |  | 21 |  |  | 21 |  |
| Other(1)(2) |  |  | 78 |  |  | 119 |  |
| Total debt |  |  | 4,523 |  |  | 4,274 |  |
| Less current portion |  |  | 17 |  |  | 245 |  |
| Long-term debt |  | $ | 4,506 |  | $ | 4,029 |  |
  (was, 2009-07-30, similarity 0.7204):
[0001047469-09-007036:note_history:54]
|  |  | June 26,2009 |  | September 26,2008 |  |
| Commercial paper |  | $ | 200 |  | $ | 116 |  |
| 6.125% public notes due 2008(2) |  |  | — |  |  | 300 |  |
| 6.125% public notes due 2009(2) |  |  | — |  |  | 215 |  |
| 6.75% public notes due 2011 |  |  | 516 |  |  | 516 |  |
| 6.375% public notes due 2011 |  |  | 849 |  |  | 849 |  |
| Revolving senior credit facility due 2012 |  |  | — |  |  | 286 |  |
| 6.0% public notes due 2013 |  |  | 655 |  |  | 655 |  |
| 8.5% public notes due 2019 |  |  | 750 |  |  | — |  |
| 7.0% public notes due 2019 |  |  | 434 |  |  | 435 |  |
| 6.875% public notes due 2021 |  |  | 716 |  |  | 717 |  |
| 7.0% public notes due 2028 |  |  | 14 |  |  | 16 |  |
| 6.875% public notes due 2029 |  |  | 21 |  |  | 23 |  |
| Other(1)(2) |  |  | 90 |  |  | 136 |  |
| Total debt |  |  | 4,245 |  |  | 4,264 |  |
| Less current portion |  |  | 19 |  |  | 555 |  |
| Long-term debt |  | $ | 4,226 |  | $ | 3,709 |  |

- removed (2010-01-28):
[0001047469-09-007036:note_history:55]
8.    Debt

- removed (2010-01-28):
[0001047469-09-007036:note_history:56]
Debt was as follows ($ in
millions):

- removed (2010-01-28):
[0001047469-09-007036:note_history:57]
(1)

- removed (2010-01-28):
[0001047469-09-007036:note_history:58]
$19 million of the amount
  shown as other is the current portion of long-term debt as of June 26,
  2009.

- removed (2010-01-28):
[0001047469-09-007036:note_history:59]
(2)

- removed (2010-01-28):
[0001047469-09-007036:note_history:60]
These instruments, plus
  $40 million of the amount shown as other, comprise the current portion of
  long-term debt as of September 26, 2008.

- removed (2010-01-28):
[0001047469-09-007036:note_history:61]
The carrying amount of
Tyco's debt subject to the provisions of FSP SFAS 107-1 and APB 28-1
at June 26, 2009 was $4,155 million. The Company has determined the
fair value of such debt to be $4,279 million at June 26, 2009. The
Company utilizes various valuation methodologies to determine the fair value of
its debt which is primarily dependent on the type of market in which the
Company's debt is traded. When available, the Company uses quoted market prices
to determine the fair value of its debt which is traded in active markets. At
June 26, 2009, the fair value of the Company's debt which is actively
traded was $4,047 million. When quoted market prices are not readily
available or representative of fair value, the Company utilizes market
information of comparable debt with similar terms, such as maturities, interest
rates and credit risk to determine the fair value of its debt which is traded in
markets that are not active. At June 26, 2009, the fair value of the
Company's debt which is not actively traded was $32 million. Additionally,
the Company believes the carrying amount of its commercial paper of
$200 million approximates fair value based on the maturities of such debt
and the frequency in which the interest rates reset.

- removed (2010-01-28):
[0001047469-09-007036:note_history:62]
In May 2008, Tyco
International Finance S.A. ("TIFSA") commenced issuing commercial paper to
U.S. institutional accredited investors and qualified institutional buyers.
Borrowings under the commercial paper program are available for general
corporate purposes. As of June 26, 2009 and September 26, 2008, TIFSA
had $200 million and $116 million, respectively, of commercial paper
outstanding bearing interest at an average rate of 0.59% and 2.95%,
respectively.

- removed (2010-01-28):
[0001047469-09-007036:note_history:63]
At June 26, 2009 and
September 26, 2008, the Company classified $200 million and
$116 million, respectively, of short-term commercial paper as long-term.
Settlement of the amount outstanding at June 26, 2009 is not expected to
require the use of working capital in the next year, as the Company has both the
intent and the ability to refinance this debt on a long-term basis.

- removed (2010-01-28):
[0001047469-09-007036:note_history:64]
On January 9, 2009,
TIFSA issued $750 million aggregate principal amount of 8.5% Notes due on
January 15, 2019, which are fully and unconditionally guaranteed by the
Company (the "2019 Notes"). TIFSA received net proceeds of approximately
$745 million after underwriting discounts and offering expenses. The net
proceeds may be used for general corporate purposes, which may include repayment
of indebtedness, acquisitions, additions to working capital, repurchase of
common shares, capital expenditures and investments in the Company's
subsidiaries. The 2019 Notes are unsecured and rank equally with TIFSA's other
unsecured and unsubordinated debt. TIFSA may redeem any of the 2019 Notes at any
time by paying the greater of the principal amount of the notes or a
"make-whole" amount, plus accrued and unpaid interest. The holders of the 2019
Notes have the right to require TIFSA to repurchase all or a portion of the
notes at a purchase price equal to 101% of the principal amount of the notes
repurchased, plus accrued and unpaid interest upon the occurrence of a change of
control triggering event, which requires both a change of control and a rating
event as defined by the Indenture governing the Notes. Additionally, the holders
of the 2019 Notes have the right to require the Company to repurchase all or a
portion of the 2019 Notes on July 15, 2014 at a purchase price equal to
100% of the principal amount of the notes tendered, plus accrued and unpaid
interest. Otherwise, the notes mature on January 15, 2019. The Company
incurred approximately $5 million of debt issuance costs in connection with
the transaction, which includes underwriter discounts, as well as legal,
accounting and rating agency fees. The debt issuance costs will be amortized
from the date of issuance to the earliest redemption date, which is
July 15, 2014. Interest is payable semiannually on
January 15th and July 15th. The interest rate payable on the 2019
Notes is subject to escalations, as defined by the Indenture, if either Moody's
or S&P downgrades the Company's debt rating below investment grade. The 2019
Notes will not be subject to the preceding adjustments if at any time the
Company's debt rating increases one level above its current rating to A3 and A-
for Moody's and S&P, respectively.

- removed (2010-01-28):
[0001047469-09-007036:note_history:65]
On January 15, 2009,
TIFSA made a payment of $215 million to extinguish all of its 6.125% notes
due 2009 which matured on the same date. Additionally, in November 2008, TIFSA
made a payment of $300 million to extinguish all of its 6.125% notes due
2008.

- removed (2010-01-28):
[0001047469-09-007036:note_history:66]
On June 24, 2008,
Tyco and TIFSA entered into a $500 million senior unsecured revolving
credit agreement with Citibank, N.A., as administrative agent for the lenders
party thereto. This credit agreement has a three-year term. Borrowings under
this agreement have a variable interest rate based on LIBOR or an alternate base
rate. The margin over LIBOR can vary based on changes in the Company's credit
rating and facility utilization. Together with the existing $1.25 billion
five-year senior revolving credit agreement, dated as of April 25, 2007,
the Company's total committed revolving credit line was $1.75 billion.
These revolving credit facilities may be used for working capital, capital
expenditures and general corporate purposes. On January 29, 2009, the
Company repaid $686 million to extinguish the entire outstanding balance
under its revolving credit facilities. As of June 26, 2009, there were no
amounts drawn under these facilities.

- removed (2010-01-28):
[0001047469-09-007036:note_history:67]
On September 15,
2008, Lehman Brothers Holdings Inc. ("Lehman") filed a petition under
Chapter 11 of the U.S. Bankruptcy Code with the U.S. Bankruptcy Court for
the Southern District of New York. Lehman was one of the lenders in the
Company's $1.25 billion revolving credit facility with a commitment of
$60 million. Our $500 million credit facility did not have a
commitment from Lehman.

- removed (2010-01-28):
[0001047469-09-007036:note_history:68]
On December 26,
2008, Lehman relinquished all of its rights and obligations as a lender under
the $1.25 billion credit facility. At that time, Lehman assigned all of its
commitment under the facility to TIFSA. As a result, the aggregate available
commitment under the facility was reduced by the assigned amount. As of
June 26, 2009, the aggregate available commitment under the Company's
senior revolving credit facilities was $1.69 billion, $200 million of
which was dedicated to backstop all of the Company's commercial paper
outstanding as of such date.


## us-gaap:ScheduleOfSubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2010-01-28):
[0001047469-10-000401:note_history:69]
| 18. Subsequent Events On January 15, 2010, the Company announced that its board of directors has recommended that its shareholders approve an annual Swiss Franc dividend equal to $0.84 at the Company's annual general meeting of shareholders on March 10, 2010. The proposed $0.84 dividend is equal to 0.85 Swiss Francs as of January 11, 2010, which represents a 5% increase over the $0.80 dividend approved by shareholders in 2009. Pursuant to Swiss law, dividend payments made prior to January 1, 2011 are subject to Swiss withholding taxes unless made in the form of a return of capital from the Company's registered share capital. As such, the proposed dividend will be paid in the form of a capital reduction and will be distributed in four quarterly installments. On January 18, 2010, the Company entered into a definitive agreement to acquire Brink's Home Security Holdings, Inc ("BHS"), now operating as Broadview Security for approximately $2.0 billion or $42.50 per share. The acquisition price will be financed using cash not to exceed $585 million and the issuance of Tyco common shares. The transaction has been unanimously approved by the board of directors of each company. The transaction is expected to close in the second half of fiscal 2010 and is subject to customary closing conditions, including clearance under the Hart-Scott-Rodino Act and the approval of BHS shareholders. Following the closing of the transaction, the Company intends to combine Broadview with its ADT Worldwide segment. The Company has evaluated subsequent events through the time it filed its quarterly report on Form 10-Q on January 28, 2010. |

- removed (2010-01-28):
[0001047469-09-007036:note_history:70]
19.    Subsequent Events

- removed (2010-01-28):
[0001047469-09-007036:note_history:71]
The Company has evaluated
subsequent events through the time it filed its quarterly report on
Form 10-Q on July 30, 2009.

- removed (2010-01-28):
[0001047469-09-007036:note_history:72]
On July 2, 2009, the
Company received the necessary consents and approvals to transfer the remaining
assets of its Infrastructure Services business in China to Guangzhou Sewage
Treatment Co., Ltd. and received cash proceeds of $24 million.
