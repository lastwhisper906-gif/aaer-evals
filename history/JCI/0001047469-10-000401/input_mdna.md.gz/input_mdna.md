# JCI MD&A — 0001047469-10-000401


## mdna

[0001047469-10-000401:mdna:1]
[same as prior period, unchanged from 0001047469-09-007036:mdna:1]

[0001047469-10-000401:mdna:2]
[same as prior period, unchanged from 0001047469-09-007036:mdna:2]

[0001047469-10-000401:mdna:3]
[same as prior period, unchanged from 0001047469-09-007036:mdna:3]

[0001047469-10-000401:mdna:4]
The unaudited Consolidated Financial Statements include the consolidated results of Tyco International Ltd., a company organized
under the laws of Switzerland, and its subsidiaries (hereinafter collectively referred to as "we," the "Company" or "Tyco"). The financial statements have been prepared in United States dollars
("USD"), in accordance with accounting principles generally accepted in the United States ("GAAP").

[0001047469-10-000401:mdna:5]
[same as prior period, unchanged from 0001047469-09-007036:mdna:5]

[0001047469-10-000401:mdna:6]
[same as prior period, unchanged from 0001047469-09-007036:mdna:6]

[0001047469-10-000401:mdna:7]
ADT Worldwide designs, sells, installs, services and monitors electronic
security systems for residential, commercial, industrial and governmental customers. In addition, ADT Worldwide manufactures certain products related to retailer anti-theft systems.

[0001047469-10-000401:mdna:8]
[same as prior period, unchanged from 0001047469-09-007036:mdna:8]

[0001047469-10-000401:mdna:9]
Flow Control designs, manufactures, sells and services valves, pipes,
fittings, valve automation and heat tracing products for the oil, gas and other energy markets along with general process industries and the water and wastewater markets.

[0001047469-10-000401:mdna:10]
[same as prior period, unchanged from 0001047469-09-007036:mdna:10]

[0001047469-10-000401:mdna:11]
[same as prior period, unchanged from 0001047469-09-007036:mdna:11]

[0001047469-10-000401:mdna:12]
[same as prior period, unchanged from 0001047469-09-007036:mdna:12]

[0001047469-10-000401:mdna:13]
[same as prior period, unchanged from 0001047469-09-007036:mdna:13]

[0001047469-10-000401:mdna:14]
[same as prior period, unchanged from 0001047469-09-007036:mdna:14]

[0001047469-10-000401:mdna:15]
Safety Products designs, manufactures and sells fire suppression,
electronic, security and life safety products, including fire suppression products, breathing apparatus, intrusion security, access control and video management systems. In addition, Safety Products
manufactures products installed and serviced by ADT Worldwide and Fire Protection Services.

[0001047469-10-000401:mdna:16]
[same as prior period, unchanged from 0001047469-09-007036:mdna:16]

[0001047469-10-000401:mdna:17]
References
to the segment data are to the Company's continuing operations. Certain prior period amounts have been reclassified to conform with the current period presentation.
Specifically, the Company has realigned certain business operations during the first quarter of fiscal 2010 resulting in prior period segment amounts being recast. See Note 13 to the
Consolidated Financial Statements.

[0001047469-10-000401:mdna:18]
[same as prior period, unchanged from 0001047469-09-007036:mdna:18]

[0001047469-10-000401:mdna:19]
Net revenue decreased $180 million, or 4.1%, for the quarter ended December 25, 2009 as compared to the quarter ended
December 26, 2008. The decrease in revenue was driven primarily by lower selling prices of steel products in our Electrical and Metal Products segment, reduced volume in our Flow Control
segment and the continued weakness in the commercial markets, which negatively impacted our ADT Worldwide and Safety Products segments. However, service revenue, which is principally derived from our
ADT Worldwide and Fire Protection Services businesses, grew as a

[0001047469-10-000401:mdna:20]
percentage
of our overall revenue to 41% in the quarter ended December 26, 2008. Partially offsetting the net revenue decrease were favorable changes in foreign currency exchange rates of
$264 million for the quarter ended December 25, 2009 as the U.S. dollar weakened against most major currencies as nearly 50% of our net revenue is generated outside the United States.

[0001047469-10-000401:mdna:21]
Operating
income of $414 million for the quarter ended December 25, 2009 remained relatively consistent with the comparable prior period. Lower volumes primarily in our
Electrical and Metal Products, Safety Products and Flow Control segments, as well as the continued weakness in the commercial markets, negatively impacted operating income. The weakness in the
commercial markets was offset by efficiencies gained from cost containment actions taken by the Company in fiscal 2009 and 2008 as well as restructuring actions taken in prior years. Restructuring,
asset impairment and divestiture charges increased from $4 million to $11 million for the quarters ended December 26, 2008 and December 25, 2009, respectively. Operating
income for the quarter ended December 25, 2009 was favorably impacted by $34 million due to changes in foreign currency exchange rates. Operating income
for the quarter ended December 26, 2008 included a legacy legal settlement charge of $8 million, while no such charges were incurred during the quarter ended December 25, 2009.

[0001047469-10-000401:mdna:22]
As
of December 25, 2009, our cash balance was $2.5 billion, as compared to $2.4 billion as of September 25, 2009. The increase was primarily due to cash flow
generated from operating activities of $379 million and proceeds of $498 million received from the issuance of long-term debt partially offset by $458 million of cash
used for acquisitions, accounts purchased by ADT and capital expenditures and the repayment of $242 million of short-term debt. We expect to continue to use our cash to fund
internal growth opportunities, improve productivity across all of our businesses, make acquisitions that strategically fit within our ADT Worldwide, Fire Protection Services and Flow Control
businesses and return capital to shareholders. In fiscal 2010, we expect to use up to $585 million of cash to fund the acquisition of Brink's Home Security Holdings, Inc. ("BHS"), as described
below.

[0001047469-10-000401:mdna:23]
On
January 18, 2010, we entered into a definitive agreement to acquire BHS, now operating as Broadview Security, for approximately $2.0 billion or $42.50 per share. The
acquisition price will be financed using cash not to exceed approximately $585 million and the issuance of Tyco common shares. The transaction has been unanimously approved by the board of
directors of each company. The transaction is expected to close in the second half of fiscal 2010 upon customary closing conditions, including clearance under the Hart-Scott-Rodino Act and
the approval of BHS shareholders. Following the closing of the transaction, we intend to combine Broadview with our ADT Worldwide segment.

[0001047469-10-000401:mdna:24]
In
2010, we also expect to continue our portfolio refinement efforts by exiting areas that have not provided, and are not expected to provide, an adequate return on investment and take
advantage of restructuring opportunities that are expected to provide significant future cost savings. During the quarter ended December 25, 2009, we incurred approximately $11 million
of restructuring and divestiture charges. We expect to incur total restructuring and restructuring related charges of approximately $100 million to $150 million in fiscal 2010.

[0001047469-10-000401:mdna:25]
43

[0001047469-10-000401:mdna:26]
Operating Results

[0001047469-10-000401:mdna:27]
|  |  | For the Quarters Ended |  |
|  |  | December 25, 2009 |  | December 26, 2008 |  |
| Revenue from product sales |  | $ | 2,528 |  | $ | 2,768 |  |
| Service revenue |  |  | 1,718 |  |  | 1,658 |  |
| Net revenue |  | $ | 4,246 |  | $ | 4,426 |  |
| Operating income |  | $ | 414 |  | $ | 413 |  |
| Interest income |  |  | 9 |  |  | 12 |  |
| Interest expense |  |  | (76 | ) |  | (73 | ) |
| Other income, net |  |  | 9 |  |  | 4 |  |
| Income from continuing operations before income taxes |  |  | 356 |  |  | 356 |  |
| Income taxes |  |  | (53 | ) |  | (84 | ) |
| Income from continuing operations |  |  | 303 |  |  | 272 |  |
| Income from discontinued operations, net of income taxes |  |  | — |  |  | 5 |  |
| Net income |  | $ | 303 |  | $ | 277 |  |
| Less: Noncontrolling interest in subsidiaries net income |  |  | 1 |  |  | — |  |
| Net income attributable to Tyco common shareholders |  | $ | 302 |  | $ | 277 |  |

[0001047469-10-000401:mdna:28]
Quarter Ended December 25, 2009 Compared to Quarter Ended December 26, 2008

[0001047469-10-000401:mdna:29]
[same as prior period, unchanged from 0001047469-09-007036:mdna:37]

[0001047469-10-000401:mdna:30]
[same as prior period, unchanged from 0001047469-09-007036:mdna:38]

[0001047469-10-000401:mdna:31]
|  |  | For the Quarters Ended |  |  |  |
|  |  | December 25, 2009 |  | December 26, 2008 |  | % Change |  |
| Revenue from product sales |  | $ | 631 |  | $ | 636 |  |  | (0.8 | )%(1) |
| Service revenue |  |  | 1,204 |  |  | 1,175 |  |  | 2.5 | %(1) |
| Net revenue |  | $ | 1,835 |  | $ | 1,811 |  |  | 1.3 | % |
| Operating income |  |  | 259 |  |  | 227 |  |  | 14.1 | % |
| Operating margin |  |  | 14.1 | % |  | 12.5 | % |  |  |  |

[0001047469-10-000401:mdna:32]
[same as prior period, unchanged from 0001047469-09-007036:mdna:79]

[0001047469-10-000401:mdna:33]
As
discussed in Note 1 to the Consolidated Financial Statements, revenue related to the sale of electronic tags and labels has been
classified as revenue from product sales during the quarter ended December 25, 2009. During the quarter ended December 26, 2008, the sale of the electronic tags and labels were
misclassified as service revenue. The service revenue and revenue from product sales during the quarter ended December 26, 2008 have not been changed for this misclassification, as the effect
is not material. The impact of the misclassification in the first, second, third and fourth quarters of fiscal 2009 would have been to decrease service revenue by $77 million,
$65 million, $73 million and $71 million, respectively, with corresponding increases to revenue from product sales.

[0001047469-10-000401:mdna:34]
Revenue
from product sales includes sales and installation of electronic security and other life safety systems as well as products related to retailer anti-theft
systems. Service revenue is comprised of electronic security services and maintenance, including the monitoring of burglar alarms, fire alarms and other life safety systems as well as other security
services.

[0001047469-10-000401:mdna:35]
Net revenue by geographic area for ADT Worldwide was as follows ($ in millions):

[0001047469-10-000401:mdna:36]
|  |  | For the Quarters Ended |  |  |  |
|  |  | December 25, 2009 |  | December 26, 2008 |  | % Change |  |
| North America |  | $ | 1,056 |  | $ | 1,069 |  |  | (1.2 | )% |
| Europe, Middle East and Africa ("EMEA") |  |  | 485 |  |  | 484 |  |  | — | % |
| Rest of World |  |  | 294 |  |  | 258 |  |  | 14.0 | % |
|  |  | $ | 1,835 |  | $ | 1,811 |  |  | 1.3 | % |

[0001047469-10-000401:mdna:37]
Net
revenue for ADT Worldwide increased $24 million, or 1.3%, during the quarter ended December 25, 2009, as compared to the quarter ended December 26, 2008. Net
revenue was favorably impacted by changes in foreign currency exchange rates of $89 million, while revenue was negatively affected by $5 million for the net impact of acquisitions and
divestitures. Approximately 56% and 52% of ADT Worldwide's total net revenue for the quarters ended December 25, 2009 and December 26, 2008, respectively, represents revenue associated
with monitoring and maintenance services under contractual arrangements, which is considered recurring revenue. Recurring revenue increased by $89 million, or 9.4%, to approximately
$1.0 billion as a result of growth in customer accounts of 193,000, or 2.6%, to a total of 7.5 million accounts as of December 25, 2009. Changes in foreign currency exchange rates
favorably impacted recurring revenue by $41 million, or 4.4%. Systems installation, product sales and other service revenue declined by $65 million, or 7.5%, to $805 million due
to lower sales volume primarily as the result of continued weakness in the commercial and retailer end markets. Changes in foreign currency exchange rates favorably impacted systems installation,
product sales and other service
revenue by $48 million, or 5.5%, while the net impact of acquisitions and divestitures resulted in an unfavorable impact of $5 million or 0.6%.

[0001047469-10-000401:mdna:38]
Geographically,
North America net revenue decreased $13 million, or 1.2%, due to a decline in systems installation, product sales and other service revenue as the result of the
continued weakness in the commercial and retailer end markets. This decrease was partially offset by an increase in recurring revenue. Net revenue was also favorably impacted by changes in foreign
currency exchange rates of $12 million, or 1.2%. Net revenue in EMEA increased by $1 million, which was favorably impacted by changes in foreign currency exchange rates of
$46 million, or 9.5%. This increase in net revenue was almost entirely offset by a decline in systems installation, product sales and other service revenue as a result of the continued slowdown
in the commercial and retailer end markets. Recurring revenue in EMEA remained relatively flat when compared to the quarter ended December 26, 2008. Net revenue increased $36 million, or
14.0%, in the Rest of World geographies primarily due to recurring revenue growth in both the Asia Pacific and Latin American regions as ADT Worldwide continues to focus on building its customer
account and recurring revenue base in these markets. This increase was partially offset by a decline in system installation, products sales and other service revenue in Latin America due to slowdown
in the commercial and retailer end markets. Net revenue in the rest of the world was also favorably impacted by changes in foreign currency exchange rates of $32 million, or 12.4%.

[0001047469-10-000401:mdna:39]
Attrition
rates remained relatively consistent, as shown in the following table:

[0001047469-10-000401:mdna:40]
|  |  | For the Quarters Ended |  |
|  |  | December 25, 2009 |  | September 25, 2009 |  | December 26, 2008 |  |
| Trailing 12-month basis attrition |  |  | 13.5 | % |  | 13.4 | % |  | 13.2 | % |

[0001047469-10-000401:mdna:41]
Operating
income increased $32 million, or 14.1%, in the quarter ended December 25, 2009 from the same period in the prior year. Operating margin increased to 14.1% in the
quarter ended December 25, 2009 from 12.5% for the same period in the prior year. Operating income was positively impacted by the shift to higher margin recurring revenue discussed above.
Additionally, operating

[0001047469-10-000401:mdna:42]
45

[0001047469-10-000401:mdna:43]
income
was favorably impacted by the net impact of savings realized through previous restructuring actions and savings realized through cost containment actions and lower intangible asset amortization
related to certain tradenames. During the quarter ended December 25, 2009, $5 million of restructuring charges were incurred compared to $1 million during the quarter ended
December 26, 2008. Changes in foreign currency exchange rates favorably impacted operating income by $10 million.

[0001047469-10-000401:mdna:44]
[same as prior period, unchanged from 0001047469-09-007036:mdna:45]

[0001047469-10-000401:mdna:45]
[same as prior period, unchanged from 0001047469-09-007036:mdna:46]

[0001047469-10-000401:mdna:46]
|  |  | For the Quarters Ended |  |  |  |
|  |  | December 25, 2009 |  | December 26, 2008 |  | % Change |  |
| Revenue from product sales |  | $ | 838 |  | $ | 892 |  |  | (6.1 | )% |
| Service revenue |  |  | 85 |  |  | 67 |  |  | 26.9 | % |
| Net revenue |  | $ | 923 |  | $ | 959 |  |  | (3.8 | )% |
| Operating income |  | $ | 112 |  | $ | 137 |  |  | (18.2 | )% |
| Operating margin |  |  | 12.1 | % |  | 14.3 | % |  |  |  |

[0001047469-10-000401:mdna:47]
Net
revenue for Flow Control decreased $36 million, or 3.8%, in the quarter ended December 25, 2009 compared to the quarter ended December 26, 2008. The decrease in
net revenue was primarily driven by reduced volume in the valves business and reduced project activity within the thermal controls business partially offset by favorable changes in foreign currency
exchange rates of $96 million. The net impact of acquisitions and divestitures unfavorably impacted net revenue by $2 million in the quarter ended December 25, 2009 and favorably
impacted net revenue by $1 million in prior year.

[0001047469-10-000401:mdna:48]
The
decrease in operating income of $25 million, or 18.2%, in the quarter ended December 25, 2009, as compared to the same period in the prior year, was primarily due to
decreased volume in the valves and thermal businesses offset by margin improvements in the water business within the EMEA region and favorable changes in foreign currency exchange rates of
$15 million. Margins were negatively impacted by restructuring charges of $6 million in the quarter ended December 25, 2009 as compared to $1 million during the quarter
ended December 26, 2008. The decline in operating income was partially offset by savings realized through cost containment and restructuring actions.

[0001047469-10-000401:mdna:49]
[same as prior period, unchanged from 0001047469-09-007036:mdna:50]

[0001047469-10-000401:mdna:50]
[same as prior period, unchanged from 0001047469-09-007036:mdna:51]

[0001047469-10-000401:mdna:51]
|  |  | For the Quarters Ended |  |  |  |
|  |  | December 25, 2009 |  | December 26, 2008 |  | % Change |  |
| Revenue from product sales |  | $ | 407 |  | $ | 426 |  |  | (4.5 | )% |
| Service revenue |  |  | 426 |  |  | 413 |  |  | 3.1 | % |
| Net revenue |  | $ | 833 |  | $ | 839 |  |  | (0.7 | )% |
| Operating income |  | $ | 64 |  | $ | 56 |  |  | 14.3 | % |
| Operating margin |  |  | 7.7 | % |  | 6.7 | % |  |  |  |

[0001047469-10-000401:mdna:52]
Revenue
from product sales includes sales and installation of fire protection and other systems. Service revenue consists of inspection, maintenance, service and monitoring of fire
detection and suppression systems.

[0001047469-10-000401:mdna:53]
Net
revenue by geographic area for Fire Protection Services was as follows ($ in millions):

[0001047469-10-000401:mdna:54]
|  |  | For the Quarters Ended |  |  |  |
|  |  | December 25, 2009 |  | December 26, 2008 |  | % Change |  |
| North America |  | $ | 469 |  | $ | 491 |  |  | (4.5 | )% |
| International |  |  | 364 |  |  | 348 |  |  | 4.6 | % |
| Net revenue |  | $ | 833 |  | $ | 839 |  |  | (0.7 | )% |

[0001047469-10-000401:mdna:55]
Net
revenue for Fire Protection Services decreased $6 million, or 0.7%, during the quarter ended December 25, 2009 compared to the quarter ended December 26, 2008.
This decrease was primarily due to the continued weakness in the commercial market, which more than offset the favorable changes in foreign currency exchange rates of $49 million, or 5.8%.
Geographically, net revenue in North America decreased $22 million, or 4.5% primarily due to the continued decline in systems installation and upgrade activity as well as service revenue in the
sprinkler business. Changes in foreign currency exchange rates favorably impacted revenue in North America by $7 million, or 1.4%. Net revenue in our international fire businesses increased by
$16 million, or 4.6% largely due to the favorable impact of changes in foreign currency exchange rates of $42 million, or 12.1% partially offset by a decrease in revenue due to the
continued weakness in the European commercial markets.

[0001047469-10-000401:mdna:56]
Operating
income increased $8 million, or 14.3% in the quarter ended December 25, 2009 as compared to the same period in the prior year. The increase was primarily driven
by savings realized through cost containment actions, a reduction in legal costs and to a lesser extent favorable changes in foreign currency exchange rates of $3 million. The increase was
partially offset by the decreased sales volume discussed above as well as restructuring charges of $3 million in the quarter ended December 25, 2009 as compared to no charges in the
quarter ended December 26, 2008.

[0001047469-10-000401:mdna:57]
[same as prior period, unchanged from 0001047469-09-007036:mdna:55]

[0001047469-10-000401:mdna:58]
[same as prior period, unchanged from 0001047469-09-007036:mdna:56]

[0001047469-10-000401:mdna:59]
|  |  | For the Quarters Ended |  |  |  |
|  |  | December 25, 2009 |  | December 26, 2008 |  | % Change |  |
| Revenue from product sales |  | $ | 296 |  | $ | 415 |  |  | (28.7 | )% |
| Service revenue |  |  | 1 |  |  | 1 |  |  | — | % |
| Net revenue |  | $ | 297 |  | $ | 416 |  |  | (28.6 | )% |
| Operating income |  | $ | 23 |  | $ | 27 |  |  | (14.8 | )% |
| Operating margin |  |  | 7.7 | % |  | 6.5 | % |  |  |  |

[0001047469-10-000401:mdna:60]
Net
revenue for Electrical and Metal Products decreased $119 million, or 28.6%, in the quarter ended December 25, 2009 compared to the quarter ended December 26,
2008. The decrease in revenue was primarily due to lower selling prices of steel products and to a lesser extent lower selling prices of armored cable products. Lower volume for both steel and armored
cable products largely resulting from a decline in the commercial market in North America also contributed to the decline. Changes in foreign currency exchange rates had a favorable impact of
$12 million.

[0001047469-10-000401:mdna:61]
Operating
income decreased $4 million, or 14.8% in the quarter ended December 25, 2009 as compared to the same period in the prior year. Operating income decreased
primarily as a result of the decline in volume of steel and armored cable products as well as lower spreads for armored cable products. Lower selling prices more than offset lower raw material costs
which resulted in the lower

[0001047469-10-000401:mdna:62]
spreads
for armored cable products. These decreases were partially offset by higher spreads for steel products as lower raw material costs more than offset lower selling prices.

[0001047469-10-000401:mdna:63]
[same as prior period, unchanged from 0001047469-09-007036:mdna:60]

[0001047469-10-000401:mdna:64]
[same as prior period, unchanged from 0001047469-09-007036:mdna:61]

[0001047469-10-000401:mdna:65]
|  |  | For the Quarters Ended |  |  |  |
|  |  | December 25, 2009 |  | December 26, 2008 |  | % Change |  |
| Revenue from product sales |  | $ | 356 |  | $ | 399 |  |  | (10.8 | )% |
| Service revenue |  |  | 2 |  |  | 2 |  |  | — | % |
| Net revenue |  | $ | 358 |  | $ | 401 |  |  | (10.7 | )% |
| Operating income |  | $ | 54 |  | $ | 80 |  |  | (32.5 | )% |
| Operating margin |  |  | 15.1 | % |  | 20.0 | % |  |  |  |

[0001047469-10-000401:mdna:66]
Net
revenue for Safety Products decreased $43 million, or 10.7%, during the quarter ended December 25, 2009 as compared to the quarter ended December 26, 2008. Net
revenue was favorably impacted by changes in foreign currency exchange rates of $18 million, while revenue was negatively affected by $6 million for the net impact of acquisitions and
divestitures. The decrease in net revenue is primarily due to lower volume in our fire suppression and electronic security businesses. The decrease in our fire suppression business was primarily due
to reduced spending in the commercial construction
market. The electronic security business decrease was primarily due to the continued slow down in the retail sector, as retail capital projects and new store openings continue to be canceled or
delayed.

[0001047469-10-000401:mdna:67]
Operating
income decreased $26 million, or 32.5% during the quarter ended December 25, 2009 compared to the same period in the prior year. The decrease in operating income
is primarily attributable to the sales volume decline as discussed above. The decrease in operating income was partially offset by the favorable changes in foreign currency exchange rates of
$3 million. A credit of $1 million of restructuring and divestiture charges, net during the quarter ended December 25, 2009 favorably impacted operating income as compared to
$1 million of restructuring charges during the quarter ended December 26, 2008.

[0001047469-10-000401:mdna:68]
[same as prior period, unchanged from 0001047469-09-007036:mdna:65]

[0001047469-10-000401:mdna:69]
Corporate expense decreased $16 million, or 14.0%, to $98 million in the quarter ended December 25, 2009 compared
to $114 million in the quarter ended December 26, 2008. Corporate expense for the quarter ended December 25, 2009 included net charges of $2 million relating to divestiture
charges as compared to $10 million of net charges in the prior year. The $10 million of net charges for the quarter ended December 26, 2008 was comprised of $8 million of
charges related to legacy legal settlements and $2 million of divestiture charges. The remaining decrease in Corporate expense is related to savings realized through cost containment actions.

[0001047469-10-000401:mdna:70]
[same as prior period, unchanged from 0001047469-09-007036:mdna:67]

[0001047469-10-000401:mdna:71]
Interest income was $9 million and $12 million during the quarters ended December 25, 2009 and December 26,
2008, respectively. The decrease in interest income is primarily related to lower investment yields.

[0001047469-10-000401:mdna:72]
Interest
expense was $76 million in the quarter ended December 25, 2009 compared to $73 million in the quarter ended December 26, 2008. The increase in
interest expense is primarily related to interest on new debt issuances.

[0001047469-10-000401:mdna:73]
[same as prior period, unchanged from 0001047469-09-007036:mdna:70]

[0001047469-10-000401:mdna:74]
Other income, net was $9 million and $4 million during the quarters ended December 25, 2009, December 26,
2008, respectively. Other income, net for the quarter ended December 25, 2009 primarily relates to an increase in receivables due from Covidien and Tyco Electronics under the Tax Sharing
Agreement.

[0001047469-10-000401:mdna:75]
[same as prior period, unchanged from 0001047469-09-007036:mdna:73]

[0001047469-10-000401:mdna:76]
Our effective income tax rate was 14.9% and 23.6% during the quarters ended December 25, 2009 and December 26, 2008,
respectively. The decrease in the effective tax rate was primarily due to the impact of enacted tax law changes on our deferred tax balances and a non-recurring item generating a tax benefit.

[0001047469-10-000401:mdna:77]
The
valuation allowance for deferred tax assets of $797 million and $791 million as of December 25, 2009 and September 25, 2009, respectively, relates
principally to the uncertainty of the utilization of certain deferred tax assets, primarily tax loss and credit carryforwards in various jurisdictions. The valuation allowance was calculated and
recorded when we determined that it was more-likely-than-not that all or a portion of our deferred tax assets would not be realized. We believe that we will
generate sufficient future taxable income to realize the tax benefits related to the remaining net deferred tax assets on our Consolidated Balance Sheets.

[0001047469-10-000401:mdna:78]
The
calculation of our tax liabilities involves dealing with uncertainties in the application of complex tax regulations in a multitude of jurisdictions across our global operations. We
record tax liabilities for anticipated tax audit issues in the U.S. and other tax jurisdictions based on our estimate of whether, and the extent to which, additional taxes will be due. These tax
liabilities are reflected net of related tax loss carryforwards. We adjust these liabilities in light of changing facts and circumstances; however, due to the complexity of some of these
uncertainties, the ultimate resolution may result in a payment that is materially different from our current estimate of the tax liabilities. Substantially all of these potential tax liabilities are
recorded in other liabilities in the Consolidated Balance Sheets as payment is not expected within one year.

[0001047469-10-000401:mdna:79]
[same as prior period, unchanged from 0001047469-09-007036:mdna:133]

[0001047469-10-000401:mdna:80]
In connection with the spin-offs of Covidien and Tyco Electronics from Tyco, Tyco entered into a Tax Sharing Agreement that
governs the rights and obligations of each party with respect to certain pre-Separation income tax liabilities. More specifically, Tyco, Covidien and Tyco Electronics share 27%, 42% and
31%, respectively, of shared income tax liabilities that arise from adjustments made by tax authorities to Tyco's, Covidien's and Tyco Electronics' U.S. and certain non-U.S. income tax
returns. All costs and expenses associated with the management of these shared tax liabilities are shared equally among the parties. Consistent with the sharing provisions of the Tax Sharing
Agreement, Tyco had a net receivable from Covidien and Tyco Electronics of $115 million and $106 million as of December 25, 2009 and September 25, 2009, respectively. In
addition, as of December 25, 2009 and September 25, 2009, Tyco had a liability of $554 million representing Tyco's obligations under the Tax Sharing Agreement.

[0001047469-10-000401:mdna:81]
Tyco
and its subsidiaries' income tax returns periodically are examined by various tax authorities. In connection with these examinations, tax authorities, including the IRS, have raised
issues and proposed tax adjustments. The Company is reviewing and contesting certain of the proposed tax adjustments. Amounts related to these tax adjustments and other tax contingencies and related
interest have been assessed as uncertain income tax positions and recorded as appropriate.

[0001047469-10-000401:mdna:82]
For
a detailed discussion of contingencies related to Tyco's income taxes, see Note 5 to the Consolidated Financial Statements.

[0001047469-10-000401:mdna:83]
[same as prior period, unchanged from 0001047469-09-007036:mdna:142]

[0001047469-10-000401:mdna:84]
[same as prior period, unchanged from 0001047469-09-007036:mdna:143]

[0001047469-10-000401:mdna:85]
[same as prior period, unchanged from 0001047469-09-007036:mdna:144]

[0001047469-10-000401:mdna:86]
During the fourth quarter of 2009, we approved a plan to sell a business in our ADT Worldwide segment. This business has been
classified as held for sale; however, its results of operations are presented in continuing operations as the criteria for discontinued operations have not been met. We have assessed and determined
that the carrying value of this business is recoverable and will continue to assess recoverability based on current fair value, less cost to sell, until the business is sold. We expect to complete the
sale during fiscal 2010.

[0001047469-10-000401:mdna:87]
[same as prior period, unchanged from 0001047469-09-007036:mdna:159]

[0001047469-10-000401:mdna:88]
The preparation of the Consolidated Financial Statements in conformity with GAAP requires management to use judgment in making
estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of contingent assets and liabilities and the reported amounts of revenue and expenses. We believe that
our accounting policies for depreciation and amortization methods of security monitoring-related assets, revenue recognition, loss contingencies, income taxes, goodwill and indefinite-lived intangible
assets, long-lived assets and pension and postretirement benefits are based on, among other things, judgments and assumptions made by management that include inherent risks and
uncertainties. During the three months ended December 25, 2009, there were no significant changes to these policies or in the underlying accounting assumptions and estimates used in the above
critical accounting policies from those disclosed in the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K for the
fiscal year ended September 25, 2009 (the "2009 Form 10-K"). See Note 1 to the Consolidated Financial Statements for the adoption of new accounting standards during
the first quarter of 2010.

[0001047469-10-000401:mdna:89]
[same as prior period, unchanged from 0001047469-09-007036:mdna:163]

[0001047469-10-000401:mdna:90]
On October 5, 2009, Tyco International Finance S.A. ("TIFSA") issued $500 million aggregate principle amount of
4.125% notes due 2014 (the "2014 notes"), which are fully and unconditionally guaranteed by the Company. TIFSA received net proceeds of approximately $495 million after deducting debt issuance
costs and a debt discount.

[0001047469-10-000401:mdna:91]
The
net proceeds of the aforementioned offering may be used for general corporate purposes, which may include repayment of indebtedness, acquisitions, additions to working capital,
repurchase of common shares, capital expenditures and investments in the Company's subsidiaries.

[0001047469-10-000401:mdna:92]
As
of December 25, 2009, there were no amounts drawn under our revolving credit facilities. As of December 25, 2009, the aggregate available commitment under our senior
revolving credit facilities was $1.69 billion. We continually monitor developments regarding the availability of funds under our revolving credit facilities. Although there is some risk that
financial institutions will fail to perform their contractual obligations, particularly in times of credit market distress, we believe that the lenders under our revolving credit facilities are
capable of meeting any borrowing requests we may make for the foreseeable future.

[0001047469-10-000401:mdna:93]
As
of December 25, 2009, TIFSA had made payments of $200 million to extinguish all of its commercial paper outstanding.

[0001047469-10-000401:mdna:94]
In
addition to our available cash and operating cash flows, additional sources of potential liquidity include committed credit lines, our commercial paper program, public debt and equity
markets as well as the ability to sell trade accounts receivable. We continue to balance our operating, investing and financing uses of cash through investment in our existing core businesses,
strategic acquisitions and

[0001047469-10-000401:mdna:95]
divestitures,
dividends and share repurchases. We believe our cash position, amounts available under our credit facilities and cash provided by operating activities will be adequate to cover our
operational and business needs.

[0001047469-10-000401:mdna:96]
We
continue to monitor market conditions and assess the impact, if any, on our financial position, results of operations or cash flows. Approximately 100% of our U.S. and more than 95%
of our non-U.S. funded pension plans are invested in marketable investments, including publicly-traded equity and fixed income securities. Although we do not believe we will be required to
make materially higher cash contributions in the next 12 months, if market condition worsen, we may be required to make incremental cash contributions under local statutory law.

[0001047469-10-000401:mdna:97]
[same as prior period, unchanged from 0001047469-09-007036:mdna:173]

[0001047469-10-000401:mdna:98]
|  |  | For the Quarters Ended |  |
|  |  | December 25, 2009 |  | December 26, 2008 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Operating income |  | $ | 414 |  | $ | 413 |  |
| Depreciation and amortization(1) |  |  | 287 |  |  | 275 |  |
| Non-cash compensation expense |  |  | 31 |  |  | 29 |  |
| Deferred income taxes |  |  | 4 |  |  | (17 | ) |
| Provision for losses on accounts receivable and inventory |  |  | 34 |  |  | 34 |  |
| Other, net |  |  | 12 |  |  | 22 |  |
| Net change in working capital |  |  | (283 | ) |  | (555 | ) |
| Interest income |  |  | 9 |  |  | 12 |  |
| Interest expense |  |  | (76 | ) |  | (73 | ) |
| Income tax expense |  |  | (53 | ) |  | (84 | ) |
| Net cash provided by operating activities |  | $ | 379 |  | $ | 56 |  |
| Other cash flow items: |  |  |  |  |  |  |  |
| Capital expenditures, net(2) |  | $ | (149 | ) | $ | (157 | ) |
| (Increase) decrease in the sale of accounts receivable |  |  | (1 | ) |  | 3 |  |
| Accounts purchased by ADT |  |  | (150 | ) |  | (117 | ) |

[0001047469-10-000401:mdna:99]
[same as prior period, unchanged from 0001047469-09-007036:mdna:96]

[0001047469-10-000401:mdna:100]
The
quarters ended December 25, 2009 and December 26, 2008 included depreciation expense of $158 million and
$148 million, respectively, and amortization of intangible assets of $129 million and $127 million, respectively.

[0001047469-10-000401:mdna:101]
[same as prior period, unchanged from 0001047469-09-007036:mdna:177]

[0001047469-10-000401:mdna:102]
Included
net proceeds received for the sale/disposition of property, plant and equipment of $16 million and $2 million for the
quarters ended December 25, 2009 and December 26, 2008, respectively.

[0001047469-10-000401:mdna:103]
The
net change in working capital decreased operating cash flow by $283 million in the quarter ended December 25, 2009. The significant changes in working
capital included a $216 million decrease in accrued and other liabilities and a $71 million decrease in accounts payable.

[0001047469-10-000401:mdna:104]
During
the three months ended December 25, 2009, we purchased approximately 129,000 customer contracts for electronic security services by our ADT Worldwide segment for cash of
$150 million.

[0001047469-10-000401:mdna:105]
We
continue to fund capital expenditures to grow our business, improve the cost structure of our businesses, to invest in new processes and technology, and to maintain high quality
production standards. The level of capital expenditures in fiscal year 2010 is expected to exceed the spending levels in fiscal year 2009.

[0001047469-10-000401:mdna:106]
During
the quarter ended December 25, 2009, we paid approximately $49 million in cash related to restructuring activities. See Note 3 to our Consolidated Financial
Statements for further information regarding our restructuring activities.

[0001047469-10-000401:mdna:107]
Income
taxes paid, net of refunds, related to continuing operations were $49 million and $73 million during the quarters ended December 25, 2009 and
December 26, 2008, respectively.

[0001047469-10-000401:mdna:108]
During
the quarter ended December 25, 2009, cash paid for acquisitions included in continuing operations totaled $143 million, net of cash acquired of $1 million,
which primarily related to the acquisition of two Brazilian valve companies, including Hiter Industria e Comercio de Controle Termo-Hidraulico Ltda ("Hiter"), a valve manufacturer which serves
a variety of industries including the oil and gas, chemical and petrochemical markets. Net cash paid for Hiter totaled $104 million by the Company's Flow Control segment. In addition, the
Company acquired certain assets of a business within its Electrical and Metal Products segment for $39 million.

[0001047469-10-000401:mdna:109]
We
will continue to divest businesses that do not align with our overall strategy. We expect to use the expected proceeds from these sales, as well as the cash generated by our
operations, to continue to make investments in our businesses that are intended to grow revenue and improve productivity, including our restructuring actions. We expect to also use cash to selectively
pursue acquisitions. As disclosed in Note 18 to our Consolidated Financial Statements, we entered into a definitive agreement to acquire BHS for approximately $2.0 billion. We will
finance this acquisition using cash not to exceed approximately $585 million and the issuance of our common shares.

[0001047469-10-000401:mdna:110]
[same as prior period, unchanged from 0001047469-09-007036:mdna:190]

[0001047469-10-000401:mdna:111]
Management
believes that cash generated by or available to us should be sufficient to fund our capital and liquidity needs for the foreseeable future, including quarterly dividend
payments. We intend to
continue to repurchase shares under our existing $1.0 billion share repurchase program approved by our Board of Directors on July 10, 2008 in accordance with applicable law and depending
on credit market conditions, macroeconomic factors and expectations regarding future cash flows. As also disclosed in Note 18 to our Consolidated Financial Statements, on January 15,
2010, we announced that our Board of Directors recommended that our shareholders approve an annual Swiss franc dividend equal to $0.84 at our annual general meeting of shareholders on March 10,
2010, which represents a 5% increase over the $0.80 dividend approved by our shareholders in 2009.

[0001047469-10-000401:mdna:112]
[same as prior period, unchanged from 0001047469-09-007036:mdna:192]

[0001047469-10-000401:mdna:113]
Tyco shareholders' equity was $13.2 billion, or $27.76 per share, as of December 25, 2009, compared to
$12.9 billion, or $27.30 per share, as of September 25, 2009. Tyco shareholders' equity increased primarily due to net income attributable to Tyco common shareholders of
$302 million. Total debt was $4.5 billion as of December 25, 2009, as compared to $4.3 billion as of September 25, 2009. Total debt as a percentage of total
capitalization (total debt and shareholders' equity) was 26% as of December 25, 2009 and 25% as of September 25, 2009.

[0001047469-10-000401:mdna:114]
Our
cash balance increased to $2.5 billion as of December 25, 2009, as compared to $2.4 billion at September 25, 2009. The increase was primarily due to cash
flow generated from operating activities of $379 million and proceeds of $498 million received from the issuance of long-term debt, partially offset by $458 million of
cash used for acquisitions, accounts purchased by ADT and capital expenditures as well as the repayment of $242 million of short-term debt.

[0001047469-10-000401:mdna:115]
On
September 30, 2009, TIFSA issued $500 million aggregate principal amount of 4.125% Notes due 2014 (the "2014" notes), which are fully and unconditionally guaranteed by
us. TIFSA received net proceeds of approximately $495 million after deducting debt issuance costs and a debt discount. The 2014 notes are unsecured and rank equally with TIFSA's other unsecured
and unsubordinated debt. Payment of principal and interest on the 2014 notes will be fully and unconditionally guaranteed by us. We will pay interest on the 2014 notes on April 15 and
October 15 of each year beginning April 15, 2010. TIFSA may redeem any of the notes at any time by paying the greater of the principal amount of the 2014 notes or a
"make-whole" amount, plus accrued and unpaid interest to, but excluding, the redemption date.

[0001047469-10-000401:mdna:116]
The following table details our long-term and short-term debt ratings as of December 25, 2009 and September 25, 2009:

[0001047469-10-000401:mdna:117]
[same as prior period, unchanged from 0001047469-09-007036:mdna:201]

[0001047469-10-000401:mdna:118]
The security ratings set forth above are not a recommendation to buy, sell or hold securities and may be subject to revision or withdrawal by the assigning rating
organization. Each rating should be evaluated independently of any other rating.

[0001047469-10-000401:mdna:119]
Commitments and Contingencies

[0001047469-10-000401:mdna:120]
For a detailed discussion of contingencies related to our litigation matters and governmental investigations related to us, see
Note 10 to our Consolidated Financial Statements.

[0001047469-10-000401:mdna:121]
[same as prior period, unchanged from 0001047469-09-007036:mdna:205]

[0001047469-10-000401:mdna:122]
As of December 25, 2009 Tyco had a backlog of unfilled orders of $8.9 billion compared to a backlog of
$9.0 billion as of September 25, 2009. We expect that approximately 86% of our backlog as of December 25, 2009 will be filled during the next 12 months. Backlog by segment
was as follows ($ in millions):

[0001047469-10-000401:mdna:123]
|  |  | December 25, 2009 |  | September 25, 2009 |  |
| ADT Worldwide |  | $ | 5,925 |  | $ | 5,916 |  |
| Flow Control |  |  | 1,652 |  |  | 1,698 |  |
| Fire Protection Services |  |  | 1,157 |  |  | 1,171 |  |
| Electrical and Metal Products |  |  | 76 |  |  | 72 |  |
| Safety Products |  |  | 118 |  |  | 102 |  |
|  |  | $ | 8,928 |  | $ | 8,959 |  |

[0001047469-10-000401:mdna:124]
Backlog
decreased by $31 million, or 0.3%, from $9.0 billion as of September 25, 2009 to $8.9 billion as of December 25, 2009. The decrease in backlog
was primarily due to unfavorable changes in foreign currency exchange rates of $31 million. ADT Worldwide's backlog includes recurring revenue-in-force which represents
12 months' revenue associated with monitoring and maintenance services under contract in the security business. ADT Worldwide's backlog increased $9 million, or 0.2%, primarily driven by
an increase in revenue-in-force which was partially offset by decreased bookings and unfavorable exchange rates of $14 million. Flow Control's backlog decreased by $46 million primarily
due to decreased bookings of $32 million and unfavorable exchange
rates of $14 million. Fire Protection Services backlog decreased by $14 million primarily due to decreased bookings of $11 million and unfavorable exchange rates of
$3 million.

[0001047469-10-000401:mdna:125]
[same as prior period, unchanged from 0001047469-09-007036:mdna:209]

[0001047469-10-000401:mdna:126]
[same as prior period, unchanged from 0001047469-09-007036:mdna:210]

[0001047469-10-000401:mdna:127]
Certain of our international businesses utilize the sale of accounts receivable as short-term financing mechanisms. The
aggregate amount outstanding under our international accounts receivable programs was $54 million and $55 million as of December 25, 2009 and September 25, 2009,
respectively.

[0001047469-10-000401:mdna:128]
[same as prior period, unchanged from 0001047469-09-007036:mdna:213]

[0001047469-10-000401:mdna:129]
Certain of our business segments have guaranteed the performance of third-parties and provided financial guarantees for uncompleted
work and financial commitments. The terms of these guarantees vary with end dates ranging from the current fiscal year through the completion of such transactions. The guarantees would typically be
triggered in the event of nonperformance and performance under the guarantees, if required, would not have a material effect on our financial position, results of operations or cash flows.

[0001047469-10-000401:mdna:130]
There
are certain guarantees or indemnifications extended among Tyco, Covidien and Tyco Electronics in accordance with the terms of the Separation and Distribution Agreement and the Tax
Sharing Agreement. The guarantees primarily relate to certain contingent tax liabilities included in the Tax Sharing Agreement. At the time of the Separation, we recorded a liability necessary to
recognize the fair value of such guarantees and indemnifications. See Note 5 to the Consolidated Financial Statements
for further discussion of the Tax Sharing Agreement. In addition, prior to the Separation we provided support in the form of financial and/or performance guarantees to various Covidien and Tyco
Electronics operating entities. To the extent these guarantees were not assigned in connection with the Separation, we assumed primary liability on any remaining such support. The estimated fair value
of these obligations was not material to us as of December 25, 2009.

[0001047469-10-000401:mdna:131]
In
disposing of assets or businesses, we often provide representations, warranties and/or indemnities to cover various risks including, for example, unknown damage to the assets,
environmental risks involved in the sale of real estate, liability to investigate and remediate environmental contamination at waste disposal sites and manufacturing facilities, and unidentified tax
liabilities and legal fees related to periods prior to disposition. We have no reason to believe that these uncertainties would have a material adverse effect on our financial position, results of
operations or cash flows. We have recorded liabilities for known indemnifications included as part of environmental liabilities. See Note 10 to the Consolidated Financial Statements for a
discussion of these liabilities.

[0001047469-10-000401:mdna:132]
In
the normal course of business, we are liable for contract completion and product performance. We record estimated product warranty costs at the time of sale. In the opinion of
management, such obligations will not significantly affect our financial position, results of operations or cash flows.

[0001047469-10-000401:mdna:133]
For
a detailed discussion of guarantees and indemnifications, see Note 16 to the Consolidated Financial Statements.

[0001047469-10-000401:mdna:134]
[same as prior period, unchanged from 0001047469-09-007036:mdna:222]

[0001047469-10-000401:mdna:135]
Recently Adopted Accounting Pronouncements—In June 2008, the Financial Accounting Standards Board ("FASB") ratified authoritative guidance for
determining whether instruments granted in share-based payment transactions are participating securities. The guidance addresses whether instruments granted in share-based payment awards are
participating securities prior to vesting and, therefore, must be included in the earnings allocation in calculating earnings per share under the two-class method. The guidance requires
that unvested share-based payment awards that contain non-forfeitable rights to dividends or dividend-equivalents be treated as participating securities in calculating earnings per share.
The guidance became effective for Tyco in the first quarter of fiscal 2010, and has been applied retrospectively to prior periods. The adoption did not have a material impact on our historical annual
or quarterly basic and diluted earnings per share. See Note 6 to the Consolidated Financial Statements for additional information related to the adoption of the guidance.

[0001047469-10-000401:mdna:136]
In
December 2007, the FASB revised the authoritative guidance for business combinations. The revised guidance retains the underlying concepts of the existing guidance in that business
combinations are still accounted for at fair value. However, the accounting for certain other aspects of business combinations will be affected. Acquisition costs will generally be expensed as
incurred. Restructuring

[0001047469-10-000401:mdna:137]
54

[0001047469-10-000401:mdna:138]
costs
associated with a business combination will generally be expensed subsequent to the acquisition date. In-process research and development will be recorded at fair value as an
indefinite-lived intangible at the acquisition date until it is completed or abandoned and its useful life can be determined. Changes in deferred tax asset valuation allowances and uncertain tax
positions after the acquisition date will generally impact income tax expense. The revised guidance also expands required disclosures surrounding the nature and financial effects of business
combinations. We adopted the revised guidance in the first quarter of fiscal 2010. The revised guidance is primarily effective for all business combinations beginning in the first quarter of fiscal
2010 and thereafter, and its adoption did not have a material impact on our financial position, results of operations or cash flows for the quarter ended December 25, 2009.

[0001047469-10-000401:mdna:139]
In
December 2007, the FASB issued authoritative guidance for noncontrolling interests in consolidated financial statements. The guidance requires the recognition of a noncontrolling
interest (minority interest prior to the adoption of the guidance) as equity in the Consolidated Financial Statements. The amount of net income attributable to the noncontrolling interest should be
included in consolidated net income on the face of the Consolidated Statements of Operations. The guidance also amends certain existing consolidation procedures in order to achieve consistency with
the requirements of the revised authoritative guidance for business combinations discussed above. The guidance also includes expanded disclosure requirements regarding the interests of the parent and
its noncontrolling interest. The guidance was adopted by Tyco in the first quarter of fiscal 2010 and has been applied retrospectively. The adoption did not have a material impact on our financial
position, results of operations or cash flows.

[0001047469-10-000401:mdna:140]
In
September 2006, the FASB issued authoritative guidance for fair value measurements, which enhances existing guidance for measuring assets and liabilities at fair value. The guidance
defines fair value, establishes a framework for measuring fair value and expands disclosure about fair value measurements. In February 2008, the FASB issued authoritative guidance which permitted
companies to partially defer the effective date of the guidance for one year for nonfinancial assets and liabilities that are recognized or disclosed at fair value in the financial statements on a
nonrecurring basis. During the first quarter of 2009 the Company elected to defer the adoption of the guidance for one year for non-financial assets and liabilities that are recognized or
disclosed at fair value in the financial statements on a nonrecurring basis. The guidance became effective for Tyco in the first quarter of 2009 for financial assets and liabilities only. We adopted
the fair value provisions relating to nonfinancial assets and liabilities in the first quarter of fiscal 2010. The adoption did not have a material impact on our financial position, results of
operations or cash flows.

[0001047469-10-000401:mdna:141]
In
April 2008, the FASB issued authoritative guidance for determining the useful life of intangible assets. The guidance amends the factors that should be considered in developing
renewal or extension
assumptions used to determine the useful life of a recognized intangible asset. The guidance became effective for Tyco in the first quarter of fiscal 2010. The adoption did not have a material impact
on our financial position, results of operations or cash flows.

[0001047469-10-000401:mdna:142]
Recently Issued Accounting Pronouncements—In September 2009, the FASB issued authoritative guidance for the accounting for revenue arrangements with
multiple deliverables. The guidance establishes a selling price hierarchy for determining the selling price of a deliverable. The selling price used for each deliverable will be based on
vendor-specific objective evidence if available, third-party evidence if vendor-specific objective evidence is not available, or estimated selling price if neither vendor-specific evidence nor
third-party evidence is available. The guidance requires arrangements under which multiple revenue generating activities to be performed be allocated at inception. The residual method under the
existing accounting guidance has been eliminated. The guidance expands the disclosure requirements related to multiple-deliverable revenue arrangements. The guidance becomes effective for revenue
arrangements entered into or materially modified beginning in fiscal 2011, with early adoption permitted. The guidance applies on a prospective basis unless the Company specifically

[0001047469-10-000401:mdna:143]
55

[0001047469-10-000401:mdna:144]
elects
to apply the guidance retrospectively. We are currently assessing what impact, if any, the guidance will have on our financial position, results of operations or cash flows, as well as the
timing of its adoption of the guidance.

[0001047469-10-000401:mdna:145]
In
June 2009, the FASB issued authoritative guidance which amended the existing guidance for the consolidation of variable interest entities, to address the elimination of the concept of
a qualifying special purpose entity. The guidance also replaces the quantitative-based risks and rewards calculation for determining which enterprise has a controlling financial interest in a variable
interest entity with an approach focused on identifying which enterprise has the power to direct the activities of a variable interest entity, and the obligation to absorb losses of the entity or the
right to receive benefits from the entity. Additionally, the guidance requires any enterprise that holds a variable interest in a variable interest entity to provide enhanced disclosures that will
provide users of financial statements with more transparent information about an enterprise's involvement in a variable interest entity. The guidance is effective for Tyco in the first quarter of
fiscal 2011. We are currently assessing what impact, if any, that the guidance will have on its financial position, results of operations or cash flows.

[0001047469-10-000401:mdna:146]
In
December 2008, the FASB issued authoritative guidance for employers' disclosures about postretirement benefit plan assets. The guidance requires additional disclosures about plan
assets related to an employer's defined benefit pension or other post-retirement plans to enable investors to better understand how investment decisions are made, the major categories of
plan assets, the inputs and valuation techniques used to measure the fair value of plan assets, the effect of fair value measurements using significant unobservable inputs (Level 3) on changes
in plan assets for the period, and the significant concentrations of risk within plan assets. The disclosure provisions of the guidance are effective for Tyco in fiscal 2010 and will be adopted
concurrent with the pension disclosures associated with our annual valuation process during the fourth quarter of fiscal 2010.

[0001047469-10-000401:mdna:147]
[same as prior period, unchanged from 0001047469-09-007036:mdna:242]

[0001047469-10-000401:mdna:148]
[same as prior period, unchanged from 0001047469-09-007036:mdna:243]

[0001047469-10-000401:mdna:149]
[same as prior period, unchanged from 0001047469-09-007036:mdna:244]

[0001047469-10-000401:mdna:150]
[same as prior period, unchanged from 0001047469-09-007036:mdna:245]

[0001047469-10-000401:mdna:151]
[same as prior period, unchanged from 0001047469-09-007036:mdna:246]

[0001047469-10-000401:mdna:152]
[same as prior period, unchanged from 0001047469-09-007036:mdna:247]

[0001047469-10-000401:mdna:153]
[same as prior period, unchanged from 0001047469-09-007036:mdna:248]

[0001047469-10-000401:mdna:154]
[same as prior period, unchanged from 0001047469-09-007036:mdna:249]

[0001047469-10-000401:mdna:155]
[same as prior period, unchanged from 0001047469-09-007036:mdna:250]

[0001047469-10-000401:mdna:156]
[same as prior period, unchanged from 0001047469-09-007036:mdna:31]

[0001047469-10-000401:mdna:157]
[same as prior period, unchanged from 0001047469-09-007036:mdna:251]

[0001047469-10-000401:mdna:158]
[same as prior period, unchanged from 0001047469-09-007036:mdna:252]

[0001047469-10-000401:mdna:159]
[same as prior period, unchanged from 0001047469-09-007036:mdna:253]

[0001047469-10-000401:mdna:160]
the outcome of litigation and governmental proceedings;

[0001047469-10-000401:mdna:161]
[same as prior period, unchanged from 0001047469-09-007036:mdna:255]

[0001047469-10-000401:mdna:162]
[same as prior period, unchanged from 0001047469-09-007036:mdna:256]

[0001047469-10-000401:mdna:163]
[same as prior period, unchanged from 0001047469-09-007036:mdna:257]

[0001047469-10-000401:mdna:164]
our ability to repay or refinance our outstanding indebtedness as it matures;

[0001047469-10-000401:mdna:165]
[same as prior period, unchanged from 0001047469-09-007036:mdna:259]

[0001047469-10-000401:mdna:166]
[same as prior period, unchanged from 0001047469-09-007036:mdna:260]

[0001047469-10-000401:mdna:167]
[same as prior period, unchanged from 0001047469-09-007036:mdna:261]

[0001047469-10-000401:mdna:168]
[same as prior period, unchanged from 0001047469-09-007036:mdna:262]

[0001047469-10-000401:mdna:169]
[same as prior period, unchanged from 0001047469-09-007036:mdna:263]

[0001047469-10-000401:mdna:170]
[same as prior period, unchanged from 0001047469-09-007036:mdna:264]

[0001047469-10-000401:mdna:171]
[same as prior period, unchanged from 0001047469-09-007036:mdna:265]

[0001047469-10-000401:mdna:172]
[same as prior period, unchanged from 0001047469-09-007036:mdna:266]

[0001047469-10-000401:mdna:173]
[same as prior period, unchanged from 0001047469-09-007036:mdna:267]

[0001047469-10-000401:mdna:174]
[same as prior period, unchanged from 0001047469-09-007036:mdna:268]

[0001047469-10-000401:mdna:175]
[same as prior period, unchanged from 0001047469-09-007036:mdna:269]

[0001047469-10-000401:mdna:176]
the ability to achieve cost savings in connection with the Company's strategic restructuring and Six Sigma initiatives;
and our ability to execute our portfolio refinement and acquisition strategies;

[0001047469-10-000401:mdna:177]
[same as prior period, unchanged from 0001047469-09-007036:mdna:271]

[0001047469-10-000401:mdna:178]
[same as prior period, unchanged from 0001047469-09-007036:mdna:272]

[0001047469-10-000401:mdna:179]
[same as prior period, unchanged from 0001047469-09-007036:mdna:273]

[0001047469-10-000401:mdna:180]
[same as prior period, unchanged from 0001047469-09-007036:mdna:274]

[0001047469-10-000401:mdna:181]
[same as prior period, unchanged from 0001047469-09-007036:mdna:275]

[0001047469-10-000401:mdna:182]
[same as prior period, unchanged from 0001047469-09-007036:mdna:276]

[0001047469-10-000401:mdna:183]
[same as prior period, unchanged from 0001047469-09-007036:mdna:277]

[0001047469-10-000401:mdna:184]
[same as prior period, unchanged from 0001047469-09-007036:mdna:278]

[0001047469-10-000401:mdna:185]
[same as prior period, unchanged from 0001047469-09-007036:mdna:279]

[0001047469-10-000401:mdna:186]
the possible effects on Tyco of future legislation in the United States that may limit or eliminate potential U.S. tax
benefits resulting from Tyco International's jurisdiction of incorporation or deny U.S. government contracts to Tyco based upon its jurisdiction of incorporation.
