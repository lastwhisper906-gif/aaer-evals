# JCI MD&A — 0000833444-24-000064


## mdna

[0000833444-24-000064:mdna:1]
ITEM 7    MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000833444-24-000064:mdna:2]
General

[0000833444-24-000064:mdna:3]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, healthy and sustainable buildings, serving a wide range of customers in more than 150 countries. The Company’s products, services, systems and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-24-000064:mdna:4]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including residential and commercial HVAC equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space), energy-management consulting. The Company's OpenBlue digital software platform enables enterprises to better manage their physical spaces by combining the Company's building products and services with cutting-edge technology and digital capabilities to enable data-driven “smart building” services and solutions. The Company partners with customers by leveraging its broad product portfolio and digital capabilities, powered by OpenBlue, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency, enhance security, create healthy environments and reduce greenhouse gas emissions.

[0000833444-24-000064:mdna:5]
The Company's fiscal year ends on September 30. Unless otherwise stated, references to years in this report relate to fiscal years rather than calendar years. This discussion summarizes the significant factors affecting the consolidated operating results, financial condition and liquidity of the Company on a continuing operations basis for the year ended September 30, 2024 and should be read in conjunction with Item 8, the consolidated financial statements and the notes to consolidated financial statements.

[0000833444-24-000064:mdna:6]
Macroeconomic Trends

[0000833444-24-000064:mdna:7]
Much of the demand for the Company’s products and solutions is driven by construction, facility expansion, retrofit and maintenance projects within the commercial, institutional, industrial, data center, governmental and residential sectors. Construction projects are heavily dependent on general economic conditions, localized demand for real estate and the availability of credit, public funding or other financing sources. Positive or negative fluctuations in construction, industrial facility expansion, retrofit activity, maintenance projects and other capital investments in buildings within the sectors that the Company serves, as well as availability of credit, financing or funding for such projects, could have a corresponding impact on the Company’s financial condition, results of operations and cash flows. During fiscal 2024, the Company observed continued softening of economic conditions in China, negatively impacting the performance of the Building Solutions Asia Pacific segment. The Company expects economic conditions in China to stabilize in fiscal 2025, however, if conditions do not stabilize, results of the Building Solutions Asia Pacific segment could be negatively impacted.

[0000833444-24-000064:mdna:8]
As a result of the Company’s global presence, a significant portion of its revenues and expenses is denominated in currencies other than the U.S. dollar. The Company is therefore subject to non-U.S. currency risks and non-U.S. exchange exposure. While the Company employs financial instruments to hedge some of its transactional foreign exchange exposure, these activities do not insulate it completely from those exposures. In addition, the currency exposure from the translation of non-U.S. dollar functional currency subsidiaries are not able to be hedged. Exchange rates can be volatile and a substantial weakening or strengthening of foreign currencies against the U.S. dollar could increase or reduce the Company’s profit margin, respectively, and impact the comparability of results from period to period. During fiscal 2024, revenue and profits were negatively impacted by movements in foreign exchange rates against the U.S. dollar.

[0000833444-24-000064:mdna:9]
The Company continues to observe trends demonstrating increased interest and demand for its products and services that enable smart, safe, efficient and sustainable buildings, particularly within verticals including data centers, government, healthcare and higher education. This demand is driven in part by capital investment, government tax incentives, building performance standards and regulations designed to limit emissions and combat climate change. In particular, legislative and regulatory initiatives such as the U.S. Climate Smart Buildings Initiative, U.S. Inflation Reduction Act and EU Energy Performance of Buildings Directive include provisions designed to fund and encourage investment in decarbonization and digital technologies for buildings. This demand is supplemented by an increase in commitments in both the public and private sectors to reduce emissions and/or achieve net zero emissions. The Company seeks to capitalize on these trends to drive growth by developing

[0000833444-24-000064:mdna:10]
and delivering technologies and solutions to create smart, sustainable and healthy buildings. The Company is investing in new digital and product capabilities, including its OpenBlue platform, to enable it to deliver sustainable, high-efficiency products and tailored services to enable customers to achieve their objectives. The Company is leveraging its install base, together with data-driven products and services to offer outcome-based solutions to customers with a focus on generating accelerated growth in services and recurring revenue.

[0000833444-24-000064:mdna:11]
The Company has experienced, and could continue to experience, increased material cost inflation and component shortages, as well as disruptions and delays in its supply chain, as a result of global macroeconomic trends, including increased global demand, geopolitical and economic tensions, including the conflict between Russia and Ukraine and Israel and Hamas, and labor shortages. Actions taken by the Company to mitigate supply chain disruptions and inflation, including expanding and redistributing its supplier network, supplier financing, price increases and productivity improvements, have historically been successful in offsetting some, but not all, of the impact of these trends. The collective impact of these trends has been favorable to revenue due to increased demand and price increases to offset inflation, while negatively impacting margins primarily due to ongoing cost pressures. Although the Company has experienced recent stabilization, it could experience further disruptions, and shortages and cost increases could occur in the future, the effect of which will depend on the Company’s ability to successfully mitigate and offset the impact of these events.

[0000833444-24-000064:mdna:12]
The extent to which the Company’s results of operations and financial condition are impacted by these and other factors in the future will depend on developments that are highly uncertain and cannot be predicted. See Part I, Item 1A, of this Annual Report on Form 10-K for an additional discussion of risks.

[0000833444-24-000064:mdna:13]
Portfolio Simplification Transactions

[0000833444-24-000064:mdna:14]
The Company has been engaged in an ongoing evaluation of its non-core product lines in connection with its objective to be a pure-play provider of comprehensive solutions for commercial buildings. During the fourth quarter of fiscal 2024, the Company completed the sale of its Air Distribution Technologies business included within the Global Products segment. During the fourth quarter of fiscal 2024, the Company entered into a definitive agreement to sell its Residential and Light Commercial ("R&LC") HVAC business to Robert Bosch GmbH (“Bosch”) for approximately $8.1 billion in cash with the Company's portion of the aggregate consideration being approximately $6.7 billion, inclusive of an upfront royalty payment for the licensing of the York tradename. The R&LC HVAC business includes the Company's North America Ducted business and Johnson Controls-Hitachi Air Conditioning Holding (UK) Ltd., the Company’s global residential joint venture with Hitachi Global Life Solutions, Inc. (“Hitachi”), of which the Company owns 60% and Hitachi owns 40%. The R&LC HVAC business, which was previously reported in the Global Products segment, meets the criteria to be classified as a discontinued operation and, as a result, its historical financial results are reflected in the consolidated financial statements as a discontinued operation, and assets and liabilities were reclassified as held for sale for all periods presented. The Company expects that the sale of the R&LC HVAC business will close in the fourth quarter of fiscal 2025.

[0000833444-24-000064:mdna:15]
Cybersecurity Incident

[0000833444-24-000064:mdna:16]
During the weekend of September 23, 2023, the Company experienced a cybersecurity incident impacting its internal information technology ("IT") infrastructure and applications. The cybersecurity incident consisted of unauthorized access, data exfiltration and deployment of ransomware by a third party to a portion of the Company's internal IT infrastructure. The incident caused disruptions and limitation of access to portions of the Company's business applications supporting aspects of the Company's operations and corporate functions, which disruptions and limitations continued into the first quarter of fiscal 2024.

[0000833444-24-000064:mdna:17]
The Company’s investigation and remediation efforts remain ongoing, including the analysis of data accessed, exfiltrated or otherwise impacted during the cybersecurity incident. Based on the information reviewed to date, the Company has not observed evidence of any impact to its digital products, services and solutions, including OpenBlue and Metasys.

[0000833444-24-000064:mdna:18]
The overall impact of the cybersecurity incident did not have a material impact on net income, net of insurance recoveries, or cash flows from operations in fiscal 2024.

[0000833444-24-000064:mdna:19]
The Company maintains insurance covering certain losses associated with cybersecurity incidents. A substantial portion of  direct costs incurred related to containing, investigating and remediating the incident, as well as business interruption losses, have been or are expected to be reimbursed through insurance recoveries. The timing of recognizing insurance recoveries may differ from the timing of recognizing the associated expenses.

[0000833444-24-000064:mdna:20]
Restructuring and Cost Optimization Initiatives

[0000833444-24-000064:mdna:21]
During the fourth quarter of fiscal 2024, the Company committed to a multi-year restructuring plan to address stranded costs and further right-size its global operations as a result of previously announced portfolio simplification actions. It is expected that one-time restructuring costs, including severance and other employee termination benefits, contract termination costs, and certain other related cash and non-cash charges, of approximately $400 million will be incurred over the course of fiscal 2025, 2026 and 2027, resulting in expected annual cost savings of approximately $500 million upon full completion of the plan. The Company’s ability to execute the most significant aspects of the restructuring plan will be dependent on the timing of the close of the R&LC HVAC business divestiture transaction. Accordingly, the Company is unable to estimate the specific costs to be incurred and savings to be achieved in fiscal 2025; however, depending on the timing of the closing of the transaction and the ability to execute more significant aspects of the planned restructuring actions, the impact of costs on net income could be material in fiscal 2025. Restructuring costs will be incurred across all segments and Corporate functions.

[0000833444-24-000064:mdna:22]
FISCAL YEAR 2024 COMPARED TO FISCAL YEAR 2023

[0000833444-24-000064:mdna:23]
Net Sales

[0000833444-24-000064:mdna:24]
|  | Year Ended September 30, |  |  |
| (in millions) | 2024 |  | 2023 |  | Change |
| Net sales | $ | 22,952 |  |  | $ | 22,331 |  |  | 3 | % |

[0000833444-24-000064:mdna:25]
The increase in net sales was due to higher organic sales ($790 million), partially offset by the negative impact of foreign currency translation ($98 million) and the net impact of acquisitions and divestitures ($71 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales increased 4% over the prior year, as strong growth in Products and Systems in the Building Solutions North America segment and growth in Services in all Building Solutions segments were partially offset primarily by weakness in China's Systems/Install business. Refer to the "Segment Analysis" below within Item 7 for a discussion of net sales by segment.

[0000833444-24-000064:mdna:26]
Cost of Sales / Gross Profit

[0000833444-24-000064:mdna:27]
|  | Year Ended September 30, |  |  |
| (in millions) | 2024 |  | 2023 |  | Change |
| Cost of sales | $ | 14,875 |  |  | $ | 14,527 |  |  | 2 | % |
| Gross profit | 8,077 |  |  | 7,804 |  |  | 3 | % |
| % of sales | 35.2 | % |  | 34.9 | % |  |  |

[0000833444-24-000064:mdna:28]
The increase in gross profit was primarily due to higher gross profit in the Systems/Install and Services businesses of the Building Solutions segments, partially offset by the Global Products segment. Refer to the "Segment Analysis" below within Item 7 for a discussion of segment earnings before interest, taxes and amortization ("EBITA").

[0000833444-24-000064:mdna:29]
Selling, General and Administrative Expenses

[0000833444-24-000064:mdna:30]
|  | Year Ended September 30, |  |  |
| (in millions) | 2024 |  | 2023 |  | Change |
| Selling, general and administrative expenses | $ | 5,661 |  |  | $ | 5,387 |  |  | 5 | % |
| % of sales | 24.7 | % |  | 24.1 | % |  |  |

[0000833444-24-000064:mdna:31]
The increase in selling, general and administrative expenses ("SG&A") was primarily due to the net impact of the water systems AFFF settlement agreement costs net of insurance recoveries ($383 million), partially offset by the year-over-year impact of net mark-to-market adjustments ($100 million) and productivity improvements. Refer to the "Segment Analysis" below within Item 7 for a discussion of segment EBITA.

[0000833444-24-000064:mdna:32]
Restructuring and Impairment Costs

[0000833444-24-000064:mdna:33]
|  |  |  | Year Ended September 30, |
| (in millions) |  |  | 2024 |  | 2023 |
| Goodwill and other intangible asset impairments |  |  | $ | 296 |  |  | $ | 212 |  |
| Held for sale impairments |  |  | 35 |  |  | 498 |  |
| Long-lived and other tangible asset impairments |  |  | 36 |  |  | 78 |  |
| Restructuring and related costs |  |  | 143 |  |  | 261 |  |
| Restructuring and impairment costs |  |  | $ | 510 |  |  | $ | 1,049 |  |

[0000833444-24-000064:mdna:34]
Refer to Note 2, "Acquisitions and Divestitures," "Note 3, "Assets and Liabilities Held for Sale and Discontinued Operations," Note 7, "Property, Plant and Equipment," Note 8, "Goodwill and Other Intangible Assets," and Note 17, "Restructuring and Related Costs," of the notes to consolidated financial statements for further disclosure related to the Company's restructuring plans and impairment costs.

[0000833444-24-000064:mdna:35]
Net Financing Charges

[0000833444-24-000064:mdna:36]
|  | Year Ended September 30, |  |  |  |
|  | 2024 |  | 2023 |  |  |  |
| Interest expense, net of capitalized interest costs | $ | 381 |  |  | $ | 297 |  |  |  |  |
| Other financing charges | 38 |  |  | 50 |  |  |  |  |
| Gain on debt extinguishment | (25) |  |  | (25) |  |  |  |  |
| Interest income | (17) |  |  | (17) |  |  |  |  |
| Net foreign exchange on financing activities | (35) |  |  | (47) |  |  |  |  |
| Net financing charges | $ | 342 |  |  | $ | 258 |  |  |  |  |

[0000833444-24-000064:mdna:37]
* Measure not meaningful

[0000833444-24-000064:mdna:38]
Refer to Note 10, "Debt and Financing Arrangements," of the notes to consolidated financial statements for further disclosure related to the Company's debt.

[0000833444-24-000064:mdna:39]
Income Tax Provision (Benefit)

[0000833444-24-000064:mdna:40]
|  | Year Ended September 30, |  |  |
| (in millions) | 2024 |  | 2023 |  | Change |
| Income tax provision (benefit) | $ | 111 |  |  | $ | (468) |  |  | * |
| Effective tax rate | 7 | % |  | (42) | % |  |  |

[0000833444-24-000064:mdna:41]
* Measure not meaningful

[0000833444-24-000064:mdna:42]
The fiscal 2024 effective tax rate was higher than fiscal 2023 primarily due to the establishment of a deferred tax liability on the outside basis difference of the Company’s investment in certain subsidiaries as a result of the planned divestiture of its R&LC HVAC business, partially offset by lower tax reserve adjustments as the result of tax audit resolutions and expired statute of limitations for certain tax years, valuation allowance adjustments and the benefits of continuing global tax planning initiatives. Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements for further details.

[0000833444-24-000064:mdna:43]
In October 2021, the Organization for Economic Co-operation and Development ("OECD")/G20 inclusive framework on Base Erosion and Profit Shifting (the Inclusive Framework) published a statement updating and finalizing the key components of a two-pillar plan on global tax reform which has now been agreed upon by the majority of OECD members. Pillar One allows countries to reallocate a portion of residual profits earned by multinational enterprises ("MNE"), with an annual global revenue exceeding €20 billion and a profit margin over 10%, to other market jurisdictions. The adoption of Pillar One and its potential effective date remain uncertain. Pillar Two requires MNEs with an annual global revenue exceeding €750 million to pay a

[0000833444-24-000064:mdna:44]
35

[0000833444-24-000064:mdna:45]
global minimum tax of 15%. The OECD has since issued administrative guidance providing transition and safe harbor rules around the implementation of the Pillar Two global minimum tax. A number of countries, including Ireland, have enacted legislation to implement the core elements of Pillar Two, which will be effective for the Company beginning in fiscal 2025. The Company continues to evaluate the impact on future periods of Pillar Two, including legislative updates and adoption by additional countries, which could result in an increase to the effective tax rate.

[0000833444-24-000064:mdna:46]
Income From Discontinued Operations, Net of Tax

[0000833444-24-000064:mdna:47]
|  | Year Ended September 30, |  |  |
| (in millions) | 2024 |  | 2023 |  | Change |
| Income from discontinued operations, net of tax | $ | 489 |  |  | $ | 452 |  |  | 8 | % |

[0000833444-24-000064:mdna:48]
The increase in income from discontinued operations, net of tax was primarily due to decreased SG&A as a result of productivity improvements. Refer to Note 3, "Assets and Liabilities Held for Sale and Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-24-000064:mdna:49]
FISCAL YEAR 2023 COMPARED TO FISCAL YEAR 2022

[0000833444-24-000064:mdna:50]
Net Sales

[0000833444-24-000064:mdna:51]
|  | Year Ended September 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |
| Net sales | $ | 22,331 |  |  | $ | 20,637 |  |  | 8 | % |

[0000833444-24-000064:mdna:52]
The increase in net sales was due to higher organic sales ($1,947 million) and the net impact of acquisitions and divestitures ($113 million), partially offset by the negative impact of foreign currency translation ($366 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales increased 9% over the prior year, attributable to increased pricing in response to inflation pressures. Refer to the "Segment Analysis" below within Item 7 for a discussion of net sales by segment.

[0000833444-24-000064:mdna:53]
Cost of Sales / Gross Profit

[0000833444-24-000064:mdna:54]
|  | Year Ended September 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |
| Cost of sales | $ | 14,527 |  |  | $ | 13,547 |  |  | 7 | % |
| Gross profit | 7,804 |  |  | 7,090 |  |  | 10 | % |
| % of sales | 34.9 | % |  | 34.4 | % |  |  |

[0000833444-24-000064:mdna:55]
Gross profit increased due to organic sales growth and favorable price/cost, partially offset by the negative impact of foreign currency translation and the year-over-year impact of net pension mark-to-market adjustments ($42 million). Refer to the "Segment Analysis" below within Item 7 for a discussion of segment earnings before interest, taxes and amortization ("EBITA").

[0000833444-24-000064:mdna:56]
Selling, General and Administrative Expenses

[0000833444-24-000064:mdna:57]
|  | Year Ended September 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |
| Selling, general and administrative expenses | $ | 5,387 |  |  | $ | 5,078 |  |  | 6 | % |
| % of sales | 24.1 | % |  | 24.6 | % |  |  |

[0000833444-24-000064:mdna:58]
The increase in SG&A was primarily due to certain investments to support growth, transaction and separation costs, the year-over-year impact of net mark-to-market adjustments ($71 million) and a loss associated with a fire at a leased warehouse facility ($40 million), partially offset by the absence of non-recurring environmental remediation charges in the prior year ($255

[0000833444-24-000064:mdna:59]
36

[0000833444-24-000064:mdna:60]
million) and positive foreign currency translation. Refer to the "Segment Analysis" below within Item 7 for a discussion of segment EBITA.

[0000833444-24-000064:mdna:61]
Restructuring and Impairment Costs

[0000833444-24-000064:mdna:62]
|  |  |  | Year Ended September 30, |
| (in millions) |  |  | 2023 |  | 2022 |
| Goodwill and other intangible assets impairments |  |  | $ | 212 |  |  | $ | 310 |  |
| Held for sale impairments |  |  | 498 |  |  | 229 |  |
| Long-lived asset impairments |  |  | 78 |  |  | — |  |
| Restructuring and related costs |  |  | 261 |  |  | 162 |  |
| Restructuring and impairment costs |  |  | $ | 1,049 |  |  | $ | 701 |  |

[0000833444-24-000064:mdna:63]
Refer to Note 2, "Acquisitions and Divestitures," Note 3, "Assets and Liabilities Held for Sale and Discontinued Operations," Note 7, "Property, Plant and Equipment," Note 8, "Goodwill and Other Intangible Assets," and Note 17, "Restructuring and Related Costs," of the notes to consolidated financial statements for further disclosure related to the Company's restructuring plans and impairment costs.

[0000833444-24-000064:mdna:64]
Net Financing Charges

[0000833444-24-000064:mdna:65]
|  | Year Ended September 30, |  |  |  |
|  | 2023 |  | 2022 |  |  |  |
| Interest expense, net of capitalized interest costs | $ | 297 |  |  | $ | 221 |  |  |  |  |
| Other financing charges | 50 |  |  | 27 |  |  |  |  |
| Gain on debt extinguishment | (25) |  |  | — |  |  |  |  |
| Interest income | (17) |  |  | (6) |  |  |  |  |
| Net foreign exchange results for financing activities | (47) |  |  | (37) |  |  |  |  |
| Net financing charges | $ | 258 |  |  | $ | 205 |  |  |  |  |

[0000833444-24-000064:mdna:66]
Refer to Note 10, "Debt and Financing Arrangements," of the notes to consolidated financial statements for further disclosure related to the Company's debt.

[0000833444-24-000064:mdna:67]
Income Tax Provision (Benefit)

[0000833444-24-000064:mdna:68]
|  | Year Ended September 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |
| Income tax provision (benefit) | $ | (468) |  |  | $ | (182) |  |  | * |
| Effective tax rate | (42) | % |  | (16) | % |  |  |

[0000833444-24-000064:mdna:69]
* Measure not meaningful

[0000833444-24-000064:mdna:70]
The statutory tax rate in Ireland of 12.5% is being used as a comparison since the Company is domiciled in Ireland.

[0000833444-24-000064:mdna:71]
For fiscal 2023, the effective tax rate for continuing operations was (42)% and was lower than the statutory tax rate primarily due to the favorable tax impacts of intellectual property tax adjustments, tax reserve adjustments as the result of tax audit resolutions and remeasurements, valuation allowance adjustments and the benefits of continuing global tax planning initiatives, partially offset by the unfavorable impact of impairment and restructuring charges.

[0000833444-24-000064:mdna:72]
For fiscal 2022, the effective tax rate for continuing operations was (16%) and was lower than the statutory tax rate primarily due to the favorable impact of tax reserve adjustments as the result of expired statute of limitations for certain tax years and the benefits of continuing global tax planning initiatives, partially offset by the unfavorable impact of impairment and restructuring charges and the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries as a result of the planned divestitures.

[0000833444-24-000064:mdna:73]
Income From Discontinued Operations, Net of Tax

[0000833444-24-000064:mdna:74]
|  | Year Ended September 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |
| Income from discontinued operations, net of tax | $ | 452 |  |  | $ | 429 |  |  | 5 | % |

[0000833444-24-000064:mdna:75]
The increase in income from discontinued operations, net of tax was primarily due to decreased SG&A as a result of productivity improvements. Refer to Note 3, "Assets and Liabilities Held for Sale & Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-24-000064:mdna:76]
SEGMENT ANALYSIS

[0000833444-24-000064:mdna:77]
Management evaluates the performance of its segments primarily on segment earnings before interest, taxes and amortization ("EBITA"), which represents income from continuing operations before income taxes and noncontrolling interests, excluding  amortization of intangible assets, corporate expenses, restructuring and impairment costs, the water systems AFFF settlement costs and AFFF insurance recoveries, net financing charges, loss on divestiture and net mark-to-market gains and losses related to pension and postretirement plans and restricted asbestos investments.

[0000833444-24-000064:mdna:78]
|  | Net Salesfor the Year EndedSeptember 30, |  |  |  | Segment EBITAfor the Year EndedSeptember 30, |  |  |
| (in millions) | 2024 |  | 2023 |  | Change |  | 2024 |  | 2023 |  | Change |
| Building Solutions North America | $ | 11,348 |  |  | $ | 10,330 |  |  | 10 | % |  | $ | 1,663 |  |  | $ | 1,394 |  |  | 19 | % |
| Building Solutions EMEA/LA | 4,296 |  |  | 4,096 |  |  | 5 | % |  | 391 |  |  | 316 |  |  | 24 | % |
| Building Solutions Asia Pacific | 2,237 |  |  | 2,746 |  |  | (19) | % |  | 261 |  |  | 343 |  |  | (24) | % |
| Global Products | 5,071 |  |  | 5,159 |  |  | (2) | % |  | 1,403 |  |  | 1,317 |  |  | 7 | % |
|  | $ | 22,952 |  |  | $ | 22,331 |  |  | 3 | % |  | $ | 3,718 |  |  | $ | 3,370 |  |  | 10 | % |

[0000833444-24-000064:mdna:79]
Net Sales

[0000833444-24-000064:mdna:80]
•The increase in Building Solutions North America was due to organic growth ($957 million), incremental sales related to business acquisitions ($48 million) and the positive impact of foreign currency translation ($13 million). Excluding the impacts of foreign currency translation and business acquisitions, sales growth was led by growth in Applied HVAC & Controls.

[0000833444-24-000064:mdna:81]
•The increase in Building Solutions EMEA/LA was due to organic growth, including higher prices ($233 million) and the net impact of business acquisitions and divestitures ($6 million), partially offset by the negative impact of foreign currency translation ($39 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, sales growth was led by growth in Services.

[0000833444-24-000064:mdna:82]
•The decrease in Building Solutions Asia Pacific was primarily due to organic sales declines ($440 million), the negative impact of foreign currency translation ($62 million) and the net impact of business acquisitions and divestitures ($7 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, sales decreased as Services growth was more than offset by weakness in the China Systems business.

[0000833444-24-000064:mdna:83]
•The decrease in Global Products was due to the net impact of business acquisitions and divestitures ($118 million) and the negative impact of foreign currency translation ($10 million), partially offset by organic growth ($40 million). Excluding the impacts of foreign currency translation and business acquisitions and divestitures, sales increased as growth in Commercial HVAC was more than offset by declines in Fire & Security and Industrial Refrigeration.

[0000833444-24-000064:mdna:84]
Segment EBITA

[0000833444-24-000064:mdna:85]
•The increase in Building Solutions North America was primarily due to higher margin backlog conversion and continued growth in Services. A favorable earn-out liability adjustment also contributed to the increase.

[0000833444-24-000064:mdna:86]
38

[0000833444-24-000064:mdna:87]
•The increase in Building Solutions EMEA/LA was primarily due to growth in higher margin Services and productivity improvements.

[0000833444-24-000064:mdna:88]
•The decrease in Building Solutions Asia Pacific was primarily due to continued weakness in the Systems business in China.

[0000833444-24-000064:mdna:89]
•The increase in Global Products was primarily driven by operational efficiencies leading to productivity improvements.

[0000833444-24-000064:mdna:90]
|  | Net Salesfor the Year EndedSeptember 30, |  |  |  | Segment EBITAfor the Year EndedSeptember 30, |  |  |
| (in millions) | 2023 |  | 2022 |  | Change |  | 2023 |  | 2022 |  | Change |
| Building Solutions North America | $ | 10,330 |  |  | $ | 9,367 |  |  | 10 | % |  | $ | 1,394 |  |  | $ | 1,122 |  |  | 24 | % |
| Building Solutions EMEA/LA | 4,096 |  |  | 3,845 |  |  | 7 | % |  | 316 |  |  | 358 |  |  | (12) | % |
| Building Solutions Asia Pacific | 2,746 |  |  | 2,714 |  |  | 1 | % |  | 343 |  |  | 332 |  |  | 3 | % |
| Global Products | 5,159 |  |  | 4,711 |  |  | 10 | % |  | 1,317 |  |  | 970 |  |  | 36 | % |
|  | $ | 22,331 |  |  | $ | 20,637 |  |  | 8 | % |  | $ | 3,370 |  |  | $ | 2,782 |  |  | 21 | % |

[0000833444-24-000064:mdna:91]
Net Sales

[0000833444-24-000064:mdna:92]
•The increase in Building Solutions North America was due to organic growth, including higher prices ($979 million) and incremental sales related to business acquisitions ($29 million), partially offset by the negative impact of foreign currency translation ($45 million). Excluding the impacts of business acquisitions and foreign currency translation, sales growth was led by growth in HVAC & Controls and Fire & Security.

[0000833444-24-000064:mdna:93]
•The increase in Building Solutions EMEA/LA was due to organic growth, including higher prices ($324 million) and the net impact of business acquisitions and divestitures ($29 million), partially offset by the negative impact of foreign currency translation ($102 million). Excluding the impacts of foreign currency translation and business acquisitions and divestitures, sales growth was led by growth in Fire & Security and HVAC & Controls.

[0000833444-24-000064:mdna:94]
•The increase in Building Solutions Asia Pacific was due to organic growth, including higher prices ($182 million) and the net impact of business acquisitions and divestitures ($19 million), partially offset by the negative impact of foreign currency translation ($169 million). The economic conditions in China, specifically challenges in real estate, began negatively impacting the Building Solutions Asia Pacific segment in the fourth quarter of fiscal 2023, but had an insignificant impact on results for the full year. Excluding the impacts of foreign currency translation and business acquisitions and divestitures, sales growth was led by continued demand for HVAC & Controls.

[0000833444-24-000064:mdna:95]
•The increase in Global Products was due to the net impact of higher prices and lower volumes ($462 million) and incremental sales related to business acquisitions ($36 million), partially offset by the negative impact of foreign currency translation ($50 million). Excluding the impacts of foreign currency translation and business acquisitions, sales growth was driven by strong price realization and growth in Commercial HVAC and Industrial Refrigeration products.

[0000833444-24-000064:mdna:96]
Segment EBITA

[0000833444-24-000064:mdna:97]
•The increase in Building Solutions North America was primarily due to favorable price/cost, volume leverage and productivity savings, partially offset by unfavorable project mix.

[0000833444-24-000064:mdna:98]
•The decrease in Building Solutions EMEA/LA reflects the negative impact of foreign currency translation ($13 million) and higher expenses, partially offset by favorable price/cost.

[0000833444-24-000064:mdna:99]
•The increase in Building Solutions Asia Pacific was primarily due to favorable price/cost and productivity savings, partially offset by the negative impact of foreign currency translation ($25 million).

[0000833444-24-000064:mdna:100]
•The increase in Global Products was primarily due to favorable price/cost and productivity savings, partially offset by unfavorable mix, lower gross margin due to lower manufacturing absorption, an uninsured loss associated with a fire at a leased warehouse facility and the negative impact of foreign currency translation.

[0000833444-24-000064:mdna:101]
LIQUIDITY AND CAPITAL RESOURCES

[0000833444-24-000064:mdna:102]
Working Capital

[0000833444-24-000064:mdna:103]
|  | September 30, |  |  |
| (in millions) | 2024 |  | 2023 |  | Change |
| Current assets | $ | 11,179 |  |  | $ | 10,737 |  |  |  |
| Current liabilities | (11,955) |  |  | (11,084) |  |  |  |
|  | (776) |  |  | (347) |  |  | * |
| Less: Cash and cash equivalents | (606) |  |  | (828) |  |  |  |
| Add: Short-term debt | 953 |  |  | 361 |  |  |  |
| Add: Current portion of long-term debt | 536 |  |  | 645 |  |  |  |
| Less: Current assets held for sale | (1,595) |  |  | (1,552) |  |  |  |
| Add: Current liabilities held for sale | 1,431 |  |  | 1,375 |  |  |  |
| Working capital (as defined) | $ | (57) |  |  | $ | (346) |  |  | * |
| Accounts receivable - net | $ | 6,051 |  |  | $ | 5,494 |  |  | 10 | % |
| Inventories | 1,774 |  |  | 1,872 |  |  | (5) | % |
| Accounts payable | 3,389 |  |  | 3,498 |  |  | (3) | % |

[0000833444-24-000064:mdna:104]
* Measure not meaningful

[0000833444-24-000064:mdna:105]
•The Company defines working capital as current assets less current liabilities, excluding cash and cash equivalents, short-term debt, the current portion of long-term debt, and current assets and liabilities held for sale (when applicable). Management believes that this measure of working capital, which excludes financing-related items and businesses to be divested, provides a more useful measurement of the Company’s operating performance.

[0000833444-24-000064:mdna:106]
•The increase in working capital (as defined) at September 30, 2024 as compared to September 30, 2023 was primarily due to an increase in accounts receivable primarily due to discontinuing the receivable factoring program during the current year, partially offset by an increase in deferred revenue and accrued compensation and benefits.

[0000833444-24-000064:mdna:107]
Cash Flows From Continuing Operations

[0000833444-24-000064:mdna:108]
|  | Year Ended September 30, |
| (in millions) | 2024 |  | 2023 |
| Cash provided by operating activities | $ | 1,568 |  |  | $ | 1,856 |  |
| Cash used by investing activities | (184) |  |  | (1,093) |  |
| Cash used by financing activities | (1,948) |  |  | (2,059) |  |

[0000833444-24-000064:mdna:109]
•The decrease in cash provided by operating activities reflects lower net income and the impact of higher accounts receivable and other asset balances, which was partially offset by the timing of accounts payable and accrued liabilities payments.

[0000833444-24-000064:mdna:110]
•The decrease in cash used by investing activities was primarily due to the net impact of proceeds from the ADTi divestiture in fiscal 2024 and cash paid for the FM:Systems acquisition in fiscal 2023. Refer to Note 2, "Acquisitions and Divestitures," of the notes to the consolidated financial statements for further disclosure related to acquisitions and divestitures.

[0000833444-24-000064:mdna:111]
•The decrease in cash used by financing activities was primarily due to changes in short- and long-term borrowing activity and stock repurchase activity. The net impact of debt proceeds and repayments generated cash of $405 million

[0000833444-24-000064:mdna:112]
in fiscal 2024 and used cash of $457 million in fiscal 2023. This increase in cash used was substantially offset by higher stock repurchases.

[0000833444-24-000064:mdna:113]
Capitalization

[0000833444-24-000064:mdna:114]
|  | September 30, |  |
| (in millions) | 2024 |  | 2023 |  |
| Short-term debt | $ | 953 |  |  | $ | 361 |  |  |
| Current portion of long-term debt | 536 |  |  | 645 |  |  |
| Long-term debt | 8,004 |  |  | 7,818 |  |  |
| Total debt | 9,493 |  |  | 8,824 |  |  |
| Less: Cash and cash equivalents | 606 |  |  | 828 |  |  |
| Net debt | $ | 8,887 |  |  | $ | 7,996 |  |  |
| Shareholders’ equity attributable to Johnson Controls ("Equity") | $ | 16,098 |  |  | $ | 16,545 |  |  |
| Total capitalization (Total debt plus Equity) | 25,591 |  |  | 25,369 |  |  |
| Net capitalization (Net debt plus Equity) | 24,985 |  |  | 24,541 |  |  |
| Total net debt as a % of Total capitalization | 34.7 | % |  | 31.5 | % |  |
| Total net debt as a % of Net capitalization | 35.6 | % |  | 32.6 | % |  |

[0000833444-24-000064:mdna:115]
•Net debt and net debt as a percentage of total capitalization are non-GAAP financial measures. The Company believes the percentage of total net debt to total capitalization is useful to understanding the Company’s financial condition as it provides a view of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders.

[0000833444-24-000064:mdna:116]
•The Company's material cash requirements primarily consist of working capital requirements, repayments of long-term debt and related interest, operating leases, dividends, capital expenditures, potential acquisitions and share repurchases.

[0000833444-24-000064:mdna:117]
•Refer to Note 10, "Debt and Financing Arrangements," of the notes to consolidated financial statements for additional information on debt obligations and maturities. Interest payable on long-term debt outstanding as of September 30, 2024 is $299 million in the twelve months following September 30, 2024 and $3.4 billion thereafter.

[0000833444-24-000064:mdna:118]
•Refer to Note 9, "Leases," of the notes to consolidated financial statements for additional information on lease obligations and maturities.

[0000833444-24-000064:mdna:119]
•As of September 30, 2024, the Company had purchase obligations which were payable in the next twelve months of approximately $2 billion and payable thereafter of approximately $120 million, substantially all of which relate to continuing operations. These purchase obligations represent commitments under enforceable and legally binding agreements, and do not represent all future expected purchases.

[0000833444-24-000064:mdna:120]
•As of September 30, 2024, the Company expects to contribute $25 million and $204 million, of which $22 million and $179 million relates to continuing operations, to the global pension and postretirement plans in the next twelve months and thereafter, respectively.

[0000833444-24-000064:mdna:121]
•As of September 30, 2024, approximately $1.7 billion remains available under the Company's share repurchase authorization, which does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. The Company expects to repurchase outstanding shares from time to time depending on market conditions, alternate uses of capital, liquidity and economic environment.

[0000833444-24-000064:mdna:122]
•The Company declared dividends of $1.48 per share in fiscal 2024 and intends to continue paying quarterly dividends in fiscal 2025.

[0000833444-24-000064:mdna:123]
•The Company believes its capital resources and liquidity position, including cash and cash equivalents of $606 million at September 30, 2024, are adequate to fund operations and meet its obligations for the foreseeable future. The Company expects requirements for working capital, capital expenditures, dividends, minimum pension contributions,

[0000833444-24-000064:mdna:124]
debt maturities and any potential acquisitions or stock repurchases in fiscal 2025 will be funded from operations, supplemented by short- and long-term borrowings, if required.

[0000833444-24-000064:mdna:125]
–The Company manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. Commercial paper outstanding was $350 million as of September 30, 2024 and $200 million as of September 30, 2023.

[0000833444-24-000064:mdna:126]
–The Company maintains a shelf registration statement with the SEC under which it may issue additional debt securities, ordinary shares, preferred shares, depository shares, warrants, purchase contracts and units that may be offered in one or more offerings on terms to be determined at the time of the offering. The Company anticipates that the proceeds of any offering would be used for general corporate purposes, including repayment of indebtedness, acquisitions, additions to working capital, repurchases of ordinary shares, dividends, capital expenditures and investments in the Company's subsidiaries.

[0000833444-24-000064:mdna:127]
–The Company has the ability to draw on its syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2028, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2024. There were no draws on the facilities as of September 30, 2024.

[0000833444-24-000064:mdna:128]
•The Company's ability to access the global capital markets and the related cost of financing is dependent upon, among other factors, the Company's credit ratings. As of September 30, 2024, the Company's credit ratings and outlook were as follows:

[0000833444-24-000064:mdna:129]
| Rating Agency |  | Short-Term Rating |  | Long-Term Rating |  | Outlook |
| S&P |  | A-2 |  | BBB+ |  | Stable |
| Moody's |  | P-2 |  | Baa2 |  | Positive |

[0000833444-24-000064:mdna:130]
The security ratings set forth above are issued by unaffiliated third-party rating agencies and are not a recommendation to buy, sell or hold securities. The ratings may be subject to revision or withdrawal by the assigning rating organization at any time.

[0000833444-24-000064:mdna:131]
•The Company entered into the following debt transactions in fiscal 2024:

[0000833444-24-000064:mdna:132]
–Repaid $924 million of debt including the following:

[0000833444-24-000064:mdna:133]
▪$484 million Senior Notes due 2024 with interest rates of 3.625%

[0000833444-24-000064:mdna:134]
▪€300 million term loans with interest rates of Euro Interbank Offered Rate (" EURIBOR")  plus 0.4% to 0.7%

[0000833444-24-000064:mdna:135]
▪Tendered $119 million of its Notes due 2045 with an interest rate of 5.125%

[0000833444-24-000064:mdna:136]
–Issued $1.3 billion of debt including the following:

[0000833444-24-000064:mdna:137]
▪Together with its wholly owned subsidiary, Tyco Fire & Security Finance S.C.A., co-issued $700 million in 5.50% Senior Notes due in April 2029

[0000833444-24-000064:mdna:138]
▪€450 million short-term term loans with interest rates of EURIBOR plus 0.65% to 0.78% due in the first quarter of fiscal 2025

[0000833444-24-000064:mdna:139]
▪$100 million short-term term loan with an interest rate of 5.9% which is due in December 2024

[0000833444-24-000064:mdna:140]
•The Company expects to receive net cash proceeds related to the sale of its R&LC HVAC business of approximately $5.0 billion after tax and transaction-related expenses when the transaction closes, likely in the fourth quarter of fiscal 2025. Consistent with its capital allocation policy, the Company expects to use a portion of the proceeds to pay down debt to the extent required to retain its investment grade rating, with the remaining proceeds expected to be returned to shareholders through share repurchases.

[0000833444-24-000064:mdna:141]
•On April 12, 2024, Tyco Fire Products agreed to a settlement with a nationwide class of public water systems that detected PFAS in their drinking water systems that they allege to be associated with the use of AFFF. Under the terms of the agreement, Tyco Fire Products agreed to contribute $750 million to resolve these PFAS claims. Tyco Fire Products contributed an initial payment of $250 million in June 2024, with the remaining $500 million due by the first quarter of fiscal 2025. Prior to the date of the final contribution, Tyco Fire Products has agreed to contribute any applicable insurance recoveries in excess of the initial $250 million payment, up to the remaining $500 million due, within a specified period following the receipt of such recovery. During fiscal 2024, the Company recorded expected insurance recoveries of $371 million in selling, general and administrative expenses in the consolidated statements of income and collected insurance recoveries of $349 million. In accordance with its agreement and recent insurance

[0000833444-24-000064:mdna:142]
recovery, Tyco Fire Products made an additional payment during the fourth quarter of fiscal 2024 of approximately $85 million, reducing its final payment to approximately $415 million. The amounts and timing of any additional insurance recoveries are uncertain. Refer to Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for additional discussion of the water systems settlement.

[0000833444-24-000064:mdna:143]
•Financial covenants in the Company's revolving credit facilities require a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of ASC 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of September 30, 2024, the Company was in compliance with all financial covenants set forth in its credit agreements and the indentures governing its outstanding notes, and expects to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-24-000064:mdna:144]
•The Company earns a significant amount of its income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be indefinitely reinvested except in limited circumstances. However, in fiscal 2024, the Company recorded income tax expense related to a change in the Company's assertion over the outside basis differences of the Company’s investment in certain subsidiaries as a result of the planned divestiture of its R&LC HVAC business. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. The Company's intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at the Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings.

[0000833444-24-000064:mdna:145]
•The Company may from time to time purchase its outstanding debt through open market purchases, privately negotiated transactions or otherwise. Purchases or retirement of debt, if any, will depend on prevailing market conditions, liquidity requirements, contractual restrictions and other factors. The amounts involved may be material.

[0000833444-24-000064:mdna:146]
Co-Issued Securities: Summarized Financial Information

[0000833444-24-000064:mdna:147]
The following information is provided in compliance with Rule 13-01 of Regulation S-X under the Securities Exchange Act of 1934 with respect to the following unsecured, unsubordinated senior notes (collectively, "the Notes") which were issued by Johnson Controls International plc ("Parent Company") and Tyco Fire & Security Finance S.C.A. (“TFSCA”):

[0000833444-24-000064:mdna:148]
•€500 million aggregate principal amount of 0.375% Senior Notes due 2027

[0000833444-24-000064:mdna:149]
•€600 million aggregate principal amount of 3.000% Senior Notes due 2028

[0000833444-24-000064:mdna:150]
•$700 million aggregate principal amount of 5.500% Senior Notes due 2029

[0000833444-24-000064:mdna:151]
•$625 million aggregate principal amount of 1.750% Senior Notes due 2030

[0000833444-24-000064:mdna:152]
•$500 million aggregate principal amount of 2.000% Sustainability-Linked Senior Notes due 2031

[0000833444-24-000064:mdna:153]
•€500 million aggregate principal amount of 1.000% Senior Notes due 2032

[0000833444-24-000064:mdna:154]
•$400 million aggregate principal amount of 4.900% Senior Notes due 2032

[0000833444-24-000064:mdna:155]
•€800 million aggregate principal amount of 4.25% Senior Notes due 2035

[0000833444-24-000064:mdna:156]
TFSCA is a corporate partnership limited by shares (société en commandite par actions) incorporated and organized under the laws of the Grand Duchy of Luxembourg (“Luxembourg”) and is a wholly-owned consolidated subsidiary of the Company that is 99.924% owned directly by the Parent Company and 0.076% owned by TFSCA’s sole general partner and manager, Tyco Fire & Security S.à r.l., which is itself wholly-owned by the Company. The Parent Company is incorporated and organized under the laws of Ireland. TFSCA is incorporated and organized under the laws of Luxembourg. The bankruptcy, insolvency,

[0000833444-24-000064:mdna:157]
administrative, debtor relief and other laws of Luxembourg or Ireland, as applicable, may be materially different from, or in conflict with, those of the United States, including in the areas of rights of creditors, priority of governmental and other creditors, ability to obtain post-petition interest and duration of the proceeding. The application of these laws, or any conflict among them, could adversely affect noteholders’ ability to enforce their rights under the Notes in those jurisdictions or limit any amounts that they may receive.

[0000833444-24-000064:mdna:158]
The following table presents the net loss attributable to the Parent Company and TFSCA (collectively, the "Obligor Group") and the net income (loss) attributable to intercompany transactions between the Obligor Group and subsidiaries of the Parent Company other than TFSCA (collectively, the "Non-Obligor Subsidiaries") which are excluded from the Net loss attributable to the Obligor Group (in millions):

[0000833444-24-000064:mdna:159]
|  |  | Year Ended September 30, 2024 |  |  |  |
| Net loss attributable to the Obligor Group |  | $ | 609 |  |  |  |  |
| Net income attributable to intercompany transactions |  | 511 |  |  |  |  |

[0000833444-24-000064:mdna:160]
The following table presents summarized balance sheet information as of September 30, 2024 (in millions):

[0000833444-24-000064:mdna:161]
|  |  | ObligorGroup |  | Intercompany Balances |
| Current assets |  | $ | 1,339 |  |  | $ | 823 |  |
| Noncurrent assets |  | 243 |  |  | 7,522 |  |
| Current liabilities |  | 6,726 |  |  | 2,789 |  |
| Noncurrent liabilities |  | 7,836 |  |  | 9,028 |  |

[0000833444-24-000064:mdna:162]
The same accounting policies as described in Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements are used by the Parent Company and each of its subsidiaries in connection with the summarized financial information presented above.

[0000833444-24-000064:mdna:163]
CRITICAL ACCOUNTING ESTIMATES

[0000833444-24-000064:mdna:164]
The Company prepares its consolidated financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). This requires management to make estimates and assumptions that affect reported amounts and related disclosures. Actual results could differ from those estimates. The following estimates are considered by management to be the most critical to the understanding of the Company's consolidated financial statements as they require significant judgments that could materially impact the Company’s results of operations, financial position and cash flows.

[0000833444-24-000064:mdna:165]
Revenue Recognition

[0000833444-24-000064:mdna:166]
The Company recognizes revenue from certain long-term contracts on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. Total estimated costs at completion are based primarily on estimated purchase contract terms, historical performance trends and other economic projections. Factors that may result in a change to these estimates include unforeseen engineering problems, construction delays, cost inflation, the performance of subcontractors and major material suppliers, and weather conditions. As a result, changes to the original estimates may be required during the life of the contract. Such estimates are reviewed monthly and any adjustments to the measure of completion are recognized as adjustments to sales and gross profit using the cumulative catch-up method. Estimated losses are recorded when identified.

[0000833444-24-000064:mdna:167]
For agreements with multiple performance obligations, the Company allocates the transaction price of the contract to each performance obligation using the best estimate of the relative standalone selling price of each distinct good or service in the contract. In order to estimate relative standalone selling price, market data and transfer price studies are utilized. If the standalone selling price is not directly observable, the Company estimates the standalone selling price using an adjusted market assessment approach or expected cost plus margin approach.

[0000833444-24-000064:mdna:168]
The Company assesses variable consideration that may affect the total transaction price, including discounts, rebates, refunds, credits or other similar sources of variable consideration, when determining the transaction price of each contract. The Company includes variable consideration in the estimated transaction price when it is probable that significant reversal of

[0000833444-24-000064:mdna:169]
44

[0000833444-24-000064:mdna:170]
revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. These estimates are based on the amount of consideration that the Company expects to be entitled to.

[0000833444-24-000064:mdna:171]
Goodwill and Indefinite-Lived Intangible Assets

[0000833444-24-000064:mdna:172]
The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s operating segments or one level below the operating segments, using a qualitative assessment or a quantitative test. A qualitative assessment is performed when prior quantitative assessments have resulted in significant excess of fair value over the carrying value of a reporting unit, and consideration of qualitative factors allow the Company to conclude it is more likely than not that the fair value of the reporting unit remains greater than its carrying value. When performing a quantitative goodwill impairment test, the fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. To estimate the fair value, the Company uses a discounted cash flow model or estimated sales price for reporting units held for sale. The assumptions included in the impairment tests require judgment, and changes to these inputs could impact the results of the calculations. The key assumptions used in the impairment test were management's projections of future cash flows, weighted-average cost of capital and long-term growth rates. Although the Company's cash flow forecasts are based on assumptions that are considered reasonable by management and consistent with the plans and estimates management is using to operate the underlying business, there are significant judgments in determining the expected future cash flows attributable to a reporting unit.

[0000833444-24-000064:mdna:173]
Management completed its fiscal 2024 annual impairment test as of July 31, which included a qualitative assessment of all but one of its reporting units. The Company did not identify any qualitative factors that suggest that it is more likely than not that the fair value of its reporting units is less than their carrying amount, including goodwill, and as such, a quantitative impairment test was not necessary. The Company performed a quantitative goodwill impairment test of one reporting unit in the Building Solutions EMEA/LA segment with $214 million of goodwill, and its fair value was in excess of its carrying value. However, for this reporting unit, a 200 basis point increase in the discount rate, or a 200 basis point decrease in the revenue growth rates, would cause the fair value to be less than the carrying value. While no impairment was recorded, it is possible that future changes in circumstances could result in a non-cash impairment charge. In the second quarter of fiscal 2024, the Company performed an interim goodwill impairment test as a result of a triggering event and impaired $230 million of goodwill in its Building Solutions EMEA/LA segment.

[0000833444-24-000064:mdna:174]
Indefinite-lived intangible assets are also subject to at least annual impairment testing in the fourth fiscal quarter or as events occur or circumstances change that indicate the assets may be impaired. Indefinite-lived intangible assets primarily consist of trademarks and trade names and are tested for impairment using a relief-from-royalty method. A considerable amount of management judgment and assumptions are required in performing the impairment tests. The key assumptions used in the impairment tests were long-term revenue growth projections, weighted-average cost of capital, and the royalty rate. The assumptions included in the impairment tests require judgment, and changes to these inputs could impact the results of the calculations.

[0000833444-24-000064:mdna:175]
The Company continuously monitors for events and circumstances that could negatively impact the key assumptions in determining fair value. While the Company believes the judgments and assumptions used in the goodwill and indefinite-lived intangible impairment tests are reasonable, different assumptions or changes in general industry, market and macro-economic conditions could change the estimated fair values and, therefore, future impairment charges could be required, which could be material to the consolidated financial statements.

[0000833444-24-000064:mdna:176]
Refer to Note 8, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for information regarding the results of goodwill and indefinite-lived intangible assets impairment testing performed in fiscal 2024 and 2023.

[0000833444-24-000064:mdna:177]
Pension Plans

[0000833444-24-000064:mdna:178]
The Company provides a range of benefits, including pensions, to eligible active and former employees. Pension plan assets and obligations are measured annually, or more frequently if there is a significant remeasurement event, using various actuarial assumptions such as discount rates, assumed rates of return and compensation increases as of that date. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends when appropriate.

[0000833444-24-000064:mdna:179]
The Company considers expected benefit payments on a plan-by-plan basis when estimating discount rates. Different discount rates are used for each plan depending on the plan jurisdiction and the expected timing of benefit payments. The Company uses country-specific discount rates determined by an independent third party which are based on government and high-quality corporate bond yields.

[0000833444-24-000064:mdna:180]
45

[0000833444-24-000064:mdna:181]
In estimating the expected return on plan assets, the Company considers historical returns on plan assets, adjusted for forward-looking considerations, inflation assumptions, asset mix and the impact of the active management of the plans’ invested assets. For fiscal 2025, the Company believes the long-term rate of return will approximate 6.50% for U.S. pension plans and 5.44% for non-U.S. pension plans. Any differences between actual investment results and the expected long-term asset returns will be reflected in net periodic benefit costs in the fourth quarter of each fiscal year or at the date of a significant remeasurement event. If actual returns on plan assets are less than the Company’s expectations, additional contributions may be required.

[0000833444-24-000064:mdna:182]
Based on information provided by its independent actuaries and other relevant sources, the Company believes that the assumptions used are reasonable, however, changes in these assumptions could impact the Company’s financial position, results of operations or cash flows. The following chart illustrates the estimated increases (decreases) in projected benefit obligation and future ongoing pension expense, excluding any potential mark-to-market adjustments, assuming an increase of 25 basis points in the key assumptions used for the Company's pension plans (in millions):

[0000833444-24-000064:mdna:183]
|  | Pension Benefits |
|  | U.S. Plans |  | Non-U.S. Plans |
|  | Change in Projected Benefit Obligation |  | Change in Ongoing Pension Expense |  | Change in Projected Benefit Obligation |  | Change in Ongoing Pension Expense |
| Discount rate | $ | (28) |  |  | $ | 2 |  |  | $ | (40) |  |  | $ | 1 |  |
| Expected return on plan assets | — |  |  | (4) |  |  | — |  |  | (3) |  |

[0000833444-24-000064:mdna:184]
Loss Contingencies

[0000833444-24-000064:mdna:185]
Accruals are recorded for various contingencies including legal proceedings, environmental matters, self-insurance and other claims that arise in the normal course of business. The accruals are based on judgment, the probability of losses and, where applicable, the consideration of opinions of internal and/or external legal counsel and actuarial determined estimates. Additionally, the Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-24-000064:mdna:186]
The Company is subject to laws and regulations relating to protecting the environment. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. The Company provides for expenses associated with environmental remediation obligations when such amounts are probable and can be reasonably estimated. Refer to Note 21, "Commitments and Contingencies," of the notes to consolidated financial statements.

[0000833444-24-000064:mdna:187]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company records receivables from third party insurers when recovery has been determined to be probable. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-24-000064:mdna:188]
Asbestos-Related Contingencies and Insurance Receivables

[0000833444-24-000064:mdna:189]
The Company and certain of its subsidiaries along with numerous other companies are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present values from the time that the costs are expected to be incurred which in some cases is not until 2068 (which is the Company's reasonable best estimate of the actuarial determined time period through which asbestos-related claims will be filed against Company affiliates). Estimated asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for

[0000833444-24-000064:mdna:190]
resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-24-000064:mdna:191]
In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable. The Company's estimate of asbestos-related insurance recoveries represents estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims discounted to present value. In determining the amount of insurance recoverable, the Company considers available insurance, allocation methodologies, solvency and creditworthiness of the insurers. Refer to Note 21, "Commitments and Contingencies," of the notes to consolidated financial statements for a discussion on management's judgments applied in the recognition and measurement of asbestos-related assets and liabilities.

[0000833444-24-000064:mdna:192]
Income Taxes

[0000833444-24-000064:mdna:193]
Deferred tax assets and liabilities are recognized for the expected future tax consequences attributable to differences between financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and other loss carryforwards. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company records a valuation allowance that primarily represents non-U.S. operating and other loss carryforwards for which realization is uncertain. Management judgment is required in determining the Company’s provision for income taxes, deferred tax assets and liabilities, and the valuation allowance recorded against the Company’s net deferred tax assets.

[0000833444-24-000064:mdna:194]
The Company reviews the realizability of its deferred tax assets and related valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary. At September 30, 2024, the Company had a valuation allowance of $6.3 billion for continuing operations, of which $5.9 billion relates to net operating and capital loss carryforwards primarily in France, Ireland, Luxembourg, Mexico, and the United Kingdom for which sustainable taxable income has not been demonstrated; and $0.4 billion for other deferred tax assets.

[0000833444-24-000064:mdna:195]
The Company’s federal income tax returns and certain non-U.S. income tax returns for various fiscal years remain under various stages of audit by the IRS and respective non-U.S. tax authorities. Although the outcome of tax audits is always uncertain, management believes that it has appropriate support for the positions taken on its tax returns and that its annual tax provisions included amounts sufficient to pay assessments, if any, which may be proposed by the taxing authorities. At September 30, 2024, the Company had recorded a liability of $2.1 billion for its best estimate of the probable loss on certain of its tax positions, the majority of which is included in other noncurrent liabilities in the consolidated statements of financial position. Nonetheless, the amounts ultimately paid, if any, upon resolution of the issues raised by the taxing authorities may differ materially from the amounts accrued for each year.

[0000833444-24-000064:mdna:196]
The Company does not generally provide additional U.S. or non-U.S. income taxes on outside basis differences of consolidated subsidiaries included in shareholders’ equity attributable to Johnson Controls International plc, except in limited circumstances including anticipated taxation on planned divestitures. The reduction of the outside basis differences via the sale or liquidation of these subsidiaries and/or distributions could create taxable income. The Company’s intent is to reduce the outside basis differences only when it would be tax efficient. Refer to "Capitalization" within the "Liquidity and Capital Resources" section for discussion of U.S. and non-U.S. cash projections.

[0000833444-24-000064:mdna:197]
Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements for the Company's income tax disclosures.

[0000833444-24-000064:mdna:198]
NEW ACCOUNTING PRONOUNCEMENTS

[0000833444-24-000064:mdna:199]
Refer to the "New Accounting Pronouncements" section within Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements.

[0000833444-24-000064:mdna:200]
RISK MANAGEMENT

[0000833444-24-000064:mdna:201]
The Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities, and interest rates. All hedging transactions are authorized and executed pursuant to clearly defined policies and procedures, which strictly prohibit the use of financial instruments for speculative purposes. At the inception of the hedge, the Company assesses the effectiveness of the hedge instrument and designates the hedge instrument as a hedge of either a forecasted transaction or of the variability of cash flows to be received or paid related to an unrecognized asset or liability (a cash flow hedge) or a net investment in a non-U.S. operation (a net investment hedge).

[0000833444-24-000064:mdna:202]
The Company performs hedge effectiveness testing on an ongoing basis depending on the type of hedging instrument used. All derivatives not designated as hedging instruments under ASC 815, "Derivatives and Hedging," are revalued in the consolidated statements of income.

[0000833444-24-000064:mdna:203]
For all foreign currency derivative instruments designated as cash flow hedges, retrospective effectiveness is tested on a monthly basis using a cumulative dollar offset test. The fair value of the hedged exposures and the fair value of the hedge instruments are revalued, and the ratio of the cumulative sum of the periodic changes in the value of the hedge instruments to the cumulative sum of the periodic changes in the value of the hedge is calculated. The hedge is deemed as highly effective if the ratio is between 80% and 125%. For commodity derivative contracts designated as cash flow hedges, effectiveness is tested using a qualitative assessment of the critical terms of the hedging instrument and the hedged item. Ineffectiveness is minimal as the Company aligns most of the critical terms of its derivatives with the supply contracts.

[0000833444-24-000064:mdna:204]
For net investment hedges, the Company assesses its net investment positions in the non-U.S. operations and compares it with the outstanding net investment hedges on a quarterly basis. The hedge is deemed effective if the aggregate outstanding principal of the hedge instruments designated as the net investment hedge in a non-U.S. operation does not exceed the Company’s net investment positions in the respective non-U.S. operation.

[0000833444-24-000064:mdna:205]
Derivative instruments not designated as hedging instruments under ASC 815 require no assessment of effectiveness.

[0000833444-24-000064:mdna:206]
A discussion of the Company’s accounting policies for derivative financial instruments is included in Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements, and further disclosure relating to derivatives and hedging activities is included in Note 11, "Derivative Instruments and Hedging Activities," and Note 12, "Fair Value Measurements," of the notes to consolidated financial statements.

[0000833444-24-000064:mdna:207]
Foreign Exchange

[0000833444-24-000064:mdna:208]
The Company has manufacturing, sales and distribution facilities around the world and thus makes investments and enters into transactions denominated in various foreign currencies. In order to maintain strict control and achieve the benefits of the Company’s global diversification, foreign exchange exposures for each currency are netted internally so that only its net foreign exchange exposures are, as appropriate, hedged with financial instruments.

[0000833444-24-000064:mdna:209]
The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. The Company primarily enters into foreign currency exchange contracts to reduce the earnings and cash flow impact of the variation of non-functional currency denominated receivables and payables. Gains and losses resulting from hedging instruments offset the foreign exchange gains or losses on the underlying assets and liabilities being hedged. The maturities of the forward exchange contracts generally coincide with the settlement dates of the related transactions. Realized and unrealized gains and losses on these contracts are recognized in the same period as gains and losses on the hedged items. The Company also selectively hedges anticipated transactions that are subject to foreign exchange exposure, primarily with foreign currency exchange contracts, which are designated as cash flow hedges in accordance with ASC 815.

[0000833444-24-000064:mdna:210]
The Company has entered into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of debt obligations are reflected in the accumulated other comprehensive income ("AOCI") account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally.

[0000833444-24-000064:mdna:211]
At September 30, 2024 and 2023, the Company estimates that an unfavorable 10% change in the exchange rates would have decreased net unrealized gains by approximately $144 million and $63 million, respectively.

[0000833444-24-000064:mdna:212]
Interest Rates

[0000833444-24-000064:mdna:213]
Substantially all of the Company's outstanding debt has fixed interest rates, and, therefore, any fluctuation in market interest rates is not expected to have a material effect on the Company's results of operations. A 100 basis point increase/decrease in the average interest rate on the Company's variable rate debt would have an immaterial impact on interest expense.

[0000833444-24-000064:mdna:214]
Commodities

[0000833444-24-000064:mdna:215]
The Company uses commodity hedge contracts in the financial derivatives market in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. As a cash flow hedge, gains and losses resulting from the hedging instruments offset the gains or losses on purchases of the underlying commodities that will be used in the business. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities.

[0000833444-24-000064:mdna:216]
ENVIRONMENTAL, HEALTH AND SAFETY AND OTHER MATTERS

[0000833444-24-000064:mdna:217]
The Company’s global operations are governed by environmental laws and worker safety laws. Under various circumstances, these laws impose civil and criminal penalties and fines, as well as injunctive and remedial relief, for noncompliance and require remediation at sites where Company-related substances have been released into the environment.

[0000833444-24-000064:mdna:218]
The Company has expended substantial resources globally, both financial and managerial, to comply with applicable environmental laws and worker safety laws and to protect the environment and workers. The Company believes it is in substantial compliance with such laws and maintains procedures designed to foster and ensure compliance. However, the Company has been, and in the future may become, the subject of formal or informal enforcement actions or proceedings regarding noncompliance with such laws or the remediation of Company-related substances released into the environment. Such matters typically are resolved with regulatory authorities through commitments to compliance, abatement or remediation programs and in some cases payment of penalties. Historically, neither such commitments nor penalties imposed on the Company have been material.

[0000833444-24-000064:mdna:219]
Refer to Note 21, "Commitments and Contingencies," of the notes to consolidated financial statements for additional information.

[0000833444-24-000064:mdna:220]
QUARTERLY FINANCIAL DATA

[0000833444-24-000064:mdna:221]
The following tables present selected quarterly financial data from continuing operations:

[0000833444-24-000064:mdna:222]
| (in millions, except per share data)(quarterly amounts unaudited) | FirstQuarter |  | SecondQuarter |  | ThirdQuarter |  | FourthQuarter |  | FullYear |  |
| 2024 |  |  |  |  |  |  |  |  |  |  |
| Net sales | $ | 5,209 |  |  | $ | 5,597 |  |  | $ | 5,898 |  |  | $ | 6,248 |  |  | $ | 22,952 |  |  |
| Gross profit | 1,778 |  |  | 1,922 |  |  | 2,109 |  |  | 2,268 |  |  | 8,077 |  |  |
| Net income (loss) | 340 |  |  | (318) |  |  | 851 |  |  | 538 |  |  | 1,411 |  |  |
| Net income (loss) attributable to Johnson Controls | 340 |  |  | (321) |  |  | 852 |  |  | 536 |  |  | 1,407 |  |  |
| Earnings (loss) per share |  |  |  |  |  |  |  |  |  |  |
| Basic | 0.50 |  |  | (0.47) |  |  | 1.26 |  |  | 0.80 |  |  | 2.09 |  |  |
| Diluted | 0.50 |  |  | (0.47) |  |  | 1.25 |  |  | 0.80 |  |  | 2.08 |  |  |
| 2023 |  |  |  |  |  |  |  |  |  |  |
| Net sales | $ | 5,155 |  |  | $ | 5,546 |  |  | $ | 5,777 |  |  | $ | 5,853 |  |  | $ | 22,331 |  |  |
| Gross profit | 1,852 |  |  | 1,916 |  |  | 2,063 |  |  | 1,973 |  |  | 7,804 |  |  |
| Net income | 101 |  |  | 45 |  |  | 947 |  |  | 488 |  |  | 1,581 |  |  |
| Net income attributable to Johnson Controls | 97 |  |  | 44 |  |  | 940 |  |  | 481 |  |  | 1,562 |  |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |
| Basic | 0.14 |  |  | 0.07 |  |  | 1.37 |  |  | 0.70 |  |  | 2.28 |  |  |
| Diluted | 0.14 |  |  | 0.07 |  |  | 1.36 |  |  | 0.70 |  |  | 2.27 |  |  |
