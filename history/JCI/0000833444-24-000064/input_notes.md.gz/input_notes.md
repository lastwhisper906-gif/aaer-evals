# JCI notes — 0000833444-24-000064


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000833444-24-000064:notes:1]
Portions of the definitive Proxy Statement to be delivered to shareholders in connection with the annual general meeting of shareholders to be held on March 12, 2025 are incorporated by reference into Part III.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000833444-24-000064:notes:2]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited  company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company," "Johnson Controls" or "JCI plc").

[0000833444-24-000064:notes:3]
The Company's fiscal year ends on September 30. Unless otherwise stated, references to years in this report relate to fiscal years rather than calendar years.

[0000833444-24-000064:notes:4]
Nature of Operations

[0000833444-24-000064:notes:5]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, healthy and sustainable buildings, serving a wide range of customers in more than 150 countries. The Company’s products, services, systems and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-24-000064:notes:6]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including residential and commercial HVAC equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, security and fire-protection space), and energy-management consulting. The Company's OpenBlue digital software platform enables enterprises to better manage their physical spaces by combining the Company's building products and services with cutting-edge technology and digital capabilities to enable data-driven “smart building” services and solutions. The Company partners with customers by leveraging its broad product portfolio and digital capabilities powered by OpenBlue, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency, enhance security, create healthy environments and reduce greenhouse gas emissions.

[0000833444-24-000064:notes:7]
As discussed in more detail in Note 3, "Assets and Liabilities Held for Sale and Discontinued Operations", the Company has entered into a definitive agreement to sell its Residential and Light Commercial (“R&LC") HVAC business, including the North America Ducted business and the global Residential joint venture with Hitachi Global Life Solutions, Inc. (“Hitachi”), of which Johnson Controls owns 60% and Hitachi owns 40%. The R&LC HVAC business, which was previously reported in the Global Products segment, meets the criteria to be classified as a discontinued operation and, as a result, its historical financial results are reflected in the consolidated financial statements as a discontinued operation, and assets and liabilities were reclassified as held for sale for all periods presented. Unless otherwise noted, all activities and amounts reported in the following footnotes relate to the continuing operations of the Company and exclude activities and amounts related to the R&LC HVAC business.

[0000833444-24-000064:notes:8]
Principles of Consolidation

[0000833444-24-000064:notes:9]
The consolidated financial statements include the accounts of Johnson Controls International plc and its subsidiaries that are consolidated in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). All significant intercompany transactions have been eliminated. The results of companies acquired or disposed of during the year are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company exercises significant influence, which typically occurs when its ownership interest exceeds 20%, and the Company does not have a controlling interest.

[0000833444-24-000064:notes:10]
The Company consolidates variable interest entities ("VIE") when it has the power to direct the significant activities of the entity and the obligation to absorb losses or receive benefits from the entity that may be significant. The Company did not have any material consolidated or nonconsolidated VIEs in its continuing operations for the presented reporting periods.

[0000833444-24-000064:notes:11]
Use of Estimates

[0000833444-24-000064:notes:12]
The preparation of consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts. Actual results could differ from those estimates.

[0000833444-24-000064:notes:13]
Fair Value of Financial Instruments

[0000833444-24-000064:notes:14]
ASC 820, "Fair Value Measurement," defines fair value as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. ASC 820 also establishes a three-level fair value hierarchy that prioritizes information used in developing assumptions when pricing an asset or liability as follows:

[0000833444-24-000064:notes:15]
Level 1: Observable inputs such as quoted prices in active markets for identical assets or liabilities;

[0000833444-24-000064:notes:16]
Level 2: Quoted prices in active markets for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active, or inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and

[0000833444-24-000064:notes:17]
Level 3: Unobservable inputs where there is little or no market data, which requires the reporting entity to develop its own assumptions.

[0000833444-24-000064:notes:18]
ASC 820 requires the use of observable market data, when available, in making fair value measurements. When inputs used to measure fair value fall within different levels of the hierarchy, the level within which the fair value measurement is categorized is based on the lowest level input that is significant to the fair value measurement.

[0000833444-24-000064:notes:19]
Acquisitions

[0000833444-24-000064:notes:20]
The purchase price of acquired businesses is allocated to the related identifiable assets and liabilities based on estimated fair values. The excess of the purchase price over the amount allocated to the assets and liabilities, if any, is recorded as goodwill. In addition, any contingent consideration is recorded at the estimated fair value as of the date of the acquisition and is recorded as part of the purchase price. This estimate is updated in future periods and any changes in the estimate, which are not considered an adjustment to the purchase price, are recorded in the consolidated statements of operations. Payments for contingent earn-out liabilities that are less than or equal to estimates on the acquisition date are reflected as financing cash outflows. Amounts paid in excess of the estimated contingent earn-out liabilities on the acquisition date are reflected as operating cash outflows.

[0000833444-24-000064:notes:21]
All available information is used to estimate fair values. External valuation specialists are typically engaged to assist in the fair value determination of identifiable intangible assets and any other significant assets or liabilities. The preliminary purchase price allocation is adjusted, as necessary, up to one year after the acquisition closing date as more information is obtained regarding assets acquired and liabilities assumed based on facts and circumstances that existed as of the acquisition date.

[0000833444-24-000064:notes:22]
The purchase price allocation methodology contains uncertainties because it requires the Company to make assumptions and to apply judgment to estimate the fair value of acquired assets and assumed liabilities. The fair value of assets and liabilities is estimated based upon the carrying value of the acquired assets and assumed liabilities and widely accepted valuation techniques, including discounted cash flows. Unanticipated events or circumstances may occur which could affect the accuracy of fair value estimates, including assumptions regarding industry economic factors and business strategies.

[0000833444-24-000064:notes:23]
Other estimates used in determining fair value include, but are not limited to, future cash flows or income related to intangibles, market rate assumptions and discount rates. Fair value estimates are based upon assumptions believed to be reasonable, but that are inherently uncertain, and therefore, may not be realized. Accordingly, there can be no assurance that the estimates, assumptions, and values reflected in the valuations will be realized, and actual results could differ materially.

[0000833444-24-000064:notes:24]
Assets and Liabilities Held for Sale

[0000833444-24-000064:notes:25]
Assets and liabilities (disposal groups) to be sold are classified as held for sale in the period in which all of the following criteria are met:

[0000833444-24-000064:notes:26]
•Management, having the authority to approve the action, commits to a plan to sell the disposal group;

[0000833444-24-000064:notes:27]
•The disposal group is available for immediate sale in its present condition subject only to terms that are usual and customary for sales of such disposal groups;

[0000833444-24-000064:notes:28]
•An active program to locate a buyer and other actions required to complete the plan to sell the disposal group have been initiated;

[0000833444-24-000064:notes:29]
•Sale of the disposal group is probable and transfer of the disposal group is expected to qualify for recognition as a completed sale within one year, except if events or circumstances beyond the Company's control extend the period of time required to sell the disposal group beyond one year;

[0000833444-24-000064:notes:30]
•The disposal group is being actively marketed for sale at a price that is reasonable in relation to its current fair value; and

[0000833444-24-000064:notes:31]
•Actions required to complete the plan indicate that it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn.

[0000833444-24-000064:notes:32]
The Company initially measures a disposal group that is classified as held for sale at the lower of its carrying value or fair value less any costs to sell in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets." The carrying amount of any assets, including goodwill, that are part of the disposal group, but not in the scope of ASC 360-10, are tested for impairment under the relevant guidance prior to measuring the disposal group at fair value, less cost to sell.

[0000833444-24-000064:notes:33]
Any loss resulting from this measurement is recognized in the period in which the held for sale criteria are met. Gains on the sale of a disposal group are not recognized until the date of sale. The Company assesses the fair value of a disposal group, less any costs to sell, each reporting period it remains classified as held for sale and reports any subsequent changes as an adjustment to the carrying value of the disposal group, as long as the new carrying value does not exceed the carrying value of the disposal group at the time it was initially classified as held for sale.

[0000833444-24-000064:notes:34]
Upon determining that a disposal group meets the criteria to be classified as held for sale, the Company reports the assets and liabilities of the disposal group, if material, in the line items assets held for sale and liabilities held for sale in the consolidated statements of financial position.

[0000833444-24-000064:notes:35]
Cash and Cash Equivalents

[0000833444-24-000064:notes:36]
Cash equivalents include all highly liquid investments with an original maturity of three months or less when purchased.

[0000833444-24-000064:notes:37]
Restricted Cash

[0000833444-24-000064:notes:38]
Restricted cash relates to amounts restricted for payment of asbestos liabilities and certain litigation and environmental matters and is recorded within other current assets in the consolidated statements of financial position.

[0000833444-24-000064:notes:39]
Receivables

[0000833444-24-000064:notes:40]
Receivables consist of billed receivables which are currently due from customers and unbilled receivables where the Company has satisfied its performance obligations, but has not yet issued the invoice to the customer. Incentives are periodically offered to customers, including early payment discounts and extended payment terms of certain receivables. The Company extends credit to customers in the normal course of business and maintains an allowance for expected credit losses resulting from the inability or unwillingness of customers to make required payments. The allowance for expected credit losses is based on historical experience, existing economic conditions, reasonable and supportable forecasts, and any specific customer collection issues the Company has identified. The Company evaluates the reasonableness of the allowance for expected credit losses on a quarterly basis. The allowance for expected credit losses was $210 million as of September 30, 2024 and $88 million as of September 30, 2023.

[0000833444-24-000064:notes:41]
The Company has previously entered into various factoring agreements to sell certain accounts receivable to third-party financial institutions. The Company collected the majority of the factored receivables on behalf of the financial institutions, but maintained no other continuing involvement with the factored receivables. Sales of accounts receivable were reflected as a reduction of accounts receivable in the consolidated statements of financial position and the proceeds were included in cash flows from operating activities in the consolidated statements of cash flows. The Company discontinued its receivables factoring program in March 2024.

[0000833444-24-000064:notes:42]
Inventories

[0000833444-24-000064:notes:43]
Inventories are stated at the lower of cost or net realizable value using the first-in, first-out ("FIFO") method. Finished goods and work-in-process inventories include material, labor and manufacturing overhead costs.

[0000833444-24-000064:notes:44]
Property, Plant and Equipment

[0000833444-24-000064:notes:45]
Property, plant and equipment are recorded at cost. Depreciation is provided over the estimated useful lives of the respective assets using the straight-line method for financial reporting purposes and accelerated methods for income tax purposes. Estimated useful lives generally range from 3 to 40 years for buildings and improvements, up to 15 years for subscriber systems, and from 3 to 15 years for machinery and equipment. Interest on borrowings is capitalized during the active construction period of major capital projects, added to the cost of the underlying assets and amortized over the useful lives of the assets.

[0000833444-24-000064:notes:46]
Goodwill and Indefinite-Lived Intangible Assets

[0000833444-24-000064:notes:47]
Goodwill reflects the cost of an acquisition in excess of the fair values assigned to identifiable net assets acquired. Goodwill is reviewed for impairment during the fourth fiscal quarter (as of July 31) or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s operating segments or one level below the operating segments, using a qualitative assessment or a quantitative test. A qualitative assessment is performed when prior quantitative assessments have resulted in significant excess of fair value over the carrying value of a reporting unit, and consideration of qualitative factors allow the Company to conclude it is more likely than not that the fair value of the reporting unit remains greater than its carrying value. When performing a quantitative goodwill impairment test, the fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. To estimate the fair value, the Company uses a discounted cash flow model or estimated sales price for reporting units held for sale. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The estimated fair value is then compared to the carrying amount of the reporting unit, including recorded goodwill. The Company is subject to financial statement risk to the extent that the carrying amount exceeds the estimated fair value.

[0000833444-24-000064:notes:48]
Indefinite-lived intangible assets are also subject to at least annual impairment testing in the fourth fiscal quarter or as events occur or circumstances change that indicate the assets may be impaired. Indefinite-lived intangible assets primarily consist of trademarks and trade names and are tested for impairment using a relief-from-royalty method. The Company considers the implications of both external (e.g., market growth, competition and local economic conditions) and internal (e.g., product sales and expected product growth) factors and their potential impact on cash flows related to the intangible asset in both the near- and long-term. The Company considers the profitability of the business, among other factors, to determine the royalty rate for use in the impairment assessment.

[0000833444-24-000064:notes:49]
While the Company believes that the estimates and assumptions underlying the valuation methodologies are reasonable, different estimates and assumptions could result in different outcomes.

[0000833444-24-000064:notes:50]
Leases

[0000833444-24-000064:notes:51]
Lessee arrangements

[0000833444-24-000064:notes:52]
The Company leases certain administrative, production and other facilities, fleet vehicles, information technology equipment and other equipment under arrangements that are accounted for as operating leases. The Company determines whether an arrangement contains a lease at contract inception based on whether the arrangement involves the use of a physically distinct identified asset and whether the Company has the right to obtain substantially all of the economic benefits from the use of the asset throughout the period as well as the right to direct the use of the asset.

[0000833444-24-000064:notes:53]
Right-of-use assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent its obligation to make lease payments arising from the lease. Right-of-use assets and the corresponding lease liabilities are recognized at commencement date based on the present value of lease payments for all leases with terms longer than twelve months. The majority of the Company's leases do not provide an implicit interest rate. To determine the present value of lease payments, the Company uses its incremental borrowing rate based on information available on the lease commencement date or  the implicit rate if it is readily determinable. The Company determines its incremental borrowing rate based on a comparable

[0000833444-24-000064:notes:54]
market yield curve consistent with its credit rating, term of the lease and relative economic environment. The Company has elected to combine lease and nonlease components for its leases.

[0000833444-24-000064:notes:55]
Most leases contain options to renew or terminate the lease. Right-of-use assets and lease liabilities reflect only the options which the Company is reasonably certain to exercise.

[0000833444-24-000064:notes:56]
The Company has certain real estate leases that contain variable lease payments which are based on changes in the Consumer Price Index ("CPI"). Additionally, the Company's leases generally require it to pay for fuel, maintenance, repair, insurance and taxes. These payments are not included in the right-of-use asset or lease liability and are expensed as incurred.

[0000833444-24-000064:notes:57]
Lease expense is recognized on a straight-line basis over the lease term.

[0000833444-24-000064:notes:58]
Lessor arrangements

[0000833444-24-000064:notes:59]
The Company has monitoring services and maintenance agreements within its security business that include subscriber system assets for which the Company retains ownership. These agreements contain both lease and nonlease components. The Company has elected to combine lease and nonlease components for these arrangements where the timing and pattern of transfer of the lease and nonlease components are the same and the lease component would be classified as an operating lease if accounted for separately. The Company has concluded that in these arrangements the nonlease components are the predominant characteristic, and as a result, the combined component is accounted for under the revenue guidance.

[0000833444-24-000064:notes:60]
Impairment of Long-Lived Assets

[0000833444-24-000064:notes:61]
Long-lived assets, including right-of-use assets under operating leases, other tangible assets and intangible assets with definite lives, are reviewed for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of Software to be Sold, Leased, or Marketed."

[0000833444-24-000064:notes:62]
Assets and liabilities are grouped at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluates the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals.

[0000833444-24-000064:notes:63]
Intangible assets acquired in a business combination that are used in research and development activities are considered indefinite-lived until the completion or abandonment of the associated research and development efforts. During the period that those assets are considered indefinite lived, they are not amortized but are tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired. If the carrying amount of an intangible asset exceeds its fair value, the Company recognizes an impairment loss in an amount equal to that excess.

[0000833444-24-000064:notes:64]
Unamortized capitalized costs of a computer software product are compared to the net realizable value of the product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset is written off.

[0000833444-24-000064:notes:65]
Revenue Recognition

[0000833444-24-000064:notes:66]
Revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services is recognized on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. The Company does not adjust the promised amount of consideration for the effects of a significant financing component because at contract inception it expects to receive the payment within twelve months of transfer of goods or services.

[0000833444-24-000064:notes:67]
The Company enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized over time on a straight-line basis over the respective contract term.

[0000833444-24-000064:notes:68]
The Company also sells certain HVAC and refrigeration products and services in bundled arrangements with multiple performance obligations, such as equipment, commissioning, service labor and extended warranties. Approximately four to twenty-four months separate the timing of the first deliverable until the last piece of equipment is delivered. There may also be extended warranty arrangements with durations of one to five years commencing upon the end of the standard warranty period. In addition, the Company sells security monitoring systems that may have multiple performance obligations, including equipment, installation, monitoring services and maintenance agreements. Revenue associated with the sale of equipment and related installations are generally recognized over time on a cost-to-cost input method, while the revenue for monitoring and maintenance services are recognized over time as services are rendered. The transaction price is allocated to each performance obligation based on the relative standalone selling price method. In order to estimate relative standalone selling price, market data and transfer price studies are utilized. If the standalone selling price is not directly observable, the Company estimates the standalone selling price using an adjusted market assessment approach or expected cost plus margin approach. If the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized over the contract term on a straight-line basis. Non-refundable fees received in connection with the initiation of a monitoring contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the contract.

[0000833444-24-000064:notes:69]
In all other cases, the Company recognizes revenue at the point in time when control over the goods or services transfers to the customer.

[0000833444-24-000064:notes:70]
The Company assesses variable consideration that may affect the total transaction price, including discounts, rebates, refunds, credits or other similar sources of variable consideration, when determining the transaction price of each contract. The Company includes variable consideration in the estimated transaction price when it is probable that significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. These estimates are based on the amount of consideration that the Company expects to be entitled to.

[0000833444-24-000064:notes:71]
Shipping and handling costs billed to customers are included in sales and the related costs are included in cost of sales when control transfers to the customer. The Company presents amounts collected from customers for sales and other taxes net of the related amounts remitted.

[0000833444-24-000064:notes:72]
Subscriber System Assets, Dealer Intangibles and Related Deferred Revenue Accounts

[0000833444-24-000064:notes:73]
The Company considers assets related to the acquisition of new customers in its electronic security business in three asset categories:

[0000833444-24-000064:notes:74]
•Internally generated residential subscriber systems outside of North America;

[0000833444-24-000064:notes:75]
•Internally generated commercial subscriber systems; and

[0000833444-24-000064:notes:76]
•Customer accounts acquired through the ADT dealer program, primarily outside of North America (referred to as dealer intangibles).

[0000833444-24-000064:notes:77]
Subscriber system assets include installed property, plant and equipment for which the Company retains ownership and deferred costs directly related to the customer acquisition and system installation. Subscriber system assets represent capitalized equipment (e.g., security control panels, touch pad, motion detectors, window sensors, and other equipment) and installation costs associated with electronic security monitoring arrangements under which the Company retains ownership of the security system assets in a customer's place of business or residence. Installation costs represent costs incurred to prepare the asset for its intended use. The Company pays property taxes on the subscriber system assets and may retrieve such assets when the agreement is terminated. These assets embody a probable future economic benefit as they generate future monitoring revenue for the Company.

[0000833444-24-000064:notes:78]
Costs related to the subscriber system equipment and installation are categorized as property, plant and equipment rather than deferred costs. Deferred costs associated with subscriber system assets represent direct and incremental selling expenses (such as commissions) related to acquiring the customer. Commissions related to up-front consideration paid by customers in connection with the establishment of the monitoring arrangement are determined based on a percentage of the up-front fees and do not exceed deferred revenue. Such deferred costs are recorded as other current and noncurrent assets within the consolidated statements of financial position.

[0000833444-24-000064:notes:79]
Subscriber system assets and any deferred revenue resulting from the customer acquisition are accounted for over the expected life of the subscriber. In certain geographical areas which have a large number of customers that behave in a similar manner over time, the Company accounts for subscriber system assets and related deferred revenue using pools, with separate pools for the components of subscriber system assets and any related deferred revenue based on the same month and year of acquisition. Pooled subscriber system assets and related deferred revenue are depreciated using a straight-line method with lives up to 12 years and considering customer attrition. Non-pooled subscriber systems (primarily in Europe, Latin America and Asia) and related deferred revenue are depreciated using a straight-line method with a 15-year life, with remaining balances written off upon customer termination.

[0000833444-24-000064:notes:80]
Certain contracts and related customer relationships result from purchasing residential security monitoring contracts from an external network of independent dealers who operate under the ADT dealer program, primarily outside of North America. Acquired contracts and related customer relationships are recorded at their contractually determined purchase price. During the first 6 months (12 months in certain circumstances) after the purchase of the customer contract, any cancellation of monitoring service, including those that result from customer payment delinquencies, results in a chargeback by the Company to the dealer for the full amount of the contract purchase price. The Company records the amount charged back to the dealer as a reduction of the previously recorded intangible asset. Intangible assets arising from the ADT dealer program are amortized in pools determined by the same month and year of contract acquisition on a straight-line basis over the period of the customer relationship. The estimated useful life of dealer intangibles ranges from 12 to 15 years.

[0000833444-24-000064:notes:81]
Research and Development Costs

[0000833444-24-000064:notes:82]
Expenditures for research activities relating to product development and improvement are charged against income as incurred and primarily included within selling, general and administrative expenses in the consolidated statements of income. Such expenditures for the years ended September 30, 2024, 2023 and 2022 were $267 million, $251 million and $236 million, respectively.

[0000833444-24-000064:notes:83]
Stock-Based Compensation

[0000833444-24-000064:notes:84]
Restricted (Non-vested) Stock /Units

[0000833444-24-000064:notes:85]
Restricted stock and restricted stock units are typically settled in shares for employees in the U.S. and in cash for employees not in the U.S. Restricted awards typically vest over a period of three years from the grant date. The Company's Compensation and Talent Development Committee may approve different vesting terms on specific grants. The fair value of each share-settled restricted award is based on the closing market value of the Company’s ordinary shares on the date of grant. The fair value of each cash-settled restricted award is recalculated at the end of each reporting period based on the closing market value of the Company's ordinary shares at the end of the reporting period, and the liability and expense are adjusted based on the new fair value.

[0000833444-24-000064:notes:86]
Performance Share Awards

[0000833444-24-000064:notes:87]
Performance-based share unit ("PSU") awards are generally contingent on the achievement of predetermined performance goals over a performance period of one to three years and on the award holder's continuous employment until the vesting date. The majority of PSUs are also indexed to the achievement of specified levels of total shareholder return versus a peer group over the performance period.

[0000833444-24-000064:notes:88]
Upon completion of the performance period, earned PSUs are typically settled with shares of the Company's ordinary shares for employees in the U.S. and in cash for employees not in the U.S.

[0000833444-24-000064:notes:89]
The fair value of the portion of the PSU which is linked to the achievement of performance goals is based on the closing market value of the Company's ordinary shares on the date of grant. Share-based compensation expense for these PSUs is recognized over the performance period based on the probability of achieving the performance targets.

[0000833444-24-000064:notes:90]
The fair value of the portion of the PSU that is indexed to total shareholder return is estimated on the date of grant using a Monte Carlo simulation that uses the following assumptions:

[0000833444-24-000064:notes:91]
•The risk-free interest rate for periods during the contractual life of the PSU is based on the U.S. Treasury yield curve in effect at the time of grant.

[0000833444-24-000064:notes:92]
•The expected volatility is based on the historical volatility of the Company's stock over the most recent three-year period as of the grant date.

[0000833444-24-000064:notes:93]
Share-based compensation expense for PSUs which are indexed to total shareholder return is not adjusted for changes in performance subsequent to the grant date because the likelihood of achieving the market condition is incorporated in the grant date fair value of the award.

[0000833444-24-000064:notes:94]
Stock Options

[0000833444-24-000064:notes:95]
Stock options are granted with an exercise price equal to the market price of the Company’s stock at the date of grant. Stock option awards typically vest between two and three years after the grant date and expire ten years from the grant date.

[0000833444-24-000064:notes:96]
The fair value of each option is estimated on the date of grant using a Black-Scholes option valuation model that uses the following assumptions:

[0000833444-24-000064:notes:97]
•The expected life of options represents the period of time that options granted are expected to be outstanding.

[0000833444-24-000064:notes:98]
•The risk-free interest rate for periods during the contractual life of the option is based on the U.S. Treasury yield curve in effect at the time of grant.

[0000833444-24-000064:notes:99]
•For grants in fiscal 2024 and 2023, expected volatility is based on the historical volatility of the Company's stock corresponding to the expected life as of the grant date. For grants in fiscal 2022, expected volatility is based on the historical volatility of the Company's stock since October 2016 and certain peer companies' stock prior to October 2016 over the most recent period corresponding to the expected life as of the grant date.

[0000833444-24-000064:notes:100]
•The expected dividend yield is based on the expected annual dividend as a percentage of the market value of the Company’s ordinary shares as of the grant date.

[0000833444-24-000064:notes:101]
The Company uses historical data to estimate option exercises and employee terminations within the valuation model.

[0000833444-24-000064:notes:102]
Earnings Per Share

[0000833444-24-000064:notes:103]
The Company presents both basic and diluted earnings per share ("EPS") amounts. Basic EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares outstanding during the reporting period. Diluted EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares and ordinary equivalent shares outstanding during the reporting period that are calculated using the treasury stock method for stock options, unvested restricted stock and unvested performance share awards. The treasury stock method assumes that the Company uses the proceeds from the exercise of stock option awards to repurchase ordinary shares at the average market price during the period. The assumed proceeds under the treasury stock method include the purchase price that the grantee will pay in the future and compensation cost for future service that the Company has not yet recognized. For unvested restricted stock and unvested performance share awards, assumed proceeds under the treasury stock method include unamortized compensation cost.

[0000833444-24-000064:notes:104]
Foreign Currency Translation

[0000833444-24-000064:notes:105]
Substantially all of the Company’s international operations use the respective local currency as the functional currency. Assets and liabilities of international entities have been translated at period-end exchange rates, and income and expenses have been translated using average exchange rates for the period. Monetary assets and liabilities denominated in non-functional currencies are adjusted to reflect period-end exchange rates. Aggregate transaction gains (losses), net of the impact of foreign currency hedges, included in income from continuing operations for the years ended September 30, 2024, 2023 and 2022 were $(10) million, $22 million and $33 million, respectively.

[0000833444-24-000064:notes:106]
Derivative Financial Instruments

[0000833444-24-000064:notes:107]
The Company has written policies and procedures that place all derivative financial instruments under the direction of Corporate treasury and restrict all derivative transactions to those intended for hedging purposes. The use of derivatives for speculative purposes is strictly prohibited. The Company selectively uses derivatives to manage the market risk from changes in foreign exchange rates, commodity prices, and interest rates.

[0000833444-24-000064:notes:108]
The fair values of all derivatives are recorded in the consolidated statements of financial position. The change in a derivative’s fair value is recorded each period in current earnings or accumulated other comprehensive income ("AOCI"), depending on whether the derivative is designated as part of a hedge transaction and if so, the type of hedge transaction.

[0000833444-24-000064:notes:109]
Investments

[0000833444-24-000064:notes:110]
Investments in debt and equity securities and deferred compensation plan assets are marked to market at the end of each accounting period. Unrealized gains and losses are recognized in the consolidated statements of income.

[0000833444-24-000064:notes:111]
Pension and Postretirement Benefits

[0000833444-24-000064:notes:112]
The Company utilizes a mark-to-market approach for recognizing pension and postretirement benefit expenses, including measuring plan assets at fair value and recognizing actuarial gains and losses in the fourth quarter of each fiscal year or at the date of a remeasurement event.

[0000833444-24-000064:notes:113]
Guarantees

[0000833444-24-000064:notes:114]
The Company records an estimate for future warranty-related costs based on actual historical claims and other known factors. Based on analysis of return rates and other factors, the Company’s warranty provisions are adjusted as necessary. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different from those estimates.

[0000833444-24-000064:notes:115]
The Company’s product warranty liability is recorded in the consolidated statements of financial position in other current liabilities if the warranty is less than one year and in other noncurrent liabilities if the warranty extends longer than one year.

[0000833444-24-000064:notes:116]
Loss Contingencies

[0000833444-24-000064:notes:117]
Accruals are recorded for various contingencies including legal proceedings, environmental matters, self-insurance and other claims that arise in the normal course of business when it is probable a liability has been incurred and the amount of the liability can be reasonably estimated. The accruals are based on judgment, the probability of losses and, where applicable, the consideration of opinions of internal and/or external legal counsel and actuarial determined estimates. Additionally, the Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-24-000064:notes:118]
The Company is subject to laws and regulations relating to protecting the environment. Expenses associated with environmental remediation obligations are recognized when such amounts are probable and can be reasonably estimated.

[0000833444-24-000064:notes:119]
Liabilities and expenses for workers' compensation, product, general and auto liabilities are dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. Receivables from third party insurers are recorded when recovery has been determined to be probable. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-24-000064:notes:120]
Asbestos-Related Contingencies and Insurance Receivables

[0000833444-24-000064:notes:121]
The Company and certain of its subsidiaries, along with numerous other companies, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. The estimated liability and corresponding insurance recovery for pending and future claims and defense costs are based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present values from the time that the costs are expected to be incurred which in some cases is not until 2068 (which is the Company's reasonable best estimate of the actuarial determined time period through which asbestos-related claims will be filed against its affiliates). Estimated asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and its defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines

[0000833444-24-000064:notes:122]
whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-24-000064:notes:123]
The Company records asbestos-related insurance recoveries that are probable. Estimated asbestos-related insurance recoveries represent estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims discounted to present value. In determining the amount of insurance recoverable, the Company considers available insurance, allocation methodologies, solvency and creditworthiness of the insurers.

[0000833444-24-000064:notes:124]
Income Taxes

[0000833444-24-000064:notes:125]
Deferred tax liabilities and assets are recognized for the expected future tax consequences of events that have been reflected in the consolidated financial statements. Deferred tax asset and liabilities are determined based on the differences between the book and tax basis of particular assets and liabilities and operating loss carryforwards, using tax rates in effect for the years in which the differences are expected to reverse. A valuation allowance is provided to reduce the carrying or book value of deferred tax assets if, based upon the available evidence, including consideration of tax planning strategies, it is more-likely-than-not that some or all of the deferred tax assets will not be realized.

[0000833444-24-000064:notes:126]
New Accounting Pronouncements

[0000833444-24-000064:notes:127]
Recently Adopted Accounting Pronouncements

[0000833444-24-000064:notes:128]
In September 2022, the FASB issued ASU 2022-04, "Disclosure of Supplier Finance Program Obligations," which is intended to enhance the transparency surrounding the use of supplier finance programs. Supplier finance programs may also be referred to as reverse factoring, payables finance, or structured payables arrangements. The amendments require a buyer that uses supplier finance programs to make annual disclosures about the program’s key terms, the balance sheet presentation of related amounts, the confirmed amount outstanding at the end of the period, and associated rollforward information. Only the amount outstanding at the end of the period must be disclosed in interim periods. The Company adopted the new disclosures, other than the rollforward disclosure, as required at the beginning of fiscal 2024. The rollforward disclosure will be adopted as required at the beginning of fiscal 2025.

[0000833444-24-000064:notes:129]
The Company maintains agreements with third-party financial institutions who offer voluntary supply chain financing ("SCF") programs to its suppliers. The SCF programs enable suppliers to sell their receivables to third-party financial institutions and receive payments earlier than the negotiated commercial terms between the suppliers and the Company, which generally range from 90 to 120 days. Suppliers sell receivables to third-party financial institutions on terms negotiated between the supplier and the respective third-party financial institution. The Company remains obligated to make payments under the terms of the original commercial arrangement regardless of whether the supplier receivable is sold, and does not pledge any assets as security or provide other forms of guarantees for the committed payment to the third-party financial institutions.

[0000833444-24-000064:notes:130]
Amounts outstanding related to SCF programs are included in accounts payable in the consolidated statements of financial position. Accounts payable included in the SCF programs were approximately $703 million and $520 million as of September 30, 2024, and September 30, 2023, respectively.

[0000833444-24-000064:notes:131]
Recently Issued Accounting Pronouncements

[0000833444-24-000064:notes:132]
In November 2024, the FASB issued ASU 2024-03, "Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses," which is intended to enhance transparency into the nature and function of expenses. The amendments require that on an annual and interim basis, entities disclose disaggregated operating expense information about specific categories, including purchases of inventory, employee compensation, depreciation, amortization and depletion. The Company expects to adopt the new annual disclosures as required for fiscal 2028 and the interim disclosures as required beginning with the first quarter of fiscal 2029.

[0000833444-24-000064:notes:133]
In December 2023, the FASB issued ASU 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures," which is intended to enhance the transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. The amendments require that on an annual basis, entities disclose specific categories in the rate reconciliation and provide additional information for reconciling items that meet a quantitative threshold. In addition, the amendments require that entities disclose additional information about income taxes paid as well as additional disclosures of pretax income and income tax expense, and remove the requirement to disclose certain

[0000833444-24-000064:notes:134]
items that are no longer considered cost beneficial or relevant. The Company expects to adopt the new annual disclosures as required for fiscal 2026.

[0000833444-24-000064:notes:135]
In November 2023, the FASB issued ASU 2023-07, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures," which is intended to improve reportable segment disclosures, primarily through enhanced disclosures about significant segment expenses. In addition, the amendments enhance interim disclosure requirements, clarify circumstances in which an entity can disclose multiple segment measures of profit or loss, provide new segment disclosure requirements for entities with a single reportable segment and contain other disclosure requirements. The Company expects to adopt the new annual disclosures as required for fiscal 2025 and the interim disclosures as required beginning with the first quarter of fiscal 2026.

[0000833444-24-000064:notes:136]
Other recently issued accounting pronouncements are not expected to have a material impact on the Company's consolidated financial statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-24-000064:notes:137]
ACQUISITIONS AND DIVESTITURES
Fiscal 2024

[0000833444-24-000064:notes:138]
During fiscal 2024, the Company completed three divestitures, including the divestiture of its Air Distribution Technologies ("ADTi") business which was included within the Global Products segment. The combined selling price, net of cash divested, was $347 million, of which $332 million was received as of September 30, 2024. In connection with the closing of the ADTi transaction, the Company recorded a pre-tax loss of $42 million within selling, general and administrative expenses in the consolidated statements of income. An impairment of $56 million was recorded within restructuring and impairment costs in the consolidated statements of income while the business was classified as held for sale. Net cash proceeds from the divestitures were used for general corporate purposes. The businesses did not meet the criteria to be classified as discontinued operations as the divestitures did not represent a strategic shift that will have a major effect on the Company's operations and financial results.

[0000833444-24-000064:notes:139]
Fiscal 2023

[0000833444-24-000064:notes:140]
In July 2023, the Company completed its acquisition of FM:Systems, a leading digital workplace management and Internet of Things ("IoT") solutions provider for facilities and real estate professionals, for $540 million, net of cash acquired, which was comprised of an upfront cash payment of $465 million, and the estimated fair value at the acquisition date of contingent earn-out liabilities which are primarily based upon the achievement of certain defined operating results in the two years following the acquisition. In connection with the acquisition and subsequent measurement period adjustments, the Company recorded goodwill of $407 million in the Building Solutions North America segment. Goodwill is attributable primarily to expected synergies, expanded market opportunities and other benefits that the Company believes will result from integrating the products and capabilities of FM:Systems into its operations. The goodwill created in the acquisition is not deductible for tax purposes.

[0000833444-24-000064:notes:141]
During fiscal 2023, the Company acquired several other businesses for a combined purchase price, net of cash acquired, of $306 million, of which $260 million was paid as of September 30, 2023. Intangible assets associated with these acquisitions totaled $116 million and primarily relate to customer relationships and technology. The Company recorded goodwill associated with these acquisitions of $119 million in the Global Products segment, $55 million in the Building Solutions Asia Pacific segment and $13 million in the Building Solutions EMEA/LA segment.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-24-000064:notes:142]
ASSETS AND LIABILITIES HELD FOR SALE AND DISCONTINUED OPERATIONS
In July 2024, the Company entered into a definitive agreement to sell its R&LC HVAC business, which includes the North America Ducted businesses and the global Residential joint venture with Hitachi, of which Johnson Controls owns 60% and Hitachi owns 40%, to Bosch Group for approximately $8.1 billion in cash with the Company’s portion of the aggregate consideration being approximately $6.7 billion, inclusive of an upfront royalty payment for the licensing of the York tradename. The transaction is expected to close in the fourth quarter of fiscal 2025, subject to required regulatory approvals and other customary closing conditions. The R&LC HVAC business, which was previously reported in the Global Products segment, meets the criteria to be classified as discontinued operations as it represents a strategic shift in the Company's operations and results in the exit of substantially all of its residential and light commercial HVAC businesses. As a result, results of the business are presented in discontinued operations for all periods presented.

[0000833444-24-000064:notes:143]
The Company determined that the assets and liabilities for the R&LC HVAC business met the held for sale criteria during the fourth quarter of 2024. Accordingly, the businesses' assets and liabilities were reclassified in the consolidated balance sheets at September 30, 2024 and 2023 to held for sale, and the Company ceased recording depreciation and amortization for the held for sale assets.

[0000833444-24-000064:notes:144]
The following table summarizes the results of the R&LC HVAC business which are reported as discontinued operations (in millions):

[0000833444-24-000064:notes:145]
|  |  | Year Ended September 30, |  |
|  |  | 2024 |  | 2023 |  | 2022 |  |
| Net sales |  | $ | 4,466 |  |  | $ | 4,462 |  |  | $ | 4,662 |  |  |
| Cost of goods sold |  | 3,300 |  |  | 3,295 |  |  | 3,409 |  |  |
| Gross profit |  | 1,166 |  |  | 1,167 |  |  | 1,253 |  |  |
| Selling, general and administrative expenses |  | 761 |  |  | 794 |  |  | 867 |  |  |
| Restructuring and impairment costs |  | 34 |  |  | 15 |  |  | 20 |  |  |
| Net financing charges |  | 17 |  |  | 23 |  |  | 8 |  |  |
| Equity income |  | 276 |  |  | 262 |  |  | 240 |  |  |
| Income from discontinued operations before income taxes |  | 630 |  |  | 597 |  |  | 598 |  |  |
| Provision for income taxes on discontinued operations |  | 141 |  |  | 145 |  |  | 169 |  |  |
| Income from discontinued operations, net of tax |  | 489 |  |  | 452 |  |  | 429 |  |  |
| Income from discontinued operations attributable to noncontrolling interest, net of tax |  | 191 |  |  | 165 |  |  | 176 |  |  |
| Income from discontinued operations |  | $ | 298 |  |  | $ | 287 |  |  | $ | 253 |  |  |

[0000833444-24-000064:notes:146]
The following table summarizes the assets and liabilities of the R&LC HVAC business which were classified as held for sale (in millions):

[0000833444-24-000064:notes:147]
|  |  | September 30, |
|  |  | 2024 |  | 2023 |
| Cash |  | $ | 5 |  |  | $ | 7 |  |
| Accounts receivable - net |  | 592 |  |  | 512 |  |
| Inventories |  | 876 |  |  | 904 |  |
| Other current assets |  | 122 |  |  | 129 |  |
| Current assets held for sale |  | 1,595 |  |  | 1,552 |  |
| Property, plant and equipment - net |  | 793 |  |  | 762 |  |
| Goodwill |  | 1,182 |  |  | 1,164 |  |
| Other intangible assets - net |  | 96 |  |  | 116 |  |
| Investments in partially-owned affiliates |  | 949 |  |  | 905 |  |
| Other noncurrent assets |  | 190 |  |  | 158 |  |
| Noncurrent assets held for sale |  | 3,210 |  |  | 3,105 |  |
| Total assets classified as held for sale |  | $ | 4,805 |  |  | $ | 4,657 |  |
| Short-term debt |  | $ | — |  |  | $ | 24 |  |
| Accounts payable |  | 917 |  |  | 770 |  |
| Accrued compensation and benefits |  | 113 |  |  | 111 |  |
| Deferred revenue |  | 84 |  |  | 73 |  |
| Other current liabilities |  | 317 |  |  | 397 |  |
| Current liabilities held for sale |  | 1,431 |  |  | 1,375 |  |
| Pension and postretirement benefit obligations |  | 28 |  |  | 27 |  |
| Other noncurrent liabilities |  | 377 |  |  | 380 |  |
| Noncurrent liabilities held for sale |  | 405 |  |  | 407 |  |
| Total liabilities classified as held for sale |  | $ | 1,836 |  |  | $ | 1,782 |  |

[0000833444-24-000064:notes:148]
Assets and liabilities classified as held for sale are required to be recorded at the lower of carrying value or fair value less costs to sell. As of September 30, 2024, the estimated fair value less costs to sell of the held for sale businesses exceeded their carrying value, and therefore, no adjustment was necessary.

[0000833444-24-000064:notes:149]
During the year ended September 30, 2023, the Company recorded impairment charges for the Global Retail business of $438 million and the Building Solutions Asia Pacific segment of $60 million. The impairment charges were primarily due to reductions in the estimated fair values of the businesses to be disposed as a result of negotiations with potential buyers and were recorded within restructuring and impairment costs in the consolidated statements of income. During the third quarter of fiscal 2023, the Company concluded that its Global Retail business no longer met the criteria to be classified as held for sale, as it was no longer probable that it would be sold in the next 12 months. The net assets were reclassified to held and used at the lower of fair value or adjusted carrying value, and due to prior period impairment charges recorded, there was no impact to the consolidated statements of income as a result of this reclassification.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-24-000064:notes:150]
REVENUE RECOGNITION
Disaggregated Revenue

[0000833444-24-000064:notes:151]
The following table presents the Company's revenues disaggregated by segment and by products and systems versus services revenue (in millions):

[0000833444-24-000064:notes:152]
|  |  | Year Ended September 30, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 7,099 |  |  | $ | 4,249 |  |  | $ | 11,348 |  |  | $ | 6,368 |  |  | $ | 3,962 |  |  | $ | 10,330 |  |
| Building Solutions EMEA/LA |  | 2,314 |  |  | 1,982 |  |  | 4,296 |  |  | 2,275 |  |  | 1,821 |  |  | 4,096 |  |
| Building Solutions Asia Pacific |  | 1,483 |  |  | 754 |  |  | 2,237 |  |  | 1,987 |  |  | 759 |  |  | 2,746 |  |
| Global Products |  | 5,071 |  |  | — |  |  | 5,071 |  |  | 5,159 |  |  | — |  |  | 5,159 |  |
| Total |  | $ | 15,967 |  |  | $ | 6,985 |  |  | $ | 22,952 |  |  | $ | 15,789 |  |  | $ | 6,542 |  |  | $ | 22,331 |  |

[0000833444-24-000064:notes:153]
The following table presents further disaggregation of Global Products revenues by product type (in millions):

[0000833444-24-000064:notes:154]
|  |  | Year Ended September 30, |
|  |  | 2024 |  | 2023 |
| HVAC |  | $ | 2,280 |  |  | $ | 2,358 |  |
| Fire & Security |  | 2,370 |  |  | 2,446 |  |
| Industrial Refrigeration |  | 421 |  |  | 355 |  |
| Total |  | $ | 5,071 |  |  | $ | 5,159 |  |

[0000833444-24-000064:notes:155]
Contract Balances

[0000833444-24-000064:notes:156]
Contract assets represent the Company’s right to consideration for performance obligations that have been satisfied but not billed and consist of unbilled receivables and costs in excess of billings. Contract liabilities are customer payments received before performance obligations are satisfied. Contract balances are classified as assets or liabilities on a contract-by-contract basis at the end of each reporting period.

[0000833444-24-000064:notes:157]
The following table presents the location and amount of contract balances in the Company's consolidated statements of financial position (in millions):

[0000833444-24-000064:notes:158]
|  |  |  |  | September 30, |  |  |
|  |  | Location of contract balances |  | 2024 |  | 2023 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,931 |  |  | $ | 2,339 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 11 |  |  | 12 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,160 |  |  | 1,923 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 252 |  |  | 225 |  |  |  |

[0000833444-24-000064:notes:159]
The Company recognized revenue that was included in the beginning of period contract liability balance of approximately $1.7 billion and $1.5 billion for the years ended September 30, 2024 and 2023, respectively.

[0000833444-24-000064:notes:160]
Performance Obligations

[0000833444-24-000064:notes:161]
A performance obligation is a distinct good, service, or bundle of goods and services promised in a contract. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When contracts with customers require significant and complex integration, contain goods or services which are highly interdependent or interrelated, or are goods or services which significantly modify or customize other promises in the contracts and, therefore, are not distinct, then the entire contract is accounted for as a single performance obligation. For any contracts with multiple performance obligations, the contract’s transaction price is allocated to each performance obligation based on the estimated relative standalone selling price of each distinct good or service in the contract. For product sales, each product sold to a customer typically represents a distinct performance obligation.

[0000833444-24-000064:notes:162]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of September 30, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $21.1 billion, of which approximately 64% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with average initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less and contracts that are cancellable without substantial penalty.

[0000833444-24-000064:notes:163]
Costs to Obtain or Fulfill a Contract

[0000833444-24-000064:notes:164]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when the costs are recoverable. These costs consist primarily of sales commissions and bid/proposal costs. Costs to obtain or fulfill a contract are capitalized when incurred and amortized to expense over the period of contract performance.

[0000833444-24-000064:notes:165]
The following table presents the location and amount of costs to obtain or fulfill a contract recorded in the Company's consolidated statements of financial position (in millions):

[0000833444-24-000064:notes:166]
|  |  | September 30, |  |  |
|  |  | 2024 |  | 2023 |  |  |
| Other current assets |  | $ | 265 |  |  | $ | 156 |  |  |  |
| Other noncurrent assets |  | 291 |  |  | 224 |  |  |  |
| Total |  | $ | 556 |  |  | $ | 380 |  |  |  |

[0000833444-24-000064:notes:167]
Amortization of costs to obtain or fulfill a contract was $312 million and $251 million during the years ended September 30, 2024 and 2023, respectively. There were no impairment losses recognized in the year ended September 30, 2024 or 2023.


## us-gaap:AccountsAndNontradeReceivableTextBlock

[0000833444-24-000064:notes:168]
ACCOUNTS RECEIVABLEThe Company discontinued its receivable factoring program in March 2024. The Company sold $641 million and $1,717 million of accounts receivable under factoring agreements during the years ended September 30, 2024, and 2023, respectively. The cost of factoring such receivables was not material. Previously sold receivables still outstanding were $16 million and $615 million as of September 30, 2024 and 2023, respectively.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-24-000064:notes:169]
INVENTORIES
Inventories consisted of the following (in millions):

[0000833444-24-000064:notes:170]
|  | September 30, |
|  | 2024 |  | 2023 |
| Raw materials and supplies | $ | 765 |  |  | $ | 859 |  |
| Work-in-process | 130 |  |  | 180 |  |
| Finished goods | 879 |  |  | 833 |  |
| Inventories | $ | 1,774 |  |  | $ | 1,872 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000833444-24-000064:notes:171]
PROPERTY, PLANT AND EQUIPMENT
Property, plant and equipment consisted of the following (in millions):

[0000833444-24-000064:notes:172]
|  | September 30, |
|  | 2024 |  | 2023 |
| Buildings and improvements | $ | 1,033 |  |  | $ | 1,042 |  |
| Subscriber systems | 973 |  |  | 823 |  |
| Machinery and equipment | 3,374 |  |  | 3,309 |  |
| Construction in progress | 418 |  |  | 442 |  |
| Land | 48 |  |  | 50 |  |
| Total property, plant and equipment | 5,846 |  |  | 5,666 |  |
| Less: Accumulated depreciation | (3,443) |  |  | (3,292) |  |
| Property, plant and equipment - net | $ | 2,403 |  |  | $ | 2,374 |  |

[0000833444-24-000064:notes:173]
During the fourth quarter of fiscal 2023, the Company determined that a triggering event had occurred in the asset group comprising the security subscriber business of Argentina, primarily as a result of the significant devaluation of the Argentine peso that occurred during the quarter and the resulting impact on operating results and cash flows. The Company conducted the two-step impairment test required in accordance with ASC 360, "Property, Plant & Equipment" and determined that the carrying amount of the asset group exceeded its fair value. A non-cash impairment charge to the subscriber system assets of $78 million was recorded and is included in restructuring and impairment costs in the consolidated statements of income. The Company used a discounted cash flow model to estimate the fair value of the asset group. The primary assumptions and inputs used in the model included management's internal projections of future cash flows, the weighted-average cost of capital and the long-term growth rate. The fair value measurement is classified as Level 3 within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement" due to the unobservable inputs used.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-24-000064:notes:174]
GOODWILL AND OTHER INTANGIBLE ASSETS
Goodwill

[0000833444-24-000064:notes:175]
The changes in the carrying amount of goodwill in each of the Company’s reportable segments were as follows (in millions):

[0000833444-24-000064:notes:176]
|  |  | Year Ended September 30, 2024 |
|  |  | Building Solutions North America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | Total |
| Goodwill |  | $ | 10,040 |  |  | $ | 1,932 |  |  | $ | 1,179 |  |  | $ | 4,586 |  |  | 17,737 |  |
| Accumulated impairment loss |  | (659) |  |  | (47) |  |  | — |  |  | (259) |  |  | (965) |  |
| Balance at beginning of period |  | 9,381 |  |  | 1,885 |  |  | 1,179 |  |  | 4,327 |  |  | 16,772 |  |
| Impairments |  | — |  |  | (230) |  |  | — |  |  | — |  |  | (230) |  |
| Foreign currency translation and other (1) |  | 10 |  |  | 107 |  |  | 48 |  |  | 18 |  |  | 183 |  |
| Balance at end of period |  | $ | 9,391 |  |  | $ | 1,762 |  |  | $ | 1,227 |  |  | $ | 4,345 |  |  | $ | 16,725 |  |

[0000833444-24-000064:notes:177]
(1)  Includes measurement period adjustments and the allocation of $21 million of goodwill from Global Products to the ADTi disposal group classified as held for sale in June 2024 and subsequently divested in July 2024. Refer to Note 2, "Acquisitions and Divestitures" of the notes to the consolidated financial statements for further information.

[0000833444-24-000064:notes:178]
|  |  | Year Ended September 30, 2023 |  |
|  |  | Building Solutions North America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | Total |  |
| Goodwill |  | $ | 9,630 |  |  | $ | 1,794 |  |  | $ | 1,116 |  |  | $ | 4,416 |  |  | 16,956 |  |  |
| Accumulated impairment loss |  | (659) |  |  | (47) |  |  | — |  |  | (75) |  |  | (781) |  |  |
| Balance at beginning of period |  | 8,971 |  |  | 1,747 |  |  | 1,116 |  |  | 4,341 |  |  | 16,175 |  |  |
| Acquisitions |  | 399 |  |  | 13 |  |  | 55 |  |  | 119 |  |  | 586 |  |  |
| Impairments |  | — |  |  | — |  |  | — |  |  | (184) |  |  | (184) |  |  |
| Foreign currency translation and other |  | 11 |  |  | 125 |  |  | 8 |  |  | 51 |  |  | 195 |  |  |
| Balance at end of period |  | $ | 9,381 |  |  | $ | 1,885 |  |  | $ | 1,179 |  |  | $ | 4,327 |  |  | $ | 16,772 |  |  |

[0000833444-24-000064:notes:179]
Management completed its fiscal 2024 annual impairment test as of July 31, which included a qualitative assessment of all but one of its reporting units. The Company did not identify any qualitative factors that suggest that it is more likely than not that the fair value of its reporting units is less than their carrying amount, including goodwill, and as such, a quantitative impairment test was not necessary. The Company performed a quantitative goodwill impairment test of one reporting unit with $214 million of goodwill, and its fair value was in excess of its carrying value. However, for this reporting unit, a 200 basis point increase in the discount rate, or a 200 basis point decrease in the revenue growth rates, would cause the fair value to be less than the carrying value. While no impairment was recorded, it is possible that future changes in circumstances could result in a non-cash impairment charge.

[0000833444-24-000064:notes:180]
In the second quarter of fiscal 2024, the Company determined a triggering event had occurred for one of its reporting units in the Business Solutions EMEA/LA segment due to year-to-date results and projections for the remainder of fiscal 2024 being lower than the forecast used in the previous annual goodwill impairment test, and a quantitative test of goodwill for possible impairment was necessary. As a result of the goodwill impairment test, the Company recorded a non-cash impairment charge of $230 million within restructuring and impairment costs in the consolidated statements of income, which was determined by comparing the carrying amount of the reporting unit to its fair value. The Company used a discounted cash flow model to estimate the fair value of the reporting unit. The primary assumptions used in the model were management's internal projections of future cash flows, the weighted-average cost of capital and the long-term growth rate, which are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-24-000064:notes:181]
In the second quarter of fiscal 2023, management completed an updated comprehensive review of the Silent-Aire reporting unit, which is included in the Global Products segment. Because actual results were lower than planned and the nearer term forecast was revised to reflect lower margins and earnings, the Company determined a triggering event had occurred and a quantitative test of goodwill for possible impairment was necessary. As a result of the goodwill impairment test, the Company recorded a non-cash impairment charge of $184 million within restructuring and impairment costs in the consolidated statements of income in fiscal 2023, which was determined by comparing the carrying amount of the reporting unit to its fair value. During its fiscal 2022 annual impairment test, the Company recorded a non-cash impairment charge of $75 million of Silent Aire goodwill within restructuring and impairment costs in the consolidated statements of income. The Company used a discounted cash flow model to estimate the fair value of the Silent-Aire reporting unit in both fiscal 2023 and 2022. The primary assumptions and inputs used in the model included management's internal projections of future cash flows, the weighted-average cost of capital and the long-term growth rate. The fair value measurement is classified as Level 3 within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement" due to the unobservable inputs used. The Silent-Aire reporting unit had no remaining goodwill balance as of September 30, 2024 and 2023.

[0000833444-24-000064:notes:182]
During fiscal 2022, the Company concluded it had a triggering event requiring assessment of goodwill impairment for its North America Retail reporting unit in conjunction with classifying its Global Retail business as held for sale. As a result, the Company recorded a non-cash impairment charge of $235 million within restructuring and impairment costs in the consolidated statements of income in fiscal 2022. The North America Retail reporting unit had no remaining goodwill balance as of September 30, 2024 and 2023. The Company used the market approach to estimate the fair value of the reporting unit based on the relative estimated sales proceeds for the planned disposal of the Global Retail business attributable to the North America Retail reporting unit. The inputs utilized in the analysis are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-24-000064:notes:183]
There were no other triggering events requiring that an impairment assessment be conducted in fiscal 2024, 2023 or 2022. However, it is possible that future changes in circumstances would require the Company to record additional non-cash impairment charges.

[0000833444-24-000064:notes:184]
Other Intangible Assets

[0000833444-24-000064:notes:185]
The Company’s other intangible assets, primarily from business acquisitions, consisted of (in millions):

[0000833444-24-000064:notes:186]
|  | September 30, |
|  | 2024 |  | 2023 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Definite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,592 |  |  | $ | (955) |  |  | $ | 637 |  |  | $ | 1,562 |  |  | $ | (795) |  |  | $ | 767 |  |
| Customer relationships | 2,632 |  |  | (1,517) |  |  | 1,115 |  |  | 2,854 |  |  | (1,380) |  |  | 1,474 |  |
| Miscellaneous | 886 |  |  | (480) |  |  | 406 |  |  | 831 |  |  | (409) |  |  | 422 |  |
|  | 5,110 |  |  | (2,952) |  |  | 2,158 |  |  | 5,247 |  |  | (2,584) |  |  | 2,663 |  |
| Indefinite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/tradenames | 1,972 |  |  | — |  |  | 1,972 |  |  | 2,109 |  |  | — |  |  | 2,109 |  |
| Total intangible assets | $ | 7,082 |  |  | $ | (2,952) |  |  | $ | 4,130 |  |  | $ | 7,356 |  |  | $ | (2,584) |  |  | $ | 4,772 |  |

[0000833444-24-000064:notes:187]
During the fourth quarter of fiscal 2024, the Company impaired $32 million and $13 million of miscellaneous intangible assets in the Global Products segment and Building Solutions North America segment, respectively. These non-cash charges were recorded within restructuring and impairment costs in the consolidated statement of income.

[0000833444-24-000064:notes:188]
During the fourth quarter of fiscal 2023, the Company impaired $18 million of miscellaneous intangible assets in the Global Products segment and $10 million of a trademark in the Building Solutions Asia Pacific segment. These non-cash charges were recorded within restructuring and impairment costs in the consolidated statements of income.

[0000833444-24-000064:notes:189]
There were no impairments of other indefinite-lived intangible assets in any of these years, other than as disclosed above. For all other remaining indefinite-lived intangible assets, the Company estimated fair values were greater than the carrying values, with the exception of two other registered trademarks in which the estimated fair values were consistent with their carrying values which totaled $335 million as of July 31, 2024.

[0000833444-24-000064:notes:190]
Amortization of other intangible assets included within continuing operations for the years ended September 30, 2024, 2023 and 2022 was $476 million, $426 million and $413 million, respectively.

[0000833444-24-000064:notes:191]
The following table summarizes estimated amortization of existing definite-lived intangible assets as of September 30, 2024 for each of the next five fiscal years (in millions):

[0000833444-24-000064:notes:192]
| 2025 |  | $ | 453 |  |
| 2026 |  | 400 |
| 2027 |  | 365 |
| 2028 |  | 276 |
| 2029 |  | 183 |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000833444-24-000064:notes:193]
LEASES
The following table presents the Company’s lease costs (in millions):

[0000833444-24-000064:notes:194]
|  |  | Year Ended September 30, |  |
|  |  | 2024 |  | 2023 |  | 2022 |  |
| Operating lease cost |  | $ | 374 |  |  | $ | 365 |  |  | $ | 334 |  |  |
| Variable lease cost |  | 170 |  |  | 154 |  |  | 160 |  |  |
| Total lease costs |  | $ | 544 |  |  | $ | 519 |  |  | $ | 494 |  |  |

[0000833444-24-000064:notes:195]
The following table presents supplemental consolidated statement of financial position information (in millions):

[0000833444-24-000064:notes:196]
|  |  |  | September 30, |
|  | Location of lease balances |  | 2024 |  | 2023 |
| Operating lease right-of-use assets | Other noncurrent assets |  | $ | 1,170 |  |  | $ | 1,301 |  |
| Operating lease liabilities - current | Other current liabilities |  | 289 |  |  | 298 |  |
| Operating lease liabilities - noncurrent | Other noncurrent liabilities |  | 921 |  |  | 1,016 |  |
| Weighted-average remaining lease term |  |  | 7 years |  | 7 years |
| Weighted-average discount rate |  |  | 3.8 | % |  | 3.5 | % |

[0000833444-24-000064:notes:197]
The following table presents supplemental cash flow information related to operating leases (in millions):

[0000833444-24-000064:notes:198]
|  |  | Year Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2022 |
| Cash paid for amounts included in the measurement of lease liability: |  |  |  |  |  |  |
| Operating cash outflows from operating leases |  | $ | 377 |  |  | $ | 355 |  |  | $ | 349 |  |
| Noncash operating lease activity: |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  | 354 |  |  | 389 |  |  | 358 |  |

[0000833444-24-000064:notes:199]
The following table presents future minimum rental payments for operating lease liabilities as of September 30, 2024 (in millions):

[0000833444-24-000064:notes:200]
| 2025 |  | $ | 326 |  |
| 2026 |  | 265 |  |
| 2027 |  | 207 |  |
| 2028 |  | 155 |  |
| 2029 |  | 106 |  |
| After 2029 |  | 314 |  |
| Total operating lease payments |  | 1,373 |  |
| Less: Interest |  | (163) |  |
| Present value of lease payments |  | $ | 1,210 |  |


## us-gaap:LeaseCostTableTextBlock

[0000833444-24-000064:notes:201]
The following table presents the Company’s lease costs (in millions):


## us-gaap:DebtDisclosureTextBlock

[0000833444-24-000064:notes:202]
DEBT AND FINANCING ARRANGEMENTS
Short-Term Debt

[0000833444-24-000064:notes:203]
Short-term debt consisted of the following (in millions):

[0000833444-24-000064:notes:204]
|  | September 30, |
|  | 2024 |  | 2023 |
| Term loans | $ | 603 |  |  | $ | 159 |  |
| Commercial paper | 350 |  |  | 200 |  |
| Bank borrowings | — |  |  | 2 |  |
|  | $ | 953 |  |  | $ | 361 |  |
| Weighted average interest rate on short-term debt outstanding | 4.8 | % |  | 4.9 | % |

[0000833444-24-000064:notes:205]
Long-Term Debt

[0000833444-24-000064:notes:206]
Long-term debt consisted of the following (in millions; due dates by fiscal year):

[0000833444-24-000064:notes:207]
|  |  |  |  |  |  |  | September 30, |
| Issuer |  | Interest Rate |  | Due Date |  |  | 2024 |  | 2023 |
| US dollar debt |  |  |  |  |  |  |  |  |  |
| JCI plc |  | 3.625% |  | 2024 |  |  | $ | — |  |  | $ | 453 |  |
| JCI Inc. |  | 3.625% |  | 2024 |  |  | — |  |  | 31 |  |
| JCI plc |  | 3.90% |  | 2026 |  |  | 487 |  | 487 |  |
| TIFSA1 |  | 3.90% |  | 2026 |  |  | 51 |  | 51 |  |
| JCI plc and TFSCA2 |  | 5.50% |  | 2029 |  |  | 700 |  | — |  |
| JCI plc and TFSCA2 |  | 1.75% |  | 2030 |  |  | 625 |  | 625 |  |
| JCI plc and TFSCA2 |  | 2.00% |  | 2031 |  |  | 500 |  | 500 |  |
| JCI plc and TFSCA2 |  | 4.90% |  | 2033 |  |  | 400 |  | 400 |  |
| JCI plc |  | 6.00% |  | 2036 |  |  | 342 |  | 342 |  |
| JCI Inc. |  | 6.00% |  | 2036 |  |  | 8 |  | 8 |  |
| JCI plc |  | 5.70% |  | 2041 |  |  | 190 |  | 190 |  |
| JCI Inc. |  | 5.70% |  | 2041 |  |  | 30 |  | 30 |  |
| JCI plc |  | 5.25% |  | 2042 |  |  | 155 |  | 155 |  |
| JCI Inc. |  | 5.25% |  | 2042 |  |  | 6 |  | 6 |  |
| JCI plc |  | 4.625% |  | 2044 |  |  | 444 |  | 444 |  |
| JCI Inc. |  | 4.625% |  | 2044 |  |  | 6 |  | 6 |  |
| JCI plc |  | 5.125% |  | 2045 |  |  | 253 |  | 372 |  |
| TIFSA1 |  | 5.125% |  | 2045 |  |  | 23 |  | 23 |  |
| JCI plc |  | 6.95% |  | 2046 |  |  | 32 |  | 32 |  |
| JCI Inc. |  | 6.95% |  | 2046 |  |  | 4 |  | 4 |  |
| JCI plc |  | 4.50% |  | 2047 |  |  | 500 |  | 500 |  |
| JCI plc |  | 4.95% |  | 2064 |  |  | 341 |  | 341 |  |
| JCI Inc. |  | 4.95% |  | 2064 |  |  | 15 |  | 15 |  |
| Euro debt |  |  |  |  |  |  |  |  |  |
| JCI plc |  | EURIBOR plus 0.70% |  | 2024 |  |  | — |  |  | 159 |  |
| JCI plc |  | 1.375% |  | 2025 |  |  | 472 |  | 448 |  |
| TIFSA1 |  | 1.375% |  | 2025 |  |  | 60 |  | 57 |  |
| JCI plc and TFSCA2 |  | 0.375% |  | 2027 |  |  | 559 |  | 530 |  |
| JCI plc and TFSCA2 |  | 3.00% |  | 2028 |  |  | 670 |  | 636 |  |
| JCI plc and TFSCA2 |  | 1.00% |  | 2032 |  |  | 559 |  | 530 |  |
| JCI plc and TFSCA2 |  | 4.25% |  | 2035 |  |  | 894 |  | 849 |  |
| Japanese yen debt |  |  |  |  |  |  |  |  |  |
| JCI plc |  | TORF plus 0.40% |  | 2027 |  |  | 211 |  | 202 |  |
| Other |  |  |  |  |  |  | 31 |  |  | 36 |  |
| Gross long-term debt |  |  |  |  |  |  | 8,568 |  |  | 8,462 |  |
| Less: |  |  |  |  |  |  |  |  |  |
| Debt issuance costs |  |  |  |  |  |  | 38 |  |  | 35 |  |
| Net unamortized discount |  |  |  |  | 38 |  |  | 41 |  |
| Net purchase accounting adjustments |  |  |  |  | (48) |  |  | (77) |  |
|  |  |  |  |  |  |  | 8,540 |  |  | 8,463 |  |
| Less: Current portion |  |  |  |  |  |  | 536 |  |  | 645 |  |
| Long-term debt |  |  |  |  |  |  | $ | 8,004 |  |  | $ | 7,818 |  |

[0000833444-24-000064:notes:208]
1 TIFSA = Tyco International Finance S.A.

[0000833444-24-000064:notes:209]
2 TFSCA = Tyco Fire & Security Finance S.C.A.

[0000833444-24-000064:notes:210]
The following table presents maturities of long-term debt as of September 30, 2024 (in millions):

[0000833444-24-000064:notes:211]
| 2025 |  | $ | 536 |  |
| 2026 |  | 544 |  |
| 2027 |  | 776 |  |
| 2028 |  | 676 |  |
| 2029 |  | 707 |  |
| After 2029 |  | 5,329 |  |
| Total |  | $ | 8,568 |  |

[0000833444-24-000064:notes:212]
Other

[0000833444-24-000064:notes:213]
As of September 30, 2024, the Company had syndicated committed revolving credit facilities of $2.5 billion which is scheduled to expire in December 2028 and $500 million which is scheduled to expire in December 2024. There were no draws on the facilities as of September 30, 2024.

[0000833444-24-000064:notes:214]
As of September 30, 2024, the Company was in compliance with all financial covenants set forth in its credit agreements and the indentures governing its outstanding notes, and expects to remain in compliance for the foreseeable future. 
Total interest paid on both short and long-term debt for the years ended September 30, 2024, 2023 and 2022 was $361 million, $288 million and $222 million, respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-24-000064:notes:215]
DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES
Unless otherwise noted, all activities and amounts reported in this footnote include both continuing operations of the Company and activities and amounts related to the R&LC HVAC business. See Note 3, "Assets and Liabilities Held for Sale and Discontinued Operations" for additional details regarding divestiture of the R&LC HVAC business.

[0000833444-24-000064:notes:216]
Cash Flow Hedges

[0000833444-24-000064:notes:217]
The Company has global operations and participates in foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange forward contracts. The Company hedges 70% to 90% of the notional amount of each of its known foreign exchange transactional exposures.

[0000833444-24-000064:notes:218]
The Company selectively hedges anticipated transactions that are subject to commodity price risk, primarily using commodity hedge contracts, to minimize overall price risk associated with its purchases of copper and aluminum in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities.

[0000833444-24-000064:notes:219]
As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the years ended September 30, 2024 and 2023.

[0000833444-24-000064:notes:220]
The Company had the following outstanding contracts to hedge forecasted commodity purchases (in metric tons):

[0000833444-24-000064:notes:221]
|  |  | Volume Outstanding as of September 30, |
| Commodity |  | 2024 |  | 2023 |
| Copper |  | 2,676 |  |  | 2,812 |  |
| Aluminum |  | 2,450 |  |  | 5,976 |  |

[0000833444-24-000064:notes:222]
The Company may enter into forward-starting interest rate swaps in conjunction with anticipated note issuances. The forward-starting interest swaps are terminated when the anticipated notes are issued.

[0000833444-24-000064:notes:223]
During fiscal 2024, the Company terminated $600 million of forward-starting interest rate swaps related to an anticipated note issuance that was no longer highly likely to occur. Accumulated amounts previously recorded in AOCI were not material and were recognized as net financing charges in the consolidated statements of income when the swaps were terminated.

[0000833444-24-000064:notes:224]
During fiscal 2023, the Company terminated forward-starting interest rate swaps with a combined notional amount of €400 million when the related anticipated debt was issued. Accumulated amounts recorded in AOCI as of the date of the debt issuance are amortized to interest expense over the life of the respective debt to reflect the difference between the swap's reference rate and the fixed rate of the note.

[0000833444-24-000064:notes:225]
Net Investment Hedges

[0000833444-24-000064:notes:226]
The Company may enter into cross-currency interest rate swaps and foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the cross-currency interest rate swaps and debt obligations are reflected in the AOCI account within shareholders’equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally.

[0000833444-24-000064:notes:227]
The following table summarizes net investment hedges (in billions):

[0000833444-24-000064:notes:228]
|  |  | September 30, |
|  | 2024 |  | 2023 |
| Euro-denominated bonds designated as net investment hedges in Europe |  | € | 2.9 |  |  | € | 2.9 |  |
| Yen-denominated debt designated as a net investment hedge in Japan |  | ¥ | 30 |  |  | ¥ | 30 |  |
| US dollar vs. Yen cross-currency interest rate swap designated as a net investment hedge in Japan |  | — |  |  | ¥ | 14 |  |

[0000833444-24-000064:notes:229]
Derivatives Not Designated as Hedging Instruments

[0000833444-24-000064:notes:230]
The Company holds certain foreign currency forward contracts not designated as hedging instruments under ASC 815 to hedge foreign currency exposure resulting from monetary assets and liabilities denominated in nonfunctional currencies. The changes in fair value of these foreign currency exchange derivatives are recorded in the consolidated statements of income where they offset foreign currency transactional gains and losses on the nonfunctional currency denominated assets and liabilities being hedged.

[0000833444-24-000064:notes:231]
Fair Value of Derivative Instruments

[0000833444-24-000064:notes:232]
The following table presents the location and fair values of derivative instruments and hedging activities included in the Company’s consolidated statements of financial position (in millions):

[0000833444-24-000064:notes:233]
|  | Designated as Hedging Instruments |  | Not Designatedas Hedging Instruments |
|  | September 30, 2024 |  | September 30, 2023 |  | September 30, 2024 |  | September 30, 2023 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 19 |  |  | $ | 16 |  |  | $ | 1 |  |  | $ | 13 |  |
| Commodity derivatives | 2 |  |  | — |  |  | — |  |  | — |  |
| Interest rate swaps | — |  |  | 22 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Cross-currency interest rate swap | — |  |  | 5 |  |  | — |  |  | — |  |
| Total assets | $ | 21 |  |  | $ | 43 |  |  | $ | 1 |  |  | $ | 13 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 24 |  |  | $ | 20 |  |  | $ | 1 |  |  | $ | 5 |  |
| Commodity derivatives | 1 |  |  | 2 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 3,424 |  |  | 3,253 |  |  | — |  |  | — |  |
| Total liabilities | $ | 3,449 |  |  | $ | 3,275 |  |  | $ | 1 |  |  | $ | 5 |  |

[0000833444-24-000064:notes:234]
Counterparty Credit Risk

[0000833444-24-000064:notes:235]
The use of derivative financial instruments exposes the Company to counterparty credit risk. The Company has established policies and procedures to limit the potential for counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association ("ISDA") master netting agreements with substantially all of its counterparties. The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position.

[0000833444-24-000064:notes:236]
The Company's derivative contracts do not contain any credit risk related contingent features and do not require collateral or other security to be furnished by the Company or the counterparties. The Company's exposure to credit risk associated with its derivative instruments is measured on an individual counterparty basis, as well as by groups of counterparties that share similar attributes. The Company does not anticipate any non-performance by any of its counterparties, and the concentration of risk with financial institutions does not present significant credit risk to the Company.

[0000833444-24-000064:notes:237]
The gross and net amounts of derivative assets and liabilities were as follows (in millions):

[0000833444-24-000064:notes:238]
|  | Fair Value of Assets |  | Fair Value of Liabilities |
|  | September 30, 2024 |  | September 30, 2023 |  | September 30, 2024 |  | September 30, 2023 |  |
| Gross amount recognized | $ | 22 |  |  | $ | 56 |  |  | $ | 3,450 |  |  | $ | 3,280 |  |  |
| Gross amount eligible for offsetting | (12) |  |  | (19) |  |  | (12) |  |  | (19) |  |  |
| Net amount | $ | 10 |  |  | $ | 37 |  |  | $ | 3,438 |  |  | $ | 3,261 |  |  |

[0000833444-24-000064:notes:239]
Derivatives Impact on the Statements of Income and Statements of Comprehensive Income

[0000833444-24-000064:notes:240]
The following table presents the pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges (in millions):

[0000833444-24-000064:notes:241]
| Derivatives in Cash Flow Hedging Relationships |  | Year Ended September 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Foreign currency exchange derivatives |  | $ | (1) |  |  | $ | (13) |  |  | $ | 26 |  |
| Commodity derivatives |  | 5 |  |  | 1 |  |  | (21) |  |
| Interest rate swaps |  | (21) |  |  | 27 |  |  | 16 |  |
| Total |  | $ | (17) |  |  | $ | 15 |  |  | $ | 21 |  |

[0000833444-24-000064:notes:242]
The following table presents the location and amount of the pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income (in millions):

[0000833444-24-000064:notes:243]
| Derivatives in Cash FlowHedging Relationships |  | Location of Gain (Loss)Reclassified from AOCI into Income |  | Year Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2022 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 1 |  |  | $ | (4) |  |  | $ | 25 |  |
| Commodity derivatives |  | Cost of sales |  | — |  |  | (8) |  |  | (7) |  |
| Interest rate swaps |  | Net financing charges |  | — |  |  | — |  |  | (2) |  |
| Total |  |  |  | $ | 1 |  |  | $ | (12) |  |  | $ | 16 |  |

[0000833444-24-000064:notes:244]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income (in millions):

[0000833444-24-000064:notes:245]
| Derivatives Not Designatedas Hedging Instruments |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Year Ended September 30, |
|  |  | 2024 |  | 2023 |  | 2022 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (5) |  |  | $ | (16) |  |  | $ | 10 |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | 43 |  |  | (103) |  |  | 85 |  |
| Foreign currency exchange derivatives |  | Selling, general and administrative |  | (1) |  |  | — |  |  | — |  |
| Interest rate swaps |  | Net financing charges |  | — |  |  | 1 |  |  | — |  |
| Equity swap |  | Selling, general and administrative |  | — |  |  | — |  |  | (5) |  |
| Total |  |  |  | $ | 37 |  |  | $ | (118) |  |  | $ | 90 |  |

[0000833444-24-000064:notes:246]
The following table presents pre-tax gains (losses) on net investment hedges recorded as foreign currency translation adjustments ("CTA") within other comprehensive income (loss) (in millions):

[0000833444-24-000064:notes:247]
|  | Year Ended September 30, |
| 2024 |  | 2023 |  | 2022 |
| Net investment hedges | $ | (173) |  |  | $ | (223) |  |  | $ | 470 |  |

[0000833444-24-000064:notes:248]
No gains or losses were reclassified from CTA into income for the years ended September 30, 2024, 2023 and 2022.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-24-000064:notes:249]
FAIR VALUE MEASUREMENTS
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value (in millions):

[0000833444-24-000064:notes:250]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2024 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |
| Commodity derivatives | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 56 |  |  | 56 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 81 |  |  | 81 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 200 |  |  | 200 |  |  | — |  |  | — |  |
| Total assets | $ | 359 |  |  | $ | 337 |  |  | $ | 22 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 25 |  |  | $ | — |  |  | $ | 25 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Contingent earn-out liabilities | 14 |  |  | — |  |  | — |  |  | 14 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 14 |  |  | — |  |  | — |  |  | 14 |  |
| Total liabilities | $ | 54 |  |  | $ | — |  |  | $ | 26 |  |  | $ | 28 |  |

[0000833444-24-000064:notes:251]
1Classified as restricted investments for payment of asbestos liabilities. Refer to Note 21, "Commitments and Contingencies" of the notes to consolidated financial statements for further details.

[0000833444-24-000064:notes:252]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2023 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 29 |  |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |
| Interest rate swaps | 22 |  |  | — |  |  | 22 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Cross-currency interest rate swaps | 5 |  |  | — |  |  | 5 |  |  | — |  |
| Deferred compensation plan assets | 45 |  |  | 45 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 76 |  |  | 76 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 155 |  |  | 155 |  |  | — |  |  | — |  |
| Total assets | $ | 332 |  |  | $ | 276 |  |  | $ | 56 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 25 |  |  | $ | — |  |  | $ | 25 |  |  | $ | — |  |
| Commodity derivatives | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Contingent earn-out liabilities | 48 |  |  | — |  |  | — |  |  | 48 |  |
| Other noncurrent liabilities |  |  |  |  |  |  |  |
| Contingent earn-out liabilities | 76 |  |  | — |  |  | — |  |  | 76 |  |
| Total liabilities | $ | 151 |  |  | $ | — |  |  | $ | 27 |  |  | $ | 124 |  |

[0000833444-24-000064:notes:253]
The following table summarizes the changes in contingent earn-out liabilities, which are valued using significant unobservable inputs (Level 3) (in millions):

[0000833444-24-000064:notes:254]
| Balance at September 30, 2023 | $ | 124 |  |  |
| Payments | (26) |  |  |
| Reduction for change in estimates | (71) |  |  |
| Currency translation | 1 |  |  |
| Balance at September 30, 2024 | $ | 28 |  |  |

[0000833444-24-000064:notes:255]
Valuation Methods

[0000833444-24-000064:notes:256]
Commodity derivatives: The commodity derivatives are valued under a market approach using publicized prices, where available, or dealer quotes.

[0000833444-24-000064:notes:257]
Contingent earn-out liabilities: The contingent earn-out liabilities are generally established using a Monte Carlo simulation based on the forecasted operating results and the earn-out formulas specified in the purchase agreements.

[0000833444-24-000064:notes:258]
Cross-currency interest rate swaps: The fair value of cross-currency interest rate swaps represents the difference between the swap's reference rate and exchange rate and the interest and exchange rates for a similar instrument as of the reporting period. Cross-currency interest rate swaps are valued under a market approach using publicized prices.

[0000833444-24-000064:notes:259]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices. Unrealized gains (losses) on the deferred compensation plan assets are recognized in the consolidated statements of income where they offset unrealized gains and losses on the related deferred compensation plan liability.

[0000833444-24-000064:notes:260]
Exchange traded funds: Investments in exchange traded funds are valued using a market approach based on quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. Refer to Note 21, "Commitments and Contingencies," of the notes to consolidated financial statements for further information.

[0000833444-24-000064:notes:261]
Foreign currency exchange derivatives: The foreign currency exchange derivatives are valued under a market approach using publicized spot and forward prices.

[0000833444-24-000064:notes:262]
Interest rate swaps: The fair value of interest rate swaps represents the difference between the swap's reference rate and the interest rate for a similar instrument as of the reporting period. Interest rate swaps are valued under a market approach using publicized prices.

[0000833444-24-000064:notes:263]
The following table presents the portion of unrealized gains recognized in the consolidated statements of income that relate to equity securities still held at September 30, 2024 and 2023 (in millions):

[0000833444-24-000064:notes:264]
|  |  | Year Ended September 30, |  |
|  | 2024 |  | 2023 |  |
| Deferred compensation plan assets |  | $ | 10 |  |  | $ | 5 |  |  |
| Investments in exchange traded funds |  | 58 |  |  | 24 |  |  |

[0000833444-24-000064:notes:265]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values.

[0000833444-24-000064:notes:266]
The fair value of long-term debt was as follows (in billions):

[0000833444-24-000064:notes:267]
|  |  | September 30, |  |
|  | 2024 |  | 2023 |  |
| Public debt |  | $ | 8.1 |  |  | $ | 7.1 |  |  |
| Other long-term debt |  | 0.2 |  |  | 0.4 |  |  |
| Total fair value of long-term debt |  | $ | 8.3 |  |  | $ | 7.5 |  |  |

[0000833444-24-000064:notes:268]
The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-24-000064:notes:269]
STOCK-BASED COMPENSATION
Unless otherwise noted, all activities and amounts reported in this footnote include both continuing operations of the Company and activities and amounts related to the R&LC HVAC business. See Note 3, "Assets and Liabilities Held for Sale and Discontinued Operations" for additional details regarding divestiture of the R&LC HVAC business.

[0000833444-24-000064:notes:270]
The Johnson Controls International plc 2021 Equity and Incentive Plan authorizes stock options, stock appreciation rights, restricted (non-vested) stock/units, performance shares, performance units and other stock-based awards. The Compensation and Talent Development Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. Annual awards are typically granted in the first quarter of the fiscal year. As of September 30, 2024, there were 55 million shares of the Company's common stock reserved and 36 million shares available for issuance under the 2021 Equity and Incentive Plan.

[0000833444-24-000064:notes:271]
The following table summarizes stock-based compensation related charges and benefits (in millions):

[0000833444-24-000064:notes:272]
|  |  | Year Ended September 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Compensation expense |  | $ | 100 |  |  | $ | 101 |  |  | $ | 104 |  |
| Income tax benefit resulting from share-based compensation arrangements |  | 25 |  |  | 25 |  |  | 26 |  |
| Tax impact from exercise and vesting of equity settled awards |  | 1 |  |  | 7 |  |  | 12 |  |

[0000833444-24-000064:notes:273]
Compensation expense is recorded in selling, general and administrative expenses. The Company does not settle stock options granted under share-based payment arrangements in cash.

[0000833444-24-000064:notes:274]
Restricted (Non-vested) Stock / Units

[0000833444-24-000064:notes:275]
A summary of non-vested restricted stock awards at September 30, 2024, and changes for the year then ended, is presented below:

[0000833444-24-000064:notes:276]
|  | WeightedAveragePrice |  | Shares/UnitsSubject toRestriction |
| Non-vested, September 30, 2023 | $ | 64.90 |  |  | 2,807,113 |  |
| Granted | 55.05 |  |  | 2,090,092 |  |
| Vested | 63.75 |  |  | (1,315,306) |  |
| Forfeited | 61.42 |  |  | (677,796) |  |
| Non-vested, September 30, 2024 | $ | 59.29 |  |  | 2,904,103 |  |

[0000833444-24-000064:notes:277]
At September 30, 2024, the Company had approximately $120 million of total unrecognized compensation cost related to non-vested restricted stock arrangements granted which is expected to be recognized over a weighted-average period of 1.8 years.

[0000833444-24-000064:notes:278]
Performance Share Awards (PSU's)

[0000833444-24-000064:notes:279]
The following table summarizes the assumptions used in determining the fair value of performance share awards granted:

[0000833444-24-000064:notes:280]
|  | Year Ended September 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Risk-free interest rate | 4.21% |  | 4.04% |  | 0.99% |
| Expected volatility of the Company’s stock | 27.20% |  | 33.50% |  | 30.00% |

[0000833444-24-000064:notes:281]
A summary of the status of the Company’s non-vested PSU's at September 30, 2024, and changes for the year then ended, is presented below:

[0000833444-24-000064:notes:282]
|  | WeightedAveragePrice |  | Shares/UnitsSubject toPSU |
| Non-vested, September 30, 2023 | $ | 71.77 |  |  | 867,524 |  |
| Granted | 54.13 |  |  | 370,307 |  |
| Vested | 50.53 |  |  | (299,746) |  |
| Forfeited | 73.83 |  |  | (142,452) |  |
| Non-vested, September 30, 2024 | $ | 71.20 |  |  | 795,633 |  |

[0000833444-24-000064:notes:283]
At September 30, 2024, the Company had approximately $27 million of total unrecognized compensation cost related to non-vested performance-based share unit awards which is expected to be recognized over a weighted-average period of 1.8 years.

[0000833444-24-000064:notes:284]
The following table summarizes the assumptions used in determining the fair value of stock options granted:

[0000833444-24-000064:notes:285]
|  | Year Ended September 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Expected life of option (years) | 5.7 |  | 5.8 |  | 6.0 |
| Risk-free interest rate | 3.86% |  | 3.59% |  | 1.35% |
| Expected volatility of the Company’s stock | 29.80% |  | 29.40% |  | 27.80% |
| Expected dividend yield on the Company’s stock | 2.77% |  | 2.10% |  | 1.71% |

[0000833444-24-000064:notes:286]
A summary of stock option activity at September 30, 2024, and changes for the year then ended, is presented below:

[0000833444-24-000064:notes:287]
|  | WeightedAverageOption Price |  | SharesSubject toOption |  | WeightedAverageRemainingContractualLife (years) |  | AggregateIntrinsicValue(in millions) |
| Outstanding, September 30, 2023 | $ | 45.44 |  |  | 4,919,916 |  |  |  |  |  |
| Granted | 53.52 |  |  | 652,702 |  |  |  |  |  |
| Exercised | 40.39 |  |  | (1,004,234) |  |  |  |  |  |
| Forfeited or expired | 63.47 |  |  | (323,602) |  |  |  |  |  |
| Outstanding, September 30, 2024 | $ | 46.51 |  |  | 4,244,782 |  |  | 5.72 |  | $ | 133 |  |
| Exercisable, September 30, 2024 | $ | 41.21 |  |  | 3,141,132 |  |  | 4.16 |  | $ | 115 |  |

[0000833444-24-000064:notes:288]
The following table summarizes additional stock option information:

[0000833444-24-000064:notes:289]
|  |  | Year Ended September 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Weighted-average grant-date fair value of options granted |  | $ | 13.74 |  |  | $ | 18.21 |  |  | $ | 18.59 |  |
| Intrinsic value of options exercised (in millions) |  | 22 |  |  | 27 |  |  | 19 |  |

[0000833444-24-000064:notes:290]
At September 30, 2024, the Company had approximately $9 million of total unrecognized compensation cost related to non-vested stock options which is expected to be recognized over a weighted-average period of 1.6 years.


## us-gaap:EarningsPerShareTextBlock

[0000833444-24-000064:notes:291]
EARNINGS PER SHARE
The following table reconciles the numerators and denominators used to calculate basic and diluted earnings per share (in millions):

[0000833444-24-000064:notes:292]
|  | Year Ended September 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Income Available to Ordinary Shareholders |  |  |  |  |  |
| Income from continuing operations | $ | 1,407 |  |  | $ | 1,562 |  |  | $ | 1,279 |  |
| Income from discontinued operations | 298 |  |  | 287 |  |  | 253 |  |
| Basic and diluted income available to shareholders | $ | 1,705 |  |  | $ | 1,849 |  |  | $ | 1,532 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |
| Basic weighted average shares outstanding | 673.8 |  |  | 684.3 |  |  | 696.1 |  |
| Effect of dilutive securities: |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 2.2 |  |  | 3.1 |  |  | 3.5 |  |
| Diluted weighted average shares outstanding | 676.0 |  |  | 687.4 |  |  | 699.6 |  |
| Antidilutive Securities |  |  |  |  |  |
| Stock options and unvested restricted stock | 0.3 |  |  | 0.2 |  |  | 0.4 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-24-000064:notes:293]
EQUITY
Dividends

[0000833444-24-000064:notes:294]
The authority to declare and pay dividends is vested in the Board of Directors. The timing, declaration and payment of future dividends to holders of the Company's ordinary shares is determined by the Company's Board of Directors and depends upon many factors, including the Company's financial condition and results of operations, the capital requirements of the Company's businesses, industry practice and any other relevant factors.

[0000833444-24-000064:notes:295]
Under Irish law, dividends may only be paid (and share repurchases and redemptions must generally be funded) out of "distributable reserves." The creation of distributable reserves was accomplished by way of a capital reduction, which the Irish High Court approved on December 18, 2014 and as acquired in conjunction with the Merger.

[0000833444-24-000064:notes:296]
Share Repurchase Program

[0000833444-24-000064:notes:297]
As of September 30, 2024, approximately $1.7 billion remained available under the share repurchase program which was approved by the Company's Board of Directors in March 2021. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice.

[0000833444-24-000064:notes:298]
Accumulated Other Comprehensive Income

[0000833444-24-000064:notes:299]
The following table includes changes attributable to both continuing and discontinued operations in AOCI attributable to Johnson Controls (in millions, net of tax):

[0000833444-24-000064:notes:300]
|  | Year Ended September 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Foreign currency translation adjustments |  |  |  |  |  |
| Balance at beginning of period | $ | (970) |  |  | $ | (901) |  |  | $ | (421) |  |
| Aggregate adjustment for the period | 14 |  |  | (69) |  |  | (480) |  |
| Balance at end of period | (956) |  |  | (970) |  |  | (901) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |  |  |
| Balance at beginning of period | 15 |  |  | (11) |  |  | (17) |  |
| Current period changes in fair value | (17) |  |  | 19 |  |  | 20 |  |
| Reclassification to income (1) | (1) |  |  | 11 |  |  | (16) |  |
| Net tax impact | (1) |  |  | (4) |  |  | 2 |  |
| Balance at end of period | (4) |  |  | 15 |  |  | (11) |  |
| Pension and postretirement plans |  |  |  |  |  |
| Balance at beginning of period | — |  |  | 1 |  |  | 4 |  |
| Reclassification to income | (5) |  |  | (1) |  |  | (3) |  |
| Net tax impact | 1 |  |  | — |  |  | — |  |
| Balance at end of period | (4) |  |  | — |  |  | 1 |  |
| Accumulated other comprehensive loss, end of period | $ | (964) |  |  | $ | (955) |  |  | $ | (911) |  |

[0000833444-24-000064:notes:301]
(1)   Refer to Note 11, "Derivative Instruments and Hedging Activities," of the notes to consolidated financial statements for disclosure of the line items in the consolidated statements of income affected by reclassifications from AOCI into income related to derivatives.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-24-000064:notes:302]
RETIREMENT PLANS
Unless otherwise noted, all activities and amounts reported in this footnote include both continuing operations of the Company and activities and amounts related to the R&LC HVAC business. See Note 3, "Assets and Liabilities Held for Sale and Discontinued Operations" for additional details regarding divestiture of the R&LC HVAC business.

[0000833444-24-000064:notes:303]
Pension Benefits

[0000833444-24-000064:notes:304]
The Company has non-contributory defined benefit pension plans covering certain U.S. and non-U.S. employees. The benefits provided are primarily based on years of service and average compensation or a monthly retirement benefit amount. The Company’s U.S. pension plans no longer allow new participants to enter the plans and no longer accrue benefits. Funding for U.S. pension plans equals or exceeds the minimum requirements of the Employee Retirement Income Security Act of 1974.

[0000833444-24-000064:notes:305]
Funding for non-U.S. plans observes the local legal and regulatory limits. Also, the Company makes contributions to union-trusteed pension funds for construction and service personnel.

[0000833444-24-000064:notes:306]
The following table includes information for pension plans with accumulated benefit obligations ("ABO") in excess of plan assets (in millions):

[0000833444-24-000064:notes:307]
|  |  | September 30, |  |
|  |  | 2024 |  | 2023 |  |
| Accumulated benefit obligation |  | $ | 331 |  |  | $ | 1,834 |  |  |
| Fair value of plan assets |  | 149 |  |  | 1,618 |  |  |

[0000833444-24-000064:notes:308]
The following table includes information for pension plans with projected benefit obligations ("PBO") in excess of plan assets (in millions):

[0000833444-24-000064:notes:309]
|  |  | September 30, |  |
|  |  | 2024 |  | 2023 |  |
| Projected benefit obligation |  | $ | 344 |  |  | $ | 1,846 |  |  |
| Fair value of plan assets |  | 163 |  |  | 1,633 |  |  |

[0000833444-24-000064:notes:310]
The Company contributed $25 million to the defined benefit plans in fiscal 2024 and expects to contribute approximately $23 million in cash in fiscal 2025. None of contributions made by the Company were voluntary.

[0000833444-24-000064:notes:311]
Projected benefit payments from the plans as of September 30, 2024 are estimated as follows (in millions):

[0000833444-24-000064:notes:312]
| 2025 | $ | 269 |  |
| 2026 | 240 |  |
| 2027 | 238 |  |
| 2028 | 231 |  |
| 2029 | 233 |  |
| 2030 - 2034 | 1,154 |  |

[0000833444-24-000064:notes:313]
Postretirement Benefits

[0000833444-24-000064:notes:314]
The Company provides certain health care and life insurance benefits for eligible retirees and their dependents primarily in the U.S. and Canada. Most non-U.S. employees are covered by government sponsored programs. The cost to the Company is not significant.

[0000833444-24-000064:notes:315]
Eligibility for coverage is based on meeting certain years of service and retirement age qualifications. These benefits may be subject to deductibles, co-payment provisions and other limitations. The Company has reserved the right to modify these benefits.

[0000833444-24-000064:notes:316]
The health care cost trend assumption does not have a significant effect on the amounts reported.

[0000833444-24-000064:notes:317]
The following table includes information for postretirement plans with accumulated postretirement benefit obligations ("APBO") in excess of plan assets (in millions):

[0000833444-24-000064:notes:318]
|  |  | September 30, |  |
|  |  | 2024 |  | 2023 |  |
| Accumulated postretirement benefit obligation |  | $ | 56 |  |  | $ | 58 |  |  |
| Fair value of plan assets |  | 26 |  |  | 24 |  |  |

[0000833444-24-000064:notes:319]
The Company contributed $2 million to the postretirement benefit plans in fiscal 2024 and expects to contribute approximately $2 million in cash in fiscal 2025.

[0000833444-24-000064:notes:320]
| 2025 | $ | 9 |  |
| 2026 | 9 |  |
| 2027 | 9 |  |
| 2028 | 7 |  |
| 2029 | 6 |  |
| 2030 - 2034 | 25 |  |

[0000833444-24-000064:notes:321]
Defined Contribution Plans

[0000833444-24-000064:notes:322]
The Company sponsors various defined contribution savings plans that allow employees to contribute a portion of their pre-tax and/or after-tax income in accordance with plan specified guidelines. Under specified conditions, the Company will contribute to certain savings plans based on predetermined percentages of compensation earned by the employee and/or will match a percentage of the employee contributions up to certain limits. Defined contribution plan contributions charged to expense amounted to $208 million, $209 million and $196 million during the years ended September 30, 2024, 2023 and 2022, respectively.

[0000833444-24-000064:notes:323]
Multiemployer Benefit Plans

[0000833444-24-000064:notes:324]
The Company contributes to multiemployer benefit plans based on obligations arising from collective bargaining agreements related to certain of its hourly employees in the U.S. These plans provide retirement benefits to participants based on their service to contributing employers. The benefits are paid from assets held in trust for that purpose. The trustees typically are responsible for determining the level of benefits to be provided to participants as well as for such matters as the investment of the assets and the administration of the plans.

[0000833444-24-000064:notes:325]
The risks of participating in these multiemployer benefit plans are different from single-employer benefit plans in the following aspects:

[0000833444-24-000064:notes:326]
•Assets contributed to the multiemployer benefit plan by one employer may be used to provide benefits to employees of other participating employers.

[0000833444-24-000064:notes:327]
•If a participating employer stops contributing to the multiemployer benefit plan, the unfunded obligations of the plan may be borne by the remaining participating employers.

[0000833444-24-000064:notes:328]
•If the Company stops participating in some of its multiemployer benefit plans, it may be required to pay those plans an amount based on its allocable share of the underfunded status of the plan, referred to as a withdrawal liability.

[0000833444-24-000064:notes:329]
The Company participates in approximately 240 multiemployer benefit plans, none of which are individually significant to the Company. The number of employees covered by the Company’s multiemployer benefit plans has remained consistent over the past three years, and there have been no significant changes that affect the comparability of fiscal 2024, 2023 and 2022 contributions. The Company recognizes expense for the contractually-required contribution for each period. The Company contributed $80 million, $67 million and $71 million to multiemployer benefit plans during the years ended September 30, 2024, 2023 and 2022, respectively.

[0000833444-24-000064:notes:330]
Based on the most recent information available, the Company believes that the present value of actuarial accrued liabilities in certain of these multiemployer benefit plans may exceed the value of the assets held in trust to pay benefits. Currently, the Company is not aware of any significant multiemployer benefit plans for which it is probable or reasonably possible that the Company will be obligated to make up any shortfall in funds. Moreover, if the Company were to exit certain markets or otherwise cease making contributions to these funds, the Company could trigger a withdrawal liability. Currently, the Company is not aware of any multiemployer benefit plans for which it is probable or reasonably possible that the Company will have a significant withdrawal liability. Any accrual for a shortfall or withdrawal liability will be recorded when it is probable that a liability exists and it can be reasonably estimated.

[0000833444-24-000064:notes:331]
Plan Assets

[0000833444-24-000064:notes:332]
The Company’s investment policies employ an approach whereby a mix of equities, fixed income and alternative investments are used to maximize the long-term return of plan assets for a prudent level of risk. The investment portfolio primarily contains a diversified blend of equity and fixed income investments. Equity investments are diversified across U.S. and non-U.S. stocks, as well as growth, value and small to large capitalization. Fixed income investments include corporate and government issues, with short-, mid- and long-term maturities, with a focus on investment grade when purchased and a target duration close to that of the plan liability. Investment and market risks are measured and monitored on an ongoing basis through regular investment portfolio reviews, annual liability measurements and periodic asset/liability studies. The majority of the real estate component of the portfolio is invested in a diversified portfolio of high-quality, operating properties with cash yields greater than the targeted appreciation. Investments in other alternative asset classes, including hedge funds, diversify the expected investment returns relative to the equity and fixed income investments. As a result of the Company's diversification strategies, there are no significant concentrations of risk within the portfolio of investments.

[0000833444-24-000064:notes:333]
The Company’s actual asset allocations are in line with target allocations. The Company rebalances asset allocations as appropriate, in order to stay within a range of allocation for each asset category.

[0000833444-24-000064:notes:334]
The expected return on plan assets is based on the Company’s expectation of the long-term average rate of return of the capital markets in which the plans invest. The average market returns are adjusted, where appropriate, for active asset management returns. The expected return reflects the investment policy target asset mix and considers the historical returns earned for each asset category.

[0000833444-24-000064:notes:335]
The Company’s plan assets at September 30, 2024 and 2023, by asset category, are as follows (in millions):

[0000833444-24-000064:notes:336]
|  |  | Fair Value Measurements Using: |
| Asset Category |  | Total as of September 30, 2024 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| U.S. Pension |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |  |
| Large-Cap |  | 19 |  |  | 19 |  |  | — |  |  | — |  |
| Small-Cap |  | 23 |  |  | 23 |  |  | — |  |  | — |  |
| International - Developed |  | 45 |  |  | 45 |  |  | — |  |  | — |  |
| International - Emerging |  | 8 |  |  | 8 |  |  | — |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |  |
| Government |  | 265 |  |  | 265 |  |  | — |  |  | — |  |
| Corporate/Other |  | 786 |  |  | 784 |  |  | 2 |  |  | — |  |
| Total Investments in the Fair Value Hierarchy |  | 1,169 |  |  | $ | 1,144 |  |  | $ | 25 |  |  | $ | — |  |
| Investments Measured at Net Asset Value(1) |  |  |  |  |  |  |  |  |
| Alternative |  | 235 |  |  |  |  |  |  |  |
| Real Estate |  | 266 |  |  |  |  |  |  |  |
| Due to Broker |  | (79) |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 1,591 |  |  |  |  |  |  |  |
| Non-U.S. Pension |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 42 |  |  | $ | 42 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |  |
| Large-Cap |  | 88 |  |  | 9 |  |  | 79 |  |  | — |  |
| International - Developed |  | 64 |  |  | 10 |  |  | 54 |  |  | — |  |
| International - Emerging |  | 3 |  |  | — |  |  | 3 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |  |
| Government |  | 789 |  |  | 26 |  |  | 763 |  |  | — |  |
| Corporate/Other |  | 417 |  |  | 282 |  |  | 135 |  |  | — |  |
| Hedge Fund |  | 22 |  |  | — |  |  | 22 |  |  | — |  |
| Real Estate |  | 11 |  |  | 11 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy |  | 1,436 |  |  | $ | 380 |  |  | $ | 1,056 |  |  | $ | — |  |
| Real Estate Investments Measured at Net Asset Value(1) |  | 89 |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 1,525 |  |  |  |  |  |  |  |
| Postretirement |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 3 |  |  | $ | 3 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities - Global |  | 89 |  |  | — |  |  | 89 |  |  | — |  |
| Total Investments in the Fair Value Hierarchy |  | 92 |  |  | $ | 3 |  |  | $ | 89 |  |  | $ | — |  |
| Multi-Credit Strategy Investments Measured at Net Asset Value(1) |  | 69 |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 161 |  |  |  |  |  |  |  |

[0000833444-24-000064:notes:337]
|  |  | Fair Value Measurements Using: |
| Asset Category |  | Total as of September 30, 2023 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| U.S. Pension |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 61 |  |  | $ | — |  |  | $ | 61 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |  |
| Large-Cap |  | 60 |  |  | 60 |  |  | — |  |  | — |  |
| Small-Cap |  | 65 |  |  | 65 |  |  | — |  |  | — |  |
| International - Developed |  | 108 |  |  | 108 |  |  | — |  |  | — |  |
| International - Emerging |  | 20 |  |  | 20 |  |  | — |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |  |
| Government |  | 225 |  |  | 225 |  |  | — |  |  | — |  |
| Corporate/Other |  | 583 |  |  | 583 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy |  | 1,122 |  |  | $ | 1,061 |  |  | $ | 61 |  |  | $ | — |  |
| Investments Measured at Net Asset Value(1) |  |  |  |  |  |  |  |  |
| Alternative |  | 211 |  |  |  |  |  |  |
| Real Estate |  | 295 |  |  |  |  |  |  |
| Due to Broker |  | (129) |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 1,499 |  |  |  |  |  |  |  |
| Non-U.S. Pension |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 52 |  |  | $ | 52 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |  |
| Large-Cap |  | 52 |  |  | 9 |  |  | 43 |  |  | — |  |
| International - Developed |  | 52 |  |  | 12 |  |  | 40 |  |  | — |  |
| International - Emerging |  | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |  |
| Government |  | 701 |  |  | 40 |  |  | 661 |  |  | — |  |
| Corporate/Other |  | 415 |  |  | 271 |  |  | 144 |  |  | — |  |
| Hedge Fund |  | 15 |  |  | — |  |  | 15 |  |  | — |  |
| Real Estate |  | 9 |  |  | 9 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy |  | 1,298 |  |  | $ | 393 |  |  | $ | 905 |  |  | $ | — |  |
| Real Estate Investments Measured at Net Asset Value(1) |  | 90 |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 1,388 |  |  |  |  |  |  |  |
| Postretirement |  |  |  |  |  |  |  |  |
| Cash and Cash Equivalents |  | $ | 8 |  |  | $ | 8 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities - Global |  | 71 |  |  | — |  |  | 71 |  |  | — |  |
| Total Investments in the Fair Value Hierarchy |  | 79 |  |  | 8 |  |  | 71 |  |  | — |  |
| Multi-Credit Strategy Investments Measured at Net Asset Value(1) |  | 65 |  |  |  |  |  |  |  |
| Total Plan Assets |  | $ | 144 |  |  |  |  |  |  |  |

[0000833444-24-000064:notes:338]
(1)The fair value of certain real estate, multi-credit strategy, and alternative investments do not have a readily determinable fair value and require the fund managers to independently arrive at fair value by calculating net asset value ("NAV") per share. In order to calculate NAV per share, the fund managers value the investments using any one, or a combination of, the following methods: independent third party appraisals, discounted cash flow analysis of net cash flows projected to be generated by the investment and recent sales of comparable investments. Assumptions used to revalue the investments are updated every quarter.

[0000833444-24-000064:notes:339]
Due to the fact that the fund managers calculate NAV per share, the Company utilizes a practical expedient for measuring the fair value of its real estate, multi-credit strategy, and alternative investments, as provided for under ASC 820, "Fair Value Measurement." In applying the practical expedient, the Company is not required to further adjust the NAV provided by the fund manager in order to determine the fair value of its investments as the NAV per share is calculated in a manner consistent with the measurement principles of ASC 946, "Financial Services - Investment Companies," and as of the Company's measurement date. The Company believes this is an appropriate methodology to obtain the fair value of these assets. The fair value amounts presented in these tables are intended to permit reconciliation of total plan assets to the amounts presented in the notes to consolidated financial statements.

[0000833444-24-000064:notes:340]
The following is a description of the valuation methodologies used for assets measured at fair value. Certain assets are held within commingled funds which are valued at the unitized NAV or percentage of the net asset value as determined by the manager of the fund. These values are based on the fair value of the underlying net assets owned by the fund.

[0000833444-24-000064:notes:341]
Cash and Cash Equivalents: The fair value of cash and cash equivalents is valued at cost.

[0000833444-24-000064:notes:342]
Equity Securities: The fair value of equity securities is determined by direct quoted market prices. The underlying holdings are direct quoted market prices on regulated financial exchanges.

[0000833444-24-000064:notes:343]
Fixed Income Securities: The fair value of fixed income securities is determined by direct or indirect quoted market prices. If indirect quoted market prices are utilized, the value of assets held in separate accounts is not published, but the investment managers report daily the underlying holdings. The underlying holdings are direct quoted market prices on regulated financial exchanges.

[0000833444-24-000064:notes:344]
Hedge Funds: The fair value of hedge funds is accounted for by the custodian. The custodian obtains valuations from underlying managers based on market quotes for the most liquid assets and alternative methods for assets that do not have sufficient trading activity to derive prices. The Company and custodian review the methods used by the underlying managers to value the assets. The Company believes this is an appropriate methodology to obtain the fair value of these assets.

[0000833444-24-000064:notes:345]
Real Estate: The fair value of real estate is determined by quoted market prices of the underlying Real Estate Investment Trusts

[0000833444-24-000064:notes:346]
("REITs"), which are securities traded on an open exchange.

[0000833444-24-000064:notes:347]
The methods described above may produce a fair value calculation that may not be indicative of net realizable value or reflective of future fair values. Furthermore, while the Company believes its valuation methods are appropriate and consistent with other market participants, the use of different methodologies or assumptions to determine the fair value of certain financial instruments could result in a different fair value measurement at the reporting date.

[0000833444-24-000064:notes:348]
Funded Status

[0000833444-24-000064:notes:349]
The following table contains the ABO and reconciliations of the changes in the PBO, the changes in plan assets and the funded status (in millions):

[0000833444-24-000064:notes:350]
|  | Pension Benefits |  | PostretirementBenefits |
|  | U.S. Plans |  | Non-U.S. Plans |  |
| September 30, | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Accumulated Benefit Obligation | $ | 1,603 |  |  | $ | 1,564 |  |  | $ | 1,563 |  |  | $ | 1,424 |  |  | $ | 73 |  |  | $ | 76 |  |
| Change in Projected Benefit Obligation |  |  |  |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of year | $ | 1,564 |  |  | $ | 1,822 |  |  | $ | 1,473 |  |  | $ | 1,471 |  |  | $ | 77 |  |  | $ | 89 |  |
| Service cost | — |  |  | — |  |  | 17 |  |  | 16 |  |  | — |  |  | — |  |
| Interest cost | 79 |  |  | 78 |  |  | 69 |  |  | 68 |  |  | 4 |  |  | 4 |  |
| Plan participant contributions | — |  |  | — |  |  | 3 |  |  | 3 |  |  | 2 |  |  | 3 |  |
| Actuarial loss (gain) | 104 |  |  | (37) |  |  | 84 |  |  | (62) |  |  | 4 |  |  | (7) |  |
| Benefits and settlements paid | (144) |  |  | (299) |  |  | (132) |  |  | (126) |  |  | (13) |  |  | (12) |  |
| Other | — |  |  | — |  |  | (3) |  |  | (3) |  |  | (1) |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | 106 |  |  | 106 |  |  | — |  |  | — |  |
| Projected benefit obligation at end of year | $ | 1,603 |  |  | $ | 1,564 |  |  | $ | 1,617 |  |  | $ | 1,473 |  |  | $ | 73 |  |  | $ | 77 |  |
| Change in Plan Assets |  |  |  |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year | $ | 1,499 |  |  | $ | 1,730 |  |  | $ | 1,388 |  |  | $ | 1,433 |  |  | $ | 144 |  |  | $ | 144 |  |
| Actual return on plan assets | 234 |  |  | 66 |  |  | 137 |  |  | (77) |  |  | 26 |  |  | 7 |  |
| Employer and employee contributions | 2 |  |  | 3 |  |  | 26 |  |  | 55 |  |  | 4 |  |  | 5 |  |
| Benefits paid | (144) |  |  | (85) |  |  | (67) |  |  | (61) |  |  | (13) |  |  | (12) |  |
| Settlement payments | — |  |  | (215) |  |  | (65) |  |  | (65) |  |  | — |  |  | — |  |
| Other | — |  |  | — |  |  | 1 |  |  | (2) |  |  | — |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | 105 |  |  | 105 |  |  | — |  |  | — |  |
| Fair value of plan assets at end of year | $ | 1,591 |  |  | $ | 1,499 |  |  | $ | 1,525 |  |  | $ | 1,388 |  |  | $ | 161 |  |  | $ | 144 |  |
| Funded status | $ | (12) |  |  | $ | (65) |  |  | $ | (92) |  |  | $ | (85) |  |  | $ | 88 |  |  | $ | 67 |  |
| Amounts recognized in the consolidated statements of financial position consist of: |
| Other noncurrent assets | $ | 2 |  |  | $ | 1 |  |  | $ | 62 |  |  | $ | 62 |  |  | $ | 118 |  |  | $ | 101 |  |
| Noncurrent assets held for sale | — |  |  | — |  |  | 52 |  |  | 35 |  |  | — |  |  | — |  |
| Accrued compensation and benefits | (2) |  |  | (3) |  |  | (12) |  |  | (12) |  |  | (2) |  |  | (2) |  |
| Pension and postretirement benefit obligations | (12) |  |  | (63) |  |  | (166) |  |  | (143) |  |  | (28) |  |  | (32) |  |
| Noncurrent liabilities held for sale | — |  |  | — |  |  | (28) |  |  | (27) |  |  | — |  |  | — |  |
| Net amount recognized | $ | (12) |  |  | $ | (65) |  |  | $ | (92) |  |  | $ | (85) |  |  | $ | 88 |  |  | $ | 67 |  |
| Weighted Average Assumptions (1) |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate (2) | 4.60 | % |  | 5.48 | % |  | 4.35 | % |  | 4.72 | % |  | 4.50 | % |  | 5.42 | % |
| Rate of compensation increase | N/A |  | N/A |  | 3.01 | % |  | 2.90 | % |  | N/A |  | N/A |
| Interest crediting rate | N/A |  | N/A |  | 1.58 | % |  | 1.63 | % |  | N/A |  | N/A |

[0000833444-24-000064:notes:351]
(1)Plan assets and obligations are determined based on a September 30 measurement date at September 30, 2024 and 2023.

[0000833444-24-000064:notes:352]
(2) The Company considers the expected benefit payments on a plan-by-plan basis when setting assumed discount rates. As a result, the Company uses different discount rates for each plan depending on the plan jurisdiction, the demographics of participants and the expected timing of benefit payments. For the U.S. pension and postretirement plans, the Company uses a discount rate provided by an independent third party calculated based on an appropriate mix of high quality bonds. For the non-U.S. pension and postretirement plans, the Company consistently uses the relevant country specific benchmark indices for

[0000833444-24-000064:notes:353]
determining the various discount rates. The Company has elected to utilize a full yield curve approach in the estimation of service and interest components of net periodic benefit cost (credit) for pension and other postretirement for plans that utilize a yield curve approach. The full yield curve approach applies the specific spot rates along the yield curve used in the determination of the benefit obligation to the relevant projected cash flows.

[0000833444-24-000064:notes:354]
The fiscal 2024 net actuarial losses related to changes in the projected benefit obligation were primarily the result of the decrease in discount rates globally. The fiscal 2023 net actuarial gains related to changes in the projected benefit obligation were primarily the result of the increase in discount rates globally.

[0000833444-24-000064:notes:355]
Net Periodic Benefit Cost

[0000833444-24-000064:notes:356]
The following table contains the components of net periodic benefit costs, which are recorded in selling, general and administrative expenses or cost of sales consistent with the related employees' salaries in the consolidated statements of income (in millions):

[0000833444-24-000064:notes:357]
|  | Pension Benefits |  | Postretirement Benefits |
|  | U.S. Plans |  | Non-U.S. Plans |  |
| Year ended September 30, | 2024 |  | 2023 |  | 2022 |  | 2024 |  | 2023 |  | 2022 |  | 2024 |  | 2023 |  | 2022 |
| Components of Net Periodic Benefit Cost (Credit): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 17 |  |  | $ | 16 |  |  | $ | 20 |  |  | $ | — |  |  | $ | — |  |  | $ | 1 |  |
| Interest cost | 79 |  |  | 78 |  |  | 56 |  |  | 69 |  |  | 68 |  |  | 39 |  |  | 4 |  |  | 4 |  |  | 2 |  |
| Expected return on plan assets | (120) |  |  | (131) |  |  | (150) |  |  | (72) |  |  | (77) |  |  | (81) |  |  | (9) |  |  | (9) |  |  | (9) |  |
| Net actuarial (gain) loss | (9) |  |  | 28 |  |  | 16 |  |  | 22 |  |  | 86 |  |  | (116) |  |  | (14) |  |  | (5) |  |  | 4 |  |
| Settlement loss | — |  |  | 1 |  |  | 1 |  |  | — |  |  | 6 |  |  | 5 |  |  | — |  |  | — |  |  | — |  |
| Amortization of prior service credit | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (5) |  |  | (4) |  |  | (4) |  |
| Other | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | — |  |  |  |  | — |  |  | — |  |
| Net periodic benefit cost (credit) | $ | (50) |  |  | $ | (24) |  |  | $ | (77) |  |  | $ | 37 |  |  | $ | 99 |  |  | $ | (133) |  |  | $ | (24) |  |  | $ | (14) |  |  | $ | (6) |  |
| Expense Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate | 5.48 | % |  | 5.08 | % |  | 2.52 | % |  | 4.72 | % |  | 4.36 | % |  | 1.79 | % |  | 5.42 | % |  | 4.92 | % |  | 2.30 | % |
| Expected return on plan assets | 8.50 | % |  | 8.25 | % |  | 7.00 | % |  | 5.26 | % |  | 5.02 | % |  | 3.70 | % |  | 6.62 | % |  | 6.64 | % |  | 5.29 | % |
| Rate of compensation increase | N/A |  | N/A |  | N/A |  | 2.90 | % |  | 3.00 | % |  | 2.85 | % |  | N/A |  | N/A |  | N/A |
| Interest crediting rate | 6.00 | % |  | N/A |  | N/A |  | 1.63 | % |  | 1.69 | % |  | 1.44 | % |  | N/A |  | N/A |  | N/A |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-24-000064:notes:358]
RESTRUCTURING AND RELATED COSTS
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company commits to restructuring plans as necessary. Restructuring activities generally result in charges for workforce reductions, plant closures, asset impairments and other related costs which are reported as restructuring and impairment costs in the Company’s consolidated statements of income. The Company expects the restructuring actions to reduce cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense.

[0000833444-24-000064:notes:359]
During the fourth quarter of fiscal 2024, the Company completed its previous restructuring plan and committed to a new multi-year restructuring plan to address stranded costs and further right-size its global operations as a result of previously announced portfolio simplification actions. It is expected that one-time restructuring costs, including severance and other employee termination benefits, contract termination costs, and certain other related cash and non-cash charges, of approximately $400 million will be incurred over the course of fiscal 2025, 2026 and 2027. Restructuring costs will be incurred across all segments and Corporate functions.

[0000833444-24-000064:notes:360]
The following table summarizes restructuring and related costs (in millions):

[0000833444-24-000064:notes:361]
|  |  |  | Year Ended September 30, 2024 |  |  |
| Building Solutions North America |  |  | $ | 12 |  |  |  |
| Building Solutions EMEA/LA |  |  | 45 |  |  |  |
| Building Solutions Asia Pacific |  |  | 11 |  |  |  |
| Global Products |  |  | 38 |  |  |  |
| Corporate |  |  | 37 |  |  |  |
| Total |  |  | $ | 143 |  |  |  |

[0000833444-24-000064:notes:362]
The following table summarizes changes in the restructuring reserve, which is included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-24-000064:notes:363]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  |  |  | Total |
| Restructuring and related costs | $ | 191 |  |  | $ | 37 |  |  | $ | 33 |  |  |  |  | $ | 261 |  |
| Utilized—cash | (98) |  |  | — |  |  | (18) |  |  |  |  | (116) |  |
| Utilized—noncash | — |  |  | (37) |  |  | (3) |  |  |  |  | (40) |  |
| Balance at September 30, 2023 | 93 |  |  | — |  |  | 12 |  |  |  |  | 105 |  |
| Additional restructuring and related costs | 71 |  | 41 |  | 31 |  |  |  | 143 |
| Utilized—cash | (138) |  |  | — |  |  | (25) |  |  |  |  | (163) |  |
| Utilized—noncash | — |  |  | (41) |  |  | (1) |  |  |  |  | (42) |  |
| Other | 32 |  | — |  |  | — |  |  |  |  | 32 |
| Balance at September 30, 2024 | $ | 58 |  |  | $ | — |  |  | $ | 17 |  |  |  |  | $ | 75 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-24-000064:notes:364]
INCOME TAXES
The components of the Company’s income tax provision from continuing operations are as follows (in millions):

[0000833444-24-000064:notes:365]
|  | 2024 |  | 2023 |  | 2022 |
| Tax expense at Ireland statutory rate of 12.5% | $ | 190 |  |  | $ | 139 |  |  | $ | 139 |  |
| U.S. state income tax, net of federal benefit | 42 |  |  | 30 |  |  | (26) |  |
| Income subject to the U.S. federal tax rate | 63 |  |  | 42 |  |  | (101) |  |
| Income subject to rates different than the statutory rate | (204) |  |  | 44 |  |  | 67 |  |
| Reserve and valuation allowance adjustments | (139) |  |  | (559) |  |  | (301) |  |
| Intellectual property transactions and adjustments | — |  |  | (176) |  |  | — |  |
| Impact of acquisitions and divestitures | 121 |  |  | — |  |  | — |  |
| Restructuring and impairment costs | 38 |  |  | 12 |  |  | 40 |  |
| Income tax provision (benefit) | $ | 111 |  |  | $ | (468) |  |  | $ | (182) |  |
| Effective tax rate | 7 | % |  | (42) | % |  | (16) | % |

[0000833444-24-000064:notes:366]
For fiscal 2024, the effective tax rate for continuing operations was 7% and was lower than the statutory tax rate primarily due to tax reserve adjustments as the result of tax audit resolutions and expired statute of limitations for certain tax years, valuation allowance adjustments and the benefits of continuing global tax planning initiatives, partially offset by the establishment of a deferred tax liability on the outside basis difference of the Company’s investment in certain subsidiaries as a result of the planned divestiture of its R&LC HVAC business and the unfavorable impact of impairment and restructuring charges.

[0000833444-24-000064:notes:367]
For fiscal 2023, the effective tax rate for continuing operations was (42)% and was lower than the statutory tax rate primarily due to the favorable tax impacts of intellectual property tax adjustments, tax reserve adjustments as the result of tax audit

[0000833444-24-000064:notes:368]
resolutions and remeasurements, valuation allowance adjustments and the benefits of continuing global tax planning initiatives, partially offset by the unfavorable impact of impairment and restructuring charges.

[0000833444-24-000064:notes:369]
For fiscal 2022, the effective tax rate for continuing operations was (16)% and was lower than the statutory tax rate primarily due to favorable impact of tax reserve adjustments as the result of expired statute of limitations for certain tax years and the benefits of continuing global tax planning initiatives, partially offset by the unfavorable impact of impairment and restructuring charges and the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain subsidiaries as a result of the planned divestitures.

[0000833444-24-000064:notes:370]
Valuation Allowances

[0000833444-24-000064:notes:371]
The Company reviews the realizability of its deferred tax assets and related valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary.

[0000833444-24-000064:notes:372]
In fiscal 2024, due to changes in forecasted taxable income, the Company determined that it was more likely than not that certain deferred tax assets of Mexico and Germany would be realized. The valuation allowance adjustment resulted in a tax benefit of $48 million.

[0000833444-24-000064:notes:373]
In fiscal 2023, due to changes in forecasted taxable income, the Company determined that it was more likely than not that certain deferred tax assets of Canada, Mexico, and Spain would be realized. The valuation allowance adjustment resulted in a tax benefit of $121 million.

[0000833444-24-000064:notes:374]
The following table summarizes changes in the valuation allowance (in millions):

[0000833444-24-000064:notes:375]
|  | 2024 |  | 2023 |  | 2022 |
| Balance at beginning of period | $ | 6,279 |  |  | $ | 5,906 |  |  | $ | 5,812 |  |
| Allowance provision for new operating and other loss carryforwards | 215 |  |  | 544 |  |  | 306 |  |
| Allowance reductions | (236) |  |  | (171) |  |  | (212) |  |
| Balance at end of period | $ | 6,258 |  |  | $ | 6,279 |  |  | $ | 5,906 |  |

[0000833444-24-000064:notes:376]
Uncertain Tax Positions

[0000833444-24-000064:notes:377]
The Company is subject to income taxes in the U.S. and numerous non-U.S. jurisdictions. Judgment is required in determining the worldwide provision for income taxes and recording the related assets and liabilities. In the ordinary course of the Company’s business, there are many transactions and calculations where the ultimate tax determination is uncertain. The Company is regularly under audit by tax authorities.

[0000833444-24-000064:notes:378]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0000833444-24-000064:notes:379]
|  | 2024 |  | 2023 |  | 2022 |
| Beginning balance, October 1 | $ | 2,158 |  |  | $ | 2,485 |  |  | $ | 2,678 |  |
| Additions for tax positions related to the current year | 39 |  |  | 59 |  |  | 164 |  |
| Additions for tax positions of prior years | 53 |  |  | 89 |  |  | 31 |  |
| Reductions for tax positions of prior years | (35) |  |  | (23) |  |  | (47) |  |
| Settlements with taxing authorities | (35) |  |  | (6) |  |  | (7) |  |
| Statute closings and audit resolutions | (127) |  |  | (446) |  |  | (334) |  |
| Ending balance, September 30 | $ | 2,053 |  |  | $ | 2,158 |  |  | $ | 2,485 |  |

[0000833444-24-000064:notes:380]
The following table summarizes tax effected unrecognized tax benefits that, if recognized, would impact the effective tax rate and the related accrued interest, net of tax benefit (in millions):

[0000833444-24-000064:notes:381]
|  | September 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Tax effected unrecognized tax benefits that, if recognized, would affect the effective tax rate | $ | 1,466 |  |  | $ | 1,533 |  |  | $ | 1,935 |  |
| Net accrued interest | 398 |  |  | 329 |  |  | 281 |  |

[0000833444-24-000064:notes:382]
In fiscal 2024, as the result of tax audit resolutions and statute expirations in various jurisdictions, the Company adjusted its reserve for uncertain tax positions which resulted in a $91 million net benefit to income tax expense.

[0000833444-24-000064:notes:383]
In fiscal 2023, as the result of tax audit resolutions, statute expirations, and remeasurements of ongoing controversy matters in various jurisdictions, the Company adjusted its reserve for uncertain tax positions which resulted in a $438 million net benefit to income tax expense.

[0000833444-24-000064:notes:384]
In fiscal 2022, the statute of limitations for certain tax years expired, which resulted in a $301 million benefit to income tax expense.

[0000833444-24-000064:notes:385]
In the U.S., fiscal years 2019 through 2020 are currently under audit and fiscal years 2017 through 2018 are currently under appeal with the Internal Revenue Service (“IRS”) for certain legal entities. In addition, fiscal years 2016 through 2019 are also under exam by the IRS in relation to a separate consolidated filing group. Additionally, the Company is currently under exam in the following major non-U.S. jurisdictions for continuing operations:

[0000833444-24-000064:notes:386]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2016 - 2017; 2019-2020 |
| Germany |  | 2007 - 2021 |
| Mexico |  | 2016 - 2019 |
| United Kingdom |  | 2014 - 2015; 2018; 2020 - 2021 |

[0000833444-24-000064:notes:387]
It is reasonably possible that certain tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense. Based upon the circumstances surrounding these examinations, the impact is not currently quantifiable.

[0000833444-24-000064:notes:388]
Other Tax Matters

[0000833444-24-000064:notes:389]
During fiscal 2024, 2023 and 2022, the Company incurred charges for restructuring and impairment costs of $510 million, $1,049 million and $701 million, which generated tax benefits of $26 million, $120 million and $47 million, respectively.

[0000833444-24-000064:notes:390]
Impacts of Tax Legislation and Change in Statutory Tax Rates

[0000833444-24-000064:notes:391]
On December 18, 2023, the president of Ireland signed into law the Finance (No. 2) Bill 2023, which included legislation regarding the implementation of the Pillar Two global minimum tax. The Pillar Two legislation is effective for the Company’s fiscal year beginning October 1, 2024.

[0000833444-24-000064:notes:392]
On September 11, 2023, the Schaffhausen parliament approved a partial revision of the cantonal act on direct taxation: Immediate Minimum Taxation Measure (“IMTM”). On November 19, 2023, IMTM was approved in a public referendum in the canton of Schaffhausen, was published in the cantonal official gazette on December 8, 2023, and was effective starting January 1, 2024. The IMTM increased Switzerland's combined statutory income tax rate to approximately 15%. As a result, in fiscal 2024, the Company recorded a noncash discrete net tax benefit of $80 million due to the remeasurement of deferred tax assets and liabilities related to Switzerland and the canton of Schaffhausen.

[0000833444-24-000064:notes:393]
On August 16, 2022, the U.S. enacted the Inflation Reduction Act (“IRA”) which, among other things, created a new book minimum tax of at least 15% of consolidated GAAP pre-tax income for corporations with average book income in excess of $1 billion. The book minimum tax was first applicable in fiscal 2024 and did not have a material impact on the Company's effective tax rate.

[0000833444-24-000064:notes:394]
During fiscal 2024, 2023 and 2022, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-24-000064:notes:395]
Selected Income Tax Data

[0000833444-24-000064:notes:396]
Selected income tax data related to continuing operations were as follows (in millions):

[0000833444-24-000064:notes:397]
|  | 2024 |  | 2023 |  | 2022 |
| Components of income (loss) from continuing operations before income taxes: |  |  |  |  |  |
| U.S. | $ | (406) |  |  | $ | (325) |  |  | $ | (27) |  |
| Non-U.S. | 1,928 |  |  | 1,438 |  |  | 1,139 |  |
| Income from continuing operations before income taxes | $ | 1,522 |  |  | $ | 1,113 |  |  | $ | 1,112 |  |
| Components of the provision (benefit) for income taxes: |  |  |  |  |  |
| Current |  |  |  |  |  |
| U.S. federal | $ | 330 |  |  | $ | (201) |  |  | $ | (237) |  |
| U.S. state | 86 |  |  | 94 |  |  | 47 |  |
| Non-U.S. | 102 |  |  | 289 |  |  | 199 |  |
|  | 518 |  |  | 182 |  |  | 9 |  |
| Deferred |  |  |  |  |  |
| U.S. federal | (299) |  |  | (267) |  |  | (173) |  |
| U.S. state | (26) |  |  | (25) |  |  | (70) |  |
| Non-U.S. | (82) |  |  | (358) |  |  | 52 |  |
|  | (407) |  |  | (650) |  |  | (191) |  |
| Income tax provision (benefit) | $ | 111 |  |  | $ | (468) |  |  | $ | (182) |  |
| Income taxes paid | $ | 704 |  |  | $ | 294 |  |  | $ | 439 |  |

[0000833444-24-000064:notes:398]
At September 30, 2024 and 2023, the Company recorded within the consolidated statements of financial position in other current assets approximately $100 million and $65 million, respectively, of income tax assets. At September 30, 2024 and 2023, the Company recorded within the consolidated statements of financial position in other current liabilities approximately $211 million and $249 million, respectively, of accrued income tax liabilities.

[0000833444-24-000064:notes:399]
At September 30, 2024, the Company has not provided U.S. or non-U.S. income taxes on approximately $24.5 billion of outside basis differences of consolidated subsidiaries of Johnson Controls International plc. The Company is indefinitely reinvested in these basis differences. The reduction of the outside basis differences via the sale or liquidation of these subsidiaries and/or distributions could create taxable income. The Company's intent is to reduce the outside basis differences only when it would be tax efficient. Given the numerous ways in which the basis differences may be reduced, it is not practicable to estimate the amount of unrecognized withholding taxes and deferred tax liability on the outside basis differences.

[0000833444-24-000064:notes:400]
Deferred taxes were classified in the consolidated statements of financial position as follows (in millions):

[0000833444-24-000064:notes:401]
|  | September 30, |
|  | 2024 |  | 2023 |
| Other noncurrent assets | $ | 1,969 |  |  | $ | 1,480 |  |
| Other noncurrent liabilities | (301) |  |  | (316) |  |
| Net deferred tax asset | $ | 1,668 |  |  | $ | 1,164 |  |

[0000833444-24-000064:notes:402]
Temporary differences and carryforwards which gave rise to deferred tax assets and liabilities included (in millions):

[0000833444-24-000064:notes:403]
|  | September 30, |
|  | 2024 |  | 2023 |
| Deferred tax assets |  |  |  |
| Accrued expenses and reserves | $ | 661 |  |  | $ | 469 |  |
| Employee and retiree benefits | 43 |  |  | 88 |  |
| Property, plant and equipment | 729 |  |  | 638 |  |
| Net operating loss and other credit carryforwards | 6,628 |  |  | 6,667 |  |
| Research and development | 219 |  |  | 171 |  |
| Intangible assets | 306 |  |  | — |  |
| Operating lease liabilities | 294 |  |  | 341 |  |
| Other, net | 455 |  |  | 269 |  |
|  | 9,335 |  |  | 8,643 |  |
| Valuation allowances | (6,258) |  |  | (6,279) |  |
|  | 3,077 |  |  | 2,364 |  |
| Deferred tax liabilities |  |  |  |
| Subsidiaries, joint ventures and partnerships | 440 |  |  | 359 |  |
| Intangible assets | — |  |  | 248 |  |
| Operating lease right-of-use assets | 294 |  |  | 341 |  |
| Other liabilities | 675 |  |  | 252 |  |
|  | 1,409 |  |  | 1,200 |  |
| Net deferred tax asset | $ | 1,668 |  |  | $ | 1,164 |  |

[0000833444-24-000064:notes:404]
At September 30, 2024, the Company had available net operating loss carryforwards of approximately $22.1 billion, of which $11.8 billion will expire at various dates between 2025 and 2044, and the remainder has an indefinite carryforward period. The Company had available U.S. foreign tax credit carryforwards at September 30, 2024 of $35 million which will expire in 2029. The valuation allowance, generally, is for loss and credit carryforwards for which realization is uncertain because it is unlikely that the losses and/or credits will be realized given the lack of sustained profitability and/or limited carryforward periods in certain countries.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-24-000064:notes:405]
SEGMENT INFORMATION
ASC 280, "Segment Reporting," establishes the standards for reporting information about segments in financial statements. In applying the criteria set forth in ASC 280, the Company has determined that it has four reportable segments for financial reporting purposes.

[0000833444-24-000064:notes:406]
The Company conducts its business through four business segments:

[0000833444-24-000064:notes:407]
•Building Solutions North America which operates in the United States and Canada;

[0000833444-24-000064:notes:408]
•Building Solutions EMEA/LA which operates in Europe, the Middle East, Africa and Latin America;

[0000833444-24-000064:notes:409]
•Building Solutions Asia Pacific which operates in Asia Pacific; and

[0000833444-24-000064:notes:410]
•Global Products which operates worldwide.

[0000833444-24-000064:notes:411]
The Building Solutions segments:

[0000833444-24-000064:notes:412]
•Design, sell, install and service HVAC, controls, building management, refrigeration, integrated electronic security and integrated fire-detection and suppression systems; and

[0000833444-24-000064:notes:413]
•Provide energy-efficiency solutions and technical services, including data-driven "smart building" solutions as well as inspection, scheduled maintenance, and repair and replacement of mechanical and controls systems.

[0000833444-24-000064:notes:414]
The Global Products segment designs, manufactures and sells:

[0000833444-24-000064:notes:415]
•HVAC equipment, controls software and software services;

[0000833444-24-000064:notes:416]
•Refrigeration equipment and controls;

[0000833444-24-000064:notes:417]
•Fire protection and suppression; and

[0000833444-24-000064:notes:418]
•Security products, including intrusion security, anti-theft devices, access control, and video surveillance and management systems.

[0000833444-24-000064:notes:419]
The Company’s segments provide products and services primarily to commercial, institutional, industrial, data center, and governmental customers.

[0000833444-24-000064:notes:420]
Management evaluates the performance of its segments primarily on segment earnings before interest, taxes and amortization ("EBITA"), which represents income from continuing operations before income taxes and noncontrolling interests, excluding  amortization of intangible assets, corporate expenses, restructuring and impairment costs, the water systems AFFF settlement costs and AFFF insurance recoveries, net financing charges, loss on divestiture and net mark-to-market gains and losses related to pension and postretirement plans and restricted asbestos investments.

[0000833444-24-000064:notes:421]
Financial information relating to the Company’s reportable segments is as follows (in millions):

[0000833444-24-000064:notes:422]
|  | Year Ended September 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Net Sales |  |  |  |  |  |
| Building Solutions North America | $ | 11,348 |  |  | $ | 10,330 |  |  | $ | 9,367 |  |
| Building Solutions EMEA/LA | 4,296 |  |  | 4,096 |  |  | 3,845 |  |
| Building Solutions Asia Pacific | 2,237 |  |  | 2,746 |  |  | 2,714 |  |
| Global Products | 5,071 |  |  | 5,159 |  |  | 4,711 |  |
| Total net sales | $ | 22,952 |  |  | $ | 22,331 |  |  | $ | 20,637 |  |

[0000833444-24-000064:notes:423]
|  | Year Ended September 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Segment EBITA |  |  |  |  |  |
| Building Solutions North America | $ | 1,663 |  |  | $ | 1,394 |  |  | $ | 1,122 |  |
| Building Solutions EMEA/LA (1) | 391 |  |  | 316 |  |  | 358 |  |
| Building Solutions Asia Pacific | 261 |  |  | 343 |  |  | 332 |  |
| Global Products | 1,403 |  |  | 1,317 |  |  | 970 |  |
| Total segment EBITA | 3,718 |  |  | 3,370 |  |  | 2,782 |  |
| Amortization of intangible assets | 476 |  |  | 426 |  |  | 413 |  |
| Corporate expenses | 490 |  |  | 429 |  |  | 369 |  |
| Restructuring and impairment costs | 510 |  |  | 1,049 |  |  | 701 |  |
| Water systems AFFF settlement (2) | 750 |  |  | — |  |  | — |  |
| AFFF insurance recoveries (2) | (367) |  |  | — |  |  | — |  |
| Net financing charges | 342 |  |  | 258 |  |  | 205 |  |
| Loss on divestiture | 42 |  |  | — |  |  | — |  |
| Net mark-to-market (gain) loss | (47) |  |  | 95 |  |  | (18) |  |
| Income from continuing operations before income taxes | $ | 1,522 |  |  | $ | 1,113 |  |  | $ | 1,112 |  |

[0000833444-24-000064:notes:424]
(1)EBITA for the Building Solutions EMEA/LA segment includes equity income (loss) of $(39) million, $1 million and $6 million for the years ended September 30, 2024, 2023 and 2022, respectively.

[0000833444-24-000064:notes:425]
(2)Refer to Note 21, "Commitments and Contingencies," of the notes to the consolidated financial statements for further disclosure related to the water systems AFFF settlement and insurance recoveries.

[0000833444-24-000064:notes:426]
|  | September 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Assets |  |  |  |  |  |
| Building Solutions North America | $ | 16,159 |  |  | $ | 15,603 |  |  | $ | 15,226 |  |
| Building Solutions EMEA/LA(1) | 5,072 |  |  | 5,202 |  |  | 4,991 |  |
| Building Solutions Asia Pacific | 2,571 |  |  | 2,645 |  |  | 2,474 |  |
| Global Products | 10,011 |  |  | 10,844 |  |  | 10,620 |  |
|  | 33,813 |  |  | 34,294 |  |  | 33,311 |  |
| Assets held for sale | 4,805 |  |  | 4,657 |  |  | 4,700 |  |
| Unallocated | 4,077 |  |  | 3,291 |  |  | 4,147 |  |
| Total | $ | 42,695 |  |  | $ | 42,242 |  |  | $ | 42,158 |  |

[0000833444-24-000064:notes:427]
(1)Assets for the Building Solutions EMEA/LA segment includes investments in partially-owned affiliates of $57 million, $130 million and $115 million, as of September 30, 2024, 2023 and 2022, respectively.

[0000833444-24-000064:notes:428]
|  | Year Ended September 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Depreciation/Amortization |  |  |  |  |  |
| Building Solutions North America | $ | 248 |  |  | $ | 225 |  |  | $ | 213 |  |
| Building Solutions EMEA/LA | 105 |  |  | 101 |  |  | 96 |  |
| Building Solutions Asia Pacific | 19 |  |  | 23 |  |  | 21 |  |
| Global Products | 325 |  |  | 351 |  |  | 348 |  |
|  | 697 |  |  | 700 |  |  | 678 |  |
| Corporate | 119 |  |  | 45 |  |  | 39 |  |
| Total | $ | 816 |  |  | $ | 745 |  |  | $ | 717 |  |

[0000833444-24-000064:notes:429]
|  | Year Ended September 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Capital Expenditures |  |  |  |  |  |
| Building Solutions North America | $ | 53 |  |  | $ | 104 |  |  | $ | 141 |  |
| Building Solutions EMEA/LA | 105 |  |  | 119 |  |  | 119 |  |
| Building Solutions Asia Pacific | 15 |  |  | 33 |  |  | 22 |  |
| Global Products | 153 |  |  | 140 |  |  | 152 |  |
|  | 326 |  |  | 396 |  |  | 434 |  |
| Corporate | 168 |  |  | 50 |  |  | 53 |  |
| Total | $ | 494 |  |  | $ | 446 |  |  | $ | 487 |  |

[0000833444-24-000064:notes:430]
In fiscal 2024, 2023 and 2022, no customer exceeded 10% of consolidated net sales.

[0000833444-24-000064:notes:431]
Geographic Segments

[0000833444-24-000064:notes:432]
Financial information relating to the Company’s operations by geographic area is as follows (in millions):

[0000833444-24-000064:notes:433]
|  | Year Ended September 30, |
|  | 2024 |  | 2023 |  | 2022 |
| Net Sales |  |  |  |  |  |
| United States | $ | 13,171 |  |  | $ | 12,408 |  |  | $ | 11,337 |  |
| Europe | 4,486 |  |  | 4,366 |  |  | 4,052 |  |
| Asia Pacific | 2,856 |  |  | 3,427 |  |  | 3,319 |  |
| Other Non-U.S. | 2,439 |  |  | 2,130 |  |  | 1,929 |  |
| Total | $ | 22,952 |  |  | $ | 22,331 |  |  | $ | 20,637 |  |
| Long-Lived Assets (Year-end) |  |  |  |  |  |
| United States | $ | 1,137 |  |  | $ | 1,277 |  |  | $ | 1,285 |  |
| Europe | 613 |  |  | 479 |  |  | 384 |  |
| Asia Pacific | 252 |  |  | 233 |  |  | 235 |  |
| Other Non-U.S. | 401 |  |  | 385 |  |  | 367 |  |
| Total | $ | 2,403 |  |  | $ | 2,374 |  |  | $ | 2,271 |  |

[0000833444-24-000064:notes:434]
Net sales attributed to geographic locations are based on the location of where the sale originated. Long-lived assets by geographic location consist of net property, plant and equipment.


## us-gaap:GuaranteesTextBlock

[0000833444-24-000064:notes:435]
GUARANTEES
Certain of the Company's subsidiaries at the business segment level have guaranteed the performance of third-parties and provided financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from the current fiscal year through the completion of such transactions and would typically be triggered in the event of nonperformance. Performance under the guarantees, if required, would not have a material effect on the Company's financial position, results of operations or cash flows.

[0000833444-24-000064:notes:436]
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. A typical warranty program requires that the Company replace defective products within a specified time period from the date of sale.

[0000833444-24-000064:notes:437]
The changes in the carrying amount of the Company’s total product warranty liability were as follows (in millions).

[0000833444-24-000064:notes:438]
|  | Year Ended September 30, |
|  | 2024 |  | 2023 |
| Balance at beginning of period | $ | 91 |  |  | $ | 66 |  |
| Accruals for warranties issued during the period | 85 |  |  | 72 |  |
| Settlements made (in cash or in kind) during the period | (87) |  |  | (46) |  |
| Changes in estimates to pre-existing warranties | 31 |  |  | (2) |  |
| Accruals from acquisitions and divestitures | — |  |  | 1 |  |
| Currency translation | 2 |  |  | — |  |
| Balance at end of period | $ | 122 |  |  | $ | 91 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-24-000064:notes:439]
COMMITMENTS AND CONTINGENCIES
Environmental Matters

[0000833444-24-000064:notes:440]
The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-24-000064:notes:441]
|  | September 30, |
|  | 2024 |  | 2023 |
| Other current liabilities | $ | 32 |  |  | $ | 28 |  |
| Other noncurrent liabilities | 179 |  |  | 211 |  |
| Total reserves for environmental liabilities | $ | 211 |  |  | $ | 239 |  |

[0000833444-24-000064:notes:442]
The Company periodically examines whether the contingent liabilities related to the environmental matters described below are probable and reasonably estimable based on experience and ongoing developments in those matters, including continued study and analysis of ongoing remediation obligations. The Company expects that it will pay the amounts recorded over an estimated period of up to 20 years. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals for environmental liabilities at this time.

[0000833444-24-000064:notes:443]
A substantial portion of the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to Aqueous Film Forming Foam ("AFFF") containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).

[0000833444-24-000064:notes:444]
PFOA, PFOS, and other PFAS compounds are being studied by the U.S. Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. On April 10, 2024, EPA announced the final National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR established legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion ("ppt") for each of PFOA and PFOS, 10 ppt for each of PFHxS, PFNA, and HFPO-DA (commonly known as GenX Chemicals), and a Hazard Index of one for mixtures containing two or more of PFHxS, PFNA, HFPO-DA, and PFBA. In February 2024, EPA released two proposed rules relating to PFAS under the Resource Conservation and Recovery Act (“RCRA”): one rule proposes to list nine PFAS (including PFOA and PFOS) as “hazardous constituents,” and a second rule proposes to clarify that hazardous waste regulated under the rule includes not only substances listed or identified as hazardous waste in the regulations, but also any substances that meet the statutory definition of hazardous waste.

[0000833444-24-000064:notes:445]
In August 2022, EPA published a proposed rule that would designate PFOA and PFOS as “hazardous substances” under Comprehensive Environmental Response, Compensation and Liability Act ("CERCLA"). In April 2023, EPA issued an Advanced Notice of Proposed Rulemaking ("ANPR") seeking input on whether it should expand the proposed rule to designate as "hazardous substances" under CERCLA: (1) seven additional PFAS; (2) the precursors to PFOA, PFOS, and the seven additional PFAS; or (3) entire categories of PFAS. On April 17, 2024, the EPA Administrator signed the final rule designating PFOA and PFOS, along with their salts and structural isomers, as “hazardous substances.”

[0000833444-24-000064:notes:446]
It is not possible to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in soil, groundwater and drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash

[0000833444-24-000064:notes:447]
flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000833444-24-000064:notes:448]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $7 million and $8 million at September 30, 2024 and 2023, respectively.

[0000833444-24-000064:notes:449]
FTC-Related Matters

[0000833444-24-000064:notes:450]
FTC Remediation

[0000833444-24-000064:notes:451]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. During the three months ended June 30, 2024, Tyco Fire Products completed its previously announced plan to discontinue the production and sale of fluorinated firefighting foams, including AFFF products, and has transitioned to non-fluorinated foam alternatives.

[0000833444-24-000064:notes:452]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the EPA to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

[0000833444-24-000064:notes:453]
Tyco Fire Products is operating and monitoring at the FTC a Groundwater Extraction and Treatment System ("GETS"), a permanent groundwater remediation system that extracts groundwater containing PFAS, treats it using advanced filtration systems, and returns the treated water to the environment. Tyco Fire Products has also completed the removal and disposal of PFAS-affected soil from the FTC. The Company's reserves for continued remediation of the FTC, the Stanton Street Facility and surrounding areas in Marinette and Peshtigo are based on estimates of costs associated with the long-term remediation actions, including the continued operation of the GETS, the implementation of long-term drinking water solutions for the area impacted by groundwater migrating from the FTC, continued monitoring and testing of groundwater monitoring wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

[0000833444-24-000064:notes:454]
FTC-Related Litigation

[0000833444-24-000064:notes:455]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water in February 2022, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. In August 2024, WDNR issued a new proposed rule to adopt the EPA Maximum Contaminant Levels for PFAS in drinking water. The WDNR initiated a rulemaking proceeding that would establish groundwater quality standards for PFOA, PFOS, perfluorobutane sulfonic acid and its potassium salt (“PFBS”) and hexafluoropropylene oxide dimer acid and its ammonium salt (“HFPO-DA”). Pursuant to state law, the WDNR has stopped work on the proposed rule and notified the state legislature that, following economic analysis, the proposed costs would exceed statutory thresholds. As a result, the state legislature is required to authorize the WDNR to allow the rulemaking to continue.

[0000833444-24-000064:notes:456]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. The WDNR issued a further letter regarding the issue on November 4, 2019. In February 2020, the WDNR sent a letter to Tyco Fire Products and

[0000833444-24-000064:notes:457]
Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to that date. On April 10, 2023, the WDNR issued a third “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids in the Marinette region. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions, including the potential assessment of penalties.

[0000833444-24-000064:notes:458]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR's requests. The parties are engaged in summary judgment and pretrial motions and the court has set a trial date of March 3, 2025.

[0000833444-24-000064:notes:459]
In October 2022, the Town of Peshtigo filed a tort action in Wisconsin state court against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and ChemDesign, Inc. relating to environmental matters at the FTC (Town of Peshtigo v. Tyco Fire Products L.P. et al., Case No. 2022CV000234 (filed October 18, 2022 in Circuit Court in Marinette County, Wisconsin)). The Town alleges that use of AFFF products at the FTC caused contamination of water supplies in Peshtigo. The Town seeks monetary penalties and an injunction ordering abatement of PFAS contamination in Peshtigo. The case has been removed to federal court and transferred to a multi-district litigation ("MDL") before the United States District Court for the District of South Carolina.

[0000833444-24-000064:notes:460]
In November 2022, individuals filed six actions in Dane County, Wisconsin alleging personal injury and/or property damage against Tyco Fire Products, Johnson Controls Inc., Chemguard, and other unaffiliated defendants related to environmental matters at the FTC. Plaintiffs allege that use of AFFF products at the FTC and activities by third parties unrelated to the Company contaminated nearby drinking water sources, surface waters, and other natural resources and properties, including their personal properties. The individuals seek monetary damages for their personal injury and/or property damage. These lawsuits have been transferred to the MDL. Subsequently, several additional plaintiffs have direct-filed in the MDL complaints with similar allegations.

[0000833444-24-000064:notes:461]
The Company is vigorously defending each of these cases and believes that it has meritorious defenses, but it is presently unable to predict the duration, scope, or outcome of these actions.

[0000833444-24-000064:notes:462]
Aqueous Film-Forming Foam ("AFFF") Matters

[0000833444-24-000064:notes:463]
AFFF Litigation

[0000833444-24-000064:notes:464]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-24-000064:notes:465]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to the MDL. Additional cases have been identified for transfer to or are being directly filed in the MDL.

[0000833444-24-000064:notes:466]
AFFF Municipal and Water Provider Cases

[0000833444-24-000064:notes:467]
Chemguard and Tyco Fire Products have been named as defendants in more than 970 cases in federal and state courts involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 35 states and territories. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation.

[0000833444-24-000064:notes:468]
Tyco Fire Products and Chemguard are also periodically notified by other municipal entities that those entities may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-24-000064:notes:469]
Water Systems AFFF Settlement Agreement

[0000833444-24-000064:notes:470]
On April 12, 2024, Tyco Fire Products agreed to a settlement with a nationwide class of public water systems that detected PFAS in their drinking water systems that they allege to be associated with the use of AFFF. Under the terms of the agreement, Tyco Fire Products agreed to contribute $750 million to resolve these PFAS claims. The settlement releases these claims against Tyco Fire Products, Chemguard, and other related corporate entities. In connection with the settlement, a charge for $750 million was recorded in selling, general and administrative expenses in the consolidated statements of income.

[0000833444-24-000064:notes:471]
Tyco Fire Products contributed an initial payment of $250 million in June 2024, with the remaining $500 million due by the first quarter of fiscal 2025. Prior to the date of the final contribution, Tyco Fire Products has agreed to contribute any applicable insurance recoveries in excess of the initial $250 million payment, up to the remaining $500 million due, within a specified period following the receipt of such recovery. During fiscal 2024, the Company recorded expected insurance recoveries of $371 million in selling, general and administrative expenses in the consolidated statements of income and collected insurance recoveries of $349 million. In accordance with its agreement and recent insurance recovery, Tyco Fire Products made an additional payment during the fourth quarter of fiscal 2024 of approximately $85 million, reducing its final payment to approximately $415 million. The amounts and timing of any additional insurance recoveries are uncertain.

[0000833444-24-000064:notes:472]
There are still several procedural and legal steps that must occur before the settlement is final and the remaining payment is made. The settlement is subject to final approval by the MDL court and other contingencies, and that process is expected to be completed in the first half of fiscal 2025.

[0000833444-24-000064:notes:473]
The class of public water systems included in this settlement broadly includes any public water system (as defined in the settlement agreement) that has detected PFAS in its drinking water sources as of May 15, 2024. The following systems are excluded from the settlement class: water systems owned and operated by a State or the United States government; systems that have not detected the presence of PFAS as of May 15, 2024; small transient water systems; privately-owned drinking water wells; and the water system in the city of Marinette, Wisconsin (which is included only if it so requests). The settlement does not resolve claims of public water systems that request exclusion from the class (“opt out”) pursuant to the process to be established by the MDL court. It also does not resolve potential future claims of public water systems that detect PFAS in their water systems for the first time after May 15, 2024, or certain claims not related to drinking water, such as separate alleged claims relating to real property damage or stormwater or wastewater treatment. Finally, this settlement does not affect the other categories of cases that remain at issue in the MDL, such as personal injury cases, property damage cases, other types of class actions, claims brought by state or territory attorneys general, or other types of damages alleged to be related to the historical use of AFFF manufactured and sold by Tyco Fire Products and Chemguard. While it is reasonably possible that the excluded systems or claims could result in additional future lawsuits, claims, assessments or proceedings, it is not possible to predict the outcome of any such matters, and as such, the Company is unable to develop an estimate of a possible loss or range of losses, if any, at this time.

[0000833444-24-000064:notes:474]
The settlement does not constitute an admission of liability or wrongdoing by Tyco Fire Products or Chemguard. If the MDL court does not approve the agreement or certain terms are not fulfilled, Tyco Fire Products and Chemguard will continue to defend themselves in the litigation.

[0000833444-24-000064:notes:475]
AFFF Putative Class Actions

[0000833444-24-000064:notes:476]
Chemguard and Tyco Fire Products are named in 45 pending putative class actions in federal courts originating from 18 states and territories. All of these cases have been direct-filed in or transferred to the MDL. In addition, six proposed class actions were filed in Canada (British Columbia, Manitoba, Quebec and Ontario) in the past year against Tyco Fire Products and other

[0000833444-24-000064:notes:477]
manufacturers on behalf of various classes of members who consumed or were exposed to products or supplies that were allegedly contaminated by AFFF.

[0000833444-24-000064:notes:478]
AFFF Individual or Mass Actions

[0000833444-24-000064:notes:479]
There are more than 8,300 individual or “mass” actions pending that were filed in state or federal courts originating from 52 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 8,300 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly-filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona, Illinois, Virginia and Wisconsin.

[0000833444-24-000064:notes:480]
Tyco and Chemguard are also periodically notified by other individuals that they may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-24-000064:notes:481]
AFFF State or U.S. Territory Attorneys General Litigation

[0000833444-24-000064:notes:482]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-24-000064:notes:483]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-24-000064:notes:484]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. The State’s case has been removed to federal court and transferred to the MDL. The State of Alaska has also named a number of manufacturers and other defendants, including affiliates of the Company, as third-party defendants in two cases brought by individuals against the State. These two cases have also been transferred to the MDL.

[0000833444-24-000064:notes:485]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL. In October 2022, the Attorney General filed two similar lawsuits in the superior courts of the State of North Carolina regarding alleged PFAS damages at two additional locations. These two cases have also been removed to federal court and transferred to the MDL.

[0000833444-24-000064:notes:486]
In addition, 33 other states and territories have filed 35 lawsuits against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of each of those State's environmental and natural resources allegedly resulting from the manufacture, storage, sale, distribution, marketing, and use of PFAS-containing AFFF within each respective State. The states and territories are: Arkansas, Arizona, California, Colorado, Connecticut, Delaware, the District of

[0000833444-24-000064:notes:487]
Columbia, Florida, Hawaii, Illinois, Indiana, Kentucky, Massachusetts, Maryland, Maine, Michigan, Mississippi, New Hampshire, New Jersey, New Mexico, Ohio, Oklahoma, Oregon, Rhode Island, South Carolina, Tennessee, Texas, Vermont, Washington, Wisconsin, Guam, the Northern Mariana Islands, and Puerto Rico. All of these complaints, if not filed directly in the MDL, have been removed to federal court and transferred to the MDL.

[0000833444-24-000064:notes:488]
Other AFFF Related Matters

[0000833444-24-000064:notes:489]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

[0000833444-24-000064:notes:490]
In October 2022, the Red Cliff Band of Lake Superior Chippewa Indians (a federally recognized tribe) filed a lawsuit in the United States District Court for the Western District of Wisconsin against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota. This complaint has been transferred to the MDL.

[0000833444-24-000064:notes:491]
In July 2023, the Fond du Lac Band of Lake Superior Chippewa (a federally recognized tribe) direct-filed a lawsuit in the MDL against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota.

[0000833444-24-000064:notes:492]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin and a federal district court in South Carolina. The insurance litigation involves numerous factual and legal issues. There are numerous factual and legal issues to be resolved in connection with these claims. The Company is presently unable to predict the outcome or ultimate financial exposure beyond the water systems AFFF settlement discussed above, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

[0000833444-24-000064:notes:493]
Asbestos Matters

[0000833444-24-000064:notes:494]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-24-000064:notes:495]
The following table presents the location and amount of asbestos-related assets and liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-24-000064:notes:496]
|  | September 30, |
|  | 2024 |  | 2023 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 350 |  |  | 364 |  |
| Total asbestos-related liabilities | 408 |  |  | 422 |  |
| Other current assets | 14 |  |  | 28 |  |
| Other noncurrent assets | 320 |  |  | 273 |  |
| Total asbestos-related assets | 334 |  |  | 301 |  |
| Net asbestos-related liabilities | $ | 74 |  |  | $ | 121 |  |

[0000833444-24-000064:notes:497]
The following table presents the components of asbestos-related assets (in millions):

[0000833444-24-000064:notes:498]
|  | September 30, |
|  | 2024 |  | 2023 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 20 |  |
| Investments | 281 |  |  | 231 |  |
| Total restricted assets | 287 |  |  | 251 |  |
| Insurance receivables for asbestos-related liabilities | 47 |  |  | 50 |  |
| Total asbestos-related assets | $ | 334 |  |  | $ | 301 |  |

[0000833444-24-000064:notes:499]
The amounts recorded for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption may impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-24-000064:notes:500]
Self-Insured Liabilities

[0000833444-24-000064:notes:501]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage a portion of its insurable liabilities.

[0000833444-24-000064:notes:502]
The following table presents the location and amount of self-insured liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-24-000064:notes:503]
|  | September 30, |
|  | 2024 |  | 2023 |
| Other current liabilities | $ | 92 |  |  | $ | 86 |  |
| Accrued compensation and benefits | 20 |  |  | 21 |  |
| Other noncurrent liabilities | 239 |  |  | 226 |  |
| Total self-insured liabilities | $ | 351 |  |  | $ | 333 |  |

[0000833444-24-000064:notes:504]
The following table presents the location and amount of insurance receivables in the Company's consolidated statements of financial position (in millions):

[0000833444-24-000064:notes:505]
|  | September 30, |
|  | 2024 |  | 2023 |
| Other current assets | $ | 5 |  |  | $ | 6 |  |
| Other noncurrent assets | 13 |  |  | 14 |  |
| Total insurance receivables | $ | 18 |  |  | $ | 20 |  |

[0000833444-24-000064:notes:506]
Other Matters

[0000833444-24-000064:notes:507]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to the Company, it is management’s opinion that 
none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000833444-24-000064:notes:508]
On September 12, 2024, Nathan Manning, the Company's Vice President and Chief Operations Officer, Global Field Operations, entered into a Rule 10b5-1 trading arrangement (the "Manning 10b5-1 Plan") during the Company's fiscal fourth quarter open trading window. The Manning 10b5-1 Plan is intended to satisfy the Rule 10b5-1 affirmative defense and contemplates the sale in regular intervals of  14,219 ordinary shares of Company stock previously issued upon the vesting of restricted stock unit awards. The Manning 10b5-1 Plan is expected to become effective on or about February 1, 2025 and is scheduled to terminate upon the earlier of the sale of all shares contemplated under the Manning 10b5-1 Plan or November 30, 2025.

[0000833444-24-000064:notes:509]
Executive Officer Retention Award

[0000833444-24-000064:notes:510]
On November 18, 2024, the Compensation and Talent Development Committee of the Board of Directors of Johnson Controls International plc (the “Company”) approved a special retention RSU award (the “Retention Award”) for Julie Brandt, the Company’s Vice President and President, Building Solutions North America. The Retention Award consists of a grant of RSUs with a grant date of November 18, 2024 and a grant date fair value of $1,000,000. The Retention Award is cliff vesting after a period of one year. In the event of an involuntary not for cause termination, vesting for the Retention Award will accelerate on a pro-rata basis based on the number of full months actively employed in the vesting term. In the event of a termination as a result of death or disability, vesting for the Retention Award will accelerate in full. In the event of any other termination, including retirement, voluntary and termination “for cause”, the Retention Award will be forfeited. The terms of the Retention Award are governed by the Company’s standard terms of and conditions for restricted share/unit awards, filed as Exhibit 10.1 to the Company’s Quarterly Report on Form 10-Q for the quarter ended December 31, 2022, filed with the SEC on February 1, 2023, which is incorporated herein by reference.


## ecd:AwardTmgMnpiDiscTextBlock

[0000833444-24-000064:notes:511]
The Company has adopted an insider trading policy governing the purchase, sale, and/or other dispositions of its securities by its directors, officers, employees and independent contractors that the Company believes is reasonably designed to promote compliance with insider trading laws, rules and regulations, and the exchange listing standards applicable to the Company.

[0000833444-24-000064:notes:512]
Directors, executive officers, employees and other related persons may not buy, sell or engage in other transactions in the Company’s shares while aware of material non-public information; buy or sell securities of other companies while aware of material non-public information about those companies that they became aware of as a result of business dealings between the Company and those companies; or disclose material non-public information to any unauthorized persons outside of the Company. The policy also restricts trading and other transactions for a limited group of Company employees (including executives and directors) to defined window periods that follow the Company's quarterly earnings releases and restricts trading and other transactions following announcement of a share repurchase program.
