# JCI note change history — 0000833444-24-000029 → 0000833444-24-000052


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-07-31):
[0000833444-24-000052:note_history:1]
|  | June 30, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 37 |  |  | $ | 31 |  |
| Other noncurrent liabilities | 180 |  |  | 211 |  |
| Total reserves for environmental liabilities | $ | 217 |  |  | $ | 242 |  |
  (was, 2024-05-01, similarity 0.9778):
[0000833444-24-000029:note_history:1]
|  | March 31, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 28 |  |  | $ | 31 |  |
| Other noncurrent liabilities | 194 |  |  | 211 |  |
| Total reserves for environmental liabilities | $ | 222 |  |  | $ | 242 |  |

- changed (2024-07-31):
[0000833444-24-000052:note_history:2]
A substantial portion of the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to Aqueous Film Forming Foam ("AFFF") containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).
  (was, 2024-05-01, similarity 0.6921):
[0000833444-24-000029:note_history:2]
Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).

- changed (2024-07-31):
[0000833444-24-000052:note_history:3]
PFOA, PFOS, and other PFAS compounds are being studied by the U.S. Environmental Protection Agency ("EPA")  and other environmental and health agencies and researchers. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. On April 10, 2024, EPA announced the final National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR established legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion ("ppt") for each of PFOA and PFOS, 10 ppt for each of PFHxS, PFNA, and HFPO-DA (commonly known as GenX Chemicals), and a Hazard Index of one for mixtures containing two or more of PFHxS, PFNA, HFPO-DA, and PFBA. In February 2024, EPA released two proposed rules relating to PFAS under the Resource Conservation and Recovery Act (“RCRA”): one rule proposes to list nine PFAS (including PFOA and PFOS) as “hazardous constituents,” and a second rule proposes to clarify that hazardous waste regulated under the rule includes not only substances listed or identified as hazardous waste in the regulations, but also any substances that meet the statutory definition of hazardous waste.
  (was, 2024-05-01, similarity 0.9996):
[0000833444-24-000029:note_history:3]
PFOA, PFOS, and other PFAS compounds are being studied by the U.S. Environmental Protection Agency ("EPA")  and other environmental and health agencies and researchers. In March 2021, EPA published its final determination to regulate PFOS and PFOA in drinking water. On April 10, 2024, EPA announced the final National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR established legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion ("ppt") for each of PFOA and PFOS, 10 ppt for each of PFHxS, PFNA, and HFPO-DA (commonly known as GenX Chemicals), and a Hazard Index of one for mixtures containing two or more of PFHxS, PFNA, HFPO-DA, and PFBA. In February 2024, EPA released two proposed rules relating to PFAS under the Resource Conservation and Recovery Act (“RCRA”): one rule proposes to list nine PFAS (including PFOA and PFOS) as “hazardous constituents,” and a second rule proposes to clarify that hazardous waste regulated under the rule includes not only substances listed or identified as hazardous waste in the regulations, but also any substances that meets the statutory definition of hazardous waste.

- changed (2024-07-31):
[0000833444-24-000052:note_history:4]
It is not possible to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in soil, groundwater and drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the
  (was, 2024-05-01, similarity 0.6554):
[0000833444-24-000029:note_history:4]
It is not possible to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in soil, groundwater and drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- added (2024-07-31):
[0000833444-24-000052:note_history:5]
various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- changed (2024-07-31):
[0000833444-24-000052:note_history:6]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $8 million and $13 million at June 30, 2024 and September 30, 2023, respectively.
  (was, 2024-05-01, similarity 0.9862):
[0000833444-24-000029:note_history:6]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $10 million and $13 million at March 31, 2024 and September 30, 2023, respectively.

- changed (2024-07-31):
[0000833444-24-000052:note_history:7]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. During the three months ended June 30, 2024, Tyco Fire Products completed its previously announced plan to discontinue the production and sale of fluorinated firefighting foams, including AFFF products, and has transitioned to non-fluorinated foam alternatives.
  (was, 2024-05-01, similarity 0.6316):
[0000833444-24-000029:note_history:7]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. On July 18, 2023, Tyco Fire Products announced that it plans to discontinue the production and sale of fluorinated firefighting foams by June 2024, including AFFF products, and will transition to non-fluorinated foam alternatives.

- changed (2024-07-31):
[0000833444-24-000052:note_history:8]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with  EPA to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.
  (was, 2024-05-01, similarity 0.9128):
[0000833444-24-000029:note_history:8]
Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with  EPA to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

- changed (2024-07-31):
[0000833444-24-000052:note_history:9]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water in February 2022, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. The WDNR initiated a rulemaking proceeding that would establish groundwater quality standards for PFOA, PFOS,
  (was, 2024-05-01, similarity 0.7483):
[0000833444-24-000029:note_history:9]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. Although Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water in February 2022, the Wisconsin Natural Resources Board did not approve WDNR's proposed standards for PFOA and PFOS in groundwater. The WDNR initiated a rulemaking proceeding that would establish groundwater quality standards for PFOA, PFOS, perfluorobutane sulfonic acid and its potassium salt (“PFBS”) and hexafluoropropylene oxide dimer acid and its ammonium salt (“HFPO-DA”). Pursuant to state law, the WDNR has stopped work on the proposed rule and notified the state legislature that, following economic analysis, the proposed costs would exceed statutory thresholds. As a result, the state legislature is required to authorize the WDNR to allow the rulemaking to continue.

- added (2024-07-31):
[0000833444-24-000052:note_history:10]
perfluorobutane sulfonic acid and its potassium salt (“PFBS”) and hexafluoropropylene oxide dimer acid and its ammonium salt (“HFPO-DA”). Pursuant to state law, the WDNR has stopped work on the proposed rule and notified the state legislature that, following economic analysis, the proposed costs would exceed statutory thresholds. As a result, the state legislature is required to authorize the WDNR to allow the rulemaking to continue.

- changed (2024-07-31):
[0000833444-24-000052:note_history:11]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR's requests. The parties are engaged in summary judgment and pretrial motions and the court has set a trial date of December 3, 2024.
  (was, 2024-05-01, similarity 0.6961):
[0000833444-24-000029:note_history:11]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the

- added (2024-07-31):
[0000833444-24-000052:note_history:12]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with

- changed (2024-07-31):
[0000833444-24-000052:note_history:13]
Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.
  (was, 2024-05-01, similarity 0.8963):
[0000833444-24-000029:note_history:13]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

- changed (2024-07-31):
[0000833444-24-000052:note_history:14]
Chemguard and Tyco Fire Products have been named as defendants in more than 950 cases in federal and state courts involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 35 states and territories. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation.
  (was, 2024-05-01, similarity 0.8895):
[0000833444-24-000029:note_history:14]
Chemguard and Tyco Fire Products have been named as defendants in more than 815 cases in federal and state courts involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 35 states and territories. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard

- changed (2024-07-31):
[0000833444-24-000052:note_history:15]
On April 12, 2024, Tyco Fire Products agreed to a settlement with a nationwide class of public water systems that detected PFAS in their drinking water systems that they allege to be associated with the use of AFFF. Under the terms of the agreement, Tyco Fire Products agreed to contribute $750 million to resolve these PFAS claims. The settlement releases these claims against Tyco Fire Products, Chemguard, and other related corporate entities. In connection with the settlement, a charge for $750 million was recorded in selling, general and administrative expenses in the consolidated statements of income in the three months ended March 31, 2024.
  (was, 2024-05-01, similarity 0.9147):
[0000833444-24-000029:note_history:15]
On April 12, 2024, Tyco Fire Products agreed to a settlement with a nationwide class of public water systems that detected PFAS in their drinking water systems that they allege to be associated with the use of AFFF. Under the terms of the agreement, Tyco Fire Products agreed to contribute $750 million to resolve these PFAS claims. The settlement releases these claims against Tyco Fire Products, Chemguard, and other related corporate entities. In connection with the settlement, a charge for $750 million was recorded by the Company in the three months ended March 31, 2024.

- added (2024-07-31):
[0000833444-24-000052:note_history:16]
Tyco Fire Products contributed an initial payment of $250 million in June 2024, with the remaining $500 million due by the first quarter of fiscal 2025. Prior to the date of the final contribution, Tyco Fire Products has agreed to contribute any applicable insurance recoveries in excess of the initial $250 million payment, up to the remaining $500 million due, within a specified period following the receipt of such recovery. During the three months ended June 30, 2024, the Company recorded expected insurance recoveries of $351 million in selling, general and administrative expenses in the consolidated statements of income, substantially all of the proceeds of which are expected to be received in the fourth quarter of fiscal 2024. In accordance with its agreement and recent insurance recovery, Tyco Fire Products will make an additional payment during the fourth quarter of fiscal 2024 of approximately $90 million, reducing its final payment to approximately $410 million. The amounts and timing of any additional insurance recoveries are uncertain.

- changed (2024-07-31):
[0000833444-24-000052:note_history:17]
There are still several procedural and legal steps that must occur before the settlement is final and the remaining payment is made. The settlement is subject to final approval by the MDL court and other contingencies, and that process is expected to take several months.
  (was, 2024-05-01, similarity 0.9466):
[0000833444-24-000029:note_history:17]
There are still several procedural and legal steps that must occur before the settlement is final and payments are made. The settlement is subject to approval by the MDL court and other contingencies, and that process is expected to take several months.

- added (2024-07-31):
[0000833444-24-000052:note_history:18]
The class of public water systems included in this settlement broadly includes any public water system (as defined in the settlement agreement) that has detected PFAS in its drinking water sources as of May 15, 2024. The following systems are excluded from the settlement class: water systems owned and operated by a State or the United States government; systems

- changed (2024-07-31):
[0000833444-24-000052:note_history:19]
that have not detected the presence of PFAS as of May 15, 2024; small transient water systems; privately-owned drinking water wells; and the water system in the city of Marinette, Wisconsin (which is included only if it so requests). The settlement does not resolve claims of public water systems that request exclusion from the class (“opt out”) pursuant to the process to be established by the MDL court. It also does not resolve potential future claims of public water systems that detect PFAS in their water systems for the first time after May 15, 2024, or certain claims not related to drinking water, such as separate alleged claims relating to real property damage or stormwater or wastewater treatment. Finally, this settlement does not affect the other categories of cases that remain at issue in the MDL, such as personal injury cases, property damage cases, other types of class actions, claims brought by state or territory attorneys general, or other types of damages alleged to be related to the historic use of AFFF manufactured and sold by Tyco Fire Products and Chemguard. While it is reasonably possible that the excluded systems or claims could result in additional future lawsuits, claims, assessments or proceedings, it is not possible to predict the outcome of any such matters, and as such, the Company is unable to develop an estimate of a possible loss or range of losses, if any, at this time.
  (was, 2024-05-01, similarity 0.8873):
[0000833444-24-000029:note_history:19]
The class of public water systems included in this settlement broadly includes any public water system (as defined in the settlement agreement) that has detected PFAS in its drinking water sources as of May 15, 2024. The following systems are excluded from the settlement class: water systems owned and operated by a State or the United States government; systems that have not detected the presence of PFAS as of May 15, 2024; small transient water systems; privately-owned drinking water wells; and the water system in the city of Marinette, Wisconsin (which is included only if it so requests). The settlement does not resolve claims of public water systems that request exclusion from the class (“opt out”) pursuant to the process to be established by the MDL Court. It also does not resolve potential future claims of public water systems that detect PFAS in their water systems for the first time after May 15, 2024, or certain claims not related to drinking water, such as separate alleged claims relating to real property damage or stormwater or wastewater treatment. Finally, this settlement does not affect the other categories of cases that remain at issue in the MDL, such as personal injury cases, property damage cases, other types of class actions, claims brought by state or territory attorneys general, or other types of damages alleged to be related to the historic use of AFFF manufactured and sold by Tyco Fire Products and Chemguard. While it is reasonably possible that the excluded systems or claims could result in additional future lawsuits, claims, assessments or proceedings, it is not possible to predict the outcome of any such matters, and as such, the Company is unable to develop an estimate of a possible loss or range of losses, if any, at this time.

- changed (2024-07-31):
[0000833444-24-000052:note_history:20]
Chemguard and Tyco Fire Products are named in 46 pending putative class actions in federal courts originating from 18 states and territories. All of these cases have been direct-filed in or transferred to the MDL. It is anticipated that the remaining state-court action will be similarly tagged and transferred. Tyco Fire Products was also recently named in class actions in British Columbia and Quebec, Canada.
  (was, 2024-05-01, similarity 0.9436):
[0000833444-24-000029:note_history:20]
Chemguard and Tyco Fire Products are named in 46 pending putative class actions in federal courts originating from 18 states and territories. All but one of these cases have been direct-filed in or transferred to the MDL. It is anticipated that the remaining state-court action will be similarly tagged and transferred. Tyco Fire Products was also recently named in a class action in British Columbia, Canada.

- changed (2024-07-31):
[0000833444-24-000052:note_history:21]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including
  (was, 2024-05-01, similarity 0.6479):
[0000833444-24-000029:note_history:21]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

- added (2024-07-31):
[0000833444-24-000052:note_history:22]
affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

- changed (2024-07-31):
[0000833444-24-000052:note_history:23]
In addition, 33 other states and territories have filed 35 lawsuits against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of each of those State's environmental and natural resources allegedly resulting from the manufacture, storage, sale, distribution, marketing, and use of PFAS-containing AFFF within each respective State. The states and territories are: Arkansas, Arizona, California, Colorado, Connecticut, Delaware, the District of Columbia, Florida, Hawaii, Illinois, Indiana, Kentucky, Massachusetts, Maryland, Maine, Michigan, Mississippi, New Hampshire, New Jersey, New Mexico, Ohio, Oklahoma, Oregon, Rhode Island, South Carolina, Tennessee, Texas, Vermont, Washington, Wisconsin, Guam, the Northern Mariana Islands, and Puerto Rico. All of these complaints, if not filed directly in the MDL, have been removed to federal court and transferred to the MDL.
  (was, 2024-05-01, similarity 0.9951):
[0000833444-24-000029:note_history:23]
In addition, 32 other states and territories have filed 34 lawsuits against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of each of those State's environmental and natural resources allegedly resulting from the manufacture, storage, sale, distribution, marketing, and use of PFAS-containing AFFF within each respective State. The states and territories are: Arkansas, Arizona, California, Colorado, Connecticut, Delaware, the District of Columbia, Florida, Hawaii, Illinois, Kentucky, Massachusetts, Maryland, Maine, Michigan, Mississippi, New Hampshire, New Jersey, New Mexico, Ohio, Oklahoma, Oregon, Rhode Island, South Carolina, Tennessee, Texas, Vermont, Washington, Wisconsin, Guam, the Northern Mariana Islands, and Puerto Rico. All of these complaints, if not filed directly in the MDL, have been removed to federal court and transferred to the MDL.

- added (2024-07-31):
[0000833444-24-000052:note_history:24]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin and a federal district court in South Carolina. The insurance litigation

- added (2024-07-31):
[0000833444-24-000052:note_history:25]
involves numerous factual and legal issues. There are numerous factual and legal issues to be resolved in connection with these claims. The Company is presently unable to predict the outcome or ultimate financial exposure beyond the water systems AFFF settlement discussed above, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

- added (2024-07-31):
[0000833444-24-000052:note_history:26]
|  | June 30, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 353 |  |  | 364 |  |
| Total asbestos-related liabilities | 411 |  |  | 422 |  |
| Other current assets | 18 |  |  | 28 |  |
| Other noncurrent assets | 310 |  |  | 273 |  |
| Total asbestos-related assets | 328 |  |  | 301 |  |
| Net asbestos-related liabilities | $ | 83 |  |  | $ | 121 |  |

- added (2024-07-31):
[0000833444-24-000052:note_history:27]
|  | June 30, 2024 |  | September 30, 2023 |
| Restricted |  |  |  |
| Cash | $ | 10 |  |  | $ | 20 |  |
| Investments | 271 |  |  | 231 |  |
| Total restricted assets | 281 |  |  | 251 |  |
| Insurance receivables for asbestos-related liabilities | 47 |  |  | 50 |  |
| Total asbestos-related assets | $ | 328 |  |  | $ | 301 |  |

- changed (2024-07-31):
[0000833444-24-000052:note_history:28]
|  | June 30, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 98 |  |  | $ | 86 |  |
| Accrued compensation and benefits | 23 |  |  | 21 |  |
| Other noncurrent liabilities | 232 |  |  | 226 |  |
| Total self-insured liabilities | $ | 353 |  |  | $ | 333 |  |
  (was, 2024-05-01, similarity 0.9813):
[0000833444-24-000029:note_history:28]
|  | March 31, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 90 |  |  | $ | 86 |  |
| Accrued compensation and benefits | 23 |  |  | 21 |  |
| Other noncurrent liabilities | 226 |  |  | 226 |  |
| Total self-insured liabilities | $ | 339 |  |  | $ | 333 |  |

- changed (2024-07-31):
[0000833444-24-000052:note_history:29]
|  | June 30, 2024 |  | September 30, 2023 |
| Other current assets | $ | 6 |  |  | $ | 6 |  |
| Other noncurrent assets | 14 |  |  | 14 |  |
| Total insurance receivables | $ | 20 |  |  | $ | 20 |  |
  (was, 2024-05-01, similarity 0.9744):
[0000833444-24-000029:note_history:29]
|  | March 31, 2024 |  | September 30, 2023 |
| Other current assets | $ | 6 |  |  | $ | 6 |  |
| Other noncurrent assets | 14 |  |  | 14 |  |
| Total insurance receivables | $ | 20 |  |  | $ | 20 |  |

- removed (2024-07-31):
[0000833444-24-000029:note_history:30]
A substantial portion of the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to Aqueous Film Forming Foam ("AFFF") containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire

- removed (2024-07-31):
[0000833444-24-000029:note_history:31]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street

- removed (2024-07-31):
[0000833444-24-000029:note_history:32]
FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR's requests. The parties are proceeding with expert discovery and the court has set a trial date of December 3, 2024.

- removed (2024-07-31):
[0000833444-24-000029:note_history:33]
bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation.

- removed (2024-07-31):
[0000833444-24-000029:note_history:34]
Tyco Fire Products expects to contribute an initial $250 million on or about May 25, 2024, with the remaining $500 million to be contributed six months after preliminary court approval of the settlement, which is expected to be addressed by the MDL court in or around mid-May, 2024. Tyco Fire Products has a significant amount of insurance through a number of insurers and expects to apply the proceeds recovered under its policies to cover a substantial portion of the total payment, although the specific amount and timing of any insurance recoveries are uncertain.

- removed (2024-07-31):
[0000833444-24-000029:note_history:35]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. In September 2022, the AFFF MDL Court declined to grant summary judgment on the government contractor defense, ruling that various factual issues relevant to the defense must be decided by a jury rather than the Court. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin and a federal district court in South Carolina. The insurance litigation involves numerous factual and legal issues. There are numerous factual and legal issues to be resolved in connection with these claims. The Company is presently unable to predict the outcome or ultimate financial exposure beyond the water systems AFFF settlement discussed above, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

- removed (2024-07-31):
[0000833444-24-000029:note_history:36]
|  | March 31, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 358 |  |  | 364 |  |
| Total asbestos-related liabilities | 416 |  |  | 422 |  |
| Other current assets | 22 |  |  | 28 |  |
| Other noncurrent assets | 308 |  |  | 273 |  |
| Total asbestos-related assets | 330 |  |  | 301 |  |
| Net asbestos-related liabilities | $ | 86 |  |  | $ | 121 |  |

- removed (2024-07-31):
[0000833444-24-000029:note_history:37]
|  | March 31, 2024 |  | September 30, 2023 |
| Restricted |  |  |  |
| Cash | $ | 14 |  |  | $ | 20 |  |
| Investments | 267 |  |  | 231 |  |
| Total restricted assets | 281 |  |  | 251 |  |
| Insurance receivables for asbestos-related liabilities | 49 |  |  | 50 |  |
| Total asbestos-related assets | $ | 330 |  |  | $ | 301 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-07-31):
[0000833444-24-000052:note_history:38]
|  | June 30, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 37 |  |  | $ | 31 |  |
| Other noncurrent liabilities | 180 |  |  | 211 |  |
| Total reserves for environmental liabilities | $ | 217 |  |  | $ | 242 |  |
  (was, 2024-05-01, similarity 0.9778):
[0000833444-24-000029:note_history:38]
|  | March 31, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 28 |  |  | $ | 31 |  |
| Other noncurrent liabilities | 194 |  |  | 211 |  |
| Total reserves for environmental liabilities | $ | 222 |  |  | $ | 242 |  |

- added (2024-07-31):
[0000833444-24-000052:note_history:39]
|  | June 30, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 353 |  |  | 364 |  |
| Total asbestos-related liabilities | 411 |  |  | 422 |  |
| Other current assets | 18 |  |  | 28 |  |
| Other noncurrent assets | 310 |  |  | 273 |  |
| Total asbestos-related assets | 328 |  |  | 301 |  |
| Net asbestos-related liabilities | $ | 83 |  |  | $ | 121 |  |

- added (2024-07-31):
[0000833444-24-000052:note_history:40]
|  | June 30, 2024 |  | September 30, 2023 |
| Restricted |  |  |  |
| Cash | $ | 10 |  |  | $ | 20 |  |
| Investments | 271 |  |  | 231 |  |
| Total restricted assets | 281 |  |  | 251 |  |
| Insurance receivables for asbestos-related liabilities | 47 |  |  | 50 |  |
| Total asbestos-related assets | $ | 328 |  |  | $ | 301 |  |

- changed (2024-07-31):
[0000833444-24-000052:note_history:41]
|  | June 30, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 98 |  |  | $ | 86 |  |
| Accrued compensation and benefits | 23 |  |  | 21 |  |
| Other noncurrent liabilities | 232 |  |  | 226 |  |
| Total self-insured liabilities | $ | 353 |  |  | $ | 333 |  |
  (was, 2024-05-01, similarity 0.9813):
[0000833444-24-000029:note_history:41]
|  | March 31, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 90 |  |  | $ | 86 |  |
| Accrued compensation and benefits | 23 |  |  | 21 |  |
| Other noncurrent liabilities | 226 |  |  | 226 |  |
| Total self-insured liabilities | $ | 339 |  |  | $ | 333 |  |

- changed (2024-07-31):
[0000833444-24-000052:note_history:42]
|  | June 30, 2024 |  | September 30, 2023 |
| Other current assets | $ | 6 |  |  | $ | 6 |  |
| Other noncurrent assets | 14 |  |  | 14 |  |
| Total insurance receivables | $ | 20 |  |  | $ | 20 |  |
  (was, 2024-05-01, similarity 0.9744):
[0000833444-24-000029:note_history:42]
|  | March 31, 2024 |  | September 30, 2023 |
| Other current assets | $ | 6 |  |  | $ | 6 |  |
| Other noncurrent assets | 14 |  |  | 14 |  |
| Total insurance receivables | $ | 20 |  |  | $ | 20 |  |

- removed (2024-07-31):
[0000833444-24-000029:note_history:43]
|  | March 31, 2024 |  | September 30, 2023 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 358 |  |  | 364 |  |
| Total asbestos-related liabilities | 416 |  |  | 422 |  |
| Other current assets | 22 |  |  | 28 |  |
| Other noncurrent assets | 308 |  |  | 273 |  |
| Total asbestos-related assets | 330 |  |  | 301 |  |
| Net asbestos-related liabilities | $ | 86 |  |  | $ | 121 |  |

- removed (2024-07-31):
[0000833444-24-000029:note_history:44]
|  | March 31, 2024 |  | September 30, 2023 |
| Restricted |  |  |  |
| Cash | $ | 14 |  |  | $ | 20 |  |
| Investments | 267 |  |  | 231 |  |
| Total restricted assets | 281 |  |  | 251 |  |
| Insurance receivables for asbestos-related liabilities | 49 |  |  | 50 |  |
| Total asbestos-related assets | $ | 330 |  |  | $ | 301 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-07-31):
[0000833444-24-000052:note_history:45]
BASIS OF PRESENTATION
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2023 filed with the SEC on December 14, 2023. The results of operations for the three and nine month periods ended June 30, 2024 are not necessarily indicative of results for the Company’s 2024 fiscal year because of seasonal and other factors.
  (was, 2024-05-01, similarity 0.9791):
[0000833444-24-000029:note_history:45]
BASIS OF PRESENTATION
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2023 filed with the SEC on December 14, 2023. The results of operations for the three and six month periods ended March 31, 2024 are not necessarily indicative of results for the Company’s 2024 fiscal year because of seasonal and other factors.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-07-31):
[0000833444-24-000052:note_history:46]
|  | June 30, |  | September 30, |
|  | 2024 |  | 2023 |
| Commercial paper | $ | 941 |  |  | $ | 200 |  |
| Term loans | 581 |  |  | 159 |  |
| Bank borrowings | 1 |  |  | 26 |  |
|  | $ | 1,523 |  |  | $ | 385 |  |
| Weighted average interest rate on short-term debt outstanding | 4.5 | % |  | 5.1 | % |

- changed (2024-07-31):
[0000833444-24-000052:note_history:47]
As of June 30, 2024, the Company had syndicated committed revolving credit facilities of $2.5 billion which is scheduled to expire in December 2028 and $500 million which is scheduled to expire in December 2024. There were no draws on the facilities as of June 30, 2024.
  (was, 2024-05-01, similarity 0.9476):
[0000833444-24-000029:note_history:47]
As of March 31, 2024, the Company had syndicated committed revolving credit facilities of $2.5 billion which is scheduled to expire in December 2028 and $500 million which is scheduled to expire in December 2024. There were no draws on the facilities as of March 31, 2024.

- added (2024-07-31):
[0000833444-24-000052:note_history:48]
In June 2024, the Company completed the debt tender offer to purchase $119 million of its 5.125% Notes due 2045.
In April 2024, the Company and its wholly-owned subsidiary, Tyco Fire & Security Finance S.C.A, co-issued $700 million unsecured, unsubordinated senior notes with an interest rate of 5.50% which is due April 2029.

- removed (2024-07-31):
[0000833444-24-000029:note_history:49]
|  | March 31, |  | September 30, |
|  | 2024 |  | 2023 |
| Commercial paper | $ | 1,784 |  |  | $ | 200 |  |
| Term loans | 424 |  |  | 159 |  |
| Bank borrowings | 2 |  |  | 26 |  |
|  | $ | 2,210 |  |  | $ | 385 |  |
| Weighted average interest rate on short-term debt outstanding | 4.7 | % |  | 5.1 | % |

- removed (2024-07-31):
[0000833444-24-000029:note_history:50]
In April 2024, the Company and its wholly-owned subsidiary, Tyco Fire & Security Finance S.C.A, co-issued $700 million unsecured, unsubordinated senior notes with an interest rate of 5.50% which is due April 2029.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-07-31):
[0000833444-24-000052:note_history:51]
The fair value of long-term debt at June 30, 2024 and September 30, 2023 was as follows (in billions):
  (was, 2024-05-01, similarity 0.9514):
[0000833444-24-000029:note_history:51]
The fair value of long-term debt at March 31, 2024 and September 30, 2023 was as follows (in billions):

- changed (2024-07-31):
[0000833444-24-000052:note_history:52]
|  |  | June 30, |  | September 30, |  |
|  | 2024 |  | 2023 |  |
| Public debt |  | $ | 8.1 |  |  | $ | 7.1 |  |  |
| Other long-term debt |  | 0.2 |  |  | 0.4 |  |  |
| Total fair value of long-term debt |  | $ | 8.3 |  |  | $ | 7.5 |  |  |
  (was, 2024-05-01, similarity 0.9773):
[0000833444-24-000029:note_history:52]
|  |  | March 31, |  | September 30, |  |
|  | 2024 |  | 2023 |  |
| Public debt |  | $ | 7.6 |  |  | $ | 7.1 |  |  |
| Other long-term debt |  | 0.4 |  |  | 0.4 |  |  |
| Total fair value of long-term debt |  | $ | 8.0 |  |  | $ | 7.5 |  |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-07-31):
[0000833444-24-000052:note_history:53]
|  | June 30, |  | September 30, |
|  | 2024 |  | 2023 |
| Commercial paper | $ | 941 |  |  | $ | 200 |  |
| Term loans | 581 |  |  | 159 |  |
| Bank borrowings | 1 |  |  | 26 |  |
|  | $ | 1,523 |  |  | $ | 385 |  |
| Weighted average interest rate on short-term debt outstanding | 4.5 | % |  | 5.1 | % |

- removed (2024-07-31):
[0000833444-24-000029:note_history:54]
|  | March 31, |  | September 30, |
|  | 2024 |  | 2023 |
| Commercial paper | $ | 1,784 |  |  | $ | 200 |  |
| Term loans | 424 |  |  | 159 |  |
| Bank borrowings | 2 |  |  | 26 |  |
|  | $ | 2,210 |  |  | $ | 385 |  |
| Weighted average interest rate on short-term debt outstanding | 4.7 | % |  | 5.1 | % |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-07-31):
[0000833444-24-000052:note_history:55]
|  |  | Three Months Ended June 30, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,791 |  |  | $ | 1,108 |  |  | $ | 2,899 |  |  | $ | 1,636 |  |  | $ | 1,029 |  |  | $ | 2,665 |  |
| Building Solutions EMEA/LA |  | 574 |  |  | 507 |  |  | 1,081 |  |  | 571 |  |  | 474 |  |  | 1,045 |  |
| Building Solutions Asia Pacific |  | 381 |  |  | 194 |  |  | 575 |  |  | 537 |  |  | 199 |  |  | 736 |  |
| Global Products |  | 2,676 |  |  | — |  |  | 2,676 |  |  | 2,687 |  |  | — |  |  | 2,687 |  |
| Total |  | $ | 5,422 |  |  | $ | 1,809 |  |  | $ | 7,231 |  |  | $ | 5,431 |  |  | $ | 1,702 |  |  | $ | 7,133 |  |
  (was, 2024-05-01, similarity 0.9921):
[0000833444-24-000029:note_history:55]
|  |  | Three Months Ended March 31, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,700 |  |  | $ | 1,039 |  |  | $ | 2,739 |  |  | $ | 1,554 |  |  | $ | 966 |  |  | $ | 2,520 |  |
| Building Solutions EMEA/LA |  | 572 |  |  | 492 |  |  | 1,064 |  |  | 582 |  |  | 449 |  |  | 1,031 |  |
| Building Solutions Asia Pacific |  | 308 |  |  | 183 |  |  | 491 |  |  | 479 |  |  | 188 |  |  | 667 |  |
| Global Products |  | 2,405 |  |  | — |  |  | 2,405 |  |  | 2,468 |  |  | — |  |  | 2,468 |  |
| Total |  | $ | 4,985 |  |  | $ | 1,714 |  |  | $ | 6,699 |  |  | $ | 5,083 |  |  | $ | 1,603 |  |  | $ | 6,686 |  |

- changed (2024-07-31):
[0000833444-24-000052:note_history:56]
|  |  | Nine Months Ended June 30, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 5,009 |  |  | $ | 3,116 |  |  | $ | 8,125 |  |  | $ | 4,641 |  |  | $ | 2,911 |  |  | $ | 7,552 |  |
| Building Solutions EMEA/LA |  | 1,718 |  |  | 1,465 |  |  | 3,183 |  |  | 1,705 |  |  | 1,346 |  |  | 3,051 |  |
| Building Solutions Asia Pacific |  | 1,026 |  |  | 547 |  |  | 1,573 |  |  | 1,489 |  |  | 560 |  |  | 2,049 |  |
| Global Products |  | 7,143 |  |  | — |  |  | 7,143 |  |  | 7,235 |  |  | — |  |  | 7,235 |  |
| Total |  | $ | 14,896 |  |  | $ | 5,128 |  |  | $ | 20,024 |  |  | $ | 15,070 |  |  | $ | 4,817 |  |  | $ | 19,887 |  |
  (was, 2024-05-01, similarity 0.9859):
[0000833444-24-000029:note_history:56]
|  |  | Six Months Ended March 31, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,218 |  |  | $ | 2,008 |  |  | $ | 5,226 |  |  | $ | 3,005 |  |  | $ | 1,882 |  |  | $ | 4,887 |  |
| Building Solutions EMEA/LA |  | 1,144 |  |  | 958 |  |  | 2,102 |  |  | 1,134 |  |  | 872 |  |  | 2,006 |  |
| Building Solutions Asia Pacific |  | 645 |  |  | 353 |  |  | 998 |  |  | 952 |  |  | 361 |  |  | 1,313 |  |
| Global Products |  | 4,467 |  |  | — |  |  | 4,467 |  |  | 4,548 |  |  | — |  |  | 4,548 |  |
| Total |  | $ | 9,474 |  |  | $ | 3,319 |  |  | $ | 12,793 |  |  | $ | 9,639 |  |  | $ | 3,115 |  |  | $ | 12,754 |  |

- changed (2024-07-31):
[0000833444-24-000052:note_history:57]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC |  | $ | 1,971 |  |  | $ | 1,973 |  |  | $ | 5,072 |  |  | $ | 5,170 |  |
| Fire & Security |  | 601 |  |  | 626 |  |  | 1,755 |  |  | 1,819 |  |
| Industrial Refrigeration |  | 104 |  |  | 88 |  |  | 316 |  |  | 246 |  |
| Total |  | $ | 2,676 |  |  | $ | 2,687 |  |  | $ | 7,143 |  |  | $ | 7,235 |  |
  (was, 2024-05-01, similarity 0.9388):
[0000833444-24-000029:note_history:57]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC |  | $ | 1,683 |  |  | $ | 1,757 |  |  | $ | 3,101 |  |  | $ | 3,197 |  |
| Fire & Security |  | 607 |  |  | 623 |  |  | 1,154 |  |  | 1,193 |  |
| Industrial Refrigeration |  | 115 |  |  | 88 |  |  | 212 |  |  | 158 |  |
| Total |  | $ | 2,405 |  |  | $ | 2,468 |  |  | $ | 4,467 |  |  | $ | 4,548 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-07-31):
[0000833444-24-000052:note_history:58]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of June 30, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $21.4 billion, of which approximately 67% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.
  (was, 2024-05-01, similarity 0.9955):
[0000833444-24-000029:note_history:58]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of March 31, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $21.2 billion, of which approximately 66% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-07-31):
[0000833444-24-000052:note_history:59]
|  |  | Three Months Ended June 30, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,791 |  |  | $ | 1,108 |  |  | $ | 2,899 |  |  | $ | 1,636 |  |  | $ | 1,029 |  |  | $ | 2,665 |  |
| Building Solutions EMEA/LA |  | 574 |  |  | 507 |  |  | 1,081 |  |  | 571 |  |  | 474 |  |  | 1,045 |  |
| Building Solutions Asia Pacific |  | 381 |  |  | 194 |  |  | 575 |  |  | 537 |  |  | 199 |  |  | 736 |  |
| Global Products |  | 2,676 |  |  | — |  |  | 2,676 |  |  | 2,687 |  |  | — |  |  | 2,687 |  |
| Total |  | $ | 5,422 |  |  | $ | 1,809 |  |  | $ | 7,231 |  |  | $ | 5,431 |  |  | $ | 1,702 |  |  | $ | 7,133 |  |
  (was, 2024-05-01, similarity 0.9921):
[0000833444-24-000029:note_history:59]
|  |  | Three Months Ended March 31, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,700 |  |  | $ | 1,039 |  |  | $ | 2,739 |  |  | $ | 1,554 |  |  | $ | 966 |  |  | $ | 2,520 |  |
| Building Solutions EMEA/LA |  | 572 |  |  | 492 |  |  | 1,064 |  |  | 582 |  |  | 449 |  |  | 1,031 |  |
| Building Solutions Asia Pacific |  | 308 |  |  | 183 |  |  | 491 |  |  | 479 |  |  | 188 |  |  | 667 |  |
| Global Products |  | 2,405 |  |  | — |  |  | 2,405 |  |  | 2,468 |  |  | — |  |  | 2,468 |  |
| Total |  | $ | 4,985 |  |  | $ | 1,714 |  |  | $ | 6,699 |  |  | $ | 5,083 |  |  | $ | 1,603 |  |  | $ | 6,686 |  |

- changed (2024-07-31):
[0000833444-24-000052:note_history:60]
|  |  | Nine Months Ended June 30, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 5,009 |  |  | $ | 3,116 |  |  | $ | 8,125 |  |  | $ | 4,641 |  |  | $ | 2,911 |  |  | $ | 7,552 |  |
| Building Solutions EMEA/LA |  | 1,718 |  |  | 1,465 |  |  | 3,183 |  |  | 1,705 |  |  | 1,346 |  |  | 3,051 |  |
| Building Solutions Asia Pacific |  | 1,026 |  |  | 547 |  |  | 1,573 |  |  | 1,489 |  |  | 560 |  |  | 2,049 |  |
| Global Products |  | 7,143 |  |  | — |  |  | 7,143 |  |  | 7,235 |  |  | — |  |  | 7,235 |  |
| Total |  | $ | 14,896 |  |  | $ | 5,128 |  |  | $ | 20,024 |  |  | $ | 15,070 |  |  | $ | 4,817 |  |  | $ | 19,887 |  |
  (was, 2024-05-01, similarity 0.9859):
[0000833444-24-000029:note_history:60]
|  |  | Six Months Ended March 31, |
|  |  | 2024 |  | 2023 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,218 |  |  | $ | 2,008 |  |  | $ | 5,226 |  |  | $ | 3,005 |  |  | $ | 1,882 |  |  | $ | 4,887 |  |
| Building Solutions EMEA/LA |  | 1,144 |  |  | 958 |  |  | 2,102 |  |  | 1,134 |  |  | 872 |  |  | 2,006 |  |
| Building Solutions Asia Pacific |  | 645 |  |  | 353 |  |  | 998 |  |  | 952 |  |  | 361 |  |  | 1,313 |  |
| Global Products |  | 4,467 |  |  | — |  |  | 4,467 |  |  | 4,548 |  |  | — |  |  | 4,548 |  |
| Total |  | $ | 9,474 |  |  | $ | 3,319 |  |  | $ | 12,793 |  |  | $ | 9,639 |  |  | $ | 3,115 |  |  | $ | 12,754 |  |

- changed (2024-07-31):
[0000833444-24-000052:note_history:61]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC |  | $ | 1,971 |  |  | $ | 1,973 |  |  | $ | 5,072 |  |  | $ | 5,170 |  |
| Fire & Security |  | 601 |  |  | 626 |  |  | 1,755 |  |  | 1,819 |  |
| Industrial Refrigeration |  | 104 |  |  | 88 |  |  | 316 |  |  | 246 |  |
| Total |  | $ | 2,676 |  |  | $ | 2,687 |  |  | $ | 7,143 |  |  | $ | 7,235 |  |
  (was, 2024-05-01, similarity 0.9388):
[0000833444-24-000029:note_history:61]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| HVAC |  | $ | 1,683 |  |  | $ | 1,757 |  |  | $ | 3,101 |  |  | $ | 3,197 |  |
| Fire & Security |  | 607 |  |  | 623 |  |  | 1,154 |  |  | 1,193 |  |
| Industrial Refrigeration |  | 115 |  |  | 88 |  |  | 212 |  |  | 158 |  |
| Total |  | $ | 2,405 |  |  | $ | 2,468 |  |  | $ | 4,467 |  |  | $ | 4,548 |  |

- changed (2024-07-31):
[0000833444-24-000052:note_history:62]
|  |  | Location of contract balances |  | June 30, 2024 |  | September 30, 2023 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,961 |  |  | $ | 2,370 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 9 |  |  | 12 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,143 |  |  | 1,996 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 314 |  |  | 297 |  |  |  |
  (was, 2024-05-01, similarity 0.989):
[0000833444-24-000029:note_history:62]
|  |  | Location of contract balances |  | March 31, 2024 |  | September 30, 2023 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,063 |  |  | $ | 2,370 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 5 |  |  | 12 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,331 |  |  | 1,996 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 310 |  |  | 297 |  |  |  |

- added (2024-07-31):
[0000833444-24-000052:note_history:63]
For the three months ended June 30, 2024 and 2023, the Company recognized revenue of $269 million and $222 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year. For the nine months ended June 30, 2024 and 2023, the Company recognized revenue of $1,530 million and $1,387 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year.

- changed (2024-07-31):
[0000833444-24-000052:note_history:64]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of June 30, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $21.4 billion, of which approximately 67% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.
  (was, 2024-05-01, similarity 0.9955):
[0000833444-24-000029:note_history:64]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of March 31, 2024, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $21.2 billion, of which approximately 66% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less.

- changed (2024-07-31):
[0000833444-24-000052:note_history:65]
|  |  | June 30, 2024 |  | September 30, 2023 |  |  |
| Other current assets |  | $ | 247 |  |  | $ | 156 |  |  |  |
| Other noncurrent assets |  | 278 |  |  | 224 |  |  |  |
| Total |  | $ | 525 |  |  | $ | 380 |  |  |  |
  (was, 2024-05-01, similarity 0.9746):
[0000833444-24-000029:note_history:65]
|  |  | March 31, 2024 |  | September 30, 2023 |  |  |
| Other current assets |  | $ | 204 |  |  | $ | 156 |  |  |  |
| Other noncurrent assets |  | 263 |  |  | 224 |  |  |  |
| Total |  | $ | 467 |  |  | $ | 380 |  |  |  |

- changed (2024-07-31):
[0000833444-24-000052:note_history:66]
During the three months ended June 30, 2024 and 2023, the Company recognized amortization expense of $84 million and $66 million, respectively, related to costs to obtain or fulfill a contract. During the nine months ended June 30, 2024 and 2023, the Company recognized amortization expense of $218 million and $188 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and nine months ended June 30, 2024 and 2023.
  (was, 2024-05-01, similarity 0.8721):
[0000833444-24-000029:note_history:66]
During the three months ended March 31, 2024 and 2023, the Company recognized amortization expense of $77 million and $61 million, respectively, related to costs to obtain or fulfill a contract. During the six months ended March 31, 2024 and 2023, the Company recognized amortization expense of $134 million and $122 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three and six months ended March 31, 2024 and 2023.

- removed (2024-07-31):
[0000833444-24-000029:note_history:67]
For the three months ended March 31, 2024 and 2023, the Company recognized revenue of $372 million and $319 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year. For the six months ended March 31, 2024 and 2023, the Company recognized revenue of $1,261 million and $1,165 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2024-07-31):
[0000833444-24-000052:note_history:68]
SUBSEQUENT EVENT
On July 23, 2024, the Company entered into a Stock and Asset Purchase Agreement (“Purchase Agreement”) with Bosch GmbH, a Gesellschaft mit beschränkter Haftung (“Purchaser”). Pursuant to the Purchase Agreement, on the terms and subject to the conditions therein, the Company has agreed to sell, and Purchaser has agreed to acquire, the Company’s Residential and Light Commercial HVAC business (the “R&LC Business”), including the Company’s North America Ducted business and Johnson Controls-Hitachi Air Conditioning Holding (UK) Ltd., the Company’s global Residential joint venture with Hitachi Global Life Solutions, Inc. (“Hitachi”), of which the Company owns 60% and Hitachi owns 40%. The total consideration payable by Purchaser to the Company and Hitachi is approximately  $8.1 billion in cash, and the Company’s portion of the aggregate consideration is approximately $6.7 billion in cash, in each case, subject to adjustment, plus the assumption by Purchaser or its affiliates of certain liabilities of the R&LC Business specified in the Purchase Agreement. Net cash proceeds to the Company are expected to be approximately $5.0 billion after tax and transaction-related expenses. The transaction is expected to close in the fourth quarter of fiscal 2025, subject to required regulatory approvals and other customary closing conditions. The Company expects to report the operating results of the R&LC HVAC business, which is currently reported in the Global Products segment, in discontinued operations beginning in the fourth quarter of fiscal 2024.
