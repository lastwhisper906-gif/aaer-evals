# JCI 8-K — 0000833444-24-000060 filed 2024-11-06

## item codes, every 8-K on or before 2024-11-19

- 2024-11-06 0000833444-24-000060 — 2.02, 9.01
- 2024-08-05 0000833444-24-000055 — 5.02, 7.01, 9.01
- 2024-07-31 0000833444-24-000049 — 2.02, 9.01
- 2024-07-26 0001193125-24-186281 — 1.01, 9.01
- 2024-07-23 0000833444-24-000044 — 2.02, 7.01, 9.01
- 2024-06-04 0001193125-24-154244 — 8.01, 9.01
- 2024-05-20 0000833444-24-000032 — 8.01, 9.01
- 2024-05-01 0000833444-24-000026 — 2.02, 9.01
- 2024-04-19 0001193125-24-102867 — 8.01, 9.01
- 2024-04-12 0000833444-24-000023 — 1.01, 8.01, 9.01
- 2024-03-18 0000833444-24-000020 — 5.07
- 2024-01-30 0000833444-24-000007 — 2.02, 9.01
- 2024-01-16 0000833444-24-000004 — 5.02, 9.01
- 2023-12-12 0000833444-23-000044 — 2.02, 9.01
- 2023-12-08 0000833444-23-000042 — 5.02
- 2023-11-13 0000833444-23-000038 — 8.01
- 2023-09-27 0000833444-23-000036 — 8.01
- 2023-09-08 0000833444-23-000033 — 5.02
- 2023-08-21 0001193125-23-217018 — 8.01, 9.01
- 2023-08-07 0001193125-23-205014 — 8.01, 9.01
- 2023-08-02 0000833444-23-000028 — 2.02, 9.01
- 2023-05-23 0001193125-23-151889 — 8.01, 9.01
- 2023-05-05 0000833444-23-000011 — 2.02, 9.01
- 2023-03-14 0000833444-23-000007 — 5.07
- 2023-02-01 0000833444-23-000003 — 2.02, 9.01
- 2022-12-22 0000833444-22-000047 — 5.02
- 2022-12-09 0000833444-22-000045 — 5.02
- 2022-11-03 0000833444-22-000038 — 2.02, 9.01
- 2022-09-14 0001193125-22-244741 — 8.01, 9.01
- 2022-09-07 0001193125-22-240030 — 8.01, 9.01
- 2022-08-04 0000833444-22-000034 — 2.02, 9.01
- 2022-07-06 0000833444-22-000029 — 5.02, 9.01
- 2022-06-30 0000833444-22-000027 — 5.02
- 2022-05-04 0000833444-22-000014 — 2.02, 9.01
- 2022-03-11 0001193125-22-073382 — 5.07
- 2022-02-15 0000833444-22-000010 — 5.02
- 2022-02-02 0000833444-22-000003 — 2.02, 9.01
- 2021-12-10 0000833444-21-000050 — 5.02
- 2021-11-05 0000833444-21-000043 — 2.02, 9.01
- 2021-09-16 0001193125-21-275152 — 1.01, 8.01, 9.01
- 2021-07-30 0000833444-21-000038 — 2.02, 9.01
- 2021-05-03 0000833444-21-000023 — 8.01
- 2021-04-30 0000833444-21-000017 — 2.02, 9.01
- 2021-03-11 0000833444-21-000013 — 5.02, 5.07, 9.01
- 2021-02-17 0001193125-21-045768 — 7.01, 9.01
- 2021-01-29 0000833444-21-000009 — 2.02, 9.01
- 2021-01-07 0000833444-21-000004 — 7.01
- 2020-11-03 0000833444-20-000043 — 2.02, 9.01
- 2020-09-15 0001193125-20-246240 — 1.01, 8.01, 9.01
- 2020-09-11 0001193125-20-244119 — 1.01, 8.01, 9.01
- 2020-08-18 0000833444-20-000038 — 5.02, 9.01
- 2020-07-31 0000833444-20-000034 — 2.02, 9.01
- 2020-06-12 0000833444-20-000020 — 8.01
- 2020-05-01 0000833444-20-000013 — 2.02, 9.01
- 2020-03-12 0000833444-20-000010 — 5.02
- 2020-03-06 0000833444-20-000008 — 5.07
- 2020-01-31 0000833444-20-000003 — 2.02, 9.01
- 2019-12-06 0001193125-19-308301 — 1.01, 1.02, 2.03, 9.01
- 2019-11-07 0000833444-19-000048 — 5.02, 9.01
- 2019-11-07 0000833444-19-000046 — 2.02, 9.01
- 2019-08-21 0000833444-19-000043 — 8.01
- 2019-07-31 0000833444-19-000038 — 2.02, 9.01
- 2019-07-23 0000833444-19-000035 — 5.02, 8.01, 9.01
- 2019-07-02 0000833444-19-000033 — 1.02, 8.01
- 2019-06-05 0001193125-19-165565 — 8.01
- 2019-05-30 0001193125-19-160205 — 8.01, 9.01
- 2019-05-16 0001193125-19-148262 — 8.01, 9.01
- 2019-05-07 0001193125-19-139826 — 5.04, 9.01
- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2024-11-19

- 2023-11-29 0000833444-23-000040 — NT 10-K, for the period ended 2023-09-30
- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-24-000060:8k_2_02:1]
EX-99.1
2
q4exh991xq4fy24earningsrel.htm
EX-99.1

[0000833444-24-000060:8k_2_02:2]
Document

[0000833444-24-000060:8k_2_02:3]
Exhibit 99.1

[0000833444-24-000060:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-24-000060:8k_2_02:5]
Johnson Controls Reports Q4 and FY24 Results; Initiates FY25 Guidance

[0000833444-24-000060:8k_2_02:6]
______________________________________________________________________________________

[0000833444-24-000060:8k_2_02:7]
▪Q4 sales increased 7% and organic sales increased 10%*

[0000833444-24-000060:8k_2_02:8]
▪Full year sales increased 2% and organic sales increased 4%*

[0000833444-24-000060:8k_2_02:9]
▪Q4 GAAP EPS of $0.95; Q4 Adjusted EPS* of $1.28

[0000833444-24-000060:8k_2_02:10]
▪Full year GAAP EPS of $2.52; full year Adjusted EPS of $3.71

[0000833444-24-000060:8k_2_02:11]
▪Q4 Orders +8% organically year-over-year

[0000833444-24-000060:8k_2_02:12]
▪Building Solutions backlog of $13.1 billion increased 7% organically year-over-year

[0000833444-24-000060:8k_2_02:13]
*  This news release contains non-GAAP financial measures. Definitions and reconciliations of the non-GAAP financial measures can be found in the attached footnotes. Non-GAAP measures should be considered in addition to, and not as replacements for, the most comparable GAAP measures. Unless otherwise indicated, historical results represent the consolidated results of the Company, inclusive of the Residential & Light Commercial business, which was classified as discontinued operations during the fiscal fourth quarter of 2024. See footnote one for additional details.

[0000833444-24-000060:8k_2_02:14]
_____________________________________________________________________________________

[0000833444-24-000060:8k_2_02:15]
CORK, Ireland — November 6, 2024 — Johnson Controls International plc (NYSE: JCI), a global leader for smart, healthy and sustainable buildings, today reported fiscal fourth quarter 2024 GAAP earnings per share (“EPS”) of $0.95. Excluding special items, adjusted EPS was $1.28.

[0000833444-24-000060:8k_2_02:16]
Q4 sales increased 7% to $7.4 billion and organic sales  increased 10%. Full year sales from increased 2% to $27.4 billion and organic sales increased 4%.

[0000833444-24-000060:8k_2_02:17]
For the quarter, GAAP net income was $633 million and adjusted net income was $858 million.

[0000833444-24-000060:8k_2_02:18]
“We are very pleased with our strong end to the fiscal year and our fourth quarter results, which delivered double-digit organic sales growth and robust margin expansion,” said George Oliver, Chairman and CEO. “Johnson Controls is entering fiscal 2025 with momentum.  Backlog is at record levels and we are well positioned to deliver continued profitable top line growth.  Importantly, the actions taken during the year to simplify our portfolio are allowing us to focus our resources on expanding Johnson Controls as a leading pure-play building solutions provider.  We are driving greater outcomes for our customers globally across the building lifecycle while unlocking shareholder value.”

[0000833444-24-000060:8k_2_02:19]
FISCAL Q4 SEGMENT RESULTS

[0000833444-24-000060:8k_2_02:20]
The financial highlights presented in the tables below include both continuing and discontinued operations and are in accordance with GAAP, unless otherwise indicated. All comparisons are to the fiscal fourth quarter of 2023.

[0000833444-24-000060:8k_2_02:21]
A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-24-000060:8k_2_02:22]
1

[0000833444-24-000060:8k_2_02:23]
Building Solutions North America

[0000833444-24-000060:8k_2_02:24]
|  |  | Fiscal Q4 |  |  |  |  |  |
| (in millions) |  | 2024 |  | 2023 |  | Change |  |  |  |  |  |
| Sales |  | $ | 3,223 |  |  | $ | 2,778 |  |  | 16 | % |  |  |  |  |  |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 484 |  |  | 427 |  |  | 13 | % |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 484 |  |  | 427 |  |  | 13 | % |  |  |  |  |  |
| Segment EBITA Margin % |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 15.0 | % |  | 15.4 | % |  | (40 | bp) |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 15.0 | % |  | 15.4 | % |  | (40 | bp) |  |  |  |  |  |

[0000833444-24-000060:8k_2_02:25]
Sales in the quarter of $3.2 billion increased 16% over the prior year. Organic sales also increased 16% led by growth greater than 20% in Applied HVAC & Controls.

[0000833444-24-000060:8k_2_02:26]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 7% year-over-year. Backlog at the end of the quarter of $9.1 billion increased 10% compared to the prior year, excluding M&A and adjusted for foreign currency.

[0000833444-24-000060:8k_2_02:27]
Segment EBITA margin of 15.0% declined 40 basis points versus the prior year primarily due to unfavorable mix, as Systems grew faster than Service.

[0000833444-24-000060:8k_2_02:28]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-24-000060:8k_2_02:29]
|  |  | Fiscal Q4 |  |  |  |  |  |
| (in millions) |  | 2024 |  | 2023 |  | Change |  |  |  |  |  |
| Sales |  | $ | 1,113 |  |  | $ | 1,045 |  |  | 7 | % |  |  |  |  |  |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 111 |  |  | 82 |  |  | 35 | % |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 128 |  |  | 82 |  |  | 56 | % |  |  |  |  |  |
| Segment EBITA Margin % |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 10.0 | % |  | 7.8 | % |  | 220 | bp |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 11.5 | % |  | 7.8 | % |  | 370 | bp |  |  |  |  |  |

[0000833444-24-000060:8k_2_02:30]
Sales in the quarter of $1.1 billion increased 7% over the prior year. Organic sales grew 10% versus the prior year led by double-digit growth in Controls, Security, and Industrial Refrigeration.

[0000833444-24-000060:8k_2_02:31]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 14% year-over-year. Backlog at the end of the quarter of $2.5 billion increased 10% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-24-000060:8k_2_02:32]
Segment EBITA margin of 10.0% expanded 220 basis points versus the prior year driven by improved productivity and by the positive mix from the growth in Service.  Adjusted segment EBITA in Q4 2024 excludes a non-recurring loss associated with the equity method accounting for a joint venture.

[0000833444-24-000060:8k_2_02:33]
2

[0000833444-24-000060:8k_2_02:34]
Building Solutions Asia Pacific

[0000833444-24-000060:8k_2_02:35]
|  |  | Fiscal Q4 |  |  |  |  |  |
| (in millions) |  | 2024 |  | 2023 |  | Change |  |  |  |  |  |
| Sales |  | $ | 664 |  |  | $ | 697 |  |  | (5 | %) |  |  |  |  |  |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 94 |  |  | 94 |  |  | — | % |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 94 |  |  | 94 |  |  | — | % |  |  |  |  |  |
| Segment EBITA Margin % |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 14.2 | % |  | 13.5 | % |  | 70 | bp |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 14.2 | % |  | 13.5 | % |  | 70 | bp |  |  |  |  |  |

[0000833444-24-000060:8k_2_02:36]
Sales in the quarter of $664 million declined 5% versus the prior year. Organic sales also declined 5% versus the prior year as mid single-digit Service growth was more than offset by continued weakness in the Systems business in China.

[0000833444-24-000060:8k_2_02:37]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 6% year-over-year. Backlog at the end of the quarter of $1.5 billion decreased 10% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-24-000060:8k_2_02:38]
Segment EBITA margin of 14.2% improved 70 basis points versus the prior year as positive mix from our Service business offset a decline in our Systems business.

[0000833444-24-000060:8k_2_02:39]
Global Products

[0000833444-24-000060:8k_2_02:40]
|  |  | Fiscal Q4* |  |  |  |  |  |
| (in millions) |  | 2024 |  | 2023 |  | Change |  |  |  |  |  |
| Sales |  | $ | 2,394 |  |  | $ | 2,386 |  |  | — | % |  |  |  |  |  |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 670 |  |  | 502 |  |  | 33 | % |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 670 |  |  | 502 |  |  | 33 | % |  |  |  |  |  |
| Segment EBITA Margin % |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 28.0 | % |  | 21.0 | % |  | 700 | bp |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 28.0 | % |  | 21.0 | % |  | 700 | bp |  |  |  |  |  |

[0000833444-24-000060:8k_2_02:41]
*Includes results for both continuing operations and discontinued operations related to the sale of the Residential and Light Commercial HVAC business.  See footnote one for additional details.

[0000833444-24-000060:8k_2_02:42]
Sales in the quarter of $2.4 billion were flat versus the prior year. Organic sales grew 8% versus the prior year as growth in Commercial and Residential HVAC were offset by declines in both Fire & Security and Industrial Refrigeration.

[0000833444-24-000060:8k_2_02:43]
Segment EBITA margin of 28.0% expanded 700 basis points versus the prior year driven primarily by operational efficiencies leading to productivity improvements.

[0000833444-24-000060:8k_2_02:44]
3

[0000833444-24-000060:8k_2_02:45]
Corporate

[0000833444-24-000060:8k_2_02:46]
|  |  | Fiscal Q4 |  |  |  |  |  |
| (in millions) |  | 2024 |  | 2023 |  | Change |  |  |  |  |  |
| Corporate Expense |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 158 |  |  | $ | 70 |  |  | 126 | % |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 114 |  |  | 49 |  |  | 133 | % |  |  |  |  |  |

[0000833444-24-000060:8k_2_02:47]
Adjusted Corporate expense excludes certain transaction/separation costs.

[0000833444-24-000060:8k_2_02:48]
OTHER Q4 ITEMS

[0000833444-24-000060:8k_2_02:49]
▪Total cash provided by operating activities of $1,526 million included cash from continuing operations of $1,352 million and cash from discontinued operations of $174 million. Free cash flow was $1,318 million and adjusted free cash flow was $1,087 million.

[0000833444-24-000060:8k_2_02:50]
▪The Company paid dividends of $247 million.

[0000833444-24-000060:8k_2_02:51]
▪The Company repurchased 5.4 million shares of common stock for approximately $370 million.

[0000833444-24-000060:8k_2_02:52]
▪The Company recorded pre-tax restructuring and impairment costs for continuing and discontinued operations of $145 million, comprised primarily of severance and other charges related to ongoing restructuring actions and certain asset impairments.

[0000833444-24-000060:8k_2_02:53]
▪The Company signed a definitive agreement to sell its Residential and Light Commercial HVAC business (the “R&LC Business”), which includes the North America Ducted businesses and the global Residential joint venture with Hitachi Global Life Solutions, Inc. (“Hitachi”), of which Johnson Controls owns 60% and Hitachi owns 40%, to Bosch Group for approximately $8.1 billion in cash with the Company’s portion of the aggregate consideration being approximately $6.7 billion. The transaction is expected to close in the fourth quarter of fiscal 2025, subject to required regulatory approvals and other customary closing conditions.

[0000833444-24-000060:8k_2_02:54]
▪The Company announced a multi-year restructuring plan to address stranded costs and further right-size its global operations following its previously announced portfolio simplification actions. The Company expects to incur approximately $400 million in restructuring costs over the next three years, resulting in expected annual cost savings of approximately $500 million.

[0000833444-24-000060:8k_2_02:55]
4

[0000833444-24-000060:8k_2_02:56]
GUIDANCE

[0000833444-24-000060:8k_2_02:57]
The following forward-looking statements regarding organic sales growth, adjusted segment EBITA margin, adjusted segment EBITA margin improvement and adjusted EPS are non-GAAP financial measures and are presented on a continuing operations basis excluding the R&LC Business, which was classified as discontinued operations during the fiscal fourth quarter of 2024. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as mark-to-market adjustments. Organic revenue growth excludes the effect of acquisitions, divestitures and foreign currency. The Company is unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to its most directly comparable forward-looking GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s fiscal 2025 first quarter and full year GAAP financial results from continuing operations.

[0000833444-24-000060:8k_2_02:58]
The Company initiated fiscal 2025 first quarter continuing operations guidance:

[0000833444-24-000060:8k_2_02:59]
▪Organic sales growth of mid-single digits

[0000833444-24-000060:8k_2_02:60]
▪Adjusted segment EBITA margin of ~14.5%

[0000833444-24-000060:8k_2_02:61]
▪Adjusted EPS before special items of ~$0.57 to $0.60

[0000833444-24-000060:8k_2_02:62]
The Company initiated fiscal 2025 full year continuing operations guidance:

[0000833444-24-000060:8k_2_02:63]
▪Organic sales growth of mid-single digits

[0000833444-24-000060:8k_2_02:64]
▪Adjusted segment EBITA margin improvement of more than 50 basis points, year-over-year

[0000833444-24-000060:8k_2_02:65]
▪Adjusted EPS before special items of ~$3.40 to $3.50

[0000833444-24-000060:8k_2_02:66]
CONFERENCE CALL & WEBCAST INFO

[0000833444-24-000060:8k_2_02:67]
Johnson Controls will host a conference call to discuss this quarter’s results at 8:30 a.m. ET today, which can be accessed by dialing 844-763-8274 (in the United States) or +1-412-717-9224 (outside the United States), or via webcast. A slide presentation will accompany the prepared remarks and has been posted on the investor relations section of the Johnson Controls website at https://investors.johnsoncontrols.com/news-and-events/events-and-presentations. A replay will be made available approximately two hours following the conclusion of the conference call.

[0000833444-24-000060:8k_2_02:68]
ABOUT JOHNSON CONTROLS

[0000833444-24-000060:8k_2_02:69]
At Johnson Controls (NYSE:JCI), we transform the environments where people live, work, learn and play. As the global leader in smart, healthy and sustainable buildings, our mission is to reimagine the performance of buildings to serve people, places and the planet.

[0000833444-24-000060:8k_2_02:70]
5

[0000833444-24-000060:8k_2_02:71]
Building on a proud history of nearly 140 years of innovation, we deliver the blueprint of the future for industries such as healthcare, schools, data centers, airports, stadiums, manufacturing and beyond through OpenBlue, our comprehensive digital offering.

[0000833444-24-000060:8k_2_02:72]
Today, with a global team of almost 100,000 experts in more than 150 countries, Johnson Controls offers the world`s largest portfolio of building technology and software as well as service solutions from some of the most trusted names in the industry.

[0000833444-24-000060:8k_2_02:73]
Visit www.johnsoncontrols.com for more information and follow @Johnson Controls on social platforms.

[0000833444-24-000060:8k_2_02:74]
JOHNSON CONTROLS CONTACTS:

[0000833444-24-000060:8k_2_02:75]
| INVESTOR CONTACTS: | MEDIA CONTACT: |  |  |  |
| Jim Lucas | Danielle Canzanella |  |  |  |
| Direct: +1 414.340.1752 | Direct: +1 203.499.8297 |  |  |  |
| Email: jim.lucas@jci.com | Email: danielle.canzanella@jci.com |  |  |  |
| Michael Gates |  |  |  |  |
| Direct: +1 414.524.5785 |  |  |  |  |
| Email: michael.j.gates@jci.com |  |  |  |  |

[0000833444-24-000060:8k_2_02:76]
###

[0000833444-24-000060:8k_2_02:77]
JOHNSON CONTROLS INTERNATIONAL PLC CAUTIONARY STATEMENT REGARDING FORWARD-LOOKING STATEMENTS

[0000833444-24-000060:8k_2_02:78]
6

[0000833444-24-000060:8k_2_02:79]
Johnson Controls’ customers; the ability to manage macroeconomic and geopolitical volatility, including supply chain shortages and the conflicts between Russia and Ukraine and Israel and Hamas; managing the risks and impacts of potential and actual security breaches, cyberattacks, privacy breaches or data breaches; maintaining and improving the capacity, reliability and security of Johnson Controls’ enterprise information technology infrastructure; the ability to manage the lifecycle cybersecurity risk in the development, deployment and operation of Johnson Controls’ digital platforms and services; changes to laws or policies governing foreign trade, including economic sanctions, tariffs, foreign exchange and capital controls, import/export controls or other trade restrictions; fluctuations in currency exchange rates; changes or uncertainty in laws, regulations, rates, policies, or interpretations that impact Johnson Controls’ business operations or tax status; the ability to adapt to global climate change, climate change regulation and successfully meet Johnson Controls’ public sustainability commitments; risks and uncertainties related to the settlement with a nationwide class of public water systems concerning the use of AFFF; the outcome of litigation and governmental proceedings; the risk of infringement or expiration of intellectual property rights; Johnson Controls’ ability to manage disruptions caused by catastrophic or geopolitical events, such as natural disasters, armed conflict, political change, climate change, pandemics and outbreaks of contagious diseases and other adverse public health developments;  any delay or inability of Johnson Controls to realize the expected benefits and synergies of recent portfolio transactions; the tax treatment of recent portfolio transactions; significant transaction costs and/or unknown liabilities associated with such transactions; labor shortages, work stoppages, union negotiations, labor disputes and other matters associated with the labor force; and the cancellation of or changes to commercial arrangements. A detailed discussion of risks related to Johnson Controls business is included in the section entitled “Risk Factors” in Johnson Controls Annual Report on Form 10-K for the fiscal year filed with the SEC, which is available at www.sec.gov and www.johnsoncontrols.com under the “Investors” tab, and such factors may be updated from time to time in Johnson Controls filings with the SEC, which are or will be accessible on the SEC’s website at www.sec.gov. Shareholders, potential investors and others should consider these factors in evaluating the forward-looking statements and should not place undue reliance on such statements. The forward-looking statements included in this communication are made only as of the date of this document, unless otherwise specified, and, except as required by law, Johnson Controls assumes no obligation, and disclaims any obligation, to update such statements to reflect events or circumstances occurring after the date of this communication.

[0000833444-24-000060:8k_2_02:80]
###

[0000833444-24-000060:8k_2_02:81]
7

[0000833444-24-000060:8k_2_02:82]
FINANCIAL STATEMENTS

[0000833444-24-000060:8k_2_02:83]
Johnson Controls International plc

[0000833444-24-000060:8k_2_02:84]
Consolidated Statements of Income

[0000833444-24-000060:8k_2_02:85]
(in millions, except per share data; unaudited)

[0000833444-24-000060:8k_2_02:86]
|  | Three Months Ended September 30, |  | Twelve Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales |  |  |  |  |  |  |  |
| Products and systems | $ | 4,391 |  |  | $ | 4,128 |  |  | $ | 15,967 |  |  | $ | 15,789 |  |
| Services | 1,857 |  |  | 1,725 |  |  | 6,985 |  |  | 6,542 |  |
|  | 6,248 |  |  | 5,853 |  |  | 22,952 |  |  | 22,331 |  |
| Cost of sales |  |  |  |  |  |  |  |
| Products and systems | 2,872 |  |  | 2,877 |  |  | 10,677 |  |  | 10,736 |  |
| Services | 1,108 |  |  | 1,004 |  |  | 4,198 |  |  | 3,791 |  |
|  | 3,980 |  |  | 3,881 |  |  | 14,875 |  |  | 14,527 |  |
| Gross profit | 2,268 |  |  | 1,972 |  |  | 8,077 |  |  | 7,804 |  |
| Selling, general and administrative expenses | 1,368 |  |  | 1,309 |  |  | 5,661 |  |  | 5,387 |  |
| Restructuring and impairment costs | 133 |  |  | 212 |  |  | 510 |  |  | 1,049 |  |
| Net financing charges | 96 |  |  | 56 |  |  | 342 |  |  | 258 |  |
| Equity income (loss) | (23) |  |  | 1 |  |  | (42) |  |  | 3 |  |
| Income from continuing operations before income taxes | 648 |  |  | 396 |  |  | 1,522 |  |  | 1,113 |  |
| Income tax provision (benefit) | 110 |  |  | (92) |  |  | 111 |  |  | (468) |  |
| Income from continuing operations | 538 |  |  | 488 |  |  | 1,411 |  |  | 1,581 |  |
| Income from discontinued operations, net of tax | 140 |  |  | 93 |  |  | 489 |  |  | 452 |  |
| Net income | 678 |  |  | 581 |  |  | 1,900 |  |  | 2,033 |  |
| Income from continuing operations attributable to noncontrolling interests | 2 |  |  | 7 |  |  | 4 |  |  | 19 |  |
| Income from discontinued operations attributable to noncontrolling interests | 43 |  |  | 25 |  |  | 191 |  |  | 165 |  |
| Net income attributable to Johnson Controls | $ | 633 |  |  | $ | 549 |  |  | $ | 1,705 |  |  | $ | 1,849 |  |
| Amounts attributable to Johnson Controls ordinary shareholders: |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 536 |  |  | $ | 481 |  |  | $ | 1,407 |  |  | $ | 1,562 |  |
| Income from discontinued operations | 97 |  |  | 68 |  |  | 298 |  |  | 287 |  |
| Net income | $ | 633 |  |  | $ | 549 |  |  | $ | 1,705 |  |  | $ | 1,849 |  |
| Basic earnings per share attributable to Johnson Controls |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.80 |  |  | $ | 0.71 |  |  | $ | 2.09 |  |  | $ | 2.28 |  |
| Discontinued operations | 0.15 |  |  | 0.10 |  |  | 0.44 |  |  | 0.42 |  |
| Total | $ | 0.95 |  |  | $ | 0.81 |  |  | $ | 2.53 |  |  | $ | 2.70 |  |
| Diluted earnings per share attributable to Johnson Controls |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.80 |  |  | $ | 0.70 |  |  | $ | 2.08 |  |  | $ | 2.27 |  |
| Discontinued operations | 0.15 |  |  | 0.10 |  |  | 0.44 |  |  | 0.42 |  |
| Total | $ | 0.95 |  |  | $ | 0.80 |  |  | $ | 2.52 |  |  | $ | 2.69 |  |

[0000833444-24-000060:8k_2_02:87]
8

[0000833444-24-000060:8k_2_02:88]
Johnson Controls International plc

[0000833444-24-000060:8k_2_02:89]
Condensed Consolidated Statements of Financial Position

[0000833444-24-000060:8k_2_02:90]
(in millions; unaudited)

[0000833444-24-000060:8k_2_02:91]
|  | September 30, 2024 |  | September 30, 2023 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 606 |  |  | $ | 828 |  |
| Accounts receivable - net | 6,051 |  |  | 5,494 |  |
| Inventories | 1,774 |  |  | 1,872 |  |
| Current assets held for sale | 1,595 |  |  | 1,552 |  |
| Other current assets | 1,153 |  |  | 991 |  |
| Current assets | 11,179 |  |  | 10,737 |  |
| Property, plant and equipment - net | 2,403 |  |  | 2,374 |  |
| Goodwill | 16,725 |  |  | 16,772 |  |
| Other intangible assets - net | 4,130 |  |  | 4,772 |  |
| Noncurrent assets held for sale | 3,210 |  |  | 3,105 |  |
| Other noncurrent assets | 5,048 |  |  | 4,482 |  |
| Total assets | $ | 42,695 |  |  | $ | 42,242 |  |
| Liabilities and Equity |  |  |  |
| Short-term debt | $ | 953 |  |  | $ | 361 |  |
| Current portion of long-term debt | 536 |  |  | 645 |  |
| Accounts payable | 3,389 |  |  | 3,498 |  |
| Accrued compensation and benefits | 1,048 |  |  | 847 |  |
| Deferred revenue | 2,160 |  |  | 1,923 |  |
| Current liabilities held for sale | 1,431 |  |  | 1,375 |  |
| Other current liabilities | 2,438 |  |  | 2,435 |  |
| Current liabilities | 11,955 |  |  | 11,084 |  |
| Long-term debt | 8,004 |  |  | 7,818 |  |
| Pension and postretirement benefits | 217 |  |  | 252 |  |
| Noncurrent liabilities held for sale | 405 |  |  | 407 |  |
| Other noncurrent liabilities | 4,753 |  |  | 4,987 |  |
| Long-term liabilities | 13,379 |  |  | 13,464 |  |
| Shareholders’ equity attributable to Johnson Controls | 16,098 |  |  | 16,545 |  |
| Noncontrolling interests | 1,263 |  |  | 1,149 |  |
| Total equity | 17,361 |  |  | 17,694 |  |
| Total liabilities and equity | $ | 42,695 |  |  | $ | 42,242 |  |

[0000833444-24-000060:8k_2_02:92]
9

[0000833444-24-000060:8k_2_02:93]
Johnson Controls International plc

[0000833444-24-000060:8k_2_02:94]
10

[0000833444-24-000060:8k_2_02:95]
Consolidated Statements of Cash Flows

[0000833444-24-000060:8k_2_02:96]
(in millions; unaudited)

[0000833444-24-000060:8k_2_02:97]
|  | Three Months Ended September 30, |  | Twelve Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Operating Activities of Continuing Operations |  |  |  |  |  |  |  |
| Income from continuing operations attributable to Johnson Controls | $ | 536 |  |  | $ | 481 |  |  | $ | 1,407 |  |  | $ | 1,562 |  |
| Income from continuing operations attributable to noncontrolling interests | 2 |  |  | 7 |  |  | 4 |  |  | 19 |  |
| Net income | 538 |  |  | 488 |  |  | 1,411 |  |  | 1,581 |  |
| Adjustments to reconcile net income to cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization | 192 |  |  | 202 |  |  | 816 |  |  | 745 |  |
| Pension and postretirement benefit expense (income) | (10) |  |  | 83 |  |  | (43) |  |  | 58 |  |
| Pension and postretirement contributions | 10 |  |  | (5) |  |  | (6) |  |  | (48) |  |
| Equity in earnings of partially-owned affiliates, net of dividends received | 23 |  |  | (2) |  |  | 44 |  |  | (3) |  |
| Deferred income taxes | — |  |  | (337) |  |  | (403) |  |  | (602) |  |
| Non-cash restructuring and impairment charges | 78 |  |  | 126 |  |  | 411 |  |  | 827 |  |
| Equity-based compensation expense | 26 |  |  | 18 |  |  | 107 |  |  | 107 |  |
| Other - net | 15 |  |  | (20) |  |  | (112) |  |  | (117) |  |
| Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |  |  |  |
| Accounts receivable | (46) |  |  | 240 |  |  | (537) |  |  | (259) |  |
| Inventories | 168 |  |  | 141 |  |  | (17) |  |  | (58) |  |
| Other assets | 78 |  |  | 31 |  |  | (482) |  |  | (187) |  |
| Restructuring reserves | 5 |  |  | 25 |  |  | (76) |  |  | 57 |  |
| Accounts payable and accrued liabilities | 466 |  |  | (17) |  |  | 645 |  |  | (85) |  |
| Accrued income taxes | (191) |  |  | 95 |  |  | (190) |  |  | (160) |  |
| Cash provided by operating activities from continuing operations | 1,352 |  |  | 1,068 |  |  | 1,568 |  |  | 1,856 |  |
| Investing Activities of Continuing Operations |  |  |  |  |  |  |  |
| Capital expenditures | (195) |  |  | (139) |  |  | (494) |  |  | (446) |  |
| Sale of property, plant and equipment | 1 |  |  | 3 |  |  | 1 |  |  | 30 |  |
| Acquisition of businesses, net of cash acquired | (4) |  |  | (466) |  |  | (3) |  |  | (726) |  |
| Business divestitures, net of cash divested | 326 |  |  | 28 |  |  | 345 |  |  | 28 |  |
| Other - net | (26) |  |  | (1) |  |  | (33) |  |  | 21 |  |
| Cash used by investing activities from continuing operations | 102 |  |  | (575) |  |  | (184) |  |  | (1,093) |  |
| Financing Activities of Continuing Operations |  |  |  |  |  |  |  |
| Net proceeds (payments) from borrowings with maturities less than three months | (655) |  |  | 195 |  |  | 48 |  |  | (75) |  |
| Proceeds from debt | — |  |  | 2 |  |  | 1,281 |  |  | 1,173 |  |
| Repayments of debt | (486) |  |  | (1,019) |  |  | (924) |  |  | (1,555) |  |
| Stock repurchases and retirements | (370) |  |  | (12) |  |  | (1,246) |  |  | (625) |  |
| Payment of cash dividends | (247) |  |  | (251) |  |  | (1,000) |  |  | (980) |  |
| Other - net | — |  |  | 20 |  |  | (107) |  |  | 3 |  |
| Cash used by financing activities from continuing operations | (1,758) |  |  | (1,065) |  |  | (1,948) |  |  | (2,059) |  |
| Discontinued Operations |  |  |  |  |  |  |  |
| Cash provided by operating activities | 174 |  |  | 322 |  |  | 530 |  |  | 365 |  |
| Cash used by investing activities | (13) |  |  | (33) |  |  | (37) |  |  | (91) |  |
| Cash provided (used) by financing activities | — |  |  | 2 |  |  | (132) |  |  | (115) |  |
| Cash provided by discontinued operations | 161 |  |  | 291 |  |  | 361 |  |  | 159 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 30 |  |  | 62 |  |  | 59 |  |  | (5) |  |
| Change in cash, cash equivalents and restricted cash held for sale | (8) |  |  | (4) |  |  | (6) |  |  | (5) |  |
| Decrease in cash, cash equivalents and restricted cash | (121) |  |  | (223) |  |  | (150) |  |  | (1,147) |  |
| Cash, cash equivalents and restricted cash at beginning of period | 888 |  |  | 1,140 |  |  | 917 |  |  | 2,064 |  |
| Cash, cash equivalents and restricted cash at end of period | 767 |  |  | 917 |  |  | 767 |  |  | 917 |  |
| Less: Restricted cash | 161 |  |  | 89 |  |  | 161 |  |  | 89 |  |
| Cash and cash equivalents at end of period | $ | 606 |  |  | $ | 828 |  |  | $ | 606 |  |  | $ | 828 |  |

[0000833444-24-000060:8k_2_02:98]
11

[0000833444-24-000060:8k_2_02:99]
FOOTNOTES

[0000833444-24-000060:8k_2_02:100]
1.Sale of Residential and Light Commercial HVAC Business

[0000833444-24-000060:8k_2_02:101]
The Company signed a definitive agreement in July 2024 to sell its Residential and Light Commercial HVAC business (the “R&LC Business”), which includes the North America Ducted businesses and the global Residential joint venture with Hitachi Global Life Solutions, Inc. (“Hitachi”), of which Johnson Controls owns 60% and Hitachi owns 40%. The R&LC Business, which was previously reported in the Global Products segment, meets the criteria to be classified as a discontinued operation and, as a result, its historical financial results are reflected in the consolidated financial statements as a discontinued operation, and assets and liabilities were retrospectively reclassified as held for sale for all periods presented. Unless otherwise noted, all activities and amounts reported in the following footnotes include both the continuing operations of the Company and activities and amounts related to the R&LC business.

[0000833444-24-000060:8k_2_02:102]
2.Non-GAAP Measures

[0000833444-24-000060:8k_2_02:103]
The Company reports various non-GAAP measures in this earnings release and the related earnings presentation.  Non-GAAP measures should be considered in addition to, and not as replacements for, the most comparable GAAP measures. Refer to footnotes three through eight for further information on the calculations of the non-GAAP measures and reconciliations of the non-GAAP measures to the most comparable GAAP measures.

[0000833444-24-000060:8k_2_02:104]
Organic sales

[0000833444-24-000060:8k_2_02:105]
Organic sales growth excludes the impact of acquisitions, divestitures and foreign currency. Management believes organic sales growth is useful to investors in understanding period-over-period sales results and trends.

[0000833444-24-000060:8k_2_02:106]
Cash flow

[0000833444-24-000060:8k_2_02:107]
Adjusted free cash flow and adjusted free cash flow conversion are non-GAAP measures which exclude the impacts of the following:

[0000833444-24-000060:8k_2_02:108]
•JC Capital cash flows primarily include activity associated with finance/notes receivables and inventory and/or capital expenditures related to lease arrangements. JC Capital net income is primarily related to interest income on the finance/notes receivable and profit recognized on arrangements with sales-type lease components.

[0000833444-24-000060:8k_2_02:109]
•Effective January 1, 2024, the Company has excluded the impact of discontinuing its accounts receivables factoring programs from adjusted free cash flow and adjusted free cash flow conversion. The Company has also re-baselined the prior year adjusted free cash flow measures to present a more comparative measure without the impact of factoring.

[0000833444-24-000060:8k_2_02:110]
•Cash payments related to the water systems AFFF settlement and cash receipts for AFFF-related insurance recoveries.

[0000833444-24-000060:8k_2_02:111]
Management believes free cash flow and adjusted free cash flow measures are useful to investors in understanding the strength of the Company and its ability to generate cash. These non-GAAP measures can also be used to evaluate the Company’s ability to generate cash flow from operations and the impact that this cash flow has on its liquidity. Management also believes adjusted free cash flows are useful to investors in understanding period-over-period cash flows, cash trends and ongoing cash flows of the Company.

[0000833444-24-000060:8k_2_02:112]
Adjusted financial measures

[0000833444-24-000060:8k_2_02:113]
Adjusted financial measures include adjusted segment EBITA, adjusted net income, adjusted earnings per share, adjusted EBIT, adjusted EBITDA and adjusted corporate expenses. These non-GAAP measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the excluded amounts is a matter of management judgment and depends upon the nature and variability of the underlying expense or income amounts and other factors.

[0000833444-24-000060:8k_2_02:114]
12

[0000833444-24-000060:8k_2_02:115]
As detailed in the tables included in footnotes four through seven, the following items were excluded from certain financial measures:

[0000833444-24-000060:8k_2_02:116]
•Net mark-to-market adjustments are the result of adjusting restricted asbestos investments and pension and postretirement plan assets to their current market value. These adjustments may have a favorable or unfavorable impact on results.

[0000833444-24-000060:8k_2_02:117]
•Restructuring and impairment costs, net of NCI represents restructuring costs attributable to Johnson Controls including costs associated with exit plans or other restructuring plans that will have a more significant impact on the underlying cost structure of the organization. Impairment costs primarily relate to write-downs of goodwill, intangible assets and assets held for sale to their fair value.

[0000833444-24-000060:8k_2_02:118]
•Water systems AFFF settlement and insurance recoveries include amounts related to a settlement with a nationwide class of public water systems concerning the use of AFFF manufactured and sold by a subsidiary of the Company, and AFFF-related insurance recoveries.

[0000833444-24-000060:8k_2_02:119]
•Transaction/separation costs include costs associated with significant mergers and acquisitions.

[0000833444-24-000060:8k_2_02:120]
•Earn-out adjustments relate to earn-out liabilities associated with certain significant acquisitions and may have a favorable or unfavorable impact on results.

[0000833444-24-000060:8k_2_02:121]
•Warehouse fire loss relates to an uninsured loss attributable to a fire at a warehouse in Menominee, Michigan.

[0000833444-24-000060:8k_2_02:122]
•Cyber incident costs primarily represent expenses, net of insurance recoveries, associated with the response to, and remediation of, a cybersecurity incident which occurred in September 2023.

[0000833444-24-000060:8k_2_02:123]
•Global products product quality issue are costs related to a product quality issue within the Global Products segment that is unusual due to the magnitude of the expected cost to remediate in comparison to typical product quality issues experienced by the Company.

[0000833444-24-000060:8k_2_02:124]
•Loss on divestiture relates to the sale of the ADTi business.

[0000833444-24-000060:8k_2_02:125]
•EMEA/LA joint venture loss relates to certain non-recurring losses associated with the equity method accounting of a joint venture company.

[0000833444-24-000060:8k_2_02:126]
•Discrete tax items, net includes the net impact of discrete tax items within the period, including the following types of items: changes in estimates associated with valuation allowances, changes in estimates associated with reserves for uncertain tax positions, withholding taxes recorded upon changes in indefinite re-investment assertions for businesses to be disposed of, impacts from statutory rate changes, and the recording of significant tax credits.

[0000833444-24-000060:8k_2_02:127]
•Related tax impact includes the tax impact of the various adjusting/excluded items.

[0000833444-24-000060:8k_2_02:128]
Management believes the exclusion of these items is useful to investors due to the unusual nature and/or magnitude of the amounts. When considered together with unadjusted amounts, adjusted financial measures are useful to investors in understanding period-over-period operating results, business trends and ongoing operations of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes.

[0000833444-24-000060:8k_2_02:129]
Debt ratios

[0000833444-24-000060:8k_2_02:130]
Management believes that net debt to adjusted EBITDA, a non-GAAP measure, is useful to understanding the Company's financial condition as the ratio provides an overview of the extent to which the Company relies on external debt financing for its funding and also is a measure of risk to its shareholders.

[0000833444-24-000060:8k_2_02:131]
13

[0000833444-24-000060:8k_2_02:132]
3. Sales

[0000833444-24-000060:8k_2_02:133]
The following tables include sales from both continuing and discontinued operations and detail the changes in sales attributable to organic growth, foreign currency, acquisitions, divestitures and other (unaudited):

[0000833444-24-000060:8k_2_02:134]
|  | Three Months Ended September 30 |
| Net sales | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Net sales - 2023 | $ | 2,778 |  |  | $ | 1,045 |  |  | $ | 697 |  |  | $ | 4,520 |  |  | $ | 2,386 |  |  | $ | 6,906 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | — |  |  | (7) |  |  | (7) |  |  | (135) |  |  | (142) |  |
| Foreign currency | (2) |  |  | (31) |  |  | 6 |  |  | (27) |  |  | (26) |  |  | (53) |  |
| Adjusted base net sales | 2,776 |  |  | 1,014 |  |  | 696 |  |  | 4,486 |  |  | 2,225 |  |  | 6,711 |  |
| Acquisitions | — |  |  | 2 |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Organic growth | 447 |  |  | 97 |  |  | (32) |  |  | 512 |  |  | 169 |  |  | 681 |  |
| Net sales - 2024 | $ | 3,223 |  |  | $ | 1,113 |  |  | $ | 664 |  |  | $ | 5,000 |  |  | $ | 2,394 |  |  | $ | 7,394 |  |
| Growth %: |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | 16 | % |  | 7 | % |  | (5 | %) |  | 11 | % |  | — | % |  | 7 | % |
| Organic growth | 16 | % |  | 10 | % |  | (5 | %) |  | 11 | % |  | 8 | % |  | 10 | % |

[0000833444-24-000060:8k_2_02:135]
|  | Twelve Months Ended September 30 |
| Net sales | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Net sales - 2023 | $ | 10,330 |  |  | $ | 4,096 |  |  | $ | 2,746 |  |  | $ | 17,172 |  |  | $ | 9,621 |  |  | $ | 26,793 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | (3) |  |  | (58) |  |  | (61) |  |  | (147) |  |  | (208) |  |
| Foreign currency | 13 |  |  | (39) |  |  | (62) |  |  | (88) |  |  | (170) |  |  | (258) |  |
| Adjusted base net sales | 10,343 |  |  | 4,054 |  |  | 2,626 |  |  | 17,023 |  |  | 9,304 |  |  | 26,327 |  |
| Acquisitions | 48 |  |  | 9 |  |  | 51 |  |  | 108 |  |  | 29 |  |  | 137 |  |
| Organic growth | 957 |  |  | 233 |  |  | (440) |  |  | 750 |  |  | 204 |  |  | 954 |  |
| Net sales - 2024 | $ | 11,348 |  |  | $ | 4,296 |  |  | $ | 2,237 |  |  | $ | 17,881 |  |  | $ | 9,537 |  |  | $ | 27,418 |  |
| Growth %: |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | 10 | % |  | 5 | % |  | (19 | %) |  | 4 | % |  | (1 | %) |  | 2 | % |
| Organic growth | 9 | % |  | 6 | % |  | (17 | %) |  | 4 | % |  | 2 | % |  | 4 | % |

[0000833444-24-000060:8k_2_02:136]
14

[0000833444-24-000060:8k_2_02:137]
|  | Three Months Ended September 30 |
| Products and systems revenue | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Products and systems revenue - 2023 | $ | 1,727 |  |  | $ | 570 |  |  | $ | 498 |  |  | $ | 2,795 |  |  | $ | 2,386 |  |  | $ | 5,181 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | (1) |  |  | — |  |  | (1) |  |  | (135) |  |  | (136) |  |
| Foreign currency | (1) |  |  | 2 |  |  | 3 |  |  | 4 |  |  | (26) |  |  | (22) |  |
| Adjusted products and systems revenue | 1,726 |  |  | 571 |  |  | 501 |  |  | 2,798 |  |  | 2,225 |  |  | 5,023 |  |
| Acquisitions | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Organic growth | 364 |  |  | 24 |  |  | (44) |  |  | 344 |  |  | 169 |  |  | 513 |  |
| Products and systems revenue - 2024 | $ | 2,090 |  |  | $ | 596 |  |  | $ | 457 |  |  | $ | 3,143 |  |  | $ | 2,394 |  |  | $ | 5,537 |  |
| Growth %: |  |  |  |  |  |  |  |  |  |  |  |
| Products and systems revenue | 21 | % |  | 5 | % |  | (8 | %) |  | 12 | % |  | — | % |  | 7 | % |
| Organic growth | 21 | % |  | 4 | % |  | (9 | %) |  | 12 | % |  | 8 | % |  | 10 | % |

[0000833444-24-000060:8k_2_02:138]
|  | Twelve Months Ended September 30 |
| Products and systems revenue | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Products and systems revenue - 2023 | $ | 6,368 |  |  | $ | 2,275 |  |  | $ | 1,987 |  |  | $ | 10,630 |  |  | $ | 9,621 |  |  | $20,251 |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | (2) |  |  | — |  |  | (2) |  |  | (147) |  |  | (149) |  |
| Foreign currency | 13 |  |  | 37 |  |  | (48) |  |  | 2 |  |  | (170) |  |  | (168) |  |
| Adjusted products and systems revenue | 6,381 |  |  | 2,310 |  |  | 1,939 |  |  | 10,630 |  |  | 9,304 |  |  | 19,934 |  |
| Acquisitions | 5 |  |  | 5 |  |  | 30 |  |  | 40 |  |  | 29 |  |  | 69 |  |
| Organic growth | 713 |  |  | (1) |  |  | (486) |  |  | 226 |  |  | 204 |  |  | 430 |  |
| Products and systems revenue - 2024 | $ | 7,099 |  |  | $ | 2,314 |  |  | $ | 1,483 |  |  | $ | 10,896 |  |  | $ | 9,537 |  |  | $ | 20,433 |  |
| Growth %: |  |  |  |  |  |  |  |  |  |  |  |
| Products and systems revenue | 11 | % |  | 2 | % |  | (25 | %) |  | 3 | % |  | (1 | %) |  | 1 | % |
| Organic growth | 11 | % |  | — | % |  | (25 | %) |  | 2 | % |  | 2 | % |  | 2 | % |

[0000833444-24-000060:8k_2_02:139]
15

[0000833444-24-000060:8k_2_02:140]
|  | Three Months Ended September 30 |
| Service revenue | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Service revenue - 2023 | $ | 1,051 |  |  | $ | 475 |  |  | $ | 199 |  |  | $ | 1,725 |  |  | $ | — |  |  | $ | 1,725 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | 1 |  |  | (7) |  |  | (6) |  |  | — |  |  | (6) |  |
| Foreign currency | (1) |  |  | (33) |  |  | 3 |  |  | (31) |  |  | — |  |  | (31) |  |
| Adjusted base service revenue | 1,050 |  |  | 443 |  |  | 195 |  |  | 1,688 |  |  | — |  |  | 1,688 |  |
| Acquisitions | — |  |  | 1 |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Organic growth | 83 |  |  | 73 |  |  | 12 |  |  | 168 |  |  | — |  |  | 168 |  |
| Service revenue - 2024 | $ | 1,133 |  |  | $ | 517 |  |  | $ | 207 |  |  | $ | 1,857 |  |  | $ | — |  |  | $ | 1,857 |  |
| Growth %: |  |  |  |  |  |  |  |  |  |  |  |
| Service revenue | 8 | % |  | 9 | % |  | 4 | % |  | 8 | % |  | — | % |  | 8 | % |
| Organic growth | 8 | % |  | 16 | % |  | 6 | % |  | 10 | % |  | — | % |  | 10 | % |

[0000833444-24-000060:8k_2_02:141]
|  | Twelve Months Ended September 30 |
| Service revenue | Building Solutions |  |  |  |  |
| (in millions) | North America |  | EMEA/LA |  | Asia Pacific |  | Total |  | Global Products |  | Total JCI plc |
| Service revenue - 2023 | $ | 3,962 |  |  | $ | 1,821 |  |  | $ | 759 |  |  | $ | 6,542 |  |  | $ | — |  |  | $ | 6,542 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | — |  |  | (1) |  |  | (58) |  |  | (59) |  |  | — |  |  | (59) |  |
| Foreign currency | — |  |  | (76) |  |  | (14) |  |  | (90) |  |  | — |  |  | (90) |  |
| Adjusted base service revenue | 3,962 |  |  | 1,744 |  |  | 687 |  |  | 6,393 |  |  | — |  |  | 6,393 |  |
| Acquisitions | 43 |  |  | 4 |  |  | 21 |  |  | 68 |  |  | — |  |  | 68 |  |
| Organic growth | 244 |  |  | 234 |  |  | 46 |  |  | 524 |  |  | — |  |  | 524 |  |
| Service revenue - 2024 | $ | 4,249 |  |  | $ | 1,982 |  |  | $ | 754 |  |  | $ | 6,985 |  |  | $ | — |  |  | $ | 6,985 |  |
| Growth %: |  |  |  |  |  |  |  |  |  |  |  |
| Service revenue | 7 | % |  | 9 | % |  | (1 | %) |  | 7 | % |  | — | % |  | 7 | % |
| Organic growth | 6 | % |  | 13 | % |  | 7 | % |  | 8 | % |  | — | % |  | 8 | % |

[0000833444-24-000060:8k_2_02:142]
16

[0000833444-24-000060:8k_2_02:143]
4.   Cash Flow, Free Cash Flow and Free Cash Flow Conversion

[0000833444-24-000060:8k_2_02:144]
The following table includes free cash flow and free cash flow conversion attributable to both continuing and discontinued operations (unaudited):

[0000833444-24-000060:8k_2_02:145]
|  | Three Months Ended September 30, |  | Twelve Months Ended September 30, |
| (in millions) | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cash provided by operating activities | $ | 1,526 |  | $ | 1,390 |  | $ | 2,098 |  | $ | 2,221 |  |
| Capital expenditures | (208) |  | (173) |  | (532) |  | (539) |  |
| Free cash flow (non-GAAP) | $ | 1,318 |  | $ | 1,217 |  | $ | 1,566 |  | $ | 1,682 |  |
| Net income attributable to JCI | $ | 633 |  | $ | 549 |  | $ | 1,705 |  | $ | 1,849 |  |
| Free cash flow conversion from net income (non-GAAP) | 208% |  | 222% |  | 92 | % |  | 91 | % |  |

[0000833444-24-000060:8k_2_02:146]
The following table includes adjusted free cash flow and adjusted free cash flow conversion attributable to both continuing and discontinued operations (unaudited):

[0000833444-24-000060:8k_2_02:147]
|  | Three Months Ended September 30, |  | Twelve Months EndedSeptember 30, |
| (in millions) | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Free cash flow (non-GAAP) | $ | 1,318 |  | $ | 1,217 |  | $ | 1,566 |  | $ | 1,682 |
| Adjustments: |  |  |  |  |  |  |  |
| JC Capital cash used by operating activities | 9 |  | 56 |  | 179 |  | 137 |
| Water systems AFFF settlement cash payments and insurance recoveries | (257) |  | — |  | (14) |  | — |
| Impact from discontinuation of factoring programs | 17 |  | — |  | 665 |  | — |
| Adjusted free cash flow (non-GAAP) | 1,087 |  | 1,273 |  | 2,396 |  | 1,819 |
| Prior year impact from factoring programs | — |  | (284) |  | — |  | (205) |
| Re-baselined adjusted free cash flow (non-GAAP) | $ | 1,087 |  | $ | 989 |  | $ | 2,396 |  | $ | 1,614 |
| Adjusted net income attributable to JCI (non-GAAP) | $ | 858 |  | $ | 719 |  | $ | 2,510 |  | $ | 2,405 |
| JC Capital net income | (8) |  | 1 |  | (16) |  | (11) |
| Adjusted net income attributable to JCI, excluding JC Capital (non-GAAP) | $ | 850 |  | $ | 720 |  | $ | 2,494 |  | $ | 2,394 |
| Adjusted free cash flow conversion (non-GAAP) | 128% |  | 137% |  | 96% |  | 67 | % |

[0000833444-24-000060:8k_2_02:148]
17

[0000833444-24-000060:8k_2_02:149]
5. EBITA, EBIT and Corporate Expense

[0000833444-24-000060:8k_2_02:150]
The Company evaluates the performance of its business units primarily on segment EBITA. The following table includes both continuing and discontinued operations (unaudited):

[0000833444-24-000060:8k_2_02:151]
|  | Three Months Ended September 30, |  | Twelve Months Ended September 30, |
|  | Actual |  | Adjusted(Non-GAAP) |  | Actual |  | Adjusted(Non-GAAP) |
| (in millions; unaudited) | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 484 |  |  | $ | 427 |  |  | $ | 484 |  |  | $ | 427 |  |  | 1,663 |  |  | $ | 1,394 |  |  | $ | 1,602 |  |  | $ | 1,394 |  |
| Building Solutions EMEA/LA | 111 |  |  | 82 |  | 128 |  |  | 82 |  |  | 391 |  |  | 316 |  |  | 408 |  |  | 316 |  |
| Building Solutions Asia Pacific | 94 |  |  | 94 |  | 94 |  |  | 94 |  |  | 261 |  |  | 343 |  |  | 261 |  |  | 343 |  |
| Global Products | 670 |  |  | 502 |  |  | 670 |  |  | 502 |  |  | 2,123 |  |  | 1,965 |  |  | 2,149 |  |  | 1,975 |  |
| EBIT (non-GAAP) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to JCI | $ | 633 |  |  | $ | 549 |  |  | $ | 858 |  |  | $ | 719 |  |  | $ | 1,705 |  |  | $ | 1,849 |  |  | $ | 2,510 |  |  | $ | 2,405 |  |
| Income attributable to noncontrolling interests (1) | 45 |  |  | 32 |  |  | 46 |  |  | 36 |  |  | 195 |  |  | 184 |  |  | 202 |  |  | 188 |  |
| Net income | 678 |  |  | 581 |  |  | 904 |  |  | 755 |  |  | 1,900 |  |  | 2,033 |  |  | 2,712 |  |  | 2,593 |  |
| Income tax provision (benefit)(2) | 153 |  |  | (57) |  |  | 143 |  |  | 118 |  |  | 252 |  |  | (323) |  |  | 432 |  |  | 405 |  |
| Income before income taxes | 831 |  |  | 524 |  |  | 1,047 |  |  | 873 |  |  | 2,152 |  |  | 1,710 |  |  | 3,144 |  |  | 2,998 |  |
| Net financing charges | 96 |  |  | 63 |  |  | 96 |  |  | 63 |  |  | 359 |  |  | 281 |  |  | 359 |  |  | 281 |  |
| EBIT (non-GAAP) | $ | 927 |  |  | $ | 587 |  |  | $ | 1,143 |  |  | $ | 936 |  |  | $ | 2,511 |  |  | $ | 1,991 |  |  | $ | 3,503 |  |  | $ | 3,279 |  |

[0000833444-24-000060:8k_2_02:152]
(1) Adjusted income attributable to noncontrolling interests excludes the impact of restructuring and impairment costs.

[0000833444-24-000060:8k_2_02:153]
(2) Adjusted income tax provision (benefit) excludes the net tax impacts of pre-tax adjusting items and discrete tax items.

[0000833444-24-000060:8k_2_02:154]
The following tables reconcile segment EBITA to adjusted segment EBITA (unaudited) attributable to both continuing and discontinued operations:

[0000833444-24-000060:8k_2_02:155]
|  | Three Months Ended September 30, |
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building SolutionsAsia Pacific |  | Global Products |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Segment EBITA | $ | 484 |  |  | $ | 427 |  |  | $ | 111 |  |  | $ | 82 |  |  | $ | 94 |  |  | $ | 94 |  |  | $ | 670 |  |  | $ | 502 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| EMEA/LA joint venture loss | — |  |  | — |  |  | 17 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Adjusted segment EBITA(non-GAAP) | $ | 484 |  |  | $ | 427 |  |  | $ | 128 |  |  | $ | 82 |  |  | $ | 94 |  |  | $ | 94 |  |  | $ | 670 |  |  | $ | 502 |  |

[0000833444-24-000060:8k_2_02:156]
18

[0000833444-24-000060:8k_2_02:157]
|  | Twelve Months Ended September 30, |
| (in millions) | Building SolutionsNorth America |  | Building SolutionsEMEA/LA |  | Building SolutionsAsia Pacific |  | Global Products |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Segment EBITA | $ | 1,663 |  |  | $ | 1,394 |  |  | $ | 391 |  |  | $ | 316 |  |  | $ | 261 |  |  | $ | 343 |  |  | $ | 2,123 |  |  | $ | 1,965 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Earn-out adjustments | (61) |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (7) |  |  | (30) |  |
| Uninsured warehouse fire loss | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 40 |  |
| Global Products product quality costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 33 |  |  | — |  |
| EMEA/LA joint venture loss | — |  |  | — |  |  | 17 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Adjusted segment EBITA(non-GAAP) | $ | 1,602 |  |  | $ | 1,394 |  |  | $ | 408 |  |  | $ | 316 |  |  | $ | 261 |  |  | $ | 343 |  |  | $ | 2,149 |  |  | $ | 1,975 |  |

[0000833444-24-000060:8k_2_02:158]
The following table reconciles Corporate expense from both continuing and discontinued operations as reported to the comparable adjusted amounts (unaudited):

[0000833444-24-000060:8k_2_02:159]
|  | Three Months Ended September 30, |  | Twelve Months Ended September 30, |
| (in millions) | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Corporate expense (GAAP) | $ | 158 |  |  | $ | 70 |  |  | $ | 531 |  |  | $ | 432 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction/separation costs | (44) |  |  | (21) |  |  | (72) |  |  | (122) |  |
| Cyber incident costs | — |  |  | — |  |  | (27) |  |  | — |  |
| Adjusted corporate expense (non-GAAP) | $ | 114 |  |  | $ | 49 |  |  | $ | 432 |  |  | $ | 310 |  |

[0000833444-24-000060:8k_2_02:160]
19

[0000833444-24-000060:8k_2_02:161]
6.  Net Income and Diluted Earnings Per Share

[0000833444-24-000060:8k_2_02:162]
The following tables reconcile net income attributable to JCI and diluted earnings per share as reported to the comparable adjusted amounts (unaudited):

[0000833444-24-000060:8k_2_02:163]
|  | Three Months Ended September 30, |
|  | Net income attributable to JCI |  | Diluted earnings per share |
| (in millions, except per share) | 2024 |  | 2023 |  | 2024 |  | 2023 |
| As reported (GAAP) | $ | 633 |  |  | $ | 549 |  |  | $ | 0.95 |  |  | $ | 0.80 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | (16) |  |  | 108 |  |  | (0.02) |  |  | 0.16 |  |
| Restructuring and impairment costs, net of NCI | 144 |  |  | 216 |  |  | 0.22 |  |  | 0.31 |  |
| AFFF insurance recoveries | (16) |  |  | — |  |  | (0.02) |  |  | — |  |
| Transaction/separation costs | 44 |  |  | 21 |  |  | 0.07 |  |  | 0.03 |  |
| Loss on divestiture | 42 |  |  | — |  |  | 0.06 |  |  | — |  |
| EMEA/LA joint venture loss | 17 |  |  | — |  |  | 0.03 |  |  | — |  |
| Tax impact of adjusting items, net | 10 |  |  | (54) |  |  | 0.01 |  |  | (0.08) |  |
| Discrete tax items, net | — |  |  | (121) |  |  | — |  |  | (0.18) |  |
| Adjusted (non-GAAP)* | $ | 858 |  |  | $ | 719 |  |  | $ | 1.28 |  |  | $ | 1.05 |  |

[0000833444-24-000060:8k_2_02:164]
* May not sum due to rounding

[0000833444-24-000060:8k_2_02:165]
|  | Twelve Months Ended September 30, |
|  | Net income attributable to JCI |  | Diluted earningsper share |
| (in millions, except per share) | 2024 |  | 2023 |  | 2024 |  | 2023 |
| As reported (GAAP) | $ | 1,705 |  |  | $ | 1,849 |  |  | $ | 2.52 |  |  | $ | 2.69 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | (58) |  |  | 92 |  |  | (0.09) |  |  | 0.13 |  |
| Restructuring and impairment costs, net of NCI | 537 |  |  | 1,060 |  |  | 0.79 |  |  | 1.54 |  |
| Water systems AFFF settlement | 750 |  |  | — |  |  | 1.11 |  |  | — |  |
| AFFF insurance recoveries | (367) |  |  | — |  |  | (0.54) |  |  | — |  |
| Transaction/separation costs | 72 |  |  | 122 |  |  | 0.11 |  |  | 0.18 |  |
| Earn-out adjustments | (68) |  |  | (30) |  |  | (0.10) |  |  | (0.04) |  |
| Warehouse fire loss | — |  |  | 40 |  |  | — |  |  | 0.06 |  |
| Cyber incident costs | 27 |  |  | — |  |  | 0.04 |  |  | — |  |
| Global Products product quality issue | 33 |  |  | — |  |  | 0.05 |  |  | — |  |
| Loss on divestiture | 42 |  |  | — |  |  | 0.06 |  |  | — |  |
| EMEA/LA joint venture loss | 17 |  |  | — |  |  | 0.03 |  |  | — |  |
| Tax impact of adjusting items, net | (123) |  |  | (169) |  |  | (0.18) |  |  | (0.25) |  |
| Discrete tax items,net | (57) |  |  | (559) |  |  | (0.08) |  |  | (0.81) |  |
| Adjusted (non-GAAP)* | $ | 2,510 |  |  | $ | 2,405 |  |  | $ | 3.71 |  |  | $ | 3.50 |  |

[0000833444-24-000060:8k_2_02:166]
* May not sum due to rounding

[0000833444-24-000060:8k_2_02:167]
20

[0000833444-24-000060:8k_2_02:168]
The following table reconciles the denominators used to calculate basic and diluted earnings per share (in millions; unaudited):

[0000833444-24-000060:8k_2_02:169]
|  | Three Months Ended September 30, |  | Twelve Months Ended September 30, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Weighted average shares outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 665.3 |  |  | 680.3 |  | 673.8 |  | 684.3 |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 2.8 |  |  | 3.0 |  |  | 2.2 |  |  | 3.1 |  |
| Diluted weighted average shares outstanding | 668.1 |  |  | 683.3 |  |  | 676.0 |  |  | 687.4 |  |

[0000833444-24-000060:8k_2_02:170]
7.  Debt Ratios

[0000833444-24-000060:8k_2_02:171]
The following table includes both continuing and discontinued operations and details net debt to income before income taxes and net debt to adjusted EBITDA (unaudited):

[0000833444-24-000060:8k_2_02:172]
| (in millions) | September 30, 2024 |  | June 30, 2024 |  | September 30, 2023 |  |  |
| Short-term debt | $ | 953 |  |  | $ | 1,523 |  |  | $ | 385 |  |  |  |
| Current portion of long-term debt | 536 |  |  | 998 |  |  | 645 |  |  |  |
| Long-term debt | 8,004 |  |  | 7,867 |  |  | 7,818 |  |  |  |
| Total debt | 9,493 |  |  | 10,388 |  |  | 8,848 |  |  |  |
| Less: cash and cash equivalents | 611 |  |  | 862 |  |  | 835 |  |  |  |
| Net debt | $ | 8,882 |  |  | $ | 9,526 |  |  | $ | 8,013 |  |  |  |
| Last twelve months income before income taxes | $ | 2,152 |  |  | $ | 1,845 |  |  | $ | 1,710 |  |  |  |
| Net debt to income before income taxes | 4.1 | x |  | 5.2 | x |  | 4.7 | x |  |  |
| Last twelve months adjusted EBITDA (non-GAAP) | $ | 4,382 |  |  | $ | 4,210 |  |  | $ | 4,127 |  |  |  |
| Net debt to adjusted EBITDA (non-GAAP) | 2.0x |  | 2.3x |  | 1.9x |  |  |

[0000833444-24-000060:8k_2_02:173]
21

[0000833444-24-000060:8k_2_02:174]
The following table reconciles net income to adjusted EBIT and adjusted EBITDA (unaudited):

[0000833444-24-000060:8k_2_02:175]
|  | Twelve Months Ended |  |  |
| (in millions) | September 30, 2024 |  | June 30, 2024 |  | September 30, 2023 |  |  |
| Net income | $ | 1,900 |  |  | $ | 1,803 |  |  | $ | 2,033 |  |  |  |
| Income tax provision (benefit) | 252 |  |  | 42 |  |  | (323) |  |  |  |
| Net financing charges | 359 |  |  | 326 |  |  | 281 |  |  |  |
| EBIT | 2,511 |  |  | 2,171 |  |  | 1,991 |  |  |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | (58) |  |  | 66 |  |  | 92 |  |  |  |
| Restructuring and impairment costs | 544 |  |  | 619 |  |  | 1,064 |  |  |  |
| Water systems AFFF settlement | 750 |  |  | 750 |  |  | — |  |  |  |
| AFFF insurance recoveries | (367) |  |  | (351) |  |  | — |  |  |  |
| Transaction/separation costs | 72 |  |  | 49 |  |  | 122 |  |  |  |
| Earn-out adjustments | (68) |  |  | (68) |  |  | (30) |  |  |  |
| Warehouse fire loss | — |  |  | — |  |  | 40 |  |  |  |
| Cyber incident costs | 27 |  |  | 27 |  |  | — |  |  |  |
| Global Products product quality issue | 33 |  |  | 33 |  |  | — |  |  |  |
| Loss on divestiture | 42 |  |  | — |  |  | — |  |  |  |
| EMEA/LA joint venture loss | 17 |  |  | — |  |  | — |  |  |  |
| Adjusted EBIT (non-GAAP) | 3,503 |  |  | 3,296 |  |  | 3,279 |  |  |  |
| Depreciation and amortization | 879 |  |  | 914 |  |  | 848 |  |  |  |
| Adjusted EBITDA (non-GAAP) | $ | 4,382 |  |  | $ | 4,210 |  |  | $ | 4,127 |  |  |  |

[0000833444-24-000060:8k_2_02:176]
8.  Income Taxes

[0000833444-24-000060:8k_2_02:177]
The Company's effective tax rate before consideration of certain excluded items was approximately 13.75% for the three and twelve months ending September 30, 2024 and approximately 13.5% for the three and twelve months ending September 30, 2023.

[0000833444-24-000060:8k_2_02:178]
22

[0000833444-24-000060:8k_2_02:179]
9.  Statements of Income

[0000833444-24-000060:8k_2_02:180]
The following tables include statements of income for both continuing and discontinued operations.

[0000833444-24-000060:8k_2_02:181]
|  | Three Months Ended September 30, 2024 |  | Three Months Ended September 30, 2023 |
|  | Continuing Operations |  | Discontinued Operations |  | Combined |  | Continuing Operations |  | Discontinued Operations |  | Combined |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |
| Products and systems | $ | 4,391 |  |  | $ | 1,146 |  |  | $ | 5,537 |  |  | $ | 4,128 |  |  | $ | 1,053 |  |  | $ | 5,181 |  |
| Services | 1,857 |  |  | — |  |  | 1,857 |  |  | 1,725 |  |  | — |  |  | 1,725 |  |
|  | 6,248 |  |  | 1,146 |  |  | 7,394 |  |  | 5,853 |  |  | 1,053 |  |  | 6,906 |  |
| Cost of sales |  |  |  |  |  |  |  |  |  |  |  |
| Products and systems | 2,872 |  |  | 832 |  |  | 3,704 |  |  | 2,877 |  |  | 817 |  |  | 3,694 |  |
| Services | 1,108 |  |  | — |  |  | 1,108 |  |  | 1,004 |  |  | — |  |  | 1,004 |  |
|  | 3,980 |  |  | 832 |  |  | 4,812 |  |  | 3,881 |  |  | 817 |  |  | 4,698 |  |
| Gross profit | 2,268 |  |  | 314 |  |  | 2,582 |  |  | 1,972 |  |  | 236 |  |  | 2,208 |  |
| Selling, general and administrative expenses | 1,368 |  |  | 200 |  |  | 1,568 |  |  | 1,309 |  |  | 167 |  |  | 1,476 |  |
| Restructuring and impairment costs | 133 |  |  | 12 |  |  | 145 |  |  | 212 |  |  | 8 |  |  | 220 |  |
| Net financing charges | 96 |  |  | — |  |  | 96 |  |  | 56 |  |  | 7 |  |  | 63 |  |
| Equity income (loss) | (23) |  |  | 81 |  |  | 58 |  |  | 1 |  |  | 74 |  |  | 75 |  |
| Income before income taxes | 648 |  |  | 183 |  |  | 831 |  |  | 396 |  |  | 128 |  |  | 524 |  |
| Income tax provision (benefit) | 110 |  |  | 43 |  |  | 153 |  |  | (92) |  |  | 35 |  |  | (57) |  |
| Net income | 538 |  |  | 140 |  |  | 678 |  |  | 488 |  |  | 93 |  |  | 581 |  |
| Income attributable to noncontrolling interests | 2 |  |  | 43 |  |  | 45 |  |  | 7 |  |  | 25 |  |  | 32 |  |
| Net income attributable to Johnson Controls | $ | 536 |  |  | $ | 97 |  |  | $ | 633 |  |  | $ | 481 |  |  | $ | 68 |  |  | $ | 549 |  |
| Earnings per share attributable to Johnson Controls |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.80 |  |  | $ | 0.15 |  |  | $ | 0.95 |  |  | $ | 0.71 |  |  | $ | 0.10 |  |  | 0.81 |  |
| Diluted | 0.80 |  |  | 0.15 |  |  | 0.95 |  |  | 0.70 |  |  | 0.10 |  |  | 0.80 |  |

[0000833444-24-000060:8k_2_02:182]
23

[0000833444-24-000060:8k_2_02:183]
|  | Twelve Months Ended September 30, 2024 |  | Twelve Months Ended September 30, 2023 |
|  | Continuing Operations |  | Discontinued Operations |  | Combined |  | Continuing Operations |  | Discontinued Operations |  | Combined |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |
| Products and systems | $ | 15,967 |  |  | $ | 4,466 |  |  | $ | 20,433 |  |  | $ | 15,789 |  |  | $ | 4,462 |  |  | $ | 20,251 |  |
| Services | 6,985 |  |  | — |  |  | 6,985 |  |  | 6,542 |  |  | — |  |  | 6,542 |  |
|  | 22,952 |  |  | 4,466 |  |  | 27,418 |  |  | 22,331 |  |  | 4,462 |  |  | 26,793 |  |
| Cost of sales |  |  |  |  |  |  |  |  |  |  |  |
| Products and systems | 10,677 |  |  | 3,300 |  |  | 13,977 |  |  | 10,736 |  |  | 3,295 |  |  | 14,031 |  |
| Services | 4,198 |  |  | — |  |  | 4,198 |  |  | 3,791 |  |  | — |  |  | 3,791 |  |
|  | 14,875 |  |  | 3,300 |  |  | 18,175 |  |  | 14,527 |  |  | 3,295 |  |  | 17,822 |  |
| Gross profit | 8,077 |  |  | 1,166 |  |  | 9,243 |  |  | 7,804 |  |  | 1,167 |  |  | 8,971 |  |
| Selling, general and administrative expenses | 5,661 |  |  | 761 |  |  | 6,422 |  |  | 5,387 |  |  | 794 |  |  | 6,181 |  |
| Restructuring and impairment costs | 510 |  |  | 34 |  |  | 544 |  |  | 1,049 |  |  | 15 |  |  | 1,064 |  |
| Net financing charges | 342 |  |  | 17 |  |  | 359 |  |  | 258 |  |  | 23 |  |  | 281 |  |
| Equity income (loss) | (42) |  |  | 276 |  |  | 234 |  |  | 3 |  |  | 262 |  |  | 265 |  |
| Income before income taxes | 1,522 |  |  | 630 |  |  | 2,152 |  |  | 1,113 |  |  | 597 |  |  | 1,710 |  |
| Income tax provision (benefit) | 111 |  |  | 141 |  |  | 252 |  |  | (468) |  |  | 145 |  |  | (323) |  |
| Net income | 1,411 |  |  | 489 |  |  | 1,900 |  |  | 1,581 |  |  | 452 |  |  | 2,033 |  |
| Income attributable to noncontrolling interests | 4 |  |  | 191 |  |  | 195 |  |  | 19 |  |  | 165 |  |  | 184 |  |
| Net income attributable to Johnson Controls | $ | 1,407 |  |  | $ | 298 |  |  | $ | 1,705 |  |  | $ | 1,562 |  |  | $ | 287 |  |  | $ | 1,849 |  |
| Earnings per share attributable to Johnson Controls |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 2.09 |  |  | $ | 0.44 |  |  | $ | 2.53 |  |  | $ | 2.28 |  |  | $ | 0.42 |  |  | $ | 2.70 |  |
| Diluted | 2.08 |  |  | 0.44 |  |  | 2.52 |  |  | 2.27 |  |  | 0.42 |  |  | 2.69 |  |

[0000833444-24-000060:8k_2_02:184]
24

[0000833444-24-000060:8k_2_02:185]
10.  Quarterly Results - Continuing Operations

[0000833444-24-000060:8k_2_02:186]
The following tables include reconciliations of EBIT to adjusted EBIT, diluted EPS to adjusted diluted EPS, and Global Products segment EBITA to Global Products adjusted segment EBITA for continuing operations only.

[0000833444-24-000060:8k_2_02:187]
|  | Fiscal 2024 |
| (in millions, except per share) | Q1 |  | Q2 |  | Q3 |  | Q4 |  | Year |
| Net sales | $ | 5,209 |  |  | $ | 5,597 |  |  | $ | 5,898 |  |  | $ | 6,248 |  |  | $ | 22,952 |  |
| Net income attributable to JCI | $ | 340 |  |  | $ | (321) |  |  | $ | 852 |  |  | $ | 536 |  |  | $ | 1,407 |  |
| Income attributable to NCI | — |  |  | 3 |  |  | (1) |  |  | 2 |  |  | 4 |  |
| Net income (loss) | 340 |  |  | (318) |  |  | 851 |  |  | 538 |  |  | 1,411 |  |
| Income tax provision (benefit) | (20) |  |  | (153) |  |  | 174 |  |  | 110 |  |  | 111 |  |
| Income (loss) before income taxes | 320 |  |  | (471) |  |  | 1,025 |  |  | 648 |  |  | 1,522 |  |
| Net financing charges | 87 |  |  | 89 |  |  | 70 |  |  | 96 |  |  | 342 |  |
| EBIT (Non-GAAP) | 407 |  |  | (382) |  |  | 1,095 |  |  | 744 |  |  | 1,864 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | (22) |  |  | (15) |  |  | (5) |  |  | (6) |  |  | (48) |  |
| Restructuring and impairment costs, net of NCI | 35 |  |  | 239 |  |  | 102 |  |  | 133 |  |  | 509 |  |
| Water systems AFFF settlement | — |  |  | 750 |  |  | — |  |  | — |  |  | 750 |  |
| AFFF insurance recoveries | — |  |  | — |  |  | (351) |  |  | (16) |  |  | (367) |  |
| Transaction/separation costs | — |  |  | 5 |  |  | 10 |  |  | 17 |  |  | 32 |  |
| Earn-out adjustments | — |  |  | (7) |  |  | (61) |  |  | — |  |  | (68) |  |
| Uninsured warehouse fire loss | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Cyber incident costs | 23 |  |  | 4 |  |  | — |  |  | — |  |  | 27 |  |
| Global Products product quality issue | — |  |  | 33 |  |  | — |  |  | — |  |  | 33 |  |
| Loss on divestiture | — |  |  | — |  |  | — |  |  | 42 |  |  | 42 |  |
| EMEA/LA joint venture loss | — |  |  | — |  |  | — |  |  | 17 |  |  | 17 |  |
| Adjusted EBIT (Non-GAAP) | $ | 443 |  |  | $ | 627 |  |  | $ | 790 |  |  | $ | 931 |  |  | $ | 2,791 |  |
| Diluted EPS | $ | 0.50 |  |  | $ | (0.47) |  |  | $ | 1.25 |  |  | $ | 0.80 |  |  | $ | 2.08 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | (0.03) |  |  | (0.02) |  |  | (0.01) |  |  | (0.01) |  |  | (0.07) |  |
| Restructuring and impairment costs, net of NCI | 0.05 |  |  | 0.35 |  |  | 0.15 |  |  | 0.20 |  |  | 0.75 |  |
| Water systems AFFF settlement | — |  |  | 1.10 |  |  | — |  |  | — |  |  | 1.11 |  |
| AFFF insurance recoveries | — |  |  | — |  |  | (0.52) |  |  | (0.02) |  |  | (0.54) |  |
| Transaction/separation costs | — |  |  | 0.01 |  |  | 0.01 |  |  | 0.03 |  |  | 0.05 |  |
| Earn-out adjustments | — |  |  | (0.01) |  |  | (0.09) |  |  | — |  |  | (0.10) |  |
| Cyber incident costs | 0.03 |  |  | 0.01 |  |  | — |  |  | — |  |  | 0.04 |  |
| Global Products product quality issue | — |  |  | 0.05 |  |  | — |  |  | — |  |  | 0.05 |  |
| Loss on divestiture | — |  |  | — |  |  | — |  |  | 0.06 |  |  | 0.06 |  |
| EMEA/LA joint venture loss | — |  |  | — |  |  | — |  |  | 0.03 |  |  | 0.03 |  |
| Tax impact of adjusting items | (0.01) |  |  | (0.32) |  |  | 0.14 |  |  | 0.03 |  |  | (0.16) |  |
| Discrete tax items | (0.08) |  |  | — |  |  | — |  |  | — |  |  | (0.08) |  |
| Adjusted diluted EPS (Non-GAAP)* | $ | 0.46 |  |  | $ | 0.69 |  |  | $ | 0.95 |  |  | $ | 1.11 |  |  | $ | 3.21 |  |
| Weighted shares outstanding | 682.4 |  |  | 679.0 |  |  | 672.8 |  |  | 668.1 |  |  | 676.0 |  |

[0000833444-24-000060:8k_2_02:188]
* May not sum due to rounding

[0000833444-24-000060:8k_2_02:189]
25

[0000833444-24-000060:8k_2_02:190]
|  | Fiscal 2023 |
| (in millions, except per share) | Q1 |  | Q2 |  | Q3 |  | Q4 |  | Year |
| Net sales | $ | 5,155 |  |  | $ | 5,546 |  |  | $ | 5,777 |  |  | $ | 5,853 |  |  | $ | 22,331 |  |
| Net income attributable to JCI | $ | 97 |  |  | $ | 44 |  |  | $ | 940 |  |  | $ | 481 |  |  | $ | 1,562 |  |
| Income attributable to NCI | 4 |  |  | 1 |  |  | 7 |  |  | 7 |  |  | 19 |  |
| Net income | 101 |  |  | 45 |  |  | 947 |  |  | 488 |  |  | 1,581 |  |
| Income tax provision (benefit) | (3) |  |  | 8 |  |  | (381) |  |  | (92) |  |  | (468) |  |
| Income before income taxes | 98 |  |  | 53 |  |  | 566 |  |  | 396 |  |  | 1,113 |  |
| Net financing charges | 62 |  |  | 66 |  |  | 74 |  |  | 56 |  |  | 258 |  |
| EBIT (Non-GAAP) | 160 |  |  | 119 |  |  | 640 |  |  | 452 |  |  | 1,371 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | (3) |  |  | 4 |  |  | (17) |  |  | 111 |  |  | 95 |  |
| Restructuring and impairment costs, net of NCI | 343 |  |  | 415 |  |  | 79 |  |  | 212 |  |  | 1,049 |  |
| Transaction/separation costs | 26 |  |  | 29 |  |  | 43 |  |  | 20 |  |  | 118 |  |
| Earn-out adjustments |  |  | (30) |  |  | — |  |  | — |  |  | (30) |  |
| Uninsured warehouse fire loss | 40 |  |  | — |  |  | — |  |  | — |  |  | 40 |  |
| Adjusted EBIT (Non-GAAP) | $ | 566 |  |  | $ | 537 |  |  | $ | 745 |  |  | $ | 795 |  |  | $ | 2,643 |  |
| Diluted EPS | $ | 0.14 |  |  | $ | 0.07 |  |  | $ | 1.36 |  |  | $ | 0.70 |  |  | $ | 2.27 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | — |  |  | 0.01 |  |  | (0.02) |  |  | 0.16 |  |  | 0.14 |  |
| Restructuring and impairment costs, net of NCI | 0.50 |  |  | 0.60 |  |  | 0.12 |  |  | 0.31 |  |  | 1.53 |  |
| Transaction/separation costs | 0.04 |  |  | 0.04 |  |  | 0.06 |  |  | 0.03 |  |  | 0.17 |  |
| Earn-out adjustments | — |  |  | (0.04) |  |  | — |  |  | — |  |  | (0.04) |  |
| Uninsured warehouse fire loss | 0.06 |  |  | — |  |  | — |  |  | — |  |  | 0.06 |  |
| Tax impact of adjusting items | (0.09) |  |  | (0.06) |  |  | (0.02) |  |  | (0.08) |  |  | (0.24) |  |
| Discrete tax items | — |  |  | — |  |  | (0.64) |  |  | (0.18) |  |  | (0.81) |  |
| Adjusted diluted EPS (Non-GAAP)* | $ | 0.63 |  |  | $ | 0.62 |  |  | $ | 0.87 |  |  | $ | 0.95 |  |  | $ | 3.07 |  |
| Weighted shares outstanding | 690.3 |  |  | 689.7 |  |  | 686.2 |  |  | 683.3 |  |  | 687.4 |  |

[0000833444-24-000060:8k_2_02:191]
* May not sum due to rounding

[0000833444-24-000060:8k_2_02:192]
|  | Global Products |
| (in millions) | Fiscal 2024 |  | Fiscal 2023 |
|  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | Year |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | Year |
| Segment EBITA | $ | 267 |  |  | $ | 290 |  |  | $ | 387 |  |  | $ | 459 |  |  | $ | 1,403 |  |  | $ | 299 |  |  | $ | 305 |  |  | $ | 355 |  |  | $ | 358 |  |  | $ | 1,317 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Earn-out adjustments | — |  |  | (7) |  |  | — |  |  | — |  |  | (7) |  |  | — |  |  | (30) |  |  | — |  |  | — |  |  | (30) |  |
| Uninsured warehouse fire loss | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 40 |  |  | — |  |  | — |  |  | — |  |  | 40 |  |
| Global Products product quality costs | — |  |  | 33 |  |  | — |  |  | — |  |  | 33 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Adjusted segment EBITA(non-GAAP) | $ | 267 |  |  | $ | 316 |  |  | $ | 387 |  |  | $ | 459 |  |  | $ | 1,429 |  |  | $ | 339 |  |  | $ | 275 |  |  | $ | 355 |  |  | $ | 358 |  |  | $ | 1,327 |  |

[0000833444-24-000060:8k_2_02:193]
26
