# JCI MD&A — 0000833444-20-000048


## mdna

[0000833444-20-000048:mdna:1]
ITEM 7    MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000833444-20-000048:mdna:2]
General

[0000833444-20-000048:mdna:3]
The Company engineers, manufactures and commissions building products and systems, including residential and commercial HVAC equipment, industrial refrigeration systems, controls, security systems, fire detection systems and fire suppression solutions. The Company further serves customers by providing technical services, including maintenance, repair, retrofit and replacement of equipment (in the HVAC, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions powered by its digital platforms and capabilities.

[0000833444-20-000048:mdna:4]
This discussion summarizes the significant factors affecting the consolidated operating results, financial condition and liquidity of the Company for the fiscal year ended September 30, 2020. This discussion should be read in conjunction with Item 8, the consolidated financial statements and the notes to consolidated financial statements. A detailed discussion of the 2019 to 2018 year-over-year changes are not included herein and can be found in the Management's Discussion and Analysis section in the Company's 2019 Annual Report on Form 10-K filed November 21, 2019.

[0000833444-20-000048:mdna:5]
Impact of COVID-19 pandemic

[0000833444-20-000048:mdna:6]
The global outbreak of COVID-19 has severely restricted the level of economic activity around the world and has caused a significant contraction in the global economy. In response to this outbreak, the governments of many countries, states, cities and other geographic regions have taken preventative or protective actions, such as imposing restrictions on travel and business operations.

[0000833444-20-000048:mdna:7]
The Company’s affiliates, employees, suppliers, customers and others have been and may continue to be restricted or prevented from conducting normal business activities, including as a result of shutdowns, travel restrictions and other actions that may be requested or mandated by governmental authorities. Such actions have and may in the future prevent the Company from accessing the facilities of its customers to deliver and install products, provide services and complete maintenance. In addition, some of the Company’s customers have chosen to delay or abandon projects on which the Company provides products and/or services as a result of such actions. Although some governments have lifted shutdown orders and similar restrictions, a resurgence in the spread of COVID-19 could cause the reinstitution of such preventive or protective measures. While a substantial portion of the Company's businesses have been classified as an essential business in jurisdictions in which facility closures have been mandated, some of its facilities have nevertheless been ordered to close, and we can give no assurance that there will not be additional closures in the future or that our businesses will be classified as essential in each of the jurisdictions in which we operate.

[0000833444-20-000048:mdna:8]
In response to the challenges presented by COVID-19, the Company has focused its efforts on preserving the health and safety of its employees and customers, as well as maintaining the continuity of its operations. The Company has modified its business practices in response to the COVID-19 outbreak, including restricting non-essential employee travel, implementation of remote work protocols, and cancellation of physical participation in meetings, events and conferences. The Company has also instituted preventive measures at its facilities, including enhanced health and safety protocols, temperature screening, requiring face coverings for all employees and encouraging employees to follow similar protocols when away from work. The Company has adopted a multifaceted framework to guide its decision making when evaluating the readiness of its facilities to safely reopen and operate, and will continue to monitor and audit its facilities to ensure that they are in compliance with the Company’s COVID-19 safety requirements.

[0000833444-20-000048:mdna:9]
In the second quarter of fiscal 2020, the Company experienced a temporary reduction of its manufacturing and operating capacity in China as a result of government-mandated actions to control the spread of COVID-19. In the third quarter of fiscal 2020, the Company experienced similar reductions as a result of government-mandated actions in India and Mexico. During the fourth quarter of fiscal 2020, the Company’s facilities were generally able to operate at normal levels, though its manufacturing capacity in India continues to be reduced as a result of continued lockdowns in the region. The Company has experienced, and may continue to experience, disruptions or delays in its supply chain as a result of government-mandated actions, which has resulted in higher supply chain costs to the Company in order to maintain the supply of materials and components for its products.

[0000833444-20-000048:mdna:10]
In order to mitigate disruptions to its supply chain and manufacturing capacity, the Company took actions including redistributing its manufacturing capacity to facilities and regions unaffected by shutdown orders, accelerating the purchase and shipment of components from suppliers in identified hot spots, diversifying the Company’s supplier base, conducting government outreach to support the Company’s and its suppliers’ designations as essential businesses, and expanded its existing supplier financing programs to support supplier viability and business continuity. While these actions have generally been successful in preserving the Company’s supply chain and manufacturing capacity, the potential resurgence of COVID-19 in various jurisdictions could lead to further disruptions.

[0000833444-20-000048:mdna:11]
The Company experienced a decline in demand and volumes in its global businesses as a result of the impact of efforts to contain the spread of COVID-19. Specifically, the Company experienced lower demand due to restricted access to customer sites to perform service and installation work as well as reduced discretionary capital spending by the Company's customers. In response, the Company quickly moved to execute temporary and permanent cost mitigation actions to offset a portion of the impact of COVID-19 on the demand for its products and services, such as deferring or reducing capital expenditures, implementing cost structure changes, short-term furloughing of salaried employees and limiting discretionary spending including corporate expense. These measures were in addition to the Company's previously disclosed fiscal 2020 restructuring plan. Although the Company intends that the temporary cost mitigation actions initiated in fiscal 2020 will cease in fiscal 2021, the necessity of future cost mitigation actions will depend on the continued impact of COVID-19, which is highly uncertain.

[0000833444-20-000048:mdna:12]
The global pandemic has also provided the Company with the opportunity to help its customers prepare to re-open by delivering solutions and support that enhance the safety and increase the efficiency of their operations. The Company has seen an increase in demand for its products and solutions that promote building health and optimize customers’ infrastructure, including thermal cameras, indoor air quality, location-based services for contact tracing and touchless access control.

[0000833444-20-000048:mdna:13]
During the second quarter of fiscal 2020, the Company determined that it had a triggering event requiring assessment of impairment for certain of its indefinite-lived intangible assets due to declines in revenue directly attributable to the COVID-19 pandemic. As a result, the Company recorded an impairment charge of $62 million related primarily to the Company's retail business indefinite-lived intangible assets within restructuring and impairment costs in the consolidated statements of income in the second quarter of fiscal 2020. During the third quarter of fiscal 2020, the Company determined that it had a triggering event requiring assessment of impairment for certain of its indefinite-lived intangible assets, long-lived assets and goodwill due to declines in revenue and further declines in forecasted cash flows in its North America Retail reporting unit directly attributable to the COVID-19 pandemic. As a result, the Company recorded an impairment charge of $424 million related to the Company's North America Retail reporting unit's goodwill within restructuring and impairment costs in the consolidated statements of income in the third quarter of fiscal 2020. There were no indefinite-lived intangibles or goodwill impairments resulting from the fiscal 2020 annual impairment tests performed in the fourth quarter of fiscal 2020. However, it is possible that future changes in such circumstances, including a more prolonged and/or severe COVID-19 pandemic, would require the Company to record additional non-cash impairment charges.

[0000833444-20-000048:mdna:14]
The Company continues to actively monitor its liquidity position and working capital needs. The Company believes that, following its implementation of liquidity and cost mitigation actions in fiscal 2020, it remains in a solid overall capital resources and liquidity position that is adequate to meet its projected needs. As a result, following a review of its liquidity position, the Company resumed its share repurchase program in July 2020, which had been suspended in March 2020. In September 2020, the Company issued $1.8 billion of senior notes. A portion of the proceeds, together with cash from operations, were used to repay short-term debt obligations incurred by the Company at the onset of the pandemic to preserve its near-term financial flexibility, as well as repay or redeem other near term-indebtedness.

[0000833444-20-000048:mdna:15]
The extent to which the COVID-19 outbreak continues to impact the Company’s results of operations and financial condition will depend on future developments that are highly uncertain and cannot be predicted, including new information that may emerge concerning the severity and longevity of COVID-19, the resurgence of COVID-19 in regions that have begun to recover from the initial impact of the pandemic, the impact of COVID-19 on economic activity, and the actions to contain its impact on

[0000833444-20-000048:mdna:16]
public health and the global economy. See Part I, Item 1A, Risk Factors, for an additional discussion of risks related to COVID-19.

[0000833444-20-000048:mdna:17]
FISCAL YEAR 2020 COMPARED TO FISCAL YEAR 2019

[0000833444-20-000048:mdna:18]
Net Sales

[0000833444-20-000048:mdna:19]
|  | Year Ended September 30, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |
| Net sales | $ | 22,317 |  |  | $ | 23,968 |  |  | -7 | % |

[0000833444-20-000048:mdna:20]
The decrease in net sales was due to lower organic sales ($1,543 million), the unfavorable impact of foreign currency translation ($150 million) and lower sales due to business divestitures ($11 million), partially offset by acquisitions ($53 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales decreased 6% as compared to the prior year due to lower demand, primarily attributable to the COVID-19 pandemic. Refer to the "Segment Analysis" below within Item 7 for a discussion of net sales by segment.

[0000833444-20-000048:mdna:21]
Cost of Sales / Gross Profit

[0000833444-20-000048:mdna:22]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |
| Cost of sales | $ | 14,906 |  |  | $ | 16,275 |  |  | -8 | % |
| Gross profit | 7,411 |  |  | 7,693 |  |  | -4 | % |
| % of sales | 33.2 | % |  | 32.1 | % |  |  |

[0000833444-20-000048:mdna:23]
Cost of sales and gross profit both decreased and gross profit as a percentage of sales increased by 110 basis points. Gross profit decreased due to organic sales declines primarily due to the unfavorable impact of the COVID-19 pandemic, partially offset by cost mitigation actions. Net mark-to-market adjustments had a net favorable year-over-year impact on cost of sales of $40 million ($88 million loss in fiscal 2020 compared to a $128 million loss in fiscal 2019) primarily due to a more significant reduction in discount rates in the prior year. Foreign currency translation had a favorable impact on cost of sales of approximately $100 million. Refer to the "Segment Analysis" below within Item 7 for a discussion of segment earnings before interest, taxes and amortization ("EBITA") by segment.

[0000833444-20-000048:mdna:24]
Selling, General and Administrative Expenses

[0000833444-20-000048:mdna:25]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |
| Selling, general and administrative expenses | $ | 5,665 |  |  | $ | 6,244 |  |  | -9 | % |
| % of sales | 25.4 | % |  | 26.1 | % |  |  |

[0000833444-20-000048:mdna:26]
Selling, general and administrative expenses ("SG&A") decreased by $579 million, and SG&A as a percentage of sales decreased by 70 basis points. The decrease in SG&A included the favorable impact of cost mitigation actions and reductions in discretionary spend in the current year. The net mark-to-market adjustments had a net favorable year-over-year impact on SG&A of $304 million ($186 million loss in fiscal 2020 compared to a $490 million loss in fiscal 2019) primarily due to a more significant reduction in discount rates in the prior year. Additional favorable impacts included a prior year environmental charge ($140 million) and foreign currency translation ($30 million). These items were partially offset by a prior year tax indemnification reserve release ($226 million). Refer to the "Segment Analysis" below within Item 7 for a discussion of segment EBITA by segment.

[0000833444-20-000048:mdna:27]
Restructuring and Impairment Costs

[0000833444-20-000048:mdna:28]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |
| Restructuring and impairment costs | $ | 783 |  |  | $ | 235 |  |  | * |

[0000833444-20-000048:mdna:29]
* Measure not meaningful

[0000833444-20-000048:mdna:30]
Refer to Note 7, "Goodwill and Other Intangible Assets," Note 16, "Significant Restructuring and Impairment Costs," and Note 17, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for further disclosure related to the Company's restructuring plans and impairment costs.

[0000833444-20-000048:mdna:31]
Net Financing Charges

[0000833444-20-000048:mdna:32]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |
| Net financing charges | $ | 231 |  |  | $ | 350 |  |  | -34 | % |

[0000833444-20-000048:mdna:33]
Refer to Note 9, "Debt and Financing Arrangements," of the notes to consolidated financial statements for further disclosure related to the Company's net financing charges.

[0000833444-20-000048:mdna:34]
Equity Income

[0000833444-20-000048:mdna:35]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |
| Equity income | $ | 171 |  |  | $ | 192 |  |  | -11 | % |

[0000833444-20-000048:mdna:36]
The decrease in equity income was primarily due to lower income at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture primarily due to the unfavorable impact of the COVID-19 pandemic. Foreign currency translation had an unfavorable impact on equity income of $3 million. Refer to the "Segment Analysis" below within Item 7 for a discussion of  segment EBITA by segment.

[0000833444-20-000048:mdna:37]
Income Tax Provision

[0000833444-20-000048:mdna:38]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |
| Income tax provision (benefit) | $ | 108 |  |  | $ | (233) |  |  | * |
| Effective tax rate | 12 | % |  | -22 | % |  |  |

[0000833444-20-000048:mdna:39]
* Measure not meaningful

[0000833444-20-000048:mdna:40]
The statutory tax rate in Ireland of 12.5% is being used as a comparison since the Company is domiciled in Ireland.

[0000833444-20-000048:mdna:41]
For fiscal 2020, the effective tax rate for continuing operations was 12% and was lower than the statutory tax rate primarily due to tax audit reserve adjustments, the income tax effects of mark-to-market adjustments, valuation allowance adjustments and the benefits of continuing global tax planning initiatives, partially offset by a discrete tax charge related to the remeasurement of deferred tax assets and liabilities as a result of Swiss tax reform, the tax impact of an impairment charge and tax rate differentials.

[0000833444-20-000048:mdna:42]
For fiscal 2019, the effective rate for continuing operations was below the statutory rate primarily due to tax audit reserve adjustments, the income tax effects of mark-to-market adjustments, a tax indemnification reserve release, the tax benefits of an asset held for sale impairment charge and continuing global tax planning initiatives, partially offset by valuation allowance adjustments as a result of tax law changes, a discrete tax charge related to newly enacted regulations related to U.S. Tax Reform and tax rate differentials.

[0000833444-20-000048:mdna:43]
31

[0000833444-20-000048:mdna:44]
The fiscal 2020 effective tax rate increased as compared to fiscal 2019 primarily due to the discrete tax items. The fiscal year 2020 and 2019 global tax planning initiatives related primarily to changes in entity tax status, global financing structures and alignment of the Company's global business functions in a tax efficient manner. Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements for further details.

[0000833444-20-000048:mdna:45]
Income From Discontinued Operations, Net of Tax

[0000833444-20-000048:mdna:46]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |
| Income from discontinued operations, net of tax | $ | — |  |  | $ | 4,598 |  |  | * |

[0000833444-20-000048:mdna:47]
* Measure not meaningful

[0000833444-20-000048:mdna:48]
Refer to Note 3, "Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-20-000048:mdna:49]
Income Attributable to Noncontrolling Interests

[0000833444-20-000048:mdna:50]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 164 |  |  | $ | 189 |  |  | -13 | % |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  | 24 |  |  | * |

[0000833444-20-000048:mdna:51]
* Measure not meaningful

[0000833444-20-000048:mdna:52]
The decrease in income from continuing operations attributable to noncontrolling interests was primarily due to lower net income primarily due to the COVID-19 pandemic at certain partially-owned affiliates within the Global Products segment.

[0000833444-20-000048:mdna:53]
Refer to Note 3, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

[0000833444-20-000048:mdna:54]
Net Income Attributable to Johnson Controls

[0000833444-20-000048:mdna:55]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |
| Net income attributable to Johnson Controls | $ | 631 |  |  | $ | 5,674 |  |  | -89 | % |

[0000833444-20-000048:mdna:56]
The decrease in net income attributable to Johnson Controls was primarily due to the prior year income from discontinued operations, higher restructuring and impairment charges, higher income tax provision and the unfavorable impact of the COVID-19 pandemic, partially offset by lower SG&A and net financing charges. Fiscal 2020 diluted earnings per share attributable to Johnson Controls was $0.84 compared to $6.49 in fiscal 2019.

[0000833444-20-000048:mdna:57]
Comprehensive Income Attributable to Johnson Controls

[0000833444-20-000048:mdna:58]
|  | Year EndedSeptember 30, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |
| Comprehensive income attributable to Johnson Controls | $ | 650 |  |  | $ | 5,350 |  |  | -88 | % |

[0000833444-20-000048:mdna:59]
The decrease in comprehensive income attributable to Johnson Controls was due to lower net income attributable to Johnson Controls ($5,043 million), partially offset by an increase in other comprehensive income attributable to Johnson Controls ($343 million) resulting primarily from foreign currency translation adjustments. The favorable foreign currency translation adjustments were primarily driven by weakening of the British pound and euro currencies against the U.S. dollar in the prior year.

[0000833444-20-000048:mdna:60]
SEGMENT ANALYSIS

[0000833444-20-000048:mdna:61]
Management evaluates the performance of its business units based primarily on segment EBITA, which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and net mark-to-market adjustments related to pension and postretirement plans and restricted asbestos investments.

[0000833444-20-000048:mdna:62]
|  | Net Salesfor the Year EndedSeptember 30, |  |  |  | Segment EBITAfor the Year EndedSeptember 30, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Building Solutions North America | $ | 8,605 |  |  | $ | 9,031 |  |  | -5 | % |  | $ | 1,157 |  |  | $ | 1,153 |  |  | — | % |
| Building Solutions EMEA/LA | 3,440 |  |  | 3,655 |  |  | -6 | % |  | 338 |  |  | 368 |  |  | -8 | % |
| Building Solutions Asia Pacific | 2,403 |  |  | 2,658 |  |  | -10 | % |  | 319 |  |  | 341 |  |  | -6 | % |
| Global Products | 7,869 |  |  | 8,624 |  |  | -9 | % |  | 1,134 |  |  | 1,179 |  |  | -4 | % |
|  | $ | 22,317 |  |  | $ | 23,968 |  |  | -7 | % |  | $ | 2,948 |  |  | $ | 3,041 |  |  | -3 | % |

[0000833444-20-000048:mdna:63]
Net Sales:

[0000833444-20-000048:mdna:64]
•The decrease in Building Solutions North America was due to lower volumes ($414 million) and the unfavorable impact of foreign currency translation ($12 million). The decrease in volumes was primarily attributable to the unfavorable impact of the COVID-19 pandemic.

[0000833444-20-000048:mdna:65]
•The decrease in Building Solutions EMEA/LA was primarily attributable to lower volumes ($151 million), the unfavorable impact of foreign currency translation ($96 million) and business divestitures ($6 million), partially offset by incremental sales related to business acquisitions ($38 million). The decrease in volumes was primarily attributable to the unfavorable impact of the COVID-19 pandemic.

[0000833444-20-000048:mdna:66]
•The decrease in Building Solutions Asia Pacific was due to lower volumes ($232 million) and the unfavorable impact of foreign currency translation ($31 million), partially offset by incremental sales related to a business acquisition ($8 million). The decrease in volumes was primarily attributable to the unfavorable impact of the COVID-19 pandemic.

[0000833444-20-000048:mdna:67]
•The decrease in Global Products was due to lower volumes ($746 million), the unfavorable impact of foreign currency translation ($11 million) and lower volumes related to business divestitures ($5 million), partially offset by incremental sales related to business acquisitions ($7 million). The decrease in volumes was primarily attributable to the unfavorable impact of the COVID-19 pandemic.

[0000833444-20-000048:mdna:68]
Segment EBITA:

[0000833444-20-000048:mdna:69]
•The increase in Building Solutions North America was due to prior year integration costs ($26 million), partially offset by current year integration costs ($11 million), unfavorable volumes, net of productivity savings and cost mitigation actions ($10 million), and the unfavorable impact of foreign currency translation ($1 million).

[0000833444-20-000048:mdna:70]
•The decrease in Building Solutions EMEA/LA was due to the unfavorable impact of foreign currency translation ($17 million), unfavorable volumes, net of productivity savings and cost mitigation actions ($14 million), lower equity income ($7 million), current year integration costs ($2 million) and lower income due to business divestitures ($1 million), partially offset by higher income due to business acquisitions ($7 million) and prior year integration costs ($4 million).

[0000833444-20-000048:mdna:71]
•The decrease in Building Solutions Asia Pacific was due to unfavorable volumes, net of productivity savings and cost mitigation actions ($18 million), and current year integration costs ($7 million), partially offset by prior year integration costs ($2 million) and higher income due to business acquisitions ($1 million).

[0000833444-20-000048:mdna:72]
•The decrease in Global Products was due to unfavorable volumes, net of favorable price/cost, productivity savings and cost mitigation actions ($143 million), a compensation charge related to a noncontrolling interest acquisition ($39 million), current year integration costs ($13 million), lower equity income driven primarily by the unfavorable impact

[0000833444-20-000048:mdna:73]
33

[0000833444-20-000048:mdna:74]
of COVID-19 ($12 million), the unfavorable impact of foreign currency translation ($5 million), lower income due to business acquisitions ($2 million) and lower income due to business divestitures ($1 million), partially offset by a prior year environmental charge ($140 million) and prior year integration costs ($30 million).

[0000833444-20-000048:mdna:75]
LIQUIDITY AND CAPITAL RESOURCES

[0000833444-20-000048:mdna:76]
Working Capital

[0000833444-20-000048:mdna:77]
|  | September 30,2020 |  | September 30,2019 |  |  |
| (in millions) |  |  | Change |
| Current assets | $ | 10,053 |  |  | $ | 12,393 |  |  |  |
| Current liabilities | (8,248) |  |  | (9,070) |  |  |  |
|  | 1,805 |  |  | 3,323 |  |  | -46 | % |
| Less: Cash | (1,951) |  |  | (2,805) |  |  |  |
| Add: Short-term debt | 31 |  |  | 10 |  |  |  |
| Add: Current portion of long-term debt | 262 |  |  | 501 |  |  |  |
| Less: Assets held for sale | — |  |  | (98) |  |  |  |
| Add: Liabilities held for sale | — |  |  | 44 |  |  |  |
| Working capital (as defined) | $ | 147 |  |  | $ | 975 |  |  | -85 | % |
| Accounts receivable | $ | 5,294 |  |  | $ | 5,770 |  |  | -8 | % |
| Inventories | 1,773 |  |  | 1,814 |  |  | -2 | % |
| Accounts payable | 3,120 |  |  | 3,582 |  |  | -13 | % |

[0000833444-20-000048:mdna:78]
•The Company defines working capital as current assets less current liabilities, excluding cash, short-term debt, the current portion of long-term debt, and the current portions of assets and liabilities held for sale. Management believes that this measure of working capital, which excludes financing-related items and businesses to be divested, provides a more useful measurement of the Company’s operating performance.

[0000833444-20-000048:mdna:79]
•The decrease in working capital at September 30, 2020 as compared to September 30, 2019, was primarily due to lower income tax assets, a decrease in accounts receivable, and the establishment of an operating lease liability on the balance sheet in the first quarter of fiscal 2020 as a result of the adoption of Accounting Standards Codification ("ASC") 842, partially offset by a decrease in accounts payable due to lower spending and a decrease in accrued compensation and benefits liabilities.

[0000833444-20-000048:mdna:80]
•The Company’s days sales in accounts receivable at September 30, 2020 were 63, a decrease from 67 at September 30, 2019. There has been no significant adverse change in the level of overdue receivables or significant changes in revenue recognition methods.

[0000833444-20-000048:mdna:81]
•The Company’s inventory turns for the year ended September 30, 2020 were higher than the comparable period ended September 30, 2019 primarily due to changes in inventory production levels.

[0000833444-20-000048:mdna:82]
•Days in accounts payable at September 30, 2020 were 69 days, a decrease from 72 days for the comparable period ended September 30, 2019.

[0000833444-20-000048:mdna:83]
Cash Flows From Continuing Operations

[0000833444-20-000048:mdna:84]
|  | Year Ended September 30, |
| (in millions) | 2020 |  | 2019 |
| Cash provided by operating activities | $ | 2,479 |  |  | $ | 1,743 |  |
| Cash used by investing activities | (258) |  |  | (533) |  |
| Cash used by financing activities | (2,824) |  |  | (10,519) |  |

[0000833444-20-000048:mdna:85]
•The increase in cash provided by operating activities was primarily due to the timing of income tax payments/refunds and favorable changes in accounts receivable, partially offset by unfavorable changes in accounts payable and accrued liabilities.

[0000833444-20-000048:mdna:86]
•The decrease in cash used by investing activities was primarily due to lower capital expenditures and higher cash proceeds from business divestitures and the sale of property, plant & equipment.

[0000833444-20-000048:mdna:87]
•The decrease in cash used by financing activities was primarily due to lower stock repurchases, higher long-term debt borrowings, net of repayments, and lower short-term debt repayments.

[0000833444-20-000048:mdna:88]
Capitalization

[0000833444-20-000048:mdna:89]
|  | September 30,2020 |  | September 30,2019 |  |  |
| (in millions) |  |  | Change |
| Short-term debt | $ | 31 |  |  | $ | 10 |  |  |  |
| Current portion of long-term debt | 262 |  |  | 501 |  |  |  |
| Long-term debt | 7,526 |  |  | 6,708 |  |  |  |
| Total debt | $ | 7,819 |  |  | $ | 7,219 |  |  | 8 | % |
| Less: cash and cash equivalents | 1,951 |  |  | 2,805 |  |  |  |
| Total net debt | $ | 5,868 |  |  | $ | 4,414 |  |  | 33 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 17,447 |  |  | 19,766 |  |  | -12 | % |
| Total capitalization | $ | 23,315 |  |  | $ | 24,180 |  |  | -4 | % |
| Total net debt as a % of total capitalization | 25.2 | % |  | 18.3 | % |  |  |

[0000833444-20-000048:mdna:90]
•Net debt and net debt as a percentage of total capitalization are non-GAAP financial measures. The Company believes the percentage of total net debt to total capitalization is useful to understanding the Company’s financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders.

[0000833444-20-000048:mdna:91]
•The Company believes its capital resources and liquidity position at September 30, 2020 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, stock repurchases, minimum pension contributions, debt maturities and any potential acquisitions in fiscal 2021 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company is unable to issue commercial paper, it would have the ability to draw on its $2.5 billion revolving credit facility which expires in December 2024 or its $0.5 billion revolving credit facility which expires in December 2020. There were no draws on the revolving credit facilities as of September 30, 2020 and 2019. The Company also selectively makes use of short-term credit lines other than its revolving credit facility. The Company, as of September 30, 2020, could borrow up to $3.0 billion based on committed credit lines. In addition, the Company held cash and cash equivalents of $2.0 billion as of September 30, 2020. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future.

[0000833444-20-000048:mdna:92]
•In September 2020, the Company issued $1.8 billion of senior notes, which includes $625 million of green bonds with an interest rate of 1.750% which are due in 2030, €500 million with an interest rate of 0.375% which are due in 2027 and €500 million with an interest rate of 1.000% which are due in 2032.  Portions of the issuance proceeds were used to repay €750 million of notes which were due in December 2020 and debt which was issued in April 2020, including $675 million of European financing arrangements which were due in September 2020 and $275 million of bank term loans which were due in April 2021.  In July 2020, the Company repaid $300 million of a bank term loan that was issued in April 2020. In March 2020, the Company retired $500 million in principal amount, plus accrued interest, of its 5.0% fixed rate notes that expired in March 2020.

[0000833444-20-000048:mdna:93]
•Financial covenants in the Company's revolving credit facilities requires a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated

[0000833444-20-000048:mdna:94]
shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of ASC 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of September 30, 2020, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures, governing its notes, and expect to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-20-000048:mdna:95]
•The Company earns a significant amount of its income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances. However, in fiscal 2019, the Company provided income tax expense related to a change in the Company's assertion over the outside basis differences of the Company’s investment in certain subsidiaries as a result of the planned divestiture of the Power Solutions business. Also, in fiscal 2018, due to U.S. Tax Reform, the Company provided income tax related to the change in the Company’s assertion over the outside basis difference of certain non-U.S. subsidiaries owned directly or indirectly by U.S. subsidiaries. Under U.S. Tax Reform, the U.S. has enacted a tax system that provides an exemption for dividends received by U.S. corporations from 10% or more owned non-U.S. corporations. However, certain non-U.S., U.S. state and withholding taxes may still apply when closing an outside basis difference via distribution or other transactions. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. Except as noted, the Company’s intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at the Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings.

[0000833444-20-000048:mdna:96]
•To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company has committed to various restructuring plans. Restructuring plans generally result in charges for workforce reductions, plant closures and asset impairments which are reported as restructuring and impairment costs in the Company’s consolidated statements of income. The Company expects the restructuring actions to reduce cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense.

[0000833444-20-000048:mdna:97]
–In fiscal 2020, the Company recorded $297 million of costs resulting from the 2020 restructuring plan. The Company currently estimates that upon completion of the restructuring action, the fiscal 2020 restructuring plans will reduce annual operating costs for continuing operations by approximately $430 million. The Company expects the annual benefit of these actions will be substantially realized in 2021. For fiscal 2020, the savings, net of execution costs, were approximately 30% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in fiscal 2021. The Company has outstanding restructuring reserves of $108 million at September 30, 2020, all of which is expected to be paid in cash.

[0000833444-20-000048:mdna:98]
–In fiscal 2018, the Company recorded $255 million of costs resulting from the 2018 restructuring plan.  The Company currently estimates that upon completion of the restructuring action, the fiscal 2018 restructuring plan will reduce annual operating costs for continuing operations by approximately $300 million. The annual restructuring activities are substantially completed, and final payments are expected to be made in fiscal 2021. The Company has outstanding restructuring reserves of $30 million at September 30, 2020, all of which is expected to be paid in cash.

[0000833444-20-000048:mdna:99]
–In fiscal 2017, the Company recorded $347 million of costs resulting from the 2017 restructuring plan. The Company currently estimates that upon completion of the restructuring action, the fiscal 2017 restructuring plan will reduce annual operating costs for continuing operations by approximately $260 million. The annual restructuring activities are substantially completed, and final payments are expected to be made in fiscal 2021. The Company has outstanding restructuring reserves of $6 million at September 30, 2020, all of which is expected to be paid in cash.

[0000833444-20-000048:mdna:100]
36

[0000833444-20-000048:mdna:101]
•Refer to Note 9, "Debt and Financing Arrangements," of the notes to consolidated financial statements for additional information on items impacting capitalization.

[0000833444-20-000048:mdna:102]
Co-Issued Securities: Summarized Financial Information

[0000833444-20-000048:mdna:103]
The following information is provided in compliance with Rule 13-01 of Regulation S-X under the Securities Exchange Act of 1934 with respect to the (i) $625 million aggregate principal amount of 1.750% Senior Notes due 2030 (the “2030 Notes”), (ii) €500 million aggregate principal amount of 0.375% Senior Notes due 2027 (the “2027 Notes”) and (iii) €500 million aggregate principal amount of 1.000% Senior Notes due 2032 (the “2032 Notes” and together with the 2030 Notes and the 2027 Notes, the “Notes”), each issued by Johnson Controls International plc ("Parent Company") and Tyco Fire & Security Finance S.C.A. (“TFSCA”), a corporate partnership limited by shares (société en commandite par actions) incorporated and organized under the laws of the Grand Duchy of Luxembourg (“Luxembourg”). Refer to Note 9, "Debt and Financing Arrangements," of the notes to consolidated financial statements for additional information.

[0000833444-20-000048:mdna:104]
TFSCA is a wholly-owned consolidated subsidiary of the Company that is 99.996% owned directly by the Parent Company and 0.004% owned by TFSCA’s sole general partner and manager, Tyco Fire & Security S.à r.l., which is itself wholly-owned by the Company. The Notes are the Parent Company’s and TFSCA’s unsecured, unsubordinated obligations. The Parent Company is incorporated and organized under the laws of Ireland and TFSCA is incorporated and organized under the laws of Luxembourg. The bankruptcy, insolvency, administrative, debtor relief and other laws of Luxembourg or Ireland, as applicable, may be materially different from, or in conflict with, those of the United States, including in the areas of rights of creditors, priority of governmental and other creditors, ability to obtain post-petition interest and duration of the proceeding. The application of these laws, or any conflict among them, could adversely affect noteholders’ ability to enforce their rights under the Notes in those jurisdictions or limit any amounts that they may receive.

[0000833444-20-000048:mdna:105]
The following tables set forth summarized financial information of the Parent Company and TFSCA (collectively, the “Obligor Group”) on a combined basis after intercompany transactions have been eliminated, including adjustments to remove the receivable and payable balances, investment in, and equity in earnings from, those subsidiaries of the Parent Company other than TFSCA (collectively, the "Non-Obligor Subsidiaries").

[0000833444-20-000048:mdna:106]
The following table presents summarized income statement information for the year ended September 30, 2020 (in millions):

[0000833444-20-000048:mdna:107]
|  |  | Year Ended |  |
|  |  | September 30, 2020 |  |
| Net sales |  | $ | — |  |  |
| Gross profit |  | — |  |  |
| Loss from continuing operations |  | (450) |  |  |
| Net loss |  | (450) |  |  |
| Income attributable to noncontrolling interests |  | — |  |  |
| Net loss attributable to the entity |  | (450) |  |  |

[0000833444-20-000048:mdna:108]
Excluded from the table above are the intercompany transactions between the Obligor Group and Non-Obligor Subsidiaries as follows (in millions):

[0000833444-20-000048:mdna:109]
|  |  | Year Ended |  |
|  |  | September 30, 2020 |  |
| Net sales |  | $ | — |  |  |
| Gross profit |  | — |  |  |
| Income from continuing operations |  | 702 |  |  |
| Net income |  | 702 |  |  |
| Income attributable to noncontrolling interests |  | — |  |  |
| Net income attributable to the entity |  | 702 |  |  |

[0000833444-20-000048:mdna:110]
The following table presents summarized balance sheet information as of September 30, 2020 (in millions):

[0000833444-20-000048:mdna:111]
|  |  | September 30, 2020 |  |
| Current assets |  | $ | 522 |  |  |
| Noncurrent assets |  | 318 |  |  |
| Current liabilities |  | 7,612 |  |  |
| Noncurrent liabilities |  | 7,258 |  |  |
| Noncontrolling interests |  | — |  |  |

[0000833444-20-000048:mdna:112]
Excluded from the table above are the intercompany balances between the Obligor Group and Non-Obligor Subsidiaries as follows (in millions):

[0000833444-20-000048:mdna:113]
|  |  | September 30, 2020 |  |
| Current assets |  | $ | 838 |  |  |
| Noncurrent assets |  | 7,338 |  |  |
| Current liabilities |  | 2,724 |  |  |
| Noncurrent liabilities |  | 3,406 |  |  |
| Noncontrolling interests |  | — |  |  |

[0000833444-20-000048:mdna:114]
The same accounting policies as described in Note 1, "Summary of Significant Accounting Policies," of the notes to  consolidated financial statements are used by the Parent Company and each of its subsidiaries in connection with the summarized financial information presented above.

[0000833444-20-000048:mdna:115]
Contractual Obligations

[0000833444-20-000048:mdna:116]
A summary of the Company’s significant contractual obligations for continuing operations as of September 30, 2020 is as follows (in millions):

[0000833444-20-000048:mdna:117]
|  | Total |  | 2021 |  | 2022 - 2023 |  | 2024 - 2025 |  | 2026 and Beyond |
| Contractual Obligations |  |  |  |  |  |  |  |  |  |
| Long-term debt* | $ | 7,822 |  |  | $ | 262 |  |  | $ | 1,505 |  |  | $ | 1,051 |  |  | $ | 5,004 |  |
| Interest on long-term debt* | 3,814 |  |  | 213 |  |  | 412 |  |  | 364 |  |  | 2,825 |  |
| Operating leases** | 1,291 |  |  | 352 |  |  | 470 |  |  | 234 |  |  | 235 |  |
| Purchase obligations | 1,087 |  |  | 911 |  |  | 102 |  |  | 63 |  |  | 11 |  |
| Pension and postretirement contributions | 388 |  |  | 49 |  |  | 67 |  |  | 70 |  |  | 202 |  |
| Total contractual cash obligations | $ | 14,402 |  |  | $ | 1,787 |  |  | $ | 2,556 |  |  | $ | 1,782 |  |  | $ | 8,277 |  |

[0000833444-20-000048:mdna:118]
* Refer to Note 9, "Debt and Financing Arrangements," of the notes to consolidated financial statements for information related to the Company's long-term debt.

[0000833444-20-000048:mdna:119]
** Refer to Note 8, "Leases," of the notes to consolidated financial statements for information related to the Company's leases.

[0000833444-20-000048:mdna:120]
CRITICAL ACCOUNTING ESTIMATES AND POLICIES

[0000833444-20-000048:mdna:121]
The Company prepares its consolidated financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). This requires management to make estimates and assumptions that affect reported amounts and related disclosures. Actual results could differ from those estimates. The following policies are considered by management to be the most critical in understanding the judgments that are involved in the preparation of the Company’s consolidated financial statements and the uncertainties that could impact the Company’s results of operations, financial position and cash flows.

[0000833444-20-000048:mdna:122]
Revenue Recognition

[0000833444-20-000048:mdna:123]
The Company recognizes revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. The Company does not adjust the promised amount of consideration for the effects of a significant financing component as at contract inception the Company expects to receive the payment within twelve months of transfer of goods or services.

[0000833444-20-000048:mdna:124]
The Company enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized over time on a straight-line basis over the respective contract term.

[0000833444-20-000048:mdna:125]
The Company also sells certain HVAC and refrigeration products and services in bundled arrangements with multiple performance obligations, such as equipment, commissioning, service labor and extended warranties. Approximately four to twelve months separate the timing of the first deliverable until the last piece of equipment is delivered, and there may be extended warranty arrangements with duration of one to five years commencing upon the end of the standard warranty period. In addition, the Company sells security monitoring systems that may have multiple performance obligations, including equipment, installation, monitoring services and maintenance agreements. Revenues associated with the sale of equipment and related installations are recognized over time on a cost-to-cost input method, while the revenue for monitoring and maintenance services are recognized over time as services are rendered. The transaction price is allocated to each performance obligation based on the relative selling price method. In order to estimate relative selling price, market data and transfer price studies are utilized. If the standalone selling price is not directly observable, the Company estimates the standalone selling price using an adjusted market assessment approach or expected cost plus margin approach. For transactions in which the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized over time on a straight-line basis over the contract term. Non-refundable fees received in connection with the initiation of a monitoring contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the contract.

[0000833444-20-000048:mdna:126]
In all other cases, the Company recognizes revenue at the point in time when control over the goods or services transfers to the customer.

[0000833444-20-000048:mdna:127]
The Company considers the contractual consideration payable by the customer and assesses variable consideration that may affect the total transaction price, including discounts, rebates, refunds, credits or other similar sources of variable consideration, when determining the transaction price of each contract. The Company includes variable consideration in the estimated transaction price when it is probable that significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. These estimates are based on the amount of consideration that the Company expects to be entitled to.

[0000833444-20-000048:mdna:128]
Shipping and handling costs billed to customers are included in sales and the related costs are included in cost of sales when control transfers to the customer. The Company presents amounts collected from customers for sales and other taxes net of the related amounts remitted. Refer to Note 4, "Revenue Recognition," of the notes to consolidated financial statements for disclosure of the Company's revenue recognition activity.

[0000833444-20-000048:mdna:129]
Goodwill and Indefinite-Lived Intangible Assets

[0000833444-20-000048:mdna:130]
Goodwill reflects the cost of an acquisition in excess of the fair values assigned to identifiable net assets acquired. The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s reportable segments or one level below the reportable segments in certain instances, using a fair value method based on management’s judgments and assumptions or third party valuations. The fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. In estimating the fair value, the Company uses multiples of earnings based on the average of published multiples of earnings of comparable entities with similar operations and economic characteristics and applies to the Company's average of historical and future financial results. In certain instances, the Company uses discounted cash flow analyses or estimated sales price to further support the fair value estimates. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The estimated fair value is then compared with the carrying amount of the reporting unit, including recorded goodwill. The Company is subject to financial statement risk to the extent that the carrying amount exceeds the estimated fair value. The assumptions included in the impairment tests require judgment, and changes to these inputs could impact the results of the calculations. The primary assumptions used in the impairment tests were management's projections of future cash flows. Although the Company's cash flow forecasts are based on assumptions that are considered reasonable by management and consistent with the plans and estimates management is using to operate the underlying businesses, there are significant judgments in determining the expected future cash flows attributable to a reporting unit. Refer to Note 7, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for information regarding the goodwill impairment testing performed in fiscal years 2020, 2019 and 2018.

[0000833444-20-000048:mdna:131]
Indefinite-lived intangible assets are also subject to at least annual impairment testing. Indefinite-lived intangible assets primarily consist of trademarks and trade names and are tested for impairment using a relief-from-royalty method. A considerable amount of management judgment and assumptions are required in performing the impairment tests. The key assumptions used in the impairment tests were long-term revenue growth projections, discount rates and general industry, market and macro-economic conditions.

[0000833444-20-000048:mdna:132]
While the Company believes the judgments and assumptions used in the impairment tests are reasonable, different assumptions could change the estimated fair values and, therefore, future impairment charges could be required, which could be material to the consolidated financial statements.

[0000833444-20-000048:mdna:133]
Impairment of Long-Lived Assets

[0000833444-20-000048:mdna:134]
The Company reviews long-lived assets, including tangible assets and other intangible assets with definitive lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of Software to be Sold, Leased, or Marketed." ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. ASC 350-30 requires intangible assets acquired in a business combination that are used in research and development activities be considered indefinite lived until the completion or abandonment of the associated research and development efforts. During the period that those assets are considered indefinite lived, they shall not be amortized but shall be tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired. If the carrying amount of an intangible asset exceeds its fair value, an entity shall recognize an impairment loss in an amount equal to that excess. ASC 985-20 requires the unamortized capitalized costs of a computer software product be compared to the net realizable value of that product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset shall be written off. Refer to Note 17, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for information regarding the impairment testing performed in fiscal years 2020, 2019 and 2018.

[0000833444-20-000048:mdna:135]
Employee Benefit Plans

[0000833444-20-000048:mdna:136]
The Company provides a range of benefits to its employees and retired employees, including pensions and postretirement benefits. Plan assets and obligations are measured annually, or more frequently if there is a significant remeasurement event, based on the Company’s measurement date utilizing various actuarial assumptions such as discount rates, assumed rates of

[0000833444-20-000048:mdna:137]
return, compensation increases, turnover rates and health care cost trend rates as of that date. The Company reviews its actuarial assumptions on an annual basis and makes modifications to the assumptions based on current rates and trends when appropriate.

[0000833444-20-000048:mdna:138]
The Company utilizes a mark-to-market approach for recognizing pension and postretirement benefit expenses, including measuring the market related value of plan assets at fair value and recognizing actuarial gains and losses in the fourth quarter of each fiscal year or at the date of a remeasurement event. Refer to Note 15, "Retirement Plans," of the notes to consolidated financial statements for disclosure of the Company's pension and postretirement benefit plans.

[0000833444-20-000048:mdna:139]
U.S. GAAP requires that companies recognize in the statement of financial position a liability for defined benefit pension and postretirement plans that are underfunded or unfunded, or an asset for defined benefit pension and postretirement plans that are over funded. U.S. GAAP also requires that companies measure the benefit obligations and fair value of plan assets that determine a benefit plan’s funded status as of the date of the employer’s fiscal year end.

[0000833444-20-000048:mdna:140]
The Company considers the expected benefit payments on a plan-by-plan basis when setting assumed discount rates. As a result, the Company uses different discount rates for each plan depending on the plan jurisdiction, the demographics of participants and the expected timing of benefit payments. For the U.S. pension and postretirement plans, the Company uses a discount rate provided by an independent third party calculated based on an appropriate mix of high quality bonds. For the non-U.S. pension and postretirement plans, the Company consistently uses the relevant country specific benchmark indices for determining the various discount rates. The Company’s weighted average discount rate on U.S. pension plans was 2.25% and 2.95% at September 30, 2020 and 2019, respectively. The Company’s weighted average discount rate on postretirement plans was 1.90% and 2.65% at September 30, 2020 and 2019, respectively. The Company’s weighted average discount rate on non-U.S. pension plans was 1.35% and 1.50% at September 30, 2020 and 2019, respectively.

[0000833444-20-000048:mdna:141]
In estimating the expected return on plan assets, the Company considers the historical returns on plan assets, adjusted for forward-looking considerations, inflation assumptions and the impact of the active management of the plans’ invested assets. Reflecting the relatively long-term nature of the plans’ obligations, approximately 27% of the plans’ assets are invested in equity securities and 63% in fixed income securities, with the remainder primarily invested in alternative investments. For the years ending September 30, 2020 and 2019, the Company’s expected long-term return on U.S. pension plan assets used to determine net periodic benefit cost was 6.90% and 7.10%, respectively. The actual rate of return on U.S. pension plans was above 6.90% in fiscal year 2020 and above 7.10% in fiscal year 2019. For the years ending September 30, 2020 and 2019, the Company’s weighted average expected long-term return on non-U.S. pension plan assets was 5.20% and 5.20%, respectively. The actual rate of return on non-U.S. pension plans was below 5.20% in fiscal year 2020 and above 5.20% in fiscal year 2019. For the years ending September 30, 2020 and 2019, the Company’s weighted average expected long-term return on postretirement plan assets was 5.70% and 5.65%, respectively. The actual rate of return on postretirement plan assets was below 5.70% in fiscal year 2020 and below 5.65% in fiscal year 2019.

[0000833444-20-000048:mdna:142]
Beginning in fiscal 2021, the Company believes the long-term rate of return will approximate 6.50%, 4.90% and 5.30% for U.S. pension, non-U.S. pension and postretirement plans, respectively. Any differences between actual investment results and the expected long-term asset returns will be reflected in net periodic benefit costs in the fourth quarter of each fiscal year or at the date of a significant remeasurement event. If the Company’s actual returns on plan assets are less than the Company’s expectations, additional contributions may be required.

[0000833444-20-000048:mdna:143]
In fiscal 2020, total employer contributions for continuing operations to the defined benefit pension plans were $58 million, none of which were voluntary contributions made by the Company. The Company expects to contribute approximately $46 million in cash to its defined benefit pension plans in fiscal 2021. In fiscal 2020, total employer contributions for continuing operations to the postretirement plans were $3 million. The Company expects to contribute approximately $3 million in cash to its postretirement plans in fiscal 2021.

[0000833444-20-000048:mdna:144]
Based on information provided by its independent actuaries and other relevant sources, the Company believes that the assumptions used are reasonable; however, changes in these assumptions could impact the Company’s financial position, results of operations or cash flows.

[0000833444-20-000048:mdna:145]
Loss Contingencies

[0000833444-20-000048:mdna:146]
Accruals are recorded for various contingencies including legal proceedings, environmental matters, self-insurance and other claims that arise in the normal course of business. The accruals are based on judgment, the probability of losses and, where applicable, the consideration of opinions of internal and/or external legal counsel and actuarially determined estimates. Additionally, the Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-20-000048:mdna:147]
The Company is subject to laws and regulations relating to protecting the environment. The Company provides for expenses associated with environmental remediation obligations when such amounts are probable and can be reasonably estimated. Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements.

[0000833444-20-000048:mdna:148]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company records receivables from third party insurers when recovery has been determined to be probable. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-20-000048:mdna:149]
Asbestos-Related Contingencies and Insurance Receivables

[0000833444-20-000048:mdna:150]
The Company and certain of its subsidiaries along with numerous other companies are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-20-000048:mdna:151]
In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable. The Company's estimate of asbestos-related insurance recoveries represents estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims discounted to present value. In determining the amount of insurance recoverable, the Company considers available insurance, allocation methodologies, solvency and creditworthiness of the insurers. Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements for a discussion on management's judgments applied in the recognition and measurement of asbestos-related assets and liabilities.

[0000833444-20-000048:mdna:152]
Income Taxes

[0000833444-20-000048:mdna:153]
The Company accounts for income taxes in accordance with ASC 740, "Income Taxes." Deferred tax assets and liabilities are recognized for the future tax consequences attributable to differences between financial statement carrying amounts of existing assets and liabilities and their respective tax bases and operating loss and other loss carryforwards. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company records a valuation allowance that primarily represents non-U.S. operating and other loss carryforwards for which realization is uncertain. Management judgment is required in determining the Company’s provision for income taxes, deferred tax assets and liabilities, and the valuation allowance recorded against the Company’s net deferred tax assets. In calculating the provision for income taxes on an interim basis, the Company uses an estimate of the annual effective tax rate based upon the facts and circumstances known at each interim period. On a quarterly basis, the actual effective tax rate is adjusted as appropriate based upon the actual results as compared to those forecasted at the beginning of the fiscal year.

[0000833444-20-000048:mdna:154]
The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary. At September 30, 2020, the Company had a valuation allowance of $5.5 billion for continuing operations, of which $5.3 billion relates to net operating loss carryforwards primarily in France, Germany, Ireland, Luxembourg, Spain, United Kingdom and the U.S. for which sustainable taxable income has not been demonstrated; and $0.2 billion for other deferred tax assets.

[0000833444-20-000048:mdna:155]
The Company’s federal income tax returns and certain non-U.S. income tax returns for various fiscal years remain under various stages of audit by the IRS and respective non-U.S. tax authorities. Although the outcome of tax audits is always uncertain, management believes that it has appropriate support for the positions taken on its tax returns and that its annual tax provisions included amounts sufficient to pay assessments, if any, which may be proposed by the taxing authorities. At September 30, 2020, the Company had recorded a liability of $2.5 billion for its best estimate of the probable loss on certain of its tax positions, the majority of which is included in other noncurrent liabilities in the consolidated statements of financial position. Nonetheless, the amounts ultimately paid, if any, upon resolution of the issues raised by the taxing authorities may differ materially from the amounts accrued for each year.

[0000833444-20-000048:mdna:156]
The Company does not generally provide additional U.S. or non-U.S. income taxes on outside basis differences of consolidated subsidiaries included in shareholders’ equity attributable to Johnson Controls International plc, except in limited circumstances including anticipated taxation on planned divestitures.  The reduction of the outside basis differences via the sale or liquidation of these subsidiaries and/or distributions could create taxable income.  The Company’s intent is to reduce the outside basis differences only when it would be tax efficient.  Refer to "Capitalization" within the "Liquidity and Capital Resources" section for discussion of U.S. and non-U.S. cash projections.

[0000833444-20-000048:mdna:157]
Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements for the Company's income tax disclosures.

[0000833444-20-000048:mdna:158]
NEW ACCOUNTING PRONOUNCEMENTS

[0000833444-20-000048:mdna:159]
Refer to the "New Accounting Pronouncements" section within Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements.

[0000833444-20-000048:mdna:160]
RISK MANAGEMENT

[0000833444-20-000048:mdna:161]
The Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities and stock-based compensation. All hedging transactions are authorized and executed pursuant to clearly defined policies and procedures, which strictly prohibit the use of financial instruments for speculative purposes. At the inception of the hedge, the Company assesses the effectiveness of the hedge instrument and designates the hedge instrument as either (1) a hedge of a recognized asset or liability or of a recognized firm commitment (a fair value hedge), (2) a hedge of a forecasted transaction or of the variability of cash flows to be received or paid related to an unrecognized asset or liability (a cash flow hedge) or (3) a hedge of a net investment in a non-U.S. operation (a net investment hedge). The Company performs hedge effectiveness testing on an ongoing basis depending on the type of hedging instrument used. All other derivatives not designated as hedging instruments under ASC 815, "Derivatives and Hedging," are revalued in the consolidated statements of income.

[0000833444-20-000048:mdna:162]
For all foreign currency derivative instruments designated as cash flow hedges, retrospective effectiveness is tested on a monthly basis using a cumulative dollar offset test. The fair value of the hedged exposures and the fair value of the hedge instruments are revalued, and the ratio of the cumulative sum of the periodic changes in the value of the hedge instruments to the cumulative sum of the periodic changes in the value of the hedge is calculated. The hedge is deemed as highly effective if the ratio is between 80% and 125%. For commodity derivative contracts designated as cash flow hedges, effectiveness is tested using a regression calculation. Ineffectiveness is minimal as the Company aligns most of the critical terms of its derivatives with the supply contracts.

[0000833444-20-000048:mdna:163]
For net investment hedges, the Company assesses its net investment positions in the non-U.S. operations and compares it with the outstanding net investment hedges on a quarterly basis. The hedge is deemed effective if the aggregate outstanding principal of the hedge instruments designated as the net investment hedge in a non-U.S. operation does not exceed the Company’s net investment positions in the respective non-U.S. operation.

[0000833444-20-000048:mdna:164]
Equity swaps and any other derivative instruments not designated as hedging instruments under ASC 815 require no assessment of effectiveness.

[0000833444-20-000048:mdna:165]
A discussion of the Company’s accounting policies for derivative financial instruments is included in Note 1, "Summary of Significant Accounting Policies," of the notes to consolidated financial statements, and further disclosure relating to derivatives and hedging activities is included in Note 10, "Derivative Instruments and Hedging Activities," and Note 11, "Fair Value Measurements," of the notes to consolidated financial statements.

[0000833444-20-000048:mdna:166]
Foreign Exchange

[0000833444-20-000048:mdna:167]
The Company has manufacturing, sales and distribution facilities around the world and thus makes investments and enters into transactions denominated in various foreign currencies. In order to maintain strict control and achieve the benefits of the Company’s global diversification, foreign exchange exposures for each currency are netted internally so that only its net foreign exchange exposures are, as appropriate, hedged with financial instruments.

[0000833444-20-000048:mdna:168]
The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. The Company primarily enters into foreign currency exchange contracts to reduce the earnings and cash flow impact of the variation of non-functional currency denominated receivables and payables. Gains and losses resulting from hedging instruments offset the foreign exchange gains or losses on the underlying assets and liabilities being hedged. The maturities of the forward exchange contracts generally coincide with the settlement dates of the related transactions. Realized and unrealized gains and losses on these contracts are recognized in the same period as gains and losses on the hedged items. The Company also selectively hedges anticipated transactions that are subject to foreign exchange exposure, primarily with foreign currency exchange contracts, which are designated as cash flow hedges in accordance with ASC 815.

[0000833444-20-000048:mdna:169]
The Company has entered into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of debt obligations are reflected in the accumulated other comprehensive income ("AOCI") account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally.

[0000833444-20-000048:mdna:170]
At September 30, 2020 and 2019, the Company estimates that an unfavorable 10% change in the exchange rates would have decreased net unrealized gains by approximately $363 million and $358 million, respectively.

[0000833444-20-000048:mdna:171]
Interest Rates

[0000833444-20-000048:mdna:172]
Substantially all of the Company's outstanding debt has fixed interest rates. A 10% increase in the average cost of the Company’s variable rate debt would have had an immaterial impact on pre-tax interest expense for the year ended September 30, 2020 and 2019.

[0000833444-20-000048:mdna:173]
Commodities

[0000833444-20-000048:mdna:174]
The Company uses commodity hedge contracts in the financial derivatives market in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. As a cash flow hedge, gains and losses resulting from the hedging instruments offset the gains or losses on purchases of the underlying commodities that will be used in the business. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities.

[0000833444-20-000048:mdna:175]
ENVIRONMENTAL, HEALTH AND SAFETY AND OTHER MATTERS

[0000833444-20-000048:mdna:176]
The Company’s global operations are governed by environmental laws and worker safety laws. Under various circumstances, these laws impose civil and criminal penalties and fines, as well as injunctive and remedial relief, for noncompliance and require remediation at sites where Company-related substances have been released into the environment.

[0000833444-20-000048:mdna:177]
The Company has expended substantial resources globally, both financial and managerial, to comply with applicable environmental laws and worker safety laws and to protect the environment and workers. The Company believes it is in substantial compliance with such laws and maintains procedures designed to foster and ensure compliance. However, the Company has been, and in the future may become, the subject of formal or informal enforcement actions or proceedings regarding noncompliance with such laws or the remediation of Company-related substances released into the environment. Such matters typically are resolved with regulatory authorities through commitments to compliance, abatement or remediation programs and in some cases payment of penalties. Historically, neither such commitments nor penalties imposed on the Company have been material.

[0000833444-20-000048:mdna:178]
Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements for additional information.

[0000833444-20-000048:mdna:179]
44

[0000833444-20-000048:mdna:180]
QUARTERLY FINANCIAL DATA

[0000833444-20-000048:mdna:181]
| (in millions, except per share data)(quarterly amounts unaudited) | FirstQuarter |  | SecondQuarter |  | ThirdQuarter |  | FourthQuarter |  | FullYear |  |
| 2020 |  |  |  |  |  |  |  |  |  |  |
| Net sales | $ | 5,576 |  |  | $ | 5,444 |  |  | $ | 5,343 |  |  | $ | 5,954 |  |  | $ | 22,317 |  |  |
| Gross profit | 1,803 |  |  | 1,801 |  |  | 1,832 |  |  | 1,975 |  |  | 7,411 |  |  |
| Net income (loss) (1) | 191 |  |  | 236 |  |  | (122) |  |  | 490 |  |  | 795 |  |  |
| Net income (loss) attributable to Johnson Controls | 159 |  |  | 213 |  |  | (182) |  |  | 441 |  |  | 631 |  |  |
| Earnings (loss) per share (2) |  |  |  |  |  |  |  |  |  |  |
| Basic | 0.21 |  |  | 0.28 |  |  | (0.24) |  |  | 0.60 |  |  | 0.84 |  |  |
| Diluted | 0.21 |  |  | 0.28 |  |  | (0.24) |  |  | 0.60 |  |  | 0.84 |  |  |
| 2019 |  |  |  |  |  |  |  |  |  |  |
| Net sales | $ | 5,464 |  |  | $ | 5,779 |  |  | $ | 6,451 |  |  | $ | 6,274 |  |  | $ | 23,968 |  |  |
| Gross profit | 1,725 |  |  | 1,844 |  |  | 2,144 |  |  | 1,980 |  |  | 7,693 |  |  |
| Net income (3) | 399 |  |  | 558 |  |  | 4,276 |  |  | 654 |  |  | 5,887 |  |  |
| Net income attributable to Johnson Controls | 355 |  |  | 515 |  |  | 4,192 |  |  | 612 |  |  | 5,674 |  |  |
| Earnings per share (2) |  |  |  |  |  |  |  |  |  |  |
| Basic | 0.39 |  |  | 0.57 |  |  | 4.81 |  |  | 0.78 |  |  | 6.52 |  |  |
| Diluted | 0.38 |  |  | 0.57 |  |  | 4.79 |  |  | 0.77 |  |  | 6.49 |  |  |

[0000833444-20-000048:mdna:182]
(1)The fiscal 2020 first quarter net income includes $39 million of integration costs, $10 million of mark-to-market gains, and $111 million of restructuring and impairment costs. The fiscal 2020 second quarter net income includes $38 million of integration costs, $32 million of mark-to-market losses, and $62 million of restructuring and impairment costs. The fiscal 2020 third quarter net income includes $30 million of integration costs, $132 million of mark-to-market losses, and $610 million of restructuring and impairment costs. The fiscal 2020 fourth quarter net income includes $28 million of integration costs, $120 million of mark-to-market losses, and $39 million of a compensation charge related to a noncontrolling interest acquisition. The preceding amounts are stated on a pre-tax and pre-noncontrolling interest impact basis.

[0000833444-20-000048:mdna:183]
(2)Due to the use of the weighted-average shares outstanding for each quarter for computing earnings per share, the sum of the quarterly per share amounts may not equal the per share amount for the year.

[0000833444-20-000048:mdna:184]
(3)The fiscal 2019 first quarter net income includes $50 million of transaction and integration costs and $21 million of mark-to-market losses. The fiscal 2019 second quarter net income includes $70 million of transaction and integration costs and $20 million of mark-to-market gains. The fiscal 2019 third quarter net income includes a $5.2 billion gain on sale of the Power Solutions business, net of transaction and other costs, $235 million of restructuring and impairment costs, $226 million of tax indemnification reserve release, $140 million of environmental charge, $86 million of transaction and integration costs, $60 million of loss on debt extinguishment and $9 million of mark-to-market gains. The fiscal 2019 fourth quarter net income includes $626 million of net mark-to-market losses and $111 million of transaction and integration costs. The preceding amounts are stated on a pre-tax and pre-noncontrolling interest impact basis and include both continuing and discontinued operations activity.
