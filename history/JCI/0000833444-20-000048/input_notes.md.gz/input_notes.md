# JCI notes — 0000833444-20-000048


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000833444-20-000048:notes:1]
Portions of the definitive Proxy Statement to be delivered to shareholders in connection with the annual general meeting of shareholders to be held on March 10, 2021 are incorporated by reference into Part III.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000833444-20-000048:notes:2]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company," "Johnson Controls" or "JCI plc").

[0000833444-20-000048:notes:3]
Nature of Operations

[0000833444-20-000048:notes:4]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global diversified technology and multi-industrial leader, serving a wide range of customers in more than 150 countries. The Company’s products and solutions enable smart, energy efficient, sustainable buildings that work seamlessly together to advance the safety, comfort and intelligence of spaces to power its customers’ mission. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-20-000048:notes:5]
In 2019, the Company sold its Power Solutions business to BCP Acquisitions LLC ("Purchaser"), an entity controlled by investment funds managed by Brookfield Capital Partners LLC, completing the Company’s transformation into a pure-play building technologies and solutions provider. The transaction closed on April 30, 2019 with net cash proceeds of $11.6 billion after tax and transaction-related expenses. Refer to Note 3, "Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-20-000048:notes:6]
The Company is a global leader in engineering, manufacturing and commissioning building products and systems, including residential and commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire detection systems and fire suppression solutions. The Company further serves customers by providing technical services, including maintenance, repair, retrofit and replacement of equipment (in the HVAC, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions powered by its digital platforms and capabilities.

[0000833444-20-000048:notes:7]
Principles of Consolidation

[0000833444-20-000048:notes:8]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries that are consolidated in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). All significant intercompany transactions have been eliminated. The results of companies acquired or disposed of during the year are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal. Investments in partially-owned affiliates are accounted for by the equity method when the Company’s interest exceeds 20% and the Company does not have a controlling interest.

[0000833444-20-000048:notes:9]
The Company consolidates variable interest entities ("VIE") in which the Company has the power to direct the significant activities of the entity and the obligation to absorb losses or receive benefits from the entity that may be significant. The Company did not have a significant variable interest in any consolidated or nonconsolidated VIEs in its continuing operations for the presented reporting periods.

[0000833444-20-000048:notes:10]
Use of Estimates

[0000833444-20-000048:notes:11]
The preparation of consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting period. Actual results could differ from those estimates.

[0000833444-20-000048:notes:12]
Fair Value of Financial Instruments

[0000833444-20-000048:notes:13]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. See Note 10, "Derivative Instruments and Hedging Activities," and Note 11, "Fair Value Measurements," of the notes to consolidated financial statements for fair value of financial instruments, including derivative instruments, hedging activities and long-term debt.

[0000833444-20-000048:notes:14]
Assets and Liabilities Held for Sale

[0000833444-20-000048:notes:15]
The Company classifies assets and liabilities (disposal groups) to be sold as held for sale in the period in which all of the following criteria are met: management, having the authority to approve the action, commits to a plan to sell the disposal group; the disposal group is available for immediate sale in its present condition subject only to terms that are usual and customary for sales of such disposal groups; an active program to locate a buyer and other actions required to complete the plan to sell the disposal group have been initiated; the sale of the disposal group is probable, and transfer of the disposal group is expected to qualify for recognition as a completed sale within one year, except if events or circumstances beyond the Company's control extend the period of time required to sell the disposal group beyond one year; the disposal group is being actively marketed for sale at a price that is reasonable in relation to its current fair value; and actions required to complete the plan indicate that it is unlikely that significant changes to the plan will be made or that the plan will be withdrawn.

[0000833444-20-000048:notes:16]
In addition, the Company classifies disposal groups to be disposed of other than by sale (e.g. spin-off) as held for sale in the period the disposal occurs.

[0000833444-20-000048:notes:17]
The Company initially measures a disposal group that is classified as held for sale at the lower of its carrying value or fair value less any costs to sell. Any loss resulting from this measurement is recognized in the period in which the held for sale criteria are met. Conversely, gains are not recognized on the sale of a disposal group until the date of sale. The Company assesses the fair value of a disposal group, less any costs to sell, each reporting period it remains classified as held for sale and reports any subsequent changes as an adjustment to the carrying value of the disposal group, as long as the new carrying value does not exceed the carrying value of the disposal group at the time it was initially classified as held for sale.

[0000833444-20-000048:notes:18]
Upon determining that a disposal group meets the criteria to be classified as held for sale, the Company reports the assets and liabilities of the disposal group, if material, in the line items assets held for sale and liabilities held for sale in the consolidated statements of financial position. Refer to Note 3, "Discontinued Operations," of the notes to consolidated financial statements for further information.

[0000833444-20-000048:notes:19]
Cash and Cash Equivalents

[0000833444-20-000048:notes:20]
The Company considers all highly liquid investments with an original maturity of three months or less when purchased to be cash equivalents.

[0000833444-20-000048:notes:21]
Restricted Cash

[0000833444-20-000048:notes:22]
At September 30, 2020 and September 30, 2019, the Company held restricted cash of approximately $9 million and $16 million, respectively all of which was recorded within other current assets in the consolidated statements of financial position. These amounts related to cash restricted for payment of asbestos liabilities.

[0000833444-20-000048:notes:23]
Receivables

[0000833444-20-000048:notes:24]
Receivables consist of amounts billed and currently due from customers and unbilled costs and accrued profits related to revenues on long-term contracts that have been recognized for accounting purposes but not yet billed to customers. The Company extends credit to customers in the normal course of business and maintains an allowance for doubtful accounts resulting from the inability or unwillingness of customers to make required payments. The allowance for doubtful accounts is based on historical experience, existing economic conditions and any specific customer collection issues the Company has identified. The Company enters into supply chain financing programs to sell certain accounts receivable without recourse to third-party financial institutions. Sales of accounts receivable are reflected as a reduction of accounts receivable in the consolidated statements of financial position and the proceeds are included in cash flows from operating activities in the consolidated statements of cash flows.

[0000833444-20-000048:notes:25]
Inventories

[0000833444-20-000048:notes:26]
Inventories are stated at the lower of cost or market using the first-in, first-out ("FIFO") method. Finished goods and work-in-process inventories include material, labor and manufacturing overhead costs.

[0000833444-20-000048:notes:27]
Property, Plant and Equipment

[0000833444-20-000048:notes:28]
Property, plant and equipment are recorded at cost. Depreciation is provided over the estimated useful lives of the respective assets using the straight-line method for financial reporting purposes and accelerated methods for income tax purposes. The

[0000833444-20-000048:notes:29]
estimated useful lives generally range from 3 to 40 years for buildings and improvements, subscriber systems up to 15 years, and from 3 to 15 years for machinery and equipment. The Company capitalizes interest on borrowings during the active construction period of major capital projects. Capitalized interest is added to the cost of the underlying assets and is amortized over the useful lives of the assets.

[0000833444-20-000048:notes:30]
Goodwill and Indefinite-Lived Intangible Assets

[0000833444-20-000048:notes:31]
Goodwill reflects the cost of an acquisition in excess of the fair values assigned to identifiable net assets acquired. The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s reportable segments or one level below the reportable segments in certain instances, using a fair value method based on management’s judgments and assumptions or third party valuations. The fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. In estimating the fair value, the Company uses multiples of earnings based on the average of published multiples of earnings of comparable entities with similar operations and economic characteristics and applies the multiples to the Company's average of historical and future financial results for each reporting unit. In certain instances, the Company uses discounted cash flow analyses or estimated sales price to further support the fair value estimates. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The estimated fair value is then compared with the carrying amount of the reporting unit, including recorded goodwill. The Company is subject to financial statement risk to the extent that the carrying amount exceeds the estimated fair value. Refer to Note 7, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for information regarding the goodwill impairment testing performed in fiscal years 2020, 2019 and 2018.

[0000833444-20-000048:notes:32]
Indefinite-lived intangible assets are also subject to at least annual impairment testing. Indefinite-lived intangible assets primarily consist of trademarks and trade names and are tested for impairment using a relief-from-royalty method. A considerable amount of management judgment and assumptions are required in performing the impairment tests.

[0000833444-20-000048:notes:33]
Leases

[0000833444-20-000048:notes:34]
Lessee arrangements

[0000833444-20-000048:notes:35]
The Company leases certain administrative, production and other facilities, fleet vehicles, information technology equipment and other equipment under arrangements that are accounted for as operating leases. The Company determines whether an arrangement contains a lease at contract inception based on whether the arrangement involves the use of a physically distinct identified asset and whether the Company has the right to obtain substantially all of the economic benefits from the use of the asset throughout the period as well as the right to direct the use of the asset.

[0000833444-20-000048:notes:36]
Right-of-use assets represent the Company’s right to use an underlying asset for the lease term and lease liabilities represent its obligation to make lease payments arising from the lease. Right-of-use assets and the corresponding lease liabilities are recognized at commencement date based on the present value of lease payments for all leases with terms longer than twelve months. As the majority of the Company's leases do not provide an implicit interest rate, to determine the present value of lease payments, the Company uses its incremental borrowing rate based on information available on the lease commencement date and uses the implicit rate when readily determinable.  The Company determines its incremental borrowing rate based on a comparable market yield curve consistent with the Company's credit rating, term of the lease and relative economic environment. The Company has elected to combine lease and nonlease components for its leases.

[0000833444-20-000048:notes:37]
Lessor arrangements

[0000833444-20-000048:notes:38]
The Company's monitoring services and maintenance agreements within its security business that include subscriber system assets for which the Company retains ownership contain both lease and nonlease components. The Company has elected the practical expedient to combine lease and nonlease components for these arrangements where the timing and pattern of transfer of the lease and nonlease components are the same and the lease component would be classified as an operating lease if accounted for separately. The Company has concluded that in these arrangements the nonlease components are the predominant characteristic, and as a result, the combined component is accounted for under the revenue guidance.

[0000833444-20-000048:notes:39]
Impairment of Long-Lived Assets

[0000833444-20-000048:notes:40]
The Company reviews long-lived assets, including right-of-use assets under operating leases, other tangible assets and intangible assets with definitive lives, for impairment whenever events or changes in circumstances indicate that the asset’s

[0000833444-20-000048:notes:41]
carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of Software to be Sold, Leased, or Marketed."

[0000833444-20-000048:notes:42]
The Company groups assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluates the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. Intangible assets acquired in a business combination that are used in research and development activities are considered indefinite-lived until the completion or abandonment of the associated research and development efforts. During the period that those assets are considered indefinite lived, they are not amortized but are tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired.  If the carrying amount of an intangible asset exceeds its fair value, the Company recognizes an impairment loss in an amount equal to that excess. Unamortized capitalized costs of a computer software product are compared to the net realizable value of the product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset is written off. Refer to Note 17, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for information regarding the impairment testing performed in fiscal years 2020, 2019 and 2018.

[0000833444-20-000048:notes:43]
Revenue Recognition

[0000833444-20-000048:notes:44]
The Company recognizes revenue from certain long-term contracts to design, manufacture and install building products and systems as well as unscheduled repair or replacement services on an over time basis, with progress towards completion measured using a cost-to-cost input method based on the relationship between actual costs incurred and total estimated costs at completion. The cost-to-cost input method is used as it best depicts the transfer of control to the customer that occurs as the Company incurs costs. Changes to the original estimates may be required during the life of the contract and such estimates are reviewed monthly. If contract modifications result in additional goods or services that are distinct from those transferred before the modification, they are accounted for prospectively as if the Company entered into a new contract. If the goods or services in the modification are not distinct from those in the original contract, sales and gross profit are adjusted using the cumulative catch-up method for revisions in estimated total contract costs and contract values. Estimated losses are recorded when identified. The Company does not adjust the promised amount of consideration for the effects of a significant financing component as at contract inception the Company expects to receive the payment within twelve months of transfer of goods or services.

[0000833444-20-000048:notes:45]
The Company enters into extended warranties and long-term service and maintenance agreements with certain customers. For these arrangements, revenue is recognized over time on a straight-line basis over the respective contract term.

[0000833444-20-000048:notes:46]
The Company also sells certain HVAC and refrigeration products and services in bundled arrangements with multiple performance obligations, such as equipment, commissioning, service labor and extended warranties. Approximately four to twelve months separate the timing of the first deliverable until the last piece of equipment is delivered, and there may be extended warranty arrangements with duration of one to five years commencing upon the end of the standard warranty period. In addition, the Company sells security monitoring systems that may have multiple performance obligations, including equipment, installation, monitoring services and maintenance agreements. Revenues associated with sale of equipment and related installations are recognized over time on a cost-to-cost input method, while the revenue for monitoring and maintenance services are recognized over time as services are rendered. The transaction price is allocated to each performance obligation based on the relative selling price method. In order to estimate relative selling price, market data and transfer price studies are utilized. If the standalone selling price is not directly observable, the Company estimates the standalone selling price using an adjusted market assessment approach or expected cost plus margin approach. For transactions in which the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized over time on a straight-line basis over the contract term. Non-refundable fees received in connection with the initiation of a monitoring contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the contract.

[0000833444-20-000048:notes:47]
In all other cases, the Company recognizes revenue at the point in time when control over the goods or services transfers to the customer.

[0000833444-20-000048:notes:48]
The Company considers the contractual consideration payable by the customer and assesses variable consideration that may affect the total transaction price, including discounts, rebates, refunds, credits or other similar sources of variable consideration, when determining the transaction price of each contract. The Company includes variable consideration in the estimated transaction price when it is probable that significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. These estimates are based on the amount of consideration that the Company expects to be entitled to.

[0000833444-20-000048:notes:49]
Shipping and handling costs billed to customers are included in sales and the related costs are included in cost of sales when control transfers to the customer. The Company presents amounts collected from customers for sales and other taxes net of the related amounts remitted.

[0000833444-20-000048:notes:50]
Subscriber System Assets, Dealer Intangibles and Related Deferred Revenue Accounts

[0000833444-20-000048:notes:51]
The Company considers assets related to the acquisition of new customers in its electronic security business in three asset categories: internally generated residential subscriber systems outside of North America, internally generated commercial subscriber systems (collectively referred to as subscriber system assets) and customer accounts acquired through the ADT dealer program, primarily outside of North America (referred to as dealer intangibles). Subscriber system assets include installed property, plant and equipment for which the Company retains ownership and deferred costs directly related to the customer acquisition and system installation. Subscriber system assets represent capitalized equipment (e.g. security control panels, touch pad, motion detectors, window sensors, and other equipment) and installation costs associated with electronic security monitoring arrangements under which the Company retains ownership of the security system assets in a customer's place of business, or outside of North America, residence. Installation costs represent costs incurred to prepare the asset for its intended use. The Company pays property taxes on the subscriber system assets and upon customer termination, may retrieve such assets. These assets embody a probable future economic benefit as they generate future monitoring revenue for the Company.

[0000833444-20-000048:notes:52]
Costs related to the subscriber system equipment and installation are categorized as property, plant and equipment rather than deferred costs. Deferred costs associated with subscriber system assets represent direct and incremental selling expenses (such as commissions) related to acquiring the customer. Commissions related to up-front consideration paid by customers in connection with the establishment of the monitoring arrangement are determined based on a percentage of the up-front fees and do not exceed deferred revenue. Such deferred costs are recorded as other current and noncurrent assets within the consolidated statements of financial position.

[0000833444-20-000048:notes:53]
Subscriber system assets and any deferred revenue resulting from the customer acquisition are accounted for over the expected life of the subscriber. In certain geographical areas where the Company has a large number of customers that behave in a similar manner over time, the Company accounts for subscriber system assets and related deferred revenue using pools, with separate pools for the components of subscriber system assets and any related deferred revenue based on the same month and year of acquisition. The Company depreciates its pooled subscriber system assets and related deferred revenue using a straight-line method with lives up to 12 years and considering customer attrition. The Company uses a straight-line method with a 15-year life for non-pooled subscriber system assets (primarily in Europe, Latin America and Asia) and related deferred revenue, with remaining balances written off upon customer termination.

[0000833444-20-000048:notes:54]
Certain contracts and related customer relationships result from purchasing residential security monitoring contracts from an external network of independent dealers who operate under the ADT dealer program, primarily outside of North America. Acquired contracts and related customer relationships are recorded at their contractually determined purchase price.

[0000833444-20-000048:notes:55]
During the first 6 months (12 months in certain circumstances) after the purchase of the customer contract, any cancellation of monitoring service, including those that result from customer payment delinquencies, results in a chargeback by the Company to the dealer for the full amount of the contract purchase price. The Company records the amount charged back to the dealer as a reduction of the previously recorded intangible asset.

[0000833444-20-000048:notes:56]
Intangible assets arising from the ADT dealer program described above are amortized in pools determined by the same month and year of contract acquisition on a straight-line basis over the period of the customer relationship. The estimated useful life of dealer intangibles ranges from 12 to 15 years.

[0000833444-20-000048:notes:57]
Research and Development Costs

[0000833444-20-000048:notes:58]
Expenditures for research activities relating to product development and improvement are charged against income as incurred and included within selling, general and administrative expenses for continuing operations in the consolidated statements of

[0000833444-20-000048:notes:59]
income. Such expenditures for the years ended September 30, 2020, 2019 and 2018 were $274 million, $319 million and $310 million, respectively.

[0000833444-20-000048:notes:60]
Earnings Per Share

[0000833444-20-000048:notes:61]
The Company presents both basic and diluted earnings per share ("EPS") amounts. Basic EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of common shares outstanding during the reporting period. Diluted EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of common shares and common equivalent shares outstanding during the reporting period that are calculated using the treasury stock method for stock options, unvested restricted stock and unvested performance share awards. See Note 13, "Earnings per Share," of the notes to consolidated financial statements for the calculation of earnings per share.

[0000833444-20-000048:notes:62]
Foreign Currency Translation

[0000833444-20-000048:notes:63]
Substantially all of the Company’s international operations use the respective local currency as the functional currency. Assets and liabilities of international entities have been translated at period-end exchange rates, and income and expenses have been translated using average exchange rates for the period. Monetary assets and liabilities denominated in non-functional currencies are adjusted to reflect period-end exchange rates. The aggregate transaction gains (losses), net of the impact of foreign currency hedges, included in income from continuing operations for the years ended September 30, 2020, 2019 and 2018 were $(32) million, $(10) million and $1 million, respectively.

[0000833444-20-000048:notes:64]
Derivative Financial Instruments

[0000833444-20-000048:notes:65]
The Company has written policies and procedures that place all financial instruments under the direction of Corporate treasury and restrict all derivative transactions to those intended for hedging purposes. The use of financial instruments for speculative purposes is strictly prohibited. The Company selectively uses financial instruments to manage the market risk from changes in foreign exchange rates, commodity prices, stock-based compensation liabilities and interest rates.

[0000833444-20-000048:notes:66]
The fair values of all derivatives are recorded in the consolidated statements of financial position. The change in a derivative’s fair value is recorded each period in current earnings or accumulated other comprehensive income ("AOCI"), depending on whether the derivative is designated as part of a hedge transaction and if so, the type of hedge transaction. See Note 10, "Derivative Instruments and Hedging Activities," and Note 11, "Fair Value Measurements," of the notes to consolidated financial statements for disclosure of the Company’s derivative instruments and hedging activities.

[0000833444-20-000048:notes:67]
Investments

[0000833444-20-000048:notes:68]
The Company invests in debt and equity securities which are marked to market at the end of each accounting period. For fiscal 2020 and 2019, unrealized gains and losses on these securities are recognized in the Company's consolidated statements of income. For periods prior to fiscal 2019, the unrealized gains and losses on these securities, other than the deferred compensation plan assets, were recognized in AOCI within the consolidated statement of shareholders' equity unless an unrealized loss is deemed to be other than temporary, in which case such loss was charged to earnings. The deferred compensation plan assets are marked to market at the end of each accounting period and all unrealized gains and losses are recorded in the consolidated statements of income.

[0000833444-20-000048:notes:69]
Pension and Postretirement Benefits

[0000833444-20-000048:notes:70]
The Company utilizes a mark-to-market approach for recognizing pension and postretirement benefit expenses, including measuring the market related value of plan assets at fair value and recognizing actuarial gains and losses in the fourth quarter of each fiscal year or at the date of a remeasurement event. Refer to Note 15, "Retirement Plans," of the notes to consolidated financial statements for disclosure of the Company's pension and postretirement benefit plans.

[0000833444-20-000048:notes:71]
Loss Contingencies

[0000833444-20-000048:notes:72]
Accruals are recorded for various contingencies including legal proceedings, environmental matters, self-insurance and other claims that arise in the normal course of business. The accruals are based on judgment, the probability of losses and, where applicable, the consideration of opinions of internal and/or external legal counsel and actuarially determined estimates. Additionally, the Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-20-000048:notes:73]
The Company is subject to laws and regulations relating to protecting the environment. The Company provides for expenses associated with environmental remediation obligations when such amounts are probable and can be reasonably estimated. Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements.

[0000833444-20-000048:notes:74]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company records receivables from third party insurers when recovery has been determined to be probable. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-20-000048:notes:75]
Asbestos-Related Contingencies and Insurance Receivables

[0000833444-20-000048:notes:76]
The Company and certain of its subsidiaries along with numerous other companies are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-20-000048:notes:77]
In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable. The Company's estimate of asbestos-related insurance recoveries represents estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims discounted to present value. In determining the amount of insurance recoverable, the Company considers available insurance, allocation methodologies, solvency and creditworthiness of the insurers. Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements for a discussion on management's judgments applied in the recognition and measurement of asbestos-related assets and liabilities.

[0000833444-20-000048:notes:78]
Income Taxes

[0000833444-20-000048:notes:79]
Deferred tax liabilities and assets are recognized for the expected future tax consequences of events that have been reflected in the consolidated financial statements. Deferred tax liabilities and assets are determined based on the differences between the book and tax basis of particular assets and liabilities and operating loss carryforwards, using tax rates in effect for the years in which the differences are expected to reverse. A valuation allowance is provided to reduce the carrying or book value of deferred tax assets if, based upon the available evidence, including consideration of tax planning strategies, it is more-likely-than-not that some or all of the deferred tax assets will not be realized. Refer to Note 18, "Income Taxes," of the notes to consolidated financial statements.

[0000833444-20-000048:notes:80]
Retrospective Changes

[0000833444-20-000048:notes:81]
Certain amounts as of September 30, 2019 and 2018 have been revised to conform to the current year's presentation.

[0000833444-20-000048:notes:82]
New Accounting Pronouncements

[0000833444-20-000048:notes:83]
Recently Adopted Accounting Pronouncements

[0000833444-20-000048:notes:84]
In February 2016, the FASB issued ASU No. 2016-02, "Leases (Topic 842)." ASU No. 2016-02 requires recognition of operating leases as lease assets and liabilities on the balance sheet, and disclosure of key information about leasing arrangements. The Company adopted Topic 842 and the related amendments using a modified-retrospective approach as of October 1, 2019 and applied the new guidance to all leases through a cumulative-effect adjustment to beginning retained earnings. The comparative periods have not been recast and continue to be reported under the previous lease accounting guidance. The Company has elected to apply the package of transitional practical expedients, under which the Company did not reassess prior conclusions about lease identification, lease classification, and initial direct costs of existing leases as of the date of adoption. The adoption of the new guidance resulted in recognition of a right-of-use asset and related lease liabilities of $1.1 billion, with an immaterial impact to retained earnings. Refer to Note 8, “Leases,” for additional lease disclosures.

[0000833444-20-000048:notes:85]
In May 2020, the SEC issued Final Rule Release No. 33-10786, which amends the financial statement requirements for acquisitions and dispositions of businesses and related pro forma financial information required under SEC Regulation S-X, Rule 3-05. Among other things, the final rule modifies the significance test required in SEC Regulation S-X, Rule 1-02(w) by changing the income test to use the lower measure of significance based on income from continuing operations before taxes or revenue. In accordance with Rules 3-09 or 4-08(g), the revised income test will apply to the evaluation of equity method investments for significance. The final rule is effective on January 1, 2021, however, voluntary early adoption is permitted as long as all amendments are adopted in their entirety. The Company early adopted all provisions of the final rule during the fourth quarter of fiscal 2020. As a result of the revised income test, none of the Company’s non-consolidated partially-owned affiliates, either individually or in the aggregate, are considered significant subsidiaries which require disclosure in the Company’s footnotes for fiscal 2020.

[0000833444-20-000048:notes:86]
Recently issued accounting pronouncements are not expected to have a material impact on the Company's consolidated financial statements.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-20-000048:notes:87]
ACQUISITIONS AND DIVESTITURES
Fiscal Year 2020

[0000833444-20-000048:notes:88]
During fiscal 2020, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $82 million, of which $77 million was paid as of September 30, 2020. In connection with the acquisitions, the Company recorded goodwill of $35 million within the Building Solutions EMEA/LA segment and $21 million within the Global Products segment. The acquisitions were not material to the Company's consolidated financial statements.

[0000833444-20-000048:notes:89]
Additionally, in the fourth quarter of fiscal 2020, the Company acquired additional ownership interest in one of its consolidated subsidiaries within the Global Products segment for a purchase price of $132 million, all of which was paid as of September 30, 2020. In connection with this transaction, the Company recorded a compensation charge of $39 million related to the cash settlement of equity awards.

[0000833444-20-000048:notes:90]
In the fourth quarter of fiscal 2020, the Company completed certain divestitures within the Global Products and Building Solutions Asia Pacific segments. The combined selling price, net of cash divested, was $152 million, of which $135 million was received as of September 30, 2020. In connection with the divestitures, the Company reduced goodwill by $11 million within the Building Solutions Asia Pacific segment. The divestitures were not material to the Company's consolidated financial statements.

[0000833444-20-000048:notes:91]
Fiscal Year 2019

[0000833444-20-000048:notes:92]
On April 30, 2019, the Company completed the sale of its Power Solutions business to BCP Acquisitions LLC for a purchase price of $13.2 billion. The net cash proceeds after tax and transaction-related expenses were $11.6 billion. In connection with the sale, the Company recorded a gain, net of transaction and other costs, of $5.2 billion ($4.0 billion after tax), subject to post-closing working capital and net debt adjustments, within income from discontinued operations, net of tax, in the consolidated statements of income. Refer to Note 3, "Discontinued Operations," of the notes to consolidated financial statements for further disclosure related to the Company's discontinued operations.

[0000833444-20-000048:notes:93]
During fiscal 2019, the Company completed certain divestitures within the Global Products and Building Solutions EMEA/LA segments. The combined selling price was $18 million, $16 million of which was received as of September 30, 2019. In

[0000833444-20-000048:notes:94]
connection with the sale, the Company reduced goodwill by $1 million within the Building Solutions EMEA/LA segment. The divestitures were not material to the Company's consolidated financial statements.

[0000833444-20-000048:notes:95]
During fiscal 2019, the Company completed certain acquisitions for a combined purchase price of $32 million, $25 million of which was paid as of September 30, 2019. In connection with the acquisitions, the Company recorded goodwill of $11 million within the Global Products segment, $8 million within the Building Solutions Asia Pacific segment, and $6 million within the Building Solutions EMEA/LA segment. The acquisitions were not material to the Company's consolidated financial statements.

[0000833444-20-000048:notes:96]
Fiscal Year 2018

[0000833444-20-000048:notes:97]
During fiscal 2018, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $21 million, all of which was paid as of September 30, 2018. In connection with the acquisitions, the Company recorded goodwill of $14 million within the Global Products segment and $1 million within the Building Solutions EMEA/LA segment. The acquisitions were not material to the Company’s consolidated financial statements.

[0000833444-20-000048:notes:98]
In the first quarter of fiscal 2018, the Company completed the sale of its Scott Safety business to 3M Company. The selling price, net of cash divested, was $2.0 billion, all of which was received as of September 30, 2018. In connection with the sale, the Company recorded a pre-tax gain of $114 million within selling, general and administrative expenses in the consolidated statements of income and reduced goodwill in assets held for sale by $1.2 billion. The gain, net of tax, recorded was $84 million.

[0000833444-20-000048:notes:99]
Also during fiscal 2018, the Company completed certain divestitures primarily within the Global Products segment. The combined selling price was $204 million, all of which was received as of September 30, 2018. In connection with the divestitures, the Company reduced goodwill by $35 million. The divestitures were not material to the Company's consolidated financial statements.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-20-000048:notes:100]
DISCONTINUED OPERATIONS
Power Solutions

[0000833444-20-000048:notes:101]
During the first quarter of fiscal 2019, the Company determined that its Power Solutions business met the criteria to be classified as a discontinued operation and, as a result, its historical financial results are reflected in the Company's consolidated financial statements as a discontinued operation, and assets and liabilities were classified as assets and liabilities held for sale. The Company did not allocate any general corporate overhead to discontinued operations.

[0000833444-20-000048:notes:102]
The following table summarizes the results of Power Solutions which are classified as discontinued operations for the fiscal years ended September 30, 2019 and 2018 (in millions). As the Power Solutions sale occurred on April 30, 2019, there are only seven months of results included in the fiscal year ended September 30, 2019.

[0000833444-20-000048:notes:103]
|  |  |  |  |  |  | Year Ended September 30, |  |
|  |  |  |  |  |  | 2019 |  | 2018 |  |
| Net sales |  |  |  |  |  | $ | 5,001 |  |  | $ | 8,000 |  |  |
| Income from discontinued operations before income taxes |  |  |  |  |  | 6,039 |  |  | 1,355 |  |  |
| Provision for income taxes on discontinued operations |  |  |  |  |  | (1,441) |  |  | (321) |  |  |
| Income from discontinued operations attributable to noncontrolling interests, net of tax |  |  |  |  |  | (24) |  |  | (47) |  |  |
| Income from discontinued operations |  |  |  |  |  | $ | 4,574 |  |  | $ | 987 |  |  |

[0000833444-20-000048:notes:104]
For the fiscal year ended September 30, 2019, income from discontinued operations before income taxes included a gain on sale of the Power Solutions business, net of transaction and other costs, of $5.2 billion and a favorable impact of $117 million for ceasing depreciation and amortization expense as the business was held for sale.

[0000833444-20-000048:notes:105]
For the fiscal year ended September 30, 2019, the effective tax rate was more than the Irish statutory rate of 12.5% primarily due to the tax impacts of the divestiture of the Power Solutions business and tax rate differentials. For the fiscal year ended September 30, 2018, the effective tax rate was more than the Irish statutory rate of 12.5% primarily due to legal entity restructuring associated with the Power Solutions business and tax rate differentials.

[0000833444-20-000048:notes:106]
During the third quarter of fiscal 2020, the Company determined that certain assets of the Building Solutions Asia Pacific segment met the criteria to be classified as held for sale. The estimated fair value, less costs to sell, of these assets was $147 million at September 30, 2020.

[0000833444-20-000048:notes:107]
During the third quarter of 2019, the Company determined that a business within its Global Products segment met the criteria to be classified as held for sale. This business was sold in the fourth quarter of fiscal 2020. The assets and liabilities of this business are presented as held for sale in the consolidated statements of financial position as of September 30, 2019. Assets and liabilities held for sale are recorded at the lower of carrying value or fair value less any costs to sell. The Company recorded impairment charges within restructuring and impairment costs in the consolidated statements of income of $15 million in the first quarter of fiscal 2020 and $235 million in the third quarter of fiscal 2019 to write down the carrying value of the assets held for sale to fair value less any costs to sell. Refer to Note 17, "Impairment of Long-Lived Assets" of the notes to consolidated financial statements for further information regarding the impairment charges. The business did not meet the criteria to be classified as a discontinued operation as the divestiture did not have a major effect on the Company’s operations and financial results.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-20-000048:notes:108]
REVENUE RECOGNITION
Disaggregated Revenue

[0000833444-20-000048:notes:109]
The following table presents the Company's revenues disaggregated by segment and by products and systems versus services revenue for the years ended September 30, 2020 and 2019 (in millions):

[0000833444-20-000048:notes:110]
|  |  | Year Ended September 30, 2020 |  | Year Ended September 30, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 5,371 |  |  | $ | 3,234 |  |  | $ | 8,605 |  |  | $ | 5,745 |  |  | $ | 3,286 |  |  | $ | 9,031 |  |
| Building Solutions EMEA/LA |  | 1,644 |  |  | 1,796 |  |  | 3,440 |  |  | 1,767 |  |  | 1,888 |  |  | 3,655 |  |
| Building Solutions Asia Pacific |  | 1,369 |  |  | 1,034 |  |  | 2,403 |  |  | 1,575 |  |  | 1,083 |  |  | 2,658 |  |
| Global Products |  | 7,869 |  |  | — |  |  | 7,869 |  |  | 8,624 |  |  | — |  |  | 8,624 |  |
| Total |  | $ | 16,253 |  |  | $ | 6,064 |  |  | $ | 22,317 |  |  | $ | 17,711 |  |  | $ | 6,257 |  |  | $ | 23,968 |  |

[0000833444-20-000048:notes:111]
The following table presents further disaggregation of Global Products segment revenues by product type for the years ended September 30, 2020 and 2019 (in millions):

[0000833444-20-000048:notes:112]
|  |  | Year EndedSeptember 30, 2020 |  | Year Ended September 30, 2019 |
| Building management systems |  | $ | 1,205 |  |  | $ | 1,292 |  |
| HVAC & refrigeration equipment |  | 5,613 |  |  | 6,181 |  |
| Specialty products |  | 1,051 |  |  | 1,151 |  |
| Total |  | $ | 7,869 |  |  | $ | 8,624 |  |

[0000833444-20-000048:notes:113]
Contract Balances

[0000833444-20-000048:notes:114]
Contract assets relate to the Company’s right to consideration for performance obligations satisfied but not billed and consist of unbilled receivables and costs in excess of billings. Contract liabilities relate to customer payments received in advance of satisfaction of performance obligations under the contract. Contract liabilities consist of deferred revenue. Contract balances are classified as assets or liabilities on a contract-by-contract basis at the end of each reporting period.

[0000833444-20-000048:notes:115]
The following table presents the location and amount of contract balances in the Company's consolidated statements of financial position (in millions):

[0000833444-20-000048:notes:116]
|  |  | Location of contract balances |  | September 30, 2020 |  | September 30, 2019 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,395 |  |  | $ | 1,389 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 104 |  |  | 90 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,435) |  |  | (1,407) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (245) |  |  | (228) |  |  |  |
| Total |  |  |  | $ | (181) |  |  | $ | (156) |  |  |  |

[0000833444-20-000048:notes:117]
For the year ended September 30, 2020, the Company recognized revenue of approximately $1.3 billion that was included in the beginning of period contract liability balance. For the year ended September 30, 2019, the Company recognized revenue of approximately $1.2 billion that was included in the beginning of period contract liability balance.

[0000833444-20-000048:notes:118]
Performance Obligations

[0000833444-20-000048:notes:119]
A performance obligation is a distinct good, service, or bundle of goods and services promised in a contract. A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. When contracts with customers require significant and complex integration, contain goods or services which are highly interdependent or interrelated, or are goods or services which significantly modify or customize other promises in the contracts and, therefore, are not distinct, then the entire contract is accounted for as a single performance obligation. For any contracts with multiple performance obligations, the contract’s transaction price is allocated to each performance obligation based on the estimated relative standalone selling price of each distinct good or service in the contract. For product sales, each product sold to a customer typically represents a distinct performance obligation.

[0000833444-20-000048:notes:120]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of September 30, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $14.4 billion, of which approximately 60% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

[0000833444-20-000048:notes:121]
Costs to Obtain or Fulfill a Contract

[0000833444-20-000048:notes:122]
The Company recognizes the incremental costs incurred to obtain or fulfill a contract with a customer as an asset when these costs are recoverable. These costs consist primarily of sales commissions and bid/proposal costs. Costs to obtain or fulfill a contract are capitalized and amortized to revenue over the period of contract performance.

[0000833444-20-000048:notes:123]
As of September 30, 2020, the Company recorded costs to obtain or fulfill a contract of $223 million, of which $119 million is recorded within other current assets and $104 million is recorded within other noncurrent assets in the consolidated statements of financial position. As of September 30, 2019, the Company recorded costs to obtain or fulfill a contract of $212 million, of which $110 million is recorded within other current assets and $102 million is recorded within other noncurrent assets in the consolidated statements of financial position.
During the year ended September 30, 2020, the Company recognized amortization expense of $162 million related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the year ended September 30, 2020. During the year ended September 30, 2019, the Company recognized amortization expense of $157 million related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the year ended September 30, 2019.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-20-000048:notes:124]
INVENTORIES
Inventories consisted of the following (in millions):

[0000833444-20-000048:notes:125]
|  | September 30, |
|  | 2020 |  | 2019 |
| Raw materials and supplies | $ | 629 |  |  | $ | 588 |  |
| Work-in-process | 142 |  |  | 176 |  |
| Finished goods | 1,002 |  |  | 1,050 |  |
| Inventories | $ | 1,773 |  |  | $ | 1,814 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000833444-20-000048:notes:126]
PROPERTY, PLANT AND EQUIPMENT
Property, plant and equipment consisted of the following (in millions):

[0000833444-20-000048:notes:127]
|  | September 30, |
|  | 2020 |  | 2019 |
| Buildings and improvements | $ | 1,351 |  |  | $ | 1,499 |  |
| Subscriber systems | 679 |  |  | 661 |  |
| Machinery and equipment | 3,332 |  |  | 2,969 |  |
| Construction in progress | 327 |  |  | 465 |  |
| Land | 241 |  |  | 250 |  |
| Total property, plant and equipment | 5,930 |  |  | 5,844 |  |
| Less: accumulated depreciation | (2,871) |  |  | (2,496) |  |
| Property, plant and equipment - net | $ | 3,059 |  |  | $ | 3,348 |  |

[0000833444-20-000048:notes:128]
Interest costs capitalized during the fiscal years ended September 30, 2020, 2019 and 2018 were $1 million, $6 million and $17 million, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-20-000048:notes:129]
GOODWILL AND OTHER INTANGIBLE ASSETS
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the fiscal years ended September 30, 2020 and 2019 were as follows (in millions):

[0000833444-20-000048:notes:130]
|  | September 30, 2018 |  | BusinessAcquisitions |  | BusinessDivestitures |  | Impairments |  | Currency Translation and Other |  | September 30, 2019 |
| Building Solutions North America | $ | 9,603 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (15) |  |  | $ | 9,588 |  |
| Building Solutions EMEA/LA | 1,950 |  |  | 6 |  |  | (1) |  |  | — |  |  | (106) |  |  | 1,849 |  |
| Building Solutions Asia Pacific | 1,235 |  |  | 8 |  |  | — |  |  | — |  |  | (49) |  |  | 1,194 |  |
| Global Products | 5,593 |  |  | 11 |  |  | (22) |  |  | — |  |  | (35) |  |  | 5,547 |  |
| Total | $ | 18,381 |  |  | $ | 25 |  |  | $ | (23) |  |  | $ | — |  |  | $ | (205) |  |  | $ | 18,178 |  |
|  | September 30, 2019 |  | BusinessAcquisitions |  | BusinessDivestitures |  | Impairments |  | Currency Translation and Other |  | September 30, 2020 |
| Building Solutions North America | $ | 9,588 |  |  | $ | — |  |  | $ | — |  |  | $ | (424) |  |  | $ | (4) |  |  | $ | 9,160 |  |
| Building Solutions EMEA/LA | 1,849 |  |  | 35 |  |  | — |  |  | — |  |  | 83 |  |  | 1,967 |  |
| Building Solutions Asia Pacific | 1,194 |  |  | — |  |  | (11) |  |  | — |  |  | 43 |  |  | 1,226 |  |
| Global Products | 5,547 |  |  | 21 |  |  | — |  |  | — |  |  | 11 |  |  | 5,579 |  |
| Total | $ | 18,178 |  |  | $ | 56 |  |  | $ | (11) |  |  | $ | (424) |  |  | $ | 133 |  |  | $ | 17,932 |  |

[0000833444-20-000048:notes:131]
The fiscal 2019 Global Products business divestiture amount includes $22 million of goodwill transferred to noncurrent assets held for sale in the consolidated statements of financial position related to the fiscal 2020 disposal of a business within the Global Products segment.

[0000833444-20-000048:notes:132]
At September 30, 2018, accumulated goodwill impairment charges included $47 million related to the Building Solutions EMEA/LA - Latin America reporting unit.

[0000833444-20-000048:notes:133]
The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company considered the ongoing deterioration in general economic and market conditions due to the COVID-19 pandemic and its impact on each of the Company’s reporting units’ performance. Due to further declines in cash flow projections of the North America Retail reporting unit in the third quarter of fiscal 2020 as a result of the COVID-19 pandemic, the Company concluded a triggering event occurred requiring assessment of impairment for its North America Retail reporting unit. As a result, the Company recorded a non-cash impairment charge of $424 million within restructuring and impairment costs in the consolidated statements of income in the third quarter of fiscal 2020, which was determined by comparing the carrying amount of a reporting unit to its fair value in accordance with ASU No. 2017-04, "Intangible - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment," which the Company early adopted. The North America Retail reporting unit has a remaining goodwill balance of $230 million at September 30, 2020. The Company used a discounted cash flow model to estimate the fair value of the reporting unit. Other than management's internal projections of future cash flows, the primary assumptions used in the model were the weighted-average cost of capital and long-term growth rates, which are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." Although the Company's cash flow forecasts are based on assumptions that are considered reasonable by management and consistent with the plans and estimates management is using to operate the underlying business, there was significant judgment in determining the expected future cash flows attributable to the North America Retail reporting unit.

[0000833444-20-000048:notes:134]
There were no goodwill impairments resulting from the fiscal 2020 and 2019 annual impairment tests. With the exception of the North America Retail reporting unit that had a recent goodwill impairment and is recorded at fair value, no reporting unit was determined to be at risk of failing the goodwill impairment test. The estimated fair value for North America Retail reporting unit exceeded its carrying value by 6%. The Company performs impairment reviews for its reporting units, which have been determined to be the Company’s reportable segments or one level below the reportable segments in certain instances, using a fair value method based on management’s judgments and assumptions or third party valuations. The fair value of a reporting unit refers to the price that would be received to sell the unit as a whole in an orderly transaction between market participants at the measurement date. In estimating the fair value, the Company uses multiples of earnings based on the average of published multiples of earnings of comparable entities with similar operations and economic characteristics and applies the multiples to the Company's average of historical and future financial results for each reporting unit. In certain instances, the Company uses discounted cash flow analyses or estimated sales price to further support the fair value estimates. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." The estimated fair value is then compared with the carrying amount of the reporting unit, including recorded goodwill. The Company is subject to financial statement risk to the extent that the carrying amount exceeds the estimated fair value.

[0000833444-20-000048:notes:135]
The assumptions included in the impairment tests require judgment, and changes to these inputs could impact the results of the calculations. The primary assumptions used in the impairment tests were management's projections of future cash flows. Although the Company's cash flow forecasts are based on assumptions that are considered reasonable by management and consistent with the plans and estimates management is using to operate the underlying businesses, there are significant judgments in determining the expected future cash flows attributable to a reporting unit.

[0000833444-20-000048:notes:136]
The Company continuously monitors for events and circumstances that could negatively impact the key assumptions in determining fair value, including long-term revenue growth projections, profitability, discount rates, recent market valuations from transactions by comparable companies, volatility in the Company's market capitalization, and general industry, market and macro-economic conditions. It is possible that future changes in such circumstances, including a more prolonged and/or severe COVID-19 pandemic, or future changes in the variables associated with the judgments, assumptions and estimates used in assessing the fair value of the reporting unit, would require the Company to record additional non-cash impairment charges.

[0000833444-20-000048:notes:137]
The Company’s other intangible assets, primarily from business acquisitions valued based on independent appraisals, consisted of (in millions):

[0000833444-20-000048:notes:138]
|  | September 30, 2020 |  | September 30, 2019 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Amortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,332 |  |  | $ | (497) |  |  | $ | 835 |  |  | $ | 1,307 |  |  | $ | (370) |  |  | $ | 937 |  |
| Customer relationships | 2,773 |  |  | (969) |  |  | 1,804 |  |  | 2,722 |  |  | (759) |  |  | 1,963 |  |
| Miscellaneous | 657 |  |  | (268) |  |  | 389 |  |  | 584 |  |  | (224) |  |  | 360 |  |
| Total amortized intangible assets | 4,762 |  |  | (1,734) |  |  | 3,028 |  |  | 4,613 |  |  | (1,353) |  |  | 3,260 |  |
| Unamortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/tradenames | 2,248 |  |  | — |  |  | 2,248 |  |  | 2,282 |  |  | — |  |  | 2,282 |  |
| Miscellaneous | 80 |  |  | — |  |  | 80 |  |  | 90 |  |  | — |  |  | 90 |  |
|  | 2,328 |  |  | — |  |  | 2,328 |  |  | 2,372 |  |  | — |  |  | 2,372 |  |
| Total intangible assets | $ | 7,090 |  |  | $ | (1,734) |  |  | $ | 5,356 |  |  | $ | 6,985 |  |  | $ | (1,353) |  |  | $ | 5,632 |  |

[0000833444-20-000048:notes:139]
The Company reviews indefinite-lived intangible assets for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. Indefinite-lived intangible assets primarily consist of trademarks and tradenames and are tested for impairment using a relief-from-royalty method. During the second and third quarters of fiscal 2020, the Company determined that it had a triggering event at each reporting period end requiring assessment of impairment for certain of its indefinite-lived intangible assets due to declines in revenue directly attributable to the COVID-19 pandemic. As a result, the Company recorded an impairment charge of $62 million related primarily to the Company's retail business indefinite-lived intangible assets within restructuring and impairment costs in the consolidated statements of income in the second quarter of fiscal 2020. No further impairment was required to be recorded in the third quarter of fiscal 2020 as a result of the completed impairment assessment.

[0000833444-20-000048:notes:140]
There were no indefinite-lived intangible asset impairments resulting from fiscal 2020 and 2019 annual impairment tests. The estimated fair values of all indefinite-lived intangibles substantially exceeded their carrying values, with the exception of the indefinite-lived trademarks related to the Company's security and Asia Pacific subscriber businesses. The estimated fair value for the security and Asia Pacific indefinite-lived trademarks exceeded their carrying value by 4% and 2%, respectively. The carrying amount of the security and Asia Pacific indefinite-lived trademarks as of September 30, 2020 was $299 million and $37 million, respectively.

[0000833444-20-000048:notes:141]
The Company continuously monitors for events and circumstances that could negatively impact the key assumptions in determining fair value, including long-term revenue growth projections, discount rates and general industry, market and macro-economic conditions. It is possible that future changes in such circumstances, including a more prolonged and/or severe COVID-19 pandemic, or future changes in the variables associated with the judgments, assumptions and estimates used in assessing the fair value of the indefinite-lived intangible assets, would require the Company to record an additional non-cash impairment charge.
Amortization of other intangible assets included within continuing operations for the fiscal years ended September 30, 2020, 2019 and 2018 was $386 million, $377 million and $376 million, respectively. Excluding the impact of any future acquisitions, the Company anticipates amortization for fiscal 2021, 2022, 2023, 2024 and 2025 will be approximately $404 million, $403 million, $402 million, $383 million and $365 million, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000833444-20-000048:notes:142]
LEASES
Most leases contain options to renew or terminate the lease. Right-of-use assets and lease liabilities reflect only the options which the Company is reasonably certain to exercise. Lease expense is recognized on a straight-line basis over the lease term.

[0000833444-20-000048:notes:143]
The Company has certain real estate leases that contain variable lease payments which are based on changes in the Consumer Price Index (CPI). Additionally, the Company’s leases generally require it to pay for fuel, maintenance, repair, insurance and taxes. These payments are not included in the right-of-use asset or lease liability and are expensed as incurred.

[0000833444-20-000048:notes:144]
The following table presents the Company’s lease costs for the fiscal year ended September 30, 2020 (in millions):

[0000833444-20-000048:notes:145]
|  |  | Year EndedSeptember 30, 2020 |  |
| Operating lease cost |  | $ | 399 |  |  |
| Variable lease cost |  | 145 |  |  |
| Total lease costs |  | $ | 544 |  |  |

[0000833444-20-000048:notes:146]
Total rental expense for continuing operations for the fiscal years ended September 30, 2019 and 2018 was $452 million and $408 million, respectively.

[0000833444-20-000048:notes:147]
The following table presents supplemental consolidated statement of financial position information as of September 30, 2020 (in millions):

[0000833444-20-000048:notes:148]
|  | Location of lease balances |  | September 30, 2020 |
| Operating lease right-of-use assets | Other noncurrent assets |  | $ | 1,190 |  |
| Operating lease liabilities - current | Other current liabilities |  | 332 |  |
| Operating lease liabilities - noncurrent | Other noncurrent liabilities |  | 875 |  |
| Weighted-average remaining lease term |  |  | 6 years |
| Weighted-average discount rate |  |  | 2.2 | % |

[0000833444-20-000048:notes:149]
The following table presents supplemental cash flow information related to operating leases for the fiscal year ended September 30, 2020 (in millions):

[0000833444-20-000048:notes:150]
|  |  | Year EndedSeptember 30, 2020 |  |
| Cash paid for amounts included in the measurement of lease liability: |  |  |  |
| Operating cash outflows from operating leases |  | $ | 397 |  |  |
| Noncash operating lease activity: |  |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  | 467 |  |  |

[0000833444-20-000048:notes:151]
The following table presents maturities of operating lease liabilities as of September 30, 2020 (in millions):

[0000833444-20-000048:notes:152]
|  |  | September 30, 2020 |
| 2021 |  | $ | 352 |  |
| 2022 |  | 279 |  |
| 2023 |  | 191 |  |
| 2024 |  | 143 |  |
| 2025 |  | 91 |  |
| After 2025 |  | 235 |  |
| Total operating lease payments |  | 1,291 |  |
| Less: interest |  | (84) |  |
| Present value of lease payments |  | $ | 1,207 |  |

[0000833444-20-000048:notes:153]
As previously disclosed in the Company's Annual Report on Form 10-K for the year ended September 30, 2019 and accounted for under the previous lease accounting guidance, future minimum operating lease payments for long-term noncancellable operating leases as of September 30, 2019 were as follows (in millions):

[0000833444-20-000048:notes:154]
|  |  | September 30, 2019 |
| 2020 |  | $ | 352 |  |
| 2021 |  | 287 |  |
| 2022 |  | 200 |  |
| 2023 |  | 111 |  |
| 2024 |  | 71 |  |
| After 2024 |  | 172 |  |
| Total minimum lease payments |  | $ | 1,193 |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-20-000048:notes:155]
DEBT AND FINANCING ARRANGEMENTS
Short-term debt consisted of the following (in millions):

[0000833444-20-000048:notes:156]
|  | September 30, |
|  | 2020 |  | 2019 |
| Bank borrowings | $ | 31 |  |  | $ | 10 |  |
| Weighted average interest rate on short-term debt outstanding | 3.4 | % |  | 2.0 | % |

[0000833444-20-000048:notes:157]
The Company had no commercial paper outstanding as of September 30, 2020 and 2019.

[0000833444-20-000048:notes:158]
In December 2019, the Company entered into a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2020.  Additionally, the Company terminated its syndicated 5-year $2 billion committed revolving credit facility and four 364-day revolving credit facilities with total committed capacity of $750 million.  As of September 30, 2020, there were no draws on the revolving credit facilities.

[0000833444-20-000048:notes:159]
Long-term debt consisted of the following (in millions; due dates by fiscal year):

[0000833444-20-000048:notes:160]
|  | September 30, |
|  | 2020 |  | 2019 |
| Unsecured notes |  |  |  |
| JCI plc - 5.00% due in 2020 ($453 million par value) | $ | — |  |  | $ | 453 |  |
| JCI Inc. - 5.00% due in 2020 ($47 million par value) | — |  |  | 47 |  |
| JCI plc - 0.00% due in 2021 (€750 million par value) | — |  |  | 818 |  |
| JCI plc - 4.25% due in 2021 ($204 million par value) | 204 |  |  | 204 |  |
| JCI Inc. - 4.25% due in 2021 ($53 million par value) | 53 |  |  | 53 |  |
| JCI plc - 3.75% due in 2022 ($171 million par value) | 171 |  |  | 171 |  |
| JCI Inc. - 3.75% due in 2022 ($22 million par value) | 22 |  |  | 22 |  |
| JCI plc - 4.625% due in 2023 ($25 million par value) | 26 |  |  | 26 |  |
| Tyco International Finance S.A. ("TIFSA") - 4.625% due in 2023 ($7 million par value) | 7 |  |  | 7 |  |
| JCI plc - 1.00% due in 2023 (€888 million par value) | 1,039 |  |  | 967 |  |
| JCI plc - 3.625% due in 2024 ($453 million par value) | 453 |  |  | 453 |  |
| JCI Inc. - 3.625% due in 2024 ($31 million par value) | 31 |  |  | 31 |  |
| JCI plc - 1.375% due in 2025 (€423 million par value) | 503 |  |  | 471 |  |
| TIFSA - 1.375% due in 2025 (€54 million par value) | 64 |  |  | 60 |  |
| JCI plc - 3.90% due in 2026 ($487 million par value) | 516 |  |  | 521 |  |
| TIFSA - 3.90% due in 2026 ($51 million par value) | 51 |  |  | 51 |  |
| JCI plc and Tyco Fire & Security Finance S.C.A. ("TFSCA") - 0.375% due in 2027 (€500 million par value) | 583 |  |  | — |  |
| JCI plc and TFSCA - 1.75% due in 2030 ($625 million par value) | 623 |  |  | — |  |
| JCI plc and TFSCA - 1.00% due in 2032 (€500 million par value) | 584 |  |  | — |  |
| JCI plc - 6.00% due in 2036 ($342 million par value) | 339 |  |  | 339 |  |
| JCI Inc. - 6.00% due in 2036 ($8 million par value) | 8 |  |  | 8 |  |
| JCI plc - 5.70% due in 2041 ($190 million par value) | 189 |  |  | 189 |  |
| JCI Inc. - 5.70% due in 2041 ($30 million par value) | 30 |  |  | 30 |  |
| JCI plc - 5.25% due in 2042 ($155 million par value) | 155 |  |  | 155 |  |
| JCI Inc. - 5.25% due in 2042 ($6 million par value) | 6 |  |  | 6 |  |
| JCI plc - 4.625% due in 2044 ($444 million par value) | 441 |  |  | 441 |  |
| JCI Inc. - 4.625% due in 2044 ($6 million par value) | 6 |  |  | 6 |  |
| JCI plc - 5.125% due in 2045 ($477 million par value) | 564 |  |  | 567 |  |
| TIFSA - 5.125% due in 2045 ($23 million par value) | 22 |  |  | 22 |  |
| JCI plc - 6.95% due in 2046 ($32 million par value) | 32 |  |  | 32 |  |
| JCI Inc. - 6.95% due in 2046 ($4 million par value) | 4 |  |  | 4 |  |
| JCI plc - 4.50% due in 2047 ($500 million par value) | 496 |  |  | 496 |  |
| JCI plc - 4.95% due in 2064 ($341 million par value) | 340 |  |  | 340 |  |
| JCI Inc. - 4.95% due in 2064 ($15 million par value) | 15 |  |  | 15 |  |
| JCI plc - Term Loan - ¥25 billion; LIBOR JPY plus 0.40% due in 2022 | 237 |  |  | 232 |  |
| Other | 8 |  |  | 3 |  |
| Gross long-term debt | 7,822 |  |  | 7,240 |  |
| Less: current portion | 262 |  |  | 501 |  |
| Less: debt issuance costs | 34 |  |  | 31 |  |
| Net long-term debt | $ | 7,526 |  |  | $ | 6,708 |  |

[0000833444-20-000048:notes:161]
The installments of long-term debt maturing in subsequent fiscal years are: 2021 - $262 million; 2022 - $432 million; 2023 - $1,073 million; 2024 - $484 million; 2025 - $567 million; 2026 and thereafter - $5,004 million. The Company’s long-term debt includes various financial covenants, none of which are expected to restrict future operations.

[0000833444-20-000048:notes:162]
Total interest paid on both short and long-term debt for continuing operations for the fiscal years ended September 30, 2020, 2019 and 2018 was $247 million, $369 million and $401 million, respectively.

[0000833444-20-000048:notes:163]
Financing Arrangements

[0000833444-20-000048:notes:164]
In September 2020, the Company and its wholly owned subsidiary, TFSCA issued €500 million aggregate principal amount of their 0.375% Senior Notes due 2027 and €500 million aggregate principal amount of their 1.000% Senior Notes due 2032. A portion of the proceeds were used to repay €750 million of notes which were due in December 2020 and the short-term debt which was issued in April 2020, including $675 million of European financing arrangements which were due in September 2020 and $275 million of bank term loans which were due in April 2021. The remainder of the proceeds is to be used for general corporate purposes.  In July 2020, the Company repaid $300 million of a bank term loan that was issued in April 2020.

[0000833444-20-000048:notes:165]
In September 2020, the Company and its wholly owned subsidiary, TFSCA issued $625 million of green bonds with an interest rate of 1.750% which are due in 2030. The net proceeds are being used to support projects that focus on sustainability and support the Company's 2025 sustainability goals.

[0000833444-20-000048:notes:166]
In March 2020, the Company retired $500 million in principal amount, plus accrued interest, of its 5.0% fixed rate notes that expired in March 2020.

[0000833444-20-000048:notes:167]
Net Financing Charges

[0000833444-20-000048:notes:168]
The Company's net financing charges line item in the consolidated statements of income for the years ended September 30, 2020, 2019 and 2018 contained the following components (in millions):

[0000833444-20-000048:notes:169]
|  | Year Ended September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Interest expense, net of capitalized interest costs | $ | 240 |  |  | $ | 335 |  |  | $ | 409 |  |
| Banking fees and bond cost amortization | 26 |  |  | 28 |  |  | 30 |  |
| Loss on debt extinguishment | — |  |  | 60 |  |  | — |  |
| Interest income | (23) |  |  | (61) |  |  | (13) |  |
| Net foreign exchange results for financing activities | (12) |  |  | (12) |  |  | (25) |  |
| Net financing charges | $ | 231 |  |  | $ | 350 |  |  | $ | 401 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-20-000048:notes:170]
DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES
The Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities, stock-based compensation liabilities and interest rates. Under Company policy, the use of derivatives is restricted to those intended for hedging purposes; the use of any derivative instrument for speculative purposes is strictly prohibited. A description of each type of derivative utilized by the Company to manage risk is included in the following paragraphs. In addition, refer to Note 11, "Fair Value Measurements," of the notes to consolidated financial statements for information related to the fair value measurements and valuation methods utilized by the Company for each derivative type.

[0000833444-20-000048:notes:171]
Cash Flow Hedges

[0000833444-20-000048:notes:172]
The Company has global operations and participates in foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange hedge contracts. The Company hedges 70% to 90% of the notional amount of each of its known foreign exchange transactional exposures.

[0000833444-20-000048:notes:173]
The Company selectively hedges anticipated transactions that are subject to commodity price risk, primarily using commodity hedge contracts, to minimize overall price risk associated with the Company’s purchases of copper and aluminum in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks

[0000833444-20-000048:notes:174]
are systematically managed pursuant to policy guidelines. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities.

[0000833444-20-000048:notes:175]
As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the fiscal years ended September 30, 2020 and 2019.

[0000833444-20-000048:notes:176]
The Company had the following outstanding contracts to hedge forecasted commodity purchases (in metric tons):

[0000833444-20-000048:notes:177]
|  |  | Volume Outstanding as of |
| Commodity |  | September 30, 2020 |  | September 30, 2019 |
| Copper |  | 2,497 |  |  | 3,561 |  |
| Aluminum |  | 3,036 |  |  | 2,967 |  |

[0000833444-20-000048:notes:178]
Net Investment Hedges

[0000833444-20-000048:notes:179]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company’s net investments globally. At September 30, 2020, the Company had 888 million euro, 500 million euro, 500 million euro, 423 million euro and 54 million euro in bonds designated as net investment hedges in the Company's net investment in Europe and 25 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan. At September 30, 2019, the Company had 888 million euro, 750 million euro, 423 million euro and 54 million euro in bonds designated as net investment hedges in the Company's net investment in Europe and 25 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan.

[0000833444-20-000048:notes:180]
Derivatives Not Designated as Hedging Instruments

[0000833444-20-000048:notes:181]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount. As of September 30, 2020 and 2019, the Company hedged approximately 1.4 million of its ordinary shares, which have a cost basis of $60 million.

[0000833444-20-000048:notes:182]
The Company also holds certain foreign currency forward contracts for which hedge accounting treatment was not elected. The change in fair value of foreign currency exchange derivatives not designated as hedging instruments under ASC 815 are recorded in the consolidated statements of income.

[0000833444-20-000048:notes:183]
Fair Value of Derivative Instruments

[0000833444-20-000048:notes:184]
The following table presents the location and fair values of derivative instruments and hedging activities included in the Company’s consolidated statements of financial position (in millions):

[0000833444-20-000048:notes:185]
|  | Derivatives and Hedging ActivitiesDesignated as Hedging Instrumentsunder ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instrumentsunder ASC 815 |
|  | September 30, 2020 |  | September 30, 2019 |  | September 30, 2020 |  | September 30, 2019 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 10 |  |  | $ | 16 |  |  | $ | 17 |  |  | $ | 19 |  |
| Commodity derivatives | 2 |  |  | — |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Equity swap | — |  |  | — |  |  | 58 |  |  | 62 |  |
| Total assets | $ | 12 |  |  | $ | 16 |  |  | $ | 75 |  |  | $ | 81 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 10 |  |  | $ | 23 |  |  | $ | — |  |  | $ | — |  |
| Commodity derivatives | — |  |  | 1 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 3,010 |  |  | 2,544 |  |  | — |  |  | — |  |
| Total liabilities | $ | 3,020 |  |  | $ | 2,568 |  |  | $ | — |  |  | $ | — |  |

[0000833444-20-000048:notes:186]
Counterparty Credit Risk

[0000833444-20-000048:notes:187]
The use of derivative financial instruments exposes the Company to counterparty credit risk. The Company has established policies and procedures to limit the potential for counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association ("ISDA") master netting agreements with substantially all of its counterparties. The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position.

[0000833444-20-000048:notes:188]
The Company's derivative contracts do not contain any credit risk related contingent features and do not require collateral or other security to be furnished by the Company or the counterparties. The Company's exposure to credit risk associated with its derivative instruments is measured on an individual counterparty basis, as well as by groups of counterparties that share similar attributes. The Company does not anticipate any non-performance by any of its counterparties, and the concentration of risk with financial institutions does not present significant credit risk to the Company.

[0000833444-20-000048:notes:189]
The gross and net amounts of derivative assets and liabilities were as follows (in millions):

[0000833444-20-000048:notes:190]
|  | Fair Value of Assets |  | Fair Value of Liabilities |
|  | September 30, 2020 |  | September 30, 2019 |  | September 30, 2020 |  | September 30, 2019 |  |
| Gross amount recognized | $ | 87 |  |  | $ | 97 |  |  | $ | 3,020 |  |  | $ | 2,568 |  |  |
| Gross amount eligible for offsetting | (10) |  |  | (11) |  |  | (10) |  |  | (11) |  |  |
| Net amount | $ | 77 |  |  | $ | 86 |  |  | $ | 3,010 |  |  | $ | 2,557 |  |  |

[0000833444-20-000048:notes:191]
Derivatives Impact on the Statements of Income and Statements of Comprehensive Income

[0000833444-20-000048:notes:192]
The following table presents the pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges for the fiscal years ended September 30, 2020, 2019 and 2018 (in millions):

[0000833444-20-000048:notes:193]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Year Ended September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Foreign currency exchange derivatives |  | $ | 1 |  |  | $ | 2 |  |  | $ | 2 |  |
| Commodity derivatives |  | 6 |  |  | (4) |  |  | (14) |  |
| Total |  | $ | 7 |  |  | $ | (2) |  |  | $ | (12) |  |

[0000833444-20-000048:notes:194]
The following table presents the location and amount of the pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income for the fiscal years ended September 30, 2020, 2019 and 2018 (in millions):

[0000833444-20-000048:notes:195]
| Derivatives in ASC 815 Cash FlowHedging Relationships |  | Location of Gain (Loss)Reclassified from AOCI into Income |  | Year Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (5) |  |  | $ | 4 |  |  | $ | 2 |  |
| Foreign currency exchange derivatives |  | Income from discontinued operations |  | — |  |  | — |  |  | 2 |  |
| Commodity derivatives |  | Cost of sales |  | 2 |  |  | (4) |  |  | 5 |  |
| Commodity derivatives |  | Income from discontinued operations |  | — |  |  | (10) |  |  | 7 |  |
| Total |  |  |  | $ | (3) |  |  | $ | (10) |  |  | $ | 16 |  |

[0000833444-20-000048:notes:196]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income for the fiscal years ended September 30, 2020, 2019 and 2018 (in millions):

[0000833444-20-000048:notes:197]
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Year Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (1) |  |  | $ | (8) |  |  | $ | 4 |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | 87 |  |  | (60) |  |  | 42 |  |
| Foreign currency exchange derivatives |  | Income tax provision |  | — |  |  | (1) |  |  | (4) |  |
| Foreign currency exchange derivatives |  | Income from discontinued operations |  | — |  |  | 52 |  |  | (7) |  |
| Equity swap |  | Selling, general and administrative |  | (4) |  |  | 14 |  |  | (8) |  |
| Total |  |  |  | $ | 82 |  |  | $ | (3) |  |  | $ | 27 |  |

[0000833444-20-000048:notes:198]
The pre-tax gains (losses) recorded in foreign currency translation adjustment ("CTA") within other comprehensive income (loss) related to net investment hedges were $(172) million, $145 million and $45 million for the years ended September 30, 2020, 2019 and 2018, respectively. For the years ended September 30, 2020, 2019 and 2018, no gains or losses were reclassified from CTA into income for the Company’s outstanding net investment hedges.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-20-000048:notes:199]
FAIR VALUE MEASUREMENTS
ASC 820, "Fair Value Measurement," defines fair value as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. ASC 820 also establishes a three-level fair value hierarchy that prioritizes information used in developing assumptions when pricing an asset or liability as follows:

[0000833444-20-000048:notes:200]
Level 1: Observable inputs such as quoted prices in active markets for identical assets or liabilities;

[0000833444-20-000048:notes:201]
Level 2: Quoted prices in active markets for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active, or inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and

[0000833444-20-000048:notes:202]
Level 3: Unobservable inputs where there is little or no market data, which requires the reporting entity to develop its own assumptions.

[0000833444-20-000048:notes:203]
ASC 820 requires the use of observable market data, when available, in making fair value measurements. When inputs used to measure fair value fall within different levels of the hierarchy, the level within which the fair value measurement is categorized is based on the lowest level input that is significant to the fair value measurement.

[0000833444-20-000048:notes:204]
Recurring Fair Value Measurements

[0000833444-20-000048:notes:205]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value as of September 30, 2020 and 2019 (in millions):

[0000833444-20-000048:notes:206]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2020 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 27 |  |  | $ | — |  |  | $ | 27 |  |  | $ | — |  |
| Exchange traded funds (fixed income)1 | 19 |  |  | 19 |  |  | — |  |  | — |  |
| Commodity derivatives | 2 |  |  | — |  |  | 2 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 63 |  |  | 63 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 143 |  |  | 143 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 129 |  |  | 129 |  |  | — |  |  | — |  |
| Equity swap | 58 |  |  | — |  |  | 58 |  |  | — |  |
| Total assets | $ | 441 |  |  | $ | 354 |  |  | $ | 87 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |
| Total liabilities | $ | 10 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |

[0000833444-20-000048:notes:207]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2019 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 35 |  |  | $ | — |  |  | $ | 35 |  |  | $ | — |  |
| Exchange traded funds (fixed income)1 | 19 |  |  | 19 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 71 |  |  | 71 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 138 |  |  | 138 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 116 |  |  | 116 |  |  | — |  |  | — |  |
| Equity swap | 62 |  |  | — |  |  | 62 |  |  | — |  |
| Total assets | $ | 441 |  |  | $ | 344 |  |  | $ | 97 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Total liabilities | $ | 24 |  |  | $ | — |  |  | $ | 24 |  |  | $ | — |  |

[0000833444-20-000048:notes:208]
1Classified as restricted investments for payment of asbestos liabilities. See Note 22, "Commitments and Contingencies" of the notes to consolidated financial statements for further details.

[0000833444-20-000048:notes:209]
Valuation Methods

[0000833444-20-000048:notes:210]
Foreign currency exchange derivatives: The foreign currency exchange derivatives are valued under a market approach using publicized spot and forward prices.

[0000833444-20-000048:notes:211]
Commodity derivatives: The commodity derivatives are valued under a market approach using publicized prices, where available, or dealer quotes.

[0000833444-20-000048:notes:212]
Equity swaps: The equity swaps are valued under a market approach as the fair value of the swaps is equal to the Company’s stock price at the reporting period date.

[0000833444-20-000048:notes:213]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices. Unrealized gains (losses) on the deferred compensation plan assets are recognized in the consolidated statements of income where they offset unrealized gains and losses on the related deferred compensation plan liability.

[0000833444-20-000048:notes:214]
Investments in exchange traded funds: Investments in exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. Refer to Note 22, "Commitments and Contingencies," of the notes to consolidated financial statements for further information.

[0000833444-20-000048:notes:215]
The following table presents the portion of unrealized gains (losses) recognized in the consolidated statements of income for the years ended September 30, 2020 and 2019 that relate to equity securities still held at September 30, 2020 and 2019 (in millions):

[0000833444-20-000048:notes:216]
|  |  | Year Ended September 30, |  |
|  | 2020 |  | 2019 |  |
| Deferred compensation plan assets |  | $ | 1 |  |  | $ | (2) |  |  |
| Investments in exchange traded funds |  | 21 |  |  | 12 |  |  |

[0000833444-20-000048:notes:217]
All of the gains and losses on investments in exchange traded funds related to restricted investments. 
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. At September 30, 2020, the fair value of long-term debt was $8.6 billion, including public debt of $8.4 billion and other long-term debt of $0.2 billion. At September 30, 2019, the fair value of long-term debt was $7.6 billion, including public debt of $7.4 billion and other long-term debt of $0.2 billion. The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy.  The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-20-000048:notes:218]
STOCK-BASED COMPENSATION
The Johnson Controls International plc 2012 Share and Incentive Plan (the "Plan"), as amended in September 2016, authorizes stock options, stock appreciation rights, restricted (non-vested) stock/units, performance shares, performance units and other stock-based awards. The Compensation Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. As of September 30, 2020, there were 76 million shares of the Company's common stock reserved and 27 million shares available for issuance under the Plan.

[0000833444-20-000048:notes:219]
The Company has four share-based compensation plans, which are described below. For the fiscal years ended September 30, 2020, 2019 and 2018, compensation cost charged against income for continuing operations, excluding the offsetting impact of outstanding equity swaps, for those plans was approximately $66 million, $103 million and $89 million, respectively, all of which was recorded in selling, general and administrative expenses.

[0000833444-20-000048:notes:220]
The total income tax benefit recognized for continuing operations in the consolidated statements of income for share-based compensation arrangements was approximately $16 million, $26 million and $22 million for the fiscal years ended September 30, 2020, 2019 and 2018, respectively.  The tax impact from the exercise and vesting of equity settled awards was less than $1 million of tax benefit, $6 million of tax expense and $3 million of tax expense for the fiscal years ended September 30, 2020,

[0000833444-20-000048:notes:221]
2019 and 2018, respectively. The Company does not settle stock options granted under share-based payment arrangements to cash.

[0000833444-20-000048:notes:222]
Stock Options

[0000833444-20-000048:notes:223]
Stock options are granted with an exercise price equal to the market price of the Company’s stock at the date of grant. Stock option awards typically vest between two and three years after the grant date and expire ten years from the grant date.

[0000833444-20-000048:notes:224]
The fair value of each option is estimated on the date of grant using a Black-Scholes option valuation model that uses the assumptions noted in the following table. The expected life of options represents the period of time that options granted are expected to be outstanding, assessed separately for executives and non-executives. The risk-free interest rate for periods during the contractual life of the option is based on the U.S. Treasury yield curve in effect at the time of grant. Expected volatility is based on the historical volatility of the Company's stock since October 2016 blended with the historical volatility of certain peer companies' stock prior to October 2016 over the most recent period corresponding to the expected life as of the grant date. The expected dividend yield is based on the expected annual dividend as a percentage of the market value of the Company’s ordinary shares as of the grant date. The Company uses historical data to estimate option exercises and employee terminations within the valuation model.

[0000833444-20-000048:notes:225]
|  | Year Ended September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Expected life of option (years) | 6.5 |  | 6.4 |  | 6.5 |
| Risk-free interest rate | 1.67% |  | 2.77% |  | 2.28% |
| Expected volatility of the Company’s stock | 22.40% |  | 21.80% |  | 23.70% |
| Expected dividend yield on the Company’s stock | 2.49% |  | 3.29% |  | 2.78% |

[0000833444-20-000048:notes:226]
A summary of stock option activity at September 30, 2020, and changes for the year then ended, is presented below:

[0000833444-20-000048:notes:227]
|  | WeightedAverageOption Price |  | SharesSubject toOption |  | WeightedAverageRemainingContractualLife (years) |  | AggregateIntrinsicValue(in millions) |
| Outstanding, September 30, 2019 | $ | 35.07 |  |  | 12,369,749 |  |  |  |  |  |
| Granted | 41.67 |  |  | 1,347,310 |  |  |  |  |  |
| Exercised | 28.80 |  |  | (2,504,516) |  |  |  |  |  |
| Forfeited or expired | 38.30 |  |  | (1,097,638) |  |  |  |  |  |
| Outstanding, September 30, 2020 | $ | 37.14 |  |  | 10,114,905 |  |  | 4.9 |  | $ | 46 |  |
| Exercisable, September 30, 2020 | $ | 36.98 |  |  | 7,473,203 |  |  | 3.6 |  | $ | 36 |  |

[0000833444-20-000048:notes:228]
The weighted-average grant-date fair value of options granted during the fiscal years ended September 30, 2020, 2019 and 2018 was $7.29, $5.56 and $7.04, respectively.

[0000833444-20-000048:notes:229]
The total intrinsic value of options exercised during the fiscal years ended September 30, 2020, 2019 and 2018 was approximately $30 million, $73 million and $38 million, respectively.

[0000833444-20-000048:notes:230]
In conjunction with the exercise of stock options, the Company received cash payments for the fiscal years ended September 30, 2020, 2019 and 2018 of approximately $75 million, $171 million and $66 million, respectively.

[0000833444-20-000048:notes:231]
At September 30, 2020, the Company had approximately $9 million of total unrecognized compensation cost related to non-vested stock options granted for continuing operations which is expected to be recognized over a weighted-average period of 1.8 years.

[0000833444-20-000048:notes:232]
Stock Appreciation Rights ("SARs")

[0000833444-20-000048:notes:233]
SARs vest under the same terms and conditions as stock option awards; however, they are settled in cash for the difference between the market price on the date of exercise and the exercise price. As a result, SARs are recorded in the Company’s consolidated statements of financial position as a liability until the date of exercise.

[0000833444-20-000048:notes:234]
The fair value of each SAR award is estimated using a similar method described for stock options. The fair value of each SAR award is recalculated at the end of each reporting period and the liability and expense are adjusted based on the new fair value.

[0000833444-20-000048:notes:235]
The assumptions used to determine the fair value of the SAR awards at September 30, 2020 were as follows:

[0000833444-20-000048:notes:236]
| Expected life of SAR (years) | 0.4 - 2.5 |
| Risk-free interest rate | 0.11% - 0.18% |
| Expected volatility of the Company’s stock | 22.40% |
| Expected dividend yield on the Company’s stock | 2.49% |

[0000833444-20-000048:notes:237]
A summary of SAR activity at September 30, 2020, and changes for the year then ended, is presented below:

[0000833444-20-000048:notes:238]
|  | WeightedAverageSAR Price |  | SharesSubject toSAR |  | WeightedAverageRemainingContractualLife (years) |  | AggregateIntrinsicValue(in millions) |
| Outstanding, September 30, 2019 | $ | 28.67 |  |  | 368,009 |  |  |  |  |  |
| Exercised | 26.88 |  |  | (129,277) |  |  |  |  |  |
| Forfeited or expired | 25.47 |  |  | (26,095) |  |  |  |  |  |
| Outstanding, September 30, 2020 | $ | 30.14 |  |  | 212,637 |  |  | 1.8 |  | $ | 2 |  |
| Exercisable, September 30, 2020 | $ | 30.14 |  |  | 212,637 |  |  | 1.8 |  | $ | 2 |  |

[0000833444-20-000048:notes:239]
In conjunction with the exercise of SARs granted, the Company made payments of $2 million, $3 million and $3 million during the fiscal years ended September 30, 2020, 2019 and 2018, respectively.

[0000833444-20-000048:notes:240]
Restricted (Non-vested) Stock / Units

[0000833444-20-000048:notes:241]
Restricted stock or restricted stock units are typically share settled unless the employee is a non-U.S. employee or elects to defer settlement until retirement at which point the award would be settled in cash. Restricted awards typically vest over a period of three years from the grant date. The Plan allows for different vesting terms on specific grants with approval by the Board of Directors. The fair value of each share-settled restricted award is based on the closing market value of the Company’s ordinary shares on the date of grant. The fair value of each cash-settled restricted award is recalculated at the end of each reporting period based on the closing market value of the Company's ordinary shares at the end of the reporting period, and the liability and expense are adjusted based on the new fair value.

[0000833444-20-000048:notes:242]
A summary of non-vested restricted stock awards at September 30, 2020, and changes for the fiscal year then ended, is presented below:

[0000833444-20-000048:notes:243]
|  | WeightedAveragePrice |  | Shares/UnitsSubject toRestriction |
| Non-vested, September 30, 2019 | $ | 35.98 |  |  | 3,333,076 |  |
| Granted | 41.38 |  |  | 2,053,292 |  |
| Vested | 37.39 |  |  | (1,634,306) |  |
| Forfeited | 37.47 |  |  | (522,183) |  |
| Non-vested, September 30, 2020 | $ | 38.58 |  |  | 3,229,879 |  |

[0000833444-20-000048:notes:244]
At September 30, 2020, the Company had approximately $81 million of total unrecognized compensation cost related to non-vested restricted stock arrangements granted for continuing operations which is expected to be recognized over a weighted-average period of 2.1 years.

[0000833444-20-000048:notes:245]
Performance Share Awards

[0000833444-20-000048:notes:246]
Performance-based share unit ("PSU") awards are generally contingent on the achievement of predetermined performance goals over a performance period of three years as well as on the award holder's continuous employment until the vesting date. The PSUs are also indexed to the achievement of specified levels of total shareholder return versus a peer group over the performance period. Each PSU that is earned is settled with shares of the Company's ordinary shares following the completion of the performance period, unless the award holder elected to defer a portion or all of the award until retirement which would then be settled in cash.

[0000833444-20-000048:notes:247]
The fair value of each PSU is estimated on the date of grant using a Monte Carlo simulation that uses the assumptions noted in the following table. The risk-free interest rate for periods during the contractual life of the PSU is based on the U.S. Treasury yield curve in effect at the time of grant. For fiscal 2020, the expected volatility is based on the historical volatility of the Company's stock over the most recent three-year period as of the grant date. For fiscal 2019 and 2018, the expected volatility is based on the historical volatility of the Company's stock since October 2016 blended with the historical volatility of certain peer companies' stock prior to October 2016 over the most recent three-year period as of the grant date.

[0000833444-20-000048:notes:248]
|  | Year Ended September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Risk-free interest rate | 1.60% |  | 2.76% |  | 1.92% |
| Expected volatility of the Company’s stock | 21.80% |  | 22.90% |  | 21.70% |

[0000833444-20-000048:notes:249]
A summary of the status of the Company’s non-vested PSUs at September 30, 2020, and changes for the fiscal year then ended, is presented below:

[0000833444-20-000048:notes:250]
|  | WeightedAveragePrice |  | Shares/UnitsSubject toPSU |
| Non-vested, September 30, 2019 | $ | 39.82 |  |  | 1,825,519 |  |
| Granted | 42.48 |  |  | 476,939 |  |
| Vested | 44.98 |  |  | (515,975) |  |
| Forfeited | 38.87 |  |  | (168,539) |  |
| Non-vested, September 30, 2020 | $ | 39.06 |  |  | 1,617,944 |  |

[0000833444-20-000048:notes:251]
At September 30, 2020, the Company had approximately $25 million of total unrecognized compensation cost related to non-vested performance-based share unit awards granted for continuing operations which is expected to be recognized over a weighted-average period of 1.8 years.


## us-gaap:EarningsPerShareTextBlock

[0000833444-20-000048:notes:252]
EARNINGS PER SHAREThe Company presents both basic and diluted EPS amounts. Basic EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares outstanding during the reporting period. Diluted EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares and ordinary equivalent shares outstanding during the reporting period that are calculated using the treasury stock method for stock options, unvested restricted stock and unvested performance share awards. The treasury stock method assumes that the Company uses the proceeds from the exercise of stock option awards to repurchase ordinary shares at the average market price during the period. The assumed proceeds under the treasury stock method include the purchase price that the grantee will pay in the future and compensation cost for future service that the Company has not yet recognized. For unvested restricted stock and unvested performance share awards, assumed proceeds under the treasury stock method include unamortized compensation cost.
The following table reconciles the numerators and denominators used to calculate basic and diluted earnings per share (in millions):

[0000833444-20-000048:notes:253]
|  | Year Ended September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Income Available to Ordinary Shareholders |  |  |  |  |  |
| Income from continuing operations | $ | 631 |  |  | $ | 1,100 |  |  | $ | 1,175 |  |
| Income from discontinued operations | — |  |  | 4,574 |  |  | 987 |  |
| Basic and diluted income available to shareholders | $ | 631 |  |  | $ | 5,674 |  |  | $ | 2,162 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |
| Basic weighted average shares outstanding | 751.0 |  |  | 870.2 |  |  | 925.7 |  |
| Effect of dilutive securities: |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 2.6 |  |  | 4.1 |  |  | 6.0 |  |
| Diluted weighted average shares outstanding | 753.6 |  |  | 874.3 |  |  | 931.7 |  |
| Antidilutive Securities |  |  |  |  |  |
| Options to purchase shares | 1.4 |  |  | 1.4 |  |  | 1.5 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-20-000048:notes:254]
EQUITY AND NONCONTROLLING INTERESTS
Dividends

[0000833444-20-000048:notes:255]
The authority to declare and pay dividends is vested in the Board of Directors. The timing, declaration and payment of future dividends to holders of the Company's ordinary shares is determined by the Company's Board of Directors and depends upon many factors, including the Company's financial condition and results of operations, the capital requirements of the Company's businesses, industry practice and any other relevant factors.

[0000833444-20-000048:notes:256]
Under Irish law, dividends may only be paid (and share repurchases and redemptions must generally be funded) out of "distributable reserves." The creation of distributable reserves was accomplished by way of a capital reduction, which the Irish High Court approved on December 18, 2014 and as acquired in conjunction with the Merger.

[0000833444-20-000048:notes:257]
Share Repurchase Program

[0000833444-20-000048:notes:258]
In March 2019, the Company's Board of Directors approved an $8.5 billion increase to its existing share repurchase authorization, subject to the completion of the previously announced sale of the Company's Power Solutions business, which closed on April 30, 2019. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. As of September 30, 2020, approximately $2.4 billion remains available under the share repurchase program.

[0000833444-20-000048:notes:259]
During fiscal year 2020, the Company repurchased and retired approximately $2,204 million of its ordinary shares. During fiscal year 2019, the Company repurchased approximately $5,983 million of its ordinary shares, of which $4,035 million of its ordinary shares were purchased through a publicly announced "modified Dutch auction" tender offer and immediately retired, and $1,948 million of its ordinary shares were purchased on an open market and retired in the fourth quarter of fiscal 2019. During fiscal year 2018, the Company repurchased approximately $300 million of its ordinary shares.

[0000833444-20-000048:notes:260]
Other comprehensive income includes activity relating to discontinued operations. The following schedules present changes in consolidated equity attributable to Johnson Controls and noncontrolling interests (in millions, net of tax):

[0000833444-20-000048:notes:261]
|  | Equity Attributable to Johnson ControlsInternational plc |  | Equity Attributable to Noncontrolling Interests |  | Total Equity |
| At September 30, 2017 | $ | 20,447 |  |  | $ | 920 |  |  | $ | 21,367 |  |
| Total comprehensive income (loss): |  |  |  |  |  |
| Net income | 2,162 |  |  | 186 |  |  | 2,348 |  |
| Foreign currency translation adjustments | (458) |  |  | (22) |  |  | (480) |  |
| Realized and unrealized losses on derivatives | (19) |  |  | (1) |  |  | (20) |  |
| Realized and unrealized gains on marketable securities | 4 |  |  | — |  |  | 4 |  |
| Other comprehensive loss | (473) |  |  | (23) |  |  | (496) |  |
| Comprehensive income | 1,689 |  |  | 163 |  |  | 1,852 |  |
| Other changes in equity: |  |  |  |  |  |
| Cash dividends - ordinary shares ($1.04 per share) | (968) |  |  | — |  |  | (968) |  |
| Dividends attributable to noncontrolling interests | — |  |  | (43) |  |  | (43) |  |
| Repurchases of ordinary shares | (300) |  |  | — |  |  | (300) |  |
| Change in noncontrolling interest share | — |  |  | 23 |  |  | 23 |  |
| Adoption of ASU 2016-09 | 179 |  |  | — |  |  | 179 |  |
| Reclassification from redeemable noncontrolling interest | — |  |  | 231 |  |  | 231 |  |
| Other, including options exercised | 117 |  |  | — |  |  | 117 |  |
| At September 30, 2018 | 21,164 |  |  | 1,294 |  |  | 22,458 |  |
| Total comprehensive income (loss): |  |  |  |  |  |
| Net income | 5,674 |  |  | 213 |  |  | 5,887 |  |
| Foreign currency translation adjustments | (325) |  |  | (17) |  |  | (342) |  |
| Realized and unrealized gains (losses) on derivatives | 7 |  |  | (1) |  |  | 6 |  |
| Pension and postretirement plans | (6) |  |  | — |  |  | (6) |  |
| Other comprehensive loss | (324) |  |  | (18) |  |  | (342) |  |
| Comprehensive income | 5,350 |  |  | 195 |  |  | 5,545 |  |
| Other changes in equity: |  |  |  |  |  |
| Cash dividends - ordinary shares ($1.04 per share) | (887) |  |  | — |  |  | (887) |  |
| Dividends attributable to noncontrolling interests | — |  |  | (132) |  |  | (132) |  |
| Repurchases and retirements of ordinary shares | (5,983) |  |  | — |  |  | (5,983) |  |
| Divestiture of Power Solutions | 483 |  |  | (295) |  |  | 188 |  |
| Adoption of ASC 606 | (45) |  |  | — |  |  | (45) |  |
| Adoption of ASU 2016-16 | (546) |  |  | — |  |  | (546) |  |
| Other, including options exercised | 230 |  |  | 1 |  |  | 231 |  |
| At September 30, 2019 | 19,766 |  |  | 1,063 |  |  | 20,829 |  |
| Total comprehensive income: |  |  |  |  |  |
| Net income | 631 |  |  | 164 |  |  | 795 |  |
| Foreign currency translation adjustments | 7 |  |  | 18 |  |  | 25 |  |
| Realized and unrealized gains on derivatives | 4 |  |  | 4 |  |  | 8 |  |
| Pension and postretirement plans | 8 |  |  | — |  |  | 8 |  |
| Other comprehensive income | 19 |  |  | 22 |  |  | 41 |  |
| Comprehensive income | 650 |  |  | 186 |  |  | 836 |  |
| Other changes in equity: |  |  |  |  |  |
| Cash dividends - ordinary shares ($1.04 per share) | (780) |  |  | — |  |  | (780) |  |
| Dividends attributable to noncontrolling interests | — |  |  | (114) |  |  | (114) |  |
| Repurchases and retirements of ordinary shares | (2,204) |  |  | — |  |  | (2,204) |  |
| Change in noncontrolling interest share | (83) |  |  | (49) |  |  | (132) |  |
| Adoption of ASC 842 | (5) |  |  | — |  |  | (5) |  |
| Other, including options exercised | 103 |  |  | — |  |  | 103 |  |
| At September 30, 2020 | $ | 17,447 |  |  | $ | 1,086 |  |  | $ | 18,533 |  |

[0000833444-20-000048:notes:262]
The Company adopted ASC 606, "Revenue from Contracts with Customers" effective October 1, 2018. As a result, the Company recorded $45 million to beginning retained earnings, which relates primarily to deferred revenue recorded for the Power Solutions business for certain battery core returns that represent a material right provided to customers.

[0000833444-20-000048:notes:263]
The Company adopted ASU 2016-16, "Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other Than Inventory" effective October 1, 2018. As a result, the Company recognized deferred taxes of $546 million related to the tax effects of all intra-entity sales of assets other than inventory on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of October 1, 2018.

[0000833444-20-000048:notes:264]
The Company adopted ASU No. 2016-09, "Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting" effective October 1, 2017. As a result, the Company recognized deferred tax assets of $179 million related to certain operating loss carryforwards resulting from the exercise of employee stock options and restricted stock vesting on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of October 1, 2017.

[0000833444-20-000048:notes:265]
The Company consolidates certain subsidiaries in which the noncontrolling interest party has within their control the right to require the Company to redeem all or a portion of its interest in the subsidiary. The redeemable noncontrolling interests are reported at their estimated redemption value. Any adjustment to the redemption value impacts retained earnings but does not impact net income. Redeemable noncontrolling interests which are redeemable only upon future events, the occurrence of which is not currently probable, are recorded at carrying value. As of September 30, 2020 and 2019, the Company does not have any subsidiaries for which the noncontrolling interest party has within their control the right to require the Company to redeem any portion of its interests.

[0000833444-20-000048:notes:266]
The following schedules present changes in the redeemable noncontrolling interests (in millions):

[0000833444-20-000048:notes:267]
|  | Year Ended September 30, 2018 |  |
| Beginning balance, September 30 | $ | 211 |  |  |
| Net income | 35 |  |  |
| Foreign currency translation adjustments | (3) |  |  |
| Realized and unrealized losses on derivatives | (9) |  |  |
| Dividends | (3) |  |  |
| Reclassification to noncontrolling interest | (231) |  |  |
| Ending balance, September 30 | $ | — |  |  |

[0000833444-20-000048:notes:268]
The following schedules present changes in AOCI attributable to Johnson Controls (in millions, net of tax):

[0000833444-20-000048:notes:269]
|  | Year Ended September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Foreign currency translation adjustments |  |  |  |  |  |
| Balance at beginning of period | $ | (785) |  |  | $ | (939) |  |  | $ | (481) |  |
| Divestiture of Power Solutions | — |  |  | 479 |  |  | — |  |
| Aggregate adjustment for the period (net of tax effect of $1, $0 and $(3)) (1) | 7 |  |  | (325) |  |  | (458) |  |
| Balance at end of period | (778) |  |  | (785) |  |  | (939) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |  |  |
| Balance at beginning of period | (2) |  |  | (13) |  |  | 6 |  |
| Divestiture of Power Solutions (net of tax effect of $0, $1 and $0) | — |  |  | 4 |  |  | — |  |
| Current period changes in fair value (net of tax effect of $1, $(1) and $(4)) | 3 |  |  | (1) |  |  | (8) |  |
| Reclassification to income (net of tax effect of $0, $2 and $(5)) (2) | 1 |  |  | 8 |  |  | (11) |  |
| Balance at end of period | 2 |  |  | (2) |  |  | (13) |  |
| Realized and unrealized gains (losses) on marketable securities |  |  |  |  |  |
| Balance at beginning of period | — |  |  | 8 |  |  | 4 |  |
| Adoption of ASU 2016-01 (3) | — |  |  | (8) |  |  | — |  |
| Current period changes in fair value (net of tax effect of $0, $0 and $1) | — |  |  | — |  |  | 5 |  |
| Reclassification to income (net of tax effect of $0, $0 and $(1)) (4) | — |  |  | — |  |  | (1) |  |
| Balance at end of period | — |  |  | — |  |  | 8 |  |
| Pension and postretirement plans |  |  |  |  |  |
| Balance at beginning of period | (8) |  |  | (2) |  |  | (2) |  |
| Reclassification to income (net of tax effect of $(1), $0 and $0) | (1) |  |  | — |  |  | — |  |
| Other changes (net of tax effect of $4, $0 and $0) | 9 |  |  | (6) |  |  | — |  |
| Balance at end of period | — |  |  | (8) |  |  | (2) |  |
| Accumulated other comprehensive loss, end of period | $ | (776) |  |  | $ | (795) |  |  | $ | (946) |  |

[0000833444-20-000048:notes:270]
(1)   During fiscal 2018, $12 million of cumulative CTA was recognized as part of the divestiture-related gain recognized as part of the divestiture of Scott Safety.

[0000833444-20-000048:notes:271]
(2)   Refer to Note 10, "Derivative Instruments and Hedging Activities," of the notes to consolidated financial statements for disclosure of the line items in the consolidated statements of income affected by reclassifications from AOCI into income related to derivatives.

[0000833444-20-000048:notes:272]
(3)   The Company adopted ASU 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities" effective October 1, 2018 and, as a result, reclassified $8 million of unrealized gains on marketable securities to retained earnings.

[0000833444-20-000048:notes:273]
(4)  During fiscal 2018, the Company sold certain marketable common stock for approximately $3 million. As a result, the Company recorded $2 million of realized gains within selling, general and administrative expenses.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-20-000048:notes:274]
RETIREMENT PLANS
Pension Benefits

[0000833444-20-000048:notes:275]
The Company has non-contributory defined benefit pension plans covering certain U.S. and non-U.S. employees. The benefits provided are primarily based on years of service and average compensation or a monthly retirement benefit amount. Certain of the Company’s U.S. pension plans have been amended to prohibit new participants from entering the plans and no longer accrue benefits. Funding for U.S. pension plans equals or exceeds the minimum requirements of the Employee Retirement Income Security Act of 1974. Funding for non-U.S. plans observes the local legal and regulatory limits. Also, the Company makes contributions to union-trusteed pension funds for construction and service personnel.

[0000833444-20-000048:notes:276]
For pension plans with accumulated benefit obligations ("ABO") that exceed plan assets for continuing and discontinued operations, the projected benefit obligation ("PBO"), ABO and fair value of plan assets of those plans were $5,598 million, $5,539 million and $4,528 million, respectively, as of September 30, 2020 and $5,450 million, $5,388 million and $4,484 million, respectively, as of September 30, 2019.

[0000833444-20-000048:notes:277]
In fiscal 2020, total employer contributions to the defined benefit pension plans were $58 million, none of which were voluntary contributions made by the Company. The Company expects to contribute approximately $46 million in cash to its defined benefit pension plans in fiscal 2021. Projected benefit payments from the plans as of September 30, 2020 are estimated as follows (in millions):

[0000833444-20-000048:notes:278]
| 2021 | $ | 323 |  |
| 2022 | 301 |  |
| 2023 | 307 |  |
| 2024 | 309 |  |
| 2025 | 309 |  |
| 2026 - 2030 | 1,516 |  |

[0000833444-20-000048:notes:279]
Postretirement Benefits

[0000833444-20-000048:notes:280]
The Company provides certain health care and life insurance benefits for eligible retirees and their dependents primarily in the U.S. and Canada. Most non-U.S. employees are covered by government sponsored programs, and the cost to the Company is not significant.

[0000833444-20-000048:notes:281]
Eligibility for coverage is based on meeting certain years of service and retirement age qualifications. These benefits may be subject to deductibles, co-payment provisions and other limitations, and the Company has reserved the right to modify these benefits.

[0000833444-20-000048:notes:282]
The health care cost trend assumption does not have a significant effect on the amounts reported.

[0000833444-20-000048:notes:283]
In fiscal 2020, total employer contributions to the postretirement plans were $3 million. The Company expects to contribute approximately $3 million in cash to its postretirement plans in fiscal 2021 for continuing operations. Projected benefit payments from the plans as of September 30, 2020 are estimated as follows (in millions):

[0000833444-20-000048:notes:284]
| 2021 | $ | 13 |  |
| 2022 | 12 |  |
| 2023 | 12 |  |
| 2024 | 12 |  |
| 2025 | 11 |  |
| 2026 - 2030 | 45 |  |

[0000833444-20-000048:notes:285]
The Medicare Prescription Drug, Improvement and Modernization Act of 2003 ("Act") includes a prescription drug benefit under Medicare as well as a federal subsidy to sponsors of retiree health care benefit plans providing a benefit that is at least actuarially equivalent to Medicare Part D.1. Under the Act, the Medicare subsidy amount is received directly by the plan sponsor and not the related plan. Further, the plan sponsor is not required to use the subsidy amount to fund postretirement benefits and may use the subsidy for any valid business purpose. Projected subsidy receipts are estimated to be less than $1 million per year over the next ten years.

[0000833444-20-000048:notes:286]
Defined Contribution Plans

[0000833444-20-000048:notes:287]
The Company sponsors various defined contribution savings plans that allow employees to contribute a portion of their pre-tax and/or after-tax income in accordance with plan specified guidelines. Under specified conditions, the Company will contribute to certain savings plans based on predetermined percentages of compensation earned by the employee and/or will match a percentage of the employee contributions up to certain limits. The Company temporarily suspended contributions in fiscal 2020 in response to the COVID-19 pandemic. Defined contribution plan contributions charged to expense for continuing and discontinued operations amounted to $104 million, $198 million and $205 million for the fiscal years ended 2020, 2019 and 2018, respectively.

[0000833444-20-000048:notes:288]
Multiemployer Benefit Plans

[0000833444-20-000048:notes:289]
The Company contributes to multiemployer benefit plans based on obligations arising from collective bargaining agreements related to certain of its hourly employees in the U.S. These plans provide retirement benefits to participants based on their service to contributing employers. The benefits are paid from assets held in trust for that purpose. The trustees typically are responsible for determining the level of benefits to be provided to participants as well as for such matters as the investment of the assets and the administration of the plans.

[0000833444-20-000048:notes:290]
The risks of participating in these multiemployer benefit plans are different from single-employer benefit plans in the following aspects:

[0000833444-20-000048:notes:291]
•Assets contributed to the multiemployer benefit plan by one employer may be used to provide benefits to employees of other participating employers.

[0000833444-20-000048:notes:292]
•If a participating employer stops contributing to the multiemployer benefit plan, the unfunded obligations of the plan may be borne by the remaining participating employers.

[0000833444-20-000048:notes:293]
•If the Company stops participating in some of its multiemployer benefit plans, the Company may be required to pay those plans an amount based on its allocable share of the underfunded status of the plan, referred to as a withdrawal liability.

[0000833444-20-000048:notes:294]
The Company participates in approximately 280 multiemployer benefit plans, none of which are individually significant to the Company. The number of employees covered by the Company’s multiemployer benefit plans has remained consistent over the past three years, and there have been no significant changes that affect the comparability of fiscal 2020, 2019 and 2018 contributions. The Company recognizes expense for the contractually-required contribution for each period. The Company contributed $66 million, $69 million and $68 million to multiemployer benefit plans in fiscal 2020, 2019 and 2018, respectively.

[0000833444-20-000048:notes:295]
Based on the most recent information available, the Company believes that the present value of actuarial accrued liabilities in certain of these multiemployer benefit plans may exceed the value of the assets held in trust to pay benefits. Currently, the Company is not aware of any significant multiemployer benefits plans for which it is probable or reasonably possible that the Company will be obligated to make up any shortfall in funds. Moreover, if the Company were to exit certain markets or otherwise cease making contributions to these funds, the Company could trigger a withdrawal liability. Currently, the Company is not aware of any multiemployer benefit plans for which it is probable or reasonably possible that the Company will have a significant withdrawal liability. Any accrual for a shortfall or withdrawal liability will be recorded when it is probable that a liability exists and it can be reasonably estimated.

[0000833444-20-000048:notes:296]
Plan Assets

[0000833444-20-000048:notes:297]
The Company’s investment policies employ an approach whereby a mix of equities, fixed income and alternative investments are used to maximize the long-term return of plan assets for a prudent level of risk. The investment portfolio primarily contains a diversified blend of equity and fixed income investments. Equity investments are diversified across U.S. and non-U.S. stocks, as well as growth, value and small to large capitalizations. Fixed income investments include corporate and government issues, with short-, mid- and long-term maturities, with a focus on investment grade when purchased and a target duration close to that of the plan liability. Investment and market risks are measured and monitored on an ongoing basis through regular investment portfolio reviews, annual liability measurements and periodic asset/liability studies. The majority of the real estate component of the portfolio is invested in a diversified portfolio of high-quality, operating properties with cash yields greater than the targeted appreciation. Investments in other alternative asset classes, including hedge funds and commodities, diversify the expected investment returns relative to the equity and fixed income investments. As a result of the Company's diversification strategies, there are no significant concentrations of risk within the portfolio of investments.

[0000833444-20-000048:notes:298]
The Company’s actual asset allocations are in line with target allocations. The Company rebalances asset allocations as appropriate, in order to stay within a range of allocation for each asset category.

[0000833444-20-000048:notes:299]
The expected return on plan assets is based on the Company’s expectation of the long-term average rate of return of the capital markets in which the plans invest. The average market returns are adjusted, where appropriate, for active asset management returns. The expected return reflects the investment policy target asset mix and considers the historical returns earned for each asset category.

[0000833444-20-000048:notes:300]
The Company’s plan assets at September 30, 2020 and 2019, by asset category, are as follows (in millions):

[0000833444-20-000048:notes:301]
|  | Fair Value Measurements Using: |
| Asset Category | Total as of September 30, 2020 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| U.S. Pension |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 36 |  |  | $ | — |  |  | $ | 36 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 198 |  |  | 198 |  |  | — |  |  | — |  |
| Small-Cap | 255 |  |  | 255 |  |  | — |  |  | — |  |
| International - Developed | 220 |  |  | 220 |  |  | — |  |  | — |  |
| International - Emerging | 33 |  |  | 33 |  |  | — |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 382 |  |  | 159 |  |  | 223 |  |  | — |  |
| Corporate/Other | 1,386 |  |  | 1,386 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy | 2,510 |  |  | $ | 2,251 |  |  | $ | 259 |  |  | $ | — |  |
| Investments Measured at Net Asset Value, as Practical Expedient: |  |  |  |  |  |  |  |
| Real Estate Investments Measured at Net Asset Value* | 276 |  |  |  |  |  |  |  |
| Due to Broker | (80) |  |  |  |  |  |  |  |
| Total Plan Assets | $ | 2,706 |  |  |  |  |  |  |  |
| Non-U.S. Pension |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 178 |  |  | $ | 178 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 357 |  |  | 23 |  |  | 334 |  |  | — |  |
| International - Developed | 226 |  |  | 52 |  |  | 174 |  |  | — |  |
| International - Emerging | 4 |  |  | — |  |  | 4 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 704 |  |  | 64 |  |  | 640 |  |  | — |  |
| Corporate/Other | 652 |  |  | 321 |  |  | 331 |  |  | — |  |
| Hedge Fund | 49 |  |  | — |  |  | 49 |  |  | — |  |
| Real Estate | 27 |  |  | 27 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy | 2,197 |  |  | $ | 665 |  |  | $ | 1,532 |  |  | $ | — |  |
| Investments Measured at Net Asset Value, as Practical Expedient: |  |  |  |  |  |  |  |
| Real Estate Investments Measured at Net Asset Value* | 16 |  |  |  |  |  |  |  |
| Total Plan Assets | $ | 2,213 |  |  |  |  |  |  |  |
| Postretirement |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 5 |  |  | $ | 5 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 23 |  |  | — |  |  | 23 |  |  | — |  |
| Small-Cap | 7 |  |  | — |  |  | 7 |  |  | — |  |
| International - Developed | 16 |  |  | — |  |  | 16 |  |  | — |  |
| International - Emerging | 10 |  |  | — |  |  | 10 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 19 |  |  | — |  |  | 19 |  |  | — |  |
| Corporate/Other | 53 |  |  | — |  |  | 53 |  |  | — |  |
| Commodities | 12 |  |  | — |  |  | 12 |  |  | — |  |
| Real Estate | 8 |  |  | — |  |  | 8 |  |  | — |  |
| Total Plan Assets | $ | 153 |  |  | $ | 5 |  |  | $ | 148 |  |  | $ | — |  |

[0000833444-20-000048:notes:302]
|  | Fair Value Measurements Using: |
| Asset Category | Total as of September 30, 2019 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| U.S. Pension |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 55 |  |  | $ | 24 |  |  | $ | 31 |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 276 |  |  | 276 |  |  | — |  |  | — |  |
| Small-Cap | 232 |  |  | 232 |  |  | — |  |  | — |  |
| International - Developed | 266 |  |  | 233 |  |  | 33 |  |  | — |  |
| International - Emerging | 52 |  |  | 42 |  |  | 10 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 332 |  |  | 47 |  |  | 285 |  |  | — |  |
| Corporate/Other | 1,266 |  |  | 1,266 |  |  | — |  |  | — |  |
| Real Estate | 55 |  |  | 55 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy | 2,534 |  |  | $ | 2,175 |  |  | $ | 359 |  |  | $ | — |  |
| Investments Measured at Net Asset Value, as Practical Expedient: |  |  |  |  |  |  |  |
| Real Estate Investments Measured at Net Asset Value* | 202 |  |  |  |  |  |  |  |
| Total Plan Assets | $ | 2,736 |  |  |  |  |  |  |  |
| Non-U.S. Pension |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 174 |  |  | $ | 174 |  |  | $ | — |  |  | $ | — |  |
| Large-Cap | 214 |  |  | 23 |  |  | 191 |  |  | — |  |
| International - Developed | 289 |  |  | 54 |  |  | 235 |  |  | — |  |
| International - Emerging | 12 |  |  | 1 |  |  | 11 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 778 |  |  | 69 |  |  | 709 |  |  | — |  |
| Corporate/Other | 517 |  |  | 289 |  |  | 228 |  |  | — |  |
| Hedge Fund | 69 |  |  | — |  |  | 69 |  |  | — |  |
| Real Estate | 31 |  |  | 31 |  |  | — |  |  | — |  |
| Total Investments in the Fair Value Hierarchy | 2,084 |  |  | $ | 641 |  |  | $ | 1,443 |  |  | $ | — |  |
| Investments Measured at Net Asset Value, as Practical Expedient: |  |  |  |  |  |  |  |
| Real Estate Investments Measured at Net Asset Value* | 14 |  |  |  |  |  |  |  |
| Total Plan Assets | $ | 2,098 |  |  |  |  |  |  |  |
| Postretirement |  |  |  |  |  |  |  |
| Cash and Cash Equivalents | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |  | $ | — |  |
| Equity Securities |  |  |  |  |  |  |  |
| Large-Cap | 22 |  |  | — |  |  | 22 |  |  | — |  |
| Small-Cap | 8 |  |  | — |  |  | 8 |  |  | — |  |
| International - Developed | 19 |  |  | — |  |  | 19 |  |  | — |  |
| International - Emerging | 9 |  |  | — |  |  | 9 |  |  | — |  |
| Fixed Income Securities |  |  |  |  |  |  |  |
| Government | 20 |  |  | — |  |  | 20 |  |  | — |  |
| Corporate/Other | 55 |  |  | — |  |  | 55 |  |  | — |  |
| Commodities | 13 |  |  | — |  |  | 13 |  |  | — |  |
| Real Estate | 11 |  |  | — |  |  | 11 |  |  | — |  |
| Total Plan Assets | $ | 163 |  |  | $ | 6 |  |  | $ | 157 |  |  | $ | — |  |

[0000833444-20-000048:notes:303]
* The fair value of certain investments in real estate do not have a readily determinable fair value and requires the fund managers to independently arrive at fair value by calculating net asset value ("NAV") per share. In order to calculate NAV per share, the fund managers value the real estate investments using any one, or a combination of, the following methods: independent third party appraisals, discounted cash flow analysis of net cash flows projected to be generated by the investment and recent sales of comparable investments. Assumptions used to revalue the properties are updated every quarter. Due to the fact that the fund managers calculate NAV per share, the Company utilizes a practical expedient for measuring the fair value of its real-estate investments, as provided for under ASC 820, "Fair Value Measurement." In applying the practical expedient, the Company is not required to further adjust the NAV provided by the fund manager in order to determine the fair value of its investment as the NAV per share is calculated in a manner consistent with the measurement principles of ASC 946, "Financial Services - Investment Companies," and as of the Company's measurement date. The Company believes this is an appropriate methodology to obtain the fair value of these assets. For the component of the real estate portfolio under development, the investments are carried at cost until they are completed and valued by a third party appraiser. In accordance with ASU No. 2015-07, "Disclosures for Investments in Certain Entities That Calculate Net Asset Value per Share (or Its Equivalent)," investments for which fair value is measured using the net asset value per share practical expedient should be disclosed separate from the fair value hierarchy. The fair value amounts presented in this table are intended to permit reconciliation of total plan assets to the amounts presented in the notes to consolidated financial statements.

[0000833444-20-000048:notes:304]
The following is a description of the valuation methodologies used for assets measured at fair value. Certain assets are held within commingled funds which are valued at the unitized NAV or percentage of the net asset value as determined by the manager of the fund. These values are based on the fair value of the underlying net assets owned by the fund.

[0000833444-20-000048:notes:305]
Cash and Cash Equivalents: The fair value of cash is valued at cost.

[0000833444-20-000048:notes:306]
Equity Securities: The fair value of equity securities is determined by direct quoted market prices. The underlying holdings are direct quoted market prices on regulated financial exchanges.

[0000833444-20-000048:notes:307]
Fixed Income Securities: The fair value of fixed income securities is determined by direct or indirect quoted market prices. If indirect quoted market prices are utilized, the value of assets held in separate accounts is not published, but the investment managers report daily the underlying holdings. The underlying holdings are direct quoted market prices on regulated financial exchanges.

[0000833444-20-000048:notes:308]
Commodities: The fair value of the commodities is determined by quoted market prices of the underlying holdings on regulated financial exchanges.

[0000833444-20-000048:notes:309]
Hedge Funds: The fair value of hedge funds is accounted for by the custodian. The custodian obtains valuations from underlying managers based on market quotes for the most liquid assets and alternative methods for assets that do not have sufficient trading activity to derive prices. The Company and custodian review the methods used by the underlying managers to value the assets. The Company believes this is an appropriate methodology to obtain the fair value of these assets.

[0000833444-20-000048:notes:310]
Real Estate: The fair value of real estate is determined by quoted market prices of the underlying Real Estate Investment Trusts

[0000833444-20-000048:notes:311]
("REITs"), which are securities traded on an open exchange.

[0000833444-20-000048:notes:312]
The methods described above may produce a fair value calculation that may not be indicative of net realizable value or reflective of future fair values. Furthermore, while the Company believes its valuation methods are appropriate and consistent with other market participants, the use of different methodologies or assumptions to determine the fair value of certain financial instruments could result in a different fair value measurement at the reporting date.

[0000833444-20-000048:notes:313]
There were no Level 3 assets as of September 30, 2020 or 2019 or any Level 3 asset activity during fiscal 2020 or 2019.

[0000833444-20-000048:notes:314]
Funded Status

[0000833444-20-000048:notes:315]
The table that follows contains the ABO and reconciliations of the changes in the PBO, the changes in plan assets and the funded status (in millions):

[0000833444-20-000048:notes:316]
|  | Pension Benefits |  | PostretirementBenefits |
|  | U.S. Plans |  | Non-U.S. Plans |  |
| September 30, | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Accumulated Benefit Obligation | $ | 3,217 |  |  | $ | 3,115 |  |  | $ | 2,627 |  |  | $ | 2,549 |  |  | $ | — |  |  | $ | — |  |
| Change in Projected Benefit Obligation |  |  |  |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of year | $ | 3,115 |  |  | $ | 3,191 |  |  | $ | 2,652 |  |  | $ | 2,542 |  |  | $ | 174 |  |  | $ | 196 |  |
| Service cost | — |  |  | 8 |  |  | 25 |  |  | 22 |  |  | 1 |  |  | 1 |  |
| Interest cost | 67 |  |  | 108 |  |  | 36 |  |  | 54 |  |  | 4 |  |  | 6 |  |
| Plan participant contributions | — |  |  | — |  |  | 3 |  |  | 2 |  |  | 4 |  |  | 6 |  |
| Power Solutions divestiture | — |  |  | (390) |  |  | — |  |  | (86) |  |  | — |  |  | (9) |  |
| Other divestitures | — |  |  | — |  |  | (2) |  |  | (8) |  |  | — |  |  | — |  |
| Actuarial (gain) loss | 298 |  |  | 441 |  |  | 7 |  |  | 337 |  |  | (3) |  |  | 15 |  |
| Amendments made during the year | — |  |  | — |  |  | — |  |  | 26 |  |  | (13) |  |  | (19) |  |
| Benefits and settlements paid | (263) |  |  | (243) |  |  | (109) |  |  | (126) |  |  | (21) |  |  | (23) |  |
| Estimated subsidy received | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Curtailment | — |  |  | — |  |  | (8) |  |  | — |  |  | — |  |  | — |  |
| Other | — |  |  | — |  |  | 4 |  |  | (2) |  |  | — |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | 118 |  |  | (109) |  |  | (1) |  |  | — |  |
| Projected benefit obligation at end of year | $ | 3,217 |  |  | $ | 3,115 |  |  | $ | 2,726 |  |  | $ | 2,652 |  |  | $ | 146 |  |  | $ | 174 |  |
| Change in Plan Assets |  |  |  |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of year | $ | 2,736 |  |  | $ | 3,046 |  |  | $ | 2,098 |  |  | $ | 2,117 |  |  | $ | 163 |  |  | $ | 174 |  |
| Actual return on plan assets | 228 |  |  | 266 |  |  | 75 |  |  | 203 |  |  | 4 |  |  | 7 |  |
| Power Solutions divestiture | — |  |  | (371) |  |  | — |  |  | (45) |  |  | — |  |  | (4) |  |
| Other divestitures | — |  |  | — |  |  | — |  |  | (4) |  |  | — |  |  | — |  |
| Employer and employee contributions | 5 |  |  | 38 |  |  | 56 |  |  | 50 |  |  | 7 |  |  | 9 |  |
| Benefits paid | (112) |  |  | (136) |  |  | (73) |  |  | (76) |  |  | (21) |  |  | (23) |  |
| Settlement payments | (151) |  |  | (107) |  |  | (36) |  |  | (50) |  |  | — |  |  | — |  |
| Other | — |  |  | — |  |  | — |  |  | (2) |  |  | — |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | 93 |  |  | (95) |  |  | — |  |  | — |  |
| Fair value of plan assets at end of year | $ | 2,706 |  |  | $ | 2,736 |  |  | $ | 2,213 |  |  | $ | 2,098 |  |  | $ | 153 |  |  | $ | 163 |  |
| Funded status | $ | (511) |  |  | $ | (379) |  |  | $ | (513) |  |  | $ | (554) |  |  | $ | 7 |  |  | $ | (11) |  |
| Amounts recognized in the statement of financial position consist of: |
| Prepaid benefit cost | $ | 32 |  |  | $ | 30 |  |  | $ | 29 |  |  | $ | 25 |  |  | $ | 78 |  |  | $ | 66 |  |
| Accrued benefit liability | (543) |  |  | (409) |  |  | (542) |  |  | (579) |  |  | (71) |  |  | (77) |  |
| Net amount recognized | $ | (511) |  |  | $ | (379) |  |  | $ | (513) |  |  | $ | (554) |  |  | $ | 7 |  |  | $ | (11) |  |
| Weighted Average Assumptions (1) |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate (2) | 2.25 | % |  | 2.95 | % |  | 1.35 | % |  | 1.50 | % |  | 1.90 | % |  | 2.65 | % |
| Rate of compensation increase | N/A |  | N/A |  | 2.75 | % |  | 2.80 | % |  | N/A |  | N/A |

[0000833444-20-000048:notes:317]
(1)    Plan assets and obligations are determined based on a September 30 measurement date at September 30, 2020 and 2019.

[0000833444-20-000048:notes:318]
(2)    The Company considers the expected benefit payments on a plan-by-plan basis when setting assumed discount rates. As a result, the Company uses different discount rates for each plan depending on the plan jurisdiction, the demographics of participants and the expected timing of benefit payments. For the U.S. pension and postretirement plans, the Company uses a discount rate provided by an independent third party calculated based on an appropriate mix of high quality bonds. For the non-U.S. pension and postretirement plans, the Company consistently uses the relevant country specific benchmark indices for determining the various discount rates. The Company has elected to utilize a full yield curve approach in the estimation of service and interest components of net periodic benefit cost (credit) for pension and other postretirement for plans that utilize a yield curve approach. The full yield curve approach applies the specific spot rates along the yield curve used in the determination of the benefit obligation to the relevant projected cash flows.

[0000833444-20-000048:notes:319]
Accumulated Other Comprehensive Income

[0000833444-20-000048:notes:320]
The amounts in AOCI in the consolidated statements of financial position, exclusive of tax impacts, that have not yet been recognized as components of net periodic benefit cost (credit) at September 30, 2020 and 2019 related to pension and postretirement benefits are $(5) million and $6 million, respectively.

[0000833444-20-000048:notes:321]
The amounts in AOCI expected to be recognized as components of net periodic benefit cost (credit) over the next fiscal year related to pension and postretirement benefits are not significant.

[0000833444-20-000048:notes:322]
Net Periodic Benefit Cost

[0000833444-20-000048:notes:323]
The table that follows contains the components of net periodic benefit costs, which are primarily recorded in selling, general and administrative expenses in the consolidated statements of income (in millions):

[0000833444-20-000048:notes:324]
|  | Pension Benefits |  | Postretirement Benefits |
|  | U.S. Plans |  | Non-U.S. Plans |  |
| Year ended September 30, | 2020 |  | 2019 |  | 2018 |  | 2020 |  | 2019 |  | 2018 |  | 2020 |  | 2019 |  | 2018 |
| Components of Net Periodic Benefit Cost (Credit): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost | $ | — |  |  | $ | 8 |  |  | $ | 15 |  |  | $ | 25 |  |  | $ | 22 |  |  | $ | 23 |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | 2 |  |
| Interest cost | 67 |  |  | 108 |  |  | 105 |  |  | 36 |  |  | 54 |  |  | 57 |  |  | 4 |  |  | 6 |  |  | 7 |  |
| Expected return on plan assets | (180) |  |  | (199) |  |  | (229) |  |  | (111) |  |  | (105) |  |  | (114) |  |  | (9) |  |  | (9) |  |  | (10) |  |
| Net actuarial (gain) loss | 244 |  |  | 361 |  |  | 7 |  |  | 43 |  |  | 236 |  |  | (22) |  |  | 2 |  |  | 17 |  |  | 5 |  |
| Amortization of prior service cost (credit) | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | — |  |  | (3) |  |  | — |  |  | — |  |
| Curtailment gain | — |  |  | — |  |  | — |  |  | (8) |  |  | — |  |  | (2) |  |  | — |  |  | — |  |  | — |  |
| Settlement loss | 6 |  |  | 13 |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost (credit) | 137 |  |  | 291 |  |  | (102) |  |  | (14) |  |  | 211 |  |  | (58) |  |  | (5) |  |  | 15 |  |  | 4 |  |
| Net periodic benefit cost related to discontinued operations | — |  |  | (2) |  |  | (5) |  |  | — |  |  | — |  |  | (7) |  |  | — |  |  | — |  |  | (2) |  |
| Net periodic benefit cost (credit) included in continuing operations | $ | 137 |  |  | $ | 289 |  |  | $ | (107) |  |  | $ | (14) |  |  | $ | 211 |  |  | $ | (65) |  |  | $ | (5) |  |  | $ | 15 |  |  | $ | 2 |  |
| Expense Assumptions: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate | 2.95 | % |  | 4.10 | % |  | 3.80 | % |  | 1.50 | % |  | 2.45 | % |  | 2.40 | % |  | 2.65 | % |  | 3.80 | % |  | 3.70 | % |
| Expected return on plan assets | 6.90 | % |  | 7.10 | % |  | 7.50 | % |  | 5.20 | % |  | 5.20 | % |  | 5.35 | % |  | 5.70 | % |  | 5.65 | % |  | 5.65 | % |
| Rate of compensation increase | N/A |  | 3.50 | % |  | 3.20 | % |  | 2.80 | % |  | 2.95 | % |  | 2.90 | % |  | N/A |  | N/A |  | N/A |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-20-000048:notes:325]
SIGNIFICANT RESTRUCTURING AND IMPAIRMENT COSTS
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company has committed to various restructuring plans in its Building Technologies & Solutions business and its corporate operations. Restructuring plans generally result in charges for workforce reductions, plant closures and asset impairments which are reported as restructuring and impairment costs in the Company’s consolidated statements of income. The Company expects the restructuring actions to reduce cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense.

[0000833444-20-000048:notes:326]
In fiscal 2020, the Company committed to a significant restructuring plan ("2020 Plan") and recorded $297 million of restructuring and impairment costs in the consolidated statements of income. This is the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. Of the restructuring and impairment costs recorded, $136 million related to the Global Products segment, $64 million related to the Building Solutions North America segment, $49 million related to the Building Solutions Asia Pacific segment, $43 million related to the Building Solutions EMEA/LA segment and $5 million related to Corporate. The restructuring actions are expected to be substantially complete in fiscal 2021.

[0000833444-20-000048:notes:327]
The following table summarizes the changes in the Company’s 2020 Plan reserve, included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-20-000048:notes:328]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | Total |
| Original reserve | $ | 196 |  |  | $ | 96 |  |  | $ | 5 |  |  | $ | 297 |  |
| Utilized—cash | (92) |  |  | — |  |  | (3) |  |  | (95) |  |
| Utilized—noncash | — |  |  | (96) |  |  | — |  |  | (96) |  |
| Currency translation | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Balance at September 30, 2020 | $ | 106 |  |  | $ | — |  |  | $ | 2 |  |  | $ | 108 |  |

[0000833444-20-000048:notes:329]
Also included in restructuring and impairment costs in the consolidated statements of income in fiscal 2020 are goodwill impairment related to the North America Retail reporting unit of $424 million and indefinite-lived intangible asset impairments of $62 million. Refer to Note 7, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for further information regarding these impairments.

[0000833444-20-000048:notes:330]
In fiscal 2018, the Company committed to a significant restructuring plan ("2018 Plan") and recorded $255 million of restructuring and impairment costs for continuing operations in the consolidated statements of income. This was the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. Of the restructuring and impairment costs recorded, $113 million related to the Global Products segment, $56 million related to the Building Solutions EMEA/LA segment, $50 million related to Corporate, $20 million related to the Building Solutions North America segment and $16 million related to the Building Solutions Asia Pacific segment. The restructuring actions were substantially complete in 2020.

[0000833444-20-000048:notes:331]
Additionally, the Company recorded $8 million of restructuring and impairment costs related to Power Solutions in fiscal 2018. This is reported within discontinued operations.

[0000833444-20-000048:notes:332]
The following table summarizes the changes in the Company’s 2018 Plan reserve, included within other current liabilities in

[0000833444-20-000048:notes:333]
the consolidated statements of financial position (in millions):

[0000833444-20-000048:notes:334]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | Total |
| Original reserve | $ | 209 |  |  | $ | 42 |  |  | $ | 12 |  |  | $ | 263 |  |
| Utilized—cash | (45) |  |  | — |  |  | (2) |  |  | (47) |  |
| Utilized—noncash | — |  |  | (42) |  |  | — |  |  | (42) |  |
| Balance at September 30, 2018 | $ | 164 |  |  | $ | — |  |  | $ | 10 |  |  | $ | 174 |  |
| Utilized—cash | (61) |  |  | — |  |  | (6) |  |  | (67) |  |
| Transfer to liabilities held for sale | (4) |  |  | — |  |  | — |  |  | (4) |  |
| Currency translation | (1) |  |  | — |  |  | — |  |  | (1) |  |
| Balance at September 30, 2019 | $ | 98 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 102 |  |
| Utilized—cash | (69) |  |  | — |  |  | — |  |  | (69) |  |
| Adoption of ASC 842 (1) | — |  |  | — |  |  | (4) |  |  | (4) |  |
| Currency translation | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Balance at September 30, 2020 | $ | 30 |  |  | $ | — |  |  | $ | — |  |  | $ | 30 |  |

[0000833444-20-000048:notes:335]
(1) Represents liability for facility closings recorded as an offset to right-of-use asset upon adoption of ASC 842.

[0000833444-20-000048:notes:336]
In fiscal 2017, the Company committed to a significant restructuring plan ("2017 Plan") and recorded $347 million of restructuring and impairment costs for continuing operations in the consolidated statements of income. This was the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. Of the restructuring and impairment costs recorded, $166 million related to Corporate, $74 million related to the Building Solutions EMEA/LA segment, $59 million related to the Building Solutions North America segment, $32 million related to the Global Products segment and $16 million related to the Building Solutions Asia Pacific segment. The restructuring actions were substantially complete in fiscal 2020.

[0000833444-20-000048:notes:337]
Additionally, the Company recorded $20 million of restructuring and impairment costs related to Power Solutions in fiscal 2017. This is reported within discontinued operations.

[0000833444-20-000048:notes:338]
The following table summarizes the changes in the Company’s 2017 Plan reserve, included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-20-000048:notes:339]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | Total |
| Original Reserve | $ | 276 |  |  | $ | 77 |  |  | $ | 14 |  |  | $ | 367 |  |
| Utilized—cash | (75) |  |  | — |  |  | — |  |  | (75) |  |
| Utilized—noncash | — |  |  | (77) |  |  | (1) |  |  | (78) |  |
| Adjustment to restructuring reserves | 25 |  |  | — |  |  | — |  |  | 25 |  |
| Balance at September 30, 2017 | $ | 226 |  |  | $ | — |  |  | $ | 13 |  |  | $ | 239 |  |
| Utilized—cash | (152) |  |  | — |  |  | (6) |  |  | (158) |  |
| Currency translation | (1) |  |  | — |  |  | — |  |  | (1) |  |
| Balance at September 30, 2018 | $ | 73 |  |  | $ | — |  |  | $ | 7 |  |  | $ | 80 |  |
| Utilized—cash | (11) |  |  | — |  |  | (2) |  |  | (13) |  |
| Transfer to liabilities held for sale | (3) |  |  | — |  |  | — |  |  | (3) |  |
| Currency translation | (3) |  |  | — |  |  | — |  |  | (3) |  |
| Balance at September 30, 2019 | $ | 56 |  |  | $ | — |  |  | $ | 5 |  |  | $ | 61 |  |
| Utilized—cash | (50) |  |  | — |  |  | — |  |  | (50) |  |
| Adoption of ASC 842 (1) | — |  |  | — |  |  | (5) |  |  | (5) |  |
| Balance at September 30, 2020 | $ | 6 |  |  | $ | — |  |  | $ | — |  |  | $ | 6 |  |

[0000833444-20-000048:notes:340]
The Company's fiscal 2020, 2018 and 2017 restructuring plans included workforce reductions of approximately 16,400 employees. Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of September 30, 2020, approximately 12,700 of the employees have been separated from the Company pursuant to the restructuring plans. In addition, the restructuring plans included nine plant closures. As of September 30, 2020, eight of the nine plants have been closed. 
Company management closely monitors its overall cost structure and continually analyzes each of its businesses for opportunities to consolidate current operations, improve operating efficiencies and locate facilities in close proximity to customers. This ongoing analysis includes a review of its manufacturing, engineering and purchasing operations, as well as the overall global footprint for all its businesses.


## us-gaap:AssetImpairmentChargesTextBlock

[0000833444-20-000048:notes:341]
IMPAIRMENT OF LONG-LIVED ASSETS
In fiscal 2020, the Company concluded it had triggering events requiring assessment of impairment for certain of its long-lived assets caused by the economic impacts of the COVID-19 pandemic on the North America Retail asset group. The Company performed a quantitative impairment analysis and determined there was no impairment of long-lived assets as of September 30, 2020.

[0000833444-20-000048:notes:342]
In fiscal 2020, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2020. As a result, the Company reviewed the long-lived assets for impairment and recorded $81 million of asset impairment charges within restructuring and impairment costs in the consolidated statements of income. Of these impairment charges, $42 million related to the Global Products segment, $24 million related to the Building Solutions Asia Pacific segment and $15 million related to the Building Solutions North America segment. The impairments were primarily measured under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-20-000048:notes:343]
In fiscal 2019 and again in 2020, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with the plans to dispose of a business within its Global Products segment that met the criteria to be classified as held for sale. Assets and liabilities held for sale are required to be recorded at the lower of carrying value or fair value less any costs to sell. Accordingly, the Company recorded impairment charges of $250 million, including $15 million in fiscal 2020 and $235 million in fiscal 2019, within restructuring and impairment costs in the consolidated statements of income to write down the carrying value of the assets held for sale to fair value less any costs to sell. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-20-000048:notes:344]
In fiscal 2018, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2018. As a result, the Company reviewed the long-lived assets for impairment and recorded $36 million of asset impairment charges within restructuring and impairment costs in the consolidated statements of income. Of the total impairment charges, $31 million related to the Global Products segment and $5 million related to Corporate assets. In addition, the Company recorded $6 million of asset impairments within discontinued operations related to the Power Solutions segment in fiscal 2018.

[0000833444-20-000048:notes:345]
Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-20-000048:notes:346]
During September 30, 2020, 2019 and 2018, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets. Refer to Note 1, "Summary of Significant Accounting Policies," and Note 7, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for discussion of the Company’s goodwill impairment testing.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-20-000048:notes:347]
INCOME TAXES
The more significant components of the Company’s income tax provision from continuing operations are as follows (in millions):

[0000833444-20-000048:notes:348]
|  | Year Ended September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Tax expense at Ireland statutory rate | $ | 113 |  |  | $ | 132 |  |  | $ | 193 |  |
| U.S. state income tax, net of federal benefit | 8 |  |  | 15 |  |  | 15 |  |
| Income subject to the U.S. federal tax rate | (92) |  |  | (110) |  |  | 39 |  |
| Income subject to rates different than the statutory rate | 99 |  |  | 38 |  |  | (201) |  |
| Reserve and valuation allowance adjustments | (70) |  |  | (284) |  |  | 31 |  |
| Impact of acquisitions and divestitures | — |  |  | — |  |  | 16 |  |
| U.S. Tax Reform discrete items | — |  |  | — |  |  | 108 |  |
| Restructuring and impairment costs | 50 |  |  | (24) |  |  | (4) |  |
| Income tax provision (benefit) | $ | 108 |  |  | $ | (233) |  |  | $ | 197 |  |

[0000833444-20-000048:notes:349]
The statutory tax rate in Ireland of 12.5% is being used as a comparison since the Company is domiciled in Ireland.

[0000833444-20-000048:notes:350]
For fiscal 2020, the effective tax rate for continuing operations was 12% and was lower than the statutory tax rate primarily due to tax audit reserve adjustments, the income tax effects of mark-to-market adjustments, valuation allowance adjustments and the benefits of continuing global tax planning initiatives, partially offset by a discrete tax charge related to the remeasurement of deferred tax assets and liabilities as a result of Swiss tax reform, the tax impact of an impairment charge and tax rate differentials.

[0000833444-20-000048:notes:351]
For fiscal 2019, the effective rate for continuing operations was below the statutory rate primarily due to tax audit reserve adjustments, the income tax effects of mark-to-market adjustments, a tax indemnification reserve release, the tax benefits of an asset held for sale impairment charge and continuing global tax planning initiatives, partially offset by valuation allowance

[0000833444-20-000048:notes:352]
adjustments as a result of tax law changes, a discrete tax charge related to newly enacted regulations related to U.S. Tax Reform and tax rate differentials.

[0000833444-20-000048:notes:353]
For fiscal 2018, the effective rate for continuing operations was above the statutory rate primarily due to the discrete net impacts of U.S. Tax Reform, the final income tax effects of the completed divestiture of the Scott Safety business, and valuation allowance adjustments, partially offset by tax audit closures, tax benefits due to changes in entity tax status, the benefits of continuing global tax planning initiatives and tax rate differentials.

[0000833444-20-000048:notes:354]
Valuation Allowances

[0000833444-20-000048:notes:355]
The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required. In determining the requirement for a valuation allowance, the historical and projected financial results of the legal entity or consolidated group recording the net deferred tax asset are considered, along with any other positive or negative evidence. Since future financial results may differ from previous estimates, periodic adjustments to the Company’s valuation allowances may be necessary.

[0000833444-20-000048:notes:356]
In the fourth quarter of fiscal 2020, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering feasible tax planning initiatives and other positive and negative evidence, the Company determined that it was more likely than not that certain deferred tax assets primarily within the U.S. would not be realized, and it is more likely than not that certain deferred tax assets of Canada would be realized. The valuation allowance adjustments resulted in a $26 million net benefit to income tax expense in the three month period ended September 30, 2020.

[0000833444-20-000048:notes:357]
In the fourth quarter of fiscal 2019, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering feasible tax planning initiatives and other positive and negative evidence, the Company determined that it was more likely than not that certain deferred tax assets primarily within the U.S., Belgium, Japan and the United Kingdom would not be realized, and it is more likely than not that certain deferred tax assets of the U.S. and France will be realized. The valuation allowance adjustments resulted in an immaterial net impact to income tax expense for the three-month period ended September 30, 2019.

[0000833444-20-000048:notes:358]
In the first quarter of fiscal 2019, as a result of changes to U.S. tax law, the Company recorded a discrete tax charge of $76 million related to valuation allowances on certain U.S. deferred tax assets.

[0000833444-20-000048:notes:359]
In the fourth quarter of fiscal 2018, the Company performed an analysis related to the realizability of its worldwide deferred tax assets. As a result, and after considering feasible tax planning initiatives and other positive and negative evidence, the Company determined that it was more likely than not that certain deferred tax assets primarily within Germany would not be realized. Therefore, the Company recorded $56 million of valuation allowances as income tax expense in the three-month period ended September 30, 2018.

[0000833444-20-000048:notes:360]
Uncertain Tax Positions

[0000833444-20-000048:notes:361]
The Company is subject to income taxes in the U.S. and numerous foreign jurisdictions. Judgment is required in determining its worldwide provision for income taxes and recording the related assets and liabilities. In the ordinary course of the Company’s business, there are many transactions and calculations where the ultimate tax determination is uncertain. The Company is regularly under audit by tax authorities.

[0000833444-20-000048:notes:362]
At September 30, 2020, the Company had gross tax effected unrecognized tax benefits for continuing operations of $2,528 million of which $2,132 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2020 was approximately $205 million (net of tax benefit).

[0000833444-20-000048:notes:363]
At September 30, 2019, the Company had gross tax effected unrecognized tax benefits for continuing operations of $2,451 million of which $2,121 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2019 was approximately $181 million (net of tax benefit).

[0000833444-20-000048:notes:364]
At September 30, 2018, the Company had gross tax effected unrecognized tax benefits for continuing operations of $2,358 million of which $2,225 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2018 was approximately $119 million (net of tax benefit).

[0000833444-20-000048:notes:365]
A reconciliation of the beginning and ending amount of unrecognized tax benefits is as follows (in millions):

[0000833444-20-000048:notes:366]
|  | Year Ended September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Beginning balance, October 1 | $ | 2,451 |  |  | $ | 2,358 |  |  | $ | 2,161 |  |
| Additions for tax positions related to the current year | 128 |  |  | 433 |  |  | 435 |  |
| Additions for tax positions of prior years | 129 |  |  | 347 |  |  | 7 |  |
| Reductions for tax positions of prior years | (27) |  |  | (88) |  |  | (201) |  |
| Settlements with taxing authorities | (54) |  |  | — |  |  | (19) |  |
| Statute closings and audit resolutions | (99) |  |  | (599) |  |  | (25) |  |
| Ending balance, September 30 | $ | 2,528 |  |  | $ | 2,451 |  |  | $ | 2,358 |  |

[0000833444-20-000048:notes:367]
During fiscal 2020, tax audit resolutions resulted in a $44 million net benefit to income tax expense.

[0000833444-20-000048:notes:368]
During fiscal 2019, the Company settled tax examinations impacting fiscal years 2015 to 2016 and adjusted various tax audit reserves which resulted in a $586 million net benefit to income tax expense in the fourth quarter. In the third quarter of fiscal 2019, the Company recorded a discrete charge related to newly enacted regulations related to U.S. Tax Reform and a discrete charge related to non-U.S. tax examinations which impacted the Company’s reserves for uncertain tax positions resulting in a $226 million net charge to income tax expense.

[0000833444-20-000048:notes:369]
During fiscal 2018, the Company settled tax examinations impacting fiscal years 2010 to fiscal 2012 which resulted in a $25 million net benefit to income tax expense.

[0000833444-20-000048:notes:370]
In the U.S., fiscal years 2017 through 2018 are currently under exam by the Internal Revenue Service (“IRS”) for certain legal entities. Additionally, the Company is currently under exam in the following major non-U.S. jurisdictions for continuing operations:

[0000833444-20-000048:notes:371]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2019 |
| China |  | 2019 |
| Germany |  | 2007 - 2018 |
| Luxembourg |  | 2017 - 2018 |
| Mexico |  | 2016 - 2017, 2019 |
| Taiwan |  | 2019 |
| United Kingdom |  | 2014 - 2015, 2017 |

[0000833444-20-000048:notes:372]
It is reasonably possible that certain tax examinations and/or tax litigation will conclude within the next twelve months, which could impact tax expense.

[0000833444-20-000048:notes:373]
Other Tax Matters

[0000833444-20-000048:notes:374]
During fiscal 2020, the Company incurred charges for restructuring and impairment costs for continuing operations of $783 million. Refer to Note 7, "Goodwill and Other Intangible Assets," Note 16, "Significant Restructuring and Impairment Costs," and Note 17, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for additional information. These costs generated tax benefits of $48 million, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-20-000048:notes:375]
During fiscal 2020, 2019, and 2018, the Company recorded transaction and integration costs for continuing operations of $135 million, $317 million and $226 million, respectively. These costs generated tax benefits of $18 million, $35 million and $27 million, respectively, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-20-000048:notes:376]
During fiscal 2020, 2019 and 2018, the Company recorded mark-to-market gains (losses) of $(274) million, $(618) million and $24 million, respectively. These gains (losses) generated tax expense (benefit) of $(65) million, $(130) million and $1 million, respectively, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-20-000048:notes:377]
During fiscal 2019, the Company recorded a $235 million impairment charge related to assets held for sale. Refer to Note 17, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for further information regarding the impairment charge. The impairment charge generated a $53 million tax benefit.  Also during fiscal 2019, the Company released a $226 million tax indemnification reserve, which was recorded within selling, general and administrative expenses in the consolidated statements of income. The reserve release generated no income tax expense.

[0000833444-20-000048:notes:378]
During fiscal 2018, the Company incurred charges for restructuring and impairment costs for continuing operations of $255 million. Refer to Note 16, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. These costs generated tax benefits of $36 million, which reflects the Company’s current tax position in these jurisdictions.

[0000833444-20-000048:notes:379]
In the fourth quarter of fiscal 2018, the Company recorded a tax benefit of $139 million due to changes in entity tax status.

[0000833444-20-000048:notes:380]
In the first quarter of fiscal 2018, the Company completed the sale of its Scott Safety business to 3M Company. In connection with the sale, the Company recorded a pre-tax gain of $114 million and income tax expense of $30 million.  Refer to Note 2, "Acquisitions and Divestitures," of the notes to consolidated financial statements for additional information.

[0000833444-20-000048:notes:381]
Impacts of Tax Legislation and Change in Statutory Tax Rates

[0000833444-20-000048:notes:382]
On March 27, 2020, in response to the COVID-19 pandemic, the “Coronavirus Aid, Relief and Economic Security Act” (“CARES”) was signed into law by the President of the United States. The CARES Act includes, among other things, U.S. corporate income tax provisions related to net operating loss carryback periods, alternative minimum tax credits, modifications to interest deduction limitations and technical corrections on tax depreciation methods for qualified improvement property. A majority of non-U.S. countries have also introduced various COVID-19 related corporate income tax relief provisions.  The Company does not expect either the U.S. or non-U.S. corporate income tax provisions to have a material effect on its financial statements.

[0000833444-20-000048:notes:383]
In the first quarter of fiscal 2020, the Company recorded a noncash discrete tax charge of $30 million due to the remeasurement of deferred tax assets and liabilities related to Switzerland and the canton of Schaffhausen. On September 28, 2018, the Swiss Parliament approved the Federal Act on Tax Reform and AHV Financing (“TRAF”), which was subsequently approved by the Swiss electorate on May 19, 2019. During the fourth quarter of fiscal 2019, the Swiss Federal Council enacted TRAF which became effective for the Company on January 1, 2020. The impacts of the federal enactment did not have a material impact to the Company’s financial statements. TRAF also provides for parameters which enable the Swiss cantons to adjust tax rates and establish new regulations for companies. As of September 30, 2019, the canton of Schaffhausen had not concluded its public referendum; however, the enactment did occur during the first quarter of fiscal 2020.

[0000833444-20-000048:notes:384]
On December 22, 2017, the “Tax Cuts and Jobs Act” (H.R. 1) was enacted and significantly revised U.S. corporate income tax by, among other things, lowering corporate income tax rates, imposing a one-time transition tax on deemed repatriated earnings of non-U.S. subsidiaries, and implementing a territorial tax system and various base erosion minimum tax provisions.

[0000833444-20-000048:notes:385]
In connection with the Company’s analysis of the impact of the U.S. tax law changes, the Company recorded a provisional net tax charge of $108 million during fiscal 2018 consistent with guidance prescribed by Staff Accounting Bulletin 118.  This provisional net tax charge arises from a benefit of $108 million due to the remeasurement of U.S. deferred tax assets and liabilities, offset by the Company’s tax charge relating to the one-time transition tax on deemed repatriated earnings, inclusive of all relevant taxes, of $216 million. The Company’s estimated benefit of the remeasurement of U.S. deferred tax assets and liabilities increased from $101 million as of December 31, 2017 to $108 million as of September 30, 2018 due to calculation refinement of the Company’s estimated impact. The Company remeasured certain deferred tax assets and liabilities based on the rates at which they are expected to reverse in the future, which is generally 21% or the blended fiscal 2018 rate of 24.5%. The Company’s tax charge for transition tax decreased from $305 million as of December 31, 2017 to $216 million as of September 30, 2018 due to further analysis of the Company’s post-1986 non-U.S. earnings and profits (“E&P”) previously deferred from U.S. federal taxation and refinement of the estimated impact of tax law changes. During fiscal 2019, the Company completed its analysis of all enactment-date income tax effects of the U.S. tax law change with no further adjustment to the provisional amounts recorded as of September 30, 2018.

[0000833444-20-000048:notes:386]
During the fiscal years ended 2020, 2019 and 2018, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-20-000048:notes:387]
Continuing Operations

[0000833444-20-000048:notes:388]
Components of the provision (benefit) for income taxes on continuing operations were as follows (in millions):

[0000833444-20-000048:notes:389]
|  | Year Ended September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Current |  |  |  |  |  |
| U.S. federal | $ | 309 |  |  | $ | (1,025) |  |  | $ | 476 |  |
| U.S. state | 72 |  |  | (33) |  |  | 26 |  |
| Non-U.S. | 264 |  |  | 213 |  |  | 434 |  |
|  | 645 |  |  | (845) |  |  | 936 |  |
| Deferred |  |  |  |  |  |
| U.S. federal | (382) |  |  | 412 |  |  | (372) |  |
| U.S. state | (43) |  |  | 84 |  |  | (10) |  |
| Non-U.S. | (112) |  |  | 116 |  |  | (357) |  |
|  | (537) |  |  | 612 |  |  | (739) |  |
| Income tax provision (benefit) | $ | 108 |  |  | $ | (233) |  |  | $ | 197 |  |

[0000833444-20-000048:notes:390]
Consolidated U.S. income (loss) from continuing operations before income taxes and noncontrolling interests for the fiscal years ended September 30, 2020, 2019 and 2018 was $(385) million, $(259) million and $261 million, respectively. Consolidated non-U.S. income from continuing operations before income taxes and noncontrolling interests for the fiscal years ended September 30, 2020, 2019 and 2018 was $1,288 million, $1,315 million and $1,285 million, respectively.

[0000833444-20-000048:notes:391]
Continuing operations income taxes paid (refunded) for the fiscal years ended September 30, 2020, 2019 and 2018 were $(386) million, $377 million and $81 million, respectively. At September 30, 2020 and 2019, the Company recorded within the continuing operations consolidated statements of financial position in other current assets approximately $252 million and $1,069 million, respectively, of income tax assets. At September 30, 2020 and 2019, the Company recorded within the continuing operations consolidated statements of financial position in other current liabilities approximately $243 million and $159 million, respectively, of accrued income tax liabilities.

[0000833444-20-000048:notes:392]
The Company has not provided U.S. or non-U.S. income taxes on approximately $22.0 billion of outside basis differences of consolidated subsidiaries of Johnson Controls International plc. The Company is indefinitely reinvested in these basis differences. The reduction of the outside basis differences via the sale or liquidation of these subsidiaries and/or distributions could create taxable income. The Company's intent is to reduce the outside basis differences only when it would be tax efficient. Given the numerous ways in which the basis differences may be reduced, it is not practicable to estimate the amount of unrecognized withholding taxes and deferred tax liability on the outside basis differences.

[0000833444-20-000048:notes:393]
Deferred taxes were classified in the consolidated statements of financial position as follows (in millions):

[0000833444-20-000048:notes:394]
|  | September 30, |
|  | 2020 |  | 2019 |
| Other noncurrent assets | $ | 862 |  |  | $ | 552 |  |
| Other noncurrent liabilities | (385) |  |  | (588) |  |
| Net deferred tax asset (liability) | $ | 477 |  |  | $ | (36) |  |

[0000833444-20-000048:notes:395]
Temporary differences and carryforwards which gave rise to deferred tax assets and liabilities included (in millions):

[0000833444-20-000048:notes:396]
|  | September 30, |
|  | 2020 |  | 2019 |
| Deferred tax assets |  |  |  |
| Accrued expenses and reserves | $ | 474 |  |  | $ | 437 |  |
| Employee and retiree benefits | 286 |  |  | 265 |  |
| Property, plant and equipment | 182 |  |  | — |  |
| Net operating loss and other credit carryforwards | 6,306 |  |  | 5,664 |  |
| Research and development | 112 |  |  | 106 |  |
| Other, net | 99 |  |  | — |  |
|  | 7,459 |  |  | 6,472 |  |
| Valuation allowances | (5,518) |  |  | (5,068) |  |
|  | 1,941 |  |  | 1,404 |  |
| Deferred tax liabilities |  |  |  |
| Property, plant and equipment | — |  |  | 139 |  |
| Subsidiaries, joint ventures and partnerships | 730 |  |  | 499 |  |
| Intangible assets | 734 |  |  | 759 |  |
| Other, net | — |  |  | 43 |  |
|  | 1,464 |  |  | 1,440 |  |
| Net deferred tax asset (liability) | $ | 477 |  |  | $ | (36) |  |

[0000833444-20-000048:notes:397]
At September 30, 2020, the Company had available net operating loss carryforwards of approximately $25.0 billion, of which $15.1 billion will expire at various dates between 2021 and 2040, and the remainder has an indefinite carryforward period. The Company had available U.S. foreign tax credit carryforwards at September 30, 2020 of $35 million which will expire in 2030. The valuation allowance, generally, is for loss and credit carryforwards for which realization is uncertain because it is unlikely that the losses and/or credits will be realized given the lack of sustained profitability and/or limited carryforward periods in certain countries.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-20-000048:notes:398]
SEGMENT INFORMATION
ASC 280, "Segment Reporting," establishes the standards for reporting information about segments in financial statements. In applying the criteria set forth in ASC 280, the Company has determined that it has four reportable segments for financial reporting purposes.

[0000833444-20-000048:notes:399]
Building Solutions North America:   Building Solutions North America designs, sells, installs, and services HVAC, controls, refrigeration, integrated electronic security, and integrated fire detection and suppression systems for commercial, industrial, retail, small business, institutional and governmental customers in North America. Building Solutions North America also provides energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and control systems, as well as data-driven “smart building” solutions, to non-residential building and industrial applications in the North American marketplace.

[0000833444-20-000048:notes:400]
Building Solutions EMEA/LA: Building Solutions EMEA/LA designs, sells, installs, and services HVAC, controls, refrigeration, integrated electronic security, integrated fire detection and suppression systems, and provides technical services, including data-driven “smart building” solutions, to markets in Europe, the Middle East, Africa and Latin America.

[0000833444-20-000048:notes:401]
Building Solutions Asia Pacific: Building Solutions Asia Pacific designs, sells, installs, and services HVAC, controls, refrigeration, integrated electronic security, integrated fire detection and suppression systems, and provides technical services, including data-driven “smart building” solutions, to the Asia Pacific marketplace.

[0000833444-20-000048:notes:402]
Global Products: Global Products designs and produces heating and air conditioning for residential and commercial applications, and markets products and refrigeration systems to replacement and new construction market customers globally. The Global Products business also designs, manufactures and sells fire protection and security products, including intrusion

[0000833444-20-000048:notes:403]
security, anti-theft devices, and access control and video management systems, for commercial, industrial, retail, residential, small business, institutional and governmental customers worldwide. Global Products also includes the Johnson Controls-Hitachi joint venture.

[0000833444-20-000048:notes:404]
On October 1, 2018, the Company adopted ASU No. 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." The new standard requires the mark-to-market of marketable securities investments previously recorded within accumulated other comprehensive income on the statement of financial position be recorded in the statement of income on a prospective basis beginning as of the adoption date. As these restricted investments do not relate to the underlying operating performance of its business, the Company’s definition of segment earnings excludes the mark-to-market adjustments in fiscal 2020 and 2019.

[0000833444-20-000048:notes:405]
Management evaluates the performance of its business segments primarily on segment earnings before interest, taxes and amortization ("EBITA"), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and net mark-to-market adjustments related to pension and postretirement plans and restricted asbestos investments.

[0000833444-20-000048:notes:406]
Financial information relating to the Company’s reportable segments is as follows (in millions):

[0000833444-20-000048:notes:407]
|  | Year Ended September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Net Sales |  |  |  |  |  |
| Building Solutions North America | $ | 8,605 |  |  | $ | 9,031 |  |  | $ | 8,679 |  |
| Building Solutions EMEA/LA | 3,440 |  |  | 3,655 |  |  | 3,696 |  |
| Building Solutions Asia Pacific | 2,403 |  |  | 2,658 |  |  | 2,553 |  |
| Global Products | 7,869 |  |  | 8,624 |  |  | 8,472 |  |
| Total net sales | $ | 22,317 |  |  | $ | 23,968 |  |  | $ | 23,400 |  |

[0000833444-20-000048:notes:408]
|  | Year Ended September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Segment EBITA |  |  |  |  |  |
| Building Solutions North America (1) | $ | 1,157 |  |  | $ | 1,153 |  |  | $ | 1,109 |  |
| Building Solutions EMEA/LA (2) | 338 |  |  | 368 |  |  | 344 |  |
| Building Solutions Asia Pacific (3) | 319 |  |  | 341 |  |  | 347 |  |
| Global Products (4) | 1,134 |  |  | 1,179 |  |  | 1,338 |  |
| Total segment EBITA | $ | 2,948 |  |  | $ | 3,041 |  |  | $ | 3,138 |  |
| Amortization of intangible assets | (386) |  |  | (377) |  |  | (376) |  |
| Corporate expenses (5) | (371) |  |  | (405) |  |  | (584) |  |
| Net financing charges | (231) |  |  | (350) |  |  | (401) |  |
| Restructuring and impairment costs | (783) |  |  | (235) |  |  | (255) |  |
| Net mark-to-market adjustments | (274) |  |  | (618) |  |  | 24 |  |
| Income from continuing operations before income taxes | $ | 903 |  |  | $ | 1,056 |  |  | $ | 1,546 |  |

[0000833444-20-000048:notes:409]
|  | September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Assets |  |  |  |  |  |
| Building Solutions North America (6) | $ | 15,215 |  |  | $ | 15,562 |  |  | $ | 15,384 |  |
| Building Solutions EMEA/LA (7) | 4,989 |  |  | 4,786 |  |  | 4,997 |  |
| Building Solutions Asia Pacific (8) | 2,720 |  |  | 2,657 |  |  | 2,743 |  |
| Global Products (9) | 13,882 |  |  | 13,945 |  |  | 14,261 |  |
|  | 36,806 |  |  | 36,950 |  |  | 37,385 |  |
| Assets held for sale | 147 |  |  | 158 |  |  | 8,203 |  |
| Unallocated | 3,862 |  |  | 5,179 |  |  | 3,209 |  |
| Total | $ | 40,815 |  |  | $ | 42,287 |  |  | $ | 48,797 |  |

[0000833444-20-000048:notes:410]
|  | Year Ended September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Depreciation/Amortization |  |  |  |  |  |
| Building Solutions North America | $ | 233 |  |  | $ | 233 |  |  | $ | 236 |  |
| Building Solutions EMEA/LA | 102 |  |  | 112 |  |  | 110 |  |
| Building Solutions Asia Pacific | 24 |  |  | 23 |  |  | 28 |  |
| Global Products | 414 |  |  | 396 |  |  | 390 |  |
|  | 773 |  |  | 764 |  |  | 764 |  |
| Corporate | 49 |  |  | 61 |  |  | 60 |  |
| Continuing Operations | 822 |  |  | 825 |  |  | 824 |  |
| Discontinued Operations | — |  |  | 32 |  |  | 261 |  |
| Total | $ | 822 |  |  | $ | 857 |  |  | $ | 1,085 |  |

[0000833444-20-000048:notes:411]
|  | Year Ended September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Capital Expenditures |  |  |  |  |  |
| Building Solutions North America | $ | 93 |  |  | $ | 119 |  |  | $ | 114 |  |
| Building Solutions EMEA/LA | 99 |  |  | 93 |  |  | 73 |  |
| Building Solutions Asia Pacific | 36 |  |  | 26 |  |  | 26 |  |
| Global Products | 191 |  |  | 310 |  |  | 307 |  |
|  | 419 |  |  | 548 |  |  | 520 |  |
| Corporate | 24 |  |  | 38 |  |  | 125 |  |
| Continuing Operations | 443 |  |  | 586 |  |  | 645 |  |
| Discontinued Operations | — |  |  | 197 |  |  | 385 |  |
| Total | $ | 443 |  |  | $ | 783 |  |  | $ | 1,030 |  |

[0000833444-20-000048:notes:412]
(1)Building Solutions North America segment EBITA for the years ended September 30, 2020 and 2018 excludes $520 million and $20 million, respectively, of restructuring and impairment costs. For the year ended September 30, 2020, Building Solutions North America includes $1 million of equity losses.

[0000833444-20-000048:notes:413]
(2)Building Solutions EMEA/LA segment EBITA for the years ended September 30, 2020 and 2018 excludes $59 million, and $56 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2020, 2019 and 2018, Building Solutions EMEA/LA segment EBITA includes $6 million, $12 million and $1 million, respectively, of equity income.

[0000833444-20-000048:notes:414]
(3)Building Solutions Asia Pacific segment EBITA for the years ended September 30, 2020 and 2018 excludes $56 million and $16 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2020, 2019 and 2018, Building Solutions Asia Pacific segment EBITA includes less than $1 million, $1 million and $1 million, respectively, of equity income.

[0000833444-20-000048:notes:415]
(4)Global Products segment EBITA for the years ended September 30, 2020, 2019 and 2018 excludes $143 million, $235 million and $113 million, respectively, of restructuring and impairment costs. For the years ended September 30, 2020, 2019 and 2018, Global Products segment EBITA includes $166 million, $179 million and $175 million, respectively, of equity income.

[0000833444-20-000048:notes:416]
(5)Corporate expenses for the years ended September 30, 2020 and 2018 excludes $5 million and $50 million, respectively, of restructuring and impairment costs.

[0000833444-20-000048:notes:417]
(6)Buildings Solutions North America assets as of September 30, 2020, 2019 and 2018 include $7 million, $8 million and $8 million, respectively, of investments in partially-owned affiliates.

[0000833444-20-000048:notes:418]
(7)Building Solutions EMEA/LA assets as of September 30, 2020, 2019 and 2018 include $108 million, $109 million and $99 million, respectively, of investments in partially-owned affiliates.

[0000833444-20-000048:notes:419]
(8)Building Solutions Asia Pacific assets as of September 30, 2020, 2019 and 2018 include $2 million and $6 million, and $1 million, respectively, of investments in partially-owned affiliates.

[0000833444-20-000048:notes:420]
(9)Global Products assets as of September 30, 2020, 2019 and 2018 include $797 million, $730 million and $740 million, respectively, of investments in partially-owned affiliates.

[0000833444-20-000048:notes:421]
In fiscal years 2020, 2019 and 2018 no customer exceeded 10% of consolidated net sales.

[0000833444-20-000048:notes:422]
Geographic Segments

[0000833444-20-000048:notes:423]
Financial information relating to the Company’s operations by geographic area is as follows (in millions):

[0000833444-20-000048:notes:424]
|  | Year Ended September 30, |
|  | 2020 |  | 2019 |  | 2018 |
| Net Sales |  |  |  |  |  |
| United States | $ | 11,007 |  |  | $ | 11,773 |  |  | $ | 11,306 |  |
| China | 1,206 |  |  | 1,424 |  |  | 1,480 |  |
| Japan | 1,789 |  |  | 1,943 |  |  | 1,903 |  |
| Germany | 583 |  |  | 629 |  |  | 616 |  |
| United Kingdom | 980 |  |  | 1,042 |  |  | 1,075 |  |
| Taiwan | 725 |  |  | 612 |  |  | 661 |  |
| Other foreign | 4,113 |  |  | 4,625 |  |  | 4,423 |  |
| Other European countries | 1,914 |  |  | 1,920 |  |  | 1,936 |  |
| Total | $ | 22,317 |  |  | $ | 23,968 |  |  | $ | 23,400 |  |
| Long-Lived Assets (Year-end) |  |  |  |  |  |
| United States | $ | 1,713 |  |  | $ | 1,824 |  |  | $ | 1,879 |  |
| China | 164 |  |  | 326 |  |  | 332 |  |
| Japan | 204 |  |  | 228 |  |  | 209 |  |
| Germany | 22 |  |  | 20 |  |  | 19 |  |
| United Kingdom | 70 |  |  | 77 |  |  | 73 |  |
| Taiwan | 133 |  |  | 141 |  |  | 154 |  |
| Other foreign | 567 |  |  | 568 |  |  | 464 |  |
| Other European countries | 186 |  |  | 164 |  |  | 170 |  |
| Total | $ | 3,059 |  |  | $ | 3,348 |  |  | $ | 3,300 |  |

[0000833444-20-000048:notes:425]
Net sales attributed to geographic locations are based on the location of the assets producing the sales. Long-lived assets by geographic location consist of net property, plant and equipment.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0000833444-20-000048:notes:426]
NONCONSOLIDATED PARTIALLY-OWNED AFFILIATES  
Investments in the net assets of nonconsolidated partially-owned affiliates are stated in the "Investments in partially-owned affiliates" line in the consolidated statements of financial position as of September 30, 2020 and 2019. Equity in the net income of nonconsolidated partially-owned affiliates is stated in the "Equity income" line in the consolidated statements of income for the years ended September 30, 2020, 2019 and 2018.

[0000833444-20-000048:notes:427]
The following table presents aggregated summarized financial data for the Company’s nonconsolidated partially-owned affiliates which were considered significant subsidiaries in fiscal 2019 and 2018, but not in fiscal 2020 due to adoption of the SEC Final Rule Release No. 33-10786. The amounts included in the table below represent 100% of the results of continuing operations of such nonconsolidated partially-owned affiliates accounted for under the equity method.

[0000833444-20-000048:notes:428]
Summarized balance sheet data as of September 30, 2019 is as follows (in millions):

[0000833444-20-000048:notes:429]
|  |  |  | September 30, 2019 |
| Current assets |  |  | $ | 2,941 |  |
| Noncurrent assets |  |  | 1,020 |  |
| Total assets |  |  | $ | 3,961 |  |
| Current liabilities |  |  | $ | 2,135 |  |
| Noncurrent liabilities |  |  | 157 |  |
| Noncontrolling interests |  |  | 67 |  |
| Shareholders’ equity |  |  | 1,602 |  |
| Total liabilities and shareholders’ equity |  |  | $ | 3,961 |  |

[0000833444-20-000048:notes:430]
Summarized income statement data for the years ended September 30, 2019 and 2018 is as follows (in millions):

[0000833444-20-000048:notes:431]
|  |  |  | Year Ended September 30, |
|  |  |  | 2019 |  | 2018 |
| Net sales |  |  | $ | 3,882 |  |  | $ | 3,974 |  |
| Gross profit |  |  | 1,070 |  |  | 1,049 |  |
| Net income |  |  | 411 |  |  | 390 |  |
| Income attributable to noncontrolling interests |  |  | 13 |  |  | 10 |  |
| Net income attributable to the entity |  |  | 398 |  |  | 380 |  |


## us-gaap:GuaranteesTextBlock

[0000833444-20-000048:notes:432]
GUARANTEES
Certain of the Company's subsidiaries at the business segment level have guaranteed the performance of third-parties and provided financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from the current fiscal year through the completion of such transactions and would typically be triggered in the event of nonperformance. Performance under the guarantees, if required, would not have a material effect on the Company's financial position, results of operations or cash flows.

[0000833444-20-000048:notes:433]
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. A typical warranty program requires that the Company replace defective products within a specified time period from the date of sale. The Company records an estimate for future warranty-related costs based on actual historical return rates and other known factors. Based on analysis of return rates and other factors, the Company’s warranty provisions are adjusted as necessary. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different than those estimates.

[0000833444-20-000048:notes:434]
The Company’s product warranty liability for continuing operations is recorded in the consolidated statements of financial position in other current liabilities if the warranty is less than one year and in other noncurrent liabilities if the warranty extends longer than one year.

[0000833444-20-000048:notes:435]
The changes in the carrying amount of the Company’s total product warranty liability for continuing operations for the fiscal years ended September 30, 2020 and 2019 were as follows (in millions). Extended warranty for which deferred revenue is recorded is not included in the table below, but rather included within the contract balances table in the Note 4, "Revenue Recognition," of the notes to consolidated financial statements for all periods presented.

[0000833444-20-000048:notes:436]
|  | Year EndedSeptember 30, |
|  | 2020 |  | 2019 |
| Balance at beginning of period | $ | 156 |  |  | $ | 197 |  |
| Accruals for warranties issued during the period | 71 |  |  | 78 |  |
| Accruals from acquisitions and divestitures | — |  |  | 1 |  |
| Accruals related to pre-existing warranties (including changes in estimates) | 9 |  |  | (39) |  |
| Settlements made (in cash or in kind) during the period | (71) |  |  | (79) |  |
| Currency translation | 2 |  |  | (2) |  |
| Balance at end of period | $ | 167 |  |  | $ | 156 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-20-000048:notes:437]
COMMITMENTS AND CONTINGENCIES
Environmental Matters

[0000833444-20-000048:notes:438]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of September 30, 2020, reserves for environmental liabilities for continuing operations totaled $130 million, of which $61 million was recorded within other current liabilities and $69 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $159 million at September 30, 2019, of which $52 million was recorded within other current liabilities and $107 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.

[0000833444-20-000048:notes:439]
Tyco Fire Products L.P. (“Tyco Fire Products”), in coordination with the Wisconsin Department of Natural Resources ("WDNR"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin. In connection with the assessment, perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluorinated substances ("PFAS") have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC. Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working with WDNR to address these issues insofar as they related to this migration.

[0000833444-20-000048:notes:440]
During the third quarter of 2019, the Company increased its environmental reserves, which included $140 million related to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The Company is not able to estimate a possible loss or range of loss in excess of the established accruals at this time.

[0000833444-20-000048:notes:441]
A substantial portion of the increased reserves relates to remediation resulting from the use of fire-fighting foams containing PFAS at the FTC. The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The reserve was recorded in the quarter ended June 30, 2019 following a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR.

[0000833444-20-000048:notes:442]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. On August 22, 2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating

[0000833444-20-000048:notes:443]
Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation.

[0000833444-20-000048:notes:444]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. Tyco Fire Products voluntarily responded to the WDNR’s letter to request additional necessary information. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 3, 2019 letter. The letter stated that “if you fail to take the actions required by Wis. Stat. § 292.11 to address this contamination, the DNR will move forward under Wis. Stat. § 292.31 to implement the SI workplan and evaluate further environmental enforcement actions and cost recovery under Wis. Stat. § 292.31(8).” The WDNR issued a further letter regarding the issue on November 4, 2019. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

[0000833444-20-000048:notes:445]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”) manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. The increase in the reserve related to the Stanton Street Facility was recorded following a further review of the Consent Order, which resulted in the identification of several structural upgrades needed to preserve the effectiveness of prior remediation efforts. In addition to ongoing remediation activities, the Company is also working with the WDNR to investigate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation of PFAS in the Marinette region.

[0000833444-20-000048:notes:446]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At September 30, 2020 and 2019, the Company recorded conditional asset retirement obligations for continuing operations of $29 million and $30 million, respectively.

[0000833444-20-000048:notes:447]
Asbestos Matters

[0000833444-20-000048:notes:448]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-20-000048:notes:449]
As of September 30, 2020, the Company's estimated asbestos-related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $115 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $483 million, of which $49 million was recorded in other current liabilities and $434 million was recorded in other noncurrent liabilities. The

[0000833444-20-000048:notes:450]
Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $368 million, of which $39 million was recorded in other current assets and $329 million was recorded in other noncurrent assets. Assets included $9 million of cash and $291 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2020 was $68 million.

[0000833444-20-000048:notes:451]
As of September 30, 2019, the Company's estimated asbestos-related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $141 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $507 million, of which $50 million was recorded in other current liabilities and $457 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $366 million, of which $46 million was recorded in other current assets and $320 million was recorded in other noncurrent assets. Assets included $16 million of cash and $273 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2019 was $77 million.

[0000833444-20-000048:notes:452]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos- related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-20-000048:notes:453]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-20-000048:notes:454]
Insurable Liabilities

[0000833444-20-000048:notes:455]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At September 30, 2020 and 2019, the insurable liabilities totaled $363 million and $379 million, respectively, of which $83 million and $99 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $258 million and $258 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at September 30, 2020 were $21 million, of which $5 million was recorded within other current assets and $16 million was recorded within other noncurrent assets, respectively. The amount of such receivables recorded at September 30, 2019 were $23 million, of which $5 million was recorded within other current assets and

[0000833444-20-000048:notes:456]
$18 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-20-000048:notes:457]
Aqueous Film-Forming Foam ("AFFF") Litigation

[0000833444-20-000048:notes:458]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but has stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

[0000833444-20-000048:notes:459]
Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-20-000048:notes:460]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to or are being directly filed in the MDL.

[0000833444-20-000048:notes:461]
AFFF Putative Class Actions

[0000833444-20-000048:notes:462]
Chemguard and Tyco Fire Products are named in 30 putative class actions in federal courts originating from Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington, New Hampshire, South Carolina, the District of Columbia, Guam, West Virginia, Michigan and South Dakota. All but one of these cases has been transferred to the MDL, and it is anticipated that the remaining case will be removed to federal court and transferred following service of the complaint.

[0000833444-20-000048:notes:463]
AFFF Individual or Mass Actions

[0000833444-20-000048:notes:464]
There are approximately 746 individual or “mass” actions pending that were filed in state or federal court in California (5 cases), Colorado (41 cases), New York (4 cases), Pennsylvania (15 cases), New Mexico (2 cases), Missouri (1 case), Arizona (1 case), and South Carolina (677 cases direct filed from various U.S. jurisdictions) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve five plaintiffs in California, approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, 15 plaintiffs in Pennsylvania, two plaintiffs in New Mexico, one plaintiff in Missouri, two plaintiffs in Arizona, and more than 500 plaintiffs from various states who direct-filed complaints in South Carolina. All but six of these matters have been transferred to or directly-filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. Many of the additional filed actions were directly filed in South Carolina by plaintiffs who were among the 660 plaintiffs the Company had previously disclosed to have made filings in Pennsylvania state court. The Company anticipates that the remainder of the possible individual product liability claims filed in Pennsylvania state court will either soon be filed in the MDL (and that all such claims in state court will be dismissed accordingly) or will be dismissed in Pennsylvania without a corresponding filing in South Carolina.

[0000833444-20-000048:notes:465]
AFFF Municipal Cases

[0000833444-20-000048:notes:466]
Chemguard and Tyco Fire Products are also defendants in 58 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Arizona, California, Colorado, Florida, Massachusetts, New Jersey, New York, Maryland, Ohio, Pennsylvania, Washington, the District of Columbia and several municipalities or water providers from various states who direct-filed complaints in South Carolina. All but three of these cases have been transferred to or directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property. Since the beginning of fiscal year 2021, two municipal actions have been filed against the Company.

[0000833444-20-000048:notes:467]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly resulting from the use of those products at the Peterson Air Force Base. In May 2020, the Company was also notified by the Lakewood Water District in Pierce County, Washington that it may assert claims regarding remediation in connection with PFOA, PFOS, and other PFAS contamination allegedly resulting from the use of those products at Joint Base Lewis-McChord.

[0000833444-20-000048:notes:468]
State or U.S. Territory Attorneys General Litigation related to AFFF

[0000833444-20-000048:notes:469]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-20-000048:notes:470]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-20-000048:notes:471]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. The 3M Company et al., No. G-4801-CI-021804752-000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio. The lawsuit seeks to recover costs and natural resource damages associated with the contamination. This lawsuit has been removed to the United States District Court for the Northern District of Ohio and transferred to the MDL.

[0000833444-20-000048:notes:472]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.). All three of these suits have been removed to federal court and transferred to the MDL.

[0000833444-20-000048:notes:473]
In September 2019, the government of Guam filed a lawsuit in the superior court of Guam against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-20-000048:notes:474]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction. This complaint has been removed to federal court and transferred to the MDL.

[0000833444-20-000048:notes:475]
In August 2020, Attorney General of the State of Michigan filed two substantially similar lawsuits—one in federal court and one in state court—against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within the State.  The federal action has been transferred to the MDL, and the state court action has been removed to federal court and tagged for transfer to the MDL.

[0000833444-20-000048:notes:476]
AFFF Matters Related to the Tyco Fire Products Fire Technology Center in Marinette, Wisconsin

[0000833444-20-000048:notes:477]
Tyco Fire Products and Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFAS (including PFOA/PFOS) contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. A second lawsuit, Duane and Janell Goldsmith individually and on behalf of H.G. and K.G v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) was also filed by a family alleging personal injuries due to contaminated groundwater; this case has been dismissed without prejudice.

[0000833444-20-000048:notes:478]
Other AFFF Related Matters

[0000833444-20-000048:notes:479]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

[0000833444-20-000048:notes:480]
Other PFAS Related Matters

[0000833444-20-000048:notes:481]
In April 2020, the Weirton Area Water Board in West Virginia filed a lawsuit in the Circuit Court of Brooke County, West Virginia against a number of PFAS chemical manufacturers, including Chemguard, with respect to PFAS contamination. This case has been removed to the United States District Court for the Northern District of West Virginia.

[0000833444-20-000048:notes:482]
The Company is vigorously defending the above matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications.  Tyco and Chemguard have insurance that has been in place for many years and the Company is pursuing this coverage for these matters. However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

[0000833444-20-000048:notes:483]
Bosch Litigation

[0000833444-20-000048:notes:484]
On March 15, 2019, a German subsidiary of the Company received a complaint from Robert Bosch GmbH (“Bosch”), filed in a German court. The complaint related to an automotive starter batteries joint venture in which the Company and Bosch were 80/20 parties to this joint venture. At the time the complaint was filed, JCI’s ownership interest in the joint venture was to be transferred to entities controlled by the Purchaser upon consummation of the sale of the Company’s Power Solutions business. The complaint alleged that certain internal Company reorganization transactions were not in compliance with the arrangements relating to such joint venture.

[0000833444-20-000048:notes:485]
On August 8, 2019, Bosch entered into an agreement with Purchaser pursuant to which Purchaser would purchase Bosch’s interest in the joint venture. Simultaneously with this agreement, the Company and Bosch executed an agreement to dismiss the proceedings between the parties upon the completion of Purchaser’s acquisition of Bosch’s interest. In the first quarter of fiscal

[0000833444-20-000048:notes:486]
2020, following the completion of Purchaser’s acquisition of Bosch’s interest in the joint venture, the Company and Bosch made filings with the German court terminating the litigation.

[0000833444-20-000048:notes:487]
Pursuant to the Company’s obligations to Purchaser in connection with the divestiture of the Company’s Power Solutions business, the Company reimbursed Purchaser a portion of its costs in connection with its acquisition of Bosch’s interests in the joint venture, which was reflected as a cash outflow for discontinued operations.

[0000833444-20-000048:notes:488]
Other Matters 
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-20-000048:notes:489]
RELATED PARTY TRANSACTIONS
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-20-000048:notes:490]
The following table presents net sales to and purchases from related parties for the years ended September 30, 2020, 2019, and 2018 (in millions):

[0000833444-20-000048:notes:491]
|  |  | Year Ended September 30, |
|  |  | 2020 |  | 2019 |  | 2018 |
| Net sales to related parties |  | $ | 194 |  |  | $ | 217 |  |  | $ | 220 |  |
| Purchases from related parties |  | 85 |  |  | 66 |  |  | 63 |  |

[0000833444-20-000048:notes:492]
The following table presents receivables from and payables to related parties in the consolidated statements of financial position (in millions):

[0000833444-20-000048:notes:493]
|  |  | September 30, |
|  |  | 2020 |  | 2019 |
| Receivable from related parties |  | $ | 48 |  |  | $ | 34 |  |
| Payable to related parties |  | 11 |  |  | 6 |  |


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000833444-20-000048:notes:494]
JOHNSON CONTROLS INTERNATIONAL PLC AND SUBSIDIARIES

[0000833444-20-000048:notes:495]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0000833444-20-000048:notes:496]
(In millions)

[0000833444-20-000048:notes:497]
| Year Ended September 30, | 2020 |  | 2019 |  | 2018 |
| Accounts Receivable - Allowance for Doubtful Accounts |  |  |  |  |  |
| Balance at beginning of period | $ | 173 |  |  | $ | 169 |  |  | $ | 172 |  |
| Provision charged to costs and expenses | 20 |  |  | 37 |  |  | 14 |  |
| Accounts charged off, net of recoveries | (21) |  |  | (21) |  |  | (17) |  |
| Acquisition (divestiture) of businesses | — |  |  | (10) |  |  | — |  |
| Currency translation | 1 |  |  | (2) |  |  | — |  |
| Balance at end of period | $ | 173 |  |  | $ | 173 |  |  | $ | 169 |  |
| Deferred Tax Assets - Valuation Allowance |  |  |  |  |  |
| Balance at beginning of period | $ | 5,068 |  |  | $ | 5,088 |  |  | $ | 3,735 |  |
| Allowance provision for new operating and other loss carryforwards | 624 |  |  | 195 |  |  | 1,639 |  |
| Allowance provision (benefits) | (174) |  |  | (215) |  |  | (286) |  |
| Balance at end of period | $ | 5,518 |  |  | $ | 5,068 |  |  | $ | 5,088 |  |
