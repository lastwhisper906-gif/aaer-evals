# JCI 10-K controls and the auditor's report


## auditors_report

[0000833444-20-000048:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0000833444-20-000048:auditors_report:2]
To the Board of Directors and Shareholders of Johnson Controls International plc

[0000833444-20-000048:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0000833444-20-000048:auditors_report:4]
We have audited the accompanying consolidated statements of financial position of Johnson Controls International plc and its subsidiaries (the “Company”) as of September 30, 2020 and 2019, and the related consolidated statements of income, of comprehensive income (loss), of shareholders’ equity attributable to Johnson Controls ordinary shareholders, and of cash flows for each of the three years in the period ended September 30, 2020, including the related notes and financial statement schedule listed in the accompanying index (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of September 30, 2020, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0000833444-20-000048:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of September 30, 2020 and 2019, and the results of its operations and its cash flows for each of the three years in the period ended September 30, 2020 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of September 30, 2020, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0000833444-20-000048:auditors_report:6]
Change in Accounting Principle

[0000833444-20-000048:auditors_report:7]
As discussed in Note 1 to the consolidated financial statements, the Company changed the manner in which it accounts for leases as of October 1, 2019.

[0000833444-20-000048:auditors_report:8]
Basis for Opinions

[0000833444-20-000048:auditors_report:9]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in Management’s Report on Internal Control Over Financial Reporting appearing under Item 9A. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000833444-20-000048:auditors_report:10]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0000833444-20-000048:auditors_report:11]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based

[0000833444-20-000048:auditors_report:12]
47

[0000833444-20-000048:auditors_report:13]
on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0000833444-20-000048:auditors_report:14]
Definition and Limitations of Internal Control over Financial Reporting

[0000833444-20-000048:auditors_report:15]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0000833444-20-000048:auditors_report:16]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000833444-20-000048:auditors_report:17]
Critical Audit Matters

[0000833444-20-000048:auditors_report:18]
The critical audit matters communicated below are matters arising from the current period audit of the consolidated financial statements that were communicated or required to be communicated to the audit committee and that (i) relate to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0000833444-20-000048:auditors_report:19]
Goodwill Impairment Assessment

[0000833444-20-000048:auditors_report:20]
As described in Note 7 to the consolidated financial statements, the Company’s consolidated goodwill balance was $17,932 million as of September 30, 2020. Management reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. Management considered the ongoing deterioration in general economic and market conditions due to the COVID-19 pandemic and its impact on each of the Company’s reporting units’ performance. Due to further declines in cash flow projections of the North America Retail reporting unit in the third quarter of fiscal 2020 as a result of the COVID-19 pandemic, management concluded a triggering event occurred requiring assessment of impairment for its North America Retail reporting unit. As a result, management recorded a non-cash impairment charge of $424 million in the third quarter of fiscal 2020. Management reviewed the goodwill of all reporting units for the fiscal 2020 annual impairment test in the fourth quarter, and there were no additional impairments recorded. Management performs impairment reviews for its reporting units using a fair value method based on management’s judgments and assumptions. The estimated fair value is then compared with the carrying amount of each reporting unit, including recorded goodwill. In estimating the fair value of the reporting units, management uses multiples of earnings based on the average of published multiples of earnings of comparable entities with similar operations and economic characteristics and applies the multiples to the Company’s average of historical and future financial results for each reporting unit. In certain instances, management uses discounted cash flow analyses to further support the fair value estimates, whereby other than management’s internal projections of future cash flows, the primary assumptions were the weighted-average cost of capital and long-term growth rates.

[0000833444-20-000048:auditors_report:21]
The principal considerations for our determination that performing procedures relating to the goodwill impairment assessment is a critical audit matter are the significant judgment by management when developing the fair value of each reporting unit; this, in turn, led to a high degree of auditor judgment, subjectivity, and effort in performing procedures and evaluating management’s significant assumptions relating to (i) the multiples of earnings of comparable entities with similar operations and economic characteristics when using the multiples of earnings approach and (ii) the revenue growth rates included in the internal projections of future cash flows, discount rates used in the weighted-average cost of capital and long-term growth rates when using discounted cash flow analyses. In addition, the audit effort involved the use of professionals with specialized skill and knowledge.

[0000833444-20-000048:auditors_report:22]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to

[0000833444-20-000048:auditors_report:23]
48

[0000833444-20-000048:auditors_report:24]
management’s goodwill impairment assessment, including controls over the fair value of the Company’s reporting units. These procedures also included, among others, (i) testing management’s process for developing the fair value estimates, (ii) evaluating the appropriateness of the multiples of earnings model and the discounted cash flow model, as applicable, (iii) testing the completeness, accuracy, and relevance of underlying data used in the models, and (iv) evaluating the significant assumptions used by management related to the multiples of earnings of comparable entities with similar operations and economic characteristics, revenue growth rates, discount rates and long-term growth rates. In those instances where management used a multiples of earnings approach, evaluating management’s assumption related to the identification of appropriate comparable entities with similar operations and economic characteristics used to determine the multiples of earnings of each reporting unit involved evaluating whether the assumption used by management was reasonable considering (i) current and past financial performance of the reporting units, (ii) external market, industry and macroeconomic data, and (iii) whether the assumption was consistent with evidence obtained in other areas of the audit. In those instances where management used discounted cash flow analyses, evaluating management’s assumptions related to the revenue growth rates, discount rates and long-term growth rates involved evaluating whether the assumptions used by management were reasonable considering (i) current and past financial performance of the reporting units, (ii) external market, industry and macroeconomic data, and (iii) whether these assumptions were consistent with evidence obtained in other areas of the audit. Professionals with specialized skill and knowledge were used to assist in the evaluation of management’s fair value models and management’s significant assumptions related to the multiples of earnings of comparable entities with similar operations and economic characteristics, discount rates used in the weighted-average cost of capital, and long-term growth rates.

[0000833444-20-000048:auditors_report:25]
Uncertain Tax Positions

[0000833444-20-000048:auditors_report:26]
As described in Note 18 to the consolidated financial statements, the Company recorded uncertain tax position liabilities totaling $2,528 million, primarily as a non-current liability, as of September 30, 2020. The Company is subject to income taxes in the U.S. and numerous foreign jurisdictions. Judgment is required by management in determining the Company’s worldwide provision for income taxes and recording the related income tax assets and liabilities. In the ordinary course of the Company’s business, there are many transactions and calculations where the ultimate tax determination is uncertain. As disclosed by management, a liability for the best estimate of the probable loss on certain of the tax positions has been recorded by management. The Company’s income tax filings are regularly under audit by tax authorities. The amounts ultimately paid, if any, upon resolution of the issues raised by the taxing authorities may differ materially from the amounts accrued for each year.

[0000833444-20-000048:auditors_report:27]
The principal considerations for our determination that performing procedures relating to uncertain tax positions is a critical audit matter are (i) the significant judgment by management in identifying and recording the estimated probable loss for each uncertain tax position; this, in turn, led to a high degree of auditor judgment, subjectivity, and effort in performing procedures to evaluate the timely identification and accurate measurement of uncertain tax positions, (ii) the evaluation of audit evidence available to support the tax liabilities for uncertain tax positions is complex and resulted in significant auditor judgment as the nature of the evidence is often highly subjective, and (iii) the audit effort involved the use of professionals with specialized skill and knowledge.

[0000833444-20-000048:auditors_report:28]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to management’s assessment of uncertain tax positions, including controls over the identification and estimate of probable loss for uncertain tax positions. These procedures also included, among others, (i) for a sample of uncertain tax positions by jurisdiction, testing the information used in the calculation of the estimate of probable loss and testing the calculation of the estimate of probable loss, (ii) testing the completeness of management’s assessment of the identification of uncertain tax positions, and (iii) evaluating the status and results of income tax audits with the relevant tax authorities, as applicable. Professionals with specialized skill and knowledge were used to assist in the evaluation of the completeness and measurement of the Company’s uncertain tax positions, including evaluating the reasonableness of management’s assessment of whether tax positions are more-likely-than-not of being sustained and the amount of potential benefit to be realized, and the application of relevant tax laws.

[0000833444-20-000048:auditors_report:29]
| /s/ PricewaterhouseCoopers LLP |
| Milwaukee, Wisconsin |
| November 16, 2020 |

[0000833444-20-000048:auditors_report:30]
We have served as the Company’s auditor since 1957.

[0000833444-20-000048:auditors_report:31]
49

[0000833444-20-000048:auditors_report:32]
Johnson Controls International plc


## item_9a

[0000833444-20-000048:item_9a:1]
ITEM 9A    CONTROLS AND PROCEDURES

[0000833444-20-000048:item_9a:2]
Disclosure Controls and Procedures

[0000833444-20-000048:item_9a:3]
The Company’s management, with the participation of the Company’s Chief Executive Officer and Chief Financial Officer, has evaluated the effectiveness of the Company’s disclosure controls and procedures (as such term is defined in Rule 13a-15(e) under the Securities Exchange Act of 1934, as amended (the "Exchange Act")) as of the end of the period covered by this report. Based on such evaluations, the Company’s Chief Executive Officer and Chief Financial Officer have concluded that, as of the end of such period, the Company’s disclosure controls and procedures are effective in recording, processing, summarizing, and reporting, on a timely basis, information required to be disclosed by the Company in the reports that it files or submits under the Exchange Act, and that information is accumulated and communicated to the Company’s management, including the Company’s Chief Executive Officer and Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure.

[0000833444-20-000048:item_9a:4]
Management’s Report on Internal Control Over Financial Reporting

[0000833444-20-000048:item_9a:5]
The Company’s management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rule 13a-15(f). The Company’s management, with the participation of the Company’s Chief Executive Officer and Chief Financial Officer, has evaluated the effectiveness of the Company’s internal control over financial reporting based on the framework in Internal Control-Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on this evaluation, the Company’s management has concluded that, as of September 30, 2020, the Company’s internal control over financial reporting was effective.

[0000833444-20-000048:item_9a:6]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000833444-20-000048:item_9a:7]
PricewaterhouseCoopers LLP, an independent registered public accounting firm, has audited the Company’s consolidated financial statements and the effectiveness of internal control over financial reporting as of September 30, 2020 as stated in its report which is included in Item 8 of this Form 10-K and is incorporated by reference herein.

[0000833444-20-000048:item_9a:8]
113

[0000833444-20-000048:item_9a:9]
Changes in Internal Control Over Financial Reporting

[0000833444-20-000048:item_9a:10]
There have been no changes in the Company’s internal control over financial reporting during the quarter ended September 30, 2020, that have materially affected, or are reasonably likely to materially affect, the Company’s internal control over financial reporting.
