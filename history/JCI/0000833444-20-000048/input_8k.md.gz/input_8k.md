# JCI 8-K — 0000833444-20-000043 filed 2020-11-03

## item codes, every 8-K on or before 2020-11-16

- 2020-11-03 0000833444-20-000043 — 2.02, 9.01
- 2020-09-15 0001193125-20-246240 — 1.01, 8.01, 9.01
- 2020-09-11 0001193125-20-244119 — 1.01, 8.01, 9.01
- 2020-08-18 0000833444-20-000038 — 5.02, 9.01
- 2020-07-31 0000833444-20-000034 — 2.02, 9.01
- 2020-06-12 0000833444-20-000020 — 8.01
- 2020-05-01 0000833444-20-000013 — 2.02, 9.01
- 2020-03-12 0000833444-20-000010 — 5.02
- 2020-03-06 0000833444-20-000008 — 5.07
- 2020-01-31 0000833444-20-000003 — 2.02, 9.01
- 2019-12-06 0001193125-19-308301 — 1.01, 1.02, 2.03, 9.01
- 2019-11-07 0000833444-19-000048 — 5.02, 9.01
- 2019-11-07 0000833444-19-000046 — 2.02, 9.01
- 2019-08-21 0000833444-19-000043 — 8.01
- 2019-07-31 0000833444-19-000038 — 2.02, 9.01
- 2019-07-23 0000833444-19-000035 — 5.02, 8.01, 9.01
- 2019-07-02 0000833444-19-000033 — 1.02, 8.01
- 2019-06-05 0001193125-19-165565 — 8.01
- 2019-05-30 0001193125-19-160205 — 8.01, 9.01
- 2019-05-16 0001193125-19-148262 — 8.01, 9.01
- 2019-05-07 0001193125-19-139826 — 5.04, 9.01
- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2020-11-16

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-20-000043:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq4f.htm
EX-99.1

[0000833444-20-000043:8k_2_02:2]
Document

[0000833444-20-000043:8k_2_02:3]
Exhibit 99.1

[0000833444-20-000043:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-20-000043:8k_2_02:5]
JOHNSON CONTROLS REPORTS FISCAL Q4 & FULL YEAR RESULTS, DEMONSTRATING CONTINUED STRONG EXECUTION IN A CHALLENGING ENVIRONMENT

[0000833444-20-000043:8k_2_02:6]
________________________________________________________________________________

[0000833444-20-000043:8k_2_02:7]
▪GAAP EPS of $0.60; Q4 adjusted EPS of $0.76, down 3% versus prior year

[0000833444-20-000043:8k_2_02:8]
▪GAAP EPS of $0.84; Full year adjusted EPS of $2.24, up 14% versus prior year

[0000833444-20-000043:8k_2_02:9]
▪Sequential quarterly improvement in sales, orders and profitability

[0000833444-20-000043:8k_2_02:10]
▪Continued focus on cost mitigation actions in response to global pandemic

[0000833444-20-000043:8k_2_02:11]
▪Q4 and full year cash provided by operating activities of $1.0 billion and $2.5 billion, respectively; Q4 and full year adjusted free cash flow of $1.0 billion and $1.9 billion (115% conversion), respectively

[0000833444-20-000043:8k_2_02:12]
▪Completed approximately $750 million of planned share repurchases in Q4; $2.2 billion for full year

[0000833444-20-000043:8k_2_02:13]
▪Provides fiscal 2021 first quarter adjusted earnings per share guidance range of $0.39 to $0.41

[0000833444-20-000043:8k_2_02:14]
________________________________________________________________________________

[0000833444-20-000043:8k_2_02:15]
CORK, Ireland, November 3, 2020 -- Johnson Controls International plc (NYSE: JCI) today reported fiscal fourth quarter 2020 GAAP earnings per share (“EPS”) from continuing operations, including special items, of $0.60. Excluding these items, adjusted EPS from continuing operations was $0.76, down 3% versus the prior year period (see attached footnotes for non-GAAP reconciliation).

[0000833444-20-000043:8k_2_02:16]
Sales of nearly $6.0 billion decreased 5% compared to the prior year and declined 6% organically, reflecting the continued impact of the COVID-19 pandemic.

[0000833444-20-000043:8k_2_02:17]
GAAP net income from continuing operations was $441 million, earnings before interest and taxes (“EBIT”) was $583 million and EBIT margin was 9.8%. Adjusted net income from continuing operations was $563 million, adjusted EBIT was $770 million and adjusted EBIT margin was 12.9%, in line with prior year results despite the revenue decline.

[0000833444-20-000043:8k_2_02:18]
“Looking back on what was an extraordinary year, I am incredibly proud of how our teams responded in a time of a global pandemic and the progress that we made as an organization. We remained focused on executing on our priorities to support our customers with the most innovative products and solutions, including our OpenBlue digital platform, contributing to a more sustainable world while maintaining the health and safety of our employees and their families, our customers and partners,” said George Oliver, chairman and CEO.  “In the fourth quarter, we performed very well across all of our end markets delivering revenue and EBIT above our prior guidance, with best in class decrementals.  This is a result of continued strong execution on our cost-out initiatives, while maintaining strong reinvestment into our growth platforms.”

[0000833444-20-000043:8k_2_02:19]
Page 1 of 19

[0000833444-20-000043:8k_2_02:20]
Oliver continued, “from a strategic perspective, we executed on the initiatives we set out to accomplish at the beginning of the year, all of which enhance the long-term competitiveness of our business.  I remain confident that Johnson Controls is well positioned to capitalize on the strong secular trends in buildings and infrastructure, providing innovative solutions enhancing air purification and health & safety, while delivering on our customers sustainability goals with industry leading energy management.”

[0000833444-20-000043:8k_2_02:21]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-20-000043:8k_2_02:22]
($ millions, except per-share amounts)

[0000833444-20-000043:8k_2_02:23]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the fourth fiscal quarter and full fiscal year of 2019.

[0000833444-20-000043:8k_2_02:24]
Organic sales growth, organic EBITA growth, segment EBITA, adjusted segment EBITA, adjusted corporate expense, EBIT, adjusted EBIT, adjusted net income from continuing operations, adjusted EPS from continuing operations and adjusted free cash flow are non-GAAP financial measures. For a reconciliation of these non-GAAP measures and detail of the special items, refer to the attached footnotes. A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-20-000043:8k_2_02:25]
|  | Fiscal Q4 |  |  | Fiscal Year |
|  | GAAP | Adjusted |  |  | GAAP | Adjusted |
|  | 2019 | 2020 | 2019 | 2020 |  |  | 2019 | 2020 | 2019 | 2020 |
| Sales | $6,274 | $5,954 | $6,274 | $5,954 |  |  | $23,968 | $22,317 | $23,968 | $22,317 |
| Segment EBITA | 962 | 869 | 990 | 926 |  |  | 3,041 | 2,948 | 3,243 | 3,020 |
| EBIT | 75 | 583 | 812 | 770 |  |  | 1,406 | 1,134 | 2,490 | 2,365 |
| Net income fromcontinuing operations | 612 | 441 | 615 | 563 |  |  | 1,100 | 631 | 1,710 | 1,688 |
| Diluted EPS fromcontinuing operations | $0.77 | $0.60 | $0.78 | $0.76 |  |  | $1.26 | $0.84 | $1.96 | $2.24 |

[0000833444-20-000043:8k_2_02:26]
Page 2 of 19

[0000833444-20-000043:8k_2_02:27]
SEGMENT RESULTS

[0000833444-20-000043:8k_2_02:28]
Building Solutions North America

[0000833444-20-000043:8k_2_02:29]
|  | Fiscal Q4 |  | Fiscal Year |
|  | GAAP | Adjusted |  | GAAP | Adjusted |
|  | 2019 | 2020 | 2019 | 2020 |  | 2019 | 2020 | 2019 | 2020 |
| Sales | $2,401 | $2,243 | $2,401 | $2,243 |  | $9,031 | $8,605 | $9,031 | $8,605 |
| Segment EBITA | 346 | 341 | 357 | 345 |  | 1,153 | 1,157 | 1,179 | 1,168 |
| Segment EBITA Margin % | 14.4% | 15.2% | 14.9% | 15.4% |  | 12.8% | 13.4% | 13.1% | 13.6% |

[0000833444-20-000043:8k_2_02:30]
Sales in the quarter of $2.2 billion, decreased 7% versus the prior year. Organic sales were down 6% versus the prior year, driven by a decline in project installations and, to a much lesser extent, service.  Growth in Performance Solutions was more than offset by a decline in Fire & Security and HVAC & Controls.

[0000833444-20-000043:8k_2_02:31]
Orders in the quarter, excluding M&A and adjusted for foreign currency, decreased 9% year-over-year driven by lower demand due to the COVID-19 pandemic.  Backlog at the end of the quarter of $5.9 billion was consistent with the prior year, excluding M&A and adjusted for foreign currency.

[0000833444-20-000043:8k_2_02:32]
Adjusted segment EBITA was $345 million, down 3% versus the prior year. Adjusted segment EBITA margin of 15.4% expanded 50 basis points versus the prior year driven by significant cost mitigation actions and restructuring benefits, which more than offset the volume decline and negative mix.

[0000833444-20-000043:8k_2_02:33]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-20-000043:8k_2_02:34]
|  | Fiscal Q4 |  | Fiscal Year |
|  | GAAP | Adjusted |  | GAAP | Adjusted |
|  | 2019 | 2020 | 2019 | 2020 |  | 2019 | 2020 | 2019 | 2020 |
| Sales | $948 | $906 | $948 | $906 |  | $3,655 | $3,440 | $3,655 | $3,440 |
| Segment EBITA | 110 | 101 | 111 | 103 |  | 368 | 338 | 372 | 340 |
| Segment EBITA Margin % | 11.6% | 11.1% | 11.7% | 11.4% |  | 10.1% | 9.8% | 10.2% | 9.9% |

[0000833444-20-000043:8k_2_02:35]
Sales in the quarter of $906 million decreased 4% versus the prior year. Organic sales declined 7% versus the prior year driven by a decline in project installations and, to a much lesser extent, service.  Volume declined across all regions and platforms.

[0000833444-20-000043:8k_2_02:36]
Page 3 of 19

[0000833444-20-000043:8k_2_02:37]
Orders in the quarter, excluding M&A and adjusted for foreign currency, decreased 7% year-over-year driven by lower demand due to the COVID-19 pandemic.  Backlog at the end of the quarter of $1.6 billion increased 1% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-20-000043:8k_2_02:38]
Adjusted segment EBITA was $103 million, down 7% versus the prior year. Adjusted segment EBITA margin of 11.4% declined 30 basis points over the prior year, including a 20 basis point headwind related  to foreign currency.  Adjusting for foreign currency, the underlying margin declined 10 basis points as the impact of the volume decline more than offset positive mix and mitigating cost actions.

[0000833444-20-000043:8k_2_02:39]
Building Solutions Asia Pacific

[0000833444-20-000043:8k_2_02:40]
|  | Fiscal Q4 |  | Fiscal Year |
|  | GAAP | Adjusted |  | GAAP | Adjusted |
|  | 2019 | 2020 | 2019 | 2020 |  | 2019 | 2020 | 2019 | 2020 |
| Sales | $726 | $661 | $726 | $661 |  | $2,658 | $2,403 | $2,658 | $2,403 |
| Segment EBITA | 101 | 90 | 103 | 97 |  | 341 | 319 | 343 | 326 |
| Segment EBITA Margin % | 13.9% | 13.6% | 14.2% | 14.7% |  | 12.8% | 13.3% | 12.9% | 13.6% |

[0000833444-20-000043:8k_2_02:41]
Sales in the quarter of $661 million decreased 9% versus the prior year. Organic sales declined 10% versus the prior year primarily driven by a decline in project installations and, to a much lesser extent, service.  Although China continues to rebound, declines continue in certain other parts of the region.

[0000833444-20-000043:8k_2_02:42]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 2% year-over-year driven by significantly improved demand in China.  Backlog at the end of the quarter of $1.7 billion increased 10% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-20-000043:8k_2_02:43]
Adjusted segment EBITA was $97 million, down 6% versus the prior year. Adjusted segment EBITA margin of 14.7% expanded 50 basis points over the prior, including a 20 basis point benefit from foreign currency.  Adjusting for foreign currency, the underlying margin improved 30 basis points as favorable mix and the benefit of mitigating cost actions more than offset the volume decline.

[0000833444-20-000043:8k_2_02:44]
Page 4 of 19

[0000833444-20-000043:8k_2_02:45]
Global Products

[0000833444-20-000043:8k_2_02:46]
|  | Fiscal Q4 |  | Fiscal Year |
|  | GAAP | Adjusted |  | GAAP | Adjusted |
|  | 2019 | 2020 | 2019 | 2020 |  | 2019 | 2020 | 2019 | 2020 |
| Sales | $2,199 | $2,144 | $2,199 | $2,144 |  | $8,624 | $7,869 | $8,624 | $7,869 |
| Segment EBITA | 405 | 337 | 419 | 381 |  | 1,179 | 1,134 | 1,349 | 1,186 |
| Segment EBITA Margin % | 18.4% | 15.7% | 19.1% | 17.8% |  | 13.7% | 14.4% | 15.6% | 15.1% |

[0000833444-20-000043:8k_2_02:47]
Sales in the quarter of $2.1 billion decreased 3% versus the prior year. Organic sales also declined 3% versus the prior year with a low-single digit decline in both Building Management Systems and HVAC & Refrigeration Equipment and a high-single digit decline in Specialty Products.

[0000833444-20-000043:8k_2_02:48]
Adjusted segment EBITA was $381 million, down 9% versus the prior year. Adjusted segment EBITA margin of 17.8% declined 130 basis points versus the prior year as positive price/cost and the benefit of mitigating cost actions was more than offset by the volume decline and related absorption as well as negative mix.

[0000833444-20-000043:8k_2_02:49]
Corporate

[0000833444-20-000043:8k_2_02:50]
|  | Fiscal Q4 |  | Fiscal Year |
|  | GAAP | Adjusted |  | GAAP | Adjusted |
|  | 2019 | 2020 | 2019 | 2020 |  | 2019 | 2020 | 2019 | 2020 |
| Corporate Expense | ($172) | ($68) | ($89) | ($58) |  | ($405) | ($371) | ($376) | ($269) |

[0000833444-20-000043:8k_2_02:51]
Adjusted Corporate expense was $58 million in the quarter, a decrease of 35% compared to the prior year, driven primarily by mitigating cost actions, continued productivity savings and cost synergies, and cost reduction actions related to the Power Solutions sale.

[0000833444-20-000043:8k_2_02:52]
OTHER ITEMS

[0000833444-20-000043:8k_2_02:53]
▪For the quarter, cash provided by operating activities from continuing operations was $1.0 billion and capital expenditures were $0.1 billion, resulting in free cash flow from continuing operations of $0.9 billion.  Adjusted free cash flow was $1.0 billion, which excludes net cash outflows of $0.2 billion primarily related to restructuring and integration payments.

[0000833444-20-000043:8k_2_02:54]
Page 5 of 19

[0000833444-20-000043:8k_2_02:55]
▪For the full year, cash provided by operating activities from continuing operations was $2.5 billion and capital expenditures were $0.4 billion, resulting in a free cash flow from continuing operations of $2.0 billion.  Adjusted free cash flow was $1.9 billion, which excludes net cash inflows of $0.1 billion primarily related to a non-recurring tax refund, partially offset by restructuring and integration payments.

[0000833444-20-000043:8k_2_02:56]
▪During the quarter, the Company repurchased 19 million shares for approximately $750 million.  For the full year, the Company repurchased 55 million shares for $2.2 billion.

[0000833444-20-000043:8k_2_02:57]
▪During the quarter, the Company repaid $2.2 billion of European debt, bank loans and other current maturities, including a €750M Euro note originally due December 2020, and refinanced approximately $1.8 billion.  As part of the refinancing, the Company issued two €500M European bonds (7 and 12-year maturities).  The Company also issued a $625 million 10-year bond in its inaugural green bond offering.

[0000833444-20-000043:8k_2_02:58]
▪During the quarter, the Company recorded net pre-tax mark-to-market losses of $120 million related primarily to year-end pension adjustments as a result of lower interest rates.

[0000833444-20-000043:8k_2_02:59]
▪During the quarter, the Company recorded pre-tax integration costs of $28 million and an acquisition related compensation charge of $39 million.

[0000833444-20-000043:8k_2_02:60]
▪During the quarter, the Company recorded a tax benefit of $26 million related to net tax audit reserve adjustments.

[0000833444-20-000043:8k_2_02:61]
FY21 FIRST QUARTER GUIDANCE

[0000833444-20-000043:8k_2_02:62]
The Company announced fiscal 2021 first quarter guidance:

[0000833444-20-000043:8k_2_02:63]
▪Organic revenue decline in the range of 5 to 7%

[0000833444-20-000043:8k_2_02:64]
▪Adjusted EBIT margin expansion of 20 to 40 basis points, year-over-year

[0000833444-20-000043:8k_2_02:65]
▪Adjusted EPS before special items of $0.39 to $0.41

[0000833444-20-000043:8k_2_02:66]
Page 6 of 19

[0000833444-20-000043:8k_2_02:67]
JOHNSON CONTROLS CONTACTS:

[0000833444-20-000043:8k_2_02:68]
| INVESTORS: | MEDIA: |  |  |  |
| Antonella Franzen | Phil Clement |  |  |  |
| Direct: 609.720.4665 | Direct: 414.208.5161 |  |  |  |
| Email: antonella.franzen@jci.com | Email: phil.clement@jci.com |  |  |  |
| Ryan Edelman | Fraser Engerman |  |  |  |
| Direct: 609.720.4545 | Direct: 414.308.8321 |  |  |  |
| Email: ryan.edelman@jci.com | Email: fraser.engerman@jci.com |  |  |  |

[0000833444-20-000043:8k_2_02:69]
###

[0000833444-20-000043:8k_2_02:70]
About Johnson Controls:

[0000833444-20-000043:8k_2_02:71]
At Johnson Controls, we transform the environments where people live, work, learn and play. From optimizing building performance to improving safety and enhancing comfort, we drive the outcomes that matter most. We deliver our promise in industries such as healthcare, education, data centers, and manufacturing. With a global team of 100,000 experts in more than 150 countries and over 130 years of innovation, we are the power behind our customers’ mission. Our leading portfolio of building technology and solutions includes some of the most trusted names in the industry, such as Tyco®, YORK®, Metasys®, Ruskin®, Titus®, Frick®, PENN®, Sabroe®, Simplex®, Ansul® and Grinnell®. For more information, visit www.johnsoncontrols.com or follow us @johnsoncontrols on Twitter

[0000833444-20-000043:8k_2_02:72]
###

[0000833444-20-000043:8k_2_02:73]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-20-000043:8k_2_02:74]
Page 7 of 19

[0000833444-20-000043:8k_2_02:75]
restrictions; maintaining the capacity, reliability and security of our enterprise and product information technology infrastructure; the risk of infringement or expiration of intellectual property rights; any delay or inability of Johnson Controls to realize the expected benefits and synergies of recent portfolio transactions such as its merger with Tyco and the disposition of the Power Solutions business;  the outcome of litigation and governmental proceedings; the ability to hire and retain key senior management; the tax treatment of recent portfolio transactions; significant transaction costs and/or unknown liabilities associated with such transactions; the availability of raw materials and component products; fluctuations in currency exchange rates; work stoppages, union negotiations, labor disputes and other matters associated with the labor force; the cancellation of or changes to commercial arrangements.  A detailed discussion of risks related to Johnson Controls’ business is included in the section entitled “Risk Factors” in Johnson Controls’ Annual Report on Form 10-K for the 2019 fiscal year filed with the SEC on November 21, 2019, which is available at www.sec.gov and www.johnsoncontrols.com under the “Investors” tab. The description of certain of these risks is supplemented in Item 1A of Part II of Johnson Controls’ subsequently filed Quarterly Reports on Form 10-Q. Shareholders, potential investors and others should consider these factors in evaluating the forward-looking statements and should not place undue reliance on such statements. The forward-looking statements included in this communication are made only as of the date of this document, unless otherwise specified, and, except as required by law, Johnson Controls assumes no obligation, and disclaims any obligation, to update such statements to reflect events or circumstances occurring after the date of this communication.

[0000833444-20-000043:8k_2_02:76]
###

[0000833444-20-000043:8k_2_02:77]
Non-GAAP Financial Information

[0000833444-20-000043:8k_2_02:78]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include restructuring and impairment costs, transaction costs, integration costs, net mark-to-market adjustments, tax indemnification reserve release, environmental reserve, loss on extinguishment of debt, Power Solutions gain on sale (net of transaction and other costs), the impact of ceasing the depreciation / amortization expense for Power Solutions business as the business is held for sale, acquisition related compensation charges and discrete tax items. Financial information regarding organic sales, EBIT, EBIT margin, segment EBITA, adjusted segment EBITA, adjusted organic segment EBITA, adjusted segment EBITA margin, adjusted corporate expense, free cash flow, adjusted free cash flow, and adjusted net income (loss) from continuing operations are also presented, which are non-GAAP performance measures. Adjusted segment EBITA excludes special items such as transaction costs, integration costs, environmental reserve and acquisition related compensation charges because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.  For further information on the calculation of thee non-GAAP measures and a reconciliation of these non-GAAP measures, refer to the attached footnotes.

[0000833444-20-000043:8k_2_02:79]
###

[0000833444-20-000043:8k_2_02:80]
Page 8 of 19

[0000833444-20-000043:8k_2_02:81]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |  |
|  |  | Three Months Ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |
| Net sales | $ | 5,954 |  |  |  | $ | 6,274 |  |  |
| Cost of sales | 3,979 |  |  |  | 4,294 |  |  |
|  | Gross profit | 1,975 |  |  |  | 1,980 |  |  |
| Selling, general and administrative expenses | (1,453) |  |  |  | (1,960) |  |  |
| Restructuring and impairment costs | — |  |  |  | — |  |  |
| Net financing charges | (62) |  |  |  | (48) |  |  |
| Equity income | 61 |  |  |  | 55 |  |  |
| Income from continuing operations before income taxes | 521 |  |  |  | 27 |  |  |
| Income tax provision (benefit) | 31 |  |  |  | (627) |  |  |
| Income from continuing operations | 490 |  |  |  | 654 |  |  |
| Income from discontinued operations, net of tax | — |  |  |  | — |  |  |
| Net income | 490 |  |  |  | 654 |  |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 49 |  |  |  | 42 |  |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | — |  |  |
| Net income attributable to JCI | $ | 441 |  |  |  | $ | 612 |  |  |
| Income from continuing operations | $ | 441 |  |  |  | $ | 612 |  |  |
| Income from discontinued operations | — |  |  |  | — |  |  |
| Net income attributable to JCI | $ | 441 |  |  |  | $ | 612 |  |  |
| Diluted earnings per share from continuing operations | $ | 0.60 |  |  |  | $ | 0.77 |  |  |
| Diluted earnings per share from discontinued operations | — |  |  |  | — |  |  |
| Diluted earnings per share | $ | 0.60 |  |  |  | $ | 0.77 |  |  |
| Diluted weighted average shares | 738.1 |  |  |  | 791.7 |  |  |
| Shares outstanding at period end | 726.2 |  |  |  | 777.6 |  |  |

[0000833444-20-000043:8k_2_02:82]
Page 9 of 19

[0000833444-20-000043:8k_2_02:83]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Twelve Months Ended September 30, |
|  |  | 2020 |  |  | 2019 |
| Net sales | $ | 22,317 |  |  |  | $ | 23,968 |  |
| Cost of sales | 14,906 |  |  |  | 16,275 |  |
|  | Gross profit | 7,411 |  |  |  | 7,693 |  |
| Selling, general and administrative expenses | (5,665) |  |  |  | (6,244) |  |
| Restructuring and impairment costs | (783) |  |  |  | (235) |  |
| Net financing charges | (231) |  |  |  | (350) |  |
| Equity income | 171 |  |  |  | 192 |  |
| Income from continuing operations before income taxes | 903 |  |  |  | 1,056 |  |
| Income tax provision (benefit) | 108 |  |  |  | (233) |  |
| Income from continuing operations | 795 |  |  |  | 1,289 |  |
| Income from discontinued operations, net of tax | — |  |  |  | 4,598 |  |
| Net income | 795 |  |  |  | 5,887 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 164 |  |  |  | 189 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | 24 |  |
| Net income attributable to JCI | $ | 631 |  |  |  | $ | 5,674 |  |
| Income from continuing operations | $ | 631 |  |  |  | $ | 1,100 |  |
| Income from discontinued operations | — |  |  |  | 4,574 |  |
| Net income attributable to JCI | $ | 631 |  |  |  | $ | 5,674 |  |
| Diluted earnings per share from continuing operations | $ | 0.84 |  |  |  | $ | 1.26 |  |
| Diluted earnings per share from discontinued operations | — |  |  |  | 5.23 |  |
| Diluted earnings per share | $ | 0.84 |  |  |  | $ | 6.49 |  |
| Diluted weighted average shares | 753.6 |  |  |  | 874.3 |  |
| Shares outstanding at period end | 726.2 |  |  |  | 777.6 |  |

[0000833444-20-000043:8k_2_02:84]
Page 10 of 19

[0000833444-20-000043:8k_2_02:85]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | September 30,2020 |  | September 30,2019 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 1,951 |  |  | $ | 2,805 |  |
| Accounts receivable - net | 5,294 |  |  | 5,770 |  |
| Inventories | 1,773 |  |  | 1,814 |  |
| Assets held for sale | — |  |  | 98 |  |
| Other current assets | 1,035 |  |  | 1,906 |  |
|  | Current assets | 10,053 |  |  | 12,393 |  |
| Property, plant and equipment - net | 3,059 |  |  | 3,348 |  |
| Goodwill | 17,932 |  |  | 18,178 |  |
| Other intangible assets - net | 5,356 |  |  | 5,632 |  |
| Investments in partially-owned affiliates | 914 |  |  | 853 |  |
| Noncurrent assets held for sale | 147 |  |  | 60 |  |
| Other noncurrent assets | 3,354 |  |  | 1,823 |  |
|  | Total assets | $ | 40,815 |  |  | $ | 42,287 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 293 |  |  | $ | 511 |  |
| Accounts payable and accrued expenses | 3,958 |  |  | 4,535 |  |
| Liabilities held for sale | — |  |  | 44 |  |
| Other current liabilities | 3,997 |  |  | 3,980 |  |
|  | Current liabilities | 8,248 |  |  | 9,070 |  |
| Long-term debt | 7,526 |  |  | 6,708 |  |
| Other noncurrent liabilities | 6,508 |  |  | 5,680 |  |
| Shareholders' equity attributable to JCI | 17,447 |  |  | 19,766 |  |
| Noncontrolling interests | 1,086 |  |  | 1,063 |  |
|  | Total liabilities and equity | $ | 40,815 |  |  | $ | 42,287 |  |

[0000833444-20-000043:8k_2_02:86]
Page 11 of 19

[0000833444-20-000043:8k_2_02:87]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Three Months Ended September 30, |
|  |  |  |  |  |  | 2020 |  |  | 2019 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI from continuing operations | $ | 441 |  |  |  | $ | 612 |  |
| Income from continuing operations attributable to noncontrolling interests | 49 |  |  |  | 42 |  |
| Net income from continuing operations | 490 |  |  |  | 654 |  |
| Adjustments to reconcile net income from continuing operations to cash provided by |  |  |  |  |
| operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 206 |  |  |  | 200 |  |
|  |  | Pension and postretirement benefit expense | 76 |  |  |  | 600 |  |
|  |  | Pension and postretirement contributions | (18) |  |  |  | (2) |  |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (45) |  |  |  | (40) |  |
|  |  | Deferred income taxes | (389) |  |  |  | 230 |  |
|  |  | Other - net | (39) |  |  |  | 16 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | 106 |  |  |  | 182 |  |
|  |  |  |  | Inventories | 250 |  |  |  | 217 |  |
|  |  |  |  | Other assets | 68 |  |  |  | (37) |  |
|  |  |  |  | Restructuring reserves | (87) |  |  |  | (37) |  |
|  |  |  |  | Accounts payable and accrued liabilities | 14 |  |  |  | 92 |  |
|  |  |  |  | Accrued income taxes | 348 |  |  |  | (1,043) |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 980 |  |  |  | 1,032 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (96) |  |  |  | (185) |  |
| Acquisition of businesses, net of cash acquired | (18) |  |  |  | (9) |  |
| Business divestitures, net of cash divested | 135 |  |  |  | — |  |
| Other - net | 30 |  |  |  | 24 |  |
|  |  |  |  |  | Cash provided (used) by investing activities from continuing operations | 51 |  |  |  | (170) |  |
| Financing Activities |  |  |  |  |
| Decrease in short and long-term debt - net | (422) |  |  |  | (10) |  |
| Stock repurchases | (737) |  |  |  | (861) |  |
| Payment of cash dividends | (194) |  |  |  | (208) |  |
| Dividends paid to noncontrolling interests | (47) |  |  |  | — |  |
| Proceeds from the exercise of stock options | 33 |  |  |  | 60 |  |
| Cash paid to acquire a noncontrolling interest | (132) |  |  |  | — |  |
| Employee equity-based compensation withholding | (1) |  |  |  | (5) |  |
| Other - net | (8) |  |  |  | 5 |  |
|  |  |  |  |  | Cash used by financing activities from continuing operations | (1,508) |  |  |  | (1,019) |  |
| Discontinued Operations |  |  |  |  |
| Net cash used by operating activities | (5) |  |  |  | (658) |  |
| Net cash provided by investing activities | — |  |  |  | 31 |  |
| Net cash provided by financing activities | — |  |  |  | — |  |
|  |  |  |  |  | Net cash flows used by discontinued operations | (5) |  |  |  | (627) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 87 |  |  |  | (96) |  |
| Changes in cash held for sale | — |  |  |  | — |  |
| Decrease in cash, cash equivalents and restricted cash | $ | (395) |  |  |  | $ | (880) |  |

[0000833444-20-000043:8k_2_02:88]
Page 12 of 19

[0000833444-20-000043:8k_2_02:89]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Twelve Months Ended September 30, |
|  |  |  |  |  |  | 2020 |  |  | 2019 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI from continuing operations | $ | 631 |  |  |  | $ | 1,100 |  |
| Income from continuing operations attributable to noncontrolling interests | 164 |  |  |  | 189 |  |
| Net income from continuing operations | 795 |  |  |  | 1,289 |  |
| Adjustments to reconcile net income from continuing operations to cash provided by |  |  |  |  |
| operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 822 |  |  |  | 825 |  |
|  |  | Pension and postretirement benefit expense | 118 |  |  |  | 515 |  |
|  |  | Pension and postretirement contributions | (61) |  |  |  | (53) |  |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (36) |  |  |  | (34) |  |
|  |  | Deferred income taxes | (537) |  |  |  | 612 |  |
|  |  | Non-cash restructuring and impairment costs | 582 |  |  |  | 235 |  |
|  |  | Other - net | (16) |  |  |  | 124 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | 534 |  |  |  | (312) |  |
|  |  |  |  | Inventories | 45 |  |  |  | (72) |  |
|  |  |  |  | Other assets | (52) |  |  |  | (99) |  |
|  |  |  |  | Restructuring reserves | (29) |  |  |  | (121) |  |
|  |  |  |  | Accounts payable and accrued liabilities | (717) |  |  |  | 56 |  |
|  |  |  |  | Accrued income taxes | 1,031 |  |  |  | (1,222) |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 2,479 |  |  |  | 1,743 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (443) |  |  |  | (586) |  |
| Acquisition of businesses, net of cash acquired | (77) |  |  |  | (25) |  |
| Business divestitures, net of cash divested | 135 |  |  |  | 12 |  |
| Other - net | 127 |  |  |  | 66 |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (258) |  |  |  | (533) |  |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | 385 |  |  |  | (3,629) |  |
| Stock repurchases | (2,204) |  |  |  | (5,983) |  |
| Payment of cash dividends | (790) |  |  |  | (920) |  |
| Proceeds from the exercise of stock options | 75 |  |  |  | 171 |  |
| Dividends paid to noncontrolling interests | (114) |  |  |  | (132) |  |
| Cash paid to acquire a noncontrolling interest | (132) |  |  |  | — |  |
| Employee equity-based compensation withholding | (34) |  |  |  | (31) |  |
| Other - net | (10) |  |  |  | 5 |  |
|  |  |  |  |  | Cash used by financing activities from continuing operations | (2,824) |  |  |  | (10,519) |  |
| Discontinued Operations |  |  |  |  |
| Net cash used by operating activities | (260) |  |  |  | (541) |  |
| Net cash provided by investing activities | — |  |  |  | 12,611 |  |
| Net cash used by financing activities | (113) |  |  |  | (35) |  |
|  |  |  |  |  | Net cash flows provided (used) by discontinued operations | (373) |  |  |  | 12,035 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 115 |  |  |  | (120) |  |
| Changes in cash held for sale | — |  |  |  | 15 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | $ | (861) |  |  |  | $ | 2,621 |  |

[0000833444-20-000043:8k_2_02:90]
Page 13 of 19

[0000833444-20-000043:8k_2_02:91]
FOOTNOTES

[0000833444-20-000043:8k_2_02:92]
1. Financial Summary

[0000833444-20-000043:8k_2_02:93]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and the net mark-to-market adjustments related to restricted asbestos investments and pension and postretirement plans. The financial results shown below are for continuing operations and exclude the Power Solutions business.

[0000833444-20-000043:8k_2_02:94]
| (in millions; unaudited) | Three Months Ended September 30, |  |
|  | 2020 |  | 2019 |  |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |  |
| Net sales |  |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,243 |  |  | $ | 2,243 |  |  | $ | 2,401 |  |  | $ | 2,401 |  |  |
| Building Solutions EMEA/LA | 906 |  |  | 906 |  |  | 948 |  |  | 948 |  |  |
| Building Solutions Asia Pacific | 661 |  |  | 661 |  |  | 726 |  |  | 726 |  |  |
| Global Products | 2,144 |  |  | 2,144 |  |  | 2,199 |  |  | 2,199 |  |  |
| Net sales | $ | 5,954 |  |  | $ | 5,954 |  |  | $ | 6,274 |  |  | $ | 6,274 |  |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 341 |  |  | $ | 345 |  |  | $ | 346 |  |  | $ | 357 |  |  |
| Building Solutions EMEA/LA | 101 |  |  | 103 |  |  | 110 |  |  | 111 |  |  |
| Building Solutions Asia Pacific | 90 |  |  | 97 |  |  | 101 |  |  | 103 |  |  |
| Global Products | 337 |  |  | 381 |  |  | 405 |  |  | 419 |  |  |
| Segment EBITA | 869 |  |  | 926 |  |  | 962 |  |  | 990 |  |  |
| Corporate expenses (2) | (68) |  |  | (58) |  |  | (172) |  |  | (89) |  |  |
| Amortization of intangible assets | (98) |  |  | (98) |  |  | (89) |  |  | (89) |  |  |
| Net mark-to-market adjustments (3) | (120) |  |  | — |  |  | (626) |  |  | — |  |  |
| Restructuring and impairment costs (4) | — |  |  | — |  |  | — |  |  | — |  |  |
| EBIT (5) | 583 |  |  | 770 |  |  | 75 |  |  | 812 |  |  |
| EBIT margin | 9.8 | % |  | 12.9 | % |  | 1.2 | % |  | 12.9 | % |  |
| Net financing charges (6) | (62) |  |  | (62) |  |  | (48) |  |  | (48) |  |  |
| Income from continuing operations before income taxes | 521 |  |  | 708 |  |  | 27 |  |  | 764 |  |  |
| Income tax benefit (provision) (7) | (31) |  |  | (96) |  |  | 627 |  |  | (103) |  |  |
| Income from continuing operations | 490 |  |  | 612 |  |  | 654 |  |  | 661 |  |  |
| Income from continuing operations attributable to noncontrolling interests | (49) |  |  | (49) |  |  | (42) |  |  | (46) |  |  |
| Net income from continuing operations attributable to JCI | $ | 441 |  |  | $ | 563 |  |  | $ | 612 |  |  | $ | 615 |  |  |

[0000833444-20-000043:8k_2_02:95]
| (in millions; unaudited) | Twelve Months Ended September 30, |
|  | 2020 |  | 2019 |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 8,605 |  |  | $ | 8,605 |  |  | $ | 9,031 |  |  | $ | 9,031 |  |
| Building Solutions EMEA/LA | 3,440 |  |  | 3,440 |  |  | 3,655 |  |  | 3,655 |  |
| Building Solutions Asia Pacific | 2,403 |  |  | 2,403 |  |  | 2,658 |  |  | 2,658 |  |
| Global Products | 7,869 |  |  | 7,869 |  |  | 8,624 |  |  | 8,624 |  |
| Net sales | $ | 22,317 |  |  | $ | 22,317 |  |  | $ | 23,968 |  |  | $ | 23,968 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 1,157 |  |  | $ | 1,168 |  |  | $ | 1,153 |  |  | $ | 1,179 |  |
| Building Solutions EMEA/LA | 338 |  |  | 340 |  |  | 368 |  |  | 372 |  |
| Building Solutions Asia Pacific | 319 |  |  | 326 |  |  | 341 |  |  | 343 |  |
| Global Products | 1,134 |  |  | 1,186 |  |  | 1,179 |  |  | 1,349 |  |
| Segment EBITA | 2,948 |  |  | 3,020 |  |  | 3,041 |  |  | 3,243 |  |
| Corporate expenses (2) | (371) |  |  | (269) |  |  | (405) |  |  | (376) |  |
| Amortization of intangible assets | (386) |  |  | (386) |  |  | (377) |  |  | (377) |  |
| Net mark-to-market adjustments (3) | (274) |  |  | — |  |  | (618) |  |  | — |  |
| Restructuring and impairment costs (4) | (783) |  |  | — |  |  | (235) |  |  | — |  |
| EBIT (5) | 1,134 |  |  | 2,365 |  |  | 1,406 |  |  | 2,490 |  |
| EBIT margin | 5.1 | % |  | 10.6 | % |  | 5.9 | % |  | 10.4 | % |
| Net financing charges (6) | (231) |  |  | (231) |  |  | (350) |  |  | (290) |  |
| Income from continuing operations before income taxes | 903 |  |  | 2,134 |  |  | 1,056 |  |  | 2,200 |  |
| Income tax benefit (provision) (7) | (108) |  |  | (288) |  |  | 233 |  |  | (297) |  |
| Income from continuing operations | 795 |  |  | 1,846 |  |  | 1,289 |  |  | 1,903 |  |
| Income from continuing operations attributable to noncontrolling interests | (164) |  |  | (158) |  |  | (189) |  |  | (193) |  |
| Net income from continuing operations attributable to JCI | $ | 631 |  |  | $ | 1,688 |  |  | $ | 1,100 |  |  | $ | 1,710 |  |

[0000833444-20-000043:8k_2_02:96]
(1) The Company's press release and earnings presentation contains financial information regarding segment EBITA, adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures. The Company's definition of adjusted segment EBITA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its businesses. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-20-000043:8k_2_02:97]
A reconciliation of segment EBITA to income from continuing operations is shown earlier within this footnote. The following is the three months ended September 30, 2020 and 2019 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-20-000043:8k_2_02:98]
| (in millions) | Building SolutionsNorth America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | ConsolidatedJCI plc |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Segment EBITA as reported | $ | 341 |  |  | $ | 346 |  |  | $ | 101 |  |  | $ | 110 |  |  | $ | 90 |  |  | $ | 101 |  |  | $ | 337 |  |  | $ | 405 |  |  | $ | 869 |  |  | $ | 962 |  |
| Segment EBITA margin as reported | 15.2 | % |  | 14.4 | % |  | 11.1 | % |  | 11.6 | % |  | 13.6 | % |  | 13.9 | % |  | 15.7 | % |  | 18.4 | % |  | 14.6 | % |  | 15.3 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Integration costs | 4 |  |  | 11 |  |  | 2 |  |  | 1 |  |  | 7 |  |  | 2 |  |  | 5 |  |  | 14 |  |  | 18 |  |  | 28 |  |
| Acquisition related compensation charge | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 39 |  |  | — |  |  | 39 |  |  | — |  |
| Adjusted segment EBITA | $ | 345 |  |  | $ | 357 |  |  | $ | 103 |  |  | $ | 111 |  |  | $ | 97 |  |  | $ | 103 |  |  | $ | 381 |  |  | $ | 419 |  |  | $ | 926 |  |  | $ | 990 |  |
| Adjusted segment EBITA margin | 15.4 | % |  | 14.9 | % |  | 11.4 | % |  | 11.7 | % |  | 14.7 | % |  | 14.2 | % |  | 17.8 | % |  | 19.1 | % |  | 15.6 | % |  | 15.8 | % |

[0000833444-20-000043:8k_2_02:99]
Page 14 of 19

[0000833444-20-000043:8k_2_02:100]
The following is the twelve months ended September 30, 2020 and 2019 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-20-000043:8k_2_02:101]
| (in millions) | Building SolutionsNorth America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | ConsolidatedJCI plc |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Segment EBITA as reported | $ | 1,157 |  |  | $ | 1,153 |  |  | $ | 338 |  |  | $ | 368 |  |  | $ | 319 |  |  | $ | 341 |  |  | $ | 1,134 |  |  | $ | 1,179 |  |  | $ | 2,948 |  |  | $ | 3,041 |  |
| Segment EBITA margin as reported | 13.4 | % |  | 12.8 | % |  | 9.8 | % |  | 10.1 | % |  | 13.3 | % |  | 12.8 | % |  | 14.4 | % |  | 13.7 | % |  | 13.2 | % |  | 12.7 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Integration costs | 11 |  |  | 26 |  |  | 2 |  |  | 4 |  |  | 7 |  |  | 2 |  |  | 13 |  |  | 30 |  |  | 33 |  |  | 62 |  |
| Acquisition related compensation charge | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 39 |  |  | — |  |  | 39 |  |  | — |  |
| Environmental reserve (8) | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 140 |  |  | — |  |  | 140 |  |
| Adjusted segment EBITA | $ | 1,168 |  |  | $ | 1,179 |  |  | $ | 340 |  |  | $ | 372 |  |  | $ | 326 |  |  | $ | 343 |  |  | $ | 1,186 |  |  | $ | 1,349 |  |  | $ | 3,020 |  |  | $ | 3,243 |  |
| Adjusted segment EBITA margin | 13.6 | % |  | 13.1 | % |  | 9.9 | % |  | 10.2 | % |  | 13.6 | % |  | 12.9 | % |  | 15.1 | % |  | 15.6 | % |  | 13.5 | % |  | 13.5 | % |

[0000833444-20-000043:8k_2_02:102]
(2) Adjusted Corporate expenses excludes special items because these costs are not considered to be directly related to the underlying operating performance of the Company's business. Adjusted Corporate expenses for the three months ended September 30, 2020 excludes $10 million of integration costs. Adjusted Corporate expenses for the twelve months ended September 30, 2020 excludes $102 million of integration costs. Adjusted Corporate expenses for the three months ended September 30, 2019 excludes $79 million of integration costs and $4 million of transaction costs. Adjusted Corporate expenses for the twelve months ended September 30, 2019 excludes $244 million of integration costs and $11 million of transaction costs, partially offset by $226 million of income as a result of a tax indemnification reserve release.

[0000833444-20-000043:8k_2_02:103]
(3) The three months ended September 30, 2020 exclude the net mark-to-market adjustments on restricted investments and pension and postretirement plans of $120 million. The twelve months ended September 30, 2020 exclude the net mark-to-market adjustments on restricted investments and pension and postretirement plans of $274 million. The three months ended September 30, 2019 exclude the net mark-to-market adjustments on restricted investments and pension and postretirement plans of $626 million. The twelve months ended September 30, 2019 exclude the net mark-to-market adjustments on restricted investments and pension and postretirement plans of $618 million.

[0000833444-20-000043:8k_2_02:104]
(4) Restructuring and impairment costs for the twelve months ended September 30, 2020 of $783 million are excluded from the adjusted non-GAAP results. The restructuring actions and impairment costs for the twelve months ended September 30, 2020 are related primarily to workforce reductions, plant closures, asset impairments, and indefinite-lived intangible asset and goodwill impairments primarily related to the Company's retail business. Restructuring and impairment costs for the twelve months ended September 30, 2019 of $235 million are excluded from the adjusted non-GAAP results. The restructuring actions and impairment costs for the twelve months ended September 30, 2019 result from the impairment of a Global Products business classified as held for sale.

[0000833444-20-000043:8k_2_02:105]
(5) Management defines earnings before interest and taxes (EBIT) as income (loss) from continuing operations before net financing charges, income taxes and noncontrolling interests. EBIT is a non-GAAP performance measure. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company. A reconciliation of EBIT to income (loss) from continuing operations is shown earlier within this footnote.

[0000833444-20-000043:8k_2_02:106]
(6) Adjusted net financing charges for the twelve months ended September 30, 2019 exclude a loss on debt extinguishment of $60 million.

[0000833444-20-000043:8k_2_02:107]
(7) Adjusted income tax provision for the three months ended September 30, 2020 excludes tax benefits from net mark-to-market adjustments of $27 million, valuation allowance adjustments of $26 million, an acquisition related compensation charge of $9 million and integration costs of $3 million. Adjusted income tax provision for the twelve months ended September 30, 2020 excludes tax benefits from net mark-to-market adjustments of $65 million, restructuring and impairment costs of $48

[0000833444-20-000043:8k_2_02:108]
million, tax audit reserve adjustments of $44 million, valuation allowance adjustments of $26 million, integration costs of $18 million and an acquisition related compensation charge of $9 million, partially offset by tax provisions related to Switzerland tax reform of $30 million. Adjusted income tax provision for the three months ended September 30, 2019 excludes tax benefits primarily related to tax audit reserve adjustments of $586 million, net mark-to-market adjustments of $132 million and integration costs of $12 million. Adjusted income tax provision for the twelve months ended September 30, 2019 excludes tax benefits primarily related to tax audit reserve adjustments of $586 million, net mark-to-market adjustments of $130 million, restructuring and impairment charges of $53 million, integration costs of $34 million, an environmental reserve of $28 million and transaction costs of $1 million, partially offset by tax provisions primarily related to new U.S. tax regulations of $226 million and valuation allowance adjustments of $76 million as a result of changes in U.S tax law.

[0000833444-20-000043:8k_2_02:109]
(8) An environmental charge for the twelve months ended September 30, 2019 of $140 million is excluded from the adjusted non-GAAP results. The $140 million is related to remediation efforts to be undertaken to address contamination at our facilities in Marinette, Wisconsin. A substantial portion of the reserve relates to the remediation of fire-fighting foams containing PFAS compounds at or near our Fire Technology Center in Marinette.

[0000833444-20-000043:8k_2_02:110]
2.  Diluted Earnings Per Share Reconciliation

[0000833444-20-000043:8k_2_02:111]
The Company's press release and earnings presentation contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include transaction/integration costs, net mark-to-market adjustments, restructuring and impairment costs, an acquisition related compensation charge, tax indemnification reserve release, environmental reserve, loss on extinguishment of debt, gain on sale of Power Solutions business, net of transaction and other costs, impact of ceasing the depreciation and amortization expense for the Power Solutions business as the business is held for sale, and discrete tax items. The Company excludes these items because they are not considered to be directly related to the underlying operating performance of the Company. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-20-000043:8k_2_02:112]
Page 15 of 19

[0000833444-20-000043:8k_2_02:113]
A reconciliation of diluted earnings per share as reported to adjusted diluted earnings per share for the respective periods is shown below (unaudited):

[0000833444-20-000043:8k_2_02:114]
|  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc from Continuing Operations |  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc from Continuing Operations |
|  | Three Months Ended |  | Three Months Ended |  | Twelve Months Ended |  | Twelve Months Ended |
|  | September 30, |  | September 30, |  | September 30, |  | September 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Earnings per share as reported for JCI plc | $ | 0.60 |  |  | $ | 0.77 |  |  | $ | 0.60 |  |  | $ | 0.77 |  |  | $ | 0.84 |  |  | $ | 6.49 |  |  | $ | 0.84 |  |  | $ | 1.26 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |
| Integration costs | 0.04 |  |  | 0.14 |  |  | 0.04 |  |  | 0.14 |  |  | 0.18 |  |  | 0.35 |  |  | 0.18 |  |  | 0.35 |  |
| Related tax impact | — |  |  | (0.02) |  |  | — |  |  | (0.02) |  |  | (0.02) |  |  | (0.04) |  |  | (0.02) |  |  | (0.04) |  |
| Acquisition related compensation charge | 0.05 |  | — |  |  | 0.05 |  | — |  |  | 0.05 |  |  | — |  |  | 0.05 |  |  | — |  |
| Related tax impact | (0.01) |  |  | — |  |  | (0.01) |  |  | — |  |  | (0.01) |  |  | — |  |  | (0.01) |  |  | — |  |
| Net mark-to-market adjustments | 0.16 |  |  | 0.79 |  |  | 0.16 |  |  | 0.79 |  |  | 0.36 |  |  | 0.71 |  |  | 0.36 |  |  | 0.71 |  |
| Related tax impact | (0.04) |  |  | (0.17) |  |  | (0.04) |  |  | (0.17) |  |  | (0.09) |  |  | (0.15) |  |  | (0.09) |  |  | (0.15) |  |
| Restructuring and impairment costs | — |  |  | — |  |  | — |  |  | — |  |  | 1.04 |  |  | 0.27 |  |  | 1.04 |  |  | 0.27 |  |
| Related tax impact | — |  |  | — |  |  | — |  |  | — |  |  | (0.06) |  |  | (0.06) |  |  | (0.06) |  |  | (0.06) |  |
| NCI impact of restructuring and impairment | — |  |  | — |  |  | — |  |  | — |  |  | (0.01) |  |  | — |  |  | (0.01) |  |  | — |  |
| Tax indemnification reserve release | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (0.26) |  |  | — |  |  | (0.26) |  |
| Environmental reserve | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.16 |  |  | — |  |  | 0.16 |  |
| Related tax impact | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (0.03) |  |  | — |  |  | (0.03) |  |
| Loss on extinguishment of debt | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.07 |  |  | — |  |  | 0.07 |  |
| Power Solutions gain on sale, net of |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| transaction and other costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (5.95) |  |  | — |  |  | — |  |
| Related tax impact | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1.43 |  |  | — |  |  | — |  |
| Cease of Power Solutions |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| depreciation / amortization expense | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (0.13) |  |  | — |  |  | — |  |
| Related tax impact | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.03 |  |  | — |  |  | — |  |
| Discrete tax items | (0.04) |  |  | (0.74) |  |  | (0.04) |  |  | (0.74) |  |  | (0.05) |  |  | (0.24) |  |  | (0.05) |  |  | (0.32) |  |
| NCI impact of discrete tax items | — |  |  | — |  |  | — |  |  | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |
| Adjusted earnings per share for JCI plc* | $ | 0.76 |  |  | $ | 0.78 |  |  | $ | 0.76 |  |  | $ | 0.78 |  |  | $ | 2.24 |  |  | $ | 2.65 |  |  | $ | 2.24 |  |  | $ | 1.96 |  |

[0000833444-20-000043:8k_2_02:115]
* May not sum due to rounding

[0000833444-20-000043:8k_2_02:116]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-20-000043:8k_2_02:117]
|  | Three Months Ended |  | Twelve Months Ended |  |  |  |  |
|  | September 30, |  | September 30, |  |  |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |  |  |  |  |
| Weighted average shares outstanding for JCI plc |  |  |  |  |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 735.2 |  |  | 786.7 |  |  | 751.0 |  |  | 870.2 |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock |  |  |  |  |  |  |  |  |  |  |  |
| and unvested performance share awards | 2.9 |  |  | 5.0 |  |  | 2.6 |  |  | 4.1 |  |  |  |  |  |
| Diluted weighted average shares outstanding | 738.1 |  |  | 791.7 |  |  | 753.6 |  |  | 874.3 |  |  |  |  |  |

[0000833444-20-000043:8k_2_02:118]
The Company has presented forward-looking statements regarding adjusted EPS, organic revenue decline, adjusted EBIT margin and adjusted free cash flow conversion, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts, expenses or income from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts that are excluded from these non-GAAP financial measures are a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period, including but not limited to the high variability of the net mark-to-market adjustments and the effect of foreign currency exchange fluctuations. Our fiscal 2021 first quarter guidance for organic revenue decline also excludes the effect of acquisitions, divestitures and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available and management cannot reliably predict all of the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s first quarter and full year 2021 GAAP financial results.

[0000833444-20-000043:8k_2_02:119]
Page 16 of 19

[0000833444-20-000043:8k_2_02:120]
3. Organic Growth Reconciliation

[0000833444-20-000043:8k_2_02:121]
The components of the changes in net sales for the three months ended September 30, 2020 versus the three months ended September 30, 2019, including organic growth, is shown below (unaudited):

[0000833444-20-000043:8k_2_02:122]
| (in millions) | Net Sales for the Three Months Ended September 30, 2019 |  | Base Year Adjustments - Divestitures and Other |  | Adjusted Base Net Sales for the Three Months Ended September 30, 2019 |  | Acquisitions |  | Foreign Currency |  | Organic Growth |  | Net Sales for the Three Months EndedSeptember 30, 2020 |
| Building Solutions North America | $ | 2,401 |  |  | $ | — |  |  | — |  |  | $ | 2,401 |  |  | $ | — |  |  | — |  |  | $ | (2) |  |  | — |  |  | $ | (156) |  |  | -6 | % |  | $ | 2,243 |  |  | -7 | % |
| Building Solutions EMEA/LA | 948 |  |  | 10 |  |  | 1 | % |  | 958 |  |  | 11 |  |  | 1 | % |  | 6 |  |  | 1 | % |  | (69) |  |  | -7 | % |  | 906 |  |  | -4 | % |
| Building Solutions Asia Pacific | 726 |  |  | — |  |  | — |  |  | 726 |  |  | 2 |  |  | — |  |  | 8 |  |  | 1 | % |  | (75) |  |  | -10 | % |  | 661 |  |  | -9 | % |
| Total field | 4,075 |  |  | 10 |  |  | — |  |  | 4,085 |  |  | 13 |  |  | — |  |  | 12 |  |  | — |  |  | (300) |  |  | -7 | % |  | 3,810 |  |  | -7 | % |
| Global Products | 2,199 |  |  | (9) |  |  | — |  |  | 2,190 |  |  | 2 |  |  | — |  |  | 15 |  |  | 1 | % |  | (63) |  |  | -3 | % |  | 2,144 |  |  | -3 | % |
| Total net sales | $ | 6,274 |  |  | $ | 1 |  |  | — |  |  | $ | 6,275 |  |  | $ | 15 |  |  | — |  |  | $ | 27 |  |  | — |  |  | $ | (363) |  |  | -6 | % |  | $ | 5,954 |  |  | -5 | % |

[0000833444-20-000043:8k_2_02:123]
The components of the changes in net sales for the twelve months ended September 30, 2020 versus the twelve months ended September 30, 2019, including organic growth, is shown below (unaudited):

[0000833444-20-000043:8k_2_02:124]
| (in millions) | Net Sales for the Twelve Months Ended September 30, 2019 |  | Base Year Adjustments - Divestitures and Other |  | Adjusted Base Net Sales for the Twelve Months Ended September 30, 2019 |  | Acquisitions |  | Foreign Currency |  | Organic Growth |  | Net Sales for the Twelve Months EndedSeptember 30, 2020 |
| Building Solutions North America | $ | 9,031 |  |  | $ | (2) |  |  | — |  |  | $ | 9,029 |  |  | $ | — |  |  | — |  |  | $ | (12) |  |  | — |  |  | $ | (412) |  |  | -5 | % |  | $ | 8,605 |  |  | -5 | % |
| Building Solutions EMEA/LA | 3,655 |  |  | (7) |  |  | — |  |  | 3,648 |  |  | 38 |  |  | 1 | % |  | (96) |  |  | -3 | % |  | (150) |  |  | -4 | % |  | 3,440 |  |  | -6 | % |
| Building Solutions Asia Pacific | 2,658 |  |  | — |  |  | — |  |  | 2,658 |  |  | 8 |  |  | — |  |  | (31) |  |  | -1 | % |  | (232) |  |  | -9 | % |  | 2,403 |  |  | -10 | % |
| Total field | 15,344 |  |  | (9) |  |  | — |  |  | 15,335 |  |  | 46 |  |  | — |  |  | (139) |  |  | -1 | % |  | (794) |  |  | -5 | % |  | 14,448 |  |  | -6 | % |
| Global Products | 8,624 |  |  | (30) |  |  | — |  |  | 8,594 |  |  | 7 |  |  | — |  |  | (11) |  |  | — |  |  | (721) |  |  | -8 | % |  | 7,869 |  |  | -9 | % |
| Total net sales | $ | 23,968 |  |  | $ | (39) |  |  | — |  |  | $ | 23,929 |  |  | $ | 53 |  |  | — |  |  | $ | (150) |  |  | -1 | % |  | $ | (1,515) |  |  | -6 | % |  | $ | 22,317 |  |  | -7 | % |

[0000833444-20-000043:8k_2_02:125]
The components of the changes in segment EBITA and EBIT for the three months ended September 30, 2020 versus the three months ended September 30, 2019, including organic growth, is shown below (unaudited):

[0000833444-20-000043:8k_2_02:126]
| (in millions) | Adjusted Segment EBITA / EBIT for the Three Months Ended September 30, 2019 |  | Base Year Adjustments - Divestitures and Other |  | Adjusted Base Segment EBITA / EBIT for the Three Months Ended September 30, 2019 |  | Acquisitions |  | Foreign Currency |  | Organic Growth |  | Adjusted SegmentEBITA / EBIT forthe ThreeMonths EndedSeptember 30, 2020 |
| Building Solutions North America | $ | 357 |  |  | $ | — |  |  | — |  |  | $ | 357 |  |  | $ | — |  |  | — |  |  | $ | — |  |  | — |  |  | $ | (12) |  |  | -3 | % |  | $ | 345 |  |  | -3 | % |
| Building Solutions EMEA/LA | 111 |  |  | 1 |  |  | 1 | % |  | 112 |  |  | 2 |  |  | 2 | % |  | (1) |  |  | -1 | % |  | (10) |  |  | -9 | % |  | 103 |  |  | -7 | % |
| Building Solutions Asia Pacific | 103 |  |  | — |  |  | — |  |  | 103 |  |  | — |  |  | — |  |  | 2 |  |  | 2 | % |  | (8) |  |  | -8 | % |  | 97 |  |  | -6 | % |
| Total field | 571 |  |  | 1 |  |  | — |  |  | 572 |  |  | 2 |  |  | — |  |  | 1 |  |  | — |  |  | (30) |  |  | -5 | % |  | 545 |  |  | -5 | % |
| Global Products | 419 |  |  | (1) |  |  | — |  |  | 418 |  |  | — |  |  | — |  |  | 2 |  |  | — |  |  | (39) |  |  | -9 | % |  | 381 |  |  | -9 | % |
| Total adjusted segment EBITA | 990 |  |  | — |  |  | — |  |  | 990 |  |  | $ | 2 |  |  | — |  |  | $ | 3 |  |  | — |  |  | $ | (69) |  |  | -7 | % |  | 926 |  |  | -6 | % |
| Corporate expenses | (89) |  |  | — |  |  |  |  | (89) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (58) |  |  | 35 | % |
| Amortization of intangible assets | (89) |  |  | — |  |  |  |  | (89) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (98) |  |  | -10 | % |
| Total adjusted EBIT | $ | 812 |  |  | $ | — |  |  |  |  | $ | 812 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 770 |  |  | -5 | % |

[0000833444-20-000043:8k_2_02:127]
Page 17 of 19

[0000833444-20-000043:8k_2_02:128]
The components of the changes in segment EBITA and EBIT for the twelve months ended September 30, 2020 versus the twelve months ended September 30, 2019, including organic growth, is shown below (unaudited):

[0000833444-20-000043:8k_2_02:129]
| (in millions) | Adjusted Segment EBITA / EBIT for the Twelve Months Ended September 30, 2019 |  | Base Year Adjustments - Divestitures and Other |  | Adjusted Base Segment EBITA / EBIT for the Twelve Months Ended September 30, 2019 |  | Acquisitions |  | Foreign Currency |  | Organic Growth |  | Adjusted SegmentEBITA / EBIT forthe Twelve Months EndedSeptember 30, 2020 |
| Building Solutions North America | $ | 1,179 |  |  | $ | — |  |  | — |  |  | $ | 1,179 |  |  | $ | — |  |  | — |  |  | $ | (1) |  |  | — |  |  | $ | (10) |  |  | -1 | % |  | $ | 1,168 |  |  | -1 | % |
| Building Solutions EMEA/LA | 372 |  |  | — |  |  | — |  |  | 372 |  |  | 7 |  |  | 2 | % |  | (17) |  |  | -5 | % |  | (22) |  |  | -6 | % |  | 340 |  |  | -9 | % |
| Building Solutions Asia Pacific | 343 |  |  | — |  |  | — |  |  | 343 |  |  | 1 |  |  | — |  |  | — |  |  | — |  |  | (18) |  |  | -5 | % |  | 326 |  |  | -5 | % |
| Total field | 1,894 |  |  | — |  |  | — |  |  | 1,894 |  |  | 8 |  |  | — |  |  | (18) |  |  | -1 | % |  | (50) |  |  | -3 | % |  | 1,834 |  |  | -3 | % |
| Global Products | 1,349 |  |  | (2) |  |  | — |  |  | 1,347 |  |  | (2) |  |  | — |  |  | (5) |  |  | — |  |  | (154) |  |  | -11 | % |  | 1,186 |  |  | -12 | % |
| Total adjusted segment EBITA | 3,243 |  |  | (2) |  |  | — |  |  | 3,241 |  |  | $ | 6 |  |  | — |  |  | $ | (23) |  |  | -1 | % |  | $ | (204) |  |  | -6 | % |  | 3,020 |  |  | -7 | % |
| Corporate expenses | (376) |  |  | — |  |  |  |  | (376) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (269) |  |  | 28 | % |
| Amortization of intangible assets | (377) |  |  | — |  |  |  |  | (377) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (386) |  |  | -2 | % |
| Total adjusted EBIT | $ | 2,490 |  |  | $ | (2) |  |  |  |  | $ | 2,488 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2,365 |  |  | -5 | % |

[0000833444-20-000043:8k_2_02:130]
4.  Adjusted Free Cash Flow Reconciliation

[0000833444-20-000043:8k_2_02:131]
The Company's press release contains financial information regarding free cash flow, adjusted free cash flow and adjusted free cash flow conversion, which are non-GAAP performance measures. Free cash flow is defined as cash provided by operating activities less capital expenditures. Adjusted free cash flow excludes special items, as included in the table below, because these cash flows are not considered to be directly related to its underlying businesses. Adjusted free cash flow conversion is defined as adjusted free cash flow divided by adjusted net income. Management believes these non-GAAP measures are useful to investors in understanding the strength of the Company and its ability to generate cash.

[0000833444-20-000043:8k_2_02:132]
The following is the three months and twelve months ended September 30, 2020 and 2019 reconciliation of free cash flow, adjusted free cash flow and adjusted free cash flow conversion for continuing operations (unaudited):

[0000833444-20-000043:8k_2_02:133]
| (in billions) | Three Months Ended September 30, 2020 |  | Three Months Ended September 30, 2019 |  | Twelve Months Ended September 30, 2020 |  | Twelve Months Ended September 30, 2019 |  |  |
| Cash provided by operating activities from continuing operations | $ | 1.0 |  |  | $ | 1.0 |  |  | $ | 2.5 |  |  | $ | 1.7 |  |  |  |
| Capital expenditures | (0.1) |  |  | (0.2) |  |  | (0.4) |  |  | (0.6) |  |  |  |
| Reported free cash flow * | 0.9 |  |  | 0.8 |  |  | 2.0 |  |  | 1.2 |  |  |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |
| Transaction/integration costs | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.3 |  |  |  |
| Restructuring payments | 0.1 |  |  | — |  |  | 0.2 |  |  | 0.1 |  |  |  |
| Nonrecurring tax payments (refunds) | — |  |  | 0.1 |  |  | (0.6) |  |  | 0.1 |  |  |  |
| Total adjusting items * | 0.2 |  |  | 0.2 |  |  | (0.1) |  |  | 0.5 |  |  |  |
| Adjusted free cash flow * | $ | 1.0 |  |  | $ | 1.0 |  |  | $ | 1.9 |  |  | $ | 1.7 |  |  |  |
| Adjusted net income from continuing operations |  |  |  |  |  |  |  |  |  |
| attributable to JCI | $ | 0.6 |  |  | $ | 0.6 |  |  | $ | 1.7 |  |  | $ | 1.7 |  |  |  |
| Adjusted free cash flow conversion | 167 | % |  | 167 | % |  | 115 | % |  | 99 | % |  |  |

[0000833444-20-000043:8k_2_02:134]
* May not sum due to rounding

[0000833444-20-000043:8k_2_02:135]
Page 18 of 19

[0000833444-20-000043:8k_2_02:136]
5.  Net Debt to EBITDA

[0000833444-20-000043:8k_2_02:137]
The Company provides financial information regarding net debt to adjusted EBITDA, which is a non-GAAP performance measure. The Company believes the total net debt to adjusted EBITDA ratio is useful to understanding the Company's financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders. The following is the September 30, 2020, June 30, 2020 and September 30, 2019 calculation of net debt to adjusted EBITDA (unaudited):

[0000833444-20-000043:8k_2_02:138]
| (in millions) | September 30, 2020 |  | June 30, 2020 |  | September 30, 2019 |  |  |
| Short-term debt and current portion of long-term debt | $ | 293 |  |  | $ | 2,423 |  |  | $ | 511 |  |  |  |
| Long-term debt | 7,526 |  |  | 5,671 |  |  | 6,708 |  |  |  |
| Total debt | 7,819 |  |  | 8,094 |  |  | 7,219 |  |  |  |
| Less: cash and cash equivalents | 1,951 |  |  | 2,342 |  |  | 2,805 |  |  |  |
| Total net debt | $ | 5,868 |  |  | $ | 5,752 |  |  | $ | 4,414 |  |  |  |
| Last twelve months adjusted EBITDA | $ | 3,187 |  |  | $ | 3,223 |  |  | $ | 3,315 |  |  |  |
| Total net debt to adjusted EBITDA | 1.8x |  | 1.8x |  | 1.3x |  |  |

[0000833444-20-000043:8k_2_02:139]
The following is the last twelve months ended September 30, 2020, June 30, 2020 and September 30, 2019 reconciliation of income from continuing operations to adjusted EBIT and adjusted EBITDA, which are non-GAAP performance measures (unaudited):

[0000833444-20-000043:8k_2_02:140]
| (in millions) | Last Twelve MonthsEndedSeptember 30, 2020 |  | Last Twelve Months EndedJune 30, 2020 |  | Twelve Months EndedSeptember 30, 2019 |  |  |
| Income from continuing operations | $ | 795 |  |  | $ | 959 |  |  | $ | 1,289 |  |  |  |
| Income tax (benefit) provision | 108 |  |  | (550) |  |  | (233) |  |  |  |
| Net financing charges | 231 |  |  | 217 |  |  | 350 |  |  |  |
| EBIT | 1,134 |  |  | 626 |  |  | 1,406 |  |  |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | 4 |  |  | 11 |  |  |  |
| Integration costs | 135 |  |  | 214 |  |  | 306 |  |  |  |
| Net mark-to-market adjustments | 274 |  |  | 780 |  |  | 618 |  |  |  |
| Restructuring and impairment costs | 783 |  |  | 783 |  |  | 235 |  |  |  |
| Acquisition related compensation charge | 39 |  |  | — |  |  | — |  |  |  |
| Tax indemnification reserve release | — |  |  | — |  |  | (226) |  |  |  |
| Environmental reserve | — |  |  | — |  |  | 140 |  |  |  |
| Adjusted EBIT (1) | 2,365 |  |  | 2,407 |  |  | 2,490 |  |  |  |
| Depreciation and amortization | 822 |  |  | 816 |  |  | 825 |  |  |  |
| Adjusted EBITDA (1) | $ | 3,187 |  |  | $ | 3,223 |  |  | $ | 3,315 |  |  |  |

[0000833444-20-000043:8k_2_02:141]
(1) The Company's definition of adjusted EBIT and adjusted EBITDA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its businesses. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-20-000043:8k_2_02:142]
6.  Income Taxes

[0000833444-20-000043:8k_2_02:143]
The Company's effective tax rate from continuing operations before consideration of transaction/integration costs, net mark-to-market adjustments, environmental reserve, tax indemnification reserve release, restructuring and impairment costs, acquisition related compensation charge, loss on extinguishment of debt and discrete tax items for the three and twelve months ending September 30, 2020 and September 30, 2019 is approximately 13.5%.

[0000833444-20-000043:8k_2_02:144]
7.  Restructuring and Impairment Costs

[0000833444-20-000043:8k_2_02:145]
The twelve months ended September 30, 2020 include restructuring and impairment costs of $783 million related primarily to workforce reductions, plant closures, asset impairments, and indefinite-lived intangible asset and goodwill impairments primarily related to the Company's retail business. The twelve months ended September 30, 2019 include restructuring and impairment costs of $235 million related to the impairment of a Global Products business classified as held for sale.

[0000833444-20-000043:8k_2_02:146]
8.  Leases

[0000833444-20-000043:8k_2_02:147]
On October 1, 2019, the Company adopted ASU 2016-02, "Leases (Topic 842)," which requires recognition of operating leases as a lease asset and liabilities on the balance sheet. The adoption of the new guidance resulted in recognition of a right-of-use asset and related lease liabilities of $1.1 billion.

[0000833444-20-000043:8k_2_02:148]
Page 19 of 19
