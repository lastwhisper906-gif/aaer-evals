# JCI note change history — 0000833444-20-000015 → 0000833444-20-000036


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-07-31):
[0000833444-20-000036:note_history:1]
Commitments and Contingencies
Environmental Matters
  (was, 2020-05-01, similarity 0.725):
[0000833444-20-000015:note_history:1]
Commitments and Contingencies

- changed (2020-07-31):
[0000833444-20-000036:note_history:2]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of June 30, 2020, reserves for environmental liabilities for continuing operations totaled $136 million, of which $45 million was recorded within other current liabilities and $91 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $159 million at September 30, 2019, of which $52 million was recorded within other current liabilities and $107 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.
  (was, 2020-05-01, similarity 0.9939):
[0000833444-20-000015:note_history:2]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of March 31, 2020, reserves for environmental liabilities for continuing operations totaled $143 million, of which $52 million was recorded within other current liabilities and $91 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $159 million at September 30, 2019, of which $52 million was recorded within other current liabilities and $107 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.

- added (2020-07-31):
[0000833444-20-000036:note_history:3]
During the third quarter of 2019, the Company increased its environmental reserves, which included $140 million related to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds

- changed (2020-07-31):
[0000833444-20-000036:note_history:4]
at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).  The Company is not able to estimate a possible loss or range of loss in excess of the established accruals at this time.
  (was, 2020-05-01, similarity 0.7451):
[0000833444-20-000015:note_history:4]
During the third quarter of 2019, the Company increased its environmental reserves which included $140 million related to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).  The Company is not able to estimate a possible loss or range of loss in excess of the established accruals at this time.

- changed (2020-07-31):
[0000833444-20-000036:note_history:5]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990.  Its corporate predecessor, Ansul Incorporated (“Ansul”) manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River.  In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. The increase in the reserve related to the Stanton Street Facility was recorded following a further review of the Consent Order, which resulted in the identification of several structural upgrades needed to preserve the effectiveness of prior remediation efforts. In addition to ongoing remediation activities, the Company is also working with the WDNR to investigate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation of PFAS in the Marinette region.
  (was, 2020-05-01, similarity 0.9264):
[0000833444-20-000015:note_history:5]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990.  Its corporate predecessor, Ansul Incorporated (“Ansul”) manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River.  In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. The increase in the reserve related to the Stanton Street Facility was recorded following a further review of the Consent Order, which resulted in the identification of several structural upgrades needed to preserve the effectiveness of prior remediation efforts.

- added (2020-07-31):
[0000833444-20-000036:note_history:6]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at

- changed (2020-07-31):
[0000833444-20-000036:note_history:7]
the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At June 30, 2020 and September 30, 2019, the Company recorded conditional asset retirement obligations for continuing operations of $29 million and $30 million, respectively.
  (was, 2020-05-01, similarity 0.7148):
[0000833444-20-000015:note_history:7]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At March 31, 2020 and September 30, 2019, the Company recorded conditional asset retirement obligations for continuing operations of $30 million.

- added (2020-07-31):
[0000833444-20-000036:note_history:8]
As of June 30, 2020, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $134 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $497 million, of which $50 million was recorded in other current liabilities and $447 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $363 million, of which $43 million was recorded in other current assets, and $320 million was recorded in other noncurrent assets. Assets included $13 million of cash and $281 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at June 30, 2020 was $69 million. As of September 30, 2019, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $141 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $507 million, of which $50 million was recorded in other current liabilities and $457 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $366 million, of which $46 million was recorded in other current assets, and $320 million was recorded in other noncurrent assets. Assets included $16 million of cash and $273 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2019 was $77 million.

- added (2020-07-31):
[0000833444-20-000036:note_history:9]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and

- changed (2020-07-31):
[0000833444-20-000036:note_history:10]
assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.
  (was, 2020-05-01, similarity 0.9166):
[0000833444-20-000015:note_history:10]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

- changed (2020-07-31):
[0000833444-20-000036:note_history:11]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At June 30, 2020 and September 30, 2019, the insurable liabilities totaled $365 million and $379 million, respectively, of which $83 million and $99 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $260 million and $258 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at June 30, 2020 were $23 million, of which $5 million was recorded within other current assets and $18 million was recorded within other noncurrent assets, respectively. The amount of such receivables recorded at September 30, 2019 were $23 million, of which $5 million was recorded within other current assets and $18 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.
  (was, 2020-05-01, similarity 0.9935):
[0000833444-20-000015:note_history:11]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At March 31, 2020 and September 30, 2019, the insurable liabilities totaled $363 million and $379 million, respectively, of which $85 million and $99 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $256 million and $258 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at March 31, 2020 were $23 million, of which $5 million was recorded within other current assets and $18 million was recorded within other noncurrent assets, respectively. The amount of such receivables recorded at September 30, 2019 were $23 million, of which $5 million was recorded within other current assets and $18 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.

- changed (2020-07-31):
[0000833444-20-000036:note_history:12]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but has stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.
  (was, 2020-05-01, similarity 0.9709):
[0000833444-20-000015:note_history:12]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but has stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

- changed (2020-07-31):
[0000833444-20-000036:note_history:13]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation
  (was, 2020-05-01, similarity 0.8):
[0000833444-20-000015:note_history:13]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to or are being directly filed in the MDL.

- added (2020-07-31):
[0000833444-20-000036:note_history:14]
(“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to or are being directly filed in the MDL.

- changed (2020-07-31):
[0000833444-20-000036:note_history:15]
Chemguard and Tyco Fire Products are named in 30 putative class actions in federal courts originating from Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington New Hampshire, South Carolina, the District of Columbia, Guam, West Virginia, Michigan and South Dakota. All but one of these cases has been transferred to the MDL, and it is anticipated that the Abbot case will be removed to federal court and transferred following service of the complaint. The following putative class actions were filed since the beginning of fiscal year 2020:
  (was, 2020-05-01, similarity 0.8369):
[0000833444-20-000015:note_history:15]
Chemguard and Tyco Fire Products are named in 27 putative class actions in federal courts originating from Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington New Hampshire, South Carolina, the District of Columbia, Guam, West Virginia, and Michigan. All but one of these cases has been transferred to the MDL, and it is anticipated that the newly filed Stengel case will be transferred. The following putative class actions were filed since the beginning of fiscal year 2020:

- changed (2020-07-31):
[0000833444-20-000036:note_history:16]
•Aguon et al. v. The 3M Company et al., filed October 3, 2019, in the United States District Court, District of Guam.
  (was, 2020-05-01, similarity 0.9697):
[0000833444-20-000015:note_history:16]
| • | Aguon et al. v. The 3M Company et al., filed October 3, 2019, in the United States District Court, District of Guam. |

- changed (2020-07-31):
[0000833444-20-000036:note_history:17]
•County of Rockland [New York] et al. v. 3M Company et al., filed February 4, 2020, in the United States District Court, District of South Carolina.
  (was, 2020-05-01, similarity 0.9761):
[0000833444-20-000015:note_history:17]
| • | County of Rockland [New York] et al. v. 3M Company et al., filed February 4, 2020, in the United States District Court, District of South Carolina. |

- changed (2020-07-31):
[0000833444-20-000036:note_history:18]
•City of Millington et al. v. 3M Company et al., filed February 25, 2020, in the United States District Court, District of Columbia.
  (was, 2020-05-01, similarity 0.973):
[0000833444-20-000015:note_history:18]
| • | City of Millington et al. v. 3M Company et al., filed February 25, 2020, in the United States District Court, District of Columbia. |

- changed (2020-07-31):
[0000833444-20-000036:note_history:19]
•Stengel et al. v. 3M Company et al., filed April 29, 2020, in the United States District Court for the Northern District of West Virginia.
  (was, 2020-05-01, similarity 0.9744):
[0000833444-20-000015:note_history:19]
| • | Stengel et al. v. 3M Company et al., filed April 29, 2020, in the United States District Court for the Northern District of West Virginia. |

- added (2020-07-31):
[0000833444-20-000036:note_history:20]
•Abbott et al. v. The 3M Company et al., filed May 6, 2020 in the Superior Court for the State of Washington in and for Spokane County.

- changed (2020-07-31):
[0000833444-20-000036:note_history:21]
•Garcia et al. v. 3M Company et al., filed May 15, 2020 in the United States District Court for the District of South Carolina [originating from South Dakota].
  (was, 2020-05-01, similarity 0.6581):
[0000833444-20-000015:note_history:21]
| • | Town of Ayer v. The 3M Company et al., direct-filed on November 4, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

- changed (2020-07-31):
[0000833444-20-000036:note_history:22]
•Gentile et al. v. The 3M Company et al., filed May 27, 2020, in the United States District Court for the Eastern District of New York.
  (was, 2020-05-01, similarity 0.7385):
[0000833444-20-000015:note_history:22]
| • | Town of Grantsville v. The 3M Company et al., filed November 26, 2019, in the United States District Court, District of Maryland. |

- added (2020-07-31):
[0000833444-20-000036:note_history:23]
There are approximately 632 individual or “mass” actions pending that were filed in state or federal court in California (2 cases), Colorado (41 cases), New York (4 cases), Pennsylvania (15 cases), New Mexico (2 cases) and South Carolina (568 cases direct filed from various U.S. jurisdictions) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve two plaintiffs in California, approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, 15 plaintiffs in Pennsylvania, two plaintiffs in New Mexico, and more than 500 plaintiffs from various states who direct-filed complaints in South Carolina. All but two of these matters have been transferred to or directly-filed in the MDL, and it is anticipated that the California cases will be transferred following service of the complaints.  Many of the additional filed actions were directly filed in South Carolina by plaintiffs who were among the 660 plaintiffs the Company had previously disclosed to have made filings in Pennsylvania state court.  The Company anticipates that the remainder of the possible individual product liability claims filed in Pennsylvania state court will either soon be filed in the MDL (and that all such claims in state court will be dismissed accordingly) or will be dismissed in Pennsylvania without a corresponding filing in South Carolina.

- added (2020-07-31):
[0000833444-20-000036:note_history:24]
Chemguard and Tyco Fire Products are also defendants in 51 cases in federal courts involving municipal or water provider plaintiffs in Alaska, Arizona, California, Colorado, Florida, Massachusetts, New Jersey, New York, Maryland, Ohio, Pennsylvania, Washington, the District of Columbia and several municipalities or water providers from various states who direct-filed complaints in South Carolina.  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property. Since the beginning of fiscal year 2020, 21 municipal actions have been filed against the Company.

- changed (2020-07-31):
[0000833444-20-000036:note_history:25]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly
  (was, 2020-05-01, similarity 0.863):
[0000833444-20-000015:note_history:25]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly resulting from the use of those products at the Peterson Air Force Base.

- added (2020-07-31):
[0000833444-20-000036:note_history:26]
resulting from the use of those products at the Peterson Air Force Base. In May 2020, the Company was also notified by the Lakewood Water District in Pierce County, Washington that it may assert claims regarding remediation in connection with PFOA, PFOS, and other PFAS contamination allegedly resulting from the use of those products at Joint Base Lewis-McChord.

- added (2020-07-31):
[0000833444-20-000036:note_history:27]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.

- changed (2020-07-31):
[0000833444-20-000036:note_history:28]
Other AFFF Related Matters
  (was, 2020-05-01, similarity 0.8182):
[0000833444-20-000015:note_history:28]
Other AFFF Matters

- added (2020-07-31):
[0000833444-20-000036:note_history:29]
Other PFAS Related Matters

- added (2020-07-31):
[0000833444-20-000036:note_history:30]
In April 2020, the Weirton Area Water Board in West Virginia filed a lawsuit in the Circuit Court of Brooke County, West Virginia against a number of PFAS chemical manufacturers, including Chemguard, with respect to PFAS contamination.  This case has been removed to the United States District Court for the Northern District of West Virginia.

- changed (2020-07-31):
[0000833444-20-000036:note_history:31]
The Company is vigorously defending the above matters and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.
  (was, 2020-05-01, similarity 0.9952):
[0000833444-20-000015:note_history:31]
The Company is vigorously defending the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.

- removed (2020-07-31):
[0000833444-20-000015:note_history:32]
Environmental Matters

- removed (2020-07-31):
[0000833444-20-000015:note_history:33]
As of March 31, 2020, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $165 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $498 million, of

- removed (2020-07-31):
[0000833444-20-000015:note_history:34]
which $50 million was recorded in other current liabilities and $448 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $333 million, of which $62 million was recorded in other current assets, and $271 million was recorded in other noncurrent assets. Assets included $13 million of cash and $251 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at March 31, 2020 was $69 million. As of September 30, 2019, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $141 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $507 million, of which $50 million was recorded in other current liabilities and $457 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $366 million, of which $46 million was recorded in other current assets, and $320 million was recorded in other noncurrent assets. Assets included $16 million of cash and $273 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2019 was $77 million.

- removed (2020-07-31):
[0000833444-20-000015:note_history:35]
There are approximately 585 individual or “mass” actions pending in federal court in Colorado (41 cases), New York (4 cases), Pennsylvania (11 cases), New Mexico (2 cases) and South Carolina (527 cases direct filed from various U.S. jurisdictions) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, 15 plaintiffs in Pennsylvania, two plaintiffs in New Mexico, and more than 500 plaintiffs from various states who direct-filed complaints in South Carolina.  These matters have been transferred to or directly-filed in the MDL.  Many of the additional filed actions were directly filed in South Carolina by plaintiffs who were among the 660 plaintiffs the Company had previously disclosed to have made filings in Pennsylvania state court.  The Company anticipates that the remainder of the possible individual product liability claims filed in Pennsylvania state court will either soon be filed in the MDL (and that all such claims in state court will be dismissed accordingly) or will be dismissed in Pennsylvania without a corresponding filing in South Carolina.

- removed (2020-07-31):
[0000833444-20-000015:note_history:36]
Chemguard and Tyco Fire Products are also defendants in 38 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Arizona, California, Colorado, Florida, Massachusetts, New Jersey, New York, Maryland, Ohio, Pennsylvania and several municipalities or water providers from various states who direct-filed complaints in South Carolina.  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property.  The following municipal actions were filed since the beginning of fiscal year 2020:

- removed (2020-07-31):
[0000833444-20-000015:note_history:37]
| • | California Water Service Co. v. The 3M Company et al., direct-filed on October 14, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

- removed (2020-07-31):
[0000833444-20-000015:note_history:38]
| • | Town of Maysville v. The 3M Company et al., direct-filed on December 10, 2019 in the MDL pending in the United States District Court, District of South Carolina. |

- removed (2020-07-31):
[0000833444-20-000015:note_history:39]
| • | Town of Mountain Lake Park v. The 3M Company et al., filed November 26, 2019, in the United States District Court, District of Maryland. |

- removed (2020-07-31):
[0000833444-20-000015:note_history:40]
| • | Sanford Airport Authority v. The 3M Company et al., filed November 19, 2019, in circuit court in Seminole County, Florida, and removed to the United States District Court, Middle District of Florida. It has been tagged for transfer to the MDL pending in the United States District Court, District of South Carolina. |

- removed (2020-07-31):
[0000833444-20-000015:note_history:41]
| • | South Adams County Water & Sanitation District v. The 3M Company et al., filed December 20, 2019, in the MDL pending in the United States District Court, District of South Carolina. |

- removed (2020-07-31):
[0000833444-20-000015:note_history:42]
| • | Town of Southampton v. The 3M Company et al., filed December 17, 2019, in the MDL pending in the United States District Court, District of South Carolina. |

- removed (2020-07-31):
[0000833444-20-000015:note_history:43]
| • | Fairbanks North Star Borough v. 3M Company, et al., filed January 31, 2020, in the MDL pending in the United States District Court, District of South Carolina. |

- removed (2020-07-31):
[0000833444-20-000015:note_history:44]
| • | England Economic and Industrial Development District v. 3M Company et al., filed February 20, 2020, in the MDL pending in the United States District Court, District of South Carolina. |

- removed (2020-07-31):
[0000833444-20-000015:note_history:45]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Group, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-07-31):
[0000833444-20-000036:note_history:46]
Financial Statements
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2019 filed with the SEC on November 21, 2019. The results of operations for the three and nine month periods ended June 30, 2020 are not necessarily indicative of results for the Company’s 2020 fiscal year because of seasonal and other factors.
  (was, 2020-05-01, similarity 0.9711):
[0000833444-20-000015:note_history:46]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2019 filed with the SEC on November 21, 2019. The results of operations for the three and six month periods ended March 31, 2020 are not necessarily indicative of results for the Company’s 2020 fiscal year because of seasonal and other factors.

- changed (2020-07-31):
[0000833444-20-000036:note_history:47]
At June 30, 2020 and September 30, 2019, the Company held restricted cash of approximately $13 million and $16 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities.
  (was, 2020-05-01, similarity 0.9856):
[0000833444-20-000015:note_history:47]
At March 31, 2020 and September 30, 2019, the Company held restricted cash of approximately $13 million and $16 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities.

- removed (2020-07-31):
[0000833444-20-000015:note_history:48]
Financial Statements


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-07-31):
[0000833444-20-000036:note_history:49]
Debt and Financing Arrangements
Net Financing Charges
  (was, 2020-05-01, similarity 0.7381):
[0000833444-20-000015:note_history:49]
Debt and Financing Arrangements

- changed (2020-07-31):
[0000833444-20-000036:note_history:50]
The Company's net financing charges line item in the consolidated statements of income for the three and nine months ended June 30, 2020 and 2019 contained the following components (in millions):
  (was, 2020-05-01, similarity 0.9626):
[0000833444-20-000015:note_history:50]
The Company's net financing charges line item in the consolidated statements of income for the three and six months ended March 31, 2020 and 2019 contained the following components (in millions):

- added (2020-07-31):
[0000833444-20-000036:note_history:51]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Interest expense, net of capitalized interest costs | $ | 58 |  |  | $ | 81 |  |  | $ | 182 |  |  | $ | 269 |  |
| Banking fees and bond cost amortization | 8 |  |  | 7 |  |  | 18 |  |  | 20 |  |
| Loss on debt extinguishment | — |  |  | 60 |  |  | — |  |  | 60 |  |
| Interest income | (3) |  |  | (28) |  |  | (21) |  |  | (41) |  |
| Net foreign exchange results for financing activities | (5) |  |  | (1) |  |  | (10) |  |  | (6) |  |
| Net financing charges | $ | 58 |  |  | $ | 119 |  |  | $ | 169 |  |  | $ | 302 |  |

- changed (2020-07-31):
[0000833444-20-000036:note_history:52]
In April 2020, the Company entered into various European financing arrangements totaling $675 million which are due in September 2020 and $575 million of bank term loans which are due in April 2021. In July 2020, a $300 million bank term loan was repaid, reducing bank term loans outstanding to $275 million.
  (was, 2020-05-01, similarity 0.7821):
[0000833444-20-000015:note_history:52]
In April 2020, the Company entered into various European financing arrangements totaling $675 million which are due in September 2020 and $575 million of bank term loans which are due in April 2021.

- changed (2020-07-31):
[0000833444-20-000036:note_history:53]
In December 2019, the Company entered into a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2020.  As of June 30, 2020, there were no draws on the facilities.
  (was, 2020-05-01, similarity 0.9852):
[0000833444-20-000015:note_history:53]
In December 2019, the Company entered into a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2020.  As of March 31, 2020, there were no draws on the facilities.

- removed (2020-07-31):
[0000833444-20-000015:note_history:54]
Net Financing Charges

- removed (2020-07-31):
[0000833444-20-000015:note_history:55]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Interest expense, net of capitalized interest costs | $ | 62 |  |  | $ | 97 |  |  | $ | 124 |  |  | $ | 188 |  |
| Banking fees and bond cost amortization | 5 |  |  | 7 |  |  | 10 |  |  | 13 |  |
| Interest income | (5 | ) |  | (6 | ) |  | (18 | ) |  | (13 | ) |
| Net foreign exchange results for financing activities | (3 | ) |  | — |  |  | (5 | ) |  | (5 | ) |
| Net financing charges | $ | 59 |  |  | $ | 98 |  |  | $ | 111 |  |  | $ | 183 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2020-07-31):
[0000833444-20-000036:note_history:56]
Related Party Transactions
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

- added (2020-07-31):
[0000833444-20-000036:note_history:57]
The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $52 million and $25 million, respectively, for the three months ended June 30, 2020; and $65 million and $27 million, respectively, for the three months ended June 30, 2019. The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $135 million and $47 million, respectively, for the nine months ended June 30, 2020; and $162 million and $57 million, respectively, for the nine months ended June 30, 2019.

- changed (2020-07-31):
[0000833444-20-000036:note_history:58]
|  |  | June 30, 2020 |  | September 30, 2019 |
| Receivable from related parties |  | $ | 50 |  |  | $ | 34 |  |
| Payable to related parties |  | 7 |  |  | 6 |  |
  (was, 2020-05-01, similarity 0.9682):
[0000833444-20-000015:note_history:58]
|  |  | March 31, 2020 |  | September 30, 2019 |
| Receivable from related parties |  | $ | 37 |  |  | $ | 34 |  |
| Payable to related parties |  | 4 |  |  | 6 |  |

- removed (2020-07-31):
[0000833444-20-000015:note_history:59]
Related Party Transactions

- removed (2020-07-31):
[0000833444-20-000015:note_history:60]
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

- removed (2020-07-31):
[0000833444-20-000015:note_history:61]
The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $38 million and $10 million, respectively, for the three months ended March 31, 2020; and $54 million and $16 million, respectively, for the three months ended March 31, 2019. The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $83 million and $22 million, respectively, for the six months ended March 31, 2020; and $97 million and $30 million, respectively, for the six months ended March 31, 2019.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2020-07-31):
[0000833444-20-000036:note_history:62]
|  |  | June 30, 2020 |  | September 30, 2019 |
| Receivable from related parties |  | $ | 50 |  |  | $ | 34 |  |
| Payable to related parties |  | 7 |  |  | 6 |  |
  (was, 2020-05-01, similarity 0.9682):
[0000833444-20-000015:note_history:62]
|  |  | March 31, 2020 |  | September 30, 2019 |
| Receivable from related parties |  | $ | 37 |  |  | $ | 34 |  |
| Payable to related parties |  | 4 |  |  | 6 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-07-31):
[0000833444-20-000036:note_history:63]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three and nine months ended June 30, 2020 and 2019 (in millions):
  (was, 2020-05-01, similarity 0.9639):
[0000833444-20-000015:note_history:63]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three and six months ended March 31, 2020 and 2019 (in millions):

- changed (2020-07-31):
[0000833444-20-000036:note_history:64]
|  |  | Three Months Ended June 30, 2020 |  |  |  |  |  | Three Months Ended June 30, 2019 |  |  |  |  |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,250 |  |  | $ | 770 |  |  | $ | 2,020 |  |  | $ | 1,494 |  |  | $ | 833 |  |  | $ | 2,327 |  |
| Building Solutions EMEA/LA |  | 346 |  |  | 410 |  |  | 756 |  |  | 464 |  |  | 458 |  |  | 922 |  |
| Building Solutions Asia Pacific |  | 344 |  |  | 244 |  |  | 588 |  |  | 427 |  |  | 264 |  |  | 691 |  |
| Global Products |  | 1,979 |  |  | — |  |  | 1,979 |  |  | 2,511 |  |  | — |  |  | 2,511 |  |
| Total |  | $ | 3,919 |  |  | $ | 1,424 |  |  | $ | 5,343 |  |  | $ | 4,896 |  |  | $ | 1,555 |  |  | $ | 6,451 |  |
  (was, 2020-05-01, similarity 0.9175):
[0000833444-20-000015:note_history:64]
|  |  | Three Months Ended March 31, 2020 |  | Three Months Ended March 31, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,357 |  |  | $ | 818 |  |  | $ | 2,175 |  |  | $ | 1,387 |  |  | $ | 800 |  |  | $ | 2,187 |  |
| Building Solutions EMEA/LA |  | 400 |  |  | 450 |  |  | 850 |  |  | 416 |  |  | 462 |  |  | 878 |  |
| Building Solutions Asia Pacific |  | 271 |  |  | 254 |  |  | 525 |  |  | 351 |  |  | 277 |  |  | 628 |  |
| Global Products |  | 1,894 |  |  | — |  |  | 1,894 |  |  | 2,086 |  |  | — |  |  | 2,086 |  |
| Total |  | $ | 3,922 |  |  | $ | 1,522 |  |  | $ | 5,444 |  |  | $ | 4,240 |  |  | $ | 1,539 |  |  | $ | 5,779 |  |

- changed (2020-07-31):
[0000833444-20-000036:note_history:65]
|  |  | Nine Months Ended June 30, 2020 |  |  |  |  |  | Nine Months Ended June 30, 2019 |  |  |  |  |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,963 |  |  | $ | 2,399 |  |  | $ | 6,362 |  |  | $ | 4,202 |  |  | $ | 2,428 |  |  | $ | 6,630 |  |
| Building Solutions EMEA/LA |  | 1,203 |  |  | 1,331 |  |  | 2,534 |  |  | 1,297 |  |  | 1,410 |  |  | 2,707 |  |
| Building Solutions Asia Pacific |  | 986 |  |  | 756 |  |  | 1,742 |  |  | 1,134 |  |  | 798 |  |  | 1,932 |  |
| Global Products |  | 5,725 |  |  | — |  |  | 5,725 |  |  | 6,425 |  |  | — |  |  | 6,425 |  |
| Total |  | $ | 11,877 |  |  | $ | 4,486 |  |  | $ | 16,363 |  |  | $ | 13,058 |  |  | $ | 4,636 |  |  | $ | 17,694 |  |
  (was, 2020-05-01, similarity 0.9154):
[0000833444-20-000015:note_history:65]
|  |  | Six Months Ended March 31, 2020 |  | Six Months Ended March 31, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 2,713 |  |  | $ | 1,629 |  |  | $ | 4,342 |  |  | $ | 2,708 |  |  | $ | 1,595 |  |  | $ | 4,303 |  |
| Building Solutions EMEA/LA |  | 857 |  |  | 921 |  |  | 1,778 |  |  | 833 |  |  | 952 |  |  | 1,785 |  |
| Building Solutions Asia Pacific |  | 642 |  |  | 512 |  |  | 1,154 |  |  | 707 |  |  | 534 |  |  | 1,241 |  |
| Global Products |  | 3,746 |  |  | — |  |  | 3,746 |  |  | 3,914 |  |  | — |  |  | 3,914 |  |
| Total |  | $ | 7,958 |  |  | $ | 3,062 |  |  | $ | 11,020 |  |  | $ | 8,162 |  |  | $ | 3,081 |  |  | $ | 11,243 |  |

- changed (2020-07-31):
[0000833444-20-000036:note_history:66]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and nine months ended June 30, 2020 and 2019 (in millions):
  (was, 2020-05-01, similarity 0.9586):
[0000833444-20-000015:note_history:66]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and six months ended March 31, 2020 and 2019 (in millions):

- changed (2020-07-31):
[0000833444-20-000036:note_history:67]
|  |  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Building management systems |  | $ | 244 |  |  | $ | 342 |  |  | $ | 860 |  |  | $ | 943 |  |
| HVAC & refrigeration equipment |  | 1,493 |  |  | 1,869 |  |  | 4,085 |  |  | 4,628 |  |
| Specialty products |  | 242 |  |  | 300 |  |  | 780 |  |  | 854 |  |
| Total |  | $ | 1,979 |  |  | $ | 2,511 |  |  | $ | 5,725 |  |  | $ | 6,425 |  |
  (was, 2020-05-01, similarity 0.8886):
[0000833444-20-000015:note_history:67]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Building management systems |  | $ | 316 |  |  | $ | 320 |  |  | $ | 616 |  |  | $ | 601 |  |
| HVAC & refrigeration equipment |  | 1,307 |  |  | 1,474 |  |  | 2,592 |  |  | 2,759 |  |
| Specialty products |  | 271 |  |  | 292 |  |  | 538 |  |  | 554 |  |
| Total |  | $ | 1,894 |  |  | $ | 2,086 |  |  | $ | 3,746 |  |  | $ | 3,914 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-07-31):
[0000833444-20-000036:note_history:68]
Revenue Recognition
Disaggregated Revenue
  (was, 2020-05-01, similarity 0.6774):
[0000833444-20-000015:note_history:68]
Disaggregated Revenue

- changed (2020-07-31):
[0000833444-20-000036:note_history:69]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three and nine months ended June 30, 2020 and 2019 (in millions):
  (was, 2020-05-01, similarity 0.9639):
[0000833444-20-000015:note_history:69]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three and six months ended March 31, 2020 and 2019 (in millions):

- changed (2020-07-31):
[0000833444-20-000036:note_history:70]
|  |  | Three Months Ended June 30, 2020 |  |  |  |  |  | Three Months Ended June 30, 2019 |  |  |  |  |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,250 |  |  | $ | 770 |  |  | $ | 2,020 |  |  | $ | 1,494 |  |  | $ | 833 |  |  | $ | 2,327 |  |
| Building Solutions EMEA/LA |  | 346 |  |  | 410 |  |  | 756 |  |  | 464 |  |  | 458 |  |  | 922 |  |
| Building Solutions Asia Pacific |  | 344 |  |  | 244 |  |  | 588 |  |  | 427 |  |  | 264 |  |  | 691 |  |
| Global Products |  | 1,979 |  |  | — |  |  | 1,979 |  |  | 2,511 |  |  | — |  |  | 2,511 |  |
| Total |  | $ | 3,919 |  |  | $ | 1,424 |  |  | $ | 5,343 |  |  | $ | 4,896 |  |  | $ | 1,555 |  |  | $ | 6,451 |  |
  (was, 2020-05-01, similarity 0.9175):
[0000833444-20-000015:note_history:70]
|  |  | Three Months Ended March 31, 2020 |  | Three Months Ended March 31, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,357 |  |  | $ | 818 |  |  | $ | 2,175 |  |  | $ | 1,387 |  |  | $ | 800 |  |  | $ | 2,187 |  |
| Building Solutions EMEA/LA |  | 400 |  |  | 450 |  |  | 850 |  |  | 416 |  |  | 462 |  |  | 878 |  |
| Building Solutions Asia Pacific |  | 271 |  |  | 254 |  |  | 525 |  |  | 351 |  |  | 277 |  |  | 628 |  |
| Global Products |  | 1,894 |  |  | — |  |  | 1,894 |  |  | 2,086 |  |  | — |  |  | 2,086 |  |
| Total |  | $ | 3,922 |  |  | $ | 1,522 |  |  | $ | 5,444 |  |  | $ | 4,240 |  |  | $ | 1,539 |  |  | $ | 5,779 |  |

- changed (2020-07-31):
[0000833444-20-000036:note_history:71]
|  |  | Nine Months Ended June 30, 2020 |  |  |  |  |  | Nine Months Ended June 30, 2019 |  |  |  |  |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,963 |  |  | $ | 2,399 |  |  | $ | 6,362 |  |  | $ | 4,202 |  |  | $ | 2,428 |  |  | $ | 6,630 |  |
| Building Solutions EMEA/LA |  | 1,203 |  |  | 1,331 |  |  | 2,534 |  |  | 1,297 |  |  | 1,410 |  |  | 2,707 |  |
| Building Solutions Asia Pacific |  | 986 |  |  | 756 |  |  | 1,742 |  |  | 1,134 |  |  | 798 |  |  | 1,932 |  |
| Global Products |  | 5,725 |  |  | — |  |  | 5,725 |  |  | 6,425 |  |  | — |  |  | 6,425 |  |
| Total |  | $ | 11,877 |  |  | $ | 4,486 |  |  | $ | 16,363 |  |  | $ | 13,058 |  |  | $ | 4,636 |  |  | $ | 17,694 |  |
  (was, 2020-05-01, similarity 0.9154):
[0000833444-20-000015:note_history:71]
|  |  | Six Months Ended March 31, 2020 |  | Six Months Ended March 31, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 2,713 |  |  | $ | 1,629 |  |  | $ | 4,342 |  |  | $ | 2,708 |  |  | $ | 1,595 |  |  | $ | 4,303 |  |
| Building Solutions EMEA/LA |  | 857 |  |  | 921 |  |  | 1,778 |  |  | 833 |  |  | 952 |  |  | 1,785 |  |
| Building Solutions Asia Pacific |  | 642 |  |  | 512 |  |  | 1,154 |  |  | 707 |  |  | 534 |  |  | 1,241 |  |
| Global Products |  | 3,746 |  |  | — |  |  | 3,746 |  |  | 3,914 |  |  | — |  |  | 3,914 |  |
| Total |  | $ | 7,958 |  |  | $ | 3,062 |  |  | $ | 11,020 |  |  | $ | 8,162 |  |  | $ | 3,081 |  |  | $ | 11,243 |  |

- changed (2020-07-31):
[0000833444-20-000036:note_history:72]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and nine months ended June 30, 2020 and 2019 (in millions):
  (was, 2020-05-01, similarity 0.9586):
[0000833444-20-000015:note_history:72]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and six months ended March 31, 2020 and 2019 (in millions):

- changed (2020-07-31):
[0000833444-20-000036:note_history:73]
|  |  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Building management systems |  | $ | 244 |  |  | $ | 342 |  |  | $ | 860 |  |  | $ | 943 |  |
| HVAC & refrigeration equipment |  | 1,493 |  |  | 1,869 |  |  | 4,085 |  |  | 4,628 |  |
| Specialty products |  | 242 |  |  | 300 |  |  | 780 |  |  | 854 |  |
| Total |  | $ | 1,979 |  |  | $ | 2,511 |  |  | $ | 5,725 |  |  | $ | 6,425 |  |
  (was, 2020-05-01, similarity 0.8886):
[0000833444-20-000015:note_history:73]
|  |  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Building management systems |  | $ | 316 |  |  | $ | 320 |  |  | $ | 616 |  |  | $ | 601 |  |
| HVAC & refrigeration equipment |  | 1,307 |  |  | 1,474 |  |  | 2,592 |  |  | 2,759 |  |
| Specialty products |  | 271 |  |  | 292 |  |  | 538 |  |  | 554 |  |
| Total |  | $ | 1,894 |  |  | $ | 2,086 |  |  | $ | 3,746 |  |  | $ | 3,914 |  |

- changed (2020-07-31):
[0000833444-20-000036:note_history:74]
|  |  | Location of contract balances |  | June 30, 2020 |  | September 30, 2019 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,409 |  |  | $ | 1,389 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 98 |  |  | 90 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,451) |  |  | (1,407) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (120) |  |  | (117) |  |  |  |
| Total |  |  |  | $ | (64) |  |  | $ | (45) |  |  |  |
  (was, 2020-05-01, similarity 0.882):
[0000833444-20-000015:note_history:74]
|  |  | Location of contract balances |  | March 31, 2020 |  | September 30, 2019 |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,422 |  |  | $ | 1,389 |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 95 |  |  | 90 |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,600 | ) |  | (1,407 | ) |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (119 | ) |  | (117 | ) |
| Total |  |  |  | $ | (202 | ) |  | $ | (45 | ) |

- added (2020-07-31):
[0000833444-20-000036:note_history:75]
For the three months ended June 30, 2020 and June 30, 2019, the Company recognized revenue of $125 million and $130 million, respectively, that was included in the beginning of period contract liability balance. For the nine months ended June 30, 2020 and June 30, 2019, the Company recognized revenue of $1,137 million and $1,056 million, respectively, that was included in the beginning of period contract liability balance.

- changed (2020-07-31):
[0000833444-20-000036:note_history:76]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of June 30, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $14.4 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.
  (was, 2020-05-01, similarity 0.9954):
[0000833444-20-000015:note_history:76]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of March 31, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $14.4 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

- added (2020-07-31):
[0000833444-20-000036:note_history:77]
As of June 30, 2020, the Company recorded the costs to obtain or fulfill a contract of $224 million, of which $121 million is recorded within other current assets and $103 million is recorded within other noncurrent assets in the consolidated statements of financial position. As of September 30, 2019, the Company recorded the costs to obtain or fulfill a contract of $212 million, of which $110 million is recorded within other current assets and $102 million is recorded within other noncurrent assets in the consolidated statements of financial position.

- changed (2020-07-31):
[0000833444-20-000036:note_history:78]
During the three months ended June 30, 2020 and 2019, the Company recognized amortization expense of $47 million and $50 million, respectively, related to costs to obtain or fulfill a contract. During the nine months ended June 30, 2020 and 2019, the Company recognized amortization expense of $116 million and $119 million, respectively, related to costs to 
obtain or fulfill a contract.  There were no impairment losses recognized in the three and nine months ended June 30, 2020 and 2019.
  (was, 2020-05-01, similarity 0.871):
[0000833444-20-000015:note_history:78]
During the three months ended March 31, 2020 and 2019, the Company recognized amortization expense of $43 million and $34 million, respectively, related to costs to obtain or fulfill a contract. During the six months ended March 31, 2020 and 2019, the Company recognized amortization expense of $69 million and $69 million, respectively, related to costs to obtain or fulfill a contract.  There were no impairment losses recognized in the three months ended March 31, 2020 and 2019.

- removed (2020-07-31):
[0000833444-20-000015:note_history:79]
Revenue Recognition

- removed (2020-07-31):
[0000833444-20-000015:note_history:80]
For the three months ended March 31, 2020 and March 31, 2019, the Company recognized revenue of $326 million and $214 million, respectively, that was included in the beginning of period contract liability balance. For the six months ended March 31, 2020 and March 31, 2019, the Company recognized revenue of $1,012 million and $926 million, respectively, that was included in the beginning of period contract liability balance.

- removed (2020-07-31):
[0000833444-20-000015:note_history:81]
As of March 31, 2020, the Company recorded the costs to obtain or fulfill a contract of $228 million, of which $123 million is recorded within other current assets and $105 million is recorded within other noncurrent assets in the consolidated statements of financial position. As of September 30, 2019, the Company recorded the costs to obtain or fulfill a contract of $212 million, of which $110 million is recorded within other current assets and $102 million is recorded within other noncurrent assets in the consolidated statements of financial position.
