# JCI MD&A — 0000833444-25-000063


## mdna

[0000833444-25-000063:mdna:1]
[same as prior period, unchanged from 0000833444-25-000032:mdna:1]

[0000833444-25-000063:mdna:2]
[same as prior period, unchanged from 0000833444-25-000032:mdna:2]

[0000833444-25-000063:mdna:3]
[same as prior period, unchanged from 0000833444-25-000032:mdna:3]

[0000833444-25-000063:mdna:4]
[same as prior period, unchanged from 0000833444-25-000032:mdna:4]

[0000833444-25-000063:mdna:5]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, safe, healthy and sustainable buildings, serving a wide range of customers around the globe. The Company’s products and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-25-000063:mdna:6]
35

[0000833444-25-000063:mdna:7]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space) and energy-management consulting. The Company partners with customers by leveraging its broad product portfolio and digital capabilities, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency, enhance security, create healthy environments and reduce greenhouse gas emissions.

[0000833444-25-000063:mdna:8]
On April 1, 2025, the Company, as part of ongoing initiatives to drive simplification, accelerate growth, better reflect its organizational and operational structure and align with the manner in which the Company's chief operating decision maker assesses performance and makes decisions regarding the allocation of resources following portfolio simplification actions, realigned into three reportable segments (Americas, EMEA and APAC) from four reportable segments (Global Products, Building Solutions North America, Building Solutions EMEA/LA and Building Solutions APAC). The Company began reporting under this segment structure on April 1, 2025.

[0000833444-25-000063:mdna:9]
The following information should be read in conjunction with the September 30, 2024 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in the Company's Annual Report on Form 10-K for the year ended September 30, 2024 filed with the SEC on November 19, 2024. References in the following discussion and analysis to "Three Months," "Third Quarter" or similar language refer to the three months ended June 30, 2025 compared to the three months ended June 30, 2024, while "Year-to-Date" refers to nine months ended June 30, 2025 compared to the nine months ended June 30, 2024.

[0000833444-25-000063:mdna:10]
[same as prior period, unchanged from 0000833444-25-000032:mdna:10]

[0000833444-25-000063:mdna:11]
[same as prior period, unchanged from 0000833444-25-000032:mdna:11]

[0000833444-25-000063:mdna:12]
The Company maintains global operations. The United States has announced tariffs and reciprocal tariffs on a wide range of products manufactured or produced worldwide, including Canada, China, the European Union, Japan and Mexico, among others. Several countries have similarly announced reciprocal or other tariffs impacting products manufactured or produced in the United States. In addition, the United States and other nations have, and may in the future, pause, reimpose, decrease or increase tariffs. Although the Company has been largely able to mitigate the impact of tariffs that have been enacted to date, if additional tariffs and reciprocal tariffs are implemented (whether as currently proposed or otherwise), such actions could negatively impact the Company's revenue growth and margins in future periods through decreased sales and increased cost of goods sold. Further, the Company has experienced, and could again experience, increased material cost inflation and component shortages, as well as disruptions and delays in its supply chain, as a result of global macroeconomic trends including the imposition of tariffs and other restrictive trade measures, as well as geopolitical and economic tensions. The net effect of these events will continue to depend on the Company’s ability to successfully mitigate and offset their impact.

[0000833444-25-000063:mdna:13]
The Company is taking actions to mitigate the actual and anticipated impact of these events, including strengthening the Company's in region, for region manufacturing strategy, pivoting to local sourcing in its supply chain, accelerating pricing actions and asserting contractual rights through change orders. The Company has historically taken a variety of actions to mitigate trade restrictions, supply chain disruptions and inflation, including through expanding and redistributing its supplier network, supplier financing, accelerated purchasing and productivity improvements. These actions have largely been successful mitigating the impacts of the current macroeconomic environment, however, it is uncertain as to whether the actions taken or contemplated to be taken by the Company will be effective in continuing to mitigate the impact of current and future trade restrictions and their related impacts. The Company continues to actively monitor and evaluate the development and potential impacts of tariffs and other trade restrictions on its supply chain and results of operations.

[0000833444-25-000063:mdna:14]
As a result of the Company’s global presence, a significant portion of its revenues and expenses are denominated in currencies other than the U.S. dollar, which results in non-U.S. currency risks and exchange exposure. While the Company employs financial instruments to hedge some of its transactional foreign exchange exposure, these activities do not insulate it completely from those exposures. In addition, currency exposure from the translation of non-U.S. dollar functional currency subsidiaries

[0000833444-25-000063:mdna:15]
cannot be hedged. Exchange rates can be volatile and a substantial weakening or strengthening of foreign currencies against the U.S. dollar could increase or reduce the Company’s profit margin, respectively, and impact the comparability of results from period to period.

[0000833444-25-000063:mdna:16]
[same as prior period, unchanged from 0000833444-25-000032:mdna:15]

[0000833444-25-000063:mdna:17]
Certain of our customers, including governmental and institutional customers, have exhibited increased uncertainty regarding future spending decisions due to various political and economic factors, including budget reductions, reprioritization of spending, interest rate fluctuation and economic uncertainty. This uncertainty has and may in the future impact the Company's ability to predict and forecast the revenue and backlog associated with these customers.

[0000833444-25-000063:mdna:18]
The extent to which the Company’s results of operations and financial condition are impacted by these and other factors in the future will depend on developments that are highly uncertain and cannot be predicted. See the section entitled "Risk Factors" in Johnson Controls' Annual Report on Form 10-K for the year ended September 30, 2024 filed with the United States Securities and Exchange Commission ("SEC") on November 19, 2024. Certain of these risk factors have been updated and supplemented in the Company's Quarterly Reports on Form 10-Q for the quarters ended December 31, 2024 and March 31, 2025, filed on February 5, 2025 and May 7, 2025, respectively.

[0000833444-25-000063:mdna:19]
[same as prior period, unchanged from 0000833444-25-000032:mdna:18]

[0000833444-25-000063:mdna:20]
The Company continues to engage in an ongoing evaluation of its non-core product lines in connection with its objective to be a pure-play provider of comprehensive solutions for commercial buildings. On July 31, 2025, the Company completed the divestiture of its Residential and Light Commercial ("R&LC") HVAC business to Robert Bosch GmbH (“Bosch”) for net cash proceeds of approximately $5.0 billion after tax and transaction-related expenses. The R&LC HVAC business included the Company's North America Ducted business and Johnson Controls-Hitachi Air Conditioning Holding (UK) Ltd., the Company’s global residential joint venture with Hitachi Global Life Solutions, Inc.

[0000833444-25-000063:mdna:21]
[same as prior period, unchanged from 0000833444-25-000032:mdna:20]

[0000833444-25-000063:mdna:22]
During the fourth quarter of fiscal 2024, the Company committed to a multi-year restructuring plan to address stranded costs and further right-size its global operations as a result of previously announced portfolio simplification actions. It is expected that one-time restructuring costs, including severance and other employee termination benefits, contract termination costs, and certain other related cash and non-cash charges, of approximately $400 million will be incurred over the course of fiscal 2025, 2026 and 2027, resulting in expected annual cost savings of approximately $500 million upon full completion of the plan. Restructuring and transformation costs in fiscal 2025 have been material, with the resulting savings being realized in fiscal 2026 and 2027. Restructuring costs will be incurred across all segments and Corporate functions.

[0000833444-25-000063:mdna:23]
[same as prior period, unchanged from 0000833444-25-000032:mdna:24]

[0000833444-25-000063:mdna:24]
[same as prior period, unchanged from 0000833444-25-000032:mdna:25]

[0000833444-25-000063:mdna:25]
The Company determined that certain data, primarily employee, job applicant and personal information and other related data, was impacted by the incident. The Company has taken appropriate actions to notify individuals and regulatory authorities.

[0000833444-25-000063:mdna:26]
[same as prior period, unchanged from 0000833444-25-000032:mdna:27]

[0000833444-25-000063:mdna:27]
37

[0000833444-25-000063:mdna:28]
[same as prior period, unchanged from 0000833444-25-000032:mdna:28]

[0000833444-25-000063:mdna:29]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
| (in millions) | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
| Net sales | $ | 6,052 |  |  | $ | 5,898 |  |  | 3 | % |  | $ | 17,154 |  |  | $ | 16,704 |  |  | 3 | % |

[0000833444-25-000063:mdna:30]
The increase in net sales for the three months ended June 30, 2025 was due to higher organic sales ($343 million) and the favorable impact of foreign currency translation ($55 million), partially offset by the net impact of acquisitions and divestitures ($244 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, net sales increased 6% over the prior year, driven by growth in Services across all segments as well as growth in Products and Systems, led by the Americas.

[0000833444-25-000063:mdna:31]
The increase in net sales for the nine months ended June 30, 2025 was due to higher organic sales ($1,205 million), partially offset by the net impact of acquisitions and divestitures ($708 million) and the unfavorable impact of foreign currency translation ($47 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, net sales increased 8% over the prior year, driven by growth in Services across all segments and growth in Products and Systems, led by the Americas.

[0000833444-25-000063:mdna:32]
[same as prior period, unchanged from 0000833444-25-000032:mdna:32]

[0000833444-25-000063:mdna:33]
[same as prior period, unchanged from 0000833444-25-000032:mdna:33]

[0000833444-25-000063:mdna:34]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
| (in millions) | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
| Cost of sales | $ | 3,806 |  |  | $ | 3,789 |  |  | — | % |  | $ | 10,913 |  |  | $ | 10,895 |  |  | — | % |
| Gross profit | 2,246 |  |  | 2,109 |  |  | 6 | % |  | 6,241 |  |  | 5,809 |  |  | 7 | % |
| % of sales | 37.1 | % |  | 35.8 | % |  | 130 | bp |  | 36.4 | % |  | 34.8 | % |  | 160 | bp |

[0000833444-25-000063:mdna:35]
The increase in gross profit for the three and nine months ended June 30, 2025 was primarily due to margin improvements as a result of converting backlog with increased mix of long-term, higher margin Systems projects and optimized Services mix.

[0000833444-25-000063:mdna:36]
[same as prior period, unchanged from 0000833444-25-000032:mdna:36]

[0000833444-25-000063:mdna:37]
[same as prior period, unchanged from 0000833444-25-000032:mdna:37]

[0000833444-25-000063:mdna:38]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
| (in millions) | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
| SG&A | $ | 1,417 |  |  | $ | 895 |  |  | 58 | % |  | $ | 4,243 |  |  | $ | 4,293 |  |  | (1 | %) |
| % of sales | 23.4 | % |  | 15.2 | % |  | 820 | bp |  | 24.7 | % |  | 25.7 | % |  | (100) | bp |

[0000833444-25-000063:mdna:39]
For the three months ended June 30, 2025, the increase in SG&A was primarily due to the unfavorable impact of the prior year water systems AFFF insurance recoveries ($350 million), the unfavorable impact of prior year earn-out adjustments ($61 million) and higher transformation costs ($45 million).

[0000833444-25-000063:mdna:40]
For the nine months ended June 30, 2025, the decrease in SG&A was primarily due to the favorable net impact of the prior year water systems AFFF settlement agreement costs and insurance recoveries ($412 million), partially offset by higher transformation costs ($124 million), the unfavorable impact of prior year earn-out adjustments ($68 million) and the impact of net mark-to-market adjustments ($35 million).

[0000833444-25-000063:mdna:41]
Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA. Refer to Note 18, "Commitments and Contingencies," of the notes to the consolidated financial statements for further disclosure related to the water systems AFFF settlement.

[0000833444-25-000063:mdna:42]
[same as prior period, unchanged from 0000833444-25-000032:mdna:42]

[0000833444-25-000063:mdna:43]
|  | Three Months Ended June 30, | Nine Months Ended June 30, |
| (in millions) | 2025 |  | 2024 |  |  | 2025 |  | 2024 |  |
| Goodwill and other intangible asset impairments | $ | — |  |  | $ | 21 |  |  |  | $ | 22 |  |  | $ | 251 |  |  |
| Held for sale impairments | — |  |  | 35 |  |  |  | — |  |  | 35 |  |  |
| Other impairments | 2 |  |  | 10 |  |  |  | 2 |  |  | 10 |  |  |
| Restructuring and related costs | 49 |  |  | 37 |  |  |  | 122 |  |  | 81 |  |  |
| Restructuring and impairment costs | $ | 51 |  |  | $ | 103 |  |  |  | $ | 146 |  |  | $ | 377 |  |  |

[0000833444-25-000063:mdna:44]
[same as prior period, unchanged from 0000833444-25-000032:mdna:44]

[0000833444-25-000063:mdna:45]
[same as prior period, unchanged from 0000833444-25-000032:mdna:45]

[0000833444-25-000063:mdna:46]
|  | Three Months Ended June 30, | Nine Months Ended June 30, |
| (in millions) | 2025 |  | 2024 |  |  | 2025 |  | 2024 |  |
| Interest expense, net of capitalized interest costs | $ | 55 |  |  | $ | 84 |  |  |  | $ | 178 |  |  | $ | 266 |  |  |
| Other financing charges | 4 |  |  | 6 |  |  |  | 14 |  |  | 32 |  |  |
| Interest income | (3) |  |  | (9) |  |  |  | (8) |  |  | (19) |  |  |
| Net foreign exchange results for financing activities | 21 |  |  | (11) |  |  |  | 59 |  |  | (33) |  |  |
| Net financing charges | $ | 77 |  |  | $ | 70 |  |  |  | $ | 243 |  |  | $ | 246 |  |  |

[0000833444-25-000063:mdna:47]
[same as prior period, unchanged from 0000833444-25-000032:mdna:47]

[0000833444-25-000063:mdna:48]
Income Tax Provision

[0000833444-25-000063:mdna:49]
|  | Three Months Ended June 30, | Nine Months Ended June 30, |
| (in millions) | 2025 |  | 2024 |  |  | 2025 |  | 2024 |  |
| Income tax provision | $ | 87 |  |  | $ | 174 |  |  |  | $ | 160 |  |  | $ | 1 |  |  |
| Effective tax rate | 12.3 | % |  | 17.0 | % |  |  | 9.9 | % |  | 0.1 | % |  |

[0000833444-25-000063:mdna:50]
[same as prior period, unchanged from 0000833444-25-000032:mdna:51]

[0000833444-25-000063:mdna:51]
[same as prior period, unchanged from 0000833444-25-000032:mdna:52]

[0000833444-25-000063:mdna:52]
[same as prior period, unchanged from 0000833444-25-000032:mdna:53]

[0000833444-25-000063:mdna:53]
[same as prior period, unchanged from 0000833444-25-000032:mdna:54]

[0000833444-25-000063:mdna:54]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
| (in millions) | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
| Americas | $ | 4,042 |  |  | $ | 4,035 |  |  | — | % |  | $ | 11,506 |  |  | $ | 11,341 |  |  | 1 | % |
| EMEA | 1,273 |  |  | 1,177 |  |  | 8 | % |  | 3,631 |  |  | 3,440 |  |  | 6 | % |
| APAC | 737 |  |  | 686 |  |  | 7 | % |  | 2,017 |  |  | 1,923 |  |  | 5 | % |
|  | $ | 6,052 |  |  | $ | 5,898 |  |  | 3 | % |  | $ | 17,154 |  |  | $ | 16,704 |  |  | 3 | % |

[0000833444-25-000063:mdna:55]
[same as prior period, unchanged from 0000833444-25-000032:mdna:56]

[0000833444-25-000063:mdna:56]
•Americas net sales were flat as organic growth ($259 million) was offset by the impact of divestitures ($243 million) and the unfavorable impact of foreign currency translation ($9 million). Excluding the impact of divestitures and foreign currency translation, sales increased 7%, led by continued strength across Applied HVAC and Controls. Products and Systems sales increased 8% and Services increased 4%.

[0000833444-25-000063:mdna:57]
•The increase in EMEA was primarily due to the favorable impact of foreign currency translation ($52 million) and organic growth ($45 million). Excluding the impact of foreign currency translation, sales growth was primarily led by 8% growth in Services.

[0000833444-25-000063:mdna:58]
•The increase in APAC was primarily due to organic growth ($39 million) and the favorable impact of foreign currency translation ($12 million). Excluding the impact of foreign currency translation, sales growth was led by 11% growth in Services and 3% growth in Products and Systems.

[0000833444-25-000063:mdna:59]
[same as prior period, unchanged from 0000833444-25-000032:mdna:61]

[0000833444-25-000063:mdna:60]
•The increase in Americas was primarily due to organic growth ($919 million), partially offset by the impact of divestitures ($714 million) and the unfavorable impact of foreign currency translation ($40 million). Excluding the impact of divestitures and foreign currency translation, sales increased 9%, led by growth in Applied HVAC and Controls.

[0000833444-25-000063:mdna:61]
•The increase in EMEA was primarily due to organic growth ($187 million) and incremental sales related to the net impact of business acquisitions and divestitures ($6 million), partially offset by the unfavorable foreign currency translation ($2 million). Excluding the impact of business acquisitions, divestitures, and foreign currency translation, sales growth was led by 9% growth in Services.

[0000833444-25-000063:mdna:62]
•The increase in APAC was primarily due to organic growth ($99 million), partially offset by the unfavorable impact of foreign currency translation ($5 million). Excluding the impact of foreign currency translation, sales growth was led by 13% growth in Services.

[0000833444-25-000063:mdna:63]
[same as prior period, unchanged from 0000833444-25-000032:mdna:66]

[0000833444-25-000063:mdna:64]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
| (in millions) | 2025 |  | 2024 |  | Change |  | 2025 |  | 2024 |  | Change |
| Americas | $ | 742 |  |  | $ | 804 |  |  | (8 | %) |  | $ | 2,038 |  |  | $ | 1,853 |  |  | 10 | % |
| EMEA | 177 |  |  | 154 |  |  | 15 | % |  | 448 |  |  | 397 |  |  | 13 | % |
| APAC | 143 |  |  | 128 |  |  | 12 | % |  | 337 |  |  | 320 |  |  | 5 | % |

[0000833444-25-000063:mdna:65]
[same as prior period, unchanged from 0000833444-25-000032:mdna:68]

[0000833444-25-000063:mdna:66]
•The decrease in Americas was primarily due to the impact of divestitures, unfavorable mix and the impact of prior year earn-out adjustments, partially offset by higher margin backlog conversion and productivity improvements.

[0000833444-25-000063:mdna:67]
•The increase in EMEA was primarily driven by productivity improvements and positive mix from the growth in Services.

[0000833444-25-000063:mdna:68]
•The increase in APAC was primarily driven by productivity improvements.

[0000833444-25-000063:mdna:69]
[same as prior period, unchanged from 0000833444-25-000032:mdna:73]

[0000833444-25-000063:mdna:70]
•The increase in Americas was primarily due to higher margin backlog conversion and productivity improvements, partially offset by the impact of divestitures, prior year earn-out adjustments and ongoing growth investments.

[0000833444-25-000063:mdna:71]
•The increase in EMEA was primarily driven by productivity improvements and positive mix from the growth in Services.

[0000833444-25-000063:mdna:72]
•The increase in APAC was primarily driven by productivity improvements.

[0000833444-25-000063:mdna:73]
[same as prior period, unchanged from 0000833444-25-000032:mdna:78]

[0000833444-25-000063:mdna:74]
Backlog and orders are additional metrics that are meant to provide management with a deeper level of insight into the progress of specific strategic and growth initiatives. Backlog is applicable to sales of products and systems and services and totaled $16.2 billion at June 30, 2025. Orders provide management with a signal of customer demand for the Company's products and services, as well as an indication of future revenues and performance. However, the timing and conversion of backlog and orders are subject to numerous uncertainties and risks and are not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-25-000063:mdna:75]
The following table summarizes backlog and orders by segment for the Systems and Services based businesses:

[0000833444-25-000063:mdna:76]
|  | Backlog |  | Orders |
| (in billions) | June 30, 2025 |  |  |  | Year-over-Year Change (1) |  | Three Months Ended June 30, 2025 |  |  |  | Year-over-Year Change (1) |
| Americas | $ | 10.3 |  |  |  |  | 10 | % |  | $ | 3.4 |  |  |  |  | 5 | % |
| EMEA | 2.6 |  |  |  |  | 9 | % |  | 1.1 |  |  |  |  | 2 | % |
| APAC | 1.7 |  |  |  |  | 14 | % |  | 0.7 |  |  |  |  | (8 | %) |
| Total | $ | 14.6 |  |  |  |  | 11 | % |  | $ | 5.2 |  |  |  |  | 2 | % |

[0000833444-25-000063:mdna:77]
(1) Change is compared to June 30, 2024 (backlog) and the three months ended June 30, 2024 (orders) and excludes the impact of mergers, acquisitions, divestitures and foreign currency.

[0000833444-25-000063:mdna:78]
Remaining performance obligations were $22.4 billion at June 30, 2025. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-25-000063:mdna:79]
[same as prior period, unchanged from 0000833444-25-000032:mdna:84]

[0000833444-25-000063:mdna:80]
[same as prior period, unchanged from 0000833444-25-000032:mdna:85]

[0000833444-25-000063:mdna:81]
[same as prior period, unchanged from 0000833444-25-000032:mdna:86]

[0000833444-25-000063:mdna:82]
[same as prior period, unchanged from 0000833444-25-000032:mdna:87]

[0000833444-25-000063:mdna:83]
[same as prior period, unchanged from 0000833444-25-000032:mdna:88]

[0000833444-25-000063:mdna:84]
| (in millions) | June 30, 2025 |  | September 30, 2024 |  | Change |
| Current assets | $ | 11,849 |  |  | $ | 11,179 |  |  |  |
| Current liabilities | 12,350 |  |  | 11,955 |  |  |  |
| Working capital | $ | (501) |  |  | $ | (776) |  |  | (35) | % |
| Accounts receivable - net | $ | 6,151 |  |  | $ | 6,051 |  |  | 2 | % |
| Inventories | 1,829 |  |  | 1,774 |  |  | 3 | % |
| Accounts payable | 3,421 |  |  | 3,389 |  |  | 1 | % |

[0000833444-25-000063:mdna:85]
•The increase in working capital at June 30, 2025 as compared to September 30, 2024 was primarily due to a decrease in other current liabilities due to a payment related to the AFFF settlement agreement and an increase in current assets held for sale primarily due to seasonal increases in inventory and increases in accounts receivable related to the R&LC HVAC business, partially offset by higher short-term debt, an increase in deferred revenue and the net impact of various other current assets and liabilities.

[0000833444-25-000063:mdna:86]
[same as prior period, unchanged from 0000833444-25-000032:mdna:91]

[0000833444-25-000063:mdna:87]
|  |  | Nine Months Ended June 30, |
| (in millions) |  | 2025 |  | 2024 |
| Cash provided by operating activities |  | $ | 1,586 |  |  | $ | 216 |  |
| Cash used by investing activities |  | (302) |  |  | (286) |  |
| Cash used by financing activities |  | (1,111) |  |  | (190) |  |

[0000833444-25-000063:mdna:88]
•The increase in cash provided by operating activities reflects higher net income and decreases in accounts receivable and other assets, partially offset by the timing of accounts payable and accrued liabilities payments.

[0000833444-25-000063:mdna:89]
[same as prior period, unchanged from 0000833444-25-000032:mdna:94]

[0000833444-25-000063:mdna:90]
•The increase in cash used by financing activities was primarily due to changes in net debt activity.

[0000833444-25-000063:mdna:91]
[same as prior period, unchanged from 0000833444-25-000032:mdna:96]

[0000833444-25-000063:mdna:92]
| (in millions) | June 30, 2025 |  | September 30, 2024 |  |
| Short-term debt | $ | 1,277 |  |  | $ | 953 |  |  |
| Current portion of long-term debt | 570 |  |  | 536 |  |  |
| Long-term debt | 8,446 |  |  | 8,004 |  |  |
| Total debt | 10,293 |  |  | 9,493 |  |  |
| Less: Cash and cash equivalents | 731 |  |  | 606 |  |  |
| Net debt | $ | 9,562 |  |  | $ | 8,887 |  |  |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders ("Equity") | $ | 15,830 |  |  | $ | 16,098 |  |  |
| Total capitalization (Total debt plus Equity) | 26,123 |  |  | 25,591 |  |  |
| Net capitalization (Net debt plus Equity) | 25,392 |  |  | 24,985 |  |  |
| Total debt as a % of Total capitalization | 39.4 | % |  | 37.1 | % |  |
| Net debt as a % of Net capitalization | 37.7 | % |  | 35.6 | % |  |

[0000833444-25-000063:mdna:93]
[same as prior period, unchanged from 0000833444-25-000032:mdna:98]

[0000833444-25-000063:mdna:94]
•In June 2025, the Company's Board of Directors approved a $9.0 billion increase to the Company's share repurchase authorization, adding to the $1.1 billion remaining as of March 31, 2025 under the prior share repurchase authorization approved in 2021. As of June 30, 2025, approximately $9.8 billion remains available under the Company's share repurchase authorization, which does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. The Company expects to repurchase outstanding shares from time to time depending on market conditions, alternate uses of capital, liquidity, and the economic environment.

[0000833444-25-000063:mdna:95]
•The Company declared a dividend of $0.37 per common share in the quarter ended June 30, 2025 and intends to continue paying dividends throughout fiscal 2025.

[0000833444-25-000063:mdna:96]
•The Company received net cash proceeds related to the sale of its R&LC HVAC business of approximately $5.0 billion after tax and transaction-related expenses in connection with the close of the transaction on July 31, 2025. Consistent with its capital allocation policy, the Company expects to return a portion of the net proceeds of the transaction to shareholders through the implementation of a $5.0 billion accelerated share repurchase program expected to commence in the coming weeks pursuant to its previously announced share repurchase authorization.

[0000833444-25-000063:mdna:97]
•The Company believes its capital resources and liquidity position, including cash and cash equivalents of $0.7 billion at June 30, 2025, are adequate to fund operations and meet its cash obligations for the foreseeable future.

[0000833444-25-000063:mdna:98]
–The Company manages its short-term debt position in the U.S. and euro commercial paper and bank loan markets. Commercial paper outstanding totaled $650 million as of June 30, 2025 and $350 million as of September 30, 2024.

[0000833444-25-000063:mdna:99]
[same as prior period, unchanged from 0000833444-25-000032:mdna:105]

[0000833444-25-000063:mdna:100]
–The Company also has the ability to draw on its $2.5 billion revolving credit facility which is scheduled to expire in December 2028 or its $0.5 billion revolving credit facility which is scheduled to expire in December 2025. There were no draws on the revolving credit facilities as of June 30, 2025 and September 30, 2024.

[0000833444-25-000063:mdna:101]
•The Company's ability to access the global capital markets and the related cost of financing is dependent upon, among other factors, the Company's credit ratings. As of June 30, 2025, the Company's credit ratings and outlook were as follows:

[0000833444-25-000063:mdna:102]
| Rating Agency |  | Short-Term Rating |  | Long-Term Rating |  | Outlook |
| S&P |  | A-2 |  | BBB+ |  | Stable |
| Moody's |  | P-2 |  | Baa1 |  | Stable |

[0000833444-25-000063:mdna:103]
[same as prior period, unchanged from 0000833444-25-000032:mdna:109]

[0000833444-25-000063:mdna:104]
•Financial covenants in the Company's revolving credit facilities require a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting

[0000833444-25-000063:mdna:105]
Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of June 30, 2025, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures governing its notes, and expects to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-25-000063:mdna:106]
•The Company earns a significant amount of its income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances. However, in the first quarter of fiscal 2024, the Company recorded income tax expense related to a change in the Company's assertion over the outside basis differences of the Company’s investment in certain consolidated subsidiaries as a result of the planned divestiture of its R&LC HVAC business. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. The Company's intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at its Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings.

[0000833444-25-000063:mdna:107]
[same as prior period, unchanged from 0000833444-25-000032:mdna:113]

[0000833444-25-000063:mdna:108]
[same as prior period, unchanged from 0000833444-25-000032:mdna:114]

[0000833444-25-000063:mdna:109]
[same as prior period, unchanged from 0000833444-25-000032:mdna:115]

[0000833444-25-000063:mdna:110]
[same as prior period, unchanged from 0000833444-25-000032:mdna:116]

[0000833444-25-000063:mdna:111]
•€500 million aggregate principal amount of 0.375% Senior Notes due 2027

[0000833444-25-000063:mdna:112]
•€600 million aggregate principal amount of 3.000% Senior Notes due 2028

[0000833444-25-000063:mdna:113]
•$700 million aggregate principal amount of 5.500% Senior Notes due 2029

[0000833444-25-000063:mdna:114]
•$625 million aggregate principal amount of 1.750% Senior Notes due 2030

[0000833444-25-000063:mdna:115]
•$500 million aggregate principal amount of 2.000% Sustainability-Linked Senior Notes due 2031

[0000833444-25-000063:mdna:116]
•€500 million aggregate principal amount of 1.000% Senior Notes due 2032

[0000833444-25-000063:mdna:117]
•$650 million aggregate principal amount of 4.900% Senior Notes due 2032

[0000833444-25-000063:mdna:118]
•€500 million aggregate principal amount of 3.125% Senior Notes due 2033

[0000833444-25-000063:mdna:119]
•€800 million aggregate principal amount of 4.250% Senior Notes due 2035

[0000833444-25-000063:mdna:120]
TFSCA is a corporate partnership limited by shares (société en commandite par actions) incorporated and organized under the laws of the Grand Duchy of Luxembourg (“Luxembourg”) and is a wholly-owned consolidated subsidiary of the Company that is 99.924% owned directly by the Parent Company and 0.076% owned by TFSCA’s sole general partner and manager, Tyco Fire & Security S.à r.l., which is itself wholly-owned by the Company. The Parent Company is incorporated and organized under the laws of Ireland. TFSCA is incorporated and organized under the laws of Luxembourg. The bankruptcy, insolvency, administrative, debtor relief and other laws of Luxembourg or Ireland, as applicable, may be materially different from, or in conflict with, those of the United States, including in the areas of rights of creditors, priority of governmental and other creditors, ability to obtain post-petition interest and duration of the proceeding. The application of these laws, or any conflict

[0000833444-25-000063:mdna:121]
among them, could adversely affect noteholders’ ability to enforce their rights under the Notes in those jurisdictions or limit any amounts that they may receive.

[0000833444-25-000063:mdna:122]
[same as prior period, unchanged from 0000833444-25-000032:mdna:127]

[0000833444-25-000063:mdna:123]
|  |  | Nine Months Ended June 30, 2025 |  | Year Ended September 30, 2024 |
| Net loss attributable to the Obligor Group |  | $ | (579) |  |  | $ | (609) |  |
| Net income (loss) attributable to intercompany transactions |  | (45) |  |  | 511 |  |

[0000833444-25-000063:mdna:124]
[same as prior period, unchanged from 0000833444-25-000032:mdna:129]

[0000833444-25-000063:mdna:125]
[same as prior period, unchanged from 0000833444-25-000032:mdna:131]

[0000833444-25-000063:mdna:126]
|  |  | Obligor Group |  | Intercompany Balances |
|  |  | June 30, 2025 |  | September 30, 2024 |  | June 30, 2025 |  | September 30, 2024 |
| Current assets |  | $ | 28 |  |  | $ | 1,339 |  |  | $ | 841 |  |  | $ | 823 |  |
| Noncurrent assets |  | 243 |  |  | 243 |  |  | 9,672 |  |  | 7,522 |  |
| Current liabilities |  | 9,609 |  |  | 6,726 |  |  | 4,729 |  |  | 2,789 |  |
| Noncurrent liabilities |  | 8,300 |  |  | 7,836 |  |  | 7,078 |  |  | 9,028 |  |

[0000833444-25-000063:mdna:127]
[same as prior period, unchanged from 0000833444-25-000032:mdna:133]

[0000833444-25-000063:mdna:128]
[same as prior period, unchanged from 0000833444-25-000032:mdna:134]

[0000833444-25-000063:mdna:129]
[same as prior period, unchanged from 0000833444-25-000032:mdna:135]

[0000833444-25-000063:mdna:130]
[same as prior period, unchanged from 0000833444-25-000032:mdna:136]

[0000833444-25-000063:mdna:131]
[same as prior period, unchanged from 0000833444-25-000032:mdna:137]
