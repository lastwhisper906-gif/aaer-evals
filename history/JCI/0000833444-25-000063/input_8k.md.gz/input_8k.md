# JCI 8-K — 0000833444-25-000055 filed 2025-07-29

## item codes, every 8-K on or before 2025-08-06

- 2025-08-01 0000833444-25-000058 — 7.01, 8.01, 9.01
- 2025-07-29 0000833444-25-000055 — 2.02, 9.01
- 2025-05-12 0000833444-25-000035 — 7.01, 9.01
- 2025-05-07 0000833444-25-000029 — 2.02, 9.01
- 2025-05-05 0000833444-25-000025 — 7.01, 9.01
- 2025-04-02 0000833444-25-000021 — 5.02, 7.01
- 2025-03-14 0000833444-25-000019 — 5.02, 5.07
- 2025-02-05 0001104659-25-009733 — 5.02, 7.01, 9.01
- 2025-02-05 0000833444-25-000009 — 2.02, 7.01, 9.01
- 2025-01-10 0000833444-25-000002 — 5.02
- 2024-12-12 0000833444-24-000066 — 5.02
- 2024-12-11 0001193125-24-275613 — 8.01, 9.01
- 2024-12-10 0001193125-24-274338 — 8.01, 9.01
- 2024-11-06 0000833444-24-000060 — 2.02, 9.01
- 2024-08-05 0000833444-24-000055 — 5.02, 7.01, 9.01
- 2024-07-31 0000833444-24-000049 — 2.02, 9.01
- 2024-07-26 0001193125-24-186281 — 1.01, 9.01
- 2024-07-23 0000833444-24-000044 — 2.02, 7.01, 9.01
- 2024-06-04 0001193125-24-154244 — 8.01, 9.01
- 2024-05-20 0000833444-24-000032 — 8.01, 9.01
- 2024-05-01 0000833444-24-000026 — 2.02, 9.01
- 2024-04-19 0001193125-24-102867 — 8.01, 9.01
- 2024-04-12 0000833444-24-000023 — 1.01, 8.01, 9.01
- 2024-03-18 0000833444-24-000020 — 5.07
- 2024-01-30 0000833444-24-000007 — 2.02, 9.01
- 2024-01-16 0000833444-24-000004 — 5.02, 9.01
- 2023-12-12 0000833444-23-000044 — 2.02, 9.01
- 2023-12-08 0000833444-23-000042 — 5.02
- 2023-11-13 0000833444-23-000038 — 8.01
- 2023-09-27 0000833444-23-000036 — 8.01
- 2023-09-08 0000833444-23-000033 — 5.02
- 2023-08-21 0001193125-23-217018 — 8.01, 9.01
- 2023-08-07 0001193125-23-205014 — 8.01, 9.01
- 2023-08-02 0000833444-23-000028 — 2.02, 9.01
- 2023-05-23 0001193125-23-151889 — 8.01, 9.01
- 2023-05-05 0000833444-23-000011 — 2.02, 9.01
- 2023-03-14 0000833444-23-000007 — 5.07
- 2023-02-01 0000833444-23-000003 — 2.02, 9.01
- 2022-12-22 0000833444-22-000047 — 5.02
- 2022-12-09 0000833444-22-000045 — 5.02
- 2022-11-03 0000833444-22-000038 — 2.02, 9.01
- 2022-09-14 0001193125-22-244741 — 8.01, 9.01
- 2022-09-07 0001193125-22-240030 — 8.01, 9.01
- 2022-08-04 0000833444-22-000034 — 2.02, 9.01
- 2022-07-06 0000833444-22-000029 — 5.02, 9.01
- 2022-06-30 0000833444-22-000027 — 5.02
- 2022-05-04 0000833444-22-000014 — 2.02, 9.01
- 2022-03-11 0001193125-22-073382 — 5.07
- 2022-02-15 0000833444-22-000010 — 5.02
- 2022-02-02 0000833444-22-000003 — 2.02, 9.01
- 2021-12-10 0000833444-21-000050 — 5.02
- 2021-11-05 0000833444-21-000043 — 2.02, 9.01
- 2021-09-16 0001193125-21-275152 — 1.01, 8.01, 9.01
- 2021-07-30 0000833444-21-000038 — 2.02, 9.01
- 2021-05-03 0000833444-21-000023 — 8.01
- 2021-04-30 0000833444-21-000017 — 2.02, 9.01
- 2021-03-11 0000833444-21-000013 — 5.02, 5.07, 9.01
- 2021-02-17 0001193125-21-045768 — 7.01, 9.01
- 2021-01-29 0000833444-21-000009 — 2.02, 9.01
- 2021-01-07 0000833444-21-000004 — 7.01
- 2020-11-03 0000833444-20-000043 — 2.02, 9.01
- 2020-09-15 0001193125-20-246240 — 1.01, 8.01, 9.01
- 2020-09-11 0001193125-20-244119 — 1.01, 8.01, 9.01
- 2020-08-18 0000833444-20-000038 — 5.02, 9.01
- 2020-07-31 0000833444-20-000034 — 2.02, 9.01
- 2020-06-12 0000833444-20-000020 — 8.01
- 2020-05-01 0000833444-20-000013 — 2.02, 9.01
- 2020-03-12 0000833444-20-000010 — 5.02
- 2020-03-06 0000833444-20-000008 — 5.07
- 2020-01-31 0000833444-20-000003 — 2.02, 9.01
- 2019-12-06 0001193125-19-308301 — 1.01, 1.02, 2.03, 9.01
- 2019-11-07 0000833444-19-000048 — 5.02, 9.01
- 2019-11-07 0000833444-19-000046 — 2.02, 9.01
- 2019-08-21 0000833444-19-000043 — 8.01
- 2019-07-31 0000833444-19-000038 — 2.02, 9.01
- 2019-07-23 0000833444-19-000035 — 5.02, 8.01, 9.01
- 2019-07-02 0000833444-19-000033 — 1.02, 8.01
- 2019-06-05 0001193125-19-165565 — 8.01
- 2019-05-30 0001193125-19-160205 — 8.01, 9.01
- 2019-05-16 0001193125-19-148262 — 8.01, 9.01
- 2019-05-07 0001193125-19-139826 — 5.04, 9.01
- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2025-08-06

- 2023-11-29 0000833444-23-000040 — NT 10-K, for the period ended 2023-09-30
- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-25-000055:8k_2_02:1]
EX-99.1
2
q3ex991xq3fy25earningsrele.htm
EX-99.1

[0000833444-25-000055:8k_2_02:2]
Document

[0000833444-25-000055:8k_2_02:3]
Exhibit 99.1

[0000833444-25-000055:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-25-000055:8k_2_02:5]
Johnson Controls Reports Strong Q3 Results; Raises FY25 Guidance

[0000833444-25-000055:8k_2_02:6]
______________________________________________________________________________________

[0000833444-25-000055:8k_2_02:7]
▪Q3 sales increased 3% and organic sales increased 6%*

[0000833444-25-000055:8k_2_02:8]
▪Q3 GAAP EPS of $0.94; Q3 Adjusted EPS* of $1.05

[0000833444-25-000055:8k_2_02:9]
▪Q3 orders increased 2% organically year-over-year

[0000833444-25-000055:8k_2_02:10]
▪Systems and Services backlog of $14.6 billion increased 11% organically year-over-year

[0000833444-25-000055:8k_2_02:11]
▪Initiates fiscal Q4 and raises full year fiscal 2025 guidance*

[0000833444-25-000055:8k_2_02:12]
*  This news release contains non-GAAP financial measures. Definitions and reconciliations of the non-GAAP financial measures can be found in the attached footnotes. Non-GAAP measures should be considered in addition to, and not as replacements for, the most comparable GAAP measures.

[0000833444-25-000055:8k_2_02:13]
_____________________________________________________________________________________

[0000833444-25-000055:8k_2_02:14]
CORK, Ireland — July 29, 2025 — Johnson Controls International plc (NYSE: JCI), a global leader for smart, safe, healthy and sustainable buildings, today reported fiscal third quarter 2025 GAAP earnings per share (“EPS”) of $0.94. Adjusted EPS was $1.05.

[0000833444-25-000055:8k_2_02:15]
Sales in the quarter of $6.1 billion increased 3% over the prior year on an as reported basis and 6% organically. GAAP income from continuing operations was $618 million. Adjusted income from continuing operations was $693 million.

[0000833444-25-000055:8k_2_02:16]
“As we celebrate 140 years of innovation and customer commitment, our strong third quarter results and record backlog reflect the momentum we’ve built and the opportunities ahead” said Joakim Weidemanis, CEO. “By prioritizing our customers, empowering our 40,000 frontline colleagues, and investing in R&D, we are strengthening our capabilities to win – both now and in the future. Looking ahead, we believe implementing the right business system will allow us to accelerate performance, drive consistency, and deliver sustained long-term value for our shareholders.”

[0000833444-25-000055:8k_2_02:17]
FISCAL Q3 SEGMENT RESULTS

[0000833444-25-000055:8k_2_02:18]
The financial highlights presented in the tables below exclude discontinued operations and are in accordance with GAAP, unless otherwise indicated. All comparisons are to the third quarter of fiscal 2024. Orders and backlog metrics included in the release relate to the Company's Systems and Services based businesses.

[0000833444-25-000055:8k_2_02:19]
A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-25-000055:8k_2_02:20]
1

[0000833444-25-000055:8k_2_02:21]
Americas

[0000833444-25-000055:8k_2_02:22]
|  |  | Fiscal Q3 |  |  |  |  |  |
| (in millions) |  | 2025 |  | 2024 |  | Change |  |  |  |  |  |
| Sales |  | $ | 4,042 |  |  | $ | 4,035 |  |  | — | % |  |  |  |  |  |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 742 |  |  | 804 |  |  | (8 | %) |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 746 |  |  | 743 |  |  | — | % |  |  |  |  |  |
| Segment EBITA Margin % |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 18.4 | % |  | 19.9 | % |  | (150 | bp) |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 18.5 | % |  | 18.4 | % |  | 10 | bp |  |  |  |  |  |

[0000833444-25-000055:8k_2_02:23]
Sales in the quarter of $4.0 billion remained flat over the prior year. Organic sales increased 7% over the prior year, led by continued strength across Applied HVAC and Controls.

[0000833444-25-000055:8k_2_02:24]
Excluding M&A and adjusted for foreign currency, orders increased 5% year-over-year and backlog of $10.3 billion increased 10% year-over-year.

[0000833444-25-000055:8k_2_02:25]
Segment EBITA margin of 18.4% declined 150 basis points versus the prior year due to the impact of divestitures and prior year earn-out adjustments. Adjusted segment EBITA in Q3 2025 excludes transformation costs. Adjusted segment EBITA in Q3 2024 excludes earn-out adjustments.

[0000833444-25-000055:8k_2_02:26]
EMEA (Europe, Middle East, Africa)

[0000833444-25-000055:8k_2_02:27]
|  |  | Fiscal Q3 |  |  |  |  |  |
| (in millions) |  | 2025 |  | 2024 |  | Change |  |  |  |  |  |
| Sales |  | $ | 1,273 |  |  | $ | 1,177 |  |  | 8 | % |  |  |  |  |  |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 177 |  |  | 154 |  |  | 15 | % |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 179 |  |  | 154 |  |  | 16 | % |  |  |  |  |  |
| Segment EBITA Margin % |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 13.9 | % |  | 13.1 | % |  | 80 | bp |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 14.1 | % |  | 13.1 | % |  | 100 | bp |  |  |  |  |  |

[0000833444-25-000055:8k_2_02:28]
Sales in the quarter of $1.3 billion increased 8% over the prior year. Organic sales grew 4% versus the prior year quarter led by 8% growth in Service, including solid growth in Applied HVAC and Fire and Security sales.

[0000833444-25-000055:8k_2_02:29]
Excluding M&A and adjusted for foreign currency, orders increased 2% year-over-year and backlog of $2.6 billion increased 9% year-over-year.

[0000833444-25-000055:8k_2_02:30]
Segment EBITA margin of 13.9% expanded 80 basis points versus the prior year driven by productivity improvements and positive mix from growth in Service. Adjusted segment EBITA in Q3 2025 excludes transformation costs.

[0000833444-25-000055:8k_2_02:31]
2

[0000833444-25-000055:8k_2_02:32]
APAC (Asia Pacific)

[0000833444-25-000055:8k_2_02:33]
|  |  | Fiscal Q3 |  |  |  |  |  |
| (in millions) |  | 2025 |  | 2024 |  | Change |  |  |  |  |  |
| Sales |  | $ | 737 |  |  | $ | 686 |  |  | 7 | % |  |  |  |  |  |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 143 |  |  | 128 |  |  | 12 | % |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 143 |  |  | 128 |  |  | 12 | % |  |  |  |  |  |
| Segment EBITA Margin % |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | 19.4 | % |  | 18.7 | % |  | 70 | bp |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 19.4 | % |  | 18.7 | % |  | 70 | bp |  |  |  |  |  |

[0000833444-25-000055:8k_2_02:34]
Sales in the quarter of $737 million increased 7% versus the prior year. Organic sales increased 6% versus the prior year led by strong double-digit growth from the Service business.

[0000833444-25-000055:8k_2_02:35]
Excluding M&A and adjusted for foreign currency, orders decreased 8% and backlog of $1.7 billion increased 14% year-over-year.

[0000833444-25-000055:8k_2_02:36]
Segment EBITA margin of 19.4% increased 70 basis points versus the prior year driven by productivity improvements.

[0000833444-25-000055:8k_2_02:37]
Corporate

[0000833444-25-000055:8k_2_02:38]
|  |  | Fiscal Q3 |  |  |  |  |  |
| (in millions) |  | 2025 |  | 2024 |  | Change |  |  |  |  |  |
| Corporate Expense |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 141 |  |  | $ | 128 |  |  | 10 | % |  |  |  |  |  |
| Adjusted (non-GAAP) |  | 93 |  |  | 119 |  |  | (22 | %) |  |  |  |  |  |

[0000833444-25-000055:8k_2_02:39]
Adjusted Corporate expense in Q3 2025 excludes certain transaction/separation costs and transformation costs. Adjusted Corporate expense in Q3 2024 excludes certain transaction/separation costs.

[0000833444-25-000055:8k_2_02:40]
OTHER Q3 ITEMS

[0000833444-25-000055:8k_2_02:41]
▪Cash provided by operating activities was $787 million. Free cash flow was $693 million and adjusted free cash flow was $725 million.

[0000833444-25-000055:8k_2_02:42]
▪The Company paid dividends of $243 million.

[0000833444-25-000055:8k_2_02:43]
▪The Company repurchased 3.8 million shares of common stock for $310 million.

[0000833444-25-000055:8k_2_02:44]
3

[0000833444-25-000055:8k_2_02:45]
GUIDANCE

[0000833444-25-000055:8k_2_02:46]
The following forward-looking statements regarding organic sales growth, adjusted segment EBITA margin, adjusted segment EBITA margin improvement, adjusted EPS and adjusted free cash flow conversion are non-GAAP financial measures and are presented on a continuing operations basis excluding the Residential and Light Commercial HVAC business, which was classified as discontinued operations beginning in the fiscal fourth quarter of 2024. These non-GAAP financial measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts excluded is a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period and the high variability of certain amounts, such as mark-to-market adjustments. Organic revenue growth excludes the effect of acquisitions, divestitures and foreign currency. The Company is unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to its most directly comparable forward-looking GAAP financial measures because such information is not available, and management cannot reliably predict the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s fiscal 2025 fourth quarter and full year GAAP financial results from continuing operations.

[0000833444-25-000055:8k_2_02:47]
The Company initiated fiscal 2025 fourth quarter guidance:

[0000833444-25-000055:8k_2_02:48]
▪Organic sales growth of low single digits

[0000833444-25-000055:8k_2_02:49]
▪Adjusted segment EBITA margin of ~18.6%

[0000833444-25-000055:8k_2_02:50]
▪Adjusted EPS before special items of $1.14 to $1.17

[0000833444-25-000055:8k_2_02:51]
The Company raised fiscal 2025 full year guidance:

[0000833444-25-000055:8k_2_02:52]
▪Organic sales growth of mid-single digits (unchanged)

[0000833444-25-000055:8k_2_02:53]
▪Adjusted segment EBITA margin improvement of ~90 basis points year-over-year (unchanged)

[0000833444-25-000055:8k_2_02:54]
▪Adjusted EPS before special items of $3.65 to $3.68 (previously ~$3.60)

[0000833444-25-000055:8k_2_02:55]
▪Adjusted free cash flow conversion of >100% (previously ~100%)

[0000833444-25-000055:8k_2_02:56]
CONFERENCE CALL & WEBCAST INFO

[0000833444-25-000055:8k_2_02:57]
Johnson Controls will host a conference call to discuss this quarter’s results at 8:30 a.m. ET today, which can be accessed by dialing 855-979-6654 (in the United States) or +1-646-233-4753 (outside the United States) along with passcode 330296, or via webcast. A slide presentation will accompany the prepared remarks and has been posted on the investor relations section of the Johnson Controls website at https://investors.johnsoncontrols.com/news-and-events/events-and-presentations. A replay will be made available approximately two hours following the conclusion of the conference call.

[0000833444-25-000055:8k_2_02:58]
4

[0000833444-25-000055:8k_2_02:59]
ABOUT JOHNSON CONTROLS

[0000833444-25-000055:8k_2_02:60]
At Johnson Controls (NYSE:JCI), we transform the environments where people live, work, learn and play. As the global leader in smart, healthy and sustainable buildings, our mission is to reimagine the performance of buildings to serve people, places and the planet.

[0000833444-25-000055:8k_2_02:61]
Building on a proud history of nearly 140 years of innovation, we deliver the blueprint of the future for industries such as healthcare, schools, data centers, airports, stadiums, manufacturing and beyond through OpenBlue, our comprehensive digital offering.

[0000833444-25-000055:8k_2_02:62]
Today, Johnson Controls offers the world`s largest portfolio of building technology and software as well as service solutions from some of the most trusted names in the industry.

[0000833444-25-000055:8k_2_02:63]
Visit www.johnsoncontrols.com for more information and follow @Johnson Controls on social platforms.

[0000833444-25-000055:8k_2_02:64]
JOHNSON CONTROLS CONTACTS:

[0000833444-25-000055:8k_2_02:65]
| INVESTOR CONTACTS: | MEDIA CONTACT: |  |  |  |
| Jim Lucas | Danielle Canzanella |  |  |  |
| Direct: +1 414.340.1752 | Direct: +1 203.499.8297 |  |  |  |
| Email: jim.lucas@jci.com | Email: danielle.canzanella@jci.com |  |  |  |
| Michael Gates |  |  |  |  |
| Direct: +1 414.524.5785 |  |  |  |  |
| Email: michael.j.gates@jci.com |  |  |  |  |

[0000833444-25-000055:8k_2_02:66]
###

[0000833444-25-000055:8k_2_02:67]
JOHNSON CONTROLS INTERNATIONAL PLC CAUTIONARY STATEMENT REGARDING FORWARD-LOOKING STATEMENTS

[0000833444-25-000055:8k_2_02:68]
5

[0000833444-25-000055:8k_2_02:69]
manage general economic, business and capital market conditions, including the impacts of trade restrictions, recessions, economic downturns and global price inflation; Johnson Controls’ ability to develop or acquire new products and technologies that achieve market acceptance and meet applicable quality and regulatory requirements; the ability of Johnson Controls to execute on its operating model and drive organizational improvement; Johnson Controls’ ability to successfully execute and complete portfolio simplification actions, as well as the possibility that the expected benefits of such actions will not be realized or will not be realized within the expected time frame; the ability to innovate and adapt to emerging technologies, ideas and trends in the marketplace, including the incorporation of technologies such as artificial intelligence; fluctuations in the cost and availability of public and private financing for Johnson Controls’ customers; the ability to manage disruptions caused by international conflicts, including Russia and Ukraine and the ongoing conflicts in the Middle East; managing the risks and impacts of potential and actual security breaches, cyberattacks, privacy breaches or data breaches, maintaining and improving the capacity, reliability and security of Johnson Controls’ enterprise information technology infrastructure; the ability to manage the lifecycle cybersecurity risk in the development, deployment and operation of Johnson Controls’ digital platforms and services; fluctuations in currency exchange rates; the ability to hire and retain senior management and other key personnel; changes or uncertainty in laws, regulations, rates, policies, or interpretations that impact Johnson Controls’ business operations or tax status; the ability to adapt to global climate change, climate change regulation and successfully meet Johnson Controls’ public sustainability commitments; the outcome of litigation and governmental proceedings; the risk of infringement or expiration of intellectual property rights; Johnson Controls’ ability to manage disruptions caused by catastrophic or geopolitical events, such as natural disasters, armed conflict, political change, climate change, pandemics and outbreaks of contagious diseases and other adverse public health developments; any delay or inability of Johnson Controls to realize the expected benefits and synergies of recent portfolio transactions; the tax treatment of recent portfolio transactions; significant transaction costs and/or unknown liabilities associated with such transactions; labor shortages, work stoppages, union negotiations, labor disputes and other matters associated with the labor force; and the cancellation of or changes to commercial arrangements. A detailed discussion of risks related to Johnson Controls' business is included in the section entitled “Risk Factors” in Johnson Controls Annual Report on Form 10-K for the year ended September 30, 2024 filed with the SEC on November 19, 2024, which is available at www.sec.gov and www.johnsoncontrols.com under the “Investors” tab. The description of certain of these risks is supplemented in Item 1A of Part II of Johnson Controls subsequently filed Quarterly Reports on Form 10-Q. Shareholders, potential investors and others should consider these factors in evaluating the forward-looking statements and should not place undue reliance on such statements. The forward-looking statements included in this communication are made only as of the date of this document, unless otherwise specified, and, except as required by law, Johnson Controls assumes no obligation, and disclaims any obligation, to update such statements to reflect events or circumstances occurring after the date of this communication.

[0000833444-25-000055:8k_2_02:70]
###

[0000833444-25-000055:8k_2_02:71]
6

[0000833444-25-000055:8k_2_02:72]
FINANCIAL STATEMENTS

[0000833444-25-000055:8k_2_02:73]
Johnson Controls International plc

[0000833444-25-000055:8k_2_02:74]
Consolidated Statements of Income

[0000833444-25-000055:8k_2_02:75]
(in millions, except per share data; unaudited)

[0000833444-25-000055:8k_2_02:76]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales |  |  |  |  |  |  |  |
| Products and systems | $ | 4,122 |  |  | $ | 4,089 |  |  | $ | 11,672 |  |  | $ | 11,576 |  |
| Services | 1,930 |  |  | 1,809 |  |  | 5,482 |  |  | 5,128 |  |
|  | 6,052 |  |  | 5,898 |  |  | 17,154 |  |  | 16,704 |  |
| Cost of sales |  |  |  |  |  |  |  |
| Products and systems | 2,656 |  |  | 2,698 |  |  | 7,635 |  |  | 7,805 |  |
| Services | 1,150 |  |  | 1,091 |  |  | 3,278 |  |  | 3,090 |  |
|  | 3,806 |  |  | 3,789 |  |  | 10,913 |  |  | 10,895 |  |
| Gross profit | 2,246 |  |  | 2,109 |  |  | 6,241 |  |  | 5,809 |  |
| Selling, general and administrative expenses | 1,417 |  |  | 895 |  |  | 4,243 |  |  | 4,293 |  |
| Restructuring and impairment costs | 51 |  |  | 103 |  |  | 146 |  |  | 377 |  |
| Net financing charges | 77 |  |  | 70 |  |  | 243 |  |  | 246 |  |
| Equity income (loss) | 4 |  |  | (16) |  |  | 5 |  |  | (19) |  |
| Income from continuing operations before income taxes | 705 |  |  | 1,025 |  |  | 1,614 |  |  | 874 |  |
| Income tax provision | 87 |  |  | 174 |  |  | 160 |  |  | 1 |  |
| Income from continuing operations | 618 |  |  | 851 |  |  | 1,454 |  |  | 873 |  |
| Income from discontinued operations, net of tax | 160 |  |  | 201 |  |  | 301 |  |  | 349 |  |
| Net income | 778 |  |  | 1,052 |  |  | 1,755 |  |  | 1,222 |  |
| Income (loss) attributable to noncontrolling interests |  |  |  |  |  |  |  |
| Continuing operations | — |  |  | (1) |  |  | — |  |  | 2 |  |
| Discontinued operations | 77 |  |  | 78 |  |  | 157 |  |  | 148 |  |
| Net income attributable to Johnson Controls | $ | 701 |  |  | $ | 975 |  |  | $ | 1,598 |  |  | $ | 1,072 |  |
| Income attributable to Johnson Controls |  |  |  |  |  |  |  |
| Continuing operations | $ | 618 |  |  | $ | 852 |  |  | $ | 1,454 |  |  | $ | 871 |  |
| Discontinued operations | 83 |  |  | 123 |  |  | 144 |  |  | 201 |  |
| Total | $ | 701 |  |  | $ | 975 |  |  | $ | 1,598 |  |  | $ | 1,072 |  |
| Basic earnings per share attributable to Johnson Controls |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.94 |  |  | $ | 1.27 |  |  | $ | 2.21 |  |  | $ | 1.28 |  |
| Discontinued operations | 0.13 |  |  | 0.18 |  |  | 0.22 |  |  | 0.30 |  |
| Total | $ | 1.07 |  |  | $ | 1.45 |  |  | $ | 2.43 |  |  | $ | 1.58 |  |
| Diluted earnings per share attributable to Johnson Controls |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.94 |  |  | $ | 1.27 |  |  | $ | 2.20 |  |  | $ | 1.28 |  |
| Discontinued operations | 0.13 |  |  | 0.18 |  |  | 0.22 |  | 0.30 |  |
| Total | $ | 1.07 |  |  | $ | 1.45 |  |  | $ | 2.42 |  |  | $ | 1.58 |  |

[0000833444-25-000055:8k_2_02:77]
7

[0000833444-25-000055:8k_2_02:78]
Johnson Controls International plc

[0000833444-25-000055:8k_2_02:79]
Condensed Consolidated Statements of Financial Position

[0000833444-25-000055:8k_2_02:80]
(in millions; unaudited)

[0000833444-25-000055:8k_2_02:81]
|  | June 30, 2025 |  | September 30, 2024 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 731 |  |  | $ | 606 |  |
| Accounts receivable - net | 6,151 |  |  | 6,051 |  |
| Inventories | 1,829 |  |  | 1,774 |  |
| Current assets held for sale | 1,993 |  |  | 1,595 |  |
| Other current assets | 1,145 |  |  | 1,153 |  |
| Current assets | 11,849 |  |  | 11,179 |  |
| Property, plant and equipment - net | 2,455 |  |  | 2,403 |  |
| Goodwill | 16,709 |  |  | 16,725 |  |
| Other intangible assets - net | 3,856 |  |  | 4,130 |  |
| Noncurrent assets held for sale | 3,174 |  |  | 3,210 |  |
| Other noncurrent assets | 5,350 |  |  | 5,048 |  |
| Total assets | $ | 43,393 |  |  | $ | 42,695 |  |
| Liabilities and Equity |  |  |  |
| Short-term debt | $ | 1,277 |  |  | $ | 953 |  |
| Current portion of long-term debt | 570 |  |  | 536 |  |
| Accounts payable | 3,421 |  |  | 3,389 |  |
| Accrued compensation and benefits | 1,070 |  |  | 1,048 |  |
| Deferred revenue | 2,428 |  |  | 2,160 |  |
| Current liabilities held for sale | 1,662 |  |  | 1,431 |  |
| Other current liabilities | 1,922 |  |  | 2,438 |  |
| Current liabilities | 12,350 |  |  | 11,955 |  |
| Long-term debt | 8,446 |  |  | 8,004 |  |
| Pension and postretirement benefit obligations | 179 |  |  | 217 |  |
| Noncurrent liabilities held for sale | 398 |  |  | 405 |  |
| Other noncurrent liabilities | 4,975 |  |  | 4,753 |  |
| Long-term liabilities | 13,998 |  |  | 13,379 |  |
| Shareholders’ equity attributable to Johnson Controls | 15,830 |  |  | 16,098 |  |
| Noncontrolling interests | 1,215 |  |  | 1,263 |  |
| Total equity | 17,045 |  |  | 17,361 |  |
| Total liabilities and equity | $ | 43,393 |  |  | $ | 42,695 |  |

[0000833444-25-000055:8k_2_02:82]
8

[0000833444-25-000055:8k_2_02:83]
Consolidated Statements of Cash Flows

[0000833444-25-000055:8k_2_02:84]
(in millions; unaudited)

[0000833444-25-000055:8k_2_02:85]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Operating Activities of Continuing Operations |  |  |  |  |  |  |  |
| Income from continuing operations attributable to Johnson Controls | $ | 618 |  |  | $ | 852 |  |  | $ | 1,454 |  |  | $ | 871 |  |
| Income (loss) from continuing operations attributable to noncontrolling interests | — |  |  | (1) |  |  | — |  |  | 2 |  |
| Income from continuing operations | 618 |  |  | 851 |  |  | 1,454 |  |  | 873 |  |
| Adjustments to reconcile net income to cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization | 190 |  |  | 201 |  |  | 585 |  |  | 624 |  |
| Pension and postretirement income and contributions | (15) |  |  | (18) |  |  | (52) |  |  | (49) |  |
| Deferred income taxes | (39) |  |  | 16 |  |  | (146) |  |  | (403) |  |
| Noncash restructuring and impairment charges | 23 |  |  | 80 |  |  | 56 |  |  | 333 |  |
| Equity-based compensation | 48 |  |  | 27 |  |  | 107 |  |  | 81 |  |
| Other - net | (24) |  |  | (69) |  |  | 8 |  |  | (106) |  |
| Changes in assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable | (172) |  |  | 18 |  |  | (79) |  |  | (491) |  |
| Inventories | (52) |  |  | (50) |  |  | (79) |  |  | (185) |  |
| Other assets | (76) |  |  | (370) |  |  | (289) |  |  | (560) |  |
| Restructuring reserves | 5 |  |  | (21) |  |  | 2 |  |  | (81) |  |
| Accounts payable and accrued liabilities | 258 |  |  | (23) |  |  | 31 |  |  | 179 |  |
| Accrued income taxes | 23 |  |  | 11 |  |  | (12) |  |  | 1 |  |
| Cash provided by operating activities from continuing operations | 787 |  |  | 653 |  |  | 1,586 |  |  | 216 |  |
| Investing Activities of Continuing Operations |  |  |  |  |  |  |  |
| Capital expenditures | (94) |  |  | (89) |  |  | (304) |  |  | (299) |  |
| Other - net | 9 |  |  | (1) |  |  | 2 |  |  | 13 |  |
| Cash used by investing activities from continuing operations | (85) |  |  | (90) |  |  | (302) |  |  | (286) |  |
| Financing Activities of Continuing Operations |  |  |  |  |  |  |  |
| Net proceeds (payments) from borrowings with maturities less than three months | (75) |  |  | (840) |  |  | 283 |  |  | 703 |  |
| Proceeds from debt | — |  |  | 859 |  |  | 775 |  |  | 1,281 |  |
| Repayments of debt | — |  |  | (275) |  |  | (502) |  |  | (438) |  |
| Stock repurchases and retirements | (310) |  |  | (402) |  |  | (970) |  |  | (876) |  |
| Payment of cash dividends | (243) |  |  | (249) |  |  | (733) |  |  | (753) |  |
| Proceeds from the exercise of stock options | 4 |  |  | 13 |  |  | 109 |  |  | 33 |  |
| Employee equity-based compensation withholding taxes | (2) |  |  | (2) |  |  | (33) |  |  | (26) |  |
| Other - net | (11) |  |  | (34) |  |  | (40) |  |  | (114) |  |
| Cash used by financing activities from continuing operations | (637) |  |  | (930) |  |  | (1,111) |  |  | (190) |  |
| Discontinued Operations |  |  |  |  |  |  |  |
| Cash provided by operating activities | 208 |  |  | 368 |  |  | 255 |  |  | 356 |  |
| Cash used by investing activities | (25) |  |  | (9) |  |  | (52) |  |  | (24) |  |
| Cash used by financing activities | (109) |  |  | (69) |  |  | (174) |  |  | (132) |  |
| Cash provided by discontinued operations | 74 |  |  | 290 |  |  | 29 |  |  | 200 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (201) |  |  | 10 |  |  | (216) |  |  | 29 |  |
| Change in cash, cash equivalents and restricted cash held for sale | — |  |  | 1 |  |  | 3 |  |  | 2 |  |
| Decrease in cash, cash equivalents and restricted cash | (62) |  |  | (66) |  |  | (11) |  |  | (29) |  |
| Cash, cash equivalents and restricted cash at beginning of period | 818 |  |  | 954 |  |  | 767 |  |  | 917 |  |
| Cash, cash equivalents and restricted cash at end of period | 756 |  |  | 888 |  |  | 756 |  |  | 888 |  |
| Less: Restricted cash | 25 |  |  | 30 |  |  | 25 |  |  | 30 |  |
| Cash and cash equivalents at end of period | $ | 731 |  |  | $ | 858 |  |  | $ | 731 |  |  | $ | 858 |  |

[0000833444-25-000055:8k_2_02:86]
9

[0000833444-25-000055:8k_2_02:87]
FOOTNOTES

[0000833444-25-000055:8k_2_02:88]
1.Sale of Residential and Light Commercial HVAC Business

[0000833444-25-000055:8k_2_02:89]
The Company signed a definitive agreement in July 2024 to sell its Residential and Light Commercial ("R&LC") HVAC business, which includes the North America Ducted businesses and the global Residential joint venture with Hitachi Global Life Solutions, Inc. (“Hitachi”), of which Johnson Controls owns 60% and Hitachi owns 40%. The R&LC HVAC business, which was previously reported in the Global Products segment prior to the Company's resegmentation, meets the criteria to be classified as a discontinued operation and, as a result, its historical financial results are reflected in the consolidated financial statements as a discontinued operation, and assets and liabilities were reclassified as held for sale for all periods presented. Unless otherwise noted, all activities and amounts reported in the following footnotes include only continuing operations of the Company and exclude activities and amounts related to the R&LC HVAC business.

[0000833444-25-000055:8k_2_02:90]
2.Non-GAAP Measures

[0000833444-25-000055:8k_2_02:91]
The Company reports various non-GAAP measures in this earnings release and the related earnings presentation.  Non-GAAP measures should be considered in addition to, and not as replacements for, the most comparable GAAP measures. Refer to footnotes three through eight for further information on the calculations of the non-GAAP measures and reconciliations of the non-GAAP measures to the most comparable GAAP measures.

[0000833444-25-000055:8k_2_02:92]
Organic sales

[0000833444-25-000055:8k_2_02:93]
Organic sales growth excludes the impact of acquisitions, divestitures and foreign currency. Management believes organic sales growth is useful to investors in understanding period-over-period sales results and trends.

[0000833444-25-000055:8k_2_02:94]
Cash flow

[0000833444-25-000055:8k_2_02:95]
Management believes free cash flow and adjusted free cash flow measures are useful to investors in understanding the strength of the Company and its ability to generate cash. These non-GAAP measures can also be used to evaluate the Company’s ability to generate cash flow from operations and the impact that this cash flow has on its liquidity. Management also believes adjusted free cash flows are useful to investors in understanding period-over-period cash flows, cash trends and ongoing cash flows of the Company.

[0000833444-25-000055:8k_2_02:96]
Adjusted free cash flow and adjusted free cash flow conversion are non-GAAP measures which exclude the impacts of the following:

[0000833444-25-000055:8k_2_02:97]
•JC Capital cash flows primarily include activity associated with finance/notes receivables and inventory and/or capital expenditures related to lease arrangements. JC Capital net income is primarily related to interest income on the finance/notes receivable and profit recognized on arrangements with sales-type lease components.

[0000833444-25-000055:8k_2_02:98]
•Effective January 1, 2024, the Company has excluded the impact of discontinuing its accounts receivables factoring programs from adjusted free cash flow and adjusted free cash flow conversion. The Company has also re-baselined the prior year adjusted free cash flow measures to present a more comparative measure without the impact of factoring.

[0000833444-25-000055:8k_2_02:99]
•Cash payments related to the water systems AFFF settlement and cash receipts for AFFF-related insurance recoveries.

[0000833444-25-000055:8k_2_02:100]
Adjusted financial measures

[0000833444-25-000055:8k_2_02:101]
Adjusted financial measures include adjusted segment EBITA, adjusted segment EBITA margin, adjusted net income, adjusted earnings per share, adjusted EBIT, adjusted EBITDA and adjusted corporate expenses. These non-GAAP measures are derived by excluding certain amounts from the corresponding financial measures determined in accordance with GAAP. The determination of the excluded amounts is a matter of management judgment and depends upon the nature and variability of the underlying expense or income amounts and other factors.

[0000833444-25-000055:8k_2_02:102]
10

[0000833444-25-000055:8k_2_02:103]
As detailed in the tables included in footnotes five through eight, the following items were excluded from certain financial measures:

[0000833444-25-000055:8k_2_02:104]
•Net mark-to-market adjustments are the result of adjusting restricted asbestos investments and pension and postretirement plan assets to their current market value. These adjustments may have a favorable or unfavorable impact on results.

[0000833444-25-000055:8k_2_02:105]
•Restructuring and impairment costs, net of NCI represents restructuring costs attributable to Johnson Controls including costs associated with exit plans or other restructuring plans that will have a more significant impact on the underlying cost structure of the organization. Impairment costs primarily relate to write-downs of goodwill, intangible assets and assets held for sale to their fair value.

[0000833444-25-000055:8k_2_02:106]
•Water systems AFFF settlement and insurance recoveries include amounts related to a settlement with a nationwide class of public water systems concerning the use of AFFF manufactured and sold by a subsidiary of the Company, and AFFF-related insurance recoveries.

[0000833444-25-000055:8k_2_02:107]
•Transaction/separation costs include costs associated with significant mergers and acquisitions.

[0000833444-25-000055:8k_2_02:108]
•Transformation costs represent incremental expenses incurred in association with strategic growth initiatives and cost saving opportunities in order to realize the benefits of portfolio simplification and the Company's lifecycle solutions strategy.

[0000833444-25-000055:8k_2_02:109]
•Earn-out adjustments relate to earn-out liabilities associated with certain significant acquisitions and may have a favorable or unfavorable impact on results.

[0000833444-25-000055:8k_2_02:110]
•Cyber incident costs primarily represent expenses, net of insurance recoveries, associated with the response to, and remediation of, a cybersecurity incident which occurred in September 2023.

[0000833444-25-000055:8k_2_02:111]
•Product quality costs are costs related to a product quality issue that is unusual due to the magnitude of the expected cost to remediate in comparison to typical product quality issues experienced by the Company.

[0000833444-25-000055:8k_2_02:112]
•Loss on divestiture relates to the sale of the ADTi business.

[0000833444-25-000055:8k_2_02:113]
•EMEA joint venture loss relates to certain non-recurring losses associated with the equity method accounting of a joint venture company.

[0000833444-25-000055:8k_2_02:114]
•Discrete tax items, net includes the net impact of discrete tax items within the period, including the following types of items: changes in estimates associated with valuation allowances, changes in estimates associated with reserves for uncertain tax positions, withholding taxes recorded upon changes in indefinite re-investment assertions for businesses to be disposed of, impacts from statutory rate changes, and the recording of significant tax credits.

[0000833444-25-000055:8k_2_02:115]
•Related tax impact includes the tax impact of the various excluded items.

[0000833444-25-000055:8k_2_02:116]
Management believes the exclusion of these items is useful to investors due to the unusual nature and/or magnitude of the amounts. When considered together with unadjusted amounts, adjusted financial measures are useful to investors in understanding period-over-period operating results, business trends and ongoing operations of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes.

[0000833444-25-000055:8k_2_02:117]
Debt ratios

[0000833444-25-000055:8k_2_02:118]
Management believes that net debt to adjusted EBITDA, a non-GAAP measure, is useful to understanding the Company's financial condition as the ratio provides an overview of the extent to which the Company relies on external debt financing for its funding and also is a measure of risk to its shareholders.

[0000833444-25-000055:8k_2_02:119]
11

[0000833444-25-000055:8k_2_02:120]
3. Sales

[0000833444-25-000055:8k_2_02:121]
The following tables detail the changes in sales from continuing operations attributable to organic growth, foreign currency, acquisitions, divestitures and other (unaudited):

[0000833444-25-000055:8k_2_02:122]
| Net sales | Three Months Ended June 30 |  | Nine Months Ended June 30 |
| (in millions) | Americas |  | EMEA |  | APAC |  | Total |  | Americas |  | EMEA |  | APAC |  | Total |
| Net sales - 2024 | $ | 4,035 |  |  | $ | 1,177 |  |  | $ | 686 |  |  | $ | 5,898 |  |  | $ | 11,341 |  |  | $ | 3,440 |  |  | $ | 1,923 |  |  | $ | 16,704 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | (243) |  |  | (7) |  |  | — |  |  | (250) |  |  | (714) |  |  | (12) |  |  | — |  |  | (726) |  |
| Foreign currency | (9) |  |  | 52 |  |  | 12 |  |  | 55 |  |  | (40) |  |  | (2) |  |  | (5) |  |  | (47) |  |
| Adjusted base net sales | 3,783 |  |  | 1,222 |  |  | 698 |  |  | 5,703 |  |  | 10,587 |  |  | 3,426 |  |  | 1,918 |  |  | 15,931 |  |
| Acquisitions | — |  |  | 6 |  |  | — |  |  | 6 |  |  | — |  |  | 18 |  |  | — |  |  | 18 |  |
| Organic growth | 259 |  |  | 45 |  |  | 39 |  |  | 343 |  |  | 919 |  |  | 187 |  |  | 99 |  |  | 1,205 |  |
| Net sales - 2025 | $ | 4,042 |  |  | $ | 1,273 |  |  | $ | 737 |  |  | $ | 6,052 |  |  | $ | 11,506 |  |  | $ | 3,631 |  |  | $ | 2,017 |  |  | $ | 17,154 |  |
| Growth %: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net sales | — | % |  | 8 | % |  | 7 | % |  | 3 | % |  | 1 | % |  | 6 | % |  | 5 | % |  | 3 | % |
| Organic growth | 7 | % |  | 4 | % |  | 6 | % |  | 6 | % |  | 9 | % |  | 5 | % |  | 5 | % |  | 8 | % |

[0000833444-25-000055:8k_2_02:123]
| Products and systems revenue | Three Months Ended June 30 |  | Nine Months Ended June 30 |
| (in millions) | Americas |  | EMEA |  | APAC |  | Total |  | Americas |  | EMEA |  | APAC |  | Total |
| Products and systems revenue - 2024 | $ | 2,887 |  |  | $ | 710 |  |  | $ | 492 |  |  | $ | 4,089 |  |  | $ | 8,114 |  |  | $ | 2,086 |  |  | $ | 1,376 |  |  | $ | 11,576 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Divestitures and other | (243) |  |  | (7) |  |  | — |  |  | (250) |  |  | (714) |  |  | (12) |  |  | — |  |  | (726) |  |
| Foreign currency | (8) |  |  | 42 |  |  | 10 |  |  | 44 |  |  | (30) |  |  | 18 |  |  | (3) |  |  | (15) |  |
| Adjusted products and systems revenue | 2,636 |  |  | 745 |  |  | 502 |  |  | 3,883 |  |  | 7,370 |  |  | 2,092 |  |  | 1,373 |  |  | 10,835 |  |
| Acquisitions | — |  |  | 4 |  |  | — |  |  | 4 |  |  | — |  |  | 13 |  |  | — |  |  | 13 |  |
| Organic growth | 211 |  |  | 7 |  |  | 17 |  |  | 235 |  |  | 724 |  |  | 72 |  |  | 28 |  |  | 824 |  |
| Products and systems revenue - 2025 | $ | 2,847 |  |  | $ | 756 |  |  | $ | 519 |  |  | $ | 4,122 |  |  | $ | 8,094 |  |  | $ | 2,177 |  |  | $ | 1,401 |  |  | $ | 11,672 |  |
| Growth %: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products and systems revenue | (1) | % |  | 6 | % |  | 5 | % |  | 1 | % |  | — | % |  | 4 | % |  | 2 | % |  | 1 | % |
| Organic growth | 8 | % |  | 1 | % |  | 3 | % |  | 6 | % |  | 10 | % |  | 3 | % |  | 2 | % |  | 8 | % |

[0000833444-25-000055:8k_2_02:124]
12

[0000833444-25-000055:8k_2_02:125]
| Service revenue | Three Months Ended June 30 |  | Nine Months Ended June 30 |
| (in millions) | Americas |  | EMEA |  | APAC |  | Total |  | Americas |  | EMEA |  | APAC |  | Total |
| Service revenue - 2024 | $ | 1,148 |  |  | $ | 467 |  |  | $ | 194 |  |  | $ | 1,809 |  |  | $ | 3,227 |  |  | $ | 1,354 |  |  | $ | 547 |  |  | $ | 5,128 |  |
| Base year adjustments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency | (1) |  |  | 10 |  |  | 2 |  |  | 11 |  |  | (10) |  |  | (20) |  |  | (2) |  |  | (32) |  |
| Adjusted base service revenue | 1,147 |  |  | 477 |  |  | 196 |  |  | 1,820 |  |  | 3,217 |  |  | 1,334 |  |  | 545 |  |  | 5,096 |  |
| Acquisitions | — |  |  | 2 |  |  | — |  |  | 2 |  |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Organic growth | 48 |  |  | 38 |  |  | 22 |  |  | 108 |  |  | 195 |  |  | 115 |  |  | 71 |  |  | 381 |  |
| Service revenue - 2025 | $ | 1,195 |  |  | $ | 517 |  |  | $ | 218 |  |  | $ | 1,930 |  |  | $ | 3,412 |  |  | $ | 1,454 |  |  | $ | 616 |  |  | $ | 5,482 |  |
| Growth %: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Service revenue | 4 | % |  | 11 | % |  | 12 | % |  | 7 | % |  | 6 | % |  | 7 | % |  | 13 | % |  | 7 | % |
| Organic growth | 4 | % |  | 8 | % |  | 11 | % |  | 6 | % |  | 6 | % |  | 9 | % |  | 13 | % |  | 7 | % |

[0000833444-25-000055:8k_2_02:126]
4.   Cash Flow, Free Cash Flow and Free Cash Flow Conversion

[0000833444-25-000055:8k_2_02:127]
The following table includes operating cash flow conversion, free cash flow and free cash flow conversion (unaudited):

[0000833444-25-000055:8k_2_02:128]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
| (in millions) | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Cash provided by operating activities from continuing operations | $ | 787 |  | $ | 653 |  | $ | 1,586 |  | $ | 216 |
| Income from continuing operations attributable to Johnson Controls | 618 |  | 852 |  | 1,454 |  | 871 |
| Operating cash flow conversion | 127 | % |  | 77 | % |  | 109 | % |  | 25 | % |
| Cash provided by operating activities from continuing operations | 787 |  | 653 |  | 1,586 |  | 216 |
| Capital expenditures | (94) |  | (89) |  | (304) |  | (299) |
| Free cash flow (non-GAAP) | $ | 693 |  | $ | 564 |  | $ | 1,282 |  | $ | (83) |
| Income from continuing operations attributable to Johnson Controls | 618 |  | 852 |  | 1,454 |  | 871 |
| Free cash flow conversion from net income (non-GAAP) | 112 | % |  | 66 | % |  | 88 | % |  | * |

[0000833444-25-000055:8k_2_02:129]
* Measure not meaningful

[0000833444-25-000055:8k_2_02:130]
13

[0000833444-25-000055:8k_2_02:131]
The following table includes adjusted free cash flow and adjusted free cash flow conversion (unaudited):

[0000833444-25-000055:8k_2_02:132]
|  | Three Months Ended June 30, |  |  | Nine Months Ended June 30, |  |
| (in millions) | 2025 |  | 2024 |  |  | 2025 |  | 2024 |  |
| Free cash flow (non-GAAP) | $ | 693 |  | $ | 564 |  |  | $ | 1,282 |  | $ | (83) |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| JC Capital cash used by operating activities | 34 |  | 50 |  |  | 111 |  | 170 |  |
| Water systems AFFF settlement cash payments and insurance recoveries | (3) |  | 243 |  |  | 383 |  | 243 |  |
| Impact from discontinuation of factoring programs | 1 |  | — |  |  | 15 |  | — |  |
| Adjusted free cash flow (non-GAAP) | 725 |  | 857 |  |  | 1,791 |  | 330 |  |
| Prior year impact from factoring programs | — |  | 48 |  |  | — |  | 582 |  |
| Re-baselined adjusted free cash flow (non-GAAP) | $ | 725 |  | $ | 905 |  |  | $ | 1,791 |  | $ | 912 |  |
| Adjusted net income attributable to JCI (non-GAAP) | $ | 693 |  | $ | 639 |  |  | $ | 1,664 |  | $ | 1,425 |  |
| JC Capital net income | (8) |  | (3) |  |  | (4) |  | (8) |  |
| Adjusted net income attributable to JCI, excluding JC Capital (non-GAAP) | $ | 685 |  | $ | 636 |  |  | $ | 1,660 |  | $ | 1,417 |  |
| Adjusted free cash flow conversion (non-GAAP) | 106 | % |  | 142 | % |  |  | 108 | % |  | 64 | % |  |

[0000833444-25-000055:8k_2_02:133]
5. EBITA, EBIT and Corporate Expense

[0000833444-25-000055:8k_2_02:134]
The Company evaluates the performance of its business units primarily on segment EBITA. The following table includes continuing operations (unaudited):

[0000833444-25-000055:8k_2_02:135]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | Actual |  | Adjusted(Non-GAAP) |  | Actual |  | Adjusted(Non-GAAP) |
| (in millions) | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Segment EBITA |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 742 |  |  | $ | 804 |  |  | $ | 746 |  |  | $ | 743 |  |  | $ | 2,038 |  |  | $ | 1,853 |  |  | $ | 2,044 |  |  | $ | 1,811 |  |
| EMEA | 177 |  |  | 154 |  | 179 |  |  | 154 |  |  | 448 |  |  | 397 |  |  | 450 |  |  | 401 |  |
| APAC | 143 |  |  | 128 |  | 143 |  |  | 128 |  |  | 337 |  |  | 320 |  |  | 337 |  |  | 323 |  |
| EBIT (non-GAAP) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Attributable to Johnson Controls | $ | 618 |  |  | $ | 852 |  |  | $ | 693 |  |  | $ | 639 |  |  | $ | 1,454 |  |  | $ | 871 |  |  | $ | 1,664 |  |  | $ | 1,425 |  |
| Attributable to noncontrolling interests | — |  |  | (1) |  |  | — |  |  | (1) |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Income from continuing operations | 618 |  |  | 851 |  |  | 693 |  |  | 638 |  |  | 1,454 |  |  | 873 |  |  | 1,664 |  |  | 1,427 |  |
| Less: Income tax provision (1) | 87 |  |  | 174 |  |  | 95 |  |  | 82 |  |  | 160 |  |  | 1 |  |  | 227 |  |  | 187 |  |
| Income before income taxes | 705 |  |  | 1,025 |  |  | 788 |  |  | 720 |  |  | 1,614 |  |  | 874 |  |  | 1,891 |  |  | 1,614 |  |
| Net financing charges | 77 |  |  | 70 |  |  | 77 |  |  | 70 |  |  | 243 |  |  | 246 |  |  | 243 |  |  | 246 |  |
| EBIT (non-GAAP) | $ | 782 |  |  | $ | 1,095 |  |  | $ | 865 |  |  | $ | 790 |  |  | $ | 1,857 |  |  | $ | 1,120 |  |  | $ | 2,134 |  |  | $ | 1,860 |  |

[0000833444-25-000055:8k_2_02:136]
(1) Adjusted income tax provision excludes the related tax impacts of pre-tax adjusting items.

[0000833444-25-000055:8k_2_02:137]
14

[0000833444-25-000055:8k_2_02:138]
The following tables include the reconciliations of segment EBITA as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-25-000055:8k_2_02:139]
|  | Three Months Ended June 30, |
| (in millions) | Americas |  | EMEA |  | APAC |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Sales | $ | 4,042 |  |  | $ | 4,035 |  |  | $ | 1,273 |  |  | $ | 1,177 |  |  | $ | 737 |  |  | $ | 686 |  |
| Segment EBITA | $ | 742 |  |  | $ | 804 |  |  | $ | 177 |  |  | $ | 154 |  |  | $ | 143 |  |  | $ | 128 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Transformation costs | 4 |  |  | — |  |  | 2 |  |  | — |  |  | — |  |  | — |  |
| Earn-out adjustments | — |  |  | (61) |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Adjusted segment EBITA (non-GAAP) | $ | 746 |  |  | $ | 743 |  |  | $ | 179 |  |  | $ | 154 |  |  | $ | 143 |  |  | $ | 128 |  |
| Segment EBITA Margin % | 18.4 | % |  | 19.9 | % |  | 13.9 | % |  | 13.1 | % |  | 19.4 | % |  | 18.7 | % |
| Adjusted segment EBITA Margin % (non-GAAP) | 18.5 | % |  | 18.4 | % |  | 14.1 | % |  | 13.1 | % |  | 19.4 | % |  | 18.7 | % |

[0000833444-25-000055:8k_2_02:140]
|  | Nine Months Ended June 30, |
| (in millions) | Americas |  | EMEA |  | APAC |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Sales | $ | 11,506 |  |  | $ | 11,341 |  |  | $ | 3,631 |  |  | $ | 3,440 |  |  | $ | 2,017 |  |  | $ | 1,923 |  |
| Segment EBITA | $ | 2,038 |  |  | $ | 1,853 |  |  | $ | 448 |  |  | $ | 397 |  |  | $ | 337 |  |  | $ | 320 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Transformation costs | 6 |  |  | — |  |  | 2 |  |  | — |  |  | — |  |  | — |  |
| Earn-out adjustments | — |  |  | (68) |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Product quality costs | — |  |  | 26 |  |  | — |  |  | 4 |  |  | — |  |  | 3 |  |
| Adjusted segment EBITA (non-GAAP) | $ | 2,044 |  |  | $ | 1,811 |  |  | $ | 450 |  |  | $ | 401 |  |  | $ | 337 |  |  | $ | 323 |  |
| Segment EBITA Margin % | 17.7 | % |  | 16.3 | % |  | 12.3 | % |  | 11.5 | % |  | 16.7 | % |  | 16.6 | % |
| Adjusted segment EBITA Margin % (non-GAAP) | 17.8 | % |  | 16.0 | % |  | 12.4 | % |  | 11.7 | % |  | 16.7 | % |  | 16.8 | % |

[0000833444-25-000055:8k_2_02:141]
15

[0000833444-25-000055:8k_2_02:142]
|  | Year Ended September 30, 2024 |
| (in millions) | Americas |  | EMEA |  | APAC |
| Sales | $ | 15,606 |  |  | $ | 4,620 |  |  | $ | 2,726 |  |
| Segment EBITA | $ | 2,679 |  |  | $ | 561 |  |  | $ | 478 |  |
| Adjusting items: |  |  |  |  |  |
| Earn-out adjustments | (68) |  |  | — |  |  | — |  |
| Product quality costs | 26 |  |  | 4 |  |  | 3 |  |
| EMEA joint venture loss | — |  |  | 17 |  |  | — |  |
| Adjusted segment EBITA (non-GAAP) | $ | 2,637 |  |  | $ | 582 |  |  | $ | 481 |  |
| Segment EBITA Margin % | 17.2 | % |  | 12.1 | % |  | 17.5 | % |
| Adjusted segment EBITA Margin % (non-GAAP) | 16.9 | % |  | 12.6 | % |  | 17.6 | % |

[0000833444-25-000055:8k_2_02:143]
The following table reconciles Corporate expense from continuing operations as reported to the comparable adjusted amounts (unaudited):

[0000833444-25-000055:8k_2_02:144]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |  |  |  |  |
| (in millions) | 2025 |  | 2024 |  | 2025 |  | 2024 |  |  |  |  |
| Corporate expense (GAAP) | $ | 141 |  |  | $ | 128 |  |  | $ | 498 |  |  | $ | 359 |  |  |  |  |  |
|  |  |  |  |  | . |  |  |  |  |  |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Transaction/separation costs | (9) |  |  | (9) |  |  | (27) |  |  | (14) |  |  |  |  |  |
| Transformation costs | (39) |  |  | — |  |  | (116) |  |  | — |  |  |  |  |  |
| Cyber incident costs | — |  |  | — |  |  | — |  |  | (27) |  |  |  |  |  |
| Adjusted corporate expense (non-GAAP) | $ | 93 |  |  | $ | 119 |  |  | $ | 355 |  |  | $ | 318 |  |  |  |  |  |

[0000833444-25-000055:8k_2_02:145]
16

[0000833444-25-000055:8k_2_02:146]
6.  Net Income and Diluted Earnings Per Share

[0000833444-25-000055:8k_2_02:147]
The following tables reconcile income from continuing operations attributable to JCI and diluted earnings per share from continuing operations as reported to the comparable adjusted amounts (unaudited):

[0000833444-25-000055:8k_2_02:148]
|  | Three Months Ended June 30, |
|  | Income from continuing operations attributable to JCI |  | Diluted earnings per share |
| (in millions, except per share) | 2025 |  | 2024 |  | 2025 |  | 2024 |
| As reported (GAAP) | $ | 618 |  |  | $ | 852 |  |  | $ | 0.94 |  |  | $ | 1.27 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | (21) |  |  | (5) |  |  | (0.03) |  |  | (0.01) |  |
| Earn-out adjustments | — |  |  | (61) |  |  | — |  |  | (0.09) |  |
| Restructuring and impairment costs, net of NCI | 51 |  |  | 103 |  |  | 0.08 |  |  | 0.15 |  |
| Water systems AFFF insurance recoveries | (1) |  |  | (351) |  |  | — |  |  | (0.52) |  |
| Transaction/separation costs | 9 |  |  | 9 |  |  | 0.01 |  |  | 0.01 |  |
| Transformation costs | 45 |  |  | — |  |  | 0.07 |  |  | — |  |
| Related tax impact | (8) |  |  | 92 |  |  | (0.01) |  |  | 0.14 |  |
| Adjusted (non-GAAP)* | $ | 693 |  |  | $ | 639 |  |  | $ | 1.05 |  |  | $ | 0.95 |  |

[0000833444-25-000055:8k_2_02:149]
* May not sum due to rounding

[0000833444-25-000055:8k_2_02:150]
|  | Nine Months Ended June 30, |
|  | Income from continuing operations attributable to JCI |  | Diluted earnings per share |
| (in millions, except per share) | 2025 |  | 2024 |  | 2025 |  | 2024 |
| As reported (GAAP) | $ | 1,454 |  |  | $ | 871 |  |  | $ | 2.20 |  |  | $ | 1.28 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | (7) |  |  | (42) |  |  | (0.01) |  |  | (0.06) |  |
| Earn-out adjustments | — |  |  | (68) |  |  | — |  |  | (0.10) |  |
| Restructuring and impairment costs, net of NCI | 146 |  |  | 377 |  |  | 0.22 |  |  | 0.56 |  |
| Water systems AFFF settlement | — |  |  | 750 |  |  | — |  |  | 1.11 |  |
| Water systems AFFF insurance recoveries | (13) |  |  | (351) |  |  | (0.02) |  |  | (0.52) |  |
| Product quality costs | — |  |  | 33 |  |  | — |  |  | 0.05 |  |
| Transaction/separation costs | 27 |  |  | 14 |  |  | 0.04 |  |  | 0.02 |  |
| Transformation costs | 124 |  |  | — |  |  | 0.19 |  |  | — |  |
| Cyber incident costs | — |  |  | 27 |  |  | — |  |  | 0.04 |  |
| Discrete tax items | (36) |  |  | (57) |  |  | (0.05) |  |  | (0.08) |  |
| Related tax impact | (31) |  |  | (129) |  |  | (0.05) |  |  | (0.19) |  |
| Adjusted (non-GAAP)* | $ | 1,664 |  |  | $ | 1,425 |  |  | $ | 2.52 |  |  | $ | 2.10 |  |

[0000833444-25-000055:8k_2_02:151]
* May not sum due to rounding

[0000833444-25-000055:8k_2_02:152]
17

[0000833444-25-000055:8k_2_02:153]
The following table reconciles the denominators used to calculate basic and diluted earnings per share (in millions; unaudited):

[0000833444-25-000055:8k_2_02:154]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Weighted average shares outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 655.4 |  |  | 670.3 |  | $ | 658.9 |  |  | $ | 676.7 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 2.0 |  |  | 2.5 |  |  | 2.2 |  |  | 1.9 |  |
| Diluted weighted average shares outstanding | 657.4 |  |  | 672.8 |  |  | 661.1 |  |  | 678.6 |  |

[0000833444-25-000055:8k_2_02:155]
7.  Debt Ratios

[0000833444-25-000055:8k_2_02:156]
The following table includes continuing operations and details net debt to income before income taxes and net debt to adjusted EBITDA (unaudited):

[0000833444-25-000055:8k_2_02:157]
| (in millions) | June 30, 2025 |  | March 31, 2025 |  | June 30, 2024 |  |  |
| Short-term debt | $ | 1,277 |  |  | $ | 1,261 |  |  | $ | 1,523 |  |  |  |
| Current portion of long-term debt | 570 |  |  | 558 |  |  | 998 |  |  |  |
| Long-term debt | 8,446 |  |  | 8,167 |  |  | 7,867 |  |  |  |
| Total debt | 10,293 |  |  | 9,986 |  |  | 10,388 |  |  |  |
| Less: cash and cash equivalents | $ | 731 |  |  | 795 |  |  | 858 |  |  |  |
| Net debt | $ | 9,562 |  |  | $ | 9,191 |  |  | $ | 9,530 |  |  |  |
| Last twelve months income before income taxes | $ | 2,262 |  |  | $ | 2,582 |  |  | $ | 1,270 |  |  |  |
| Net debt to income before income taxes | 4.2 | x |  | 3.6 | x |  | 7.5 | x |  |  |
| Last twelve months adjusted EBITDA (non-GAAP) | $ | 3,843 |  |  | $ | 3,779 |  |  | $ | 3,496 |  |  |  |
| Net debt to adjusted EBITDA (non-GAAP) | 2.5x |  | 2.4x |  | 2.7x |  |  |

[0000833444-25-000055:8k_2_02:158]
18

[0000833444-25-000055:8k_2_02:159]
The following table reconciles income from continuing operations to adjusted EBIT and adjusted EBITDA (unaudited):

[0000833444-25-000055:8k_2_02:160]
|  | Twelve Months Ended |  |  |
| (in millions) | June 30, 2025 |  | March 31, 2025 |  | June 30, 2024 |  |  |
| Income from continuing operations | $ | 1,992 |  |  | $ | 2,225 |  |  | $ | 1,361 |  |  |  |
| Income tax provision (benefit) | 270 |  |  | 357 |  |  | (91) |  |  |  |
| Income before income taxes | 2,262 |  |  | 2,582 |  |  | 1,270 |  |  |  |
| Net financing charges | 339 |  |  | 332 |  |  | 302 |  |  |  |
| EBIT | 2,601 |  |  | 2,914 |  |  | 1,572 |  |  |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Net mark-to-market adjustments | (12) |  |  | 4 |  |  | 69 |  |  |  |
| Restructuring and impairment costs | 279 |  |  | 330 |  |  | 588 |  |  |  |
| Water systems AFFF settlement | — |  |  | — |  |  | 750 |  |  |  |
| Water systems AFFF insurance recoveries | (29) |  |  | (379) |  |  | (351) |  |  |  |
| Earn-out adjustments | — |  |  | (61) |  |  | (68) |  |  |  |
| Transaction/separation costs | 44 |  |  | 45 |  |  | 35 |  |  |  |
| Transformation costs | 124 |  |  | 79 |  |  | — |  |  |  |
| Cyber incident costs | — |  |  | — |  |  | 27 |  |  |  |
| Product quality costs | — |  |  | — |  |  | 33 |  |  |  |
| Loss on divestiture | 42 |  |  | 42 |  |  | — |  |  |  |
| EMEA joint venture loss | 17 |  |  | 17 |  |  | — |  |  |  |
| Adjusted EBIT (non-GAAP) | 3,066 |  |  | 2,991 |  |  | 2,655 |  |  |  |
| Depreciation and amortization | 777 |  |  | 788 |  |  | 841 |  |  |  |
| Adjusted EBITDA (non-GAAP) | $ | 3,843 |  |  | $ | 3,779 |  |  | $ | 3,496 |  |  |  |

[0000833444-25-000055:8k_2_02:161]
8.  Income Taxes

[0000833444-25-000055:8k_2_02:162]
The Company's effective tax rate before consideration of certain excluded items was approximately 12.0% for the three and nine months ending June 30, 2025 and 11.4% and 11.6% for the three and nine months ending June 30, 2024, respectively.
