# JCI notes — 0000833444-25-000063


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-25-000063:notes:1]
BASIS OF PRESENTATION
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2024 filed with the SEC on November 19, 2024. The results of operations for the three and nine month periods ended June 30, 2025 are not necessarily indicative of results for the Company’s 2025 fiscal year because of seasonal and other factors.

[0000833444-25-000063:notes:2]
On April 1, 2025, the Company realigned into three reportable segments (Americas, EMEA and APAC) from four reportable segments (Global Products, Building Solutions North America, Building Solutions EMEA/LA and Building Solutions APAC). Historical information has been recast to present the comparative periods on a consistent basis. Refer to Note 16, "Segment Information," of the notes to the consolidated financial statements for further disclosure.

[0000833444-25-000063:notes:3]
[same as prior period, unchanged from 0000833444-25-000032:notes:2]

[0000833444-25-000063:notes:4]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global leader in smart, safe, healthy and sustainable buildings, serving a wide range of customers around the globe. The Company’s products and solutions advance the safety, comfort and intelligence of spaces to serve people, places and the planet. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-25-000063:notes:5]
The Company is a global leader in engineering, manufacturing, commissioning and retrofitting building products and systems, including commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire-detection systems and fire-suppression solutions. The Company further serves customers by providing technical services, including maintenance, management, repair, retrofit and replacement of equipment (in the HVAC, industrial refrigeration, controls, security and fire-protection space) and energy-management consulting. The Company partners with customers by leveraging its broad product portfolio and digital capabilities, together with its direct channel service and solutions capabilities, to deliver outcome-based solutions across the lifecycle of a building that address customers’ needs to improve energy efficiency, enhance security, create healthy environments and reduce greenhouse gas emissions.

[0000833444-25-000063:notes:6]
As discussed in more detail in Note 3, "Assets and Liabilities Held for Sale and Discontinued Operations", of the notes to the consolidated financial statements, the Company entered into a definitive agreement to sell its Residential and Light Commercial (“R&LC") HVAC business, including the North America Ducted business and the global Residential joint venture with Hitachi Global Life Solutions, Inc. (“Hitachi”), of which Johnson Controls owns 60% and Hitachi owns 40%. The R&LC HVAC business, which was previously reported in the Global Products segment prior to the Company's resegmentation, meets the criteria to be classified as a discontinued operation and, as a result, its historical financial results are reflected in the consolidated financial statements as a discontinued operation, and assets and liabilities are classified as held for sale for all periods presented. Unless otherwise noted, all activities and amounts reported in the following footnotes relate to the continuing operations of the Company and exclude activities and amounts related to the R&LC HVAC business.

[0000833444-25-000063:notes:7]
[same as prior period, unchanged from 0000833444-25-000032:notes:6]

[0000833444-25-000063:notes:8]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc and its subsidiaries in conformity with U.S. GAAP. The results of companies acquired or disposed of during the reporting period are included in the consolidated financial statements from the effective date of acquisition or up to the date of disposal.

[0000833444-25-000063:notes:9]
Investments in partially-owned affiliates are accounted for by the equity method when the Company exercises significant influence, which typically occurs when its ownership interest exceeds 20%, and the Company does not have a controlling interest.

[0000833444-25-000063:notes:10]
[same as prior period, unchanged from 0000833444-25-000032:notes:8]


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000833444-25-000063:notes:11]
NEW ACCOUNTING STANDARDS
Recently Adopted Accounting Pronouncements

[0000833444-25-000063:notes:12]
In September 2022, the FASB issued ASU 2022-04, "Disclosure of Supplier Finance Program Obligations," which is intended to enhance the transparency surrounding the use of supplier finance programs. Supplier finance programs may also be referred to as reverse factoring, payables finance, or structured payables arrangements. The amendments require a buyer that uses supplier finance programs to make annual disclosures about the program’s key terms, the balance sheet presentation of related amounts, the confirmed amount outstanding at the end of the period, and associated rollforward information. Only the amount outstanding at the end of the period must be disclosed in interim periods. The Company adopted the new disclosures, other than the rollforward disclosure, as required at the beginning of fiscal 2024. The rollforward disclosure will be adopted as required in fiscal 2025.

[0000833444-25-000063:notes:13]
Amounts outstanding related to supply chain financing ("SCF") programs are included in accounts payable in the consolidated statements of financial position. Accounts payable included in the SCF programs were $844 million and $703 million as of June 30, 2025 and September 30, 2024, respectively.

[0000833444-25-000063:notes:14]
Recently Issued Accounting Pronouncements

[0000833444-25-000063:notes:15]
In November 2024, the FASB issued ASU 2024-03, "Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses," which is intended to enhance transparency into the nature and function of expenses. The amendments require that on an annual and interim basis, entities disclose disaggregated operating expense information about specific categories, including purchases of inventory, employee compensation, depreciation, amortization and depletion. The Company expects to adopt the new annual disclosures as required for fiscal 2028 and the interim disclosures as required beginning with the first quarter of fiscal 2029.

[0000833444-25-000063:notes:16]
In December 2023, the FASB issued ASU 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures," which is intended to enhance the transparency about income tax information through improvements to income tax disclosures primarily related to the rate reconciliation and income taxes paid information. The amendments require that on an annual basis, entities disclose specific categories in the rate reconciliation and provide additional information for reconciling items that meet a quantitative threshold. In addition, the amendments require that entities disclose additional information about income taxes paid as well as additional disclosures of pretax income and income tax expense, and remove the requirement to disclose certain items that are no longer considered cost beneficial or relevant. The Company expects to adopt the new annual disclosures as required for fiscal 2026.

[0000833444-25-000063:notes:17]
In November 2023, the FASB issued ASU 2023-07, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures," which is intended to improve reportable segment disclosures, primarily through enhanced disclosures about significant segment expenses. In addition, the amendments enhance interim disclosure requirements, clarify circumstances in which an entity can disclose multiple segment measures of profit or loss, provide new segment disclosure requirements for entities with a single reportable segment and contain other disclosure requirements. The Company expects to adopt the new annual disclosures as required for fiscal 2025 and the interim disclosures as required beginning with the first quarter of fiscal 2026.

[0000833444-25-000063:notes:18]
The Company does not expect the recently issued accounting pronouncements above to have a material impact on its consolidated financial statements other than the related incremental disclosures. Other recently issued accounting pronouncements are not expected to have a material impact on the Company's consolidated financial statements.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-25-000063:notes:19]
ASSETS AND LIABILITIES HELD FOR SALE AND DISCONTINUED OPERATIONS
In July 2024, the Company entered into a definitive agreement to sell its R&LC HVAC business, which includes the North America Ducted businesses and the global Residential joint venture with Hitachi, of which Johnson Controls owns 60% and Hitachi owns 40%, to Bosch Group for approximately $8.1 billion in cash with the Company’s portion of the aggregate consideration being approximately $6.7 billion, inclusive of an upfront royalty payment for the licensing of the York tradename. The transaction closed on July 31, 2025 with net cash proceeds of approximately $5.0 billion after tax and transaction-related expenses. The R&LC HVAC business, which was previously reported in the Global Products segment prior to the Company's resegmentation, meets the criteria to be classified as discontinued operations as it represents a strategic shift in the Company's operations and results in the exit of substantially all of its residential and light commercial HVAC businesses. Results of the business are presented in discontinued operations for all periods presented.

[0000833444-25-000063:notes:20]
The Company determined that the assets and liabilities for the R&LC HVAC business met the held for sale criteria during the fourth quarter of 2024. Accordingly, the assets and liabilities of the business were reclassified in the consolidated balance sheets at June 30, 2025 and September 30, 2024 to held for sale, and the Company ceased recording depreciation and amortization for the held for sale assets.

[0000833444-25-000063:notes:21]
[same as prior period, unchanged from 0000833444-25-000032:notes:19]

[0000833444-25-000063:notes:22]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |  |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  |
| Net sales |  | $ | 1,369 |  |  | $ | 1,333 |  |  | $ | 3,404 |  |  | $ | 3,320 |  |  |
| Cost of goods sold |  | 1,007 |  |  | 954 |  |  | 2,579 |  |  | 2,468 |  |  |
| Gross profit |  | 362 |  |  | 379 |  |  | 825 |  |  | 852 |  |  |
| Selling, general and administrative expenses |  | 212 |  |  | 195 |  |  | 584 |  |  | 562 |  |  |
| Restructuring and impairment costs |  | 12 |  |  | 3 |  |  | 21 |  |  | 22 |  |  |
| Net financing charges |  | 5 |  |  | 2 |  |  | 6 |  |  | 17 |  |  |
| Equity income |  | 77 |  |  | 75 |  |  | 211 |  |  | 196 |  |  |
| Income from discontinued operations before income taxes |  | 210 |  |  | 254 |  |  | 425 |  |  | 447 |  |  |
| Provision for income taxes on discontinued operations |  | 50 |  |  | 53 |  |  | 124 |  |  | 98 |  |  |
| Income from discontinued operations, net of tax |  | 160 |  |  | 201 |  |  | 301 |  |  | 349 |  |  |
| Income from discontinued operations attributable to noncontrolling interest, net of tax |  | 77 |  |  | 78 |  |  | 157 |  |  | 148 |  |  |
| Income from discontinued operations |  | $ | 83 |  |  | $ | 123 |  |  | $ | 144 |  |  | $ | 201 |  |  |

[0000833444-25-000063:notes:23]
[same as prior period, unchanged from 0000833444-25-000032:notes:21]

[0000833444-25-000063:notes:24]
|  |  | June 30, 2025 |  | September 30, 2024 |
| Cash |  | $ | 2 |  |  | $ | 5 |  |
| Accounts receivable - net |  | 751 |  |  | 592 |  |
| Inventories |  | 1,089 |  |  | 876 |  |
| Other current assets |  | 135 |  |  | 122 |  |
| Current assets held for sale |  | 1,977 |  |  | 1,595 |  |
| Property, plant and equipment - net |  | 808 |  |  | 793 |  |
| Goodwill |  | 1,195 |  |  | 1,182 |  |
| Other intangible assets - net |  | 98 |  |  | 96 |  |
| Investments in partially-owned affiliates |  | 769 |  |  | 949 |  |
| Other noncurrent assets |  | 198 |  |  | 190 |  |
| Noncurrent assets held for sale |  | 3,068 |  |  | 3,210 |  |
| Total assets classified as held for sale |  | $ | 5,045 |  |  | $ | 4,805 |  |
| Accounts payable |  | $ | 1,083 |  |  | $ | 917 |  |
| Accrued compensation and benefits |  | 101 |  |  | 113 |  |
| Deferred revenue |  | 125 |  |  | 84 |  |
| Other current liabilities |  | 339 |  |  | 317 |  |
| Current liabilities held for sale |  | 1,648 |  |  | 1,431 |  |
| Pension and postretirement benefit obligations |  | 27 |  |  | 28 |  |
| Other noncurrent liabilities |  | 362 |  |  | 377 |  |
| Noncurrent liabilities held for sale |  | 389 |  |  | 405 |  |
| Total liabilities classified as held for sale |  | $ | 2,037 |  |  | $ | 1,836 |  |

[0000833444-25-000063:notes:25]
During the third quarter of fiscal 2025, the Company signed a definitive agreement to sell its ADT Mexico residential security business. The transaction is expected to close in the first quarter of fiscal 2026. The ADT Mexico business, which is reported in the EMEA segment, does not meet the criteria to be classified as discontinued operations as it does not represent a strategic shift in the Company's operations nor result in the exit of substantially all of its residential security businesses.

[0000833444-25-000063:notes:26]
The Company determined that the assets and liabilities of the ADT Mexico business met the held for sale criteria during the third quarter of 2025. Accordingly, $122 million of assets and $23 million of liabilities associated with the ADT Mexico business were reclassified to held for sale in the consolidated balance sheet at June 30, 2025.

[0000833444-25-000063:notes:27]
Assets and liabilities classified as held for sale are required to be recorded at the lower of carrying value or fair value less costs to sell. As of June 30, 2025, the estimated fair value less costs to sell of the held for sale businesses exceeded their carrying value, and therefore, no adjustment was necessary.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-25-000063:notes:28]
[same as prior period, unchanged from 0000833444-25-000032:notes:24]

[0000833444-25-000063:notes:29]
[same as prior period, unchanged from 0000833444-25-000032:notes:25]

[0000833444-25-000063:notes:30]
|  |  | Three Months Ended June 30, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Americas |  | $ | 2,847 |  |  | $ | 1,195 |  |  | $ | 4,042 |  |  | $ | 2,887 |  |  | $ | 1,148 |  |  | $ | 4,035 |  |
| EMEA |  | 756 |  |  | 517 |  |  | 1,273 |  |  | 710 |  |  | 467 |  |  | 1,177 |  |
| APAC |  | 519 |  |  | 218 |  |  | 737 |  |  | 492 |  |  | 194 |  |  | 686 |  |
| Total |  | $ | 4,122 |  |  | $ | 1,930 |  |  | $ | 6,052 |  |  | $ | 4,089 |  |  | $ | 1,809 |  |  | $ | 5,898 |  |

[0000833444-25-000063:notes:31]
|  |  | Nine Months Ended June 30, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Americas |  | $ | 8,094 |  |  | $ | 3,412 |  |  | $ | 11,506 |  |  | $ | 8,114 |  |  | $ | 3,227 |  |  | $ | 11,341 |  |
| EMEA |  | 2,177 |  |  | 1,454 |  |  | 3,631 |  |  | 2,086 |  |  | 1,354 |  |  | 3,440 |  |
| APAC |  | 1,401 |  |  | 616 |  |  | 2,017 |  |  | 1,376 |  |  | 547 |  |  | 1,923 |  |
| Total |  | $ | 11,672 |  |  | $ | 5,482 |  |  | $ | 17,154 |  |  | $ | 11,576 |  |  | $ | 5,128 |  |  | $ | 16,704 |  |

[0000833444-25-000063:notes:32]
[same as prior period, unchanged from 0000833444-25-000032:notes:30]

[0000833444-25-000063:notes:33]
[same as prior period, unchanged from 0000833444-25-000032:notes:31]

[0000833444-25-000063:notes:34]
[same as prior period, unchanged from 0000833444-25-000032:notes:32]

[0000833444-25-000063:notes:35]
|  |  | Location of contract balances |  | June 30, 2025 |  | September 30, 2024 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,119 |  |  | $ | 1,931 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 7 |  |  | 11 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,428 |  |  | 2,160 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 269 |  |  | 252 |  |  |  |

[0000833444-25-000063:notes:36]
For the three months ended June 30, 2025 and 2024, the Company recognized revenue of $279 million and $267 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year. For the nine months ended June 30, 2025 and 2024, the Company recognized revenue of $1,550 million and $1,475 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year.

[0000833444-25-000063:notes:37]
[same as prior period, unchanged from 0000833444-25-000032:notes:35]

[0000833444-25-000063:notes:38]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of June 30, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $22.4 billion, of which approximately 63% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for service contracts with an original expected duration of one year or less and contracts that are cancellable without substantial penalty.

[0000833444-25-000063:notes:39]
[same as prior period, unchanged from 0000833444-25-000032:notes:37]

[0000833444-25-000063:notes:40]
[same as prior period, unchanged from 0000833444-25-000032:notes:38]

[0000833444-25-000063:notes:41]
[same as prior period, unchanged from 0000833444-25-000032:notes:39]

[0000833444-25-000063:notes:42]
|  | June 30, 2025 |  | September 30, 2024 |  |  |
| Other current assets | $ | 306 |  |  | $ | 265 |  |  |  |
| Other noncurrent assets | 257 |  |  | 291 |  |  |  |
| Total | $ | 563 |  |  | $ | 556 |  |  |  |

[0000833444-25-000063:notes:43]
During the three months ended June 30, 2025 and 2024, the Company recognized expense of $104 million and $84 million, respectively, related to costs to obtain or fulfill a contract. During the nine months ended June 30, 2025 and 2024, the Company recognized expense of $279 million and $218 million, respectively, related to costs to obtain or fulfill a contract.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-25-000063:notes:44]
[same as prior period, unchanged from 0000833444-25-000032:notes:42]

[0000833444-25-000063:notes:45]
|  | June 30, 2025 |  | September 30, 2024 |
| Raw materials and supplies | $ | 746 |  |  | $ | 765 |  |
| Work-in-process | 142 |  |  | 130 |  |
| Finished goods | 941 |  |  | 879 |  |
| Inventories | $ | 1,829 |  |  | $ | 1,774 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-25-000063:notes:46]
[same as prior period, unchanged from 0000833444-25-000032:notes:44]

[0000833444-25-000063:notes:47]
|  |  | Nine Months Ended June 30, 2025 |
|  |  | Americas |  | EMEA |  | APAC |  |  | Total |
| Goodwill |  | $ | 14,118 |  |  | $ | 2,409 |  |  | $ | 1,393 |  |  |  | 17,920 |  |
| Accumulated impairment loss |  | (918) |  |  | (277) |  |  | — |  |  |  | (1,195) |  |
| Balance at beginning of period |  | 13,200 |  |  | 2,132 |  |  | 1,393 |  |  |  | 16,725 |  |
| Foreign currency translation and other (1) |  | (3) |  |  | 23 |  |  | (36) |  |  |  | (16) |  |
| Balance at end of period |  | $ | 13,197 |  |  | $ | 2,155 |  |  | $ | 1,357 |  |  |  | $ | 16,709 |  |

[0000833444-25-000063:notes:48]
(1)  Includes measurement period adjustments and the allocation of $56 million of goodwill from EMEA to the ADT Mexico residential security business disposal group classified as held for sale. Refer to Note 3, "Assets and Liabilities Held for Sale and Discontinued Operations" of the notes to the consolidated financial statements for further information.

[0000833444-25-000063:notes:49]
At April 1, 2025, the Company reallocated goodwill of reporting units impacted by the change in reportable segments described in Note 16, "Segment Information," of the notes to the consolidated financial statements and assessed goodwill for impairment. The Company determined that the estimated fair value of each reporting unit exceeded its corresponding carrying amount including recorded goodwill, and as such, no impairment existed at April 1, 2025.

[0000833444-25-000063:notes:50]
During the third quarter of fiscal 2025, the Company signed a definitive agreement to sell its ADT Mexico residential security business, resulting in a triggering event for the impacted reporting unit. The Company performed a quantitative goodwill impairment test of the reporting unit with $174 million of remaining goodwill, and its fair value was slightly in excess of its carrying value. However, for this reporting unit, a 50 basis point increase in the discount rate, or a 100 basis point decrease in the revenue growth rates, would cause the fair value to be less than the carrying value. While no impairment was recorded, it is possible that future changes in circumstances could result in a non-cash impairment charge. The Company used a discounted cash flow model to estimate the fair value of the reporting unit. The primary assumptions used in the model were management's internal projections of future cash flows, the weighted-average cost of capital and the long-term growth rate, which are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement." This reporting unit was previously disclosed as being at risk of impairment in the Company’s Annual Report on Form 10-K for the year-ended September 30, 2024.

[0000833444-25-000063:notes:51]
[same as prior period, unchanged from 0000833444-25-000032:notes:46]

[0000833444-25-000063:notes:52]
|  | June 30, 2025 |  | September 30, 2024 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Definite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,604 |  |  | $ | (1,074) |  |  | $ | 530 |  |  | $ | 1,592 |  |  | $ | (955) |  |  | $ | 637 |  |
| Customer relationships | 2,641 |  |  | (1,689) |  |  | 952 |  |  | 2,632 |  |  | (1,517) |  |  | 1,115 |  |
| Miscellaneous | 895 |  |  | (503) |  |  | 392 |  |  | 886 |  |  | (480) |  |  | 406 |  |
|  | 5,140 |  |  | (3,266) |  |  | 1,874 |  |  | 5,110 |  |  | (2,952) |  |  | 2,158 |  |
| Indefinite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 1,982 |  |  | — |  |  | 1,982 |  |  | 1,972 |  |  | — |  |  | 1,972 |  |
| Total intangible assets | $ | 7,122 |  |  | $ | (3,266) |  |  | $ | 3,856 |  |  | $ | 7,082 |  |  | $ | (2,952) |  |  | $ | 4,130 |  |

[0000833444-25-000063:notes:53]
Amortization of other intangible assets included within continuing operations for the three months ended June 30, 2025 and 2024 was $110 million and $116 million, respectively. Amortization of other intangible assets included within continuing operations for the nine months ended June 30, 2025 and 2024 was $342 million and $357 million, respectively.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000833444-25-000063:notes:54]
[same as prior period, unchanged from 0000833444-25-000032:notes:49]

[0000833444-25-000063:notes:55]
|  | Location of lease balances |  | June 30, 2025 |  | September 30, 2024 |
| Operating lease right-of-use assets | Other noncurrent assets |  | $ | 1,319 |  | $ | 1,170 |  |
| Operating lease liabilities - current | Other current liabilities |  | 284 |  | 289 |  |
| Operating lease liabilities - noncurrent | Other noncurrent liabilities |  | 1,068 |  | 921 |  |

[0000833444-25-000063:notes:56]
[same as prior period, unchanged from 0000833444-25-000032:notes:51]

[0000833444-25-000063:notes:57]
|  |  |  |  | Nine Months Ended June 30, |  |  |
|  |  |  |  |  |  | 2025 |  | 2024 |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  |  |  |  |  | $ | 421 |  |  | $ | 232 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-25-000063:notes:58]
DEBT AND FINANCING ARRANGEMENTS
Short-term debt consisted of the following (in millions):

[0000833444-25-000063:notes:59]
|  | June 30, 2025 |  | September 30, 2024 |
| Commercial paper | $ | 650 |  |  | $ | 350 |  |
| Term loans | 627 |  |  | 603 |  |
|  | $ | 1,277 |  |  | $ | 953 |  |
| Weighted average interest rate on short-term debt outstanding | 4.0 | % |  | 4.8 | % |

[0000833444-25-000063:notes:60]
As of June 30, 2025, the Company had two syndicated committed revolving credit facilities, including $2.5 billion which is scheduled to expire in December 2028 and $500 million which is scheduled to expire in December 2025. There were no draws on the facilities as of June 30, 2025.

[0000833444-25-000063:notes:61]
In February 2025, the Company repaid €476 million of its 1.375% Notes due 2025 and extinguished $7 million of its 5.125% Notes due 2045 through a bilateral private purchase.

[0000833444-25-000063:notes:62]
In December 2024, the Company and its wholly-owned subsidiary, Tyco Fire & Security Finance S.C.A, co-issued the following unsecured, unsubordinated senior notes:

[0000833444-25-000063:notes:63]
•$250 million 4.900% Senior Notes due 2032. These notes are a further issuance of the $400 million, 4.900% Senior Notes due 2032, which were originally issued in September 2022.

[0000833444-25-000063:notes:64]
•€500 million 3.125% Senior Notes due 2033.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-25-000063:notes:65]
[same as prior period, unchanged from 0000833444-25-000032:notes:60]

[0000833444-25-000063:notes:66]
The Company has global operations and participates in foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange forward contracts. The Company hedges 70% to 90% of the notional amount of each of its known foreign exchange transactional exposures.

[0000833444-25-000063:notes:67]
[same as prior period, unchanged from 0000833444-25-000032:notes:63]

[0000833444-25-000063:notes:68]
Under ASC 815, "Derivatives and Hedging," cash flow hedge gains or losses due to changes in fair value are initially recorded as a component of accumulated other comprehensive income ("AOCI") and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates and commodity prices during the three and nine months ended June 30, 2025 and 2024.

[0000833444-25-000063:notes:69]
[same as prior period, unchanged from 0000833444-25-000032:notes:65]

[0000833444-25-000063:notes:70]
|  |  | Volume Outstanding as of |
| Commodity |  | June 30, 2025 |  | September 30, 2024 |
| Copper |  | 2,313 |  |  | 2,676 |  |
| Aluminum |  | 974 |  |  | 2,450 |  |

[0000833444-25-000063:notes:71]
[same as prior period, unchanged from 0000833444-25-000032:notes:67]

[0000833444-25-000063:notes:72]
[same as prior period, unchanged from 0000833444-25-000032:notes:68]

[0000833444-25-000063:notes:73]
The Company may enter into cross-currency interest rate swaps and foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the cross-currency interest rate swaps and debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally.

[0000833444-25-000063:notes:74]
[same as prior period, unchanged from 0000833444-25-000032:notes:70]

[0000833444-25-000063:notes:75]
|  |  | June 30, |  | September 30, |
|  | 2025 |  | 2024 |
| Euro-denominated bonds designated as net investment hedges in Europe |  | € | 2.9 |  |  | € | 2.9 |  |
| Yen-denominated debt designated as a net investment hedge in Japan |  | ¥ | 30 |  |  | ¥ | 30 |  |

[0000833444-25-000063:notes:76]
[same as prior period, unchanged from 0000833444-25-000032:notes:72]

[0000833444-25-000063:notes:77]
[same as prior period, unchanged from 0000833444-25-000032:notes:73]

[0000833444-25-000063:notes:78]
[same as prior period, unchanged from 0000833444-25-000032:notes:74]

[0000833444-25-000063:notes:79]
[same as prior period, unchanged from 0000833444-25-000032:notes:75]

[0000833444-25-000063:notes:80]
|  | Derivatives and Hedging Activities Designatedas Hedging Instruments |  | Derivatives and Hedging ActivitiesNot Designatedas Hedging Instruments |
|  | June 30, |  | September 30, |  | June 30, |  | September 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 13 |  |  | $ | 19 |  |  | $ | — |  |  | $ | 1 |  |
| Commodity derivatives | 3 |  |  | 2 |  |  | — |  |  | — |  |
| Total assets | $ | 16 |  |  | $ | 21 |  |  | $ | — |  |  | $ | 1 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 7 |  |  | $ | 24 |  |  | $ | 11 |  |  | $ | 1 |  |
| Commodity derivatives | 1 |  |  | 1 |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 3,611 |  |  | 3,424 |  |  | — |  |  | — |  |
| Total liabilities | $ | 3,619 |  |  | $ | 3,449 |  |  | $ | 11 |  |  | $ | 1 |  |

[0000833444-25-000063:notes:81]
[same as prior period, unchanged from 0000833444-25-000032:notes:77]

[0000833444-25-000063:notes:82]
[same as prior period, unchanged from 0000833444-25-000032:notes:78]

[0000833444-25-000063:notes:83]
[same as prior period, unchanged from 0000833444-25-000032:notes:79]

[0000833444-25-000063:notes:84]
[same as prior period, unchanged from 0000833444-25-000032:notes:80]

[0000833444-25-000063:notes:85]
|  |  | Fair Value of Assets |  |  |  | Fair Value of Liabilities |  |  |
|  |  | June 30, |  | September 30, |  |  |  | June 30, |  | September 30, |  |  |
|  |  | 2025 |  | 2024 |  |  |  | 2025 |  | 2024 |  |  |
| Gross amount recognized |  | $ | 16 |  |  | $ | 22 |  |  |  |  | $ | 3,630 |  |  | $ | 3,450 |  |  |  |
| Gross amount eligible for offsetting |  | (10) |  |  | (12) |  |  |  |  | (10) |  |  | (12) |  |  |  |
| Net amount |  | $ | 6 |  |  | $ | 10 |  |  |  |  | $ | 3,620 |  |  | $ | 3,438 |  |  |  |

[0000833444-25-000063:notes:86]
[same as prior period, unchanged from 0000833444-25-000032:notes:82]

[0000833444-25-000063:notes:87]
[same as prior period, unchanged from 0000833444-25-000032:notes:83]

[0000833444-25-000063:notes:88]
| Derivatives in Cash Flow Hedging Relationships |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Foreign currency exchange derivatives |  | $ | — |  |  | $ | 2 |  |  | $ | 15 |  |  | $ | 4 |  |
| Commodity derivatives |  | — |  |  | 4 |  |  | 3 |  |  | 5 |  |
| Interest rate swaps |  | — |  |  | — |  |  | — |  |  | (21) |  |
| Total |  | $ | — |  |  | $ | 6 |  |  | $ | 18 |  |  | $ | (12) |  |

[0000833444-25-000063:notes:89]
[same as prior period, unchanged from 0000833444-25-000032:notes:85]

[0000833444-25-000063:notes:90]
| Derivatives in Cash Flow Hedging Relationships |  | Location of Gain (Loss) Reclassified from AOCI into Income |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 4 |  |  | $ | 4 |  |  | $ | 7 |  |  | $ | 1 |  |
| Commodity derivatives |  | Cost of sales |  | 2 |  |  | — |  |  | 1 |  |  | (4) |  |
| Total |  |  |  | $ | 6 |  |  | $ | 4 |  |  | $ | 8 |  |  | $ | (3) |  |

[0000833444-25-000063:notes:91]
[same as prior period, unchanged from 0000833444-25-000032:notes:87]

[0000833444-25-000063:notes:92]
| Derivatives Not Designated as Hedging Instruments |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | — |  |  | $ | (4) |  |  | $ | (8) |  |  | $ | (7) |  |
| Foreign currency exchange derivatives |  | SG&A |  | 1 |  |  | 2 |  |  | (1) |  |  | 2 |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | 71 |  |  | 20 |  |  | (13) |  |  | 36 |  |
| Total |  |  |  | $ | 72 |  |  | $ | 18 |  |  | $ | (22) |  |  | $ | 31 |  |

[0000833444-25-000063:notes:93]
The following table presents pre-tax gains (losses) on net investment hedges recorded as foreign currency translation adjustments ("CTA") within other comprehensive income (loss) (in millions):

[0000833444-25-000063:notes:94]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
| 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net investment hedges | $ | (269) |  |  | $ | 44 |  |  | $ | (162) |  |  | $ | (3) |  |

[0000833444-25-000063:notes:95]
No gains or losses were reclassified from CTA into income during the three and nine months ended June 30, 2025 and 2024.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-25-000063:notes:96]
[same as prior period, unchanged from 0000833444-25-000032:notes:92]

[0000833444-25-000063:notes:97]
[same as prior period, unchanged from 0000833444-25-000032:notes:93]

[0000833444-25-000063:notes:98]
[same as prior period, unchanged from 0000833444-25-000032:notes:94]

[0000833444-25-000063:notes:99]
[same as prior period, unchanged from 0000833444-25-000032:notes:95]

[0000833444-25-000063:notes:100]
[same as prior period, unchanged from 0000833444-25-000032:notes:96]

[0000833444-25-000063:notes:101]
[same as prior period, unchanged from 0000833444-25-000032:notes:97]

[0000833444-25-000063:notes:102]
[same as prior period, unchanged from 0000833444-25-000032:notes:98]

[0000833444-25-000063:notes:103]
|  | Fair Value Measurements Using: |
|  | Total as of June 30, 2025 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 13 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |
| Commodity derivatives | 3 |  |  | — |  |  | 3 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 59 |  |  | 59 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)(1) | 74 |  |  | 74 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)(1) | 204 |  |  | 204 |  |  | — |  |  | — |  |
| Total assets | $ | 353 |  |  | $ | 337 |  |  | $ | 16 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 18 |  |  | $ | — |  |  | $ | 18 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Contingent earn-out liabilities | 25 |  |  | — |  |  | — |  |  | 25 |  |
| Total liabilities | $ | 44 |  |  | $ | — |  |  | $ | 19 |  |  | $ | 25 |  |

[0000833444-25-000063:notes:104]
(1)  Classified as restricted investments for payment of asbestos liabilities. See Note 18, "Commitments and Contingencies," of the notes to the consolidated financial statements for further details.

[0000833444-25-000063:notes:105]
[same as prior period, unchanged from 0000833444-25-000032:notes:101]

[0000833444-25-000063:notes:106]
[same as prior period, unchanged from 0000833444-25-000032:notes:102]

[0000833444-25-000063:notes:107]
[same as prior period, unchanged from 0000833444-25-000032:notes:103]

[0000833444-25-000063:notes:108]
[same as prior period, unchanged from 0000833444-25-000032:notes:104]

[0000833444-25-000063:notes:109]
[same as prior period, unchanged from 0000833444-25-000032:notes:105]

[0000833444-25-000063:notes:110]
Exchange traded funds: Investments in exchange traded funds are valued using a market approach based on quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. Refer to Note 18, "Commitments and Contingencies," of the notes to the consolidated financial statements for further information.

[0000833444-25-000063:notes:111]
[same as prior period, unchanged from 0000833444-25-000032:notes:107]

[0000833444-25-000063:notes:112]
The following table presents the portion of unrealized gains recognized in the consolidated statements of income that relate to equity securities still held at June 30, 2025 and 2024 (in millions):

[0000833444-25-000063:notes:113]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Deferred compensation plan assets |  | $ | 4 |  |  | $ | — |  |  | $ | 2 |  |  | $ | 7 |  |
| Investments in exchange traded funds |  | 20 |  |  | 4 |  |  | 12 |  |  | 43 |  |

[0000833444-25-000063:notes:114]
[same as prior period, unchanged from 0000833444-25-000032:notes:110]

[0000833444-25-000063:notes:115]
The fair value of long-term debt at June 30, 2025 and September 30, 2024 was as follows (in billions):

[0000833444-25-000063:notes:116]
|  |  | June 30, |  | September 30, |
|  | 2025 |  | 2024 |
| Public debt |  | $ | 8.3 |  |  | $ | 8.1 |  |
| Other long-term debt |  | 0.3 |  |  | 0.2 |  |
| Total fair value of long-term debt |  | $ | 8.6 |  |  | $ | 8.3 |  |

[0000833444-25-000063:notes:117]
[same as prior period, unchanged from 0000833444-25-000032:notes:113]


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0000833444-25-000063:notes:118]
[same as prior period, unchanged from 0000833444-25-000032:notes:114]

[0000833444-25-000063:notes:119]
[same as prior period, unchanged from 0000833444-25-000032:notes:115]


## us-gaap:EarningsPerShareTextBlock

[0000833444-25-000063:notes:120]
[same as prior period, unchanged from 0000833444-25-000032:notes:116]

[0000833444-25-000063:notes:121]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Income Available to Ordinary Shareholders |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 618 |  |  | $ | 852 |  |  | $ | 1,454 |  |  | $ | 871 |  |
| Income from discontinued operations | 83 |  |  | 123 |  |  | 144 |  |  | 201 |  |
| Basic and diluted income available to shareholders | $ | 701 |  |  | $ | 975 |  |  | $ | 1,598 |  |  | $ | 1,072 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 655.4 |  |  | 670.3 |  |  | 658.9 |  |  | 676.7 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 2.0 |  |  | 2.5 |  |  | 2.2 |  |  | 1.9 |  |
| Diluted weighted average shares outstanding | 657.4 |  |  | 672.8 |  |  | 661.1 |  |  | 678.6 |  |
| Antidilutive Securities |  |  |  |  |  |  |  |
| Stock options and unvested restricted stock | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | 0.4 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000833444-25-000063:notes:122]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS) 
The following table includes changes in AOCI attributable to Johnson Controls (in millions):

[0000833444-25-000063:notes:123]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Foreign currency translation adjustments |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (1,131) |  |  | $ | (1,001) |  |  | $ | (956) |  |  | $ | (970) |  |
| Aggregate adjustment for the period | (147) |  |  | (51) |  |  | (322) |  |  | (82) |  |
| Balance at end of period | (1,278) |  |  | (1,052) |  |  | (1,278) |  |  | (1,052) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |  |  |  |  |
| Balance at beginning of period | 9 |  |  | — |  |  | (4) |  |  | 15 |  |
| Current period changes in fair value | — |  |  | 6 |  |  | 16 |  |  | (14) |  |
| Reclassification to income (1) | (6) |  |  | (3) |  |  | (8) |  |  | 4 |  |
| Net tax impact | — |  |  | 1 |  |  | (1) |  |  | (1) |  |
| Balance at end of period | 3 |  |  | 4 |  |  | 3 |  |  | 4 |  |
| Pension and postretirement plans |  |  |  |  |  |  |  |
| Balance at beginning of period | (6) |  |  | (2) |  |  | (4) |  |  | — |  |
| Reclassification to income | (1) |  |  | (1) |  |  | (3) |  |  | (4) |  |
| Net tax impact | 1 |  |  | — |  |  | 1 |  |  | 1 |  |
| Balance at end of period | (6) |  |  | (3) |  |  | (6) |  |  | (3) |  |
| Accumulated other comprehensive loss, end of period | $ | (1,281) |  |  | $ | (1,051) |  |  | $ | (1,281) |  |  | $ | (1,051) |  |

[0000833444-25-000063:notes:124]
[same as prior period, unchanged from 0000833444-25-000032:notes:121]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-25-000063:notes:125]
[same as prior period, unchanged from 0000833444-25-000032:notes:122]

[0000833444-25-000063:notes:126]
[same as prior period, unchanged from 0000833444-25-000032:notes:123]

[0000833444-25-000063:notes:127]
|  | U.S. Pension Plans |
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Interest cost | $ | 16 |  |  | $ | 20 |  |  | $ | 49 |  |  | $ | 59 |  |
| Expected return on plan assets | (24) |  |  | (30) |  |  | (73) |  |  | (90) |  |
| Net periodic benefit credit | $ | (8) |  |  | $ | (10) |  |  | $ | (24) |  |  | $ | (31) |  |

[0000833444-25-000063:notes:128]
|  | Non-U.S. Pension Plans |
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Service cost | $ | 5 |  |  | $ | 4 |  |  | $ | 13 |  |  | $ | 12 |  |
| Interest cost | 16 |  |  | 17 |  |  | 48 |  |  | 51 |  |
| Expected return on plan assets | (20) |  |  | (18) |  |  | (58) |  |  | (54) |  |
| Net periodic benefit cost | $ | 1 |  |  | $ | 3 |  |  | $ | 3 |  |  | $ | 9 |  |

[0000833444-25-000063:notes:129]
|  | Postretirement Benefits |
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Interest cost | $ | 1 |  |  | $ | 1 |  |  | $ | 2 |  |  | $ | 3 |  |
| Expected return on plan assets | (3) |  |  | (3) |  |  | (8) |  |  | (7) |  |
| Amortization of prior service credit | (2) |  |  | (1) |  |  | (4) |  |  | (4) |  |
| Net periodic benefit credit | $ | (4) |  |  | $ | (3) |  |  | $ | (10) |  |  | $ | (8) |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-25-000063:notes:130]
[same as prior period, unchanged from 0000833444-25-000032:notes:127]

[0000833444-25-000063:notes:131]
[same as prior period, unchanged from 0000833444-25-000032:notes:128]

[0000833444-25-000063:notes:132]
[same as prior period, unchanged from 0000833444-25-000032:notes:129]

[0000833444-25-000063:notes:133]
|  | Three Months Ended June 30, 2025 |  | Nine Months Ended June 30, 2025 |  |  |
| Americas | $ | 13 |  |  | $ | 33 |  |  |  |
| EMEA | 22 |  |  | 40 |  |  |  |
| APAC | 1 |  |  | 8 |  |  |  |
| Corporate | 13 |  |  | 41 |  |  |  |
| Total | $ | 49 |  |  | $ | 122 |  |  |  |

[0000833444-25-000063:notes:134]
[same as prior period, unchanged from 0000833444-25-000032:notes:131]

[0000833444-25-000063:notes:135]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  |  |  |  |  | Total |
| Restructuring and related costs | $ | 74 |  |  | $ | 27 |  |  | $ | 21 |  |  |  |  |  |  | $ | 122 |  |
| Utilized—cash | (44) |  |  | (27) |  |  | (13) |  |  |  |  |  |  | (84) |  |
| Other | — |  |  | — |  |  | 3 |  |  |  |  |  |  | 3 |  |
| Balance at June 30, 2025 | $ | 30 |  |  | $ | — |  |  | $ | 11 |  |  |  |  |  |  | $ | 41 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-25-000063:notes:136]
[same as prior period, unchanged from 0000833444-25-000032:notes:135]

[0000833444-25-000063:notes:137]
[same as prior period, unchanged from 0000833444-25-000032:notes:136]

[0000833444-25-000063:notes:138]
For the three months ended June 30, 2025, the Company's effective tax rate for continuing operations was 12.3% and was lower than the statutory tax rate of 12.5% primarily due to the benefits of continuing global tax planning, partially offset by tax rate differentials.

[0000833444-25-000063:notes:139]
For the nine months ended June 30, 2025, the Company's effective tax rate for continuing operations was 9.9% and was lower than the statutory tax rate of 12.5% primarily due to tax reserve adjustments as the result of expired statute of limitations for certain tax years and the benefits of continuing global tax planning, partially offset by tax rate differentials.

[0000833444-25-000063:notes:140]
For the three months ended June 30, 2024, the Company's effective tax rate for continuing operations was 17.0% and was higher than the statutory tax rate of 12.5% primarily due to the tax impact of the water systems Aqueous Film Forming Foam ("AFFF") insurance proceeds and tax rate differentials, partially offset by the benefits of continuing global tax planning.

[0000833444-25-000063:notes:141]
For the nine months ended June 30, 2024, the Company's effective tax rate for continuing operations was 0.1% and was lower than the statutory tax rate of 12.5% primarily due to the net tax impact of the water systems AFFF settlement costs and insurance proceeds, Swiss tax reform, and the benefits of continuing global tax planning, partially offset by the tax impact of an impairment charge, the establishment of a deferred tax liability on the outside basis difference of the Company's investment in certain consolidated subsidiaries, and tax rate differentials.

[0000833444-25-000063:notes:142]
Refer to Note 18, "Commitments and Contingencies," of the notes to the consolidated financial statements for further disclosure related to the water systems AFFF settlement.

[0000833444-25-000063:notes:143]
[same as prior period, unchanged from 0000833444-25-000032:notes:143]

[0000833444-25-000063:notes:144]
At September 30, 2024, the Company had gross tax-effected unrecognized tax benefits of $2.1 billion, of which $1.5 billion, if recognized, would impact the effective tax rate. Accrued interest, net at September 30, 2024 was approximately $398 million (net of tax benefit). Interest accrued during the nine months ended June 30, 2025 and 2024 was approximately $64 million and $90 million (both net of tax benefit), respectively. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-25-000063:notes:145]
During the nine months ended June 30, 2025, as the result of the expiration of the statute of limitations in certain jurisdictions, the Company adjusted its reserve for uncertain tax positions which resulted in a $36 million net benefit to income tax expense.

[0000833444-25-000063:notes:146]
[same as prior period, unchanged from 0000833444-25-000032:notes:146]

[0000833444-25-000063:notes:147]
[same as prior period, unchanged from 0000833444-25-000032:notes:147]

[0000833444-25-000063:notes:148]
It is reasonably possible that tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense. Based upon the circumstances surrounding these examinations, the impact is not currently quantifiable.

[0000833444-25-000063:notes:149]
[same as prior period, unchanged from 0000833444-25-000032:notes:149]

[0000833444-25-000063:notes:150]
On July 4, 2025, the One Big Beautiful Bill Act (“OBBB”) was signed into law by the president of the United States. It includes a broad range of tax reform provisions affecting businesses, including extending and modifying certain key Tax Cuts & Jobs Act provisions (both U.S. and non-U.S.), and expanding certain Inflation Reduction Act incentives while accelerating the phase-out of others. The Company does not expect the OBBB to have a material impact on tax expense.

[0000833444-25-000063:notes:151]
On December 18, 2023, the president of Ireland signed into law the Finance (No. 2) Bill 2023, which included legislation regarding the implementation of the Pillar Two global minimum tax. The Pillar Two legislation is effective for the Company’s fiscal year beginning October 1, 2024. The impact in the current fiscal year will not be material; however, the Company is continuing to assess the future impact of the new legislation.

[0000833444-25-000063:notes:152]
On September 11, 2023, the Schaffhausen parliament approved a partial revision of the cantonal act on direct taxation: Immediate Minimum Taxation Measure (“IMTM”). On November 19, 2023, IMTM was approved in a public referendum in the canton of Schaffhausen, was published in the cantonal official gazette on December 8, 2023, and was effective starting January 1, 2024. The IMTM increased Switzerland's combined statutory income tax rate to approximately 15%. As a result, in the nine months ended June 30, 2024, the Company recorded a noncash discrete net tax benefit of $80 million due to the remeasurement of deferred tax assets and liabilities related to Switzerland and the canton of Schaffhausen.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-25-000063:notes:153]
SEGMENT INFORMATION
On April 1, 2025, the Company, as part of ongoing initiatives to drive simplification, accelerate growth, better reflect its organizational and operational structure and align with the manner in which the Company's chief operating decision maker assesses performance and makes decisions regarding the allocation of resources following portfolio simplification actions, realigned into three reportable segments (Americas, EMEA and APAC).

[0000833444-25-000063:notes:154]
The Company conducts its business through three operating segments, all of which are reportable segments:

[0000833444-25-000063:notes:155]
•Americas, which designs, manufactures, sells, installs and services HVAC, controls, building management, refrigeration, integrated electronic security systems, integrated fire detection and suppression systems, and digital (software) solutions for commercial, industrial, data center, institutional and governmental customers in the Americas (United States, Canada, and Latin America – Central and South America). Americas also provides energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and control systems, as well as data-driven "smart building" solutions, to the Americas marketplace.

[0000833444-25-000063:notes:156]
•EMEA, which designs, manufactures sells, installs and services HVAC, controls, building management, refrigeration, integrated electronic security systems, integrated fire detection and suppression systems, and digital (software) solutions for commercial, residential security (Global Subscriber business), industrial, data center, institutional, governmental, and marine customers and provides technical services, including data-driven “smart building” solutions, to markets in Europe, the Middle East and Africa.

[0000833444-25-000063:notes:157]
•APAC, which designs, manufactures, sells, installs, and services HVAC, controls, building management, refrigeration, integrated electronic security systems, integrated fire detection and suppression systems, and digital (software) solutions for commercial, industrial, data center, institutional, and governmental customers and provides technical services, including data-driven “smart building” solutions, to the Asian and Pacific marketplace.

[0000833444-25-000063:notes:158]
[same as prior period, unchanged from 0000833444-25-000032:notes:166]

[0000833444-25-000063:notes:159]
[same as prior period, unchanged from 0000833444-25-000032:notes:168]

[0000833444-25-000063:notes:160]
|  | Net Sales |
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Americas | $ | 4,042 |  |  | $ | 4,035 |  |  | $ | 11,506 |  |  | $ | 11,341 |  |
| EMEA | 1,273 |  |  | 1,177 |  |  | 3,631 |  |  | 3,440 |  |
| APAC | 737 |  |  | 686 |  |  | 2,017 |  |  | 1,923 |  |
| Total net sales | $ | 6,052 |  |  | $ | 5,898 |  |  | $ | 17,154 |  |  | $ | 16,704 |  |

[0000833444-25-000063:notes:161]
|  | Segment EBITA |
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Americas | $ | 742 |  |  | $ | 804 |  |  | $ | 2,038 |  |  | $ | 1,853 |  |
| EMEA | 177 |  |  | 154 |  |  | 448 |  |  | 397 |  |
| APAC | 143 |  |  | 128 |  |  | 337 |  |  | 320 |  |
| Total segment EBITA | 1,062 |  |  | 1,086 |  |  | 2,823 |  |  | 2,570 |  |
| Corporate expenses | 141 |  |  | 128 |  |  | 498 |  |  | 359 |  |
| Amortization of intangible assets | 110 |  |  | 116 |  |  | 342 |  |  | 357 |  |
| Restructuring and impairment costs | 51 |  |  | 103 |  |  | 146 |  |  | 377 |  |
| Water systems AFFF settlement (1) | — |  |  | — |  |  | — |  |  | 750 |  |
| Water systems AFFF insurance recoveries (1) | (1) |  |  | (351) |  |  | (13) |  |  | (351) |  |
| Net mark-to-market gains | (21) |  |  | (5) |  |  | (7) |  |  | (42) |  |
| Net financing charges | 77 |  |  | 70 |  |  | 243 |  |  | 246 |  |
| Income before income taxes | $ | 705 |  |  | $ | 1,025 |  |  | $ | 1,614 |  |  | $ | 874 |  |

[0000833444-25-000063:notes:162]
(1) Refer to Note 18, "Commitments and Contingencies," of the notes to the consolidated financial statements for further disclosure related to the water systems AFFF settlement.


## us-gaap:GuaranteesTextBlock

[0000833444-25-000063:notes:163]
[same as prior period, unchanged from 0000833444-25-000032:notes:172]

[0000833444-25-000063:notes:164]
[same as prior period, unchanged from 0000833444-25-000032:notes:173]

[0000833444-25-000063:notes:165]
[same as prior period, unchanged from 0000833444-25-000032:notes:174]

[0000833444-25-000063:notes:166]
[same as prior period, unchanged from 0000833444-25-000032:notes:175]

[0000833444-25-000063:notes:167]
| Balance at September 30, 2024 | $ | 122 |  |
| Accruals for warranties issued during the period | 77 |  |
| Settlements made during the period | (81) |  |
| Changes in estimates to pre-existing warranties | 2 |  |
| Balance at June 30, 2025 | $ | 120 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-25-000063:notes:168]
COMMITMENTS AND CONTINGENCIES
Environmental Matters

[0000833444-25-000063:notes:169]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. The following table presents the location and amount of reserves for environmental liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-25-000063:notes:170]
|  | June 30, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 23 |  |  | $ | 32 |  |
| Other noncurrent liabilities | 170 |  |  | 179 |  |
| Total reserves for environmental liabilities | $ | 193 |  |  | $ | 211 |  |

[0000833444-25-000063:notes:171]
The Company periodically examines whether the contingent liabilities related to the environmental matters described below are probable and reasonably estimable based on experience and ongoing developments in those matters, including continued study and analysis of ongoing remediation obligations. The Company expects that it will pay the amounts recorded over an estimated period of up to 20 years. The Company is not able to estimate a possible loss or range of loss, if any, in excess of the established accruals for environmental liabilities at this time.

[0000833444-25-000063:notes:172]
A substantial portion of the Company's environmental reserves relates to ongoing long-term remediation efforts to address contamination relating to Aqueous Film Forming Foam ("AFFF") containing perfluorooctane sulfonate ("PFOS"), perfluorooctanoic acid ("PFOA"), and/or other per- and poly-fluoroalkyl substances ("PFAS") at or near the Tyco Fire Products L.P. (“Tyco Fire Products”) Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin, as well as the continued remediation of PFAS, arsenic and

[0000833444-25-000063:notes:173]
other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). During the three months ended June 30, 2024, Tyco Fire Products completed its previously announced plan to discontinue the production and sale of fluorinated firefighting foams, including AFFF products, and has transitioned to non-fluorinated foam alternatives.

[0000833444-25-000063:notes:174]
PFOA, PFOS, and other PFAS compounds are being studied by the U.S. Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. In April 2024, EPA published National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR established legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion ("ppt") for each of PFOA and PFOS, 10 ppt for each of PFHxS, PFNA, and HFPO-DA (commonly known as GenX Chemicals), and a Hazard Index of one for mixtures containing two or more of PFHxS, PFNA, HFPO-DA, and PFBS. In February 2024, EPA released two proposed rules relating to PFAS under the Resource Conservation and Recovery Act (“RCRA”): one rule proposes to list nine PFAS (including PFOA and PFOS) as “hazardous constituents,” and a second rule proposes to clarify that hazardous waste regulated under the rule includes not only substances listed or identified as hazardous waste in the regulations, but also any substances that meet the statutory definition of hazardous waste. In April 2024, EPA finalized a rule designating PFOA and PFOS, along with their salts and structural isomers, as "hazardous substances" under the Comprehensive Environmental Response, Compensation and Liability Act ("CERCLA"). In May 2025, EPA announced that it will retain the 4.0 ppt limit on PFOS and PFOA but will institute a two-year delay in the compliance deadline from 2029 until 2031. EPA also announced its intent to rescind and reconsider the limits on four other types of PFAS (PFHxS, PFNA, HFPO-DA, and PFBS).

[0000833444-25-000063:notes:175]
It is not possible to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in soil, groundwater and drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

[0000833444-25-000063:notes:176]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $7 million at both June 30, 2025 and September 30, 2024.

[0000833444-25-000063:notes:177]
FTC-Related Matters

[0000833444-25-000063:notes:178]
FTC and Stanton Street Remediation

[0000833444-25-000063:notes:179]
The use of fire-fighting foams at the FTC was primarily for training and testing purposes to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere.

[0000833444-25-000063:notes:180]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”), manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the EPA to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities

[0000833444-25-000063:notes:181]
completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation and ongoing operation and monitoring of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. In addition to ongoing remediation activities, the Company is also working with the Wisconsin Department of Natural Resources ("WDNR") to investigate and remediate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation and remediation of PFAS in the Marinette region.

[0000833444-25-000063:notes:182]
Tyco Fire Products is operating and monitoring at the FTC a Groundwater Extraction and Treatment System ("GETS"), a permanent groundwater remediation system that extracts groundwater containing PFAS, treats it using advanced filtration systems, and returns the treated water to the environment. Tyco Fire Products has also completed the removal and disposal of PFAS-affected soil from the FTC. The Company is also continuing to replace private drinking water wells that may have been impacted by PFAS migrating from the FTC. The Company's reserves for continued remediation of the FTC, the Stanton Street Facility and surrounding areas in Marinette and Peshtigo are based on estimates of costs associated with the long-term remediation actions, including the continued operation of the GETS, the implementation of long-term drinking water solutions for the area impacted by groundwater migrating from the FTC, continued monitoring and testing of groundwater monitoring wells, the operation and wind-down of other legacy remediation and treatment systems and the completion of ongoing investigation obligations.

[0000833444-25-000063:notes:183]
FTC-Related Litigation

[0000833444-25-000063:notes:184]
Wisconsin approved final regulatory standards for PFOA and PFOS in drinking water and surface water in February 2022. In August 2024, WDNR issued a new proposed rule to adopt the EPA Maximum Contaminant Levels for PFAS in drinking water. In February 2025, the Wisconsin Department of Health Services ("WDHS") recommended individual groundwater enforcement standards of 4 ng/L for PFOA and PFOS, 10 ng/L for PFHxS, PFNA, and HFPO-DA, and 2,000 ng/L for PFBS. Following the February 2025 WDHS recommendation, the WDNR Secretary and the Governor signed the WDNR scope statement and WDNR is in the early stages of rule development for enforcement standards for these six PFAS constituents.

[0000833444-25-000063:notes:185]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers. On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 2019 letter. In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area. In September 2021, the WDNR sent an additional “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids, which reviewed and responded to the Company’s biosolids investigation conducted to that date. On April 10, 2023, the WDNR issued a third “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. concerning land-applied biosolids in the Marinette region. Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations. The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions, including the potential assessment of penalties.

[0000833444-25-000063:notes:186]
In March 2022, the Wisconsin Department of Justice (“WDOJ”) filed a civil enforcement action against Johnson Controls Inc. and Tyco Fire Products in Wisconsin state court relating to environmental matters at the FTC (State of Wisconsin v. Tyco Fire Products, LP and Johnson Controls, Inc., Case No. 22-CX-1 (filed March 14, 2022 in Circuit Court in Marinette County, Wisconsin)). The WDOJ alleges that the Company failed to timely report the presence of PFAS chemicals at the FTC, and that the Company has not sufficiently investigated or remediated PFAS at or near the FTC. The WDOJ seeks monetary penalties and an injunction ordering these two subsidiaries to complete a site investigation and cleanup of PFAS contamination in accordance with the WDNR's requests. The parties have completed briefing of summary judgment and pretrial motions. The Court has continued the trial previously scheduled for March 3, 2025 and has not yet set a new trial date.

[0000833444-25-000063:notes:187]
In October 2022, the Town of Peshtigo filed a tort action in Wisconsin state court against Tyco Fire Products, Johnson Controls Inc., Chemguard, Inc., and ChemDesign, Inc. relating to environmental matters at the FTC (Town of Peshtigo v.

[0000833444-25-000063:notes:188]
Tyco Fire Products L.P. et al., Case No. 2022CV000234 (filed October 18, 2022 in Circuit Court in Marinette County, Wisconsin)). The Town alleges that use of AFFF products at the FTC caused contamination of water supplies in Peshtigo. The Town seeks monetary penalties and an injunction ordering abatement of PFAS contamination in Peshtigo. The case has been removed to federal court and transferred to a multi-district litigation ("MDL") before the United States District Court for the District of South Carolina.

[0000833444-25-000063:notes:189]
In November 2022, individuals filed six actions in Dane County, Wisconsin alleging personal injury and/or property damage against Tyco Fire Products, Johnson Controls Inc., Chemguard, and other unaffiliated defendants related to environmental matters at the FTC. Plaintiffs allege that use of AFFF products at the FTC and activities by third parties unrelated to the Company contaminated nearby drinking water sources, surface waters, and other natural resources and properties, including their personal properties. The individuals seek monetary damages for their personal injury and/or property damage. These lawsuits have been transferred to the MDL. Subsequently, several additional plaintiffs have direct-filed in the MDL complaints with similar allegations.

[0000833444-25-000063:notes:190]
The Company is vigorously defending each of these cases and believes that it has meritorious defenses, but it is presently unable to predict the duration, scope, or outcome of these actions.

[0000833444-25-000063:notes:191]
Aqueous Film-Forming Foam ("AFFF") Matters

[0000833444-25-000063:notes:192]
AFFF Litigation

[0000833444-25-000063:notes:193]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-25-000063:notes:194]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to the MDL. Additional cases have been identified for transfer to or are being directly filed in the MDL.

[0000833444-25-000063:notes:195]
AFFF Municipal and Water Provider Cases

[0000833444-25-000063:notes:196]
Chemguard and Tyco Fire Products have been named as defendants in more than 260 cases in federal and state courts involving municipal or water provider plaintiffs that were filed in state or federal courts originating from 34 states and territories. The decrease in water provider actions during the three months ended June 30, 2025 reflects dismissals resulting from the water systems AFFF settlement agreement discussed further below. More water provider cases may be dismissed pursuant to the water systems AFFF settlement agreement. The vast majority of these cases have been transferred to or were directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal and water provider plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells and/or other public property, allegedly requiring remediation.

[0000833444-25-000063:notes:197]
Tyco Fire Products and Chemguard are also periodically notified by other municipal entities that those entities may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-25-000063:notes:198]
Water Systems AFFF Settlement Agreement

[0000833444-25-000063:notes:199]
On April 12, 2024, Tyco Fire Products agreed to a settlement with a nationwide class of public water systems that detected PFAS in their drinking water systems that they allege to be associated with the use of AFFF. Under the terms of the agreement, Tyco Fire Products agreed to contribute $750 million to resolve these PFAS claims. The settlement releases these claims against Tyco Fire Products, Chemguard, and other related corporate entities. On November 22, 2024, the Court entered final approval of the settlement agreement. In accordance with the terms of the settlement agreement, Tyco Fire Products made its final required payment of $415 million in December 2024 and has now paid the full settlement amount.

[0000833444-25-000063:notes:200]
The class of public water systems included in this settlement broadly includes any public water system (as defined in the settlement agreement) that has detected PFAS in its drinking water sources as of May 15, 2024. The following systems are excluded from the settlement class: water systems owned and operated by a State or the United States government; systems that have not detected the presence of PFAS as of May 15, 2024; small transient water systems; privately-owned drinking water wells; and the water system in the city of Marinette, Wisconsin (which is included only if it so requests). The settlement does not resolve claims of public water systems that request exclusion from the class (“opt out”) pursuant to the process to be established by the MDL court. It also does not resolve potential future claims of public water systems that detect PFAS in their water systems for the first time after May 15, 2024, or certain claims not related to drinking water, such as separate alleged claims relating to real property damage or stormwater or wastewater treatment. Finally, this settlement does not affect the other categories of cases that remain at issue in the MDL, such as personal injury cases, property damage cases, other types of class actions, claims brought by state or territory attorneys general, or other types of damages alleged to be related to the historic use of AFFF manufactured and sold by Tyco Fire Products and Chemguard. While it is reasonably possible that the excluded systems or claims could result in additional future lawsuits, claims, assessments or proceedings, it is not possible to predict the outcome of any such matters, and as such, the Company is unable to develop an estimate of a possible loss or range of losses, if any, at this time.

[0000833444-25-000063:notes:201]
The settlement does not constitute an admission of liability or wrongdoing by Tyco Fire Products or Chemguard.

[0000833444-25-000063:notes:202]
AFFF Putative Class Actions

[0000833444-25-000063:notes:203]
Chemguard and Tyco Fire Products are named in 45 pending putative class actions in federal courts originating from 20 states and territories. The decrease in putative class actions during the three months ended June 30, 2025 reflects dismissals resulting from the water systems AFFF settlement agreement. All of these cases have been direct-filed in or transferred to the MDL. In addition, six proposed class actions were filed in Canada (British Columbia, Manitoba, Quebec and Ontario), which name Tyco Fire Products and other manufacturers as defendants, on behalf of various classes of members (including individuals and government entities) who seek to recover for remediation (past and future) costs, claim property or other environmental damages, or claim personal injuries or other harms arising from alleged exposure to or contamination with PFAS or PFAS-containing products (including AFFF).

[0000833444-25-000063:notes:204]
AFFF Individual or Mass Actions

[0000833444-25-000063:notes:205]
There are more than 9,900 individual or “mass” actions pending that were filed in state or federal courts originating from 52 states and territories against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve plaintiffs from various states including approximately 7,000 plaintiffs in Colorado and more than 9,900 other plaintiffs. The vast majority of these matters have been tagged for transfer to, transferred to, or directly-filed in the MDL, and it is anticipated that several newly-filed state court actions will be similarly tagged and transferred. There are several matters that are proceeding in state courts, including actions in Arizona and Illinois.

[0000833444-25-000063:notes:206]
Tyco and Chemguard are also periodically notified by other individuals that they may assert claims regarding PFOS and/or PFOA contamination allegedly resulting from the use of AFFF.

[0000833444-25-000063:notes:207]
AFFF State or U.S. Territory Attorneys General Litigation

[0000833444-25-000063:notes:208]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-25-000063:notes:209]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL. In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-25-000063:notes:210]
In April 2021, the State of Alaska filed a lawsuit in the superior court of the State of Alaska against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State. The State’s case has been removed to federal court and transferred to the MDL. The State of Alaska has also named a number of manufacturers and other defendants, including affiliates of the Company, as third-party defendants in two cases brought by individuals against the State. These two cases have also been transferred to the MDL.

[0000833444-25-000063:notes:211]
In early November 2021, the Attorney General of the State of North Carolina filed four individual lawsuits in the superior courts of the State of North Carolina against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFOS and PFOA damage of the State’s land, natural resources, and property allegedly resulting from the use of firefighting foams at four separate locations throughout the State. These four cases have been removed to federal court and transferred to the MDL. In October 2022, the Attorney General filed two similar lawsuits in the superior courts of the State of North Carolina regarding alleged PFAS damages at two additional locations. These two cases have also been removed to federal court and transferred to the MDL.

[0000833444-25-000063:notes:212]
In addition, 33 other states and territories have filed 35 lawsuits against a number of manufacturers and other defendants, including affiliates of the Company, with respect to PFAS damage of each of those State's environmental and natural resources allegedly resulting from the manufacture, storage, sale, distribution, marketing, and use of PFAS-containing AFFF within each respective State. The states and territories are: Arkansas, Arizona, California, Colorado, Connecticut, Delaware, the District of Columbia, Florida, Hawaii, Illinois, Indiana, Kentucky, Massachusetts, Maryland, Maine, Michigan, Mississippi, New Hampshire, New Jersey, New Mexico, Ohio, Oklahoma, Oregon, Rhode Island, South Carolina, Tennessee, Texas, Vermont, Washington, Wisconsin, Guam, the Northern Mariana Islands, and Puerto Rico. All of these complaints, if not filed directly in the MDL, have been removed to federal court and transferred to the MDL.

[0000833444-25-000063:notes:213]
Other AFFF Related Matters

[0000833444-25-000063:notes:214]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and

[0000833444-25-000063:notes:215]
disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington. This case has been transferred to the MDL.

[0000833444-25-000063:notes:216]
In October 2022, the Red Cliff Band of Lake Superior Chippewa Indians (a federally recognized tribe) filed a lawsuit in the United States District Court for the Western District of Wisconsin against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota. This complaint has been transferred to the MDL.

[0000833444-25-000063:notes:217]
In July 2023, the Fond du Lac Band of Lake Superior Chippewa (a federally recognized tribe) direct-filed a lawsuit in the MDL against a number of manufacturers, including affiliates of the Company, with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF at Duluth Air National Guard Base in Duluth, Minnesota.

[0000833444-25-000063:notes:218]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin. The insurance litigation involves numerous factual and legal issues. There are numerous factual and legal issues to be resolved in connection with these claims. The Company is presently unable to predict the outcome or ultimate financial exposure beyond the water systems AFFF settlement discussed above, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

[0000833444-25-000063:notes:219]
Asbestos Matters

[0000833444-25-000063:notes:220]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-25-000063:notes:221]
The following table presents the location and amount of asbestos-related assets and liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-25-000063:notes:222]
|  | June 30, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 337 |  |  | 350 |  |
| Total asbestos-related liabilities | 395 |  |  | 408 |  |
| Other current assets | 14 |  |  | 14 |  |
| Other noncurrent assets | 314 |  |  | 320 |  |
| Total asbestos-related assets | 328 |  |  | 334 |  |
| Net asbestos-related liabilities | $ | 67 |  |  | $ | 74 |  |

[0000833444-25-000063:notes:223]
The following table presents the components of asbestos-related assets (in millions):

[0000833444-25-000063:notes:224]
|  | June 30, 2025 |  | September 30, 2024 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 6 |  |
| Investments | 278 |  |  | 281 |  |
| Total restricted assets | 284 |  |  | 287 |  |
| Insurance receivables for asbestos-related liabilities | 44 |  |  | 47 |  |
| Total asbestos-related assets | $ | 328 |  |  | $ | 334 |  |

[0000833444-25-000063:notes:225]
The amounts recorded for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-25-000063:notes:226]
Self-Insured Liabilities

[0000833444-25-000063:notes:227]
The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. The Company maintains captive insurance companies to manage a portion of its insurable liabilities.

[0000833444-25-000063:notes:228]
The following table presents the location and amount of self-insured liabilities in the Company's consolidated statements of financial position (in millions):

[0000833444-25-000063:notes:229]
|  | June 30, 2025 |  | September 30, 2024 |
| Other current liabilities | $ | 96 |  |  | $ | 92 |  |
| Accrued compensation and benefits | 32 |  |  | 20 |  |
| Other noncurrent liabilities | 256 |  |  | 239 |  |
| Total self-insured liabilities | $ | 384 |  |  | $ | 351 |  |

[0000833444-25-000063:notes:230]
The following table presents the location and amount of insurance receivables in the Company's consolidated statements of financial position (in millions):

[0000833444-25-000063:notes:231]
|  | June 30, 2025 |  | September 30, 2024 |
| Other current assets | $ | 5 |  |  | $ | 5 |  |
| Other noncurrent assets | 13 |  |  | 13 |  |
| Total insurance receivables | $ | 18 |  |  | $ | 18 |  |

[0000833444-25-000063:notes:232]
Other Matters

[0000833444-25-000063:notes:233]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to the Company, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.
