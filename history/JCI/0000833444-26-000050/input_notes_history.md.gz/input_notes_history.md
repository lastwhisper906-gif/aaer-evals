# JCI note change history — 0000833444-26-000019 → 0000833444-26-000050


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0000833444-26-000050:note_history:1]
|  | March 31, 2026 |  | September 30, 2025 |
| Other current liabilities | $ | 23 |  |  | $ | 27 |  |
| Other noncurrent liabilities | 152 |  |  | 160 |  |
| Total reserves for environmental liabilities | $ | 175 |  |  | $ | 187 |  |
  (was, 2026-02-04, similarity 0.9731):
[0000833444-26-000019:note_history:1]
|  | December 31, 2025 |  | September 30, 2025 |
| Other current liabilities | $ | 24 |  |  | $ | 27 |  |
| Other noncurrent liabilities | 156 |  |  | 160 |  |
| Total reserves for environmental liabilities | $ | 180 |  |  | $ | 187 |  |

- changed (2026-05-06):
[0000833444-26-000050:note_history:2]
PFOA, PFOS, and other PFAS compounds are being studied by the U.S. Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. In April 2024, EPA published National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR established legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion ("ppt") for each of PFOA and PFOS, 10 ppt for each of PFHxS, PFNA, and HFPO-DA (commonly known as GenX Chemicals), and a Hazard Index of one for mixtures containing two or more of PFHxS, PFNA, HFPO-DA, and PFBS. In February 2024, EPA released two proposed rules relating to PFAS under the Resource Conservation and Recovery Act (“RCRA”): one rule proposes to list nine PFAS (including PFOA and PFOS) as “hazardous constituents,” and a second rule proposes to clarify that hazardous waste regulated under the rule includes not only substances listed or identified as hazardous waste in the regulations, but also any substances that meet the statutory definition of hazardous waste. In April 2024, EPA finalized a rule designating PFOA and PFOS, along with their salts and structural isomers, as "hazardous substances" under the Comprehensive Environmental Response, Compensation and Liability Act ("CERCLA"). In May 2025, EPA announced that it will retain the 4.0 ppt limit on PFOS and PFOA but will institute a two-year delay in the compliance deadline from 2029 until 2031. EPA also announced its intent to rescind and reconsider the limits on four other types of PFAS (PFHxS, PFNA, HFPO-DA, and PFBS). In February 2026, EPA sent to the White House Office of Management & Budget a proposed rule to rescind the Maximum Contaminant Levels for these four other types of PFAS.
  (was, 2026-02-04, similarity 0.9502):
[0000833444-26-000019:note_history:2]
PFOA, PFOS, and other PFAS compounds are being studied by the U.S. Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. In April 2024, EPA published National Primary Drinking Water Regulation (“NPDWR”) for six PFAS compounds including PFOA and PFOS. The NPDWR established legally enforceable levels, called Maximum Contaminant Levels, of 4.0 parts per trillion ("ppt") for each of PFOA and PFOS, 10 ppt for each of PFHxS, PFNA, and HFPO-DA (commonly known as GenX Chemicals), and a Hazard Index of one for mixtures containing two or more of PFHxS, PFNA, HFPO-DA, and PFBS. In February 2024, EPA released two proposed rules relating to PFAS under the Resource Conservation and Recovery Act (“RCRA”): one rule proposes to list nine PFAS (including PFOA and PFOS) as “hazardous constituents,” and a second rule proposes to clarify that hazardous waste regulated under the rule includes not only substances listed or identified as hazardous waste in the regulations, but also any substances that meet the statutory definition of hazardous waste. In April 2024, EPA finalized a rule designating PFOA and PFOS, along with their salts and structural isomers, as "hazardous substances" under the Comprehensive Environmental Response, Compensation and Liability Act ("CERCLA"). In May 2025, EPA announced that it will retain the 4.0 ppt limit on PFOS and PFOA but will institute a two-year delay in the compliance deadline from 2029 until 2031. EPA also announced its intent to rescind and reconsider the limits on four other types of PFAS (PFHxS, PFNA, HFPO-DA, and PFBS).

- changed (2026-05-06):
[0000833444-26-000050:note_history:3]
It is not possible to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in soil, groundwater and drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the
  (was, 2026-02-04, similarity 0.7257):
[0000833444-26-000019:note_history:3]
It is not possible to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the financial viability of other potentially responsible parties and third-party indemnitors, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, changes in environmental regulations, changes in permissible levels of specific compounds in soil, groundwater and drinking water sources, or changes in enforcement theories and policies, including efforts to recover natural resource damages, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- added (2026-05-06):
[0000833444-26-000050:note_history:4]
often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows.

- changed (2026-05-06):
[0000833444-26-000050:note_history:5]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $7 million at both March 31, 2026 and September 30, 2025.
  (was, 2026-02-04, similarity 0.9787):
[0000833444-26-000019:note_history:5]
In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. Conditional asset retirement obligations were $7 million at both December 31, 2025 and September 30, 2025.

- changed (2026-05-06):
[0000833444-26-000050:note_history:6]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other
  (was, 2026-02-04, similarity 0.7384):
[0000833444-26-000019:note_history:6]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

- added (2026-05-06):
[0000833444-26-000050:note_history:7]
sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

- changed (2026-05-06):
[0000833444-26-000050:note_history:8]
The class of public water systems included in this settlement broadly includes any public water system (as defined in the settlement agreement) that has detected PFAS in its drinking water sources as of May 15, 2024. The following systems are excluded from the settlement class: water systems owned and operated by a State or the United States government; systems that have not detected the presence of PFAS as of May 15, 2024; small transient water systems; privately-owned drinking water wells; and the water system in the city of Marinette, Wisconsin (which is included only if it so requests). The settlement does not resolve claims of public water systems that request exclusion from the class (“opt out”) pursuant to the process to be established by the MDL court. It also does not resolve potential future claims of public water systems that detect PFAS in their water systems for the first time after May 15, 2024, or certain claims not related to drinking water, such as separate alleged claims relating to real property damage or stormwater or wastewater treatment. Finally, this settlement does not affect the other categories of cases that remain at issue in the MDL, such as personal injury cases, property damage cases, other types of class actions, claims brought by state or territory attorneys general, or other types of damages alleged to be related to the historical use of AFFF manufactured and sold by Tyco Fire Products and Chemguard. While it is reasonably possible that the excluded systems or claims could result in additional future lawsuits, claims, assessments or proceedings, it is not possible to predict the outcome of any such matters, and as such, the Company is unable to develop an estimate of a possible loss or range of losses, if any, at this time.
  (was, 2026-02-04, similarity 0.8546):
[0000833444-26-000019:note_history:8]
The class of public water systems included in this settlement broadly includes any public water system (as defined in the settlement agreement) that has detected PFAS in its drinking water sources as of May 15, 2024. The following systems are excluded from the settlement class: water systems owned and operated by a State or the United States government; systems that have not detected the presence of PFAS as of May 15, 2024; small transient water systems; privately-owned drinking water wells; and the water system in the city of Marinette, Wisconsin (which is included only if it so requests). The settlement does not resolve claims of public water systems that request exclusion from the class (“opt out”) pursuant to the process to be established by the MDL court. It also does not resolve potential future claims of public water systems that detect PFAS in their water systems for the first time after May 15, 2024, or certain claims not related to drinking water, such as separate alleged claims relating to real property damage or stormwater or wastewater treatment. Finally, this settlement does not affect the other categories of cases that remain at issue in the MDL, such as personal injury cases, property damage cases, other types of class actions, claims brought by state or territory attorneys general, or other types of

- changed (2026-05-06):
[0000833444-26-000050:note_history:9]
Chemguard and Tyco Fire Products are named in 50 pending putative class actions in federal courts originating from 21 states and territories. All of these cases have been direct-filed in or transferred to the MDL. In addition, six proposed class actions were filed in Canada (British Columbia, Manitoba, Quebec and Ontario), which name Tyco Fire Products and other manufacturers as defendants, on behalf of various classes of members (including individuals and government entities) who seek to recover for remediation (past and future) costs, claim property or other environmental damages, or claim personal injuries or other harms arising from alleged exposure to or contamination with PFAS or PFAS-containing products (including AFFF).
  (was, 2026-02-04, similarity 0.9959):
[0000833444-26-000019:note_history:9]
Chemguard and Tyco Fire Products are named in 49 pending putative class actions in federal courts originating from 21 states and territories. All of these cases have been direct-filed in or transferred to the MDL. In addition, seven proposed class actions were filed in Canada (British Columbia, Manitoba, Quebec and Ontario), which name Tyco Fire Products and other manufacturers as defendants, on behalf of various classes of members (including individuals and government entities) who seek to recover for remediation (past and future) costs, claim property or other environmental damages, or claim personal injuries or other harms arising from alleged exposure to or contamination with PFAS or PFAS-containing products (including AFFF).

- changed (2026-05-06):
[0000833444-26-000050:note_history:10]
In addition, an affiliate of the Company has been named with other manufacturers as a third party by the Canadian Federal Government who is seeking contribution and indemnity in respect of seven single-plaintiff actions filed in Ontario relating to alleged PFAS and benzene contamination of a private well from the use of AFFF in firefighting training.
  (was, 2026-02-04, similarity 0.701):
[0000833444-26-000019:note_history:10]
In addition, an affiliate of the Company has been named with other manufacturers as a third party by the Canadian Federal Government who is seeking contribution and indemnity in respect of a single-plaintiff action filed in Ontario relating to alleged PFAS and benzene contamination of a private well from the use of AFFF in firefighting training.

- changed (2026-05-06):
[0000833444-26-000050:note_history:11]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin. The Company has reached settlements with certain insurers and remains in discussions and litigation with the remaining carriers. In the first six months of fiscal year 2026, the Company recorded
  (was, 2026-02-04, similarity 0.6206):
[0000833444-26-000019:note_history:11]
The Company is vigorously defending all of the above AFFF matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The Company has a historical general liability insurance program and is pursuing coverage under the program from various insurers through insurance claims discussions and litigation pending in a state court in Wisconsin. The Company has reached settlements with certain insurers and remains in discussions and litigation with the remaining carriers. In the first quarter of fiscal year 2026, the Company recorded $130 million of insurance recoveries related to settlements with its insurance carriers in selling, general and administrative expenses in the consolidated statements of income. The Company is unable to predict the amount and timing of any future recoveries under its insurance policies with the remaining carriers. The insurance litigation involves numerous factual and legal issues. There are numerous factual and legal issues to be resolved in connection with these claims. The Company is presently unable to predict the outcome or ultimate financial exposure beyond the water systems AFFF settlement discussed above, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

- added (2026-05-06):
[0000833444-26-000050:note_history:12]
approximately $131 million of insurance recoveries related to settlements with its insurance carriers in selling, general and administrative expenses in the consolidated statements of income. The Company is unable to predict the amount and timing of any future recoveries under its insurance policies with the remaining carriers. The insurance litigation involves numerous factual and legal issues. There are numerous factual and legal issues to be resolved in connection with these claims. The Company is presently unable to predict the outcome or ultimate financial exposure beyond the water systems AFFF settlement discussed above, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

- added (2026-05-06):
[0000833444-26-000050:note_history:13]
|  | March 31, 2026 |  | September 30, 2025 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 328 |  |  | 329 |  |
| Total asbestos-related liabilities | 386 |  |  | 387 |  |
| Other current assets | 14 |  |  | 13 |  |
| Other noncurrent assets | 310 |  |  | 326 |  |
| Total asbestos-related assets | 324 |  |  | 339 |  |
| Net asbestos-related liabilities | $ | 62 |  |  | $ | 48 |  |

- added (2026-05-06):
[0000833444-26-000050:note_history:14]
|  | March 31, 2026 |  | September 30, 2025 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 5 |  |
| Investments | 276 |  |  | 290 |  |
| Total restricted assets | 282 |  |  | 295 |  |
| Insurance receivables for asbestos-related liabilities | 42 |  |  | 44 |  |
| Total asbestos-related assets | $ | 324 |  |  | $ | 339 |  |

- changed (2026-05-06):
[0000833444-26-000050:note_history:15]
The amounts recorded for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.
  (was, 2026-02-04, similarity 0.8066):
[0000833444-26-000019:note_history:15]
The amounts recorded for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to

- changed (2026-05-06):
[0000833444-26-000050:note_history:16]
|  | March 31, 2026 |  | September 30, 2025 |
| Other current liabilities | $ | 84 |  |  | $ | 87 |  |
| Accrued compensation and benefits | 38 |  |  | 38 |  |
| Other noncurrent liabilities | 316 |  |  | 289 |  |
| Total self-insured liabilities | $ | 438 |  |  | $ | 414 |  |
  (was, 2026-02-04, similarity 0.9773):
[0000833444-26-000019:note_history:16]
|  | December 31, 2025 |  | September 30, 2025 |
| Other current liabilities | $ | 89 |  |  | $ | 87 |  |
| Accrued compensation and benefits | 38 |  |  | 38 |  |
| Other noncurrent liabilities | 311 |  |  | 289 |  |
| Total self-insured liabilities | $ | 438 |  |  | $ | 414 |  |

- removed (2026-05-06):
[0000833444-26-000019:note_history:17]
damages alleged to be related to the historical use of AFFF manufactured and sold by Tyco Fire Products and Chemguard. While it is reasonably possible that the excluded systems or claims could result in additional future lawsuits, claims, assessments or proceedings, it is not possible to predict the outcome of any such matters, and as such, the Company is unable to develop an estimate of a possible loss or range of losses, if any, at this time.

- removed (2026-05-06):
[0000833444-26-000019:note_history:18]
|  | December 31, 2025 |  | September 30, 2025 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 336 |  |  | 329 |  |
| Total asbestos-related liabilities | 394 |  |  | 387 |  |
| Other current assets | 14 |  |  | 13 |  |
| Other noncurrent assets | 326 |  |  | 326 |  |
| Total asbestos-related assets | 340 |  |  | 339 |  |
| Net asbestos-related liabilities | $ | 54 |  |  | $ | 48 |  |

- removed (2026-05-06):
[0000833444-26-000019:note_history:19]
|  | December 31, 2025 |  | September 30, 2025 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 5 |  |
| Investments | 291 |  |  | 290 |  |
| Total restricted assets | 297 |  |  | 295 |  |
| Insurance receivables for asbestos-related liabilities | 43 |  |  | 44 |  |
| Total asbestos-related assets | $ | 340 |  |  | $ | 339 |  |

- removed (2026-05-06):
[0000833444-26-000019:note_history:20]
jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0000833444-26-000050:note_history:21]
|  | March 31, 2026 |  | September 30, 2025 |
| Other current liabilities | $ | 23 |  |  | $ | 27 |  |
| Other noncurrent liabilities | 152 |  |  | 160 |  |
| Total reserves for environmental liabilities | $ | 175 |  |  | $ | 187 |  |
  (was, 2026-02-04, similarity 0.9731):
[0000833444-26-000019:note_history:21]
|  | December 31, 2025 |  | September 30, 2025 |
| Other current liabilities | $ | 24 |  |  | $ | 27 |  |
| Other noncurrent liabilities | 156 |  |  | 160 |  |
| Total reserves for environmental liabilities | $ | 180 |  |  | $ | 187 |  |

- added (2026-05-06):
[0000833444-26-000050:note_history:22]
|  | March 31, 2026 |  | September 30, 2025 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 328 |  |  | 329 |  |
| Total asbestos-related liabilities | 386 |  |  | 387 |  |
| Other current assets | 14 |  |  | 13 |  |
| Other noncurrent assets | 310 |  |  | 326 |  |
| Total asbestos-related assets | 324 |  |  | 339 |  |
| Net asbestos-related liabilities | $ | 62 |  |  | $ | 48 |  |

- added (2026-05-06):
[0000833444-26-000050:note_history:23]
|  | March 31, 2026 |  | September 30, 2025 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 5 |  |
| Investments | 276 |  |  | 290 |  |
| Total restricted assets | 282 |  |  | 295 |  |
| Insurance receivables for asbestos-related liabilities | 42 |  |  | 44 |  |
| Total asbestos-related assets | $ | 324 |  |  | $ | 339 |  |

- changed (2026-05-06):
[0000833444-26-000050:note_history:24]
|  | March 31, 2026 |  | September 30, 2025 |
| Other current liabilities | $ | 84 |  |  | $ | 87 |  |
| Accrued compensation and benefits | 38 |  |  | 38 |  |
| Other noncurrent liabilities | 316 |  |  | 289 |  |
| Total self-insured liabilities | $ | 438 |  |  | $ | 414 |  |
  (was, 2026-02-04, similarity 0.9773):
[0000833444-26-000019:note_history:24]
|  | December 31, 2025 |  | September 30, 2025 |
| Other current liabilities | $ | 89 |  |  | $ | 87 |  |
| Accrued compensation and benefits | 38 |  |  | 38 |  |
| Other noncurrent liabilities | 311 |  |  | 289 |  |
| Total self-insured liabilities | $ | 438 |  |  | $ | 414 |  |

- removed (2026-05-06):
[0000833444-26-000019:note_history:25]
|  | December 31, 2025 |  | September 30, 2025 |
| Other current liabilities | $ | 58 |  |  | $ | 58 |  |
| Other noncurrent liabilities | 336 |  |  | 329 |  |
| Total asbestos-related liabilities | 394 |  |  | 387 |  |
| Other current assets | 14 |  |  | 13 |  |
| Other noncurrent assets | 326 |  |  | 326 |  |
| Total asbestos-related assets | 340 |  |  | 339 |  |
| Net asbestos-related liabilities | $ | 54 |  |  | $ | 48 |  |

- removed (2026-05-06):
[0000833444-26-000019:note_history:26]
|  | December 31, 2025 |  | September 30, 2025 |
| Restricted |  |  |  |
| Cash | $ | 6 |  |  | $ | 5 |  |
| Investments | 291 |  |  | 290 |  |
| Total restricted assets | 297 |  |  | 295 |  |
| Insurance receivables for asbestos-related liabilities | 43 |  |  | 44 |  |
| Total asbestos-related assets | $ | 340 |  |  | $ | 339 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0000833444-26-000050:note_history:27]
BASIS OF PRESENTATION
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2025 filed with the SEC on November 14, 2025. The results of operations for the three and six month periods ended March 31, 2026 are not necessarily indicative of results for the Company’s 2026 fiscal year because of seasonal and other factors.
  (was, 2026-02-04, similarity 0.9765):
[0000833444-26-000019:note_history:27]
BASIS OF PRESENTATION
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a public limited company organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2025 filed with the SEC on November 14, 2025. The results of operations for the three month period ended December 31, 2025 is not necessarily indicative of results for the Company’s 2026 fiscal year because of seasonal and other factors.

- changed (2026-05-06):
[0000833444-26-000050:note_history:28]
Johnson Controls International plc, headquartered in Cork, Ireland, a global leader in thermal management, mission-critical building systems, energy efficiency, and decarbonization, helps customers use energy more productively, reduce carbon emissions, and operate with the precision and resilience required in rapidly expanding industries such as data centers, healthcare, pharmaceuticals, advanced manufacturing, and higher education.
  (was, 2026-02-04, similarity 0.8392):
[0000833444-26-000019:note_history:28]
Johnson Controls International plc, headquartered in Cork, Ireland, a global technology leader in energy efficiency, decarbonization, thermal management and mission-critical performance, helps customers use energy more productively, reduce carbon emissions, and operate with the precision and resilience required in rapidly expanding industries such as data centers, healthcare, pharmaceuticals, advanced manufacturing, and higher education.

- changed (2026-05-06):
[0000833444-26-000050:note_history:29]
Prior Period Revision – Statement of Cash Flows
Amounts reported as "Repayments of debt" and "Proceeds from debt" have been revised for certain short-term debt transactions that occurred in the six months ended March 31, 2025 and were incorrectly presented on a net basis within the financing activities section of the consolidated statements of cash flows. A similar revision for the nine months ended June 30, 2025 will be included in the Company's third quarter fiscal 2026 Quarterly Report on Form 10-Q. Cash provided by financing activities and the total increase (decrease) in cash, cash equivalents and restricted cash were unchanged for all affected periods. The Company does not consider the incorrect presentation to be material to any periods impacted.
  (was, 2026-02-04, similarity 0.8881):
[0000833444-26-000019:note_history:29]
Prior Period Revision – Statement of Cash Flows
Amounts reported as "Repayments of debt" and "Proceeds from debt" have been revised for certain short-term debt transactions that occurred in the three months ended December 31, 2024 and were incorrectly presented on a net basis within the financing activities section of the consolidated statements of cash flows. A similar revision for the periods ended March 31, 2025 and June 30, 2025 will be included in future Quarterly Reports on Form 10-Q. Cash provided by financing activities and the total increase (decrease) in cash, cash equivalents and restricted cash were unchanged for all affected periods. The Company does not consider the incorrect presentation to be material to any periods impacted.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-05-06):
[0000833444-26-000050:note_history:30]
|  | March 31, 2026 |  | September 30, 2025 |
| Commercial paper | $ | 441 |  |  | $ | 400 |  |
| Term loans | 437 |  |  | 320 |  |
| Bank borrowings | 4 |  |  | 3 |  |
|  | $ | 882 |  |  | $ | 723 |  |
| Weighted average interest rate on short-term debt outstanding | 3.4 | % |  | 4.5 | % |

- changed (2026-05-06):
[0000833444-26-000050:note_history:31]
As of March 31, 2026, the Company had an outstanding syndicated committed revolving credit facility of $2.5 billion which is scheduled to expire in December 2028. There were no draws on the facility as of March 31, 2026.
  (was, 2026-02-04, similarity 0.9171):
[0000833444-26-000019:note_history:31]
As of December 31, 2025, the Company had an outstanding syndicated committed revolving credit facility of $2.5 billion which is scheduled to expire in December 2028. There were no draws on the facility as of December 31, 2025.

- added (2026-05-06):
[0000833444-26-000050:note_history:32]
In February 2026, the Company repaid $538 million of outstanding 3.90% Notes due 2026.

- changed (2026-05-06):
[0000833444-26-000050:note_history:33]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |  |  |
| (in millions) | 2026 |  | 2025 |  | 2026 |  | 2025 |  |  |  |  |  |
| Interest expense, net of capitalized interest costs | $ | 60 |  |  | $ | 56 |  |  | $ | 102 |  |  | $ | 123 |  |  |  |  |  |  |
| Other financing charges | 4 |  |  | 4 |  |  | 11 |  |  | 10 |  |  |  |  |  |  |
| Interest income | (1) |  |  | (2) |  |  | (3) |  |  | (5) |  |  |  |  |  |  |
| Net foreign exchange results for financing activities | 4 |  |  | 22 |  |  | 16 |  |  | 38 |  |  |  |  |  |  |
| Net financing charges | $ | 67 |  |  | $ | 80 |  |  | $ | 126 |  |  | $ | 166 |  |  |  |  |  |  |
  (was, 2026-02-04, similarity 0.7265):
[0000833444-26-000019:note_history:33]
|  | Three Months Ended December 31, |  |
| (in millions) | 2025 |  | 2024 |  |  |  |  |  |  |
| Interest expense, net of capitalized interest costs | $ | 42 |  |  | $ | 67 |  |  |  |  |  |  |  |
| Other financing charges | 7 |  |  | 6 |  |  |  |  |  |  |  |
| Interest income | (2) |  |  | (3) |  |  |  |  |  |  |  |
| Net foreign exchange results for financing activities | 12 |  |  | 16 |  |  |  |  |  |  |  |
| Net financing charges | $ | 59 |  |  | $ | 86 |  |  |  |  |  |  |  |

- changed (2026-05-06):
[0000833444-26-000050:note_history:34]
Net financing charges includes pre-tax gains (losses) on derivatives not designated as hedging instruments of $(33) million and $60 million for the three months ended March 31, 2026 and 2025, respectively, and $(188) million and $(84) million for the six months ended March 31, 2026 and 2025, respectively, which are offset by gains resulting from changes in foreign exchange rates on underlying exposures during those periods.
  (was, 2026-02-04, similarity 0.823):
[0000833444-26-000019:note_history:34]
Net financing charges includes pre-tax losses on derivatives not designated as hedging instruments of $155 million and $144 million for the three months ended December 31, 2025 and 2024, respectively, which are offset by gains resulting from changes in foreign exchange rates on underlying exposures during those periods.

- removed (2026-05-06):
[0000833444-26-000019:note_history:35]
|  | December 31, 2025 |  | September 30, 2025 |
| Commercial paper | $ | 200 |  |  | $ | 400 |  |
| Term loans | 236 |  |  | 320 |  |
| Bank borrowings | — |  |  | 3 |  |
|  | $ | 436 |  |  | $ | 723 |  |
| Weighted average interest rate on short-term debt outstanding | 4.3 | % |  | 4.5 | % |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0000833444-26-000050:note_history:36]
The fair value of long-term debt at March 31, 2026 and September 30, 2025 was as follows (in billions):
  (was, 2026-02-04, similarity 0.9524):
[0000833444-26-000019:note_history:36]
The fair value of long-term debt at December 31, 2025 and September 30, 2025 was as follows (in billions):

- changed (2026-05-06):
[0000833444-26-000050:note_history:37]
|  |  | March 31, |  | September 30, |
|  | 2026 |  | 2025 |
| Public debt |  | $ | 7.7 |  |  | $ | 8.4 |  |
| Other long-term debt |  | 0.5 |  |  | 0.5 |  |
| Total fair value of long-term debt |  | $ | 8.2 |  |  | $ | 8.9 |  |
  (was, 2026-02-04, similarity 0.9764):
[0000833444-26-000019:note_history:37]
|  |  | December 31, |  | September 30, |
|  | 2025 |  | 2025 |
| Public debt |  | $ | 8.4 |  |  | $ | 8.4 |  |
| Other long-term debt |  | 0.6 |  |  | 0.5 |  |
| Total fair value of long-term debt |  | $ | 9.0 |  |  | $ | 8.9 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-05-06):
[0000833444-26-000050:note_history:38]
|  | March 31, 2026 |  | September 30, 2025 |
| Commercial paper | $ | 441 |  |  | $ | 400 |  |
| Term loans | 437 |  |  | 320 |  |
| Bank borrowings | 4 |  |  | 3 |  |
|  | $ | 882 |  |  | $ | 723 |  |
| Weighted average interest rate on short-term debt outstanding | 3.4 | % |  | 4.5 | % |

- changed (2026-05-06):
[0000833444-26-000050:note_history:39]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |  |  |
| (in millions) | 2026 |  | 2025 |  | 2026 |  | 2025 |  |  |  |  |  |
| Interest expense, net of capitalized interest costs | $ | 60 |  |  | $ | 56 |  |  | $ | 102 |  |  | $ | 123 |  |  |  |  |  |  |
| Other financing charges | 4 |  |  | 4 |  |  | 11 |  |  | 10 |  |  |  |  |  |  |
| Interest income | (1) |  |  | (2) |  |  | (3) |  |  | (5) |  |  |  |  |  |  |
| Net foreign exchange results for financing activities | 4 |  |  | 22 |  |  | 16 |  |  | 38 |  |  |  |  |  |  |
| Net financing charges | $ | 67 |  |  | $ | 80 |  |  | $ | 126 |  |  | $ | 166 |  |  |  |  |  |  |
  (was, 2026-02-04, similarity 0.7265):
[0000833444-26-000019:note_history:39]
|  | Three Months Ended December 31, |  |
| (in millions) | 2025 |  | 2024 |  |  |  |  |  |  |
| Interest expense, net of capitalized interest costs | $ | 42 |  |  | $ | 67 |  |  |  |  |  |  |  |
| Other financing charges | 7 |  |  | 6 |  |  |  |  |  |  |  |
| Interest income | (2) |  |  | (3) |  |  |  |  |  |  |  |
| Net foreign exchange results for financing activities | 12 |  |  | 16 |  |  |  |  |  |  |  |
| Net financing charges | $ | 59 |  |  | $ | 86 |  |  |  |  |  |  |  |

- removed (2026-05-06):
[0000833444-26-000019:note_history:40]
|  | December 31, 2025 |  | September 30, 2025 |
| Commercial paper | $ | 200 |  |  | $ | 400 |  |
| Term loans | 236 |  |  | 320 |  |
| Bank borrowings | — |  |  | 3 |  |
|  | $ | 436 |  |  | $ | 723 |  |
| Weighted average interest rate on short-term debt outstanding | 4.3 | % |  | 4.5 | % |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0000833444-26-000050:note_history:41]
The following tables present the Company's revenues disaggregated by segment and by Products & Systems and Services revenue (in millions):
  (was, 2026-02-04, similarity 0.9928):
[0000833444-26-000019:note_history:41]
The following table presents the Company's revenues disaggregated by segment and by Products & Systems and Services revenue (in millions):

- changed (2026-05-06):
[0000833444-26-000050:note_history:42]
|  |  | Three Months Ended March 31, |
|  |  | 2026 |  | 2025 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Americas |  | $ | 2,875 |  |  | $ | 1,246 |  |  | $ | 4,121 |  |  | $ | 2,711 |  |  | $ | 1,126 |  |  | $ | 3,837 |  |
| EMEA |  | 799 |  |  | 483 |  |  | 1,282 |  |  | 721 |  |  | 480 |  |  | 1,201 |  |
| APAC |  | 525 |  |  | 214 |  |  | 739 |  |  | 433 |  |  | 205 |  |  | 638 |  |
| Total |  | $ | 4,199 |  |  | $ | 1,943 |  |  | $ | 6,142 |  |  | $ | 3,865 |  |  | $ | 1,811 |  |  | $ | 5,676 |  |
  (was, 2026-02-04, similarity 0.9848):
[0000833444-26-000019:note_history:42]
|  |  | Three Months Ended December 31, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Americas |  | $ | 2,640 |  |  | $ | 1,203 |  |  | $ | 3,843 |  |  | $ | 2,536 |  |  | $ | 1,091 |  |  | $ | 3,627 |  |
| EMEA |  | 762 |  |  | 499 |  |  | 1,261 |  |  | 700 |  |  | 457 |  |  | 1,157 |  |
| APAC |  | 490 |  |  | 203 |  |  | 693 |  |  | 449 |  |  | 193 |  |  | 642 |  |
| Total |  | $ | 3,892 |  |  | $ | 1,905 |  |  | $ | 5,797 |  |  | $ | 3,685 |  |  | $ | 1,741 |  |  | $ | 5,426 |  |

- added (2026-05-06):
[0000833444-26-000050:note_history:43]
|  |  | Six Months Ended March 31, |
|  |  | 2026 |  | 2025 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Americas |  | $ | 5,515 |  |  | $ | 2,449 |  |  | $ | 7,964 |  |  | $ | 5,247 |  |  | $ | 2,217 |  |  | $ | 7,464 |  |
| EMEA |  | 1,561 |  |  | 982 |  |  | 2,543 |  |  | 1,421 |  |  | 937 |  |  | 2,358 |  |
| APAC |  | 1,015 |  |  | 417 |  |  | 1,432 |  |  | 882 |  |  | 398 |  |  | 1,280 |  |
| Total |  | $ | 8,091 |  |  | $ | 3,848 |  |  | $ | 11,939 |  |  | $ | 7,550 |  |  | $ | 3,552 |  |  | $ | 11,102 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0000833444-26-000050:note_history:44]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of March 31, 2026, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $26.3 billion, of which approximately 67% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations of service contracts with a duration of one year or less and open purchase orders from the indirect third-party sales channel that have a short cycle time (generally 60 days or less).
  (was, 2026-02-04, similarity 0.9938):
[0000833444-26-000019:note_history:44]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of December 31, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $24.5 billion, of which approximately 65% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations of service contracts with a duration of one year or less and open purchase orders from the indirect third-party sales channel that have a short cycle time (generally 60 days or less).


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-05-06):
[0000833444-26-000050:note_history:45]
The following tables present the Company's revenues disaggregated by segment and by Products & Systems and Services revenue (in millions):
  (was, 2026-02-04, similarity 0.9928):
[0000833444-26-000019:note_history:45]
The following table presents the Company's revenues disaggregated by segment and by Products & Systems and Services revenue (in millions):

- changed (2026-05-06):
[0000833444-26-000050:note_history:46]
|  |  | Three Months Ended March 31, |
|  |  | 2026 |  | 2025 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Americas |  | $ | 2,875 |  |  | $ | 1,246 |  |  | $ | 4,121 |  |  | $ | 2,711 |  |  | $ | 1,126 |  |  | $ | 3,837 |  |
| EMEA |  | 799 |  |  | 483 |  |  | 1,282 |  |  | 721 |  |  | 480 |  |  | 1,201 |  |
| APAC |  | 525 |  |  | 214 |  |  | 739 |  |  | 433 |  |  | 205 |  |  | 638 |  |
| Total |  | $ | 4,199 |  |  | $ | 1,943 |  |  | $ | 6,142 |  |  | $ | 3,865 |  |  | $ | 1,811 |  |  | $ | 5,676 |  |
  (was, 2026-02-04, similarity 0.9848):
[0000833444-26-000019:note_history:46]
|  |  | Three Months Ended December 31, |
|  |  | 2025 |  | 2024 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Americas |  | $ | 2,640 |  |  | $ | 1,203 |  |  | $ | 3,843 |  |  | $ | 2,536 |  |  | $ | 1,091 |  |  | $ | 3,627 |  |
| EMEA |  | 762 |  |  | 499 |  |  | 1,261 |  |  | 700 |  |  | 457 |  |  | 1,157 |  |
| APAC |  | 490 |  |  | 203 |  |  | 693 |  |  | 449 |  |  | 193 |  |  | 642 |  |
| Total |  | $ | 3,892 |  |  | $ | 1,905 |  |  | $ | 5,797 |  |  | $ | 3,685 |  |  | $ | 1,741 |  |  | $ | 5,426 |  |

- added (2026-05-06):
[0000833444-26-000050:note_history:47]
|  |  | Six Months Ended March 31, |
|  |  | 2026 |  | 2025 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Americas |  | $ | 5,515 |  |  | $ | 2,449 |  |  | $ | 7,964 |  |  | $ | 5,247 |  |  | $ | 2,217 |  |  | $ | 7,464 |  |
| EMEA |  | 1,561 |  |  | 982 |  |  | 2,543 |  |  | 1,421 |  |  | 937 |  |  | 2,358 |  |
| APAC |  | 1,015 |  |  | 417 |  |  | 1,432 |  |  | 882 |  |  | 398 |  |  | 1,280 |  |
| Total |  | $ | 8,091 |  |  | $ | 3,848 |  |  | $ | 11,939 |  |  | $ | 7,550 |  |  | $ | 3,552 |  |  | $ | 11,102 |  |

- added (2026-05-06):
[0000833444-26-000050:note_history:48]
|  |  | Location of contract balances |  | March 31, 2026 |  | September 30, 2025 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,365 |  |  | $ | 2,178 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 6 |  |  | 9 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,845 |  |  | 2,470 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 488 |  |  | 478 |  |  |  |

- changed (2026-05-06):
[0000833444-26-000050:note_history:49]
For the three months ended March 31, 2026 and 2025, the Company recognized revenue of $447 million and $393 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year. For the six months ended March 31, 2026 and 2025, the Company recognized revenue of $1,451 million and $1,271 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year.
  (was, 2026-02-04, similarity 0.6484):
[0000833444-26-000019:note_history:49]
For the three months ended December 31, 2025 and 2024, the Company recognized revenue of $1,004 million and $878 million, respectively, that was included in the contract liability balance at the end of the prior fiscal year.

- changed (2026-05-06):
[0000833444-26-000050:note_history:50]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of March 31, 2026, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $26.3 billion, of which approximately 67% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations of service contracts with a duration of one year or less and open purchase orders from the indirect third-party sales channel that have a short cycle time (generally 60 days or less).
  (was, 2026-02-04, similarity 0.9938):
[0000833444-26-000019:note_history:50]
Performance obligations are satisfied at a point in time or over time. The timing of satisfying the performance obligation is typically stipulated by the terms of the contract. As of December 31, 2025, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $24.5 billion, of which approximately 65% is expected to be recognized as revenue over the next two years. The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose construction contracts, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations of service contracts with a duration of one year or less and open purchase orders from the indirect third-party sales channel that have a short cycle time (generally 60 days or less).

- changed (2026-05-06):
[0000833444-26-000050:note_history:51]
|  | March 31, 2026 |  | September 30, 2025 |  |  |
| Other current assets | $ | 321 |  |  | $ | 327 |  |  |  |
| Other noncurrent assets | 199 |  |  | 249 |  |  |  |
| Total | $ | 520 |  |  | $ | 576 |  |  |  |
  (was, 2026-02-04, similarity 0.9738):
[0000833444-26-000019:note_history:51]
|  | December 31, 2025 |  | September 30, 2025 |  |  |
| Other current assets | $ | 320 |  |  | $ | 327 |  |  |  |
| Other noncurrent assets | 233 |  |  | 249 |  |  |  |
| Total | $ | 553 |  |  | $ | 576 |  |  |  |

- changed (2026-05-06):
[0000833444-26-000050:note_history:52]
Amortization of costs to obtain or fulfill a contract was $123 million and $91 million during the three months ended March 31, 2026 and 2025, respectively. Amortization of costs to obtain or fulfill a contract was $225 million and $175 million during the six months ended March 31, 2026 and 2025, respectively.
  (was, 2026-02-04, similarity 0.6497):
[0000833444-26-000019:note_history:52]
Amortization of costs to obtain or fulfill a contract was $102 million and $84 million during the three months ended December 31, 2025 and 2024, respectively.

- removed (2026-05-06):
[0000833444-26-000019:note_history:53]
|  |  | Location of contract balances |  | December 31, 2025 |  | September 30, 2025 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 2,343 |  |  | $ | 2,178 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 6 |  |  | 9 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | 2,542 |  |  | 2,470 |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | 501 |  |  | 478 |  |  |  |
