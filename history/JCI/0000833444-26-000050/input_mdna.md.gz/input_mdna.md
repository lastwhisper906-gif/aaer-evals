# JCI MD&A — 0000833444-26-000050


## mdna

[0000833444-26-000050:mdna:1]
[same as prior period, unchanged from 0000833444-26-000019:mdna:1]

[0000833444-26-000050:mdna:2]
[same as prior period, unchanged from 0000833444-26-000019:mdna:2]

[0000833444-26-000050:mdna:3]
[same as prior period, unchanged from 0000833444-26-000019:mdna:3]

[0000833444-26-000050:mdna:4]
[same as prior period, unchanged from 0000833444-26-000019:mdna:4]

[0000833444-26-000050:mdna:5]
Johnson Controls International plc, headquartered in Cork, Ireland, a global leader in thermal management, mission-critical building systems, energy efficiency, and decarbonization, helps customers use energy more productively, reduce carbon emissions, and operate with the precision and resilience required in rapidly expanding industries such as data centers, healthcare, pharmaceuticals, advanced manufacturing, and higher education.

[0000833444-26-000050:mdna:6]
32

[0000833444-26-000050:mdna:7]
[same as prior period, unchanged from 0000833444-26-000019:mdna:6]

[0000833444-26-000050:mdna:8]
The following information should be read in conjunction with the September 30, 2025 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in the Company's Annual Report on Form 10-K for the year ended September 30, 2025 filed with the SEC on November 14, 2025. References in the following discussion and analysis to "Three Months," "Second Quarter" or similar language refer to the three months ended March 31, 2026 compared to the three months ended March 31, 2025, while "Year-to-Date" refers to six months ended March 31, 2026 compared to the six months ended March 31, 2025.

[0000833444-26-000050:mdna:9]
[same as prior period, unchanged from 0000833444-26-000019:mdna:8]

[0000833444-26-000050:mdna:10]
[same as prior period, unchanged from 0000833444-26-000019:mdna:9]

[0000833444-26-000050:mdna:11]
The Company maintains global operations. The Company has experienced, and could again experience, increased material cost inflation and component shortages, as well as disruptions and delays in its supply chain, as a result of global macroeconomic trends including the imposition of tariffs and other restrictive trade measures. The United States has announced tariffs and reciprocal tariffs on a wide range of products manufactured or produced worldwide, including Canada, China, the European Union, Japan, India and Mexico, among others.. Several countries have similarly announced reciprocal or other tariffs impacting products manufactured or produced in the United States. In addition, the United States and other nations have, and may in the future, pause, reimpose, decrease or increase tariffs. Although the Company has been largely able to mitigate the impact of tariffs that have been enacted to date, if additional tariffs and reciprocal tariffs are implemented (whether as currently proposed or otherwise), such actions could negatively impact the Company's revenue growth and margins in future periods through decreased sales and increased cost of goods sold. In February 2026, certain tariffs imposed under the International Emergency Economic Powers Act (IEEPA), were invalidated by the U.S. Supreme Court. However, the United States has since imposed new tariffs and duties in their place. The Company is currently evaluating its options to mitigate the impact of prior IEEPA tariffs through participation in the IEEPA refund process. To date, the tariffs enacted by the United States and other countries have not had a material impact on the Company's financial performance for the periods presented.

[0000833444-26-000050:mdna:12]
Geopolitical and economic tensions, including the ongoing conflicts in the Middle East, have the potential to cause disruptions in global supply chains, increase costs and create overall volatility. The ongoing conflicts in the Middle East have disrupted energy supplies and supply chains, increased costs for energy and other supplies and created volatility in the capital markets, among other impacts. The net effect of these events will continue to depend on the Company’s ability to successfully mitigate and offset their impacts.

[0000833444-26-000050:mdna:13]
The Company is taking actions to mitigate the actual and anticipated impact of ongoing trade restrictions and geopolitical conflict, including strengthening the Company's in region, for region manufacturing strategy, pivoting to local sourcing in its supply chain, accelerating pricing actions and asserting contractual rights through change orders. The Company has historically taken a variety of actions to mitigate trade restrictions, supply chain disruptions and inflation, including through expanding and redistributing its supplier network, supplier financing, accelerated purchasing and productivity improvements. These actions have largely been successful in mitigating the impacts of the current macroeconomic environment, however, it is uncertain as to whether the actions taken or contemplated to be taken by the Company will be effective in continuing to mitigate the impact of current and future trade restrictions and their related impacts. The Company continues to actively monitor and evaluate the development and potential impacts of tariffs, trade restrictions and geopolitical conflicts on its supply chain and results of operations.

[0000833444-26-000050:mdna:14]
[same as prior period, unchanged from 0000833444-26-000019:mdna:12]

[0000833444-26-000050:mdna:15]
[same as prior period, unchanged from 0000833444-26-000019:mdna:13]

[0000833444-26-000050:mdna:16]
[same as prior period, unchanged from 0000833444-26-000019:mdna:14]

[0000833444-26-000050:mdna:17]
The extent to which the Company’s results of operations and financial condition are impacted by these and other factors in the future will depend on developments that are highly uncertain and cannot be predicted. See the section entitled "Risk Factors" in Johnson Controls' Annual Report on Form 10-K for the year ended September 30, 2025 filed with the United States Securities and Exchange Commission ("SEC") on November 14, 2025. Certain of these risk factors have been updated and supplemented in the Company's Quarterly Report on Form 10-Q for the quarter ended December 31, 2025 filed on February 4, 2026 and in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0000833444-26-000050:mdna:18]
[same as prior period, unchanged from 0000833444-26-000019:mdna:19]

[0000833444-26-000050:mdna:19]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |  |  |
| (in millions) | 2026 |  | 2025 |  | Change |  | 2026 |  | 2025 |  | Change |  |  |  |  |  |  |
| Net sales | $ | 6,142 |  |  | $ | 5,676 |  |  | 8 | % |  | $ | 11,939 |  |  | $ | 11,102 |  |  | 8 | % |  |  |  |  |  |  |

[0000833444-26-000050:mdna:20]
The increase in net sales for the three months ended March 31, 2026 was due to higher organic sales ($360 million) and the favorable impact of foreign currency translation ($128 million), partially offset by the impact of divestitures ($22 million). Excluding the impact of foreign currency translation and business divestitures, net sales increased 6% over the prior year, driven by growth across all segments, led by the Americas.

[0000833444-26-000050:mdna:21]
The increase in net sales for the six months ended March 31, 2026 was due to higher organic sales ($671 million) and the favorable impact of foreign currency translation ($200 million), partially offset by the net impact of acquisitions and divestitures ($34 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, net sales increased 6% over the prior year, driven by growth across all segments, led by the Americas.

[0000833444-26-000050:mdna:22]
[same as prior period, unchanged from 0000833444-26-000019:mdna:22]

[0000833444-26-000050:mdna:23]
[same as prior period, unchanged from 0000833444-26-000019:mdna:24]

[0000833444-26-000050:mdna:24]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |  |  |
| (in millions) | 2026 |  | 2025 |  | Change |  | 2026 |  | 2025 |  | Change |  |  |  |  |  |  |
| Cost of sales | $ | 3,880 |  |  | $ | 3,607 |  |  | 8 | % |  | $ | 7,603 |  |  | $ | 7,107 |  |  | 7 | % |  |  |  |  |  |  |
| Gross profit | 2,262 |  |  | 2,069 |  |  | 9 | % |  | 4,336 |  |  | 3,995 |  |  | 9 | % |  |  |  |  |  |  |
| % of sales | 36.8 | % |  | 36.5 | % |  | 30 | bp |  | 36.3 | % |  | 36.0 | % |  | 30 | bp |  |  |  |  |  |  |

[0000833444-26-000050:mdna:25]
The increase in gross profit for the three and six months ended March 31, 2026 was primarily due to organic sales growth, productivity improvements and better operating leverage.

[0000833444-26-000050:mdna:26]
[same as prior period, unchanged from 0000833444-26-000019:mdna:27]

[0000833444-26-000050:mdna:27]
[same as prior period, unchanged from 0000833444-26-000019:mdna:28]

[0000833444-26-000050:mdna:28]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |  |  |
| (in millions) | 2026 |  | 2025 |  | Change |  | 2026 |  | 2025 |  | Change |  |  |  |  |  |  |
| SG&A | $ | 1,401 |  |  | $ | 1,427 |  |  | (2 | %) |  | $ | 2,622 |  |  | $ | 2,826 |  |  | (7 | %) |  |  |  |  |  |  |
| % of sales | 22.8 | % |  | 25.1 | % |  | (230) | bp |  | 22.0 | % |  | 25.5 | % |  | (350) | bp |  |  |  |  |  |  |

[0000833444-26-000050:mdna:29]
The decrease in SG&A for the three months ended March 31, 2026 was primarily due to benefits from ongoing cost reduction actions.

[0000833444-26-000050:mdna:30]
The decrease in SG&A for the six months ended March 31, 2026 was primarily due to AFFF insurance recoveries related to the previously disclosed water systems settlement ($119 million), the gain on the ADT Mexico business divestiture ($70 million) and benefits from ongoing cost actions.

[0000833444-26-000050:mdna:31]
Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings. Refer to Note 18, "Commitments and Contingencies," of the notes to the consolidated financial statements for further disclosure related to the water systems AFFF settlement.

[0000833444-26-000050:mdna:32]
[same as prior period, unchanged from 0000833444-26-000019:mdna:32]

[0000833444-26-000050:mdna:33]
[same as prior period, unchanged from 0000833444-26-000019:mdna:17]

[0000833444-26-000050:mdna:34]
It is expected that the plan will be completed in fiscal 2027 and the Company will incur one-time restructuring costs, including severance and other employee termination benefits, contract termination costs, and certain other related cash and non-cash charges, totaling approximately $400 million, resulting in expected annual cost savings of approximately $500 million upon full completion of the plan. Restructuring costs will be incurred across all segments and Corporate functions.

[0000833444-26-000050:mdna:35]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |  |  |  |  |  |  |  |  |  |  |  |  |
| (in millions) | 2026 |  | 2025 |  | 2026 |  | 2025 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and related costs | $ | 36 |  |  | $ | 40 |  |  | $ | 73 |  |  | $ | 73 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other impairments | 21 |  |  | 22 |  |  | 71 |  |  | 22 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and impairment costs | $ | 57 |  |  | $ | 62 |  |  | $ | 144 |  |  | $ | 95 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0000833444-26-000050:mdna:36]
Refer to Note 3, "Divestitures" and Note 14, "Restructuring and Related Costs," of the notes to the consolidated financial statements for further disclosure related to the Company's restructuring actions and impairment costs.

[0000833444-26-000050:mdna:37]
[same as prior period, unchanged from 0000833444-26-000019:mdna:35]

[0000833444-26-000050:mdna:38]
[same as prior period, unchanged from 0000833444-26-000019:mdna:36]

[0000833444-26-000050:mdna:39]
[same as prior period, unchanged from 0000833444-26-000019:mdna:37]

[0000833444-26-000050:mdna:40]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |  |  |
| (in millions) | 2026 |  | 2025 |  | 2026 |  | 2025 |  |  |  |  |  |
| Income tax provision | $ | 126 |  |  | $ | 26 |  |  | $ | 278 |  |  | $ | 73 |  |  |  |  |  |  |
| Effective tax rate | 17.1 | % |  | 5.2 | % |  | 19.2 | % |  | 8.0 | % |  |  |  |  |  |

[0000833444-26-000050:mdna:41]
[same as prior period, unchanged from 0000833444-26-000019:mdna:39]

[0000833444-26-000050:mdna:42]
[same as prior period, unchanged from 0000833444-26-000019:mdna:40]

[0000833444-26-000050:mdna:43]
The Chief Executive Officer, the Company’s chief operating decision maker ("CODM"), evaluates the performance of its segments and allocates resources based on two profitability measures, Segment EBIT and Segment EBITA (non-GAAP):

[0000833444-26-000050:mdna:44]
•Segment earnings before interest and taxes (“Segment EBIT”) represents segment income from continuing operations, excluding restructuring and impairment costs, AFFF related settlement costs and insurance recoveries, gains or losses on divestitures, and net mark-to-market gains and losses related to pension and postretirement plans and restricted asbestos investments.  Segment EBIT is used as a tool to allow the CODM to evaluate the recurring profitability of the segments, including revenues and expenses that are within the operational control of the segments, and excluding the impact of certain non-cash and non-recurring items. Segment EBIT also provides the CODM with visibility into the integration of key strategic initiatives, such as acquisitions and mergers.

[0000833444-26-000050:mdna:45]
•Segment earnings before interest, taxes and amortization ("Segment EBITA") (non-GAAP) represents Segment EBIT, excluding the impact of amortization of intangible assets. Segment EBITA provides the CODM with performance comparability across periods and more accurate benchmarking against peer companies that may not have similar historical acquisition activity, by holding constant the impact of significant acquisitions.

[0000833444-26-000050:mdna:46]
Both Segment EBIT and Segment EBITA are reviewed by the CODM and compared against the profit plan and forecast for the current and prior year. Segment EBITA is not defined under GAAP and may not be comparable to similarly titled measures used by other companies.

[0000833444-26-000050:mdna:47]
[same as prior period, unchanged from 0000833444-26-000019:mdna:45]

[0000833444-26-000050:mdna:48]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |  |  |
| (in millions) | 2026 |  | 2025 |  | Change |  | 2026 |  | 2025 |  | Change |  |  |  |  |  |  |
| Americas | $ | 4,121 |  |  | $ | 3,837 |  |  | 7 | % |  | $ | 7,964 |  |  | $ | 7,464 |  |  | 7 | % |  |  |  |  |  |  |
| EMEA | 1,282 |  |  | 1,201 |  |  | 7 | % |  | 2,543 |  |  | 2,358 |  |  | 8 | % |  |  |  |  |  |  |
| APAC | 739 |  |  | 638 |  |  | 16 | % |  | 1,432 |  |  | 1,280 |  |  | 12 | % |  |  |  |  |  |  |
|  | $ | 6,142 |  |  | $ | 5,676 |  |  | 8 | % |  | $ | 11,939 |  |  | $ | 11,102 |  |  | 8 | % |  |  |  |  |  |  |

[0000833444-26-000050:mdna:49]
Three Months:

[0000833444-26-000050:mdna:50]
•The increase in Americas was due to organic growth ($260 million) and foreign currency translation ($24 million). Excluding the impact of foreign currency translation, sales increased 7%, led by continued strength across Applied HVAC. Products and Systems sales increased 5% and Services increased 10%.

[0000833444-26-000050:mdna:51]
•The increase in EMEA was due to the favorable impact of foreign currency translation ($89 million) and organic growth ($14 million), partially offset by the impact of divestitures ($22 million). Excluding the impact of foreign

[0000833444-26-000050:mdna:52]
36

[0000833444-26-000050:mdna:53]
currency translation and divestitures, sales increased 1%, as Products and Systems growth offset disruptions caused by the Middle East conflicts and lower non-recurring Services volumes during the quarter.

[0000833444-26-000050:mdna:54]
•The increase in APAC was due to organic growth ($86 million) and foreign currency translation ($15 million). Excluding the impact of foreign currency translation, sales increased 13%, led by over 20% growth in Applied HVAC primarily due to data center application growth.

[0000833444-26-000050:mdna:55]
Year to Date:

[0000833444-26-000050:mdna:56]
•The increase in Americas was due to organic growth ($470 million) and foreign currency translation ($30 million). Excluding the impact of foreign currency translation, sales increased 6%, led by continued strength across Applied HVAC. Products and Systems sales increased 5% and Services increased 10%.

[0000833444-26-000050:mdna:57]
•The increase in EMEA was due to the favorable impact of foreign currency translation ($154 million) and organic growth ($65 million), partially offset by the net impact of business acquisitions and divestitures ($34 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, sales increased 3%. Products and Systems sales increased 2% and Services increased 3%.

[0000833444-26-000050:mdna:58]
•The increase in APAC was due to organic growth ($136 million) and foreign currency translation ($16 million). Excluding the impact of foreign currency translation, sales increased 10%, led by 14% growth in Products and Systems primarily due to data center application growth.

[0000833444-26-000050:mdna:59]
Segment EBIT and Segment EBITA (non-GAAP)

[0000833444-26-000050:mdna:60]
|  | Segment EBITThree Months Ended March 31, |  | Segment EBITSix Months Ended March 31, |  |  |
| (in millions) | 2026 |  | 2025 |  | Change |  | 2026 |  | 2025 |  | Change |  |  |  |  |  |  |
| Americas | $ | 705 |  |  | $ | 616 |  |  | 14 | % |  | $ | 1,249 |  |  | $ | 1,110 |  |  | 13 | % |  |  |  |  |  |  |
| EMEA | 179 |  |  | 117 |  |  | 53 | % |  | 330 |  |  | 233 |  |  | 42 | % |  |  |  |  |  |  |
| APAC | 143 |  |  | 101 |  |  | 42 | % |  | 256 |  |  | 186 |  |  | 38 | % |  |  |  |  |  |  |

[0000833444-26-000050:mdna:61]
|  | Segment EBITA (non-GAAP)Three Months Ended March 31, |  | Segment EBITA (non-GAAP)Six Months Ended March 31, |  |  |
| (in millions) | 2026 |  | 2025 |  | Change |  | 2026 |  | 2025 |  | Change |  |  |  |  |  |  |
| Americas | $ | 782 |  |  | $ | 707 |  |  | 11 | % |  | $ | 1,402 |  |  | $ | 1,296 |  |  | 8 | % |  |  |  |  |  |  |
| EMEA | 186 |  |  | 135 |  |  | 38 | % |  | 344 |  |  | 271 |  |  | 27 | % |  |  |  |  |  |  |
| APAC | 146 |  |  | 104 |  |  | 40 | % |  | 263 |  |  | 194 |  |  | 36 | % |  |  |  |  |  |  |

[0000833444-26-000050:mdna:62]
Three Months:

[0000833444-26-000050:mdna:63]
•The increase in Americas was primarily driven by favorable pricing, productivity improvements and increased volumes.

[0000833444-26-000050:mdna:64]
•The increase in EMEA was primarily driven by productivity improvements and improved leverage on higher revenue.

[0000833444-26-000050:mdna:65]
[same as prior period, unchanged from 0000833444-26-000019:mdna:54]

[0000833444-26-000050:mdna:66]
Year to Date:

[0000833444-26-000050:mdna:67]
•The increase in Americas was primarily driven by favorable pricing, productivity improvements and increased volumes.

[0000833444-26-000050:mdna:68]
•The increase in EMEA was primarily driven by productivity improvements and improved leverage on higher revenue.

[0000833444-26-000050:mdna:69]
•The increase in APAC was primarily driven by increased volumes and productivity improvements.

[0000833444-26-000050:mdna:70]
A reconciliation of income from continuing operations before income taxes to Segment EBIT and Segment EBITA (non-GAAP) is as follows (in millions):

[0000833444-26-000050:mdna:71]
|  | Three Months Ended March 31, |  | Six Months Ended March 31, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Income from continuing operations before income taxes | $ | 738 |  |  | $ | 501 |  |  | $ | 1,446 |  |  | $ | 909 |  |
| Corporate expenses | 152 |  |  | 186 |  |  | 308 |  |  | 357 |  |
| Restructuring and impairment costs | 57 |  |  | 62 |  |  | 144 |  |  | 95 |  |
| Water systems AFFF insurance recoveries (1) | (1) |  |  | (8) |  |  | (131) |  |  | (12) |  |
| Net financing charges | 67 |  |  | 80 |  |  | 126 |  |  | 166 |  |
| Gain on divestiture | — |  |  | — |  |  | (70) |  |  | — |  |
| Net mark-to-market adjustments | 14 |  |  | 13 |  |  | 12 |  |  | 14 |  |
| Segment EBIT | 1,027 |  |  | 834 |  |  | 1,835 |  |  | 1,529 |  |
| Amortization of intangible assets | 87 |  |  | 112 |  |  | 174 |  |  | 232 |  |
| Segment EBITA (non-GAAP) | $ | 1,114 |  |  | $ | 946 |  |  | $ | 2,009 |  |  | $ | 1,761 |  |

[0000833444-26-000050:mdna:72]
[same as prior period, unchanged from 0000833444-26-000019:mdna:55]

[0000833444-26-000050:mdna:73]
Backlog and orders are additional metrics that are meant to provide management with a deeper level of insight into the progress of specific strategic and growth initiatives. Orders provide management with a signal of customer demand for the Company's products and services, as well as an indication of future revenues and performance. The Company believes backlog is a useful measure for evaluating its operational performance and relationship to total orders. However, the timing and conversion of backlog and orders are subject to numerous uncertainties and risks and are not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-26-000050:mdna:74]
[same as prior period, unchanged from 0000833444-26-000019:mdna:57]

[0000833444-26-000050:mdna:75]
|  | Backlog |  | Orders |
| (in billions) | March 31, 2026 |  |  |  | Year-over-Year Change (1) |  | Three Months Ended March 31, 2026 |  |  |  | Year-over-Year Change (1) |
| Americas | $ | 14.9 |  |  |  |  | 32 | % |  | $ | 5.3 |  |  |  |  | 40 | % |
| EMEA | 3.2 |  |  |  |  | 13 | % |  | 1.4 |  |  |  |  | 11 | % |
| APAC | 1.9 |  |  |  |  | 14 | % |  | 0.7 |  |  |  |  | 4 | % |
| Total | $ | 20.0 |  |  |  |  | 26 | % |  | $ | 7.4 |  |  |  |  | 30 | % |

[0000833444-26-000050:mdna:76]
(1) Change is compared to March 31, 2025 (backlog) and the three months ended March 31, 2025 (orders) and excludes the impact of acquisitions, divestitures and foreign currency.

[0000833444-26-000050:mdna:77]
Backlog

[0000833444-26-000050:mdna:78]
Backlog increased 26%, led by growth in Products and Systems.

[0000833444-26-000050:mdna:79]
•The 32% increase in backlog for Americas was led by 37% growth in Products and Systems, partially offset by a 2% decrease in Services.

[0000833444-26-000050:mdna:80]
•The 13% increase in backlog for EMEA was due to 14% growth in Services and 13% growth in Products and Systems.

[0000833444-26-000050:mdna:81]
•The 14% increase in backlog for APAC was due to 14% growth in Products and Systems and 6% growth in Services.

[0000833444-26-000050:mdna:82]
38

[0000833444-26-000050:mdna:83]
Orders

[0000833444-26-000050:mdna:84]
Orders increased 30%, reflecting sustained demand in large projects across our core markets, including our solutions for large-scale data center projects.

[0000833444-26-000050:mdna:85]
•The 40% increase in orders for Americas was led by 57% growth in Products and Systems and 4% growth in Services.

[0000833444-26-000050:mdna:86]
•The 11% increase in orders for EMEA was led by 26% growth in Products and Systems, partially offset by an 8% decrease  in Services.

[0000833444-26-000050:mdna:87]
•The 4% increase in backlog for APAC was due to 6% growth in Products and Systems and 2% growth in Services.

[0000833444-26-000050:mdna:88]
Remaining performance obligations were $26.3 billion at March 31, 2026. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-26-000050:mdna:89]
[same as prior period, unchanged from 0000833444-26-000019:mdna:62]

[0000833444-26-000050:mdna:90]
[same as prior period, unchanged from 0000833444-26-000019:mdna:63]

[0000833444-26-000050:mdna:91]
[same as prior period, unchanged from 0000833444-26-000019:mdna:64]

[0000833444-26-000050:mdna:92]
[same as prior period, unchanged from 0000833444-26-000019:mdna:66]

[0000833444-26-000050:mdna:93]
[same as prior period, unchanged from 0000833444-26-000019:mdna:67]

[0000833444-26-000050:mdna:94]
| (in millions) | March 31, 2026 |  | September 30, 2025 |  | Change |
| Current assets | $ | 10,991 |  |  | $ | 10,162 |  |  |  |
| Current liabilities | 10,605 |  |  | 10,941 |  |  |  |
| Working capital | $ | 386 |  |  | $ | (779) |  |  | (150) | % |
| Accounts receivable - net | $ | 6,614 |  |  | $ | 6,269 |  |  | 6 | % |
| Inventories | 1,933 |  |  | 1,820 |  |  | 6 | % |
| Accounts payable | 3,610 |  |  | 3,614 |  |  | — | % |

[0000833444-26-000050:mdna:95]
The increase in working capital at March 31, 2026 as compared to September 30, 2025 was primarily due to increases in cash and accounts receivable and decreases in accrued compensation and the current portion of long-term debt, partially offset by an increase in deferred revenue and the net impact of other current assets and liabilities.

[0000833444-26-000050:mdna:96]
[same as prior period, unchanged from 0000833444-26-000019:mdna:70]

[0000833444-26-000050:mdna:97]
|  |  | Six Months Ended March 31, |
| (in millions) |  | 2026 |  | 2025 |
| Cash provided by operating activities |  | $ | 1,283 |  |  | $ | 799 |  |
| Cash provided (used) by investing activities |  | 41 |  |  | (217) |  |
| Cash used by financing activities |  | (1,030) |  |  | (474) |  |

[0000833444-26-000050:mdna:98]
The increase in cash provided by operating activities primarily reflects higher net income and favorable changes in accounts payable and accrued liabilities and other assets, partially offset by higher accounts receivable.

[0000833444-26-000050:mdna:99]
[same as prior period, unchanged from 0000833444-26-000019:mdna:73]

[0000833444-26-000050:mdna:100]
The increase in cash used by financing activities was primarily due to changes in net debt activity, partially offset by lower stock repurchases.

[0000833444-26-000050:mdna:101]
[same as prior period, unchanged from 0000833444-26-000019:mdna:76]

[0000833444-26-000050:mdna:102]
| (in millions) | March 31, 2026 |  | September 30, 2025 |  |
| Short-term debt | $ | 882 |  |  | $ | 723 |  |  |
| Current portion of long-term debt | 28 |  |  | 566 |  |  |
| Long-term debt | 8,613 |  |  | 8,591 |  |  |
| Total debt | 9,523 |  |  | 9,880 |  |  |
| Less: Cash and cash equivalents | 698 |  |  | 379 |  |  |
| Net debt | $ | 8,825 |  |  | $ | 9,501 |  |  |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders ("Equity") | $ | 13,518 |  |  | $ | 12,927 |  |  |
| Total capitalization (Total debt plus Equity) | 23,041 |  |  | 22,807 |  |  |
| Net capitalization (Net debt plus Equity) | 22,343 |  |  | 22,428 |  |  |
| Total debt as a % of Total capitalization | 41.3 | % |  | 43.3 | % |  |
| Net debt as a % of Net capitalization | 39.5 | % |  | 42.4 | % |  |

[0000833444-26-000050:mdna:103]
[same as prior period, unchanged from 0000833444-26-000019:mdna:78]

[0000833444-26-000050:mdna:104]
•The Company completed its previously announced accelerated share repurchase ("ASR") program in the second quarter of fiscal 2026 and resumed open market repurchases after final settlement of the ASR transactions. In total, the Company invested $5.0 billion to repurchase 43,693,817 shares at an average price of $114.43 per share. As of March 31, 2026, approximately $4.5 billion remains available under the Company's share repurchase authorization, which does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. The Company expects to repurchase outstanding shares from time to time depending on market conditions, alternate uses of capital, liquidity, and the economic environment.

[0000833444-26-000050:mdna:105]
•The Company declared a dividend of $0.40 per common share in the quarter ended March 31, 2026 and intends to continue paying dividends throughout fiscal 2026.

[0000833444-26-000050:mdna:106]
•The Company believes its capital resources and liquidity position, including cash and cash equivalents of $698 million at March 31, 2026, are adequate to fund operations and meet its cash obligations for the foreseeable future.

[0000833444-26-000050:mdna:107]
40

[0000833444-26-000050:mdna:108]
–The Company manages its short-term debt position in the U.S. and euro commercial paper and bank loan markets. Commercial paper outstanding totaled $441 million as of March 31, 2026 and $400 million as of September 30, 2025.

[0000833444-26-000050:mdna:109]
[same as prior period, unchanged from 0000833444-26-000019:mdna:83]

[0000833444-26-000050:mdna:110]
–The Company also has the ability to draw on its $2.5 billion revolving credit facility which is scheduled to expire in December 2028. There were no draws on the revolving credit facility as of March 31, 2026 and September 30, 2025.

[0000833444-26-000050:mdna:111]
•The Company's ability to access the global capital markets and the related cost of financing is dependent upon, among other factors, the Company's credit ratings. As of March 31, 2026, the Company's credit ratings and outlook were as follows:

[0000833444-26-000050:mdna:112]
[same as prior period, unchanged from 0000833444-26-000019:mdna:86]

[0000833444-26-000050:mdna:113]
[same as prior period, unchanged from 0000833444-26-000019:mdna:87]

[0000833444-26-000050:mdna:114]
•Financial covenants in the Company's revolving credit facilities require a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of March 31, 2026, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures governing its notes, and expects to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-26-000050:mdna:115]
[same as prior period, unchanged from 0000833444-26-000019:mdna:89]

[0000833444-26-000050:mdna:116]
41

[0000833444-26-000050:mdna:117]
[same as prior period, unchanged from 0000833444-26-000019:mdna:90]

[0000833444-26-000050:mdna:118]
[same as prior period, unchanged from 0000833444-26-000019:mdna:91]

[0000833444-26-000050:mdna:119]
[same as prior period, unchanged from 0000833444-26-000019:mdna:92]

[0000833444-26-000050:mdna:120]
•€500 million aggregate principal amount of 0.375% Senior Notes due September 2027

[0000833444-26-000050:mdna:121]
•€600 million aggregate principal amount of 3.000% Senior Notes due September 2028

[0000833444-26-000050:mdna:122]
•$700 million aggregate principal amount of 5.500% Senior Notes due April 2029

[0000833444-26-000050:mdna:123]
•$625 million aggregate principal amount of 1.750% Senior Notes due September 2030

[0000833444-26-000050:mdna:124]
•$500 million aggregate principal amount of 2.000% Sustainability-Linked Senior Notes due September 2031

[0000833444-26-000050:mdna:125]
•€500 million aggregate principal amount of 1.000% Senior Notes due September 2032

[0000833444-26-000050:mdna:126]
•$650 million aggregate principal amount of 4.900% Senior Notes due December 2032

[0000833444-26-000050:mdna:127]
•€500 million aggregate principal amount of 3.125% Senior Notes due December 2033

[0000833444-26-000050:mdna:128]
•€800 million aggregate principal amount of 4.250% Senior Notes due May 2035

[0000833444-26-000050:mdna:129]
[same as prior period, unchanged from 0000833444-26-000019:mdna:103]

[0000833444-26-000050:mdna:130]
[same as prior period, unchanged from 0000833444-26-000019:mdna:104]

[0000833444-26-000050:mdna:131]
|  |  | Six Months Ended March 31, 2026 |  | Year Ended September 30, 2025 |
| Net loss attributable to the Obligor Group |  | $ | 151 |  |  | $ | 844 |  |
| Net loss attributable to intercompany transactions |  | 25 |  |  | 56 |  |

[0000833444-26-000050:mdna:132]
[same as prior period, unchanged from 0000833444-26-000019:mdna:106]

[0000833444-26-000050:mdna:133]
[same as prior period, unchanged from 0000833444-26-000019:mdna:107]

[0000833444-26-000050:mdna:134]
|  |  | Obligor Group |  | Intercompany Balances |  |
|  |  | March 31, 2026 |  | September 30, 2025 |  | March 31, 2026 |  | September 30, 2025 |  |
| Current assets |  | $ | 1,245 |  |  | $ | 2,748 |  |  | $ | 6,272 |  |  | $ | 6,161 |  |  |
| Noncurrent assets |  | 243 |  |  | 243 |  |  | 2,148 |  |  | 2,450 |  |  |
| Current liabilities |  | 1,665 |  |  | 1,585 |  |  | 3,053 |  |  | 4,041 |  |  |
| Noncurrent liabilities |  | 8,491 |  |  | 8,473 |  |  | 5,021 |  |  | 22,450 |  | * |

[0000833444-26-000050:mdna:135]
42

[0000833444-26-000050:mdna:136]
[same as prior period, unchanged from 0000833444-26-000019:mdna:109]

[0000833444-26-000050:mdna:137]
[same as prior period, unchanged from 0000833444-26-000019:mdna:110]

[0000833444-26-000050:mdna:138]
[same as prior period, unchanged from 0000833444-26-000019:mdna:111]

[0000833444-26-000050:mdna:139]
[same as prior period, unchanged from 0000833444-26-000019:mdna:112]

[0000833444-26-000050:mdna:140]
[same as prior period, unchanged from 0000833444-26-000019:mdna:113]

[0000833444-26-000050:mdna:141]
The Company prepares its consolidated financial statements in conformity with accounting principles generally accepted in the United States of America ("U.S. GAAP"). This requires management to make estimates and assumptions that affect reported amounts and related disclosures. Actual results could differ from those estimates. The Company’s critical accounting estimates requiring significant judgement that could materially impact the Company's results of operations, financial position and cash flows are described in Management’s Discussion and Analysis of Financial Condition and Results of Operations included in the Company’s Annual Report on Form 10-K for the year ended September 30, 2025. Since the date of the Company’s most recent Annual Report, there have been no material changes in the Company’s critical accounting estimates or assumptions.
