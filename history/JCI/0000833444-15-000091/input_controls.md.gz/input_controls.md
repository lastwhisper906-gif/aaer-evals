# JCI 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 4 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0000833444-15-000091:item_9a:1]
Item 9A.    Controls and Procedures

[0000833444-15-000091:item_9a:2]
Conclusion Regarding the Effectiveness of Disclosure Controls and Procedures

[0000833444-15-000091:item_9a:3]
We maintain disclosure controls and procedures that are designed to provide reasonable assurance that information required to be disclosed in our Exchange Act reports is recorded, processed, summarized and reported within the time periods specified in the SEC's rules and forms, and that such information is accumulated and communicated to our management, including our Chief Executive Officer and Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure.

[0000833444-15-000091:item_9a:4]
Under the supervision and with the participation of our management, including our Chief Executive Officer and our Chief Financial Officer, we conducted an evaluation of the effectiveness of our disclosure controls and procedures, as defined under Exchange Act Rule 13a-15(e). Based on this evaluation, our Chief Executive Officer and our Chief Financial Officer concluded that, as of September 25, 2015, our disclosure controls and procedures were effective to provide reasonable assurance that information required to be disclosed in our Exchange Act reports is recorded, processed, summarized and reported as and when required.

[0000833444-15-000091:item_9a:5]
There were no changes in our internal controls over financial reporting that occurred during the quarter ended September 25, 2015 that have materially affected, or are reasonably likely to materially affect, these internal controls.

[0000833444-15-000091:item_9a:6]
55

[0000833444-15-000091:item_9a:7]
Management's Report on Internal Control over Financial Reporting

[0000833444-15-000091:item_9a:8]
Our management is responsible for establishing and maintaining adequate internal control over financial reporting, as defined under Exchange Act Rules 13a-15(f) and 15d-15(f). Our internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with accounting principles generally accepted in the United States of America. Internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the Company's assets, (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that the Company's receipts and expenditures are being made only in accordance with authorizations of the Company's management and directors and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the Company's assets that could have a material effect on the financial statements.

[0000833444-15-000091:item_9a:9]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000833444-15-000091:item_9a:10]
Management assessed the effectiveness of our internal control over financial reporting as of September 25, 2015. In making this assessment, management used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission (COSO) in its framework, Internal Control—Integrated Framework (2013). Management's assessment included an evaluation of the design of the Company's internal control over financial reporting and testing of the operational effectiveness of its internal control over financial reporting. Management reviewed the results of its assessment with the Audit Committee of our Board of Directors. Based on our assessment and those criteria, management believes that the Company maintained effective internal controls over financial reporting as of September 25, 2015.

[0000833444-15-000091:item_9a:11]
Our internal control over financial reporting as of September 25, 2015, has been audited by Deloitte & Touche LLP, the independent registered public accounting firm that audited and reported on the Consolidated Financial Statements included in this Form 10-K, and their report is also included in this Form 10-K.

[0000833444-15-000091:item_9a:12]
56

[0000833444-15-000091:item_9a:13]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0000833444-15-000091:item_9a:14]
To the Board of Directors and Shareholders of

[0000833444-15-000091:item_9a:15]
Tyco International plc:

[0000833444-15-000091:item_9a:16]
We have audited the internal control over financial reporting of Tyco International plc and subsidiaries (the "Company"), formerly known as Tyco International Ltd. and subsidiaries, as of September 25, 2015, based on criteria established in  Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. The Company's management is responsible for maintaining effective internal control over financial reporting and for its assessment of the effectiveness of internal control over financial reporting, included in the accompanying Management’s Report on Internal Control over Financial Reporting. Our responsibility is to express an opinion on the Company's internal control over financial reporting based on our audit.

[0000833444-15-000091:item_9a:17]
We conducted our audit in accordance with the standards of the Public Company Accounting Oversight Board (United States). Those standards require that we plan and perform the audit to obtain reasonable assurance about whether effective internal control over financial reporting was maintained in all material respects. Our audit included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, testing and evaluating the design and operating effectiveness of internal control based on the assessed risk, and performing such other procedures as we considered necessary in the circumstances. We believe that our audit provides a reasonable basis for our opinion.

[0000833444-15-000091:item_9a:18]
A company's internal control over financial reporting is a process designed by, or under the supervision of, the company's principal executive and principal financial officers, or persons performing similar functions, and effected by the company's board of directors, management, and other personnel to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company's internal control over financial reporting includes those policies and procedures that (1) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (2) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (3) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company's assets that could have a material effect on the financial statements.

[0000833444-15-000091:item_9a:19]
Because of the inherent limitations of internal control over financial reporting, including the possibility of collusion or improper management override of controls, material misstatements due to error or fraud may not be prevented or detected on a timely basis. Also, projections of any evaluation of the effectiveness of the internal control over financial reporting to future periods are subject to the risk that the controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000833444-15-000091:item_9a:20]
In our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of September 25, 2015, based on the criteria established in  Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.

[0000833444-15-000091:item_9a:21]
We have also audited, in accordance with the standards of the Public Company Accounting Oversight Board (United States), the consolidated financial statements and financial statement schedule as of and for the fiscal year ended September 25, 2015 of the Company and our report dated November 13, 2015 expressed an unqualified opinion on those financial statements and financial statement schedule.

[0000833444-15-000091:item_9a:22]
/s/ DELOITTE & TOUCHE LLP

[0000833444-15-000091:item_9a:23]
New York, New York

[0000833444-15-000091:item_9a:24]
November 13, 2015

[0000833444-15-000091:item_9a:25]
57
