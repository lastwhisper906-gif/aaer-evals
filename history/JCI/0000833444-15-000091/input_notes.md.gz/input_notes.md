# JCI notes — 0000833444-15-000091


## tyc:AcquisitionCostsPolicyTextBlock

[0000833444-15-000091:notes:1]
Acquisition Costs—Costs incurred to acquire new businesses, new product lines or similar assets are expensed when incurred and are included in Selling, general and administrative expenses within the Consolidated Statements of Operations. See Note 5.


## tyc:AsbestosContingenciesAndInsuranceReceivablesPolicyTextBlock

[0000833444-15-000091:notes:2]
Asbestos-Related Contingencies and Insurance Receivables—The Company and certain of its subsidiaries along with numerous other companies are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made in the future during a defined period of time (the look-forward period). On a periodic basis, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on a periodic basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-15-000091:notes:3]
In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable. The Company's estimate of asbestos-related insurance recoveries represents estimated amounts due to the Company for previously paid and settled claims and the probable reimbursements relating to its estimated liability for pending and future claims. In determining the amount of insurance recoverable, the Company considers a number of factors, including available insurance, allocation methodologies, solvency and creditworthiness of the insurers. See Note 12.


## tyc:CondensedFinancialStatementsDisclosureTableTextBlock

[0000833444-15-000091:notes:4]
|  | TycoInternationalplc |  | TycoFire & Security Finance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | — |  |  | $ | — |  |  | $ | 9,902 |  |  | $ | — |  |  | $ | 9,902 |  |
| Cost of product sales | — |  |  | — |  |  | — |  |  | 4,072 |  |  | — |  |  | 4,072 |  |
| Cost of services | — |  |  | — |  |  | — |  |  | 2,198 |  |  | — |  |  | 2,198 |  |
| Selling, general and administrative expenses | 7 |  |  | — |  |  | 2 |  |  | 2,564 |  |  | — |  |  | 2,573 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | — |  |  | 175 |  |  | — |  |  | 175 |  |
| Operating (loss) income | (7 | ) |  | — |  |  | (2 | ) |  | 893 |  |  | — |  |  | 884 |  |
| Interest income | — |  |  | — |  |  | — |  |  | 15 |  |  | — |  |  | 15 |  |
| Interest expense | — |  |  | — |  |  | (100 | ) |  | (2 | ) |  | — |  |  | (102 | ) |
| Other (expense) income, net | — |  |  | — |  |  | (88 | ) |  | 6 |  |  | — |  |  | (82 | ) |
| Equity in net income of subsidiaries | 557 |  |  | 591 |  |  | 674 |  |  | — |  |  | (1,822 | ) |  | — |  |
| Intercompany interest and fees | 3 |  |  | — |  |  | 106 |  |  | (109 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 553 |  |  | 591 |  |  | 590 |  |  | 803 |  |  | (1,822 | ) |  | 715 |  |
| Income tax (benefit) expense | (2 | ) |  | — |  |  | 1 |  |  | (99 | ) |  | — |  |  | (100 | ) |
| Income from continuing operations | 551 |  |  | 591 |  |  | 591 |  |  | 704 |  |  | (1,822 | ) |  | 615 |  |
| Loss from discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | (66 | ) |  | — |  |  | (66 | ) |
| Net income | 551 |  |  | 591 |  |  | 591 |  |  | 638 |  |  | (1,822 | ) |  | 549 |  |
| Less: noncontrolling interest in subsidiaries net loss | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 551 |  |  | $ | 591 |  |  | $ | 591 |  |  | $ | 640 |  |  | $ | (1,822 | ) |  | $ | 551 |  |

[0000833444-15-000091:notes:5]
CONDENSED CONSOLIDATING STATEMENT OF COMPREHENSIVE INCOME

[0000833444-15-000091:notes:6]
For the Year Ended September 25, 2015

[0000833444-15-000091:notes:7]
($ in millions)

[0000833444-15-000091:notes:8]
|  | TycoInternationalplc |  | TycoFire & Security Finance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 551 |  |  | $ | 591 |  |  | $ | 591 |  |  | $ | 638 |  |  | $ | (1,822 | ) |  | $ | 549 |  |
| Other comprehensive (loss) income, net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | (540 | ) |  | — |  |  | 3 |  |  | (543 | ) |  | 540 |  |  | (540 | ) |
| Defined benefit and post retirement plans | (67 | ) |  | — |  |  | — |  |  | (67 | ) |  | 67 |  |  | (67 | ) |
| Unrealized loss on marketable securities and derivative instruments | (9 | ) |  | — |  |  | — |  |  | (9 | ) |  | 9 |  |  | (9 | ) |
| Total other comprehensive (loss) income, net of tax | (616 | ) |  | — |  |  | 3 |  |  | (619 | ) |  | 616 |  |  | (616 | ) |
| Comprehensive (loss) income | (65 | ) |  | 591 |  |  | 594 |  |  | 19 |  |  | (1,206 | ) |  | (67 | ) |
| Less: comprehensive loss attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Comprehensive (loss) income attributable to Tyco ordinary shareholders | $ | (65 | ) |  | $ | 591 |  |  | $ | 594 |  |  | $ | 21 |  |  | $ | (1,206 | ) |  | $ | (65 | ) |

[0000833444-15-000091:notes:9]
CONDENSED CONSOLIDATING STATEMENT OF OPERATIONS

[0000833444-15-000091:notes:10]
For the Year Ended September 26, 2014

[0000833444-15-000091:notes:11]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | 10,332 |  |  | $ | — |  |  | $ | 10,332 |  |
| Cost of product sales | — |  |  | — |  |  | 4,250 |  |  | — |  |  | 4,250 |  |
| Cost of services | — |  |  | — |  |  | 2,297 |  |  | — |  |  | 2,297 |  |
| Selling, general and administrative expenses | (7 | ) |  | 4 |  |  | 3,040 |  |  | — |  |  | 3,037 |  |
| Separation costs | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | 47 |  |  | — |  |  | 47 |  |
| Operating income (loss) | 7 |  |  | (4 | ) |  | 697 |  |  | — |  |  | 700 |  |
| Interest income | — |  |  | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Interest expense | — |  |  | (95 | ) |  | (2 | ) |  | — |  |  | (97 | ) |
| Other (expense) income, net | (6 | ) |  | — |  |  | 5 |  |  | — |  |  | (1 | ) |
| Equity in net income of subsidiaries | 1,866 |  |  | 1,881 |  |  | — |  |  | (3,747 | ) |  | — |  |
| Intercompany interest and fees | (28 | ) |  | 105 |  |  | (72 | ) |  | (5 | ) |  | — |  |
| Income from continuing operations before income taxes | 1,839 |  |  | 1,887 |  |  | 642 |  |  | (3,752 | ) |  | 616 |  |
| Income tax expense (benefit) | 1 |  |  | (1 | ) |  | (24 | ) |  | — |  |  | (24 | ) |
| Equity gain in earnings of unconsolidated subsidiaries |  |  |  |  |  |  | 206 |  |  | — |  |  | 206 |  |
| Income from continuing operations | 1,840 |  |  | 1,886 |  |  | 824 |  |  | (3,752 | ) |  | 798 |  |
| (Loss) Income from discontinued operations, net of income taxes | (2 | ) |  | — |  |  | 1,038 |  |  | 5 |  |  | 1,041 |  |
| Net income | 1,838 |  |  | 1,886 |  |  | 1,862 |  |  | (3,747 | ) |  | 1,839 |  |
| Less: noncontrolling interest in subsidiaries net income | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net income attributable to Tyco ordinary shareholders | $ | 1,838 |  |  | $ | 1,886 |  |  | $ | 1,861 |  |  | $ | (3,747 | ) |  | $ | 1,838 |  |

[0000833444-15-000091:notes:12]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 1,838 |  |  | $ | 1,886 |  |  | $ | 1,862 |  |  | $ | (3,747 | ) |  | $ | 1,839 |  |
| Other comprehensive loss, net of tax |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | (174 | ) |  | — |  |  | (174 | ) |  | 174 |  |  | (174 | ) |
| Defined benefit and post retirement plans | (64 | ) |  | — |  |  | (64 | ) |  | 64 |  |  | (64 | ) |
| Total other comprehensive loss, net of tax | (238 | ) |  | — |  |  | (238 | ) |  | 238 |  |  | (238 | ) |
| Comprehensive income | 1,600 |  |  | 1,886 |  |  | 1,624 |  |  | (3,509 | ) |  | 1,601 |  |
| Less: comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Comprehensive income attributable to Tyco ordinary shareholders | $ | 1,600 |  |  | $ | 1,886 |  |  | $ | 1,623 |  |  | $ | (3,509 | ) |  | $ | 1,600 |  |

[0000833444-15-000091:notes:13]
For the Year Ended September 27, 2013

[0000833444-15-000091:notes:14]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | 10,058 |  |  | $ | — |  |  | $ | 10,058 |  |
| Cost of product sales | — |  |  | — |  |  | 3,985 |  |  | — |  |  | 3,985 |  |
| Cost of services | — |  |  | — |  |  | 2,404 |  |  | — |  |  | 2,404 |  |
| Selling, general and administrative expenses | 11 |  |  | 1 |  |  | 2,826 |  |  | — |  |  | 2,838 |  |
| Separation costs | 3 |  |  | — |  |  | 5 |  |  | — |  |  | 8 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | 111 |  |  | — |  |  | 111 |  |
| Operating (loss) income | (14 | ) |  | (1 | ) |  | 727 |  |  | — |  |  | 712 |  |
| Interest income | 2 |  |  | — |  |  | 14 |  |  | — |  |  | 16 |  |
| Interest expense | (1 | ) |  | (95 | ) |  | (4 | ) |  | — |  |  | (100 | ) |
| Other (expense) income, net | (31 | ) |  | — |  |  | 2 |  |  | — |  |  | (29 | ) |
| Equity in net (loss) income of subsidiaries | (12,666 | ) |  | 2,563 |  |  | — |  |  | 10,103 |  |  | — |  |
| Intercompany interest and fees | 13,248 |  |  | 122 |  |  | (13,362 | ) |  | (8 | ) |  | — |  |
| Income (loss) from continuing operations before income taxes | 538 |  |  | 2,589 |  |  | (12,623 | ) |  | 10,095 |  |  | 599 |  |
| Income tax expense | (2 | ) |  | (2 | ) |  | (104 | ) |  | — |  |  | (108 | ) |
| Equity loss in earnings of unconsolidated subsidiaries | — |  |  | — |  |  | (48 | ) |  | — |  |  | (48 | ) |
| Income (loss) from continuing operations | 536 |  |  | 2,587 |  |  | (12,775 | ) |  | 10,095 |  |  | 443 |  |
| Income from discontinued operations, net of income taxes | — |  |  | — |  |  | 82 |  |  | 8 |  |  | 90 |  |
| Net income (loss) | 536 |  |  | 2,587 |  |  | (12,693 | ) |  | 10,103 |  |  | 533 |  |
| Less: noncontrolling interest in subsidiaries net loss | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Net income (loss) attributable to Tyco ordinary shareholders | $ | 536 |  |  | $ | 2,587 |  |  | $ | (12,690 | ) |  | $ | 10,103 |  |  | $ | 536 |  |

[0000833444-15-000091:notes:15]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income (loss) | $ | 536 |  |  | $ | 2,587 |  |  | $ | (12,693 | ) |  | $ | 10,103 |  |  | $ | 533 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | (100 | ) |  | — |  |  | (100 | ) |  | 100 |  |  | (100 | ) |
| Defined benefit and post retirement plans | 79 |  |  | — |  |  | 79 |  |  | (79 | ) |  | 79 |  |
| Total other comprehensive loss, net of tax | (21 | ) |  | — |  |  | (21 | ) |  | 21 |  |  | (21 | ) |
| Comprehensive income (loss) | 515 |  |  | 2,587 |  |  | (12,714 | ) |  | 10,124 |  |  | 512 |  |
| Less: comprehensive loss attributable to noncontrolling interests | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Comprehensive income (loss) attributable to Tyco ordinary shareholders | $ | 515 |  |  | $ | 2,587 |  |  | $ | (12,711 | ) |  | $ | 10,124 |  |  | $ | 515 |  |

[0000833444-15-000091:notes:16]
CONDENSED CONSOLIDATING BALANCE SHEET

[0000833444-15-000091:notes:17]
As of September 25, 2015

[0000833444-15-000091:notes:18]
|  | TycoInternationalplc |  | TycoFire & Security Finance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,401 |  |  | $ | — |  |  | $ | 1,401 |  |
| Accounts receivable, net | — |  |  | — |  |  | — |  |  | 1,775 |  |  | — |  |  | 1,775 |  |
| Inventories | — |  |  | — |  |  | — |  |  | 627 |  |  | — |  |  | 627 |  |
| Intercompany receivables | 15 |  |  | — |  |  | 332 |  |  | 6,508 |  |  | (6,855 | ) |  | — |  |
| Prepaid expenses and other current assets | — |  |  | — |  |  | 63 |  |  | 713 |  |  | — |  |  | 776 |  |
| Deferred income taxes | — |  |  | — |  |  | — |  |  | 62 |  |  | — |  |  | 62 |  |
| Assets held for sale | — |  |  | — |  |  | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Total current assets | 15 |  |  | — |  |  | 395 |  |  | 11,098 |  |  | (6,855 | ) |  | 4,653 |  |
| Property, plant and equipment, net | — |  |  | — |  |  | — |  |  | 1,189 |  |  | — |  |  | 1,189 |  |
| Goodwill | — |  |  | — |  |  | — |  |  | 4,236 |  |  | — |  |  | 4,236 |  |
| Intangible assets, net | — |  |  | — |  |  | — |  |  | 871 |  |  | — |  |  | 871 |  |
| Investment in subsidiaries | 10,885 |  |  | 11,148 |  |  | 16,001 |  |  | — |  |  | (38,034 | ) |  | — |  |
| Intercompany loans receivable | — |  |  | — |  |  | 2,942 |  |  | 5,066 |  |  | (8,008 | ) |  | — |  |
| Other assets | 1 |  |  | — |  |  | 44 |  |  | 1,327 |  |  | — |  |  | 1,372 |  |
| Total Assets | $ | 10,901 |  |  | $ | 11,148 |  |  | $ | 19,382 |  |  | $ | 23,787 |  |  | $ | (52,897 | ) |  | $ | 12,321 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Loans payable and current maturities of long-term debt | $ | — |  |  | $ | — |  |  | $ | 967 |  |  | $ | 20 |  |  | $ | — |  |  | $ | 987 |  |
| Accounts payable | 1 |  |  | — |  |  | — |  |  | 784 |  |  | — |  |  | 785 |  |
| Accrued and other current liabilities | 88 |  |  | — |  |  | 61 |  |  | 1,537 |  |  | — |  |  | 1,686 |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 382 |  |  | — |  |  | 382 |  |
| Intercompany payables | 3,616 |  |  | — |  |  | 2,892 |  |  | 347 |  |  | (6,855 | ) |  | — |  |
| Liabilities held for sale | — |  |  | — |  |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Total current liabilities | 3,705 |  |  | — |  |  | 3,920 |  |  | 3,075 |  |  | (6,855 | ) |  | 3,845 |  |
| Long-term debt | — |  |  | — |  |  | 2,158 |  |  | 1 |  |  | — |  |  | 2,159 |  |
| Intercompany loans payable | 3,155 |  |  | — |  |  | 1,911 |  |  | 2,942 |  |  | (8,008 | ) |  | — |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 303 |  |  | — |  |  | 303 |  |
| Other liabilities | — |  |  | — |  |  | 245 |  |  | 1,693 |  |  | — |  |  | 1,938 |  |
| Total Liabilities | 6,860 |  |  | — |  |  | 8,234 |  |  | 8,014 |  |  | (14,863 | ) |  | 8,245 |  |
| Tyco Shareholders' Equity: |  |  |  |  |  |  |  |  |  |  |  |
| Ordinary shares | 4 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |
| Other shareholders' equity | 4,037 |  |  | 11,148 |  |  | 11,148 |  |  | 15,738 |  |  | (38,034 | ) |  | 4,037 |  |
| Total Tyco Shareholders' Equity | 4,041 |  |  | 11,148 |  |  | 11,148 |  |  | 15,738 |  |  | (38,034 | ) |  | 4,041 |  |
| Nonredeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 35 |  |  | — |  |  | 35 |  |
| Total Equity | 4,041 |  |  | 11,148 |  |  | 11,148 |  |  | 15,773 |  |  | (38,034 | ) |  | 4,076 |  |
| Total Liabilities, Redeemable Noncontrolling Interest and Equity | $ | 10,901 |  |  | $ | 11,148 |  |  | $ | 19,382 |  |  | $ | 23,787 |  |  | $ | (52,897 | ) |  | $ | 12,321 |  |

[0000833444-15-000091:notes:19]
As of September 26, 2014

[0000833444-15-000091:notes:20]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | — |  |  | $ | 892 |  |  | $ | — |  |  | $ | 892 |  |
| Accounts receivable, net | — |  |  | — |  |  | 1,734 |  |  | — |  |  | 1,734 |  |
| Inventories | — |  |  | — |  |  | 625 |  |  | — |  |  | 625 |  |
| Intercompany receivables | 18 |  |  | 245 |  |  | 8,102 |  |  | (8,365 | ) |  | — |  |
| Prepaid expenses and other current assets | 7 |  |  | 62 |  |  | 982 |  |  | — |  |  | 1,051 |  |
| Deferred income taxes | — |  |  | — |  |  | 304 |  |  | — |  |  | 304 |  |
| Assets held for sale | — |  |  | — |  |  | 180 |  |  | — |  |  | 180 |  |
| Total current assets | 25 |  |  | 307 |  |  | 12,819 |  |  | (8,365 | ) |  | 4,786 |  |
| Property, plant and equipment, net | — |  |  | — |  |  | 1,262 |  |  | — |  |  | 1,262 |  |
| Goodwill | — |  |  | — |  |  | 4,122 |  |  | — |  |  | 4,122 |  |
| Intangible assets, net | — |  |  | — |  |  | 712 |  |  | — |  |  | 712 |  |
| Investment in subsidiaries | 12,738 |  |  | 16,202 |  |  | — |  |  | (28,940 | ) |  | — |  |
| Intercompany loans receivable | — |  |  | 3,693 |  |  | 5,346 |  |  | (9,039 | ) |  | — |  |
| Other assets | 26 |  |  | 4 |  |  | 897 |  |  | — |  |  | 927 |  |
| Total Assets | $ | 12,789 |  |  | $ | 20,206 |  |  | $ | 25,158 |  |  | $ | (46,344 | ) |  | $ | 11,809 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |
| Loans payable and current maturities of long-term debt | $ | — |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |
| Accounts payable | 1 |  |  | — |  |  | 824 |  |  | — |  |  | 825 |  |
| Accrued and other current liabilities | 191 |  |  | 23 |  |  | 1,900 |  |  | — |  |  | 2,114 |  |
| Deferred revenue | — |  |  | — |  |  | 400 |  |  | — |  |  | 400 |  |
| Intercompany payables | 3,517 |  |  | 4,593 |  |  | 255 |  |  | (8,365 | ) |  | — |  |
| Liabilities held for sale | — |  |  | — |  |  | 118 |  |  | — |  |  | 118 |  |
| Total current liabilities | 3,709 |  |  | 4,616 |  |  | 3,517 |  |  | (8,365 | ) |  | 3,477 |  |
| Long-term debt | — |  |  | 1,441 |  |  | 2 |  |  | — |  |  | 1,443 |  |
| Intercompany loans payable | 4,180 |  |  | 1,888 |  |  | 2,971 |  |  | (9,039 | ) |  | — |  |
| Deferred revenue | — |  |  | — |  |  | 335 |  |  | — |  |  | 335 |  |
| Other liabilities | 253 |  |  | — |  |  | 1,618 |  |  | — |  |  | 1,871 |  |
| Total Liabilities | 8,142 |  |  | 7,945 |  |  | 8,443 |  |  | (17,404 | ) |  | 7,126 |  |
| Redeemable noncontrolling interest | — |  |  | — |  |  | 13 |  |  | — |  |  | 13 |  |
| Tyco Shareholders' Equity: |  |  |  |  |  |  |  |  |  |
| Ordinary shares | 208 |  |  | — |  |  | — |  |  | — |  |  | 208 |  |
| Ordinary shares held in treasury | — |  |  | — |  |  | (2,515 | ) |  | — |  |  | (2,515 | ) |
| Other shareholders' equity | 4,439 |  |  | 12,261 |  |  | 19,194 |  |  | (28,940 | ) |  | 6,954 |  |
| Total Tyco Shareholders' Equity | 4,647 |  |  | 12,261 |  |  | 16,679 |  |  | (28,940 | ) |  | 4,647 |  |
| Nonredeemable noncontrolling interest | — |  |  | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Total Equity | 4,647 |  |  | 12,261 |  |  | 16,702 |  |  | (28,940 | ) |  | 4,670 |  |
| Total Liabilities, Redeemable Noncontrolling Interest and Equity | $ | 12,789 |  |  | $ | 20,206 |  |  | $ | 25,158 |  |  | $ | (46,344 | ) |  | $ | 11,809 |  |

[0000833444-15-000091:notes:21]
CONDENSED CONSOLIDATING STATEMENT OF CASH FLOWS

[0000833444-15-000091:notes:22]
|  | TycoInternationalPlc |  | Tyco Fire & Security Finance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by (used in) operating activities | $ | 159 |  |  | $ | — |  |  | $ | (1,568 | ) |  | $ | 1,951 |  |  | $ | — |  |  | $ | 542 |  |
| Net cash used in discontinued operating activities | — |  |  | — |  |  | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | — |  |  | (246 | ) |  | — |  |  | (246 | ) |
| Proceeds from disposal of assets | — |  |  | — |  |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | — |  |  | (583 | ) |  | — |  |  | (583 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases | — |  |  | — |  |  | — |  |  | (18 | ) |  | — |  |  | (18 | ) |
| Divestiture of businesses, net of cash divested | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Net increase in intercompany loans | — |  |  | — |  |  | (41 | ) |  | — |  |  | 41 |  |  | — |  |
| Increase in investment in subsidiaries | — |  |  | — |  |  | (3 | ) |  | — |  |  | 3 |  |  | — |  |
| Sales and maturities of investments | — |  |  | — |  |  | 4 |  |  | 284 |  |  | — |  |  | 288 |  |
| Purchases of investments | — |  |  | — |  |  | (1 | ) |  | (289 | ) |  | — |  |  | (290 | ) |
| Increase in restricted cash | — |  |  | — |  |  | — |  |  | (20 | ) |  | — |  |  | (20 | ) |
| Other | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Net cash used in investing activities | — |  |  | — |  |  | (41 | ) |  | (865 | ) |  | 44 |  |  | (862 | ) |
| Net cash used in discontinued investing activities | — |  |  | — |  |  | — |  |  | (37 | ) |  | — |  |  | (37 | ) |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short-term debt | — |  |  | — |  |  | 363 |  |  | 1 |  |  | — |  |  | 364 |  |
| Repayments of short-term debt | — |  |  | — |  |  | (363 | ) |  | (1 | ) |  | — |  |  | (364 | ) |
| Proceeds from issuance of long-term debt | — |  |  | — |  |  | 2,058 |  |  | 1 |  |  |  |  | 2,059 |  |
| Repayment of long-term debt | — |  |  |  |  | (445 | ) |  | — |  |  | — |  |  | (445 | ) |
| Proceeds from exercise of share options | 85 |  |  | — |  |  | — |  |  | 7 |  |  | — |  |  | 92 |  |
| Dividends paid | (324 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (324 | ) |
| Repurchase of ordinary shares by treasury | — |  |  | — |  |  | — |  |  | (417 | ) |  | — |  |  | (417 | ) |
| Net intercompany loan borrowings (repayments) | 83 |  |  | — |  |  | — |  |  | (42 | ) |  | (41 | ) |  | — |  |
| Increase in equity from parent | — |  |  | — |  |  | — |  |  | 3 |  |  | (3 | ) |  | — |  |
| Transfer to discontinued operations | — |  |  | — |  |  | — |  |  | (40 | ) |  | — |  |  | (40 | ) |
| Payment of contingent consideration | — |  |  | — |  |  | — |  |  | (24 | ) |  |  |  | (24 | ) |
| Other | (3 | ) |  | — |  |  | (4 | ) |  | (32 | ) |  | — |  |  | (39 | ) |
| Net cash (used in) provided by financing activities | (159 | ) |  | — |  |  | 1,609 |  |  | (544 | ) |  | (44 | ) |  | 862 |  |
| Net cash provided by discontinued financing activities | — |  |  | — |  |  | — |  |  | 40 |  |  | — |  |  | 40 |  |
| Effect of currency translation on cash | — |  |  | — |  |  | — |  |  | (33 | ) |  | — |  |  | (33 | ) |
| Net increase in cash and cash equivalents | — |  |  | — |  |  | — |  |  | 509 |  |  | — |  |  | 509 |  |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | — |  |  | 892 |  |  | — |  |  | 892 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,401 |  |  | $ | — |  |  | $ | 1,401 |  |

[0000833444-15-000091:notes:23]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |
| Net cash (used in) provided by operating activities | $ | (205 | ) |  | $ | 592 |  |  | $ | 442 |  |  | $ | — |  |  | $ | 829 |  |
| Net cash provided by discontinued operating activities | — |  |  | — |  |  | 83 |  |  | — |  |  | 83 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | (288 | ) |  | — |  |  | (288 | ) |
| Proceeds from disposal of assets | — |  |  | — |  |  | 10 |  |  | — |  |  | 10 |  |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | (65 | ) |  | — |  |  | (65 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases | — |  |  | — |  |  | (25 | ) |  | — |  |  | (25 | ) |
| Divestiture of businesses, net of cash divested | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Net increase in intercompany loans | — |  |  | (521 | ) |  | — |  |  | 521 |  |  | — |  |
| Increase (decrease) in investment in subsidiaries | (4 | ) |  | (9 | ) |  | 4 |  |  | 9 |  |  | — |  |
| Sales and maturities of investments | — |  |  | — |  |  | 283 |  |  | — |  |  | 283 |  |
| Purchases of investments | — |  |  | (62 | ) |  | (324 | ) |  | — |  |  | (386 | ) |
| Sale of equity investment | — |  |  | — |  |  | 250 |  |  | — |  |  | 250 |  |
| Decrease in restricted cash | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Other | — |  |  | — |  |  | (4 | ) |  | — |  |  | (4 | ) |
| Net cash used in investing activities | (4 | ) |  | (592 | ) |  | (155 | ) |  | 530 |  |  | (221 | ) |
| Net cash provided by discontinued investing activities | — |  |  | — |  |  | 1,789 |  |  | — |  |  | 1,789 |  |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short term debt | — |  |  | 830 |  |  | — |  |  | — |  |  | 830 |  |
| Repayment of short term debt | — |  |  | (830 | ) |  | (1 | ) |  | — |  |  | (831 | ) |
| Proceeds from exercise of share options | — |  |  | — |  |  | 91 |  |  | — |  |  | 91 |  |
| Dividends paid | (311 | ) |  | — |  |  | — |  |  | — |  |  | (311 | ) |
| Repurchase of ordinary shares by treasury | — |  |  | — |  |  | (1,833 | ) |  | — |  |  | (1,833 | ) |
| Net intercompany loan borrowings | 520 |  |  | — |  |  | 1 |  |  | (521 | ) |  | — |  |
| Increase in equity from parent | — |  |  | — |  |  | 9 |  |  | (9 | ) |  | — |  |
| Purchase of noncontrolling interest | — |  |  | — |  |  | (66 | ) |  | — |  |  | (66 | ) |
| Transfer from discontinued operations | — |  |  | — |  |  | 1,872 |  |  | — |  |  | 1,872 |  |
| Other | — |  |  | — |  |  | (11 | ) |  | — |  |  | (11 | ) |
| Net cash provided by (used in) financing activities | 209 |  |  | — |  |  | 62 |  |  | (530 | ) |  | (259 | ) |
| Net cash used in discontinued financing activities | — |  |  | — |  |  | (1,872 | ) |  | — |  |  | (1,872 | ) |
| Effect of currency translation on cash | — |  |  | — |  |  | (20 | ) |  | — |  |  | (20 | ) |
| Net increase in cash and cash equivalents | — |  |  | — |  |  | 329 |  |  | — |  |  | 329 |  |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | 563 |  |  | — |  |  | 563 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | — |  |  | $ | 892 |  |  | $ | — |  |  | $ | 892 |  |

[0000833444-15-000091:notes:24]
|  | TycoInternationalLtd. |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |
| Net cash (used in) provided by operating activities | $ | (251 | ) |  | $ | 452 |  |  | $ | 500 |  |  | $ | — |  |  | $ | 701 |  |
| Net cash provided by discontinued operating activities | — |  |  | — |  |  | 149 |  |  | — |  |  | 149 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | (269 | ) |  | — |  |  | (269 | ) |
| Proceeds from disposal of assets | — |  |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | (229 | ) |  | — |  |  | (229 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases | — |  |  | — |  |  | (19 | ) |  | — |  |  | (19 | ) |
| Divestiture of businesses, net of cash divested | — |  |  | — |  |  | 17 |  |  | — |  |  | 17 |  |
| Intercompany dividend from subsidiary | — |  |  | 32 |  |  | — |  |  | (32 | ) |  | — |  |
| Net increase in intercompany loans | — |  |  | (431 | ) |  | — |  |  | 431 |  |  | — |  |
| Decrease in investment in subsidiaries | — |  |  | 8 |  |  | — |  |  | (8 | ) |  | — |  |
| Sales and maturities of investments | — |  |  | — |  |  | 182 |  |  | — |  |  | 182 |  |
| Purchases of investments | — |  |  | — |  |  | (227 | ) |  | — |  |  | (227 | ) |
| Increase in restricted cash | — |  |  | — |  |  | (8 | ) |  | — |  |  | (8 | ) |
| Other | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Net cash used in investing activities | — |  |  | (391 | ) |  | (544 | ) |  | 391 |  |  | (544 | ) |
| Net cash used in discontinued investing activities | — |  |  | — |  |  | (111 | ) |  | — |  |  | (111 | ) |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short term debt | — |  |  | 475 |  |  | — |  |  | — |  |  | 475 |  |
| Repayment of short term debt | — |  |  | (475 | ) |  | (30 | ) |  | — |  |  | (505 | ) |
| Proceeds from exercise of share options | — |  |  | — |  |  | 153 |  |  | — |  |  | 153 |  |
| Dividends paid | (288 | ) |  | — |  |  | — |  |  | — |  |  | (288 | ) |
| Intercompany dividend to parent | — |  |  | — |  |  | (32 | ) |  | 32 |  |  | — |  |
| Repurchase of ordinary shares by treasury | — |  |  | — |  |  | (300 | ) |  | — |  |  | (300 | ) |
| Net intercompany loan borrowings (repayments) | 449 |  |  | — |  |  | (18 | ) |  | (431 | ) |  | — |  |
| Decrease in equity from parent | — |  |  | — |  |  | (8 | ) |  | 8 |  |  | — |  |
| Transfer from (to) discontinued operations | 90 |  |  | (61 | ) |  | 39 |  |  | — |  |  | 68 |  |
| Other | — |  |  | — |  |  | (30 | ) |  | — |  |  | (30 | ) |
| Net cash provided by (used in) financing activities | 251 |  |  | (61 | ) |  | (226 | ) |  | (391 | ) |  | (427 | ) |
| Net cash used in discontinued financing activities | — |  |  | — |  |  | (68 | ) |  | — |  |  | (68 | ) |
| Effect of currency translation on cash | — |  |  | — |  |  | (11 | ) |  | — |  |  | (11 | ) |
| Net decrease in cash and cash equivalents | — |  |  | — |  |  | (311 | ) |  | — |  |  | (311 | ) |
| Less: net increase in cash and cash equivalents related to discontinued operations | — |  |  | — |  |  | (30 | ) |  | — |  |  | (30 | ) |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | 844 |  |  | — |  |  | 844 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | — |  |  | $ | 563 |  |  | $ | — |  |  | $ | 563 |  |


## tyc:GuaranteesDisclosureTextBlock

[0000833444-15-000091:notes:25]
Guarantees

[0000833444-15-000091:notes:26]
Certain of the Company's subsidiaries at the business segment level have guaranteed the performance of third-parties and provided financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from the current fiscal year through the completion of such transactions and would typically be triggered in the event of nonperformance.  Performance under the guarantees, if required, would not have a material effect on the Company's financial position, results of operations or cash flows.

[0000833444-15-000091:notes:27]
There are certain guarantees or indemnifications extended among Tyco, Medtronic, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 Separation and Distribution Agreements and Tax Sharing Agreements. These guarantees primarily relate to certain contingent tax liabilities included in the Tax Sharing Agreements. See Note 6.

[0000833444-15-000091:notes:28]
In addition, Tyco historically provided support in the form of financial and/or performance guarantees to various Medtronic, TE Connectivity, ADT and Tyco Flow Control operating entities. In connection with both the 2007 and 2012 Separations, the Company worked with the guarantee counterparties to cancel or assign these guarantees to Medtronic, TE Connectivity, ADT or Pentair, as appropriate. To the extent these guarantees were not assigned prior to the Separation dates, Tyco remained as the guarantor, but was typically indemnified by the former subsidiary. The Company's obligations related to the 2012 Separation were $3 million, which were included in Other liabilities within the Company's Consolidated Balance Sheets as of both September 25, 2015 and September 26, 2014, with an offset to Tyco shareholders' equity on the 2012 Separation date. The Company's obligations related to the 2007 Separation were $3 million, which were included in Other liabilities within the Company's Consolidated Balance Sheets as of both September 25, 2015 and September 26, 2014, with an offset to Tyco shareholders' equity on the 2007 Separation date.

[0000833444-15-000091:notes:29]
In disposing of assets or businesses, the Company or its subsidiaries often provides representations, warranties and/or indemnities to cover various risks including, for example, unknown damage to the assets, environmental risks involved in the sale of real estate, liability to investigate and remediate environmental contamination at waste disposal sites and manufacturing facilities and unidentified tax liabilities and legal fees related to periods prior to disposition. The Company has no reason to believe that these contingencies, if realized, would have a material adverse effect on the Company's financial position, results of operations or cash flows. The Company has recorded liabilities for known indemnifications included as part of environmental liabilities. See Note 12 for further details on environmental matters.

[0000833444-15-000091:notes:30]
In the normal course of business, the Company is liable for contract completion and product performance. In the opinion of management, such obligations will not significantly affect the Company's financial position, results of operations or cash flows.

[0000833444-15-000091:notes:31]
During the year ended September 26, 2014, Tyco replaced available for sale investments held as collateral for the Company's insurable liabilities with letters of credit.  As of September 25, 2015 and September 26, 2014, the Company had total outstanding letters of credit and bank guarantees of approximately $581 million and $662 million respectively.

[0000833444-15-000091:notes:32]
The Company records estimated product warranty costs at the time of sale. See Note 1.

[0000833444-15-000091:notes:33]
The changes in the carrying amount of the Company's warranty accrual from September 26, 2014 to September 25, 2015 were as follows ($ in millions):

[0000833444-15-000091:notes:34]
| Balance as of September 26, 2014 | $ | 28 |  |
| Warranties issued | 20 |  |
| Changes in estimates | (3 | ) |
| Settlements | (13 | ) |
| Currency translation | (2 | ) |
| Balance as of September 25, 2015 | $ | 30 |  |

[0000833444-15-000091:notes:35]
Warranty accruals for businesses that are included in Liabilities held for sale within the Consolidated Balance Sheets are excluded from the table above.  See Note 3.


## tyc:InsurableLiabilitiesPolicyTextBlock

[0000833444-15-000091:notes:36]
Insurable Liabilities—The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. Certain insurable liabilities, such as workers' compensation, are discounted using a risk-free rate of return when the pattern and timing of the future obligation is reliably determinable. The impact of the discount on the Consolidated Balance Sheets was to reduce the obligation by $14 million to $67 million as of September 25, 2015 and by $17 million to $74 million as of September 26, 2014. The Company records receivables from third party insurers when recovery has been determined to be probable. The Company maintains captive insurance companies to manage certain of its insurable liabilities. During fiscal 2013 and a portion of 2014, the captive insurance companies held certain investment accounts for the purpose of providing collateral for the Company's insurable liabilities. These investment accounts were liquidated during fiscal 2014. See Note 10.


## tyc:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesAndNewAccountingPronouncementsTextBlock

[0000833444-15-000091:notes:37]
Basis of Presentation and Summary of Significant Accounting Policies

[0000833444-15-000091:notes:38]
Basis of Presentation—The Consolidated Financial Statements include the consolidated accounts of Tyco International plc., a corporation organized under the laws of Ireland, and its subsidiaries (Tyco and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Tyco"). The financial statements have been prepared in United States dollars ("USD") and in accordance with generally accepted accounting principles in the United States ("GAAP"). Unless otherwise indicated, references to 2015, 2014 and 2013 are to Tyco's fiscal years ending September 25, 2015, September 26, 2014 and September 27, 2013, respectively.

[0000833444-15-000091:notes:39]
Effective September 28, 2012, Tyco completed the spin-offs of The ADT Corporation ("ADT") and Pentair Ltd. (formerly known as Tyco Flow Control International Ltd. ("Tyco Flow Control")), formerly the North American residential security and flow control businesses of Tyco, respectively, into separate, publicly traded companies in the form of a distribution to Tyco shareholders. Immediately following the spin-off, Pentair, Inc. was merged with a subsidiary of Tyco Flow Control in a tax-free, all-stock merger (the "Merger"), with Pentair Ltd. ("Pentair") succeeding Pentair Inc. as an independent publicly traded company. The distribution was made on September 28, 2012, to Tyco shareholders of record on September 17, 2012. Each Tyco shareholder received 0.50 of an ordinary share of ADT and approximately 0.24 of a common share of Pentair for each Tyco common share held on the record date. The distribution was structured to be tax-free to Tyco shareholders except to the extent of cash received in lieu of fractional shares. The distributions, the Merger and related transactions are collectively referred to herein as the "2012 Separation".

[0000833444-15-000091:notes:40]
Effective June 29, 2007, the Company completed the spin-offs of Covidien (subsequently acquired by Medtronic plc) and TE Connectivity, formerly the Healthcare and Electronics businesses of Tyco, respectively, into separate, public traded companies (the "2007 Separation") in the form of a tax-free distribution to Tyco shareholders.

[0000833444-15-000091:notes:41]
During the fourth quarter of fiscal 2015, the Company changed the name of its North America Installation & Services and Rest of World Installation & Services segments to North America Integrated Solutions & Services and Rest of World Integrated Solutions & Services, respectively. The segment reporting structure is consistent with how management reviews the businesses, makes investing and resource decisions and assesses operating performance. The name changes better reflect the Company's focus on providing technology solutions that encompass a mix of products, services and consultation that is tailored to the unique needs of each customer. No changes were made to the current segment structure or underlying financial data that comprise each segment as a result of the name changes and there was no impact to previously disclosed segment information.

[0000833444-15-000091:notes:42]
The Company operates and reports financial and operating information in the following three segments: North America Integrated Solutions & Services ("NA Integrated Solutions & Services"), Rest of World Integrated Solutions & Services ("ROW Integrated Solutions & Services") and Global Products. The Company also provides general corporate services to its segments which is reported as a fourth, non-operating segment, Corporate and Other.

[0000833444-15-000091:notes:43]
Change of Jurisdiction— On May 30, 2014, Tyco entered into a Merger Agreement ("Merger Agreement") with Tyco International plc, a newly-formed Irish public limited company and a wholly-owned subsidiary of Tyco ("Tyco Ireland").  Under the Merger Agreement, Tyco merged with and into Tyco Ireland, with Tyco Ireland being the surviving company.  This resulted in Tyco Ireland becoming Tyco's publicly-traded parent company and changed the jurisdiction of organization of Tyco from Switzerland to Ireland.  Tyco's shareholders received one ordinary share of Tyco Ireland for each ordinary share of Tyco held immediately prior to the re-domicile to Ireland.  The re-domicile to Ireland became effective in November 17, 2014.

[0000833444-15-000091:notes:44]
Reclassifications— Certain prior period amounts have been reclassified to conform with the current period presentation. The Company completed the sale of several ROW Integrated Solutions & Services businesses during the third quarter of fiscal 2015. The assets and liabilities related to these ROW Integrated Solutions & Services businesses were classified as held for sale of as September 26, 2014, and the results of operations of two of these businesses are included in discontinued operations for all periods presented, as the criteria to be presented as a discontinued operation were not satisfied for the third business.

[0000833444-15-000091:notes:45]
The Company expects to complete the sale of another of its ROW Integrated Solutions & Services businesses during the first half of fiscal 2016.  The assets and liabilities of this business are classified as held for sale, and its results of operations are presented as discontinued operations for all periods presented.  See Note 3.

[0000833444-15-000091:notes:46]
Principles of Consolidation—Tyco conducts business through its operating subsidiaries. The Company consolidates companies in which it owns or controls more than fifty percent of the voting shares or has the ability to control through similar rights. Also, the Company consolidates variable interest entities ("VIE") in which the Company has the power to direct the significant activities of the entity and the obligation to absorb losses or receive benefits from the entity that may be significant. The VIEs which the Company consolidates, individually or in the aggregate, did not have a material impact on the Company's financial position, results of operations or cash flows. All intercompany transactions have been eliminated. The results of companies acquired or disposed of during the year are included in the Consolidated Financial Statements from the effective date of acquisition or up to the date of disposal.

[0000833444-15-000091:notes:47]
The Company has a 52 or 53-week fiscal year that ends on the last Friday in September. Fiscal 2015, 2014 and 2013 were 52 week years which ended on September 25, 2015, September 26, 2014 and September 27, 2013, respectively. Fiscal 2016 will be a 53-week year which will end on September 30, 2016.

[0000833444-15-000091:notes:48]
Use of Estimates—The preparation of the Consolidated Financial Statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amount of assets and liabilities, disclosure of contingent assets and liabilities and reported amounts of revenues and expenses. Significant estimates in these Consolidated Financial Statements include restructuring charges, allowances for doubtful accounts receivable, estimates of future cash flows associated with asset impairments, useful lives for depreciation and amortization, loss contingencies (including legal, environmental and asbestos reserves), insurance reserves, net realizable value of inventories, fair values of financial instruments, estimated contract revenue and related costs, income taxes and tax valuation allowances, and pension and postretirement employee benefit liabilities and expenses. Actual results could differ materially from these estimates.

[0000833444-15-000091:notes:49]
Revenue Recognition—The Company recognizes revenue principally on four types of transactions—sales of products, security systems, monitoring and maintenance services, and contract sales, including the installation of fire and security systems and other construction-related projects.

[0000833444-15-000091:notes:50]
Revenue from the sales of products is recognized at the time title and risks and rewards of ownership pass. This is generally when the products reach the free-on-board shipping point, the sales price is fixed and determinable and collection is reasonably assured.

[0000833444-15-000091:notes:51]
Provisions for certain rebates, sales incentives, trade promotions, product returns and discounts to customers are accounted for as reductions in determining net revenue in the same period the related sales are recorded. These provisions are based on terms of arrangements with direct, indirect and other market participants. Rebates are estimated based on sales terms, historical experience and trend analysis.

[0000833444-15-000091:notes:52]
Sales of security monitoring systems may have multiple elements, including equipment, installation, monitoring services and maintenance agreements. The Company assesses its revenue arrangements to determine the appropriate units of accounting. When ownership of the system is transferred to the customer, each deliverable provided under the arrangement is considered a separate unit of accounting. Revenues associated with sale of equipment and related installations are recognized once delivery, installation and customer acceptance is completed, while the revenue for monitoring and maintenance services are recognized as services are rendered. Amounts assigned to each unit of accounting are based on an allocation of total arrangement consideration using a hierarchy of estimated selling price for the deliverables. The selling price used for each deliverable will be based on Vendor Specific Objective Evidence ("VSOE") if available, Third Party Evidence ("TPE") if VSOE is not available, or estimated selling price if neither VSOE or TPE is available. Revenue recognized for equipment and installation is limited to the lesser of their allocated amounts under the estimated selling price hierarchy or the non-contingent up-front consideration received at the time of installation, since collection of future amounts under the arrangement with the customer is contingent upon the delivery of monitoring and maintenance services. While the Company does not expect situations where VSOE is not available for sales of security systems and services, if such cases were to arise the Company would follow the selling price hierarchy to allocate arrangement consideration. For transactions in which the Company retains ownership of the subscriber system asset, fees for monitoring and maintenance services are recognized on a straight-line basis over the contract term. Non-refundable fees received in connection with the initiation of a monitoring contract, along with associated direct and incremental selling costs, are deferred and amortized over the estimated life of the customer relationship.

[0000833444-15-000091:notes:53]
Revenue from the sale of services is recognized as services are rendered. Customer billings for services not yet rendered are deferred and recognized as revenue as the services are rendered and the associated deferred revenue is included in current liabilities or long-term liabilities, as appropriate.

[0000833444-15-000091:notes:54]
Contract sales for the installation of fire protection systems, large security intruder systems and other construction-related projects are recorded primarily under the percentage-of-completion method. Profits recognized on contracts in process are based upon estimated contract revenue and related total cost of the project at completion. The extent of progress toward completion is generally measured based on the ratio of actual cost incurred to total estimated cost at completion. Revisions to cost estimates as contracts progress have the effect of increasing or decreasing profits each period. Provisions for anticipated losses are made in the period in which they become determinable. Estimated warranty costs are included in total estimated contract costs and are accrued over the construction period of the respective contracts under percentage-of-completion accounting.

[0000833444-15-000091:notes:55]
The Company recorded retainage receivables of $54 million and $53 million as of September 25, 2015 and September 26, 2014, respectively, of which $45 million and $42 million were unbilled, respectively. The retainage provisions consist primarily of fire protection contracts which become due upon contract completion and acceptance. The Company expects approximately $42 million to be collected during fiscal 2016, which are reflected in Accounts receivable within the Consolidated Balance Sheet as of September 25, 2015.

[0000833444-15-000091:notes:56]
Research and Development—Research and development expenditures are expensed when incurred and are included in Cost of product sales within the Consolidated Statements of Operations, which amounted to $212 million, $193 million and $172 million for fiscal years 2015, 2014 and 2013, respectively, related to new product development. Research and development expenses include salaries, direct costs incurred and building and overhead expenses.

[0000833444-15-000091:notes:57]
Advertising—Advertising costs are expensed when incurred and are included in Selling, general and administrative expenses within the Consolidated Statements of Operations, which amounted to $22 million, $48 million and $60 million for fiscal years 2015, 2014 and 2013, respectively.

[0000833444-15-000091:notes:58]
Translation of Foreign Currency—For the Company's non-U.S. subsidiaries whose books are in a functional currency other than U.S. dollars, assets and liabilities are translated into U.S. dollars using period-end exchange rates. Revenue and expenses are translated at the average exchange rates in effect during the period. Foreign currency translation gains and losses are included as a component of Accumulated other comprehensive loss within the Consolidated Statement of Shareholders' Equity.

[0000833444-15-000091:notes:59]
Cash and Cash Equivalents—All highly liquid investments with original maturities of three months or less are considered to be cash equivalents.

[0000833444-15-000091:notes:60]
Allowance for Doubtful Accounts—The allowance for doubtful accounts receivable reflects the best estimate of probable losses inherent in Tyco's receivable portfolio determined on the basis of historical experience, specific allowances for known troubled accounts and other currently available evidence.

[0000833444-15-000091:notes:61]
Inventories—Inventories are recorded at the lower of cost (primarily first-in, first-out) or market value.

[0000833444-15-000091:notes:62]
Property, Plant and Equipment, Net—Property, plant and equipment, net is recorded at cost less accumulated depreciation. Depreciation expense for fiscal years 2015, 2014 and 2013 was $254 million, $267 million and $285 million, respectively, and is recorded in Cost of product sales, Cost of services and Selling, general and administrative expenses within the Consolidated Statement of Operations. Maintenance and repair expenditures are charged to expense when incurred. Except for pooled subscriber systems which are depreciated on an accelerated basis over a period of up to 15 years, depreciation is calculated using the straight-line method over the estimated useful lives of the related assets as follows:

[0000833444-15-000091:notes:63]
| Buildings and related improvements | Up to 50 years |
| Leasehold improvements | Lesser of remaining term of the lease or economic useful life |
| Subscriber systems | Up to 14 years |
| Other machinery, equipment and furniture and fixtures | Up to 21 years |

[0000833444-15-000091:notes:64]
See below for discussion of depreciation method and estimated useful lives related to subscriber systems.

[0000833444-15-000091:notes:65]
Subscriber System Assets, Dealer Intangibles and Related Deferred Revenue Accounts—The Company considers assets related to the acquisition of new customers in its electronic security business in three asset categories: internally generated residential subscriber systems outside of North America, internally generated commercial subscriber systems (collectively referred to as subscriber system assets) and customer accounts acquired through the ADT dealer program, primarily outside of North America (referred to as dealer intangibles). Subscriber system assets include installed property, plant and equipment for which Tyco retains ownership and deferred costs directly related to the customer acquisition and system installation. Subscriber system assets represent capitalized equipment (e.g. security control panels, touchpad, motion detectors, window sensors, and other equipment) and installation costs associated with electronic security monitoring arrangements under which the Company retains ownership of the security system assets in a customer's place of business, or outside of North America, residence. Installation costs represent costs incurred to prepare the asset for its intended use. The Company pays property taxes on the subscriber system assets and upon customer termination, may retrieve such assets. These assets embody a probable future economic benefit as they generate future monitoring revenue for the Company.

[0000833444-15-000091:notes:66]
Costs related to the subscriber system equipment and installation are categorized as property, plant and equipment rather than deferred costs. Deferred costs associated with subscriber system assets represent direct and incremental selling expenses (such as commissions) related to acquiring the customer. Commissions related to up-front consideration paid by customers in connection with the establishment of the monitoring arrangement are determined based on a percentage of the up-front fees and do not exceed deferred revenue. Such deferred costs are recorded as non-current assets and are included in Other assets within the Consolidated Balance Sheets.

[0000833444-15-000091:notes:67]
Subscriber system assets and any deferred revenue resulting from the customer acquisition are accounted for over the expected life of the subscriber. In certain geographical areas where the Company has a large number of customers that behave in a similar manner over time, the Company accounts for subscriber system assets and related deferred revenue using pools, with separate pools for the components of subscriber system assets and any related deferred revenue based on the same month and year of acquisition. The Company depreciates its pooled subscriber system assets and related deferred revenue using an accelerated method with lives up to 15 years. The accelerated method utilizes declining balance rates based on geographical area ranging from 140% to 360% for commercial subscriber pools and dealer intangibles and converts to a straight-line methodology when the resulting depreciation charge is greater than that from the accelerated method. The Company uses a straight-line method with a 14-year life for non-pooled subscriber system assets (primarily in Europe, Latin America and Asia) and related deferred revenue, with remaining balances written off upon customer termination.

[0000833444-15-000091:notes:68]
Certain contracts and related customer relationships result from purchasing residential security monitoring contracts from an external network of independent dealers who operate under the ADT dealer program, primarily outside of North America. Acquired contracts and related customer relationships are recorded at their contractually determined purchase price.

[0000833444-15-000091:notes:69]
During the first 6 months (12 months in certain circumstances) after the purchase of the customer contract, any cancellation of monitoring service, including those that result from customer payment delinquencies, results in a chargeback by the Company to the dealer for the full amount of the contract purchase price. The Company records the amount charged back to the dealer as a reduction of the previously recorded intangible asset.

[0000833444-15-000091:notes:70]
Intangible assets arising from the ADT dealer program described above are amortized in pools determined by the same month and year of contract acquisition on an accelerated basis over the period and pattern of economic benefit that is expected to be obtained from the customer relationship.

[0000833444-15-000091:notes:71]
The estimated useful life of dealer intangibles ranges from 12 to 15 years. The Company amortizes dealer intangible assets on an accelerated basis.

[0000833444-15-000091:notes:72]
Other Amortizable Intangible Assets, Net—Intangible assets primarily include contracts and related customer relationships (dealer accounts discussed above) and intellectual property.

[0000833444-15-000091:notes:73]
Other contracts and related customer relationships, as well as intellectual property consisting primarily of patents, trademarks, copyrights and unpatented technology, are amortized on a straight-line basis over 4 to 40 years. The Company evaluates the amortization methods and remaining useful lives of intangible assets on a periodic basis to determine whether events and circumstances warrant a revision to the amortization method or remaining useful lives.

[0000833444-15-000091:notes:74]
Long-Lived Asset Impairments—The Company reviews long-lived assets, including property, plant and equipment and amortizable intangible assets, for impairment whenever events or changes in business circumstances indicate that the carrying amount of the asset may not be fully recoverable. Tyco performs undiscounted operating cash flow analyses to determine if impairment exists. For purposes of recognition and measurement of an impairment for assets held for use, Tyco groups assets and liabilities at the lowest level for which cash flows are separately identified. If an impairment is determined to exist, any related impairment loss is calculated based on fair value. Impairment losses on assets to be disposed of, if any, are based on the estimated proceeds to be received, less costs of disposal.

[0000833444-15-000091:notes:75]
Goodwill and Indefinite-Lived Intangible Asset Impairments—Goodwill and indefinite-lived intangible assets are assessed for impairment annually and more frequently if triggering events occur (see Note 8). In performing these assessments, management relies on and considers a number of factors, including operating results, business plans, economic projections, anticipated future cash flows, comparable market transactions (to the extent available), other market data and the Company's overall market capitalization. There are inherent uncertainties related to these factors which require judgment in applying them to the analysis of goodwill and indefinite-lived intangible assets for impairment. The Company elected to make the first day of the fourth quarter the annual impairment assessment date for all goodwill and indefinite-lived intangible assets.

[0000833444-15-000091:notes:76]
When testing for goodwill impairment, the Company first assesses qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount.  If the Company concludes it is more likely than not that the fair value of a reporting unit is less than its carrying amount, a quantitative fair value test is performed.  Based upon the Company’s most recent annual impairment test completed as of June 29, 2015, it is not more likely than not that the fair value of each reporting unit was less than its carrying value.

[0000833444-15-000091:notes:77]
Indefinite-lived intangible assets consisting primarily of trade names and franchise rights are tested for impairment using either a relief-from-royalty method or excess earnings method, respectively.

[0000833444-15-000091:notes:78]
Investments—The Company invests in debt and equity securities. Long-term investments in marketable equity securities that represent less than twenty percent ownership are marked to market at the end of each accounting period. Unrealized gains and losses are recognized in Accumulated other comprehensive loss within the Consolidated Statement of Shareholders' Equity  for available for sale securities unless an unrealized loss is deemed to be other than temporary, in which case such loss is charged to earnings.  Unrealized gains and losses are recognized in Other income (expense), net for trading securities. Management determines the proper classification of investments at the time of purchase and reevaluates such classifications as of each balance sheet date. Realized gains and losses on sales of investments are recorded in Other income (expense), net within the Consolidated Statements of Operations.

[0000833444-15-000091:notes:79]
Other equity investments for which the Company does not have the ability to exercise significant influence and for which there is not a readily determinable market value are accounted for under the cost method of accounting. Each reporting period, the Company evaluates the carrying value of its investments accounted for under the cost method of accounting, such that they are recorded at the lower of cost or estimated net realizable value. For equity investments in which the Company exerts significant influence over operating and financial policies but does not control, the equity method of accounting is used. The Company's share of net income or losses of equity investments is included in Equity income (loss) in earnings of unconsolidated subsidiaries or Selling, general and administrative expenses within the Consolidated Statements of Operations, depending on the nature of the investment. See Note 11.

[0000833444-15-000091:notes:80]
Product Warranty—The Company records estimated product warranty costs at the time of sale. Products are warranted against defects in material and workmanship when properly used for their intended purpose, installed correctly, and appropriately maintained. Generally, product warranties are implicit in the sale; however, the customer may purchase an extended warranty. However, in most instances the warranty is either negotiated in the contract or sold as a separate component. The warranty liability is determined based on historical information such as past experience, product failure rates or number of units repaired, estimated cost of material and labor, and in certain instances estimated property damage. See Note 10.

[0000833444-15-000091:notes:81]
Environmental Costs—The Company is subject to laws and regulations relating to protecting the environment. Tyco provides for expenses associated with environmental remediation obligations when such amounts are probable and can be reasonably estimated. See Note 12.

[0000833444-15-000091:notes:82]
Income Taxes—Deferred tax liabilities and assets are recognized for the expected future tax consequences of events that have been reflected in the Consolidated Financial Statements. Deferred tax liabilities and assets are determined based on the differences between the book and tax bases of particular assets and liabilities and operating loss carryforwards, using tax rates in effect for the years in which the differences are expected to reverse. A valuation allowance is provided to offset deferred tax assets if, based upon the available evidence, including consideration of tax planning strategies, it is more-likely-than-not that some or all of the deferred tax assets will not be realized. See Note 6.

[0000833444-15-000091:notes:83]
Fair Value of Financial Instruments—Authoritative guidance for fair value measurements establishes a three-level hierarchy that ranks the quality and reliability of information used in developing fair value estimates for financial instruments. The hierarchy gives the highest priority to quoted prices in active markets and the lowest priority to unobservable data. In cases where two or more levels of inputs are used to determine fair value, a financial instrument's level is determined based on the lowest level input that is considered significant to the fair value measurement in its entirety. The three levels of the fair value hierarchy are summarized as follows:

[0000833444-15-000091:notes:84]
| • | Level 1—inputs are based upon quoted prices (unadjusted) in active markets for identical assets or liabilities which are accessible as of the measurement date. |

[0000833444-15-000091:notes:85]
| • | Level 2—inputs are based upon quoted prices for similar assets or liabilities in active markets, quoted prices for identical or similar assets or liabilities in markets that are not active, and model-derived valuations for the asset or liability that are derived principally from or corroborated by market data for which the primary inputs are observable, including forward interest rates, yield curves, credit risk and exchange rates. |

[0000833444-15-000091:notes:86]
| • | Level 3—inputs for the valuations are unobservable and are based on management's estimates and assumptions that market participants would use similar inputs in pricing the asset or liability. The fair values are therefore determined using model-based techniques such as option pricing models and discounted cash flow models. |

[0000833444-15-000091:notes:87]
Financial Instruments—The Company may use interest rate swaps, currency swaps, forward and option contracts and commodity swaps to manage risks generally associated with interest rate risk, foreign exchange risk and commodity prices. Derivatives used for hedging purposes are designated and effective as a hedge of the identified risk exposure at the inception of the contract. Accordingly, changes in fair value of the derivative contract are highly effective at offsetting the changes in the fair value of the underlying hedged item at inception of the hedge and are expected to remain highly effective over the life of the hedge contract.

[0000833444-15-000091:notes:88]
All derivative financial instruments are reported within the Consolidated Balance Sheets at fair value. Derivatives used to economically hedge foreign currency denominated balance sheet items related to operating activities are reported in Selling, general and administrative expenses along with offsetting transaction gains and losses on the items being hedged. Derivatives used to manage the exposure to changes in interest rates are reported in Interest expense along with offsetting transaction gains and losses on the items being hedged within the Consolidated Statements of Operations. Gains and losses on net investment hedges are included in the cumulative translation adjustment ("CTA") component of Accumulated other comprehensive loss to the extent they are effective within the Consolidated Statement of Shareholders' Equity. Gains and losses on derivatives designated as cash flow hedges are recorded in Accumulated other comprehensive loss within the Consolidated Statement of Shareholders' Equity and reclassified to earnings in a manner that matches the timing of the earnings impact of the hedged transactions. The Company classifies cash flows associated with the settlement of derivatives consistent with the nature of the transaction being hedged. The ineffective portion of all hedges, if any, is recognized currently in earnings. Instruments that do not qualify for hedge accounting are marked to market with changes recognized in current earnings. See Note 11.

[0000833444-15-000091:notes:89]
Redeemable Noncontrolling Interests—Noncontrolling interest with redemption features, such as put options, that are not solely within the Company's control are considered redeemable noncontrolling interests. The Company accretes changes in the redemption value through noncontrolling interest in subsidiaries net income attributable to the noncontrolling interest over the period from the date of issuance to the earliest redemption date. Redeemable noncontrolling interest is considered to be temporary equity and is therefore reported in the mezzanine section between liabilities and equity on the Company's Consolidated Balance Sheet at the greater of the initial carrying amount increased or decreased for the noncontrolling interest's share of net income or loss or its redemption value.

[0000833444-15-000091:notes:90]
Recently Adopted Accounting Pronouncements - In March 2013, the Financial Accounting Standards Board ("FASB") issued authoritative guidance to resolve diversity in practice on the accounting for CTA when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets within a foreign entity. The guidance requires that the parent release any CTA into net income when the parent ceases to have a controlling financial interest in a subsidiary or group of assets within a foreign entity which results in a substantially complete liquidation of the foreign entity; when the sale of an investment in a foreign entity results in the loss of a controlling financial interest; or where an acquirer obtains control of an acquiree in which it had an equity interest immediately before the acquisition date. The guidance does not change the requirement to release a pro rata portion of the CTA into net income upon a partial sale of an equity method investment that is a foreign entity. The guidance became effective for Tyco in the first quarter of fiscal 2015. The adoption of this guidance, which was applied on a prospective basis, did not have a material impact on the Company's financial position, results of operations or cash flows.

[0000833444-15-000091:notes:91]
In July 2013, the FASB issued authoritative guidance for the presentation of an unrecognized tax benefit when a net operating loss (“NOL”) carryforward, a similar tax loss, or a tax credit carryforward exists. The guidance requires an entity to present an unrecognized tax benefit, or a portion of an unrecognized tax benefit, in the financial statements as a reduction to a deferred tax asset for a NOL carryforward, a similar tax loss, or a tax credit carryforward. If the NOL carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the jurisdiction or the tax law of the jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit will be presented in the financial statements as a liability and will not be combined with deferred tax assets.  This guidance does not require any additional recurring disclosures and became effective for Tyco during the first fiscal quarter of fiscal 2015.  The adoption of this guidance, which was applied on a prospective basis, did not have a material impact on the Company's financial position, results of operations or cash flows.

[0000833444-15-000091:notes:92]
Recently Issued Accounting Pronouncements - In April 2014, the FASB issued authoritative guidance to change the criteria for reporting discontinued operations.  Under the new guidance, only disposals representing a strategic shift that has or will have a major effect on the Company's operations and financial results should be reported as discontinued operations, with expanded disclosures. In addition, disclosure of the pre-tax income attributable to a disposal of a significant part of an organization that does not qualify as a discontinued operation is required. This guidance is effective for Tyco in the first quarter of fiscal 2016.  The adoption of the new guidance in the first quarter of fiscal 2016 may impact the presentation and disclosure of any future components classified as held for sale or completed disposals.

[0000833444-15-000091:notes:93]
In May 2014, the FASB issued authoritative guidance for revenue from contracts with customers, which provides a single comprehensive revenue recognition model to apply in determining how and when to recognize revenue. The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. When applying the new revenue model to contracts with customers the guidance requires five steps to be applied, which include: 1) identify the contract(s) with a customer, 2) identify the performance obligations in the contract, 3) determine the transaction price, 4) allocate the transaction price to the performance obligations in the contract and 5) recognize revenue when (or as) the entity satisfies a performance obligation. The guidance also requires both quantitative and qualitative disclosures, which are more comprehensive than existing revenue standards. The disclosures are intended to enable financial statement users to understand the nature, timing and uncertainty of revenue and the related cash flow. The new standard allows for both retrospective and prospective methods of adoption. In August 2015, the FASB issued authoritative guidance to defer the effective date of this guidance, which for Tyco will be the first quarter of fiscal 2019, with early adoption permitted beginning the first quarter of fiscal 2018.  The Company is currently in the process of determining the adoption method as well as assessing the impact the guidance will have upon adoption.

[0000833444-15-000091:notes:94]
In May 2015, the FASB issued authoritative guidance which is intended to improve the existing disclosure requirements for short-duration contracts for insurance entities that issue such contracts.  The guidance requires additional information to be disclosed about the liability for unpaid claims and claim adjustment expenses to increase the transparency of significant estimates made in measuring those liabilities.  This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted.  The Company is currently assessing the impact, if any, the guidance will have upon adoption.

[0000833444-15-000091:notes:95]
In July 2015, the FASB issued authoritative guidance with the goal to simplify the existing guidance under which an entity must measure inventory at the lower of cost or market. Under the new guidance inventory is “measured at the lower of cost and net realizable value,” and does not apply to inventory which is measured using last-in, first-out or the retail method. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted on a prospective basis. The Company is currently assessing the impact, if any, the guidance will have upon adoption.

[0000833444-15-000091:notes:96]
In September 2015, the FASB issued authoritative guidance with the intent to reduce the cost and complexity to financial reporting when recognizing adjustments to provisional amounts in connection with a business combination. This guidance eliminates the requirement to restate prior period financial statements, but requires entities to present separately on the face of the income statement, or disclose in the notes, the portion of the amount recorded in current-period earnings by line item that would have been recorded in previous reporting periods if the adjustment to the provisional amounts had been recognized as of the acquisition date. This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted on a prospective basis. The Company is currently assessing the impact, if any, the guidance will have upon adoption.


## tyc:ReconciliationOfUSFederalIncomeTaxRateAndProvisionForIncomeTaxesTextBlock

[0000833444-15-000091:notes:97]
The reconciliation between U.S. federal income taxes at the statutory rate and the Company's provision for income taxes on continuing operations for the years ended September 25, 2015, September 26, 2014 and September 27, 2013 is as follows ($ in millions):

[0000833444-15-000091:notes:98]
|  | For the Years Ended |
|  | September 25, 2015 |  | September 26, 2014 |  | September 27, 2013 |
| Notional U.S. federal income tax expense at the statutory rate | $ | 250 |  |  | $ | 215 |  |  | $ | 209 |  |
| Adjustments to reconcile to the income tax provision: |  |  |  |  |  |
| U.S. state income tax provision, net | (11 | ) |  | (12 | ) |  | (3 | ) |
| Non U.S. net earnings(1) | (199 | ) |  | (232 | ) |  | (175 | ) |
| Nondeductible charges | 58 |  |  | 47 |  |  | 78 |  |
| Valuation allowance | 3 |  |  | 4 |  |  | 4 |  |
| Other | (1 | ) |  | 2 |  |  | (5 | ) |
| Provision for income taxes | $ | 100 |  |  | $ | 24 |  |  | $ | 108 |  |

[0000833444-15-000091:notes:99]
_______________________________________________________________________________

[0000833444-15-000091:notes:100]
| (1) | Excludes nondeductible charges and other items which are broken out separately in the table. |


## tyc:ScheduleOfAllocationOfPlanAssetsPensionPlansTableTextBlock

[0000833444-15-000091:notes:101]
Pension plans have the following weighted-average asset allocations:

[0000833444-15-000091:notes:102]
|  | U.S. Plans |  | Non-U.S. Plans |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Asset Category: |  |  |  |  |  |  |  |
| Equity securities | 59 | % |  | 62 | % |  | 50 | % |  | 51 | % |
| Debt securities | 40 | % |  | 36 | % |  | 48 | % |  | 49 | % |
| Cash and cash equivalents | 1 | % |  | 2 | % |  | 2 | % |  | — |  |
| Total | 100 | % |  | 100 | % |  | 100 | % |  | 100 | % |


## tyc:ScheduleOfComponentsOfSeparationRelatedCostsClassificationTableTextBlock

[0000833444-15-000091:notes:103]
The components of the Separation charges incurred within continuing operations and discontinued operations consisted of the following ($ in millions):

[0000833444-15-000091:notes:104]
|  | For the Year Ended |  | For the Year Ended |  | For the Year Ended |
|  | September 25, 2015 |  | September 26, 2014 |  | September 27, 2013 |
|  | ContinuingOperations |  | DiscontinuedOperations |  | Total |  | ContinuingOperations |  | DiscontinuedOperations |  | Total |  | ContinuingOperations |  | DiscontinuedOperations |  | Total |
| Professional fees | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |  | $ | 5 |  |  | $ | 1 |  |  | $ | 6 |  |
| Information technology related costs | 1 |  |  | — |  |  | 1 |  |  | 12 |  |  | — |  |  | 12 |  |  | 10 |  |  | — |  |  | 10 |  |
| Employee compensation costs | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  | 3 |  |  | 1 |  |  | 4 |  |
| Marketing costs | 1 |  |  | — |  |  | 1 |  |  | 32 |  |  | — |  |  | 32 |  |  | 40 |  |  | — |  |  | 40 |  |
| Other costs (income) | — |  |  | — |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |  | 11 |  |  | (10 | ) |  | 1 |  |
| Total pre-tax separation charges (income) | 2 |  |  | — |  |  | 2 |  |  | 53 |  |  | 1 |  |  | 54 |  |  | 69 |  |  | (8 | ) |  | 61 |  |
| Tax-related separation charges | — |  |  | — |  |  | — |  |  | 9 |  |  | — |  |  | 9 |  |  | 22 |  |  | — |  |  | 22 |  |
| Tax benefit on pre-tax separation charges | (1 | ) |  | — |  |  | (1 | ) |  | (15 | ) |  | — |  |  | (15 | ) |  | (13 | ) |  | — |  |  | (13 | ) |
| Total separation charges (income), net of tax benefit | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 47 |  |  | $ | 1 |  |  | $ | 48 |  |  | $ | 78 |  |  | $ | (8 | ) |  | $ | 70 |  |


## tyc:ScheduleOfFutureMinimumRentalPaymentsForOperatingAndCapitalLeasesTableTextBlock

[0000833444-15-000091:notes:105]
Following is a schedule of minimum lease payments for non-cancelable operating leases as of September 25, 2015 ($ in millions):

[0000833444-15-000091:notes:106]
|  | OperatingLeases |
| 2016 | $ | 183 |  |
| 2017 | 151 |  |
| 2018 | 113 |  |
| 2019 | 81 |  |
| 2020 | 45 |  |
| Thereafter | 58 |  |
|  | $ | 631 |  |


## tyc:ScheduleOfIntangibleAssetsTextBlock

[0000833444-15-000091:notes:107]
The following table sets forth the gross carrying amount and accumulated amortization of the Company's intangible assets as of September 25, 2015 and September 26, 2014 ($ in millions):

[0000833444-15-000091:notes:108]
|  | As of |
|  | September 25, 2015 |  | September 26, 2014 |
|  | Gross CarryingAmount |  | AccumulatedAmortization |  | Gross CarryingAmount |  | AccumulatedAmortization |
| Amortizable: |  |  |  |  |  |  |  |
| Contracts and related customer relationships | $ | 1,289 |  |  | $ | 993 |  |  | $ | 1,400 |  |  | $ | 1,113 |  |
| Intellectual property | 761 |  |  | 496 |  |  | 608 |  |  | 487 |  |
| Other | 9 |  |  | 5 |  |  | 29 |  |  | 15 |  |
| Total | $ | 2,059 |  |  | $ | 1,494 |  |  | $ | 2,037 |  |  | $ | 1,615 |  |
| Non-Amortizable: |  |  |  |  |  |  |  |
| Intellectual property | $ | 210 |  |  |  |  |  | $ | 214 |  |  |  |  |
| Franchise rights | 76 |  |  |  |  |  | 76 |  |  |  |  |
| In-process research and development | 20 |  |  |  |  |  | — |  |  |  |  |
| Total | $ | 306 |  |  |  |  |  | $ | 290 |  |  |  |  |


## tyc:ScheduleOfNetReceivablesAndLiabilitiesRecordedUnderTaxSharingAgreementsTableTextBlock

[0000833444-15-000091:notes:109]
The receivables and liabilities related to the 2012 and 2007 Tax Sharing Agreements as of September 25, 2015 and September 26, 2014 are as follows ($ in millions):

[0000833444-15-000091:notes:110]
|  | 2012 Tax Sharing Agreement |  | 2007 Tax Sharing Agreement |
|  | As of |  | As of |
|  | September 25, 2015 |  | September 26, 2014 |  | September 25, 2015 |  | September 26, 2014 |
| Net receivable: |  |  |  |  |  |  |  |
| Prepaid expenses and other current assets | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3 |  |
| Other assets | — |  |  | — |  |  | 19 |  |  | 23 |  |
|  | — |  |  | — |  |  | 19 |  |  | 26 |  |
| Tax sharing agreement related liabilities |  |  |  |  |  |  |  |
| Accrued and other current liabilities | — |  |  | — |  |  | (15 | ) |  | (21 | ) |
| Other liabilities | (46 | ) |  | (46 | ) |  | (194 | ) |  | (194 | ) |
|  | (46 | ) |  | (46 | ) |  | (209 | ) |  | (215 | ) |
| Net liability | $ | (46 | ) |  | $ | (46 | ) |  | $ | (190 | ) |  | $ | (189 | ) |


## tyc:ScheduleOfPensionPlanAssetsValuedUsingNetAssetValueOrItsEquivalentTableTextBlock

[0000833444-15-000091:notes:111]
The following tables set forth a summary of pension plan assets valued using NAV or its equivalent as of September 25, 2015 and September 26, 2014 ($ in millions):

[0000833444-15-000091:notes:112]
|  | As of |
|  | September 25, 2015 |
| Investment ($ in millions) | FairValue |  | RedemptionFrequency |  | RedemptionNoticePeriod |
| U.S. equity securities | $ | 304 |  |  | Daily |  | 1 day, 5 days |
| Non-U.S. equity securities | 355 |  |  | Daily, Semi-monthly |  | 1 day, 2 days |
| Government and government agency securities | 259 |  |  | Daily |  | 1 day, 2 days |
| Corporate and other debt securities | 214 |  |  | Daily |  | 1 day, 2 days |
|  | $ | 1,132 |  |  |  |  |  |

[0000833444-15-000091:notes:113]
|  | As of |
|  | September 26, 2014 |
| Investment ($ in millions) | FairValue |  | RedemptionFrequency |  | RedemptionNoticePeriod |
| U.S. equity securities | $ | 323 |  |  | Daily |  | 1 day, 5 days |
| Non-U.S. equity securities | 403 |  |  | Daily, Semi-monthly |  | 1 day, 2 days |
| Government and government agency securities | 159 |  |  | Daily |  | 1 day, 2 days |
| Corporate and other debt securities | 136 |  |  | Daily |  | 1 day, 2 days |
|  | $ | 1,021 |  |  |  |  |  |


## tyc:ScheduleOfPropertyPlantAndEquipmentTableTextBlock

[0000833444-15-000091:notes:114]
Property, plant and equipment consisted of the following ($ in millions):

[0000833444-15-000091:notes:115]
|  | As of |
|  | September 25, 2015 |  | September 26, 2014 |
| Land | $ | 33 |  |  | $ | 36 |  |
| Buildings | 411 |  |  | 411 |  |
| Subscriber systems | 1,933 |  |  | 2,210 |  |
| Machinery and equipment | 1,281 |  |  | 1,265 |  |
| Construction in progress | 84 |  |  | 90 |  |
| Accumulated depreciation | (2,553 | ) |  | (2,750 | ) |
| Property, plant and equipment, net | $ | 1,189 |  |  | $ | 1,262 |  |


## tyc:ScheduleOfRepurchaseProgramsTableTextBlock

[0000833444-15-000091:notes:116]
Shares repurchased by the Company by fiscal year and share repurchase program are provided below:

[0000833444-15-000091:notes:117]
|  | 2014 ShareRepurchase Programs |  | 2013 ShareRepurchase Program |  | 2011 ShareRepurchase Program |
|  | Shares(in millions) |  | Amounts($ in billions) |  | Shares(in millions) |  | Amounts($ in billions) |  | Shares(in millions) |  | Amounts($ in billions) |
| Approved Repurchase Amount |  |  |  | $ | 2.8 |  |  |  |  |  | $ | 0.6 |  |  |  |  |  | $ | 1.0 |  |
| Repurchases |  |  |  |  |  |  |  |  |  |  |  |
| Fiscal 2015 | 9.7 |  |  | 0.4 |  |  | N/A |  |  | N/A |  |  | N/A |  |  | N/A |  |
| Fiscal 2014 | 30.0 |  |  | 1.4 |  |  | 12.0 |  |  | 0.5 |  |  | N/A |  |  | N/A |  |
| Fiscal 2013 | N/A |  |  | N/A |  |  | 3.0 |  |  | 0.1 |  |  | 7.0 |  |  | 0.2 |  |
| Fiscal 2012 | N/A |  |  | N/A |  |  | N/A |  |  | N/A |  |  | 11.0 |  |  | 0.5 |  |
| Fiscal 2011 | N/A |  |  | N/A |  |  | N/A |  |  | N/A |  |  | 6.0 |  |  | 0.3 |  |
| Remaining Amount Available |  |  | $ | 1.0 |  |  |  |  | $ | — |  |  |  |  | $ | — |  |


## tyc:ScheduleOfRestructuringReserveByBalanceSheetLocationTextBlock

[0000833444-15-000091:notes:118]
As of  September 25, 2015 and September 26, 2014, restructuring reserves related to all actions were included in the Company's Consolidated Balance Sheets as follows ($ in millions):

[0000833444-15-000091:notes:119]
|  | As of |
|  | September 25, 2015 |  | September 26, 2014 |
| Accrued and other current liabilities | $ | 145 |  |  | $ | 83 |  |
| Other liabilities | 15 |  |  | 16 |  |
| Total | $ | 160 |  |  | $ | 99 |  |


## tyc:ScheduleOfSegmentReportingInformationDepreciationAndAmortizationAndCapitalExpendituresBySegmentTextBlock

[0000833444-15-000091:notes:120]
Depreciation and amortization, and capital expenditures by segment for the years ended September 25, 2015, September 26, 2014 and September 27, 2013 are as follows ($ in millions):

[0000833444-15-000091:notes:121]
|  | 2015 |  | 2014 |  | 2013 |
| Depreciation and amortization: |  |  |  |  |  |
| NA Integrated Solutions & Services | $ | 137 |  |  | $ | 137 |  |  | $ | 139 |  |
| ROW Integrated Solutions & Services | 113 |  |  | 141 |  |  | 175 |  |
| Global Products | 84 |  |  | 72 |  |  | 58 |  |
| Corporate and Other | 8 |  |  | 8 |  |  | 7 |  |
|  | $ | 342 |  |  | $ | 358 |  |  | $ | 379 |  |

[0000833444-15-000091:notes:122]
|  | 2015 |  | 2014 |  | 2013 |
| Capital expenditures |  |  |  |  |  |
| NA Integrated Solutions & Services | $ | 107 |  |  | $ | 133 |  |  | $ | 92 |  |
| ROW Integrated Solutions & Services | 98 |  |  | 102 |  |  | 109 |  |
| Global Products | 29 |  |  | 45 |  |  | 58 |  |
| Corporate and Other | 12 |  |  | 8 |  |  | 10 |  |
|  | $ | 246 |  |  | $ | 288 |  |  | $ | 269 |  |


## tyc:ScheduleOfSegmentReportingInformationNetRevenueAndOperatingIncomeLossBySegmentTableTextBlock

[0000833444-15-000091:notes:123]
Selected information by segment is presented in the following tables ($ in millions):

[0000833444-15-000091:notes:124]
|  | 2015 |  | 2014 |  | 2013 |
| Net Revenue(1): |  |  |  |  |  |
| NA Integrated Solutions & Services | $ | 3,879 |  |  | $ | 3,876 |  |  | $ | 3,891 |  |
| ROW Integrated Solutions & Services | 3,432 |  |  | 3,912 |  |  | 3,828 |  |
| Global Products | 2,591 |  |  | 2,544 |  |  | 2,339 |  |
|  | $ | 9,902 |  |  | $ | 10,332 |  |  | $ | 10,058 |  |

[0000833444-15-000091:notes:125]
______________________________________________________________________________

[0000833444-15-000091:notes:126]
| (1) | Net revenue by segment excludes intercompany transactions. |

[0000833444-15-000091:notes:127]
|  | 2015 |  | 2014 |  | 2013 |
| Operating income (loss): |  |  |  |  |  |
| NA Integrated Solutions & Services | $ | 542 |  |  | $ | 450 |  |  | $ | 388 |  |
| ROW Integrated Solutions & Services | 243 |  |  | 412 |  |  | 336 |  |
| Global Products | 405 |  |  | 458 |  |  | 307 |  |
| Corporate and Other(1) | (306 | ) |  | (620 | ) |  | (319 | ) |
|  | $ | 884 |  |  | $ | 700 |  |  | $ | 712 |  |

[0000833444-15-000091:notes:128]
| (1) | Operating loss for fiscal 2014 includes asbestos related charges of $225 million related to the Yarway settlement and $240 million related to an updated valuation performed over the Company's liability for asbestos related claims (excluding Yarway claims), partially offset by $96 million of legacy legal reversal and recoveries. See Note 12 for further details on asbestos and legacy legal matters. |


## tyc:ScheduleOfSeparationCostsClassificationTableTextBlock

[0000833444-15-000091:notes:129]
Pre-tax separation charges were classified in continuing operations within the Company's Consolidated Statement of Operations as follows ($ in millions):

[0000833444-15-000091:notes:130]
|  | For the Years Ended |
|  | September 25, 2015 |  | September 26, 2014 |  | September 27, 2013 |
| Selling, general and administrative expenses ("SG&A") | $ | 2 |  |  | $ | 52 |  |  | $ | 61 |  |
| Separation costs | — |  |  | 1 |  |  | 8 |  |
| Total | $ | 2 |  |  | $ | 53 |  |  | $ | 69 |  |


## tyc:ScheduleOfSupplementalBalanceSheetDisclosuresTextBlock

[0000833444-15-000091:notes:131]
Selected supplementary Consolidated Balance Sheet information as of September 25, 2015 and September 26, 2014 is as follows ($ in millions):

[0000833444-15-000091:notes:132]
|  | As ofSeptember 25,2015 |  | As ofSeptember 26,2014 |
| Contracts in process | $ | 370 |  |  | $ | 388 |  |
| Other | 406 |  |  | 663 |  |
| Prepaid expenses and other current assets | $ | 776 |  |  | $ | 1,051 |  |
| Accrued payroll and payroll related costs | $ | 232 |  |  | $ | 316 |  |
| Accrued guarantees | 219 |  |  | 218 |  |
| Accrued insurance commitments - asbestos | 21 |  |  | 346 |  |
| Other | 1,214 |  |  | 1,234 |  |
| Accrued and other current liabilities | $ | 1,686 |  |  | $ | 2,114 |  |


## tyc:ScheduleOfTaxSharingAgreementIncomeLossTableTextBlock

[0000833444-15-000091:notes:133]
The Company recorded (expense) income in conjunction with the 2012 and 2007 Tax Sharing Agreements for the years ended September 25, 2015, September 26, 2014 and September 27, 2013 as follows ($ in millions):

[0000833444-15-000091:notes:134]
|  | For the Years Ended |
|  | September 25, 2015 |  | September 26, 2014 |  | September 27, 2013 |
| (Expense)/income |  |  |  |  |  |
| 2007 Tax Sharing Agreement | $ | (5 | ) |  | $ | (21 | ) |  | $ | — |  |
| 2012 Tax Sharing Agreement | (2 | ) |  | 15 |  |  | (32 | ) |


## tyc:SeparationTransactionDisclosureTextBlock

[0000833444-15-000091:notes:135]
2012 Separation Transaction

[0000833444-15-000091:notes:136]
On September 28, 2012, the Company completed the spin-offs of ADT and Tyco Flow Control, formerly the North American residential security and flow control businesses of Tyco, respectively, into separate, publicly traded companies in the form of a distribution to Tyco shareholders.  In connection with activities taken to complete the 2012 Separation and to create the revised organizational structure of the Company, the Company incurred pre-tax charges ("Separation charges") of $2 million, $54 million and $61 million for the years ended September 25, 2015, September 26, 2014 and September 27, 2013 respectively. The amounts presented within discontinued operations are costs directly related to the 2012 Separation that are not expected to provide a future benefit to the Company. The components of the Separation charges incurred within continuing operations and discontinued operations consisted of the following ($ in millions):


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0000833444-15-000091:notes:137]
|  |  | As of September 26, 2014 |  | Consolidated Balance SheetClassification |
| Investment Assets: |  | Level 1 |  | Level 2 |  | Total |  | Cash and Cash Equivalents |  | Prepaid Expenses and Other Current Assets |
| Cash equivalents |  | $ | 223 |  |  | $ | — |  |  | $ | 223 |  |  | $ | 223 |  |  | $ | — |  |
| Time deposits |  | 275 |  |  | — |  |  | 275 |  |  | — |  |  | 275 |  |
| Trading securities: |  |  |  |  |  |  |  |  |  |  |
| Exchange traded funds (equity) |  | 62 |  |  | — |  |  | 62 |  |  | — |  |  | 62 |  |
|  |  | $ | 560 |  |  | $ | — |  |  | $ | 560 |  |  | $ | 223 |  |  | $ | 337 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000833444-15-000091:notes:138]
Acquisitions

[0000833444-15-000091:notes:139]
During the year ended September 25, 2015, total consideration for acquisitions included in continuing operations was $588 million, which was comprised of $583 million of cash paid, net of cash acquired of $28 million and $5 million of contingent consideration, for 12 acquisitions. The largest individual acquisition was Industrial Safety Technologies International ("IST"), a global leader in gas and flame detection with operations in Europe, the Middle East, China, and the U.S., for total consideration paid of $327 million, net of $5 million of cash acquired.  The purchase price for IST was allocated as follows: $67 million of assets, $137 million of goodwill, $143 million of intangible assets and the assumption of $15 million of liabilities.  In addition, during the fourth quarter of fiscal 2015, the Company acquired FootFall, a global retail intelligence company, from Experian, plc, for total consideration paid of $58 million, net of $2 million of cash acquired.  IST is being integrated into the Global Products segment, and FootFall is being integrated into the NA Integrated Solutions & Services and ROW Integrated Solutions & Services segments. The balance of the acquisitions for the year ended September 25, 2015 were included in the Company's ROW Integrated Solutions & Services and Global Products segments, none of which were material individually or in the aggregate.

[0000833444-15-000091:notes:140]
The determination of fair value for certain assets and liabilities relating to the acquisitions made during the first nine months of fiscal 2015 has been finalized, with no material adjustment to the preliminary purchase price allocations. The final determination of fair value of certain assets and liabilities relating to the FootFall acquisition remains subject to change based on final valuations of the assets acquired and liabilities assumed. The Company does not expect the finalization of this matter to have a material effect on the purchase price allocation, which is expected to be completed within fiscal 2016.

[0000833444-15-000091:notes:141]
During the year ended September 26, 2014, total consideration for acquisitions included in continuing operations was $66 million, which was comprised of $65 million of cash paid, net of cash acquired of $1 million, and $1 million of contingent consideration. This was primarily comprised of $53 million of cash paid, net of $1 million cash acquired, and $1 million of contingent consideration for the acquisition of Westfire, Inc. ("Westfire") on November 8, 2013. Westfire, a fire protection services company with operations in the United States, Chile and Peru, provides critical special-hazard suppression and detection applications in mining, telecommunications and other vertical markets and has been integrated with the NA Integrated Solutions & Services and ROW Integrated Solutions & Services segments.  The balance of the acquisitions for the year ended September 26, 2014 were included in the Company's ROW Integrated Solutions & Services segment, none of which were material individually or in the aggregate.

[0000833444-15-000091:notes:142]
During the year ended September 26, 2014, the Company also paid $66 million in cash to purchase the remaining ownership interest of a joint venture in Brazil, which has been consolidated into the Company's ROW Integrated Solutions & Services segment. In connection with Tyco’s acquisition of the remaining ownership interest in this joint venture, the Company recorded an indemnification asset of approximately $11 million relating to the indemnification of Tyco for certain pre-acquisition tax liabilities, in accordance with the purchase agreement.

[0000833444-15-000091:notes:143]
During the year ended September 27, 2013, total consideration for acquisitions included in continuing operations was  $257 million, which was comprised of $229 million cash paid, net of cash acquired of $9 million, and $28 million of consideration that was primarily contingent on the successful transfer of a business license in China to Tyco.  The transfer of this license occurred during the first quarter of fiscal 2015, and the Company has made payments of approximately $23 million during the year ended September 25, 2015. Cash paid for acquisitions primarily related to the acquisition of Exacq Technologies ("Exacq") on July 26, 2013 by the Company's Global Products segment.  Exacq is a developer of open architecture video management systems for security and surveillance applications.  Cash paid for Exacq totaled approximately $148 million, net of cash acquired of $2 million.  The balance of the acquisitions for the year ended September 27, 2013 were included within the Company's NA and ROW Integrated Solutions & Services segments, none of which were material individually or in the aggregate.

[0000833444-15-000091:notes:144]
Acquisition and Integration Related Costs

[0000833444-15-000091:notes:145]
Acquisition and integration costs are expensed as incurred. During the years ended September 25, 2015, September 26, 2014 and September 27, 2013, the Company incurred acquisition and integration costs of $5 million, $3 million and $4 million, respectively. Such costs are recorded in Selling, general and administrative expenses within the Consolidated Statements of Operations.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-15-000091:notes:146]
Commitments and Contingencies

[0000833444-15-000091:notes:147]
The Company has facility, vehicle and equipment leases that expire at various dates beyond fiscal 2016. Rental expense under these leases was $261 million, $279 million and $284 million for fiscal years 2015, 2014 and 2013, respectively. Following is a schedule of minimum lease payments for non-cancelable operating leases as of September 25, 2015 ($ in millions):

[0000833444-15-000091:notes:148]
The Company also has purchase obligations related to commitments to purchase certain goods and services. As of September 25, 2015, such obligations were as follows: $353 million in 2016, $44 million in 2017, $2 million in 2018, nil in 2019 and nil in 2020 and thereafter.

[0000833444-15-000091:notes:149]
Legacy Matters Related to Former Management

[0000833444-15-000091:notes:150]
In recent years, the Company has settled several lawsuits involving disputes with former management.  With respect to Dennis Kozlowski, the Company's former chief executive officer, in the first quarter of fiscal 2014, the parties signed an agreement resolving all outstanding disputes, and with Mr. Kozlowski agreeing to release the Company from any claims to monetary amounts related to compensation, retention or other arrangements. As a result, in the first quarter of fiscal 2014, the Company reversed a non-cash net liability of approximately $92 million, which was recorded in Selling, general and administrative expenses within the Consolidated Statement of Operations for the amounts allegedly due to him.  Pursuant to the settlement agreement, Tyco is entitled to a portion of the proceeds, if any, from the future sale of certain assets owned by Mr. Kozlowski, the timing and amount of which is uncertain.  During the quarter ended June 27, 2014, the Company received a $6 million recovery from the sale of property owned by Mr. Kozlowski, $2 million of which will be shared pursuant to the terms of a legacy class action lawsuit, resulting in a net recovery of $4 million for the Company, which was recorded in Selling, general and administrative expenses within the Consolidated Statement of Operations. During the quarter ended June 26, 2015, the Company received approximately $4 million in cash from the sale of property owned by Mr. Kozlowski, $2 million of which will be shared pursuant to the terms of a legacy class action lawsuit, resulting in a net recovery of $2 million for the Company, which was recorded in Selling, general and administrative expenses within the Consolidated Statement of Operations.  The cash received has been classified as restricted.

[0000833444-15-000091:notes:151]
With respect to Mark Swartz, the Company's former chief financial officer, in November 2014, the parties reached a definitive agreement to resolve all outstanding disputes, with Mr. Swartz agreeing to release the Company from any claims to monetary amounts related to compensation, retention or other arrangements alleged to have existed between him and the Company.  In the first quarter of fiscal 2015, the Company also received approximately $12 million in cash from Mr. Swartz, $5 million of which will be shared pursuant to the terms of a legacy class action lawsuit, resulting in a net recovery of $7 million for the Company, which was recorded in Selling, general and administrative expenses within the Consolidated Statement of Operations. The cash received has been classified as restricted.

[0000833444-15-000091:notes:152]
Environmental Matters

[0000833444-15-000091:notes:153]
Tyco is involved in various stages of investigation and cleanup related to environmental remediation matters at a number of sites. The ultimate cost of site cleanup is difficult to predict given the uncertainties regarding the extent of the required cleanup, the interpretation of applicable laws and regulations and alternative cleanup methods. As of September 25, 2015, Tyco concluded that it was probable that it would incur remedial costs in the range of approximately $23 million to $72 million. As of September 25, 2015, Tyco concluded that the best estimate within this range is approximately $33 million, of which $11 million is included in Accrued and other current liabilities and $22 million is included in Other liabilities in the Company's Consolidated Balance Sheet.

[0000833444-15-000091:notes:154]
The majority of the liabilities described above relate to ongoing remediation efforts at a facility in the Company's Global Products segment located in Marinette, Wisconsin, which the Company acquired in 1990 in connection with its acquisition of, among other things, the Ansul product line. Prior to Tyco's acquisition, Ansul manufactured arsenic-based agricultural herbicides at the Marinette facility, which resulted in significant arsenic contamination of soil and groundwater on the Marinette site and in parts of the adjoining Menominee River. Ansul has been engaged in ongoing remediation efforts at the Marinette site since 1990, and in February 2009 entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the Marinette site. Under this agreement, Ansul's principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment.  As of September 25, 2015, the Company concluded that its remaining remediation and monitoring costs related to the Marinette facility were in the range of approximately $14 million to $46 million. The Company's best estimate within that range is approximately $23 million, of which $9 million is included in Accrued and other current liabilities and $14 million is included in Other liabilities in the Company's Consolidated Balance Sheet. During the years ended September 25, 2015, September 26, 2014, and September 27, 2013, the Company recorded charges of nil, nil, and $100 million, respectively, in Selling, general and administrative expenses within the Consolidated Statement of Operations.  Although the Company has recorded its best estimate of the costs that it will incur to remediate and monitor the arsenic contamination at the Marinette facility, it is possible that technological, regulatory or enforcement developments, the results of environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows.

[0000833444-15-000091:notes:155]
Asbestos Matters

[0000833444-15-000091:notes:156]
The Company and certain of its subsidiaries, including Grinnell LLC (“Grinnell”), along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. Substantially all cases pending against affiliates of the Company have been filed against Grinnell, and have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-15-000091:notes:157]
During the third quarter of fiscal 2014, the Company, through Grinnell, resolved disputes with certain of its historical insurers and agreed that certain insurance proceeds would be used to establish and fund a qualified settlement fund (“QSF”), within the meaning of the Internal Revenue Code, which would be used for the resolution primarily of Grinnell asbestos liabilities. It is intended that the QSF will receive future insurance payments and proceeds from third party insurers and, in addition, will fund and manage liabilities for certain historical operations of the Company, primarily related to Grinnell. On January 9, 2015, the Company completed a series of restructuring transactions related to the establishment and funding of a dedicated structure pursuant to which a subsidiary of the Company acquired the assets of Grinnell and transferred cash and other assets totaling approximately $278 million (not including $22 million received by the QSF during the quarter ended December 26, 2014 from historic third-party insurers in settlement of coverage disputes) to the structure. As part of the restructuring, subsidiaries in the structure assumed certain liabilities related to historic Grinnell, Scott and Figgie operations, including all historical Grinnell asbestos liabilities, and such subsidiaries purchased additional insurance by, through or from a wholly-owned subsidiary in the structure in order to supplement and enhance existing insurance assets. The structure and the QSF fully fund all historic Grinnell asbestos liabilities and provide for the efficient and streamlined management of claims related thereto.

[0000833444-15-000091:notes:158]
The Company consolidates the qualified settlement fund and related entities that were established for the purpose of managing and resolving the liabilities described above. Although the entities in the dedicated structure serve the specific purpose of managing certain liabilities, each entity in the structure is a wholly-owned indirect subsidiary of the Company, and therefore is required to be consolidated under GAAP.

[0000833444-15-000091:notes:159]
As of September 25, 2015, the Company has determined that there were approximately 3,300 claims pending against its subsidiaries, primarily Grinnell.  This amount reflects the Company's current estimate of the number of viable claims made against Grinnell and includes adjustments for claims that are not actively being prosecuted, identify incorrect defendants, are duplicative of other actions or for which the Company is indemnified by third parties. As a result of the conclusion of the Yarway bankruptcy, addressed separately below, Yarway Corporation is no longer a subsidiary of the Company and, as of August 2015, is no longer consolidated.

[0000833444-15-000091:notes:160]
As of September 25, 2015, the Company's estimated asbestos related net liability recorded within the Company's Consolidated Balance Sheet is $28 million.  The net liability in the Consolidated Balance Sheet is comprised of a liability for pending and future claims and related defense costs of $515 million, of which $23 million is recorded in Accrued and other current liabilities, and $492 million is recorded in Other liabilities.  The Company also maintains separate cash, investment and other assets within the Consolidated Balance Sheet of $487 million, of which $38 million is recorded in Prepaid expenses and other current assets, and $449 million is recorded in Other assets.  Assets include $11 million of cash and $263 million of investments, which have all been designated as restricted.  The Company believes that the asbestos related liabilities and insurance related assets as of September 25, 2015 are appropriate.  As of September 26, 2014, the Company's estimated net liability, which included claims against the Company's former Yarway subsidiary, of $608 million was recorded within the Company's Consolidated Balance Sheet as a liability for pending and future claims and related defense costs of $853 million, and separately as an asset for insurance recoveries of $245 million.

[0000833444-15-000091:notes:161]
The Company periodically assesses the sufficiency of its estimated liability for pending and future asbestos claims and defense costs. On a periodic basis, the Company, through the dedicated structure referred to above, evaluates actual experience regarding asbestos claims filed, settled and dismissed, amounts paid in settlements, and the recoverability of its insurance assets. If and when data from actual experience demonstrate a significant unfavorable discernible trend, the Company performs a valuation of its asbestos related liabilities and corresponding insurance assets including a comprehensive review of the underlying assumptions. In addition, the Company evaluates its ability to reasonably estimate claim activity beyond its current look-forward period (through 2056) in order to assess whether such period continues to be appropriate. In addition to claims and litigation experience, the Company considers additional qualitative and quantitative factors such as changes in legislation, the legal environment, the Company’s strategy in managing claims and obtaining insurance, including its defense strategy, and health related trends in the overall population of individuals potentially exposed to asbestos. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance assets is warranted.

[0000833444-15-000091:notes:162]
During the fourth quarter of fiscal 2014, the Company concluded that an unfavorable trend had developed in actual claim filing activity compared to projected claim filing activity established during the Company’s then most recent valuation. Accordingly, the Company, with the assistance of independent actuarial service providers, performed a revised valuation of its asbestos-related liabilities and corresponding insurance assets. As part of the revised valuation, the Company assessed whether a change in its look-forward period was appropriate, taking into consideration its more extensive history and experience with asbestos-related claims and litigation, and determined that it was possible to make a reasonable estimate of the actuarially determined ultimate risk of loss for pending and unasserted potential future asbestos-related claims through 2056. In connection with the revised valuation, the Company considered a recent settlement with one of its insurers calling for the establishment of a qualified settlement fund, and the results of a separate independent actuarial consulting firm report conducted in the fourth quarter to assist the Company in obtaining insurance to fully fund all estimable asbestos-related claims (excluding Yarway claims) incurred through 2056.

[0000833444-15-000091:notes:163]
The independent actuarial service firm calculated a total estimated liability for asbestos-related claims of the Company, which reflects the Company’s best estimate of its ultimate risk of loss to resolve all pending and future claims (excluding Yarway claims) through 2056, which is the Company’s reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates.

[0000833444-15-000091:notes:164]
During fiscal 2014, in conjunction with determining the total estimated liability, the Company retained an independent third party to assist it in valuing its insurance assets responsive to asbestos-related claims, excluding Yarway claims. These insurance assets represent amounts due to the Company for previously settled claims and the probable reimbursements relating to its total liability for pending and unasserted potential future asbestos claims and defense costs. In calculating this amount, the Company used the estimated asbestos liability for pending and projected future claims and defense costs described above, and it also considered the amount of insurance available, the solvency risk with respect to the Company's insurance carriers, resolution of insurance coverage issues, gaps in coverage, allocation methodologies, and the terms of existing settlement agreements with insurance carriers.

[0000833444-15-000091:notes:165]
As a result of the activity described above, the Company recorded a net charge of $240 million in Selling, general and administrative expenses within the Consolidated Statement of Operations during the quarter ended September 26, 2014. Although the Company’s methodology established a range of estimates of reasonably possible outcomes, the Company recorded its best estimate within such range based upon currently known information. The Company's estimated gross asbestos liability of $538 million was recorded within the Company's Consolidated Balance Sheet as a liability for pending and future claims and related defense costs, and separately as an asset for insurance recoveries of $245 million. The aforementioned total estimated liability is on a pre-tax basis, not discounted for the time-value of money, and includes defense costs, which is consistent with the Company’s historical accounting practices.

[0000833444-15-000091:notes:166]
The effect of the change in the look-forward period reduced income from continuing operations before income taxes and net income in fiscal 2014 by approximately $116 million and $71 million, respectively.  In addition, the effect of the change decreased the Company's basic income from continuing operations and net income by $0.16 per share, and decreased the Company's diluted income from continuing operations and net income by $0.15 per share.

[0000833444-15-000091:notes:167]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-15-000091:notes:168]
Yarway

[0000833444-15-000091:notes:169]
As previously disclosed, on April 22, 2013, Yarway Corporation, a former indirect wholly-owned subsidiary of the Company, filed a voluntary petition for relief under Chapter 11 of the U.S. Bankruptcy Code (“Chapter 11”) in the United States Bankruptcy Court for the District of Delaware (“Bankruptcy Court”). On October 9, 2014, the Company reached an agreement with Yarway and various representatives of asbestos claimants that held or purported to hold asbestos-related claims against Yarway to fund a section 524(g) trust (the “Yarway Trust”) for the resolution and payment of current and future Yarway asbestos claims and to resolve the potential liability of the Company, each of its current and former affiliates and various other parties (the “Company Protected Parties”) for pending and future derivative personal injury claims related to exposure to asbestos-containing products that were allegedly manufactured, distributed, and/or sold by Yarway (“Yarway Asbestos Claims”). As a result of the agreement to settle, the Company recorded a charge of $225 million in Selling, general and administrative expenses within the Consolidated Statement of Operations in the fourth quarter of fiscal 2014. On April 8, 2015, the Bankruptcy Court issued an order confirming Yarway’s Chapter 11 plan, and on July 14, 2015, the United States District Court for the District of Delaware affirmed the Bankruptcy Court's confirmation order. On August 19, 2015, the Chapter 11 plan became effective, the Company contributed approximately $325 million in cash to the Yarway Trust and each of the Company Protected Parties received the benefit of a release from Yarway and an injunction under section 524(g) of the Bankruptcy Code permanently enjoining the assertion of Yarway Asbestos Claims against those Parties. As a result of the effectiveness of Chapter 11 plan, ownership of the Yarway Corporation was transferred to the Yarway Trust and it is no longer a consolidated subsidiary of the Company.

[0000833444-15-000091:notes:170]
As a result of the voluntary bankruptcy petition during the third quarter of fiscal 2013, the Company recorded an expected loss upon deconsolidation of $10 million related to the Yarway Chapter 11 filing, which represented the Company's best estimate of loss at the time.  Upon deconsolidation, the Company recorded an additional $4 million loss in Selling, general and administrative expenses within the Company's Consolidated Statement of Operations during the year ended September 25, 2015.

[0000833444-15-000091:notes:171]
Tax Matters

[0000833444-15-000091:notes:172]
Tyco and its subsidiaries' income tax returns are examined periodically by various tax authorities. In connection with these examinations, tax authorities, including the IRS, have raised issues and proposed tax adjustments, in particular with respect to years preceding the 2007 Separation. The issues and proposed adjustments related to such years are generally subject to the sharing provisions of a tax sharing agreement entered in 2007 with Medtronic and TE Connectivity (the "2007 Tax Sharing Agreement") under which Tyco, Medtronic and TE Connectivity share 27%, 42% and 31%, respectively, of shared income tax liabilities that arise from adjustments made by tax authorities to Tyco's, Medtronic's and TE Connectivity's U.S. and certain non-U.S. income tax returns. The costs and expenses associated with the management of these shared tax liabilities are generally shared equally among the parties. Tyco has previously disclosed that in connection with U.S. federal tax audits, the IRS has raised a number of issues and proposed tax adjustments for periods beginning with the 1997 tax year. Although Tyco has been able to resolve substantially all of the issues and adjustments proposed by the IRS for tax years through 2007, it has not been able to resolve matters related to the treatment of certain intercompany debt transactions during the period. As a result, on June 20, 2013, Tyco received Notices of Deficiency from the IRS asserting that several of Tyco's former U.S. subsidiaries owe additional taxes of $883.3 million plus penalties of $154 million based on audits of the 1997 through 2000 tax years of Tyco and its subsidiaries as they existed at that time. In addition, Tyco received Final Partnership Administrative Adjustments for certain U.S. partnerships owned by former U.S. subsidiaries with respect to which an additional tax deficiency of approximately $30 million was asserted. These amounts exclude interest and do not reflect the impact on subsequent periods if the IRS position described below is ultimately proved correct.

[0000833444-15-000091:notes:173]
The IRS asserted in the Notices of Deficiency that substantially all of Tyco's intercompany debt originated during the 1997 - 2000 period should not be treated as debt for U.S. federal income tax purposes, and has disallowed interest and related deductions recognized on U.S. income tax returns totaling approximately $2.9 billion. Tyco strongly disagrees with the IRS position and has filed petitions with the U.S. Tax Court contesting the IRS proposed adjustments. A trial date has been set for October 2016. Tyco believes that it has meritorious defenses for its tax filings, that the IRS positions with regard to these matters are inconsistent with the applicable tax laws and existing Treasury regulations, and that the previously reported taxes for the years in question are appropriate.

[0000833444-15-000091:notes:174]
No payments with respect to these matters would be required until the dispute is definitively resolved, which, based on the experience of other companies, could take several years. Tyco believes that its income tax reserves and the liabilities recorded within the Consolidated Balance Sheet for the tax sharing agreements continue to be appropriate. However, the ultimate resolution of these matters, and the impact of that resolution, are uncertain and could have a material impact on Tyco's financial condition, results of operations and cash flows. In particular, if the IRS is successful in asserting its claim, it would have an adverse impact on interest deductions related to the same intercompany debt in subsequent time periods, totaling approximately $6.6 billion, which is expected to be disallowed by the IRS. See Note 6.

[0000833444-15-000091:notes:175]
Other Matters

[0000833444-15-000091:notes:176]
As previously disclosed, SimplexGrinnell LP (“SG”), a subsidiary of the Company in the North America Integrated Solutions & Services segment, has been named as a defendant in lawsuits in several jurisdictions seeking damages for SG’s alleged failure to pay prevailing wages and for other pay-related claims.  Through the first quarter of fiscal 2015, the Company had recorded a total of approximately $17 million in charges related to these lawsuits, which was recorded in the Cost of services within the Consolidated Statement of Operations.  During the quarter ended March 27, 2015, the Company agreed in principle to settle all outstanding lawsuits for a total of approximately $14 million.

[0000833444-15-000091:notes:177]
In addition to the foregoing, the Company is subject to claims and suits, including from time to time, contractual disputes and product and general liability claims, incidental to present and former operations, acquisitions and dispositions. With respect to many of these claims, the Company either self-insures or maintains insurance through third-parties, with varying deductibles. While the ultimate outcome of these matters cannot be predicted with certainty, the Company believes that the resolution of any such proceedings, whether the underlying claims are covered by insurance or not, will not have a material adverse effect on the Company's financial condition, results of operations or cash flows beyond amounts recorded for such matters.


## us-gaap:CondensedFinancialStatementsTextBlock

[0000833444-15-000091:notes:178]
Tyco International Finance S.A.

[0000833444-15-000091:notes:179]
TIFSA, a 100% owned subsidiary of the Company, has public debt securities outstanding which are fully and unconditionally guaranteed by Tyco and by Tyco Fire & Security Finance S.C.A. ("TIFSCA"), a wholly owned subsidiary of Tyco and parent company TIFSA. See Note 9. The following tables present condensed consolidating financial information for Tyco, TIFSCA, TIFSA and all other subsidiaries. Condensed financial information for Tyco, TIFSCA and TIFSA on a stand-alone basis is presented using the equity method of accounting for subsidiaries.


## us-gaap:DebtDisclosureTextBlock

[0000833444-15-000091:notes:180]
Debt

[0000833444-15-000091:notes:181]
The carrying value of the Company's debt as of September 25, 2015 and September 26, 2014 is as follows ($ in millions):

[0000833444-15-000091:notes:182]
|  | As of September 25, 2015 |  | As of September 26, 2014 |
| 3.375% public notes due 2015 (See Note 21) | $ | 258 |  |  | $ | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 8.5% public notes due 2019 | — |  |  | 364 |  |
| 7.0% public notes due 2019(2) (See Note 21) | 245 |  |  | 245 |  |
| 6.875% public notes due 2021(2) (See Note 21) | 465 |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% Euro-denominated public notes due 2025 | 558 |  |  | — |  |
| 3.9% public notes due 2026 | 745 |  |  | — |  |
| 5.125% public notes due 2045 | 746 |  |  | — |  |
| Other(1) | 20 |  |  | 22 |  |
| Total debt | 3,146 |  |  | 1,463 |  |
| Less: current portion | 987 |  |  | 20 |  |
| Long-term debt | $ | 2,159 |  |  | $ | 1,443 |  |

[0000833444-15-000091:notes:183]
| (1) | $19 million and $20 million of the current portion of the Company's total debt as of September 25, 2015 and September 26, 2014, respectively, is included in Other. |

[0000833444-15-000091:notes:184]
| (2) | On September 14, 2015, the Company and TIFSA announced the redemption of its outstanding $242 million aggregate principal amount of 7.0% notes due 2019 and $462 million aggregate principal amount of 6.875% notes due 2021, which have been classified as current within the Consolidated Balance Sheet as of September 25, 2015. On October 14, 2015, TIFSA completed the redemption. See Note 21. |

[0000833444-15-000091:notes:185]
Fair Value

[0000833444-15-000091:notes:186]
The carrying amount of Tyco's debt subject to the fair value disclosure requirements as of September 25, 2015 and September 26, 2014 was $3,126 million and $1,441 million, respectively. The Company utilizes various valuation methodologies to determine the fair value of its debt, which is primarily dependent on the type of market in which the Company's debt is traded. When available, the Company uses quoted market prices to determine the fair value of its debt that is traded in active markets. As of September 25, 2015 and September 26, 2014, the fair value of the Company's debt which was actively traded was $3,291 million and $1,670 million, respectively. As of September 25, 2015 and September 26, 2014, the Company's debt that was subject to the fair value disclosure requirements was all actively traded and is classified as Level 1 in the fair value hierarchy. See Note 1 for further details on the fair value hierarchy.

[0000833444-15-000091:notes:187]
Commercial Paper

[0000833444-15-000091:notes:188]
From time to time, TIFSA may issue commercial paper for general corporate purposes. The maximum aggregate amount of unsecured commercial paper notes available to be issued, on a private placement basis, under the commercial paper program was $1.5 billion as of September 25, 2015.  As of September 25, 2015 and September 26, 2014, TIFSA had no commercial paper outstanding.

[0000833444-15-000091:notes:189]
Fiscal 2015 Debt Issuance/Repayment

[0000833444-15-000091:notes:190]
On February 25, 2015, TIFSA issued €500 million aggregate principal amount of 1.375% notes due February 25, 2025 (the "2025 Euro notes"), which are fully and unconditionally guaranteed by the Company and Tyco Fire & Security Finance S.C.A ("TIFSCA"). TIFSA received total net proceeds of approximately $563 million after deducting debt issuance costs of approximately $5 million and a debt discount of approximately $1 million. The net proceeds were made available for general corporate purposes.  The Euro notes are TIFSA’s senior unsecured obligations and rank equally in right of payment with all of its existing and future senior debt, and senior to any subordinated indebtedness that TIFSA may incur. The Euro notes were designated as a net investment hedge.  See Note 11.

[0000833444-15-000091:notes:191]
On September 14, 2015, TIFSA issued $750 million aggregate principal amount of 3.9% notes due on February 14, 2026 (the "2026 notes") and $750 million aggregate principal amount of 5.125% notes due on September 14, 2045 (the "2045 notes"), which are fully and unconditionally guaranteed by the Company and TIFSCA. TIFSA received total net proceeds of approximately $1,477 million after deducting debt issuance costs of approximately $6 million for the 2026 notes and $8 million for the 2045 notes, as well as a debt discount of approximately $5 million for the 2026 notes and $4 million for the 2045 notes.  The 2026 notes and the 2045 notes are TIFSA's senior unsecured obligations and rank equally in right of payment with all of its existing and future senior debt, and senior to any subordinated indebtedness that TIFSA may incur.

[0000833444-15-000091:notes:192]
On August 11, 2015, TIFSA notified holders of its 8.5% notes due 2019 (the "2019 notes") that it would redeem the entire $364 million aggregate principal amount. On September 16, 2015, TIFSA paid cash of $445 million to complete the redemption, resulting in a loss on extinguishment of debt of $81 million. This loss represents the make-whole premium related to the 2019 notes and was recorded in Other expense, net within the Consolidated Statements of Operations. The redemption was funded with a portion of the net proceeds from the 2015 debt issuances described above.

[0000833444-15-000091:notes:193]
Credit Facilities

[0000833444-15-000091:notes:194]
On August 7, 2015, TIFSA entered into an Amended and Restated Five-Year Senior Unsecured Credit Agreement in the aggregate amount of $1.5 billion (the “2015 Credit Agreement”). The 2015 Credit Agreement amends and restates TIFSA's existing Five-Year Senior Unsecured Credit Agreement, dated June 22, 2012 (the “2012 Credit Agreement”), which provided for revolving credit commitments in the aggregate amount of $1.0 billion, and was scheduled to expire on June 22, 2017.

[0000833444-15-000091:notes:195]
As a result of entering into the 2015 Credit Agreement, the Company's committed revolving credit facility totaled $1.5 billion as of September 25, 2015. This revolving credit facility may be used for working capital, capital expenditures and general corporate purposes. As of September 25, 2015 and September 26, 2014, there were no amounts drawn under the Company's revolving credit facilities. Interest under the revolving credit facilities is variable and is calculated by reference to LIBOR or an alternate base rate.

[0000833444-15-000091:notes:196]
TIFSA's revolving credit facility contains customary terms and conditions, and financial covenants that limit the ratio of the Company's debt to earnings before interest, taxes, depreciation, and amortization and that limit our ability to incur subsidiary debt or grant liens on its property. The indentures contain customary covenants including limits on negative pledges, subsidiary debt and sale/leaseback transactions. None of these covenants are considered restrictive to the Company's business.

[0000833444-15-000091:notes:197]
Other Debt Information

[0000833444-15-000091:notes:198]
The aggregate amounts of principal public debt maturing during the next five fiscal years and thereafter are as follows: $962 million in 2016, nil in 2017, $67 million in 2018, nil in 2019, nil in 2020 and $2,101 million thereafter.

[0000833444-15-000091:notes:199]
As of September 25, 2015, the weighted-average interest rate on total debt was 4.38%.  As of September 26, 2014, the weighted-average interest rate on total debt was 6.5%.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-15-000091:notes:200]
Share Plans

[0000833444-15-000091:notes:201]
Total share-based compensation cost recognized during 2015, 2014 and 2013 consisted of the following ($ in millions):

[0000833444-15-000091:notes:202]
|  | 2015 |  | 2014 |  | 2013 |
| Selling, general and administrative expenses | $ | 57 |  |  | $ | 72 |  |  | $ | 63 |  |
| Restructuring and asset impairments charges, net | 2 |  |  | — |  |  | — |  |
| Total share-based compensation costs | $ | 59 |  |  | $ | 72 |  |  | $ | 63 |  |

[0000833444-15-000091:notes:203]
The Company has recognized a related tax benefit associated with its share-based compensation arrangements during 2015, 2014 and 2013 of $18 million, and $25 million and $20 million, respectively.

[0000833444-15-000091:notes:204]
On September 17, 2012, shareholders approved the Tyco International plc 2012 Share and Incentive Plan (the "2012 Plan") which replaced the 2004 Tyco International Ltd. Stock and Incentive Plan (the "2004 Plan").  The 2012 Plan provides for the award of stock options, stock appreciation rights, annual performance bonuses, long term performance awards, restricted units, restricted shares, deferred stock units, promissory stock and other stock-based awards (collectively, "Awards").  Pursuant to the 2012 Plan, effective October 1, 2012, 50 million ordinary shares were available for equity-based awards, subject to adjustments as provided under the terms of the 2012 Plan. No additional awards may be granted under the 2004 Plan. In addition, any ordinary shares which have been awarded under the 2004 Plan but which are not issued, owing to expiration, forfeiture, cancellation, return to the Company or settlement in cash in lieu of ordinary shares on or after January 1, 2004 and which are no longer available for any reason will also be available for issuance under the 2012 Plan. When ordinary shares are issued pursuant to a grant of a full value award (for example, restricted stock units and performance share units), the total number of ordinary shares remaining available for grant will be decreased by 3.32 shares under the 2012 Plan.  As of September 25, 2015, there were approximately 32 million shares available for grant under the 2012 Plan.

[0000833444-15-000091:notes:205]
Share Options—Options are granted to purchase ordinary shares at prices that are equal to or greater than the closing market price of the ordinary shares on the date the option is granted. Conditions of vesting are determined at the time of grant. Options are generally exercisable in equal annual installments over a period of four years and will generally expire 10 years after the date of grant. Historically, the Company's practice has been to settle stock option exercises through either newly issued shares or from shares held in treasury.

[0000833444-15-000091:notes:206]
The grant-date fair value of each option grant is estimated using the Black-Scholes option pricing model. The fair value is then amortized on a straight-line basis over the requisite service period of the awards, which is generally the vesting period. Use of a valuation model requires management to make certain assumptions with respect to selected model inputs. Expected volatility is calculated based on an analysis of historic and implied volatility measures for a set of peer companies. The average expected life is based on the contractual term of the option and expected employee exercise and post-vesting employment termination behavior. The risk-free interest rate is based on U.S. Treasury zero-coupon issues with a remaining term equal to the expected life assumed at the date of grant. The compensation expense recognized is net of estimated forfeitures. Forfeitures are estimated based on voluntary termination behavior, as well as an analysis of actual share option forfeitures. The weighted-average assumptions used in the Black-Scholes option pricing model for 2015, 2014 and 2013 are as follows:

[0000833444-15-000091:notes:207]
|  | 2015 |  | 2014 |  | 2013 |
| Expected stock price volatility | 31 | % |  | 33 | % |  | 35 | % |
| Risk free interest rate | 1.82 | % |  | 1.64 | % |  | 0.87 | % |
| Expected annual dividend per share | $ | 0.73 |  |  | $ | 0.64 |  |  | $ | 0.60 |  |
| Expected life of options (years) | 5.5 |  |  | 5.5 |  |  | 5.8 |  |

[0000833444-15-000091:notes:208]
The weighted-average grant-date fair values of options granted during 2015, 2014 and 2013 was $11.29, $10.24 and $7.21, respectively.  The total intrinsic value of options exercised during 2015, 2014 and 2013 was $66 million, $76 million and $73 million, respectively. The related excess cash tax benefit classified as a financing cash inflow for 2015, 2014 and 2013 was not material.

[0000833444-15-000091:notes:209]
A summary of the option activity as of September 25, 2015, and changes during the year then ended is presented below:

[0000833444-15-000091:notes:210]
|  | Shares |  | Weighted-AverageExercise Price |  | Weighted-AverageRemainingContractual Term(in years) |  | AggregateIntrinsicValue($ in millions) |
| Outstanding as of September 26, 2014 | 15,126,365 |  |  | $ | 24.31 |  |  |  |  |  |
| Granted | 1,906,376 |  |  | 42.52 |  |  |  |  |  |
| Exercised | (3,834,707 | ) |  | 23.95 |  |  |  |  |  |
| Expired | (627,093 | ) |  | 31.56 |  |  |  |  |  |
| Forfeited | (35,464 | ) |  | 28.70 |  |  |  |  |  |
| Outstanding as of September 25, 2015 | 12,535,477 |  |  | 26.81 |  |  | 6.07 |  | $ | 116 |  |
| Vested and unvested expected to vest as of September 25, 2015 |  |  |  |  |  |  | 5.99 |  | $ | 115 |  |
| Exercisable as of September 25, 2015 |  |  |  |  |  |  | 4.48 |  | $ | 93 |  |

[0000833444-15-000091:notes:211]
As of September 25, 2015, there was $27 million of total unrecognized compensation cost related to unvested options granted. The cost is expected to be recognized over a weighted-average period of 2.6 fiscal years.

[0000833444-15-000091:notes:212]
Employee Stock Purchase Plans—The Tyco Employee Stock Purchase Plan ("ESPP") was suspended indefinitely during the fourth quarter of 2009.  As of September 25, 2015, there were approximately 3 million shares available for grant under the ESPP.

[0000833444-15-000091:notes:213]
Restricted Share Awards—Restricted share awards, including restricted stock units and performance share units are granted subject to certain restrictions. Conditions of vesting are determined at the time of grant. Restrictions on the award generally lapse upon normal retirement, if more than twelve months from the grant date, death or disability of the employee.

[0000833444-15-000091:notes:214]
The fair market value of restricted awards, both time vesting and those subject to specific performance criteria, are expensed over the period of vesting. Restricted stock units, which vest based solely upon passage of time generally vest over a period of four years. The fair value of restricted stock units is determined based on the closing market price of the Company's shares on the grant date. Performance share units, which are restricted share awards that vest dependent upon attainment of various levels of performance that equal or exceed targeted levels generally vest in their entirety at the end of a  three year performance period. The number of shares that ultimately vest can vary from 0% to 200% of target depending on the level of achievement of the performance criteria. The fair value of performance share units is determined based on the Monte Carlo valuation model. The compensation expense recognized for all restricted share awards is net of estimated forfeitures.

[0000833444-15-000091:notes:215]
Recipients of restricted stock units have no voting rights and receive dividend equivalent units ("DEUs"). Recipients of performance share units have no voting rights and receive DEUs depending on the attainment of performance levels.

[0000833444-15-000091:notes:216]
A summary of the activity of the Company's restricted stock unit awards as of September 25, 2015 and changes during the year then ended is presented in the tables below:

[0000833444-15-000091:notes:217]
| Non-vested Restricted Stock Units | Shares |  | Weighted-AverageGrant-DateFair Value |
| Non-vested as of September 26, 2014 | 2,411,300 |  |  | $ | 28.59 |  |
| Granted | 598,089 |  |  | 42.31 |  |
| Vested | (929,023 | ) |  | 25.56 |  |
| Forfeited | (300,222 | ) |  | 30.60 |  |
| Non-vested as of September 25, 2015 | 1,780,144 |  |  | 33.98 |  |

[0000833444-15-000091:notes:218]
The weighted-average grant-date fair value of restricted stock units granted during 2015, 2014 and 2013 was $42.31, $38.73 and $27.66, respectively. The total fair value of restricted stock units vested during 2015, 2014 and 2013 was $39 million, $79 million and $64 million, respectively.

[0000833444-15-000091:notes:219]
As of September 25, 2015, there was $31 million of total unrecognized compensation cost related to all unvested restricted share awards. The cost is expected to be recognized over a weighted-average period of 2.6 fiscal years.

[0000833444-15-000091:notes:220]
A summary of the activity of the Company's performance share unit awards as of September 25, 2015 and changes during the year then ended is presented in the table below:

[0000833444-15-000091:notes:221]
| Non-vested Performance Share Units | Shares |  | Weighted-AverageGrant-DateFair Value |
| Non-vested as of September 26, 2014 | 1,387,651 |  |  | $ | 34.10 |  |
| Granted | 540,472 |  |  | 42.91 |  |
| Adjustments for performance achievement relative to award target | 193,814 |  |  | 30.36 |  |
| Vested | (886,008 | ) |  | 30.36 |  |
| Forfeited | (226,699 | ) |  | 35.09 |  |
| Non-vested as of September 25, 2015 | 1,009,230 |  |  | 40.02 |  |

[0000833444-15-000091:notes:222]
The weighted-average grant-date fair value of performance share units granted during 2015, 2014 and 2013 was $42.91, $39.01 and $30.36, respectively. The total fair value of performance share units vested during 2015, 2014 and 2013 was $25 million, nil and nil, respectively. Vested awards include shares that have been fully earned, but had not been delivered as of September 25, 2015. The final determination of the number of shares to be issued in respect of an award based on achievement of pre-defined performance metrics is made by the Company's Compensation and Human Resources Committee of the Board of Directors.

[0000833444-15-000091:notes:223]
As of September 25, 2015, there was $19 million of total unrecognized compensation cost related to all unvested performance share awards. The cost is expected to be recognized over a weighted-average period of 1.9 fiscal years.

[0000833444-15-000091:notes:224]
Deferred Stock Units—Deferred Stock Units ("DSUs") are notional units that are tied to the value of Tyco ordinary shares with distribution deferred until termination of employment or service to the Company. Distribution, when made, will be in the form of actual shares on a one-for-one basis. Similar to restricted stock units that vest over time, the fair value of DSUs is determined based on the closing market price of the Company's shares on the grant date and is amortized to expense over the vesting period. Recipients of DSUs do not have the right to vote and do not receive cash dividends. However, they have the right to receive dividend equivalent units. Conditions of vesting are determined at the time of grant. Under the 2004 Plan, grants made to executives generally vested in equal annual installments over three years while DSUs granted to the Board of Directors were immediately vested.

[0000833444-15-000091:notes:225]
There were no DSU awards granted during 2015, 2014 and 2013; however, participants continue to earn DEUs on their existing awards. The total fair value of DSUs including DEUs vested during 2015, 2014 and 2013 was not material.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-15-000091:notes:226]
Divestitures

[0000833444-15-000091:notes:227]
The Company has continued to assess the strategic fit of its various businesses and has pursued the divestiture of certain businesses which do not align with its long-term strategy.

[0000833444-15-000091:notes:228]
Fiscal 2015

[0000833444-15-000091:notes:229]
During the fourth quarter of fiscal 2015, the Company approved a plan to sell a business within its Global Products segment; however, as of September 25, 2015, the sale had not been completed. The assets and liabilities have not been presented separately as held for sale within the Consolidated Balance Sheets as the amounts were not material to the presentation of all periods. A pre-tax loss of approximately $17 million for the write-down to fair value, less cost to sell was recorded in Selling, general and administrative expenses within the Company’s Consolidated Statements of Operations for the year ended September 25, 2015. This business has not been presented in discontinued operations as the amounts were not material to the Consolidated Financial Statements. The Company expects to complete the transaction during the first half of fiscal 2016.

[0000833444-15-000091:notes:230]
During the third quarter of fiscal 2015, the Company completed the sale of several businesses in the ROW Integrated Solutions and Services segment and recorded a loss on sale of $26 million in (Loss) income from discontinued operations, net of taxes within the Consolidated Statements of Operations for the year ended September 25, 2015. These businesses were accounted for as held for sale within the Consolidated Balance Sheet as of September 26, 2014 and their results of operations have been presented within discontinued operations within the Consolidated Statements of Operations for the years ended September 25, 2015, September 26, 2014, and September 27, 2013.

[0000833444-15-000091:notes:231]
In addition, during the third quarter of fiscal 2015, the Company completed the sale of a business in the ROW Integrated Solutions & Services segment that did not meet the criteria to be classified as a discontinued operation.  Thus, its results of operations are included in continuing operations within the Consolidated Financial Statements. The Company recorded a loss of $18 million in Selling, general and administrative expenses within the Consolidated Statements of Operations for the year ended September 25, 2015. This business was presented as held for sale as of September 26, 2014.

[0000833444-15-000091:notes:232]
During the second quarter of fiscal 2015, the Company concluded that another business in the ROW Integrated Solutions & Services segment which it intends to sell met the criteria to be classified as held for sale. This business is accounted for as held for sale within the Consolidated Balance Sheets as of September 25, 2015 and September 26, 2014, and its results of operations have been presented as discontinued operations within the Consolidated Statements of Operations for the years ended September 25, 2015, September 26, 2014, and September 27, 2013. The Company expects to complete the sale of this business during the first half of fiscal 2016.

[0000833444-15-000091:notes:233]
Fiscal 2014

[0000833444-15-000091:notes:234]
On May 22, 2014, the Company, together with its wholly-owned subsidiary Tyco Far East Holdings Ltd. (the “Seller”) completed the sale of Tyco Fire & Security Services Korea Co. Ltd. and its subsidiaries that formed and operated the Company’s ADT Korea business to an affiliate of The Carlyle Group. The transaction took the form of a sale by the Seller of all of the stock of Tyco Fire & Security Services Korea Co. Ltd. for an aggregate purchase price of $1.93 billion, subject to customary adjustments as set forth in the stock purchase agreement. During the third quarter of fiscal 2014, the Company recognized a gain of $1.0 billion, net of a $212 million charge related to the indemnification at fair value for certain tax related matters borne by the buyer that are probable of being paid.  The net gain was recorded in (Loss) income from discontinued operations, net of income taxes, within the Consolidated Statements of Operations for the year ended September 26, 2014, and the liability was recorded in Other liabilities within the Consolidated Balance Sheet. During the fourth quarter of fiscal 2014, the Company recorded a working capital adjustment, which reduced the net gain by $15 million. This business was accounted for as held for sale within the Consolidated Balance Sheet as of September 27, 2013, and its results of operations have been presented within discontinued operations within the Consolidated Statements of Operations for the years ended September 26, 2014 and September 27, 2013.

[0000833444-15-000091:notes:235]
On April 9, 2014, Atkore International Group Inc. (“Atkore”) redeemed all of the Company’s remaining common equity stake in Atkore for aggregate cash proceeds of $250 million. The Company recognized a net gain of $216 million related to this transaction, which is included in Equity income (loss) in earnings of unconsolidated subsidiaries within the Consolidated Statement of Operations for the year ended September 26, 2014.  The net gain is comprised of a $227 million gain on the sale of the equity investment, partially offset by an $11 million loss, which is the Company's share of loss on Atkore's debt extinguishment undertaken in connection with the redemption.

[0000833444-15-000091:notes:236]
Fiscal 2013

[0000833444-15-000091:notes:237]
During the fourth quarter of fiscal 2013, the Company approved a plan to sell its armored guard business in New Zealand and its fire and security business in Fiji, both of which were in its ROW Integrated Solutions & Services segment.  The sale was completed during the first quarter of fiscal 2014. The assets and liabilities have not been presented separately as held for sale within the Consolidated Balance Sheets as the amounts were not material to the presentation of all periods.  A pre-tax loss of approximately $13 million for the write-down to fair value, less cost to sell was recorded in Selling, general and administrative expenses within the Consolidated Statements of Operations for the year ended September 27, 2013.  This business has not been presented in discontinued operations as the amounts were not material to the Consolidated Financial Statements.

[0000833444-15-000091:notes:238]
During the third quarter of fiscal 2013, the Company completed the sale of its North America guarding business in its NA Integrated Solutions & Services segment for approximately $25 million of cash proceeds, net of $2 million of cash divested on sale.  The pre-tax loss for the write-down to fair value, less cost to sell, was not material.  This business was accounted for as held for sale during the second quarter of fiscal 2013; however, its results of operations have not been presented in discontinued operations as the amounts were not material to the Consolidated Financial Statements.

[0000833444-15-000091:notes:239]
Divestiture Charges (Gains), Net

[0000833444-15-000091:notes:240]
During 2015, 2014, and 2013, the Company recorded a net loss of $31 million, a net gain of $2 million, and a net loss of $20 million, respectively, in Selling, general and administrative expenses within the Company's Consolidated Statements of Operations. The net loss for the year ended September 25, 2015 primarily related to the write-down to fair value, less cost to sell, of a business within the Company's Global Products segment which has not been presented in discontinued operations as the amounts were not material and the divestiture of a business within the Company's ROW Integrated Solutions & Services segment that did not meet the criteria to be presented as discontinued operations.  The net gain for the year ended September 26, 2014 was primarily the result of a favorable court judgment relating to a divested business in the Company's ROW Integrated Solutions & Services segment.  The net loss for the year ended September 27, 2013 primarily resulted from the write-down to fair value, less cost to sell, of the armored guard business in New Zealand and the fire and security business in Fiji, both of which are in the Company's ROW Integrated Solutions & Services segment.

[0000833444-15-000091:notes:241]
Discontinued Operations

[0000833444-15-000091:notes:242]
The components of (Loss) income from discontinued operations, net of income taxes are as follows ($ in millions):

[0000833444-15-000091:notes:243]
|  | For the Years Ended |
|  | September 25, 2015 |  | September 26,2014 |  | September 27,2013 |
| Net revenue | $ | 15 |  |  | $ | 403 |  |  | $ | 589 |  |
| Pre-tax (loss) income from discontinued operations | $ | (13 | ) |  | $ | 56 |  |  | $ | 98 |  |
| Pre-tax separation (charge) income included within discontinued operations (See Note 2) | — |  |  | (1 | ) |  | 8 |  |
| Pre-tax (loss) gain on sale of discontinued operations | (27 | ) |  | 1,160 |  |  | — |  |
| Income tax expense | (26 | ) |  | (174 | ) |  | (16 | ) |
| (Loss) income from discontinued operations, net of income taxes | $ | (66 | ) |  | $ | 1,041 |  |  | $ | 90 |  |

[0000833444-15-000091:notes:244]
Total assets and total liabilities held for sale as of September 25, 2015 and September 26, 2014 were as follows ($ in millions):

[0000833444-15-000091:notes:245]
|  | As of |
|  | September 25, 2015 |  | September 26, 2014 |
| Accounts receivable, net | $ | 1 |  |  | $ | 26 |  |
| Inventories | — |  |  | 7 |  |
| Prepaid expenses and other current assets | 1 |  |  | 107 |  |
| Deferred income taxes | 1 |  |  | 3 |  |
| Property, plant and equipment, net | — |  |  | 6 |  |
| Goodwill | 1 |  |  | 3 |  |
| Intangible assets, net | 8 |  |  | 25 |  |
| Other assets | — |  |  | 3 |  |
| Total assets | $ | 12 |  |  | $ | 180 |  |
| Accounts payable | 1 |  |  | 48 |  |
| Accrued and other current liabilities | 1 |  |  | 62 |  |
| Deferred revenue | — |  |  | 2 |  |
| Other liabilities | 3 |  |  | 6 |  |
| Total liabilities | $ | 5 |  |  | $ | 118 |  |


## us-gaap:EarningsPerShareTextBlock

[0000833444-15-000091:notes:246]
Earnings Per Share

[0000833444-15-000091:notes:247]
The reconciliations between basic and diluted earnings per share attributable to Tyco ordinary shareholders for the years ended September 25, 2015, September 26, 2014 and September 27, 2013 are as follows (in millions, except per share data):

[0000833444-15-000091:notes:248]
|  | For the Years Ended |
|  | September 25, 2015 |  | September 26, 2014 |  | September 27, 2013 |
|  | Income |  | Shares |  | PerShareAmount |  | Income |  | Shares |  | PerShareAmount |  | Income |  | Shares |  | PerShareAmount |
| Basic earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 617 |  |  | 421 |  |  | $ | 1.47 |  |  | $ | 797 |  |  | 455 |  |  | $ | 1.75 |  |  | $ | 446 |  |  | 465 |  |  | $ | 0.96 |  |
| Share options and restricted share awards |  |  |  | 6 |  |  |  |  |  |  |  |  | 8 |  |  |  |  |  |  |  |  | 7 |  |  |  |  |
| Diluted earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations attributable to Tyco ordinary shareholders, giving effect to dilutive adjustments | $ | 617 |  |  | 427 |  |  | $ | 1.44 |  |  | $ | 797 |  |  | 463 |  |  | $ | 1.72 |  |  | $ | 446 |  |  | 472 |  |  | $ | 0.94 |  |

[0000833444-15-000091:notes:249]
The computation of diluted earnings per share for the years ended September 25, 2015, September 26, 2014 and September 27, 2013 excludes the effect of the potential exercise of share options to purchase approximately 3 million, 2 million, and 4 million shares, respectively, and excludes restricted share awards of 1 million, 2 million, and 1 million shares, respectively, because the effect would be anti-dilutive.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000833444-15-000091:notes:250]
Financial Instruments

[0000833444-15-000091:notes:251]
The Company's financial instruments consist primarily of cash and cash equivalents, time deposits, accounts receivable, investments, accounts payable, debt and derivative financial instruments. The fair value of cash, accounts receivable and accounts payable approximated book value as of September 25, 2015 and September 26, 2014. The fair value of derivative financial instruments was not material to any of the periods presented. See below for the fair value of cash equivalents, time deposits and investments and Note 9 for the fair value of debt.

[0000833444-15-000091:notes:252]
Derivative Instruments

[0000833444-15-000091:notes:253]
In the normal course of business, Tyco is exposed to market risk arising from changes in currency exchange rates, interest rates and commodity prices. The Company may use derivative financial instruments to manage exposures to foreign currency, commodity and interest rate risks. The Company's objective for utilizing derivative financial instruments is to manage these risks using the most effective methods to eliminate or reduce the impacts of these exposures. The Company does not use derivative financial instruments for trading or speculative purposes.  As of and during the year ended September 25, 2015, September 26, 2014 and September 27, 2013, the Company did not hold or enter into any commodity derivative instruments or interest rate swaps.

[0000833444-15-000091:notes:254]
For derivative instruments that are designated and qualified as hedging instruments for accounting purposes, the Company documents and links the relationships between the hedging instruments and hedged items. The Company also assesses and documents at the hedge's inception whether the derivatives used in hedging transactions are effective in offsetting changes in fair values associated with the hedged items. During the quarter ended March 27, 2015, the Company designated its  2025 Euro notes as a net investment hedge of the Company’s investments in certain of its international subsidiaries that use the Euro as their functional currency and intercompany permanent loans in order to reduce the volatility caused by changes in foreign currency exchange rates of the Euro with respect to the U.S. Dollar. During the year ended September 25, 2015, the change in the carrying value due to remeasurement of the 2025 Euro notes resulted in a $9 million gain reported in Accumulated other comprehensive loss within the Consolidated Statement of Shareholders' Equity. This hedge did not result in any hedge ineffectiveness for the year ended September 25, 2015.  During the years ended September 26, 2014 and September 27, 2013, the Company did not have derivative instruments that were designated and qualified as hedging instruments for accounting purposes.

[0000833444-15-000091:notes:255]
Foreign Currency Exposures

[0000833444-15-000091:notes:256]
As of September 25, 2015 and September 26, 2014, the total gross notional amount of the Company's foreign exchange contracts was $365 million and $258 million, respectively. The fair value of these derivative financial instruments and impact of such changes in the fair value was not material to the Consolidated Balance Sheets as of September 25, 2015 and September 26, 2014 or Consolidated Statements of Operations and Consolidated Statements of Cash Flows for the years ended September 25, 2015, September 26, 2014 and September 27, 2013.

[0000833444-15-000091:notes:257]
Counterparty Credit Risk

[0000833444-15-000091:notes:258]
The use of derivative financial instruments exposes the Company to counterparty credit risk.  Tyco has established policies and procedures to limit the potential for counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association master netting agreements with substantially all of its counterparties.  The Company's derivative contracts do not contain any credit risk related contingent features and do not require collateral or other security to be furnished by the Company or the counterparties.  The Company's exposure to credit risk associated with its derivative instruments is measured on an individual counterparty basis, as well as by groups of counterparties that share similar attributes.  The Company does not anticipate any non-performance by any of its counterparties, and the concentration of risk with financial institutions does not present significant credit risk to the Company.

[0000833444-15-000091:notes:259]
Cash Equivalents and Investments

[0000833444-15-000091:notes:260]
The fair value of cash equivalents approximates carrying value and are included in Level 1.

[0000833444-15-000091:notes:261]
Investments may include marketable securities such as U.S. government obligations, U.S. government agency and corporate debt securities, equity securities, exchange traded funds or time deposits with banks.

[0000833444-15-000091:notes:262]
When available, the Company uses quoted market prices to determine the fair value of investment securities. Such investments are included in Level 1. When quoted market prices are not readily available, pricing determinations are made based on the results of market approach valuation models using observable market data such as recently reported trades, bid and offer information and benchmark securities. These investments are included in Level 2 and consist primarily of U.S. government agency securities and corporate debt securities.

[0000833444-15-000091:notes:263]
Assets Measured at Fair Value on a Recurring Basis

[0000833444-15-000091:notes:264]
The following tables present the Company's hierarchy for its assets measured at fair value on a recurring basis as of September 25, 2015 and September 26, 2014 ($ in millions):

[0000833444-15-000091:notes:265]
|  |  |  |  |  |  |  | Consolidated Balance SheetClassification |
|  | As of September 25, 2015 |  | Cash and Cash Equivalents |  | Prepaid Expenses and Other Current Assets |  | Other Assets |
| Investment Assets: | Level 1 |  | Level 2 |  | Total |  |  |  |
| Cash equivalents | $ | 909 |  |  | $ | — |  |  | $ | 909 |  |  | $ | 909 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |  |  |
| Exchange traded funds (fixed income) (1) | 186 |  |  | — |  |  | 186 |  |  | — |  |  | 15 |  |  | 171 |  |
| Exchange traded funds (equity) (1) | 77 |  |  | — |  |  | 77 |  |  | — |  |  | — |  |  | 77 |  |
| Trading securities: |  |  |  |  |  |  |  |  |  |  |  |
| Exchange traded funds (equity) | 59 |  |  | — |  |  | 59 |  |  | — |  |  | 59 |  |  | — |  |
|  | $ | 1,231 |  |  | $ | — |  |  | $ | 1,231 |  |  | $ | 909 |  |  | $ | 74 |  |  | $ | 248 |  |

[0000833444-15-000091:notes:266]
(1) Classified as restricted investments.  See Note 12 for further details on asbestos.

[0000833444-15-000091:notes:267]
During 2015 and 2014, the Company did not have any significant transfers between levels within the fair value hierarchy.

[0000833444-15-000091:notes:268]
The Company recorded an unrealized loss of $14 million for the year ended September 25, 2015 related to these available-for-sale securities. The Company did not hold available-for-sale securities as of September 26, 2014. Unrealized gains and losses related to trading securities were not material for the years ended September 25, 2015 and September 26, 2014. Investments with continuous unrealized losses for less than 12 months and 12 months or greater as of both September 25, 2015 and September 26, 2014 were not material. The Company did not record any other-than-temporary impairments for fiscal years 2015, 2014 and 2013.

[0000833444-15-000091:notes:269]
Other

[0000833444-15-000091:notes:270]
The year ended September 26, 2014 included a $7 million loss on the sale of an investment related to the Company's ROW Integrated Solutions and Services business.

[0000833444-15-000091:notes:271]
The Company had $1.4 billion and $1.5 billion of intercompany loans designated as permanent in nature as of  September 25, 2015 and September 26, 2014, respectively. Additionally, for the years ended September 25, 2015, September 26, 2014, and September 27, 2013 the Company recorded a cumulative translation loss of $161 million, loss of $28 million and gain of $3 million, respectively, through Accumulated other comprehensive loss within the Consolidated Statement of Shareholders' Equity related to these loans.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-15-000091:notes:272]
Goodwill and Intangible Assets

[0000833444-15-000091:notes:273]
There were no goodwill impairments resulting from the Company's 2015, 2014 and 2013 annual impairment tests.  The changes in the carrying amount of goodwill by segment for 2015 and 2014 are as follows ($ in millions):

[0000833444-15-000091:notes:274]
|  | NA Integrated Solutions& Services |  | ROWIntegrated Solutions& Services |  | GlobalProducts |  | Total |
| Gross goodwill | $ | 2,104 |  |  | $ | 1,991 |  |  | $ | 1,824 |  |  | $ | 5,919 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of September 27, 2013 | $ | 1,978 |  |  | $ | 923 |  |  | $ | 1,257 |  |  | $ | 4,158 |  |
| 2014 activity: |  |  |  |  |  |  |  |
| Acquisitions/ Purchase accounting adjustments | 10 |  |  | 15 |  |  | (4 | ) |  | 21 |  |
| Currency translation | (12 | ) |  | (34 | ) |  | (11 | ) |  | (57 | ) |
| Gross goodwill | $ | 2,102 |  |  | $ | 1,972 |  |  | $ | 1,809 |  |  | $ | 5,883 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of September 26, 2014 | $ | 1,976 |  |  | $ | 904 |  |  | $ | 1,242 |  |  | $ | 4,122 |  |
| 2015 activity: |  |  |  |  |  |  |  |
| Acquisitions/ Purchase accounting adjustments | 23 |  |  | 50 |  |  | 274 |  |  | 347 |  |
| Currency translation | (29 | ) |  | (168 | ) |  | (36 | ) |  | (233 | ) |
| Gross goodwill | $ | 2,096 |  |  | $ | 1,854 |  |  | $ | 2,047 |  |  | $ | 5,997 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of September 25, 2015 | $ | 1,970 |  |  | $ | 786 |  |  | $ | 1,480 |  |  | $ | 4,236 |  |

[0000833444-15-000091:notes:275]
Intangible Assets

[0000833444-15-000091:notes:276]
There were no indefinite-lived intangible asset impairments resulting from the Company's 2015, 2014 and 2013 annual impairment tests.

[0000833444-15-000091:notes:277]
Intangible asset amortization expense for 2015, 2014 and 2013 was $88 million, $91 million and $94 million, respectively, and was recorded in Cost of services and Selling, general and administrative expenses within the Consolidated Statements of Operations.

[0000833444-15-000091:notes:278]
The estimated aggregate amortization expense on intangible assets is expected to be approximately $88 million for 2016, $83 million for 2017, $77 million for 2018, $71 million for 2019 and $246 million for 2020 and thereafter.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-15-000091:notes:279]
Income Taxes

[0000833444-15-000091:notes:280]
Significant components of the income tax provision for fiscal 2015, 2014 and 2013 are as follows ($ in millions):

[0000833444-15-000091:notes:281]
|  | For the Years Ended |
|  | September 25, 2015 |  | September 26, 2014 |  | September 27, 2013 |
| Current: |  |  |  |  |  |
| United States: |  |  |  |  |  |
| Federal | $ | (6 | ) |  | $ | 10 |  |  | $ | 14 |  |
| State | 6 |  |  | 18 |  |  | 8 |  |
| Non U.S. | 80 |  |  | 95 |  |  | 81 |  |
| Current income tax provision | $ | 80 |  |  | $ | 123 |  |  | $ | 103 |  |
| Deferred: |  |  |  |  |  |
| United States: |  |  |  |  |  |
| Federal | $ | 58 |  |  | $ | (79 | ) |  | $ | (12 | ) |
| State | (4 | ) |  | (24 | ) |  | 5 |  |
| Non U.S. | (34 | ) |  | 4 |  |  | 12 |  |
| Deferred income tax provision | $ | 20 |  |  | $ | (99 | ) |  | $ | 5 |  |
|  | $ | 100 |  |  | $ | 24 |  |  | $ | 108 |  |

[0000833444-15-000091:notes:282]
Non-U.S. income from continuing operations before income taxes was $866 million, $1.1 billion and $844 million for fiscal 2015, 2014 and 2013, respectively.

[0000833444-15-000091:notes:283]
Nondeductible charges during fiscal 2013 primarily related to separation costs incurred.

[0000833444-15-000091:notes:284]
Deferred income taxes result from temporary differences between the amount of assets and liabilities recognized for financial reporting and tax purposes. The components of the net deferred income tax asset as of September 25, 2015 and September 26, 2014 are as follows ($ in millions):

[0000833444-15-000091:notes:285]
|  | As of |
|  | September 25, 2015 |  | September 26, 2014 |
| Deferred tax assets: |  |  |  |
| Accrued liabilities and reserves | $ | 329 |  |  | $ | 483 |  |
| Tax loss and carryforwards | 2,473 |  |  | 2,265 |  |
| Postretirement benefits | 141 |  |  | 106 |  |
| Deferred revenue | 138 |  |  | 120 |  |
| Other | 91 |  |  | 73 |  |
|  | 3,172 |  |  | 3,047 |  |
| Deferred tax liabilities: |  |  |  |
| Prepaid insurance | (109 | ) |  | — |  |
| Property, plant and equipment | (78 | ) |  | (92 | ) |
| Intangible assets | (622 | ) |  | (532 | ) |
| Other | (36 | ) |  | (20 | ) |
|  | (845 | ) |  | (644 | ) |
| Net deferred tax asset before valuation allowance | 2,327 |  |  | 2,403 |  |
| Valuation allowance | (2,016 | ) |  | (1,990 | ) |
| Net deferred tax asset | $ | 311 |  |  | $ | 413 |  |

[0000833444-15-000091:notes:286]
The valuation allowance for deferred tax assets of $2.0 billion as of both September 25, 2015 and September 26, 2014, relates principally to the uncertainty of the utilization of certain deferred tax assets, primarily tax loss and credit carryforwards in various jurisdictions. The valuation allowance as of September 25, 2015 and September 26, 2014 includes separation related charges associated with the early extinguishment of debt which further increased a net operating loss carryforward which the Company does not expect to realize in future periods. The valuation allowance was calculated and recorded when the Company determined that it was more-likely-than-not that all or a portion of our deferred tax assets would not be realized. The Company believes that it will generate sufficient future taxable income to realize the tax benefits related to the remaining net deferred tax assets within the Company's Consolidated Balance Sheets.

[0000833444-15-000091:notes:287]
As of September 25, 2015, the Company had $8,167 million of net operating loss carryforwards in certain non-U.S. jurisdictions. Of these, $7,381 million have no expiration, and the remaining $786 million will expire in future years through 2035. In the U.S., there were approximately $342 million of federal and $563 million of state net operating loss carryforwards as of September 25, 2015, which will expire in future years through 2035. As of September 25, 2015, the Company’s deferred tax asset related to excess interest deductions, which do not have an expiration, of $213 million has been presented within the tax loss and carryforwards line in the table above. Accordingly, the Company reclassified a deferred tax asset of $99 million as of September 26, 2014 for comparative purposes, which was presented within other deferred tax assets in fiscal 2014.

[0000833444-15-000091:notes:288]
As of September 25, 2015, deferred tax assets of approximately $162 million relate to certain operating loss carryforwards resulting from the exercise of employee stock options and restricted stock vestings, the tax benefit of which, when recognized, will be accounted for as a credit to additional paid-in capital rather than a reduction of income tax provision. Such amount has been presented within the tax loss and carryforwards line in the table above.  As of September 26, 2014, the Company presented this item within other deferred tax liabilities in the table above.  Accordingly, the Company reclassified $140 million of deferred tax liabilities as of September 26, 2014 to the tax loss and carryforwards line in the table above for comparative purposes.

[0000833444-15-000091:notes:289]
As of September 25, 2015 and September 26, 2014, the Company had unrecognized tax benefits of $302 million and $267 million, respectively, of which $284 million and $247 million, if recognized, would affect the effective tax rate. The Company recognizes interest and penalties related to unrecognized tax benefits in income tax expense. The Company accrued interest and penalties related to unrecognized tax benefits of $40 million and $36 million as of September 25, 2015 and September 26, 2014, respectively. The Company recognized $1 million of income tax expense for interest and penalties related to unrecognized tax benefits for each of the years ended September 25, 2015, September 26, 2014 and September 27, 2013, respectively.

[0000833444-15-000091:notes:290]
A rollforward of unrecognized tax benefits as of September 25, 2015, September 26, 2014 and September 27, 2013 is as follows ($ in millions):

[0000833444-15-000091:notes:291]
|  | As of |
|  | September 25, 2015 |  | September 26, 2014 |  | September 27, 2013 |
| Balance as of beginning of year | $ | 267 |  |  | $ | 256 |  |  | $ | 120 |  |
| Additions based on tax positions related to the current year | 48 |  |  | 46 |  |  | 137 |  |
| Additions based on tax positions related to prior years | 17 |  |  | 7 |  |  | 7 |  |
| Reductions based on tax positions related to prior years | (19 | ) |  | (39 | ) |  | (6 | ) |
| Reductions related to settlements | — |  |  | (1 | ) |  | — |  |
| Reductions related to lapse of the applicable statute of limitations | (2 | ) |  | (2 | ) |  | (2 | ) |
| Currency translation | (9 | ) |  | — |  |  | — |  |
| Balance as of end of year | $ | 302 |  |  | $ | 267 |  |  | $ | 256 |  |

[0000833444-15-000091:notes:292]
Certain of Tyco's uncertain tax positions relate to tax years that remain subject to audit by the taxing authorities in the U.S. federal, state and local or foreign jurisdictions. Open tax years in significant jurisdictions are as follows:

[0000833444-15-000091:notes:293]
| Jurisdiction | YearsOpen To Audit |
| Australia | 2004-2014 |
| Canada | 2006-2014 |
| Germany | 2006-2014 |
| Ireland | 2010-2014 |
| Switzerland | 2005-2014 |
| United Kingdom | 2013-2014 |
| United States | 1997-2014 |

[0000833444-15-000091:notes:294]
Based on the current status of its income tax audits, the Company believes the unrecognized tax benefits that may be resolved in the next twelve months are not expected to be material.

[0000833444-15-000091:notes:295]
Tax Sharing Agreement and Other Income Tax Matters

[0000833444-15-000091:notes:296]
In connection with the 2012 and 2007 Separations, Tyco entered into the 2012 and 2007 Tax Sharing Agreements, respectively, that govern the respective rights, responsibilities, and obligations of (i) Tyco, Pentair and ADT after the 2012 Separation and (ii) Tyco, Medtronic (formerly Covidien plc) and TE Connectivity after the 2007 Separation with respect to taxes. Specifically, this includes taxes in the ordinary course of business and taxes, if any, incurred as a result of any failure of the respective distributions to qualify tax-free for U.S. federal income tax purposes within the meaning of Section 355 of the Internal Revenue Code ("the Code") or certain internal transactions undertaken in anticipation of the spin-offs to qualify for tax-favored treatment under the Code.

[0000833444-15-000091:notes:297]
Under the 2012 Tax Sharing Agreement Tyco, Pentair and ADT share (i) certain pre-Distribution income tax liabilities that arise from adjustments made by tax authorities to ADT's, Tyco Flow Control's and Tyco's income tax returns, and (ii) payments required to be made by Tyco with respect to the 2007 Tax Sharing Agreement, excluding approximately $175 million of pre-2012 Separation related tax liabilities (collectively, "Shared Tax Liabilities"). Tyco will be responsible for the first $500 million of Shared Tax Liabilities. Pentair and ADT will share 42% and 58%, respectively, of the next $225 million of Shared Tax Liabilities. Tyco, Pentair and ADT will share 52.5% 20% and 27.5%, respectively, of Shared Tax Liabilities above $725 million. All costs and expenses associated with the management of these Shared Tax Liabilities will generally be shared 20%, 27.5%, and 52.5% by Pentair, ADT and Tyco, respectively. In connection with the execution of the 2012 Tax Sharing Arrangement, Tyco established liabilities representing the fair market value of its obligations which was recorded in Other liabilities within the Consolidated Balance Sheet with an offset to Tyco shareholders' equity.

[0000833444-15-000091:notes:298]
Under the 2007 Tax Sharing Agreement, Tyco shares responsibility for certain of Tyco's, Medtronic's and TE Connectivity's income tax liabilities, which result in cash payments, based on a sharing formula for periods prior to and including June 29, 2007. More specifically, Tyco, Medtronic and TE Connectivity share 27%, 42% and 31%, respectively, of shared income tax liabilities that arise from adjustments made by tax authorities to Tyco's, Medtronic's and TE Connectivity's U.S. and certain non-U.S. income tax returns. The costs and expenses associated with the management of these shared tax liabilities are generally shared equally among the parties. In connection with the execution of the 2007 Tax Sharing Agreement, Tyco established a net receivable from Medtronic and TE Connectivity representing the amount Tyco expected to receive for pre-2007 Separation uncertain tax positions, including amounts owed to the Internal Revenue Service ("IRS"). Tyco also established liabilities representing the fair market value of its share of Medtronic's and TE Connectivity's estimated obligations, primarily to the IRS, for their pre-2007 Separation taxes covered by the 2007 Tax Sharing Agreement. During the year ended September 25, 2015, Tyco made a net cash payment of $4 million to Medtronic and TE Connectivity related to the resolution of certain pre-separation tax matters for years prior to 2007. During the year ended September 26, 2014, Tyco made a net cash payment of $155 million to Medtronic under the terms of the 2007 Tax Sharing Agreement. The cash exchanged was a reimbursement between the parties for various payments made to the IRS for federal income taxes related to the audit of fiscal years 2005 through 2007. During the year ended September 27, 2013, Tyco made a net cash payment of $16 million to Medtronic and TE Connectivity related to the resolution of certain IRS audit and pre-Separation tax matters.

[0000833444-15-000091:notes:299]
Tyco assesses the shared tax liabilities and related guaranteed liabilities related to both the 2012 and 2007 Tax Sharing Agreements at each reporting period. Tyco will provide payment to Pentair and ADT under the 2012 Tax Sharing Agreement and to Medtronic and TE Connectivity under the 2007 Tax Sharing Agreement as the shared income tax liabilities are settled. Settlement is expected to occur as the tax, audit and legal processes are completed for the impacted years and cash payments are made. Due to the nature of the unresolved adjustments described in the next paragraph, the maximum amount of future payments under the 2012 and 2007 Tax Sharing Agreements is not known. Such cash payments, when they occur, will reduce the guarantor liability as they represent an equivalent reduction of risk. Tyco also assesses the sufficiency of the 2012 and 2007 Tax Sharing Agreements guarantee liabilities on a quarterly basis and will increase the liability when it is probable that cash payments expected to be made exceed the recorded balance.

[0000833444-15-000091:notes:300]
Tyco and its subsidiaries' income tax returns are examined periodically by various tax authorities. In connection with these examinations, tax authorities, including the IRS, have raised issues and proposed tax adjustments, in particular with respect to years preceding the 2007 Separation. The issues and proposed adjustments related to such years are generally subject to the sharing provisions of the 2007 Tax Sharing Agreement and Tyco's liabilities under the 2007 Tax Sharing Agreement are further subject to the sharing provisions in the 2012 Tax Sharing Agreement. Tyco has previously disclosed that in connection with U.S. federal tax audits, the IRS has raised a number of issues and proposed tax adjustments for periods beginning with the 1997 tax year. Although Tyco has been able to resolve substantially all of the issues and adjustments proposed by the IRS for tax years through 2007, it has not been able to resolve matters related to the treatment of certain intercompany debt transactions during the period. As a result, on June 20, 2013, Tyco received Notices of Deficiency from the IRS asserting that several of Tyco's former U.S. subsidiaries owe additional taxes of $883.3 million plus penalties of $154 million based on audits of the 1997 through 2000 tax years of Tyco and its subsidiaries as they existed at that time. In addition, Tyco received Final Partnership Administrative Adjustments for certain U.S. partnerships owned by former U.S. subsidiaries with respect to which an additional tax deficiency of approximately $30 million was asserted. These amounts exclude interest and do not reflect the impact on subsequent periods if the IRS position described below is ultimately proved correct.

[0000833444-15-000091:notes:301]
No payments with respect to these matters would be required until the dispute is definitively resolved, which, based on the experience of other companies, could take several years. Tyco believes that its income tax reserves and the liabilities recorded within the Consolidated Balance Sheet for the tax sharing agreements continue to be appropriate. However, the ultimate resolution of these matters, and the impact of that resolution, are uncertain and could have a material impact on Tyco's financial condition, results of operations and cash flows. In particular, if the IRS is successful in asserting its claim, it would have an adverse impact on interest deductions related to the same intercompany debt in subsequent time periods, totaling approximately $6.6 billion, which is expected to be disallowed by the IRS.

[0000833444-15-000091:notes:302]
As noted above, Tyco has assessed its obligations under the 2007 Tax Sharing Agreement to determine that its recorded liability is sufficient to cover the indemnifications made by it under such agreement. In the absence of observable transactions for identical or similar guarantees, Tyco determined the fair value of these guarantees and indemnifications utilizing expected present value measurement techniques. Significant assumptions utilized to determine fair value included determining a range of potential outcomes, assigning a probability weighting to each potential outcome and estimating the anticipated timing of resolution. The probability weighted outcomes were discounted using Tyco's incremental borrowing rate.  However, the ultimate resolution of these matters is uncertain and could result in a material adverse impact to the Company's financial position, results of operations, cash flows, or the effective tax rate in future reporting periods.

[0000833444-15-000091:notes:303]
In addition to dealing with tax liabilities for periods prior to the respective Separations, the 2012 and 2007 Tax Sharing Agreements contain sharing provisions to address the contingencies that the 2012 or 2007 Separations, or internal transactions related thereto, may be deemed taxable by U.S. or non U.S. taxing authorities. In the event the 2012 Separation is determined to be taxable and such determination was the result of actions taken after the 2012 Separations by Tyco, ADT or Pentair, the party responsible for such failure would be responsible for all taxes imposed on each company as a result thereof. If such determination is not the result of actions taken by Tyco, ADT or Pentair after the 2012 Separation, then Tyco, ADT and Pentair would be responsible for any taxes imposed on any of the companies as a result of such determination in the same manner and in the same proportions as described above. Similar provisions exist in the 2007 Tax Sharing Agreement. If either of the 2007 or 2012 Separation, or internal transactions taken in anticipation thereof, were deemed taxable, the associated liability could be significant. Tyco is responsible for all of its own taxes that are not shared pursuant to the 2012 and 2007 Tax Sharing Agreements' sharing formulas. In addition, Pentair and ADT, and Medtronic and TE Connectivity are responsible for their tax liabilities that are not subject to the 2012 or 2007 Tax Sharing Agreements' sharing formula.

[0000833444-15-000091:notes:304]
Each of the 2012 and 2007 Tax Sharing Agreements provides that, if any party to such agreement were to default in its obligation to another party to pay its share of the distribution taxes that arise as a result of no party's fault, each non-defaulting party to the agreement would be required to pay, equally with any other non-defaulting party to the agreement, the amounts in default. In addition, if another party to the 2012 or 2007 Tax Sharing Agreements that is responsible for all or a portion of an income tax liability were to default in its payment of such liability to a taxing authority, Tyco could be liable under applicable tax law for such liabilities and required to make additional tax payments. Accordingly, under certain circumstances, Tyco may be obligated to pay amounts in excess of its agreed-upon share of its tax liabilities under either of the 2012 or 2007 Tax Sharing Agreements.

[0000833444-15-000091:notes:305]
As a result of the 2012 Separation, equity awards of certain employees were converted into the three companies. Pursuant to the terms of the 2012 Separation and Distribution Agreement, each of the three companies is responsible for issuing its own shares upon employee exercise of a stock option award or vesting of a restricted unit award. However, the 2012 Tax Sharing Agreement provides that any allowable compensation tax deduction for such awards is to be claimed by the employee's current employer. The 2012 Tax Sharing Agreement requires the employer claiming a tax deduction for shares issued by the other companies to pay a percentage of the allowable tax deduction to the company issuing the equity.

[0000833444-15-000091:notes:306]
During 2015, Tyco incurred a charge of $4 million, to make payments to ADT and Pentair based on estimated allowable deductions for ADT and Pentair shares issued to Company employees, offset by income of $2 million to be received from ADT and Pentair for Company shares issued to their employees, resulting in a net impact of approximately $2 million which was recorded in Other expense, net within the Consolidated Statement of Operations. Additionally, a charge of $5 million was recorded in Other expense, net within the Consolidated Statement of Operations primarily related to the finalization of various audits under the 2007 Tax Sharing Agreement.

[0000833444-15-000091:notes:307]
During 2014, Tyco incurred a charge of $6 million, to make payments to ADT and Pentair based on estimated allowable deductions for ADT and Pentair shares issued to Company employees, offset by income of $1 million to be received from ADT and Pentair for Company shares issued to their employees, resulting in a net impact of approximately $5 million which was recorded in Other expense, net within the Consolidated Statement of Operations. Offsetting this charge was approximately $20 million recorded in Other expense, net within the Consolidated Statement of Operations related to the finalization of audits of fiscal years 2005 through 2007 under the 2012 Tax Sharing Agreement. Additionally, a charge of $21 million was recorded in Other expense, net within the Consolidated Statement of Operations primarily related to the finalization of various audits under the 2007 Tax Sharing Agreement.

[0000833444-15-000091:notes:308]
During 2013, Tyco incurred a charge of $38 million, to make payments to ADT and Pentair based on estimated allowable deductions for ADT and Pentair shares issued to Company employees, offset by income of $6 million to be received from ADT and Pentair for Company shares issued to their employees, resulting in a net impact of approximately $32 million which was recorded in Other expense, net within the Consolidated Statement of Operations.

[0000833444-15-000091:notes:309]
Other Income Tax Matters

[0000833444-15-000091:notes:310]
Except for earnings that are currently distributed, no additional material provision has been made for U.S. or non-U.S. income taxes on the undistributed earnings of subsidiaries or for  deferred tax liabilities for temporary differences related to investments in subsidiaries, since the earnings are expected to be permanently reinvested, the investments are essentially permanent in duration, or Tyco has concluded that no additional tax liability will arise as a result of the distribution of such earnings. A liability could arise if amounts are distributed by such subsidiaries or if such subsidiaries are ultimately disposed. It is not practicable to estimate the additional income taxes related to permanently reinvested earnings or the basis differences related to investments in subsidiaries.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-15-000091:notes:311]
Inventory

[0000833444-15-000091:notes:312]
Inventories consisted of the following ($ in millions):

[0000833444-15-000091:notes:313]
|  | As of |
|  | September 25, 2015 |  | September 26, 2014 |
| Purchased materials and manufactured parts | $ | 165 |  |  | $ | 159 |  |
| Work in process | 84 |  |  | 85 |  |
| Finished goods | 378 |  |  | 381 |  |
| Inventories | $ | 627 |  |  | $ | 625 |  |

[0000833444-15-000091:notes:314]
Inventories are recorded at the lower of cost (primarily first-in, first-out) or market value.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-15-000091:notes:315]
Retirement Plans

[0000833444-15-000091:notes:316]
The Company sponsors a number of pension plans. The Company measures its pension plans as of its fiscal year end. The following disclosures exclude the impact of plans which are immaterial individually and in the aggregate.

[0000833444-15-000091:notes:317]
Defined Benefit Pension Plans—The Company has a number of noncontributory and contributory defined benefit retirement plans covering certain of its U.S. and non-U.S. employees, designed in accordance with conditions and practices in the countries concerned. Net periodic pension benefit cost is based on periodic actuarial valuations which use the projected unit credit method of calculation and is charged to the Consolidated Statements of Operations on a systematic basis over the expected average remaining service lives of current participants. Contribution amounts are determined based on local regulations and the advice of professionally qualified actuaries in the countries concerned. The benefits under the defined benefit plans are based on various factors, such as years of service and compensation.

[0000833444-15-000091:notes:318]
The net periodic benefit cost for material U.S. and non-U.S. defined benefit pension plans for 2015, 2014 and 2013 is as follows ($ in millions):

[0000833444-15-000091:notes:319]
|  | U.S. Plans |  | Non-U.S. Plans |
|  | 2015 |  | 2014 |  | 2013 |  | 2015 |  | 2014 |  | 2013 |
| Service cost | $ | 7 |  |  | $ | 8 |  |  | $ | 6 |  |  | $ | 9 |  |  | $ | 9 |  |  | $ | 8 |  |
| Interest cost | 36 |  |  | 38 |  |  | 33 |  |  | 50 |  |  | 57 |  |  | 50 |  |
| Expected return on plan assets | (56 | ) |  | (51 | ) |  | (48 | ) |  | (74 | ) |  | (76 | ) |  | (67 | ) |
| Amortization of net actuarial loss | 9 |  |  | 9 |  |  | 14 |  |  | 13 |  |  | 13 |  |  | 11 |  |
| Plan settlements, curtailments and special termination benefits | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |
| Net periodic (benefit) cost | $ | (4 | ) |  | $ | 4 |  |  | $ | 5 |  |  | $ | (2 | ) |  | $ | 4 |  |  | $ | 2 |  |
| Weighted-average assumptions used to determine net periodic pension cost during the year: |  |  |  |  |  |  |  |  |  |  |  |
| Discount rate | 4.3 | % |  | 4.9 | % |  | 3.6 | % |  | 3.7 | % |  | 4.2 | % |  | 4.2 | % |
| Expected return on plan assets | 8.0 | % |  | 8.0 | % |  | 8.0 | % |  | 6.6 | % |  | 6.7 | % |  | 6.8 | % |
| Rate of compensation increase | N/A |  |  | N/A |  |  | N/A |  |  | 2.9 | % |  | 2.8 | % |  | 2.8 | % |

[0000833444-15-000091:notes:320]
The estimated net loss for material U.S. and non-U.S. pension benefit plans that will be amortized from accumulated other comprehensive loss into net periodic benefit cost over the next fiscal year is expected to be $13 million and $16 million, respectively.  For inactive plans the Company amortizes its actuarial gains and losses over the average remaining life expectancy of the pension plan participants.

[0000833444-15-000091:notes:321]
The change in benefit obligations, plan assets and the amounts recognized within the Consolidated Balance Sheets for material U.S. and non-U.S. defined benefit plans as of September 25, 2015 and September 26, 2014 is as follows ($ in millions):

[0000833444-15-000091:notes:322]
|  | U.S. Plans |  | Non-U.S. Plans |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Change in benefit obligations: |  |  |  |  |  |  |  |
| Benefit obligations as of beginning of year | $ | 846 |  |  | $ | 792 |  |  | $ | 1,450 |  |  | $ | 1,327 |  |
| Service cost | 7 |  |  | 8 |  |  | 9 |  |  | 9 |  |
| Interest cost | 36 |  |  | 38 |  |  | 50 |  |  | 57 |  |
| Employee contributions | — |  |  | — |  |  | 2 |  |  | 2 |  |
| Plan amendments | — |  |  | — |  |  | (3 | ) |  | — |  |
| Actuarial loss | 38 |  |  | 55 |  |  | 37 |  |  | 106 |  |
| Acquisitions and mergers | — |  |  | — |  |  | 3 |  |  | 2 |  |
| Benefits and administrative expenses paid | (50 | ) |  | (47 | ) |  | (46 | ) |  | (50 | ) |
| Plan settlements, curtailments and special termination benefits | — |  |  | — |  |  | (13 | ) |  | (10 | ) |
| Currency translation | — |  |  | — |  |  | (105 | ) |  | 7 |  |
| Benefit obligations as of end of year | $ | 877 |  |  | $ | 846 |  |  | $ | 1,384 |  |  | $ | 1,450 |  |
| Change in plan assets: |  |  |  |  |  |  |  |
| Fair value of plan assets as of beginning of year | $ | 720 |  |  | $ | 652 |  |  | $ | 1,202 |  |  | $ | 1,119 |  |
| Actual return on plan assets | (14 | ) |  | 90 |  |  | 49 |  |  | 98 |  |
| Employer contributions | 13 |  |  | 25 |  |  | 21 |  |  | 29 |  |
| Employee contributions | — |  |  | — |  |  | 2 |  |  | 2 |  |
| Acquisitions and mergers | — |  |  | — |  |  | — |  |  | 2 |  |
| Benefits and administrative expenses paid | (50 | ) |  | (47 | ) |  | (46 | ) |  | (50 | ) |
| Plan settlements and special termination benefits | — |  |  | — |  |  | (10 | ) |  | (10 | ) |
| Currency translation | — |  |  | — |  |  | (82 | ) |  | 12 |  |
| Fair value of plan assets as of end of year | $ | 669 |  |  | $ | 720 |  |  | $ | 1,136 |  |  | $ | 1,202 |  |
| Funded status | $ | (208 | ) |  | $ | (126 | ) |  | $ | (248 | ) |  | $ | (248 | ) |
| Net amount recognized | $ | (208 | ) |  | $ | (126 | ) |  | $ | (248 | ) |  | $ | (248 | ) |

[0000833444-15-000091:notes:323]
|  | U.S. Plans |  | Non-U.S. Plans |
|  | 2015 |  | 2014 |  | 2015 |  | 2014 |
| Amounts recognized in the Consolidated Balance Sheets consist of: |  |  |  |  |  |  |  |
| Non-current assets | $ | — |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |
| Current liabilities | (3 | ) |  | (3 | ) |  | (5 | ) |  | (6 | ) |
| Non-current liabilities | (205 | ) |  | (123 | ) |  | (244 | ) |  | (242 | ) |
| Net amount recognized | $ | (208 | ) |  | $ | (126 | ) |  | $ | (248 | ) |  | $ | (248 | ) |
| Amounts recognized in accumulated other comprehensive loss (before income taxes) consist of: |  |  |  |  |  |  |  |
| Transition asset and prior service credit | $ | — |  |  | $ | — |  |  | $ | 4 |  |  | $ | 2 |  |
| Net actuarial loss | (378 | ) |  | (278 | ) |  | (502 | ) |  | (491 | ) |
| Total loss recognized | $ | (378 | ) |  | $ | (278 | ) |  | $ | (498 | ) |  | $ | (489 | ) |
| Weighted-average assumptions used to determine pension benefit obligations at year end: |  |  |  |  |  |  |  |
| Discount rate | 4.4 | % |  | 4.3 | % |  | 3.6 | % |  | 3.7 | % |
| Rate of compensation increase | N/A |  |  | N/A |  |  | 2.8 | % |  | 2.9 | % |

[0000833444-15-000091:notes:324]
The accumulated and aggregate benefit obligation and fair value of plan assets with accumulated benefit obligations in excess of plan assets as of September 25, 2015 and September 26, 2014 were as follows ($ in millions):

[0000833444-15-000091:notes:325]
|  | U.S. Plans |  | Non-U.S. Plans |
|  | As of September 25, 2015 |  | As of September 26, 2014 |  | As of September 25, 2015 |  | As of September 26, 2014 |
| Accumulated benefit obligation | $ | 877 |  |  | $ | 846 |  |  | $ | 1,370 |  |  | $ | 1,431 |  |
| Accumulated benefit obligation and fair value of plan assets for plans with accumulated benefit obligations in excess of plan assets: |  |  |  |  |  |  |  |
| Accumulated benefit obligation | $ | 877 |  |  | $ | 846 |  |  | $ | 1,358 |  |  | $ | 1,429 |  |
| Fair value of plan assets | 669 |  |  | 720 |  |  | 1,121 |  |  | 1,200 |  |
| Aggregate benefit obligation and fair value of plan assets for plans with benefit obligations in excess of plan assets: |  |  |  |  |  |  |  |
| Aggregate benefit obligation | $ | 877 |  |  | $ | 846 |  |  | $ | 1,373 |  |  | $ | 1,449 |  |
| Fair value of plan assets | 669 |  |  | 720 |  |  | 1,123 |  |  | 1,202 |  |

[0000833444-15-000091:notes:326]
In determining the expected return on plan assets, the Company considers the relative weighting of plan assets by asset class, historical performance of asset classes over long-term periods, asset class performance expectations as well as current and future economic conditions.

[0000833444-15-000091:notes:327]
The Company's investment strategy for its pension plans is to manage the plans on a going-concern basis. Current investment policy is to maintain an adequate level of diversification while maximizing the return on assets, subject to a prudent level of portfolio risk, for the purpose of enhancing the security of benefits for participants as well as providing adequate liquidity to meet immediate and future benefit payment requirements. In addition, local regulations and local financial considerations are factors in determining the appropriate investment strategy in each country. For U.S. pension plans, this policy targets a 60% allocation to equity securities and a 40% allocation to debt securities. Various asset allocation strategies are in place for non-U.S. pension plans, with a weighted-average target allocation of 51% to equity securities, 44% to debt securities and 5% to other asset classes.

[0000833444-15-000091:notes:328]
Although the Company does not buy or sell any of its own securities as a direct investment for its pension funds, due to external investment management in certain commingled funds, the plans may indirectly hold Tyco securities. The aggregate amount of the securities would not be considered material relative to the total fund assets.

[0000833444-15-000091:notes:329]
The Company evaluates its defined benefit plans' asset portfolios for the existence of significant concentrations of risk. Types of investment concentration risks that are evaluated include, but are not limited to, concentrations in a single entity, industry, foreign country and individual fund manager. As of September 25, 2015, there were no significant concentrations of risk in the Company's defined benefit plan assets.

[0000833444-15-000091:notes:330]
The Company's plan assets are accounted for at fair value and are classified in their entirety based on the lowest level of input that is significant to the fair value measurement. The Company's assessment of the significance of a particular input to the fair value measurement requires judgment, and may affect the valuation of fair value of assets and their placement within the fair value hierarchy levels. The Company's asset allocations by level within the fair value hierarchy as of September 25, 2015 and September 26, 2014 are presented in the table below for the Company's material defined benefit plans.

[0000833444-15-000091:notes:331]
|  | As of |
|  | September 25, 2015 |
| ($ in millions) | Level 1 |  | Level 2 |  | Total |
| Equity securities: |  |  |  |  |  |
| U.S. equity securities | $ | 186 |  |  | $ | 308 |  |  | $ | 494 |  |
| Non-U.S. equity securities | 147 |  |  | 322 |  |  | 469 |  |
| Fixed income securities: |  |  |  |  |  |
| Government and government agency securities | 49 |  |  | 356 |  |  | 405 |  |
| Corporate debt securities | — |  |  | 346 |  |  | 346 |  |
| Mortgage and other asset-backed securities | — |  |  | 62 |  |  | 62 |  |
| Cash and cash equivalents | 29 |  |  | — |  |  | 29 |  |
| Total | $ | 411 |  |  | $ | 1,394 |  |  | $ | 1,805 |  |

[0000833444-15-000091:notes:332]
|  | As of |
|  | September 26, 2014 |
| ($ in millions) | Level 1 |  | Level 2 |  | Total |
| Equity securities: |  |  |  |  |  |
| U.S. equity securities | $ | 207 |  |  | $ | 326 |  |  | $ | 533 |  |
| Non-U.S. equity securities | 165 |  |  | 363 |  |  | 528 |  |
| Fixed income securities: |  |  |  |  |  |
| Government and government agency securities | 45 |  |  | 325 |  |  | 370 |  |
| Corporate debt securities | — |  |  | 408 |  |  | 408 |  |
| Mortgage and other asset-backed securities | — |  |  | 69 |  |  | 69 |  |
| Cash and cash equivalents | 14 |  |  | — |  |  | 14 |  |
| Total | $ | 431 |  |  | $ | 1,491 |  |  | $ | 1,922 |  |

[0000833444-15-000091:notes:333]
Equity securities consist primarily of publicly traded U.S. and non-U.S. equities. Publicly traded securities are valued at the last trade or closing price reported in the active market in which the individual securities are traded. Certain equity securities are held within commingled funds which are valued at the unitized net asset value ("NAV") or percentage of the net asset value as determined by the custodian of the fund. These values are based on the fair value of the underlying net assets owned by the fund.

[0000833444-15-000091:notes:334]
Fixed income securities consist primarily of government and government agency securities, corporate debt securities, and mortgage and other asset-backed securities. When available, fixed income securities are valued at the closing price reported in the active market in which the individual security is traded. Government and government agency securities and corporate debt securities are valued using the most recent bid prices or occasionally the mean of the latest bid and ask prices when markets are less liquid. Asset-backed securities including mortgage backed securities are valued using broker/dealer quotes when available. When quotes are not available, fair value is determined utilizing a discounted cash flow approach, which incorporates other observable inputs such as cash flows, underlying security structure and market information including interest rates and bid evaluations of comparable securities. Certain fixed income securities are held within commingled funds which are valued unitizing NAV determined by the custodian of the fund. These values are based on the fair value of the underlying net assets owned by the fund.

[0000833444-15-000091:notes:335]
Cash and cash equivalents consist primarily of short-term commercial paper, bonds and other cash or cash-like instruments including settlement proceeds due from brokers, stated at cost, which approximates fair value.

[0000833444-15-000091:notes:336]
The strategy of the Company's investment managers with regard to the investments valued using NAV or its equivalent is to either match or exceed relevant benchmarks associated with the respective asset category. None of the investments valued using NAV or its equivalent contain any redemption restrictions or unfunded commitments.

[0000833444-15-000091:notes:337]
During 2015, the Company contributed $13 million to its U.S. and $21 million to its non-U.S. pension plans, which represented the Company's minimum required contributions to its pension plans for fiscal year 2015. The Company did not make any voluntary contributions to its U.S. and non-U.S. plans during 2015.

[0000833444-15-000091:notes:338]
The Company's funding policy is to make contributions in accordance with the laws and customs of the various countries in which it operates as well as to make voluntary contributions from time-to-time. The Company anticipates that it will contribute at least the minimum required to its pension plans in 2016 of $3 million for the U.S. plans and $26 million for non-U.S. plans.

[0000833444-15-000091:notes:339]
Benefit payments, including those amounts to be paid out of corporate assets and reflecting future expected service as appropriate, are expected to be paid as follows ($ in millions):

[0000833444-15-000091:notes:340]
|  | U.S. Plans |  | Non-U.S. Plans |
| 2016 | $ | 45 |  |  | $ | 44 |  |
| 2017 | 46 |  |  | 46 |  |
| 2018 | 47 |  |  | 47 |  |
| 2019 | 48 |  |  | 48 |  |
| 2020 | 49 |  |  | 49 |  |
| 2021 - 2024 | 262 |  |  | 269 |  |

[0000833444-15-000091:notes:341]
The Company also participates in a number of multi-employer defined benefit plans on behalf of certain employees. Pension expense related to multi-employer plans was not material for 2015, 2014 and 2013.

[0000833444-15-000091:notes:342]
Executive Retirement Arrangements—Messrs. Kozlowski and Swartz participated in individual Executive Retirement Arrangements maintained by Tyco (the "ERA"). Under the ERA, Messrs. Kozlowski and Swartz would have fixed lifetime benefits commencing at their normal retirement age of 65.  Due to the legal settlements as described in Note 12, the Company reversed the liabilities to Messrs. Kozlowski and Swartz in fiscal years 2014 and 2012, respectively.

[0000833444-15-000091:notes:343]
Defined Contribution Retirement Plans—The Company maintains several defined contribution retirement plans, which include 401(k) matching programs, as well as qualified and nonqualified profit sharing and share bonus retirement plans. Expense for the defined contribution plans is computed as a percentage of participants' compensation and was $61 million, $65 million and $63 million for 2015, 2014 and 2013, respectively.

[0000833444-15-000091:notes:344]
Deferred Compensation Plans—The Company has nonqualified deferred compensation plans, which permit eligible employees to defer a portion of their compensation. A record keeping account is set up for each participant and the participant chooses from a variety of measurement funds for the deemed investment of their accounts. The measurement funds correspond to a number of funds in the Company's 401(k) plans and the account balance fluctuates with the investment returns on those funds. Deferred compensation liabilities were $85 million and $95 million as of September 25, 2015 and September 26, 2014, respectively. Deferred compensation expense was not material for 2015, 2014 and 2013.

[0000833444-15-000091:notes:345]
Postretirement Benefit Plans—The Company generally does not provide postretirement benefits other than pensions for its employees. However, certain acquired operations provide these benefits to employees who were eligible at the date of acquisition, and a small number of U.S. and Canadian operations provide ongoing eligibility for such benefits.

[0000833444-15-000091:notes:346]
Net periodic postretirement benefit cost was not material for 2015, 2014 and 2013. The Company's Consolidated Balance Sheets include unfunded postretirement benefit obligations of $26 million and $32 million as of September 25, 2015 and September 26, 2014, respectively within other liabilities. The Company's Consolidated Balance Sheets include nil of postretirement benefit assets as of both September 25, 2015 and September 26, 2014. In addition, the Company recorded a net actuarial gain of $8 million and $6 million in Accumulated other comprehensive loss within the Consolidated Statement of Shareholders' Equity as of September 25, 2015 and September 26, 2014, respectively.

[0000833444-15-000091:notes:347]
The Company expects to make contributions to its postretirement benefit plans of $3 million in 2016.

[0000833444-15-000091:notes:348]
| 2016 | $ | 3 |  |
| 2017 | 3 |  |
| 2018 | 3 |  |
| 2019 | 3 |  |
| 2020 | 2 |  |
| 2021 - 2024 | 9 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000833444-15-000091:notes:349]
Property, Plant and Equipment


## us-gaap:ReconciliationOfAssetsFromSegmentToConsolidatedTextBlock

[0000833444-15-000091:notes:350]
Total assets by segment as of September 25, 2015, September 26, 2014 and September 27, 2013 are as follows ($ in millions):

[0000833444-15-000091:notes:351]
|  | 2015 |  | 2014 |  | 2013 |
| Total Assets: |  |  |  |  |  |
| NA Integrated Solutions & Services | $ | 3,880 |  |  | $ | 3,870 |  |  | $ | 3,842 |  |
| ROW Integrated Solutions & Services | 2,751 |  |  | 3,029 |  |  | 2,980 |  |
| Global Products | 3,097 |  |  | 2,676 |  |  | 2,726 |  |
| Corporate and Other | 2,581 |  |  | 2,054 |  |  | 1,639 |  |
| Assets held for sale | 12 |  |  | 180 |  |  | 989 |  |
|  | $ | 12,321 |  |  | $ | 11,809 |  |  | $ | 12,176 |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000833444-15-000091:notes:352]
Restructuring and Asset Impairment Charges, Net

[0000833444-15-000091:notes:353]
During fiscal 2015, the Company identified and pursued opportunities for cost savings through restructuring activities and workforce reductions to improve operating efficiencies across the Company's businesses. The Company expects to incur restructuring and restructuring related charges between $50 million and $75 million in fiscal 2016, which does not include repositioning charges, as discussed below.

[0000833444-15-000091:notes:354]
The Company recorded restructuring and asset impairment charges by action and Consolidated Statement of Operations classification as follows ($ in millions):

[0000833444-15-000091:notes:355]
|  | For the Years Ended |
|  | September 25, 2015 |  | September 26, 2014 |  | September 27, 2013 |
| 2015 actions | $ | 178 |  |  | $ | — |  |  | $ | — |  |
| 2014 actions | (1 | ) |  | 44 |  |  | — |  |
| 2013 and prior actions | (1 | ) |  | 5 |  |  | 111 |  |
| Total restructuring and asset impairment charges, net | $ | 176 |  |  | $ | 49 |  |  | $ | 111 |  |
| Charges reflected in SG&A | 1 |  |  | 2 |  |  | — |  |
| Charges reflected in restructuring and asset impairment charges, net | $ | 175 |  |  | $ | 47 |  |  | $ | 111 |  |

[0000833444-15-000091:notes:356]
2015 Actions

[0000833444-15-000091:notes:357]
Restructuring and asset impairment charges, net, during the year ended September 25, 2015 related to the 2015 actions are as follows ($ in millions):

[0000833444-15-000091:notes:358]
|  | For the Year Ended |
|  | September 25, 2015 |
|  | EmployeeSeverance andBenefits |  | Facility Exitand OtherCharges |  | Charges Reflected in SG&A |  | Total |
| NA Integrated Solutions & Services | $ | 41 |  |  | $ | 3 |  |  | $ | 1 |  |  | $ | 45 |  |
| ROW Integrated Solutions & Services | 81 |  |  | 9 |  |  | 1 |  |  | 91 |  |
| Global Products | 21 |  |  | 1 |  |  | (1 | ) |  | 21 |  |
| Corporate and Other | 20 |  |  | 1 |  |  | — |  |  | 21 |  |
| Total | $ | 163 |  |  | $ | 14 |  |  | $ | 1 |  |  | $ | 178 |  |

[0000833444-15-000091:notes:359]
The rollforward of the reserves related to 2015 actions from September 26, 2014 to September 25, 2015 is as follows ($ in millions):

[0000833444-15-000091:notes:360]
| Balance as of September 26, 2014 | $ | — |  |
| Charges | 188 |  |
| Reversals | (11 | ) |
| Utilization | (57 | ) |
| Currency translation | (2 | ) |
| Balance as of September 25, 2015 | $ | 118 |  |

[0000833444-15-000091:notes:361]
Restructuring reserves for businesses that are included in Liabilities held for sale within the Consolidated Balance Sheets are excluded from the table above.  See Note 3.

[0000833444-15-000091:notes:362]
2014 Actions

[0000833444-15-000091:notes:363]
Restructuring and asset impairment charges, net, during the years ended September 25, 2015 and September 26, 2014 related to the 2014 actions are as follows ($ in millions):

[0000833444-15-000091:notes:364]
|  | For the Year Ended |
|  | September 25, 2015 |
|  | EmployeeSeverance andBenefits |  | Facility Exitand OtherCharges |  | Total |
| NA Integrated Solutions & Services | $ | (5 | ) |  | $ | — |  |  | $ | (5 | ) |
| ROW Integrated Solutions & Services | (1 | ) |  | (1 | ) |  | (2 | ) |
| Global Products | 6 |  |  | — |  |  | 6 |  |
| Total | $ | — |  |  | $ | (1 | ) |  | $ | (1 | ) |

[0000833444-15-000091:notes:365]
|  | For the Year Ended |
|  | September 26, 2014 |
|  | EmployeeSeverance andBenefits |  | Facility Exitand OtherCharges |  | Charges Reflected in SG&A |  | Total |
| NA Integrated Solutions & Services | $ | 16 |  |  | $ | — |  |  | $ | — |  |  | $ | 16 |  |
| ROW Integrated Solutions & Services | 18 |  |  | 5 |  |  | — |  |  | 23 |  |
| Global Products | 3 |  |  | — |  |  | 2 |  |  | 5 |  |
| Total | $ | 37 |  |  | $ | 5 |  |  | $ | 2 |  |  | $ | 44 |  |

[0000833444-15-000091:notes:366]
Restructuring and asset impairment charges, net, incurred cumulative to date from initiation of the 2014 actions are as follows ($ in millions):

[0000833444-15-000091:notes:367]
|  | EmployeeSeverance andBenefits |  | Facility Exitand OtherCharges |  | Charges Reflected in SG&A |  | Total |
| NA Integrated Solutions & Services | $ | 11 |  |  | $ | — |  |  | $ | — |  |  | $ | 11 |  |
| ROW Integrated Solutions & Services | 17 |  |  | 4 |  |  | — |  |  | 21 |  |
| Global Products | 9 |  |  | — |  |  | 2 |  |  | 11 |  |
| Total | $ | 37 |  |  | $ | 4 |  |  | $ | 2 |  |  | $ | 43 |  |

[0000833444-15-000091:notes:368]
The rollforward of the reserves related to 2014 actions from September 26, 2014 to September 25, 2015 is as follows ($ in millions):

[0000833444-15-000091:notes:369]
| Balance as of September 26, 2014 | $ | 29 |  |
| Charges | 7 |  |
| Reversals | (8 | ) |
| Utilization | (17 | ) |
| Currency translation | (3 | ) |
| Balance as of September 25, 2015 | $ | 8 |  |

[0000833444-15-000091:notes:370]
2013 and prior actions

[0000833444-15-000091:notes:371]
The Company continues to maintain restructuring reserves related to actions initiated prior to fiscal 2013. The total amount of these reserves was $34 million and $70 million as of September 25, 2015 and September 26, 2014, respectively. The Company recorded $1 million in net reversals, $5 million of restructuring charges, net and $111 million of restructuring charges, net, and utilized $27 million, $62 million and $81 million for the years ended September 25, 2015, September 26, 2014 and September 27, 2013, respectively, related to 2013 and prior actions.  The remaining change in reserve during the years ended September 25, 2015, September 26, 2014 and September 27, 2013 relates to currency translation.  The aggregate remaining reserves relate to employee severance and benefits as well as facility exit costs for long-term non-cancelable lease obligations primarily within the Company's NA and ROW Integrated Solutions and Services businesses.

[0000833444-15-000091:notes:372]
Total Restructuring Reserves

[0000833444-15-000091:notes:373]
Repositioning

[0000833444-15-000091:notes:374]
The Company has initiated certain global actions designed to reduce its cost structure and improve future profitability by streamlining operations and better aligning functions, which the Company refers to as repositioning actions. These actions may or may not lead to a future restructuring action. During the years ended September 25, 2015, September 26, 2014, and September 27, 2013, the Company recorded repositioning charges of $113 million, $44 million, and $20 million, respectively, primarily related to professional fees which have been reflected in Selling, general and administrative expenses within the Consolidated Statement of Operations.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000833444-15-000091:notes:375]
The components of Accumulated other comprehensive loss are as follows ($ in millions):

[0000833444-15-000091:notes:376]
|  | CurrencyTranslationAdjustments |  | Unrealized Loss onMarketableSecurities andDerivativeInstruments |  | RetirementPlans |  | Accumulated OtherComprehensive Loss |
| Balance as of September 28, 2012 | $ | (419 | ) |  | $ | — |  |  | $ | (547 | ) |  | $ | (966 | ) |
| Other comprehensive (loss) income, net of tax | (85 | ) |  | — |  |  | 61 |  |  | (24 | ) |
| Amounts reclassified from accumulated other comprehensive income, net of tax | (15 | ) |  | — |  |  | 18 |  |  | 3 |  |
| Net current period other comprehensive (loss) income | (100 | ) |  | — |  |  | 79 |  |  | (21 | ) |
| Balance as of September 27, 2013 | $ | (519 | ) |  | $ | — |  |  | $ | (468 | ) |  | $ | (987 | ) |
| Other comprehensive loss, net of tax | (133 | ) |  | — |  |  | (80 | ) |  | (213 | ) |
| Amounts reclassified from accumulated other comprehensive income, net of tax | (41 | ) |  | — |  |  | 16 |  |  | (25 | ) |
| Net current period other comprehensive loss | (174 | ) |  | — |  |  | (64 | ) |  | (238 | ) |
| Balance as of September 26, 2014 | $ | (693 | ) |  | $ | — |  |  | $ | (532 | ) |  | $ | (1,225 | ) |
| Other comprehensive loss, net of tax | (541 | ) |  | (9 | ) |  | (84 | ) |  | (634 | ) |
| Amounts reclassified from accumulated other comprehensive income, net | 1 |  |  | — |  |  | 17 |  |  | 18 |  |
| Net current period other comprehensive loss | (540 | ) |  | (9 | ) |  | (67 | ) |  | (616 | ) |
| Balance as of September 25, 2015 | $ | (1,233 | ) |  | $ | (9 | ) |  | $ | (599 | ) |  | $ | (1,841 | ) |


## us-gaap:ScheduleOfComprehensiveIncomeLossTableTextBlock

[0000833444-15-000091:notes:377]
|  | 2015 |  | 2014 |  | 2013 |
| Net income | $ | 549 |  |  | $ | 1,839 |  |  | $ | 533 |  |
| Foreign currency translation (1) | (541 | ) |  | (133 | ) |  | (85 | ) |
| Liquidation of foreign entities (2) | 1 |  |  | (40 | ) |  | (9 | ) |
| Income tax expense (3) | — |  |  | (1 | ) |  | (6 | ) |
| Foreign currency translation, net of tax | (540 | ) |  | (174 | ) |  | (100 | ) |
| Net actuarial (losses) gains | (128 | ) |  | (104 | ) |  | 107 |  |
| Amortization reclassified into earnings (4) | 22 |  |  | 22 |  |  | 26 |  |
| Income tax benefit (expense) | 39 |  |  | 18 |  |  | (54 | ) |
| Defined benefit and post retirement plans, net of tax | (67 | ) |  | (64 | ) |  | 79 |  |
| Unrealized (loss) gain on marketable securities and derivative instruments (5) | (14 | ) |  | (1 | ) |  | 2 |  |
| Income tax benefit (expense) | 5 |  |  | 1 |  |  | (2 | ) |
| Unrealized loss on marketable securities and derivative instruments, net of tax | (9 | ) |  | — |  |  | — |  |
| Total other comprehensive loss, net of tax | (616 | ) |  | (238 | ) |  | (21 | ) |
| Comprehensive (loss) income | (67 | ) |  | 1,601 |  |  | 512 |  |
| Less: comprehensive (loss) gain attributable to noncontrolling interests | (2 | ) |  | 1 |  |  | (3 | ) |
| Comprehensive (loss) income attributable to Tyco ordinary shareholders | $ | (65 | ) |  | $ | 1,600 |  |  | $ | 515 |  |

[0000833444-15-000091:notes:378]
| (1) | Includes a $9 million gain related to the net investment hedge for the year ended September 25, 2015. The Company did not hold this net investment hedge in fiscal years 2014 or 2013. |

[0000833444-15-000091:notes:379]
| (2) | During the years ended September 25, 2015, September 26, 2014 and September 27, 2013, $1 million of cumulative translation losses, $40 million of cumulative translation gains and $9 million of cumulative translation gains, respectively, were transferred from currency translation adjustments as a result of the sale of foreign entities. Of these amounts, a loss of $1 million, a gain of $40 million and nil, respectively, are included in (Loss) income from discontinued operations, net of income taxes within the Consolidated Statements of Operations. |

[0000833444-15-000091:notes:380]
| (3) | Income tax expense related to previously held net investment hedges was nil, $1 million and $6 million for the years ended September 25, 2015, September 26, 2014 and September 27, 2013. |

[0000833444-15-000091:notes:381]
| (4) | Reclassified to net periodic benefit cost. See Note 13. During the year ended September 26, 2014, $6 million of net actuarial losses were transferred from amortization of net actuarial losses and included in (Loss) income from discontinued operations, net of income taxes within the Consolidated Statements of Operations as a result of the sale of foreign entities. |

[0000833444-15-000091:notes:382]
| (5) | When sold, the (loss) gain will be reclassified to realized (loss) gain on marketable securities and derivative instruments and is recorded in Other expense, net within the Consolidated Statements of Operations. |


## us-gaap:ScheduleOfEntityWideDisclosureOnGeographicAreasLongLivedAssetsInIndividualForeignCountriesByCountryTextBlock

[0000833444-15-000091:notes:383]
Long-lived assets by geographic area as of September 25, 2015, September 26, 2014 and September 27, 2013 are as follows ($ in millions):

[0000833444-15-000091:notes:384]
|  | 2015 |  | 2014 |  | 2013 |
| Long-lived assets(1): |  |  |  |  |  |
| North America(2) | $ | 856 |  |  | $ | 905 |  |  | $ | 905 |  |
| Latin America | 110 |  |  | 113 |  |  | 129 |  |
| Europe, Middle East and Africa | 313 |  |  | 338 |  |  | 340 |  |
| Asia-Pacific | 109 |  |  | 137 |  |  | 154 |  |
| Corporate and Other | 14 |  |  | 20 |  |  | 32 |  |
|  | $ | 1,402 |  |  | $ | 1,513 |  |  | $ | 1,560 |  |

[0000833444-15-000091:notes:385]
| (1) | Long-lived assets are comprised primarily of subscriber system assets, net, property, plant and equipment, net, deferred subscriber acquisition costs, net and dealer intangibles. They exclude goodwill, other intangible assets and other assets. |

[0000833444-15-000091:notes:386]
| (2) | Includes U.S. long-lived assets of $801 million, $836 million, and $828 million for 2015, 2014 and 2013, respectively. |


## us-gaap:ScheduleOfRevenueFromExternalCustomersAttributedToForeignCountriesByGeographicAreaTextBlock

[0000833444-15-000091:notes:387]
Net revenue by geographic area for the years ended September 25, 2015, September 26, 2014 and September 27, 2013 is as follows ($ in millions):

[0000833444-15-000091:notes:388]
|  | 2015 |  | 2014 |  | 2013 |
| Net Revenue(1): |  |  |  |  |  |
| North America(2) | $ | 5,544 |  |  | $ | 5,496 |  |  | $ | 5,343 |  |
| Latin America | 492 |  |  | 500 |  |  | 456 |  |
| Europe, Middle East and Africa (3) | 2,551 |  |  | 2,836 |  |  | 2,758 |  |
| Asia-Pacific | 1,315 |  |  | 1,500 |  |  | 1,501 |  |
|  | $ | 9,902 |  |  | $ | 10,332 |  |  | $ | 10,058 |  |

[0000833444-15-000091:notes:389]
| (1) | Net revenue is attributed to individual countries based on the jurisdiction of formation of the reporting entity that records the transaction. |

[0000833444-15-000091:notes:390]
| (2) | Includes U.S. net revenue of $4,822 million, $4,717 million and $4,568 million for 2015, 2014 and 2013, respectively. |

[0000833444-15-000091:notes:391]
| (3) | The U.K. represents the largest portion of net revenue in the Europe, Middle East and Africa region with net revenue of $1,140 million, $1,262 million and $1,168 million for 2015, 2014 and 2013, respectively. |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000833444-15-000091:notes:392]
TYCO INTERNATIONAL PLC

[0000833444-15-000091:notes:393]
SCHEDULE II—VALUATION AND QUALIFYING ACCOUNTS

[0000833444-15-000091:notes:394]
| Description | Balance atBeginningof Year |  | AdditionsCharged toIncome |  | Acquisitions(Divestitures)and Other |  | Deductions(1) |  | Balance atEnd ofYear |
| Accounts Receivable: |  |  |  |  |  |  |  |  |  |
| Year Ended September 27, 2013 | $ | 59 |  |  | $ | 52 |  |  | $ | 1 |  |  | $ | (39 | ) |  | $ | 73 |  |
| Year Ended September 26, 2014 | $ | 73 |  |  | 27 |  |  | 1 |  |  | (34 | ) |  | $ | 67 |  |
| Year Ended September 25, 2015 | $ | 67 |  |  | 39 |  |  | (4 | ) |  | (31 | ) |  | $ | 71 |  |

[0000833444-15-000091:notes:395]
| (1) | Deductions represent uncollectible accounts written off, net of recoveries. |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-15-000091:notes:396]
Shareholders' Equity and Comprehensive Income

[0000833444-15-000091:notes:397]
Dividends

[0000833444-15-000091:notes:398]
The authority to declare and pay dividends is vested in the Board of Directors. The timing, declaration and payment of future dividends to holders of the Company's ordinary shares will be determined by the Company's Board of Directors and will depend upon many factors, including the Company's financial condition and results of operations, the capital requirements of the Company's businesses, industry practice and any other relevant factors.

[0000833444-15-000091:notes:399]
Under Irish law, dividends may only be paid (and share repurchases and redemptions must generally be funded) out of “distributable reserves.”  The creation of distributable reserves was accomplished by way of a capital reduction, which the Irish high Court approved on December 18, 2014.

[0000833444-15-000091:notes:400]
On September 3, 2015, the Company declared a quarterly dividend of $0.205 per share, paid on November 12, 2015 to shareholders of record on October 23, 2015.  On June 4, 2015, the Company declared a quarterly dividend of $0.205 per share, paid on August 19, 2015 to shareholders of record on July 24, 2015.  On March 4, 2015, the Company declared a quarterly dividend of $0.205 per share paid on May 20, 2015 to shareholders of record on April 24, 2015.

[0000833444-15-000091:notes:401]
The Company presented dividends declared of $86 million for each of the quarters ended March 27, 2015 and June 26, 2015, as a reduction of Additional paid in capital within the Company’s Consolidated Shareholders’ Equity.  For the quarter ended September 25, 2015, the Company corrected this presentation to present dividends declared for the second, third and fourth quarters of fiscal 2015 (subsequent to the re-domicile to Ireland), as a reduction of Accumulated Earnings within the Consolidated Statement of Shareholder’s Equity to conform the presentation to its stand-alone statutory financial statements prepared under Irish GAAP.  The Irish Companies Act (2014) does not permit dividends to be paid from share capital, including share premium. This reclassification has no effect on net revenue, operating income (loss), net income (loss), cash flows and total equity.  The Company will reclass its presentation of dividends declared for the periods ending March 27, 2015 and June 26, 2015 when the Company files its Quarterly Reports on Form 10-Q for the periods ending March 25, 2016 and June 24, 2016, respectively.

[0000833444-15-000091:notes:402]
Prior to the change in domicile to Ireland, the Company made dividend payments from its contributed surplus equity position in its Swiss statutory accounts.  Under Swiss law, the authority to declare dividends is vested in the general meeting of shareholders.  On March 5, 2014, the Company's shareholders approved an annual cash dividend of $0.72 per ordinary share.  Payment of the dividend was made in four quarterly installments of $0.18 from May 2014 through February 2015.  As a result, during the quarter ended March 28, 2014, the Company recorded an accrued dividend of $332 million within Accrued and other current liabilities and a corresponding reduction to Contributed surplus within the Company's Consolidated Balance Sheet. The first installment was paid on May 21, 2014 to shareholders of record on April 25, 2014.  The second installment was paid on August 20, 2014 to shareholders of record on July 25, 2014.  The third installment was paid on November 13, 2014 to stockholders of record on October 24, 2014.  The fourth installment was paid on February 18, 2015 to shareholders of record on January 23, 2015.

[0000833444-15-000091:notes:403]
On March 6, 2013, the Company's shareholders approved a cash dividend of $0.64 per share, payable to shareholders in four quarterly installments of $0.16 from May 2013 through February 2014.  As a result, during the quarter ended March 29, 2013, the Company recorded an accrued dividend of $296 million within Accrued and other current liabilities and a corresponding reduction to Contributed surplus within the Company's Consolidated Balance Sheet.  The first installment of $0.16 was paid on May 22, 2013 to shareholders of record on April 26, 2013.  The second installment of $0.16 was paid on August 21, 2013 to shareholders of record on July 26, 2013.  The third installment of $0.16 was paid on November 14, 2013 to shareholders of record on October 25, 2013.  The fourth installment of $0.16 was paid on February 19, 2014 to shareholders of record on January 24, 2014.

[0000833444-15-000091:notes:404]
Authorized Share Capital

[0000833444-15-000091:notes:405]
As of September 25, 2015, the Company's authorized share capital amounted to $11,000,000 and €40,000, divided into 1,000,000,000 ordinary shares with a par value of $0.01 per share, 100,000,000 preferred shares with a par value of $0.01 per share and 40,000 ordinary A shares with a par value of €1.00 per share.  The authorized share capital includes 40,000 ordinary A shares with a par value of €1.00 per share in order to satisfy statutory requirements for the incorporation of all Irish public limited companies. Tyco Ireland may issue shares subject to the maximum prescribed by its authorized share capital contained in its memorandum of association. In connection with the re-domicile to Ireland, the Company canceled all the outstanding treasury shares, including shares held by subsidiaries, with an offsetting reduction in Additional paid in capital.

[0000833444-15-000091:notes:406]
As of September 26, 2014, the Company's share capital amounted to CHF 243,181,525, or 486,363,050 registered ordinary shares with a par value of CHF 0.50 per share. Although the Company stated its par value in Swiss francs, it used the U.S. dollar as its reporting currency for preparing its Consolidated Financial Statements.

[0000833444-15-000091:notes:407]
Issued Share Capital

[0000833444-15-000091:notes:408]
The Company issued one authorized ordinary share in exchange for each ordinary share of Tyco Switzerland to the former shareholders of Tyco Switzerland.  All ordinary shares issued at the effective time of the re-domicile to Ireland were issued as fully paid-up and non-assessable.

[0000833444-15-000091:notes:409]
Share Repurchase Program

[0000833444-15-000091:notes:410]
The Company's Board of Directors approved the $1 billion and $1.75 billion 2014 share repurchase programs and the $600 million 2013 share repurchase program in September 2014, March 2014 and January 2013, respectively. Share repurchases reduce the amount of ordinary shares outstanding and decrease the dividends declared within the Consolidated Statement of Shareholders' Equity. Shares repurchased by the Company by fiscal year and share repurchase program are provided below:

[0000833444-15-000091:notes:411]
Comprehensive Income

[0000833444-15-000091:notes:412]
Accumulated Other Comprehensive Loss


## us-gaap:SubsequentEventsTextBlock

[0000833444-15-000091:notes:413]
Subsequent Events

[0000833444-15-000091:notes:414]
On September 14, 2015, the Company and TIFSA announced the redemption of all of the outstanding $242 million aggregate principal amount of 7.0% notes due 2019 and $462 million aggregate principal amount of 6.875% notes due 2021. On October 14, 2015, TIFSA paid cash of $876 million to complete the redemption. As a result, the Company expects to record a charge of $168 million to Other expense, net during the first quarter of fiscal 2016 as a loss on extinguishment of debt. The charge is comprised of the make-whole premium and write-off of unamortized premium and debt issuance costs related to the extinguished notes.

[0000833444-15-000091:notes:415]
On October 15, 2015, the Company repaid at maturity $258 million aggregate principal amount of 3.375% notes due 2015, which matured on such date.

[0000833444-15-000091:notes:416]
On October 12, 2015, the Company made its annual equity compensation grant, and granted Tyco employees 2.6 million share options with a weighted-average grant-date fair value of $7.18 per share at the date of grant. Additionally, the Company granted 0.5 million and 0.6 million restricted stock units and performance share units with a weighted-average grant-date fair value of $36.08 and $37.16 per share on the date of grant, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000833444-15-000091:notes:417]
Supplementary Consolidated Balance Sheet Information
