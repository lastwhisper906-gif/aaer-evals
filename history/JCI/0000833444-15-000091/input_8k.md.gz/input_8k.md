# JCI 8-K — 0000833444-15-000088 filed 2015-11-13

## item codes, every 8-K on or before 2015-11-13

- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2015-11-13

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-15-000088:8k_2_02:1]
EX-99.1
2
exhibit991-q415.htm
EXHIBIT 99.1

[0000833444-15-000088:8k_2_02:2]
Exhibit

[0000833444-15-000088:8k_2_02:3]
| Investor Contacts: |  | Media Contact: |  |
| Antonella Franzen |  | Stephen Wasdick |  |
| +1-609-720-4665 |  | +1-609-806-2262 |  |
| afranzen@tyco.com |  | swasdick@tyco.com |  |
| Ryan Edelman |  |  |  |
| +1-609-720-4545 |  |  |  |
| redelman@tyco.com |  |  |  |

[0000833444-15-000088:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-15-000088:8k_2_02:5]
TYCO REPORTS FOURTH QUARTER 2015 EARNINGS FROM CONTINUING OPERATIONS

[0000833444-15-000088:8k_2_02:6]
BEFORE SPECIAL ITEMS OF $0.61 PER SHARE AND U.S. GAAP EARNINGS OF $0.19 PER SHARE

[0000833444-15-000088:8k_2_02:7]
| • | Segment operating margin before special items expands 150 basis points for the quarter to 15.7% and increases 50 basis points for the year to 14.4% |

[0000833444-15-000088:8k_2_02:8]
| • | Diluted earnings per share (EPS) from continuing operations before special items increases 9% for the quarter and 12% for the year |

[0000833444-15-000088:8k_2_02:9]
| • | Fiscal 2016 EPS before special items will now include restructuring and repositioning charges. Full-year guidance of $2.05 - $2.20 includes an estimated $0.14 - $0.19 per share, or $75 million to $100 million, of restructuring and repositioning charges. Including all restructuring and repositioning charges, full-year 2015 EPS before special items was $1.74, which reflects $0.49 per share, or $289 million, of restructuring and repositioning charges. |

[0000833444-15-000088:8k_2_02:10]
| • | First quarter fiscal 2016 EPS before special items guidance of approximately $0.40 includes an estimated $0.04 per share, or $20 million, of restructuring and repositioning charges. This compares to $0.38 per share in the prior year quarter, adjusted to include $0.11 per share, or $75 million, of restructuring and repositioning charges. |

[0000833444-15-000088:8k_2_02:11]
(Income and EPS amounts are attributable to Tyco ordinary shareholders)

[0000833444-15-000088:8k_2_02:12]
($ millions, except per-share amounts)

[0000833444-15-000088:8k_2_02:13]
(All prior periods have been recast to reflect certain businesses as discontinued operations)

[0000833444-15-000088:8k_2_02:14]
|  |  | Q4 2015 |  | Q4 2014 |  | % Change |  | FY 15 |  | FY 14 |  | % Change |
| Revenue |  | $ | 2,505 |  |  | $ | 2,703 |  |  | (7 | )% |  | $ | 9,902 |  |  | $ | 10,332 |  |  | (4 | )% |
| Segment Operating Income |  | $ | 303 |  |  | $ | 348 |  |  | (13 | )% |  | $ | 1,190 |  |  | $ | 1,320 |  |  | (10 | )% |
| Operating Income (Loss) |  | $ | 211 |  |  | $ | (199 | ) |  | 206 | % |  | $ | 884 |  |  | $ | 700 |  |  | 26 | % |
| Income (Loss) from Continuing Operations |  | $ | 82 |  |  | $ | (75 | ) |  | 209 | % |  | $ | 617 |  |  | $ | 797 |  |  | (23 | )% |
| Diluted EPS from Continuing Operations |  | $ | 0.19 |  |  | $ | (0.17 | ) |  | 212 | % |  | $ | 1.44 |  |  | $ | 1.72 |  |  | (16 | )% |
| Special Items |  | $ | (0.42 | ) |  | $ | (0.73 | ) |  |  |  | $ | (0.80 | ) |  | $ | (0.28 | ) |  |  |  |
| Segment Operating Income Before Special Items |  | $ | 394 |  |  | $ | 384 |  |  | 3 | % |  | $ | 1,421 |  |  | $ | 1,438 |  |  | (1 | )% |
| Income from Continuing Ops Before Special Items |  | $ | 260 |  |  | $ | 253 |  |  | 3 | % |  | $ | 955 |  |  | $ | 925 |  |  | 3 | % |
| Diluted EPS from Continuing Ops Before Special Items |  | $ | 0.61 |  |  | $ | 0.56 |  |  | 9 | % |  | $ | 2.24 |  |  | $ | 2.00 |  |  | 12 | % |

[0000833444-15-000088:8k_2_02:15]
CORK, Ireland, Nov. 13, 2015 - Tyco (NYSE: TYC) today reported $0.19 in U.S. GAAP diluted earnings per share (EPS) from continuing operations for the fiscal fourth quarter of 2015 and diluted EPS from continuing operations before special items of $0.61.  Revenue of $2.5 billion in the quarter decreased 7% versus the prior year, primarily due to a 7% negative impact of the stronger U.S. dollar against foreign currencies.  Organic revenue declined 1% in the quarter.  Acquisitions contributed 2 percentage points of growth, which was partially offset by the impact of divestitures.

[0000833444-15-000088:8k_2_02:16]
For the full year, the company reported U.S. GAAP diluted EPS from continuing operations of $1.44 and diluted EPS from continuing operations before special items of $2.24.  Revenue of $9.9 billion decreased 4%.  Organic revenue growth for the year of 1% and acquisitions growth of 2% were more than offset by a 6% negative impact related to changes in foreign currency exchange rates and a 1% impact related to divestitures.

[0000833444-15-000088:8k_2_02:17]
"We delivered solid operational results this year with strong performance in the fourth quarter, exhibiting effective execution on our productivity initiatives and cost actions amid a challenging macroeconomic environment," said Tyco Chief Executive Officer George R. Oliver.  "The quarter's margin expansion reflects our progress with our transformation to an operating company.  Despite slower growth in the  industrial and energy-related end markets, we continue to see pockets of strength across the globe, led by U.S. non-residential construction markets.  We anticipate these market conditions to continue in fiscal 2016.

[0000833444-15-000088:8k_2_02:18]
"We continue to make investments to grow our business, both organically and through acquisitions, and deliver long-term value to shareholders.  In fiscal 2015, we increased our investments in R&D and sales and marketing and completed about $575 million in acquisitions that we expect will contribute approximately $300 million to revenue on an annualized basis.  We also repurchased over $400 million in shares during the year.  As we enter the next phase of our transformation, we are well positioned to leverage our installed base and technology expertise to develop new solutions for customers and drive top-line growth,” Mr. Oliver added.

[0000833444-15-000088:8k_2_02:19]
Organic revenue, free cash flow, adjusted free cash flow, operating income, segment operating income, and diluted EPS from continuing operations before special items are non-GAAP financial measures and are described below.  For a reconciliation of these non-GAAP measures, see the attached tables. Additional schedules as well as fourth quarter review slides can be found in the Investor Relations section of Tyco’s website at http://investors.tyco.com.

[0000833444-15-000088:8k_2_02:20]
SEGMENT RESULTS

[0000833444-15-000088:8k_2_02:21]
The financial results presented in the tables below are in accordance with U.S. GAAP unless otherwise indicated. All dollar amounts are pre-tax and stated in millions.  Certain businesses have been classified as discontinued operations.  The revenue and operating income results shown below have been adjusted to reflect these changes in all periods presented.  All comparisons are to the fiscal 2014 fourth quarter or full year unless otherwise indicated.

[0000833444-15-000088:8k_2_02:22]
During the fourth quarter of fiscal 2015, the company changed the names of its North America Installation & Services and Rest of World Installation & Services segments to North America Integrated Solutions & Services and Rest of World Integrated Solutions & Services, respectively, to better reflect the company's focus on providing technology-enabled solutions that are tailored to customers' needs.  No changes were made to the current segment structure or underlying financial data that comprise each segment as a result of the name changes, and there was no impact to previously disclosed segment information.

[0000833444-15-000088:8k_2_02:23]
North America Integrated Solutions & Services

[0000833444-15-000088:8k_2_02:24]
|  |  | Q4 2015 |  | Q4 2014 |  | % Change |  | FY 15 |  | FY 14 |  | % Change |
| Revenue |  | $ | 1,012 |  |  | $ | 1,012 |  |  | — | % |  | $ | 3,879 |  |  | $ | 3,876 |  |  | — | % |
| Operating Income |  | $ | 158 |  |  | $ | 117 |  |  | 35 | % |  | $ | 542 |  |  | $ | 450 |  |  | 20 | % |
| Operating Margin |  | 15.6 | % |  | 11.6 | % |  |  |  | 14.0 | % |  | 11.6 | % |  |  |  |
| Special Items |  | $ | (22 | ) |  | $ | (17 | ) |  |  |  | $ | (51 | ) |  | $ | (64 | ) |  |  |  |
| Operating Income Before Special Items |  | $ | 180 |  |  | $ | 134 |  |  | 34 | % |  | $ | 593 |  |  | $ | 514 |  |  | 15 | % |
| Operating Margin Before Special Items |  | 17.8 | % |  | 13.2 | % |  |  |  | 15.3 | % |  | 13.3 | % |  |  |  |

[0000833444-15-000088:8k_2_02:25]
Revenue of $1.0 billion was consistent with the prior year, as organic growth was offset by the weakening of the Canadian dollar.  Organic revenue growth of 2% was driven by 3% growth in service revenue and 1% growth in integrated solutions.  Backlog of $2.5 billion increased 2% year over year and, in line with normal seasonality, decreased 1% on a quarter sequential basis, excluding the impact of foreign currency.

[0000833444-15-000088:8k_2_02:26]
Operating income for the quarter was $158 million and the operating margin was 15.6%.  Special items of $22 million consisted primarily of restructuring and repositioning charges.  Before special items, operating income was $180 million and the operating margin improved 460 basis points to 17.8%.  The prior year included a $10 million legal charge, which resulted in a 100 basis point tailwind to the year-over-year margin expansion.  The current year benefited from discrete items, which favorably impacted the operating margin by 120 basis points.  Underlying margin expansion of 240 basis points resulted from increased revenue, improved execution and the benefit of restructuring and productivity initiatives.

[0000833444-15-000088:8k_2_02:27]
Revenue for the full year of $3.9 billion was flat with the prior year as 1% organic growth was fully offset by the weakening of the Canadian dollar.  Operating income was $542 million and included $51 million of special charges.  Before special items, operating income was $593 million and the operating margin improved 200 basis points to 15.3%.

[0000833444-15-000088:8k_2_02:28]
Rest of World Integrated Solutions & Services

[0000833444-15-000088:8k_2_02:29]
|  |  | Q4 2015 |  | Q4 2014 |  | % Change |  | FY 15 |  | FY 14 |  | % Change |
| Revenue |  | $ | 827 |  |  | $ | 1,010 |  |  | (18 | )% |  | $ | 3,432 |  |  | $ | 3,912 |  |  | (12 | )% |
| Operating Income |  | $ | 56 |  |  | $ | 102 |  |  | (45 | )% |  | $ | 243 |  |  | $ | 412 |  |  | (41 | )% |
| Operating Margin |  | 6.8 | % |  | 10.1 | % |  |  |  | 7.1 | % |  | 10.5 | % |  |  |  |
| Special Items |  | $ | (34 | ) |  | $ | (17 | ) |  |  |  | $ | (121 | ) |  | $ | (42 | ) |  |  |  |
| Operating Income Before Special Items |  | $ | 90 |  |  | $ | 119 |  |  | (24 | )% |  | $ | 364 |  |  | $ | 454 |  |  | (20 | )% |
| Operating Margin Before Special Items |  | 10.9 | % |  | 11.8 | % |  |  |  | 10.6 | % |  | 11.6 | % |  |  |  |

[0000833444-15-000088:8k_2_02:30]
Revenue of $827 million decreased 18% compared to the prior year, driven by a 13% unfavorable impact from foreign currency exchange rates.  Organic revenue declined 3%, reflecting a 7% decrease in integrated solutions, while service was consistent with the prior year.  Additionally, revenue from acquisitions contributed 2%, which was more than offset by a decline related to a divestiture.  Backlog of $1.9 billion increased 4% year over year and increased 2% on a quarter sequential basis, excluding the impact of foreign currency and the divestiture.

[0000833444-15-000088:8k_2_02:31]
Operating income for the quarter was $56 million and the operating margin was 6.8%.  Special items of $34 million consisted primarily of restructuring and repositioning charges.  Before special items, operating income was $90 million and the operating margin was 10.9%.  The operating margin declined 90 basis points year over year, as the benefit of restructuring and productivity initiatives was more than offset by the revenue decline and the contributing mix of geographies.

[0000833444-15-000088:8k_2_02:32]
Revenue for the full year of $3.4 billion declined 12% compared to the prior year, driven by an 11% unfavorable impact from foreign currency exchange rates.  A 2% benefit from acquisitions was more than offset by a 1% organic revenue decline and a 2% decline related to divestitures.  Operating income was $243 million and included $121 million of special charges.  Before special items, operating income was $364 million and the operating margin was 10.6%.

[0000833444-15-000088:8k_2_02:33]
Global Products

[0000833444-15-000088:8k_2_02:34]
|  |  | Q4 2015 |  | Q4 2014 |  | % Change |  | FY 15 |  | FY 14 |  | % Change |
| Revenue |  | $ | 666 |  |  | $ | 681 |  |  | (2 | )% |  | $ | 2,591 |  |  | $ | 2,544 |  |  | 2 | % |
| Operating Income |  | $ | 89 |  |  | $ | 129 |  |  | (31 | )% |  | $ | 405 |  |  | $ | 458 |  |  | (12 | )% |
| Operating Margin |  | 13.4 | % |  | 18.9 | % |  |  |  | 15.6 | % |  | 18.0 | % |  |  |  |
| Special Items |  | $ | (35 | ) |  | $ | (2 | ) |  |  |  | $ | (59 | ) |  | $ | (12 | ) |  |  |  |
| Operating Income Before Special Items |  | $ | 124 |  |  | $ | 131 |  |  | (5 | )% |  | $ | 464 |  |  | $ | 470 |  |  | (1 | )% |
| Operating Margin Before Special Items |  | 18.6 | % |  | 19.2 | % |  |  |  | 17.9 | % |  | 18.5 | % |  |  |  |

[0000833444-15-000088:8k_2_02:35]
Revenue of $666 million decreased 2% in the quarter, with a 2% decline in organic revenue.  Acquisitions contributed 7 percentage points of growth, which was fully offset by the unfavorable impact of changes in foreign currency exchange rates.

[0000833444-15-000088:8k_2_02:36]
Operating income for the quarter was $89 million and the operating margin was 13.4%.  Special items of $35 million consisted primarily of restructuring and repositioning charges as well as a loss on a divestiture.  Before special items, operating income was $124 million and the operating margin declined 60 basis points to 18.6%.  Productivity benefits were more than offset by an 80 basis point impact related to non-cash purchase accounting, as well as volume deleverage and mix.

[0000833444-15-000088:8k_2_02:37]
Revenue for the full year of $2.6 billion increased 2% compared to the prior year, including a 6% unfavorable impact from foreign currency exchange rates.  Organic revenue grew 3% and acquisitions contributed an additional 5% to revenue growth.  Operating income was $405 million and included $59 million of special charges.  Before special items, operating income was $464 million and the operating margin was 17.9%.

[0000833444-15-000088:8k_2_02:38]
OTHER ITEMS

[0000833444-15-000088:8k_2_02:39]
| • | For the quarter, cash from operating activities was $31 million and free cash was an outflow of $38 million, which included cash outflows of $377 million, primarily related to funding the Yarway asbestos trust and restructuring and repositioning. Adjusted free cash flow was $339 million for the quarter. For the full year, cash from operating activities was $542 million and free cash flow was $258 million, which included cash outflows of $503 million, primarily related to funding the Yarway asbestos trust and restructuring and repositioning. Adjusted free cash flow was $761 million for the year. |

[0000833444-15-000088:8k_2_02:40]
| • | Corporate expense was $45 million for the quarter and $201 million for the year, both before special items. On a GAAP basis, corporate expense was $92 million for the quarter and $306 million for the year. |

[0000833444-15-000088:8k_2_02:41]
| • | The tax rate before special items was 17.4% for the quarter and 16.0% for the year. |

[0000833444-15-000088:8k_2_02:42]
| • | During the quarter, the company issued long-term debt consisting of $750 million of 10-year notes with a 3.9% coupon and $750 million of 30-year notes with a 5.125% coupon to refinance higher-coupon, shorter-maturity debt and to pay make-whole premiums related to early redemption. The company redeemed its 8.5% notes due in 2019 during the quarter, resulting in a loss from retirement of debt of $81 million. After the quarter's close, the company redeemed its 7.0% notes due in 2019 and 6.875% notes due in 2021, which is expected to result in a loss from retirement of debt of $168 million in the first quarter of fiscal 2016. The company also repaid $258 million in public notes that matured in October. The company now has long-term debt outstanding of $2.2 billion at a weighted average interest rate of 3.7%, with no significant debt maturity until 2025. |

[0000833444-15-000088:8k_2_02:43]
| • | The company increased the commitments under its revolving credit facility to $1.5 billion from $1.0 billion and extended the facility's term five years through 2020. |

[0000833444-15-000088:8k_2_02:44]
| • | As previously announced, during the quarter the company completed the acquisition of FootFall, a global retail intelligence leader, for approximately $60 million in cash. On an annualized basis, this business is expected to contribute approximately $40 million in revenue. |

[0000833444-15-000088:8k_2_02:45]
| • | The company plans to divest a piping components business within its Global Products segment. In fiscal 2015, this business contributed approximately $45 million in revenue. |

[0000833444-15-000088:8k_2_02:46]
ABOUT TYCO

[0000833444-15-000088:8k_2_02:47]
Tyco (NYSE: TYC) is the world’s largest pure-play fire protection and security company. Tyco provides more than three million customers around the globe with the latest fire protection and security products and services. Tyco has over 57,000 employees in more than 900 locations across 50 countries serving various end markets, including commercial, institutional, governmental, retail, industrial, energy, residential and small business. For more information, visit www.tyco.com.

[0000833444-15-000088:8k_2_02:48]
CONFERENCE CALL AND WEBCAST

[0000833444-15-000088:8k_2_02:49]
Management will discuss the company’s fourth quarter results for 2015 during a conference call and webcast today beginning at 8:00 a.m. Eastern time (ET).  Today’s conference call for investors can be accessed in the following ways:

[0000833444-15-000088:8k_2_02:50]
| • | Live via webcast - through the Investor Relations section of Tyco’s website at http://investors.tyco.com, |

[0000833444-15-000088:8k_2_02:51]
| • | Live via telephone (for “listen-only” participants and those who would like to ask a question) - by dialing 800-857-9797 (in the United States) or 517-308-9029 (outside the United States), passcode “Tyco”, |

[0000833444-15-000088:8k_2_02:52]
| • | Replay via telephone - by dialing 888-325-4186 (in the United States) or 402-998-1251 (outside the United States), passcode 4999, from 10:00 a.m. (ET) on November 13, 2015, until 11:59 p.m. (ET) on November 20, 2015, and |

[0000833444-15-000088:8k_2_02:53]
| • | Replay via webcast - through the “Presentations & Webcasts” link on the Investor Relations section of Tyco’s website: http://investors.tyco.com. |

[0000833444-15-000088:8k_2_02:54]
NON-GAAP MEASURES

[0000833444-15-000088:8k_2_02:55]
Organic revenue, free cash flow (outflow) (FCF), and income from continuing operations, earnings per share (EPS) from continuing operations, operating income and segment operating income, in each case “before special items,” are non-GAAP measures and should not be considered replacements for GAAP results.

[0000833444-15-000088:8k_2_02:56]
Organic revenue is a useful measure used by the company to measure the underlying results and trends in the business. The difference between reported net revenue (the most comparable GAAP measure) and organic revenue (the non-GAAP measure) consists of the impact from foreign currency, acquisitions and divestitures, and other changes that either do not reflect the underlying results and trends of the Company’s businesses or are not completely under management’s control. There are limitations associated with organic revenue, such as the fact that, as presented herein, the metric may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using organic revenue in combination with the GAAP numbers. Organic revenue may be used as a component in the company’s incentive compensation plans.

[0000833444-15-000088:8k_2_02:57]
FCF is a useful measure of the company's cash that permits management and investors to gain insight into the number that management employs to measure cash that is free from any significant existing obligation and is available to service debt and make investments. The difference between Cash Flows from Operating Activities (the most comparable GAAP measure) and FCF (the non-GAAP measure) consists mainly of significant cash flows that the company believes are useful to identify. It, or a measure that is based on it, may be used as a component in the company's incentive compensation plans. The difference reflects the impact from:

[0000833444-15-000088:8k_2_02:58]
| • | net capital expenditures, |

[0000833444-15-000088:8k_2_02:59]
| • | dealer generated accounts and bulk accounts purchased, |

[0000833444-15-000088:8k_2_02:60]
| • | cash paid for purchase accounting and holdback liabilities, and |

[0000833444-15-000088:8k_2_02:61]
| • | voluntary pension contributions. |

[0000833444-15-000088:8k_2_02:62]
Capital expenditures and dealer generated and bulk accounts purchased are subtracted because they represent long-term investments that are required for normal business activities. Cash paid for purchase accounting and holdback liabilities is subtracted because these cash outflows are not available for general corporate uses. Voluntary pension contributions are added because this activity is driven by economic financing decisions rather than operating activity. In addition, the company presents adjusted free cash flow, which is free cash flow, adjusted to exclude the cash impact of the special items highlighted below. This number provides information to investors regarding the cash impact of certain items management believes are useful to identify, as described below.

[0000833444-15-000088:8k_2_02:63]
The limitation associated with using these cash flow metrics is that they adjust for cash items that are ultimately within management's and the Board of Directors' discretion to direct and therefore may imply that there is less or more cash that is available for the company's programs than the most comparable GAAP measure. Furthermore, these non-GAAP metrics may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using FCF in combination with the GAAP cash flow numbers.

[0000833444-15-000088:8k_2_02:64]
The company has presented its income and EPS from continuing operations, operating income and segment operating income before special items. Special items include charges and gains related to divestitures, acquisitions, restructurings, impairments, certain changes to accounting methodologies, legacy legal and tax charges and other income or charges that may mask the underlying operating results and/or business trends of the company or business segment, as applicable. The company utilizes these measures to assess overall operating performance and segment level core operating performance, as well as to provide insight to management in evaluating overall and segment operating plan execution and underlying market conditions. The Company also presents its effective tax rate as adjusted for special items for consistency, and presents corporate expense excluding special items. One or more of these measures may be used as components in the company's incentive compensation plans. These measures are useful for investors because they may permit more meaningful comparisons of the company's underlying operating results and business trends between periods. The difference between income and EPS from continuing operations before special items and income and EPS from continuing operations (the most comparable GAAP measures) consists of the impact of the special items noted

[0000833444-15-000088:8k_2_02:65]
above on the applicable GAAP measure. The limitation of these measures is that they exclude the impact (which may be material) of items that increase or decrease the company's reported GAAP metrics, and these non-GAAP metrics may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using the non-GAAP measures in combination with the most comparable GAAP measures in order to better understand the amounts, character and impact of any increase or decrease on reported results.

[0000833444-15-000088:8k_2_02:66]
The company provides general corporate services to its segments and those costs are reported in the "Corporate and Other" segment. This segment's operating income (loss) is presented as "Corporate Expense." Segment Operating Income represents Tyco’s operating income excluding the Corporate and Other segment, and reflects the results of Tyco’s three operating segments. Segment Operating Income before special items reflects GAAP operating income adjusted for the special items noted in the paragraph above.

[0000833444-15-000088:8k_2_02:67]
FORWARD-LOOKING STATEMENTS

[0000833444-15-000088:8k_2_02:68]
# # #

[0000833444-15-000088:8k_2_02:69]
TYCO INTERNATIONAL PLC

[0000833444-15-000088:8k_2_02:70]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0000833444-15-000088:8k_2_02:71]
(in millions, except per share data)

[0000833444-15-000088:8k_2_02:72]
(Unaudited)

[0000833444-15-000088:8k_2_02:73]
|  | Quarters Ended |  | Twelve Months Ended |
|  | September 25, 2015 |  | September 26, 2014 |  | September 25, 2015 |  | September 26, 2014 |
| Revenue from product sales | $ | 1,508 |  |  | $ | 1,668 |  |  | $ | 5,965 |  |  | $ | 6,218 |  |
| Service revenue | 997 |  |  | 1,035 |  |  | 3,937 |  |  | 4,114 |  |
| Net revenue | 2,505 |  |  | 2,703 |  |  | 9,902 |  |  | 10,332 |  |
| Cost of product sales | 1,026 |  |  | 1,145 |  |  | 4,072 |  |  | 4,250 |  |
| Cost of services | 553 |  |  | 576 |  |  | 2,198 |  |  | 2,297 |  |
| Selling, general and administrative expenses | 648 |  |  | 1,161 |  |  | 2,573 |  |  | 3,037 |  |
| Separation costs | — |  |  | — |  |  | — |  |  | 1 |  |
| Restructuring and asset impairment charges, net | 67 |  |  | 20 |  |  | 175 |  |  | 47 |  |
| Operating income (loss) | 211 |  |  | (199 | ) |  | 884 |  |  | 700 |  |
| Interest income | 4 |  |  | 4 |  |  | 15 |  |  | 14 |  |
| Interest expense | (27 | ) |  | (24 | ) |  | (102 | ) |  | (97 | ) |
| Other (expense) income, net | (91 | ) |  | 1 |  |  | (82 | ) |  | (1 | ) |
| Income (loss) from continuing operations before income taxes | 97 |  |  | (218 | ) |  | 715 |  |  | 616 |  |
| Income tax (expense) benefit | (14 | ) |  | 140 |  |  | (100 | ) |  | (24 | ) |
| Equity income in earnings of unconsolidated subsidiaries | — |  |  | — |  |  | — |  |  | 206 |  |
| Income (loss) from continuing operations | 83 |  |  | (78 | ) |  | 615 |  |  | 798 |  |
| (Loss) income from discontinued operations, net of income taxes | (16 | ) |  | (14 | ) |  | (66 | ) |  | 1,041 |  |
| Net income (loss) | 67 |  |  | (92 | ) |  | 549 |  |  | 1,839 |  |
| Less: noncontrolling interest in subsidiaries net income (loss) | 1 |  |  | (3 | ) |  | (2 | ) |  | 1 |  |
| Net income (loss) attributable to Tyco common shareholders | $ | 66 |  |  | $ | (89 | ) |  | $ | 551 |  |  | $ | 1,838 |  |
| Amounts attributable to Tyco common shareholders: |  |  |  |  |  |  |  |  |  |
| Income (loss) from continuing operations | $ | 82 |  |  | $ | (75 | ) |  | $ | 617 |  |  | $ | 797 |  |
| (Loss) income from discontinued operations | (16 | ) |  | (14 | ) |  | (66 | ) |  | 1,041 |  |
| Net income (loss) attributable to Tyco common shareholders | $ | 66 |  |  | $ | (89 | ) |  | $ | 551 |  |  | $ | 1,838 |  |
| Basic earnings per share attributable to Tyco common shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) from continuing operations | $ | 0.19 |  |  | $ | (0.17 | ) |  | $ | 1.47 |  |  | $ | 1.75 |  |
| (Loss) income from discontinued operations | (0.03 | ) |  | (0.03 | ) |  | (0.16 | ) |  | 2.29 |  |
| Net income (loss) attributable to Tyco common shareholders | $ | 0.16 |  |  | $ | (0.20 | ) |  | $ | 1.31 |  |  | $ | 4.04 |  |
| Diluted earnings per share attributable to Tyco common shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income (loss) from continuing operations | $ | 0.19 |  |  | $ | (0.17 | ) |  | $ | 1.44 |  |  | $ | 1.72 |  |
| (Loss) income from discontinued operations | (0.04 | ) |  | (0.03 | ) |  | (0.15 | ) |  | 2.25 |  |
| Net income (loss) attributable to Tyco common shareholders | $ | 0.15 |  |  | $ | (0.20 | ) |  | $ | 1.29 |  |  | $ | 3.97 |  |
| Weighted average number of shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |
| Basic | 422 |  |  | 438 |  |  | 421 |  |  | 455 |  |
| Diluted | 427 |  |  | 438 |  |  | 427 |  |  | 463 |  |

[0000833444-15-000088:8k_2_02:74]
Note: These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K filed on November 14, 2014 for the fiscal year ended September 26, 2014 and Quarterly Report on Form 10-Q filed on July 31, 2015 for the quarter ended June 26, 2015.

[0000833444-15-000088:8k_2_02:75]
TYCO INTERNATIONAL PLC

[0000833444-15-000088:8k_2_02:76]
RESULTS OF SEGMENTS

[0000833444-15-000088:8k_2_02:77]
(in millions)

[0000833444-15-000088:8k_2_02:78]
(Unaudited)

[0000833444-15-000088:8k_2_02:79]
|  |  | Quarters Ended |  |  |  | Twelve Months Ended |  |  |
|  |  | September 25, 2015 |  |  |  | September 26, 2014 |  |  |  | September 25, 2015 |  |  |  | September 26, 2014 |  |  |
| Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| NA Integrated Solutions & Services |  | $ | 1,012 |  |  |  |  |  | $ | 1,012 |  |  |  |  |  | $ | 3,879 |  |  |  |  |  | $ | 3,876 |  |  |  |  |
| ROW Integrated Solutions & Services |  | 827 |  |  |  |  |  | 1,010 |  |  |  |  |  | 3,432 |  |  |  |  |  | 3,912 |  |  |  |  |
| Global Products |  | 666 |  |  |  |  |  | 681 |  |  |  |  |  | 2,591 |  |  |  |  |  | 2,544 |  |  |  |  |
| Total Net Revenue |  | $ | 2,505 |  |  |  |  |  | $ | 2,703 |  |  |  |  |  | $ | 9,902 |  |  |  |  |  | $ | 10,332 |  |  |  |  |
| Operating Income and Margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| NA Integrated Solutions & Services |  | $ | 158 |  |  | 15.6 | % |  | $ | 117 |  |  | 11.6 | % |  | $ | 542 |  |  | 14.0 | % |  | $ | 450 |  |  | 11.6 | % |
| ROW Integrated Solutions & Services |  | 56 |  |  | 6.8 | % |  | 102 |  |  | 10.1 | % |  | 243 |  |  | 7.1 | % |  | 412 |  |  | 10.5 | % |
| Global Products |  | 89 |  |  | 13.4 | % |  | 129 |  |  | 18.9 | % |  | 405 |  |  | 15.6 | % |  | 458 |  |  | 18.0 | % |
| Corporate and Other |  | (92 | ) |  | N/M |  |  | (547 | ) |  | N/M |  |  | (306 | ) |  | N/M |  |  | (620 | ) |  | N/M |  |
| Operating Income and Margin |  | $ | 211 |  |  | 8.4 | % |  | $ | (199 | ) |  | N/M |  |  | $ | 884 |  |  | 8.9 | % |  | $ | 700 |  |  | 6.8 | % |

[0000833444-15-000088:8k_2_02:80]
TYCO INTERNATIONAL PLC

[0000833444-15-000088:8k_2_02:81]
CONSOLIDATED BALANCE SHEETS

[0000833444-15-000088:8k_2_02:82]
(in millions)

[0000833444-15-000088:8k_2_02:83]
(Unaudited)

[0000833444-15-000088:8k_2_02:84]
|  |  | September 25, 2015 |  | September 26, 2014 |
| Assets |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,401 |  |  | $ | 892 |  |
| Accounts receivable, net |  | 1,775 |  |  | 1,734 |  |
| Inventories |  | 627 |  |  | 625 |  |
| Prepaid expenses and other current assets |  | 776 |  |  | 1,051 |  |
| Deferred income taxes |  | 62 |  |  | 304 |  |
| Assets held for sale |  | 12 |  |  | 180 |  |
| Total Current Assets |  | 4,653 |  |  | 4,786 |  |
| Property, plant and equipment, net |  | 1,189 |  |  | 1,262 |  |
| Goodwill |  | 4,236 |  |  | 4,122 |  |
| Intangible assets, net |  | 871 |  |  | 712 |  |
| Other assets |  | 1,372 |  |  | 927 |  |
| Total Assets |  | $ | 12,321 |  |  | $ | 11,809 |  |
| Liabilities and Equity |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |
| Loans payable and current maturities of long-term debt |  | $ | 987 |  |  | $ | 20 |  |
| Accounts payable |  | 785 |  |  | 825 |  |
| Accrued and other current liabilities |  | 1,686 |  |  | 2,114 |  |
| Deferred revenue |  | 382 |  |  | 400 |  |
| Liabilities held for sale |  | 5 |  |  | 118 |  |
| Total Current Liabilities |  | 3,845 |  |  | 3,477 |  |
| Long-term debt |  | 2,159 |  |  | 1,443 |  |
| Deferred revenue |  | 303 |  |  | 335 |  |
| Other liabilities |  | 1,938 |  |  | 1,871 |  |
| Total Liabilities |  | 8,245 |  |  | 7,126 |  |
| Redeemable noncontrolling interest in businesses held for sale |  | — |  |  | 13 |  |
| Total Tyco shareholders' equity |  | 4,041 |  |  | 4,647 |  |
| Nonredeemable noncontrolling interest |  | 35 |  |  | 23 |  |
| Total Equity |  | 4,076 |  |  | 4,670 |  |
| Total Liabilities, Redeemable Noncontrolling Interest and Equity |  | $ | 12,321 |  |  | $ | 11,809 |  |

[0000833444-15-000088:8k_2_02:85]
Note: These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K filed on November 14, 2014 for the fiscal year ended September 26, 2014 and Quarterly Report on Form 10-Q filed on July 31, 2015 for the quarter ended June 26, 2015.

[0000833444-15-000088:8k_2_02:86]
TYCO INTERNATIONAL PLC

[0000833444-15-000088:8k_2_02:87]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000833444-15-000088:8k_2_02:88]
(in millions)

[0000833444-15-000088:8k_2_02:89]
(Unaudited)

[0000833444-15-000088:8k_2_02:90]
|  |  | For the Quarters Ended |  | For the Twelve Months Ended |
|  |  | September 25, 2015 |  | September 26, 2014 |  | September 25, 2015 |  | September 26, 2014 |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) attributable to Tyco ordinary shareholders |  | $ | 66 |  |  | $ | (89 | ) |  | $ | 551 |  |  | $ | 1,838 |  |
| Noncontrolling interest in subsidiaries net income (loss) |  | 1 |  |  | (3 | ) |  | (2 | ) |  | 1 |  |
| Loss (income) from discontinued operations, net of income taxes |  | 16 |  |  | 14 |  |  | 66 |  |  | (1,041 | ) |
| Income (loss) from continuing operations |  | 83 |  |  | (78 | ) |  | 615 |  |  | 798 |  |
| Adjustments to reconcile income from continuing operations to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  | 85 |  |  | 90 |  |  | 342 |  |  | 358 |  |
| Non-cash compensation expense |  | 15 |  |  | 24 |  |  | 59 |  |  | 72 |  |
| Deferred income taxes |  | 21 |  |  | (191 | ) |  | 20 |  |  | (106 | ) |
| Provision for losses on accounts receivable and inventory |  | 19 |  |  | 13 |  |  | 56 |  |  | 45 |  |
| Loss on the retirement of debt |  | 81 |  |  | — |  |  | 81 |  |  | — |  |
| Non-cash restructuring and asset impairment charges, net |  | 2 |  |  | 2 |  |  | 3 |  |  | 2 |  |
| Legacy legal matters |  | — |  |  | — |  |  | — |  |  | (92 | ) |
| Loss (gain) on divestitures |  | 13 |  |  | — |  |  | 31 |  |  | (2 | ) |
| Loss (gain) on sale of investments |  | 5 |  |  | (1 | ) |  | (10 | ) |  | (215 | ) |
| Other non-cash items |  | 7 |  |  | 5 |  |  | 16 |  |  | 25 |  |
| Changes in assets and liabilities, net of the effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  | (46 | ) |  | (55 | ) |  | (149 | ) |  | (96 | ) |
| Contracts in progress |  | — |  |  | (49 | ) |  | 9 |  |  | (99 | ) |
| Inventories |  | 28 |  |  | — |  |  | (44 | ) |  | (14 | ) |
| Prepaid expenses and other assets |  | 22 |  |  | 31 |  |  | (33 | ) |  | 2 |  |
| Asbestos insurance assets |  | 2 |  |  | (83 | ) |  | 32 |  |  | (93 | ) |
| Accounts payable |  | 57 |  |  | 38 |  |  | (21 | ) |  | 54 |  |
| Accrued and other liabilities |  | 17 |  |  | 23 |  |  | (19 | ) |  | (327 | ) |
| Deferred revenue |  | (26 | ) |  | (11 | ) |  | (32 | ) |  | (23 | ) |
| Gross asbestos liabilities |  | (323 | ) |  | 543 |  |  | (338 | ) |  | 532 |  |
| Income taxes, net |  | (22 | ) |  | 22 |  |  | (18 | ) |  | 28 |  |
| Other |  | (9 | ) |  | (12 | ) |  | (58 | ) |  | (20 | ) |
| Net cash provided by operating activities |  | 31 |  |  | 311 |  |  | 542 |  |  | 829 |  |
| Net cash (used in) provided by discontinued operating activities |  | (2 | ) |  | (19 | ) |  | (3 | ) |  | 83 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |
| Capital expenditures |  | (64 | ) |  | (78 | ) |  | (246 | ) |  | (288 | ) |
| Proceeds from disposal of assets |  | 1 |  |  | 3 |  |  | 5 |  |  | 10 |  |
| Acquisition of businesses, net of cash acquired |  | (59 | ) |  | (2 | ) |  | (583 | ) |  | (65 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases |  | (5 | ) |  | (5 | ) |  | (18 | ) |  | (25 | ) |
| Divestiture of businesses, net of cash divested |  | 5 |  |  | 1 |  |  | 3 |  |  | 1 |  |
| Sales and maturities of investments including restricted investments |  | 5 |  |  | — |  |  | 288 |  |  | 283 |  |
| Purchases of investments, including restricted investments |  | — |  |  | (54 | ) |  | (290 | ) |  | (386 | ) |
| Sale of equity investment |  | — |  |  | — |  |  | — |  |  | 250 |  |
| Decrease (increase) in restricted cash |  | 7 |  |  | 2 |  |  | (20 | ) |  | 3 |  |
| Other |  | — |  |  | (5 | ) |  | (1 | ) |  | (4 | ) |
| Net cash used in investing activities |  | (110 | ) |  | (138 | ) |  | (862 | ) |  | (221 | ) |
| Net cash (used in) provided by discontinued investing activities |  | — |  |  | — |  |  | (37 | ) |  | 1,789 |  |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short-term debt |  | 105 |  |  | — |  |  | 364 |  |  | 830 |  |
| Repayment of short-term debt |  | (105 | ) |  | — |  |  | (364 | ) |  | (831 | ) |
| Proceeds from issuance of long-term debt |  | 1,490 |  |  | — |  |  | 2,059 |  |  | — |  |
| Repayment of long-term debt |  | (445 | ) |  | — |  |  | (445 | ) |  | — |  |
| Proceeds from exercise of share options |  | 22 |  |  | 12 |  |  | 92 |  |  | 91 |  |
| Dividends paid |  | (86 | ) |  | (80 | ) |  | (324 | ) |  | (311 | ) |
| Repurchase of ordinary shares by treasury |  | — |  |  | (1,027 | ) |  | (417 | ) |  | (1,833 | ) |
| Purchase of noncontrolling interest |  | — |  |  | (66 | ) |  | — |  |  | (66 | ) |
| Transfer (to) from discontinued operations |  | (2 | ) |  | (19 | ) |  | (40 | ) |  | 1,872 |  |
| Payment of contingent consideration |  | (1 | ) |  | — |  |  | (24 | ) |  | — |  |
| Other |  | (15 | ) |  | (1 | ) |  | (39 | ) |  | (11 | ) |
| Net cash provided by (used in) financing activities |  | 963 |  |  | (1,181 | ) |  | 862 |  |  | (259 | ) |
| Net cash provided by (used in) discontinued financing activities |  | 2 |  |  | 19 |  |  | 40 |  |  | (1,872 | ) |
| Effect of currency translation on cash |  | (14 | ) |  | (12 | ) |  | (33 | ) |  | (20 | ) |
| Net increase (decrease) in cash and cash equivalents |  | 870 |  |  | (1,020 | ) |  | 509 |  |  | 329 |  |
| Cash and cash equivalents at beginning of period |  | 531 |  |  | 1,912 |  |  | 892 |  |  | 563 |  |
| Cash and cash equivalents at end of period |  | $ | 1,401 |  |  | $ | 892 |  |  | $ | 1,401 |  |  | $ | 892 |  |

[0000833444-15-000088:8k_2_02:91]
| Reconciliation to "Free Cash Flow": |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 31 |  |  | $ | 311 |  |  | $ | 542 |  |  | $ | 829 |  |
| Capital expenditures, net |  | (62 | ) |  | (75 | ) |  | (241 | ) |  | (278 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases |  | (5 | ) |  | (5 | ) |  | (18 | ) |  | (25 | ) |
| Payment of contingent consideration |  | (2 | ) |  | — |  |  | (25 | ) |  | — |  |
| Free Cash Flow |  | $ | (38 | ) |  | $ | 231 |  |  | $ | 258 |  |  | $ | 526 |  |
| Reconciliation to "Adjusted Free Cash Flow": |  |  |  |  |  |  |  |  |
| CIT settlement |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (17 | ) |
| IRS litigation costs |  | 2 |  |  | (1 | ) |  | 2 |  |  | — |  |
| Separation costs |  | — |  |  | 37 |  |  | 3 |  |  | 108 |  |
| Restructuring and repositioning costs |  | 46 |  |  | 25 |  |  | 165 |  |  | 104 |  |
| Environmental remediation payments |  | — |  |  | 3 |  |  | 7 |  |  | 63 |  |
| Legal settlements |  | — |  |  | — |  |  | (16 | ) |  | 6 |  |
| Net asbestos payments |  | 328 |  |  | 5 |  |  | 336 |  |  | 18 |  |
| Tax related separation costs and other tax matters |  | — |  |  | — |  |  | — |  |  | 149 |  |
| Cash payment to ADT Resi/Pentair |  | — |  |  | 9 |  |  | 1 |  |  | 39 |  |
| Acquisition and integration costs |  | 1 |  |  | 3 |  |  | 5 |  |  | 3 |  |
| Special Items |  | $ | 377 |  |  | $ | 81 |  |  | $ | 503 |  |  | $ | 473 |  |
| Adjusted Free Cash Flow |  | $ | 339 |  |  | $ | 312 |  |  | $ | 761 |  |  | $ | 999 |  |

[0000833444-15-000088:8k_2_02:92]
Note: Free cash flow is a non-GAAP measure.  See description of non-GAAP measures contained in this release.

[0000833444-15-000088:8k_2_02:93]
TYCO INTERNATIONAL PLC

[0000833444-15-000088:8k_2_02:94]
ORGANIC GROWTH RECONCILIATION - REVENUE

[0000833444-15-000088:8k_2_02:95]
(in millions)

[0000833444-15-000088:8k_2_02:96]
(Unaudited)

[0000833444-15-000088:8k_2_02:97]
|  |  |  |  | Quarter Ended September 25, 2015 |  |  |  |  |
|  |  |  |  | Base Year |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Net Revenue for the Quarter Ended September 26, 2014 |  | Adjustments |  | Adjusted Fiscal 2014 BaseRevenue |  |  |  |  |  |  |  |  |  |  |  |  |  | Net Revenue for the Quarter Ended September 25, 2015 |
|  |  |  | Divestitures / Other |  |  | Foreign Currency |  | Acquisitions |  | Organic Revenue(1) |  |
| NA Integrated Solutions & Services |  | $ | 1,012 |  |  | $ | — |  |  | — | % |  | $ | 1,012 |  |  | $ | (19 | ) |  | (1.9 | )% |  | $ | 2 |  |  | 0.2 | % |  | $ | 17 |  |  | 1.7 | % |  | $ | 1,012 |  |  | — | % |
| ROW Integrated Solutions & Services |  | 1,010 |  |  | (33 | ) |  | (3.3 | )% |  | 977 |  |  | (133 | ) |  | (13.2 | )% |  | 16 |  |  | 1.6 | % |  | (33 | ) |  | (3.4 | )% |  | 827 |  |  | (18.1 | )% |
| Global Products |  | 681 |  |  | — |  |  | — | % |  | 681 |  |  | (49 | ) |  | (7.2 | )% |  | 48 |  |  | 7.0 | % |  | (14 | ) |  | (2.1 | )% |  | 666 |  |  | (2.2 | )% |
| Total Net Revenue |  | $ | 2,703 |  |  | $ | (33 | ) |  | (1.2 | )% |  | $ | 2,670 |  |  | $ | (201 | ) |  | (7.4 | )% |  | $ | 66 |  |  | 2.4 | % |  | $ | (30 | ) |  | (1.1 | )% |  | $ | 2,505 |  |  | (7.3 | )% |

[0000833444-15-000088:8k_2_02:98]
|  | (1) Organic revenue growth percentage based on adjusted fiscal 2014 base revenue. |

[0000833444-15-000088:8k_2_02:99]
|  |  |  |  | Twelve Months Ended September 25, 2015 |  |  |  |  |
|  |  |  |  | Base Year |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Net Revenue for the Twelve Months Ended September 26, 2014 |  | Adjustments |  | Adjusted Fiscal 2014 BaseRevenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Net Revenue for the Twelve Months Ended September 25, 2015 |
|  |  |  | Divestitures / Other |  |  | Foreign Currency |  | Acquisitions |  |  | Organic Revenue (1) |  |
| NA Integrated Solutions & Services |  | $ | 3,876 |  |  | $ | — |  |  | — | % |  | $ | 3,876 |  |  | $ | (52 | ) |  | (1.3 | )% |  | $ | 11 |  |  | 0.3 | % |  |  | $ | 44 |  |  | 1.1 | % |  | $ | 3,879 |  |  | 0.1 | % |
| ROW Integrated Solutions & Services |  | 3,912 |  |  | (67 | ) |  | (1.7 | )% |  | 3,845 |  |  | (422 | ) |  | (10.8 | )% |  | 60 |  |  | 1.5 | % |  |  | (51 | ) |  | (1.3 | )% |  | 3,432 |  |  | (12.3 | )% |
| Global Products |  | 2,544 |  |  | — |  |  | — | % |  | 2,544 |  |  | (148 | ) |  | (5.8 | )% |  | 128 |  |  | 5.0 | % |  |  | 67 |  |  | 2.6 | % |  | 2,591 |  |  | 1.8 | % |
| Total Net Revenue |  | $ | 10,332 |  |  | $ | (67 | ) |  | (0.6 | )% |  | $ | 10,265 |  |  | $ | (622 | ) |  | (6.0 | )% |  | $ | 199 |  |  | 1.9 | % |  |  | $ | 60 |  |  | 0.6 | % |  | $ | 9,902 |  |  | (4.2 | )% |

[0000833444-15-000088:8k_2_02:100]
|  | (1) Organic revenue growth percentage based on adjusted fiscal 2014 base revenue. |

[0000833444-15-000088:8k_2_02:101]
Earnings Per Share Summary

[0000833444-15-000088:8k_2_02:102]
(Unaudited)

[0000833444-15-000088:8k_2_02:103]
|  | Quarter Ended |  | Year Ended |  | Quarter Ended |  | Year Ended |
|  | September 25, 2015 |  | September 25, 2015 |  | September 26, 2014 |  | September 26, 2014 |
| Diluted EPS from Continuing Operations Attributable to Tyco Shareholders (GAAP) | $ | 0.19 |  |  | $ | 1.44 |  |  | $ | (0.17 | ) |  | $ | 1.72 |  |
| expense / (benefit) |  |  |  |  |  |  |  |
| Restructuring and repositioning activities | 0.21 |  |  | 0.49 |  |  | 0.05 |  |  | 0.14 |  |
| Separation costs included in SG&A | — |  |  | — |  |  | 0.02 |  |  | 0.08 |  |
| (Gains) / losses on divestitures, net included in SG&A | 0.03 |  |  | 0.08 |  |  | — |  |  | (0.01 | ) |
| Acquisition / integration costs | — |  |  | 0.01 |  |  | — |  |  | — |  |
| Settlement with former management | — |  |  | (0.01 | ) |  | — |  |  | (0.13 | ) |
| Amortization of inventory step-up | — |  |  | 0.01 |  |  | — |  |  | — |  |
| Asbestos | (0.02 | ) |  | 0.02 |  |  | 0.66 |  |  | 0.63 |  |
| CIT settlement | — |  |  | — |  |  | — |  |  | (0.03 | ) |
| Loss on sale of investment | — |  |  | — |  |  | — |  |  | 0.02 |  |
| Tax items | — |  |  | — |  |  | — |  |  | 0.03 |  |
| 2012 Tax Sharing Agreement | — |  |  | — |  |  | — |  |  | 0.01 |  |
| Gain on sale of Atkore divestiture | — |  |  | — |  |  | — |  |  | (0.46 | ) |
| Loss on extinguishment of debt | 0.20 |  |  | 0.20 |  |  | — |  |  | — |  |
| Total Before Special Items | $ | 0.61 |  |  | $ | 2.24 |  |  | $ | 0.56 |  |  | $ | 2.00 |  |

[0000833444-15-000088:8k_2_02:104]
Tyco International plc

[0000833444-15-000088:8k_2_02:105]
For the Quarter Ended September 25, 2015

[0000833444-15-000088:8k_2_02:106]
(in millions, except per share data)

[0000833444-15-000088:8k_2_02:107]
(Unaudited)

[0000833444-15-000088:8k_2_02:108]
expense / (benefit)

[0000833444-15-000088:8k_2_02:109]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Integrated Solutions& Services |  |  |  | ROW Integrated Solutions & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $1,012 |  |  |  |  |  | $827 |  |  |  |  |  | $666 |  |  |  |  |  | $2,505 |  |  |  |  |  | $— |  |  |  |  |  | $2,505 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Integrated Solutions& Services |  | Margin |  | ROW Integrated Solutions & Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other (Expense), net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $158 |  |  | 15.6 | % |  |  | $56 |  |  | 6.8 | % |  |  | $89 |  |  | 13.4 | % |  |  | $303 |  |  | 12.1 | % |  |  | ($92 | ) |  | N/M |  |  | $211 |  |  | 8.4 | % |  |  | ($23 | ) |  |  | ($91 | ) |  |  | ($14 | ) |  |  | $— |  |  |  | ($1 | ) |  |  | $82 |  |  | $0.19 |  |
| Restructuring and repositioning activities |  | 21 |  |  |  |  | 37 |  |  |  |  | 18 |  |  |  |  | 76 |  |  |  |  | 43 |  |  |  |  | 119 |  |  |  |  |  |  |  |  | (29 | ) |  |  |  |  |  | 90 |  | 0.21 |  |
| Restructuring charges in cost of sales and SG&A |  | 1 |  |  |  |  | 1 |  |  |  |  | (1 | ) |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | — |  | — |  |
| (Gains) / losses on divestitures, net included in SG&A |  |  |  |  |  | (4 | ) |  |  |  | 16 |  |  |  |  | 12 |  |  |  |  |  |  |  |  | 12 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 12 |  | 0.03 |  |
| Acquisition / integration costs |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 3 |  |  |  |  | 3 |  |  |  |  |  |  |  |  | (10 | ) |  |  |  |  |  | (7 | ) | (0.02 | ) |
| IRS litigation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | — |  | — |  |
| Amortization of acquired backlog |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Loss on extinguishment of debt |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 81 |  |  |  |  |  |  |  |  | 81 |  | 0.20 |  |
| Total Before Special Items |  |  | $180 |  |  | 17.8 | % |  |  | $90 |  |  | 10.9 | % |  |  | $124 |  |  | 18.6 | % |  |  | $394 |  |  | 15.7 | % |  |  | ($45 | ) |  | N/M |  |  | $349 |  |  | 13.9 | % |  |  | ($23 | ) |  |  | ($10 | ) |  |  | ($55 | ) |  |  | $— |  |  |  | ($1 | ) |  |  | $260 |  |  | $0.61 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 427 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 427 |  |

[0000833444-15-000088:8k_2_02:110]
Tyco International plc

[0000833444-15-000088:8k_2_02:111]
For the Year Ended September 25, 2015

[0000833444-15-000088:8k_2_02:112]
(in millions, except per share data)

[0000833444-15-000088:8k_2_02:113]
(Unaudited)

[0000833444-15-000088:8k_2_02:114]
expense / (benefit)

[0000833444-15-000088:8k_2_02:115]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Integrated Solutions& Services |  |  |  | ROW Integrated Solutions & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $3,879 |  |  |  |  |  | $3,432 |  |  |  |  |  | $2,591 |  |  |  |  |  | $9,902 |  |  |  |  |  | $— |  |  |  |  |  | $9,902 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Integrated Solutions& Services |  | Margin |  | ROW Integrated Solutions& Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other (Expense), net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $542 |  |  | 14.0 | % |  |  | $243 |  |  | 7.1 | % |  |  | $405 |  |  | 15.6 | % |  |  | $1,190 |  |  | 12.0 | % |  |  | ($306 | ) |  | N/M |  |  | $884 |  |  | 8.9 | % |  |  | ($87 | ) |  |  | ($82 | ) |  |  | ($100 | ) |  |  | $— |  |  |  | $2 |  |  |  | $617 |  |  | $1.44 |  |
| Restructuring and repositioning activities |  | 48 |  |  |  |  | 103 |  |  |  |  | 34 |  |  |  |  | 185 |  |  |  |  | 103 |  |  |  |  | 288 |  |  |  |  |  |  |  |  | (78 | ) |  |  |  |  |  | 210 |  | 0.49 |  |
| Restructuring charges in cost of sales and SG&A |  | 1 |  |  |  |  | 1 |  |  |  |  | (1 | ) |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | — |  | — |  |
| Separation costs included in SG&A |  | 2 |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | 1 |  | — |  |
| (Gains) / losses on divestitures, net included in SG&A |  |  |  |  |  | 14 |  |  |  |  | 17 |  |  |  |  | 31 |  |  |  |  |  |  |  |  | 31 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  | 32 |  | 0.08 |  |
| Acquisition / integration costs |  |  |  |  |  | 2 |  |  |  |  | 3 |  |  |  |  | 5 |  |  |  |  |  |  |  |  | 5 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | 4 |  | 0.01 |  |
| Settlement with former management |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (9 | ) |  |  |  | (9 | ) |  |  |  |  |  |  |  | 4 |  |  |  |  |  |  | (5 | ) | (0.01 | ) |
| Legacy legal items |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Amortization of inventory step-up |  |  |  |  |  |  |  |  |  | 4 |  |  |  |  | 4 |  |  |  |  |  |  |  |  | 4 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | 3 |  | 0.01 |  |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 10 |  |  |  |  | 10 |  |  |  |  |  |  |  |  | (3 | ) |  |  |  |  |  | 7 |  | 0.02 |  |
| IRS litigation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | — |  | — |  |
| Amortization of acquired backlog |  |  |  |  |  |  |  |  |  | 2 |  |  |  |  | 2 |  |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  | — |  |
| Loss on extinguishment of debt |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 81 |  |  |  |  |  |  |  |  | 81 |  | 0.20 |  |
| 2012 Tax Sharing Agreement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  |  |  | 2 |  | — |  |
| Total Before Special Items |  |  | $593 |  |  | 15.3 | % |  |  | $364 |  |  | 10.6 | % |  |  | $464 |  |  | 17.9 | % |  |  | $1,421 |  |  | 14.4 | % |  |  | ($201 | ) |  | N/M |  |  | $1,220 |  |  | 12.3 | % |  |  | ($87 | ) |  |  | $1 |  |  |  | ($181 | ) |  |  | $— |  |  |  | $2 |  |  |  | $955 |  |  | $2.24 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 427 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 427 |  |

[0000833444-15-000088:8k_2_02:116]
Tyco International plc

[0000833444-15-000088:8k_2_02:117]
For the Quarter Ended September 26, 2014

[0000833444-15-000088:8k_2_02:118]
(in millions, except per share data)

[0000833444-15-000088:8k_2_02:119]
(Unaudited)

[0000833444-15-000088:8k_2_02:120]
expense / (benefit)

[0000833444-15-000088:8k_2_02:121]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Integrated Solutions& Services |  |  |  | ROW Integrated Solutions & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $1,012 |  |  |  |  |  | $1,010 |  |  |  |  |  | $681 |  |  |  |  |  | $2,703 |  |  |  |  |  | $— |  |  |  |  |  | $2,703 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Integrated Solutions& Services |  | Margin |  | ROW Integrated Solutions & Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other (Expense), net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $117 |  |  | 11.6 | % |  |  | $102 |  |  | 10.1 | % |  |  | $129 |  |  | 18.9 | % |  |  | $348 |  |  | 12.9 | % |  |  | ($547 | ) |  | N/M |  |  | ($199 | ) |  | N/M |  |  |  | ($20 | ) |  |  | $1 |  |  |  | $140 |  |  |  | $— |  |  |  | $3 |  |  |  | ($75 | ) |  | ($0.17 | ) |
| Restructuring and repositioning activities |  | 6 |  |  |  |  | 16 |  |  |  |  | 1 |  |  |  |  | 23 |  |  |  |  | 13 |  |  |  |  | 36 |  |  |  |  |  |  |  |  | (11 | ) |  |  |  |  |  | 25 |  | 0.05 |  |
| Restructuring charges in cost of sales and SG&A |  |  |  |  |  |  |  |  |  | 2 |  |  |  |  | 2 |  |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  | — |  |
| Separation costs included in SG&A |  | 11 |  |  |  |  |  |  |  |  |  |  |  |  | 11 |  |  |  |  |  |  |  |  | 11 |  |  |  |  |  |  |  |  | (3 | ) |  |  |  |  |  | 8 |  | 0.02 |  |
| (Gains) / losses on divestitures, net included in SG&A |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (2 | ) |  |  |  |  |  | (2 | ) | — |  |
| Acquisition / integration costs |  |  |  |  |  | 1 |  |  |  |  | (1 | ) |  |  |  | — |  |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | (1 | ) | — |  |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 467 |  |  |  |  | 467 |  |  |  |  |  |  |  |  | (173 | ) |  |  |  |  |  | 294 |  | 0.66 |  |
| IRS litigation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 4 |  |  |  |  | 4 |  |  |  |  |  |  |  |  | (2 | ) |  |  |  |  |  | 2 |  | — |  |
| Tax items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | (1 | ) | — |  |
| 2012 Tax Sharing Agreement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Total Before Special Items |  |  | $134 |  |  | 13.2 | % |  |  | $119 |  |  | 11.8 | % |  |  | $131 |  |  | 19.2 | % |  |  | $384 |  |  | 14.2 | % |  |  | ($63 | ) |  | N/M |  |  | $321 |  |  | 11.9 | % |  |  | ($20 | ) |  |  | $2 |  |  |  | ($53 | ) |  |  | $— |  |  |  | $3 |  |  |  | $253 |  |  | $0.56 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 438 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 447 |  |

[0000833444-15-000088:8k_2_02:122]
Tyco International plc

[0000833444-15-000088:8k_2_02:123]
For the Year Ended September 26, 2014

[0000833444-15-000088:8k_2_02:124]
(in millions, except per share data)

[0000833444-15-000088:8k_2_02:125]
(Unaudited)

[0000833444-15-000088:8k_2_02:126]
expense / (benefit)

[0000833444-15-000088:8k_2_02:127]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Integrated Solutions& Services |  |  |  | ROW Integrated Solutions & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $3,876 |  |  |  |  |  | $3,912 |  |  |  |  |  | $2,544 |  |  |  |  |  | $10,332 |  |  |  |  |  | $— |  |  |  |  |  | $10,332 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Integrated Solutions& Services |  | Margin |  | ROW Integrated Solutions & Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Margin |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other (Expense), net |  | Income Tax (Expense) |  | Equity in earnings of unconsolidated subsidiaries |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $450 |  |  | 11.6 | % |  |  | $412 |  |  | 10.5 | % |  |  | $458 |  |  | 18.0 | % |  |  | $1,320 |  |  | 12.8 | % |  |  | ($620 | ) |  | N/M |  |  | $700 |  |  | 6.8 | % |  |  | ($83 | ) |  |  | ($1 | ) |  |  | ($24 | ) |  |  | $206 |  |  |  | ($1 | ) |  |  | $797 |  |  | $1.72 |  |
| Restructuring and repositioning activities |  | 13 |  |  |  |  | 31 |  |  |  |  | 10 |  |  |  |  | 54 |  |  |  |  | 37 |  |  |  |  | 91 |  |  |  |  |  |  |  |  | (28 | ) |  |  |  |  |  | 63 |  | 0.14 |  |
| Restructuring charges in cost of sales and SG&A |  |  |  |  |  |  |  |  |  | 2 |  |  |  |  | 2 |  |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  | — |  |
| Separation costs included in SG&A |  | 51 |  |  |  |  |  |  |  |  |  |  |  |  | 51 |  |  |  |  | 1 |  |  |  |  | 52 |  |  |  |  |  |  |  |  | (15 | ) |  |  |  |  |  | 37 |  | 0.08 |  |
| (Gains) / losses on divestitures, net included in SG&A |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  | (3 | ) |  |  |  | (2 | ) |  |  |  |  |  |  |  | (2 | ) |  |  |  |  |  | (4 | ) | (0.01 | ) |
| Acquisition / integration costs |  |  |  |  |  | 3 |  |  |  |  |  |  |  |  | 3 |  |  |  |  |  |  |  |  | 3 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  | 2 |  | — |  |
| Settlement with former management |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (96 | ) |  |  |  | (96 | ) |  |  |  |  |  |  |  | 37 |  |  |  |  |  |  | (59 | ) | (0.13 | ) |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 462 |  |  |  |  | 462 |  |  |  |  |  |  |  |  | (171 | ) |  |  |  |  |  | 291 |  | 0.63 |  |
| IRS litigation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 4 |  |  |  |  | 4 |  |  |  |  |  |  |  |  | (2 | ) |  |  |  |  |  | 2 |  | — |  |
| CIT settlement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (16 | ) |  |  |  | (16 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  | (16 | ) | (0.03 | ) |
| Loss on sale of investment |  |  |  |  |  | 7 |  |  |  |  |  |  |  |  | 7 |  |  |  |  |  |  |  |  | 7 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 7 |  | 0.02 |  |
| Separation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Tax items |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 12 |  |  |  |  |  |  | 12 |  | 0.03 |  |
| 2012 Tax Sharing Agreement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 6 |  |  |  |  |  |  |  |  | 6 |  | 0.01 |  |
| Gain on sale of Atkore divestiture |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (216 | ) |  |  |  | (216 | ) | (0.46 | ) |
| Total Before Special Items |  |  | $514 |  |  | 13.3 | % |  |  | $454 |  |  | 11.6 | % |  |  | $470 |  |  | 18.5 | % |  |  | $1,438 |  |  | 13.9 | % |  |  | ($230 | ) |  | N/M |  |  | $1,208 |  |  | 11.7 | % |  |  | ($83 | ) |  |  | $5 |  |  |  | ($194 | ) |  |  | ($10 | ) |  |  | ($1 | ) |  |  | $925 |  |  | $2.00 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 463 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 463 |  |
