# JCI MD&A — 0000833444-15-000091


## mdna

[0000833444-15-000091:mdna:1]
Item 7.    Management's Discussion and Analysis of Financial Condition and Results of Operations

[0000833444-15-000091:mdna:2]
Results of Operations

[0000833444-15-000091:mdna:3]
Organization

[0000833444-15-000091:mdna:4]
The Consolidated Financial Statements include the consolidated results of Tyco International plc and its subsidiaries (hereinafter collectively referred to as "we", the "Company", "Tyco Ireland" or "Tyco").  The financial statements have been prepared in United States dollars ("USD"), in accordance with GAAP.

[0000833444-15-000091:mdna:5]
During the fourth quarter of fiscal 2015, the Company changed the name of its North America Installation & Services and Rest of World Installation & Services segments to North America Integrated Solutions & Services and Rest of World Integrated Solutions & Services, respectively. The segment reporting structure is consistent with how management reviews the businesses, makes investing and resource decisions and assesses operating performance. The name changes better reflect the Company's focus on providing technology solutions that encompass a mix of products, services and consultation that is tailored to the unique needs of each customer. No changes were made to the current segment structure or underlying financial data that comprise each segment as a result of the name changes and there was no impact to previously disclosed segment information.

[0000833444-15-000091:mdna:6]
We operate and report financial and operating information in the following three segments:

[0000833444-15-000091:mdna:7]
| • | North America Integrated Solutions & Services ("NA Integrated Solutions & Services") designs, sells, installs, services and monitors integrated electronic security systems and integrated fire detection and suppression systems for commercial, industrial, retail, small business, institutional and governmental customers in North America. |

[0000833444-15-000091:mdna:8]
| • | Rest of World Integrated Solutions & Services ("ROW Integrated Solutions & Services") designs, sells, installs, services and monitors integrated electronic security systems and integrated fire detection and suppression systems for commercial, industrial, retail, residential, small business, institutional and governmental customers in the Rest of World ("ROW") regions. |

[0000833444-15-000091:mdna:9]
| • | Global Products designs, manufactures and sells fire protection, security and life safety products, including intrusion security, anti-theft devices, breathing apparatus and access control and video management systems, for commercial, industrial, retail, residential, small business, institutional and governmental customers worldwide, including products installed and serviced by our NA and ROW Integrated Solutions & Services segments. |

[0000833444-15-000091:mdna:10]
We also provide general corporate services to our segments which is reported as a fourth, non-operating segment, Corporate and Other. References to the segment data are to the Company's continuing operations.

[0000833444-15-000091:mdna:11]
Certain prior period amounts have been reclassified to conform with current period presentation. We completed the sale of several ROW Integrated Solutions & Services businesses during the third quarter of fiscal 2015. The assets and liabilities related to these ROW Integrated Solutions & Services businesses were classified as held for sale as of September 26, 2014, and the results of operations of two of these businesses are included in discontinued operations for all periods presented.  The criteria to be presented as a discontinued operation were not satisfied for the third business.

[0000833444-15-000091:mdna:12]
The Company expects to complete the sale of another of its ROW Integrated Solutions & Services businesses during the first half of fiscal 2016.  The assets and liabilities of this business are classified as held for sale and its results of operations are presented as discontinued operations for all periods presented.  See Note 3 to the Consolidated Financial Statements.

[0000833444-15-000091:mdna:13]
Recent Transactions

[0000833444-15-000091:mdna:14]
Following the completion of the 2012 Separation, the Company began the implementation of a planned transition from a holding company structure to a more focused operating company structure. In connection with this transition, the Company has identified and pursued opportunities for cost savings through restructuring activities and workforce reductions to improve operating efficiencies across the Company's businesses. It has also initiated certain global actions designed to reduce its cost structure and improve future profitability by streamlining operations and better aligning functions. These actions are collectively referred to as restructuring and repositioning actions. During the fiscal years ended September 25, 2015, September 26, 2014, and September 27, 2013, the Company recorded restructuring and repositioning charges of $289 million, $93 million, and $131 million, respectively. As the Company has substantially completed many of the actions it expected to take in connection with the transition, it now expects to incur future restructuring and repositioning charges that are significantly less than the amounts recorded in fiscal 2015. Based on its current outlook for end market economic conditions, the Company expects to incur between $75 million and $100 million of restructuring and repositioning charges in fiscal 2016. See Note 4 to the Consolidated Financial Statements.

[0000833444-15-000091:mdna:15]
During fiscal 2014, the Company incurred net charges of approximately $462 million related to the asbestos claims primarily against its Yarway and Grinnell subsidiaries.  With respect to Grinnell, during the second quarter of fiscal 2015, the Company completed a series of restructuring transactions related to the establishment and funding of a structure dedicated to resolving certain historic Grinnell asbestos liabilities. Pursuant to this transaction, a subsidiary of the Company acquired certain assets of Grinnell and transferred cash and other assets totaling approximately $278 million to the structure, and subsidiaries in the structure assumed certain liabilities related to historic Grinnell, Scott and Figgie operations, including all historical Grinnell asbestos liabilities.  With respect to Yarway, in the fourth quarter of fiscal 2015, the Bankruptcy Court overseeing Yarway’s previously disclosed Chapter 11 Bankruptcy proceeding issued an order confirming Yarway’s Chapter 11 plan, and on August 19, 2015, the Chapter 11 plan became effective, at which time a subsidiary of the Company contributed approximately $325 million in cash to the 524(g) trust established for Yarway and the Company and certain other parties received the benefit of a release from Yarway and an injunction under section 524(g) of the Bankruptcy Code permanently enjoining the assertion of Yarway asbestos claims against those parties. As a result of the effectiveness of Chapter 11 plan, ownership of Yarway was transferred to the Yarway trust and it is no longer a consolidated subsidiary of the Company. See Note 12 to the Consolidated Financial Statements for further details on asbestos.

[0000833444-15-000091:mdna:16]
In the second quarter of fiscal 2015, Tyco’s finance subsidiary, Tyco International Finance S.A. (“TIFSA”), issued €500 million aggregate principal amount of 1.375% notes due February 25, 2025 (the "2025 Euro notes"), which are fully and unconditionally guaranteed by the Company and Tyco Fire & Security Finance S.C.A. (“TIFSCA”). TIFSA received total net proceeds of approximately $563 million, which were made available for general corporate purposes. In addition, on September 14, 2015, TIFSA issued $750 million aggregate principal amount of 3.9% notes due on February 14, 2026 (the "2026 notes") and $750 million aggregate principal amount of 5.125% notes due on September 14, 2045 (the "2045 notes"), which are fully and unconditionally guaranteed by the Company and TIFSCA. TIFSA received total net proceeds of approximately $1,477 million. In September and October 2015, all of the net proceeds of the 2026 notes and 2045 notes were used to fund the redemption of the Company's outstanding 8.5% notes due 2019, 7.0% notes due 2019 and 6.875% notes due 2021, which aggregated $1,068 million in principal amount, to make the associated make-whole payments for early redemption of these notes, and to contribute to the repayment of $258 million in principal amount of 3.375% notes that matured in October 2015. As a result of the redemption of the 8.5% notes, which occurred during fiscal 2015, the Company recorded a charge to Other expense, net within the Consolidated Statement of Operations as a loss on extinguishment of debt of $81 million during the fourth quarter of fiscal 2015. The Company will record a charge of $168 million as a loss on extinguishment of debt within the Consolidated Statements of Operations related to the early extinguishment of the 7.0% notes due 2019 and 6.875% notes due 2021 in the first quarter of fiscal 2016. As a result of the issuance of debt and redemptions described above, the Company’s outstanding long-term debt as of October 15, 2015 was $2,159 million with a weighted average annual interest rate of 3.7% compared to $1,443 million with a weighted average annual interest rate of 6.5% as of September 26, 2014. See Note 9 to the Consolidated Financial Statements.

[0000833444-15-000091:mdna:17]
Business Overview

[0000833444-15-000091:mdna:18]
We are a leading global provider of security products and services, fire detection and suppression products and services and life safety products. We utilize our extensive global footprint of approximately 900 locations, including manufacturing facilities, service and distribution centers, monitoring centers and sales offices, to provide solutions and localized expertise to our global customer base. We provide an extensive range of product and service offerings to over 3 million customers in more than 100 countries through multiple channels. Our revenues are broadly diversified across the United States and Canada (collectively “North America”); Central America and South America (collectively “Latin America”); Europe, the Middle East, and Africa (collectively “EMEA”) and the Asia-Pacific geographic areas. The following chart reflects our fiscal 2015 net revenue by geographic area.

[0000833444-15-000091:mdna:19]
33

[0000833444-15-000091:mdna:20]
Fiscal 2015 Net Revenue by Geographic Area

[0000833444-15-000091:mdna:21]
Our end-use customers, to whom we may sell directly or through wholesalers, distributors, commercial builders or contractors, are also broadly diversified and include:

[0000833444-15-000091:mdna:22]
| • | Commercial customers, including residential and commercial property developers, financial institutions, food service businesses and commercial enterprises; |

[0000833444-15-000091:mdna:23]
| • | Industrial customers, including companies in the oil and gas, power generation, mining, petrochemical and other industries; |

[0000833444-15-000091:mdna:24]
| • | Retail and small business customers, including international, regional and local consumer outlets, from national chains to specialty stores; |

[0000833444-15-000091:mdna:25]
| • | Institutional customers, including a broad range of healthcare facilities, academic institutions, museums and foundations; |

[0000833444-15-000091:mdna:26]
| • | Governmental customers, including federal, state and local governments, defense installations, mass transportation networks, public utilities and other government-affiliated entities and applications; and |

[0000833444-15-000091:mdna:27]
| • | Residential customers outside of North America, including owners of single family homes and local providers of a wide range of goods and services. |

[0000833444-15-000091:mdna:28]
As a global business with a varied customer base and an extensive range of products and services, our operations and results are impacted by global, regional and industry specific factors, and by political factors. Our geographic diversity and the diversity in our customer base and our products and services has helped mitigate the impact of any one industry or the economy of any single country on our consolidated operating results, financial condition and cash flows. Due to the global nature of our business and the variety of our customers, products and services, no single factor is predominantly used to forecast Company results. Rather, management monitors a number of factors to develop expectations regarding future results, including the activity of key competitors and customers, order rates for longer lead time projects, and capital expenditure budgets and spending patterns of our customers. We also monitor trends throughout the commercial and residential fire and security markets, including building codes and fire-safety standards. Our commercial installation businesses are impacted by trends in commercial construction starts, while our residential business, which is located outside of North America, is impacted by new housing starts.

[0000833444-15-000091:mdna:29]
34

[0000833444-15-000091:mdna:30]
Because we are a global business, with approximately 51% of our revenue generated outside the United States, and because our financial statements are prepared in U.S. Dollars, our results of operations are impacted by changes in foreign currency exchange rates. During the year, the U.S. Dollar has remained strong against the currencies of most of the significant non-U.S. jurisdictions where we operate. The most significant impact on our results has been due to the strengthening of the U.S. Dollar as compared to the Euro which has unfavorably impacted our revenue and operating income during fiscal 2015. The average U.S. Dollar to Euro exchange rate in fiscal 2015 was 1.15 as compared to 1.36 in fiscal 2014. Assuming that the exchange rates for our principal non-U.S. currencies (the Euro, British Pound, and the Canadian and Australian dollars) remain at current levels throughout 2016, we expect foreign currency exchange rates to unfavorably impact our GAAP reported revenue and operating income during fiscal 2016.

[0000833444-15-000091:mdna:31]
In addition, the Company sells its products and services into the petrochemical, oil and gas market. Revenue from this market vertical is spread across each of the Company’s segments, with the most significant exposure in the United Kingdom in the ROW Integrated Solutions & Services segment and in the Fire Protection Products business in the Global Products segment. As a result of volatility in oil prices during the year, this market vertical has seen significant changes in spending patterns, in particular with respect to capital expenditures. The revenue tied to this market vertical has been unfavorably impacted during fiscal 2015, and we expect weakness in this sector to continue in fiscal 2016.

[0000833444-15-000091:mdna:32]
Results of Operations

[0000833444-15-000091:mdna:33]
Consolidated financial information is as follows:

[0000833444-15-000091:mdna:34]
|  | For the Years Ended |
| ($ in millions) | September 25, 2015 |  | September 26, 2014 |  | September 27, 2013 |
| Net revenue | $ | 9,902 |  |  | $ | 10,332 |  |  | $ | 10,058 |  |
| Net revenue (decline) growth | (4.2 | )% |  | 2.7 | % |  | NA |  |
| Organic revenue growth | 0.6 | % |  | 2.6 | % |  | NA |  |
| Operating income | $ | 884 |  |  | $ | 700 |  |  | $ | 712 |  |
| Operating margin | 8.9 | % |  | 6.8 | % |  | 7.1 | % |
| Interest income | $ | 15 |  |  | $ | 14 |  |  | $ | 16 |  |
| Interest expense | 102 |  |  | 97 |  |  | 100 |  |
| Other expense, net | 82 |  |  | 1 |  |  | 29 |  |
| Income tax expense | 100 |  |  | 24 |  |  | 108 |  |
| Equity income (loss) in earnings of unconsolidated subsidiaries | — |  |  | 206 |  |  | (48 | ) |
| Income from continuing operations attributable to Tyco ordinary shareholders | 617 |  |  | 797 |  |  | 446 |  |

[0000833444-15-000091:mdna:35]
Net Revenue:

[0000833444-15-000091:mdna:36]
Net revenue for the year ended September 25, 2015 decreased by $430 million, or 4.2%, to $9,902 million as compared to net revenue of $10,332 million for the year ended September 26, 2014. Changes in foreign currency exchange rates had an unfavorable impact of $622 million, or 6.0%, on net revenue.  Net revenue growth was also unfavorably impacted by divestitures of $67 million, or 0.6%, in our ROW Integrated Solutions & Services segment.  These declines were partially offset by the impact of acquisitions, which contributed $199 million, or 1.9%.  On an organic basis, net revenue grew by $60 million, or 0.6%, year over year as a result of growth in our Global Products, and to a lesser extent, NA Integrated Solutions & Services segments, partially offset by a decline in our ROW Integrated Solutions & Services segment.

[0000833444-15-000091:mdna:37]
Net revenue for the year ended September 26, 2014 increased by $274 million, or 2.7%, to $10,332 million as compared to net revenue of $10,058 million for the year ended September 27, 2013. On an organic basis, net revenue grew by $262 million, or 2.6%, year over year, as a result of growth in all three segments, led primarily by Global Products, and to lesser extent, ROW and NA Integrated Solutions and Services. Net revenue was favorably impacted by acquisitions, which contributed $201 million, or 2.0%, primarily within our ROW Integrated Solutions & Services and Global Products segments.  Net revenue growth was unfavorably impacted by divestitures of $107 million, or 1.1%, in our ROW and NA Integrated Solutions & Services segments. Changes in foreign currency exchange rates, primarily in our ROW Integrated Solutions & Services segment, also unfavorably impacted net revenue by $82 million, or 0.8%.

[0000833444-15-000091:mdna:38]
35

[0000833444-15-000091:mdna:39]
Cost of Revenue and Selling, General & Administrative ("SG&A")

[0000833444-15-000091:mdna:40]
The significant components of cost of product sales include material costs, labor and overhead costs, product shipping and warehousing costs. The significant components of cost of services include labor and employee related costs, depreciation expense, costs associated with our equipment and fleet of vehicles, telecommunication costs and material costs. The significant components of SG&A include compensation and compensation related costs, facility and maintenance expenses and professional fees.

[0000833444-15-000091:mdna:41]
Operating Income:

[0000833444-15-000091:mdna:42]
Operating income for the year ended September 25, 2015 increased $184 million, or 26.3%, to $884 million, as compared to operating income of $700 million for the year ended September 26, 2014.  This increase is primarily due to the $452 million decline in asbestos-related charges, as well as a $51 million reduction in separation costs during the year ended September 25, 2015.  In addition, improved execution, the benefits from cost-containment, and previous restructuring and productivity initiatives had a favorable impact on operating income.  These items were partially offset by a $196 million increase in restructuring and repositioning charges as compared to the prior year, an $88 million decrease in legacy legal gains, and a $33 million increase in loss on divestitures. Foreign currency exchange rates had an unfavorable impact of $47 million.  In addition, a $21 million insurance recovery related to China operations, and a $16 million gain related to a settlement with a former subsidiary (CIT) in fiscal year 2014 did not recur in fiscal year 2015.

[0000833444-15-000091:mdna:43]
Operating income for the year ended September 26, 2014 decreased $12 million, or 1.7%, to $700 million, as compared to operating income of $712 million for the year ended September 27, 2013. Operating income for the year ended September 26, 2014 was unfavorably impacted by asbestos related charges of $225 million relating to Yarway, a subsidiary of the Company at the time, and $240 million as a result of other asbestos related claims. Operating income for the year ended September 26, 2014 was favorably impacted by the reversal of a compensation reserve of $92 million established in respect of legacy litigation with former management, a gain of $16 million relating to a settlement with CIT, and a $21 million insurance recovery related to China operations. In addition, the year ended September 26, 2014 was also favorably impacted by a $100 million decline in environmental remediation costs related to our Global Products facility in Marinette, Wisconsin and a decrease in restructuring and repositioning charges of $38 million. See Note 12 to the Consolidated Financial Statements for further details on asbestos, environmental and legacy legal matters.

[0000833444-15-000091:mdna:44]
Items impacting operating income for fiscal 2015, 2014 and 2013 are as follows:

[0000833444-15-000091:mdna:45]
|  | For the Years Ended |
| ($ in millions) | September 25, 2015 |  | September 26, 2014 |  | September 27, 2013 |
| Restructuring, repositioning and asset impairment charges, net | $ | 289 |  |  | $ | 93 |  |  | $ | 131 |  |
| Environmental remediation costs - Marinette | — |  |  | — |  |  | 100 |  |
| Asbestos related charges | 10 |  |  | 462 |  |  | 12 |  |
| Losses (gains) on divestitures | 31 |  |  | (2 | ) |  | 20 |  |
| Separation costs | 2 |  |  | 53 |  |  | 69 |  |
| Legacy legal (gains) charges | (8 | ) |  | (96 | ) |  | 27 |  |
| China insurance recovery | — |  |  | (21 | ) |  | — |  |
| CIT settlement gain | — |  |  | (16 | ) |  | — |  |
| Impact of foreign currency | 47 |  |  | 13 |  |  | 14 |  |

[0000833444-15-000091:mdna:46]
36

[0000833444-15-000091:mdna:47]
We continue to identify and pursue opportunities for cost savings through restructuring activities and workforce reductions to improve operating efficiencies across our businesses.  Additionally, we initiated certain global actions designed to reduce our cost structure and improve future profitability by streamlining operations and better aligning functions, which we refer to as repositioning actions. Based on its current outlook for end market economic conditions, the Company expects to incur between $75 million and $100 million of restructuring and repositioning charges in fiscal 2016. See Note 4 to the Consolidated Financial Statements.

[0000833444-15-000091:mdna:48]
Income (loss) from continuing operations attributable to Tyco ordinary shareholders:

[0000833444-15-000091:mdna:49]
Interest Income and Expense

[0000833444-15-000091:mdna:50]
Interest income was $15 million in 2015, as compared to $14 million and $16 million in 2014 and 2013, respectively.

[0000833444-15-000091:mdna:51]
Interest expense was $102 million in 2015, as compared to $97 million and $100 million in 2014 and 2013, respectively. The weighted-average interest rate on total debt outstanding was 4.38% for fiscal 2015, and 6.5% for both fiscal 2014 and 2013.  The increase in interest expense for fiscal 2015 was primarily due to the net increase in debt during fiscal 2015 resulting from the various debt transactions in February and September as described above. See Note 9 to the Consolidated Financial Statements. As a result of the debt refinancing, the Company expects its weighted average interest rate to be 3.7% for 2016 on approximately $2.2 billion of long-term debt. See Note 21 to our Consolidated Financial Statements.

[0000833444-15-000091:mdna:52]
Other Expense, Net

[0000833444-15-000091:mdna:53]
Significant components of other expense, net for fiscal 2015, 2014 and 2013 are as follows:

[0000833444-15-000091:mdna:54]
|  | For the Years Ended |
| ($ in millions) | September 25, 2015 |  | September 26, 2014 |  | September 27, 2013 |
| Loss on extinguishment of debt (see Note 9 to the Consolidated Financial Statements) | $ | (81 | ) |  | $ | — |  |  | $ | — |  |
| 2012 Tax Sharing Agreement (loss) income (see Note 6 to the Consolidated Financial Statements) | (2 | ) |  | 15 |  |  | (32 | ) |
| 2007 Tax Sharing Agreement loss (see Note 6 to the Consolidated Financial Statements) | (5 | ) |  | (21 | ) |  | — |  |
| Other | 6 |  | 5 |  | 3 |  |
|  | $ | (82 | ) |  | $ | (1 | ) |  | $ | (29 | ) |

[0000833444-15-000091:mdna:55]
Effective Income Tax Rate

[0000833444-15-000091:mdna:56]
Our effective income tax rate was 14.0% during the year ended September 25, 2015. Our effective tax rate is affected by the mix of jurisdictions in which income is earned. Our effective tax rate for the year was unfavorably impacted by an increase in valuation allowance when the Company determined that it was more-likely-than not that a portion of our state deferred tax assets would not be realized, partially offset by a reversal of valuation allowance when a tax law change in a non-US jurisdiction affected the Company’s ability to determine that it was more-likely-than-not that our deferred tax assets would be realized. The year was favorably impacted by the increase in non-recurring repositioning and restructuring expenses described above, which were primarily incurred in high tax jurisdictions.

[0000833444-15-000091:mdna:57]
Our effective income tax rate was 3.9% during the year ended September 26, 2014.  Our effective tax rate is affected by the mix of jurisdictions in which income is earned. Our effective tax rate for the year was favorably impacted by asbestos related charges that generated a tax benefit in a high tax jurisdiction, partially offset by a reversal of a compensation reserve established in respect of legacy litigation with former management that generated tax expense in a high tax jurisdiction.

[0000833444-15-000091:mdna:58]
Our effective income tax rate was 18.0% during the year ended September 27, 2013. Our effective tax rate for the year was favorably impacted by taxes on the environmental remediation charges incurred during the second quarter of 2013, partially offset by Tax Sharing Agreement adjustments incurred throughout the year and enacted tax law changes in the fourth quarter of 2013.

[0000833444-15-000091:mdna:59]
The rate can vary from quarter to quarter due to discrete items, such as the settlement of income tax audits and changes in tax laws, as well as recurring factors such as the geographic mix of income before taxes.  The Company has operations and a taxable presence in nearly 60 countries outside the U.S.  All of these countries have a tax rate that is lower than the rate in the U.S.  The countries in which the Company has a material presence that have lower tax rates compared to the U.S. include Canada, Australia, Ireland, Germany, Switzerland and the United Kingdom.  The Company's ability to obtain a benefit from

[0000833444-15-000091:mdna:60]
37

[0000833444-15-000091:mdna:61]
lower tax rates outside the U.S. is dependent on its relative levels of income in countries outside the U.S. and on the statutory tax rates and tax laws in these countries.  Based on the dispersion of the Company's non-U.S. income and management’s current assessment of the likelihood and magnitude of any potential change to statutory tax rates or tax laws affecting the Company, any such changes are not expected to materially affect the Company's income tax provision or net income, aside from any one-time adjustment to reflect the impact of the change in the tax rate to the Company's deferred tax balances.

[0000833444-15-000091:mdna:62]
The valuation allowance for deferred tax assets of $2.0 billion as of both September 25, 2015 and September 26, 2014, respectively, relates principally to the uncertainty of the utilization of certain deferred tax assets, primarily tax loss and credit carryforwards in various jurisdictions. Specifically, the valuation allowance as of September 25, 2015 and September 26, 2014 includes separation related charges associated with the early extinguishment of debt which further increased a net operating loss carryforward which the Company does not expect to realize in future periods. The valuation allowance was calculated and recorded when the Company determined that it was more-likely-than-not that all or a portion of our deferred tax assets would not be realized. The Company believes that it will generate sufficient future taxable income to realize the tax benefits related to the remaining net deferred tax assets within the Company's Consolidated Balance Sheets.

[0000833444-15-000091:mdna:63]
The calculation of our tax liabilities involves dealing with uncertainties in the application of complex tax regulations in a multitude of jurisdictions across our global operations. We record tax liabilities for anticipated tax audit issues in the U.S. and other tax jurisdictions based on our estimate of whether, and the extent to which, additional taxes will be due. These tax liabilities are reflected net of related tax loss carryforwards. We adjust these liabilities in light of changing facts and circumstances; however, due to the complexity of some of these uncertainties, the ultimate resolution may result in a payment that is materially different from our current estimate of the tax liabilities. Substantially all of these potential tax liabilities are recorded in Other liabilities within the Consolidated Balance Sheets as payment is not expected within one year.

[0000833444-15-000091:mdna:64]
Equity Income (Loss) in Earnings of Unconsolidated Subsidiaries

[0000833444-15-000091:mdna:65]
Equity income (loss) in earnings of unconsolidated subsidiaries was nil in fiscal 2015.  Fiscal 2014 and 2013 reflect our share of Atkore's net income or loss, which was accounted for under the equity method of accounting.  Equity income (loss) in earnings of unconsolidated subsidiaries during the years ended September 26, 2014 and September 27, 2013 was a gain of $206 million and loss of $48 million, respectively.

[0000833444-15-000091:mdna:66]
On April 9, 2014, Atkore redeemed all of our remaining common equity stake in it for aggregate cash proceeds of $250 million.  We recognized a net gain of $216 million related to this transaction, which was comprised of a $227 million gain on the sale of the equity investment, partially offset by an $11 million loss, which was our share of loss on Atkore's debt extinguishment undertaken in connection with the redemption. See Note 3 to the Consolidated Financial Statements.

[0000833444-15-000091:mdna:67]
Segment Results

[0000833444-15-000091:mdna:68]
The following chart reflects our net revenue by segment, as well as the percent of net revenue by segment, for the years ended September 25, 2015, September 26, 2014 and September 27, 2013, respectively.

[0000833444-15-000091:mdna:69]
38

[0000833444-15-000091:mdna:70]
The segment discussions that follow describe the significant factors contributing to the changes in results for each of our segments included in continuing operations.

[0000833444-15-000091:mdna:71]
NA Integrated Solutions & Services

[0000833444-15-000091:mdna:72]
NA Integrated Solutions & Services designs, sells, installs, services and monitors integrated electronic security systems and integrated fire detection and suppression systems for commercial, industrial, retail, small business, institutional and governmental customers in North America.

[0000833444-15-000091:mdna:73]
Financial information for NA Integrated Solutions & Services for the years ended September 25, 2015, September 26, 2014 and September 27, 2013 were as follows:

[0000833444-15-000091:mdna:74]
|  | For the Years Ended |
| ($ in millions) | September 25, 2015 |  | September 26, 2014 |  | September 27, 2013 |
| Net revenue | $ | 3,879 |  |  | $ | 3,876 |  |  | $ | 3,891 |  |
| Net revenue growth (decline) | 0.1 | % |  | (0.4 | )% |  | NA |  |
| Organic revenue growth | 1.1 | % |  | 1.0 | % |  | NA |  |
| Operating income | $ | 542 |  |  | $ | 450 |  |  | $ | 388 |  |
| Operating margin | 14.0 | % |  | 11.6 | % |  | 10.0 | % |

[0000833444-15-000091:mdna:75]
Revenue

[0000833444-15-000091:mdna:76]
The change in net revenue compared to the prior periods is attributable to the following:

[0000833444-15-000091:mdna:77]
| Factors Contributing to Year-Over-Year Change | Fiscal 2015Compared toFiscal 2014 |  | Fiscal 2014Compared toFiscal 2013 |
| Organic revenue growth | $ | 44 |  |  | $ | 37 |  |
| Acquisitions | 11 |  |  | 19 |  |
| Divestitures | — |  |  | (42 | ) |
| Impact of foreign currency | (52 | ) |  | (29 | ) |
| Total change | $ | 3 |  |  | $ | (15 | ) |

[0000833444-15-000091:mdna:78]
Net revenue increased $3 million to $3,879 million for the year ended September 25, 2015 as compared to $3,876 million for the year ended September 26, 2014. On an organic basis, net revenue grew by $44 million, or 1.1%, driven by increases in both integrated solutions and service revenue. Net revenue was also favorably impacted by $11 million, or 0.3%, due to acquisitions made during fiscal 2015. Changes in foreign currency exchange rates unfavorably impacted net revenue by $52 million, or 1.3%.

[0000833444-15-000091:mdna:79]
Net revenue decreased $15 million, or 0.4% to $3,876 million for the year ended September 26, 2014 as compared to $3,891 million for the year ended September 27, 2013. On an organic basis, net revenue grew by $37 million, or 1.0%, due to increases in both integrated solutions and service revenue. The impact of acquisitions was $19 million, or 0.5%, due to the acquisition of Westfire, Inc. ("Westfire"), a fire protection services company, in the first quarter of fiscal 2014, which was integrated into the NA Integrated Solutions & Services and ROW Integrated Solutions and Services segments. Net revenue was unfavorably impacted by $42 million, or 1.1%, primarily due to the divestiture of our North America guarding business in the third quarter of fiscal 2013.

[0000833444-15-000091:mdna:80]
Operating Income

[0000833444-15-000091:mdna:81]
Operating income for the year ended September 25, 2015 increased $92 million, or 20.4%, to $542 million, as compared to operating income of $450 million for the year ended September 26, 2014. Operating income for the year ended September 25, 2015 increased due to a $49 million decline in separation costs. In addition, improved execution, cost containment, and the benefits from previous restructuring and productivity initiatives had a favorable impact on operating income during the fiscal year. These items were partially offset by a $36 million increase in restructuring and repositioning charges.

[0000833444-15-000091:mdna:82]
Operating income for the year ended September 26, 2014 increased $62 million, or 16.0%, to $450 million, as compared to operating income of $388 million for the year ended September 27, 2013. Operating income for the year ended September 26, 2014 increased due to a higher mix of service revenue, improved execution, lower restructuring and repositioning charges, and savings realized from restructuring activities and productivity initiatives.

[0000833444-15-000091:mdna:83]
Key items impacting operating income for the years ended September 25, 2015, September 26, 2014 and September 27, 2013 were as follows:

[0000833444-15-000091:mdna:84]
|  | For the Years Ended |
| ($ in millions) | September 25, 2015 |  | September 26, 2014 |  | September 27, 2013 |
| Separation costs | $ | 2 |  |  | $ | 51 |  |  | $ | 49 |  |
| Restructuring, repositioning and asset impairment charges, net | 49 |  |  | 13 |  |  | 36 |  |

[0000833444-15-000091:mdna:85]
ROW Integrated Solutions & Services:

[0000833444-15-000091:mdna:86]
ROW Integrated Solutions & Services designs, sells, installs, services and monitors integrated electronic security systems and integrated fire detection and suppression systems for commercial, industrial, retail, residential, small business, institutional and governmental customers in our Continental Europe, United Kingdom, Asia, Pacific and Growth Markets regions, which are collectively our ROW regions.

[0000833444-15-000091:mdna:87]
Financial information for ROW Integrated Solutions & Services for the years ended September 25, 2015, September 26, 2014 and September 27, 2013 were as follows:

[0000833444-15-000091:mdna:88]
|  | For the Years Ended |
| ($ in millions) | September 25, 2015 |  | September 26, 2014 |  | September 27, 2013 |
| Net revenue | $ | 3,432 |  |  | $ | 3,912 |  |  | $ | 3,828 |  |
| Net revenue (decline) growth | (12.3 | )% |  | 2.2 | % |  | NA |  |
| Organic revenue (decline) growth | (1.3 | )% |  | 2.1 | % |  | NA |  |
| Operating income | $ | 243 |  |  | $ | 412 |  |  | $ | 336 |  |
| Operating margin | 7.1 | % |  | 10.5 | % |  | 8.8 | % |

[0000833444-15-000091:mdna:89]
Revenue

[0000833444-15-000091:mdna:90]
The change in net revenue compared to the prior periods is attributable to the following:

[0000833444-15-000091:mdna:91]
| Factors Contributing to Year-Over-Year Change | Fiscal 2015Compared toFiscal 2014 |  | Fiscal 2014Compared toFiscal 2013 |
| Organic revenue (decline) growth | $ | (51 | ) |  | $ | 78 |  |
| Acquisitions | 60 |  |  | 119 |  |
| Divestitures | (67 | ) |  | (67 | ) |
| Impact of foreign currency | (422 | ) |  | (46 | ) |
| Total change | $ | (480 | ) |  | $ | 84 |  |

[0000833444-15-000091:mdna:92]
Net revenue decreased $480 million, or 12.3%, to $3,432 million for the year ended September 25, 2015 as compared to $3,912 million for the year ended September 26, 2014.  Changes in foreign currency exchanges rates unfavorably impacted net revenue by $422 million, or 10.8%. Net revenue was also unfavorably impacted by $67 million, or 1.7% due to divestitures in the Asia and Pacific regions.  On an organic basis, net revenue declined by $51 million, or 1.3%, primarily in the United Kingdom and Pacific regions as a result of pressure within the oil and gas and mining industries, respectively, which were partially offset by an increase within Growth Markets.  Net revenue was favorably impacted by $60 million, or 1.5%, primarily due to the acquisitions within Growth Markets and the United Kingdom.

[0000833444-15-000091:mdna:93]
Net revenue increased $84 million, or 2.2%, to $3,912 million for the year ended September 26, 2014 as compared to $3,828 million for the year ended September 27, 2013.  On an organic basis, net revenue grew by $78 million, or 2.1%, and was driven by integrated solutions and service growth in Growth Markets and integrated solutions growth in Asia.  Growth in these regions were offset by declines in both integrated solutions and service revenue in our Pacific, and to a lesser extent, Continental Europe regions.  Net revenue was favorably impacted by $119 million, or 3.1%, primarily due to the acquisitions within the Growth Markets and our Pacific regions during fiscal 2014 and 2013.  Net revenue was unfavorably impacted by $67 million, or 1.8% due to divestitures in the Pacific region. Changes in foreign currency exchanges rates unfavorably impacted net revenue by $46 million, or 1.2%.

[0000833444-15-000091:mdna:94]
Operating Income

[0000833444-15-000091:mdna:95]
Operating income for the year ended September 25, 2015 decreased $169 million, or 41.0%, to $243 million, as compared to operating income of $412 million for the year ended September 26, 2014. Operating income was unfavorably impacted by a $73 million increase in restructuring and repositioning charges and a $13 million increase in loss on divestitures.  Foreign currency exchange rates had an unfavorable impact of $27 million. In addition, operating income for fiscal 2014 included a China insurance recovery of $21 million which did not recur in fiscal 2015. The impact of lower revenue was partially offset by the benefits of cost-containment initiatives and previous productivity and restructuring actions.

[0000833444-15-000091:mdna:96]
Operating income for the year ended September 26, 2014 increased $76 million, or 22.6%, to $412 million, as compared to operating income of $336 million for the year ended September 27, 2013. Operating income for the year ended September 26, 2014 was favorably impacted by a decrease in restructuring and repositioning charges and loss on divestitures, a $21 million insurance recovery related to China and the benefit of ongoing productivity initiatives, partially offset by a lower mix of high-margin service revenue in the Pacific region.

[0000833444-15-000091:mdna:97]
Key items impacting operating income for the years ended September 25, 2015, September 26, 2014 and September 27, 2013 were as follows:

[0000833444-15-000091:mdna:98]
|  | For the Years Ended |
| ($ in millions) | September 25, 2015 |  | September 26, 2014 |  | September 27, 2013 |
| Restructuring, repositioning and asset impairment charges, net | $ | 104 |  |  | $ | 31 |  |  | $ | 64 |  |
| China insurance recovery | — |  |  | (21 | ) |  | — |  |
| Loss on divestitures | 14 |  |  | 1 |  |  | 14 |  |
| Impact of foreign currency | 27 |  |  | 10 |  |  | 12 |  |

[0000833444-15-000091:mdna:99]
Global Products:

[0000833444-15-000091:mdna:100]
Global Products designs, manufactures and sells fire protection, security and life safety products, including intrusion security, anti-theft devices, breathing apparatus and access control and video management systems, for commercial, industrial, retail, residential, small business, institutional and governmental customers worldwide, including products installed and serviced by our NA and ROW Integrated Solutions & Services segments.

[0000833444-15-000091:mdna:101]
Financial information for Global Products for the years ended September 25, 2015, September 26, 2014 and September 27, 2013 were as follows:

[0000833444-15-000091:mdna:102]
|  | For the Years Ended |
| ($ in millions) | September 25, 2015 |  | September 26, 2014 |  | September 27, 2013 |
| Net revenue | $ | 2,591 |  |  | $ | 2,544 |  |  | $ | 2,339 |  |
| Net revenue growth | 1.8 | % |  | 8.8 | % |  | NA |  |
| Organic revenue growth | 2.6 | % |  | 6.3 | % |  | NA |  |
| Operating income | $ | 405 |  |  | $ | 458 |  |  | $ | 307 |  |
| Operating margin | 15.6 | % |  | 18.0 | % |  | 13.1 | % |

[0000833444-15-000091:mdna:103]
Revenue

[0000833444-15-000091:mdna:104]
The change in net revenue compared to the prior periods is attributable to the following:

[0000833444-15-000091:mdna:105]
| Factors Contributing to Year-Over-Year Change | Fiscal 2015Compared toFiscal 2014 |  | Fiscal 2014Compared toFiscal 2013 |
| Organic revenue growth | $ | 67 |  |  | $ | 147 |  |
| Acquisitions | 128 |  |  | 63 |  |
| Impact of foreign currency | (148 | ) |  | (7 | ) |
| Other | — |  |  | 2 |  |
| Total change | $ | 47 |  |  | $ | 205 |  |

[0000833444-15-000091:mdna:106]
Net revenue increased $47 million, or 1.8%, to $2,591 million for the year ended September 25, 2015 as compared to $2,544 million for the year ended September 26, 2014. On an organic basis, net revenue grew by $67 million, or 2.6%, primarily driven by our security products and life safety businesses. Net revenue was favorably impacted by $128 million, or 5.0% from acquisitions across all three businesses, primarily in our life safety and fire products businesses. Changes in foreign currency exchange rates unfavorably impacted net revenue by $148 million, or 5.8%.

[0000833444-15-000091:mdna:107]
Net revenue increased $205 million, or 8.8%, to $2,544 million for the year ended September 26, 2014 as compared to $2,339 million for the year ended September 27, 2013.  On an organic basis, net revenue grew by $147 million, or 6.3%, driven by increases across all three of our product platforms, primarily in security products.  The impact of acquisitions was $63 million, or 2.7%, primarily due to the acquisition of Exacq Technologies, a developer of open architecture video management systems for security and surveillance applications, during 2013.

[0000833444-15-000091:mdna:108]
Operating Income

[0000833444-15-000091:mdna:109]
Operating income for the year ended September 25, 2015 decreased $53 million, or 11.6%, to $405 million, as compared to operating income of $458 million for the year ended September 26, 2014.  The decrease was driven mainly by a $21 million increase in restructuring and repositioning charges, a $17 million loss on divestiture and additional investments in research and development.  Foreign currency exchange rates had an unfavorable impact of $16 million. These items were partially offset by net revenue growth, as well as the benefit of cost-containment initiatives and previous productivity and restructuring actions.

[0000833444-15-000091:mdna:110]
Operating income for the year ended September 26, 2014 increased $151 million, or 49.2%, to $458 million, as compared to operating income of $307 million for the year ended September 27, 2013.  The increase was driven by net revenue growth in fiscal 2014 and the unfavorable impact of an environmental remediation charge in fiscal 2013, partially offset by additional investments in research and development and sales and marketing costs. See Note 12 to the Consolidated Financial Statements.

[0000833444-15-000091:mdna:111]
Key items impacting operating income for the years ended September 25, 2015, September 26, 2014 and September 27, 2013 were as follows:

[0000833444-15-000091:mdna:112]
|  | For the Years Ended |
| ($ in millions) | September 25, 2015 |  | September 26, 2014 |  | September 27, 2013 |
| Environmental remediation costs - Marinette | $ | — |  |  | $ | — |  |  | $ | 100 |  |
| Restructuring, repositioning and asset impairment charges, net | 33 |  |  | 12 |  |  | 12 |  |
| Loss on divestitures | 17 |  |  | — |  |  | — |  |
| Impact of foreign currency | 16 |  |  | — |  |  | 1 |  |

[0000833444-15-000091:mdna:113]
Corporate and Other

[0000833444-15-000091:mdna:114]
Corporate expense decreased $314 million, or 50.6%, to $306 million for the year ended September 25, 2015 as compared to $620 million for the year ended September 26, 2014. The decrease in expense was primarily due to a reduction of $452 million in asbestos-related charges as compared to the prior period. This was partially offset by a $66 million increase in restructuring and repositioning charges, an $87 million decrease in legacy legal gains, and to a lesser extent, a $16 million gain related to a settlement with a former subsidiary which did not recur in fiscal 2015.

[0000833444-15-000091:mdna:115]
Corporate expense increased $301 million, or 94.4%, to $620 million for the year ended September 26, 2014 as compared to $319 million for the year ended September 27, 2013. The increase in Corporate expense for the year ended September 26, 2014 was primarily due to asbestos related charges of $225 million relating to Yarway, and $240 million related to other asbestos related claims. The increase in expense was also due to higher restructuring, repositioning and asset impairment charges, partially offset by a $96 million reversal and recoveries from settlements with former management. The increase in expense was also partially offset to a lesser extent by lower separation costs and a gain related to a legal settlement with CIT. See Note 12 to the Consolidated Financial Statements.

[0000833444-15-000091:mdna:116]
Key items included in corporate expense for the years ended September 25, 2015, September 26, 2014 and September 27, 2013 were as follows:

[0000833444-15-000091:mdna:117]
|  | For the Years Ended |
| ($ in millions) | September 25, 2015 |  | September 26, 2014 |  | September 27, 2013 |
| Legacy legal (gains) charges | $ | (9 | ) |  | $ | (96 | ) |  | $ | 27 |  |
| Separation costs | — |  |  | 2 |  |  | 20 |  |
| Restructuring, repositioning and asset impairment charges, net | 103 |  |  | 37 |  |  | 19 |  |
| Asbestos related charges | 10 |  |  | 462 |  |  | 12 |  |
| CIT settlement gain | — |  |  | (16 | ) |  | — |  |

[0000833444-15-000091:mdna:118]
Critical Accounting Policies and Estimates

[0000833444-15-000091:mdna:119]
The preparation of the Consolidated Financial Statements in conformity with GAAP requires management to use judgment in making estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of contingent assets and liabilities and the reported amounts of revenue and expenses. The following accounting policies are based on, among other things, judgments and assumptions made by management that include inherent risks and uncertainties. Management's estimates are based on the relevant information available at the end of each period.

[0000833444-15-000091:mdna:120]
Depreciation and Amortization Methods for Security Monitoring-Related Assets—Tyco considers assets related to the acquisition of new customers in its electronic security business in three asset categories: internally generated residential subscriber systems outside of North America, internally generated commercial subscriber systems (collectively referred to as subscriber system assets) and customer accounts acquired through the ADT dealer program primarily outside of North America (referred to as dealer intangibles). Subscriber system assets include installed property, plant and equipment for which Tyco retains ownership and deferred costs directly related to the customer acquisition and system installation. Subscriber system assets and any deferred revenue resulting from the customer acquisition are accounted for over the expected life of the subscriber. In certain geographical areas where the Company has a large number of customers that behave in a similar manner over time, the Company accounts for subscriber system assets and related deferred revenue using pools, with separate pools for the components of subscriber system assets and any related deferred revenue based on the month and year of acquisition. The Company depreciates its pooled subscriber system assets and related deferred revenue using an accelerated method with lives up to 15 years. The accelerated method utilizes declining balance rates based on geographical area ranging from 140% to 360% for commercial subscriber pools and dealer intangibles and converts to a straight line methodology when the resulting depreciation charge is greater than that from the accelerated method. The Company uses a straight-line method with a 14-year life for non-pooled subscriber system assets (primarily in Europe, Latin America and Asia) and related deferred revenue, with remaining balances written off upon customer termination.

[0000833444-15-000091:mdna:121]
Revenue Recognition—Contract sales for the installation of fire protection systems, large security intruder systems and other construction-related projects are recorded primarily under the percentage-of-completion method. Profits recognized on contracts in process are based upon estimated contract revenue and related total cost of the project at completion. The risk of this methodology is its dependence upon estimates of costs at completion, which are subject to the uncertainties inherent in long-term contracts. Provisions for anticipated losses are made in the period in which they become determinable.

[0000833444-15-000091:mdna:122]
Sales of security monitoring systems may have multiple elements, including equipment, installation, monitoring services and maintenance agreements. We assess our revenue arrangements to determine the appropriate units of accounting. When ownership of the system is transferred to the customer, each deliverable provided under the arrangement is considered a separate unit of accounting. Revenues associated with sale of equipment and related installations are recognized once delivery, installation and customer acceptance is completed, while the revenue for monitoring and maintenance services are recognized as services are rendered. Amounts assigned to each unit of accounting are based on an allocation of total arrangement consideration using a hierarchy of estimated selling price for the deliverables. The selling price used for each deliverable will be based on Vendor Specific Objective Evidence ("VSOE") if available, Third Party Evidence ("TPE") if VSOE is not available, or estimated selling price if neither VSOE or TPE is available. Revenue recognized for equipment and installation is limited to the lesser of their allocated amounts under the estimated selling price hierarchy or the non-contingent up-front consideration received at the time of installation, since collection of future amounts under the arrangement with the customer is contingent upon the delivery of monitoring and maintenance services.

[0000833444-15-000091:mdna:123]
Product discounts granted are based on the terms of arrangements with direct, indirect and other market participants. Rebates are estimated based on sales terms, historical experience and trend analysis.

[0000833444-15-000091:mdna:124]
Loss Contingencies—Accruals are recorded for various contingencies including legal proceedings, self-insurance and other claims that arise in the normal course of business. The accruals are based on judgment, the probability of losses and, where applicable, the consideration of opinions of internal and/or external legal counsel and actuarially determined estimates. Additionally, the Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-15-000091:mdna:125]
Asbestos-Related Contingencies and Insurance Receivables—We and certain of our subsidiaries along with numerous other companies are named as defendants in personal injury lawsuits based on alleged exposure to asbestos-containing materials. We estimate the liability and corresponding insurance recovery for pending and future claims and defense costs based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2056 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Periodically, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on a periodic basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-15-000091:mdna:126]
In connection with the recognition of liabilities for asbestos-related matters, we record asbestos-related insurance recoveries that are probable. The estimate of asbestos-related insurance recoveries represents estimated amounts due to us for previously paid and settled claims and the probable reimbursements relating to estimated liability for pending and future claims. In determining the amount of insurance recoverable, we consider available insurance, allocation methodologies, solvency and creditworthiness of the insurers. See Note 12 to the Consolidated Financial Statements for a discussion on management's judgments applied in the recognition and measurement of asbestos-related assets and liabilities.

[0000833444-15-000091:mdna:127]
Insurable Liabilities—The Company records liabilities for its workers' compensation, product, general and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. Certain insurable liabilities are discounted using a risk-free rate of return when the pattern and timing of the future obligation is reliably determinable. The Company records receivables from third party insurers when recovery has been determined to be probable.

[0000833444-15-000091:mdna:128]
Income Taxes—In determining taxable income for financial statement purposes, we must make certain estimates and judgments. These estimates and judgments affect the calculation of certain tax liabilities and the determination of the recoverability of certain of the deferred tax assets, which arise from temporary differences between the tax and financial statement recognition of revenue and expense.

[0000833444-15-000091:mdna:129]
In evaluating our ability to recover our deferred tax assets we consider all available positive and negative evidence including our past operating results, the existence of cumulative losses in the most recent years and our forecast of future taxable income. In estimating future taxable income, we develop assumptions including the amount of future pre-tax operating income, the reversal of temporary differences and the implementation of feasible and prudent tax planning strategies. These assumptions require significant judgment about the forecasts of future taxable income and are consistent with the plans and estimates we are using to manage the underlying businesses.

[0000833444-15-000091:mdna:130]
We currently have recorded valuation allowances that we will maintain until it is more-likely-than-not the deferred tax assets will be realized. Our income tax expense recorded in the future may be reduced to the extent of decreases in our valuation allowances. The realization of our remaining deferred tax assets is primarily dependent on future taxable income in the appropriate jurisdiction. Any reduction in future taxable income including but not limited to any future restructuring activities may require that we record an additional valuation allowance against our deferred tax assets. An increase in the valuation allowance could result in additional income tax expense in such period and could have a significant impact on our future earnings.

[0000833444-15-000091:mdna:131]
Changes in tax laws and rates could also affect recorded deferred tax assets and liabilities in the future. Management records the effect of a tax rate or law change on the Company's deferred tax assets and liabilities in the period of enactment. Future tax rate or law changes could have a material effect on the Company's financial condition, results of operations or cash flows.

[0000833444-15-000091:mdna:132]
44

[0000833444-15-000091:mdna:133]
In addition, the calculation of our tax liabilities involves dealing with uncertainties in the application of complex tax regulations in a multitude of jurisdictions across our global operations. We recognize potential liabilities and record tax liabilities for anticipated tax audit issues in the U.S. and other tax jurisdictions based on our estimate of whether, and the extent to which, additional taxes will be due. These tax liabilities are reflected net of related tax loss carryforwards. We adjust these reserves in light of changing facts and circumstances; however, due to the complexity of some of these uncertainties, the ultimate resolution may result in a payment that is materially different from our current estimate of the tax liabilities. If our estimate of tax liabilities proves to be less than the ultimate assessment, an additional charge to expense would result. If payment of these amounts ultimately proves to be less than the recorded amounts, the reversal of the liabilities would result in tax benefits being recognized in the period when we determine the liabilities are no longer necessary.

[0000833444-15-000091:mdna:134]
Goodwill and Indefinite-Lived Intangible Asset Impairments—Goodwill and indefinite-lived intangible assets are assessed for impairment annually and more frequently if triggering events occur. In performing these assessments, management relies on and considers a number of factors, including operating results, business plans, economic projections, anticipated future cash flows, comparable market transactions (to the extent available), other market data and the Company's overall market capitalization.  We elected to make the first day of the fourth quarter the annual impairment assessment date for all goodwill and indefinite-lived intangible assets.

[0000833444-15-000091:mdna:135]
When testing for goodwill impairment, we first assess qualitative factors to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying amount.  If we conclude it is more likely than not that the fair value of a reporting unit is less than its carrying amount, a quantitative fair value test is performed.  Based upon our most recent annual impairment test completed as of June 29, 2015, it is more likely than not that the fair value of each reporting unit was in excess of its carrying value.

[0000833444-15-000091:mdna:136]
We recorded no goodwill impairments in conjunction with our annual goodwill impairment assessment performed during the fourth quarter of fiscal 2015.

[0000833444-15-000091:mdna:137]
Indefinite-lived intangible assets consisting primarily of trade names and franchise rights are tested for impairment using either a relief-from-royalty method or excess earnings method, respectively.

[0000833444-15-000091:mdna:138]
Fair value determinations require considerable judgment and are sensitive to changes in underlying assumptions and factors. As a result, there can be no assurance that the estimates and assumptions made for purposes of the annual goodwill impairment test will prove to be accurate predictions of the future. Examples of events or circumstances that could reasonably be expected to negatively affect the underlying key assumptions and ultimately impact the estimated fair value of the aforementioned reporting units may include such items as follows:

[0000833444-15-000091:mdna:139]
| • | A prolonged downturn in the business environment in which the reporting units operate (i.e. sales volumes and prices) especially in the commercial construction and retailer end markets; |

[0000833444-15-000091:mdna:140]
| • | An economic recovery that significantly differs from our assumptions in timing or degree; |

[0000833444-15-000091:mdna:141]
| • | Volatility in equity and debt markets resulting in higher discount rates; and |

[0000833444-15-000091:mdna:142]
| • | Unexpected regulatory changes. |

[0000833444-15-000091:mdna:143]
While historical performance and current expectations have resulted in fair values of goodwill in excess of carrying values, if our assumptions are not realized, it is possible that in the future an impairment charge may need to be recorded. However, it is not possible at this time to determine if an impairment charge would result or if such a charge would be material.

[0000833444-15-000091:mdna:144]
Long-Lived Assets—Asset groups held and used by the Company, including property, plant and equipment and amortizable intangible assets, are reviewed for impairment whenever events or changes in business circumstances indicate that the carrying amount of the asset group may not be fully recoverable. Tyco performs undiscounted operating cash flow analyses to determine if impairment exists. For purposes of recognition and measurement of an impairment for assets held for use, Tyco groups assets and liabilities at the lowest level for which cash flows are separately identified. If an impairment is determined to exist, any related impairment loss is calculated based on fair value. Impairments to long-lived assets to be disposed of are recorded based upon the fair value less cost to sell of the applicable assets. The calculation of the fair value of long-lived assets is based on assumptions concerning the amount and timing of estimated future cash flows and assumed discount rates, reflecting varying degrees of perceived risk. Since judgment is involved in determining the fair value and useful lives of long-lived assets, there is a risk that the carrying value of our long-lived assets may be overstated or understated.

[0000833444-15-000091:mdna:145]
Pension and Postretirement Benefits—Our pension expense and obligations are developed from actuarial valuations. Two critical assumptions in determining pension expense and obligations are the discount rate and expected long-term return on plan assets. We evaluate these assumptions at least annually. Other assumptions reflect demographic factors such as retirement, mortality and turnover and are evaluated periodically and updated to reflect our actual experience. Actual results may differ from actuarial assumptions resulting in actuarial gains and losses. For active plans, such actuarial gains and losses will be amortized over the average expected service period of the participants and in the case of inactive plans over the average

[0000833444-15-000091:mdna:146]
45

[0000833444-15-000091:mdna:147]
remaining life expectancy of participants. The discount rate represents the market rate for high-quality fixed income investments and is used to calculate the present value of the expected future cash flows for benefit obligations under our pension plans. A decrease in the discount rate increases the present value of pension benefit obligations. A 25 basis point decrease in the discount rate would increase the present value of pension obligations by approximately $86 million and increase our annual pension expense by approximately $1 million. We consider the relative weighting of plan assets by class, historical performance of asset classes over long-term periods, asset class performance expectations as well as current and future economic conditions in determining the expected long-term return on plan assets. A 25 basis point decrease in the expected long-term return on plan assets would increase our annual pension expense by approximately $5 million.

[0000833444-15-000091:mdna:148]
Liquidity and Capital Resources

[0000833444-15-000091:mdna:149]
A fundamental objective of the Company is to have sufficient liquidity, balance sheet strength, and financial flexibility to fund the operating and capital requirements of its core businesses around the world.

[0000833444-15-000091:mdna:150]
The primary source of funds to finance our operations and capital expenditures is cash generated by operations. In addition, we maintain a $1.5 billion commercial paper program, backed up by a committed revolving credit facility, and have access to equity and debt capital from public and private sources. We continue to balance our operating, investing, and financing uses of cash through investments and acquisitions in our core businesses, dividends, and share repurchases.  In addition, we believe our available cash, amounts available under our credit facility, commercial paper program and cash provided by operating activities will be adequate to cover our operational, capital and other business needs in the foreseeable future. To the extent it is necessary for us to finance our cash needs through the issuance of commercial paper, by accessing our committed revolving credit facility, or through other public or private sources, our cost of funding may increase depending on market conditions at the time of such borrowing.

[0000833444-15-000091:mdna:151]
As of September 25, 2015 and September 26, 2014, our cash and cash equivalents, short- and long-term debt at carrying value, and Tyco shareholder's equity are as follows:

[0000833444-15-000091:mdna:152]
|  | As of |  | Credit Availability as of |
| ($ in millions) | September 25, 2015 |  | September 26, 2014 |  | September 25, 2015 |
| Cash and cash equivalents | $ | 1,401 |  |  | $ | 892 |  |  | $ | — |  |
| Total debt (excluding revolving credit facility) (1) | 3,146 |  |  | 1,463 |  |  | — |  |
| Revolving credit facility | — |  |  | — |  |  | 1,500 |  |
| Total Tyco shareholders' equity | 4,041 |  |  | 4,647 |  |  | — |  |
| Total debt as a % of total capital (2) | 43.8 | % |  | 23.9 | % |  | NA |  |

[0000833444-15-000091:mdna:153]
(1) On October 14, 2015, the Company redeemed its outstanding $242 million aggregate principal amount 7.0% notes due 2019 and $462 million aggregate principal amount 6.875% notes due 2021, which were classified as current as of September 25, 2015. On October 15, 2015, the Company repaid $258 million aggregate principal amount of 3.375% notes due 2015, which matured on such date. See Note 21 to the Consolidated Financial Statements. After such repayments, the Company's total debt and total debt as a percentage of total capital were $2,178 million and 35.0%, respectively.

[0000833444-15-000091:mdna:154]
(2) Total capital represents the aggregate amount of total debt and total shareholders' equity which was $7,187 million and $6,110 million as of September 25, 2015 and September 26, 2014, respectively.

[0000833444-15-000091:mdna:155]
Significant uses of capital that are expected in the near- to mid-term include expenditures for (i) capital expenditures and dealer investments in annual amounts expected to approximate 3% to 3.5% of total revenues, (ii) the funding of potential tax liabilities or settlements (see Note 6 to the Consolidated Financial Statements), including with respect to the divestiture of our ADT Korea business (see Note 3 to the Consolidated Financial Statements), with respect to which the amounts and timing are uncertain, (iii) estimated restructuring payments, of which $145 million has been accrued as a current liability as of September 25, 2015 (see Note 4 to the Consolidated Financial Statements) and (iv) quarterly dividend payments, of which $87 million has been accrued as of September 25, 2015 (see Note 14 to the Consolidated Financial Statements). The Company intends to fund these capital uses through a combination of available cash, cash generated from operations, borrowing in the commercial paper market or under its revolving credit facility, and borrowing in public or private markets for debt securities. In addition, the Company intends, in its discretion, to pursue strategically important acquisitions, may repurchase its shares from time to time and may engage in other capital market activities, in each case depending on a number of factors, including the Company’s strategic priorities, its financial condition and results of operations, the capital requirements of the Company’s businesses, industry and capital markets factors and other relevant factors.

[0000833444-15-000091:mdna:156]
Sources and uses of cash

[0000833444-15-000091:mdna:157]
In summary, our cash flows from operating, investing, and financing from continuing operations for fiscal 2015, 2014 and 2013 were as follows:

[0000833444-15-000091:mdna:158]
|  | For the Years Ended |
| ($ in millions) | September 25, 2015 |  | September 26, 2014 |  | September 27, 2013 |
| Net cash provided by operating activities | $ | 542 |  |  | $ | 829 |  |  | $ | 701 |  |
| Net cash used in investing activities | (862 | ) |  | (221 | ) |  | (544 | ) |
| Net cash provided by (used in) financing activities | 862 |  |  | (259 | ) |  | (427 | ) |

[0000833444-15-000091:mdna:159]
Cash flow from operating activities

[0000833444-15-000091:mdna:160]
Cash flow from operating activities can fluctuate significantly from period to period as working capital needs and the timing of payments for items such as restructuring activities, pension funding, income taxes, asbestos liabilities and other items impact reported cash flow.

[0000833444-15-000091:mdna:161]
The net change in working capital reduced operating cash flow by $671 million in fiscal 2015. The significant changes in working capital included a $338 million decrease in the gross asbestos liabilities, a $149 million increase in accounts receivable, a $44 million increase in inventories, a $33 million increase in prepaid expenses and other current assets, and a $32 million decrease in deferred revenue, partially offset by a $32 million decrease in asbestos insurance assets.

[0000833444-15-000091:mdna:162]
On January 9, 2015, the Company completed a series of restructuring transactions related to the establishment and funding of a structure dedicated to resolving certain historic Grinnell asbestos liabilities. Pursuant to this transaction, a subsidiary of the Company acquired certain assets of Grinnell and transferred cash and other assets totaling approximately $278 million to the structure. The cash and other assets transferred to the structure have been designated as restricted by the Company. In addition, on the effective date of Yarway’s Chapter 11 plan of reorganization, which occurred in August 2015, the Company contributed approximately $325 million to an asbestos settlement trust that conformed to the provisions of Section 524(g) of the U.S. Bankruptcy Code. See Note 12 to the Consolidated Financial Statements for information regarding asbestos.

[0000833444-15-000091:mdna:163]
The net change in working capital reduced operating cash flow by $56 million in fiscal 2014. The significant changes in working capital included a $327 million decrease in accrued expenses and other liabilities, a $99 million increase in contracts in progress, a $96 million increase in accounts receivable, and a $93 million increase in asbestos insurance assets, partially offset by a $532 million increase in gross asbestos liabilities, and a $54 million increase in accounts payable.

[0000833444-15-000091:mdna:164]
The net change in working capital reduced operating cash flow by $384 million in fiscal 2013. The significant changes in working capital included a $141 million decrease in accrued and other liabilities, an $80 million decrease gross asbestos liabilities, a $73 million increase in accounts receivable, a $61 million increase in prepaid expenses and other assets, a $36 million increase in inventories, and a $33 million decrease in deferred revenue, partially offset by a $94 million decrease in asbestos insurance assets.

[0000833444-15-000091:mdna:165]
During fiscal 2015, 2014 and 2013, we paid approximately $101 million, $74 million and $81 million, respectively, in cash related to restructuring activities. See Note 4 to the Consolidated Financial Statements.

[0000833444-15-000091:mdna:166]
In connection with the 2012 Separation, we paid $2 million, $58 million and $165 million in separation costs during fiscal 2015, 2014 and 2013, respectively.

[0000833444-15-000091:mdna:167]
During fiscal 2015, 2014 and 2013, we made environmental remediation payments related to environmental remediation activities for a facility located in Marinette, Wisconsin, of $7 million, $63 million and $51 million, respectively.

[0000833444-15-000091:mdna:168]
During fiscal 2015, 2014 and 2013, we made required contributions of $34 million, $54 million and $50 million, respectively, to our U.S. and non-U.S. pension plans. We also made voluntary contributions of nil during the years ended September 25, 2015, September 26, 2014 and September 27, 2013 to our U.S. plans. The Company anticipates that it will contribute at least the minimum required to its pension plans in 2016 of $3 million for the U.S. plans and $26 million for non-U.S. plans.

[0000833444-15-000091:mdna:169]
Income taxes paid, net of refunds, related to continuing operations were $98 million, $102 million and $134 million in fiscal 2015, 2014 and 2013, respectively.

[0000833444-15-000091:mdna:170]
Interest paid, net of interest received, related to continuing operations was $87 million, $84 million and $80 million in fiscal 2015, 2014 and 2013, respectively.

[0000833444-15-000091:mdna:171]
47

[0000833444-15-000091:mdna:172]
Cash flow from investing activities

[0000833444-15-000091:mdna:173]
Cash flows related to investing activities consist primarily of cash used for capital expenditures and acquisitions, proceeds derived from divestitures of businesses and assets and the purchase and sales and maturities of investments.

[0000833444-15-000091:mdna:174]
We made capital expenditures of $246 million, $288 million and $269 million during fiscal 2015, 2014 and 2013, respectively. The level of capital expenditures in fiscal year 2016 is expected to exceed the spending levels in fiscal year 2015 and is also expected to exceed depreciation expense.

[0000833444-15-000091:mdna:175]
During fiscal 2015, we paid cash for acquisitions totaling $583 million, net of $28 million cash acquired and $5 million of contingent consideration, for 12 acquisitions.  The largest acquisition was Industrial Safety Technologies ("IST") for $327 million, net of $5 million cash acquired, which is being integrated into the Global Products segment.  During 2014, we paid cash for acquisitions totaling $65 million, net of $1 million cash acquired, which was related to acquisitions included in our NA Integrated Solutions & Services and ROW Integrated Solutions & Services segments.  During 2013, we paid cash for acquisitions totaling $229 million, net of $9 million cash acquired, which primarily related to the acquisition of Exacq Technologies within our Global Products segment.  See Note 5 to the Consolidated Financial Statements.

[0000833444-15-000091:mdna:176]
During fiscal 2015, 2014 and 2013, we received cash proceeds, net of cash divested, of $3 million, $1 million and $17 million, respectively, for divestitures. See Note 3 to the Consolidated Financial Statements.

[0000833444-15-000091:mdna:177]
During fiscal 2015, we made net purchases of investments of $2 million. This represented the purchase of $290 million of investments primarily consisting of exchange traded equity and fixed income funds, which are classified as available-for-sale investments. These investments were classified as restricted as they related to funding for asbestos matters. See Note 12 to the Consolidated Financial Statements for further details on asbestos. The purchases were partially offset by $288 million of receipts, primarily related to the maturity of time deposits. During fiscal 2014, we made net purchases of investments of $103 million. This primarily related to the purchase of time deposits of $275 million and $62 million of trading securities which serve to partially offset changes in the market value of liabilities for an unfunded non-qualified defined contribution pension plan. These purchases were partially offset by the liquidation of the portfolio of investments held by our captive insurance companies which served as collateral for our insurable liabilities. We now provide letters of credit as collateral. During fiscal 2013, we made net purchases of investments of $45 million.

[0000833444-15-000091:mdna:178]
During fiscal 2014, we also generated $250 million in proceeds from the sale of our equity method investment in Atkore.  See Note 3 to our Consolidated Financial Statements.

[0000833444-15-000091:mdna:179]
Cash flow from financing activities

[0000833444-15-000091:mdna:180]
Cash flows from financing activities relate primarily to proceeds received from incurring debt and issuing stock, and cash used to repay debt, repurchase stock, and make dividend payments to shareholders.

[0000833444-15-000091:mdna:181]
During 2015, TIFSA issued €500 million aggregate principal amount of 1.375% notes due 2025, $750 million aggregate principal amount of 3.9% notes due 2026, and $750 million aggregate principal amount of 5.125% notes due 2045, which were fully and unconditionally guaranteed by the Company and TIFSCA. TIFSA received proceeds before issuance costs of approximately $2,059 million. During 2015, the Company used the net proceeds of the aforementioned offering and paid cash of $445 million to redeem the $364 million aggregate principal amount of 8.5% notes due 2019, resulting in a loss on extinguishment of debt of $81 million. This loss represents the make-whole premium related to the 2019 notes and was recorded in Other expense, net within the Consolidated Statements of Operations. See Note 9 to the Consolidated Financial Statements. In addition and subsequent to fiscal year end, on October 14, 2015, the Company redeemed its outstanding $242 million aggregate principal amount 7.0% notes due 2019 and $462 million aggregate principal amount 6.875% notes due 2021, which were classified as current as of September 25, 2015. Also, on October 15, 2015, the Company repaid $258 million aggregate principal amount of 3.375% notes due 2015, which matured on such date. See Note 21 to the Consolidated Financial Statements.

[0000833444-15-000091:mdna:182]
On August 7, 2015, TIFSA entered into an Amended and Restated Five-Year Senior Unsecured Credit Agreement in the aggregate amount of $1.5 billion (the “2015 Credit Agreement”). The 2015 Credit Agreement amends and restates TIFSA's existing Five-Year Senior Unsecured Credit Agreement, dated June 22, 2012 (the “2012 Credit Agreement”), which provided for revolving credit commitments in the aggregate amount of $1.0 billion, and which was scheduled to expire on June 22, 2017.  As of September 25, 2015 and September 26, 2014, there were no amounts drawn under our revolving credit facilities. See Note 9 to the Consolidated Financial Statements.

[0000833444-15-000091:mdna:183]
TIFSA's revolving credit facility contains customary terms and conditions, and financial covenants that limit the ratio of our debt to earnings before interest, taxes, depreciation, and amortization and that limit our ability to incur subsidiary debt or

[0000833444-15-000091:mdna:184]
grant liens on our property. Our indentures contain customary covenants including limits on negative pledges, subsidiary debt and sale/leaseback transactions. None of these covenants are considered restrictive to our business.

[0000833444-15-000091:mdna:185]
As of September 25, 2015 and September 26, 2014, TIFSA had no commercial paper outstanding. The maximum aggregate amount of unsecured commercial paper notes available to be issued, on a private placement basis, under the commercial paper program was $1.5 billion as of September 25, 2015.

[0000833444-15-000091:mdna:186]
Pursuant to our share repurchase program, we may repurchase Tyco shares from time to time in open market purchases at prevailing market prices, in negotiated transactions off the market, or pursuant to an approved trading plan in accordance with applicable regulations. In January 2013, the Company's Board of Directors approved a $600 million share repurchase program.  In March 2014, and September 2014, the Company's Board of Directors authorized an additional $1.75 billion and $1 billion in share repurchases, respectively.  During the year ended September 25, 2015, we repurchased approximately 10 million ordinary shares for $417 million.  During the year ended September 26, 2014, we repurchased approximately 42 million ordinary shares for $1.8 billion.  During the year ended September 27, 2013, we repurchased approximately 10 million ordinary shares for $300 million.  See Note 14 to the Consolidated Financial Statements.

[0000833444-15-000091:mdna:187]
During fiscal years 2015, 2014 and 2013, we paid cash dividends of approximately $324 million, $311 million and $288 million, respectively. See Note 14 to the Consolidated Financial Statements.

[0000833444-15-000091:mdna:188]
During fiscal 2014, we paid $66 million in cash to purchase the remaining ownership interest of a joint venture in Brazil, which is part of the Company's ROW Integrated Solutions & Services segment.  During both fiscal years 2015 and 2013, we paid cash of nil relating to purchases of ownership interests in joint ventures.

[0000833444-15-000091:mdna:189]
During fiscal year 2015, we paid contingent consideration of $24 million, $23 million of which related to the successful transfer of a business license in China to Tyco.

[0000833444-15-000091:mdna:190]
Management believes that cash generated by or available to us should be sufficient to fund our capital and operational business needs for the foreseeable future.

[0000833444-15-000091:mdna:191]
Commitments and Contingencies

[0000833444-15-000091:mdna:192]
For a detailed discussion of contingencies related to tax and litigation matters and governmental investigations, see Notes 6 and 12 to the Consolidated Financial Statements.

[0000833444-15-000091:mdna:193]
Contractual Obligations

[0000833444-15-000091:mdna:194]
Contractual obligations and commitments for debt, minimum lease payment obligations under non-cancelable operating leases and purchase obligations as of September 25, 2015 are as follows ($ in millions):

[0000833444-15-000091:mdna:195]
|  | Fiscal Year |  |  |  |  |
|  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Debt principal(1)(3) | $ | 962 |  |  | $ | — |  |  | $ | 67 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,101 |  |  | $ | 3,130 |  |
| Interest payments(2)(3) | 270 |  |  | 80 |  |  | 79 |  |  | 77 |  |  | 77 |  |  | 1,165 |  |  | 1,748 |  |
| Operating leases | 183 |  |  | 151 |  |  | 113 |  |  | 81 |  |  | 45 |  |  | 58 |  |  | 631 |  |
| Purchase obligations(4) | 353 |  |  | 44 |  |  | 2 |  |  | — |  |  | — |  |  | — |  |  | 399 |  |
| Total contractual cash obligations(5) | $ | 1,768 |  |  | $ | 275 |  |  | $ | 261 |  |  | $ | 158 |  |  | $ | 122 |  |  | $ | 3,324 |  |  | $ | 5,908 |  |

[0000833444-15-000091:mdna:196]
_______________________________________________________________________________

[0000833444-15-000091:mdna:197]
| (1) | Debt principal consists of the aggregate principal amount of our public debt outstanding, excluding debt discount or premium, swap activity and interest. |

[0000833444-15-000091:mdna:198]
| (2) | Interest payments consist of interest on our fixed interest rate debt. |

[0000833444-15-000091:mdna:199]
| (3) | After fiscal year end, on October 14, 2015, the Company completed the redemption of all of the outstanding $242 million aggregate principal amount of 7.0% notes due 2019 and $462 million aggregate principal amount of 6.875% notes due 2021. Interest payments in 2016 include a $172 million make-whole premium related to the redemption of these notes. In addition, on October 15, 2015, the Company repaid at maturity $258 million in principal amount of 3.375% notes due 2015. |

[0000833444-15-000091:mdna:200]
| (4) | Purchase obligations consist of commitments for purchases of goods and services. |

[0000833444-15-000091:mdna:201]
| (5) | Other long-term liabilities excluded from the above contractual obligation table primarily consist of the following: pension and postretirement costs (see Note 13 to the Consolidated Financial Statements), income taxes (see Note 6 to |

[0000833444-15-000091:mdna:202]
49

[0000833444-15-000091:mdna:203]
the Consolidated Financial Statements), warranties (see Note 10 to the Consolidated Financial Statements) and environmental liabilities (see Note 12 to the Consolidated Financial Statements). We are unable to estimate the timing of payment for these items due to the inherent uncertainties related to these obligations. However, the minimum required contributions to our pension plans are expected to be approximately $29 million in 2016 and we do not expect to make any material contributions in 2016 related to other postretirement benefit plans.

[0000833444-15-000091:mdna:204]
As of September 25, 2015, we recorded gross unrecognized tax benefits of $302 million and accrued interest and penalties of $40 million. We are unable to make a reasonably reliable estimate of the timing for the remaining payments in future years; therefore, such amounts have been excluded from the above contractual obligation table. However, based on the current status of its income tax audits, the Company does not believe the unrecognized tax benefits that may be resolved in the next twelve months will be material. Although the Company had unrecognized tax benefits that, if recognized, would affect the effective tax rate, the Company had net operating loss carryforwards which would offset the cash impact of any such recognition of unrecognized tax benefits relating to the current year.

[0000833444-15-000091:mdna:205]
In the normal course of business, we are liable for contract completion and product performance. In the opinion of management, such obligations will not significantly affect our financial position, results of operations or cash flows.

[0000833444-15-000091:mdna:206]
In connection with the 2012 Separation we entered into a liability sharing agreement regarding certain actions that were pending against Tyco prior to the 2012 Separation. Under the 2012 Tax Sharing Agreement, Pentair, Tyco and ADT share (i) certain pre-Distribution income tax liabilities that arise from adjustments made by tax authorities to Tyco Flow Control's, Tyco's and ADT's U.S. income tax returns, and (ii) payments required to be made by Tyco with respect to the 2007 Tax Sharing Agreement, excluding approximately $175 million of pre-2012 Separation related tax liabilities that were anticipated to be paid prior to the 2012 Separation (collectively, "Shared Tax Liabilities"). The Company will be responsible for the first $500 million of Shared Tax Liabilities. Pentair and ADT will share 42% and 58%, respectively, of the next $225 million of Shared Tax Liabilities. Pentair, ADT and Tyco will share 20%, 27.5% and 52.5%, respectively, of Shared Tax Liabilities above $725 million. The timing and amounts of these payments are subject to a number of uncertainties and could change. See Notes 6 and 12, respectively, to the Consolidated Financial Statements.

[0000833444-15-000091:mdna:207]
In connection with the 2007 Separation, we entered into a liability sharing agreement regarding certain actions that were pending against Tyco prior to the 2007 Separation. Under the 2007 Separation and Distribution Agreement and 2007 Tax Sharing Agreement, we have assumed 27%, Medtronic has assumed 42% and TE Connectivity has assumed 31% of certain Tyco pre-Separation contingent and other corporate liabilities, which, as of September 25, 2015, primarily relate to tax contingencies and potential actions with respect to the spin-offs or the distributions made or brought by any third party.

[0000833444-15-000091:mdna:208]
Backlog

[0000833444-15-000091:mdna:209]
We had a backlog of unfilled orders of $4,562 million and $4,857 million as of September 25, 2015 and September 26, 2014, respectively.

[0000833444-15-000091:mdna:210]
The Company's backlog includes recurring revenue-in-force and long-term deferred revenue for upfront fees from its NA and ROW Integrated Solutions & Services segments. Revenue-in-force represents 12 months' revenue associated with monitoring and maintenance services under contract in the security and fire business. Backlog by segment was as follows ($ in millions):

[0000833444-15-000091:mdna:211]
|  | NA Integrated Solutions& Services |  | ROWIntegrated Solutions& Services |  | GlobalProducts |  | Total |
| As of September 26, 2014 |  |  |  |  |  |  |  |
| Backlog | $ | 992 |  |  | $ | 997 |  |  | $ | 181 |  |  | $ | 2,170 |  |
| Recurring revenue in force | 1,243 |  |  | 1,140 |  |  | — |  |  | 2,383 |  |
| Deferred revenue | 266 |  |  | 38 |  |  | — |  |  | 304 |  |
| Total Backlog | $ | 2,501 |  |  | $ | 2,175 |  |  | $ | 181 |  |  | $ | 4,857 |  |
| As of September 25, 2015 |  |  |  |  |  |  |  |
| Backlog | $ | 1,035 |  |  | $ | 820 |  |  | $ | 195 |  |  | $ | 2,050 |  |
| Recurring revenue in force | 1,229 |  |  | 1,013 |  |  | — |  |  | 2,242 |  |
| Deferred revenue | 235 |  |  | 35 |  |  | — |  |  | 270 |  |
| Total Backlog | $ | 2,499 |  |  | $ | 1,868 |  |  | $ | 195 |  |  | $ | 4,562 |  |

[0000833444-15-000091:mdna:212]
Backlog decreased $295 million, or 6.1%, to $4,562 million as of September 25, 2015 as compared to $4,857 million in the prior year. The net decrease in backlog as of September 25, 2015 was driven primarily by the unfavorable impact of changes in foreign currency of $355 million, or 7.3%, primarily related to ROW Integrated Solutions & Services.  In addition, a divestiture of a business in our ROW Integrated Solutions & Services segment had an unfavorable impact of $104 million, or 2.1%.  These impacts were partially offset by an increase in NA Integrated Solutions & Services backlog and to a lesser extent, the favorable impact of acquisitions.

[0000833444-15-000091:mdna:213]
Guarantees

[0000833444-15-000091:mdna:214]
Certain of our business segments have guaranteed the performance of third-parties and provided financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from fiscal year 2015 through the completion of such transactions and would typically be triggered in the event of nonperformance. The Company's performance under the guarantees, if required, would not have a material effect on our financial position, results of operations or cash flows.

[0000833444-15-000091:mdna:215]
There are certain guarantees or indemnifications extended among Tyco, Medtronic, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 Separation and Distribution Agreements and the Tax Sharing Agreements. The guarantees primarily relate to certain contingent tax liabilities included in the Tax Sharing Agreements. At the time of the 2007 and 2012 Separations, we recorded liabilities necessary to recognize the fair value of such guarantees and indemnifications. See Note 6 to the Consolidated Financial Statements for further discussion of the Tax Sharing Agreements. In addition, prior to the 2007 and 2012 Separations we provided support in the form of financial and/or performance guarantees to various Medtronic, TE Connectivity, ADT and Tyco Flow Control operating entities. To the extent these guarantees were not assigned in connection with the 2007 and 2012 Separations, we assumed primary liability on any remaining such support. See Note 10 to the Consolidated Financial Statements for a discussion of these liabilities.

[0000833444-15-000091:mdna:216]
In disposing of assets or businesses, we often provide representations, warranties and/or indemnities to cover various risks including, for example, unknown damage to the assets, environmental risks involved in the sale of real estate, liability to investigate and remediate environmental contamination at waste disposal sites and manufacturing facilities, and unidentified tax liabilities and legal fees related to periods prior to disposition. We have no reason to believe that these uncertainties would have a material adverse effect on our financial position, results of operations or cash flows. We have recorded liabilities for known indemnifications included as part of environmental liabilities.

[0000833444-15-000091:mdna:217]
In the normal course of business, we are liable for contract completion and product performance. We record estimated product warranty costs at the time of sale. In the opinion of management, such obligations will not significantly affect our financial position, results of operations or cash flows.

[0000833444-15-000091:mdna:218]
During the year ended September 26, 2014, Tyco replaced available for sale investments held as collateral for the Company's insurable liabilities with letters of credit. As of September 25, 2015 and September 26, 2014, we had total outstanding letters of credit and bank guarantees of approximately $581 million and $662 million, respectively.

[0000833444-15-000091:mdna:219]
For a detailed discussion of guarantees and indemnifications, see Note 10 to the Consolidated Financial Statements.

[0000833444-15-000091:mdna:220]
Accounting Pronouncements

[0000833444-15-000091:mdna:221]
See Note 1 to the Consolidated Financial Statements for Recently Adopted Accounting Pronouncements and Recently Issued Accounting Pronouncements.

[0000833444-15-000091:mdna:222]
Non-U.S. GAAP Measure

[0000833444-15-000091:mdna:223]
In an effort to provide investors with additional information regarding our results as determined by U.S. GAAP, we also disclose the non-U.S. GAAP measure of organic revenue growth (decline). We believe that this measure is useful to investors in evaluating our operating performance for the periods presented. When read in conjunction with our U.S. GAAP revenue, it enables investors to better evaluate our operations without giving effect to fluctuations in foreign exchange rates and acquisition and divestiture activity, either of which may be significant from period to period. In addition, organic revenue growth (decline) is a factor we use in internal evaluations of the overall performance of our business. This measure is not a financial measure under U.S. GAAP and should not be considered as a substitute for revenue as determined in accordance with U.S. GAAP, and it may not be comparable to similarly titled measures reported by other companies. Organic revenue growth (decline) presented herein is defined as revenue growth (decline) excluding the effects of foreign currency fluctuations, acquisitions and divestitures and other changes that may not reflect underlying results and trends. Our organic growth (decline) calculations incorporate an estimate of prior year reported net revenue associated with acquired entities that have been fully integrated within the first year, and exclude prior year net revenue associated with entities that do not meet the criteria for discontinued operations which have been divested within the past year ("adjusted number"). We calculate the rate of organic

[0000833444-15-000091:mdna:224]
51

[0000833444-15-000091:mdna:225]
growth (decline) based on the adjusted number to better reflect the rate of growth (decline) of the combined business, in the case of acquisitions, or the remaining business, in the case of dispositions. We base the rate of organic growth (decline) for acquired businesses that are not fully integrated within the first year upon unadjusted historical net revenue.  Foreign currency fluctuations are calculated by subtracting (i) the U.S. dollar equivalent of local currencies for the current period using monthly weighted average exchange rates for the prior period from (ii) the U.S. dollar equivalent of local currencies for the current period using monthly weighted average exchange rates for the current period. We may use organic revenue growth (decline) as a component of our compensation programs.

[0000833444-15-000091:mdna:226]
The tables below detail the components of organic revenue growth and reconciles the non-U.S. GAAP measure to U.S. GAAP net revenue growth.

[0000833444-15-000091:mdna:227]
Fiscal 2015

[0000833444-15-000091:mdna:228]
|  | NetRevenueforFiscal 2014 |  | Base YearAdjustments(Divestitures) |  | AdjustedFiscal 2014Base Revenue |  | ForeignCurrency |  | Acquisitions |  | OrganicRevenue |  | Organic Growth (Decline)Percentage(1) |  | NetRevenueforFiscal 2015 |
|  | ($ in millions) |
| NA Integrated Solutions & Services | $ | 3,876 |  |  | $ | — |  |  | $ | 3,876 |  |  | $ | (52 | ) |  | $ | 11 |  |  | $ | 44 |  |  | 1.1 | % |  | $ | 3,879 |  |
| ROW Integrated Solutions & Services | 3,912 |  |  | (67 | ) |  | 3,845 |  |  | (422 | ) |  | 60 |  |  | (51 | ) |  | (1.3 | )% |  | 3,432 |  |
| Global Products | 2,544 |  |  | — |  |  | 2,544 |  |  | (148 | ) |  | 128 |  |  | 67 |  |  | 2.6 | % |  | 2,591 |  |
| Total Net Revenue | $ | 10,332 |  |  | $ | (67 | ) |  | $ | 10,265 |  |  | $ | (622 | ) |  | $ | 199 |  |  | $ | 60 |  |  | 0.6 | % |  | $ | 9,902 |  |

[0000833444-15-000091:mdna:229]
_______________________________________________________________________________

[0000833444-15-000091:mdna:230]
| (1) | Organic revenue growth percentage based on adjusted fiscal 2014 base revenue. |

[0000833444-15-000091:mdna:231]
Fiscal 2014

[0000833444-15-000091:mdna:232]
|  | NetRevenueforFiscal 2013 |  | Base YearAdjustments(Divestitures) |  | AdjustedFiscal 2013Base Revenue |  | ForeignCurrency |  | Acquisitions |  | OrganicRevenue |  | OrganicGrowth Percentage(1) |  | NetRevenueforFiscal 2014 |
|  | ($ in millions) |
| NA Integrated Solutions & Services | $ | 3,891 |  |  | $ | (42 | ) |  | $ | 3,849 |  |  | $ | (29 | ) |  | $ | 19 |  |  | $ | 37 |  |  | 1.0 | % |  | $ | 3,876 |  |
| ROW Integrated Solutions & Services | 3,828 |  |  | (67 | ) |  | 3,761 |  |  | (46 | ) |  | 119 |  |  | 78 |  |  | 2.1 | % |  | 3,912 |  |
| Global Products | 2,339 |  |  | 2 |  |  | 2,341 |  |  | (7 | ) |  | 63 |  |  | 147 |  |  | 6.3 | % |  | 2,544 |  |
| Total Net Revenue | $ | 10,058 |  |  | $ | (107 | ) |  | $ | 9,951 |  |  | $ | (82 | ) |  | $ | 201 |  |  | $ | 262 |  |  | 2.6 | % |  | $ | 10,332 |  |

[0000833444-15-000091:mdna:233]
_______________________________________________________________________________

[0000833444-15-000091:mdna:234]
| (1) | Organic revenue growth percentage based on adjusted fiscal 2013 base revenue. |

[0000833444-15-000091:mdna:235]
Forward-Looking Information

[0000833444-15-000091:mdna:236]
| • | overall economic and business conditions, and overall demand for Tyco's goods and services; |

[0000833444-15-000091:mdna:237]
| • | economic and competitive conditions in the industries, end markets and regions served by our businesses; |

[0000833444-15-000091:mdna:238]
| • | changes in legal and tax requirements (including tax rate changes, new tax laws or treaties and revised tax law interpretations); |

[0000833444-15-000091:mdna:239]
| • | our, and our employees' and agents' ability to comply with complex and continually changing laws and regulations that govern our international operations, including the U.S. Foreign Corrupt Practices Act, similar anti-bribery laws in other jurisdictions, a variety of export control, customs, privacy, currency exchange control and transfer pricing regulations, and our corporate policies governing these matters; |

[0000833444-15-000091:mdna:240]
| • | the outcome of litigation, arbitrations and governmental proceedings; |

[0000833444-15-000091:mdna:241]
| • | effect of income tax audits, litigation, settlements and appeals; |

[0000833444-15-000091:mdna:242]
| • | our ability to repay or refinance our outstanding indebtedness as it matures; |

[0000833444-15-000091:mdna:243]
| • | our ability to operate within the limitations imposed by financing arrangements and to maintain our credit ratings; |

[0000833444-15-000091:mdna:244]
| • | interest rate fluctuations and other changes in borrowing costs, or other consequences of volatility in the capital or credit markets; |

[0000833444-15-000091:mdna:245]
| • | other capital market conditions, including availability of funding sources; |

[0000833444-15-000091:mdna:246]
| • | currency exchange rate fluctuations; |

[0000833444-15-000091:mdna:247]
| • | availability of and fluctuations in the prices of key raw materials; |

[0000833444-15-000091:mdna:248]
| • | changes affecting customers or suppliers; |

[0000833444-15-000091:mdna:249]
| • | economic and political conditions in international markets, including governmental changes and restrictions on the ability to transfer capital across borders; |

[0000833444-15-000091:mdna:250]
| • | our ability to achieve anticipated cost savings; |

[0000833444-15-000091:mdna:251]
| • | our ability to predict end-user demand for new or enhanced product or service offerings; |

[0000833444-15-000091:mdna:252]
| • | our ability to execute our portfolio refinement and acquisition strategies, including successfully integrating acquired operations; |

[0000833444-15-000091:mdna:253]
| • | potential impairment of our goodwill, intangibles and/or our long-lived assets; |

[0000833444-15-000091:mdna:254]
| • | our ability to realize the intended benefits of the 2012 Separation, including the integration of our commercial security and fire protection businesses; |

[0000833444-15-000091:mdna:255]
| • | other risks associated with the 2012 Separation, for example the risk that we may be liable for certain contingent liabilities of the spun-off entities if they were to become insolvent; |

[0000833444-15-000091:mdna:256]
| • | risks associated with our jurisdiction of incorporation, including the possibility of reduced flexibility with respect to certain aspects of capital management and corporate governance, increased or different regulatory burdens, and the possibility that we may not realize anticipated tax benefits; |

[0000833444-15-000091:mdna:257]
| • | the possible effects on Tyco of future legislation in the United States that may limit or eliminate potential U.S. tax benefits resulting from Tyco International's incorporation outside of the United States or deny U.S. government contracts to Tyco based upon its jurisdiction of incorporation; |

[0000833444-15-000091:mdna:258]
| • | natural events such as severe weather, fires, floods and earthquakes; and |

[0000833444-15-000091:mdna:259]
| • | acts of terrorism, cyber-attacks or our inability to maintain adequate security related information networks and data. |
