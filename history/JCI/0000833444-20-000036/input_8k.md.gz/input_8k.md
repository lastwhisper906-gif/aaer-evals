# JCI 8-K — 0000833444-20-000034 filed 2020-07-31

## item codes, every 8-K on or before 2020-07-31

- 2020-07-31 0000833444-20-000034 — 2.02, 9.01
- 2020-06-12 0000833444-20-000020 — 8.01
- 2020-05-01 0000833444-20-000013 — 2.02, 9.01
- 2020-03-12 0000833444-20-000010 — 5.02
- 2020-03-06 0000833444-20-000008 — 5.07
- 2020-01-31 0000833444-20-000003 — 2.02, 9.01
- 2019-12-06 0001193125-19-308301 — 1.01, 1.02, 2.03, 9.01
- 2019-11-07 0000833444-19-000048 — 5.02, 9.01
- 2019-11-07 0000833444-19-000046 — 2.02, 9.01
- 2019-08-21 0000833444-19-000043 — 8.01
- 2019-07-31 0000833444-19-000038 — 2.02, 9.01
- 2019-07-23 0000833444-19-000035 — 5.02, 8.01, 9.01
- 2019-07-02 0000833444-19-000033 — 1.02, 8.01
- 2019-06-05 0001193125-19-165565 — 8.01
- 2019-05-30 0001193125-19-160205 — 8.01, 9.01
- 2019-05-16 0001193125-19-148262 — 8.01, 9.01
- 2019-05-07 0001193125-19-139826 — 5.04, 9.01
- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2020-07-31

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-20-000034:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq3f.htm
EX-99.1

[0000833444-20-000034:8k_2_02:2]
Document

[0000833444-20-000034:8k_2_02:3]
Exhibit 99.1

[0000833444-20-000034:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-20-000034:8k_2_02:5]
JOHNSON CONTROLS REPORTS FISCAL Q3 RESULTS DEMONSTRATING STRONG EXECUTION IN AN UNPRECEDENTED TIME; PROVIDES Q4 GUIDANCE

[0000833444-20-000034:8k_2_02:6]
________________________________________________________________________________

[0000833444-20-000034:8k_2_02:7]
▪Adjusted EPS of $0.67, up 3% versus prior year; GAAP EPS was a loss of $0.24

[0000833444-20-000034:8k_2_02:8]
▪Significant cost mitigation actions both temporary and permanent executed; tracking ahead of expectations

[0000833444-20-000034:8k_2_02:9]
▪Adjusted EBIT margin expansion of 70bps year-over-year; GAAP EBIT margin of (1.2%)

[0000833444-20-000034:8k_2_02:10]
▪Adjusted free cash flow of $0.8 billion; GAAP free cash flow of $0.7 billion

[0000833444-20-000034:8k_2_02:11]
▪Share repurchase program resumed

[0000833444-20-000034:8k_2_02:12]
▪Announced the launch of OpenBlue, our new digital platform

[0000833444-20-000034:8k_2_02:13]
▪Company provides Q4 adjusted earnings per share guidance range of $0.68 to $0.72; full year guidance of $2.16 to $2.20, representing a year-over-year increase of 10-12%

[0000833444-20-000034:8k_2_02:14]
________________________________________________________________________________

[0000833444-20-000034:8k_2_02:15]
CORK, Ireland, July 31, 2020 -- Johnson Controls International plc (NYSE: JCI) today reported a fiscal third quarter 2020 GAAP loss per share from continuing operations, including special items, of $0.24. Excluding these items, adjusted earnings per share (“EPS”) from continuing operations was $0.67, up 3% versus the prior year period (see attached footnotes for non-GAAP reconciliation).

[0000833444-20-000034:8k_2_02:16]
Sales of $5.3 billion decreased 17% compared to the prior year and declined 16% organically, driven by the COVID-19 pandemic.

[0000833444-20-000034:8k_2_02:17]
GAAP earnings before interest and taxes (“EBIT”) was a loss of $65 million and EBIT margin was (1.2%) driven primarily by a restructuring and impairment charge.  Adjusted EBIT was $707 million and adjusted EBIT margin was 13.2%, up 70 basis points compared to prior year results.

[0000833444-20-000034:8k_2_02:18]
“As we continue to navigate through an unprecedented environment we have maintained focus on our two top priorities – protecting the health and safety of our employees and their families, as well as supporting the continuous functionality of our customers’ and partners’ critical infrastructure and essential facilities,” said George Oliver, chairman and CEO. “We have made significant progress in securing our facilities, implementing new policies, and ensuring the wellbeing of our employees, our customers, and their building occupants.”

[0000833444-20-000034:8k_2_02:19]
“At the same time, the decisive actions we took to control costs from the very beginning of the COVID-19 pandemic, have resulted in significant benefits in the quarter,” Oliver continued.

[0000833444-20-000034:8k_2_02:20]
“Although market conditions remain uncertain and visibility still somewhat limited, we are well positioned with improved operating fundamentals, a strong balance sheet and cash flow, and a leading position in intelligent and sustainable building solutions. It is because of our market leading position that we are excited to announce OpenBlue, our new digital platform. OpenBlue will allow our customers to manage

[0000833444-20-000034:8k_2_02:21]
Page 1 of 18

[0000833444-20-000034:8k_2_02:22]
their operations more systemically and seamlessly, delivering buildings that have memory, intelligence and a unique identity. The platform is infused with award-winning artificial intelligence, combining data from both inside and outside of buildings leveraging the cloud to provide unique occupant experiences. OpenBlue is the culmination of years of R&D led by our incredible engineers and data scientists around the globe, and reflects how we think about buildings evolving from inflexible assets to sustainable dynamic resources.  As the world looks to re-open economies while dealing with the global pandemic, OpenBlue solutions contain innovative technologies that enhance our core capabilities, delivering the highest air quality and the safest and most secure buildings, to ensure an efficient return to a healthy workplace,” Oliver added.

[0000833444-20-000034:8k_2_02:23]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-20-000034:8k_2_02:24]
($ millions, except per-share amounts)

[0000833444-20-000034:8k_2_02:25]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the fiscal third quarter of 2019. The results of Power Solutions are reported as discontinued operations in all periods presented.

[0000833444-20-000034:8k_2_02:26]
Organic sales growth, organic EBITA growth, segment EBITA, adjusted segment EBITA, EBIT, adjusted EBIT, adjusted EPS from continuing operations and adjusted free cash flow are non-GAAP financial measures. For a reconciliation of these non-GAAP measures and detail of the special items, refer to the attached footnotes.  A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-20-000034:8k_2_02:27]
|  | GAAP | GAAP |  | Adjusted | Adjusted |  |
|  | Q3 2019 | Q3 2020 |  | Q3 2019 | Q3 2020 | Change |
| Sales | $6,451 | $5,343 |  | $6,451 | $5,343 | (17%) |
| Segment EBITA | 832 | 839 |  | 992 | 850 | (14%) |
| EBIT | 583 | (65) |  | 809 | 707 | (13%) |
| Net income (loss) fromcontinuing operations | 141 | (182) |  | 565 | 502 | (11%) |
| Diluted EPS from continuing operations | $0.16 | ($0.24) |  | $0.65 | $0.67 | +3% |

[0000833444-20-000034:8k_2_02:28]
Special items in the quarter resulted in a $0.92 charge and included the following significant items:

[0000833444-20-000034:8k_2_02:29]
•Non-cash goodwill impairment charge of $424 million pre-tax ($0.57 per share) related to our Retail business.

[0000833444-20-000034:8k_2_02:30]
•Restructuring and impairment charge of $186 million pre-tax ($0.21 per share) related primarily to cost reduction initiatives.

[0000833444-20-000034:8k_2_02:31]
•Non-cash net mark-to-market adjustments of $132 million pre-tax ($0.13 per share) related primarily to certain pension plans.

[0000833444-20-000034:8k_2_02:32]
Page 2 of 18

[0000833444-20-000034:8k_2_02:33]
BUSINESS RESULTS

[0000833444-20-000034:8k_2_02:34]
Building Solutions North America

[0000833444-20-000034:8k_2_02:35]
|  | GAAP | GAAP |  | Adjusted | Adjusted |  |
|  | Q3 2019 | Q3 2020 |  | Q3 2019 | Q3 2020 | Change |
| Sales | $2,327 | $2,020 |  | $2,327 | $2,020 | (13%) |
| Segment EBITA | $300 | $307 |  | $310 | $311 | Flat |
| Segment EBITA margin % | 12.9% | 15.2% |  | 13.3% | 15.4% | 210bps |

[0000833444-20-000034:8k_2_02:36]
Sales in the quarter of $2.0 billion, decreased 13% versus the prior year. Organic sales were also down 13% versus the prior year, driven by a decline in project installations and, to a lesser extent, service.  Growth in Performance Solutions was more than offset by a decline in Fire & Security and HVAC & Controls.

[0000833444-20-000034:8k_2_02:37]
Orders in the quarter, excluding M&A and adjusted for foreign currency, decreased 16% year-over-year driven by lower demand due to the COVID-19 pandemic.  Backlog at the end of the quarter of $5.8 billion increased 2% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-20-000034:8k_2_02:38]
Adjusted segment EBITA was $311 million, essentially flat with the prior year. Adjusted segment EBITA margin of 15.4% expanded 210 basis points versus the prior year driven by significant cost mitigation actions taken in the quarter to offset the volume decline.

[0000833444-20-000034:8k_2_02:39]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-20-000034:8k_2_02:40]
|  | GAAP | GAAP |  | Adjusted | Adjusted |  |
|  | Q3 2019 | Q3 2020 |  | Q3 2019 | Q3 2020 | Change |
| Sales | $922 | $756 |  | $922 | $756 | (18%) |
| Segment EBITA | $101 | $62 |  | $103 | $62 | (40%) |
| Segment EBITA margin % | 11.0% | 8.2% |  | 11.2% | 8.2% | (300bps) |

[0000833444-20-000034:8k_2_02:41]
Sales in the quarter of $756 million decreased 18% versus the prior year. Organic sales declined 15% versus the prior year driven by a decline in project installations and, to a lesser extent, service.  Volume declined across all regions and platforms.

[0000833444-20-000034:8k_2_02:42]
Page 3 of 18

[0000833444-20-000034:8k_2_02:43]
Orders in the quarter, excluding M&A and adjusted for foreign currency, decreased 20% year-over-year driven by lower demand due to the COVID-19 pandemic.  Backlog at the end of the quarter of $1.7 billion increased 2% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-20-000034:8k_2_02:44]
Adjusted segment EBITA was $62 million, down approximately 40% versus the prior year. Adjusted segment EBITA margin of 8.2% declined 300 basis points over the prior year, including a 40 basis point headwind related to foreign currency.  Adjusting for foreign currency, the underlying margin declined 260 basis points driven by the significant volume declines, resulting from closures across the regions which more than offset positive mix and mitigating cost actions.

[0000833444-20-000034:8k_2_02:45]
Building Solutions Asia Pacific

[0000833444-20-000034:8k_2_02:46]
|  | GAAP | GAAP |  | Adjusted | Adjusted |  |
|  | Q3 2019 | Q3 2020 |  | Q3 2019 | Q3 2020 | Change |
| Sales | $691 | $588 |  | $691 | $588 | (15%) |
| Segment EBITA | $98 | $92 |  | $98 | $92 | (6%) |
| Segment EBITA margin % | 14.2% | 15.6% |  | 14.2% | 15.6% | 140bps |

[0000833444-20-000034:8k_2_02:47]
Sales in the quarter of $588 million decreased 15% versus the prior year. Organic sales declined 12% versus the prior year primarily driven by a decline in project installations and, to a lesser extent, service.   China rebounded significantly from the previous quarter, although declines accelerated in certain other parts of the region.

[0000833444-20-000034:8k_2_02:48]
Orders in the quarter, excluding M&A and adjusted for foreign currency, decreased 10% year-over-year driven by lower demand due to the COVID-19 pandemic.  Backlog at the end of the quarter of $1.6 billion increased 4% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-20-000034:8k_2_02:49]
Adjusted segment EBITA was $92 million, down 6% versus the prior year. Adjusted segment EBITA margin of 15.6% expanded 140 basis points over the prior year as favorable mix and the benefit of mitigating cost actions more than offset the volume decline.

[0000833444-20-000034:8k_2_02:50]
Global Products

[0000833444-20-000034:8k_2_02:51]
|  | GAAP | GAAP |  | Adjusted | Adjusted |  |
|  | Q3 2019 | Q3 2020 |  | Q3 2019 | Q3 2020 | Change |
| Sales | $2,511 | $1,979 |  | $2,511 | $1,979 | (21%) |
| Segment EBITA | $333 | $378 |  | $481 | $385 | (20%) |
| Segment EBITA margin % | 13.3% | 19.1% |  | 19.2% | 19.5% | 30bps |

[0000833444-20-000034:8k_2_02:52]
Page 4 of 18

[0000833444-20-000034:8k_2_02:53]
Sales in the quarter of $2.0 billion decreased 21% versus the prior year. Organic sales declined 20% versus the prior year with declines across Building Management Systems, HVAC & Refrigeration Equipment and Specialty Products.

[0000833444-20-000034:8k_2_02:54]
Adjusted segment EBITA was $385 million, down 20% versus the prior year. Adjusted segment EBITA margin of 19.5% expanded 30 basis points over the prior year as positive price/cost as well as the benefit of significant mitigating cost actions more than offset the volume decline.

[0000833444-20-000034:8k_2_02:55]
Corporate

[0000833444-20-000034:8k_2_02:56]
|  | GAAP | GAAP |  | Adjusted | Adjusted |  |
|  | Q3 2019 | Q3 2020 |  | Q3 2019 | Q3 2020 | Change |
| Corporate expense | $70 | ($67) |  | ($90) | ($48) | (47%) |

[0000833444-20-000034:8k_2_02:57]
Adjusted Corporate expense was $48 million in the quarter, a decrease of 47% compared to the prior year, driven primarily by mitigating cost actions, continued productivity savings and cost synergies, and ongoing cost reductions related to the Power Solutions sale.

[0000833444-20-000034:8k_2_02:58]
OTHER ITEMS

[0000833444-20-000034:8k_2_02:59]
▪In a separate release, the Company launched OpenBlue, its new digital platform.

[0000833444-20-000034:8k_2_02:60]
▪Cash provided by operating activities from continuing operations was $0.8 billion and capital expenditures were $0.1 billion in the quarter, resulting in free cash flow from continuing operations of approximately $0.7 billion.  Adjusted free cash flow was $0.8 billion, which excludes net cash outflows of less than $0.1 billion, primarily related to restructuring and integration costs.

[0000833444-20-000034:8k_2_02:61]
▪As previously disclosed, in April 2020, the Company raised $675 million via European financing arrangements, with an average interest rate of 1.0% and a 6-month term, and raised $575 million in bank term loans, with an average interest rate of 2.7% and a 1-year term.

[0000833444-20-000034:8k_2_02:62]
FISCAL Q4 GUIDANCE

[0000833444-20-000034:8k_2_02:63]
The Company has provided the below guidance related to the fourth quarter of fiscal 2020.

[0000833444-20-000034:8k_2_02:64]
Organic revenue decline                                                                      (9% – 11%)

[0000833444-20-000034:8k_2_02:65]
Net EBIT decrementals, including synergies and productivity              (low-teens)

[0000833444-20-000034:8k_2_02:66]
Weighted-average shares                                                                   ~737M

[0000833444-20-000034:8k_2_02:67]
Adjusted EPS                                                                                       $0.68 to $0.72

[0000833444-20-000034:8k_2_02:68]
Page 5 of 18

[0000833444-20-000034:8k_2_02:69]
JOHNSON CONTROLS CONTACTS:

[0000833444-20-000034:8k_2_02:70]
| INVESTORS: | MEDIA: |  |  |  |
| Antonella Franzen | Phil Clement |  |  |  |
| Direct: 609.720.4665 | Direct: 414.208.5161 |  |  |  |
| Email: antonella.franzen@jci.com | Email: phil.clement@jci.com |  |  |  |
| Ryan Edelman | Fraser Engerman |  |  |  |
| Direct: 609.720.4545 | Direct: 414.308.8321 |  |  |  |
| Email: ryan.edelman@jci.com | Email: fraser.engerman@jci.com |  |  |  |

[0000833444-20-000034:8k_2_02:71]
###

[0000833444-20-000034:8k_2_02:72]
About Johnson Controls:

[0000833444-20-000034:8k_2_02:73]
At Johnson Controls, we transform the environments where people live, work, learn and play. From optimizing building performance to improving safety and enhancing comfort, we drive the outcomes that matter most. We deliver our promise in industries such as healthcare, education, data centers, and manufacturing. With a global team of 105,000 experts in more than 150 countries and over 130 years of innovation, we are the power behind our customers’ mission. Our leading portfolio of building technology and solutions includes some of the most trusted names in the industry, such as Tyco®, YORK®, Metasys®, Ruskin®, Titus®, Frick®, PENN®, Sabroe®, Simplex®, Ansul® and Grinnell®. For more information, visit www.johnsoncontrols.com or follow us @johnsoncontrols on Twitter

[0000833444-20-000034:8k_2_02:74]
###

[0000833444-20-000034:8k_2_02:75]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-20-000034:8k_2_02:76]
Page 6 of 18

[0000833444-20-000034:8k_2_02:77]
Solutions business, changes in tax laws (including but not limited to the Tax Cuts and Jobs Act enacted in December 2017), regulations, rates, policies or interpretations, the loss of key senior management, the tax treatment of recent portfolio transactions, significant transaction costs and/or unknown liabilities associated with such transactions, the outcome of actual or potential litigation relating to such transactions, the risk that disruptions from recent transactions will harm Johnson Controls’ business, the strength of the U.S. or other economies, changes to laws or policies governing foreign trade, including increased tariffs or trade restrictions, energy and commodity prices, the availability of raw materials and component products, currency exchange rates, maintaining the capacity, reliability and security of our information technology infrastructure, the risk of infringement or expiration of intellectual property rights, work stoppages, union negotiations, labor disputes and other matters associated with the labor force, the outcome of litigation and governmental proceedings and cancellation of or changes to commercial arrangements.  A detailed discussion of risks related to Johnson Controls’ business is included in the section entitled “Risk Factors” in Johnson Controls’ Annual Report on Form 10-K for the 2019 fiscal year filed with the SEC on November 21, 2019, which is available at www.sec.gov and www.johnsoncontrols.com under the “Investors” tab. The description of certain of these risks is supplemented in Item 1A of Part II of Johnson Controls’ subsequently filed Quarterly Reports on Form 10-Q. Shareholders, potential investors and others should consider these factors in evaluating the forward-looking statements and should not place undue reliance on such statements. The forward-looking statements included in this communication are made only as of the date of this document, unless otherwise specified, and, except as required by law, Johnson Controls assumes no obligation, and disclaims any obligation, to update such statements to reflect events or circumstances occurring after the date of this communication.

[0000833444-20-000034:8k_2_02:78]
###

[0000833444-20-000034:8k_2_02:79]
Non-GAAP Financial Information

[0000833444-20-000034:8k_2_02:80]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include restructuring and impairment costs, transaction costs, integration costs, net mark-to-market adjustments, and discrete tax items. Financial information regarding organic sales, EBIT, EBIT margin, segment EBITA, adjusted segment EBITA, adjusted organic segment EBITA, adjusted segment EBITA margin, adjusted corporate expense, free cash flow, adjusted free cash flow, and adjusted net income (loss) from continuing operations are also presented, which are non-GAAP performance measures. Adjusted segment EBITA excludes special items such as transaction costs and integration costs because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.  For further information on the calculation of thee non-GAAP measures and a reconciliation of these non-GAAP measures, refer to the attached footnotes.

[0000833444-20-000034:8k_2_02:81]
###

[0000833444-20-000034:8k_2_02:82]
Page 7 of 18

[0000833444-20-000034:8k_2_02:83]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |  |  |  |  |  |  |
|  |  | Three Months Ended June 30, |  |  |  |  |
|  |  | 2020 |  |  | 2019 |  |
| Net sales |  | $ | 5,343 |  |  |  | $ | 6,451 |  |  |
| Cost of sales |  | 3,511 |  |  |  | 4,307 |  |  |
|  | Gross profit | 1,832 |  |  |  | 2,144 |  |  |
| Selling, general and administrative expenses |  | (1,334) |  |  |  | (1,388) |  |  |
| Restructuring and impairment costs |  | (610) |  |  |  | (235) |  |  |
| Net financing charges |  | (58) |  |  |  | (119) |  |  |
| Equity income |  | 47 |  |  |  | 62 |  |  |
| Income (loss) from continuing operations before income taxes |  | (123) |  |  |  | 464 |  |  |
| Income tax provision (benefit) |  | (1) |  |  |  | 239 |  |  |
| Income (loss) from continuing operations |  | (122) |  |  |  | 225 |  |  |
| Income from discontinued operations, net of tax |  | — |  |  |  | 4,051 |  |  |
| Net income (loss) |  | (122) |  |  |  | 4,276 |  |  |
| Less: Income from continuing operations attributable to noncontrolling interests |  | 60 |  |  |  | 84 |  |  |
| Less: Income from discontinued operations attributable to noncontrolling interests |  | — |  |  |  | — |  |  |
| Net income (loss) attributable to JCI |  | $ | (182) |  |  |  | $ | 4,192 |  |  |
| Income (loss) from continuing operations |  | $ | (182) |  |  |  | $ | 141 |  |  |
| Income from discontinued operations |  | — |  |  |  | 4,051 |  |  |
| Net income (loss) attributable to JCI |  | $ | (182) |  |  |  | $ | 4,192 |  |  |
| Diluted earnings (loss) per share from continuing operations |  | $ | (0.24) |  |  |  | $ | 0.16 |  |  |
| Diluted earnings per share from discontinued operations |  | — |  |  |  | 4.63 |  |  |
| Diluted earnings (loss) per share |  | $ | (0.24) |  |  |  | $ | 4.79 |  |  |
| Diluted weighted average shares |  | 744.0 |  |  |  | 875.2 |  |  |
| Shares outstanding at period end |  | 744.0 |  |  |  | 795.7 |  |  |

[0000833444-20-000034:8k_2_02:84]
Page 8 of 18

[0000833444-20-000034:8k_2_02:85]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |  |  |  |  |  |
|  |  | Nine Months Ended June 30, |  |  |  |
|  |  | 2020 |  |  | 2019 |
| Net sales |  | $ | 16,363 |  |  |  | $ | 17,694 |  |
| Cost of sales |  | 10,927 |  |  |  | 11,981 |  |
|  | Gross profit | 5,436 |  |  |  | 5,713 |  |
| Selling, general and administrative expenses |  | (4,212) |  |  |  | (4,284) |  |
| Restructuring and impairment costs |  | (783) |  |  |  | (235) |  |
| Net financing charges |  | (169) |  |  |  | (302) |  |
| Equity income |  | 110 |  |  |  | 137 |  |
| Income from continuing operations before income taxes |  | 382 |  |  |  | 1,029 |  |
| Income tax provision |  | 77 |  |  |  | 394 |  |
| Income from continuing operations |  | 305 |  |  |  | 635 |  |
| Income from discontinued operations, net of tax |  | — |  |  |  | 4,598 |  |
| Net income |  | 305 |  |  |  | 5,233 |  |
| Less: Income from continuing operations attributable to noncontrolling interests |  | 115 |  |  |  | 147 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests |  | — |  |  |  | 24 |  |
| Net income attributable to JCI |  | $ | 190 |  |  |  | $ | 5,062 |  |
| Income from continuing operations |  | $ | 190 |  |  |  | $ | 488 |  |
| Income from discontinued operations |  | — |  |  |  | 4,574 |  |
| Net income attributable to JCI |  | $ | 190 |  |  |  | $ | 5,062 |  |
| Diluted earnings per share from continuing operations |  | $ | 0.25 |  |  |  | $ | 0.54 |  |
| Diluted earnings per share from discontinued operations |  | — |  |  |  | 5.07 |  |
| Diluted earnings per share |  | $ | 0.25 |  |  |  | $ | 5.61 |  |
| Diluted weighted average shares |  | 758.9 |  |  |  | 902.2 |  |
| Shares outstanding at period end |  | 744.0 |  |  |  | 795.7 |  |

[0000833444-20-000034:8k_2_02:86]
Page 9 of 18

[0000833444-20-000034:8k_2_02:87]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |  |  |  |  |
|  |  | June 30,2020 |  | September 30,2019 |
| ASSETS |  |  |  |  |
| Cash and cash equivalents |  | $ | 2,342 |  |  | $ | 2,805 |  |
| Accounts receivable - net |  | 5,344 |  |  | 5,770 |  |
| Inventories |  | 1,996 |  |  | 1,814 |  |
| Assets held for sale |  | 89 |  |  | 98 |  |
| Other current assets |  | 1,369 |  |  | 1,906 |  |
|  | Current assets | 11,140 |  |  | 12,393 |  |
| Property, plant and equipment - net |  | 3,041 |  |  | 3,348 |  |
| Goodwill |  | 17,759 |  |  | 18,178 |  |
| Other intangible assets - net |  | 5,364 |  |  | 5,632 |  |
| Investments in partially-owned affiliates |  | 834 |  |  | 853 |  |
| Noncurrent assets held for sale |  | 199 |  |  | 60 |  |
| Other noncurrent assets |  | 2,941 |  |  | 1,823 |  |
|  | Total assets | $ | 41,278 |  |  | $ | 42,287 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Short-term debt and current portion of long-term debt |  | $ | 2,423 |  |  | $ | 511 |  |
| Accounts payable and accrued expenses |  | 3,742 |  |  | 4,535 |  |
| Liabilities held for sale |  | 38 |  |  | 44 |  |
| Other current liabilities |  | 4,101 |  |  | 3,980 |  |
|  | Current liabilities | 10,304 |  |  | 9,070 |  |
| Long-term debt |  | 5,671 |  |  | 6,708 |  |
| Other noncurrent liabilities |  | 6,413 |  |  | 5,680 |  |
| Noncurrent liabilities held for sale |  | 17 |  |  | — |  |
| Shareholders' equity attributable to JCI |  | 17,805 |  |  | 19,766 |  |
| Noncontrolling interests |  | 1,068 |  |  | 1,063 |  |
|  | Total liabilities and equity | $ | 41,278 |  |  | $ | 42,287 |  |

[0000833444-20-000034:8k_2_02:88]
Page 10 of 18

[0000833444-20-000034:8k_2_02:89]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Three Months Ended June 30, |  |  |  |
|  |  |  |  |  |  | 2020 |  |  | 2019 |
| Operating Activities |  |  |  |  |  |  |  |  |  |
| Net income (loss) attributable to JCI from continuing operations |  |  |  |  |  | $ | (182) |  |  |  | $ | 141 |  |
| Income from continuing operations attributable to noncontrolling interests |  |  |  |  |  | 60 |  |  |  | 84 |  |
| Net income (loss) from continuing operations |  |  |  |  |  | (122) |  |  |  | 225 |  |
| Adjustments to reconcile net income (loss) from continuing operations to cash provided |  |  |  |  |  |  |  |  |  |
| by operating activities: |  |  |  |  |  |  |  |  |  |
|  |  | Depreciation and amortization |  |  |  | 202 |  |  |  | 203 |  |
|  |  | Pension and postretirement benefit expense (income) |  |  |  | 122 |  |  |  | (28) |  |
|  |  | Pension and postretirement contributions |  |  |  | (16) |  |  |  | (14) |  |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received |  |  |  | 20 |  |  |  | 73 |  |
|  |  | Deferred income taxes |  |  |  | (87) |  |  |  | (121) |  |
|  |  | Non-cash restructuring and impairment costs |  |  |  | 466 |  |  |  | 235 |  |
|  |  | Other - net |  |  |  | (33) |  |  |  | 75 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |  |  |  |
|  |  |  |  | Accounts receivable |  | 184 |  |  |  | (355) |  |
|  |  |  |  | Inventories |  | 56 |  |  |  | 32 |  |
|  |  |  |  | Other assets |  | 30 |  |  |  | (33) |  |
|  |  |  |  | Restructuring reserves |  | 96 |  |  |  | (25) |  |
|  |  |  |  | Accounts payable and accrued liabilities |  | (126) |  |  |  | (19) |  |
|  |  |  |  | Accrued income taxes |  | 41 |  |  |  | 360 |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 833 |  |  |  | 608 |  |
| Investing Activities |  |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  |  |  |  | (97) |  |  |  | (123) |  |
| Acquisition of businesses, net of cash acquired |  |  |  |  |  | (1) |  |  |  | (3) |  |
| Business divestitures, net of cash divested |  |  |  |  |  | — |  |  |  | 6 |  |
| Other - net |  |  |  |  |  | 77 |  |  |  | 16 |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (21) |  |  |  | (104) |  |
| Financing Activities |  |  |  |  |  |  |  |  |  |
| Increase (decrease) in short and long-term debt - net |  |  |  |  |  | 974 |  |  |  | (5,163) |  |
| Stock repurchases |  |  |  |  |  | — |  |  |  | (4,122) |  |
| Payment of cash dividends |  |  |  |  |  | (194) |  |  |  | (233) |  |
| Dividends paid to noncontrolling interests |  |  |  |  |  | (62) |  |  |  | — |  |
| Proceeds from the exercise of stock options |  |  |  |  |  | 3 |  |  |  | 60 |  |
| Employee equity-based compensation withholding |  |  |  |  |  | (1) |  |  |  | (3) |  |
|  |  |  |  |  | Cash provided (used) by financing activities from continuing operations | 720 |  |  |  | (9,461) |  |
| Discontinued Operations |  |  |  |  |  |  |  |  |  |
| Net cash used by operating activities |  |  |  |  |  | (47) |  |  |  | (385) |  |
| Net cash provided by investing activities |  |  |  |  |  | — |  |  |  | 12,733 |  |
| Net cash used by financing activities |  |  |  |  |  | (113) |  |  |  | (7) |  |
|  |  |  |  |  | Net cash flows provided (used) by discontinued operations | (160) |  |  |  | 12,341 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  |  |  |  | (36) |  |  |  | 14 |  |
| Changes in cash held for sale |  |  |  |  |  | — |  |  |  | 45 |  |
| Increase in cash, cash equivalents and restricted cash |  |  |  |  |  | $ | 1,336 |  |  |  | $ | 3,443 |  |

[0000833444-20-000034:8k_2_02:90]
Page 11 of 18

[0000833444-20-000034:8k_2_02:91]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  | Nine Months Ended June 30, |  |  |  |
|  |  |  |  |  |  | 2020 |  |  | 2019 |
| Operating Activities |  |  |  |  |  |  |  |  |  |
| Net income attributable to JCI from continuing operations |  |  |  |  |  | $ | 190 |  |  |  | $ | 488 |  |
| Income from continuing operations attributable to noncontrolling interests |  |  |  |  |  | 115 |  |  |  | 147 |  |
| Net income from continuing operations |  |  |  |  |  | 305 |  |  |  | 635 |  |
| Adjustments to reconcile net income from continuing operations to cash provided by |  |  |  |  |  |  |  |  |  |
| operating activities: |  |  |  |  |  |  |  |  |  |
|  |  | Depreciation and amortization |  |  |  | 616 |  |  |  | 625 |  |
|  |  | Pension and postretirement benefit expense (income) |  |  |  | 42 |  |  |  | (85) |  |
|  |  | Pension and postretirement contributions |  |  |  | (43) |  |  |  | (51) |  |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received |  |  |  | 9 |  |  |  | 6 |  |
|  |  | Deferred income taxes |  |  |  | (148) |  |  |  | 382 |  |
|  |  | Non-cash restructuring and impairment costs |  |  |  | 582 |  |  |  | 235 |  |
|  |  | Other - net |  |  |  | 23 |  |  |  | 108 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |  |  |  |
|  |  |  |  | Accounts receivable |  | 428 |  |  |  | (494) |  |
|  |  |  |  | Inventories |  | (205) |  |  |  | (289) |  |
|  |  |  |  | Other assets |  | (120) |  |  |  | (62) |  |
|  |  |  |  | Restructuring reserves |  | 58 |  |  |  | (84) |  |
|  |  |  |  | Accounts payable and accrued liabilities |  | (731) |  |  |  | (36) |  |
|  |  |  |  | Accrued income taxes |  | 683 |  |  |  | (179) |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 1,499 |  |  |  | 711 |  |
| Investing Activities |  |  |  |  |  |  |  |  |  |
| Capital expenditures |  |  |  |  |  | (347) |  |  |  | (401) |  |
| Acquisition of businesses, net of cash acquired |  |  |  |  |  | (59) |  |  |  | (16) |  |
| Business divestitures, net of cash divested |  |  |  |  |  | — |  |  |  | 12 |  |
| Other - net |  |  |  |  |  | 97 |  |  |  | 42 |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (309) |  |  |  | (363) |  |
| Financing Activities |  |  |  |  |  |  |  |  |  |
| Increase (decrease) in short and long-term debt - net |  |  |  |  |  | 807 |  |  |  | (3,619) |  |
| Stock repurchases |  |  |  |  |  | (1,467) |  |  |  | (5,122) |  |
| Payment of cash dividends |  |  |  |  |  | (596) |  |  |  | (712) |  |
| Proceeds from the exercise of stock options |  |  |  |  |  | 42 |  |  |  | 111 |  |
| Dividends paid to noncontrolling interests |  |  |  |  |  | (67) |  |  |  | (132) |  |
| Employee equity-based compensation withholding |  |  |  |  |  | (33) |  |  |  | (26) |  |
| Other - net |  |  |  |  |  | (2) |  |  |  | — |  |
|  |  |  |  |  | Cash used by financing activities from continuing operations | (1,316) |  |  |  | (9,500) |  |
| Discontinued Operations |  |  |  |  |  |  |  |  |  |
| Net cash provided (used) by operating activities |  |  |  |  |  | (255) |  |  |  | 117 |  |
| Net cash provided by investing activities |  |  |  |  |  | — |  |  |  | 12,580 |  |
| Net cash used by financing activities |  |  |  |  |  | (113) |  |  |  | (35) |  |
|  |  |  |  |  | Net cash flows provided (used) by discontinued operations | (368) |  |  |  | 12,662 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash |  |  |  |  |  | 28 |  |  |  | (24) |  |
| Changes in cash held for sale |  |  |  |  |  | — |  |  |  | 15 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash |  |  |  |  |  | $ | (466) |  |  |  | $ | 3,501 |  |

[0000833444-20-000034:8k_2_02:92]
Page 12 of 18

[0000833444-20-000034:8k_2_02:93]
FOOTNOTES

[0000833444-20-000034:8k_2_02:94]
1. Financial Summary

[0000833444-20-000034:8k_2_02:95]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and the net mark-to-market adjustments related to restricted asbestos investments and pension and postretirement plans. The financial results shown below are for continuing operations and exclude the Power Solutions business.

[0000833444-20-000034:8k_2_02:96]
| (in millions; unaudited) | Three Months Ended June 30, |  |  |  |  |  |  |  |
|  | 2020 |  |  |  | 2019 |  |  |  |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |  |
| Net sales |  |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,020 |  |  | $ | 2,020 |  |  | $ | 2,327 |  |  | $ | 2,327 |  |  |
| Building Solutions EMEA/LA | 756 |  |  | 756 |  |  | 922 |  |  | 922 |  |  |
| Building Solutions Asia Pacific | 588 |  |  | 588 |  |  | 691 |  |  | 691 |  |  |
| Global Products | 1,979 |  |  | 1,979 |  |  | 2,511 |  |  | 2,511 |  |  |
| Net sales | $ | 5,343 |  |  | $ | 5,343 |  |  | $ | 6,451 |  |  | $ | 6,451 |  |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 307 |  |  | $ | 311 |  |  | $ | 300 |  |  | $ | 310 |  |  |
| Building Solutions EMEA/LA | 62 |  |  | 62 |  |  | 101 |  |  | 103 |  |  |
| Building Solutions Asia Pacific | 92 |  |  | 92 |  |  | 98 |  |  | 98 |  |  |
| Global Products | 378 |  |  | 385 |  |  | 333 |  |  | 481 |  |  |
| Segment EBITA | 839 |  |  | 850 |  |  | 832 |  |  | 992 |  |  |
| Corporate expenses (2) | (67) |  |  | (48) |  |  | 70 |  |  | (90) |  |  |
| Amortization of intangible assets | (95) |  |  | (95) |  |  | (93) |  |  | (93) |  |  |
| Net mark-to-market adjustments (3) | (132) |  |  | — |  |  | 9 |  |  | — |  |  |
| Restructuring and impairment costs (4) | (610) |  |  | — |  |  | (235) |  |  | — |  |  |
| EBIT (5) | (65) |  |  | 707 |  |  | 583 |  |  | 809 |  |  |
| EBIT margin | (1.2) | % |  | 13.2 | % |  | 9.0 | % |  | 12.5 | % |  |
| Net financing charges (6) | (58) |  |  | (58) |  |  | (119) |  |  | (59) |  |  |
| Income (loss) from continuing operations before income taxes | (123) |  |  | 649 |  |  | 464 |  |  | 750 |  |  |
| Income tax benefit (provision) (7) | 1 |  |  | (87) |  |  | (239) |  |  | (101) |  |  |
| Income (loss) from continuing operations | (122) |  |  | 562 |  |  | 225 |  |  | 649 |  |  |
| Income from continuing operations attributable to noncontrolling interests | (60) |  |  | (60) |  |  | (84) |  |  | (84) |  |  |
| Net income (loss) from continuing operations attributable to JCI | $ | (182) |  |  | $ | 502 |  |  | $ | 141 |  |  | $ | 565 |  |  |

[0000833444-20-000034:8k_2_02:97]
| (in millions; unaudited) | Nine Months Ended June 30, |  |  |  |  |  |  |
|  | 2020 |  |  |  | 2019 |  |  |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 6,362 |  |  | $ | 6,362 |  |  | $ | 6,630 |  |  | $ | 6,630 |  |
| Building Solutions EMEA/LA | 2,534 |  |  | 2,534 |  |  | 2,707 |  |  | 2,707 |  |
| Building Solutions Asia Pacific | 1,742 |  |  | 1,742 |  |  | 1,932 |  |  | 1,932 |  |
| Global Products | 5,725 |  |  | 5,725 |  |  | 6,425 |  |  | 6,425 |  |
| Net sales | $ | 16,363 |  |  | $ | 16,363 |  |  | $ | 17,694 |  |  | $ | 17,694 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 816 |  |  | $ | 823 |  |  | $ | 807 |  |  | $ | 822 |  |
| Building Solutions EMEA/LA | 237 |  |  | 237 |  |  | 258 |  |  | 261 |  |
| Building Solutions Asia Pacific | 229 |  |  | 229 |  |  | 240 |  |  | 240 |  |
| Global Products | 797 |  |  | 805 |  |  | 774 |  |  | 930 |  |
| Segment EBITA | 2,079 |  |  | 2,094 |  |  | 2,079 |  |  | 2,253 |  |
| Corporate expenses (2) | (303) |  |  | (211) |  |  | (233) |  |  | (287) |  |
| Amortization of intangible assets | (288) |  |  | (288) |  |  | (288) |  |  | (288) |  |
| Net mark-to-market adjustments (3) | (154) |  |  | — |  |  | 8 |  |  | — |  |
| Restructuring and impairment costs (4) | (783) |  |  | — |  |  | (235) |  |  | — |  |
| EBIT (5) | 551 |  |  | 1,595 |  |  | 1,331 |  |  | 1,678 |  |
| EBIT margin | 3.4 | % |  | 9.7 | % |  | 7.5 | % |  | 9.5 | % |
| Net financing charges (6) | (169) |  |  | (169) |  |  | (302) |  |  | (242) |  |
| Income from continuing operations before income taxes | 382 |  |  | 1,426 |  |  | 1,029 |  |  | 1,436 |  |
| Income tax provision (7) | (77) |  |  | (192) |  |  | (394) |  |  | (194) |  |
| Income from continuing operations | 305 |  |  | 1,234 |  |  | 635 |  |  | 1,242 |  |
| Income from continuing operations attributable to noncontrolling interests | (115) |  |  | (109) |  |  | (147) |  |  | (147) |  |
| Net income from continuing operations attributable to JCI | $ | 190 |  |  | $ | 1,125 |  |  | $ | 488 |  |  | $ | 1,095 |  |

[0000833444-20-000034:8k_2_02:98]
(1) The Company's press release contains financial information regarding segment EBITA, adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures. The Company's definition of adjusted segment EBITA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its businesses. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-20-000034:8k_2_02:99]
A reconciliation of segment EBITA to income from continuing operations is shown earlier within this footnote. The following is the three months ended June 30, 2020 and 2019 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-20-000034:8k_2_02:100]
| (in millions) | Building SolutionsNorth America |  |  |  | Building Solutions EMEA/LA |  |  |  | Building Solutions Asia Pacific |  |  |  | Global Products |  |  |  | ConsolidatedJCI plc |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Segment EBITA as reported | $ | 307 |  |  | $ | 300 |  |  | $ | 62 |  |  | $ | 101 |  |  | $ | 92 |  |  | $ | 98 |  |  | $ | 378 |  |  | $ | 333 |  |  | $ | 839 |  |  | $ | 832 |  |
| Segment EBITA margin as reported | 15.2 | % |  | 12.9 | % |  | 8.2 | % |  | 11.0 | % |  | 15.6 | % |  | 14.2 | % |  | 19.1 | % |  | 13.3 | % |  | 15.7 | % |  | 12.9 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Integration costs | 4 |  |  | 10 |  |  | — |  |  | 2 |  |  | — |  |  | — |  |  | 7 |  |  | 8 |  |  | 11 |  |  | 20 |  |
| Environmental reserve (8) | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 140 |  |  | — |  |  | 140 |  |
| Adjusted segment EBITA | $ | 311 |  |  | $ | 310 |  |  | $ | 62 |  |  | $ | 103 |  |  | $ | 92 |  |  | $ | 98 |  |  | $ | 385 |  |  | $ | 481 |  |  | $ | 850 |  |  | $ | 992 |  |
| Adjusted segment EBITA margin | 15.4 | % |  | 13.3 | % |  | 8.2 | % |  | 11.2 | % |  | 15.6 | % |  | 14.2 | % |  | 19.5 | % |  | 19.2 | % |  | 15.9 | % |  | 15.4 | % |

[0000833444-20-000034:8k_2_02:101]
Page 13 of 18

[0000833444-20-000034:8k_2_02:102]
The following is the nine months ended June 30, 2020 and 2019 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-20-000034:8k_2_02:103]
| (in millions) | Building SolutionsNorth America |  |  |  | Building Solutions EMEA/LA |  |  |  | Building Solutions Asia Pacific |  |  |  | Global Products |  |  |  | ConsolidatedJCI plc |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Segment EBITA as reported | $ | 816 |  |  | $ | 807 |  |  | $ | 237 |  |  | $ | 258 |  |  | $ | 229 |  |  | $ | 240 |  |  | $ | 797 |  |  | $ | 774 |  |  | $ | 2,079 |  |  | $ | 2,079 |  |
| Segment EBITA margin as reported | 12.8 | % |  | 12.2 | % |  | 9.4 | % |  | 9.5 | % |  | 13.1 | % |  | 12.4 | % |  | 13.9 | % |  | 12.0 | % |  | 12.7 | % |  | 11.7 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Integration costs | 7 |  |  | 15 |  |  | — |  |  | 3 |  |  | — |  |  | — |  |  | 8 |  |  | 16 |  |  | 15 |  |  | 34 |  |
| Environmental reserve (8) | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 140 |  |  | — |  |  | 140 |  |
| Adjusted segment EBITA | $ | 823 |  |  | $ | 822 |  |  | $ | 237 |  |  | $ | 261 |  |  | $ | 229 |  |  | $ | 240 |  |  | $ | 805 |  |  | $ | 930 |  |  | $ | 2,094 |  |  | $ | 2,253 |  |
| Adjusted segment EBITA margin | 12.9 | % |  | 12.4 | % |  | 9.4 | % |  | 9.6 | % |  | 13.1 | % |  | 12.4 | % |  | 14.1 | % |  | 14.5 | % |  | 12.8 | % |  | 12.7 | % |

[0000833444-20-000034:8k_2_02:104]
(2)  Adjusted Corporate expenses excludes special items because these costs are not considered to be directly related to the underlying operating performance of the Company's business. Adjusted Corporate expenses for the three months ended June 30, 2020 excludes $19 million of integration costs. Adjusted Corporate expenses for the nine months ended June 30, 2020 excludes $92 million of integration costs. Adjusted Corporate expenses for the three months ended June 30, 2019 excludes $226 million of income as a result of a tax indemnification reserve release, partially offset by $63 million of integration costs and $3 million of transaction costs. Adjusted Corporate expenses for the nine months ended June 30, 2019 excludes $226 million of income as a result of a tax indemnification reserve release, partially offset by $165 million of integration costs and $7 million of transaction costs.

[0000833444-20-000034:8k_2_02:105]
(3) The three months ended June 30, 2020 exclude the net mark-to-market adjustments on restricted investments and pension and postretirement plans of $132 million. The nine months ended June 30, 2020 exclude the net mark-to-market adjustments on restricted investments and pension and postretirement plans of $154 million. The three months ended June 30, 2019 exclude the net mark-to-market adjustments on restricted investments of $9 million. The nine months ended June 30, 2019 exclude the net mark-to-market adjustments on restricted investments of $8 million.

[0000833444-20-000034:8k_2_02:106]
(4) Restructuring and impairment costs for the three months ended June 30, 2020 of $610 million are excluded from the adjusted non-GAAP results. Restructuring and impairment costs for the nine months ended June 30, 2020 of $783 million are excluded from the adjusted non-GAAP results. Restructuring and impairment costs for the three and nine months ended June 30, 2019 of $235 million are excluded from the adjusted non-GAAP results. The restructuring actions and impairment costs related primarily to workforce reductions, plant closures and asset impairments.

[0000833444-20-000034:8k_2_02:107]
(5) Management defines earnings before interest and taxes (EBIT) as income (loss) from continuing operations before net financing charges, income taxes and noncontrolling interests. EBIT is a non-GAAP performance measure. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company. A reconciliation of EBIT to income (loss) from continuing operations is shown earlier within this footnote.

[0000833444-20-000034:8k_2_02:108]
(6) Adjusted net financing charges for the three months and nine months ended June 30, 2019 exclude a loss on debt extinguishment of $60 million.

[0000833444-20-000034:8k_2_02:109]
(7) Adjusted income tax provision for the three months ended June 30, 2020 excludes tax benefits from net mark-to-market adjustments of $34 million, restructuring and impairment costs of $28 million, tax audit reserve adjustments of $22 million, and integration costs of $4 million. Adjusted income tax provision for the nine months ended June 30, 2020 excludes tax benefits from restructuring and impairment costs of $48 million, tax audit reserve adjustments of $44 million, net mark-to-market adjustments of $38 million, and integration costs of $15 million, partially offset by tax provisions related to Switzerland tax reform of $30 million. Adjusted income tax provision for the three months ended June 30, 2019 excludes tax provisions related to new U.S. tax regulations of $226 million and net mark-to-market adjustments of $2 million, partially offset by the tax benefits related to restructuring and impairment charges of $53 million, and environmental reserve of $28 million and integration

[0000833444-20-000034:8k_2_02:110]
costs of $9 million. Adjusted income tax provision for the nine months ended June 30, 2019 excludes tax provisions primarily related to new U.S. tax regulations of $226 million, valuation allowance adjustments of $76 million as a result of changes in U.S tax law and net mark-to-market adjustments of $2 million, partially offset by the tax benefits related to restructuring and impairment charges of $53 million, an environmental reserve of $28 million, integration costs of $22 million and transaction costs of $1 million.

[0000833444-20-000034:8k_2_02:111]
(8) An environmental charge for the three and nine months ended June 30, 2019 of $140 million is excluded from the adjusted non-GAAP results.  The $140 million is related to remediation efforts to be undertaken to address contamination at our facilities in Marinette, Wisconsin.  A substantial portion of the reserve relates to the remediation of fire-fighting foams containing PFAS compounds at or near our Fire Technology Center in Marinette.

[0000833444-20-000034:8k_2_02:112]
Page 14 of 18

[0000833444-20-000034:8k_2_02:113]
2.  Diluted Earnings Per Share Reconciliation

[0000833444-20-000034:8k_2_02:114]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include transaction/integration costs, net mark-to-market adjustments, restructuring and impairment costs, tax indemnification reserve release, environmental reserve, loss on extinguishment of debt, gain on sale of Power Solutions business, net of transaction and other costs, impact of ceasing the depreciation and amortization expense for the Power Solutions business as the business is held for sale, and discrete tax items. The Company excludes these items because they are not considered to be directly related to the underlying operating performance of the Company. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-20-000034:8k_2_02:115]
A reconciliation of diluted earnings per share as reported to adjusted diluted earnings per share for the respective periods is shown below (unaudited):

[0000833444-20-000034:8k_2_02:116]
|  | Net Income Attributableto JCI plc |  |  |  | Net Income Attributableto JCI plc from Continuing Operations |  |  |  | Net Income Attributableto JCI plc |  |  |  | Net Income Attributableto JCI plc from Continuing Operations |  |  |
|  | Three Months Ended |  |  |  | Three Months Ended |  |  |  | Nine Months Ended |  |  |  | Nine Months Ended |  |  |
|  | June 30, |  |  |  | June 30, |  |  |  | June 30, |  |  |  | June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Earnings (loss) per share as reported for JCI plc | $ | (0.24) |  |  | $ | 4.79 |  |  | $ | (0.24) |  |  | $ | 0.16 |  |  | $ | 0.25 |  |  | $ | 5.61 |  |  | $ | 0.25 |  |  | $ | 0.54 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |
| Integration costs | 0.04 |  |  | 0.09 |  |  | 0.04 |  |  | 0.09 |  |  | 0.14 |  |  | 0.22 |  |  | 0.14 |  |  | 0.22 |  |
| Related tax impact | (0.01) |  |  | (0.01) |  |  | (0.01) |  |  | (0.01) |  |  | (0.02) |  |  | (0.02) |  |  | (0.02) |  |  | (0.02) |  |
| Net mark-to-market adjustments | 0.18 |  |  | (0.01) |  |  | 0.18 |  |  | (0.01) |  |  | 0.20 |  |  | (0.01) |  |  | 0.20 |  |  | (0.01) |  |
| Related tax impact | (0.05) |  |  | — |  |  | (0.05) |  |  | — |  |  | (0.05) |  |  | — |  |  | (0.05) |  |  | — |  |
| Restructuring and impairment costs | 0.82 |  |  | 0.27 |  |  | 0.82 |  |  | 0.27 |  |  | 1.03 |  |  | 0.26 |  |  | 1.03 |  |  | 0.26 |  |
| Related tax impact | (0.04) |  |  | (0.06) |  |  | (0.04) |  |  | (0.06) |  |  | (0.06) |  |  | (0.06) |  |  | (0.06) |  |  | (0.06) |  |
| NCI impact of restructuring and impairment | — |  |  | — |  |  | — |  |  | — |  |  | (0.01) |  |  | — |  |  | (0.01) |  |  | — |  |
| Tax indemnification reserve release | — |  |  | (0.26) |  |  | — |  |  | (0.26) |  |  | — |  |  | (0.25) |  |  | — |  |  | (0.25) |  |
| Environmental reserve | — |  |  | 0.16 |  |  | — |  |  | 0.16 |  |  | — |  |  | 0.16 |  |  | — |  |  | 0.16 |  |
| Related tax impact | — |  |  | (0.03) |  |  | — |  |  | (0.03) |  |  | — |  |  | (0.03) |  |  | — |  |  | (0.03) |  |
| Loss on extinguishment of debt | — |  |  | 0.07 |  |  | — |  |  | 0.07 |  |  | — |  |  | 0.07 |  |  | — |  |  | 0.07 |  |
| Power Solutions gain on sale, net of |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| transaction and other costs | — |  |  | (6.00) |  |  | — |  |  | — |  |  | — |  |  | (5.77) |  |  | — |  |  | — |  |
| Related tax impact | — |  |  | 1.43 |  |  | — |  |  | — |  |  | — |  |  | 1.39 |  |  | — |  |  | — |  |
| Cease of Power Solutions |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| depreciation / amortization expense | — |  |  | (0.02) |  |  | — |  |  | — |  |  | — |  |  | (0.13) |  |  | — |  |  | — |  |
| Related tax impact | — |  |  | 0.01 |  |  | — |  |  | — |  |  | — |  |  | 0.03 |  |  | — |  |  | — |  |
| Discrete tax items | (0.03) |  |  | 0.26 |  |  | (0.03) |  |  | 0.26 |  |  | (0.02) |  |  | 0.42 |  |  | (0.02) |  |  | 0.33 |  |
| NCI impact of discrete tax items | — |  |  | — |  |  | — |  |  | — |  |  | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |
| Adjusted earnings per share for JCI plc* | $ | 0.67 |  |  | $ | 0.69 |  |  | $ | 0.67 |  |  | $ | 0.65 |  |  | $ | 1.48 |  |  | $ | 1.89 |  |  | $ | 1.48 |  |  | $ | 1.21 |  |

[0000833444-20-000034:8k_2_02:117]
* May not sum due to rounding

[0000833444-20-000034:8k_2_02:118]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-20-000034:8k_2_02:119]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |  |  |  |  |
|  | June 30, |  |  |  | June 30, |  |  |  |  |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |  |  |  |  |
| Weighted average shares outstanding for JCI plc |  |  |  |  |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 744.0 |  |  | 870.9 |  |  | 756.3 |  |  | 898.4 |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock |  |  |  |  |  |  |  |  |  |  |  |
| and unvested performance share awards | — |  |  | 4.3 |  |  | 2.6 |  |  | 3.8 |  |  |  |  |  |
| Diluted weighted average shares outstanding | 744.0 |  |  | 875.2 |  |  | 758.9 |  |  | 902.2 |  |  |  |  |  |

[0000833444-20-000034:8k_2_02:120]
For the three months ended June 30, 2020, the total number of potential dilutive shares due to stock options, unvested restricted stock and unvested performance share awards was 1.5 million. However, these items were not included in the computation of diluted loss per share for the three months ended June 30, 2020, since to do so would decrease the loss per share. On an adjusted diluted outstanding share basis, inclusion of the effect of dilutive securities results in diluted weighted average shares outstanding of 745.5 million for the three months ended June 30, 2020.

[0000833444-20-000034:8k_2_02:121]
Page 15 of 18

[0000833444-20-000034:8k_2_02:122]
The Company has presented forward-looking statements regarding adjusted EPS, organic revenue decline, net EBIT decrementals, adjusted corporate expense and adjusted free cash flow conversion, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts, expenses, income or cash flows from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts that are excluded from these non-GAAP financial measures are a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period, including but not limited to the high variability of the net mark-to-market adjustments and the effect of foreign currency exchange fluctuations. Our fiscal 2020 fourth quarter guidance for organic revenue decline also excludes the effect of acquisitions, divestitures and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available and management cannot reliably predict all of the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s full year 2020 GAAP financial results.

[0000833444-20-000034:8k_2_02:123]
3. Organic Growth Reconciliation

[0000833444-20-000034:8k_2_02:124]
The components of the changes in net sales for the three months ended June 30, 2020 versus the three months ended June 30, 2019, including organic growth, is shown below (unaudited):

[0000833444-20-000034:8k_2_02:125]
| (in millions) | Net Sales for the Three Months Ended June 30, 2019 |  | Base Year Adjustments - Divestitures and Other |  |  |  | Adjusted Base Net Sales for the Three Months Ended June 30, 2019 |  | Acquisitions |  |  |  | Foreign Currency |  |  |  | Organic Growth |  |  |  | Net Sales for the Three Months EndedJune 30, 2020 |  |  |
| Building Solutions North America | $ | 2,327 |  |  | $ | — |  |  | — |  |  | $ | 2,327 |  |  | $ | — |  |  | — |  |  | $ | (8) |  |  | — |  |  | $ | (299) |  |  | -13 | % |  | $ | 2,020 |  |  | -13 | % |
| Building Solutions EMEA/LA | 922 |  |  | 6 |  |  | 1 | % |  | 928 |  |  | 12 |  |  | 1 | % |  | (44) |  |  | -5 | % |  | (140) |  |  | -15 | % |  | 756 |  |  | -18 | % |
| Building Solutions Asia Pacific | 691 |  |  | — |  |  | — |  |  | 691 |  |  | 2 |  |  | — |  |  | (19) |  |  | -3 | % |  | (86) |  |  | -12 | % |  | 588 |  |  | -15 | % |
| Total field | 3,940 |  |  | 6 |  |  | — |  |  | 3,946 |  |  | 14 |  |  | — |  |  | (71) |  |  | -2 | % |  | (525) |  |  | -13 | % |  | 3,364 |  |  | -15 | % |
| Global Products | 2,511 |  |  | (6) |  |  | — |  |  | 2,505 |  |  | 2 |  |  | — |  |  | (16) |  |  | -1 | % |  | (512) |  |  | -20 | % |  | 1,979 |  |  | -21 | % |
| Total net sales | $ | 6,451 |  |  | $ | — |  |  | — |  |  | $ | 6,451 |  |  | $ | 16 |  |  | — |  |  | $ | (87) |  |  | -1 | % |  | $ | (1,037) |  |  | -16 | % |  | $ | 5,343 |  |  | -17 | % |

[0000833444-20-000034:8k_2_02:126]
The components of the changes in net sales for the nine months ended June 30, 2020 versus the nine months ended June 30, 2019, including organic growth, is shown below (unaudited):

[0000833444-20-000034:8k_2_02:127]
| (in millions) | Net Sales for the Nine Months Ended June 30, 2019 |  | Base Year Adjustments - Divestitures and Other |  |  |  | Adjusted Base Net Sales for the Nine Months Ended June 30, 2019 |  | Acquisitions |  |  |  | Foreign Currency |  |  |  | Organic Growth |  |  |  | Net Sales for the Nine Months EndedJune 30, 2020 |  |  |
| Building Solutions North America | $ | 6,630 |  |  | $ | (2) |  |  | — |  |  | $ | 6,628 |  |  | $ | — |  |  | — |  |  | $ | (10) |  |  | — |  |  | $ | (256) |  |  | -4 | % |  | $ | 6,362 |  |  | -4 | % |
| Building Solutions EMEA/LA | 2,707 |  |  | (17) |  |  | -1 | % |  | 2,690 |  |  | 27 |  |  | 1 | % |  | (102) |  |  | -4 | % |  | (81) |  |  | -3 | % |  | 2,534 |  |  | -6 | % |
| Building Solutions Asia Pacific | 1,932 |  |  | — |  |  | — |  |  | 1,932 |  |  | 6 |  |  | — |  |  | (39) |  |  | -2 | % |  | (157) |  |  | -8 | % |  | 1,742 |  |  | -10 | % |
| Total field | 11,269 |  |  | (19) |  |  | — |  |  | 11,250 |  |  | 33 |  |  | — |  |  | (151) |  |  | -1 | % |  | (494) |  |  | -4 | % |  | 10,638 |  |  | -6 | % |
| Global Products | 6,425 |  |  | (21) |  |  | — |  |  | 6,404 |  |  | 5 |  |  | — |  |  | (26) |  |  | — |  |  | (658) |  |  | -10 | % |  | 5,725 |  |  | -11 | % |
| Total net sales | $ | 17,694 |  |  | $ | (40) |  |  | — |  |  | $ | 17,654 |  |  | $ | 38 |  |  | — |  |  | $ | (177) |  |  | -1 | % |  | $ | (1,152) |  |  | -7 | % |  | $ | 16,363 |  |  | -8 | % |

[0000833444-20-000034:8k_2_02:128]
The components of the changes in segment EBITA and EBIT for the three months ended June 30, 2020 versus the three months ended June 30, 2019, including organic growth, is shown below (unaudited):

[0000833444-20-000034:8k_2_02:129]
| (in millions) | Adjusted Segment EBITA / EBIT for the Three Months Ended June 30, 2019 |  | Base Year Adjustments - Divestitures and Other |  |  |  | Adjusted Base Segment EBITA / EBIT for the Three Months Ended June 30, 2019 |  | Acquisitions |  |  |  | Foreign Currency |  |  |  | Organic Growth |  |  |  | Adjusted SegmentEBITA / EBIT forthe ThreeMonths EndedJune 30, 2020 |  |  |
| Building Solutions North America | $ | 310 |  |  | $ | — |  |  | — |  |  | $ | 310 |  |  | $ | — |  |  | — |  |  | $ | (1) |  |  | — |  |  | $ | 2 |  |  | 1 | % |  | $ | 311 |  |  | — |  |
| Building Solutions EMEA/LA | 103 |  |  | — |  |  | — |  |  | 103 |  |  | 2 |  |  | 2 | % |  | (7) |  |  | -7 | % |  | (36) |  |  | -35 | % |  | 62 |  |  | -40 | % |
| Building Solutions Asia Pacific | 98 |  |  | — |  |  | — |  |  | 98 |  |  | — |  |  | — |  |  | (1) |  |  | -1 | % |  | (5) |  |  | -5 | % |  | 92 |  |  | -6 | % |
| Total field | 511 |  |  | — |  |  | — |  |  | 511 |  |  | 2 |  |  | — |  |  | (9) |  |  | -2 | % |  | (39) |  |  | -8 | % |  | 465 |  |  | -9 | % |
| Global Products | 481 |  |  | — |  |  | — |  |  | 481 |  |  | (1) |  |  | — |  |  | (4) |  |  | -1 | % |  | (91) |  |  | -19 | % |  | 385 |  |  | -20 | % |
| Total adjusted segment EBITA | 992 |  |  | — |  |  | — |  |  | 992 |  |  | $ | 1 |  |  | — |  |  | $ | (13) |  |  | -1 | % |  | $ | (130) |  |  | -13 | % |  | 850 |  |  | -14 | % |
| Corporate expenses | (90) |  |  | — |  |  |  |  | (90) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (48) |  |  | 47 | % |
| Amortization of intangible assets | (93) |  |  | — |  |  |  |  | (93) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (95) |  |  | -2 | % |
| Total adjusted EBIT | $ | 809 |  |  | $ | — |  |  |  |  | $ | 809 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 707 |  |  | -13 | % |

[0000833444-20-000034:8k_2_02:130]
Page 16 of 18

[0000833444-20-000034:8k_2_02:131]
The components of the changes in segment EBITA and EBIT for the nine months ended June 30, 2020 versus the nine months ended June 30, 2019, including organic growth, is shown below (unaudited):

[0000833444-20-000034:8k_2_02:132]
| (in millions) | Adjusted Segment EBITA / EBIT for the Nine Months Ended June 30, 2019 |  | Base Year Adjustments - Divestitures and Other |  |  |  | Adjusted Base Segment EBITA / EBIT for the Nine Months Ended June 30, 2019 |  | Acquisitions |  |  |  | Foreign Currency |  |  |  | Organic Growth |  |  |  | Adjusted SegmentEBITA / EBIT forthe Nine Months EndedJune 30, 2020 |  |  |
| Building Solutions North America | $ | 822 |  |  | $ | — |  |  | — |  |  | $ | 822 |  |  | $ | — |  |  | — |  |  | $ | (1) |  |  | — |  |  | $ | 2 |  |  | — |  |  | $ | 823 |  |  | — |  |
| Building Solutions EMEA/LA | 261 |  |  | (1) |  |  | — |  |  | 260 |  |  | 5 |  |  | 2 | % |  | (16) |  |  | -6 | % |  | (12) |  |  | -5 | % |  | 237 |  |  | -9 | % |
| Building Solutions Asia Pacific | 240 |  |  | — |  |  | — |  |  | 240 |  |  | 1 |  |  | — |  |  | (2) |  |  | -1 | % |  | (10) |  |  | -4 | % |  | 229 |  |  | -5 | % |
| Total field | 1,323 |  |  | (1) |  |  | — |  |  | 1,322 |  |  | 6 |  |  | — |  |  | (19) |  |  | -1 | % |  | (20) |  |  | -2 | % |  | 1,289 |  |  | -3 | % |
| Global Products | 930 |  |  | (1) |  |  | — |  |  | 929 |  |  | (2) |  |  | — |  |  | (7) |  |  | -1 | % |  | (115) |  |  | -12 | % |  | 805 |  |  | -13 | % |
| Total adjusted segment EBITA | 2,253 |  |  | (2) |  |  | — |  |  | 2,251 |  |  | $ | 4 |  |  | — |  |  | $ | (26) |  |  | -1 | % |  | $ | (135) |  |  | -6 | % |  | 2,094 |  |  | -7 | % |
| Corporate expenses | (287) |  |  | — |  |  |  |  | (287) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (211) |  |  | 26 | % |
| Amortization of intangible assets | (288) |  |  | — |  |  |  |  | (288) |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (288) |  |  | — |  |
| Total adjusted EBIT | $ | 1,678 |  |  | $ | (2) |  |  |  |  | $ | 1,676 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,595 |  |  | -5 | % |

[0000833444-20-000034:8k_2_02:133]
4.  Adjusted Free Cash Flow Reconciliation

[0000833444-20-000034:8k_2_02:134]
The Company's press release contains financial information regarding free cash flow, adjusted free cash flow and adjusted free cash flow conversion, which are non-GAAP performance measures. Free cash flow is defined as cash provided by operating activities less capital expenditures. Adjusted free cash flow excludes special items, as included in the table below, because these cash flows are not considered to be directly related to its underlying businesses. Adjusted free cash flow conversion is defined as adjusted free cash flow divided by adjusted net income. Management believes these non-GAAP measures are useful to investors in understanding the strength of the Company and its ability to generate cash.

[0000833444-20-000034:8k_2_02:135]
The following is the three months and nine months ended June 30, 2020 and 2019 reconciliation of free cash flow, adjusted free cash flow and adjusted free cash flow conversion for continuing operations (unaudited):

[0000833444-20-000034:8k_2_02:136]
| (in billions) | Three Months Ended June 30, 2020 |  | Three Months Ended June 30, 2019 |  | Nine Months Ended June 30, 2020 |  | Nine Months Ended June 30, 2019 |  |  |
| Cash provided by operating activities from continuing operations | $ | 0.8 |  |  | $ | 0.6 |  |  | $ | 1.5 |  |  | $ | 0.7 |  |  |  |
| Capital expenditures | (0.1) |  |  | (0.1) |  |  | (0.3) |  |  | (0.4) |  |  |  |
| Reported free cash flow | 0.7 |  |  | 0.5 |  |  | 1.2 |  |  | 0.3 |  |  |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |
| Transaction/integration costs | — |  |  | 0.1 |  |  | 0.2 |  |  | 0.2 |  |  |  |
| Restructuring payments | — |  |  | — |  |  | 0.1 |  |  | 0.1 |  |  |  |
| Nonrecurring tax refunds | — |  |  | — |  |  | (0.6) |  |  | — |  |  |  |
| Total adjusting items * | 0.1 |  |  | 0.1 |  |  | (0.3) |  |  | 0.3 |  |  |  |
| Adjusted free cash flow | $ | 0.8 |  |  | $ | 0.6 |  |  | $ | 0.9 |  |  | $ | 0.6 |  |  |  |
| Adjusted net income from continuing operations |  |  |  |  |  |  |  |  |  |
| attributable to JCI | $ | 0.5 |  |  | $ | 0.6 |  |  | $ | 1.1 |  |  | $ | 1.1 |  |  |  |
| Adjusted free cash flow conversion | 160 | % |  | 100 | % |  | 82 | % |  | 55 | % |  |  |

[0000833444-20-000034:8k_2_02:137]
* May not sum due to rounding

[0000833444-20-000034:8k_2_02:138]
Page 17 of 18

[0000833444-20-000034:8k_2_02:139]
5.  Net Debt to EBITDA

[0000833444-20-000034:8k_2_02:140]
The Company provides financial information regarding net debt to adjusted EBITDA, which is a non-GAAP performance measure. The Company believes the total net debt to adjusted EBITDA ratio is useful to understanding the Company's financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders. The following is the June 30, 2020 and March 31, 2020 calculation of net debt to adjusted EBITDA (unaudited):

[0000833444-20-000034:8k_2_02:141]
| (in millions) | June 30, 2020 |  | March 31, 2020 |  |  |
| Short-term debt and current portion of long-term debt | $ | 2,423 |  |  | $ | 1,430 |  |  |  |
| Long-term debt | 5,671 |  |  | 5,640 |  |  |  |
| Total debt | 8,094 |  |  | 7,070 |  |  |  |
| Less: cash and cash equivalents | 2,342 |  |  | 1,006 |  |  |  |
| Total net debt | $ | 5,752 |  |  | $ | 6,064 |  |  |  |
| Last twelve months adjusted EBITDA | $ | 3,223 |  |  | $ | 3,326 |  |  |  |
| Total net debt to adjusted EBITDA | 1.8x |  | 1.8x |  |  |

[0000833444-20-000034:8k_2_02:142]
The following is the last twelve months ended June 30, 2020 and March 31, 2020 reconciliation of income from continuing operations to adjusted EBIT and adjusted EBITDA, which are non-GAAP performance measures (unaudited):

[0000833444-20-000034:8k_2_02:143]
| (in millions) | Last Twelve MonthsEndedJune 30, 2020 |  | Last Twelve Months EndedMarch 31, 2020 |  |  |
| Income from continuing operations | $ | 959 |  |  | $ | 1,306 |  |  |  |
| Income tax benefit | (550) |  |  | (310) |  |  |  |
| Net financing charges | 217 |  |  | 278 |  |  |  |
| EBIT | 626 |  |  | 1,274 |  |  |  |
| Adjusting items: |  |  |  |  |  |
| Transaction costs | 4 |  |  | 7 |  |  |  |
| Integration costs | 214 |  |  | 267 |  |  |  |
| Net mark-to-market adjustments | 780 |  |  | 639 |  |  |  |
| Restructuring and impairment costs | 783 |  |  | 408 |  |  |  |
| Tax indemnification reserve release | — |  |  | (226) |  |  |  |
| Environmental reserve | — |  |  | 140 |  |  |  |
| Adjusted EBIT (1) | 2,407 |  |  | 2,509 |  |  |  |
| Depreciation and amortization | 816 |  |  | 817 |  |  |  |
| Adjusted EBITDA (1) | $ | 3,223 |  |  | $ | 3,326 |  |  |  |

[0000833444-20-000034:8k_2_02:144]
(1) The Company's definition of adjusted EBIT and adjusted EBITDA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its businesses. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-20-000034:8k_2_02:145]
6.  Income Taxes

[0000833444-20-000034:8k_2_02:146]
The Company's effective tax rate from continuing operations before consideration of transaction/integration costs, net mark-to-market adjustments, environmental reserve, tax indemnification reserve release, restructuring and impairment costs, loss on extinguishment of debt and discrete tax items for the three and nine months ending June 30, 2020 and June 30, 2019 is approximately 13.5%.

[0000833444-20-000034:8k_2_02:147]
7.  Restructuring and Impairment Costs

[0000833444-20-000034:8k_2_02:148]
The three months ended June 30, 2020 include restructuring and impairment costs of $610 million related to workforce reductions, asset impairments and goodwill impairments related to the Company's retail business. The nine months ended June 30, 2020 include restructuring and impairment costs of $783 million related primarily to workforce reductions, plant closures, asset impairments, and indefinite-lived intangible asset and goodwill impairments related to the Company's retail business. The three and nine months ended June 30, 2019 include restructuring and impairment costs of $235 million related to the impairment of a Global Products business classified as held for sale.

[0000833444-20-000034:8k_2_02:149]
8.  Leases

[0000833444-20-000034:8k_2_02:150]
On October 1, 2019, the Company adopted ASU 2016-02, "Leases (Topic 842)," which requires recognition of operating leases as a lease asset and liabilities on the balance sheet. The adoption of the new guidance resulted in recognition of a right-of-use asset and related lease liabilities of $1.1 billion.

[0000833444-20-000034:8k_2_02:151]
Page 18 of 18
