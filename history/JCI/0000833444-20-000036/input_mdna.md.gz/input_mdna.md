# JCI MD&A — 0000833444-20-000036


## mdna

[0000833444-20-000036:mdna:1]
[same as prior period, unchanged from 0000833444-20-000015:mdna:1]

[0000833444-20-000036:mdna:2]
[same as prior period, unchanged from 0000833444-20-000015:mdna:2]

[0000833444-20-000036:mdna:3]
[same as prior period, unchanged from 0000833444-20-000015:mdna:3]

[0000833444-20-000036:mdna:4]
[same as prior period, unchanged from 0000833444-20-000015:mdna:4]

[0000833444-20-000036:mdna:5]
[same as prior period, unchanged from 0000833444-20-000015:mdna:5]

[0000833444-20-000036:mdna:6]
[same as prior period, unchanged from 0000833444-20-000015:mdna:6]

[0000833444-20-000036:mdna:7]
On November 13, 2018, the Company entered into a Stock and Asset Purchase Agreement (“Purchase Agreement”) with BCP Acquisitions LLC (“Purchaser”). The Purchaser was a newly-formed entity controlled by investment funds managed by Brookfield Capital Partners LLC. Pursuant to the Purchase Agreement, on the terms and subject to the conditions therein, the Company agreed to sell, and Purchaser agreed to acquire, the Company’s Power Solutions business for a purchase price of $13.2 billion. The transaction closed on April 30, 2019 with net cash proceeds of $11.6 billion after tax and transaction-related expenses.

[0000833444-20-000036:mdna:8]
[same as prior period, unchanged from 0000833444-20-000015:mdna:9]

[0000833444-20-000036:mdna:9]
[same as prior period, unchanged from 0000833444-20-000015:mdna:10]

[0000833444-20-000036:mdna:10]
The following information should be read in conjunction with the September 30, 2019 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in our Annual Report on Form 10-K for the year ended September 30, 2019 filed with the SEC on November 21, 2019. References in the following discussion and analysis to "Three Months" (or similar language) refer to the three months ended June 30, 2020 compared to the three months ended June 30, 2019, while "Year-to-Date" refers to the nine months ended June 30, 2020 compared to the nine months ended June 30, 2019.

[0000833444-20-000036:mdna:11]
[same as prior period, unchanged from 0000833444-20-000015:mdna:12]

[0000833444-20-000036:mdna:12]
The global outbreak of COVID-19 has severely restricted the level of economic activity around the world. In response to this outbreak, the governments of many countries, states, cities and other geographic regions have taken preventative or protective actions, such as imposing restrictions on travel and business operations. The Company’s affiliates, employees, suppliers, customers and others have been and may continue to be restricted or prevented from conducting normal business activities, including as a result of shutdowns, travel restrictions and other actions that may be requested or mandated by governmental authorities. Such actions have and may in the future prevent the Company from accessing the facilities of its customers to deliver and install products, provide services and complete maintenance. In addition, some of the Company’s customers have chosen to delay or abandon projects on which the Company provides products and/or services as a result of such actions. Although some governments have begun to lift shutdown orders and similar restrictions, a resurgence in the spread of COVID-19 could cause the reinstitution of such preventive or protective measures. While a substantial portion of the Company businesses have been classified as an essential business in jurisdictions in which facility closures have been mandated, some of its facilities have nevertheless been ordered to close in certain jurisdictions.

[0000833444-20-000036:mdna:13]
In response to the challenges presented by COVID-19, the Company has focused its efforts on preserving the health and safety of its employees and customers, as well as maintaining the continuity of its operations.  The Company has modified its business practices in response to the COVID-19 outbreak, including restricting non-essential employee travel, implementation of remote work protocols, and cancellation of physical participation in meetings, events and conferences. The Company has also instituted preventive measures at its facilities, including enhanced health and safety protocols, temperature screening, requiring face coverings for all employees and encouraging employees to follow similar protocols when away from work. The Company has adopted a multifaceted framework to guide its decision making when evaluating the readiness of its facilities to safely reopen and operate, and will continue to monitor and audit its facilities to ensure that they are in compliance with the Company’s COVID-19 safety requirements.

[0000833444-20-000036:mdna:14]
In the second quarter of fiscal 2020, the Company experienced a temporary reduction of its manufacturing and operating capacity in China as a result of government-mandated actions to control the spread of COVID-19. In the third quarter of fiscal 2020, the Company experienced similar reductions as a result of government-mandated actions in India and Mexico.  Further, the Company has experienced, and may continue to experience, disruptions or delays in its supply chain as a result of such actions, which has resulted in higher supply chain costs to the Company in order to maintain the supply of materials and

[0000833444-20-000036:mdna:15]
[same as prior period, unchanged from 0000833444-20-000015:mdna:29]

[0000833444-20-000036:mdna:16]
components for its products. In order to mitigate disruptions to its supply chain and manufacturing capacity, the Company has taken actions including redistributing its manufacturing capacity to facilities and regions unaffected by shutdown orders, accelerating the purchase and shipment of components from suppliers in identified hot spots, diversifying the Company’s supplier base, conducting government outreach to support the Company’s and its suppliers’ designations as essential businesses, and expanding its existing supplier financing programs to support supplier viability and business continuity.

[0000833444-20-000036:mdna:17]
The Company has also experienced a decline in demand and volumes in its global businesses as a result of the impact of efforts to contain the spread of COVID-19.  Specifically, the Company experienced lower demand due to restricted access to customer sites to perform service and installation work as well as reduced discretionary capital spending by the Company's customers.  In response, the Company quickly moved to execute cost mitigation actions to offset a portion of the impact of COVID-19 on the demand for its products and services, such as deferring or reducing capital expenditures, implementing cost structure changes, short-term furloughing of salaried employees and limiting discretionary spending including corporate expense. These measures are in addition to the Company's previously disclosed fiscal 2020 restructuring plan. The duration of these cost mitigation actions, as well as the implementation of new cost mitigation actions, will depend on the continued impact of COVID-19, which is highly uncertain.

[0000833444-20-000036:mdna:18]
Although COVID-19 has negatively impacted demand for the Company’s products and services overall, the global pandemic has also provided the Company with the opportunity to help its customers prepare to re-open by delivering solutions and support that enhance the safety and increase the efficiency of their operations.  The Company has seen an increase in demand for its products and solutions that promote building health and optimize customers’ infrastructure, including thermal cameras, indoor air quality, location-based services for contact tracing and touchless access control.

[0000833444-20-000036:mdna:19]
During the second quarter of fiscal 2020, the Company determined that it had a triggering event requiring assessment of impairment for certain of its indefinite-lived intangible assets due to declines in revenue directly attributable to the COVID-19 pandemic. As a result, the Company recorded an impairment charge of $62 million related primarily to the Company's retail business indefinite-lived intangible assets within restructuring and impairment costs in the consolidated statements of income in the second quarter of fiscal 2020. During the third quarter of fiscal 2020, the Company determined that it had a triggering event requiring assessment of impairment for certain of its indefinite-lived intangible assets, long-lived assets and goodwill due to declines in revenue and further declines in forecasted cash flows in its North America Retail reporting unit directly attributable to the COVID-19 pandemic. As a result, the Company recorded an impairment charge of $424 million related to the Company's North America Retail reporting unit's goodwill within restructuring and impairment costs in the consolidated statements of income in the third quarter of fiscal 2020. It is possible that future changes in such circumstances, including a more prolonged and/or severe COVID-19 pandemic, would require the Company to record additional non-cash impairment charges.

[0000833444-20-000036:mdna:20]
The Company continues to actively monitor its liquidity position and working capital needs. Given the increasingly uncertain economic environment, the Company took proactive measures in the third quarter of fiscal 2020 to increase near-term financial flexibility, electing to opportunistically raise $675 million via European financing arrangements and $575 million in bank term loans. In addition, the Company took precautionary actions to preserve its liquidity resources in an uncertain environment by suspending its share repurchase program in March 2020.

[0000833444-20-000036:mdna:21]
The Company believes that, following its implementation of its liquidity and cost mitigation actions, it remains in a solid overall capital resources and liquidity position that is adequate to meet its projected needs. As a result, in June 2020, following a review of its liquidity position, the Company announced that it would resume its share repurchase program beginning in the fourth quarter of fiscal 2020.  In addition, in July 2020, the Company repaid a $300 million bank term loan.

[0000833444-20-000036:mdna:22]
The Company’s expected cash flow in the fourth quarter and current leverage also provide the Company with the ability to access the debt markets. In order to maintain its solid liquidity position, the Company intends to be opportunistic in exploring opportunities to refinance a portion of its upcoming short term debt maturities.

[0000833444-20-000036:mdna:23]
The extent to which the COVID-19 outbreak continues to impact the Company’s results of operations and financial condition will depend on future developments that are highly uncertain and cannot be predicted, including new information that may emerge concerning the severity and longevity of COVID-19, the resurgence of COVID-19 in regions that have begun to recover from the initial impact of the pandemic, the impact of COVID-19 on economic activity, and the actions to contain its impact on public health and the global economy. See Part II, Item 1A, Risk Factors, for an additional discussion of risks related to COVD-19.

[0000833444-20-000036:mdna:24]
[same as prior period, unchanged from 0000833444-20-000015:mdna:18]

[0000833444-20-000036:mdna:25]
|  | Three Months Ended June 30, |  |  |  |  |  | Nine Months Ended June 30, |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Net sales | $ | 5,343 |  |  | $ | 6,451 |  |  | -17 | % |  | $ | 16,363 |  |  | $ | 17,694 |  |  | -8 | % |

[0000833444-20-000036:mdna:26]
The decrease in consolidated net sales for the three months ended June 30, 2020 was due to lower organic sales ($1,037 million) and the unfavorable impact of foreign currency translation ($87 million), partially offset by acquisitions ($16 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales decreased 16% as compared to the prior year primarily due to the unfavorable impact of the COVID-19 pandemic on demand and volumes. Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-20-000036:mdna:27]
The decrease in consolidated net sales for the nine months ended June 30, 2020 was due to lower organic sales ($1,180 million), the unfavorable impact of foreign currency translation ($177 million) and lower sales due to business divestitures ($12 million), partially offset by acquisitions ($38 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales decreased 7% as compared to the prior year due to the unfavorable impact of the COVID-19 pandemic. Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-20-000036:mdna:28]
[same as prior period, unchanged from 0000833444-20-000015:mdna:22]

[0000833444-20-000036:mdna:29]
|  | Three Months Ended June 30, |  |  |  |  |  | Nine Months Ended June 30, |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Cost of sales | $ | 3,511 |  |  | $ | 4,307 |  |  | -18 | % |  | $ | 10,927 |  |  | $ | 11,981 |  |  | -9 | % |
| Gross profit | 1,832 |  |  | 2,144 |  |  | -15 | % |  | 5,436 |  |  | 5,713 |  |  | -5 | % |
| % of sales | 34.3 | % |  | 33.2 | % |  |  |  | 33.2 | % |  | 32.3 | % |  |  |

[0000833444-20-000036:mdna:30]
Cost of sales and gross profit decreased for the three month period ended June 30, 2020, and gross profit as a percentage of sales increased by 110 basis points. Gross profit decreased due to organic sales declines from the unfavorable impact of the COVID-19 pandemic. Foreign currency translation had a favorable impact on cost of sales of approximately $60 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA") by segment.

[0000833444-20-000036:mdna:31]
Cost of sales decreased and gross profit decreased for the nine month period ended June 30, 2020, and gross profit as a percentage of sales increased by 90 basis points. Foreign currency translation had a favorable impact on cost of sales of approximately $120 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-20-000036:mdna:32]
[same as prior period, unchanged from 0000833444-20-000015:mdna:26]

[0000833444-20-000036:mdna:33]
|  | Three Months Ended June 30, |  |  |  |  |  | Nine Months Ended June 30, |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Selling, general and administrative expenses | $ | 1,334 |  |  | $ | 1,388 |  |  | -4 | % |  | $ | 4,212 |  |  | $ | 4,284 |  |  | -2 | % |
| % of sales | 25.0 | % |  | 21.5 | % |  |  |  | 25.7 | % |  | 24.2 | % |  |  |

[0000833444-20-000036:mdna:34]
Selling, general and administrative expenses ("SG&A") for the three month period ended June 30, 2020 decreased $54 million, and SG&A as a percentage of sales increased by 350 basis points. The decrease in SG&A was primarily due to a favorable impact of cost mitigation actions and reduction in discretionary spend in the current quarter, a prior year environmental charge and a favorable impact of foreign currency translation, partially offset by a current year mark-to-market loss on pension plans

[0000833444-20-000036:mdna:35]
and a prior year tax indemnification reserve release. Foreign currency translation had a favorable impact on SG&A of $16 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-20-000036:mdna:36]
SG&A for the nine month period ended June 30, 2020 decreased $72 million, and SG&A as a percentage of sales increased by 150 basis points. The decrease in SG&A was primarily due to a favorable impact of cost mitigation actions and reduction in discretionary spend in the current year, a prior year environmental charge and a favorable impact of foreign currency translation, partially offset by a current year mark-to-market loss on pension plans and a prior year tax indemnification reserve release. Foreign currency translation had a favorable impact on SG&A of $35 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-20-000036:mdna:37]
[same as prior period, unchanged from 0000833444-20-000015:mdna:32]

[0000833444-20-000036:mdna:38]
|  | Three Months Ended June 30, |  |  |  |  |  | Nine Months Ended June 30, |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Restructuring and impairment costs | $ | 610 |  |  | $ | 235 |  |  | * |  | $ | 783 |  |  | $ | 235 |  |  | * |

[0000833444-20-000036:mdna:39]
[same as prior period, unchanged from 0000833444-20-000015:mdna:34]

[0000833444-20-000036:mdna:40]
[same as prior period, unchanged from 0000833444-20-000015:mdna:35]

[0000833444-20-000036:mdna:41]
[same as prior period, unchanged from 0000833444-20-000015:mdna:36]

[0000833444-20-000036:mdna:42]
|  | Three Months Ended June 30, |  |  |  |  |  | Nine Months Ended June 30, |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Net financing charges | $ | 58 |  |  | $ | 119 |  |  | -51 | % |  | $ | 169 |  |  | $ | 302 |  |  | -44 | % |

[0000833444-20-000036:mdna:43]
[same as prior period, unchanged from 0000833444-20-000015:mdna:38]

[0000833444-20-000036:mdna:44]
[same as prior period, unchanged from 0000833444-20-000015:mdna:39]

[0000833444-20-000036:mdna:45]
|  | Three Months Ended June 30, |  |  |  |  |  | Nine Months Ended June 30, |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Equity income | $ | 47 |  |  | $ | 62 |  |  | -24 | % |  | $ | 110 |  |  | $ | 137 |  |  | -20 | % |

[0000833444-20-000036:mdna:46]
The decrease in equity income for the three months ended June 30, 2020 was primarily due to lower income at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture primarily due to the unfavorable impact of the COVID-19 pandemic. Foreign currency translation had an unfavorable impact on equity income of $2 million for the three months ended June 30, 2020. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-20-000036:mdna:47]
The decrease in equity income for the nine months ended June 30, 2020 was primarily due to lower income at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture primarily due to the unfavorable impact of the COVID-19 pandemic. Foreign currency translation had an unfavorable impact on equity income of $4 million for the nine months ended June 30, 2020. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-20-000036:mdna:48]
Income Tax Provision (Benefit)

[0000833444-20-000036:mdna:49]
|  | Three Months Ended June 30, |  |  |  |  |  | Nine Months Ended June 30, |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Income tax provision (benefit) | $ | (1) |  |  | $ | 239 |  |  | * |  | $ | 77 |  |  | $ | 394 |  |  | -80 | % |
| Effective tax rate | 1 | % |  | 52 | % |  |  |  | 20 | % |  | 38 | % |  |  |

[0000833444-20-000036:mdna:50]
[same as prior period, unchanged from 0000833444-20-000015:mdna:49]

[0000833444-20-000036:mdna:51]
[same as prior period, unchanged from 0000833444-20-000015:mdna:45]

[0000833444-20-000036:mdna:52]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended June 30, 2020, the Company's effective tax rate for continuing operations was 1% and was lower than the statutory tax rate of 12.5% primarily due to tax audit reserve adjustments, the income tax effects of mark-to-market adjustments and the benefits of continuing global tax planning initiatives, partially offset by the tax impact of an impairment charge and tax rate differentials. For the nine months ended June 30, 2020, the Company's effective tax rate for continuing operations was 20% and was higher than the statutory tax rate of 12.5% primarily due to a discrete tax charge related to the remeasurement of deferred tax assets and liabilities as a result of Swiss tax reform, the tax impact of an impairment charge and tax rate differentials, partially offset by tax audit reserve adjustments, the income tax effects of mark-to-market adjustments and the benefits of continuing global tax planning initiatives. For the three months ended June 30, 2019, the Company's effective tax rate for continuing operations was 52% and was higher than the statutory tax rate of 12.5% primarily due to a discrete tax charge related to newly enacted regulations related to U.S. Tax Reform, non-U.S. tax audit reserve adjustments and tax rate differentials, partially offset by a tax indemnification reserve release, the tax benefits of an asset held for sale impairment charge and continuing global tax planning initiatives. For the nine months ended June 30, 2019, the Company's effective tax rate for continuing operations was 38% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments as a result of tax law changes, a discrete tax charge related to newly enacted regulations related to U.S. Tax Reform, non-U.S. tax audit reserve adjustments, and tax rate differentials, partially offset by a tax indemnification reserve release, the tax benefits of an asset held for sale impairment charge and continuing global tax planning initiatives. The effective tax rate for the nine months ended June 30, 2020 decreased as compared to the nine months ended June 30, 2019 primarily due to the discrete tax items. Refer to Note 10, "Income Taxes," of the notes to consolidated financial statements for further detail.

[0000833444-20-000036:mdna:53]
[same as prior period, unchanged from 0000833444-20-000015:mdna:47]

[0000833444-20-000036:mdna:54]
|  | Three Months Ended June 30, |  |  |  |  |  | Nine Months Ended June 30, |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Income from discontinued operations, net of tax | $ | — |  |  | $ | 4,051 |  |  | * |  | $ | — |  |  | $ | 4,598 |  |  | * |

[0000833444-20-000036:mdna:55]
[same as prior period, unchanged from 0000833444-20-000015:mdna:53]

[0000833444-20-000036:mdna:56]
[same as prior period, unchanged from 0000833444-20-000015:mdna:50]

[0000833444-20-000036:mdna:57]
[same as prior period, unchanged from 0000833444-20-000015:mdna:51]

[0000833444-20-000036:mdna:58]
|  | Three Months Ended June 30, |  |  |  |  |  | Nine Months Ended June 30, |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 60 |  |  | $ | 84 |  |  | -29 | % |  | $ | 115 |  |  | $ | 147 |  |  | -22 | % |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  | — |  |  | * |  | — |  |  | 24 |  |  | * |

[0000833444-20-000036:mdna:59]
[same as prior period, unchanged from 0000833444-20-000015:mdna:62]

[0000833444-20-000036:mdna:60]
The decrease in income from continuing operations attributable to noncontrolling interests for the three and nine months ended June 30, 2020 was primarily due to lower net income as a result of the COVID-19 pandemic at certain partially-owned affiliates within the Global Products segment.

[0000833444-20-000036:mdna:61]
[same as prior period, unchanged from 0000833444-20-000015:mdna:55]

[0000833444-20-000036:mdna:62]
Net Income (Loss) Attributable to Johnson Controls

[0000833444-20-000036:mdna:63]
|  | Three Months Ended June 30, |  |  |  |  |  | Nine Months Ended June 30, |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Net income (loss) attributable to Johnson Controls | $ | (182) |  |  | $ | 4,192 |  |  | * |  | $ | 190 |  |  | $ | 5,062 |  |  | -96 | % |

[0000833444-20-000036:mdna:64]
* Measure not meaningful

[0000833444-20-000036:mdna:65]
The increase in net loss attributable to Johnson Controls for the three months ended June 30, 2020 was primarily due to the prior year income from discontinued operations, current year restructuring and impairment charges and the unfavorable impact of the COVID-19 pandemic, partially offset by lower income tax provision and net financing charges. The decrease in net income attributable to Johnson Controls for the nine months ended June 30, 2020 was primarily due to the prior year income from discontinued operations, current year restructuring and impairment charges and the unfavorable impact of the COVID-19 pandemic, partially offset by lower income tax provision and net financing charges.

[0000833444-20-000036:mdna:66]
Diluted earnings (loss) per share attributable to Johnson Controls for the three months ended June 30, 2020 was $(0.24) compared to $4.79 for the three months ended June 30, 2019. Diluted earnings per share attributable to Johnson Controls for the nine months ended June 30, 2020 was $0.25 compared to $5.61 for the nine months ended June 30, 2019.

[0000833444-20-000036:mdna:67]
[same as prior period, unchanged from 0000833444-20-000015:mdna:60]

[0000833444-20-000036:mdna:68]
|  | Three Months Ended June 30, |  |  |  |  |  | Nine Months Ended June 30, |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Comprehensive income (loss) attributable to Johnson Controls | $ | (104) |  |  | $ | 4,097 |  |  | * |  | $ | 42 |  |  | $ | 4,969 |  |  | -99 | % |

[0000833444-20-000036:mdna:69]
* Measure not meaningful

[0000833444-20-000036:mdna:70]
The increase in comprehensive loss attributable to Johnson Controls for the three months ended June 30, 2020 was due to lower net income attributable to Johnson Controls ($4,374 million), partially offset by an increase in other comprehensive income attributable to Johnson Controls ($173 million) resulting primarily from favorable currency translation adjustments. The year-

[0000833444-20-000036:mdna:71]
52

[0000833444-20-000036:mdna:72]
over-year favorable foreign currency translation adjustments were primarily driven by the strengthening of the euro, Canadian dollar and Mexican peso against the U.S. dollar in the current quarter.

[0000833444-20-000036:mdna:73]
The decrease in comprehensive income attributable to Johnson Controls for the nine months ended June 30, 2020 was due to lower net income attributable to Johnson Controls ($4,872 million) and an increase in other comprehensive loss attributable to Johnson Controls ($55 million) resulting primarily from unfavorable currency translation adjustments. The year-over-year unfavorable foreign currency translation adjustments were primarily driven by the weakening of the Canadian dollar, Mexican peso and Brazilian real currencies, partially offset by the strengthening of the euro against the U.S. dollar in the current year.

[0000833444-20-000036:mdna:74]
[same as prior period, unchanged from 0000833444-20-000015:mdna:65]

[0000833444-20-000036:mdna:75]
[same as prior period, unchanged from 0000833444-20-000015:mdna:66]

[0000833444-20-000036:mdna:76]
[same as prior period, unchanged from 0000833444-20-000015:mdna:67]

[0000833444-20-000036:mdna:77]
|  | Three Months Ended June 30, |  |  |  |  |  | Nine Months Ended June 30, |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Building Solutions North America | $ | 2,020 |  |  | $ | 2,327 |  |  | -13 | % |  | $ | 6,362 |  |  | $ | 6,630 |  |  | -4 | % |
| Building Solutions EMEA/LA | 756 |  |  | 922 |  |  | -18 | % |  | 2,534 |  |  | 2,707 |  |  | -6 | % |
| Building Solutions Asia Pacific | 588 |  |  | 691 |  |  | -15 | % |  | 1,742 |  |  | 1,932 |  |  | -10 | % |
| Global Products | 1,979 |  |  | 2,511 |  |  | -21 | % |  | 5,725 |  |  | 6,425 |  |  | -11 | % |
|  | $ | 5,343 |  |  | $ | 6,451 |  |  | -17 | % |  | $ | 16,363 |  |  | $ | 17,694 |  |  | -8 | % |

[0000833444-20-000036:mdna:78]
[same as prior period, unchanged from 0000833444-20-000015:mdna:69]

[0000833444-20-000036:mdna:79]
•The decrease in Building Solutions North America was due to lower volumes ($299 million) and the unfavorable impact of foreign currency translation ($8 million). The decrease in volumes was primarily attributable to the unfavorable impact of the COVID-19 pandemic.

[0000833444-20-000036:mdna:80]
•The decrease in Building Solutions EMEA/LA was primarily attributable to lower volumes ($134 million) and the unfavorable impact of foreign currency translation ($44 million), partially offset by incremental sales related to business acquisitions ($12 million). The decrease in volumes was primarily attributable to the unfavorable impact of the COVID-19 pandemic.

[0000833444-20-000036:mdna:81]
•The decrease in Building Solutions Asia Pacific was due to lower volumes ($86 million) and the unfavorable impact of foreign currency translation ($19 million), partially offset by incremental sales related to business acquisitions ($2 million). The decrease in volumes was primarily attributable to the unfavorable impact of the COVID-19 pandemic.

[0000833444-20-000036:mdna:82]
•The decrease in Global Products was due to lower volumes ($518 million) and the unfavorable impact of foreign currency translation ($16 million), partially offset by incremental sales related to business acquisitions ($2 million). The decrease in volumes was primarily attributable to the unfavorable impact of the COVID-19 pandemic.

[0000833444-20-000036:mdna:83]
[same as prior period, unchanged from 0000833444-20-000015:mdna:74]

[0000833444-20-000036:mdna:84]
•The decrease in Building Solutions North America was due to lower volumes ($258 million) and the unfavorable impact of foreign currency translation ($10 million). The decrease in volumes was primarily attributable to an increase in installation / services being more than offset by the unfavorable impact of the COVID-19 pandemic.

[0000833444-20-000036:mdna:85]
•The decrease in Building Solutions EMEA/LA was primarily attributable to the unfavorable impact of foreign currency translation ($102 million), lower volumes ($91 million) and lower volumes due to business divestitures ($7 million), partially offset by incremental sales related to business acquisitions ($27 million). The decrease in volumes

[0000833444-20-000036:mdna:86]
was primarily attributable to an increase in installation / services sales being more than offset by the unfavorable impact of the COVID-19 pandemic.

[0000833444-20-000036:mdna:87]
•The decrease in Building Solutions Asia Pacific was due to lower volumes ($157 million) and the unfavorable impact of foreign currency translation ($39 million), partially offset by incremental sales related to business acquisitions ($6 million). The decrease in volumes was primarily attributable to an increase in installation / services sales being more than offset by the unfavorable impact of the COVID-19 pandemic.

[0000833444-20-000036:mdna:88]
•The decrease in Global Products was due to lower volumes ($674 million), the unfavorable impact of foreign currency translation ($26 million) and lower volumes due to business divestitures ($5 million), partially offset by incremental sales related to business acquisitions ($5 million). The decrease in volumes was primarily attributable to an increase in building management and specialty product sales being more than offset by the unfavorable impact of the COVID-19 pandemic.

[0000833444-20-000036:mdna:89]
[same as prior period, unchanged from 0000833444-20-000015:mdna:80]

[0000833444-20-000036:mdna:90]
|  | Three Months Ended June 30, |  |  |  |  |  | Nine Months Ended June 30, |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  | 2020 |  | 2019 |  | Change |
| Building Solutions North America | $ | 307 |  |  | $ | 300 |  |  | 2 | % |  | $ | 816 |  |  | $ | 807 |  |  | 1 | % |
| Building Solutions EMEA/LA | 62 |  |  | 101 |  |  | -39 | % |  | 237 |  |  | 258 |  |  | -8 | % |
| Building Solutions Asia Pacific | 92 |  |  | 98 |  |  | -6 | % |  | 229 |  |  | 240 |  |  | -5 | % |
| Global Products | 378 |  |  | 333 |  |  | 14 | % |  | 797 |  |  | 774 |  |  | 3 | % |
|  | $ | 839 |  |  | $ | 832 |  |  | 1 | % |  | $ | 2,079 |  |  | $ | 2,079 |  |  | — | % |

[0000833444-20-000036:mdna:91]
[same as prior period, unchanged from 0000833444-20-000015:mdna:82]

[0000833444-20-000036:mdna:92]
•The increase in Building Solutions North America was due to prior year integration costs ($10 million), and productivity savings and cost mitigation actions, net of unfavorable volumes ($2 million), partially offset by current year integration costs ($4 million) and the unfavorable impact of foreign currency translation ($1 million).

[0000833444-20-000036:mdna:93]
•The decrease in Building Solutions EMEA/LA was due to unfavorable volumes, net of productivity savings and cost mitigation actions ($34 million), the unfavorable impact of foreign currency translation ($7 million) and lower equity income ($2 million), partially offset by higher income due to business acquisitions ($2 million) and prior year integration costs ($2 million).

[0000833444-20-000036:mdna:94]
•The decrease in Building Solutions Asia Pacific was due to unfavorable volumes, net of productivity savings and cost mitigation actions ($5 million) and the unfavorable impact of foreign currency translation ($1 million).

[0000833444-20-000036:mdna:95]
•The increase in Global Products was due to prior year environmental charge ($140 million) and prior year integration costs ($8 million), partially offset by unfavorable volumes, net of favorable price / cost, productivity savings and cost mitigation actions ($79 million), lower equity income driven primarily by the unfavorable impact of COVID-19 ($12 million), current year integration costs ($7 million), the unfavorable impact of foreign currency translation ($4 million) and lower income due to business acquisitions ($1 million).

[0000833444-20-000036:mdna:96]
[same as prior period, unchanged from 0000833444-20-000015:mdna:87]

[0000833444-20-000036:mdna:97]
•The increase in Building Solutions North America was due to prior year integration costs ($15 million), and productivity savings and cost mitigation actions, net of unfavorable volumes ($2 million), partially offset by current year integration costs ($7 million) and the unfavorable impact of foreign currency translation ($1 million).

[0000833444-20-000036:mdna:98]
•The decrease in Building Solutions EMEA/LA was due to the unfavorable impact of foreign currency translation ($16 million), unfavorable volumes, net of productivity savings and cost mitigation actions ($12 million), and lower income due to business divestitures ($1 million), partially offset by higher income due to business acquisitions ($5 million) and prior year integration costs ($3 million).

[0000833444-20-000036:mdna:99]
•The decrease in Building Solutions Asia Pacific was due to unfavorable volumes, net of productivity savings and cost mitigation actions ($10 million) and the unfavorable impact of foreign currency translation ($2 million), partially offset by higher income due to business acquisitions ($1 million).

[0000833444-20-000036:mdna:100]
•The increase in Global Products was due to prior year environmental charge ($140 million) and prior year integration costs ($16 million), partially offset by unfavorable volumes, net of favorable price / cost, productivity savings and cost mitigation actions ($91 million), lower equity income driven primarily by the unfavorable impact of COVID-19 ($24 million), current year integration costs ($8 million), the unfavorable impact of foreign currency translation ($7 million), lower income due to business acquisitions ($2 million) and lower income due to business divestitures ($1 million).

[0000833444-20-000036:mdna:101]
[same as prior period, unchanged from 0000833444-20-000015:mdna:93]

[0000833444-20-000036:mdna:102]
The Company’s backlog relating to the Building Technologies & Solutions business is applicable to its sales of systems and services. At June 30, 2020, the backlog was $9.4 billion, of which $9.1 billion was attributable to the field business. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-20-000036:mdna:103]
In the first quarter of fiscal 2019, the Company adopted ASC 606, “Revenue from Contracts with Customers,” and as a result is required to disclose remaining performance obligations. At June 30, 2020, remaining performance obligations were $14.4 billion, which is $5.0 billion higher than the Company's backlog of $9.4 billion. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-20-000036:mdna:104]
•Remaining performance obligations include large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which are services to be performed over the building's lifetime with initial contract terms of 25 to 35 years for the entire term of the contract versus backlog which includes only the lifecycle period of these contracts which approximates five years;

[0000833444-20-000036:mdna:105]
•The Company has elected to exclude from remaining performance obligations certain contracts with customers with a term of one year or less or contracts that are cancelable without substantial penalty while these contracts are included within backlog; and

[0000833444-20-000036:mdna:106]
•Remaining performance obligations include the full remaining term of service contracts with substantial termination penalties versus backlog which includes one year for all outstanding service contracts.

[0000833444-20-000036:mdna:107]
[same as prior period, unchanged from 0000833444-20-000015:mdna:99]

[0000833444-20-000036:mdna:108]
[same as prior period, unchanged from 0000833444-20-000015:mdna:100]

[0000833444-20-000036:mdna:109]
[same as prior period, unchanged from 0000833444-20-000015:mdna:101]

[0000833444-20-000036:mdna:110]
|  | June 30, |  | September 30, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |
| Current assets | $ | 11,140 |  |  | $ | 12,393 |  |  |  |
| Current liabilities | (10,304) |  |  | (9,070) |  |  |  |
|  | 836 |  |  | 3,323 |  |  | -75 | % |
| Less: Cash | (2,342) |  |  | (2,805) |  |  |  |
| Add: Short-term debt | 1,321 |  |  | 10 |  |  |  |
| Add: Current portion of long-term debt | 1,102 |  |  | 501 |  |  |  |
| Less: Assets held for sale | (89) |  |  | (98) |  |  |  |
| Add: Liabilities held for sale | 38 |  |  | 44 |  |  |  |
| Working capital (as defined) | $ | 866 |  |  | $ | 975 |  |  | -11 | % |
| Accounts receivable - net | $ | 5,344 |  |  | $ | 5,770 |  |  | -7 | % |
| Inventories | 1,996 |  |  | 1,814 |  |  | 10 | % |
| Accounts payable | 3,057 |  |  | 3,582 |  |  | -15 | % |

[0000833444-20-000036:mdna:111]
•The Company defines working capital as current assets less current liabilities, excluding cash, short-term debt, the current portion of long-term debt, and the current portions of assets and liabilities held for sale. Management believes that this measure of working capital, which excludes financing-related items and businesses to be divested, provides a more useful measurement of the Company’s operating performance.

[0000833444-20-000036:mdna:112]
•The decrease in working capital at June 30, 2020 as compared to September 30, 2019, was primarily due to lower income tax assets, a decrease in accounts receivable, and the establishment of an operating lease liability on the balance sheet in the first quarter of fiscal 2020 as a result of the adoption of ASC 842, partially offset by a decrease in accounts payable due to lower spending, a decrease in accrued compensation and benefits liabilities and an increase in inventory.

[0000833444-20-000036:mdna:113]
•The Company’s days sales in accounts receivable at June 30, 2020 and September 30, 2019 were 70 days and 67 days, respectively. There has been no significant adverse changes in the level of overdue receivables or significant changes in revenue recognition methods.

[0000833444-20-000036:mdna:114]
•The Company’s inventory turns for the three months ended June 30, 2020 were lower than the comparable period ended September 30, 2019, primarily due to changes in inventory production levels.

[0000833444-20-000036:mdna:115]
•Days in accounts payable at June 30, 2020 were 73 days, higher than 72 days at the comparable period ended September 30, 2019.

[0000833444-20-000036:mdna:116]
[same as prior period, unchanged from 0000833444-20-000015:mdna:108]

[0000833444-20-000036:mdna:117]
|  |  | Nine Months Ended June 30, |  |  |
| (in millions) |  | 2020 |  | 2019 |
| Cash provided by operating activities |  | $ | 1,499 |  |  | $ | 711 |  |
| Cash used by investing activities |  | (309) |  |  | (363) |  |
| Cash used by financing activities |  | (1,316) |  |  | (9,500) |  |

[0000833444-20-000036:mdna:118]
•The increase in cash provided by operating activities was primarily due to the timing of income tax payments / refunds and favorable changes in accounts receivable, partially offset by unfavorable changes in accounts payable and accrued liabilities.

[0000833444-20-000036:mdna:119]
•The decrease in cash used by investing activities was primarily due to lower capital expenditures and higher net cash payments made for acquisitions, partially offset by higher proceeds from the sale of property, plant & equipment.

[0000833444-20-000036:mdna:120]
•The decrease in cash used by financing activities was primarily due to lower stock repurchases, higher short-term debt borrowings and lower repayments of long-term debt.

[0000833444-20-000036:mdna:121]
[same as prior period, unchanged from 0000833444-20-000015:mdna:113]

[0000833444-20-000036:mdna:122]
|  | June 30, |  | September 30, |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |
| Short-term debt | $ | 1,321 |  |  | $ | 10 |  |  |  |
| Current portion of long-term debt | 1,102 |  |  | 501 |  |  |  |
| Long-term debt | 5,671 |  |  | 6,708 |  |  |  |
| Total debt | 8,094 |  |  | 7,219 |  |  | 12 | % |
| Less: cash and cash equivalents | 2,342 |  |  | 2,805 |  |  |  |
| Total net debt | 5,752 |  |  | 4,414 |  |  | 30 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 17,805 |  |  | 19,766 |  |  | -10 | % |
| Total capitalization | $ | 23,557 |  |  | $ | 24,180 |  |  | -3 | % |
| Total net debt as a % of total capitalization | 24.4 | % |  | 18.3 | % |  |  |

[0000833444-20-000036:mdna:123]
•Net debt and net debt as a percentage of total capitalization are non-GAAP financial measures. The Company believes the percentage of total net debt to total capitalization is useful to understanding the Company’s financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders.

[0000833444-20-000036:mdna:124]
•The Company believes its capital resources and liquidity position at June 30, 2020 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, minimum pension contributions, debt maturities and any potential acquisitions or stock repurchases in the remainder of fiscal 2020 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company is unable to issue commercial paper, it would have the ability to draw on its $2.5 billion and $0.5 billion revolving credit facilities. The facilities mature in December 2024 and December 2020, respectively. There were no draws on the revolving credit facilities as of June 30, 2020 and September 30, 2019. In addition, the Company held cash and cash equivalents of $1.0 billion as of June 30, 2020. Given the increasingly uncertain economic environment caused by the COVID-19 pandemic, the Company took proactive measures in April 2020 to increase near-term financial flexibility, electing to opportunistically raise $675 million via European financing arrangements and $575 million in bank term loans.

[0000833444-20-000036:mdna:125]
This new debt partially replaces a recently matured $500 million bond, which was repaid in March 2020. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future.

[0000833444-20-000036:mdna:126]
•The Company’s debt financial covenant in its revolving credit facility requires a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of June 30, 2020, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures, governing its notes, and expect to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-20-000036:mdna:127]
•The key financial assumptions used in calculating the Company’s pension liability are determined annually, or whenever plan assets and liabilities are re-measured as required under accounting principles generally accepted in the U.S., including the expected rate of return on its plan assets. In fiscal 2020, the Company believes the long-term rate of return will approximate 6.90%, 5.20% and 5.70% for U.S. pension, non-U.S. pension and postretirement plans, respectively. During the first nine months of fiscal 2020, the Company made approximately $43 million in total pension and postretirement contributions. In total, the Company expects to contribute approximately $50 million in cash to its defined benefit pension plans in fiscal 2020. The Company expects to contribute $4 million in cash to its postretirement plans in fiscal 2020.

[0000833444-20-000036:mdna:128]
•The Company earns a significant amount of its income outside of the parent company.  Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances. However, in fiscal 2019, the Company provided income tax expense related to a change in the Company's assertion over the outside basis differences of the Company’s investment in certain subsidiaries as a result of the planned divestiture of the Power Solutions business. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. Except as noted, the Company's intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at the Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings.

[0000833444-20-000036:mdna:129]
•To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2020 and recorded a cumulative $297 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the cumulative fiscal 2020 restructuring plan will reduce annual operating costs for continuing operations by approximately $430 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in 2021. For fiscal 2020, the savings, net of execution costs, are expected to be approximately 30% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in fiscal 2021. The restructuring plan reserve balance of $139 million at June 30, 2020 is expected to be paid in cash.

[0000833444-20-000036:mdna:130]
•To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2018 and recorded $255 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost

[0000833444-20-000036:mdna:131]
58

[0000833444-20-000036:mdna:132]
reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2018 restructuring plan will reduce annual operating costs for continuing operations by approximately $300 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in 2020. The restructuring action is expected to be substantially complete in 2020. The restructuring plan reserve balance of $69 million at June 30, 2020 is expected to be paid in cash.

[0000833444-20-000036:mdna:133]
•To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2017 and recorded $347 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions business and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2017 restructuring plan will reduce annual operating costs for continuing operations by approximately $260 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company substantially realized the annual benefit of these actions in fiscal 2019. The restructuring actions are expected to be substantially complete in fiscal 2020. The restructuring plan reserve balance of $21 million at June 30, 2020 is expected to be paid in cash.

[0000833444-20-000036:mdna:134]
•Refer to Note 12, "Debt and Financing Arrangements," of the notes to consolidated financial statements for additional information on items impacting capitalization.

[0000833444-20-000036:mdna:135]
[same as prior period, unchanged from 0000833444-20-000015:mdna:127]

[0000833444-20-000036:mdna:136]
[same as prior period, unchanged from 0000833444-20-000015:mdna:128]
