# JCI notes — 0000833444-20-000036


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-20-000036:notes:1]
Financial Statements
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2019 filed with the SEC on November 21, 2019. The results of operations for the three and nine month periods ended June 30, 2020 are not necessarily indicative of results for the Company’s 2020 fiscal year because of seasonal and other factors.

[0000833444-20-000036:notes:2]
[same as prior period, unchanged from 0000833444-20-000015:notes:3]

[0000833444-20-000036:notes:3]
[same as prior period, unchanged from 0000833444-20-000015:notes:4]

[0000833444-20-000036:notes:4]
[same as prior period, unchanged from 0000833444-20-000015:notes:5]

[0000833444-20-000036:notes:5]
[same as prior period, unchanged from 0000833444-20-000015:notes:6]

[0000833444-20-000036:notes:6]
[same as prior period, unchanged from 0000833444-20-000015:notes:7]

[0000833444-20-000036:notes:7]
[same as prior period, unchanged from 0000833444-20-000015:notes:8]

[0000833444-20-000036:notes:8]
[same as prior period, unchanged from 0000833444-20-000015:notes:9]

[0000833444-20-000036:notes:9]
At June 30, 2020 and September 30, 2019, the Company held restricted cash of approximately $13 million and $16 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-20-000036:notes:10]
Acquisitions and Divestitures
During the first nine months of fiscal 2020, the Company completed certain acquisitions for a combined purchase price, net of cash acquired, of $63 million, of which $59 million was paid as of June 30, 2020. In connection with the acquisitions, the Company recorded goodwill of $19 million within the Global Products segment and $23 million within the Building Solutions EMEA/LA segment. The acquisitions were not material to the Company's consolidated financial statements.

[0000833444-20-000036:notes:11]
On April 30, 2019, the Company completed the sale of its Power Solutions business to BCP Acquisitions LLC for a purchase price of $13.2 billion. The net cash proceeds after tax and transaction-related expenses were $11.6 billion. In connection with the sale, the Company recorded a gain, net of transaction and other costs, of $5.2 billion ($4.0 billion after tax), subject to post-closing working capital and net debt adjustments, within income from discontinued operations, net of tax, in the consolidated statements of income. During the first quarter of fiscal 2019, the Company determined that its Power Solutions business met the criteria to be classified as a discontinued operation and, as a result, Power Solutions' historical financial results are reflected in the Company's consolidated financial statements as a discontinued operation. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further disclosure related to the Company's discontinued operations.

[0000833444-20-000036:notes:12]
During the first nine months of fiscal 2019, the Company completed certain divestitures within the Global Products and Building Solutions EMEA/LA businesses. The combined selling price was $18 million, $12 million of which was received as of June 30, 2019. In connection with the sale, the Company reduced goodwill by $1 million within the Building Solutions EMEA/LA segment. The divestitures were not material to the Company's consolidated financial statements. 
During the first nine months of fiscal 2019, the Company completed certain acquisitions for a combined purchase price of $16 million, all of which was paid as of June 30, 2019. In connection with the acquisition, the Company recorded goodwill of $9 million within the Global Products segment and $1 million within the Building Solutions EMEA/LA segment. The acquisitions were not material to the Company's consolidated financial statements.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-20-000036:notes:13]
Discontinued OperationsOn November 13, 2018, the Company entered into a Stock and Asset Purchase Agreement (“Purchase Agreement”) with BCP Acquisitions LLC (“Purchaser”). The Purchaser was a newly-formed entity controlled by investment funds managed by Brookfield Capital Partners LLC. Pursuant to the Purchase Agreement, on the terms and subject to the conditions therein, the Company agreed to sell, and Purchaser agreed to acquire, the Company’s Power Solutions business for a purchase price of $13.2 billion. The transaction closed on April 30, 2019 with net cash proceeds of $11.6 billion after tax and transaction-related expenses. 
During the first quarter of fiscal 2019, the Company determined that its Power Solutions business met the criteria to be classified as a discontinued operation and, as a result, Power Solutions' historical financial results are reflected in the Company's consolidated financial statements as a discontinued operation, and assets and liabilities were retrospectively reclassified as assets and liabilities held for sale. The Company did not allocate any general corporate overhead to discontinued operations.

[0000833444-20-000036:notes:14]
The following table summarizes the results of Power Solutions reclassified as discontinued operations for the three and nine month periods ended June 30, 2019 (in millions):

[0000833444-20-000036:notes:15]
|  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  | 2019 |  | 2019 |
| Net sales | $ | 562 |  |  | $ | 5,001 |  |
| Income from discontinued operations before income taxes | 5,315 |  |  | 6,039 |  |
| Provision for income taxes on discontinued operations | (1,264) |  |  | (1,441) |  |
| Income from discontinued operations attributable to noncontrolling interests, net of tax | — |  |  | (24) |  |
| Income from discontinued operations | $ | 4,051 |  |  | $ | 4,574 |  |

[0000833444-20-000036:notes:16]
For the three months ended June 30, 2019, income from discontinued operations before income taxes included a gain on sale of the Power Solutions business, net of transaction and other costs, of $5.2 billion and a favorable impact of $21 million for ceasing depreciation and amortization expense as the business was held for sale. For the nine months ended June 30, 2019, income from discontinued operations before income taxes included a gain on sale of the Power Solutions business, net of transaction and other costs, of $5.2 billion and a favorable impact of $117 million for ceasing depreciation and amortization expense as the business was held for sale.

[0000833444-20-000036:notes:17]
For the three and nine months ended June 30, 2019, the effective tax rate was more than the Irish statutory rate of 12.5% primarily due to the tax impacts of the divestiture of the Power Solutions business and tax rate differentials.

[0000833444-20-000036:notes:18]
[same as prior period, unchanged from 0000833444-20-000015:notes:23]

[0000833444-20-000036:notes:19]
During the third quarter of fiscal 2019, the Company determined that a business within its Global Products segment met the criteria to be classified as held for sale. The assets and liabilities of this business are presented as held for sale in the consolidated statements of financial position as of June 30, 2020 and September 30, 2019. Assets and liabilities held for sale are required to be recorded at the lower of carrying value or fair value less any costs to sell. Accordingly, the Company has recorded total impairment charges of $250 million within restructuring and impairment costs in the consolidated statements of income to write down the carrying value of the assets held for sale to fair value less any costs to sell. Of the $250 million total impairment charges, $235 million was recorded during the third quarter of fiscal 2019, and $15 million was recorded during the first quarter of fiscal 2020. Refer to Note 18, "Impairment of Long-Lived Assets" of the notes to consolidated financial statements for further information regarding the impairment charges. The divestiture of the business held for sale could result in a gain or loss on sale to the extent the ultimate selling price differs from the current carrying value of the net assets recorded. The business did not meet the criteria to be classified as a discontinued operation as the divestiture of the business will not have a major effect on the Company's operations and financial results.
During the third quarter of fiscal 2020, the Company determined that certain assets of the Building Solutions Asia Pacific segment, with an estimated fair value, less costs to sell, of $141 million met the criteria to be classified as held for sale.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000833444-20-000036:notes:20]
Revenue Recognition
Disaggregated Revenue

[0000833444-20-000036:notes:21]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three and nine months ended June 30, 2020 and 2019 (in millions):

[0000833444-20-000036:notes:22]
|  |  | Three Months Ended June 30, 2020 |  |  |  |  |  | Three Months Ended June 30, 2019 |  |  |  |  |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,250 |  |  | $ | 770 |  |  | $ | 2,020 |  |  | $ | 1,494 |  |  | $ | 833 |  |  | $ | 2,327 |  |
| Building Solutions EMEA/LA |  | 346 |  |  | 410 |  |  | 756 |  |  | 464 |  |  | 458 |  |  | 922 |  |
| Building Solutions Asia Pacific |  | 344 |  |  | 244 |  |  | 588 |  |  | 427 |  |  | 264 |  |  | 691 |  |
| Global Products |  | 1,979 |  |  | — |  |  | 1,979 |  |  | 2,511 |  |  | — |  |  | 2,511 |  |
| Total |  | $ | 3,919 |  |  | $ | 1,424 |  |  | $ | 5,343 |  |  | $ | 4,896 |  |  | $ | 1,555 |  |  | $ | 6,451 |  |

[0000833444-20-000036:notes:23]
|  |  | Nine Months Ended June 30, 2020 |  |  |  |  |  | Nine Months Ended June 30, 2019 |  |  |  |  |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,963 |  |  | $ | 2,399 |  |  | $ | 6,362 |  |  | $ | 4,202 |  |  | $ | 2,428 |  |  | $ | 6,630 |  |
| Building Solutions EMEA/LA |  | 1,203 |  |  | 1,331 |  |  | 2,534 |  |  | 1,297 |  |  | 1,410 |  |  | 2,707 |  |
| Building Solutions Asia Pacific |  | 986 |  |  | 756 |  |  | 1,742 |  |  | 1,134 |  |  | 798 |  |  | 1,932 |  |
| Global Products |  | 5,725 |  |  | — |  |  | 5,725 |  |  | 6,425 |  |  | — |  |  | 6,425 |  |
| Total |  | $ | 11,877 |  |  | $ | 4,486 |  |  | $ | 16,363 |  |  | $ | 13,058 |  |  | $ | 4,636 |  |  | $ | 17,694 |  |

[0000833444-20-000036:notes:24]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and nine months ended June 30, 2020 and 2019 (in millions):

[0000833444-20-000036:notes:25]
|  |  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Building management systems |  | $ | 244 |  |  | $ | 342 |  |  | $ | 860 |  |  | $ | 943 |  |
| HVAC & refrigeration equipment |  | 1,493 |  |  | 1,869 |  |  | 4,085 |  |  | 4,628 |  |
| Specialty products |  | 242 |  |  | 300 |  |  | 780 |  |  | 854 |  |
| Total |  | $ | 1,979 |  |  | $ | 2,511 |  |  | $ | 5,725 |  |  | $ | 6,425 |  |

[0000833444-20-000036:notes:26]
[same as prior period, unchanged from 0000833444-20-000015:notes:32]

[0000833444-20-000036:notes:27]
[same as prior period, unchanged from 0000833444-20-000015:notes:33]

[0000833444-20-000036:notes:28]
[same as prior period, unchanged from 0000833444-20-000015:notes:34]

[0000833444-20-000036:notes:29]
|  |  | Location of contract balances |  | June 30, 2020 |  | September 30, 2019 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,409 |  |  | $ | 1,389 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 98 |  |  | 90 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,451) |  |  | (1,407) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (120) |  |  | (117) |  |  |  |
| Total |  |  |  | $ | (64) |  |  | $ | (45) |  |  |  |

[0000833444-20-000036:notes:30]
For the three months ended June 30, 2020 and June 30, 2019, the Company recognized revenue of $125 million and $130 million, respectively, that was included in the beginning of period contract liability balance. For the nine months ended June 30, 2020 and June 30, 2019, the Company recognized revenue of $1,137 million and $1,056 million, respectively, that was included in the beginning of period contract liability balance.

[0000833444-20-000036:notes:31]
[same as prior period, unchanged from 0000833444-20-000015:notes:37]

[0000833444-20-000036:notes:32]
[same as prior period, unchanged from 0000833444-20-000015:notes:38]

[0000833444-20-000036:notes:33]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of June 30, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $14.4 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

[0000833444-20-000036:notes:34]
[same as prior period, unchanged from 0000833444-20-000015:notes:40]

[0000833444-20-000036:notes:35]
[same as prior period, unchanged from 0000833444-20-000015:notes:41]

[0000833444-20-000036:notes:36]
As of June 30, 2020, the Company recorded the costs to obtain or fulfill a contract of $224 million, of which $121 million is recorded within other current assets and $103 million is recorded within other noncurrent assets in the consolidated statements of financial position. As of September 30, 2019, the Company recorded the costs to obtain or fulfill a contract of $212 million, of which $110 million is recorded within other current assets and $102 million is recorded within other noncurrent assets in the consolidated statements of financial position.

[0000833444-20-000036:notes:37]
During the three months ended June 30, 2020 and 2019, the Company recognized amortization expense of $47 million and $50 million, respectively, related to costs to obtain or fulfill a contract. During the nine months ended June 30, 2020 and 2019, the Company recognized amortization expense of $116 million and $119 million, respectively, related to costs to 
obtain or fulfill a contract.  There were no impairment losses recognized in the three and nine months ended June 30, 2020 and 2019.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000833444-20-000036:notes:38]
Leases
Lessee arrangements

[0000833444-20-000036:notes:39]
[same as prior period, unchanged from 0000833444-20-000015:notes:46]

[0000833444-20-000036:notes:40]
[same as prior period, unchanged from 0000833444-20-000015:notes:47]

[0000833444-20-000036:notes:41]
[same as prior period, unchanged from 0000833444-20-000015:notes:48]

[0000833444-20-000036:notes:42]
[same as prior period, unchanged from 0000833444-20-000015:notes:49]

[0000833444-20-000036:notes:43]
The following table presents the Company’s lease costs for the three and nine months ended June 30, 2020 (in millions):

[0000833444-20-000036:notes:44]
|  |  | Three Months Ended June 30, |  | Nine Months Ended June 30, |
|  |  | 2020 |  | 2020 |
| Operating lease cost |  | $ | 97 |  |  | $ | 294 |  |
| Variable lease cost |  | 36 |  |  | 113 |  |
| Total lease costs |  | $ | 133 |  |  | $ | 407 |  |

[0000833444-20-000036:notes:45]
The following table presents supplemental consolidated statement of financial position information as of June 30, 2020 (in millions):

[0000833444-20-000036:notes:46]
|  | Location of lease balances |  | June 30, 2020 |
| Operating lease right-of-use assets | Other noncurrent assets |  | $ | 1,127 |  |
| Operating lease liabilities - current | Other current liabilities |  | 322 |  |
| Operating lease liabilities - noncurrent | Other noncurrent liabilities |  | 820 |  |
| Weighted-average remaining lease term |  |  | 6 years |
| Weighted-average discount rate |  |  | 2.3 | % |

[0000833444-20-000036:notes:47]
The following table presents supplemental cash flow information related to operating leases for the three and nine months ended June 30, 2020 (in millions):

[0000833444-20-000036:notes:48]
|  |  | Three Months Ended June 30, 2020 |  | Nine Months Ended June 30, 2020 |
| Cash paid for amounts included in the measurement of lease liability: |  |  |  |  |
| Operating cash outflows from operating leases |  | $ | 100 |  |  | $ | 297 |  |
| Noncash operating lease activity: |  |  |  |  |
| Right-of-use assets obtained in exchange for operating lease liabilities |  | 141 |  |  | 315 |  |

[0000833444-20-000036:notes:49]
The following table presents maturities of operating lease liabilities as of June 30, 2020 (in millions):

[0000833444-20-000036:notes:50]
|  |  | June 30, 2020 |
| 2020 (3 months) |  | $ | 83 |  |
| 2021 |  | 338 |  |
| 2022 |  | 256 |  |
| 2023 |  | 160 |  |
| 2024 |  | 115 |  |
| After 2024 |  | 278 |  |
| Total operating lease payments |  | 1,230 |  |
| Less interest |  | (88) |  |
| Present value of lease payments |  | $ | 1,142 |  |

[0000833444-20-000036:notes:51]
[same as prior period, unchanged from 0000833444-20-000015:notes:58]

[0000833444-20-000036:notes:52]
[same as prior period, unchanged from 0000833444-20-000015:notes:59]

[0000833444-20-000036:notes:53]
[same as prior period, unchanged from 0000833444-20-000015:notes:60]

[0000833444-20-000036:notes:54]
[same as prior period, unchanged from 0000833444-20-000015:notes:61]


## us-gaap:InventoryDisclosureTextBlock

[0000833444-20-000036:notes:55]
Inventories
Inventories consisted of the following (in millions):

[0000833444-20-000036:notes:56]
|  | June 30, 2020 |  | September 30, 2019 |
| Raw materials and supplies | $ | 661 |  |  | $ | 588 |  |
| Work-in-process | 157 |  |  | 176 |  |
| Finished goods | 1,178 |  |  | 1,050 |  |
| Inventories | $ | 1,996 |  |  | $ | 1,814 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-20-000036:notes:57]
Goodwill and Other Intangible Assets
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the nine month period ended June 30, 2020 were as follows (in millions):

[0000833444-20-000036:notes:58]
|  |  |  | Business Acquisitions |  | Impairments |  |  |  | Currency Translation and Other |  |  |
|  | September 30, |  |  |  |  |  |  |  |  |  | June 30, |
|  | 2019 |  |  |  |  |  |  |  |  |  | 2020 |
| Building Solutions North America | $ | 9,588 |  |  | $ | — |  |  | $ | (424) |  |  |  |  | $ | (20) |  |  | $ | 9,144 |  |
| Building Solutions EMEA/LA | 1,849 |  |  | 23 |  |  | — |  |  |  |  | 3 |  |  | 1,875 |  |
| Building Solutions Asia Pacific | 1,194 |  |  | — |  |  | — |  |  |  |  | 10 |  |  | 1,204 |  |
| Global Products | 5,547 |  |  | 19 |  |  | — |  |  |  |  | (30) |  |  | 5,536 |  |
| Total | $ | 18,178 |  |  | $ | 42 |  |  | $ | (424) |  |  |  |  | $ | (37) |  |  | $ | 17,759 |  |

[0000833444-20-000036:notes:59]
[same as prior period, unchanged from 0000833444-20-000015:notes:68]

[0000833444-20-000036:notes:60]
The Company reviews goodwill for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. The Company considered the ongoing deterioration in general economic and market conditions due to the COVID-19 pandemic and its impact on each of the Company’s reporting units’ performance. Due to further declines in cash flow projections of North America Retail reporting unit in the third quarter of fiscal 2020 as a result of the COVID-19 pandemic, the Company concluded a triggering event occurred requiring assessment of impairment for its North America Retail reporting unit during the quarter ended June 30, 2020. As a result, the Company recorded a non-cash impairment charge of $424 million within restructuring and impairment costs in the consolidated statements of income in the third quarter of fiscal 2020, which was determined by comparing the carrying amount of a reporting unit to its fair value in accordance with ASU No. 2017-04, "Intangible - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment," which the Company early adopted. The North America Retail reporting unit has a remaining goodwill balance of $228 million at June 30, 2020. The Company used a discounted cash flow model to estimate the fair value of the reporting unit. Other than management's internal projections of future cash flows, the primary assumptions used in the model were the weighted-average cost of capital and long-term growth rates, which are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 80, "Fair Value Measurement." Although the Company's cash flow forecasts are based on assumptions that are considered reasonable by management and consistent with the plans and estimates management is using to operate the underlying business, there is significant judgment in determining the expected future cash flows attributable to the North America Retail reporting unit.

[0000833444-20-000036:notes:61]
The Company concluded a triggering event did not occur for any other reporting unit in the third quarter of fiscal 2020 based on the Company’s assessment of its market capitalization, forecasts and the amount of excess of fair value over the carrying value of the reporting units in the fiscal 2019 annual test. The Company continuously monitors for events and circumstances that could negatively impact the key assumptions in determining fair value, including long-term revenue growth projections, profitability, discount rates, recent market valuations from transactions by comparable companies,

[0000833444-20-000036:notes:62]
volatility in the Company's market capitalization, and general industry, market and macro-economic conditions. It is possible that future changes in such circumstances, including a more prolonged and/or severe COVID-19 pandemic, or future changes in the variables associated with the judgments, assumptions and estimates used in assessing the fair value of the reporting unit, would require the Company to record additional non-cash impairment charges.

[0000833444-20-000036:notes:63]
[same as prior period, unchanged from 0000833444-20-000015:notes:70]

[0000833444-20-000036:notes:64]
|  | June 30, 2020 |  |  |  |  |  | September 30, 2019 |  |  |  |  |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Definite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,318 |  |  | $ | (462) |  |  | $ | 856 |  |  | $ | 1,307 |  |  | $ | (370) |  |  | $ | 937 |  |
| Customer relationships | 2,732 |  |  | (906) |  |  | 1,826 |  |  | 2,722 |  |  | (759) |  |  | 1,963 |  |
| Miscellaneous | 636 |  |  | (255) |  |  | 381 |  |  | 584 |  |  | (224) |  |  | 360 |  |
| Total definite-lived intangible assets | 4,686 |  |  | (1,623) |  |  | 3,063 |  |  | 4,613 |  |  | (1,353) |  |  | 3,260 |  |
| Indefinite-lived intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,221 |  |  | — |  |  | 2,221 |  |  | 2,282 |  |  | — |  |  | 2,282 |  |
| Miscellaneous | 80 |  |  | — |  |  | 80 |  |  | 90 |  |  | — |  |  | 90 |  |
|  | 2,301 |  |  | — |  |  | 2,301 |  |  | 2,372 |  |  | — |  |  | 2,372 |  |
| Total intangible assets | $ | 6,987 |  |  | $ | (1,623) |  |  | $ | 5,364 |  |  | $ | 6,985 |  |  | $ | (1,353) |  |  | $ | 5,632 |  |

[0000833444-20-000036:notes:65]
The Company reviews indefinite-lived intangible assets for impairment during the fourth fiscal quarter or more frequently if events or changes in circumstances indicate the asset might be impaired. Indefinite-lived intangible assets primarily consist of trademarks and tradenames and are tested for impairment using a relief-from-royalty method. During the second and third quarters of fiscal 2020, the Company determined that it had a triggering event at each reporting period end requiring assessment of impairment for certain of its indefinite-lived intangible assets due to declines in revenue directly attributable to the COVID-19 pandemic. As a result, the Company recorded an impairment charge of $62 million related primarily to the Company's retail business indefinite-lived intangible assets within restructuring and impairment costs in the consolidated statements of income in the second quarter of fiscal 2020. No further impairment was required to be recorded in the third quarter of fiscal 2020 as a result of the completed impairment assessment. The Company continuously monitors for events and circumstances that could negatively impact the key assumptions in determining fair value, including long-term revenue growth projections, discount rates and general industry, market and macro-economic conditions. It is possible that future changes in such circumstances, including a more prolonged and/or severe COVID-19 pandemic, or future changes in the variables associated with the judgments, assumptions and estimates used in assessing the fair value of the indefinite-lived intangible assets, would require the Company to record an additional non-cash impairment charge.

[0000833444-20-000036:notes:66]
Amortization of other intangible assets included within continuing operations for the three month periods ended June 30, 2020 and 2019 was $95 million and $93 million, respectively. Amortization of other intangible assets included within continuing operations for the nine month periods ended June 30, 2020 and 2019 was $288 million and $288 million, respectively. Excluding the impact of any future acquisitions, the Company anticipates amortization for fiscal 2021, 2022, 2023, 2024 and 2025 will be approximately $398 million, $394 million, $387 million, $369 million and $352 million per year, respectively.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-20-000036:notes:67]
Significant Restructuring and Impairment Costs
To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company commits to restructuring plans as necessary.

[0000833444-20-000036:notes:68]
In fiscal 2020, the Company committed to a significant restructuring plan ("2020 Plan") and recorded $297 million of restructuring and impairment costs in the consolidated statements of income, of which $111 million was recorded in the first quarter and $186 million was recorded in the third quarter of fiscal 2020. This is the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related primarily to cost reduction initiatives. The costs consist primarily of workforce reductions, plant closures and asset impairments. Of the restructuring and impairment costs recorded, $136 million related to the Global Products segment, $64 million related to the Building Solutions North America segment, $49 million related to the Building Solutions Asia Pacific segment, $43 million related to the Building Solutions EMEA/LA segment and $5 million related to Corporate. The restructuring actions are expected to be substantially complete in fiscal 2021.

[0000833444-20-000036:notes:69]
[same as prior period, unchanged from 0000833444-20-000015:notes:77]

[0000833444-20-000036:notes:70]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  |  |  | Total |
| Original reserve | $ | 54 |  |  | $ | 54 |  |  | $ | 3 |  |  |  |  | $ | 111 |  |
| Utilized—cash | (8) |  |  | — |  |  | — |  |  |  |  | (8) |  |
| Utilized—noncash | — |  |  | (54) |  |  | — |  |  |  |  | (54) |  |
| Balance at December 31, 2019 | $ | 46 |  |  | $ | — |  |  | $ | 3 |  |  |  |  | $ | 49 |  |
| Utilized—cash | (24) |  |  | — |  |  | (1) |  |  |  |  | (25) |  |
| Balance at March 31, 2020 | $ | 22 |  |  | $ | — |  |  | $ | 2 |  |  |  |  | $ | 24 |  |
| Additional reserve | 142 |  |  | 42 |  |  | 2 |  |  |  |  | 186 |  |
| Utilized—cash | (28) |  |  | — |  |  | (1) |  |  |  |  | (29) |  |
| Utilized—noncash | — |  |  | (42) |  |  | — |  |  |  |  | (42) |  |
| Balance at June 30, 2020 | $ | 136 |  |  | $ | — |  |  | $ | 3 |  |  |  |  | $ | 139 |  |

[0000833444-20-000036:notes:71]
In the third quarter of fiscal 2020, the Company recorded $424 million of restructuring and impairment costs in the consolidated statements of income for goodwill impairment related to the North America Retail reporting unit. Refer to Note 8, "Goodwill and Other Intangible Assets," of the notes to consolidated financial statements for further information regarding goodwill impairments.

[0000833444-20-000036:notes:72]
[same as prior period, unchanged from 0000833444-20-000015:notes:79]

[0000833444-20-000036:notes:73]
In fiscal 2018, the Company committed to a significant restructuring plan ("2018 Plan") and recorded $255 million of restructuring and impairment costs for continuing operations in the consolidated statements of income. This was the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. Of the restructuring and impairment costs recorded, $113 million related to the Global Products segment, $56 million related to the Building Solutions EMEA/LA segment, $50 million related to Corporate, $20 million related to the Building Solutions North America segment and

[0000833444-20-000036:notes:74]
$16 million related to the Building Solutions Asia Pacific segment. The restructuring actions are expected to be substantially complete in 2020.

[0000833444-20-000036:notes:75]
[same as prior period, unchanged from 0000833444-20-000015:notes:81]

[0000833444-20-000036:notes:76]
[same as prior period, unchanged from 0000833444-20-000015:notes:82]

[0000833444-20-000036:notes:77]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original reserve | $ | 209 |  |  | $ | 42 |  |  | $ | 12 |  |  | $ | — |  |  | $ | 263 |  |
| Utilized—cash | (45) |  |  | — |  |  | (2) |  |  | — |  |  | (47) |  |
| Utilized—noncash | — |  |  | (42) |  |  | — |  |  | — |  |  | (42) |  |
| Balance at September 30, 2018 | $ | 164 |  |  | $ | — |  |  | $ | 10 |  |  | $ | — |  |  | $ | 174 |  |
| Utilized—cash | (61) |  |  | — |  |  | (6) |  |  | — |  |  | (67) |  |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (1) |  |  | (1) |  |
| Transfer to liabilities held for sale | (4) |  |  | — |  |  | — |  |  | — |  |  | (4) |  |
| Balance at September 30, 2019 | $ | 99 |  |  | $ | — |  |  | $ | 4 |  |  | $ | (1) |  |  | $ | 102 |  |
| Utilized—cash | (30) |  |  | — |  |  | — |  |  | — |  |  | (30) |  |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Adoption of ASC 8421 | — |  |  | — |  |  | (4) |  |  | — |  |  | (4) |  |
| Balance at June 30, 2020 | $ | 69 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 69 |  |

[0000833444-20-000036:notes:78]
[same as prior period, unchanged from 0000833444-20-000015:notes:84]

[0000833444-20-000036:notes:79]
[same as prior period, unchanged from 0000833444-20-000015:notes:85]

[0000833444-20-000036:notes:80]
[same as prior period, unchanged from 0000833444-20-000015:notes:86]

[0000833444-20-000036:notes:81]
[same as prior period, unchanged from 0000833444-20-000015:notes:87]

[0000833444-20-000036:notes:82]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original reserve | $ | 276 |  |  | $ | 77 |  |  | $ | 14 |  |  | $ | — |  |  | $ | 367 |  |
| Utilized—cash | (75) |  |  | — |  |  | — |  |  | — |  |  | (75) |  |
| Utilized—noncash | — |  |  | (77) |  |  | (1) |  |  | — |  |  | (78) |  |
| Adjustment to restructuring reserves | 25 |  |  | — |  |  | — |  |  | — |  |  | 25 |  |
| Balance at September 30, 2017 | $ | 226 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |  | $ | 239 |  |
| Utilized—cash | (152) |  |  | — |  |  | (6) |  |  | — |  |  | (158) |  |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (1) |  |  | (1) |  |
| Balance at September 30, 2018 | $ | 74 |  |  | $ | — |  |  | $ | 7 |  |  | $ | (1) |  |  | $ | 80 |  |
| Utilized—cash | (11) |  |  | — |  |  | (2) |  |  | — |  |  | (13) |  |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | (3) |  |  | (3) |  |
| Transfer to liabilities held for sale | (3) |  |  | — |  |  | — |  |  | — |  |  | (3) |  |
| Balance at September 30, 2019 | $ | 60 |  |  | $ | — |  |  | $ | 5 |  |  | $ | (4) |  |  | $ | 61 |  |
| Utilized—cash | (35) |  |  | — |  |  | — |  |  | — |  |  | (35) |  |
| Adoption of ASC 8421 | — |  |  | — |  |  | (5) |  |  | — |  |  | (5) |  |
| Balance at June 30, 2020 | $ | 25 |  |  | $ | — |  |  | $ | — |  |  | $ | (4) |  |  | $ | 21 |  |

[0000833444-20-000036:notes:83]
The Company's fiscal 2020, 2018 and 2017 restructuring plans included workforce reductions of approximately 16,400 employees (14,100 for the Building Technologies & Solutions business and 2,300 for Corporate). Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of June 30, 2020, approximately 10,300 of the employees have been separated from the Company pursuant to the restructuring plans. In addition, the restructuring plans included nine plant closures in the Building Technologies & Solutions business. As of June 30, 2020, eight of the nine plants have been closed.
Company management closely monitors its overall cost structure and continually analyzes each of its businesses for opportunities to consolidate current operations, improve operating efficiencies and locate facilities in close proximity to customers. This ongoing analysis includes a review of its manufacturing, engineering and purchasing operations, as well as the overall global footprint for all its businesses.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-20-000036:notes:84]
Income Taxes
In calculating the provision for income taxes, the Company uses an estimate of the annual effective tax rate based upon the facts and circumstances known at each interim period. On a quarterly basis, the actual effective tax rate is adjusted, as appropriate, based upon changed facts and circumstances, if any, as compared to those forecasted at the beginning of the fiscal year and each interim period thereafter.

[0000833444-20-000036:notes:85]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended June 30, 2020, the Company's effective tax rate for continuing operations was 1% and was lower than the statutory tax rate of 12.5% primarily due to tax audit reserve adjustments, the income tax effects of mark-to-market adjustments and the benefits of continuing global tax planning initiatives, partially offset by the tax impact of an impairment charge and tax rate differentials. For the nine months ended June 30, 2020, the Company's effective tax rate for continuing operations was 20% and was higher than the statutory tax rate of 12.5% primarily due to a discrete tax charge

[0000833444-20-000036:notes:86]
related to the remeasurement of deferred tax assets and liabilities as a result of Swiss tax reform, the tax impact of an impairment charge and tax rate differentials, partially offset by tax audit reserve adjustments, the income tax effects of mark-to-market adjustments and the benefits of continuing global tax planning initiatives. For the three months ended June 30, 2019, the Company's effective tax rate for continuing operations was 52% and was higher than the statutory tax rate of 12.5% primarily due to a discrete tax charge related to newly enacted regulations related to U.S. Tax Reform, non-U.S. tax audit reserve adjustments and tax rate differentials, partially offset by a tax indemnification reserve release, the tax benefits of an asset held for sale impairment charge and continuing global tax planning initiatives. For the nine months ended June 30, 2019, the Company's effective tax rate for continuing operations was 38% and was higher than the statutory tax rate of 12.5% primarily due to valuation allowance adjustments as a result of tax law changes, a discrete tax charge related to newly enacted regulations related to U.S. Tax Reform, non-U.S. tax audit reserve adjustments and tax rate differentials, partially offset by a tax indemnification reserve release, the tax benefits of an asset held for sale impairment charge and continuing global tax planning initiatives.

[0000833444-20-000036:notes:87]
[same as prior period, unchanged from 0000833444-20-000015:notes:95]

[0000833444-20-000036:notes:88]
[same as prior period, unchanged from 0000833444-20-000015:notes:96]

[0000833444-20-000036:notes:89]
[same as prior period, unchanged from 0000833444-20-000015:notes:97]

[0000833444-20-000036:notes:90]
[same as prior period, unchanged from 0000833444-20-000015:notes:98]

[0000833444-20-000036:notes:91]
At September 30, 2019, the Company had gross tax effected unrecognized tax benefits of $2,451 million, of which $2,121 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2019 was approximately $181 million (net of tax benefit). The interest and penalties accrued during the nine months ended June 30, 2020 were approximately $55 million (net of tax benefit). Interest and penalties accrued during the nine months ended June 30, 2019 were approximately $49 million (net of tax benefit). The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-20-000036:notes:92]
In the third quarter of fiscal 2020, tax audit resolutions resulted in a $22 million net benefit to income tax expense.

[0000833444-20-000036:notes:93]
[same as prior period, unchanged from 0000833444-20-000015:notes:100]

[0000833444-20-000036:notes:94]
In the third quarter of fiscal 2019, the Company recorded a discrete charge of $199 million related to newly enacted regulations related to U.S. Tax Reform which impacted the Company's reserves for uncertain tax positions.

[0000833444-20-000036:notes:95]
In the third quarter of fiscal 2019, the Company recorded a discrete charge of $27 million related to non-U.S. tax examinations.

[0000833444-20-000036:notes:96]
[same as prior period, unchanged from 0000833444-20-000015:notes:101]

[0000833444-20-000036:notes:97]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2019 |
| Germany |  | 2007 - 2016 |
| Taiwan |  | 2017 - 2018 |
| United Kingdom |  | 2014 - 2015, 2017 |

[0000833444-20-000036:notes:98]
It is reasonably possible that certain tax examinations and/or tax litigation will conclude within the next twelve months, which could have a material impact on tax expense.

[0000833444-20-000036:notes:99]
[same as prior period, unchanged from 0000833444-20-000015:notes:104]

[0000833444-20-000036:notes:100]
[same as prior period, unchanged from 0000833444-20-000015:notes:105]

[0000833444-20-000036:notes:101]
[same as prior period, unchanged from 0000833444-20-000015:notes:106]

[0000833444-20-000036:notes:102]
During the nine months ended June 30, 2020 and 2019, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-20-000036:notes:103]
[same as prior period, unchanged from 0000833444-20-000015:notes:108]

[0000833444-20-000036:notes:104]
In the third quarter of fiscal 2020, the Company recorded net mark-to-market losses of $132 million. These losses generated a tax benefit of $34 million, which reflects the Company's current tax position in the impacted jurisdictions.

[0000833444-20-000036:notes:105]
In the third quarter of fiscal 2020, the Company recorded $610 million of restructuring and impairment costs. Refer to Note 8, "Goodwill and Other Intangible Assets," and Note 9, “Significant Restructuring and Impairment Costs,” of the notes to consolidated financial statements for additional information. The restructuring costs generated a $28 million tax benefit, which reflects the Company’s current tax position in the impacted jurisdictions.

[0000833444-20-000036:notes:106]
In the second quarter of fiscal 2020, the Company recorded $62 million of restructuring and impairment costs. Refer to Note 8, "Goodwill and Other Intangible Assets," and Note 9, “Significant Restructuring and Impairment Costs,” of the notes to consolidated financial statements for additional information. The restructuring costs generated a $4 million tax benefit, which reflects the Company’s current tax position in the impacted jurisdictions.

[0000833444-20-000036:notes:107]
In the first quarter of fiscal 2020, the Company recorded $111 million of restructuring and impairment costs. Refer to Note 9, “Significant Restructuring and Impairment Costs,” of the notes to consolidated financial statements for additional information. The restructuring costs generated a $16 million tax benefit, which reflects the Company’s current tax position in the impacted jurisdictions.

[0000833444-20-000036:notes:108]
In the third quarter of fiscal 2019, the Company recorded a $235 million impairment charge related to assets held for sale. Refer to Note 18, "Impairment of Long-Lived Assets," of the notes to consolidated financial statements for further information regarding the impairment charge.  The impairment charge generated a $53 million tax benefit. 
In the third quarter of fiscal 2019, the Company released a $226 million tax indemnification reserve. Refer to Note 20, "Guarantees," of the notes to consolidated financial statements for further information regarding the reserve release. The reserve release generated no income tax expense.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-20-000036:notes:109]
Pension and Postretirement Plans
The components of the Company’s net periodic benefit costs from continuing operations associated with its defined benefit pension and postretirement plans, which are primarily recorded in selling, general and administrative expenses in the consolidated statements of income, are shown in the tables below in accordance with ASC 715, "Compensation – Retirement Benefits" (in millions):

[0000833444-20-000036:notes:110]
|  | U.S. Pension Plans |  |  |  |  |  |  |
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Interest cost | $ | 18 |  |  | $ | 25 |  |  | 55 |  |  | 75 |  |
| Expected return on plan assets | (46) |  |  | (46) |  |  | (136) |  |  | (138) |  |
| Net actuarial loss | 157 |  |  | — |  |  | 157 |  |  | — |  |
| Settlement loss | 6 |  |  | — |  |  | 6 |  |  | — |  |
| Net periodic benefit cost (credit) | $ | 135 |  |  | $ | (21) |  |  | $ | 82 |  |  | $ | (63) |  |

[0000833444-20-000036:notes:111]
|  | Non-U.S. Pension Plans |  |  |  |  |  |  |
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Service cost | $ | 6 |  |  | $ | 5 |  |  | $ | 19 |  |  | $ | 16 |  |
| Interest cost | 9 |  |  | 14 |  |  | 27 |  |  | 40 |  |
| Expected return on plan assets | (27) |  |  | (26) |  |  | (83) |  |  | (78) |  |
| Amortization of prior service cost | — |  |  | — |  |  | 1 |  |  | — |  |
| Settlement loss | — |  |  | — |  |  | — |  |  | 1 |  |
| Net periodic benefit credit | $ | (12) |  |  | $ | (7) |  |  | $ | (36) |  |  | $ | (21) |  |

[0000833444-20-000036:notes:112]
|  | Postretirement Benefits |  |  |  |  |  |  |
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Service cost | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |
| Interest cost | 1 |  |  | 2 |  |  | 3 |  |  | 5 |  |
| Expected return on plan assets | (3) |  |  | (2) |  |  | (7) |  |  | (7) |  |
| Amortization of prior service credit | — |  |  | — |  |  | (1) |  |  | — |  |
| Net periodic benefit credit | $ | (1) |  |  | $ | — |  |  | $ | (4) |  |  | $ | (1) |  |

[0000833444-20-000036:notes:113]
During the three months ended June 30, 2020, the amount of cumulative fiscal 2020 lump sum payouts triggered a remeasurement event for certain U.S. pension plans resulting in the recognition of net actuarial losses of $157 million, primarily due to a decrease in discount rates.


## us-gaap:DebtDisclosureTextBlock

[0000833444-20-000036:notes:114]
Debt and Financing Arrangements
Net Financing Charges

[0000833444-20-000036:notes:115]
The Company's net financing charges line item in the consolidated statements of income for the three and nine months ended June 30, 2020 and 2019 contained the following components (in millions):

[0000833444-20-000036:notes:116]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Interest expense, net of capitalized interest costs | $ | 58 |  |  | $ | 81 |  |  | $ | 182 |  |  | $ | 269 |  |
| Banking fees and bond cost amortization | 8 |  |  | 7 |  |  | 18 |  |  | 20 |  |
| Loss on debt extinguishment | — |  |  | 60 |  |  | — |  |  | 60 |  |
| Interest income | (3) |  |  | (28) |  |  | (21) |  |  | (41) |  |
| Net foreign exchange results for financing activities | (5) |  |  | (1) |  |  | (10) |  |  | (6) |  |
| Net financing charges | $ | 58 |  |  | $ | 119 |  |  | $ | 169 |  |  | $ | 302 |  |

[0000833444-20-000036:notes:117]
In April 2020, the Company entered into various European financing arrangements totaling $675 million which are due in September 2020 and $575 million of bank term loans which are due in April 2021. In July 2020, a $300 million bank term loan was repaid, reducing bank term loans outstanding to $275 million.

[0000833444-20-000036:notes:118]
In March 2020, the Company retired $500 million in principal amount, plus accrued interest, of its 5.0% fixed rate notes that expired in March 2020.

[0000833444-20-000036:notes:119]
In December 2019, the Company entered into a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2020.  As of June 30, 2020, there were no draws on the facilities.

[0000833444-20-000036:notes:120]
In December 2019, the Company terminated its syndicated 5-year $2 billion committed revolving credit facility and four 364-day revolving credit facilities with total committed capacity of $750 million.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-20-000036:notes:121]
Stock-Based Compensation
On September 2, 2016, the shareholders of the Company approved amendments to the Johnson Controls International plc 2012 Share and Incentive Plan (the "Plan"). The types of awards authorized by the Plan comprise of stock options, stock appreciation rights, performance shares, performance units and other stock-based compensation awards. The Compensation Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. Awards are typically granted annually in the Company’s fiscal first quarter. A summary of the stock-based awards granted during the nine month periods ended June 30, 2020 and 2019 is presented below:

[0000833444-20-000036:notes:122]
|  | Nine Months Ended June 30, |  |  |  |  |  |  |  |  |  |  |
|  | 2020 |  |  |  |  |  | 2019 |  |  |  |  |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |  | Number Granted |  | Weighted Average Grant Date Fair Value |  |  |
| Stock options | 1,347,310 |  |  | $ | 7.29 |  |  |  |  | 1,741,510 |  |  | $ | 5.56 |  |  |  |
| Restricted stock/units | 1,896,383 |  |  | 41.41 |  |  |  |  | 2,334,423 |  |  | 33.50 |  |  |  |
| Performance shares | 476,939 |  |  | 42.48 |  |  |  |  | 583,989 |  |  | 36.28 |  |  |  |

[0000833444-20-000036:notes:123]
[same as prior period, unchanged from 0000833444-20-000015:notes:127]

[0000833444-20-000036:notes:124]
[same as prior period, unchanged from 0000833444-20-000015:notes:128]

[0000833444-20-000036:notes:125]
[same as prior period, unchanged from 0000833444-20-000015:notes:129]

[0000833444-20-000036:notes:126]
|  | Nine Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |
| Expected life of option (years) | 6.5 |  | 6.4 |
| Risk-free interest rate | 1.67% |  | 2.77% |
| Expected volatility of the Company’s stock | 22.4% |  | 21.8% |
| Expected dividend yield on the Company’s stock | 2.49% |  | 3.29% |

[0000833444-20-000036:notes:127]
[same as prior period, unchanged from 0000833444-20-000015:notes:131]

[0000833444-20-000036:notes:128]
[same as prior period, unchanged from 0000833444-20-000015:notes:132]

[0000833444-20-000036:notes:129]
[same as prior period, unchanged from 0000833444-20-000015:notes:133]

[0000833444-20-000036:notes:130]
[same as prior period, unchanged from 0000833444-20-000015:notes:134]

[0000833444-20-000036:notes:131]
[same as prior period, unchanged from 0000833444-20-000015:notes:135]

[0000833444-20-000036:notes:132]
|  | Nine Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |
| Risk-free interest rate | 1.60% |  | 2.76% |
| Expected volatility of the Company’s stock | 21.8% |  | 22.9% |


## us-gaap:EarningsPerShareTextBlock

[0000833444-20-000036:notes:133]
Earnings Per Share
The Company presents both basic and diluted earnings per share ("EPS") amounts. Basic EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares outstanding during the reporting period. Diluted EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares and ordinary equivalent shares outstanding during the reporting period that are calculated using the treasury stock method for stock options, unvested restricted stock and unvested performance share awards. The treasury stock method assumes that the Company uses the proceeds from the exercise of stock option awards to repurchase ordinary shares at the average market price during the period. The assumed proceeds under the treasury stock method include the purchase price that the grantee will pay in the future and compensation cost for future service that the Company has not yet recognized. For unvested restricted stock and unvested performance share awards, assumed proceeds under the treasury stock method would include unamortized compensation cost.

[0000833444-20-000036:notes:134]
[same as prior period, unchanged from 0000833444-20-000015:notes:139]

[0000833444-20-000036:notes:135]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Income (loss) Available to Ordinary Shareholders |  |  |  |  |  |  |  |
| Income (loss) from continuing operations | $ | (182) |  |  | $ | 141 |  |  | $ | 190 |  |  | $ | 488 |  |
| Income from discontinued operations | — |  |  | 4,051 |  |  | — |  |  | 4,574 |  |
| Basic and diluted income (loss) available to shareholders | $ | (182) |  |  | $ | 4,192 |  |  | $ | 190 |  |  | $ | 5,062 |  |
| Weighted Average Shares Outstanding |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 744.0 |  |  | 870.9 |  |  | 756.3 |  |  | 898.4 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | — |  |  | 4.3 |  |  | 2.6 |  |  | 3.8 |  |
| Diluted weighted average shares outstanding | 744.0 |  |  | 875.2 |  |  | 758.9 |  |  | 902.2 |  |
| Antidilutive Securities |  |  |  |  |  |  |  |
| Options to purchase shares | — |  |  | 0.7 |  |  | 1.6 |  |  | 1.9 |  |

[0000833444-20-000036:notes:136]
For the three months ended June 30, 2020, the total number of potential dilutive shares due to stock options, unvested restricted stock and unvested performance share awards was 1.5 million. However, these items were not included in the computation of diluted loss per share for the three months ended June 30, 2020 since to do so would decrease the loss per share.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-20-000036:notes:137]
Equity and Noncontrolling Interests
Other comprehensive income includes activity relating to discontinued operations. The following schedules present changes in consolidated equity attributable to Johnson Controls and noncontrolling interests (in millions, net of tax):

[0000833444-20-000036:notes:138]
|  | Three Months Ended June 30, 2020 |  |  |  |  |  | Three Months Ended June 30, 2019 |  |  |  |  |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, March 31, | $ | 18,084 |  |  | $ | 1,004 |  |  | $ | 19,088 |  |  | $ | 20,036 |  |  | $ | 1,265 |  |  | $ | 21,301 |  |
| Total comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) | (182) |  |  | 60 |  |  | (122) |  |  | 4,192 |  |  | 84 |  |  | 4,276 |  |
| Foreign currency translation adjustments | 72 |  |  | 4 |  |  | 76 |  |  | (90) |  |  | (4) |  |  | (94) |  |
| Realized and unrealized gains (losses) on derivatives | 6 |  |  | — |  |  | 6 |  |  | (5) |  |  | (4) |  |  | (9) |  |
| Other comprehensive income (loss) | 78 |  |  | 4 |  |  | 82 |  |  | (95) |  |  | (8) |  |  | (103) |  |
| Comprehensive income (loss) | (104) |  |  | 64 |  |  | (40) |  |  | 4,097 |  |  | 76 |  |  | 4,173 |  |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (195) |  |  | — |  |  | (195) |  |  | (208) |  |  | — |  |  | (208) |  |
| Repurchases and retirements of ordinary shares | — |  |  | — |  |  | — |  |  | (4,122) |  |  | — |  |  | (4,122) |  |
| Divestiture of Power Solutions | — |  |  | — |  |  | — |  |  | 483 |  |  | (295) |  |  | 188 |  |
| Other, including options exercised | 20 |  |  | — |  |  | 20 |  |  | 77 |  |  | — |  |  | 77 |  |
| Ending balance, June 30, | $ | 17,805 |  |  | $ | 1,068 |  |  | $ | 18,873 |  |  | $ | 20,363 |  |  | $ | 1,046 |  |  | $ | 21,409 |  |

[0000833444-20-000036:notes:139]
|  | Nine Months Ended June 30, 2020 |  |  |  |  |  | Nine Months Ended June 30, 2019 |  |  |  |  |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, September 30, | $ | 19,766 |  |  | $ | 1,063 |  |  | $ | 20,829 |  |  | $ | 21,164 |  |  | $ | 1,294 |  |  | $ | 22,458 |  |
| Total comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |
| Net income | 190 |  |  | 115 |  |  | 305 |  |  | 5,062 |  |  | 171 |  |  | 5,233 |  |
| Foreign currency translation adjustments | (148) |  |  | (9) |  |  | (157) |  |  | (103) |  |  | 8 |  |  | (95) |  |
| Realized and unrealized gains on derivatives | 1 |  |  | 2 |  |  | 3 |  |  | 10 |  |  | — |  |  | 10 |  |
| Pension and postretirement plans | (1) |  |  | — |  |  | (1) |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | (148) |  |  | (7) |  |  | (155) |  |  | (93) |  |  | 8 |  |  | (85) |  |
| Comprehensive income | 42 |  |  | 108 |  |  | 150 |  |  | 4,969 |  |  | 179 |  |  | 5,148 |  |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (590) |  |  | — |  |  | (590) |  |  | (683) |  |  | — |  |  | (683) |  |
| Dividends attributable to noncontrolling interests | — |  |  | (103) |  |  | (103) |  |  | — |  |  | (132) |  |  | (132) |  |
| Repurchases and retirements of ordinary shares | (1,467) |  |  | — |  |  | (1,467) |  |  | (5,122) |  |  | — |  |  | (5,122) |  |
| Divestiture of Power Solutions | — |  |  | — |  |  | — |  |  | 483 |  |  | (295) |  |  | 188 |  |
| Adoption of ASC 606 | — |  |  | — |  |  | — |  |  | (45) |  |  | — |  |  | (45) |  |
| Adoption of ASU 2016-16 | — |  |  | — |  |  | — |  |  | (546) |  |  | — |  |  | (546) |  |
| Adoption of ASC 842 | (5) |  |  | — |  |  | (5) |  |  | — |  |  | — |  |  | — |  |
| Other, including options exercised | 59 |  |  | — |  |  | 59 |  |  | 143 |  |  | — |  |  | 143 |  |
| Ending balance, June 30, | $ | 17,805 |  |  | $ | 1,068 |  |  | $ | 18,873 |  |  | $ | 20,363 |  |  | $ | 1,046 |  |  | $ | 21,409 |  |

[0000833444-20-000036:notes:140]
[same as prior period, unchanged from 0000833444-20-000015:notes:145]

[0000833444-20-000036:notes:141]
During the quarter ended December 31, 2018, the Company adopted ASU 2016-16, "Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other Than Inventory." As a result, the Company recognized deferred taxes of $546 million related to the tax effects of all intra-entity sales of assets other than inventory on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of October 1, 2018.

[0000833444-20-000036:notes:142]
In order to enhance liquidity resources in response to financial market uncertainty related to the COVID-19 pandemic, in March 2020 the Company made the decision to suspend its share repurchase program. As a result, no shares were repurchased during the three months ended June 30, 2020. For the nine months ended June 30, 2020, the Company repurchased and retired $1,467 million of its ordinary shares. As of June 30, 2020, approximately $3.1 billion remains available under the share repurchase program. In June 2020, the Company announced the share repurchase program would resume in the fourth quarter of fiscal 2020.

[0000833444-20-000036:notes:143]
On May 1, 2019, the Company announced a "modified Dutch auction" tender offer for up to $4.0 billion of its ordinary shares with a price range between $36.00 and $40.00 per share. The tender offer expired on May 31, 2019. Through the tender offer, the Company accepted for payment 102 million shares at a purchase price of $39.25 per share, for a total of approximately $4,035 million, including fees and commissions. The shares purchased through the tender offer were immediately retired. Ordinary shares were reduced by the number of shares retired at $0.01 par value per share. The excess purchase price over par value was recorded in retained earnings in the consolidated statements of financial position.

[0000833444-20-000036:notes:144]
In addition to the equity tender offer described above, the Company repurchased $87 million and $1,087 million of its ordinary shares, respectively, during the three and nine months ended June 30, 2019. These repurchased shares were retired in the fourth quarter of fiscal 2019.

[0000833444-20-000036:notes:145]
[same as prior period, unchanged from 0000833444-20-000015:notes:148]

[0000833444-20-000036:notes:146]
|  | Three Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |
| Foreign currency translation adjustments ("CTA") |  |  |  |
| Balance at beginning of period | $ | (1,005) |  |  | $ | (952) |  |
| Divestiture of Power Solutions | — |  |  | 479 |  |
| Aggregate adjustment for the period (net of tax effect of $0 and $0) | 72 |  |  | (90) |  |
| Balance at end of period | (933) |  |  | (563) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | (7) |  |  | 2 |  |
| Divestiture of Power Solutions (net of tax effect of $0 and $1) | — |  |  | 4 |  |
| Current period changes in fair value (net of tax effect of $1 and $(3)) | 4 |  |  | (4) |  |
| Reclassification to income (net of tax effect of $0 and $0) * | 2 |  |  | (1) |  |
| Balance at end of period | (1) |  |  | 1 |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (9) |  |  | (2) |  |
| Reclassification to income (net of tax effect of $0 and $0) | — |  |  | — |  |
| Balance at end of period | (9) |  |  | (2) |  |
| Accumulated other comprehensive loss, end of period | $ | (943) |  |  | $ | (564) |  |

[0000833444-20-000036:notes:147]
|  | Nine Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |
| CTA |  |  |  |
| Balance at beginning of period | $ | (785) |  |  | $ | (939) |  |
| Divestiture of Power Solutions | — |  |  | 479 |  |
| Aggregate adjustment for the period (net of tax effect of $0 and $0) | (148) |  |  | (103) |  |
| Balance at end of period | (933) |  |  | (563) |  |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | (2) |  |  | (13) |  |
| Divestiture of Power Solutions (net of tax effect of $0 and $1) | — |  |  | 4 |  |
| Current period changes in fair value (net of tax effect of $0 and $1) | 1 |  |  | 4 |  |
| Reclassification to income (net of tax effect of $0 and $3) * | — |  |  | 6 |  |
| Balance at end of period | (1) |  |  | 1 |  |
| Realized and unrealized gains (losses) on marketable securities |  |  |  |
| Balance at beginning of period | — |  |  | 8 |  |
| Adoption of ASU 2016-01 ** | — |  |  | (8) |  |
| Balance at end of period | — |  |  | — |  |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (8) |  |  | (2) |  |
| Reclassification to income (net of tax effect of $0 and $0) | (1) |  |  | — |  |
| Balance at end of period | (9) |  |  | (2) |  |
| Accumulated other comprehensive loss, end of period | $ | (943) |  |  | $ | (564) |  |

[0000833444-20-000036:notes:148]
[same as prior period, unchanged from 0000833444-20-000015:notes:151]

[0000833444-20-000036:notes:149]
[same as prior period, unchanged from 0000833444-20-000015:notes:152]

[0000833444-20-000036:notes:150]
[same as prior period, unchanged from 0000833444-20-000015:notes:153]

[0000833444-20-000036:notes:151]
** During the quarter ended December 31, 2018, the Company adopted ASU 2016-01, "Financial Instruments - Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities." As a result, the Company reclassified $8 million of unrealized gains on marketable securities to retained earnings as of October 1, 2018.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-20-000036:notes:152]
Derivative Instruments and Hedging ActivitiesThe Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities, stock-based compensation liabilities and interest rates. Under Company policy, the use of derivatives is restricted to those intended for hedging purposes; the use of any derivative instrument for speculative purposes is strictly prohibited. A description of each type of derivative utilized by the Company to manage risk is included in the following paragraphs. In addition, refer to Note 17, "Fair Value Measurements," of the notes to consolidated financial statements for information related to the fair value measurements and valuation methods utilized by the Company for each derivative type.
Cash Flow Hedges

[0000833444-20-000036:notes:153]
[same as prior period, unchanged from 0000833444-20-000015:notes:158]

[0000833444-20-000036:notes:154]
[same as prior period, unchanged from 0000833444-20-000015:notes:159]

[0000833444-20-000036:notes:155]
As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the three and nine months ended June 30, 2020 and 2019.

[0000833444-20-000036:notes:156]
[same as prior period, unchanged from 0000833444-20-000015:notes:161]

[0000833444-20-000036:notes:157]
|  |  | Volume Outstanding as of |  |  |
| Commodity |  | June 30, 2020 |  | September 30, 2019 |
| Copper |  | 2,724 |  |  | 3,561 |  |
| Aluminum |  | 2,622 |  |  | 2,967 |  |

[0000833444-20-000036:notes:158]
[same as prior period, unchanged from 0000833444-20-000015:notes:163]

[0000833444-20-000036:notes:159]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset currency gains and losses recorded on the Company’s net investments globally. At June 30, 2020 and September 30, 2019, the Company had 888 million euro, 750 million euro, 423 million euro and 54 million euro in bonds designated as net investment hedges in the Company's net investment in Europe and 25 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan.

[0000833444-20-000036:notes:160]
[same as prior period, unchanged from 0000833444-20-000015:notes:165]

[0000833444-20-000036:notes:161]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount.  As of June 30, 2020 and September 30, 2019, the Company hedged approximately 1.4 million shares of its ordinary shares, which have a cost basis of $60 million.

[0000833444-20-000036:notes:162]
[same as prior period, unchanged from 0000833444-20-000015:notes:167]

[0000833444-20-000036:notes:163]
[same as prior period, unchanged from 0000833444-20-000015:notes:168]

[0000833444-20-000036:notes:164]
[same as prior period, unchanged from 0000833444-20-000015:notes:169]

[0000833444-20-000036:notes:165]
|  | Derivatives and Hedging Activities Designatedas Hedging Instruments under ASC 815 |  |  |  | Derivatives and Hedging Activities NotDesignated as Hedging Instruments under ASC 815 |  |  |
|  | June 30, |  | September 30, |  | June 30, |  | September 30, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 5 |  |  | $ | 16 |  |  | $ | 15 |  |  | $ | 19 |  |
| Commodity derivatives | 1 |  |  | — |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Equity swap | — |  |  | — |  |  | 49 |  |  | 62 |  |
| Total assets | $ | 6 |  |  | $ | 16 |  |  | $ | 64 |  |  | $ | 81 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 9 |  |  | $ | 23 |  |  | $ | 16 |  |  | $ | — |  |
| Commodity derivatives | — |  |  | 1 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 2,602 |  |  | 2,544 |  |  | — |  |  | — |  |
| Total liabilities | $ | 2,611 |  |  | $ | 2,568 |  |  | $ | 16 |  |  | $ | — |  |

[0000833444-20-000036:notes:166]
[same as prior period, unchanged from 0000833444-20-000015:notes:171]

[0000833444-20-000036:notes:167]
[same as prior period, unchanged from 0000833444-20-000015:notes:172]

[0000833444-20-000036:notes:168]
[same as prior period, unchanged from 0000833444-20-000015:notes:173]

[0000833444-20-000036:notes:169]
[same as prior period, unchanged from 0000833444-20-000015:notes:174]

[0000833444-20-000036:notes:170]
|  |  | Fair Value of Assets |  |  |  |  |  | Fair Value of Liabilities |  |  |  |  |
|  |  | June 30, |  | September 30, |  |  |  | June 30, |  | September 30, |  |  |
|  |  | 2020 |  | 2019 |  |  |  | 2020 |  | 2019 |  |  |
| Gross amount recognized |  | $ | 70 |  |  | $ | 97 |  |  |  |  | $ | 2,627 |  |  | $ | 2,568 |  |  |  |
| Gross amount eligible for offsetting |  | (21) |  |  | (11) |  |  |  |  | (21) |  |  | (11) |  |  |  |
| Net amount |  | $ | 49 |  |  | $ | 86 |  |  |  |  | $ | 2,606 |  |  | $ | 2,557 |  |  |  |

[0000833444-20-000036:notes:171]
[same as prior period, unchanged from 0000833444-20-000015:notes:176]

[0000833444-20-000036:notes:172]
The following table presents the pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges for the three and nine months ended June 30, 2020 and 2019 (in millions):

[0000833444-20-000036:notes:173]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Foreign currency exchange derivatives |  | $ | — |  |  | $ | (2) |  |  | $ | 2 |  |  | $ | 7 |  |
| Commodity derivatives |  | 5 |  |  | (5) |  |  | 2 |  |  | (2) |  |
| Total |  | $ | 5 |  |  | $ | (7) |  |  | $ | 4 |  |  | $ | 5 |  |

[0000833444-20-000036:notes:174]
The following table presents the location and amount of the pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income for the three and nine months ended June 30, 2020 and 2019 (in millions):

[0000833444-20-000036:notes:175]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Location of Gain (Loss) Reclassified from AOCI into Income |  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
|  |  |  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (4) |  |  | $ | 2 |  |  | $ | (1) |  |  | $ | 4 |  |
| Commodity derivatives |  | Cost of sales |  | 2 |  |  | — |  |  | 1 |  |  | (3) |  |
| Commodity derivatives |  | Income from discontinued operations |  | — |  |  | (1) |  |  | — |  |  | (10) |  |
| Total |  |  |  | $ | (2) |  |  | $ | 1 |  |  | $ | — |  |  | $ | (9) |  |

[0000833444-20-000036:notes:176]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income for the three and nine months ended June 30, 2020 and 2019 (in millions):

[0000833444-20-000036:notes:177]
|  |  |  |  | Amount of Gain (Loss) Recognized inIncome on Derivative |  |  |  |  |  |  |
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
|  |  |  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | (2) |  |  | $ | (3) |  |  | $ | 2 |  |  | $ | (9) |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | 19 |  |  | (18) |  |  | 68 |  |  | (42) |  |
| Foreign currency exchange derivatives |  | Income from discontinued operations |  | — |  |  | (2) |  |  | — |  |  | 52 |  |
| Equity swap |  | Selling, general and administrative |  | 10 |  |  | 7 |  |  | (14) |  |  | 10 |  |
| Total |  |  |  | $ | 27 |  |  | $ | (16) |  |  | $ | 56 |  |  | $ | 11 |  |

[0000833444-20-000036:notes:178]
The pre-tax losses on net investment hedges recorded in CTA within other comprehensive income (loss) were $46 million and $36 million for the three months ended June 30, 2020 and 2019, respectively. The pre-tax gains (losses) on net investment hedges recorded in CTA within other comprehensive income (loss) were $(58) million and $48 million for the nine months ended June 30, 2020 and 2019, respectively. For the three and nine months ended June 30, 2020 and 2019, no gains or losses were reclassified from CTA into income.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-20-000036:notes:179]
Fair Value Measurements
ASC 820, "Fair Value Measurement," defines fair value as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. ASC 820 also establishes a three-level fair value hierarchy that prioritizes information used in developing assumptions when pricing an asset or liability as follows:

[0000833444-20-000036:notes:180]
[same as prior period, unchanged from 0000833444-20-000015:notes:186]

[0000833444-20-000036:notes:181]
[same as prior period, unchanged from 0000833444-20-000015:notes:187]

[0000833444-20-000036:notes:182]
[same as prior period, unchanged from 0000833444-20-000015:notes:188]

[0000833444-20-000036:notes:183]
[same as prior period, unchanged from 0000833444-20-000015:notes:189]

[0000833444-20-000036:notes:184]
[same as prior period, unchanged from 0000833444-20-000015:notes:190]

[0000833444-20-000036:notes:185]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value as of June 30, 2020 and September 30, 2019 (in millions):

[0000833444-20-000036:notes:186]
|  | Fair Value Measurements Using: |  |  |  |  |  |  |
|  | Total as of June 30, 2020 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |
| Exchange traded funds (fixed income)1 | 19 |  |  | 19 |  |  | — |  |  | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 61 |  |  | 61 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 142 |  |  | 142 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 120 |  |  | 120 |  |  | — |  |  | — |  |
| Equity swap | 49 |  |  | — |  |  | 49 |  |  | — |  |
| Total assets | $ | 412 |  |  | $ | 342 |  |  | $ | 70 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 25 |  |  | $ | — |  |  | $ | 25 |  |  | $ | — |  |
| Total liabilities | $ | 25 |  |  | $ | — |  |  | $ | 25 |  |  | $ | — |  |

[0000833444-20-000036:notes:187]
|  | Fair Value Measurements Using: |  |  |  |  |  |  |
|  | Total as of September 30, 2019 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 35 |  |  | $ | — |  |  | $ | 35 |  |  | $ | — |  |
| Exchange traded funds (fixed income)1 | 19 |  |  | 19 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Deferred compensation plan assets | 71 |  |  | 71 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 138 |  |  | 138 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 116 |  |  | 116 |  |  | — |  |  | — |  |
| Equity swap | 62 |  |  | — |  |  | 62 |  |  | — |  |
| Total assets | $ | 441 |  |  | $ | 344 |  |  | $ | 97 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Total liabilities | $ | 24 |  |  | $ | — |  |  | $ | 24 |  |  | $ | — |  |

[0000833444-20-000036:notes:188]
1 Classified as restricted investments for payment of asbestos liabilities. See Note 21, "Commitments and Contingencies," of the notes to consolidated financial statements for further details.

[0000833444-20-000036:notes:189]
[same as prior period, unchanged from 0000833444-20-000015:notes:195]

[0000833444-20-000036:notes:190]
[same as prior period, unchanged from 0000833444-20-000015:notes:196]

[0000833444-20-000036:notes:191]
[same as prior period, unchanged from 0000833444-20-000015:notes:197]

[0000833444-20-000036:notes:192]
[same as prior period, unchanged from 0000833444-20-000015:notes:198]

[0000833444-20-000036:notes:193]
Deferred compensation plan assets: Assets held in the deferred compensation plans will be used to pay benefits under certain of the Company's non-qualified deferred compensation plans. The investments primarily consist of mutual funds which are publicly traded on stock exchanges and are valued using a market approach based on the quoted market prices. Unrealized gains (losses) on the deferred compensation plan assets are recognized in the consolidated statements of income where they offset unrealized gains and losses on the related deferred compensation plan liability.

[0000833444-20-000036:notes:194]
Investments in exchange traded funds:  Investments in exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments.  Refer to Note 21, "Commitments and Contingencies," of the notes to consolidated financial statements for further information.

[0000833444-20-000036:notes:195]
The following table presents the portion of unrealized gains (losses) recognized in the consolidated statements of income for the three and nine months ended June 30, 2020 and 2019 that relate to equity securities still held at June 30, 2020 and 2019 (in millions):

[0000833444-20-000036:notes:196]
|  |  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Deferred compensation plan assets |  | $ | 6 |  |  | $ | — |  |  | $ | (1) |  |  | $ | (2) |  |
| Investments in exchange traded funds |  | 31 |  |  | 9 |  |  | 9 |  |  | 8 |  |

[0000833444-20-000036:notes:197]
All of the gains and losses on investments in exchange traded funds related to restricted investments. 
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. At June 30, 2020, the fair value of long-term debt was $7.3 billion, including public debt of $7.1 billion and other long-term debt of $0.2 billion. At September 30, 2019, the fair value of long-term debt was $7.6 billion, including public debt of $7.4 billion and other long-term debt of $0.2 billion. The fair value of public debt was determined primarily using market quotes which are classified as Level 1 inputs within the ASC 820 fair value hierarchy.  The fair value of other long-term debt was determined using quoted market prices for similar instruments and are classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:AssetImpairmentChargesTextBlock

[0000833444-20-000036:notes:198]
Impairment of Long-Lived Assets
The Company reviews long-lived assets, including right-of-use assets under operating leases, other tangible assets and intangible assets with definitive lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets," ASC 350-30, "General Intangibles Other than Goodwill" and ASC 985-20, "Costs of software to be sold, leased, or marketed."  ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. ASC 350-30 requires intangible assets acquired in a business combination that are used in research and development activities to be considered indefinite lived until the completion or abandonment of the associated research and development efforts. During the period that those assets are considered indefinite lived, they shall not be amortized but shall be tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired.  If the carrying amount of an intangible asset exceeds its fair value, an entity shall recognize an impairment loss in an amount equal to that excess. ASC 985-20 requires the unamortized capitalized costs of a computer software product be compared to the net realizable value of that product. The amount by which the unamortized capitalized costs of a computer software product exceed the net realizable value of that asset shall be written off.

[0000833444-20-000036:notes:199]
During the third quarter of fiscal 2020, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets caused by the economic impacts of the COVID-19 pandemic on the North America Retail reporting unit. The Company performed a quantitative impairment analysis and determined there was no impairment of long-lived assets as of June 30, 2020.

[0000833444-20-000036:notes:200]
In the third quarter of fiscal 2020, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2020. As a result, the Company reviewed the long-lived assets for impairment and recorded $42 million of asset impairment charges within restructuring and impairment costs in the consolidated statements of income. Of the total impairment charges, $24 million related to the Building Solutions Asia Pacific segment, $9 million related to the Global Products segment and $9 million related to the Building Solutions North America segment. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were primarily measured under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in

[0000833444-20-000036:notes:201]
the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-20-000036:notes:202]
In the first quarter of fiscal 2020, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2020. As a result, the Company reviewed the long-lived assets for impairment and recorded $39 million of asset impairment charges within restructuring and impairment costs in the consolidated statements of income. Of the total impairment charges, $33 million related to the Global Products segment and $6 million related to the Building Solutions North America segment. Refer to Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-20-000036:notes:203]
During the third quarter of fiscal 2019, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with the plans to dispose of a business within its Global Products segment that met the criteria to be classified as held for sale. Assets and liabilities held for sale are required to be recorded at the lower of carrying value or fair value less any costs to sell. The Company recorded an initial impairment charge of $235 million within restructuring and impairment costs in the consolidated statements of income in the third quarter of fiscal 2019 to write down the carrying value of the assets held for sale to fair value less any costs to sell. In the first quarter of fiscal 2020, the Company recorded an additional impairment charge of $15 million to further write down the carrying value of the assets held for sale to the current fair value less any costs to sell. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-20-000036:notes:204]
At June 30, 2020 and 2019, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets.

[0000833444-20-000036:notes:205]
Refer to Note 8, "Goodwill and Other Intangible Assets," and Note 9, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for further information regarding the indefinite-lived intangible and goodwill impairment charges recorded in the second and third quarters of fiscal 2020.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-20-000036:notes:206]
Segment Information
ASC 280, "Segment Reporting," establishes the standards for reporting information about segments in financial statements. In applying the criteria set forth in ASC 280, the Company has determined that it has four reportable segments for financial reporting purposes.

[0000833444-20-000036:notes:207]
•Building Solutions North America designs, sells, installs, and services HVAC and controls systems, integrated electronic security systems (including monitoring), and integrated fire detection and suppression systems for commercial, industrial, retail, small business, institutional and governmental customers in North America. Building Solutions North America also provides energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and control systems, to non-residential building and industrial applications in the North American marketplace.

[0000833444-20-000036:notes:208]
•Building Solutions EMEA/LA designs, sells, installs, and services HVAC, controls, refrigeration, integrated electronic security, integrated fire detection and suppression systems, and provides technical services to markets in Europe, the Middle East, Africa and Latin America.

[0000833444-20-000036:notes:209]
•Building Solutions Asia Pacific designs, sells, installs, and services HVAC, controls, refrigeration, integrated electronic security, integrated fire detection and suppression systems, and provides technical services to the Asia Pacific marketplace.

[0000833444-20-000036:notes:210]
•Global Products designs and produces heating and air conditioning for residential and commercial applications, and markets products and refrigeration systems to replacement and new construction market customers globally. The

[0000833444-20-000036:notes:211]
Global Products business also designs, manufactures and sells fire protection and security products, including intrusion security, anti-theft devices, and access control and video management systems, for commercial, industrial, retail, residential, small business, institutional and governmental customers worldwide.  Global Products also includes the Johnson Controls-Hitachi joint venture.

[0000833444-20-000036:notes:212]
[same as prior period, unchanged from 0000833444-20-000015:notes:215]

[0000833444-20-000036:notes:213]
[same as prior period, unchanged from 0000833444-20-000015:notes:216]

[0000833444-20-000036:notes:214]
|  | Net Sales |  |  |  |  |  |  |
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Building Solutions North America | $ | 2,020 |  |  | $ | 2,327 |  |  | $ | 6,362 |  |  | $ | 6,630 |  |
| Building Solutions EMEA/LA | 756 |  |  | 922 |  |  | 2,534 |  |  | 2,707 |  |
| Building Solutions Asia Pacific | 588 |  |  | 691 |  |  | 1,742 |  |  | 1,932 |  |
| Global Products | 1,979 |  |  | 2,511 |  |  | 5,725 |  |  | 6,425 |  |
| Total net sales | $ | 5,343 |  |  | $ | 6,451 |  |  | $ | 16,363 |  |  | $ | 17,694 |  |

[0000833444-20-000036:notes:215]
|  | Segment EBITA |  |  |  |  |  |  |
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Building Solutions North America | $ | 307 |  |  | $ | 300 |  |  | $ | 816 |  |  | $ | 807 |  |
| Building Solutions EMEA/LA | 62 |  |  | 101 |  |  | 237 |  |  | 258 |  |
| Building Solutions Asia Pacific | 92 |  |  | 98 |  |  | 229 |  |  | 240 |  |
| Global Products | 378 |  |  | 333 |  |  | 797 |  |  | 774 |  |
| Total segment EBITA | $ | 839 |  |  | $ | 832 |  |  | $ | 2,079 |  |  | $ | 2,079 |  |
| Corporate expenses | $ | (67) |  |  | $ | 70 |  |  | $ | (303) |  |  | $ | (233) |  |
| Amortization of intangible assets | (95) |  |  | (93) |  |  | (288) |  |  | (288) |  |
| Restructuring and impairment costs | (610) |  |  | (235) |  |  | (783) |  |  | (235) |  |
| Net mark-to-market adjustments | (132) |  |  | 9 |  |  | (154) |  |  | 8 |  |
| Net financing charges | (58) |  |  | (119) |  |  | (169) |  |  | (302) |  |
| Income (loss) from continuing operations before income taxes | $ | (123) |  |  | $ | 464 |  |  | $ | 382 |  |  | $ | 1,029 |  |


## us-gaap:GuaranteesTextBlock

[0000833444-20-000036:notes:216]
GuaranteesCertain of the Company's subsidiaries at the business segment level have guaranteed the performance of third-parties and provided financial guarantees for uncompleted work and financial commitments. The terms of these guarantees vary with end dates ranging from the current fiscal year through the completion of such transactions and would typically be triggered in the event of nonperformance. Performance under the guarantees, if required, would not have a material effect on the Company's financial position, results of operations or cash flows.
The Company offers warranties to its customers depending upon the specific product and terms of the customer purchase agreement. A typical warranty program requires that the Company replace defective products within a specified time period from the date of sale. The Company records an estimate for future warranty-related costs based on actual historical return rates and other known factors. Based on analysis of return rates and other factors, the Company’s warranty provisions are adjusted as necessary. The Company monitors its warranty activity and adjusts its reserve estimates when it is probable that future warranty costs will be different than those estimates.

[0000833444-20-000036:notes:217]
[same as prior period, unchanged from 0000833444-20-000015:notes:222]

[0000833444-20-000036:notes:218]
The changes in the carrying amount of the Company’s total product warranty liability for continuing operations, including extended warranties for which deferred revenue is recorded, for the nine months ended June 30, 2020 and 2019 were as follows (in millions):

[0000833444-20-000036:notes:219]
|  | Nine Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |
| Balance at beginning of period | $ | 285 |  |  | $ | 315 |  |
| Accruals for warranties issued during the period | 70 |  |  | 85 |  |
| Accruals from acquisition and divestitures | 1 |  |  | 2 |  |
| Accruals related to pre-existing warranties | 1 |  |  | (20) |  |
| Settlements made (in cash or in kind) during the period | (61) |  |  | (79) |  |
| Currency translation | — |  |  | 1 |  |
| Balance at end of period | $ | 296 |  |  | $ | 304 |  |

[0000833444-20-000036:notes:220]
In the third quarter of fiscal 2019, the majority of the Company's tax indemnification liabilities related to prior divested businesses were resolved, including a $226 million release, as a result of changes to the likelihood of payments due to the expiration of certain statute of limitations.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-20-000036:notes:221]
Commitments and Contingencies
Environmental Matters

[0000833444-20-000036:notes:222]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of June 30, 2020, reserves for environmental liabilities for continuing operations totaled $136 million, of which $45 million was recorded within other current liabilities and $91 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $159 million at September 30, 2019, of which $52 million was recorded within other current liabilities and $107 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.

[0000833444-20-000036:notes:223]
Tyco Fire Products L.P. (“Tyco Fire Products”), in coordination with the Wisconsin Department of Natural Resources ("WDNR"), has been conducting an environmental assessment of its Fire Technology Center ("FTC") located in Marinette, Wisconsin and surrounding areas in the City of Marinette and Town of Peshtigo, Wisconsin.  In connection with the assessment, perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and/or other per- and poly fluorinated substances ("PFAS") have been detected at the FTC and in groundwater and surface water outside of the boundaries of the FTC. Tyco Fire Products continues to investigate the extent of potential migration of these compounds and is working with WDNR to address these issues insofar as they related to this migration.

[0000833444-20-000036:notes:224]
During the third quarter of 2019, the Company increased its environmental reserves, which included $140 million related to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds

[0000833444-20-000036:notes:225]
at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).  The Company is not able to estimate a possible loss or range of loss in excess of the established accruals at this time.

[0000833444-20-000036:notes:226]
A substantial portion of the increased reserves relates to remediation resulting from the use of fire-fighting foams containing PFAS at the FTC. The use of fire-fighting foams at the FTC was primarily for training and testing purposes in order to ensure that such products sold by the Company’s affiliates, Chemguard, Inc. ("Chemguard") and Tyco Fire Products, were effective at suppressing high intensity fires that may occur at military installations, airports or elsewhere. The reserve was recorded in the quarter ended June 30, 2019 following a comprehensive review by independent environmental consultants related to the presence of PFAS at or near the FTC, as well as remediation discussions with the WDNR.

[0000833444-20-000036:notes:227]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS.  The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion.  On August 22, 2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation.

[0000833444-20-000036:notes:228]
In July 2019, the Company received a letter from the WDNR directing the expansion of the evaluation of PFAS in the Marinette region to include (1) biosolids sludge produced by the City of Marinette Waste Water Treatment Plant and spread on certain fields in the area and (2) the Menominee and Peshtigo Rivers.  Tyco Fire Products voluntarily responded to the WDNR’s letter to request additional necessary information.  On October 16, 2019, the WDNR issued a “Notice of Noncompliance” to Tyco Fire Products and Johnson Controls, Inc. regarding the WDNR’s July 3, 2019 letter.  The letter stated that “if you fail to take the actions required by Wis. Stat. § 292.11 to address this contamination, the DNR will move forward under Wis. Stat. § 292.31 to implement the SI workplan and evaluate further environmental enforcement actions and cost recovery under Wis. Stat. § 292.31(8).”  The WDNR issued a further letter regarding the issue on November 4, 2019.  In February 2020, the WDNR sent a letter to Tyco Fire Products and Johnson Controls, Inc. further directing the expansion of the evaluation of PFAS in the Marinette region to include investigation activities south and west of the previously defined FTC study area.  Tyco Fire Products and Johnson Controls, Inc. believe that they have complied with all applicable environmental laws and regulations.  The Company cannot predict what regulatory or enforcement actions, if any, might result from the WDNR’s actions, or the consequences of any such actions.

[0000833444-20-000036:notes:229]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990.  Its corporate predecessor, Ansul Incorporated (“Ansul”) manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River.  In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. The increase in the reserve related to the Stanton Street Facility was recorded following a further review of the Consent Order, which resulted in the identification of several structural upgrades needed to preserve the effectiveness of prior remediation efforts. In addition to ongoing remediation activities, the Company is also working with the WDNR to investigate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation of PFAS in the Marinette region.

[0000833444-20-000036:notes:230]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at

[0000833444-20-000036:notes:231]
the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At June 30, 2020 and September 30, 2019, the Company recorded conditional asset retirement obligations for continuing operations of $29 million and $30 million, respectively.

[0000833444-20-000036:notes:232]
Asbestos Matters

[0000833444-20-000036:notes:233]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-20-000036:notes:234]
As of June 30, 2020, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $134 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $497 million, of which $50 million was recorded in other current liabilities and $447 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $363 million, of which $43 million was recorded in other current assets, and $320 million was recorded in other noncurrent assets. Assets included $13 million of cash and $281 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at June 30, 2020 was $69 million. As of September 30, 2019, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $141 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $507 million, of which $50 million was recorded in other current liabilities and $457 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $366 million, of which $46 million was recorded in other current assets, and $320 million was recorded in other noncurrent assets. Assets included $16 million of cash and $273 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2019 was $77 million.

[0000833444-20-000036:notes:235]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-20-000036:notes:236]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and

[0000833444-20-000036:notes:237]
assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-20-000036:notes:238]
Insurable Liabilities

[0000833444-20-000036:notes:239]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At June 30, 2020 and September 30, 2019, the insurable liabilities totaled $365 million and $379 million, respectively, of which $83 million and $99 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $260 million and $258 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at June 30, 2020 were $23 million, of which $5 million was recorded within other current assets and $18 million was recorded within other noncurrent assets, respectively. The amount of such receivables recorded at September 30, 2019 were $23 million, of which $5 million was recorded within other current assets and $18 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.

[0000833444-20-000036:notes:240]
Aqueous Film-Forming Foam ("AFFF") Litigation

[0000833444-20-000036:notes:241]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but has stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

[0000833444-20-000036:notes:242]
Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, diminution in property values, investigation and remediation costs, and natural resources damages, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination.

[0000833444-20-000036:notes:243]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation

[0000833444-20-000036:notes:244]
(“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to or are being directly filed in the MDL.

[0000833444-20-000036:notes:245]
AFFF Putative Class Actions

[0000833444-20-000036:notes:246]
Chemguard and Tyco Fire Products are named in 30 putative class actions in federal courts originating from Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington New Hampshire, South Carolina, the District of Columbia, Guam, West Virginia, Michigan and South Dakota. All but one of these cases has been transferred to the MDL, and it is anticipated that the Abbot case will be removed to federal court and transferred following service of the complaint. The following putative class actions were filed since the beginning of fiscal year 2020:

[0000833444-20-000036:notes:247]
•Aguon et al. v. The 3M Company et al., filed October 3, 2019, in the United States District Court, District of Guam.

[0000833444-20-000036:notes:248]
•County of Rockland [New York] et al. v. 3M Company et al., filed February 4, 2020, in the United States District Court, District of South Carolina.

[0000833444-20-000036:notes:249]
•City of Millington et al. v. 3M Company et al., filed February 25, 2020, in the United States District Court, District of Columbia.

[0000833444-20-000036:notes:250]
•Stengel et al. v. 3M Company et al., filed April 29, 2020, in the United States District Court for the Northern District of West Virginia.

[0000833444-20-000036:notes:251]
•Abbott et al. v. The 3M Company et al., filed May 6, 2020 in the Superior Court for the State of Washington in and for Spokane County.

[0000833444-20-000036:notes:252]
•Garcia et al. v. 3M Company et al., filed May 15, 2020 in the United States District Court for the District of South Carolina [originating from South Dakota].

[0000833444-20-000036:notes:253]
•Gentile et al. v. The 3M Company et al., filed May 27, 2020, in the United States District Court for the Eastern District of New York.

[0000833444-20-000036:notes:254]
AFFF Individual or Mass Actions

[0000833444-20-000036:notes:255]
There are approximately 632 individual or “mass” actions pending that were filed in state or federal court in California (2 cases), Colorado (41 cases), New York (4 cases), Pennsylvania (15 cases), New Mexico (2 cases) and South Carolina (568 cases direct filed from various U.S. jurisdictions) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve two plaintiffs in California, approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, 15 plaintiffs in Pennsylvania, two plaintiffs in New Mexico, and more than 500 plaintiffs from various states who direct-filed complaints in South Carolina. All but two of these matters have been transferred to or directly-filed in the MDL, and it is anticipated that the California cases will be transferred following service of the complaints.  Many of the additional filed actions were directly filed in South Carolina by plaintiffs who were among the 660 plaintiffs the Company had previously disclosed to have made filings in Pennsylvania state court.  The Company anticipates that the remainder of the possible individual product liability claims filed in Pennsylvania state court will either soon be filed in the MDL (and that all such claims in state court will be dismissed accordingly) or will be dismissed in Pennsylvania without a corresponding filing in South Carolina.

[0000833444-20-000036:notes:256]
AFFF Municipal Cases

[0000833444-20-000036:notes:257]
Chemguard and Tyco Fire Products are also defendants in 51 cases in federal courts involving municipal or water provider plaintiffs in Alaska, Arizona, California, Colorado, Florida, Massachusetts, New Jersey, New York, Maryland, Ohio, Pennsylvania, Washington, the District of Columbia and several municipalities or water providers from various states who direct-filed complaints in South Carolina.  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property. Since the beginning of fiscal year 2020, 21 municipal actions have been filed against the Company.

[0000833444-20-000036:notes:258]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly

[0000833444-20-000036:notes:259]
resulting from the use of those products at the Peterson Air Force Base. In May 2020, the Company was also notified by the Lakewood Water District in Pierce County, Washington that it may assert claims regarding remediation in connection with PFOA, PFOS, and other PFAS contamination allegedly resulting from the use of those products at Joint Base Lewis-McChord.

[0000833444-20-000036:notes:260]
State or U.S. Territory Attorneys General Litigation related to AFFF

[0000833444-20-000036:notes:261]
In June 2018, the State of New York filed a lawsuit in New York state court (State of New York v. The 3M Company et al No. 904029-18 (N.Y. Sup. Ct., Albany County)) against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at locations across New York, including Stewart Air National Guard Base in Newburgh and Gabreski Air National Guard Base in Southampton, Plattsburgh Air Force Base in Plattsburgh, Griffiss Air Force Base in Rome, and unspecified “other” sites throughout the State. The lawsuit seeks to recover costs and natural resource damages associated with contamination at these sites. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.

[0000833444-20-000036:notes:262]
In February 2019, the State of New York filed a second lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at additional locations across New York.  This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In July 2019, the State of New York filed a third lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to the United States District Court for the Northern District of New York and transferred to the MDL.  In November 2019, the State of New York filed a fourth lawsuit in New York state court (State of New York v. The 3M Company et al (N.Y. Sup. Ct., Albany County)), against a number of manufacturers, including affiliates of the Company, with respect to alleged PFOS and PFOA contamination purportedly resulting from firefighting foams used at further additional locations across New York. This suit has been removed to federal court and transferred to the MDL.

[0000833444-20-000036:notes:263]
In January 2019, the State of Ohio filed a lawsuit in Ohio state court (State of Ohio v. The 3M Company et al., No. G-4801-CI-021804752 -000 (Court of Common Pleas of Lucas County, Ohio)) against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across Ohio.  The lawsuit seeks to recover costs and natural resource damages associated with the contamination.  This lawsuit has been removed to the United States District Court for the Northern District of Ohio and transferred to the MDL.

[0000833444-20-000036:notes:264]
In addition, in May and June 2019, three other states filed lawsuits in their respective state courts against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various specified and unspecified locations across their jurisdictions (State of New Hampshire v. The 3M Company et al.; State of Vermont v. The 3M Company et al.; State of New Jersey v. The 3M Company et al.). All three of these suits have been removed to federal court and transferred to the MDL.

[0000833444-20-000036:notes:265]
In September 2019, the government of Guam filed a lawsuit in the superior court of Guam against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.

[0000833444-20-000036:notes:266]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.

[0000833444-20-000036:notes:267]
AFFF Matters Related to the Tyco Fire Products Fire Technology Center in Marinette, Wisconsin

[0000833444-20-000036:notes:268]
Tyco Fire Products and Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFAS (including PFOA/PFOS) contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. A second lawsuit, Duane and Janell Goldsmith individually and on behalf of H.G. and K.G v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) was also filed by a family alleging personal injuries due to contaminated groundwater; this case has been dismissed without prejudice.

[0000833444-20-000036:notes:269]
Other AFFF Related Matters

[0000833444-20-000036:notes:270]
In March 2020, the Kalispel Tribe of Indians (a federally recognized Tribe) and two tribal corporations filed a lawsuit in the United States District Court for the Eastern District of Washington against a number of manufacturers, including affiliates of the Company, and the United States with respect to PFAS contamination allegedly resulting from the use and disposal of AFFF by the United States Air Force at and around Fairchild Air Force Base in eastern Washington.  This case has been transferred to the MDL.

[0000833444-20-000036:notes:271]
Other PFAS Related Matters

[0000833444-20-000036:notes:272]
In April 2020, the Weirton Area Water Board in West Virginia filed a lawsuit in the Circuit Court of Brooke County, West Virginia against a number of PFAS chemical manufacturers, including Chemguard, with respect to PFAS contamination.  This case has been removed to the United States District Court for the Northern District of West Virginia.

[0000833444-20-000036:notes:273]
The Company is vigorously defending the above matters and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.

[0000833444-20-000036:notes:274]
Bosch Litigation

[0000833444-20-000036:notes:275]
On March 15, 2019, a German subsidiary of the Company received a complaint from Robert Bosch GmbH (“Bosch”), filed in a German court. The complaint relates to an automotive starter batteries joint venture in which the Company and Bosch were 80/20 parties to this joint venture. At the time the complaint was filed, JCI’s ownership interest in the joint venture was to be transferred to entities controlled by the Purchaser upon consummation of the previously announced sale of the Company’s Power Solutions business.

[0000833444-20-000036:notes:276]
The complaint alleged that certain internal Company reorganization transactions were not in compliance with the arrangements relating to such joint venture. The complaint sought a declaration that such internal reorganization transactions are void or, in the alternative, a declaration of damages that represent an alleged difference between (i) the value ascribed to the joint venture interests in connection with the Power Solutions sale and (ii) the value that was assigned to those interests in connection with such internal reorganization transactions.

[0000833444-20-000036:notes:277]
On August 8, 2019, Bosch entered into an agreement with Purchaser pursuant to which Purchaser would purchase Bosch’s interest in the joint venture.  Simultaneously with this agreement, the Company and Bosch executed an agreement to dismiss the proceedings between the parties upon the completion of Purchaser’s acquisition of Bosch’s interest. In the first quarter of fiscal 2020, following the completion of Purchaser’s acquisition of Bosch’s interest in the joint venture, the Company and Bosch made filings with the German court terminating the litigation.

[0000833444-20-000036:notes:278]
Pursuant to the Company’s obligations to Purchaser in connection with the divestiture of the Company’s Power Solutions business, the Company reimbursed Purchaser a portion of its costs in connection with its acquisition of Bosch’s interests in the joint venture, which is reflected as a cash outflow for discontinued operations.

[0000833444-20-000036:notes:279]
Other Matters

[0000833444-20-000036:notes:280]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-20-000036:notes:281]
Related Party Transactions
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-20-000036:notes:282]
The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $52 million and $25 million, respectively, for the three months ended June 30, 2020; and $65 million and $27 million, respectively, for the three months ended June 30, 2019. The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $135 million and $47 million, respectively, for the nine months ended June 30, 2020; and $162 million and $57 million, respectively, for the nine months ended June 30, 2019.

[0000833444-20-000036:notes:283]
The following table sets forth the amount of accounts receivable due from and payable to related parties in the consolidated statements of financial position for continuing operations (in millions):

[0000833444-20-000036:notes:284]
|  |  | June 30, 2020 |  | September 30, 2019 |
| Receivable from related parties |  | $ | 50 |  |  | $ | 34 |  |
| Payable to related parties |  | 7 |  |  | 6 |  |
