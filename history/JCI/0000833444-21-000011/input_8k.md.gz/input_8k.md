# JCI 8-K — 0000833444-21-000009 filed 2021-01-29

## item codes, every 8-K on or before 2021-01-29

- 2021-01-29 0000833444-21-000009 — 2.02, 9.01
- 2021-01-07 0000833444-21-000004 — 7.01
- 2020-11-03 0000833444-20-000043 — 2.02, 9.01
- 2020-09-15 0001193125-20-246240 — 1.01, 8.01, 9.01
- 2020-09-11 0001193125-20-244119 — 1.01, 8.01, 9.01
- 2020-08-18 0000833444-20-000038 — 5.02, 9.01
- 2020-07-31 0000833444-20-000034 — 2.02, 9.01
- 2020-06-12 0000833444-20-000020 — 8.01
- 2020-05-01 0000833444-20-000013 — 2.02, 9.01
- 2020-03-12 0000833444-20-000010 — 5.02
- 2020-03-06 0000833444-20-000008 — 5.07
- 2020-01-31 0000833444-20-000003 — 2.02, 9.01
- 2019-12-06 0001193125-19-308301 — 1.01, 1.02, 2.03, 9.01
- 2019-11-07 0000833444-19-000048 — 5.02, 9.01
- 2019-11-07 0000833444-19-000046 — 2.02, 9.01
- 2019-08-21 0000833444-19-000043 — 8.01
- 2019-07-31 0000833444-19-000038 — 2.02, 9.01
- 2019-07-23 0000833444-19-000035 — 5.02, 8.01, 9.01
- 2019-07-02 0000833444-19-000033 — 1.02, 8.01
- 2019-06-05 0001193125-19-165565 — 8.01
- 2019-05-30 0001193125-19-160205 — 8.01, 9.01
- 2019-05-16 0001193125-19-148262 — 8.01, 9.01
- 2019-05-07 0001193125-19-139826 — 5.04, 9.01
- 2019-05-03 0001193125-19-137038 — 8.01
- 2019-05-01 0000833444-19-000017 — 2.01, 2.02, 8.01, 9.01
- 2019-03-18 0001193125-19-077386 — 7.01
- 2019-03-07 0001193125-19-067361 — 7.01, 9.01
- 2019-03-07 0000833444-19-000007 — 5.07
- 2019-02-01 0000833444-19-000003 — 2.02, 9.01
- 2019-01-11 0001193125-19-007466 — 2.03, 9.01
- 2018-12-06 0000833444-18-000056 — 5.02, 9.01
- 2018-11-13 0001193125-18-325492 — 1.01, 9.01
- 2018-11-13 0001193125-18-324903 — 8.01, 9.01
- 2018-11-13 0000833444-18-000049 — 7.01
- 2018-11-08 0000833444-18-000046 — 2.02, 9.01
- 2018-07-31 0000833444-18-000040 — 2.02, 9.01
- 2018-06-13 0000833444-18-000028 — 5.02, 9.01
- 2018-05-01 0000833444-18-000018 — 2.02, 9.01
- 2018-03-12 0001193125-18-078427 — 7.01, 8.01, 9.01
- 2018-03-08 0000833444-18-000012 — 5.07
- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2021-01-29

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-21-000009:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq1fy21.htm
EX-99.1

[0000833444-21-000009:8k_2_02:2]
Document

[0000833444-21-000009:8k_2_02:3]
Exhibit 99.1

[0000833444-21-000009:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-21-000009:8k_2_02:5]
Johnson Controls Reports Strong Start to Fiscal Year;

[0000833444-21-000009:8k_2_02:6]
Provides Fiscal 2021 Full Year and Q2 Guidance

[0000833444-21-000009:8k_2_02:7]
________________________________________________________________________________

[0000833444-21-000009:8k_2_02:8]
▪GAAP EPS of $0.45; Adjusted EPS of $0.43, up 8% versus prior year

[0000833444-21-000009:8k_2_02:9]
▪Continued sequential quarterly improvement in sales, orders and profitability

[0000833444-21-000009:8k_2_02:10]
▪Backlog of $9.5B increases 3% organically year-over-year

[0000833444-21-000009:8k_2_02:11]
▪Cash provided by operating activities was $0.5 billion; Free cash flow of $0.4 billion

[0000833444-21-000009:8k_2_02:12]
▪Executed $346 million of planned share repurchases in Q1

[0000833444-21-000009:8k_2_02:13]
▪Announced ambitious new ESG commitments

[0000833444-21-000009:8k_2_02:14]
▪Provides fiscal 2021 second quarter adjusted earnings per share guidance range of $0.47 to $0.49; top-line organic growth expected to turn positive

[0000833444-21-000009:8k_2_02:15]
▪Provides fiscal 2021 full year adjusted earnings per share guidance range of $2.45 to $2.55; represents a 9 to 14% increase year over year

[0000833444-21-000009:8k_2_02:16]
________________________________________________________________________________

[0000833444-21-000009:8k_2_02:17]
CORK, Ireland, January 29, 2021 -- Johnson Controls International plc (NYSE: JCI), the global leader for smart, healthy and sustainable buildings, today reported fiscal first quarter 2021 GAAP earnings per share (“EPS”) from continuing operations, including special items, of $0.45. Excluding these items, adjusted EPS from continuing operations was $0.43, up 8% versus the prior year period (see attached footnotes for non-GAAP reconciliation).

[0000833444-21-000009:8k_2_02:18]
Sales of $5.3 billion decreased 4% compared to the prior year and declined 5% organically, reflecting the continued impact of the COVID-19 pandemic.

[0000833444-21-000009:8k_2_02:19]
GAAP net income from continuing operations was $327 million. Adjusted net income from continuing operations was $311 million, up 2% versus the prior year. Earnings before interest and taxes (“EBIT”) was $492 million and EBIT margin was 9.2%. Adjusted EBIT was $471 million and adjusted EBIT margin was 8.8%, an increase of 80 basis points versus prior year results, despite the revenue decline.

[0000833444-21-000009:8k_2_02:20]
“2021 is off to a strong start with solid financial performance in our fiscal first quarter, demonstrating our continued commitment to disciplined execution, in what remains a challenging market environment,” said George Oliver, chairman and CEO. “The continued benefits from our actions taken in fiscal 2020 to reduce structural costs, combined with ongoing efforts to minimize discretionary expenses, enabled us to achieve record first quarter profitability and free cash flow. Although many of our end markets remain under pressure due to the ongoing impacts of the pandemic, we further advanced our strategic growth initiatives, with continued reinvestment in our businesses to ensure we are best positioned for the recovery.  As we progress into the second quarter, we expect to return to organic revenue growth, with strong margin expansion and year-over-year growth in earnings per share.”

[0000833444-21-000009:8k_2_02:21]
Page 1 of 15

[0000833444-21-000009:8k_2_02:22]
Mr. Oliver added, “Our OpenBlue digital technologies are reinventing the building landscape, creating dynamic smart facilities that help our customers meet their sustainability commitments, while delivering healthy places, enriched experiences and cost savings. Our vision for a healthy world centers on healthy buildings, which means delivering on the most critical elements to serve People, Places and the Planet. We believe we are uniquely positioned to lead the industry in translating new building technology capabilities into game-changing solutions that deliver on that vision."

[0000833444-21-000009:8k_2_02:23]
In a separate press release issued today, Johnson Controls announced an ambitious set of new Environmental, Social & Governance (ESG) commitments, science-based targets as well as a net zero carbon pledge to support a healthy, more sustainable planet over the next two decades.

[0000833444-21-000009:8k_2_02:24]
“Our commitments reinforce the urgency to make positive changes that will improve the health of our planet, and we believe we are uniquely positioned to help customers and suppliers achieve their sustainability goals, in addition to our own,” said Katie McGinty, vice president & chief sustainability, government and regulatory affairs officer at Johnson Controls.  “We are excited to step up the role we play and will continue to innovate and uncover new pathways to meet our goals which will contribute to healthier people, healthier places and a healthier planet.”

[0000833444-21-000009:8k_2_02:25]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-21-000009:8k_2_02:26]
($ millions, except per-share amounts)

[0000833444-21-000009:8k_2_02:27]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the first fiscal quarter of 2020.

[0000833444-21-000009:8k_2_02:28]
Organic sales, total segment EBITA, adjusted segment EBITA, adjusted corporate expense, EBIT, adjusted EBIT, adjusted net income from continuing operations, adjusted EPS from continuing operations and free cash flow are non-GAAP financial measures. For a reconciliation of these non-GAAP measures and detail of the special items, refer to the attached footnotes. A slide presentation to accompany the results can be found in the Investor Relations section of Johnson Controls’ website at

[0000833444-21-000009:8k_2_02:29]
http://investors.johnsoncontrols.com.

[0000833444-21-000009:8k_2_02:30]
|  |  | Fiscal Q1 |  |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |  |
|  |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  |  |  |  |  |  |  |
| Sales |  | $5,576 |  |  | $5,341 |  |  | $5,576 |  |  | $5,341 |  |  |  |  |  |  |  |  |
| Segment EBITA |  | 623 |  | 642 |  | 625 |  | 642 |  |  |  |  |  |  |  |
| EBIT |  | 308 |  | 492 |  | 448 |  | 471 |  |  |  |  |  |  |  |
| Net income from continuing operations |  | 159 |  | 327 |  | 306 |  | 311 |  |  |  |  |  |  |  |
| Diluted EPS from continuing operations |  | $0.21 |  |  | $0.45 |  |  | $0.40 |  |  | $0.43 |  |  |  |  |  |  |  |  |

[0000833444-21-000009:8k_2_02:31]
Page 2 of 15

[0000833444-21-000009:8k_2_02:32]
SEGMENT RESULTS

[0000833444-21-000009:8k_2_02:33]
Building Solutions North America

[0000833444-21-000009:8k_2_02:34]
|  |  | Fiscal Q1 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  |  |  |  |  |  |
| Sales |  | $2,167 |  |  | $2,034 |  |  | $2,167 |  |  | $2,034 |  |  |  |  |  |  |  |
| Segment EBITA |  | 258 |  | 255 |  | 259 |  | 255 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 11.9% |  | 12.5% |  | 12.0% |  | 12.5% |  |  |  |  |  |  |

[0000833444-21-000009:8k_2_02:35]
Sales in the quarter of $2.0 billion, decreased 6% versus the prior year. Organic sales also declined 6% versus the prior year, driven by a decline in project installations and, to a much lesser extent, service.  Strong growth in Performance Solutions was more than offset by a decline in Fire & Security and HVAC & Controls.

[0000833444-21-000009:8k_2_02:36]
Orders in the quarter, excluding M&A and adjusted for foreign currency, decreased 7% year-over-year driven by lower demand due to the COVID-19 pandemic.  Backlog at the end of the quarter of $5.9 billion increased 1% compared to the prior year, excluding M&A and adjusted for foreign currency.

[0000833444-21-000009:8k_2_02:37]
Adjusted segment EBITA was $255 million, down 2% versus the prior year. Adjusted segment EBITA margin of 12.5% expanded 50 basis points versus the prior year driven by significant cost mitigation actions and restructuring benefits as well as positive mix, which more than offset the impact of the volume decline.

[0000833444-21-000009:8k_2_02:38]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-21-000009:8k_2_02:39]
|  |  | Fiscal Q1 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  |  |  |  |  |  |
| Sales |  | $928 |  | $906 |  | $928 |  | $906 |  |  |  |  |  |  |
| Segment EBITA |  | 90 |  | 95 |  | 90 |  | 95 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 9.7% |  | 10.5% |  | 9.7% |  | 10.5% |  |  |  |  |  |  |

[0000833444-21-000009:8k_2_02:40]
Sales in the quarter of $906 million decreased 2% versus the prior year. Organic sales declined 5% versus the prior year driven by a decline in project installations. Volumes declined across all regions and platforms.

[0000833444-21-000009:8k_2_02:41]
Page 3 of 15

[0000833444-21-000009:8k_2_02:42]
Orders in the quarter, excluding M&A and adjusted for foreign currency, increased 2% year-over-year driven by service.  Backlog at the end of the quarter of $1.8 billion increased 5% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-21-000009:8k_2_02:43]
Adjusted segment EBITA was $95 million, up 6% versus the prior year. Adjusted segment EBITA margin of 10.5% expanded 80 basis points over the prior year, including a 20 basis point headwind related to foreign currency. Adjusting for foreign currency, underlying EBITA margin expanded 100 basis points as positive mix and mitigating cost actions more than offset the impact of the volume decline.

[0000833444-21-000009:8k_2_02:44]
Building Solutions Asia Pacific

[0000833444-21-000009:8k_2_02:45]
|  |  | Fiscal Q1 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  |  |  |  |  |  |
| Sales |  | $629 |  | $615 |  | $629 |  | $615 |  |  |  |  |  |  |
| Segment EBITA |  | 72 |  | 79 |  | 72 |  | 79 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 11.4% |  | 12.8% |  | 11.4% |  | 12.8% |  |  |  |  |  |  |

[0000833444-21-000009:8k_2_02:46]
Sales in the quarter of $615 million decreased 2% versus the prior year. Organic sales declined 6% versus the prior year driven by a decline in project installations which more than offset growth in service. Although China continues to rebound, declines continue in certain other parts of the region.

[0000833444-21-000009:8k_2_02:47]
Orders in the quarter, excluding M&A and adjusted for foreign currency, decreased 1% year-over-year as growth in service was more than offset by a decline in project activity.  Significantly improved demand in China was offset by further declines in Japan, Hong Kong and South East Asia.  Backlog at the end of the quarter of $1.8 billion increased 12% year-over-year, excluding M&A and adjusted for foreign currency.

[0000833444-21-000009:8k_2_02:48]
Adjusted segment EBITA was $79 million, up 10% versus the prior year. Adjusted segment EBITA margin of 12.8% expanded 140 basis points over the prior year as favorable mix and the benefit of mitigating cost actions more than offset the impact of the volume decline.

[0000833444-21-000009:8k_2_02:49]
Page 4 of 15

[0000833444-21-000009:8k_2_02:50]
Global Products

[0000833444-21-000009:8k_2_02:51]
|  |  | Fiscal Q1 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  |  |  |  |  |  |
| Sales |  | $1,852 |  | $1,786 |  | $1,852 |  | $1,786 |  |  |  |  |  |  |
| Segment EBITA |  | 203 |  | 213 |  | 204 |  | 213 |  |  |  |  |  |  |
| Segment EBITA Margin % |  | 11.0% |  | 11.9% |  | 11.0% |  | 11.9% |  |  |  |  |  |  |

[0000833444-21-000009:8k_2_02:52]
Sales in the quarter of $1.8 billion decreased 4% versus the prior year. Organic sales declined 2% versus the prior year as low double-digit growth in residential was more than offset by a decline in commercial HVAC, Fire & Security and Industrial Refrigeration.

[0000833444-21-000009:8k_2_02:53]
Adjusted segment EBITA was $213 million, up 4% versus the prior year. Adjusted segment EBITA margin of 11.9% expanded 90 basis points versus the prior year as positive price/cost and the benefit of mitigating cost actions more than offset the impact of the volume decline and negative mix.

[0000833444-21-000009:8k_2_02:54]
Corporate

[0000833444-21-000009:8k_2_02:55]
|  |  | Fiscal Q1 |  |  |  |
|  |  | GAAP |  | Adjusted |  |  |  |  |
|  |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  |  |  |  |  |  |
| Corporate Expense |  | ($118) |  | ($67) |  | ($81) |  | ($67) |  |  |  |  |  |  |

[0000833444-21-000009:8k_2_02:56]
Adjusted Corporate expense was $67 million in the quarter, a decrease of 17% compared to the prior year, driven primarily by mitigating cost actions and continuous structural cost reductions.

[0000833444-21-000009:8k_2_02:57]
OTHER ITEMS

[0000833444-21-000009:8k_2_02:58]
▪For the quarter, cash provided by operating activities from continuing operations was $0.5 billion and capital expenditures were $0.1 billion, resulting in free cash flow from continuing operations of $0.4 billion.

[0000833444-21-000009:8k_2_02:59]
▪During the quarter, the Company repurchased 8 million shares for $346 million.

[0000833444-21-000009:8k_2_02:60]
▪During the quarter, the Company recorded a net $124 million divestiture reserve reversal in discontinued operations related to the sale of the Power Solutions business.

[0000833444-21-000009:8k_2_02:61]
Page 5 of 15

[0000833444-21-000009:8k_2_02:62]
FY21 SECOND QUARTER AND FULL YEAR GUIDANCE

[0000833444-21-000009:8k_2_02:63]
The Company initiated fiscal 2021 second quarter guidance:

[0000833444-21-000009:8k_2_02:64]
▪Organic revenue growth up slightly

[0000833444-21-000009:8k_2_02:65]
▪Adjusted EBITA margin expansion of 80 to 100 basis points, year-over-year

[0000833444-21-000009:8k_2_02:66]
▪Adjusted EPS before special items of $0.47 to $0.49; represents 12 to 17% growth year-over-year

[0000833444-21-000009:8k_2_02:67]
The Company initiated fiscal 2021 full year guidance:

[0000833444-21-000009:8k_2_02:68]
▪Organic revenue growth up low-to-mid single digits

[0000833444-21-000009:8k_2_02:69]
▪Adjusted EBITA margin expansion of 40 to 60 basis points, year-over-year

[0000833444-21-000009:8k_2_02:70]
▪Adjusted EPS before special items of $2.45 to $2.55; represents 9 to 14% growth year-over-year

[0000833444-21-000009:8k_2_02:71]
JOHNSON CONTROLS CONTACTS:

[0000833444-21-000009:8k_2_02:72]
| INVESTORS: | MEDIA: |  |  |  |
| Antonella Franzen | Chaz Bickers |  |  |  |
| Direct: 609.720.4665 | Direct: 224.505.9290 |  |  |  |
| Email: antonella.franzen@jci.com | Email: charles.norman.bickers@jci.com |  |  |  |
| Ryan Edelman | Michael Isaac |  |  |  |
| Direct: 609.720.4545 | Direct: +41.52.6330374 |  |  |  |
| Email: ryan.edelman@jci.com | Email: michael.isaac@jci.com |  |  |  |

[0000833444-21-000009:8k_2_02:73]
###

[0000833444-21-000009:8k_2_02:74]
About Johnson Controls:

[0000833444-21-000009:8k_2_02:75]
At Johnson Controls, we transform the environments where people live, work, learn and play. From optimizing building performance to improving safety and enhancing comfort, we drive the outcomes that matter most. We deliver our promise in industries such as healthcare, education, data centers, and manufacturing. With a global team of 100,000 experts in more than 150 countries and over 130 years of innovation, we are the power behind our customers’ mission. Our leading portfolio of building technology and solutions includes some of the most trusted names in the industry, such as Tyco®, YORK®, Metasys®, Ruskin®, Titus®, Frick®, PENN®, Sabroe®, Simplex®, Ansul® and Grinnell®. For more information, visit www.johnsoncontrols.com or follow us @johnsoncontrols on Twitter

[0000833444-21-000009:8k_2_02:76]
###

[0000833444-21-000009:8k_2_02:77]
Page 6 of 15

[0000833444-21-000009:8k_2_02:78]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-21-000009:8k_2_02:79]
###

[0000833444-21-000009:8k_2_02:80]
Non-GAAP Financial Information

[0000833444-21-000009:8k_2_02:81]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include restructuring and impairment costs, transaction costs, integration costs, net mark-to-market adjustments, Power Solutions divestiture reserve adjustment and discrete tax items. Financial information regarding organic sales, EBIT, EBIT margin, adjusted EBIT, adjusted EBIT margin, total segment EBITA, adjusted segment EBITA, adjusted segment EBITA margin, adjusted corporate expense, free cash flow, and adjusted net income (loss) from continuing operations are also presented, which are non-GAAP performance measures. Adjusted segment EBITA

[0000833444-21-000009:8k_2_02:82]
Page 7 of 15

[0000833444-21-000009:8k_2_02:83]
excludes special items such as integration costs because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.  For further information on the calculation of thee non-GAAP measures and a reconciliation of these non-GAAP measures, refer to the attached footnotes.

[0000833444-21-000009:8k_2_02:84]
###

[0000833444-21-000009:8k_2_02:85]
Page 8 of 15

[0000833444-21-000009:8k_2_02:86]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |  |
|  |  | Three Months Ended December 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Net sales | $ | 5,341 |  |  |  | $ | 5,576 |  |  |
| Cost of sales | 3,613 |  |  |  | 3,773 |  |  |
|  | Gross profit | 1,728 |  |  |  | 1,803 |  |  |
| Selling, general and administrative expenses | (1,294) |  |  |  | (1,427) |  |  |
| Restructuring and impairment costs | — |  |  |  | (111) |  |  |
| Net financing charges | (59) |  |  |  | (52) |  |  |
| Equity income | 58 |  |  |  | 43 |  |  |
| Income from continuing operations before income taxes | 433 |  |  |  | 256 |  |  |
| Income tax provision | 61 |  |  |  | 65 |  |  |
| Income from continuing operations | 372 |  |  |  | 191 |  |  |
| Income from discontinued operations, net of tax | 124 |  |  |  | — |  |  |
| Net income | 496 |  |  |  | 191 |  |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 45 |  |  |  | 32 |  |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | — |  |  |
| Net income attributable to JCI | $ | 451 |  |  |  | $ | 159 |  |  |
| Income from continuing operations | $ | 327 |  |  |  | $ | 159 |  |  |
| Income from discontinued operations | 124 |  |  |  | — |  |  |
| Net income attributable to JCI | $ | 451 |  |  |  | $ | 159 |  |  |
| Diluted earnings per share from continuing operations | $ | 0.45 |  |  |  | $ | 0.21 |  |  |
| Diluted earnings per share from discontinued operations | 0.17 |  |  |  | — |  |  |
| Diluted earnings per share | $ | 0.62 |  |  |  | $ | 0.21 |  |  |
| Diluted weighted average shares | 726.5 |  |  |  | 774.0 |  |  |
| Shares outstanding at period end | 720.3 |  |  |  | 764.0 |  |  |

[0000833444-21-000009:8k_2_02:87]
Page 9 of 15

[0000833444-21-000009:8k_2_02:88]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | December 31, 2020 |  | September 30,2020 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 1,839 |  |  | $ | 1,951 |  |
| Accounts receivable - net | 5,177 |  |  | 5,294 |  |
| Inventories | 1,913 |  |  | 1,773 |  |
| Other current assets | 1,105 |  |  | 1,035 |  |
|  | Current assets | 10,034 |  |  | 10,053 |  |
| Property, plant and equipment - net | 3,082 |  |  | 3,059 |  |
| Goodwill | 18,207 |  |  | 17,932 |  |
| Other intangible assets - net | 5,384 |  |  | 5,356 |  |
| Investments in partially-owned affiliates | 1,003 |  |  | 914 |  |
| Noncurrent assets held for sale | 155 |  |  | 147 |  |
| Other noncurrent assets | 3,559 |  |  | 3,354 |  |
|  | Total assets | $ | 41,424 |  |  | $ | 40,815 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 464 |  |  | $ | 293 |  |
| Accounts payable and accrued expenses | 4,046 |  |  | 3,958 |  |
| Other current liabilities | 3,976 |  |  | 3,997 |  |
|  | Current liabilities | 8,486 |  |  | 8,248 |  |
| Long-term debt | 7,469 |  |  | 7,526 |  |
| Other noncurrent liabilities | 6,646 |  |  | 6,508 |  |
| Shareholders' equity attributable to JCI | 17,656 |  |  | 17,447 |  |
| Noncontrolling interests | 1,167 |  |  | 1,086 |  |
|  | Total liabilities and equity | $ | 41,424 |  |  | $ | 40,815 |  |

[0000833444-21-000009:8k_2_02:89]
Page 10 of 15

[0000833444-21-000009:8k_2_02:90]
| JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Three Months Ended December 31, |
|  |  |  |  |  |  | 2020 |  |  | 2019 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI from continuing operations | $ | 327 |  |  |  | $ | 159 |  |
| Income from continuing operations attributable to noncontrolling interests | 45 |  |  |  | 32 |  |
| Net income from continuing operations | 372 |  |  |  | 191 |  |
| Adjustments to reconcile net income from continuing operations to cash provided by |  |  |  |  |
| operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 207 |  |  |  | 207 |  |
|  |  | Pension and postretirement benefit income | (46) |  |  |  | (40) |  |
|  |  | Pension and postretirement contributions | (17) |  |  |  | (12) |  |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (52) |  |  |  | 8 |  |
|  |  | Deferred income taxes | (59) |  |  |  | (3) |  |
|  |  | Non-cash restructuring and impairment costs | — |  |  |  | 54 |  |
|  |  | Other - net | (25) |  |  |  | 16 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | 224 |  |  |  | 237 |  |
|  |  |  |  | Inventories | (98) |  |  |  | (114) |  |
|  |  |  |  | Other assets | (70) |  |  |  | (92) |  |
|  |  |  |  | Restructuring reserves | (34) |  |  |  | 33 |  |
|  |  |  |  | Accounts payable and accrued liabilities | 91 |  |  |  | (498) |  |
|  |  |  |  | Accrued income taxes | 22 |  |  |  | 524 |  |
|  |  |  |  |  | Cash provided by operating activities from continuing operations | 515 |  |  |  | 511 |  |
| Investing Activities |  |  |  |  |
| Capital expenditures | (91) |  |  |  | (126) |  |
| Acquisition of businesses, net of cash acquired | — |  |  |  | (48) |  |
| Business divestitures, net of cash divested | 11 |  |  |  | — |  |
| Other - net | 43 |  |  |  | 1 |  |
|  |  |  |  |  | Cash used by investing activities from continuing operations | (37) |  |  |  | (173) |  |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | (20) |  |  |  | 10 |  |
| Stock repurchases | (346) |  |  |  | (651) |  |
| Payment of cash dividends | (190) |  |  |  | (203) |  |
| Dividends paid to noncontrolling interests | — |  |  |  | (5) |  |
| Proceeds from the exercise of stock options | 31 |  |  |  | 21 |  |
| Employee equity-based compensation withholding | (21) |  |  |  | (20) |  |
| Other - net | (1) |  |  |  | (2) |  |
|  |  |  |  |  | Cash used by financing activities from continuing operations | (547) |  |  |  | (850) |  |
| Discontinued Operations |  |  |  |  |
| Net cash used by operating activities | (36) |  |  |  | (194) |  |
| Net cash provided by investing activities | — |  |  |  | — |  |
| Net cash provided by financing activities | — |  |  |  | — |  |
|  |  |  |  |  | Net cash flows used by discontinued operations | (36) |  |  |  | (194) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (11) |  |  |  | 57 |  |
| Changes in cash held for sale | — |  |  |  | — |  |
| Decrease in cash, cash equivalents and restricted cash | $ | (116) |  |  |  | $ | (649) |  |

[0000833444-21-000009:8k_2_02:91]
Page 11 of 15

[0000833444-21-000009:8k_2_02:92]
FOOTNOTES

[0000833444-21-000009:8k_2_02:93]
1. Financial Summary

[0000833444-21-000009:8k_2_02:94]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, restructuring and impairment costs, and the net mark-to-market adjustments related to restricted asbestos investments and pension and postretirement plans. The financial results shown below are for continuing operations and exclude the Power Solutions business.

[0000833444-21-000009:8k_2_02:95]
| (in millions; unaudited) | Three Months Ended December 31, |  |
|  | 2020 |  | 2019 |  |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |  |
| Net sales |  |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,034 |  |  | $ | 2,034 |  |  | $ | 2,167 |  |  | $ | 2,167 |  |  |
| Building Solutions EMEA/LA | 906 |  |  | 906 |  |  | 928 |  |  | 928 |  |  |
| Building Solutions Asia Pacific | 615 |  |  | 615 |  |  | 629 |  |  | 629 |  |  |
| Global Products | 1,786 |  |  | 1,786 |  |  | 1,852 |  |  | 1,852 |  |  |
| Net sales | $ | 5,341 |  |  | $ | 5,341 |  |  | $ | 5,576 |  |  | $ | 5,576 |  |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 255 |  |  | $ | 255 |  |  | $ | 258 |  |  | $ | 259 |  |  |
| Building Solutions EMEA/LA | 95 |  |  | 95 |  |  | 90 |  |  | 90 |  |  |
| Building Solutions Asia Pacific | 79 |  |  | 79 |  |  | 72 |  |  | 72 |  |  |
| Global Products | 213 |  |  | 213 |  |  | 203 |  |  | 204 |  |  |
| Segment EBITA | 642 |  |  | 642 |  |  | 623 |  |  | 625 |  |  |
| Corporate expenses (2) | (67) |  |  | (67) |  |  | (118) |  |  | (81) |  |  |
| Amortization of intangible assets | (104) |  |  | (104) |  |  | (96) |  |  | (96) |  |  |
| Net mark-to-market adjustments (3) | 21 |  |  | — |  |  | 10 |  |  | — |  |  |
| Restructuring and impairment costs (4) | — |  |  | — |  |  | (111) |  |  | — |  |  |
| EBIT (5) | 492 |  |  | 471 |  |  | 308 |  |  | 448 |  |  |
| EBIT margin | 9.2 | % |  | 8.8 | % |  | 5.5 | % |  | 8.0 | % |  |
| Net financing charges | (59) |  |  | (59) |  |  | (52) |  |  | (52) |  |  |
| Income from continuing operations before income taxes | 433 |  |  | 412 |  |  | 256 |  |  | 396 |  |  |
| Income tax provision (6) | (61) |  |  | (56) |  |  | (65) |  |  | (53) |  |  |
| Income from continuing operations | 372 |  |  | 356 |  |  | 191 |  |  | 343 |  |  |
| Income from continuing operations attributable to noncontrolling interests | (45) |  |  | (45) |  |  | (32) |  |  | (37) |  |  |
| Net income from continuing operations attributable to JCI | $ | 327 |  |  | $ | 311 |  |  | $ | 159 |  |  | $ | 306 |  |  |

[0000833444-21-000009:8k_2_02:96]
(1) The Company's press release contains financial information regarding segment EBITA, adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures. The Company's definition of adjusted segment EBITA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its businesses. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-21-000009:8k_2_02:97]
A reconciliation of segment EBITA to income from continuing operations is shown earlier within this footnote. The following is the three months ended December 31, 2020 and 2019 reconciliation of segment EBITA and segment EBITA margin as reported to adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-21-000009:8k_2_02:98]
| (in millions) | Building SolutionsNorth America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | ConsolidatedJCI plc |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Segment EBITA as reported | $ | 255 |  |  | $ | 258 |  |  | $ | 95 |  |  | $ | 90 |  |  | $ | 79 |  |  | $ | 72 |  |  | $ | 213 |  |  | $ | 203 |  |  | $ | 642 |  |  | $ | 623 |  |
| Segment EBITA margin as reported | 12.5 | % |  | 11.9 | % |  | 10.5 | % |  | 9.7 | % |  | 12.8 | % |  | 11.4 | % |  | 11.9 | % |  | 11.0 | % |  | 12.0 | % |  | 11.2 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Integration costs | — |  |  | 1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 2 |  |
| Adjusted segment EBITA | $ | 255 |  |  | $ | 259 |  |  | $ | 95 |  |  | $ | 90 |  |  | $ | 79 |  |  | $ | 72 |  |  | $ | 213 |  |  | $ | 204 |  |  | $ | 642 |  |  | $ | 625 |  |
| Adjusted segment EBITA margin | 12.5 | % |  | 12.0 | % |  | 10.5 | % |  | 9.7 | % |  | 12.8 | % |  | 11.4 | % |  | 11.9 | % |  | 11.0 | % |  | 12.0 | % |  | 11.2 | % |

[0000833444-21-000009:8k_2_02:99]
Page 12 of 15

[0000833444-21-000009:8k_2_02:100]
(2) Adjusted Corporate expenses excludes special items because these costs are not considered to be directly related to the underlying operating performance of the Company's business. Adjusted Corporate expenses for the three months ended December 31, 2019 excludes $37 million of integration costs.

[0000833444-21-000009:8k_2_02:101]
(3) The three months ended December 31, 2020 exclude the net mark-to-market adjustments on restricted investments of $21 million. The three months ended December 31, 2019 exclude the net mark-to-market adjustments on restricted investments of $10 million.

[0000833444-21-000009:8k_2_02:102]
(4) Restructuring and impairment costs for the three months ended December 31, 2019 of $111 million are excluded from the adjusted non-GAAP results. The restructuring actions and impairment costs related primarily to workforce reductions, plant closures, and asset impairments.

[0000833444-21-000009:8k_2_02:103]
(5) Management defines earnings before interest and taxes (EBIT) as income (loss) from continuing operations before net financing charges, income taxes and noncontrolling interests. EBIT is a non-GAAP performance measure. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company. A reconciliation of EBIT to income (loss) from continuing operations is shown earlier within this footnote.

[0000833444-21-000009:8k_2_02:104]
(6) Adjusted income tax provision for the three months ended December 31, 2020 excludes tax provision from net mark-to-market adjustments of $5 million. Adjusted income tax provision for the three months ended December 31, 2019 excludes tax provisions related to Switzerland tax reform of $30 million and net mark-to-market adjustments of $3 million, partially offset by tax benefits for restructuring and impairment costs of $16 million and integration costs of $5 million.

[0000833444-21-000009:8k_2_02:105]
2.  Diluted Earnings Per Share Reconciliation

[0000833444-21-000009:8k_2_02:106]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include transaction/integration costs, net mark-to-market adjustments, restructuring and impairment costs, Power Solutions divestiture reserve adjustment, and discrete tax items. The Company excludes these items because they are not considered to be directly related to the underlying operating performance of the Company. Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-21-000009:8k_2_02:107]
A reconciliation of diluted earnings per share as reported to adjusted diluted earnings per share for the respective periods is shown below (unaudited):

[0000833444-21-000009:8k_2_02:108]
|  | Net Income Attributableto JCI plc |  | Net Income Attributableto JCI plc from Continuing Operations |
|  | Three Months Ended |  | Three Months Ended |
|  | December 31, |  | December 31, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Earnings per share as reported for JCI plc | $ | 0.62 |  |  | $ | 0.21 |  |  | $ | 0.45 |  |  | $ | 0.21 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Integration costs | — |  |  | 0.05 |  |  | — |  |  | 0.05 |  |
| Related tax impact | — |  |  | (0.01) |  |  | — |  |  | (0.01) |  |
| Net mark-to-market adjustments | (0.03) |  |  | (0.01) |  |  | (0.03) |  |  | (0.01) |  |
| Related tax impact | 0.01 |  |  | — |  |  | 0.01 |  |  | — |  |
| Restructuring and impairment costs | — |  |  | 0.14 |  |  | — |  |  | 0.14 |  |
| Related tax impact | — |  |  | (0.02) |  |  | — |  |  | (0.02) |  |
| NCI impact of restructuring and impairment | — |  |  | (0.01) |  |  | — |  |  | (0.01) |  |
| Power Solutions divestiture reserve adjustment | (0.21) |  |  | — |  |  | — |  |  | — |  |
| Related tax impact | 0.04 |  |  | — |  |  | — |  |  | — |  |
| Discrete tax items | — |  |  | 0.04 |  |  | — |  |  | 0.04 |  |
| Adjusted earnings per share for JCI plc* | $ | 0.43 |  |  | $ | 0.40 |  |  | $ | 0.43 |  |  | $ | 0.40 |  |

[0000833444-21-000009:8k_2_02:109]
* May not sum due to rounding

[0000833444-21-000009:8k_2_02:110]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-21-000009:8k_2_02:111]
|  | Three Months Ended |  |  |  |  |
|  | December 31, |  |  |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Weighted average shares outstanding for JCI plc |  |  |  |  |  |  |  |
| Basic weighted average shares outstanding | 723.1 |  |  | 769.9 |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Stock options, unvested restricted stock |  |  |  |  |  |  |  |
| and unvested performance share awards | 3.4 |  |  | 4.1 |  |  |  |  |  |
| Diluted weighted average shares outstanding | 726.5 |  |  | 774.0 |  |  |  |  |  |

[0000833444-21-000009:8k_2_02:112]
The Company has presented forward-looking statements regarding adjusted EPS, organic revenue, adjusted EBITA margin, and free cash flow conversion, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts, expenses, or income from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts that are excluded from these non-GAAP financial measures are a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period, including but not limited to the high variability of the net mark-to-market adjustments and the effect of foreign currency exchange fluctuations. Our fiscal 2021 full year and second quarter guidance for organic revenue also excludes the effect of acquisitions, divestitures, and foreign currency. We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available and management cannot reliably predict all of the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s second quarter and full year 2021 GAAP financial results.

[0000833444-21-000009:8k_2_02:113]
Page 13 of 15

[0000833444-21-000009:8k_2_02:114]
3. Organic Growth Reconciliation

[0000833444-21-000009:8k_2_02:115]
The components of the changes in net sales for the three months ended December 31, 2020 versus the three months ended December 31, 2019, including organic growth, is shown below (unaudited):

[0000833444-21-000009:8k_2_02:116]
| (in millions) | Net Sales for the Three Months Ended December 31, 2019 |  | Base Year Adjustments - Divestitures and Other |  | Base Year Adjustments -Foreign Currency |  | Adjusted Base Net Sales for the Three Months Ended December 31, 2019 |  | Acquisitions |  | Organic Growth |  | Net Sales for the Three Months EndedDecember 31, 2020 |
| Building Solutions North America | $ | 2,167 |  |  | $ | — |  |  | — |  |  | $ | 3 |  |  | — |  |  | $ | 2,170 |  |  | $ | — |  |  | — |  |  | $ | (136) |  |  | -6 | % |  | $ | 2,034 |  |  | -6 | % |
| Building Solutions EMEA/LA | 928 |  |  | — |  |  | — |  |  | 21 |  |  | 2 | % |  | 949 |  |  | 9 |  |  | 1 | % |  | (52) |  |  | -5 | % |  | 906 |  |  | -2 | % |
| Building Solutions Asia Pacific | 629 |  |  | (2) |  |  | — |  |  | 28 |  |  | 4 | % |  | 655 |  |  | — |  |  | — |  |  | (40) |  |  | -6 | % |  | 615 |  |  | -2 | % |
| Total field | 3,724 |  |  | (2) |  |  | — |  |  | 52 |  |  | 1 | % |  | 3,774 |  |  | 9 |  |  | — |  |  | (228) |  |  | -6 | % |  | 3,555 |  |  | -5 | % |
| Global Products | 1,852 |  |  | (71) |  |  | -4 | % |  | 37 |  |  | 2 | % |  | 1,818 |  |  | — |  |  | — |  |  | (32) |  |  | -2 | % |  | 1,786 |  |  | -4 | % |
| Total net sales | $ | 5,576 |  |  | $ | (73) |  |  | -1 | % |  | $ | 89 |  |  | 2 | % |  | $ | 5,592 |  |  | $ | 9 |  |  | — |  |  | $ | (260) |  |  | -5 | % |  | $ | 5,341 |  |  | -4 | % |

[0000833444-21-000009:8k_2_02:117]
4.  Free Cash Flow Reconciliation

[0000833444-21-000009:8k_2_02:118]
The Company's press release contains financial information regarding free cash flow which is a non-GAAP performance measure. Free cash flow is defined as cash provided by operating activities less capital expenditures. Management believes this non-GAAP measure is useful to investors in understanding the strength of the Company and its ability to generate cash.

[0000833444-21-000009:8k_2_02:119]
The following is the three months ended December 31, 2020 and 2019 reconciliation of free cash flow for continuing operations (unaudited):

[0000833444-21-000009:8k_2_02:120]
| (in billions) | Three Months Ended December 31, 2020 |  | Three Months Ended December 31, 2019 |  |  |
| Cash provided by operating activities from continuing operations | $ | 0.5 |  |  | $ | 0.5 |  |  |  |
| Capital expenditures | (0.1) |  |  | (0.1) |  |  |  |
| Reported free cash flow | $ | 0.4 |  |  | $ | 0.4 |  |  |  |

[0000833444-21-000009:8k_2_02:121]
5.  Net Debt to EBITDA

[0000833444-21-000009:8k_2_02:122]
The Company provides financial information regarding net debt to adjusted EBITDA, which is a non-GAAP performance measure. The Company believes the total net debt to adjusted EBITDA ratio is useful to understanding the Company's financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders. The following is the December 31, 2020 calculation of net debt to adjusted EBITDA (unaudited):

[0000833444-21-000009:8k_2_02:123]
| (in millions) | December 31, 2020 |  |  |
| Short-term debt and current portion of long-term debt | $ | 464 |  |  |  |
| Long-term debt | 7,469 |  |  |  |
| Total debt | 7,933 |  |  |  |
| Less: cash and cash equivalents | 1,839 |  |  |  |
| Total net debt | $ | 6,094 |  |  |  |
| Last twelve months adjusted EBITDA | $ | 3,210 |  |  |  |
| Total net debt to adjusted EBITDA | 1.9x |  |  |

[0000833444-21-000009:8k_2_02:124]
The following is the last twelve months ended December 31, 2020 reconciliation of income from continuing operations to adjusted EBIT and adjusted EBITDA, which are non-GAAP performance measures (unaudited):

[0000833444-21-000009:8k_2_02:125]
| (in millions) | Last Twelve MonthsEndedDecember 31, 2020 |  |  |
| Income from continuing operations | $ | 976 |  |  |  |
| Income tax provision | 104 |  |  |  |
| Net financing charges | 238 |  |  |  |
| EBIT | 1,318 |  |  |  |
| Adjusting items: |  |  |  |
| Integration costs | 96 |  |  |  |
| Net mark-to-market adjustments | 263 |  |  |  |
| Restructuring and impairment costs | 672 |  |  |  |
| Acquisition related compensation charge | 39 |  |  |  |
| Adjusted EBIT (1) | 2,388 |  |  |  |
| Depreciation and amortization | 822 |  |  |  |
| Adjusted EBITDA (1) | $ | 3,210 |  |  |  |

[0000833444-21-000009:8k_2_02:126]
(1) The Company's definition of adjusted EBIT and adjusted EBITDA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its businesses. Management believes this non-GAAP measure is useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-21-000009:8k_2_02:127]
Page 14 of 15

[0000833444-21-000009:8k_2_02:128]
6.  Trade Working Capital as a Percentage of Net Sales

[0000833444-21-000009:8k_2_02:129]
The Company provides financial information regarding trade working capital as a percentage of net sales, which is a non-GAAP performance measure. Trade working capital is defined as current assets less current liabilities, excluding cash, short-term debt, the current portion of long-term debt, the current portion of assets and liabilities held for sale, accrued compensation and benefits, and other current assets and liabilities. Management believes this non-GAAP measure, which excludes financing-related items, non-trade related items and businesses to be divested, is a more useful measurement of the Company's operating performance. The following is the December 31, 2020 and December 31, 2019 calculation of trade working capital as a percentage of net sales (unaudited):

[0000833444-21-000009:8k_2_02:130]
| (in millions) | December 31, 2020 |  | December 31, 2019 |
| Current assets | $ | 10,034 |  |  | $ | 11,320 |  |
| Current liabilities | (8,486) |  |  | (9,692) |  |
| Total working capital | 1,548 |  |  | 1,628 |  |
| Less: cash and cash equivalents | (1,839) |  |  | (2,160) |  |
| Less: assets held for sale | — |  |  | (87) |  |
| Less: other current assets | (1,105) |  |  | (1,508) |  |
| Add: short-term debt | 11 |  |  | 20 |  |
| Add: current portion of long-term debt | 453 |  |  | 1,342 |  |
| Add: accrued compensation and benefits | 836 |  |  | 844 |  |
| Add: liabilities held for sale | — |  |  | 44 |  |
| Add: other current liabilities | 2,393 |  |  | 2,611 |  |
| Trade working capital | $ | 2,297 |  |  | $ | 2,734 |  |
| Last twelve months net sales | $ | 22,082 |  |  | $ | 24,080 |  |
| Trade working capital as a percentage of net sales | 10.4 | % |  | 11.4 | % |

[0000833444-21-000009:8k_2_02:131]
7. Income Taxes

[0000833444-21-000009:8k_2_02:132]
The Company's effective tax rate from continuing operations before consideration of transaction/integration costs, net mark-to-market adjustments, restructuring and impairment costs and discrete tax items for the three months ending December 31, 2020 and December 31, 2019 is approximately 13.5%.

[0000833444-21-000009:8k_2_02:133]
8.  Restructuring and Impairment Costs

[0000833444-21-000009:8k_2_02:134]
The three months ended December 31, 2019 include restructuring and impairment costs of $111 million related primarily to workforce reductions, plant closures and asset impairments.

[0000833444-21-000009:8k_2_02:135]
Page 15 of 15
