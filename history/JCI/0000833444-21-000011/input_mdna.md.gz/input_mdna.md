# JCI MD&A — 0000833444-21-000011


## mdna

[0000833444-21-000011:mdna:1]
[same as prior period, unchanged from 0000833444-20-000036:mdna:1]

[0000833444-21-000011:mdna:2]
[same as prior period, unchanged from 0000833444-20-000036:mdna:2]

[0000833444-21-000011:mdna:3]
[same as prior period, unchanged from 0000833444-20-000036:mdna:3]

[0000833444-21-000011:mdna:4]
[same as prior period, unchanged from 0000833444-20-000036:mdna:4]

[0000833444-21-000011:mdna:5]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global diversified technology and multi industrial leader serving a wide range of customers in more than 150 countries. The Company’s products and solutions enable smart, energy efficient, sustainable buildings that work seamlessly together to advance the safety, comfort and intelligence of spaces to power its customers’ mission. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

[0000833444-21-000011:mdna:6]
Johnson Controls was originally incorporated in the state of Wisconsin in 1885 as Johnson Electric Service Company to manufacture, install and service automatic temperature regulation systems for buildings. The Company was renamed to Johnson Controls, Inc. in 1974. In 2005, the Company acquired York International, a global supplier of heating, ventilating, air-conditioning ("HVAC") and refrigeration equipment and services. In 2014, the Company acquired Air Distribution Technologies, Inc., one of the largest independent providers of air distribution and ventilation products in North America. In 2015, the Company formed a joint venture with Hitachi to expand its building related product offerings. In 2016, Johnson Controls, Inc. and Tyco completed their combination (the "Merger"), combining Johnson Controls portfolio of building efficiency solutions with Tyco’s portfolio of fire and security solutions. Following the Merger, Tyco changed its name to "Johnson Controls International plc."

[0000833444-21-000011:mdna:7]
In 2016, Johnson Controls completed the spin-off of its automotive business into Adient plc, an independent, publicly traded company. In 2019, the Company sold its Power Solutions business to BCP Acquisitions LLC, an entity controlled by investment funds managed by Brookfield Capital Partners LLC, completing the Company’s transformation into a pure-play building technologies and solutions provider.

[0000833444-21-000011:mdna:8]
The Company is a global leader in engineering, manufacturing and commissioning building products and systems, including residential and commercial HVAC equipment, industrial refrigeration systems, controls, security systems, fire detection systems and fire suppression solutions. The Company further serves customers by providing technical services, including maintenance, repair, retrofit and replacement of equipment (in the HVAC, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions powered by its digital platforms and capabilities.

[0000833444-21-000011:mdna:9]
The Company continues to observe trends demonstrating increased interest and demand for safe, efficient and sustainable buildings, and seeks to capitalize on these trends to drive growth by delivering technologies and solutions to create healthy buildings. In 2020, the Company launched OpenBlue, a digitally driven suite of connected solutions that delivers impactful sustainability, new occupant experiences, and respectful safety and security by combining the Company’s building expertise with cutting-edge technology, including AI-powered service solutions such as remote diagnostics, predictive maintenance, compliance monitoring and advanced risk assessments.

[0000833444-21-000011:mdna:10]
The following information should be read in conjunction with the September 30, 2020 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in our Annual Report on Form 10-K for the year ended September 30, 2020 filed with the SEC on November 16, 2020. References in the following discussion and analysis to "Three Months" (or similar language) refer to the three months ended December 31, 2020 compared to the three months ended December 31, 2019.

[0000833444-21-000011:mdna:11]
[same as prior period, unchanged from 0000833444-20-000036:mdna:11]

[0000833444-21-000011:mdna:12]
The global outbreak of COVID-19 has severely restricted the level of economic activity around the world and caused a significant contraction in the global economy. In response to this outbreak, the governments of many countries, states, cities and other geographic regions have taken and continue to take preventative or protective actions, such as imposing restrictions on travel and business operations.

[0000833444-21-000011:mdna:13]
The Company’s affiliates, employees, suppliers, customers and others have been and may continue to be restricted or prevented from conducting normal business activities, including as a result of shutdowns, travel restrictions and other actions that may be requested or mandated by governmental authorities. Although some governments have lifted shutdown orders and similar restrictions, resurgences in the spread of COVID-19 have caused the reinstitution of such restrictions in certain jurisdictions and similar restrictions could be reinstituted elsewhere in response to further outbreaks. While a substantial portion of the Company's businesses have been classified as an essential business in jurisdictions in which facility closures have been mandated, some of its facilities have nevertheless been ordered to close, and we can give no assurance that there will not be additional closures in the future or that the Company's businesses will be classified as essential in each of the jurisdictions in which it operates.

[0000833444-21-000011:mdna:14]
In response to the challenges presented by COVID-19, the Company has focused its efforts on preserving the health and safety of its employees and customers, as well as maintaining the continuity of its operations. The Company has modified its business practices in response to the COVID-19 outbreak, including restricting non-essential employee travel, implementation of remote work protocols, and cancellation of physical participation in meetings, events and conferences. The Company has also instituted preventive measures at its facilities, including enhanced health and safety protocols, temperature screening, requiring face coverings for all employees and encouraging employees to follow similar protocols when away from work. The Company has adopted a multifaceted framework to guide its decision making when evaluating the readiness of its facilities to safely reopen and operate, and will continue to monitor and audit its facilities to ensure that they are in compliance with the Company’s COVID-19 safety requirements.

[0000833444-21-000011:mdna:15]
During portions of fiscal 2020, the Company experienced temporary reductions of its manufacturing and operating capacity in China, India and Mexico. Currently, the Company’s facilities have been operating at normal levels. The Company has experienced, and may continue to experience, disruptions or delays in its supply chain as a result of government-mandated actions, which has resulted in higher supply chain costs to the Company in order to maintain the supply of materials and components for its products. While actions taken by the Company to mitigate manufacturing and supply chain disruptions,

[0000833444-21-000011:mdna:16]
including redistributing manufacturing capacity, expanding supplier diversity, government outreach and supplier financing, have generally been successful, a continued resurgence of COVID-19 could lead to further disruptions.

[0000833444-21-000011:mdna:17]
The Company experienced a decline in demand and volumes in its global businesses as a result of the impact of efforts to contain the spread of COVID-19. Specifically, the Company experienced lower demand due to restricted access to customer sites to perform service and installation work as well as reduced discretionary capital spending by the Company's customers. Although the Company has experienced increases in demand and volumes as governments have lifted COVID-19-related restrictions, the reinstitution of lockdowns or other restrictive measures by governments could cause a decrease in economic activity and demand for the Company’s products and services.

[0000833444-21-000011:mdna:18]
The global pandemic has also provided the Company with the opportunity to help its customers prepare to re-open by delivering solutions and support that enhance the safety and increase the efficiency of their operations. The Company has seen an increase in demand for its products and solutions that promote building health and optimize customers’ infrastructure, including thermal cameras, indoor air quality, location-based services for contact tracing and touchless access control.

[0000833444-21-000011:mdna:19]
In fiscal 2020, the Company executed temporary and permanent cost mitigation actions to offset a portion of the impact of COVID-19 on the demand for its products and services. As a result of these and other permanent cost mitigation actions, including the Company's 2020 restructuring plan, the Company experienced a positive impact on its results of operations for the three months ended December 31, 2020. Although the Company has largely ceased temporary cost mitigation actions initiated in fiscal 2020, the necessity of future cost mitigation actions will depend on the continued impact of COVID-19, which is highly uncertain.

[0000833444-21-000011:mdna:20]
During fiscal 2020, the Company determined that it had triggering events requiring assessment of impairment for certain of its indefinite-lived intangible assets due to declines in revenue directly attributable to the COVID-19 pandemic and for certain of its indefinite-lived intangible assets, long-lived assets and goodwill due to declines in revenue and further declines in forecasted cash flows in its North America Retail reporting unit. As a result, the Company recorded an impairment charge of $62 million related primarily to the Company's retail business indefinite-lived intangible assets and an impairment charge of $424 million related to the Company's North America Retail reporting unit's goodwill. There were no triggering events requiring that an impairment assessment be conducted in the first quarter of fiscal 2021. However, it is possible that future changes in circumstances, including a more prolonged and/or severe COVID-19 pandemic, would require the Company to record additional non-cash impairment charges.

[0000833444-21-000011:mdna:21]
The Company continues to actively monitor its liquidity position and working capital needs. The Company believes that, following its implementation of liquidity and cost mitigation actions in fiscal 2020, it remains in a solid overall capital resources and liquidity position that is adequate to meet its projected needs.

[0000833444-21-000011:mdna:22]
The extent to which the COVID-19 outbreak continues to impact the Company’s results of operations and financial condition will depend on future developments that are highly uncertain and cannot be predicted, including new information that may emerge concerning the severity and longevity of COVID-19, the resurgence of COVID-19 in regions that have begun to recover from the initial impact of the pandemic, the impact of COVID-19 on economic activity, and the actions to contain its impact on public health and the global economy See Part I, Item 1A, of the Company’s Annual Report on Form 10-K for the year ended September 30, 2020 for an additional discussion of risks related to COVID-19.

[0000833444-21-000011:mdna:23]
41

[0000833444-21-000011:mdna:24]
[same as prior period, unchanged from 0000833444-20-000036:mdna:24]

[0000833444-21-000011:mdna:25]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  |  |  |  |  |  |
| Net sales | $ | 5,341 |  |  | $ | 5,576 |  |  | -4 | % |  |  |  |  |  |  |

[0000833444-21-000011:mdna:26]
The decrease in consolidated net sales for the three months ended December 31, 2020 was due to lower organic sales ($260 million) and lower sales due to business divestitures ($73 million), partially offset by the favorable impact of foreign currency translation ($89 million) and incremental sales from acquisitions ($9 million). Excluding the impact of foreign currency translation and business acquisitions and divestitures, consolidated net sales decreased 5% as compared to the prior year primarily due to the unfavorable impact of the COVID-19 pandemic on demand and volumes. Refer to the "Segment Analysis" below within this Item 2 for a discussion of net sales by segment.

[0000833444-21-000011:mdna:27]
[same as prior period, unchanged from 0000833444-20-000036:mdna:28]

[0000833444-21-000011:mdna:28]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  |  |  |  |  |  |
| Cost of sales | $ | 3,613 |  |  | $ | 3,773 |  |  | -4 | % |  |  |  |  |  |  |
| Gross profit | 1,728 |  |  | 1,803 |  |  | -4 | % |  |  |  |  |  |  |
| % of sales | 32.4 | % |  | 32.3 | % |  |  |  |  |  |  |  |  |

[0000833444-21-000011:mdna:29]
Cost of sales and gross profit decreased for the three month period ended December 31, 2020, and gross profit as a percentage of sales increased by 10 basis points. Gross profit decreased due to organic sales declines from the unfavorable impact of the COVID-19 pandemic. Foreign currency translation had an unfavorable impact on cost of sales of approximately $63 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA") by segment.

[0000833444-21-000011:mdna:30]
[same as prior period, unchanged from 0000833444-20-000036:mdna:32]

[0000833444-21-000011:mdna:31]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  |  |  |  |  |  |
| Selling, general and administrative expenses | $ | 1,294 |  |  | $ | 1,427 |  |  | -9 | % |  |  |  |  |  |  |
| % of sales | 24.2 | % |  | 25.6 | % |  |  |  |  |  |  |  |  |

[0000833444-21-000011:mdna:32]
Selling, general and administrative expenses ("SG&A") for the three month period ended December 31, 2020 decreased $133 million, and SG&A as a percentage of sales decreased by 140 basis points. The decrease in SG&A was primarily due to a favorable impact of cost mitigation actions and reduction in discretionary spend in the current quarter and the favorable year-over-year impact of net mark-to-market adjustments on restricted asbestos investments, partially offset by an unfavorable impact of foreign currency translation. Foreign currency translation had an unfavorable impact on SG&A of $20 million. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-21-000011:mdna:33]
42

[0000833444-21-000011:mdna:34]
[same as prior period, unchanged from 0000833444-20-000036:mdna:37]

[0000833444-21-000011:mdna:35]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  |  |  |  |  |  |
| Restructuring and impairment costs | $ | — |  |  | $ | 111 |  |  | * |  |  |  |  |  |  |

[0000833444-21-000011:mdna:36]
[same as prior period, unchanged from 0000833444-20-000036:mdna:39]

[0000833444-21-000011:mdna:37]
Refer to Note 10, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for further disclosure related to the Company's restructuring plans and impairment costs.

[0000833444-21-000011:mdna:38]
[same as prior period, unchanged from 0000833444-20-000036:mdna:41]

[0000833444-21-000011:mdna:39]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  |  |  |  |  |  |
| Net financing charges | $ | 59 |  |  | $ | 52 |  |  | 13 | % |  |  |  |  |  |  |

[0000833444-21-000011:mdna:40]
Refer to Note 13, "Debt and Financing Arrangements," of the notes to consolidated financial statements for further disclosure related to the Company's net financing charges.

[0000833444-21-000011:mdna:41]
[same as prior period, unchanged from 0000833444-20-000036:mdna:44]

[0000833444-21-000011:mdna:42]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  |  |  |  |  |  |
| Equity income | $ | 58 |  |  | $ | 43 |  |  | 35 | % |  |  |  |  |  |  |

[0000833444-21-000011:mdna:43]
The increase in equity income for the three months ended December 31, 2020 was primarily due to higher income at certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture. Foreign currency translation had a favorable impact on equity income of $3 million for the three months ended December 31, 2020. Refer to the "Segment Analysis" below within this Item 2 for a discussion of segment EBITA by segment.

[0000833444-21-000011:mdna:44]
Income Tax Provision

[0000833444-21-000011:mdna:45]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  |  |  |  |  |  |
| Income tax provision | $ | 61 |  |  | $ | 65 |  |  | -6 | % |  |  |  |  |  |  |
| Effective tax rate | 14 | % |  | 25 | % |  |  |  |  |  |  |  |  |

[0000833444-21-000011:mdna:46]
[same as prior period, unchanged from 0000833444-20-000036:mdna:51]

[0000833444-21-000011:mdna:47]
The statutory tax rate in Ireland is being used as a comparison since the Company is domiciled in Ireland. For the three months ended December 31, 2020, the Company's effective tax rate for continuing operations was 14% and was higher than the statutory tax rate of 12.5% primarily due to tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives.  For the three months ended December 31, 2019, the Company's effective tax rate for continuing operations was 25% and was higher than the statutory tax rate of 12.5% primarily due to a discrete tax charge related to the remeasurement

[0000833444-21-000011:mdna:48]
43

[0000833444-21-000011:mdna:49]
of deferred tax assets and liabilities as a result of Swiss tax reform and tax rate differentials, partially offset by the benefits of continuing global tax planning initiatives. The effective tax rate for the three months ended December 31, 2020 decreased as compared to the three months ended December 31, 2019 primarily due to the discrete tax items. Refer to Note 11, "Income Taxes," of the notes to consolidated financial statements for further detail.

[0000833444-21-000011:mdna:50]
[same as prior period, unchanged from 0000833444-20-000036:mdna:53]

[0000833444-21-000011:mdna:51]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  |  |  |  |  |  |
| Income from discontinued operations, net of tax | $ | 124 |  |  | $ | — |  |  | * |  |  |  |  |  |  |

[0000833444-21-000011:mdna:52]
[same as prior period, unchanged from 0000833444-20-000036:mdna:50]

[0000833444-21-000011:mdna:53]
[same as prior period, unchanged from 0000833444-20-000036:mdna:56]

[0000833444-21-000011:mdna:54]
[same as prior period, unchanged from 0000833444-20-000036:mdna:57]

[0000833444-21-000011:mdna:55]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  |  |  |  |  |  |
| Income from continuing operations attributable to noncontrolling interests | $ | 45 |  |  | $ | 32 |  |  | 41 | % |  |  |  |  |  |  |

[0000833444-21-000011:mdna:56]
The increase in income from continuing operations attributable to noncontrolling interests for the three months ended December 31, 2020 was primarily due to higher net income at certain partially-owned affiliates within the Global Products segment.

[0000833444-21-000011:mdna:57]
Net Income Attributable to Johnson Controls

[0000833444-21-000011:mdna:58]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  |  |  |  |  |  |
| Net income attributable to Johnson Controls | $ | 451 |  |  | $ | 159 |  |  | * |  |  |  |  |  |  |

[0000833444-21-000011:mdna:59]
[same as prior period, unchanged from 0000833444-20-000036:mdna:55]

[0000833444-21-000011:mdna:60]
The increase in net income attributable to Johnson Controls for the three months ended December 31, 2020 was primarily due to lower SG&A, the current year income from discontinued operations, and prior year restructuring and impairment charges, partially offset by the unfavorable impact of the COVID-19 pandemic.

[0000833444-21-000011:mdna:61]
Diluted earnings per share attributable to Johnson Controls for the three months ended December 31, 2020 was $0.62 compared to $0.21 for the three months ended December 31, 2019.

[0000833444-21-000011:mdna:62]
[same as prior period, unchanged from 0000833444-20-000036:mdna:67]

[0000833444-21-000011:mdna:63]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  |  |  |  |  |  |
| Comprehensive income attributable to Johnson Controls | $ | 723 |  |  | $ | 414 |  |  | 75 | % |  |  |  |  |  |  |

[0000833444-21-000011:mdna:64]
The increase in comprehensive income attributable to Johnson Controls for the three months ended December 31, 2020 was due to higher net income attributable to Johnson Controls ($292 million) and an increase in other comprehensive income attributable to Johnson Controls ($17 million) resulting primarily from favorable currency translation adjustments. The year-over-year favorable foreign currency translation adjustments were primarily driven by the strengthening of the euro, Mexican peso and Canadian dollar against the U.S. dollar in the current quarter.

[0000833444-21-000011:mdna:65]
[same as prior period, unchanged from 0000833444-20-000036:mdna:74]

[0000833444-21-000011:mdna:66]
[same as prior period, unchanged from 0000833444-20-000036:mdna:75]

[0000833444-21-000011:mdna:67]
[same as prior period, unchanged from 0000833444-20-000036:mdna:76]

[0000833444-21-000011:mdna:68]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,034 |  |  | $ | 2,167 |  |  | -6 | % |  |  |  |  |  |  |
| Building Solutions EMEA/LA | 906 |  |  | 928 |  |  | -2 | % |  |  |  |  |  |  |
| Building Solutions Asia Pacific | 615 |  |  | 629 |  |  | -2 | % |  |  |  |  |  |  |
| Global Products | 1,786 |  |  | 1,852 |  |  | -4 | % |  |  |  |  |  |  |
|  | $ | 5,341 |  |  | $ | 5,576 |  |  | -4 | % |  |  |  |  |  |  |

[0000833444-21-000011:mdna:69]
•The decrease in Building Solutions North America was due to lower volumes ($136 million), partially offset by the favorable impact of foreign currency translation ($3 million). The decrease in volumes was primarily attributable to the unfavorable impact of the COVID-19 pandemic.

[0000833444-21-000011:mdna:70]
•The decrease in Building Solutions EMEA/LA was due to lower volumes ($52 million), partially offset by the favorable impact of foreign currency translation ($21 million) and incremental sales related to business acquisitions ($9 million). The decrease in volumes was primarily attributable to the unfavorable impact of the COVID-19 pandemic.

[0000833444-21-000011:mdna:71]
•The decrease in Building Solutions Asia Pacific was due to lower volumes ($40 million) and business divestitures ($2 million), partially offset by the favorable impact of foreign currency translation ($28 million). The decrease in volumes was primarily attributable to the unfavorable impact of the COVID-19 pandemic.

[0000833444-21-000011:mdna:72]
•The decrease in Global Products was due to business divestitures ($71 million) and lower volumes ($32 million), partially offset by the favorable impact of foreign currency translation ($37 million). The decrease in volumes was primarily attributable to the unfavorable impact of the COVID-19 pandemic.

[0000833444-21-000011:mdna:73]
45

[0000833444-21-000011:mdna:74]
[same as prior period, unchanged from 0000833444-20-000036:mdna:89]

[0000833444-21-000011:mdna:75]
|  | Three Months Ended December 31, |  |  |  |  |  |  |
| (in millions) | 2020 |  | 2019 |  | Change |  |  |  |  |  |  |
| Building Solutions North America | $ | 255 |  |  | $ | 258 |  |  | -1 | % |  |  |  |  |  |  |
| Building Solutions EMEA/LA | 95 |  |  | 90 |  |  | 6 | % |  |  |  |  |  |  |
| Building Solutions Asia Pacific | 79 |  |  | 72 |  |  | 10 | % |  |  |  |  |  |  |
| Global Products | 213 |  |  | 203 |  |  | 5 | % |  |  |  |  |  |  |
|  | $ | 642 |  |  | $ | 623 |  |  | 3 | % |  |  |  |  |  |  |

[0000833444-21-000011:mdna:76]
•The decrease in Building Solutions North America was due to unfavorable volumes, net of productivity savings and cost mitigation actions ($4 million), partially offset by prior year integration costs ($1 million).

[0000833444-21-000011:mdna:77]
•The increase in Building Solutions EMEA/LA was due to productivity savings and cost mitigation actions, net of unfavorable volumes ($4 million) and higher income due to business acquisitions ($1 million).

[0000833444-21-000011:mdna:78]
•The increase in Building Solutions Asia Pacific was due to productivity savings and cost mitigation actions, net of unfavorable volumes ($4 million) and the favorable impact of foreign currency translation ($3 million).

[0000833444-21-000011:mdna:79]
•The increase in Global Products was due to higher equity income ($10 million) driven primarily by certain partially-owned affiliates of the Johnson Controls - Hitachi joint venture, the favorable impact of foreign currency translation ($6 million) and prior year integration costs ($1 million), partially offset by lower income due to business divestitures ($6 million) and unfavorable volumes / mix, net of productivity savings and cost mitigation actions ($1 million).

[0000833444-21-000011:mdna:80]
[same as prior period, unchanged from 0000833444-20-000036:mdna:101]

[0000833444-21-000011:mdna:81]
The Company’s backlog is applicable to its sales of systems and services. At December 31, 2020, the backlog was $9.8 billion, of which $9.5 billion was attributable to the field business. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned in the upcoming fiscal year.

[0000833444-21-000011:mdna:82]
At December 31, 2020, remaining performance obligations were $14.9 billion, which is $5.1 billion higher than the Company's backlog of $9.8 billion. Differences between the Company’s remaining performance obligations and backlog are primarily due to:

[0000833444-21-000011:mdna:83]
[same as prior period, unchanged from 0000833444-20-000036:mdna:104]

[0000833444-21-000011:mdna:84]
[same as prior period, unchanged from 0000833444-20-000036:mdna:105]

[0000833444-21-000011:mdna:85]
[same as prior period, unchanged from 0000833444-20-000036:mdna:106]

[0000833444-21-000011:mdna:86]
[same as prior period, unchanged from 0000833444-20-000036:mdna:107]

[0000833444-21-000011:mdna:87]
[same as prior period, unchanged from 0000833444-20-000036:mdna:108]

[0000833444-21-000011:mdna:88]
[same as prior period, unchanged from 0000833444-20-000036:mdna:109]

[0000833444-21-000011:mdna:89]
|  | December 31, |  | September 30, |  |  |
| (in millions) | 2020 |  | 2020 |  | Change |
| Current assets | $ | 10,034 |  |  | $ | 10,053 |  |  |  |
| Current liabilities | (8,486) |  |  | (8,248) |  |  |  |
|  | 1,548 |  |  | 1,805 |  |  | -14 | % |
| Less: Cash | (1,839) |  |  | (1,951) |  |  |  |
| Add: Short-term debt | 11 |  |  | 31 |  |  |  |
| Add: Current portion of long-term debt | 453 |  |  | 262 |  |  |  |
| Working capital (as defined) | $ | 173 |  |  | $ | 147 |  |  | 18 | % |
| Accounts receivable - net | $ | 5,177 |  |  | $ | 5,294 |  |  | -2 | % |
| Inventories | 1,913 |  |  | 1,773 |  |  | 8 | % |
| Accounts payable | 3,210 |  |  | 3,120 |  |  | 3 | % |

[0000833444-21-000011:mdna:90]
[same as prior period, unchanged from 0000833444-20-000036:mdna:111]

[0000833444-21-000011:mdna:91]
•The increase in working capital at December 31, 2020 as compared to September 30, 2020, was primarily due to the favorable resolution of certain post-closing working capital and net debt adjustments related to Power Solutions sale, an increase in inventory to meet anticipated customer demand, partially offset by a decrease in accounts receivable and increase in accounts payable.

[0000833444-21-000011:mdna:92]
•The Company’s days sales in accounts receivable at December 31, 2020 and September 30, 2020 were 68 days and 63 days, respectively. There has been no significant adverse changes in the level of overdue receivables or significant changes in revenue recognition methods.

[0000833444-21-000011:mdna:93]
•The Company’s inventory turns for the three months ended December 31, 2020 were lower than the comparable period ended September 30, 2020, primarily due to changes in inventory production levels.

[0000833444-21-000011:mdna:94]
•Days in accounts payable at December 31, 2020 were 77 days, higher than 69 days at the comparable period ended September 30, 2020, primarily due to timing.

[0000833444-21-000011:mdna:95]
[same as prior period, unchanged from 0000833444-20-000036:mdna:116]

[0000833444-21-000011:mdna:96]
|  |  | Three Months Ended December 31, |
| (in millions) |  | 2020 |  | 2019 |
| Cash provided by operating activities |  | $ | 515 |  |  | $ | 511 |  |
| Cash used by investing activities |  | (37) |  |  | (173) |  |
| Cash used by financing activities |  | (547) |  |  | (850) |  |

[0000833444-21-000011:mdna:97]
•The increase in cash provided by operating activities was primarily due to favorable changes in accounts payable and accrued liabilities, partially offset by prior year income tax refunds.

[0000833444-21-000011:mdna:98]
•The decrease in cash used by investing activities was primarily due to prior year payments for acquisitions, lower capital expenditures, higher proceeds from the sale of property, plant & equipment and current year cash proceeds from business divestitures.

[0000833444-21-000011:mdna:99]
•The decrease in cash used by financing activities was primarily due to lower stock repurchases.

[0000833444-21-000011:mdna:100]
[same as prior period, unchanged from 0000833444-20-000036:mdna:121]

[0000833444-21-000011:mdna:101]
|  | December 31, |  | September 30, |  |  |
| (in millions) | 2020 |  | 2020 |  | Change |
| Short-term debt | $ | 11 |  |  | $ | 31 |  |  |  |
| Current portion of long-term debt | 453 |  |  | 262 |  |  |  |
| Long-term debt | 7,469 |  |  | 7,526 |  |  |  |
| Total debt | 7,933 |  |  | 7,819 |  |  | 1 | % |
| Less: cash and cash equivalents | 1,839 |  |  | 1,951 |  |  |  |
| Total net debt | 6,094 |  |  | 5,868 |  |  | 4 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 17,656 |  |  | 17,447 |  |  | 1 | % |
| Total capitalization | $ | 23,750 |  |  | $ | 23,315 |  |  | 2 | % |
| Total net debt as a % of total capitalization | 25.7 | % |  | 25.2 | % |  |  |

[0000833444-21-000011:mdna:102]
[same as prior period, unchanged from 0000833444-20-000036:mdna:123]

[0000833444-21-000011:mdna:103]
•The Company believes its capital resources and liquidity position at December 31, 2020 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, minimum pension contributions, debt maturities and any potential acquisitions or stock repurchases in the remainder of fiscal 2021 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company is unable to issue commercial paper, it would have the ability to draw on its $2.5 billion revolving credit facility which expires in December 2024 or its $0.5 billion 364-day revolving credit facility which expires in December 2021. There were no draws on the revolving credit facilities as of December 31, 2020 and September 30, 2020. In addition, the Company held cash and cash equivalents of $1.8 billion as of December 31, 2020. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future.

[0000833444-21-000011:mdna:104]
•Financial covenants in the Company's revolving credit facilities requires a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of

[0000833444-21-000011:mdna:105]
debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. As of December 31, 2020, the Company was in compliance with all covenants and other requirements set forth in its credit agreements and the indentures governing its notes, and expects to remain in compliance for the foreseeable future. None of the Company’s debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the Company's credit rating.

[0000833444-21-000011:mdna:106]
•The key financial assumptions used in calculating the Company’s pension liability are determined annually, or whenever plan assets and liabilities are re-measured as required under accounting principles generally accepted in the U.S., including the expected rate of return on its plan assets. In fiscal 2021, the Company believes the long-term rate of return will approximate 6.50%, 4.90% and 5.30% for U.S. pension, non-U.S. pension and postretirement plans, respectively. During the first three months of fiscal 2021, the Company made approximately $17 million in total pension and postretirement contributions. In total, the Company expects to contribute approximately $46 million in cash to its defined benefit pension plans in fiscal 2021. The Company expects to contribute $3 million in cash to its postretirement plans in fiscal 2021.

[0000833444-21-000011:mdna:107]
•The Company earns a significant amount of its income outside of the parent company. Outside basis differences in these subsidiaries are deemed to be permanently reinvested except in limited circumstances. The Company currently does not intend nor foresee a need to repatriate undistributed earnings included in the outside basis differences other than in tax efficient manners. The Company's intent is to reduce basis differences only when it would be tax efficient. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at the Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in tax efficient methods, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings.

[0000833444-21-000011:mdna:108]
•To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2020 and recorded $297 million of restructuring and impairment costs in the consolidated statements of income. The restructuring actions related primarily to cost reduction initiatives. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2020 restructuring plans will reduce annual operating costs for continuing operations by approximately $430 million, which is primarily the result of lower cost of sales and SG&A due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in 2021. The restructuring action is expected to be substantially complete in fiscal 2021. The Company has outstanding restructuring reserves of $81 million at December 31, 2020, all of which is expected to be paid in cash.

[0000833444-21-000011:mdna:109]
•Refer to Note 13, "Debt and Financing Arrangements," of the notes to consolidated financial statements for additional information on items impacting capitalization.

[0000833444-21-000011:mdna:110]
49

[0000833444-21-000011:mdna:111]
Co-Issued Securities: Summarized Financial Information

[0000833444-21-000011:mdna:112]
The following information is provided in compliance with Rule 13-01 of Regulation S-X under the Securities Exchange Act of 1934 with respect to the (i) $625 million aggregate principal amount of 1.750% Senior Notes due 2030 (the “2030 Notes”), (ii) €500 million aggregate principal amount of 0.375% Senior Notes due 2027 (the “2027 Notes”) and (iii) €500 million aggregate principal amount of 1.000% Senior Notes due 2032 (the “2032 Notes” and together with the 2030 Notes and the 2027 Notes, the “Notes”), each issued by Johnson Controls International plc ("Parent Company") and Tyco Fire & Security Finance S.C.A. (“TFSCA”), a corporate partnership limited by shares (société en commandite par actions) incorporated and organized under the laws of the Grand Duchy of Luxembourg (“Luxembourg”).

[0000833444-21-000011:mdna:113]
TFSCA is a wholly-owned consolidated subsidiary of the Company that is 99.996% owned directly by the Parent Company and 0.004% owned by TFSCA’s sole general partner and manager, Tyco Fire & Security S.à r.l., which is itself wholly-owned by the Company. The Notes are the Parent Company’s and TFSCA’s unsecured, unsubordinated obligations. The Parent Company is incorporated and organized under the laws of Ireland and TFSCA is incorporated and organized under the laws of Luxembourg. The bankruptcy, insolvency, administrative, debtor relief and other laws of Luxembourg or Ireland, as applicable, may be materially different from, or in conflict with, those of the United States, including in the areas of rights of creditors, priority of governmental and other creditors, ability to obtain post-petition interest and duration of the proceeding. The application of these laws, or any conflict among them, could adversely affect noteholders’ ability to enforce their rights under the Notes in those jurisdictions or limit any amounts that they may receive.

[0000833444-21-000011:mdna:114]
The following tables set forth summarized financial information of the Parent Company and TFSCA (collectively, the “Obligor Group”) on a combined basis after intercompany transactions have been eliminated, including adjustments to remove the receivable and payable balances, investment in, and equity in earnings from, those subsidiaries of the Parent Company other than TFSCA (collectively, the "Non-Obligor Subsidiaries").

[0000833444-21-000011:mdna:115]
The following table presents summarized income statement information (in millions):

[0000833444-21-000011:mdna:116]
|  |  | Three Months Ended |  | Year Ended |  |
|  |  | December 31, 2020 |  | September 30, 2020 |  |
| Net sales |  | $ | — |  |  | $ | — |  |  |
| Gross profit |  | — |  |  | — |  |  |
| Loss from continuing operations |  | (63) |  |  | (450) |  |  |
| Net loss |  | (63) |  |  | (450) |  |  |
| Income attributable to noncontrolling interests |  | — |  |  | — |  |  |
| Net loss attributable to the entity |  | (63) |  |  | (450) |  |  |

[0000833444-21-000011:mdna:117]
Excluded from the table above are the intercompany transactions between the Obligor Group and Non-Obligor Subsidiaries as follows (in millions):

[0000833444-21-000011:mdna:118]
|  |  | Three Months Ended |  | Year Ended |  |
|  |  | December 31, 2020 |  | September 30, 2020 |  |
| Net sales |  | $ | — |  |  | $ | — |  |  |
| Gross profit |  | — |  |  | — |  |  |
| Income from continuing operations |  | 117 |  |  | 702 |  |  |
| Net income |  | 117 |  |  | 702 |  |  |
| Income attributable to noncontrolling interests |  | — |  |  | — |  |  |
| Net income attributable to the entity |  | 117 |  |  | 702 |  |  |

[0000833444-21-000011:mdna:119]
The following table presents summarized balance sheet information as of December 31, 2020 and September 30, 2020 (in millions):

[0000833444-21-000011:mdna:120]
|  |  | December 31, 2020 |  | September 30, 2020 |  |
| Current assets |  | $ | 834 |  |  | $ | 522 |  |  |
| Noncurrent assets |  | 324 |  |  | 318 |  |  |
| Current liabilities |  | 5,145 |  |  | 7,612 |  |  |
| Noncurrent liabilities |  | 7,217 |  |  | 7,258 |  |  |
| Noncontrolling interests |  | — |  |  | — |  |  |

[0000833444-21-000011:mdna:121]
Excluded from the table above are the intercompany balances between the Obligor Group and Non-Obligor Subsidiaries as follows (in millions):

[0000833444-21-000011:mdna:122]
|  |  | December 31, 2020 |  | September 30, 2020 |  |
| Current assets |  | $ | 840 |  |  | $ | 838 |  |  |
| Noncurrent assets |  | 7,343 |  |  | 7,338 |  |  |
| Current liabilities |  | 1,382 |  |  | 2,724 |  |  |
| Noncurrent liabilities |  | 3,483 |  |  | 3,406 |  |  |
| Noncontrolling interests |  | — |  |  | — |  |  |

[0000833444-21-000011:mdna:123]
The same accounting policies as described in Note 1, "Summary of Significant Accounting Policies," of the Company's Annual Report on 10-K for the year ended September 30, 2020 are used by the Parent Company and each of its subsidiaries in connection with the summarized financial information presented above.

[0000833444-21-000011:mdna:124]
[same as prior period, unchanged from 0000833444-20-000036:mdna:135]

[0000833444-21-000011:mdna:125]
[same as prior period, unchanged from 0000833444-20-000036:mdna:136]
