# JCI note change history — 0000833444-20-000036 → 0000833444-21-000011


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-01-29):
[0000833444-21-000011:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of December 31, 2020, reserves for environmental liabilities for continuing operations totaled $122 million, of which $61 million was recorded within other current liabilities and $61 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $130 million at September 30, 2020, of which $61 million was recorded within other current liabilities and $69 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.
  (was, 2020-07-31, similarity 0.9919):
[0000833444-20-000036:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of June 30, 2020, reserves for environmental liabilities for continuing operations totaled $136 million, of which $45 million was recorded within other current liabilities and $91 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $159 million at September 30, 2019, of which $52 million was recorded within other current liabilities and $107 million was recorded within other noncurrent liabilities in the consolidated statements of financial position.

- changed (2021-01-29):
[0000833444-21-000011:note_history:2]
During the third quarter of 2019, the Company increased its environmental reserves, which included $140 million related to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”). The Company is not able to estimate a possible loss or range of loss in excess of the established accruals at this time.
  (was, 2020-07-31, similarity 0.7443):
[0000833444-20-000036:note_history:2]
at or near the FTC, as well as the continued remediation of arsenic and other contaminants at the Tyco Fire Products Stanton Street manufacturing facility also located in Marinette, Wisconsin (the “Stanton Street Facility”).  The Company is not able to estimate a possible loss or range of loss in excess of the established accruals at this time.

- changed (2021-01-29):
[0000833444-21-000011:note_history:3]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS. The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion. On August 22,
  (was, 2020-07-31, similarity 0.6885):
[0000833444-20-000036:note_history:3]
On June 21, 2019, the WDNR announced that it had received from the Wisconsin Department of Health Services (“WDHS”) a recommendation for groundwater quality standards as to, among other compounds, PFOA and PFOS.  The WDHS recommended a groundwater enforcement standard for PFOA and PFOS of 20 parts per trillion.  On August 22, 2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation.

- added (2021-01-29):
[0000833444-21-000011:note_history:4]
2019, the Governor of Wisconsin issued an executive order that, among other things, directed the WDNR to create a PFAS Coordinating Council and to work with other Wisconsin agencies (including WDHS) to establish final groundwater quality standards based on the WDHS’s prior recommendation.

- added (2021-01-29):
[0000833444-21-000011:note_history:5]
In December 2020, the Company received a notice from the Wisconsin Department of Justice (“WDOJ”) that the WDOJ was considering a potential civil enforcement action against the Company relating to environmental matters at the FTC including, but not limited to, the investigation and remediation of PFAS at or near the FTC as discussed in the prior paragraphs and the Company’s alleged failure to timely report the presence of PFAS chemicals at the FTC. Such enforcement action could seek civil monetary penalties and/or injunctive relief. The Company is presently unable to predict the duration, scope, or results of any potential civil enforcement action that may result, the consequences of any such action, or the nature of any resolution of these potential claims with the WDOJ.

- changed (2021-01-29):
[0000833444-21-000011:note_history:6]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990. Its corporate predecessor, Ansul Incorporated (“Ansul”) manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River. In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. The increase in the reserve related to the Stanton Street Facility in the third quarter of 2019 was recorded following a further review of the Consent Order, which resulted in the identification of several structural upgrades needed to preserve the effectiveness of prior remediation efforts. In addition to ongoing remediation activities, the Company is also working with the WDNR to investigate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation of PFAS in the Marinette region.
  (was, 2020-07-31, similarity 0.9921):
[0000833444-20-000036:note_history:6]
Tyco Fire Products has been engaged in remediation activities at the Stanton Street Facility since 1990.  Its corporate predecessor, Ansul Incorporated (“Ansul”) manufactured arsenic-based agricultural herbicides at the Stanton Street Facility, which resulted in significant arsenic contamination of soil and groundwater on the site and in parts of the adjoining Menominee River.  In 2009, Ansul entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the site. Under this agreement, Tyco Fire Products’ principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. The increase in the reserve related to the Stanton Street Facility was recorded following a further review of the Consent Order, which resulted in the identification of several structural upgrades needed to preserve the effectiveness of prior remediation efforts. In addition to ongoing remediation activities, the Company is also working with the WDNR to investigate the presence of PFAS at or near the Stanton Street Facility as part of the evaluation of PFAS in the Marinette region.

- changed (2021-01-29):
[0000833444-21-000011:note_history:7]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or
  (was, 2020-07-31, similarity 0.6385):
[0000833444-20-000036:note_history:7]
Potential environmental liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at

- added (2021-01-29):
[0000833444-21-000011:note_history:8]
abandonment of existing owned facilities. At December 31, 2020 and September 30, 2020, the Company recorded conditional asset retirement obligations for continuing operations of $30 million and $29 million, respectively.

- changed (2021-01-29):
[0000833444-21-000011:note_history:9]
As of December 31, 2020, the Company's estimated asbestos-related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $93 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $474 million, of which $49 million was recorded in other current liabilities and $425 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $381 million, of which $17 million was recorded in other current assets, and $364 million was recorded in other noncurrent assets. Assets included $5 million of cash and $308 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at December 31, 2020 was $68 million. As of September 30, 2020, the Company's estimated asbestos-related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $115 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $483 million, of which $49 million was recorded in other current liabilities and $434 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $368 million, of which $39 million was recorded in other current assets, and $329 million was recorded in other noncurrent assets. Assets included $9 million of cash and $291 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2020 was $68 million.
  (was, 2020-07-31, similarity 0.9937):
[0000833444-20-000036:note_history:9]
As of June 30, 2020, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $134 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $497 million, of which $50 million was recorded in other current liabilities and $447 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $363 million, of which $43 million was recorded in other current assets, and $320 million was recorded in other noncurrent assets. Assets included $13 million of cash and $281 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at June 30, 2020 was $69 million. As of September 30, 2019, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $141 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $507 million, of which $50 million was recorded in other current liabilities and $457 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $366 million, of which $46 million was recorded in other current assets, and $320 million was recorded in other noncurrent assets. Assets included $16 million of cash and $273 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2019 was $77 million.

- changed (2021-01-29):
[0000833444-21-000011:note_history:10]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos-related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.
  (was, 2020-07-31, similarity 0.9994):
[0000833444-20-000036:note_history:10]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

- added (2021-01-29):
[0000833444-21-000011:note_history:11]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-

- added (2021-01-29):
[0000833444-21-000011:note_history:12]
related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

- changed (2021-01-29):
[0000833444-21-000011:note_history:13]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At December 31, 2020 and September 30, 2020, the insurable liabilities totaled $362 million and $363 million, respectively, of which $88 million and $83 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $252 million and $258 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at December 31, 2020 were $21 million, of which $5 million was recorded within other current assets and $16 million was recorded within other noncurrent assets, respectively. The amount of such receivables recorded at September 30, 2020 were $21 million, of which $5 million was recorded within other current assets and $16 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.
  (was, 2020-07-31, similarity 0.9913):
[0000833444-20-000036:note_history:13]
The Company records liabilities for its workers' compensation, product, general, and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At June 30, 2020 and September 30, 2019, the insurable liabilities totaled $365 million and $379 million, respectively, of which $83 million and $99 million was recorded within other current liabilities, $22 million and $22 million was recorded within accrued compensation and benefits, and $260 million and $258 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at June 30, 2020 were $23 million, of which $5 million was recorded within other current assets and $18 million was recorded within other noncurrent assets, respectively. The amount of such receivables recorded at September 30, 2019 were $23 million, of which $5 million was recorded within other current assets and $18 million was recorded within other noncurrent assets, respectively. The Company maintains captive insurance companies to manage its insurable liabilities.

- changed (2021-01-29):
[0000833444-21-000011:note_history:14]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, suppliers and distributors, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but has stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.
  (was, 2020-07-31, similarity 0.9853):
[0000833444-20-000036:note_history:14]
Two of the Company's subsidiaries, Chemguard and Tyco Fire Products, have been named, along with other defendant manufacturers, and, in some cases, certain subsidiaries of the Company affiliated with Chemguard and Tyco Fire Products, in a number of class action and other lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals PFOS and PFOA and/or other PFAS compounds and that the use of these products by others at various airbases, airports and other sites resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports, airbases and other sites. PFOA, PFOS, and other PFAS compounds are being studied by the United States Environmental Protection Agency ("EPA") and other environmental and health agencies and researchers. The EPA has not issued binding regulatory limits, but has stated that it would propose regulatory standards for PFOS and PFOA in drinking water by the end of 2019, in accordance with its PFAS Action Plan released in February 2019, and issued interim recommendations for addressing PFOA and PFOS in groundwater in December 2019. While those studies continue, the EPA has issued a health advisory level for PFOA and PFOS in drinking water. Both PFOA and PFOS are types of synthetic chemical compounds that have been present in firefighting foam. However, both are also present in many existing consumer products. According to EPA, PFOA and PFOS have been used to make carpets, clothing, fabrics for furniture, paper packaging for food and other materials (e.g., cookware) that are resistant to water, grease or stains.

- changed (2021-01-29):
[0000833444-21-000011:note_history:15]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation (“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to or are being directly filed in the MDL.
  (was, 2020-07-31, similarity 0.8):
[0000833444-20-000036:note_history:15]
In September 2018, Tyco Fire Products and Chemguard filed a Petition for Multidistrict Litigation with the United States Judicial Panel on Multidistrict Litigation (“JPML”) seeking to consolidate all existing and future federal cases into one jurisdiction. On December 7, 2018, the JPML issued an order transferring various AFFF cases to a multi-district litigation

- added (2021-01-29):
[0000833444-21-000011:note_history:16]
Chemguard and Tyco Fire Products are named in 31 putative class actions in federal courts originating from Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington, New Hampshire, South Carolina, the District of Columbia, Guam, West Virginia, Michigan and South Dakota. All of these cases have been direct-filed in or transferred to the MDL. Since the beginning of fiscal year 2021, one putative class action (Jackson v. 3M Company, et al., direct filed on January 15, 2021 in the MDL pending in the United States District Court, District of South Carolina) has been filed against the Company.

- added (2021-01-29):
[0000833444-21-000011:note_history:17]
There are approximately 876 individual or “mass” actions pending that were filed in state or federal court in California (5 cases), Colorado (41 cases), New York (4 cases), Pennsylvania (15 cases), New Mexico (2 cases), Missouri (1 case), Arizona (1 case) and South Carolina (807 cases direct filed from various U.S. jurisdictions) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve five plaintiffs in California, approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, 15 plaintiffs in Pennsylvania, two plaintiffs in New Mexico, one plaintiff in Missouri, two plaintiffs in Arizona, and more than 800 plaintiffs from various states who direct-filed complaints in South Carolina. All but six of these matters have been transferred to or directly-filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL.  Many of the additional filed actions were directly filed in South Carolina by plaintiffs who were among the 660 plaintiffs the Company had previously disclosed to have made filings in Pennsylvania state court.  The Company anticipates that the remainder of the possible individual product liability claims filed in Pennsylvania state court will either soon be filed in the MDL (and that all such claims in state court will be dismissed accordingly) or will be dismissed in Pennsylvania without a corresponding filing in South Carolina.

- added (2021-01-29):
[0000833444-21-000011:note_history:18]
Chemguard and Tyco Fire Products are also defendants in 63 cases in federal and state courts involving municipal or water provider plaintiffs in Alaska, Arizona, California, Colorado, Florida, Massachusetts, New Jersey, New York, Maryland, Ohio, Pennsylvania, Washington, the District of Columbia and several municipalities or water providers from various states who direct-filed complaints in South Carolina. All but three of these cases have been transferred to or directly filed in the MDL, and it is anticipated that the remaining cases will be transferred to the MDL. These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property. Since the beginning of fiscal year 2021, the following municipal actions have been filed against the Company:

- added (2021-01-29):
[0000833444-21-000011:note_history:19]
•Hicksville Water District v. 3M Company, et al., filed on October 16, 2020 in New York State Court; now pending in the Eastern District of New York (tagged for transfer to the MDL pending in the United States District Court, District of South Carolina).

- added (2021-01-29):
[0000833444-21-000011:note_history:20]
•Pennsylvania-American Water Co. v. 3M Company, et al., complaint filed on October 21, 2020 in the Court of Common Pleas of Cumberland County, Pennsylvania.

- changed (2021-01-29):
[0000833444-21-000011:note_history:21]
•Santa Clarita Valley Water Agency v. 3M Company, et al., direct-filed on October 27, 2020 in the MDL pending in the United States District Court, District of South Carolina.
  (was, 2020-07-31, similarity 0.7117):
[0000833444-20-000036:note_history:21]
•Aguon et al. v. The 3M Company et al., filed October 3, 2019, in the United States District Court, District of Guam.

- changed (2021-01-29):
[0000833444-21-000011:note_history:22]
•Barnstable Fire District v. 3M Company, et al., direct-filed on December 3, 2020 in the MDL pending in the United States District Court, District of South Carolina.
  (was, 2020-07-31, similarity 0.7039):
[0000833444-20-000036:note_history:22]
•County of Rockland [New York] et al. v. 3M Company et al., filed February 4, 2020, in the United States District Court, District of South Carolina.

- changed (2021-01-29):
[0000833444-21-000011:note_history:23]
•Miami-Dade County, Florida v. 3M Company, et al., direct-filed on December 3, 2020 in the MDL pending in the United States District Court, District of South Carolina.
  (was, 2020-07-31, similarity 0.6713):
[0000833444-20-000036:note_history:23]
•City of Millington et al. v. 3M Company et al., filed February 25, 2020, in the United States District Court, District of Columbia.

- changed (2021-01-29):
[0000833444-21-000011:note_history:24]
•Town of Cairo v. 3M Company, et al., direct-filed on December 7, 2020 in the MDL pending in the United States District Court, District of South Carolina.
  (was, 2020-07-31, similarity 0.6855):
[0000833444-20-000036:note_history:24]
•Stengel et al. v. 3M Company et al., filed April 29, 2020, in the United States District Court for the Northern District of West Virginia.

- changed (2021-01-29):
[0000833444-21-000011:note_history:25]
•Paducah Water of the City of Paducah, Kentucky v. 3M Company, et al., direct-filed on December 16, 2020 in the MDL pending in the United States District Court, District of South Carolina.
  (was, 2020-07-31, similarity 0.6291):
[0000833444-20-000036:note_history:25]
•Garcia et al. v. 3M Company et al., filed May 15, 2020 in the United States District Court for the District of South Carolina [originating from South Dakota].

- added (2021-01-29):
[0000833444-21-000011:note_history:26]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly resulting from the use of those products at the Peterson Air Force Base. In May 2020, the Company was also notified by the Lakewood Water District in Pierce County, Washington that it may assert claims regarding remediation in connection with PFOA, PFOS, and other PFAS contamination allegedly resulting from the use of those products at Joint Base Lewis-McChord.

- changed (2021-01-29):
[0000833444-21-000011:note_history:27]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Company, with respect
  (was, 2020-07-31, similarity 0.6922):
[0000833444-20-000036:note_history:27]
In November 2019, the government of the Commonwealth of the Northern Mariana Islands filed a lawsuit in the superior court of the Northern Mariana Islands against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.

- added (2021-01-29):
[0000833444-21-000011:note_history:28]
to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within its jurisdiction.  This complaint has been removed to federal court and transferred to the MDL.

- added (2021-01-29):
[0000833444-21-000011:note_history:29]
In August 2020, Attorney General of the State of Michigan filed two substantially similar lawsuits—one in federal court and one in state court—against a number of manufacturers, including affiliates of the Company, with respect to PFOS and PFOA contamination allegedly resulting from the use of firefighting foams at various locations within the State.  The federal action has been transferred to the MDL, and the state court action has been removed to federal court and tagged for transfer to the MDL.

- added (2021-01-29):
[0000833444-21-000011:note_history:30]
In December 2020, the State of Mississippi filed a lawsuit against a number of manufacturers and other defendants, including affiliates of the Group, with respect to PFOS and PFOA damage of the State’s land and natural resources allegedly resulting from the use of firefighting foams at various locations throughout the State.  This complaint was direct-filed in the MDL in South Carolina.

- changed (2021-01-29):
[0000833444-21-000011:note_history:31]
Tyco Fire Products and Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFAS (including PFOA/PFOS) contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. On January 7, 2021, the parties agreed to settle the lawsuit. The settlement provides that Tyco will pay up to $17.5 million to compensate Town of Peshtigo residents who live in the area affected by PFAS from the FTC for claims related to loss of real property value, exposure and/or personal injury. The settlement does not constitute an admission of wrongdoing by Tyco or Chemguard and is subject to approval by the federal court presiding over the lawsuit and other contingencies. The Company does not expect the settlement to have a significant impact on its fiscal year 2021 results of operations or cash flows.
  (was, 2020-07-31, similarity 0.6354):
[0000833444-20-000036:note_history:31]
Tyco Fire Products and Chemguard are defendants in one lawsuit in Marinette County, Wisconsin alleging damages due to the historical use of AFFF products at Tyco’s Fire Technology Center in Marinette, Wisconsin. The putative class action, Joan & Richard Campbell for themselves and on behalf of other similarly situated v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) alleges PFAS (including PFOA/PFOS) contaminated groundwater migrated off Tyco’s property and into residential drinking water wells causing both personal injuries and property damage to the plaintiffs; Tyco and Chemguard removed this case to the United States District Court for the Eastern District of Wisconsin and it has been transferred to the MDL. A second lawsuit, Duane and Janell Goldsmith individually and on behalf of H.G. and K.G v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) was also filed by a family alleging personal injuries due to contaminated groundwater; this case has been dismissed without prejudice.

- added (2021-01-29):
[0000833444-21-000011:note_history:32]
A second lawsuit, Duane and Janell Goldsmith individually and on behalf of H.G. and K.G v. Tyco Fire Products LP and Chemguard Inc., et al. (Marinette County Circuit Court, filed Dec. 17, 2018) was also filed by a family alleging personal injuries due to contaminated groundwater; this case has been dismissed without prejudice.

- added (2021-01-29):
[0000833444-21-000011:note_history:33]
The Company is vigorously defending the above matters and believes that it has meritorious defenses to class certification and the claims asserted, including statutes of limitations, the government contractor defense, various medical and scientific defenses, and other factual and legal defenses. The government contractor defense is a form of immunity available to government contractors that produced products for the United States government pursuant to the government’s specifications. Tyco and Chemguard have insurance that has been in place for many years and the Company is pursuing this coverage for these matters. However, there are numerous factual and legal issues to be resolved in connection with

- added (2021-01-29):
[0000833444-21-000011:note_history:34]
these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, and there can be no assurance that any such exposure will not be material.

- removed (2021-01-29):
[0000833444-20-000036:note_history:35]
During the third quarter of 2019, the Company increased its environmental reserves, which included $140 million related to remediation efforts to be undertaken to address contamination relating to fire-fighting foams containing PFAS compounds

- removed (2021-01-29):
[0000833444-20-000036:note_history:36]
the sites, and the often quite lengthy periods over which eventual remediation may occur. It is possible that technological, regulatory or enforcement developments, the results of additional environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows. Nevertheless, the Company does not currently believe that any claims, penalties or costs in addition to the amounts accrued will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At June 30, 2020 and September 30, 2019, the Company recorded conditional asset retirement obligations for continuing operations of $29 million and $30 million, respectively.

- removed (2021-01-29):
[0000833444-20-000036:note_history:37]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and

- removed (2021-01-29):
[0000833444-20-000036:note_history:38]
assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

- removed (2021-01-29):
[0000833444-20-000036:note_history:39]
(“MDL”) before the United States District Court for the District of South Carolina. Additional cases have been identified for transfer to or are being directly filed in the MDL.

- removed (2021-01-29):
[0000833444-20-000036:note_history:40]
Chemguard and Tyco Fire Products are named in 30 putative class actions in federal courts originating from Colorado, Delaware, Florida, Massachusetts, New York, Pennsylvania, Washington New Hampshire, South Carolina, the District of Columbia, Guam, West Virginia, Michigan and South Dakota. All but one of these cases has been transferred to the MDL, and it is anticipated that the Abbot case will be removed to federal court and transferred following service of the complaint. The following putative class actions were filed since the beginning of fiscal year 2020:

- removed (2021-01-29):
[0000833444-20-000036:note_history:41]
•Abbott et al. v. The 3M Company et al., filed May 6, 2020 in the Superior Court for the State of Washington in and for Spokane County.

- removed (2021-01-29):
[0000833444-20-000036:note_history:42]
•Gentile et al. v. The 3M Company et al., filed May 27, 2020, in the United States District Court for the Eastern District of New York.

- removed (2021-01-29):
[0000833444-20-000036:note_history:43]
There are approximately 632 individual or “mass” actions pending that were filed in state or federal court in California (2 cases), Colorado (41 cases), New York (4 cases), Pennsylvania (15 cases), New Mexico (2 cases) and South Carolina (568 cases direct filed from various U.S. jurisdictions) against Chemguard and Tyco Fire Products and other defendants in which the plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values. The cases involve two plaintiffs in California, approximately 7,000 plaintiffs in Colorado, approximately 126 plaintiffs in New York, 15 plaintiffs in Pennsylvania, two plaintiffs in New Mexico, and more than 500 plaintiffs from various states who direct-filed complaints in South Carolina. All but two of these matters have been transferred to or directly-filed in the MDL, and it is anticipated that the California cases will be transferred following service of the complaints.  Many of the additional filed actions were directly filed in South Carolina by plaintiffs who were among the 660 plaintiffs the Company had previously disclosed to have made filings in Pennsylvania state court.  The Company anticipates that the remainder of the possible individual product liability claims filed in Pennsylvania state court will either soon be filed in the MDL (and that all such claims in state court will be dismissed accordingly) or will be dismissed in Pennsylvania without a corresponding filing in South Carolina.

- removed (2021-01-29):
[0000833444-20-000036:note_history:44]
Chemguard and Tyco Fire Products are also defendants in 51 cases in federal courts involving municipal or water provider plaintiffs in Alaska, Arizona, California, Colorado, Florida, Massachusetts, New Jersey, New York, Maryland, Ohio, Pennsylvania, Washington, the District of Columbia and several municipalities or water providers from various states who direct-filed complaints in South Carolina.  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at fire training academies, municipal airports, Air National Guard bases, or Navy or Air Force bases released PFOS and PFOA into public water supply wells, allegedly requiring remediation of public property. Since the beginning of fiscal year 2020, 21 municipal actions have been filed against the Company.

- removed (2021-01-29):
[0000833444-20-000036:note_history:45]
In May 2018, the Company was also notified by the Widefield Water and Sanitation District in Colorado Springs, Colorado that it may assert claims regarding its remediation costs in connection with PFOS and PFOA contamination allegedly

- removed (2021-01-29):
[0000833444-20-000036:note_history:46]
resulting from the use of those products at the Peterson Air Force Base. In May 2020, the Company was also notified by the Lakewood Water District in Pierce County, Washington that it may assert claims regarding remediation in connection with PFOA, PFOS, and other PFAS contamination allegedly resulting from the use of those products at Joint Base Lewis-McChord.

- removed (2021-01-29):
[0000833444-20-000036:note_history:47]
The Company is vigorously defending the above matters and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.

- removed (2021-01-29):
[0000833444-20-000036:note_history:48]
Bosch Litigation

- removed (2021-01-29):
[0000833444-20-000036:note_history:49]
On March 15, 2019, a German subsidiary of the Company received a complaint from Robert Bosch GmbH (“Bosch”), filed in a German court. The complaint relates to an automotive starter batteries joint venture in which the Company and Bosch were 80/20 parties to this joint venture. At the time the complaint was filed, JCI’s ownership interest in the joint venture was to be transferred to entities controlled by the Purchaser upon consummation of the previously announced sale of the Company’s Power Solutions business.

- removed (2021-01-29):
[0000833444-20-000036:note_history:50]
The complaint alleged that certain internal Company reorganization transactions were not in compliance with the arrangements relating to such joint venture. The complaint sought a declaration that such internal reorganization transactions are void or, in the alternative, a declaration of damages that represent an alleged difference between (i) the value ascribed to the joint venture interests in connection with the Power Solutions sale and (ii) the value that was assigned to those interests in connection with such internal reorganization transactions.

- removed (2021-01-29):
[0000833444-20-000036:note_history:51]
On August 8, 2019, Bosch entered into an agreement with Purchaser pursuant to which Purchaser would purchase Bosch’s interest in the joint venture.  Simultaneously with this agreement, the Company and Bosch executed an agreement to dismiss the proceedings between the parties upon the completion of Purchaser’s acquisition of Bosch’s interest. In the first quarter of fiscal 2020, following the completion of Purchaser’s acquisition of Bosch’s interest in the joint venture, the Company and Bosch made filings with the German court terminating the litigation.

- removed (2021-01-29):
[0000833444-20-000036:note_history:52]
Pursuant to the Company’s obligations to Purchaser in connection with the divestiture of the Company’s Power Solutions business, the Company reimbursed Purchaser a portion of its costs in connection with its acquisition of Bosch’s interests in the joint venture, which is reflected as a cash outflow for discontinued operations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-01-29):
[0000833444-21-000011:note_history:53]
Financial Statements
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2020 filed with the SEC on November 16, 2020. The results of operations for the three month period ended December 31, 2020 are not necessarily indicative of results for the Company’s 2021 fiscal year because of seasonal and other factors.
  (was, 2020-07-31, similarity 0.9782):
[0000833444-20-000036:note_history:53]
Financial Statements
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2019 filed with the SEC on November 21, 2019. The results of operations for the three and nine month periods ended June 30, 2020 are not necessarily indicative of results for the Company’s 2020 fiscal year because of seasonal and other factors.

- added (2021-01-29):
[0000833444-21-000011:note_history:54]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global diversified technology and multi-industrial leader serving a wide range of customers in more than 150 countries. The Company’s products and solutions enable smart, energy efficient, sustainable buildings that work seamlessly together to advance the safety, comfort and intelligence of spaces to power its customers’ mission. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

- added (2021-01-29):
[0000833444-21-000011:note_history:55]
The Company is a global leader in engineering, manufacturing and commissioning building products and systems, including residential and commercial heating, ventilating, air-conditioning ("HVAC") equipment, industrial refrigeration systems, controls, security systems, fire detection systems and fire suppression solutions. The Company further serves customers by providing technical services, including maintenance, repair, retrofit and replacement of equipment (in the HVAC, security and fire-protection space), energy-management consulting and data-driven “smart building” services and solutions powered by its digital platforms and capabilities.

- changed (2021-01-29):
[0000833444-21-000011:note_history:56]
At December 31, 2020 and September 30, 2020, the Company held restricted cash of approximately $5 million and $9 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities.
  (was, 2020-07-31, similarity 0.9808):
[0000833444-20-000036:note_history:56]
At June 30, 2020 and September 30, 2019, the Company held restricted cash of approximately $13 million and $16 million, respectively, all of which was recorded within other current assets in the consolidated statements of financial position. These amounts were related to cash restricted for payment of asbestos liabilities.

- removed (2021-01-29):
[0000833444-20-000036:note_history:57]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global diversified technology and multi industrial leader serving a wide range of customers in more than 150 countries. The Company creates intelligent buildings, efficient energy solutions and integrated infrastructure that work seamlessly together to deliver on the promise of smart cities and communities. The Company is committed to helping its customers win and creating greater value for all of its stakeholders through its strategic focus on buildings.

- removed (2021-01-29):
[0000833444-20-000036:note_history:58]
The Company is a global market leader in engineering, developing, manufacturing and installing building products and systems around the world, including heating, ventilating, air-conditioning ("HVAC") equipment, HVAC controls, energy-management systems, security systems, fire detection systems and fire suppression solutions. The Company further serves customers by providing technical services (in the HVAC, security and fire-protection space), energy-management consulting and data-driven solutions via its data-enabled business. Finally, the Company has a strong presence in the North American residential air conditioning and heating systems market and is a global market leader in industrial refrigeration products.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-01-29):
[0000833444-21-000011:note_history:59]
The Company's net financing charges line item in the consolidated statements of income for the three months ended December 31, 2020 and 2019 contained the following components (in millions):
  (was, 2020-07-31, similarity 0.9485):
[0000833444-20-000036:note_history:59]
The Company's net financing charges line item in the consolidated statements of income for the three and nine months ended June 30, 2020 and 2019 contained the following components (in millions):

- changed (2021-01-29):
[0000833444-21-000011:note_history:60]
|  | Three Months Ended December 31, |  |  |
|  | 2020 |  | 2019 |  |  |  |  |
| Interest expense, net of capitalized interest costs | $ | 59 |  |  | $ | 62 |  |  |  |  |  |
| Banking fees and bond cost amortization | 8 |  |  | 5 |  |  |  |  |  |
| Interest income | (3) |  |  | (13) |  |  |  |  |  |
| Net foreign exchange results for financing activities | (5) |  |  | (2) |  |  |  |  |  |
| Net financing charges | $ | 59 |  |  | $ | 52 |  |  |  |  |  |
  (was, 2020-07-31, similarity 0.652):
[0000833444-20-000036:note_history:60]
|  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Interest expense, net of capitalized interest costs | $ | 58 |  |  | $ | 81 |  |  | $ | 182 |  |  | $ | 269 |  |
| Banking fees and bond cost amortization | 8 |  |  | 7 |  |  | 18 |  |  | 20 |  |
| Loss on debt extinguishment | — |  |  | 60 |  |  | — |  |  | 60 |  |
| Interest income | (3) |  |  | (28) |  |  | (21) |  |  | (41) |  |
| Net foreign exchange results for financing activities | (5) |  |  | (1) |  |  | (10) |  |  | (6) |  |
| Net financing charges | $ | 58 |  |  | $ | 119 |  |  | $ | 169 |  |  | $ | 302 |  |

- changed (2021-01-29):
[0000833444-21-000011:note_history:61]
As of December 31, 2020, the Company had a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which was renewed in December 2020 and is now scheduled to expire in December 2021. As of December 31, 2020, there were no draws on the facilities.
  (was, 2020-07-31, similarity 0.8847):
[0000833444-20-000036:note_history:61]
In December 2019, the Company entered into a syndicated $2.5 billion committed revolving credit facility, which is scheduled to expire in December 2024, and a syndicated $500 million committed revolving credit facility, which is scheduled to expire in December 2020.  As of June 30, 2020, there were no draws on the facilities.

- removed (2021-01-29):
[0000833444-20-000036:note_history:62]
In April 2020, the Company entered into various European financing arrangements totaling $675 million which are due in September 2020 and $575 million of bank term loans which are due in April 2021. In July 2020, a $300 million bank term loan was repaid, reducing bank term loans outstanding to $275 million.

- removed (2021-01-29):
[0000833444-20-000036:note_history:63]
In March 2020, the Company retired $500 million in principal amount, plus accrued interest, of its 5.0% fixed rate notes that expired in March 2020.

- removed (2021-01-29):
[0000833444-20-000036:note_history:64]
In December 2019, the Company terminated its syndicated 5-year $2 billion committed revolving credit facility and four 364-day revolving credit facilities with total committed capacity of $750 million.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2021-01-29):
[0000833444-21-000011:note_history:65]
The following table presents net sales to and purchases from related parties for the three months ended December 31, 2020 and 2019 (in millions):

- changed (2021-01-29):
[0000833444-21-000011:note_history:66]
|  |  | Three Months Ended December 31, |
|  |  | 2020 |  | 2019 |
| Net sales to related parties |  | $ | 44 |  |  | $ | 42 |  |
| Purchases from related parties |  | 29 |  |  | 12 |  |
  (was, 2020-07-31, similarity 0.7483):
[0000833444-20-000036:note_history:66]
|  |  | June 30, 2020 |  | September 30, 2019 |
| Receivable from related parties |  | $ | 50 |  |  | $ | 34 |  |
| Payable to related parties |  | 7 |  |  | 6 |  |

- changed (2021-01-29):
[0000833444-21-000011:note_history:67]
The following table presents receivables from and payables to related parties in the consolidated statements of financial position (in millions):
  (was, 2020-07-31, similarity 0.8163):
[0000833444-20-000036:note_history:67]
The following table sets forth the amount of accounts receivable due from and payable to related parties in the consolidated statements of financial position for continuing operations (in millions):

- added (2021-01-29):
[0000833444-21-000011:note_history:68]
|  |  | December 31, 2020 |  | September 30, 2020 |
| Receivable from related parties |  | $ | 51 |  |  | $ | 48 |  |
| Payable to related parties |  | 14 |  |  | 11 |  |

- removed (2021-01-29):
[0000833444-20-000036:note_history:69]
The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $52 million and $25 million, respectively, for the three months ended June 30, 2020; and $65 million and $27 million, respectively, for the three months ended June 30, 2019. The net sales to and purchases from related parties included in the consolidated statements of income for continuing operations were $135 million and $47 million, respectively, for the nine months ended June 30, 2020; and $162 million and $57 million, respectively, for the nine months ended June 30, 2019.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2021-01-29):
[0000833444-21-000011:note_history:70]
The following table presents net sales to and purchases from related parties for the three months ended December 31, 2020 and 2019 (in millions):

- changed (2021-01-29):
[0000833444-21-000011:note_history:71]
|  |  | Three Months Ended December 31, |
|  |  | 2020 |  | 2019 |
| Net sales to related parties |  | $ | 44 |  |  | $ | 42 |  |
| Purchases from related parties |  | 29 |  |  | 12 |  |
  (was, 2020-07-31, similarity 0.7483):
[0000833444-20-000036:note_history:71]
|  |  | June 30, 2020 |  | September 30, 2019 |
| Receivable from related parties |  | $ | 50 |  |  | $ | 34 |  |
| Payable to related parties |  | 7 |  |  | 6 |  |

- changed (2021-01-29):
[0000833444-21-000011:note_history:72]
The following table presents receivables from and payables to related parties in the consolidated statements of financial position (in millions):
  (was, 2020-07-31, similarity 0.8163):
[0000833444-20-000036:note_history:72]
The following table sets forth the amount of accounts receivable due from and payable to related parties in the consolidated statements of financial position for continuing operations (in millions):

- added (2021-01-29):
[0000833444-21-000011:note_history:73]
|  |  | December 31, 2020 |  | September 30, 2020 |
| Receivable from related parties |  | $ | 51 |  |  | $ | 48 |  |
| Payable to related parties |  | 14 |  |  | 11 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-01-29):
[0000833444-21-000011:note_history:74]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three months ended December 31, 2020 and 2019 (in millions):
  (was, 2020-07-31, similarity 0.9504):
[0000833444-20-000036:note_history:74]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three and nine months ended June 30, 2020 and 2019 (in millions):

- added (2021-01-29):
[0000833444-21-000011:note_history:75]
|  |  | Three Months Ended December 31, 2020 |  | Three Months Ended December 31, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,242 |  |  | $ | 792 |  |  | $ | 2,034 |  |  | $ | 1,356 |  |  | $ | 811 |  |  | $ | 2,167 |  |
| Building Solutions EMEA/LA |  | 426 |  |  | 480 |  |  | 906 |  |  | 457 |  |  | 471 |  |  | 928 |  |
| Building Solutions Asia Pacific |  | 345 |  |  | 270 |  |  | 615 |  |  | 371 |  |  | 258 |  |  | 629 |  |
| Global Products |  | 1,786 |  |  | — |  |  | 1,786 |  |  | 1,852 |  |  | — |  |  | 1,852 |  |
| Total |  | $ | 3,799 |  |  | $ | 1,542 |  |  | $ | 5,341 |  |  | $ | 4,036 |  |  | $ | 1,540 |  |  | $ | 5,576 |  |

- changed (2021-01-29):
[0000833444-21-000011:note_history:76]
The following table presents further disaggregation of Global Products segment revenues by product type for the three months ended December 31, 2020 and 2019 (in millions):
  (was, 2020-07-31, similarity 0.9429):
[0000833444-20-000036:note_history:76]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and nine months ended June 30, 2020 and 2019 (in millions):

- added (2021-01-29):
[0000833444-21-000011:note_history:77]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2020 |  | 2019 |  |  |  |  |
| HVAC |  | $ | 1,249 |  |  | $ | 1,300 |  |  |  |  |  |
| Fire & Security |  | 488 |  |  | 492 |  |  |  |  |  |
| Industrial Refrigeration |  | 49 |  |  | 60 |  |  |  |  |  |
| Total |  | $ | 1,786 |  |  | $ | 1,852 |  |  |  |  |  |

- removed (2021-01-29):
[0000833444-20-000036:note_history:78]
|  |  | Three Months Ended June 30, 2020 |  |  |  |  |  | Three Months Ended June 30, 2019 |  |  |  |  |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,250 |  |  | $ | 770 |  |  | $ | 2,020 |  |  | $ | 1,494 |  |  | $ | 833 |  |  | $ | 2,327 |  |
| Building Solutions EMEA/LA |  | 346 |  |  | 410 |  |  | 756 |  |  | 464 |  |  | 458 |  |  | 922 |  |
| Building Solutions Asia Pacific |  | 344 |  |  | 244 |  |  | 588 |  |  | 427 |  |  | 264 |  |  | 691 |  |
| Global Products |  | 1,979 |  |  | — |  |  | 1,979 |  |  | 2,511 |  |  | — |  |  | 2,511 |  |
| Total |  | $ | 3,919 |  |  | $ | 1,424 |  |  | $ | 5,343 |  |  | $ | 4,896 |  |  | $ | 1,555 |  |  | $ | 6,451 |  |

- removed (2021-01-29):
[0000833444-20-000036:note_history:79]
|  |  | Nine Months Ended June 30, 2020 |  |  |  |  |  | Nine Months Ended June 30, 2019 |  |  |  |  |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,963 |  |  | $ | 2,399 |  |  | $ | 6,362 |  |  | $ | 4,202 |  |  | $ | 2,428 |  |  | $ | 6,630 |  |
| Building Solutions EMEA/LA |  | 1,203 |  |  | 1,331 |  |  | 2,534 |  |  | 1,297 |  |  | 1,410 |  |  | 2,707 |  |
| Building Solutions Asia Pacific |  | 986 |  |  | 756 |  |  | 1,742 |  |  | 1,134 |  |  | 798 |  |  | 1,932 |  |
| Global Products |  | 5,725 |  |  | — |  |  | 5,725 |  |  | 6,425 |  |  | — |  |  | 6,425 |  |
| Total |  | $ | 11,877 |  |  | $ | 4,486 |  |  | $ | 16,363 |  |  | $ | 13,058 |  |  | $ | 4,636 |  |  | $ | 17,694 |  |

- removed (2021-01-29):
[0000833444-20-000036:note_history:80]
|  |  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Building management systems |  | $ | 244 |  |  | $ | 342 |  |  | $ | 860 |  |  | $ | 943 |  |
| HVAC & refrigeration equipment |  | 1,493 |  |  | 1,869 |  |  | 4,085 |  |  | 4,628 |  |
| Specialty products |  | 242 |  |  | 300 |  |  | 780 |  |  | 854 |  |
| Total |  | $ | 1,979 |  |  | $ | 2,511 |  |  | $ | 5,725 |  |  | $ | 6,425 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-01-29):
[0000833444-21-000011:note_history:81]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three months ended December 31, 2020 and 2019 (in millions):
  (was, 2020-07-31, similarity 0.9504):
[0000833444-20-000036:note_history:81]
The following tables present the Company's revenues disaggregated by segment and by products and systems versus services revenue for the three and nine months ended June 30, 2020 and 2019 (in millions):

- added (2021-01-29):
[0000833444-21-000011:note_history:82]
|  |  | Three Months Ended December 31, 2020 |  | Three Months Ended December 31, 2019 |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,242 |  |  | $ | 792 |  |  | $ | 2,034 |  |  | $ | 1,356 |  |  | $ | 811 |  |  | $ | 2,167 |  |
| Building Solutions EMEA/LA |  | 426 |  |  | 480 |  |  | 906 |  |  | 457 |  |  | 471 |  |  | 928 |  |
| Building Solutions Asia Pacific |  | 345 |  |  | 270 |  |  | 615 |  |  | 371 |  |  | 258 |  |  | 629 |  |
| Global Products |  | 1,786 |  |  | — |  |  | 1,786 |  |  | 1,852 |  |  | — |  |  | 1,852 |  |
| Total |  | $ | 3,799 |  |  | $ | 1,542 |  |  | $ | 5,341 |  |  | $ | 4,036 |  |  | $ | 1,540 |  |  | $ | 5,576 |  |

- changed (2021-01-29):
[0000833444-21-000011:note_history:83]
The following table presents further disaggregation of Global Products segment revenues by product type for the three months ended December 31, 2020 and 2019 (in millions):
  (was, 2020-07-31, similarity 0.9429):
[0000833444-20-000036:note_history:83]
The following table presents further disaggregation of Global Products segment revenues by product type for the three and nine months ended June 30, 2020 and 2019 (in millions):

- added (2021-01-29):
[0000833444-21-000011:note_history:84]
|  |  | Three Months Ended December 31, |  |  |
|  |  | 2020 |  | 2019 |  |  |  |  |
| HVAC |  | $ | 1,249 |  |  | $ | 1,300 |  |  |  |  |  |
| Fire & Security |  | 488 |  |  | 492 |  |  |  |  |  |
| Industrial Refrigeration |  | 49 |  |  | 60 |  |  |  |  |  |
| Total |  | $ | 1,786 |  |  | $ | 1,852 |  |  |  |  |  |

- added (2021-01-29):
[0000833444-21-000011:note_history:85]
|  |  | Location of contract balances |  | December 31, 2020 |  | September 30, 2020 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,404 |  |  | $ | 1,395 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 104 |  |  | 104 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,583) |  |  | (1,435) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (257) |  |  | (245) |  |  |  |
| Total |  |  |  | $ | (332) |  |  | $ | (181) |  |  |  |

- changed (2021-01-29):
[0000833444-21-000011:note_history:86]
For the three months ended December 31, 2020 and December 31, 2019, the Company recognized revenue of $714 million and $686 million, respectively, that was included in the beginning of period contract liability balance.
  (was, 2020-07-31, similarity 0.6007):
[0000833444-20-000036:note_history:86]
For the three months ended June 30, 2020 and June 30, 2019, the Company recognized revenue of $125 million and $130 million, respectively, that was included in the beginning of period contract liability balance. For the nine months ended June 30, 2020 and June 30, 2019, the Company recognized revenue of $1,137 million and $1,056 million, respectively, that was included in the beginning of period contract liability balance.

- changed (2021-01-29):
[0000833444-21-000011:note_history:87]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of December 31, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $14.9 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.
  (was, 2020-07-31, similarity 0.9939):
[0000833444-20-000036:note_history:87]
Performance obligations are satisfied as of a point in time or over time. The timing of satisfying the performance obligation is typically indicated by the terms of the contract. As of June 30, 2020, the aggregate amount of the transaction price allocated to remaining performance obligations was approximately $14.4 billion, of which approximately 60% is expected to be recognized as revenue over the next two years.  The remaining performance obligations expected to be recognized in revenue beyond two years primarily relate to large, multi-purpose contracts to construct hospitals, schools and other governmental buildings, which include services to be performed over the building's lifetime, with initial contract terms of 25 to 35 years. Future contract modifications could affect both the timing and the amount of the remaining performance obligations. The Company excludes the value of remaining performance obligations for contracts with an original expected duration of one year or less.

- added (2021-01-29):
[0000833444-21-000011:note_history:88]
As of December 31, 2020, the Company recorded the costs to obtain or fulfill a contract of $236 million, of which $135 million is recorded within other current assets and $101 million is recorded within other noncurrent assets in the consolidated statements of financial position. As of September 30, 2020, the Company recorded the costs to obtain or fulfill a contract of $223 million, of which $119 million is recorded within other current assets and $104 million is recorded within other noncurrent assets in the consolidated statements of financial position.
During the three months ended December 31, 2020 and 2019, the Company recognized amortization expense of $41 million and $26 million, respectively, related to costs to obtain or fulfill a contract. There were no impairment losses recognized in the three months ended December 31, 2020 and 2019.

- removed (2021-01-29):
[0000833444-20-000036:note_history:89]
|  |  | Three Months Ended June 30, 2020 |  |  |  |  |  | Three Months Ended June 30, 2019 |  |  |  |  |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 1,250 |  |  | $ | 770 |  |  | $ | 2,020 |  |  | $ | 1,494 |  |  | $ | 833 |  |  | $ | 2,327 |  |
| Building Solutions EMEA/LA |  | 346 |  |  | 410 |  |  | 756 |  |  | 464 |  |  | 458 |  |  | 922 |  |
| Building Solutions Asia Pacific |  | 344 |  |  | 244 |  |  | 588 |  |  | 427 |  |  | 264 |  |  | 691 |  |
| Global Products |  | 1,979 |  |  | — |  |  | 1,979 |  |  | 2,511 |  |  | — |  |  | 2,511 |  |
| Total |  | $ | 3,919 |  |  | $ | 1,424 |  |  | $ | 5,343 |  |  | $ | 4,896 |  |  | $ | 1,555 |  |  | $ | 6,451 |  |

- removed (2021-01-29):
[0000833444-20-000036:note_history:90]
|  |  | Nine Months Ended June 30, 2020 |  |  |  |  |  | Nine Months Ended June 30, 2019 |  |  |  |  |
|  |  | Products & Systems |  | Services |  | Total |  | Products & Systems |  | Services |  | Total |
| Building Solutions North America |  | $ | 3,963 |  |  | $ | 2,399 |  |  | $ | 6,362 |  |  | $ | 4,202 |  |  | $ | 2,428 |  |  | $ | 6,630 |  |
| Building Solutions EMEA/LA |  | 1,203 |  |  | 1,331 |  |  | 2,534 |  |  | 1,297 |  |  | 1,410 |  |  | 2,707 |  |
| Building Solutions Asia Pacific |  | 986 |  |  | 756 |  |  | 1,742 |  |  | 1,134 |  |  | 798 |  |  | 1,932 |  |
| Global Products |  | 5,725 |  |  | — |  |  | 5,725 |  |  | 6,425 |  |  | — |  |  | 6,425 |  |
| Total |  | $ | 11,877 |  |  | $ | 4,486 |  |  | $ | 16,363 |  |  | $ | 13,058 |  |  | $ | 4,636 |  |  | $ | 17,694 |  |

- removed (2021-01-29):
[0000833444-20-000036:note_history:91]
|  |  | Three Months Ended June 30, |  |  |  | Nine Months Ended June 30, |  |  |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Building management systems |  | $ | 244 |  |  | $ | 342 |  |  | $ | 860 |  |  | $ | 943 |  |
| HVAC & refrigeration equipment |  | 1,493 |  |  | 1,869 |  |  | 4,085 |  |  | 4,628 |  |
| Specialty products |  | 242 |  |  | 300 |  |  | 780 |  |  | 854 |  |
| Total |  | $ | 1,979 |  |  | $ | 2,511 |  |  | $ | 5,725 |  |  | $ | 6,425 |  |

- removed (2021-01-29):
[0000833444-20-000036:note_history:92]
|  |  | Location of contract balances |  | June 30, 2020 |  | September 30, 2019 |  |  |
| Contract assets - current |  | Accounts receivable - net |  | $ | 1,409 |  |  | $ | 1,389 |  |  |  |
| Contract assets - noncurrent |  | Other noncurrent assets |  | 98 |  |  | 90 |  |  |  |
| Contract liabilities - current |  | Deferred revenue |  | (1,451) |  |  | (1,407) |  |  |  |
| Contract liabilities - noncurrent |  | Other noncurrent liabilities |  | (120) |  |  | (117) |  |  |  |
| Total |  |  |  | $ | (64) |  |  | $ | (45) |  |  |  |

- removed (2021-01-29):
[0000833444-20-000036:note_history:93]
As of June 30, 2020, the Company recorded the costs to obtain or fulfill a contract of $224 million, of which $121 million is recorded within other current assets and $103 million is recorded within other noncurrent assets in the consolidated statements of financial position. As of September 30, 2019, the Company recorded the costs to obtain or fulfill a contract of $212 million, of which $110 million is recorded within other current assets and $102 million is recorded within other noncurrent assets in the consolidated statements of financial position.

- removed (2021-01-29):
[0000833444-20-000036:note_history:94]
During the three months ended June 30, 2020 and 2019, the Company recognized amortization expense of $47 million and $50 million, respectively, related to costs to obtain or fulfill a contract. During the nine months ended June 30, 2020 and 2019, the Company recognized amortization expense of $116 million and $119 million, respectively, related to costs to 
obtain or fulfill a contract.  There were no impairment losses recognized in the three and nine months ended June 30, 2020 and 2019.
