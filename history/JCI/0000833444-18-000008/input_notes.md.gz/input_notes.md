# JCI notes — 0000833444-18-000008


## jci:ComponentsOfNetFinancingChargesTableTextBlock

[0000833444-18-000008:notes:1]
The Company's net financing charges line item in the consolidated statements of income for the three months ended December 31, 2017 and 2016 contained the following components (in millions):

[0000833444-18-000008:notes:2]
|  | Three Months EndedDecember 31, |
|  | 2017 |  | 2016 |
| Interest expense, net of capitalized interest costs | $ | 114 |  |  | $ | 110 |  |
| Banking fees and bond cost amortization | 13 |  |  | 30 |  |
| Interest income | (9 | ) |  | (7 | ) |
| Net foreign exchange results for financing activities | (2 | ) |  | 3 |  |
| Net financing charges | $ | 116 |  |  | $ | 136 |  |


## jci:DisposalGroupIncludingDiscontinuedOperationsIncomeStatementDisclosuresTableTextBlock

[0000833444-18-000008:notes:3]
The following table summarizes the results of Adient, reclassified as discontinued operations for the three month period ended December 31, 2016 (in millions). As the Adient spin-off occurred on October 31, 2016, there is only one month of Adient results included in the three month period ended December 31, 2016.

[0000833444-18-000008:notes:4]
|  | Three Months Ended December 31, |
|  | 2016 |
| Net sales | $ | 1,434 |  |
| Income from discontinued operations before income taxes | 1 |  |
| Provision for income taxes on discontinued operations | 35 |  |
| Income from discontinued operations attributable to noncontrolling interests, net of tax | 9 |  |
| Loss from discontinued operations | $ | (43 | ) |


## jci:EquityAttributableToParentAndNoncontrollingInterestsTableTextBlock

[0000833444-18-000008:notes:5]
[same as prior period, unchanged from 0000833444-17-000044:notes:6]

[0000833444-18-000008:notes:6]
|  | Three Months Ended December 31, 2017 |  | Three Months Ended December 31, 2016 |
|  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |  | EquityAttributable toJohnson Controls International plc |  | EquityAttributable toNoncontrollingInterests |  | TotalEquity |
| Beginning balance, September 30, | $ | 20,447 |  |  | $ | 920 |  |  | $ | 21,367 |  |  | $ | 24,118 |  |  | $ | 972 |  |  | $ | 25,090 |  |
| Total comprehensive income (loss): |  |  |  |  |  |  |  |  |  |  |  |
| Net income | 230 |  |  | 28 |  |  | 258 |  |  | 329 |  |  | 36 |  |  | 365 |  |
| Foreign currency translation adjustments | 58 |  |  | 16 |  |  | 74 |  |  | (659 | ) |  | (35 | ) |  | (694 | ) |
| Realized and unrealized gains on derivatives | 1 |  |  | 1 |  |  | 2 |  |  | — |  |  | 4 |  |  | 4 |  |
| Realized and unrealized losses on marketable securities | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Other comprehensive income (loss) | 59 |  |  | 17 |  |  | 76 |  |  | (661 | ) |  | (31 | ) |  | (692 | ) |
| Comprehensive income (loss) | 289 |  |  | 45 |  |  | 334 |  |  | (332 | ) |  | 5 |  |  | (327 | ) |
| Other changes in equity: |  |  |  |  |  |  |  |  |  |  |  |
| Cash dividends—ordinary shares | (242 | ) |  | — |  |  | (242 | ) |  | (236 | ) |  | — |  |  | (236 | ) |
| Repurchases of ordinary shares | (150 | ) |  | — |  |  | (150 | ) |  | — |  |  | — |  |  | — |  |
| Change in noncontrolling interest share | — |  |  | — |  |  | — |  |  | — |  |  | (20 | ) |  | (20 | ) |
| Adoption of ASU 2016-09 | 179 |  |  | — |  |  | 179 |  |  | — |  |  | — |  |  | — |  |
| Spin-off of Adient | — |  |  | — |  |  | — |  |  | (4,020 | ) |  | (138 | ) |  | (4,158 | ) |
| Other, including options exercised | 12 |  |  | — |  |  | 12 |  |  | 47 |  |  | — |  |  | 47 |  |
| Ending balance, December 31 | $ | 20,535 |  |  | $ | 965 |  |  | $ | 21,500 |  |  | $ | 19,577 |  |  | $ | 819 |  |  | $ | 20,396 |  |


## jci:OffsettingDerivativeAssetsandLiabilitiesTableTextBlock

[0000833444-18-000008:notes:7]
[same as prior period, unchanged from 0000833444-17-000044:notes:9]

[0000833444-18-000008:notes:8]
|  | Fair Value of Assets |  | Fair Value of Liabilities |
|  | December 31, |  | September 30, |  | December 31, |  | September 30, |
|  | 2017 |  | 2017 |  | 2017 |  | 2017 |
| Gross amount recognized | $ | 130 |  |  | $ | 91 |  |  | $ | 3,023 |  |  | $ | 2,105 |  |
| Gross amount eligible for offsetting | (27 | ) |  | (16 | ) |  | (27 | ) |  | (16 | ) |
| Net amount | $ | 103 |  |  | $ | 75 |  |  | $ | 2,996 |  |  | $ | 2,089 |  |


## jci:ScheduleOfIntangibleAssetsTableTextBlock

[0000833444-18-000008:notes:9]
[same as prior period, unchanged from 0000833444-17-000044:notes:11]

[0000833444-18-000008:notes:10]
|  | December 31, 2017 |  | September 30, 2017 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |  | GrossCarryingAmount |  | AccumulatedAmortization |  | Net |
| Amortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Technology | $ | 1,343 |  |  | $ | (174 | ) |  | $ | 1,169 |  |  | $ | 1,328 |  |  | $ | (137 | ) |  | $ | 1,191 |  |
| Customer relationships | 3,136 |  |  | (503 | ) |  | 2,633 |  |  | 3,168 |  |  | (486 | ) |  | 2,682 |  |
| Miscellaneous | 413 |  |  | (167 | ) |  | 246 |  |  | 389 |  |  | (147 | ) |  | 242 |  |
| Total amortized intangible assets | 4,892 |  |  | (844 | ) |  | 4,048 |  |  | 4,885 |  |  | (770 | ) |  | 4,115 |  |
| Unamortized intangible assets |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks/trade names | 2,486 |  |  | — |  |  | 2,486 |  |  | 2,483 |  |  | — |  |  | 2,483 |  |
| Miscellaneous | 123 |  |  | — |  |  | 123 |  |  | 143 |  |  | — |  |  | 143 |  |
|  | 2,609 |  |  | — |  |  | 2,609 |  |  | 2,626 |  |  | — |  |  | 2,626 |  |
| Total intangible assets | $ | 7,501 |  |  | $ | (844 | ) |  | $ | 6,657 |  |  | $ | 7,511 |  |  | $ | (770 | ) |  | $ | 6,741 |  |


## jci:ScheduleofsharebasedpaymentawardperformancesharevaluationassumptionsTableTextBlock

[0000833444-18-000008:notes:11]
|  | Three Months Ended December 31, |
|  | 2017 |  | 2016 |
| Risk-free interest rate | 1.92% |  | 1.40% |
| Expected volatility of the Company’s stock | 21.7% |  | 21.0% |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-18-000008:notes:12]
Commitments and Contingencies

[0000833444-18-000008:notes:13]
Environmental Matters

[0000833444-18-000008:notes:14]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of December 31, 2017, reserves for environmental liabilities totaled $48 million, of which $10 million was recorded within other current liabilities and $38 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $51 million at September 30, 2017. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities, primarily in the Power Solutions and Building Technologies & Solutions businesses. At December 31, 2017 and September 30, 2017, the Company recorded conditional asset retirement obligations of $62 million and $61 million, respectively.

[0000833444-18-000008:notes:15]
Asbestos Matters

[0000833444-18-000008:notes:16]
The Company and certain of its subsidiaries, along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. These cases have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-18-000008:notes:17]
As of December 31, 2017, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $166 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $559 million, of which $54 million was recorded in other current liabilities and $505 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $393 million, of which $55 million was recorded in other current assets, and $338 million was recorded in other noncurrent assets. Assets included $10 million of cash and $283 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at December 31, 2017 was $100 million. As of September 30, 2017, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $181 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $573 million, of which $48 million was recorded in other current liabilities and $525 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $392 million, of which $53 million was recorded in other current assets, and $339 million was recorded in other noncurrent assets. Assets included $22 million of cash and $269 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2017 was $101 million.

[0000833444-18-000008:notes:18]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

[0000833444-18-000008:notes:19]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-18-000008:notes:20]
Insurable Liabilities

[0000833444-18-000008:notes:21]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At December 31, 2017 and September 30, 2017, the insurable liabilities totaled $434 million and $445 million, respectively, of which $92 million and $122 million was recorded within other current liabilities, $23 million and $22 million was recorded within accrued compensation and benefits, and $319 million and $301 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at December 31, 2017 was $21 million, of which $6 million was recorded within other current assets and $15 million was recorded within other noncurrent assets.  The amount of such receivables recorded at September 30, 2017 was $46 million, of which $31 million was recorded within other current assets and $15 million was recorded within other noncurrent assets. The Company maintains captive insurance companies to manage certain of its insurable liabilities.

[0000833444-18-000008:notes:22]
Arbitration Award

[0000833444-18-000008:notes:23]
In September 2017, the Company was subject to an unfavorable arbitration award of approximately $50 million relating to a contractual dispute with a subcontractor used by the Company at an airport construction project in Doha, Qatar. In connection with the unfavorable arbitration award, the Company recorded a charge of $50 million within selling, general and administrative expenses in the consolidated statements of income in the fourth quarter of fiscal 2017. The airport project is being managed by a steering committee. The Company and the subcontractor were working jointly to document claims for increased costs against the steering committee when the subcontractor initiated the arbitration proceeding against the Company. Pursuant to its arbitration proceeding against the Company, the subcontractor sought to recover costs it alleges it incurred due to project delays, additional work and related financing costs. The Company has filed annulment proceedings with respect to the arbitration award in the local court in Qatar. While the award remains outstanding, a portion of the balance will accrue interest at a statutory rate of 9.56%.

[0000833444-18-000008:notes:24]
In a related action, the Company has initiated an arbitration claim against the steering committee related to costs it incurred in connection with delays of the airport construction project, including costs related to the above award. The arbitrator is expected to issue a decision on the Company’s claims against the steering committee by the end of fiscal 2018.

[0000833444-18-000008:notes:25]
Aqueous Film-Forming Foam Litigation

[0000833444-18-000008:notes:26]
Two of our subsidiaries, Chemguard, Inc. ("Chemguard") and Tyco Fire Products L.P. ("Tyco Fire Products"), have been named, along with other defendant manufacturers, in a number of class action lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and that the use of these products by others at various airbases and airports resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports and airbases. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination. As of February 2, 2018, the Company is named in 12 putative class actions in federal courts in three states as set forth below:

[0000833444-18-000008:notes:27]
Colorado

[0000833444-18-000008:notes:28]
•District of Colorado - Bell et al. v. The 3M Company et al., filed on September 18, 2016.

[0000833444-18-000008:notes:29]
•District of Colorado - Davis et al. v. The 3M Company et al., filed on September 22, 2016.

[0000833444-18-000008:notes:30]
The above cases have been consolidated in the U.S. District Court for the District of Colorado, and a hearing on the plaintiffs’ motion for class certification is scheduled for April 2018 with a trial date schedule for April 2019.

[0000833444-18-000008:notes:31]
New York

[0000833444-18-000008:notes:32]
| • | Eastern District of New York - Green et al. v. The 3M Company et al., filed March 27, 2017 in Supreme Court of the State of New York, Suffolk County, prior to removal to federal court. |

[0000833444-18-000008:notes:33]
| • | Southern District of New York - Adamo et al. v. The Port Authority of NY and NJ et al., filed August 11, 2017 in Supreme Court of the State of New York, Orange County, prior to removal to federal court. |

[0000833444-18-000008:notes:34]
| • | Southern District of New York - Fogarty et al. v. The Port Authority of NY and NJ et al., filed August 11, 2017 in Supreme Court of the State of New York, Orange County, prior to removal to federal court. |

[0000833444-18-000008:notes:35]
| • | Southern District of New York - Miller et al. v. The Port Authority of NY and NJ et al., filed August 11, 2017 in Supreme Court of the State of New York, Orange County, prior to removal to federal court. |

[0000833444-18-000008:notes:36]
| • | Supreme Court of the State of New York, Suffolk County - Singer et al. v. The 3M Company et al., filed October 10, 2017. |

[0000833444-18-000008:notes:37]
Chemguard and Tyco Fire Products are also defendants in Ayo, et al. v. The 3M Company, et al., filed on December 11, 2017 in the Suffolk County Supreme Court of New York. Approximately 32 plaintiffs allege that releases of PFOS and PFOA have contaminated surrounding communities’ water supplies near the Gabreski Air National Guard Base located on Long Island, New York.  The plaintiffs assert defective design, failure to warn, negligence, private nuisance, and trespass and seek recovery for alleged diminished property values, personal injury, medical monitoring and punitive damages.

[0000833444-18-000008:notes:38]
Responses to the complaints have not been filed yet in any of the New York actions.

[0000833444-18-000008:notes:39]
Pennsylvania

[0000833444-18-000008:notes:40]
| • | Eastern District of Pennsylvania - Bates et al. v. The 3M Company et al., filed September 15, 2016. |

[0000833444-18-000008:notes:41]
| • | Eastern District of Pennsylvania - Grande et al. v. The 3M Company et al., filed October 13, 2016. |

[0000833444-18-000008:notes:42]
| • | Eastern District of Pennsylvania - Yockey et al. v. The 3M Company et al., filed October 24, 2016. |

[0000833444-18-000008:notes:43]
| • | Eastern District of Pennsylvania - Fearnley et al. v. The 3M Company et al., filed December 9, 2016. |

[0000833444-18-000008:notes:44]
The above cases have been consolidated in the U.S. District Court for the Eastern District of Pennsylvania. The defendants' motion to dismiss the complaint in the consolidated proceeding was denied without prejudice and the cases are currently stayed pending the appeal of an action in which the Company is not a party.

[0000833444-18-000008:notes:45]
In addition to the putative class actions, Chemguard and Tyco Fire Products are also defendants in an action filed by two plaintiffs in the U.S. District Court for the Eastern District of Pennsylvania:  Menkes et al. v. The 3M Company et al., (filed February 7, 2017). The Menkes plaintiffs assert substantive claims and allegations similar to the putative class allegations, but also include personal injury claim. The Company is also on notice of approximately 540 other possible individual product liability claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters, and, under Pennsylvania’s procedural rules, they may or may not result in lawsuits.

[0000833444-18-000008:notes:46]
Chemguard and Tyco Fire Products are also defendants in two cases pending in the U.S. District Court for the District of Massachusetts: Town of Barnstable v. the 3M. Co., et al, (filed Nov. 21, 2016), and County of Barnstable v. the 3M. Co., et al, (filed January 9, 2017).  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at a fire training academy and municipal airport released PFOS and PFOA into the town’s water supply wells, allegedly requiring remediation of the town and county property. The defendants have filed a motion to dismiss in County of Barnstable, which was granted without prejudice and the plaintiffs have subsequently filed an amended complaint.

[0000833444-18-000008:notes:47]
The Company is vigorously defending these cases and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.

[0000833444-18-000008:notes:48]
The Company is involved in various lawsuits, claims and proceedings incident to the operation of its businesses, including those pertaining to product liability, environmental, safety and health, intellectual property, employment, commercial and contractual matters, and various other casualty matters. Although the outcome of litigation cannot be predicted with certainty and some lawsuits, claims or proceedings may be disposed of unfavorably to us, it is management’s opinion that none of these will have a material adverse effect on the Company’s financial position, results of operations or cash flows. Costs related to such matters were not material to the periods presented.


## us-gaap:CondensedFinancialStatementsTextBlock

[0000833444-18-000008:notes:49]
[same as prior period, unchanged from 0000833444-17-000044:notes:26]

[0000833444-18-000008:notes:50]
Tyco International Finance S.A. ("TIFSA"), a 100% owned subsidiary of the Company, has public debt securities outstanding which, as of September 30, 2016, were fully and unconditionally guaranteed by Johnson Controls and by Tyco Fire & Security Finance S.C.A. ("TIFSCA"), a wholly owned subsidiary of the Company and parent company of TIFSA. During the first quarter of fiscal 2017, the guarantees were removed. The following tables present condensed consolidating financial information for Johnson Controls, TIFSCA, TIFSA and all other subsidiaries. Condensed financial information for the Company, TIFSCA and TIFSA on a stand-alone basis is presented using the equity method of accounting for subsidiaries.

[0000833444-18-000008:notes:51]
CONDENSED CONSOLIDATING STATEMENT OF OPERATIONS

[0000833444-18-000008:notes:52]
For the Three Months Ended December 31, 2017

[0000833444-18-000008:notes:53]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net sales | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 7,435 |  |  | $ | — |  |  | $ | 7,435 |  |
| Cost of sales | — |  |  | — |  |  | — |  |  | 5,266 |  |  | — |  |  | 5,266 |  |
| Gross profit | — |  |  | — |  |  | — |  |  | 2,169 |  |  | — |  |  | 2,169 |  |
| Selling, general and administrative expenses | (3 | ) |  | — |  |  | — |  |  | (1,414 | ) |  | — |  |  | (1,417 | ) |
| Restructuring and impairment costs | — |  |  | — |  |  | — |  |  | (158 | ) |  | — |  |  | (158 | ) |
| Net financing charges | (50 | ) |  | 1 |  |  | (2 | ) |  | (65 | ) |  | — |  |  | (116 | ) |
| Equity income | 285 |  |  | 188 |  |  | 142 |  |  | 60 |  |  | (615 | ) |  | 60 |  |
| Intercompany interest and fees | (2 | ) |  | 85 |  |  | (29 | ) |  | (54 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 230 |  |  | 274 |  |  | 111 |  |  | 538 |  |  | (615 | ) |  | 538 |  |
| Income tax provision | — |  |  | — |  |  | — |  |  | 267 |  |  | — |  |  | 267 |  |
| Net income | 230 |  |  | 274 |  |  | 111 |  |  | 271 |  |  | (615 | ) |  | 271 |  |
| Income from continuing operations attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 41 |  |  | — |  |  | 41 |  |
| Net income attributable to Johnson Controls | $ | 230 |  |  | $ | 274 |  |  | $ | 111 |  |  | $ | 230 |  |  | $ | (615 | ) |  | $ | 230 |  |

[0000833444-18-000008:notes:54]
[same as prior period, unchanged from 0000833444-17-000044:notes:32]

[0000833444-18-000008:notes:55]
| (in millions) | Johnson ControlsInternationalplc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net income | $ | 230 |  |  | $ | 274 |  |  | $ | 111 |  |  | $ | 271 |  |  | $ | (615 | ) |  | $ | 271 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments | 58 |  |  | (7 | ) |  | (1 | ) |  | 53 |  |  | (24 | ) |  | 79 |  |
| Realized and unrealized gains (losses) on derivatives | 1 |  |  | — |  |  | — |  |  | (1 | ) |  | (1 | ) |  | (1 | ) |
| Realized and unrealized gains (losses) on marketable securities | — |  |  | — |  |  | (4 | ) |  | 4 |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | 59 |  |  | (7 | ) |  | (5 | ) |  | 56 |  |  | (25 | ) |  | 78 |  |
| Total comprehensive income | 289 |  |  | 267 |  |  | 106 |  |  | 327 |  |  | (640 | ) |  | 349 |  |
| Comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 60 |  |  | — |  |  | 60 |  |
| Comprehensive income attributable to Johnson Controls | $ | 289 |  |  | $ | 267 |  |  | $ | 106 |  |  | $ | 267 |  |  | $ | (640 | ) |  | $ | 289 |  |

[0000833444-18-000008:notes:56]
For the Three Months Ended December 31, 2016

[0000833444-18-000008:notes:57]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net sales | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 7,086 |  |  | $ | — |  |  | $ | 7,086 |  |
| Cost of sales | — |  |  | — |  |  | — |  |  | 4,972 |  |  | — |  |  | 4,972 |  |
| Gross profit | — |  |  | — |  |  | — |  |  | 2,114 |  |  | — |  |  | 2,114 |  |
| Selling, general and administrative expenses | (2 | ) |  | — |  |  | 1 |  |  | (1,569 | ) |  | — |  |  | (1,570 | ) |
| Restructuring and impairment costs | — |  |  | — |  |  | — |  |  | (78 | ) |  | — |  |  | (78 | ) |
| Net financing charges | (19 | ) |  | — |  |  | (19 | ) |  | (98 | ) |  | — |  |  | (136 | ) |
| Equity income (loss) | 318 |  |  | (286 | ) |  | (110 | ) |  | 55 |  |  | 78 |  |  | 55 |  |
| Intercompany interest and fees | 32 |  |  | — |  |  | 17 |  |  | (49 | ) |  | — |  |  | — |  |
| Income (loss) from continuing operations before income taxes | 329 |  |  | (286 | ) |  | (111 | ) |  | 375 |  |  | 78 |  |  | 385 |  |
| Income tax benefit | — |  |  | — |  |  | — |  |  | (27 | ) |  | — |  |  | (27 | ) |
| Income (loss) from continuing operations | 329 |  |  | (286 | ) |  | (111 | ) |  | 402 |  |  | 78 |  |  | 412 |  |
| Income (loss) from sale of intercompany investment, net of tax | — |  |  | — |  |  | (935 | ) |  | — |  |  | 935 |  |  | — |  |
| Loss from discontinued operations, net of tax | — |  |  | — |  |  | — |  |  | (34 | ) |  | — |  |  | (34 | ) |
| Net income (loss) | 329 |  |  | (286 | ) |  | (1,046 | ) |  | 368 |  |  | 1,013 |  |  | 378 |  |
| Income from continuing operations attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 40 |  |  | — |  |  | 40 |  |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Net income (loss) attributable to Johnson Controls | $ | 329 |  |  | $ | (286 | ) |  | $ | (1,046 | ) |  | $ | 319 |  |  | $ | 1,013 |  |  | $ | 329 |  |

[0000833444-18-000008:notes:58]
| (in millions) | Johnson ControlsInternationalplc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Net income (loss) | $ | 329 |  |  | $ | (286 | ) |  | $ | (1,046 | ) |  | $ | 368 |  |  | $ | 1,013 |  |  | $ | 378 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation adjustments | (659 | ) |  | — |  |  | 27 |  |  | (730 | ) |  | 659 |  |  | (703 | ) |
| Realized and unrealized gains on derivatives | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Realized and unrealized gains (losses) on marketable securities | (2 | ) |  | — |  |  | — |  |  | (2 | ) |  | 2 |  |  | (2 | ) |
| Other comprehensive income (loss) | (661 | ) |  | — |  |  | 27 |  |  | (728 | ) |  | 661 |  |  | (701 | ) |
| Total comprehensive income (loss) | (332 | ) |  | (286 | ) |  | (1,019 | ) |  | (360 | ) |  | 1,674 |  |  | (323 | ) |
| Comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Comprehensive income (loss) attributable to Johnson Controls | $ | (332 | ) |  | $ | (286 | ) |  | $ | (1,019 | ) |  | $ | (369 | ) |  | $ | 1,674 |  |  | $ | (332 | ) |

[0000833444-18-000008:notes:59]
[same as prior period, unchanged from 0000833444-17-000044:notes:37]

[0000833444-18-000008:notes:60]
As of December 31, 2017

[0000833444-18-000008:notes:61]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 285 |  |  | $ | 108 |  |  | $ | 81 |  |  | $ | 991 |  |  | $ | (913 | ) |  | $ | 552 |  |
| Accounts receivable - net | — |  |  | — |  |  | — |  |  | 6,731 |  |  | — |  |  | 6,731 |  |
| Inventories | — |  |  | — |  |  | — |  |  | 3,459 |  |  | — |  |  | 3,459 |  |
| Intercompany receivables | 323 |  |  | 1,824 |  |  | 397 |  |  | 22,957 |  |  | (25,501 | ) |  | — |  |
| Assets held for sale | — |  |  | — |  |  | — |  |  | 40 |  |  | — |  |  | 40 |  |
| Other current assets | 46 |  |  | — |  |  | 1 |  |  | 1,600 |  |  | — |  |  | 1,647 |  |
| Current assets | 654 |  |  | 1,932 |  |  | 479 |  |  | 35,778 |  |  | (26,414 | ) |  | 12,429 |  |
| Property, plant and equipment - net | — |  |  | — |  |  | — |  |  | 6,105 |  |  | — |  |  | 6,105 |  |
| Goodwill | 243 |  |  | — |  |  | 32 |  |  | 19,442 |  |  | — |  |  | 19,717 |  |
| Other intangible assets - net | — |  |  | — |  |  | — |  |  | 6,657 |  |  | — |  |  | 6,657 |  |
| Investments in partially-owned affiliates | — |  |  | — |  |  | — |  |  | 1,219 |  |  | — |  |  | 1,219 |  |
| Investments in affiliates | 38,975 |  |  | 32,053 |  |  | 21,422 |  |  | — |  |  | (92,450 | ) |  | — |  |
| Intercompany loans receivable | — |  |  | 4,140 |  |  | 2,836 |  |  | 9,004 |  |  | (15,980 | ) |  | — |  |
| Other noncurrent assets | 68 |  |  | — |  |  | 2 |  |  | 3,570 |  |  | — |  |  | 3,640 |  |
| Total assets | $ | 39,940 |  |  | $ | 38,125 |  |  | $ | 24,771 |  |  | $ | 81,775 |  |  | $ | (134,844 | ) |  | $ | 49,767 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | 1,820 |  |  | $ | — |  |  | $ | — |  |  | $ | 607 |  |  | $ | (913 | ) |  | $ | 1,514 |  |
| Current portion of long-term debt | 49 |  |  | — |  |  | 18 |  |  | 24 |  |  | — |  |  | 91 |  |
| Accounts payable | 1 |  |  | — |  |  | — |  |  | 4,019 |  |  | — |  |  | 4,020 |  |
| Accrued compensation and benefits | 1 |  |  | — |  |  | — |  |  | 882 |  |  | — |  |  | 883 |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 1,368 |  |  | — |  |  | 1,368 |  |
| Intercompany payables | 3,753 |  |  | 18,978 |  |  | 1,958 |  |  | 812 |  |  | (25,501 | ) |  | — |  |
| Other current liabilities | 376 |  |  | 1 |  |  | 24 |  |  | 2,969 |  |  | — |  |  | 3,370 |  |
| Current liabilities | 6,000 |  |  | 18,979 |  |  | 2,000 |  |  | 10,681 |  |  | (26,414 | ) |  | 11,246 |  |
| Long-term debt | 8,717 |  |  | — |  |  | 153 |  |  | 2,025 |  |  | — |  |  | 10,895 |  |
| Pension and postretirement benefits | — |  |  | — |  |  | — |  |  | 896 |  |  | — |  |  | 896 |  |
| Intercompany loans payable | 4,688 |  |  | — |  |  | 4,316 |  |  | 6,976 |  |  | (15,980 | ) |  | — |  |
| Other noncurrent liabilities | — |  |  | — |  |  | 23 |  |  | 4,981 |  |  | — |  |  | 5,004 |  |
| Long-term liabilities | 13,405 |  |  | — |  |  | 4,492 |  |  | 14,878 |  |  | (15,980 | ) |  | 16,795 |  |
| Redeemable noncontrolling interests | — |  |  | — |  |  | — |  |  | 226 |  |  | — |  |  | 226 |  |
| Ordinary shares | 9 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 9 |  |
| Ordinary shares held in treasury | (885 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (885 | ) |
| Other shareholders' equity | 21,411 |  |  | 19,146 |  |  | 18,279 |  |  | 55,025 |  |  | (92,450 | ) |  | 21,411 |  |
| Shareholders’ equity attributable to Johnson Controls | 20,535 |  |  | 19,146 |  |  | 18,279 |  |  | 55,025 |  |  | (92,450 | ) |  | 20,535 |  |
| Noncontrolling interests | — |  |  | — |  |  | — |  |  | 965 |  |  | — |  |  | 965 |  |
| Total equity | 20,535 |  |  | 19,146 |  |  | 18,279 |  |  | 55,990 |  |  | (92,450 | ) |  | 21,500 |  |
| Total liabilities and equity | $ | 39,940 |  |  | $ | 38,125 |  |  | $ | 24,771 |  |  | $ | 81,775 |  |  | $ | (134,844 | ) |  | $ | 49,767 |  |

[0000833444-18-000008:notes:62]
As of September 30, 2017

[0000833444-18-000008:notes:63]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | 107 |  |  | $ | 382 |  |  | $ | 718 |  |  | $ | (886 | ) |  | $ | 321 |  |
| Accounts receivable - net | — |  |  | — |  |  | — |  |  | 6,666 |  |  | — |  |  | 6,666 |  |
| Inventories | — |  |  | — |  |  | — |  |  | 3,209 |  |  | — |  |  | 3,209 |  |
| Intercompany receivables | 1,580 |  |  | 1,732 |  |  | 55 |  |  | 4,470 |  |  | (7,837 | ) |  | — |  |
| Assets held for sale | — |  |  | — |  |  | — |  |  | 189 |  |  | — |  |  | 189 |  |
| Other current assets | 14 |  |  | — |  |  | 1 |  |  | 1,892 |  |  | — |  |  | 1,907 |  |
| Current assets | $ | 1,594 |  |  | $ | 1,839 |  |  | $ | 438 |  |  | $ | 17,144 |  |  | $ | (8,723 | ) |  | $ | 12,292 |  |
| Property, plant and equipment - net | — |  |  | — |  |  | — |  |  | 6,121 |  |  | — |  |  | 6,121 |  |
| Goodwill | 243 |  |  | — |  |  | 32 |  |  | 19,413 |  |  | — |  |  | 19,688 |  |
| Other intangible assets - net | — |  |  | — |  |  | — |  |  | 6,741 |  |  | — |  |  | 6,741 |  |
| Investments in partially-owned affiliates | — |  |  | — |  |  | — |  |  | 1,191 |  |  | — |  |  | 1,191 |  |
| Investments in affiliates | 19,487 |  |  | 31,594 |  |  | 21,132 |  |  | — |  |  | (72,213 | ) |  | — |  |
| Intercompany loans receivable | 17,908 |  |  | 4,140 |  |  | 2,836 |  |  | 9,004 |  |  | (33,888 | ) |  | — |  |
| Noncurrent assets held for sale | — |  |  | — |  |  | — |  |  | 1,920 |  |  | — |  |  | 1,920 |  |
| Other noncurrent assets | 56 |  |  | — |  |  | 7 |  |  | 3,868 |  |  | — |  |  | 3,931 |  |
| Total assets | $ | 39,288 |  |  | $ | 37,573 |  |  | $ | 24,445 |  |  | $ | 65,402 |  |  | $ | (114,824 | ) |  | $ | 51,884 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |  |  |
| Short-term debt | $ | 1,476 |  |  | $ | — |  |  | $ | — |  |  | $ | 624 |  |  | $ | (886 | ) |  | $ | 1,214 |  |
| Current portion of long-term debt | 307 |  |  | — |  |  | 18 |  |  | 69 |  |  | — |  |  | 394 |  |
| Accounts payable | — |  |  | — |  |  | — |  |  | 4,271 |  |  | — |  |  | 4,271 |  |
| Accrued compensation and benefits | 4 |  |  | — |  |  | — |  |  | 1,067 |  |  | — |  |  | 1,071 |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 1,279 |  |  | — |  |  | 1,279 |  |
| Liabilities held for sale | — |  |  | — |  |  | — |  |  | 72 |  |  | — |  |  | 72 |  |
| Intercompany payables | 4,236 |  |  | 1,055 |  |  | 1,886 |  |  | 660 |  |  | (7,837 | ) |  | — |  |
| Other current liabilities | 324 |  |  | 2 |  |  | 24 |  |  | 3,203 |  |  | — |  |  | 3,553 |  |
| Current liabilities | 6,347 |  |  | 1,057 |  |  | 1,928 |  |  | 11,245 |  |  | (8,723 | ) |  | 11,854 |  |
| Long-term debt | 7,806 |  |  | — |  |  | 152 |  |  | 4,006 |  |  | — |  |  | 11,964 |  |
| Pension and postretirement benefits | — |  |  | — |  |  | — |  |  | 947 |  |  | — |  |  | 947 |  |
| Intercompany loans payable | 4,688 |  |  | 17,908 |  |  | 4,316 |  |  | 6,976 |  |  | (33,888 | ) |  | — |  |
| Noncurrent liabilities held for sale | — |  |  | — |  |  | — |  |  | 173 |  |  | — |  |  | 173 |  |
| Other noncurrent liabilities | — |  |  | — |  |  | 24 |  |  | 5,344 |  |  | — |  |  | 5,368 |  |
| Long-term liabilities | 12,494 |  |  | 17,908 |  |  | 4,492 |  |  | 17,446 |  |  | (33,888 | ) |  | 18,452 |  |
| Redeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 211 |  |  | — |  |  | 211 |  |
| Ordinary shares | 9 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 9 |  |
| Ordinary shares held in treasury | (710 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (710 | ) |
| Other shareholders' equity | 21,148 |  |  | 18,608 |  |  | 18,025 |  |  | 35,580 |  |  | (72,213 | ) |  | 21,148 |  |
| Shareholders’ equity attributable to Johnson Controls | 20,447 |  |  | 18,608 |  |  | 18,025 |  |  | 35,580 |  |  | (72,213 | ) |  | 20,447 |  |
| Noncontrolling interests | — |  |  | — |  |  | — |  |  | 920 |  |  | — |  |  | 920 |  |
| Total equity | 20,447 |  |  | 18,608 |  |  | 18,025 |  |  | 36,500 |  |  | (72,213 | ) |  | 21,367 |  |
| Total liabilities and equity | $ | 39,288 |  |  | $ | 37,573 |  |  | $ | 24,445 |  |  | $ | 65,402 |  |  | $ | (114,824 | ) |  | $ | 51,884 |  |

[0000833444-18-000008:notes:64]
[same as prior period, unchanged from 0000833444-17-000044:notes:40]

[0000833444-18-000008:notes:65]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Operating Activities |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided (used) by operating activities | $ | (135 | ) |  | $ | 1 |  |  | $ | 33 |  |  | $ | (28 | ) |  | $ | — |  |  | $ | (129 | ) |
| Investing Activities |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | — |  |  | (230 | ) |  | — |  |  | (230 | ) |
| Sale of property, plant and equipment | — |  |  | — |  |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Business divestitures | — |  |  | — |  |  | — |  |  | 2,011 |  |  | — |  |  | 2,011 |  |
| Changes in long-term investments | — |  |  | — |  |  | — |  |  | (12 | ) |  | — |  |  | (12 | ) |
| Net change in intercompany loans receivable | 300 |  |  | — |  |  | (334 | ) |  | 480 |  |  | (446 | ) |  | — |  |
| Net cash provided (used) by investing activities | 300 |  |  | — |  |  | (334 | ) |  | 2,254 |  |  | (446 | ) |  | 1,774 |  |
| Financing Activities |  |  |  |  |  |  |  |  |  |  |  |
| Increase (decrease) in short-term debt - net | 344 |  |  | — |  |  | — |  |  | (13 | ) |  | (27 | ) |  | 304 |  |
| Increase in long-term debt | 885 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 885 |  |
| Repayment of long-term debt | (259 | ) |  | — |  |  | — |  |  | (1,975 | ) |  | — |  |  | (2,234 | ) |
| Debt financing costs | (4 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (4 | ) |
| Stock repurchases | (150 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (150 | ) |
| Payment of cash dividends | (232 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (232 | ) |
| Proceeds from the exercise of stock options | 16 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 16 |  |
| Employee equity-based compensation withholding taxes | — |  |  | — |  |  | — |  |  | (25 | ) |  | — |  |  | (25 | ) |
| Net change in intercompany loans payable | (480 | ) |  | — |  |  | — |  |  | 34 |  |  | 446 |  |  | — |  |
| Net cash provided (used) by financing activities | 120 |  |  | — |  |  | — |  |  | (1,979 | ) |  | 419 |  |  | (1,440 | ) |
| Effect of exchange rate changes on cash and cash equivalents | — |  |  | — |  |  | — |  |  | 17 |  |  | — |  |  | 17 |  |
| Change in cash held for sale | — |  |  | — |  |  | — |  |  | 9 |  |  | — |  |  | 9 |  |
| Increase (decrease) in cash and cash equivalents | 285 |  |  | 1 |  |  | (301 | ) |  | 273 |  |  | (27 | ) |  | 231 |  |
| Cash and cash equivalents at beginning of period | — |  |  | 107 |  |  | 382 |  |  | 718 |  |  | (886 | ) |  | 321 |  |
| Cash and cash equivalents at end of period | $ | 285 |  |  | $ | 108 |  |  | $ | 81 |  |  | $ | 991 |  |  | $ | (913 | ) |  | $ | 552 |  |

[0000833444-18-000008:notes:66]
| (in millions) | Johnson ControlsInternational plc |  | Tyco Fire & Security Finance SCA |  | Tyco International Finance S.A. |  | Other Subsidiaries |  | Consolidating Adjustments |  | Total |
| Operating Activities |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided (used) by operating activities | $ | 211 |  |  | $ | — |  |  | $ | 32 |  |  | $ | (2,128 | ) |  | $ | — |  |  | $ | (1,885 | ) |
| Investing Activities |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | — |  |  | (371 | ) |  | — |  |  | (371 | ) |
| Sale of property, plant and equipment | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | (6 | ) |  | 3 |  |  | — |  |  | (3 | ) |
| Business divestitures | — |  |  | — |  |  | — |  |  | 47 |  |  | — |  |  | 47 |  |
| Changes in long-term investments | — |  |  | — |  |  | — |  |  | (6 | ) |  | — |  |  | (6 | ) |
| Net change in intercompany loans receivable | — |  |  | — |  |  | 10 |  |  | — |  |  | (10 | ) |  | — |  |
| Net cash provided (used) by investing activities | — |  |  | — |  |  | 4 |  |  | (325 | ) |  | (10 | ) |  | (331 | ) |
| Financing Activities |  |  |  |  |  |  |  |  |  |  |  |
| Increase in short-term debt - net | 105 |  |  | — |  |  | — |  |  | 1,460 |  |  | (253 | ) |  | 1,312 |  |
| Increase in long-term debt | — |  |  | — |  |  | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Repayment of long-term debt | — |  |  | — |  |  | — |  |  | (763 | ) |  | — |  |  | (763 | ) |
| Debt financing costs | (6 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (6 | ) |
| Proceeds from the exercise of stock options | 29 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 29 |  |
| Employee equity-based compensation withholding taxes | — |  |  | — |  |  | — |  |  | (25 | ) |  | — |  |  | (25 | ) |
| Net change in intercompany loans payable | — |  |  | — |  |  | — |  |  | (10 | ) |  | 10 |  |  | — |  |
| Dividends paid to noncontrolling interests | — |  |  | — |  |  | — |  |  | (31 | ) |  | — |  |  | (31 | ) |
| Dividend from Adient spin-off | — |  |  | — |  |  | — |  |  | 2,050 |  |  | — |  |  | 2,050 |  |
| Cash transferred to Adient related to spin-off | — |  |  | — |  |  | — |  |  | (564 | ) |  | — |  |  | (564 | ) |
| Cash paid related to prior acquisitions | — |  |  | — |  |  | — |  |  | (45 | ) |  | — |  |  | (45 | ) |
| Net cash provided (used) by financing activities | 128 |  |  | — |  |  | — |  |  | 2,079 |  |  | (243 | ) |  | 1,964 |  |
| Effect of exchange rate changes on cash and cash equivalents | — |  |  | — |  |  | — |  |  | (55 | ) |  | — |  |  | (55 | ) |
| Change in cash held for sale | — |  |  | — |  |  | — |  |  | 105 |  |  | — |  |  | 105 |  |
| Increase (decrease) in cash and cash equivalents | 339 |  |  | — |  |  | 36 |  |  | (324 | ) |  | (253 | ) |  | (202 | ) |
| Cash and cash equivalents at beginning of period | 11 |  |  | — |  |  | 244 |  |  | 324 |  |  | — |  |  | 579 |  |
| Cash and cash equivalents at end of period | $ | 350 |  |  | $ | — |  |  | $ | 280 |  |  | $ | — |  |  | $ | (253 | ) |  | $ | 377 |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-18-000008:notes:67]
Debt and Financing Arrangements

[0000833444-18-000008:notes:68]
In December 2017, the Company repaid a 364-day 150 million euro floating rate term loan, plus accrued interest, scheduled  to mature in September 2018.

[0000833444-18-000008:notes:69]
In November 2017, the Company issued 750 million euro in principal amount of 0.0% senior unsecured fixed rate notes due in December 2020. Proceeds from the issuance were used to repay existing debt and for other general corporate purposes.

[0000833444-18-000008:notes:70]
In November 2017, the Company retired $300 million in principal amount, plus accrued interest, of its 1.4% fixed rate notes that expired in November 2017.

[0000833444-18-000008:notes:71]
In October 2017, the Company completed the previously announced sale of its Scott Safety business to 3M. Net cash proceeds from the transaction of approximately $1.9 billion were used to repay a significant portion of the TSarl $4.0 billion of merger-related debt. As of December 31, 2017, the outstanding balance of the TSarl term loan was approximately $1.8 billion.

[0000833444-18-000008:notes:72]
Net Financing Charges

[0000833444-18-000008:notes:73]
Net financing charges for the three months ended December 31, 2016, included $17 million of transaction costs related primarily to the prior year debt exchange offer fees.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000833444-18-000008:notes:74]
[same as prior period, unchanged from 0000833444-17-000044:notes:65]

[0000833444-18-000008:notes:75]
The Company selectively uses derivative instruments to reduce market risk associated with changes in foreign currency, commodities, stock-based compensation liabilities and interest rates. Under Company policy, the use of derivatives is restricted to those intended for hedging purposes; the use of any derivative instrument for speculative purposes is strictly prohibited. A description of each type of derivative utilized by the Company to manage risk is included in the following paragraphs. In addition, refer to Note 16, "Fair Value Measurements," of the notes to consolidated financial statements for information related to the fair value measurements and valuation methods utilized by the Company for each derivative type.

[0000833444-18-000008:notes:76]
[same as prior period, unchanged from 0000833444-17-000044:notes:67]

[0000833444-18-000008:notes:77]
The Company has global operations and participates in the foreign exchange markets to minimize its risk of loss from fluctuations in foreign currency exchange rates. The Company selectively hedges anticipated transactions that are subject to foreign exchange rate risk primarily using foreign currency exchange hedge contracts. The Company hedges 70% to 90% of the nominal amount of each of its known foreign exchange transactional exposures. As cash flow hedges under ASC 815, "Derivatives and Hedging," the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions occur and affect earnings. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in currency exchange rates during the three months ended December 31, 2017 and 2016.

[0000833444-18-000008:notes:78]
The Company selectively hedges anticipated transactions that are subject to commodity price risk, primarily using commodity hedge contracts, to minimize overall price risk associated with the Company’s purchases of lead, copper, tin, aluminum and polypropylene in cases where commodity price risk cannot be naturally offset or hedged through supply base fixed price contracts. Commodity risks are systematically managed pursuant to policy guidelines. As cash flow hedges, the effective portion of the hedge gains or losses due to changes in fair value are initially recorded as a component of AOCI and are subsequently reclassified into earnings when the hedged transactions, typically sales, occur and affect earnings. The maturities of the commodity hedge contracts coincide with the expected purchase of the commodities. These contracts were highly effective in hedging the variability in future cash flows attributable to changes in commodity prices during the three months ended December 31, 2017 and 2016.

[0000833444-18-000008:notes:79]
[same as prior period, unchanged from 0000833444-17-000044:notes:70]

[0000833444-18-000008:notes:80]
|  |  |  |  | Volume Outstanding as of |
| Commodity |  | Units |  | December 31, 2017 |  | September 30, 2017 |
| Copper |  | Metric Tons |  | 3,765 |  |  | 1,962 |  |
| Polypropylene |  | Metric Tons |  | 21,762 |  |  | 19,563 |  |
| Lead |  | Metric Tons |  | 13,791 |  |  | 24,705 |  |
| Aluminum |  | Metric Tons |  | 5,295 |  |  | 2,169 |  |
| Tin |  | Metric Tons |  | 1,655 |  |  | 1,715 |  |

[0000833444-18-000008:notes:81]
[same as prior period, unchanged from 0000833444-17-000044:notes:73]

[0000833444-18-000008:notes:82]
The Company selectively uses interest rate swaps to reduce market risk associated with changes in interest rates for its fixed-rate bonds. As fair value hedges, the interest rate swaps and related debt balances are valued under a market approach using publicized swap curves. Changes in the fair value of the swap and hedged portion of the debt are recorded in the consolidated statements of income. As of September 30, 2016, the Company had four fixed to floating interest rate swaps totaling $400 million to hedge the coupon of its 2.6% notes that matured in December 2016, three fixed to floating interest rate swaps totaling $300 million to hedge the coupon of its 1.4% notes maturing November 2017 and one fixed to floating interest rate swap totaling $150 million to hedge the coupon of its 7.125% notes maturing July 2017.  In December 2016, the four remaining outstanding interest rate swaps were terminated. The Company had no interest rate swaps outstanding at December 31, 2017 and September 30, 2017, respectively.

[0000833444-18-000008:notes:83]
[same as prior period, unchanged from 0000833444-17-000044:notes:75]

[0000833444-18-000008:notes:84]
The Company enters into foreign currency denominated debt obligations to selectively hedge portions of its net investment in non-U.S. subsidiaries. The currency effects of the debt obligations are reflected in the AOCI account within shareholders’ equity attributable to Johnson Controls ordinary shareholders where they offset gains and losses recorded on the Company’s net investments globally. At December 31, 2017, the Company had one billion euro, 750 million euro, 423 million euro and 58 million euro bonds designated as net investment hedges in the Company's net investment in Europe and 35 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan. At September 30, 2017, the Company had one billion euro, 423 million euro and 58 million euro bonds designated as net investment hedges in the Company's net investment in Europe and 35 billion yen of foreign denominated debt designated as net investment hedge in the Company's net investment in Japan.

[0000833444-18-000008:notes:85]
[same as prior period, unchanged from 0000833444-17-000044:notes:77]

[0000833444-18-000008:notes:86]
The Company selectively uses equity swaps to reduce market risk associated with certain of its stock-based compensation plans, such as its deferred compensation plans. These equity compensation liabilities increase as the Company’s stock price increases and decrease as the Company’s stock price decreases. In contrast, the value of the swap agreement moves in the opposite direction of these liabilities, allowing the Company to fix a portion of the liabilities at a stated amount. As of December 31, 2017, the Company hedged approximately 1.8 million shares of its ordinary shares, which have a cost basis of $73 million. As of September 30, 2017, the Company hedged approximately 1.4 million shares of its ordinary shares, which have a cost basis of $58 million.

[0000833444-18-000008:notes:87]
[same as prior period, unchanged from 0000833444-17-000044:notes:79]

[0000833444-18-000008:notes:88]
Fair Value of Derivative Instruments

[0000833444-18-000008:notes:89]
[same as prior period, unchanged from 0000833444-17-000044:notes:80]

[0000833444-18-000008:notes:90]
|  | Derivatives and Hedging Activities Designatedas Hedging Instruments under ASC 815 |  | Derivatives and Hedging Activities NotDesignated as Hedging Instruments under ASC 815 |
|  | December 31, |  | September 30, |  | December 31, |  | September 30, |
|  | 2017 |  | 2017 |  | 2017 |  | 2017 |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 35 |  |  | $ | 27 |  |  | $ | 21 |  |  | $ | — |  |
| Commodity derivatives | 6 |  |  | 9 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Equity swap | — |  |  | — |  |  | 68 |  |  | 55 |  |
| Total assets | $ | 41 |  |  | $ | 36 |  |  | $ | 89 |  |  | $ | 55 |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 25 |  |  | $ | 21 |  |  | $ | 16 |  |  | $ | 25 |  |
| Commodity derivatives | 1 |  |  | 1 |  |  | — |  |  | — |  |
| Long-term debt |  |  |  |  |  |  |  |
| Foreign currency denominated debt | 2,981 |  |  | 2,058 |  |  | — |  |  | — |  |
| Total liabilities | $ | 3,007 |  |  | $ | 2,080 |  |  | $ | 16 |  |  | $ | 25 |  |

[0000833444-18-000008:notes:91]
[same as prior period, unchanged from 0000833444-17-000044:notes:82]

[0000833444-18-000008:notes:92]
The use of derivative financial instruments exposes the Company to counterparty credit risk. The Company has established policies and procedures to limit the potential for counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association ("ISDA") master netting agreements with substantially all of its counterparties. The Company's derivative contracts do not contain any credit risk related contingent features and do not require collateral or other security to be furnished by the Company or the counterparties. The Company's exposure to credit risk associated with its derivative instruments is measured on an individual counterparty basis, as well as by groups of counterparties that share similar attributes. The Company does not anticipate any non-performance by any of its counterparties, and the concentration of risk with financial institutions does not present significant credit risk to the Company.

[0000833444-18-000008:notes:93]
The Company enters into ISDA master netting agreements with counterparties that permit the net settlement of amounts owed under the derivative contracts. The master netting agreements generally provide for net settlement of all outstanding contracts with a counterparty in the case of an event of default or a termination event. The Company has not elected to offset the fair value positions of the derivative contracts recorded in the consolidated statements of financial position. Collateral is generally not required of the Company or the counterparties under the master netting agreements. As of December 31, 2017 and September 30, 2017, no cash collateral was received or pledged under the master netting agreements.

[0000833444-18-000008:notes:94]
[same as prior period, unchanged from 0000833444-17-000044:notes:85]

[0000833444-18-000008:notes:95]
The following table presents the effective portion of pre-tax gains (losses) recorded in other comprehensive income (loss) related to cash flow hedges for the three months ended December 31, 2017 and 2016 (in millions):

[0000833444-18-000008:notes:96]
| Derivatives in ASC 815 Cash Flow Hedging Relationships |  | Three Months Ended December 31, |
|  | 2017 |  | 2016 |
| Foreign currency exchange derivatives |  | $ | 6 |  |  | $ | 8 |  |
| Commodity derivatives |  | 3 |  |  | 2 |  |
| Total |  | $ | 9 |  |  | $ | 10 |  |

[0000833444-18-000008:notes:97]
The following tables present the location and amount of the effective portion of pre-tax gains (losses) on cash flow hedges reclassified from AOCI into the Company’s consolidated statements of income for the three months ended December 31, 2017 and 2016 (in millions):

[0000833444-18-000008:notes:98]
| Derivatives in ASC 815 Cash FlowHedging Relationships |  | Location of Gain (Loss) Reclassifiedfrom AOCI into Income |  | Three Months Ended December 31, |
|  | 2017 |  | 2016 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 2 |  |  | $ | 8 |  |
| Commodity derivatives |  | Cost of sales |  | 5 |  |  | 1 |  |
| Total |  |  |  | $ | 7 |  |  | $ | 9 |  |

[0000833444-18-000008:notes:99]
The following table presents the location and amount of pre-tax gains (losses) on fair value hedges recognized in the Company’s consolidated statements of income for the three months ended December 31, 2017 and 2016 (in millions):

[0000833444-18-000008:notes:100]
| Derivatives in ASC 815 Fair ValueHedging Relationships |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months Ended December 31, |
|  | 2017 |  | 2016 |
| Interest rate swap |  | Net financing charges |  | $ | — |  |  | $ | (1 | ) |
| Fixed rate debt swapped to floating |  | Net financing charges |  | — |  |  | 2 |  |
| Total |  |  |  | $ | — |  |  | $ | 1 |  |

[0000833444-18-000008:notes:101]
The following table presents the location and amount of pre-tax gains (losses) on derivatives not designated as hedging instruments recognized in the Company’s consolidated statements of income for the three months ended December 31, 2017 and 2016 (in millions):

[0000833444-18-000008:notes:102]
|  |  |  |  | Amount of Gain (Loss) Recognized inIncome on Derivative |
| Derivatives Not Designated as Hedging Instruments under ASC 815 |  | Location of Gain (Loss)Recognized in Income on Derivative |  | Three Months Ended December 31, |
|  | 2017 |  | 2016 |
| Foreign currency exchange derivatives |  | Cost of sales |  | $ | 2 |  |  | $ | 1 |  |
| Foreign currency exchange derivatives |  | Net financing charges |  | 4 |  |  | 4 |  |
| Foreign currency exchange derivatives |  | Income tax provision |  | 2 |  |  | (3 | ) |
| Foreign currency exchange derivatives |  | Income (loss) from discontinued operations |  | — |  |  | 5 |  |
| Equity swap |  | Selling, general and administrative |  | (2 | ) |  | — |  |
| Total |  |  |  | $ | 6 |  |  | $ | 7 |  |

[0000833444-18-000008:notes:103]
The effective portion of pre-tax gains (losses) recorded in CTA within other comprehensive income (loss) related to net investment hedges were $(36) million and $47 million for the three months ended December 31, 2017 and 2016, respectively. For the three months ended December 31, 2017 and 2016, no gains or losses were reclassified from CTA into income for the Company’s outstanding net investment hedges.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-18-000008:notes:104]
[same as prior period, unchanged from 0000833444-17-000044:notes:95]

[0000833444-18-000008:notes:105]
During September 2016, the Board of Directors of the Company approved amendments to the Johnson Controls International plc 2012 Share and Incentive Plan (the "Plan"). The types of awards authorized by the Plan comprise of stock options, stock appreciation rights, performance shares, performance units and other stock-based compensation awards. The Compensation Committee of the Company's Board of Directors determines the types of awards to be granted to individual participants and the terms and conditions of the awards. Awards are typically granted annually in the Company’s fiscal first quarter. A summary of the stock-based awards granted during the three month periods ended December 31, 2017 and 2016 is presented below:

[0000833444-18-000008:notes:106]
|  | Three Months Ended December 31, |
|  | 2017 |  | 2016 |
|  | Number Granted |  | Weighted Average Grant Date Fair Value |  | Number Granted |  | Weighted Average Grant Date Fair Value |
| Stock options | 1,355,595 |  |  | $ | 7.05 |  |  | 2,830,826 |  |  | $ | 7.81 |  |
| Stock appreciation rights | — |  |  | — |  |  | 15,693 |  |  | 8.28 |  |
| Restricted stock/units | 2,051,817 |  |  | 37.36 |  |  | 1,512,544 |  |  | 41.74 |  |
| Performance shares | 496,478 |  |  | 36.31 |  |  | 846,725 |  |  | 48.40 |  |

[0000833444-18-000008:notes:107]
[same as prior period, unchanged from 0000833444-17-000044:notes:99]

[0000833444-18-000008:notes:108]
[same as prior period, unchanged from 0000833444-17-000044:notes:100]

[0000833444-18-000008:notes:109]
The fair value of each option is estimated on the date of grant using a Black-Scholes option valuation model that uses the assumptions noted in the following table. The expected life of options represents the period of time that options granted are expected to be outstanding, assessed separately for executives and non-executives. The risk-free interest rate for periods during the contractual life of the option is based on the U.S. Treasury yield curve in effect at the time of grant. For fiscal 2018, the expected volatility is based on the historical volatility of the Company’s stock after the Adient spin-off blended with the historical volatility of certain peer companies’ stock prior to the Adient spin-off over the most recent period corresponding to the expected life as of the grant date. For fiscal 2017, the expected volatility is based on the historical volatility of certain peer companies over the most recent period corresponding to the expected life as of the grant date. The expected dividend yield is based on the expected annual dividend as a percentage of the market value of the Company’s ordinary shares as of the grant date. The Company uses historical data to estimate option exercises and employee terminations within the valuation model.

[0000833444-18-000008:notes:110]
|  | Three Months Ended December 31, |
|  | 2017 |  | 2016 |
| Expected life of option (years) | 6.5 |  | 4.75 & 6.5 |
| Risk-free interest rate | 2.28% |  | 1.23% - 1.48% |
| Expected volatility of the Company’s stock | 23.7% |  | 24.6% |
| Expected dividend yield on the Company’s stock | 2.78% |  | 2.21% |

[0000833444-18-000008:notes:111]
Stock Appreciation Rights ("SARs")

[0000833444-18-000008:notes:112]
[same as prior period, unchanged from 0000833444-17-000044:notes:104]

[0000833444-18-000008:notes:113]
Restricted (Nonvested) Stock / Units

[0000833444-18-000008:notes:114]
The Plan provides for the award of restricted stock or restricted stock units to certain employees. These awards are typically share settled unless the employee is a non-U.S. employee or elects to defer settlement until retirement at which point the award would be settled in cash. Restricted awards typically vest over a period of three years from the grant date. The Plan allows for different vesting terms on specific grants with approval by the Board of Directors. The value of restricted awards is based on the closing market value of the Company’s ordinary shares on the date of grant.

[0000833444-18-000008:notes:115]
[same as prior period, unchanged from 0000833444-17-000044:notes:107]

[0000833444-18-000008:notes:116]
[same as prior period, unchanged from 0000833444-17-000044:notes:108]

[0000833444-18-000008:notes:117]
The fair value of each PSU is estimated on the date of grant using a Monte Carlo simulation that uses the assumptions noted in the following table. The risk-free interest rate for periods during the contractual life of the PSU is based on the U.S. Treasury yield curve in effect at the time of grant. For fiscal 2018, the expected volatility is based on the historical volatility of the Company’s stock after the Adient spin-off blended with the historical volatility of certain peer companies’ stock prior to the Adient spin-off over the most recent three-year period as of the grant date. For fiscal 2017, the expected volatility is based on historical volatility of certain peer companies over the most recent three-year period as of the grant date.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-18-000008:notes:118]
[same as prior period, unchanged from 0000833444-17-000044:notes:114]

[0000833444-18-000008:notes:119]
On October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience business from Johnson Controls to Adient plc and the issuance of ordinary shares of Adient directly to holders of Johnson Controls ordinary shares on a pro rata basis. Prior to the open of business on October 31, 2016, each of the Company's shareholders received one ordinary share of Adient plc for every 10 ordinary shares of Johnson Controls held as of the close of business on October 19, 2016, the record date for the distribution. Company shareholders received cash in lieu of fractional shares of Adient, if any. Following the separation and distribution, Adient plc is now an independent public company trading on the New York Stock Exchange ("NYSE") under the symbol "ADNT." The Company did not retain any equity interest in Adient plc. Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation. The Company did not allocate any general corporate overhead to discontinued operations.

[0000833444-18-000008:notes:120]
For the three months ended December 31, 2016, the income from discontinued operations before income taxes included separation costs of $79 million.

[0000833444-18-000008:notes:121]
For the three months ended December 31, 2016, the effective tax rate was more than the U.S. federal statutory rate of 35% primarily due to the tax impacts of separation costs and Adient spin-off related tax expense, partially offset by non-U.S. tax rate differentials.

[0000833444-18-000008:notes:122]
The following table summarizes depreciation and amortization, capital expenditures, and significant operating and investing noncash items related to Adient for the three month period ended December 31, 2016 (in millions):

[0000833444-18-000008:notes:123]
|  | Three Months Ended December 31, |
|  | 2016 |
| Depreciation and amortization | $ | 29 |  |
| Equity in earnings of partially-owned affiliates | (31 | ) |
| Deferred income taxes | 562 |  |
| Equity-based compensation | 1 |  |
| Accrued income taxes | (808 | ) |
| Capital expenditures | (91 | ) |

[0000833444-18-000008:notes:124]
[same as prior period, unchanged from 0000833444-17-000044:notes:118]

[0000833444-18-000008:notes:125]
During the second quarter of fiscal 2017, the Company signed a definitive agreement to sell its Scott Safety business of the Global Products segment to 3M Company. The transaction closed on October 4, 2017. The assets and liabilities of this business are presented as held for sale in the consolidated statements of financial position as of September 30, 2017. The business did not meet the criteria to be classified as a discontinued operation as the divestiture of the Scott Safety business did not have a major effect on the Company’s operations and financial results.

[0000833444-18-000008:notes:126]
The following table summarizes the carrying value of the Scott Safety assets and liabilities held for sale at September 30, 2017 (in millions):

[0000833444-18-000008:notes:127]
|  | September 30, 2017 |
| Cash | $ | 9 |  |
| Accounts receivable - net | 100 |  |
| Inventories | 75 |  |
| Other current assets | 5 |  |
| Assets held for sale | $ | 189 |  |
| Property, plant and equipment - net | $ | 79 |  |
| Goodwill | 1,248 |  |
| Other intangible assets - net | 592 |  |
| Other noncurrent assets | 1 |  |
| Noncurrent assets held for sale | $ | 1,920 |  |
| Accounts payable | $ | 37 |  |
| Accrued compensation and benefits | 10 |  |
| Other current liabilities | 25 |  |
| Liabilities held for sale | $ | 72 |  |
| Other noncurrent liabilities | $ | 173 |  |
| Noncurrent liabilities held for sale | $ | 173 |  |

[0000833444-18-000008:notes:128]
During the first quarter of fiscal 2018, the Company signed a definitive agreement to sell a certain Global Products business. As a result, $18 million of goodwill was transfered to assets held for sale in the consolidated statements of financial position as of December 31, 2017. The business did not meet the criteria to be classified as a discontinued operation as the divestiture of the business will not have a major effect on the Company’s operations and financial results.

[0000833444-18-000008:notes:129]
At December 31, 2017, $22 million of certain Corporate assets were classified as held for sale.


## us-gaap:EarningsPerShareTextBlock

[0000833444-18-000008:notes:130]
[same as prior period, unchanged from 0000833444-17-000044:notes:128]

[0000833444-18-000008:notes:131]
The Company presents both basic and diluted earnings per share ("EPS") amounts. Basic EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares outstanding during the reporting period. Diluted EPS is calculated by dividing net income attributable to Johnson Controls by the weighted average number of ordinary shares and ordinary equivalent shares outstanding during the reporting period that are calculated using the treasury stock method for stock options, unvested restricted stock and unvested performance share awards. The treasury stock method assumes that the Company uses the proceeds from the exercise of stock option awards to repurchase ordinary shares at the average market price during the period. The assumed proceeds under the treasury stock method include the purchase price that the grantee will pay in the future and compensation cost for future service that the Company has not yet recognized. For unvested restricted stock and unvested performance share awards, assumed proceeds under the treasury stock method would include unamortized compensation cost.

[0000833444-18-000008:notes:132]
[same as prior period, unchanged from 0000833444-17-000044:notes:130]

[0000833444-18-000008:notes:133]
|  | Three Months EndedDecember 31, |
|  | 2017 |  | 2016 |
| Income Available to Ordinary Shareholders |  |  |  |
| Income from continuing operations | $ | 230 |  |  | $ | 372 |  |
| Loss from discontinued operations | — |  |  | (43 | ) |
| Basic and diluted income available to shareholders | $ | 230 |  |  | $ | 329 |  |
| Weighted Average Shares Outstanding |  |  |  |
| Basic weighted average shares outstanding | 926.1 |  |  | 937.2 |  |
| Effect of dilutive securities: |  |  |  |
| Stock options, unvested restricted stock and unvested performance share awards | 7.2 |  |  | 10.2 |  |
| Diluted weighted average shares outstanding | 933.3 |  |  | 947.4 |  |
| Antidilutive Securities |  |  |  |
| Options to purchase shares | 1.0 |  |  | 0.1 |  |

[0000833444-18-000008:notes:134]
During the three months ended December 31, 2017 and 2016, the Company declared a dividend of $0.26 and $0.25, respectively, per share. The Company paid all dividends in the month subsequent to the end of each fiscal quarter.


## us-gaap:FairValueDisclosuresTextBlock

[0000833444-18-000008:notes:135]
[same as prior period, unchanged from 0000833444-17-000044:notes:133]

[0000833444-18-000008:notes:136]
[same as prior period, unchanged from 0000833444-17-000044:notes:134]

[0000833444-18-000008:notes:137]
Level 1: Observable inputs such as quoted prices in active markets for identical assets or liabilities;

[0000833444-18-000008:notes:138]
Level 2: Quoted prices in active markets for similar assets or liabilities, quoted prices for identical or similar assets or liabilities in markets that are not active, or inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and

[0000833444-18-000008:notes:139]
[same as prior period, unchanged from 0000833444-17-000044:notes:137]

[0000833444-18-000008:notes:140]
[same as prior period, unchanged from 0000833444-17-000044:notes:138]

[0000833444-18-000008:notes:141]
[same as prior period, unchanged from 0000833444-17-000044:notes:139]

[0000833444-18-000008:notes:142]
The following tables present the Company’s fair value hierarchy for those assets and liabilities measured at fair value as of December 31, 2017 and September 30, 2017 (in millions):

[0000833444-18-000008:notes:143]
|  | Fair Value Measurements Using: |
|  | Total as of December 31, 2017 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 56 |  |  | $ | — |  |  | $ | 56 |  |  | $ | — |  |
| Commodity derivatives | 6 |  |  | — |  |  | 6 |  |  | — |  |
| Exchange traded funds (fixed income)1 | 28 |  |  | 28 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Investments in marketable common stock | 6 |  |  | 6 |  |  | — |  |  | — |  |
| Deferred compensation plan assets | 96 |  |  | 96 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 142 |  |  | 142 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 113 |  |  | 113 |  |  | — |  |  | — |  |
| Equity swap | 68 |  |  | — |  |  | 68 |  |  | — |  |
| Total assets | $ | 515 |  |  | $ | 385 |  |  | $ | 130 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 41 |  |  | $ | — |  |  | $ | 41 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Total liabilities | $ | 42 |  |  | $ | — |  |  | $ | 42 |  |  | $ | — |  |

[0000833444-18-000008:notes:144]
|  | Fair Value Measurements Using: |
|  | Total as of September 30, 2017 |  | Quoted Pricesin ActiveMarkets(Level 1) |  | SignificantOtherObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Other current assets |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 27 |  |  | $ | — |  |  | $ | 27 |  |  | $ | — |  |
| Commodity derivatives | 9 |  |  | — |  |  | 9 |  |  | — |  |
| Exchange traded funds (fixed income)1 | 14 |  |  | 14 |  |  | — |  |  | — |  |
| Other noncurrent assets |  |  |  |  |  |  |  |
| Investments in marketable common stock | 10 |  |  | 10 |  |  | — |  |  | — |  |
| Deferred compensation plan assets | 92 |  |  | 92 |  |  | — |  |  | — |  |
| Exchange traded funds (fixed income)1 | 155 |  |  | 155 |  |  | — |  |  | — |  |
| Exchange traded funds (equity)1 | 100 |  |  | 100 |  |  | — |  |  | — |  |
| Equity swap | 55 |  |  | — |  |  | 55 |  |  | — |  |
| Total assets | $ | 462 |  |  | $ | 371 |  |  | $ | 91 |  |  | $ | — |  |
| Other current liabilities |  |  |  |  |  |  |  |
| Foreign currency exchange derivatives | $ | 46 |  |  | $ | — |  |  | $ | 46 |  |  | $ | — |  |
| Commodity derivatives | 1 |  |  | — |  |  | 1 |  |  | — |  |
| Total liabilities | $ | 47 |  |  | $ | — |  |  | $ | 47 |  |  | $ | — |  |

[0000833444-18-000008:notes:145]
1 Classified as restricted investments for payment of asbestos liabilities. See Note 21, "Commitments and Contingencies," of the notes to consolidated financial statements for further details.

[0000833444-18-000008:notes:146]
[same as prior period, unchanged from 0000833444-17-000044:notes:144]

[0000833444-18-000008:notes:147]
[same as prior period, unchanged from 0000833444-17-000044:notes:145]

[0000833444-18-000008:notes:148]
[same as prior period, unchanged from 0000833444-17-000044:notes:146]

[0000833444-18-000008:notes:149]
[same as prior period, unchanged from 0000833444-17-000044:notes:148]

[0000833444-18-000008:notes:150]
[same as prior period, unchanged from 0000833444-17-000044:notes:149]

[0000833444-18-000008:notes:151]
Investments in marketable common stock and exchange traded funds:  Investments in marketable common stock and exchange traded funds are valued using a market approach based on the quoted market prices, where available, or broker/dealer quotes of identical or comparable instruments. The Company recorded unrealized gains of $14 million and unrealized losses of $10 million on these investments as of December 31, 2017 within AOCI in the consolidated statements of financial position. The Company recorded unrealized gains of $10 million and unrealized losses of $6 million on these investments  as of September 30, 2017 within AOCI in the consolidated statements of financial position.

[0000833444-18-000008:notes:152]
The fair values of cash and cash equivalents, accounts receivable, short-term debt and accounts payable approximate their carrying values. The fair value of long-term debt was $11.5 billion and $12.7 billion at December 31, 2017 and September 30, 2017, respectively. The fair value of public debt was $9.3 billion and $8.6 billion, at December 31, 2017 and September 30, 2017, respectively, which was determined primarily using market quotes classified as Level 1 inputs within the ASC 820 fair value hierarchy. The fair value of other long-term debt was $2.2 billion and $4.1 billion at December 31, 2017 and September 30, 2017, respectively, which was determined based on quoted market prices for similar instruments classified as Level 2 inputs within the ASC 820 fair value hierarchy.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-18-000008:notes:153]
[same as prior period, unchanged from 0000833444-17-000044:notes:155]

[0000833444-18-000008:notes:154]
The changes in the carrying amount of goodwill in each of the Company’s reportable segments for the three month period ended December 31, 2017 were as follows (in millions):

[0000833444-18-000008:notes:155]
|  |  |  | Business Acquisitions |  | Business Divestitures |  | Currency Translation and Other |  |  |
|  | September 30, |  |  |  |  | December 31, |
|  | 2017 |  |  |  |  | 2017 |
| Building Technologies & Solutions |  |  |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 9,637 |  |  | $ | — |  |  | $ | — |  |  | $ | (4 | ) |  | $ | 9,633 |  |
| Building Solutions EMEA/LA | 2,012 |  |  | — |  |  | — |  |  | 14 |  |  | 2,026 |  |
| Building Solutions Asia Pacific | 1,255 |  |  | — |  |  | — |  |  | 28 |  |  | 1,283 |  |
| Global Products | 5,687 |  |  | — |  |  | (18 | ) |  | 1 |  |  | 5,670 |  |
| Power Solutions | 1,097 |  |  | — |  |  | — |  |  | 8 |  |  | 1,105 |  |
| Total | $ | 19,688 |  |  | $ | — |  |  | $ | (18 | ) |  | $ | 47 |  |  | $ | 19,717 |  |

[0000833444-18-000008:notes:156]
At September 30, 2017, accumulated goodwill impairment charges included $47 million related to the Building Solutions EMEA/LA  - Latin America reporting unit. The three months ended December 31, 2017 Global Products business divestiture amount includes $18 million of goodwill transferred to assets held for sale in the consolidated statements of financial position. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's assets and liabilities held for sale.

[0000833444-18-000008:notes:157]
Amortization of other intangible assets included within continuing operations for the three month periods ended December 31, 2017 and 2016 was $94 million and $149 million, respectively. Excluding the impact of any future acquisitions, the Company anticipates amortization for fiscal 2019, 2020, 2021, 2022 and 2023 will be approximately $376 million, $371 million, $365 million, $355 million and $346 million per year, respectively.


## us-gaap:GuaranteesTextBlock

[0000833444-18-000008:notes:158]
[same as prior period, unchanged from 0000833444-17-000044:notes:160]

[0000833444-18-000008:notes:159]
[same as prior period, unchanged from 0000833444-17-000044:notes:161]

[0000833444-18-000008:notes:160]
[same as prior period, unchanged from 0000833444-17-000044:notes:162]

[0000833444-18-000008:notes:161]
[same as prior period, unchanged from 0000833444-17-000044:notes:163]

[0000833444-18-000008:notes:162]
The changes in the carrying amount of the Company’s total product warranty liability, including extended warranties, for the three months ended December 31, 2017 and 2016 were as follows (in millions):

[0000833444-18-000008:notes:163]
|  | Three Months EndedDecember 31, |
|  | 2017 |  | 2016 |
| Balance at beginning of period | $ | 409 |  |  | $ | 374 |  |
| Accruals for warranties issued during the period | 84 |  |  | 82 |  |
| Accruals from acquisition and divestitures | — |  |  | (1 | ) |
| Accruals related to pre-existing warranties | (3 | ) |  | (6 | ) |
| Settlements made (in cash or in kind) during the period | (77 | ) |  | (73 | ) |
| Currency translation | 2 |  |  | (6 | ) |
| Balance at end of period | $ | 415 |  |  | $ | 370 |  |

[0000833444-18-000008:notes:164]
As a result of the Tyco Merger in the fourth quarter of fiscal 2016, the Company recorded, as part of the acquired liabilities of Tyco, $290 million of post sale contingent tax indemnification liabilities which is generally recorded within other noncurrent liabilities in the consolidated statements of financial position. The liabilities are recorded at fair value and relate to certain tax related matters borne by the buyer of previously divested subsidiaries of Tyco which Tyco has indemnified certain parties and the amounts are probable of being paid. At December 31, 2017 and September 30, 2017, the Company recorded liabilities of $272 million and $290 million, respectively.  Of the $272 million recorded as of December 31, 2017, $237 million is related to prior divested businesses and the remainder relates to Tyco’s tax sharing agreements from its 2007 and 2012 spin-off transactions. These are certain guarantees or indemnifications extended among Tyco, Medtronic, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 separation and tax sharing agreements. In addition, the Company has recorded $9 million and $11 million of tax indemnification liabilities as of December 31, 2017 and September 30, 2017, respectively, related to other divestitures.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsIncludingIntangibleAssetsPolicyPolicyTextBlock

[0000833444-18-000008:notes:165]
[same as prior period, unchanged from 0000833444-17-000044:notes:168]

[0000833444-18-000008:notes:166]
The Company reviews long-lived assets, including tangible assets and other intangible assets with definitive lives, for impairment whenever events or changes in circumstances indicate that the asset’s carrying amount may not be recoverable. The Company conducts its long-lived asset impairment analyses in accordance with ASC 360-10-15, "Impairment or Disposal of Long-Lived Assets" and ASC 350-30, "General Intangibles Other than Goodwill." ASC 360-10-15 requires the Company to group assets and liabilities at the lowest level for which identifiable cash flows are largely independent of the cash flows of other assets and liabilities and evaluate the asset group against the sum of the undiscounted future cash flows. If the undiscounted cash flows do not indicate the carrying amount of the asset group is recoverable, an impairment charge is measured as the amount by which the carrying amount of the asset group exceeds its fair value based on discounted cash flow analysis or appraisals. ASC 350-30 requires intangible assets acquired in a business combination that are used in research and development activities to be considered indefinite lived until the completion or abandonment of the associated research and development efforts. During the period that those assets are considered indefinite lived, they shall not be amortized but shall be tested for impairment annually and more frequently if events or changes in circumstances indicate that it is more likely than not that the asset is impaired.  If the carrying amount of an intangible asset exceeds its fair value, an entity shall recognize an impairment loss in an amount equal to that excess.

[0000833444-18-000008:notes:167]
In the first quarter of fiscal 2018, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2018. As a result, the Company reviewed the long-lived assets for impairment and recorded $30 million of asset impairment charges within restructuring and impairment costs in the consolidated statements of income. Of the total impairment charges, $23 million related to the Global Products segment, $5 million related to Corporate assets and $2 million related to the Power Solutions segment. Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-18-000008:notes:168]
In the first quarter of fiscal 2017, the Company concluded it had a triggering event requiring assessment of impairment for certain of its long-lived assets in conjunction with its restructuring actions announced in fiscal 2017. As a result, the Company reviewed the long-lived assets for impairment and recorded $15 million of asset impairment charges within restructuring and impairment costs in the consolidated statements of income, all of which related to Corporate assets. Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The impairments were measured under a market approach utilizing an appraisal to determine fair values of the impaired assets. This method is consistent with the methods the Company employed in prior periods to value other long-lived assets. The inputs utilized in the analyses are classified as Level 3 inputs within the fair value hierarchy as defined in ASC 820, "Fair Value Measurement."

[0000833444-18-000008:notes:169]
At December 31, 2017 and 2016, the Company concluded it did not have any other triggering events requiring assessment of impairment of its long-lived assets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-18-000008:notes:170]
[same as prior period, unchanged from 0000833444-17-000044:notes:173]

[0000833444-18-000008:notes:171]
In calculating the provision for income taxes, the Company uses an estimate of the annual effective tax rate based upon the facts and circumstances known at each interim period. On a quarterly basis, the actual effective tax rate is adjusted, as appropriate, based upon changed facts and circumstances, if any, as compared to those forecasted at the beginning of the fiscal year and each interim period thereafter. The U.S. federal statutory tax rate is being used as a comparison due to the Company's current legal entity structure. As a result of recently enacted U.S. Tax Reform, the Company will be subject to a U.S. federal statutory tax rate of 24.5% for its fiscal year ended September 30, 2018, which reflects a blended federal statutory rate of 35% for its first fiscal quarter and 21% for the remaining three fiscal quarters. For the three months ended December 31, 2017, the Company's effective tax rate was 50% and was higher than the blended U.S. federal statutory rate of 24.5% primarily due to the discrete net impacts of U.S. Tax Reform, Tyco Merger transaction and integration costs, and the jurisdictional mix of significant restructuring and impairment costs, partially offset by the benefits of continuing global tax planning initiatives, non-U.S. tax rate differentials and tax audit closures. For the three months ended December 31, 2016, the Company's effective tax rate was -7% and was lower than the U.S. federal statutory rate of 35% primarily due to the benefits of continuing global tax planning initiatives, non-U.S. tax rate differentials and a tax benefit due to changes in entity tax status, partially offset by the jurisdictional mix of significant restructuring and impairment costs, as well as Tyco Merger transaction and integration costs, and purchase accounting impacts.

[0000833444-18-000008:notes:172]
[same as prior period, unchanged from 0000833444-17-000044:notes:175]

[0000833444-18-000008:notes:173]
[same as prior period, unchanged from 0000833444-17-000044:notes:176]

[0000833444-18-000008:notes:174]
[same as prior period, unchanged from 0000833444-17-000044:notes:177]

[0000833444-18-000008:notes:175]
At September 30, 2017, the Company had gross tax effected unrecognized tax benefits of $2,173 million, of which $2,047 million, if recognized, would impact the effective tax rate. Total net accrued interest at September 30, 2017 was approximately $99 million (net of tax benefit). The interest and penalties accrued during the three months ended December 31, 2017 and 2016 were not material. The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense.

[0000833444-18-000008:notes:176]
In the first quarter of fiscal 2018, tax audit resolutions resulted in a net $25 million benefit to income tax expense.

[0000833444-18-000008:notes:177]
The Company is currently under exam in the following major non-U.S. jurisdictions:

[0000833444-18-000008:notes:178]
| Tax Jurisdiction |  | Tax Years Covered |
| Belgium |  | 2015 - 2016 |
| Brazil |  | 2011 - 2012 |
| Canada |  | 2013 - 2014 |
| China |  | 2008 - 2016 |
| France |  | 2010 - 2016 |
| Germany |  | 2007 - 2015 |
| Japan |  | 2016 |
| Spain |  | 2010 - 2014 |
| Switzerland |  | 2011 - 2014 |
| United Kingdom |  | 2011 - 2014 |

[0000833444-18-000008:notes:179]
[same as prior period, unchanged from 0000833444-17-000044:notes:182]

[0000833444-18-000008:notes:180]
On December 22, 2017, the “Tax Cuts and Jobs Act” (H.R. 1) was enacted and significantly revises U.S. corporate income tax by, among other things, lowering corporate income tax rates, imposing a one-time transition tax on deemed repatriated earnings of non-U.S. subsidiaries, and implementing a territorial tax system and various base erosion minimum tax provisions.

[0000833444-18-000008:notes:181]
In the first quarter of fiscal 2018, as a result of the enacted legislation, the Company recorded a discrete non-cash tax benefit of $101 million due to the remeasurement of U.S. deferred tax assets and liabilities.  The Company remeasured certain deferred tax assets and liabilities based on the rates at which they are expected to reverse in the future, which is generally 21% or the blended fiscal 2018 rate of 24.5%. This tax benefit is provisional as the Company is still analyzing certain aspects of the legislation and refining calculations, which could potentially materially affect the measurement of these amounts or give rise to new deferred tax amounts.

[0000833444-18-000008:notes:182]
In the first quarter of fiscal 2018, the Company also recorded a discrete tax charge of $305 million due to the one-time transition tax on deemed repatriated earnings of certain non-U.S. subsidiaries.  This charge is inclusive of relevant non-U.S. withholding taxes and U.S. state income tax on the portion of the earnings expected to be repatriated.  This one-time transition tax is based on the Company’s post-1986 earnings and profits (“E&P”) not previously subjected to U.S. taxation.  This tax charge is provisional as the Company has not yet finally determined its post-1986 non-U.S. E&P.  Further, the transition tax is based in part on the amount of those earnings held in cash and other specified assets. Given the varying tax rates (15.5% on cash and 8% on other property), this amount may change when the Company completes the calculation of post-1986 non-U.S. E&P previously deferred from U.S. federal taxation and concludes on the amounts held in cash versus other specified assets.

[0000833444-18-000008:notes:183]
Various impacts of the enacted legislation are still being evaluated by the Company and may materially differ from the estimated impacts recognized in the first quarter of fiscal 2018 due to future treasury regulations, tax law technical corrections, and other potential guidance, notices, rulings, refined computations, actions the Company may take as a result of the tax legislation, and other items. The SEC has issued rules that allow for a measurement period of up to one year after the enactment date of the legislation to finalize the recording of the related tax impacts.

[0000833444-18-000008:notes:184]
On October 13, 2016, the U.S. Treasury and the Internal Revenue Service (“IRS”) released final and temporary Section 385 regulations. These regulations address whether certain instruments between related parties are treated as debt or equity. The Company does not expect that the regulations will have a material impact on its consolidated financial statements.

[0000833444-18-000008:notes:185]
During the three months ended December 31, 2017 and 2016, other tax legislation was adopted in various jurisdictions. These law changes did not have a material impact on the Company's consolidated financial statements.

[0000833444-18-000008:notes:186]
[same as prior period, unchanged from 0000833444-17-000044:notes:185]

[0000833444-18-000008:notes:187]
In the first quarter of fiscal 2018, the Company recorded $50 million of transaction and integration costs.  These costs generated a $7 million tax benefit which was impacted by the Company’s current tax position in these jurisdictions.

[0000833444-18-000008:notes:188]
In the first quarter of fiscal 2018, the Company recorded $158 million of significant restructuring and impairment costs. Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $24 million tax benefit, which was impacted by the Company’s current tax position in these jurisdictions and the lower enacted U.S. tax rate.

[0000833444-18-000008:notes:189]
[same as prior period, unchanged from 0000833444-17-000044:notes:191]

[0000833444-18-000008:notes:190]
[same as prior period, unchanged from 0000833444-17-000044:notes:192]

[0000833444-18-000008:notes:191]
In the first quarter of fiscal 2017, the Company recorded $78 million of significant restructuring and impairment costs. Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $14 million tax benefit, which was impacted by the Company’s current tax position in these jurisdictions.


## us-gaap:InventoryDisclosureTextBlock

[0000833444-18-000008:notes:192]
[same as prior period, unchanged from 0000833444-17-000044:notes:196]

[0000833444-18-000008:notes:193]
[same as prior period, unchanged from 0000833444-17-000044:notes:197]

[0000833444-18-000008:notes:194]
|  | December 31, 2017 |  | September 30, 2017 |
| Raw materials and supplies | $ | 1,006 |  |  | $ | 919 |  |
| Work-in-process | 543 |  |  | 567 |  |
| Finished goods | 1,910 |  |  | 1,723 |  |
| Inventories | $ | 3,459 |  |  | $ | 3,209 |  |


## us-gaap:LongTermContractsOrProgramsDisclosureTextBlock

[0000833444-18-000008:notes:195]
[same as prior period, unchanged from 0000833444-17-000044:notes:199]

[0000833444-18-000008:notes:196]
The Building Technologies & Solutions business records certain long-term contracts under the percentage-of-completion method of accounting. Under this method, sales and gross profit are recognized as work is performed based on the relationship between actual costs incurred and total estimated costs at completion. The Company records costs and earnings in excess of billings on uncompleted contracts primarily within accounts receivable - net and billings in excess of costs and earnings on uncompleted contracts primarily within deferred revenue in the consolidated statements of financial position. Costs and earnings in excess of billings related to these contracts were $975 million and $908 million at December 31, 2017 and September 30, 2017, respectively. Billings in excess of costs and earnings related to these contracts were $567 million and $451 million at December 31, 2017 and September 30, 2017, respectively.


## us-gaap:MergersAcquisitionsAndDispositionsDisclosuresTextBlock

[0000833444-18-000008:notes:197]
[same as prior period, unchanged from 0000833444-17-000044:notes:214]

[0000833444-18-000008:notes:198]
In the first quarter of fiscal 2018, the Company completed the sale of its Scott Safety business to 3M Company. The selling price, net of cash divested, was $2.0 billion, all of which was received as of December 31, 2017. In connection with the sale, the Company recorded a pre-tax gain of $114 million within selling, general and administrative expenses in the consolidated statements of income and reduced goodwill in assets held for sale by $1.2 billion. The gain, net of tax, recorded was $84 million. Net cash proceeds from the transaction of approximately $1.9 billion were used to repay a significant portion of the Tyco International Holding S.a.r.L.'s ("TSarl") $4.0 billion of merger-related debt. The Scott Safety business is included in the Global Products segment and is reported within assets and liabilities held for sale in the consolidated statements of financial position as of September 30, 2017. Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further disclosure related to the Company's net assets held for sale.

[0000833444-18-000008:notes:199]
In the first quarter of fiscal 2017, the Company completed two acquisitions for a combined purchase price, net of cash acquired, of $6 million, $3 million of which was paid in the three months ended December 31, 2016. The acquisitions in the aggregate were not material to the Company’s consolidated financial statements. In connection with the acquisitions, the Company recorded goodwill of $1 million.

[0000833444-18-000008:notes:200]
In the first quarter of fiscal 2017, the Company completed one divestiture for a sales price of $4 million, none of which was received in the three months ended December 31, 2016. The divestiture decreased the Company's ownership from a controlling to noncontrolling interest, and as a result, the Company deconsolidated cash of $5 million. The divestiture was not material to the Company's consolidated financial statements.

[0000833444-18-000008:notes:201]
During the first quarter of fiscal 2017, the Company received $52 million in net cash proceeds related to prior year business divestitures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000833444-18-000008:notes:202]
[same as prior period, unchanged from 0000833444-17-000044:notes:224]

[0000833444-18-000008:notes:203]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2017 filed with the SEC on November 21, 2017. The results of operations for the three month period ended December 31, 2017 are not necessarily indicative of results for the Company’s 2018 fiscal year because of seasonal and other factors.

[0000833444-18-000008:notes:204]
[same as prior period, unchanged from 0000833444-17-000044:notes:226]

[0000833444-18-000008:notes:205]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global diversified technology and multi industrial leader serving a wide range of customers in more than 150 countries. The Company creates intelligent buildings, efficient energy solutions, integrated infrastructure and next generation transportation systems that work seamlessly together to deliver on the promise of smart cities and communities. The Company is committed to helping our customers win and creating greater value for all of its stakeholders through strategic focus on our buildings and energy growth platforms.

[0000833444-18-000008:notes:206]
In the fourth quarter of fiscal 2016, Johnson Controls, Inc. ("JCI Inc.") and Tyco International plc ("Tyco") completed their combination with JCI Inc. merging with a wholly-owned, indirect subsidiary of Tyco (the "Merger"). Following the Merger, Tyco changed its name to “Johnson Controls International plc” and JCI Inc. is a wholly-owned subsidiary of Johnson Controls International plc. The Merger was accounted for as a reverse acquisition using the acquisition method of accounting in accordance with Accounting Standards Codification ("ASC") 805, "Business Combinations." JCI Inc. was the accounting acquirer for financial reporting purposes. Accordingly, the historical consolidated financial statements of JCI Inc. for periods prior to this transaction are considered to be the historic financial statements of the Company.

[0000833444-18-000008:notes:207]
The Building Technologies & Solutions ("Buildings") business is a global market leader in engineering, developing, manufacturing and installing building products and systems around the world, including heating, ventilating, air-conditioning ("HVAC") equipment, HVAC controls, energy-management systems, security systems, fire detection systems and fire suppression solutions. The Buildings business further serves customers by providing technical services (in the HVAC, security and fire-protection space), energy-management consulting and data-driven solutions via its recently launch data-enabled business. Finally, the Company is a North American market leader in residential air conditioning and heating systems and a global market leader in industrial refrigeration products.

[0000833444-18-000008:notes:208]
The Power Solutions business is a leading global supplier of lead-acid automotive batteries for virtually every type of passenger car, light truck and utility vehicle. The Company serves both automotive original equipment manufacturers and the general vehicle battery aftermarket. The Company also supplies advanced battery technologies to power start-stop, hybrid and electric vehicles.

[0000833444-18-000008:notes:209]
[same as prior period, unchanged from 0000833444-17-000044:notes:230]

[0000833444-18-000008:notes:210]
[same as prior period, unchanged from 0000833444-17-000044:notes:231]

[0000833444-18-000008:notes:211]
Under certain criteria as provided for in Financial Accounting Standards Board ("FASB") ASC 810, "Consolidation," the Company may consolidate a partially-owned affiliate. To determine whether to consolidate a partially-owned affiliate, the Company first determines if the entity is a variable interest entity ("VIE"). An entity is considered to be a VIE if it has one of the following characteristics: 1) the entity is thinly capitalized; 2) residual equity holders do not control the entity; 3) equity holders are shielded from economic losses or do not participate fully in the entity’s residual economics; or 4) the entity was established with non-substantive voting rights. If the entity meets one of these characteristics, the Company then determines if it is the primary beneficiary of the VIE. The party with the power to direct activities of the VIE that most significantly impact the VIE’s economic performance and the potential to absorb benefits or losses that could be significant to the VIE is considered the primary beneficiary and consolidates the VIE. If the entity is not considered a VIE, then the Company applies the voting interest model to determine whether or not the Company shall consolidate the partially-owned affiliate.

[0000833444-18-000008:notes:212]
[same as prior period, unchanged from 0000833444-17-000044:notes:233]

[0000833444-18-000008:notes:213]
Based upon the criteria set forth in ASC 810, the Company has determined that it was not the primary beneficiary in any VIEs for the reporting period ended December 31, 2017 and that it was the primary beneficiary in one VIE for the reporting period ended September 30, 2017, as the Company absorbed significant economics of the entity and had the power to direct the activities that are considered most significant to the entity.

[0000833444-18-000008:notes:214]
In fiscal 2012, a pre-existing VIE accounted for under the equity method was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The Company acquired additional interests in two of the reorganized group entities. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company was considered the primary beneficiary of one of the entities due to the Company’s power pertaining to decisions over significant activities of the entity. As such, this VIE was consolidated within the Company’s consolidated statements of financial position as of September 30, 2017. The impact of the entity on the Company’s consolidated statements of income for the three month periods ended December 31, 2017 and 2016 were not material. During the quarter ended December 31, 2017, certain joint venture agreements were amended, and as a result, the Company can no longer make key operating decisions considered to be most significant to the VIE. As such, the Company is no longer considered the primary beneficiary of this entity, and the Company deconsolidated the entity during the quarter ended December 31, 2017.

[0000833444-18-000008:notes:215]
The carrying amounts and classification of assets (none of which are restricted) and liabilities included in the Company’s consolidated statements of financial position for the consolidated VIE is as follows (in millions):

[0000833444-18-000008:notes:216]
|  |  | September 30,2017 |
| Current assets |  | $ | 2 |  |
| Noncurrent assets |  | 53 |  |
| Total assets |  | $ | 55 |  |
| Current liabilities |  | $ | 6 |  |
| Noncurrent liabilities |  | 42 |  |
| Total liabilities |  | $ | 48 |  |

[0000833444-18-000008:notes:217]
[same as prior period, unchanged from 0000833444-17-000044:notes:239]

[0000833444-18-000008:notes:218]
[same as prior period, unchanged from 0000833444-17-000044:notes:240]

[0000833444-18-000008:notes:219]
As mentioned previously within the "Consolidated VIEs" section above, in fisca1 2012, a pre-existing VIE was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The VIEs are named as co-obligors under a third party debt agreement in the amount of $162 million, maturing in fiscal 2020, under which a VIE could become subject to paying more than its allocated share of the third party debt in the event of bankruptcy of one or more of the other co-obligors. The other co-obligors, all related parties in which the Company is an equity investor, consist of the remaining group entities involved in the reorganization. As part of the overall reorganization transaction, the Company has also provided financial support to the group entities in the form of loans totaling $37 million, which are subordinate to the third party debt agreement. The Company is a significant customer of certain co-obligors, resulting in a remote possibility of loss. Additionally, the Company is subject to a floor guaranty expiring in fiscal 2022; in the event that the other owner party no longer owns any part of the group entities due to sale or transfer, the Company has guaranteed that the proceeds received from the sale or transfer will not be less than $25 million. The Company has partnered with the group entities to design and manufacture battery components for the Power Solutions business. The Company is not considered to be the primary beneficiary of three of the entities as of December 31, 2017 and two of the entities as of September 30, 2017, as the Company cannot make key operating decisions considered to be most significant to the VIEs. Therefore, the entities are accounted for under the equity method of accounting as the Company’s interest exceeds 20% and the Company does not have a controlling interest. The Company’s maximum exposure to loss includes the partially-owned affiliate investment balances of $38 million and $65 million at December 31, 2017 and September 30, 2017, respectively, as well as the subordinated loan from the Company, third party debt agreement and floor guaranty mentioned above. Current liabilities due to the VIEs are not material and represent normal course of business trade payables for all presented periods.

[0000833444-18-000008:notes:220]
[same as prior period, unchanged from 0000833444-17-000044:notes:242]

[0000833444-18-000008:notes:221]
[same as prior period, unchanged from 0000833444-17-000044:notes:243]

[0000833444-18-000008:notes:222]
At December 31, 2017, the Company held restricted cash of approximately $19 million, of which $10 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. At September 30, 2017, the Company held restricted cash of approximately $31 million, of which $22 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash restricted for payment of asbestos liabilities.

[0000833444-18-000008:notes:223]
[same as prior period, unchanged from 0000833444-17-000044:notes:245]

[0000833444-18-000008:notes:224]
Effective July 1, 2017, the Company reorganized the reportable segments within its Building Technologies & Solutions business to align with its new management reporting structure and business activities. Prior to this reorganization, Building Technologies & Solutions was comprised of five reportable segments for financial reporting purposes: Systems and Service North America, Products North America, Asia, Rest of World and Tyco. As a result of this change, Building Technologies & Solutions is now comprised of four reportable segments for financial reporting purposes: Building Solutions North America, Building Solutions EMEA/LA, Building Solutions Asia Pacific and Global Products. Refer to Note 18, “Segment Information,” of the notes to consolidated financial statements for further information. The net sales and cost of sales split of products and systems versus services in the consolidated statements of income has also been revised for the Building Technologies & Solutions reorganization.

[0000833444-18-000008:notes:225]
In March 2016, the FASB issued Accounting Standards Update ("ASU") No. 2016-09, "Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting." During the quarter ended December 31, 2017, the Company adopted ASU No. 2016-09. As a result, employee withholding taxes paid to taxing authorities for equity-based compensation transactions, previously classified as cash flows from operating activities, were reclassified to financing activities in the consolidated statements of cash flows for the three months ended December 31, 2016. Refer to Note 2, "New Accounting Standards," of the notes to consolidated financial statements for further information.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-18-000008:notes:226]
[same as prior period, unchanged from 0000833444-17-000044:notes:251]

[0000833444-18-000008:notes:227]
[same as prior period, unchanged from 0000833444-17-000044:notes:252]

[0000833444-18-000008:notes:228]
|  | U.S. Pension Plans |
|  | Three Months EndedDecember 31, |
|  | 2017 |  | 2016 |
| Service cost | $ | 4 |  |  | $ | 5 |  |
| Interest cost | 26 |  |  | 28 |  |
| Expected return on plan assets | (57 | ) |  | (59 | ) |
| Net actuarial gain | — |  |  | (117 | ) |
| Settlement gain | — |  |  | (8 | ) |
| Net periodic benefit credit | $ | (27 | ) |  | $ | (151 | ) |

[0000833444-18-000008:notes:229]
|  | Non-U.S. Pension Plans |
|  | Three Months EndedDecember 31, |
|  | 2017 |  | 2016 |
| Service cost | $ | 6 |  |  | $ | 8 |  |
| Interest cost | 14 |  |  | 12 |  |
| Expected return on plan assets | (29 | ) |  | (23 | ) |
| Net periodic benefit credit | $ | (9 | ) |  | $ | (3 | ) |

[0000833444-18-000008:notes:230]
|  | Postretirement Benefits |
|  | Three Months EndedDecember 31, |
|  | 2017 |  | 2016 |
| Service cost | $ | — |  |  | $ | 1 |  |
| Interest cost | 2 |  |  | 1 |  |
| Expected return on plan assets | (2 | ) |  | (3 | ) |
| Net periodic benefit credit | $ | — |  |  | $ | (1 | ) |

[0000833444-18-000008:notes:231]
During the three months ended December 31, 2016, the amount of lump sum payouts triggered a remeasurement event for certain U.S. pension plans resulting in the recognition of net actuarial gains of $117 million.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000833444-18-000008:notes:232]
Related Party Transactions

[0000833444-18-000008:notes:233]
In the ordinary course of business, the Company enters into transactions with related parties, such as equity affiliates. Such transactions consist of facility management services, the sale or purchase of goods and other arrangements.

[0000833444-18-000008:notes:234]
The net sales to and purchases from related parties included in the consolidated statements of income were $242 million and $41 million, respectively, for the three months ended December 31, 2017; and $225 million and $49 million, respectively, for the three months ended December 31, 2016.

[0000833444-18-000008:notes:235]
The following table sets forth the amount of accounts receivable due from and payable to related parties in the consolidated statements of financial position (in millions):

[0000833444-18-000008:notes:236]
|  |  | December 31, 2017 |  | September 30, 2017 |  |
| Receivable from related parties |  | $ | 122 |  |  | $ | 108 |  |
| Payable to related parties |  | 34 |  |  | 50 |  |

[0000833444-18-000008:notes:237]
The Company has also provided financial support to certain of its VIE's; see Note 1, "Financial Statements," of the notes to consolidated financial statements for additional information.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000833444-18-000008:notes:238]
[same as prior period, unchanged from 0000833444-17-000044:notes:263]

[0000833444-18-000008:notes:239]
[same as prior period, unchanged from 0000833444-17-000044:notes:264]

[0000833444-18-000008:notes:240]
In fiscal 2018, the Company committed to a significant restructuring plan (2018 Plan) and recorded $158 million of restructuring and impairment costs in the consolidated statements of income. This was the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. Of the restructuring and impairment costs recorded, $76 million related to the Global Products segment, $32 million related to the Building Solutions EMEA/LA segment, $24 million related to Corporate, $14 million related to the Building Solutions Asia Pacific segment, $8 million related to the Building Solutions North America segment and $4 million related to the Power Solutions segment. The restructuring actions are expected to be substantially complete in 2020.

[0000833444-18-000008:notes:241]
The following table summarizes the changes in the Company’s 2018 Plan reserve, included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-18-000008:notes:242]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | Total |
| Original reserve | $ | 125 |  |  | $ | 30 |  |  | $ | 3 |  |  | $ | 158 |  |
| Utilized—noncash | — |  |  | (30 | ) |  | — |  |  | (30 | ) |
| Balance at December 31, 2017 | $ | 125 |  |  | $ | — |  |  | $ | 3 |  |  | $ | 128 |  |

[0000833444-18-000008:notes:243]
In fiscal 2017, the Company committed to a significant restructuring plan (2017 Plan) and recorded $367 million of restructuring and impairment costs in the consolidated statements of income. This was the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. Of the restructuring and impairment costs recorded, $166 million related to Corporate, $74 million related to the Building Solutions EMEA/LA segment, $59 million related to the Building Solutions North America segment, $32 million related to the Global Products segment, $20 million related to the Power Solutions segment and $16 million related to the Building Solutions Asia Pacific segment. The restructuring actions are expected to be substantially complete in fiscal 2018.

[0000833444-18-000008:notes:244]
[same as prior period, unchanged from 0000833444-17-000044:notes:266]

[0000833444-18-000008:notes:245]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | Total |
| Original reserve | $ | 276 |  |  | $ | 77 |  |  | $ | 14 |  |  | $ | 367 |  |
| Utilized—cash | (75 | ) |  | — |  |  | — |  |  | (75 | ) |
| Utilized—noncash | — |  |  | (77 | ) |  | (1 | ) |  | (78 | ) |
| Adjustment to restructuring reserves | 25 |  |  | — |  |  | — |  |  | 25 |  |
| Balance at September 30, 2017 | $ | 226 |  |  | $ | — |  |  | $ | 13 |  |  | $ | 239 |  |
| Utilized—cash | (26 | ) |  | — |  |  | (2 | ) |  | (28 | ) |
| Balance at December 31, 2017 | $ | 200 |  |  | $ | — |  |  | $ | 11 |  |  | $ | 211 |  |

[0000833444-18-000008:notes:246]
In fiscal 2016, the Company committed to a significant restructuring plan (2016 Plan) and recorded $288 million of restructuring and impairment costs in the consolidated statements of income. This was the total amount incurred to date and the total amount expected to be incurred for this restructuring plan. The restructuring actions related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments and change-in-control payments. Of the restructuring and impairment costs recorded, $161 million related to Corporate, $66 million related to the Power Solutions segment, $44 million related to the Global Products segment and $17 million related to the Building Solutions EMEA/LA segment. The restructuring actions are expected to be substantially complete in fiscal 2018. Included in the reserve is $56 million of committed restructuring actions taken by Tyco for liabilities assumed as part of the Tyco acquisition.

[0000833444-18-000008:notes:247]
[same as prior period, unchanged from 0000833444-17-000044:notes:269]

[0000833444-18-000008:notes:248]
The following table summarizes the changes in the Company’s 2016 Plan reserve, included within other current liabilities in the consolidated statements of financial position (in millions):

[0000833444-18-000008:notes:249]
|  | Employee Severance and Termination Benefits |  | Long-Lived Asset Impairments |  | Other |  | CurrencyTranslation |  | Total |
| Original reserve | $ | 368 |  |  | $ | 190 |  |  | $ | 62 |  |  | $ | — |  |  | $ | 620 |  |
| Acquired Tyco restructuring reserves | 78 |  |  | — |  |  | — |  |  | — |  |  | 78 |  |
| Utilized—cash | (32 | ) |  | — |  |  | — |  |  | — |  |  | (32 | ) |
| Utilized—noncash | — |  |  | (190 | ) |  | (32 | ) |  | 1 |  |  | (221 | ) |
| Balance at September 30, 2016 | $ | 414 |  |  | $ | — |  |  | $ | 30 |  |  | $ | 1 |  |  | $ | 445 |  |
| Adient spin-off impact | (194 | ) |  | — |  |  | (22 | ) |  | — |  |  | (216 | ) |
| Utilized—cash | (86 | ) |  | — |  |  | (2 | ) |  | — |  |  | (88 | ) |
| Utilized—noncash | — |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Adjustment to restructuring reserves | (25 | ) |  | — |  |  | — |  |  | — |  |  | (25 | ) |
| Transfer to liabilities held for sale | (3 | ) |  | — |  |  | — |  |  | — |  |  | (3 | ) |
| Adjustment to acquired Tyco restructuring reserves | (22 | ) |  | — |  |  | — |  |  | — |  |  | (22 | ) |
| Balance at September 30, 2017 | $ | 84 |  |  | $ | — |  |  | $ | 6 |  |  | $ | 2 |  |  | $ | 92 |  |
| Utilized—cash | (5 | ) |  | — |  |  | (1 | ) |  | — |  |  | (6 | ) |
| Balance at December 31, 2017 | $ | 79 |  |  | $ | — |  |  | $ | 5 |  |  | $ | 2 |  |  | $ | 86 |  |

[0000833444-18-000008:notes:250]
The Company's fiscal 2018, 2017 and 2016 restructuring plans included workforce reductions of approximately 9,200 employees (7,300 for the Building Technologies & Solutions business, 1,700 for Corporate and 200 for Power Solutions). Restructuring charges associated with employee severance and termination benefits are paid over the severance period granted to each employee or on a lump sum basis in accordance with individual severance agreements. As of December 31, 2017, approximately 1,800 of the employees have been separated from the Company pursuant to the restructuring plans. In addition, the restructuring plans included eleven plant closures in the Building Technologies & Solutions business. As of December 31, 2017, four of the eleven plants have been closed.

[0000833444-18-000008:notes:251]
[same as prior period, unchanged from 0000833444-17-000044:notes:273]


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000833444-18-000008:notes:252]
The following schedules present changes in accumulated other comprehensive income ("AOCI") attributable to Johnson Controls (in millions, net of tax):

[0000833444-18-000008:notes:253]
|  | Three Months EndedDecember 31, |
|  | 2017 |  | 2016 |
| Foreign currency translation adjustments ("CTA") |  |  |  |
| Balance at beginning of period | $ | (481 | ) |  | $ | (1,152 | ) |
| Aggregate adjustment for the period (net of tax effect of $1 and $5)* | 58 |  |  | (659 | ) |
| Adient spin-off impact (net of tax effect of $0) | — |  |  | 563 |  |
| Balance at end of period | (423 | ) |  | (1,248 | ) |
| Realized and unrealized gains (losses) on derivatives |  |  |  |
| Balance at beginning of period | 6 |  |  | 4 |  |
| Current period changes in fair value (net of tax effect of $3 and $4) | 6 |  |  | 6 |  |
| Reclassification to income (net of tax effect of $(2) and $(3)) ** | (5 | ) |  | (6 | ) |
| Adient spin-off impact (net of tax effect of $0 and $6) | — |  |  | 16 |  |
| Balance at end of period | 7 |  |  | 20 |  |
| Realized and unrealized gains (losses) on marketable securities |  |  |  |
| Balance at beginning of period | 4 |  |  | (1 | ) |
| Current period changes in fair value (net of tax effect of $0) | — |  |  | (2 | ) |
| Balance at end of period | 4 |  |  | (3 | ) |
| Pension and postretirement plans |  |  |  |
| Balance at beginning of period | (2 | ) |  | (4 | ) |
| Adient spin-off impact (net of tax effect of $0) | — |  |  | 2 |  |
| Balance at end of period | (2 | ) |  | (2 | ) |
| Accumulated other comprehensive loss, end of period | $ | (414 | ) |  | $ | (1,233 | ) |

[0000833444-18-000008:notes:254]
* During the three months ended December 31, 2017, $12 million of cumulative CTA were recognized as part of the divestiture-related gain recognized as a result of the divestiture of Scott Safety.

[0000833444-18-000008:notes:255]
** Refer to Note 15, "Derivative Instruments and Hedging Activities," of the notes to consolidated financial statements for disclosure of the line items in the consolidated statements of income affected by reclassifications from AOCI into income related to derivatives.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000833444-18-000008:notes:256]
[same as prior period, unchanged from 0000833444-17-000044:notes:279]

[0000833444-18-000008:notes:257]
|  | Net Sales |
|  | Three Months EndedDecember 31, |
|  | 2017 |  | 2016 |
| Building Technologies & Solutions |  |  |  |
| Building Solutions North America | $ | 2,012 |  |  | $ | 1,942 |  |
| Building Solutions EMEA/LA | 915 |  |  | 875 |  |
| Building Solutions Asia Pacific | 597 |  |  | 575 |  |
| Global Products | 1,781 |  |  | 1,794 |  |
|  | 5,305 |  |  | 5,186 |  |
| Power Solutions | 2,130 |  |  | 1,900 |  |
| Total net sales | $ | 7,435 |  |  | $ | 7,086 |  |

[0000833444-18-000008:notes:258]
|  | Segment EBITA |
|  | Three Months EndedDecember 31, |
|  | 2017 |  | 2016 |
| Building Technologies & Solutions |  |  |  |
| Building Solutions North America | $ | 227 |  |  | $ | 196 |  |
| Building Solutions EMEA/LA | 69 |  |  | 49 |  |
| Building Solutions Asia Pacific | 74 |  |  | 63 |  |
| Global Products | 286 |  |  | 127 |  |
|  | 656 |  |  | 435 |  |
| Power Solutions | 384 |  |  | 389 |  |
| Total segment EBITA | $ | 1,040 |  |  | $ | 824 |  |
| Corporate expenses | $ | (134 | ) |  | $ | (193 | ) |
| Amortization of intangible assets | (94 | ) |  | (149 | ) |
| Restructuring and impairment costs | (158 | ) |  | (78 | ) |
| Net mark-to-market adjustments on pension plans | — |  |  | 117 |  |
| Net financing charges | (116 | ) |  | (136 | ) |
| Income from continuing operations before income taxes | $ | 538 |  |  | $ | 385 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-18-000008:notes:259]
[same as prior period, unchanged from 0000833444-17-000044:notes:282]

[0000833444-18-000008:notes:260]
ASC 280, "Segment Reporting," establishes the standards for reporting information about segments in financial statements. In applying the criteria set forth in ASC 280, the Company has determined that it has five reportable segments for financial reporting purposes. The Company’s five reportable segments are presented in the context of its two primary businesses – Building Technologies & Solutions and Power Solutions.

[0000833444-18-000008:notes:261]
Effective July 1, 2017, the Company reorganized the reportable segments within its Building Technologies & Solutions business to align with its new management reporting structure and business activities. Prior to this reorganization, Building Technologies & Solutions was comprised of five reportable segments for financial reporting purposes: Systems and Service North America, Products North America, Asia, Rest of World and Tyco. As a result of this change, Building Technologies & Solutions is now comprised of four reportable segments for financial reporting purposes: Building Solutions North America, Building Solutions EMEA/LA, Building Solutions Asia Pacific and Global Products. Historical information has been revised to reflect the new Building Technologies & Solutions segments.

[0000833444-18-000008:notes:262]
A summary of the significant Building Technologies & Solutions reportable segment changes is as follows:

[0000833444-18-000008:notes:263]
| • | The “Systems and Service North America” segment is now part of the new “Building Solutions North America” reportable segment. |

[0000833444-18-000008:notes:264]
| • | The North America Unitary Products business, Air Distribution Technologies business and refrigeration systems business, as well as HVAC products installed for Marine customers, previously included in the “Products North America” segment, are now part of the new reportable segment “Global Products.” The systems and products installation business for U.S. Navy customers, previously included in the “Products North America” segment, is now part of the new “Building Solutions North America” reportable segment. |

[0000833444-18-000008:notes:265]
| • | The systems and service business within the former “Asia” segment is now part of the new “Building Solutions Asia Pacific” reportable segment. The HVAC products manufacturing business and the Johnson Controls-Hitachi joint venture, previously part of the “Asia” segment, are now part of the new “Global Products” reportable segment. |

[0000833444-18-000008:notes:266]
| • | The systems and service businesses in Europe, the Middle East and Latin America within the former “Rest of World” segment are now part of the new “Building Solutions EMEA/LA” reportable segment. The HVAC products manufacturing businesses, previously part of the “Rest of World” segment, are now part of the new “Global Products” reportable segment. |

[0000833444-18-000008:notes:267]
| • | As the Company has integrated the legacy Tyco business with its legacy Building Efficiency business for segment reporting purposes, Tyco is no longer a separate reportable segment. The Tyco businesses are now included throughout the new reportable segments. |

[0000833444-18-000008:notes:268]
[same as prior period, unchanged from 0000833444-17-000044:notes:286]

[0000833444-18-000008:notes:269]
| • | Building Solutions North America designs, sells, installs, and services HVAC and controls systems, integrated electronic security systems (including monitoring), and integrated fire detection and suppression systems for commercial, industrial, retail, small business, institutional and governmental customers in North America. Building Solutions North America also provides energy efficiency solutions and technical services, including inspection, scheduled maintenance, and repair and replacement of mechanical and control systems, to non-residential building and industrial applications in the North American marketplace. |

[0000833444-18-000008:notes:270]
| • | Building Solutions EMEA/LA designs, sells, installs, and services HVAC, controls, refrigeration, integrated electronic security, integrated fire detection and suppression systems, and provides technical services to markets in Europe, the Middle East, Africa and Latin America. |

[0000833444-18-000008:notes:271]
| • | Building Solutions Asia Pacific designs, sells, installs, and services HVAC, controls, refrigeration, integrated electronic security, integrated fire detection and suppression systems, and provides technical services to the Asia Pacific marketplace. |

[0000833444-18-000008:notes:272]
| • | Global Products designs and produces heating and air conditioning for residential and commercial applications, and markets products and refrigeration systems to replacement and new construction market customers globally. The Global Products business also designs, manufactures and sells fire protection and security products, including intrusion security, anti-theft devices, and access control and video management systems, for commercial, industrial, retail, residential, small business, institutional and governmental customers worldwide. Global Products also includes the Johnson Controls-Hitachi joint venture, which was formed October 1, 2015, and included the Scott Safety business, prior to its sale on October 4, 2017. |

[0000833444-18-000008:notes:273]
[same as prior period, unchanged from 0000833444-17-000044:notes:295]

[0000833444-18-000008:notes:274]
[same as prior period, unchanged from 0000833444-17-000044:notes:296]

[0000833444-18-000008:notes:275]
Management evaluates the performance of its business segments primarily on segment earnings before interest, taxes and amortization ("EBITA"), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, significant restructuring and impairment costs, and the net mark-to-market adjustments related to pension and postretirement plans.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-18-000008:notes:276]
[same as prior period, unchanged from 0000833444-17-000044:notes:297]

[0000833444-18-000008:notes:277]
[same as prior period, unchanged from 0000833444-17-000044:notes:298]

[0000833444-18-000008:notes:278]
As previously disclosed, during the quarter ended December 31, 2017, the Company adopted ASU No. 2016-09. As a result, the Company recognized deferred tax assets of $179 million related to certain operating loss carryforwards resulting from the exercise of employee stock options and restricted stock vestings on a modified retrospective basis through a cumulative-effect adjustment to retained earnings as of October 1, 2017.

[0000833444-18-000008:notes:279]
As previously disclosed, on October 31, 2016, the Company completed the Adient spin-off. As a result of the spin-off, the Company divested net assets of approximately $4.0 billion.

[0000833444-18-000008:notes:280]
Following the Tyco Merger, the Company adopted, subject to the ongoing existence of sufficient distributable reserves, the existing Tyco International plc $1 billion share repurchase program in September 2016. In December 2017, the Company's Board of Directors approved an $1 billion increase to its share repurchase authorization. The share repurchase program does not have an expiration date and may be amended or terminated by the Board of Directors at any time without prior notice. For the three month period ended December 31, 2017, the Company repurchased $150 million of its ordinary shares. For the three month period ended December 31, 2016, the Company had no repurchases of its ordinary shares.  As of December 31, 2017, approximately $1.2 billion remains available under the share repurchase program.

[0000833444-18-000008:notes:281]
[same as prior period, unchanged from 0000833444-17-000044:notes:303]

[0000833444-18-000008:notes:282]
[same as prior period, unchanged from 0000833444-17-000044:notes:304]

[0000833444-18-000008:notes:283]
|  | Three Months EndedDecember 31, |
|  | 2017 |  | 2016 |
| Beginning balance, September 30 | $ | 211 |  |  | $ | 234 |  |
| Net income | 13 |  |  | 13 |  |
| Foreign currency translation adjustments | 5 |  |  | (9 | ) |
| Realized and unrealized losses on derivatives | (3 | ) |  | — |  |
| Dividends | — |  |  | (43 | ) |
| Spin-off of Adient | — |  |  | (36 | ) |
| Ending balance, December 31 | $ | 226 |  |  | $ | 159 |  |
