# JCI note change history — 0000833444-17-000044 → 0000833444-18-000008


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-02-02):
[0000833444-18-000008:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of December 31, 2017, reserves for environmental liabilities totaled $48 million, of which $10 million was recorded within other current liabilities and $38 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $51 million at September 30, 2017. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities, primarily in the Power Solutions and Building Technologies & Solutions businesses. At December 31, 2017 and September 30, 2017, the Company recorded conditional asset retirement obligations of $62 million and $61 million, respectively.
  (was, 2017-08-03, similarity 0.9731):
[0000833444-17-000044:note_history:1]
The Company accrues for potential environmental liabilities when it is probable a liability has been incurred and the amount of the liability is reasonably estimable. As of June 30, 2017, reserves for environmental liabilities totaled $48 million, of which $12 million was recorded within other current liabilities and $36 million was recorded within other noncurrent liabilities in the consolidated statements of financial position. Reserves for environmental liabilities for continuing operations totaled $51 million at September 30, 2016. Such potential liabilities accrued by the Company do not take into consideration possible recoveries of future insurance proceeds. They do, however, take into account the likely share other parties will bear at remediation sites. It is difficult to estimate the Company’s ultimate level of liability at many remediation sites due to the large number of other parties that may be involved, the complexity of determining the relative liability among those parties, the uncertainty as to the nature and scope of the investigations and remediation to be conducted, the uncertainty in the application of law and risk assessment, the various choices and costs associated with diverse technologies that may be used in corrective actions at the sites, and the often quite lengthy periods over which eventual remediation may occur. Nevertheless, the Company does not currently believe that any claims, penalties or costs in connection with known environmental matters will have a material adverse effect on the Company’s financial position, results of operations or cash flows. In addition, the Company has identified asset retirement obligations for environmental matters that are expected to be addressed at the retirement, disposal, removal or abandonment of existing owned facilities. At June 30, 2017 and September 30, 2016, the Company recorded conditional asset retirement obligations of $72 million and $74 million, respectively.

- changed (2018-02-02):
[0000833444-18-000008:note_history:2]
As of December 31, 2017, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $166 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $559 million, of which $54 million was recorded in other current liabilities and $505 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $393 million, of which $55 million was recorded in other current assets, and $338 million was recorded in other noncurrent assets. Assets included $10 million of cash and $283 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at December 31, 2017 was $100 million. As of September 30, 2017, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $181 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $573 million, of which $48 million was recorded in other current liabilities and $525 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $392 million, of which $53 million was recorded in other current assets, and $339 million was recorded in other noncurrent assets. Assets included $22 million of cash and $269 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2017 was $101 million.
  (was, 2017-08-03, similarity 0.9618):
[0000833444-17-000044:note_history:2]
As of June 30, 2017, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $147 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $535 million, of which $35 million was recorded in other current liabilities and $500 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $388 million, of which $52 million was recorded in other current assets, and $336 million was recorded in other noncurrent assets. Assets included $28 million of cash and $264 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at June 30, 2017 was $96 million. As of September 30, 2016, the Company's estimated asbestos related net liability recorded on a discounted basis within the Company's consolidated statements of financial position was $148 million. The net liability within the consolidated statements of financial position was comprised of a liability for pending and future claims and related defense costs of $548 million, of which $35 million was recorded in other current liabilities and $513 million was recorded in other noncurrent liabilities. The Company also maintained separate cash, investments and receivables related to insurance recoveries within the consolidated statements of financial position of $400 million, of which $41 million was recorded in other current assets, and $359 million was recorded in other noncurrent assets. Assets included $16 million of cash and $264 million of investments, which have all been designated as restricted. In connection with the recognition of liabilities for asbestos-related matters, the Company records asbestos-related insurance recoveries that are probable; the amount of such recoveries recorded at September 30, 2016 was $120 million. The Company believes that the asbestos related liabilities and insurance related receivables recorded as of June 30, 2017 and September 30, 2016 are appropriate.

- changed (2018-02-02):
[0000833444-18-000008:note_history:3]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2068 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2068. At least annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.
  (was, 2017-08-03, similarity 0.9972):
[0000833444-17-000044:note_history:3]
The Company's estimate of the liability and corresponding insurance recovery for pending and future claims and defense costs is based on the Company's historical claim experience, and estimates of the number and resolution cost of potential future claims that may be filed and is discounted to present value from 2069 (which is the Company's reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates). Asbestos related defense costs are included in the asbestos liability. The Company's legal strategy for resolving claims also impacts these estimates. The Company considers various trends and developments in evaluating the period of time (the look-back period) over which historical claim and settlement experience is used to estimate and value claims reasonably projected to be made through 2069. Annually, the Company assesses the sufficiency of its estimated liability for pending and future claims and defense costs by evaluating actual experience regarding claims filed, settled and dismissed, and amounts paid in settlements. In addition to claims and settlement experience, the Company considers additional quantitative and qualitative factors such as changes in legislation, the legal environment, and the Company's defense strategy. The Company also evaluates the recoverability of its insurance receivable on an annual basis. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance receivable is warranted.

- changed (2018-02-02):
[0000833444-18-000008:note_history:4]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At December 31, 2017 and September 30, 2017, the insurable liabilities totaled $434 million and $445 million, respectively, of which $92 million and $122 million was recorded within other current liabilities, $23 million and $22 million was recorded within accrued compensation and benefits, and $319 million and $301 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at December 31, 2017 was $21 million, of which $6 million was recorded within other current assets and $15 million was recorded within other noncurrent assets.  The amount of such receivables recorded at September 30, 2017 was $46 million, of which $31 million was recorded within other current assets and $15 million was recorded within other noncurrent assets. The Company maintains captive insurance companies to manage certain of its insurable liabilities.
  (was, 2017-08-03, similarity 0.7636):
[0000833444-17-000044:note_history:4]
The Company records liabilities for its workers' compensation, product, general, property and auto liabilities. The determination of these liabilities and related expenses is dependent on claims experience. For most of these liabilities, claims incurred but not yet reported are estimated by utilizing actuarial valuations based upon historical claims experience. At June 30, 2017 and September 30, 2016, the insurable liabilities for continuing operations totaled $488 million and $422 million, respectively, of which $86 million and $60 million was recorded within other current liabilities, $30 million and $28 million was recorded within accrued compensation and benefits, and $372 million and $334 million was recorded within other noncurrent liabilities in the consolidated statements of financial position, respectively. The Company records receivables from third party insurers when recovery has been determined to be probable. The amount of such receivables recorded at June 30, 2017 was $49 million, of which $30 million was recorded within other current assets and $19 million was recorded within other noncurrent assets. Insurance receivables recorded at September 30, 2016 were $21 million, primarily recorded within other noncurrent assets. The Company maintains captive insurance companies to manage certain of its insurable liabilities.

- added (2018-02-02):
[0000833444-18-000008:note_history:5]
Arbitration Award

- added (2018-02-02):
[0000833444-18-000008:note_history:6]
In September 2017, the Company was subject to an unfavorable arbitration award of approximately $50 million relating to a contractual dispute with a subcontractor used by the Company at an airport construction project in Doha, Qatar. In connection with the unfavorable arbitration award, the Company recorded a charge of $50 million within selling, general and administrative expenses in the consolidated statements of income in the fourth quarter of fiscal 2017. The airport project is being managed by a steering committee. The Company and the subcontractor were working jointly to document claims for increased costs against the steering committee when the subcontractor initiated the arbitration proceeding against the Company. Pursuant to its arbitration proceeding against the Company, the subcontractor sought to recover costs it alleges it incurred due to project delays, additional work and related financing costs. The Company has filed annulment proceedings with respect to the arbitration award in the local court in Qatar. While the award remains outstanding, a portion of the balance will accrue interest at a statutory rate of 9.56%.

- added (2018-02-02):
[0000833444-18-000008:note_history:7]
In a related action, the Company has initiated an arbitration claim against the steering committee related to costs it incurred in connection with delays of the airport construction project, including costs related to the above award. The arbitrator is expected to issue a decision on the Company’s claims against the steering committee by the end of fiscal 2018.

- added (2018-02-02):
[0000833444-18-000008:note_history:8]
Aqueous Film-Forming Foam Litigation

- added (2018-02-02):
[0000833444-18-000008:note_history:9]
Two of our subsidiaries, Chemguard, Inc. ("Chemguard") and Tyco Fire Products L.P. ("Tyco Fire Products"), have been named, along with other defendant manufacturers, in a number of class action lawsuits relating to the use of fire-fighting foam products by the U.S. Department of Defense (the "DOD") and others for fire suppression purposes and related training exercises. Plaintiffs generally allege that the firefighting foam products manufactured by defendants contain or break down into the chemicals perfluorooctane sulfonate ("PFOS") and perfluorooctanoic acid ("PFOA") and that the use of these products by others at various airbases and airports resulted in the release of these chemicals into the environment and ultimately into communities’ drinking water supplies neighboring those airports and airbases. Plaintiffs generally seek compensatory damages, including damages for alleged personal injuries, medical monitoring, and alleged diminution in property values, and also seek punitive damages and injunctive relief to address remediation of the alleged contamination. As of February 2, 2018, the Company is named in 12 putative class actions in federal courts in three states as set forth below:

- added (2018-02-02):
[0000833444-18-000008:note_history:10]
Colorado

- added (2018-02-02):
[0000833444-18-000008:note_history:11]
•District of Colorado - Bell et al. v. The 3M Company et al., filed on September 18, 2016.

- added (2018-02-02):
[0000833444-18-000008:note_history:12]
•District of Colorado - Bell et al. v. The 3M Company et al., filed on September 18, 2016.

- added (2018-02-02):
[0000833444-18-000008:note_history:13]
•District of Colorado - Davis et al. v. The 3M Company et al., filed on September 22, 2016.

- added (2018-02-02):
[0000833444-18-000008:note_history:14]
The above cases have been consolidated in the U.S. District Court for the District of Colorado, and a hearing on the plaintiffs’ motion for class certification is scheduled for April 2018 with a trial date schedule for April 2019.

- added (2018-02-02):
[0000833444-18-000008:note_history:15]
New York

- added (2018-02-02):
[0000833444-18-000008:note_history:16]
| • | Eastern District of New York - Green et al. v. The 3M Company et al., filed March 27, 2017 in Supreme Court of the State of New York, Suffolk County, prior to removal to federal court. |

- added (2018-02-02):
[0000833444-18-000008:note_history:17]
| • | Southern District of New York - Adamo et al. v. The Port Authority of NY and NJ et al., filed August 11, 2017 in Supreme Court of the State of New York, Orange County, prior to removal to federal court. |

- added (2018-02-02):
[0000833444-18-000008:note_history:18]
| • | Southern District of New York - Fogarty et al. v. The Port Authority of NY and NJ et al., filed August 11, 2017 in Supreme Court of the State of New York, Orange County, prior to removal to federal court. |

- added (2018-02-02):
[0000833444-18-000008:note_history:19]
| • | Southern District of New York - Miller et al. v. The Port Authority of NY and NJ et al., filed August 11, 2017 in Supreme Court of the State of New York, Orange County, prior to removal to federal court. |

- added (2018-02-02):
[0000833444-18-000008:note_history:20]
| • | Supreme Court of the State of New York, Suffolk County - Singer et al. v. The 3M Company et al., filed October 10, 2017. |

- added (2018-02-02):
[0000833444-18-000008:note_history:21]
Chemguard and Tyco Fire Products are also defendants in Ayo, et al. v. The 3M Company, et al., filed on December 11, 2017 in the Suffolk County Supreme Court of New York. Approximately 32 plaintiffs allege that releases of PFOS and PFOA have contaminated surrounding communities’ water supplies near the Gabreski Air National Guard Base located on Long Island, New York.  The plaintiffs assert defective design, failure to warn, negligence, private nuisance, and trespass and seek recovery for alleged diminished property values, personal injury, medical monitoring and punitive damages.

- added (2018-02-02):
[0000833444-18-000008:note_history:22]
Responses to the complaints have not been filed yet in any of the New York actions.

- added (2018-02-02):
[0000833444-18-000008:note_history:23]
Pennsylvania

- added (2018-02-02):
[0000833444-18-000008:note_history:24]
| • | Eastern District of Pennsylvania - Bates et al. v. The 3M Company et al., filed September 15, 2016. |

- added (2018-02-02):
[0000833444-18-000008:note_history:25]
| • | Eastern District of Pennsylvania - Grande et al. v. The 3M Company et al., filed October 13, 2016. |

- added (2018-02-02):
[0000833444-18-000008:note_history:26]
| • | Eastern District of Pennsylvania - Yockey et al. v. The 3M Company et al., filed October 24, 2016. |

- added (2018-02-02):
[0000833444-18-000008:note_history:27]
| • | Eastern District of Pennsylvania - Fearnley et al. v. The 3M Company et al., filed December 9, 2016. |

- added (2018-02-02):
[0000833444-18-000008:note_history:28]
The above cases have been consolidated in the U.S. District Court for the Eastern District of Pennsylvania. The defendants' motion to dismiss the complaint in the consolidated proceeding was denied without prejudice and the cases are currently stayed pending the appeal of an action in which the Company is not a party.

- added (2018-02-02):
[0000833444-18-000008:note_history:29]
In addition to the putative class actions, Chemguard and Tyco Fire Products are also defendants in an action filed by two plaintiffs in the U.S. District Court for the Eastern District of Pennsylvania:  Menkes et al. v. The 3M Company et al., (filed February 7, 2017). The Menkes plaintiffs assert substantive claims and allegations similar to the putative class allegations, but also include personal injury claim. The Company is also on notice of approximately 540 other possible individual product liability claims by filings made in Pennsylvania state court, but complaints have not been filed in those matters, and, under Pennsylvania’s procedural rules, they may or may not result in lawsuits.

- added (2018-02-02):
[0000833444-18-000008:note_history:30]
Chemguard and Tyco Fire Products are also defendants in two cases pending in the U.S. District Court for the District of Massachusetts: Town of Barnstable v. the 3M. Co., et al, (filed Nov. 21, 2016), and County of Barnstable v. the 3M. Co., et al, (filed January 9, 2017).  These municipal plaintiffs generally allege that the use of the defendants’ fire-fighting foam products at a fire training academy and municipal airport released PFOS and PFOA into the town’s water supply wells, allegedly requiring remediation of the town and county property. The defendants have filed a motion to dismiss in County of Barnstable, which was granted without prejudice and the plaintiffs have subsequently filed an amended complaint.

- added (2018-02-02):
[0000833444-18-000008:note_history:31]
The Company is vigorously defending these cases and believes that it has meritorious defenses to class certification and the claims asserted.  However, there are numerous factual and legal issues to be resolved in connection with these claims, and it is extremely difficult to predict the outcome or ultimate financial exposure, if any, represented by these matters, but there can be no assurance that any such exposure will not be material. The Company is also pursuing insurance coverage for these matters.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-02-02):
[0000833444-18-000008:note_history:32]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission ("SEC"). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2017 filed with the SEC on November 21, 2017. The results of operations for the three month period ended December 31, 2017 are not necessarily indicative of results for the Company’s 2018 fiscal year because of seasonal and other factors.
  (was, 2017-08-03, similarity 0.8325):
[0000833444-17-000044:note_history:32]
The consolidated financial statements include the consolidated accounts of Johnson Controls International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Johnson Controls International plc and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Johnson Controls"). In the opinion of management, the accompanying unaudited consolidated financial statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States of America (U.S. GAAP) have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (SEC). These consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended September 30, 2016 filed with the SEC on November 23, 2016, portions of which (including Part I, Item 1. Business and Item 3. Legal Proceedings, and the following items from Part II of the Annual Report: Item 6. Selected Financial Data, Item 7. Management’s Discussion and Analysis, and Item 8. Financial Statements and Supplementary Data) were recast in the Company's Current Report on Form 8-K filed with the SEC on February 23, 2017. The results of operations for the three and nine month periods ended June 30, 2017 are not necessarily indicative of results for the Company’s 2017 fiscal year because of seasonal and other factors.

- added (2018-02-02):
[0000833444-18-000008:note_history:33]
Johnson Controls International plc, headquartered in Cork, Ireland, is a global diversified technology and multi industrial leader serving a wide range of customers in more than 150 countries. The Company creates intelligent buildings, efficient energy solutions, integrated infrastructure and next generation transportation systems that work seamlessly together to deliver on the promise of smart cities and communities. The Company is committed to helping our customers win and creating greater value for all of its stakeholders through strategic focus on our buildings and energy growth platforms.

- added (2018-02-02):
[0000833444-18-000008:note_history:34]
In the fourth quarter of fiscal 2016, Johnson Controls, Inc. ("JCI Inc.") and Tyco International plc ("Tyco") completed their combination with JCI Inc. merging with a wholly-owned, indirect subsidiary of Tyco (the "Merger"). Following the Merger, Tyco changed its name to “Johnson Controls International plc” and JCI Inc. is a wholly-owned subsidiary of Johnson Controls International plc. The Merger was accounted for as a reverse acquisition using the acquisition method of accounting in accordance with Accounting Standards Codification ("ASC") 805, "Business Combinations." JCI Inc. was the accounting acquirer for financial reporting purposes. Accordingly, the historical consolidated financial statements of JCI Inc. for periods prior to this transaction are considered to be the historic financial statements of the Company.

- added (2018-02-02):
[0000833444-18-000008:note_history:35]
The Building Technologies & Solutions ("Buildings") business is a global market leader in engineering, developing, manufacturing and installing building products and systems around the world, including heating, ventilating, air-conditioning ("HVAC") equipment, HVAC controls, energy-management systems, security systems, fire detection systems and fire suppression solutions. The Buildings business further serves customers by providing technical services (in the HVAC, security and fire-protection space), energy-management consulting and data-driven solutions via its recently launch data-enabled business. Finally, the Company is a North American market leader in residential air conditioning and heating systems and a global market leader in industrial refrigeration products.

- added (2018-02-02):
[0000833444-18-000008:note_history:36]
The Power Solutions business is a leading global supplier of lead-acid automotive batteries for virtually every type of passenger car, light truck and utility vehicle. The Company serves both automotive original equipment manufacturers and the general vehicle battery aftermarket. The Company also supplies advanced battery technologies to power start-stop, hybrid and electric vehicles.

- changed (2018-02-02):
[0000833444-18-000008:note_history:37]
Under certain criteria as provided for in Financial Accounting Standards Board ("FASB") ASC 810, "Consolidation," the Company may consolidate a partially-owned affiliate. To determine whether to consolidate a partially-owned affiliate, the Company first determines if the entity is a variable interest entity ("VIE"). An entity is considered to be a VIE if it has one of the following characteristics: 1) the entity is thinly capitalized; 2) residual equity holders do not control the entity; 3) equity holders are shielded from economic losses or do not participate fully in the entity’s residual economics; or 4) the entity was established with non-substantive voting rights. If the entity meets one of these characteristics, the Company then determines if it is the primary beneficiary of the VIE. The party with the power to direct activities of the VIE that most significantly impact the VIE’s economic performance and the potential to absorb benefits or losses that could be significant to the VIE is considered the primary beneficiary and consolidates the VIE. If the entity is not considered a VIE, then the Company applies the voting interest model to determine whether or not the Company shall consolidate the partially-owned affiliate.
  (was, 2017-08-03, similarity 0.996):
[0000833444-17-000044:note_history:37]
Under certain criteria as provided for in Financial Accounting Standards Board (FASB) ASC 810, "Consolidation," the Company may consolidate a partially-owned affiliate. To determine whether to consolidate a partially-owned affiliate, the Company first determines if the entity is a variable interest entity (VIE). An entity is considered to be a VIE if it has one of the following characteristics: 1) the entity is thinly capitalized; 2) residual equity holders do not control the entity; 3) equity holders are shielded from economic losses or do not participate fully in the entity’s residual economics; or 4) the entity was established with non-substantive voting rights. If the entity meets one of these characteristics, the Company then determines if it is the primary beneficiary of the VIE. The party with the power to direct activities of the VIE that most significantly impact the VIE’s economic performance and the potential to absorb benefits or losses that could be significant to the VIE is considered the primary beneficiary and consolidates the VIE. If the entity is not considered a VIE, then the Company applies the voting interest model to determine whether or not the Company shall consolidate the partially-owned affiliate.

- added (2018-02-02):
[0000833444-18-000008:note_history:38]
Based upon the criteria set forth in ASC 810, the Company has determined that it was not the primary beneficiary in any VIEs for the reporting period ended December 31, 2017 and that it was the primary beneficiary in one VIE for the reporting period ended September 30, 2017, as the Company absorbed significant economics of the entity and had the power to direct the activities that are considered most significant to the entity.

- added (2018-02-02):
[0000833444-18-000008:note_history:39]
In fiscal 2012, a pre-existing VIE accounted for under the equity method was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The Company acquired additional interests in two of the reorganized group entities. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company was considered the primary beneficiary of one of the entities due to the Company’s power pertaining to decisions over significant activities of the entity. As such, this VIE was consolidated within the Company’s consolidated statements of financial position as of September 30, 2017. The impact of the entity on the Company’s consolidated statements of income for the three month periods ended December 31, 2017 and 2016 were not material. During the quarter ended December 31, 2017, certain joint venture agreements were amended, and as a result, the Company can no longer make key operating decisions considered to be most significant to the VIE. As such, the Company is no longer considered the primary beneficiary of this entity, and the Company deconsolidated the entity during the quarter ended December 31, 2017.

- changed (2018-02-02):
[0000833444-18-000008:note_history:40]
The carrying amounts and classification of assets (none of which are restricted) and liabilities included in the Company’s consolidated statements of financial position for the consolidated VIE is as follows (in millions):
  (was, 2017-08-03, similarity 0.9821):
[0000833444-17-000044:note_history:40]
The carrying amounts and classification of assets (none of which are restricted) and liabilities included in the Company’s consolidated statements of financial position for the consolidated VIEs are as follows (in millions):

- added (2018-02-02):
[0000833444-18-000008:note_history:41]
|  |  | September 30,2017 |
| Current assets |  | $ | 2 |  |
| Noncurrent assets |  | 53 |  |
| Total assets |  | $ | 55 |  |
| Current liabilities |  | $ | 6 |  |
| Noncurrent liabilities |  | 42 |  |
| Total liabilities |  | $ | 48 |  |

- changed (2018-02-02):
[0000833444-18-000008:note_history:42]
As mentioned previously within the "Consolidated VIEs" section above, in fisca1 2012, a pre-existing VIE was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The VIEs are named as co-obligors under a third party debt agreement in the amount of $162 million, maturing in fiscal 2020, under which a VIE could become subject to paying more than its allocated share of the third party debt in the event of bankruptcy of one or more of the other co-obligors. The other co-obligors, all related parties in which the Company is an equity investor, consist of the remaining group entities involved in the reorganization. As part of the overall reorganization transaction, the Company has also provided financial support to the group entities in the form of loans totaling $37 million, which are subordinate to the third party debt agreement. The Company is a significant customer of certain co-obligors, resulting in a remote possibility of loss. Additionally, the Company is subject to a floor guaranty expiring in fiscal 2022; in the event that the other owner party no longer owns any part of the group entities due to sale or transfer, the Company has guaranteed that the proceeds received from the sale or transfer will not be less than $25 million. The Company has partnered with the group entities to design and manufacture battery components for the Power Solutions business. The Company is not considered to be the primary beneficiary of three of the entities as of December 31, 2017 and two of the entities as of September 30, 2017, as the Company cannot make key operating decisions considered to be most significant to the VIEs. Therefore, the entities are accounted for under the equity method of accounting as the Company’s interest exceeds 20% and the Company does not have a controlling interest. The Company’s maximum exposure to loss includes the partially-owned affiliate investment balances of $38 million and $65 million at December 31, 2017 and September 30, 2017, respectively, as well as the subordinated loan from the Company, third party debt agreement and floor guaranty mentioned above. Current liabilities due to the VIEs are not material and represent normal course of business trade payables for all presented periods.
  (was, 2017-08-03, similarity 0.6013):
[0000833444-17-000044:note_history:42]
In fiscal 2012, a pre-existing VIE accounted for under the equity method was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The Company acquired additional interests in two of the reorganized group entities. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is considered the primary beneficiary of one of the entities due to the Company’s power pertaining to decisions over significant activities of the entity. As such, this VIE has been consolidated within the Company’s consolidated statements of financial position. The impact of consolidation of the entity on the Company’s consolidated statements of income for the three and nine month periods ended June 30, 2017 and 2016 was not material. The VIE is named as a co-obligor under a third party debt agreement in the amount of $166 million, maturing in fiscal 2020, under which it could become subject to paying more than its allocated share of the third party debt in the event of bankruptcy of one or more of the other co-obligors. The other co-obligors, all related parties in which the Company is an equity investor, consist of the remaining group entities involved in the reorganization. As part of the overall reorganization transaction, the Company has also provided financial support to the group entities in the form of loans totaling $37 million, which are subordinate to the third party debt agreement. The Company is a significant customer of certain co-obligors, resulting in a remote possibility of loss. Additionally, the Company is subject to a floor guaranty expiring in fiscal 2022; in the event that the other owner party no longer owns any part of the group entities due to sale or transfer, the Company has guaranteed that the proceeds received from the sale or transfer will not be less than $25 million. The Company has partnered with the group entities to design and manufacture battery components for the Power Solutions business.

- added (2018-02-02):
[0000833444-18-000008:note_history:43]
At December 31, 2017, the Company held restricted cash of approximately $19 million, of which $10 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. At September 30, 2017, the Company held restricted cash of approximately $31 million, of which $22 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash restricted for payment of asbestos liabilities.

- added (2018-02-02):
[0000833444-18-000008:note_history:44]
Effective July 1, 2017, the Company reorganized the reportable segments within its Building Technologies & Solutions business to align with its new management reporting structure and business activities. Prior to this reorganization, Building Technologies & Solutions was comprised of five reportable segments for financial reporting purposes: Systems and Service North America, Products North America, Asia, Rest of World and Tyco. As a result of this change, Building Technologies & Solutions is now comprised of four reportable segments for financial reporting purposes: Building Solutions North America, Building Solutions EMEA/LA, Building Solutions Asia Pacific and Global Products. Refer to Note 18, “Segment Information,” of the notes to consolidated financial statements for further information. The net sales and cost of sales split of products and systems versus services in the consolidated statements of income has also been revised for the Building Technologies & Solutions reorganization.

- added (2018-02-02):
[0000833444-18-000008:note_history:45]
In March 2016, the FASB issued Accounting Standards Update ("ASU") No. 2016-09, "Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting." During the quarter ended December 31, 2017, the Company adopted ASU No. 2016-09. As a result, employee withholding taxes paid to taxing authorities for equity-based compensation transactions, previously classified as cash flows from operating activities, were reclassified to financing activities in the consolidated statements of cash flows for the three months ended December 31, 2016. Refer to Note 2, "New Accounting Standards," of the notes to consolidated financial statements for further information.

- removed (2018-02-02):
[0000833444-17-000044:note_history:46]
On September 2, 2016, Johnson Controls, Inc. ("JCI Inc.") and Tyco International plc (“Tyco”) completed their combination pursuant to the Agreement and Plan of Merger (the “Merger Agreement”), dated as of January 24, 2016, as amended by Amendment No. 1, dated as of July 1, 2016, by and among JCI Inc., Tyco and certain other parties named therein, including Jagara Merger Sub LLC, an indirect wholly owned subsidiary of Tyco (“Merger Sub”). Pursuant to the terms of the Merger Agreement, on September 2, 2016, Merger Sub merged with and into JCI Inc., with JCI Inc. being the surviving corporation in the Merger and a wholly owned, indirect subsidiary of Tyco (the “Merger”). Following the Merger, Tyco changed its name to “Johnson Controls International plc.” The Merger changed the jurisdiction of organization from the United States to Ireland. The domicile to Ireland became effective on September 2, 2016.

- removed (2018-02-02):
[0000833444-17-000044:note_history:47]
The Merger was accounted for as a reverse acquisition using the acquisition method of accounting in accordance with Accounting Standards Codification ("ASC") 805, "Business Combinations." JCI Inc. was the accounting acquirer for financial reporting purposes. Accordingly, the historical consolidated financial statements of JCI Inc. for periods prior to this transaction are considered to be the historic financial statements of the Company. Refer to Note 3, "Merger Transaction," of the notes to consolidated financial statements for further information.

- removed (2018-02-02):
[0000833444-17-000044:note_history:48]
On October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience Business from Johnson Controls to Adient plc and the issuance of ordinary shares of Adient directly to holders of Johnson Controls ordinary shares on a pro rata basis. Prior to the open of business on October 31, 2016, each of the Company's shareholders received one ordinary share of Adient plc for every 10 ordinary shares of Johnson Controls held as of the close of business on October 19, 2016, the record date for the distribution. Company shareholders received cash in lieu of fractional shares of Adient, if any. Following the separation and distribution, Adient plc is now an independent public company trading on the New York Stock Exchange (NYSE) under the symbol "ADNT." The Company did not retain any equity interest in Adient plc. Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation. Refer to Note 5, "Discontinued Operations," of the notes to consolidated financial statements for further information.

- removed (2018-02-02):
[0000833444-17-000044:note_history:49]
Based upon the criteria set forth in ASC 810, the Company has determined that it was the primary beneficiary in one VIE for the reporting period ended June 30, 2017 and three VIEs for the reporting period ended  September 30, 2016, as the Company absorbs significant economics of the entities and has the power to direct the activities that are considered most significant to the entities.

- removed (2018-02-02):
[0000833444-17-000044:note_history:50]
Two of the VIEs manufacture products in North America for the automotive industry. The Company funded the entities’ short-term liquidity needs through revolving credit facilities and had the power to direct the activities that were considered most significant to the entities through its key customer supply relationships. These VIE's were divested as a result of the Adient spin-off in the first quarter of fiscal 2017.

- removed (2018-02-02):
[0000833444-17-000044:note_history:51]
|  | June 30,2017 |  | September 30, 2016 |
| Current assets | $ | 2 |  |  | $ | 284 |  |
| Noncurrent assets | 53 |  |  | 98 |  |
| Total assets | $ | 55 |  |  | $ | 382 |  |
| Current liabilities | $ | 4 |  |  | $ | 230 |  |
| Noncurrent liabilities | 43 |  |  | 29 |  |
| Total liabilities | $ | 47 |  |  | $ | 259 |  |

- removed (2018-02-02):
[0000833444-17-000044:note_history:52]
As mentioned previously within the "Consolidated VIEs" section above, in fisca1 2012, a pre-existing VIE was reorganized into three separate investments as a result of the counterparty exercising its option to put its interest to the Company. The reorganized group entities are considered to be VIEs as the other owner party has been provided decision making rights but does not have equity at risk. The Company is not considered to be the primary beneficiary of two of the entities as the Company cannot make key operating decisions considered to be most significant to the VIEs. Therefore, the entities are accounted for under the equity method of accounting as the Company’s interest exceeds 20% and the Company does not have a controlling interest. The Company’s maximum exposure to loss includes the partially-owned affiliate investment balances of $63 million  and $59 million at June 30, 2017 and September 30, 2016 respectively, as well as the subordinated loan from the Company, third party debt agreement and floor guaranty mentioned previously within the "Consolidated VIEs" section above. Current liabilities due to the VIEs are not material and represent normal course of business trade payables for all presented periods.

- removed (2018-02-02):
[0000833444-17-000044:note_history:53]
At June 30, 2017, the Company held restricted cash of approximately $37 million, of which $28 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash restricted for payment of asbestos liabilities. At September 30, 2016, the Company held restricted cash of approximately $88 million, of which $79 million was recorded within other current assets in the consolidated statements of financial position and $9 million was recorded within other noncurrent assets in the consolidated statements of financial position. These amounts were primarily related to cash held in escrow from business divestitures and cash restricted for payment of asbestos liabilities.

- removed (2018-02-02):
[0000833444-17-000044:note_history:54]
Certain amounts as of September 30, 2016 have been revised to conform to the current year’s presentation.

- removed (2018-02-02):
[0000833444-17-000044:note_history:55]
During the first quarter of fiscal 2017, the Company determined that its Automotive Experience business (Adient) met the criteria to be classified as a discontinued operation, which required retrospective application to financial information for all periods presented. Refer to Note 5, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

- removed (2018-02-02):
[0000833444-17-000044:note_history:56]
In the first quarter of fiscal 2017, the Company began evaluating the performance of its business segments primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, significant restructuring and impairment costs, and the net mark-to-market adjustments related to pension and postretirement plans. Historical information has been revised to present the comparable periods on a consistent basis.

- removed (2018-02-02):
[0000833444-17-000044:note_history:57]
In April 2015, the FASB issued Accounting Standards Update (ASU) No. 2015-03, "Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs." ASU No. 2015-03 requires that debt issuance costs related to a recognized debt liability be presented in the balance sheet as a direct deduction from the carrying amount of the debt liability.

- removed (2018-02-02):
[0000833444-17-000044:note_history:58]
During the quarter ended December 31, 2016, the Company adopted ASU No. 2015-03 and applied the change retrospectively to all periods presented. This change did not have an impact to any period presented on the consolidated statements of income. The financial statement impact of this change for the period ending September 30, 2016 was a decrease to noncurrent assets held for sale of $44 million, a decrease to noncurrent liabilities held for sale of $44 million, a decrease to other noncurrent assets of $30 million and a decrease to long-term debt of $30 million.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-02):
[0000833444-18-000008:note_history:59]
In December 2017, the Company repaid a 364-day 150 million euro floating rate term loan, plus accrued interest, scheduled  to mature in September 2018.
  (was, 2017-08-03, similarity 0.8993):
[0000833444-17-000044:note_history:59]
In October 2016, the Company repaid a nine-month 100 million euro floating rate term loan, plus accrued interest, scheduled to mature in October 2016.

- added (2018-02-02):
[0000833444-18-000008:note_history:60]
In November 2017, the Company issued 750 million euro in principal amount of 0.0% senior unsecured fixed rate notes due in December 2020. Proceeds from the issuance were used to repay existing debt and for other general corporate purposes.

- changed (2018-02-02):
[0000833444-18-000008:note_history:61]
In November 2017, the Company retired $300 million in principal amount, plus accrued interest, of its 1.4% fixed rate notes that expired in November 2017.
  (was, 2017-08-03, similarity 0.9296):
[0000833444-17-000044:note_history:61]
In December 2016, the Company retired $400 million in principal amount, plus accrued interest, of its 2.6% fixed rate notes that matured in December 2016.

- added (2018-02-02):
[0000833444-18-000008:note_history:62]
In October 2017, the Company completed the previously announced sale of its Scott Safety business to 3M. Net cash proceeds from the transaction of approximately $1.9 billion were used to repay a significant portion of the TSarl $4.0 billion of merger-related debt. As of December 31, 2017, the outstanding balance of the TSarl term loan was approximately $1.8 billion.

- changed (2018-02-02):
[0000833444-18-000008:note_history:63]
The Company's net financing charges line item in the consolidated statements of income for the three months ended December 31, 2017 and 2016 contained the following components (in millions):
  (was, 2017-08-03, similarity 0.9309):
[0000833444-17-000044:note_history:63]
The Company's net financing charges line item in the consolidated statements of income for the three and nine month periods ended June 30, 2017 and 2016 contained the following components (in millions):

- changed (2018-02-02):
[0000833444-18-000008:note_history:64]
|  | Three Months EndedDecember 31, |
|  | 2017 |  | 2016 |
| Interest expense, net of capitalized interest costs | $ | 114 |  |  | $ | 110 |  |
| Banking fees and bond cost amortization | 13 |  |  | 30 |  |
| Interest income | (9 | ) |  | (7 | ) |
| Net foreign exchange results for financing activities | (2 | ) |  | 3 |  |
| Net financing charges | $ | 116 |  |  | $ | 136 |  |
  (was, 2017-08-03, similarity 0.7919):
[0000833444-17-000044:note_history:64]
|  | Three Months EndedJune 30, |  | Nine Months EndedJune 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Interest expense, net of capitalized interest costs | $ | 115 |  |  | $ | 66 |  |  | $ | 343 |  |  | $ | 203 |  |
| Banking fees and bond cost amortization | 14 |  |  | 7 |  |  | 55 |  |  | 19 |  |
| Interest income | (4 | ) |  | (4 | ) |  | (16 | ) |  | (8 | ) |
| Net foreign exchange results for financing activities | (1 | ) |  | (4 | ) |  | (6 | ) |  | (12 | ) |
| Net financing charges | $ | 124 |  |  | $ | 65 |  |  | $ | 376 |  |  | $ | 202 |  |

- changed (2018-02-02):
[0000833444-18-000008:note_history:65]
Net financing charges for the three months ended December 31, 2016, included $17 million of transaction costs related primarily to the prior year debt exchange offer fees.
  (was, 2017-08-03, similarity 0.8726):
[0000833444-17-000044:note_history:65]
Net financing charges for the nine month period ended June 30, 2017 included $17 million of transaction costs related primarily to the debt exchange offers.

- removed (2018-02-02):
[0000833444-17-000044:note_history:66]
Debt exchange

- removed (2018-02-02):
[0000833444-17-000044:note_history:67]
In connection with the Tyco Merger, on December 28, 2016, the Company completed its offers to exchange all validly tendered and accepted notes of certain series (the "existing notes") issued by JCI Inc. or Tyco International Finance S.A. ("TIFSA"), as applicable, each of which is a wholly owned subsidiary of the Company, for new notes (the New Notes) to be issued by the Company, and the related solicitation of consents to amend the indentures governing the existing notes (the offers to exchange and the related consent solicitation together the "exchange offers"). Pursuant to the exchange offers, the Company exchanged approximately $5.6 billion of $6.0 billion in aggregate principal amount of dollar denominated notes and approximately 423 million euro of 500 million euro in aggregate principal amount of euro denominated notes. All validly tendered and accepted existing notes have been canceled. Immediately following such cancellation, $380.9 million aggregate principal amount of existing notes (not including the TIFSA Euro Notes) remained outstanding across seventeen series of dollar-denominated existing notes and 77.4 million euro aggregate principal amount of TIFSA Euro Notes remained outstanding across one series. In connection with the settlement of the exchange offers, the New Notes were registered under the Securities Act of 1933 and their terms are described in the Company’s Prospectus dated December 19, 2016, as filed with the SEC under Rule 424(b)(3) of the Act on that date. The issuance of the New Notes occurred on December 28, 2016. The New Notes are unsecured and unsubordinated obligations of the Company and will rank equally with all other unsecured and unsubordinated indebtedness of the Company issued from time to time.

- removed (2018-02-02):
[0000833444-17-000044:note_history:68]
Other financing arrangements

- removed (2018-02-02):
[0000833444-17-000044:note_history:69]
In June 2017, the Company partially repaid $135 million of the $4.0 billion floating rate term loan scheduled to mature in March 2020.

- removed (2018-02-02):
[0000833444-17-000044:note_history:70]
In March 2017, the Company issued one billion euro in principal amount of 1.0% senior unsecured fixed rate notes due in         fiscal 2023. Proceeds from the issuance were used to repay existing debt and for other general corporate purposes.

- removed (2018-02-02):
[0000833444-17-000044:note_history:71]
In March 2017, the Company entered into a 364-day $150 million committed revolving credit facility scheduled to expire in March 2018. As of June 30, 2017, there were no draws on the facility.

- removed (2018-02-02):
[0000833444-17-000044:note_history:72]
In March 2017, the Company retired $46 million in principal amount, plus accrued interest, of its 2.355% fixed rate notes that matured in March 2017.

- removed (2018-02-02):
[0000833444-17-000044:note_history:73]
In March and February 2017, the Company repurchased, at a discount, 15 million euro of its TIFSA 1.375% fixed rate notes, plus accrued interest, scheduled to mature in February 2025.

- removed (2018-02-02):
[0000833444-17-000044:note_history:74]
In February 2017, the Company issued $500 million aggregate principal amount of 4.5% senior unsecured fixed rate notes due in fiscal 2047. Proceeds from the issuance were used to repay outstanding commercial paper borrowings and for other general corporate purposes.

- removed (2018-02-02):
[0000833444-17-000044:note_history:75]
In February 2017, the Company entered into a 364-day $150 million committed revolving credit facility scheduled to expire in February 2018. As of June 30, 2017, there were no draws on the facility.

- removed (2018-02-02):
[0000833444-17-000044:note_history:76]
In January 2017, the Company entered into a 364-day $250 million committed revolving credit facility scheduled to expire                      in January 2018. As of June 30, 2017, there were no draws on the facility outstanding.

- removed (2018-02-02):
[0000833444-17-000044:note_history:77]
In December 2016, the Company entered into a 364-day 100 million euro floating rate term loan scheduled to mature in December 2017. Proceeds from the term loan were used for general corporate purposes. Principal and accrued interest were fully repaid in March 2017.

- removed (2018-02-02):
[0000833444-17-000044:note_history:78]
In December 2016, a $100 million committed revolving credit facility expired. There were no draws on the facility.

- removed (2018-02-02):
[0000833444-17-000044:note_history:79]
In November 2016, the Company fully repaid its 37 billion yen syndicated floating rate term loan, plus accrued interest, scheduled to mature in June 2020.

- removed (2018-02-02):
[0000833444-17-000044:note_history:80]
In November 2016, a $35 million committed revolving credit facility expired. There were no draws on the facility.

- removed (2018-02-02):
[0000833444-17-000044:note_history:81]
In October 2016, the Company repaid two ten-month floating rate term loans totaling $325 million, plus accrued interest, scheduled to mature in October 2016.

- removed (2018-02-02):
[0000833444-17-000044:note_history:82]
In October 2016, the Company repaid a nine-month $100 million floating rate term loan, plus accrued interest, scheduled to mature in November 2016.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2018-02-02):
[0000833444-18-000008:note_history:83]
The net sales to and purchases from related parties included in the consolidated statements of income were $242 million and $41 million, respectively, for the three months ended December 31, 2017; and $225 million and $49 million, respectively, for the three months ended December 31, 2016.

- changed (2018-02-02):
[0000833444-18-000008:note_history:84]
The following table sets forth the amount of accounts receivable due from and payable to related parties in the consolidated statements of financial position (in millions):
  (was, 2017-08-03, similarity 0.9297):
[0000833444-17-000044:note_history:84]
The following table sets forth the amount of accounts receivable due from and payable to related parties for continuing operations in the consolidated statements of financial position (in millions):

- changed (2018-02-02):
[0000833444-18-000008:note_history:85]
|  |  | December 31, 2017 |  | September 30, 2017 |  |
| Receivable from related parties |  | $ | 122 |  |  | $ | 108 |  |
| Payable to related parties |  | 34 |  |  | 50 |  |
  (was, 2017-08-03, similarity 0.9655):
[0000833444-17-000044:note_history:85]
|  |  | June 30, 2017 |  | September 30, 2016 |  |
| Receivable from related parties |  | $ | 99 |  |  | $ | 66 |  |
| Payable to related parties |  | 22 |  |  | 11 |  |

- removed (2018-02-02):
[0000833444-17-000044:note_history:86]
The net sales to and purchases from related parties for continuing operations included in the consolidated statements of income were $272 million and $64 million, respectively, for the three months ended June 30, 2017; and $277 million and $48 million, respectively, for the three months ended June 30, 2016. The net sales to and purchases from related parties for continuing operations included in the consolidated statements of income were $726 million and $165 million, respectively, for the nine months ended June 30, 2017; and $747 million and $131 million, respectively, for the nine months ended June 30, 2016.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2018-02-02):
[0000833444-18-000008:note_history:87]
The following table sets forth the amount of accounts receivable due from and payable to related parties in the consolidated statements of financial position (in millions):
  (was, 2017-08-03, similarity 0.9297):
[0000833444-17-000044:note_history:87]
The following table sets forth the amount of accounts receivable due from and payable to related parties for continuing operations in the consolidated statements of financial position (in millions):

- changed (2018-02-02):
[0000833444-18-000008:note_history:88]
|  |  | December 31, 2017 |  | September 30, 2017 |  |
| Receivable from related parties |  | $ | 122 |  |  | $ | 108 |  |
| Payable to related parties |  | 34 |  |  | 50 |  |
  (was, 2017-08-03, similarity 0.9655):
[0000833444-17-000044:note_history:88]
|  |  | June 30, 2017 |  | September 30, 2016 |  |
| Receivable from related parties |  | $ | 99 |  |  | $ | 66 |  |
| Payable to related parties |  | 22 |  |  | 11 |  |
