# JCI MD&A — 0000833444-18-000008


## mdna

[0000833444-18-000008:mdna:1]
[same as prior period, unchanged from 0000833444-17-000044:mdna:1]

[0000833444-18-000008:mdna:2]
[same as prior period, unchanged from 0000833444-17-000044:mdna:2]

[0000833444-18-000008:mdna:3]
[same as prior period, unchanged from 0000833444-17-000044:mdna:3]

[0000833444-18-000008:mdna:4]
[same as prior period, unchanged from 0000833444-17-000044:mdna:4]

[0000833444-18-000008:mdna:5]
[same as prior period, unchanged from 0000833444-17-000044:mdna:5]

[0000833444-18-000008:mdna:6]
Johnson Controls was originally incorporated in the state of Wisconsin in 1885 as Johnson Electric Service Company to manufacture, install and service automatic temperature regulation systems for buildings. The Company was renamed to Johnson Controls, Inc. in 1974. In 1978, the Company acquired Globe-Union, Inc., a Wisconsin-based manufacturer of automotive batteries for both the replacement and original equipment markets. The Company entered the automotive seating industry in 1985 with the acquisition of Michigan-based Hoover Universal, Inc. In 2005, the Company acquired York International, a global supplier of heating, ventilating, air-conditioning and refrigeration equipment and services. In 2014, the Company acquired Air Distribution Technologies, Inc. ("ADTi"), one of the largest independent providers of air distribution and ventilation products in North America. On October 1, 2015, the Company formed a joint venture with Hitachi to expand its building product offerings.

[0000833444-18-000008:mdna:7]
In the fourth quarter of fiscal 2016, Johnson Controls, Inc. ("JCI Inc.") and Tyco completed their combination, with JCI Inc. merging with a wholly owned, indirect subsidiary of Tyco (the "Merger"). Following the Merger, Tyco changed its name to “Johnson Controls International plc” and JCI Inc. is a wholly-owned subsidiary of Johnson Controls International plc. The Merger was accounted for as a reverse acquisition using the acquisition method of accounting in accordance with Accounting Standards Codification ("ASC") 805, "Business Combinations." JCI Inc. was the accounting acquirer for financial reporting purposes. Accordingly, the historical consolidated financial statements of JCI Inc. for periods prior to this transaction are considered to be the historic financial statements of the Company.

[0000833444-18-000008:mdna:8]
The acquisition of Tyco brings together best-in-class product, technology and service capabilities across controls, fire, security, HVAC, power solutions and energy storage, to serve various end-markets including large institutions, commercial buildings, retail, industrial, small business and residential. The combination of the Tyco and Johnson Controls buildings platforms creates immediate opportunities for near-term growth through cross-selling, complementary branch and channel networks, and expanded global reach for established businesses. The new Company benefits by combining innovation capabilities and pipelines involving new products, advanced solutions for smart buildings and cities, value-added services driven by advanced data and analytics and connectivity between buildings and energy storage through infrastructure integration.

[0000833444-18-000008:mdna:9]
On October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience Business from Johnson Controls to Adient plc ("Adient") and the issuance of ordinary shares of Adient directly to holders of Johnson Controls ordinary shares on a pro rata basis. Prior to the open of business on October 31, 2016, each of the Company's shareholders received one ordinary share of Adient plc for every 10 ordinary shares of Johnson Controls held as of the close of business on October 19, 2016, the record date for the distribution. Company shareholders received cash in lieu of fractional shares of Adient, if any. Following the separation and distribution, Adient plc is now an independent public company trading on the New York Stock Exchange ("NYSE") under the symbol "ADNT." The Company did not retain any equity interest in Adient plc. Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation.

[0000833444-18-000008:mdna:10]
The Building Technologies & Solutions ("Buildings") business is a global market leader in engineering, developing, manufacturing and installing building products and systems around the world, including HVAC equipment, HVAC controls, energy-management systems, security systems, fire detection systems and fire suppression solutions. The Buildings business further serves customers by providing technical services (in the HVAC, security and fire-protection space), energy-management consulting and data-driven solutions via its recently launch data-enabled business. Finally, the Company is a North American market leader in residential air conditioning and heating systems and a global market leader in industrial refrigeration products.

[0000833444-18-000008:mdna:11]
The Power Solutions business is a leading global supplier of lead-acid automotive batteries for virtually every type of passenger car, light truck and utility vehicle. The Company serves both automotive original equipment manufacturers ("OEMs") and the general vehicle battery aftermarket. The Company also supplies advanced battery technologies to power start-stop, hybrid and electric vehicles.

[0000833444-18-000008:mdna:12]
The following information should be read in conjunction with the September 30, 2017 consolidated financial statements and notes thereto, along with management’s discussion and analysis of financial condition and results of operations included in our Annual Report on Form 10-K for the year ended September 30, 2017 filed with the SEC on November 21, 2017. References in the following discussion and analysis to "Three Months"(or similar language) refer to the three months ended December 31, 2017 compared to the three months ended December 31, 2016.

[0000833444-18-000008:mdna:13]
[same as prior period, unchanged from 0000833444-17-000044:mdna:24]

[0000833444-18-000008:mdna:14]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Net sales | $ | 7,435 |  |  | $ | 7,086 |  |  | 5 | % |

[0000833444-18-000008:mdna:15]
The increase in consolidated net sales for the three months ended December 31, 2017 was due to the favorable impact of foreign currency translation ($172 million), and higher sales in the the Power Solutions business ($152 million) and Building Technologies & Solutions business ($25 million). Increased sales resulted from higher volumes across all Building Technologies & Solutions segments and the impact of higher lead costs on pricing in the Power Solutions business, partially offset by lower volumes related to business divestitures in the Building Technologies & Solutions business. Excluding the impact of foreign currency translation, impact of lead costs on pricing and business divestitures, consolidated net sales increased 3% as compared to the prior year. Refer to the "Segment Analysis" below within Item 2 for a discussion of net sales by segment.

[0000833444-18-000008:mdna:16]
49

[0000833444-18-000008:mdna:17]
[same as prior period, unchanged from 0000833444-17-000044:mdna:28]

[0000833444-18-000008:mdna:18]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Cost of sales | $ | 5,266 |  |  | $ | 4,972 |  |  | 6 | % |
| Gross profit | 2,169 |  |  | 2,114 |  |  | 3 | % |
| % of sales | 29.2 | % |  | 29.8 | % |  |  |

[0000833444-18-000008:mdna:19]
Cost of sales for the three month period ended December 31, 2017 increased as compared to the three month period ended December 31, 2016, and gross profit as a percentage of sales decreased by 60 basis points. Gross profit in the Building Technologies & Solutions business increased due to prior year nonrecurring purchase accounting adjustments ($112 million) and higher volumes across all Building Technologies & Solutions segments, partially offset by higher operating costs. Gross profit in the Power Solutions business was impacted by higher operating costs primarily driven by efforts to satisfy customer demand, partially offset by favorable pricing and product mix. Net mark-to-market adjustments on pension plans had a prior year favorable impact on cost of sales of $10 million primarily due to an increase in discount rates. Foreign currency translation had an unfavorable impact on cost of sales of approximately $128 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment earnings before interest, taxes and amortization ("EBITA") by segment.

[0000833444-18-000008:mdna:20]
[same as prior period, unchanged from 0000833444-17-000044:mdna:32]

[0000833444-18-000008:mdna:21]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Selling, general and administrative expenses | $ | 1,417 |  |  | $ | 1,570 |  |  | -10 | % |
| % of sales | 19.1 | % |  | 22.2 | % |  |  |

[0000833444-18-000008:mdna:22]
Selling, general and administrative expenses ("SG&A") for the three month period ended December 31, 2017 decreased 10% as compared to the three month period ended December 31, 2016. The decrease in SG&A was primarily due to a gain on business divestiture in the Building Technologies & Solutions Global Products segment ($114 million), and productivity savings and costs synergies, partially offset by net mark-to-market adjustments on pension plans which had a prior year favorable impact on SG&A of $107 million primarily due to an increase in discount rates. Foreign currency translation had an unfavorable impact on SG&A of $24 million. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-18-000008:mdna:23]
[same as prior period, unchanged from 0000833444-17-000044:mdna:36]

[0000833444-18-000008:mdna:24]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Restructuring and impairment costs | $ | 158 |  |  | $ | 78 |  |  | * |

[0000833444-18-000008:mdna:25]
[same as prior period, unchanged from 0000833444-17-000044:mdna:38]

[0000833444-18-000008:mdna:26]
Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for further disclosure related to the Company's restructuring plans.

[0000833444-18-000008:mdna:27]
50

[0000833444-18-000008:mdna:28]
[same as prior period, unchanged from 0000833444-17-000044:mdna:40]

[0000833444-18-000008:mdna:29]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Net financing charges | $ | 116 |  |  | $ | 136 |  |  | -15 | % |

[0000833444-18-000008:mdna:30]
Net financing charges were lower for the three month period ended December 31, 2017 primarily due to prior year debt exchange offer fees.

[0000833444-18-000008:mdna:31]
[same as prior period, unchanged from 0000833444-17-000044:mdna:43]

[0000833444-18-000008:mdna:32]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Equity income | $ | 60 |  |  | $ | 55 |  |  | 9 | % |

[0000833444-18-000008:mdna:33]
The increase in equity income for the three months ended December 31, 2017 was primarily due to higher income at the Johnson Controls - Hitachi ("JCH") joint venture in the Building Technologies & Solutions business, partially offset by lower income at certain partially-owned affiliates in the Power Solutions business. Refer to the "Segment Analysis" below within Item 2 for a discussion of segment EBITA by segment.

[0000833444-18-000008:mdna:34]
Income Tax Provision (Benefit)

[0000833444-18-000008:mdna:35]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Income tax provision (benefit) | $ | 267 |  |  | $ | (27 | ) |  | * |
| Effective tax rate | 50 | % |  | -7 | % |  |  |

[0000833444-18-000008:mdna:36]
[same as prior period, unchanged from 0000833444-17-000044:mdna:48]

[0000833444-18-000008:mdna:37]
In calculating the provision for income taxes, the Company uses an estimate of the annual effective tax rate based upon the facts and circumstances known at each interim period. On a quarterly basis, the actual effective tax rate is adjusted, as appropriate, based upon changed facts and circumstances, if any, as compared to those forecasted at the beginning of the fiscal year and each interim period thereafter.

[0000833444-18-000008:mdna:38]
The U.S. federal statutory tax rate is being used as a comparison due to the Company's current legal entity structure.  As a result of recently enacted U.S. Tax Reform, the Company will be subject to a U.S. federal statutory tax rate of 24.5% for its fiscal year ended September 30, 2018, which reflects a blended federal statutory rate of 35% for its first fiscal quarter and 21% for the remaining three fiscal quarters. For the three months ended December 31, 2017, the Company's effective tax rate was 50% and was higher than the blended U.S. federal statutory rate of 24.5% primarily due to the discrete net impacts of U.S. Tax Reform, Tyco Merger transaction and integration costs, and the jurisdictional mix of significant restructuring and impairment costs, partially offset by the benefits of continuing global tax planning initiatives, non-U.S. tax rate differentials and tax audit closures. For the three months ended December 31, 2016, the Company's effective tax rate was -7% and was lower than the U.S. federal statutory rate of 35% primarily due to the benefits of continuing global tax planning initiatives, non-U.S. tax rate differentials and a tax benefit due to changes in entity tax status, partially offset by the jurisdictional mix of significant restructuring and impairment costs, as well as Tyco Merger transaction and integration costs, and purchase accounting impacts. The effective tax rate for the three months ended December 31, 2017 increased as compared to the three months ended December 31, 2016, primarily due to the discrete tax items described below, partially offset by tax planning initiatives. The global tax planning initiatives related primarily to foreign tax credit planning, global financing structures and alignment of our global business functions in a tax efficient manner.

[0000833444-18-000008:mdna:39]
51

[0000833444-18-000008:mdna:40]
On December 22, 2017, the “Tax Cuts and Jobs Act” (H.R. 1) was enacted and significantly revises U.S. corporate income tax by, among other things, lowering corporate income tax rates, imposing a one-time transition tax on deemed repatriated earnings of non-U.S. subsidiaries, and implementing a territorial tax system and various base erosion minimum tax provisions.

[0000833444-18-000008:mdna:41]
In the first quarter of fiscal 2018, as a result of the enacted legislation, the Company recorded a discrete non-cash tax benefit of $101 million due to the remeasurement of U.S. deferred tax assets and liabilities.  The Company remeasured certain deferred tax assets and liabilities based on the rates at which they are expected to reverse in the future, which is generally 21% or the blended fiscal 2018 rate of 24.5%. This tax benefit is provisional as the Company is still analyzing certain aspects of the legislation and refining calculations, which could potentially materially affect the measurement of these amounts or give rise to new deferred tax amounts.

[0000833444-18-000008:mdna:42]
In the first quarter of fiscal 2018, the Company also recorded a discrete tax charge of $305 million due to the one-time transition tax on deemed repatriated earnings of certain non-U.S. subsidiaries. This charge is inclusive of relevant withholding taxes. This one-time transition tax is based on the Company’s post-1986 earnings and profits (“E&P”) not previously subjected to U.S. taxation.  This tax charge is provisional as the Company has not yet finally determined its post-1986 non-U.S. E&P. Further, the transition tax is based in part on the amount of those earnings held in cash and other specified assets. Given the varying tax rates (15.5% on cash and 8% on other property), this amount may change when the Company completes the calculation of post-1986 non-U.S. E&P previously deferred from U.S. federal taxation and concludes on the amounts held in cash versus other specified assets.

[0000833444-18-000008:mdna:43]
Various impacts of the enacted legislation are still being evaluated by the Company and may materially differ from the estimated impacts recognized in the first quarter of fiscal 2018 due to future treasury regulations, tax law technical corrections, and other potential guidance, notices, rulings, refined computations, actions the Company may take as a result of the tax legislation, and other items. The SEC has issued rules that allow for a measurement period of up to one year after the enactment date of the legislation to finalize the recording of the related tax impacts.

[0000833444-18-000008:mdna:44]
In the first quarter of fiscal 2018, tax audit resolutions resulted in a net $25 million benefit to income tax expense.

[0000833444-18-000008:mdna:45]
In the first quarter of fiscal 2018, the Company recorded $50 million of transaction and integration costs.  These costs generated a $7 million tax benefit which was impacted by the Company’s current tax position in these jurisdictions.

[0000833444-18-000008:mdna:46]
In the first quarter of fiscal 2018, the Company recorded $158 million of significant restructuring and impairment costs. Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $24 million tax benefit, which was impacted by the Company’s current tax position in these jurisdictions and the lower enacted U.S. tax rate.

[0000833444-18-000008:mdna:47]
[same as prior period, unchanged from 0000833444-17-000044:mdna:57]

[0000833444-18-000008:mdna:48]
[same as prior period, unchanged from 0000833444-17-000044:mdna:58]

[0000833444-18-000008:mdna:49]
In the first quarter of fiscal 2017, the Company recorded $78 million of significant restructuring and impairment costs. Refer to Note 8, "Significant Restructuring and Impairment Costs," of the notes to consolidated financial statements for additional information. The restructuring costs generated a $14 million tax benefit, which was impacted by the Company’s current tax position in these jurisdictions.

[0000833444-18-000008:mdna:50]
Loss From Discontinued Operations, Net of Tax

[0000833444-18-000008:mdna:51]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Loss from discontinued operations, net of tax | $ | — |  |  | $ | (34 | ) |  | * |

[0000833444-18-000008:mdna:52]
[same as prior period, unchanged from 0000833444-17-000044:mdna:64]

[0000833444-18-000008:mdna:53]
Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

[0000833444-18-000008:mdna:54]
[same as prior period, unchanged from 0000833444-17-000044:mdna:66]

[0000833444-18-000008:mdna:55]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Income from continuing operations attributable to noncontrolling interests | $ | 41 |  |  | $ | 40 |  |  | 3 | % |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  | 9 |  |  | * |  |

[0000833444-18-000008:mdna:56]
[same as prior period, unchanged from 0000833444-17-000044:mdna:68]

[0000833444-18-000008:mdna:57]
The increase in income from continuing operations attributable to noncontrolling interests for the three months ended December 31, 2017 was primarily due to higher net income at a certain Power Solutions partially-owned affiliate.

[0000833444-18-000008:mdna:58]
Refer to Note 4, "Discontinued Operations," of the notes to consolidated financial statements for further information regarding the Company's discontinued operations.

[0000833444-18-000008:mdna:59]
[same as prior period, unchanged from 0000833444-17-000044:mdna:71]

[0000833444-18-000008:mdna:60]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Net income attributable to Johnson Controls | $ | 230 |  |  | $ | 329 |  |  | -30 | % |

[0000833444-18-000008:mdna:61]
The decrease in net income attributable to Johnson Controls for the three months ended December 31, 2017 was primarily due to an increase in restructuring and impairment costs, and the income tax provision due to discrete period net tax charges, partially offset by lower SG&A. Diluted earnings per share attributable to Johnson Controls for the three months ended December 31, 2017 was $0.25 compared to $0.35 for the three months ended December 31, 2016.

[0000833444-18-000008:mdna:62]
[same as prior period, unchanged from 0000833444-17-000044:mdna:76]

[0000833444-18-000008:mdna:63]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Comprehensive income (loss) attributable to Johnson Controls | $ | 289 |  |  | $ | (332 | ) |  | * |

[0000833444-18-000008:mdna:64]
[same as prior period, unchanged from 0000833444-17-000044:mdna:73]

[0000833444-18-000008:mdna:65]
The increase in comprehensive income (loss) attributable to Johnson Controls for the three months ended December 31, 2017 was primarily due to an increase in other comprehensive income attributable to Johnson Controls ($720 million) resulting primarily from favorable foreign currency translation adjustments, partially offset by lower net income attributable to Johnson Controls ($99 million). These year-over-year favorable foreign currency translation adjustments were primarily driven by the weakening of the British pound, euro and Japanese yen currencies against the U.S. dollar in the prior year.

[0000833444-18-000008:mdna:66]
[same as prior period, unchanged from 0000833444-17-000044:mdna:81]

[0000833444-18-000008:mdna:67]
Management evaluates the performance of its business units based primarily on segment EBITA, which is defined as income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, significant restructuring and impairment costs, and net mark-to-market adjustments on pension and postretirement plans.

[0000833444-18-000008:mdna:68]
[same as prior period, unchanged from 0000833444-17-000044:mdna:83]

[0000833444-18-000008:mdna:69]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Building Solutions North America | $ | 2,012 |  |  | $ | 1,942 |  |  | 4 | % |
| Building Solutions EMEA/LA | 915 |  |  | 875 |  |  | 5 | % |
| Building Solutions Asia Pacific | 597 |  |  | 575 |  |  | 4 | % |
| Global Products | 1,781 |  |  | 1,794 |  |  | -1 | % |
|  | $ | 5,305 |  |  | $ | 5,186 |  |  | 2 | % |

[0000833444-18-000008:mdna:70]
| • | The increase in Building Solutions North America was due to higher volumes ($60 million) and the favorable impact of foreign currency translation ($10 million). The increase in volumes was primarily attributable to higher HVAC and controls sales. |

[0000833444-18-000008:mdna:71]
| • | The increase in Building Solutions EMEA/LA was due to the favorable impact of foreign currency translation ($47 million), higher volumes in the Middle East ($20 million), Latin America ($11 million) and in Europe ($2 million), and the impact of prior year nonrecurring purchase accounting adjustments ($3 million), partially offset by lower volumes related to a business divestiture ($43 million). |

[0000833444-18-000008:mdna:72]
| • | The increase in Building Solutions Asia Pacific was due to higher service and project installation volumes ($14 million), the favorable impact of foreign currency translation ($14 million) and the impact of prior year nonrecurring purchase accounting adjustments ($1 million), partially offset by lower volumes related to a business divestiture ($7 million). |

[0000833444-18-000008:mdna:73]
| • | The decrease in Global Products was due to lower volumes related to business divestitures ($138 million), partially offset by higher volumes ($96 million), the favorable impact of foreign currency translation ($23 million) and the impact of prior year nonrecurring purchase accounting adjustments ($6 million). The increase in volumes was primarily attributable to higher building management, HVAC and refrigeration equipment, and specialty products sales. |

[0000833444-18-000008:mdna:74]
[same as prior period, unchanged from 0000833444-17-000044:mdna:98]

[0000833444-18-000008:mdna:75]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Building Solutions North America | $ | 227 |  |  | $ | 196 |  |  | 16 | % |
| Building Solutions EMEA/LA | 69 |  |  | 49 |  |  | 41 | % |
| Building Solutions Asia Pacific | 74 |  |  | 63 |  |  | 17 | % |
| Global Products | 286 |  |  | 127 |  |  | * |  |
|  | $ | 656 |  |  | $ | 435 |  |  | 51 | % |

[0000833444-18-000008:mdna:76]
[same as prior period, unchanged from 0000833444-17-000044:mdna:78]

[0000833444-18-000008:mdna:77]
| • | The increase in Building Solutions North America was due to prior year nonrecurring purchase accounting adjustments ($23 million), prior year transaction costs ($10 million), prior year integration costs ($7 million), favorable volumes / mix ($5 million), lower selling, general and administrative expenses ($2 million), and the favorable impact of foreign currency translation ($1 million), partially offset by current year integration costs ($9 million), higher operating costs ($5 million) and incremental investments ($3 million). |

[0000833444-18-000008:mdna:78]
| • | The increase in Building Solutions EMEA/LA was due to prior year nonrecurring purchase accounting adjustments ($12 million), higher volumes ($10 million), the favorable impact of foreign currency translation ($4 million), prior year transaction costs ($2 million), prior year integration costs ($2 million) and higher equity income ($1 million), partially offset by higher operating costs ($5 million), higher selling, general and administrative expenses ($2 million), lower income due to a business divestiture ($2 million) and current year integration costs ($2 million). |

[0000833444-18-000008:mdna:79]
| • | The increase in Building Solutions Asia Pacific was due to prior year nonrecurring purchase accounting adjustments ($6 million), higher volumes ($3 million), lower selling, general and administrative expenses ($3 million), prior year |

[0000833444-18-000008:mdna:80]
54

[0000833444-18-000008:mdna:81]
transaction costs ($2 million) and prior year integration costs ($1 million), partially offset by unfavorable pricing ($4 million).

[0000833444-18-000008:mdna:82]
| • | The increase in Global Products was due to a gain on business divestiture ($114 million), prior year nonrecurring purchase accounting adjustments ($71 million), favorable volumes / mix ($30 million), higher equity income ($7 million), the favorable impact of foreign currency translation ($5 million), prior year integration costs ($4 million) and prior year transaction costs ($3 million), partially offset by lower income due to business divestitures ($35 million), incremental global product investments ($17 million), higher operating costs ($13 million), current year integration costs ($6 million), and higher selling, general and administrative expenses ($4 million). |

[0000833444-18-000008:mdna:83]
[same as prior period, unchanged from 0000833444-17-000044:mdna:115]

[0000833444-18-000008:mdna:84]
|  | Three Months EndedDecember 31, |  |  |
| (in millions) | 2017 |  | 2016 |  | Change |
| Net sales | $ | 2,130 |  |  | $ | 1,900 |  |  | 12 | % |
| Segment EBITA | 384 |  |  | 389 |  |  | -1 | % |

[0000833444-18-000008:mdna:85]
| • | Net sales increased due to the impact of higher lead costs on pricing ($131 million), the favorable impact of foreign currency translation ($78 million), and favorable pricing and product mix ($48 million), partially offset by lower volumes ($27 million). The decrease in volumes was driven by changes in customer demand patterns in Europe and North America, partially offset by an increase in start-stop battery volumes. Additionally, higher start-stop volumes contributed to favorable product mix. |

[0000833444-18-000008:mdna:86]
| • | Segment EBITA decreased due to higher operating costs primarily driven by efforts to satisfy customer demand including higher transportation costs in North America ($25 million), incremental investments ($11 million), lower volumes ($8 million) and lower equity income ($4 million), partially offset by favorable pricing and product mix ($19 million), a current year gain on a business deconsolidation and changes in selling, general and administrative expenses ($13 million), the favorable impact of foreign currency translation ($10 million) and prior year transaction costs ($1 million). |

[0000833444-18-000008:mdna:87]
[same as prior period, unchanged from 0000833444-17-000044:mdna:123]

[0000833444-18-000008:mdna:88]
The Company's backlog relating to the Building Technologies & Solutions business is applicable to its sales of systems and services. At December 31, 2017, the backlog was $8.5 billion. The backlog amount outstanding at any given time is not necessarily indicative of the amount of revenue to be earned during the fiscal year.

[0000833444-18-000008:mdna:89]
55

[0000833444-18-000008:mdna:90]
[same as prior period, unchanged from 0000833444-17-000044:mdna:16]

[0000833444-18-000008:mdna:91]
[same as prior period, unchanged from 0000833444-17-000044:mdna:126]

[0000833444-18-000008:mdna:92]
|  | December 31, |  | September 30, |  |  |
| (in millions) | 2017 |  | 2017 |  | Change |
| Current assets | $ | 12,429 |  |  | $ | 12,292 |  |  |  |
| Current liabilities | (11,246 | ) |  | (11,854 | ) |  |  |
|  | 1,183 |  |  | 438 |  |  | * |  |
| Less: Cash | (552 | ) |  | (321 | ) |  |  |
| Add: Short-term debt | 1,514 |  |  | 1,214 |  |  |  |
| Add: Current portion of long-term debt | 91 |  |  | 394 |  |  |  |
| Less: Assets held for sale | (40 | ) |  | (189 | ) |  |  |
| Add: Liabilities held for sale | — |  |  | 72 |  |  |  |
| Working capital (as defined) | $ | 2,196 |  |  | $ | 1,608 |  |  | 37 | % |
| Accounts receivable - net | $ | 6,731 |  |  | $ | 6,666 |  |  | 1 | % |
| Inventories | 3,459 |  |  | 3,209 |  |  | 8 | % |
| Accounts payable | 4,020 |  |  | 4,271 |  |  | -6 | % |
| * Measure not meaningful |  |  |  |  |  |

[0000833444-18-000008:mdna:93]
| • | The Company defines working capital as current assets less current liabilities, excluding cash, short-term debt, the current portion of long-term debt, and the current portion of assets and liabilities held for sale. Management believes that this measure of working capital, which excludes financing-related items and businesses to be divested, provides a more useful measurement of the Company’s operating performance. |

[0000833444-18-000008:mdna:94]
| • | The increase in working capital at December 31, 2017 as compared to September 30, 2017, was primarily due to an increase in inventory to meet anticipated customer demand and a decrease in accounts payable due to timing and mix of supplier payments. |

[0000833444-18-000008:mdna:95]
| • | The Company’s days sales in accounts receivable at December 31, 2017 were 70 days, higher than 65 days at September 30, 2017. There have been no changes in revenue recognition methods. There has been no significant adverse changes in the level of overdue receivables or changes in revenue recognition methods. |

[0000833444-18-000008:mdna:96]
| • | The Company’s inventory turns for the three months ended December 31, 2017 were lower than the comparable period ended September 30, 2017, primarily due to changes in inventory production levels. |

[0000833444-18-000008:mdna:97]
| • | Days in accounts payable at December 31, 2017 were 72 days, slightly lower than 73 days at the comparable period ended September 30, 2017. |

[0000833444-18-000008:mdna:98]
56

[0000833444-18-000008:mdna:99]
[same as prior period, unchanged from 0000833444-17-000044:mdna:134]

[0000833444-18-000008:mdna:100]
|  |  | Three Months Ended December 31, |
| (in millions) |  | 2017 |  | 2016 |
| Cash used by operating activities |  | $ | (129 | ) |  | $ | (1,885 | ) |
| Cash provided (used) by investing activities |  | 1,774 |  |  | (331 | ) |
| Cash provided (used) by financing activities |  | (1,440 | ) |  | 1,964 |  |
| Capital expenditures |  | (230 | ) |  | (371 | ) |

[0000833444-18-000008:mdna:101]
| • | The decrease in cash used by operating activities for the three months ended December 31, 2017 was primarily due to higher prior year income tax payments related to the Adient spin-off ($1.2 billion in the first quarter of fiscal 2017) and prior year operating cash outflows in the Automotive Experience business before the Adient spin-off, change in control pension payments and transaction related restructuring payments. |

[0000833444-18-000008:mdna:102]
| • | The increase in cash provided by investing activities for the three months ended December 31, 2017 was primarily due to net cash proceeds received from the Scott Safety divestiture in the current year and a decrease in capital expenditures. |

[0000833444-18-000008:mdna:103]
| • | The increase in cash used by financing activities for the three months ended December 31, 2017 was primarily due to the prior year net dividend proceeds from the Adient spin-off, higher repayments of long-term debt and a prior year increase in short-term debt, partially offset by an increase in long-term debt. |

[0000833444-18-000008:mdna:104]
| • | The decrease in capital expenditures for the three months ended December 31, 2017 primarily relates to lower capital investments in the current year in the Building Technologies & Solutions business and prior year capital investments in the Automotive Experience business before the Adient spin-off. |

[0000833444-18-000008:mdna:105]
[same as prior period, unchanged from 0000833444-17-000044:mdna:149]

[0000833444-18-000008:mdna:106]
|  | December 31, |  | September 30, |  |  |
| (in millions) | 2017 |  | 2017 |  | Change |
| Short-term debt | $ | 1,514 |  |  | $ | 1,214 |  |  |  |
| Current portion of long-term debt | 91 |  |  | 394 |  |  |  |
| Long-term debt | 10,895 |  |  | 11,964 |  |  |  |
| Total debt | 12,500 |  |  | 13,572 |  |  | -8 | % |
| Less: cash and cash equivalents | 552 |  |  | 321 |  |  |  |
| Total net debt | 11,948 |  |  | 13,251 |  |  | -10 | % |
| Shareholders’ equity attributable to Johnson Controls ordinary shareholders | 20,535 |  |  | 20,447 |  |  | 0 | % |
| Total capitalization | $ | 32,483 |  |  | $ | 33,698 |  |  | -4 | % |
| Total net debt as a % of total capitalization | 36.8 | % |  | 39.3 | % |  |  |

[0000833444-18-000008:mdna:107]
| • | Net debt and net debt as a percentage of total capitalization are non-GAAP financial measures. The Company believes the percentage of total net debt to total capitalization is useful to understanding the Company’s financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders. |

[0000833444-18-000008:mdna:108]
| • | The Company believes its capital resources and liquidity position at December 31, 2017 are adequate to meet projected needs. The Company believes requirements for working capital, capital expenditures, dividends, stock repurchases, minimum pension contributions, debt maturities and any potential acquisitions in the remainder of fiscal 2018 will continue to be funded from operations, supplemented by short- and long-term borrowings, if required. The Company currently manages its short-term |

[0000833444-18-000008:mdna:109]
[same as prior period, unchanged from 0000833444-17-000044:mdna:15]

[0000833444-18-000008:mdna:110]
debt position in the U.S. and euro commercial paper markets and bank loan markets. In the event the Company and Tyco International Holding S.à.r.l ("TSarl") are unable to issue commercial paper, they would have the ability to draw on their $2.0 billion and $1.0 billion revolving credit facilities, respectively. Both facilities mature in August 2020. There were no draws on the revolving credit facility as of December 31, 2017 and September 30, 2017. The Company also selectively makes use of short-term credit lines other than its revolving credit facilities at the Company and TSarl. The Company estimates that, as of December 31, 2017, it could borrow up to $1.4 billion based on average borrowing levels during the quarter on committed credit lines. As such, the Company believes it has sufficient financial resources to fund operations and meet its obligations for the foreseeable future.

[0000833444-18-000008:mdna:111]
| • | The Company’s debt financial covenant in its revolving credit facility require a minimum consolidated shareholders’ equity attributable to Johnson Controls of at least $3.5 billion at all times. The revolving credit facility also limits the amount of debt secured by liens that may be incurred to a maximum aggregated amount of 10% of consolidated shareholders’ equity attributable to Johnson Controls for liens and pledges. For purposes of calculating these covenants, consolidated shareholders’ equity attributable to Johnson Controls is calculated without giving effect to (i) the application of Accounting Standards Codification ("ASC") 715-60, "Defined Benefit Plans - Other Postretirement," or (ii) the cumulative foreign currency translation adjustment. TSarl's revolving credit facility contains customary terms and conditions, and a financial covenant that limits the ratio of TSarl's debt to earnings before interest, taxes, depreciation, and amortization as adjusted for certain items set forth in the agreement to 3.5x. TSarl's revolving credit facility also limits its ability to incur subsidiary debt or grant liens on its and its subsidiaries' property. As of December 31, 2017, the Company and TSarl were in compliance with all covenants and other requirements set forth in their credit agreements and the indentures, governing their notes, and expect to remain in compliance for the foreseeable future. None of the Company’s or TSarl's debt agreements limit access to stated borrowing levels or require accelerated repayment in the event of a decrease in the respective borrower's credit rating. |

[0000833444-18-000008:mdna:112]
| • | The key financial assumptions used in calculating the Company’s pension liability are determined annually, or whenever plan assets and liabilities are re-measured as required under accounting principles generally accepted in the U.S., including the expected rate of return on its plan assets. In fiscal 2018, the Company believes the long-term rate of return will approximate 7.50%, 5.35% and 5.65% for U.S. pension, non-U.S. pension and postretirement plans, respectively. During the first three months of fiscal 2018, the Company made approximately $24 million in total pension and postretirement contributions. In total, the Company expects to contribute approximately $100 million in cash to its defined benefit pension plans in fiscal 2018. The Company expects to contribute $5 million in cash to its postretirement plans in fiscal 2018. |

[0000833444-18-000008:mdna:113]
| • | The Company earns a significant amount of its operating income outside of the parent company. Outside basis differences in consolidated subsidiaries are deemed to be permanently reinvested except in limited circumstances. However, in fiscal 2018, due to U.S. Tax Reform, the Company provided income tax related to the change in the Company’s assertion over the outside basis difference of certain non-U.S. subsidiaries owned directly or indirectly by U.S. subsidiaries. Under U.S. Tax Reform, the U.S. has adopted a territorial tax system that provides an exemption for dividends received by U.S. corporations from 10% or more owned non-U.S. corporations. However, certain non-U.S, U.S. state and withholding taxes may still apply when closing an outside basis difference via distribution or other transactions. The Company currently does not intend nor foresee a need to repatriate undistributed earnings or reduce outside basis differences other than as noted above or in tax efficient manners. The Company expects existing U.S. cash and liquidity to continue to be sufficient to fund the Company’s U.S. operating activities and cash commitments for investing and financing activities for at least the next twelve months and thereafter for the foreseeable future. In the U.S., should the Company require more capital than is generated by its operations, the Company could elect to raise capital in the U.S. through debt or equity issuances. The Company has borrowed funds in the U.S. and continues to have the ability to borrow funds in the U.S. at reasonable interest rates. In addition, the Company expects existing non-U.S. cash, cash equivalents, short-term investments and cash flows from operations to continue to be sufficient to fund the Company’s non-U.S. operating activities and cash commitments for investing activities, such as material capital expenditures, for at least the next twelve months and thereafter for the foreseeable future. Should the Company require more capital at the Luxembourg and Ireland holding and financing entities, other than amounts that can be provided in a tax efficient manner, the Company could also elect to raise capital through debt or equity issuances. These alternatives could result in increased interest expense or other dilution of the Company’s earnings. |

[0000833444-18-000008:mdna:114]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2018 and recorded $158 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2018 restructuring plan will reduce annual operating costs by approximately |

[0000833444-18-000008:mdna:115]
$150 million, which is primarily the result of lower cost of sales and selling, general and administrative expenses due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in 2020. For fiscal 2018, the savings, net of execution costs, are expected to be approximately 45% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in fiscal 2020. The restructuring plan reserve balance of $128 million at December 31, 2017 is expected to be paid in cash.

[0000833444-18-000008:mdna:116]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2017 and recorded $367 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures and asset impairments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2017 restructuring plan will reduce annual operating costs by approximately $280 million, which is primarily the result of lower cost of sales and selling, general and administrative expenses due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in fiscal 2019. For fiscal 2018, the savings, net of execution costs, are expected to be approximately 85% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in fiscal 2018. The restructuring plan reserve balance of $211 million at December 31, 2017 is expected to be paid in cash. |

[0000833444-18-000008:mdna:117]
| • | To better align its resources with its growth strategies and reduce the cost structure of its global operations to address the softness in certain underlying markets, the Company committed to a significant restructuring plan in fiscal 2016 and recorded $288 million of restructuring and impairment costs in the consolidated statements of income. The restructuring action related to cost reduction initiatives in the Company’s Building Technologies & Solutions and Power Solutions businesses and at Corporate. The costs consist primarily of workforce reductions, plant closures, asset impairments and change-in-control payments. The Company currently estimates that upon completion of the restructuring action, the fiscal 2016 restructuring plan will reduce annual operating costs by approximately $135 million, which is primarily the result of lower cost of sales and selling, general and administrative expenses due to reduced employee-related costs, depreciation and amortization expense. The Company expects the annual benefit of these actions will be substantially realized in fiscal 2019. For fiscal 2018, the savings, net of execution costs, are expected to be approximately 75% of the expected annual operating cost reduction. The restructuring action is expected to be substantially complete in fiscal 2018. The restructuring plan reserve balance of $86 million at December 31, 2017 is expected to be paid in cash. |

[0000833444-18-000008:mdna:118]
| • | Refer to Note 11, "Debt and Financing Arrangements," of the notes to consolidated financial statements for additional information on items impacting capitalization. |

[0000833444-18-000008:mdna:119]
[same as prior period, unchanged from 0000833444-17-000044:mdna:178]

[0000833444-18-000008:mdna:120]
Refer to Note 2, "New Accounting Standards," of the notes to consolidated financial statements.
