# JCI 8-K — 0000833444-18-000004 filed 2018-01-31

## item codes, every 8-K on or before 2018-02-02

- 2018-02-02 0000833444-18-000010 — 8.01
- 2018-01-31 0000833444-18-000004 — 2.02, 9.01
- 2018-01-09 0000833444-18-000002 — 5.02
- 2017-12-11 0000833444-17-000064 — 5.02, 9.01
- 2017-12-11 0000833444-17-000062 — 5.02, 9.01
- 2017-12-04 0001104659-17-071502 — 1.01, 8.01, 9.01
- 2017-11-09 0000833444-17-000057 — 5.02, 9.01
- 2017-11-09 0000833444-17-000056 — 2.02, 9.01
- 2017-11-09 0000833444-17-000055 — 2.02, 9.01
- 2017-09-19 0000833444-17-000049 — 5.02, 9.01
- 2017-09-15 0001193125-17-286406 — 5.02, 9.01
- 2017-08-21 0000833444-17-000047 — 5.02, 8.01, 9.01
- 2017-07-27 0000833444-17-000042 — 2.02, 9.01
- 2017-06-15 0000833444-17-000024 — 5.02, 9.01
- 2017-06-15 0000833444-17-000022 — 5.07 — amendment of 0000833444-17-000024
- 2017-04-27 0000833444-17-000013 — 2.02, 9.01
- 2017-03-15 0001104659-17-016442 — 1.01, 8.01, 9.01
- 2017-03-09 0001104659-17-015486 — 5.07
- 2017-03-09 0001104659-17-015299 — 8.01, 9.01
- 2017-02-23 0000833444-17-000010 — 8.01, 9.01
- 2017-02-07 0001104659-17-006814 — 1.01, 8.01, 9.01
- 2017-02-01 0001104659-17-005844 — 9.01
- 2017-02-01 0000833444-17-000003 — 2.02, 9.01
- 2016-12-28 0001104659-16-164074 — 2.03, 8.01, 9.01
- 2016-12-12 0001047469-16-017153 — 1.01, 3.03, 8.01, 9.01
- 2016-12-05 0001104659-16-160505 — 7.01, 9.01
- 2016-11-08 0000833444-16-000212 — 2.02, 7.01, 9.01
- 2016-11-08 0000833444-16-000211 — 2.02, 9.01
- 2016-10-31 0001104659-16-153134 — 2.01, 5.02, 9.01
- 2016-10-03 0001104659-16-148239 — 2.01, 9.01 — amendment, the index does not say of what
- 2016-10-03 0001047469-16-015901 — 7.01, 9.01
- 2016-09-09 0001104659-16-143835 — 1.01, 4.01, 5.02, 5.03, 7.01, 8.01, 9.01
- 2016-09-06 0001104659-16-143068 — 1.02, 2.01, 2.03, 3.03, 5.01, 5.02, 5.03, 8.01, 9.01
- 2016-08-18 0001193125-16-685046 — 5.07, 8.01, 9.01
- 2016-08-08 0000833444-16-000202 — 5.04, 8.01, 9.01
- 2016-07-29 0000833444-16-000194 — 2.02, 8.01, 9.01
- 2016-06-03 0001193125-16-612787 — 5.02, 8.01, 9.01
- 2016-05-31 0000833444-16-000181 — 8.01
- 2016-05-12 0000833444-16-000174 — 5.02
- 2016-04-29 0000833444-16-000167 — 2.02, 8.01, 9.01
- 2016-04-21 0000833444-16-000146 — 8.01
- 2016-03-16 0000833444-16-000139 — 1.01, 2.03, 9.01
- 2016-03-11 0000833444-16-000133 — 8.01, 9.01
- 2016-03-11 0000833444-16-000132 — 5.07
- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2018-02-02

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-18-000004:8k_2_02:1]
EX-99.1
2
exh991-johnsonctrlsq1fy18.htm
EXHIBIT 99.1

[0000833444-18-000004:8k_2_02:2]
Exhibit

[0000833444-18-000004:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000833444-18-000004:8k_2_02:4]
| CONTACT: | Investors:Antonella Franzen(609) 720-4665Ryan Edelman(609) 720-4545Media:Fraser Engerman(414) 524-2733 | Exhibit 99.1 |

[0000833444-18-000004:8k_2_02:5]
Johnson Controls reports first quarter earnings and re-affirms full year guidance

[0000833444-18-000004:8k_2_02:6]
________________________________________________________________________________

[0000833444-18-000004:8k_2_02:7]
| ▪ | GAAP earnings of $0.25 per share including special items |

[0000833444-18-000004:8k_2_02:8]
| ▪ | Adjusted EPS from continuing operations of $0.54, up 2% versus prior year |

[0000833444-18-000004:8k_2_02:9]
| ▪ | Sales of $7.4 billion, up 5% and reflecting organic growth of 3% versus prior year |

[0000833444-18-000004:8k_2_02:10]
| ▪ | Organic field orders up 5% |

[0000833444-18-000004:8k_2_02:11]
| ▪ | Continue to expect 14% adjusted effective tax rate for fiscal 2018 |

[0000833444-18-000004:8k_2_02:12]
| ▪ | Re-affirm full year fiscal 2018 guidance for adjusted EPS from continuing operations in the range of $2.75 to $2.85 |

[0000833444-18-000004:8k_2_02:13]
________________________________________________________________________________

[0000833444-18-000004:8k_2_02:14]
CORK, Ireland, Jan. 31, 2018 -- Johnson Controls International plc (NYSE: JCI) today reported fiscal first quarter 2018 GAAP earnings per share (“EPS”) from continuing operations, including special items, of $0.25.  Excluding these items, adjusted EPS from continuing operations was $0.54, up 2% versus the prior year period (see attached footnotes for non-GAAP reconciliation).

[0000833444-18-000004:8k_2_02:15]
Sales of $7.4 billion increased 5% compared to the prior year.  Excluding the impacts of M&A, foreign exchange and changes in lead prices, total sales grew 3% organically.

[0000833444-18-000004:8k_2_02:16]
GAAP earnings before interest and taxes (“EBIT”) was $654 million and the EBIT margin was 8.8%. Adjusted EBIT was $748 million and adjusted EBIT margin of 10.1% includes a 30 basis point headwind related to the divestiture of Scott Safety, foreign exchange and lead prices.

[0000833444-18-000004:8k_2_02:17]
Page 1 of 15

[0000833444-18-000004:8k_2_02:18]
“Despite anticipated margin pressure in the quarter, we were able to deliver earnings growth.  We are seeing solid traction around our efforts to increase sales capacity and gross margins on orders are beginning to improve, both of which support our confidence in delivering fiscal 2018 adjusted earnings per share guidance of $2.75 to $2.85,” said George Oliver, Johnson Controls chairman & CEO.

[0000833444-18-000004:8k_2_02:19]
“Additionally, we continue to strive for increased accountability and improved execution.  During the quarter, we nominated two highly accomplished female executives to our Board, and more closely aligned executive compensation incentives with shareholder expectations and improved financial performance.  We remain intensely focused on improving the cash generation potential of the Company, both near and long-term, while at the same time achieving our cost synergy and productivity targets,” Oliver added.

[0000833444-18-000004:8k_2_02:20]
U.S. Tax Reform

[0000833444-18-000004:8k_2_02:21]
In connection with the passage of U.S. Tax Reform during the quarter, the Company recorded a provisionally estimated one-time net tax charge of approximately $200 million.  This was comprised of a non-cash benefit of approximately $100 million, related to the remeasurement of the Company’s net U.S. deferred tax liabilities and a one-time tax charge of approximately $300 million based on the preliminary estimate of income taxes on unremitted foreign earnings, payable over an 8-year period in accordance with the new legislation. The Company continues to expect a 14% adjusted effective tax rate in fiscal 2018.  As certain other provisions of the new legislation become effective for the Company in fiscal 2019, the effective tax rate is expected to increase to 16 to 18%.

[0000833444-18-000004:8k_2_02:22]
Income and EPS amounts attributable to Johnson Controls ordinary shareholders

[0000833444-18-000004:8k_2_02:23]
($ millions, except per-share amounts)

[0000833444-18-000004:8k_2_02:24]
The financial highlights presented in the tables below are in accordance with GAAP, unless otherwise indicated. All comparisons are to the first quarter of 2017.  The spin-off of Adient plc occurred on Oct. 31, 2016 and the results of this business are reported in discontinued operations for all historical periods presented.

[0000833444-18-000004:8k_2_02:25]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q1 2017 |  | Q1 2018 |  | Q1 2017 |  | Q1 2018 |  | Change |
| Sales |  | $7,086 |  | $7,435 |  | $7,096 |  | $7,435 |  | +5% |
| Segment EBITA |  | 824 |  | 1,040 |  | 968 |  | 943 |  | (3%) |
| EBIT |  | 521 |  | 654 |  | 757 |  | 748 |  | (1%) |
| Net income from continuing operations |  | 372 |  | 230 |  | 502 |  | 502 |  | - |
| Diluted EPS from continuing operations |  | $0.39 |  | $0.25 |  | $0.53 |  | $0.54 |  | +2% |

[0000833444-18-000004:8k_2_02:26]
Organic sales growth, adjusted segment EBITA, adjusted EBIT, adjusted EPS from continuing operations and adjusted free cash flow are non-GAAP financial measures. For a reconciliation of these non-GAAP measures and detail of the special items, refer to the attached footnotes.  A slide presentation reviewing first quarter results can be found in the Investor Relations section of Johnson Controls’ website at http://investors.johnsoncontrols.com.

[0000833444-18-000004:8k_2_02:27]
Page 2 of 15

[0000833444-18-000004:8k_2_02:28]
BUSINESS RESULTS

[0000833444-18-000004:8k_2_02:29]
Building Solutions North America

[0000833444-18-000004:8k_2_02:30]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q1 2017 |  | Q1 2018 |  | Q1 2017 |  | Q1 2018 |  | Change |
| Sales |  | $1,942 |  | $2,012 |  | $1,942 |  | $2,012 |  | +4% |
| Segment EBITA |  | $196 |  | $227 |  | $236 |  | $236 |  | - |
| Segment EBITA margin % |  | 10.1% |  | 11.3% |  | 12.2% |  | 11.7% |  | (50bps) |

[0000833444-18-000004:8k_2_02:31]
Sales in the first quarter of 2018 were $2.0 billion, an increase of 4% versus the prior year quarter.  Excluding M&A and foreign exchange, organic sales increased 3% versus the prior year driven by growth in HVAC and Controls.

[0000833444-18-000004:8k_2_02:32]
Orders in the quarter, excluding M&A and adjusted for foreign exchange, increased 4% year-over-year.  Backlog at the end of the quarter of $5.3 billion was 4% higher year-over-year, excluding M&A and adjusted for foreign exchange.

[0000833444-18-000004:8k_2_02:33]
Adjusted segment EBITA was $236 million, consistent with the prior year.  Adjusted segment EBITA margin of 11.7% declined 50 basis points over the prior year as the benefit of cost synergies and productivity savings, as well as volume leverage, were more than offset by expected low margin backlog conversion and salesforce additions.

[0000833444-18-000004:8k_2_02:34]
Building Solutions EMEA/LA (Europe, Middle East, Africa/Latin America)

[0000833444-18-000004:8k_2_02:35]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q1 2017 |  | Q1 2018 |  | Q1 2017 |  | Q1 2018 |  | Change |
| Sales |  | $875 |  | $915 |  | $878 |  | $915 |  | +4% |
| Segment EBITA |  | $49 |  | $69 |  | $65 |  | $71 |  | +9% |
| Segment EBITA margin % |  | 5.6% |  | 7.5% |  | 7.4% |  | 7.8% |  | +40bps |

[0000833444-18-000004:8k_2_02:36]
Sales in the first quarter of 2018 were $915 million, an increase of 4% versus the prior year quarter.  Excluding M&A and foreign exchange, organic sales also increased 4% versus the prior year driven by strong growth in the Middle East & Africa and the Latin America regions.

[0000833444-18-000004:8k_2_02:37]
Orders in the quarter, excluding M&A and adjusted for foreign exchange, increased 6% year-over-year.  Backlog at the end of the quarter of $1.4 billion increased 1% year-over-year, excluding M&A and adjusted for foreign exchange.

[0000833444-18-000004:8k_2_02:38]
Adjusted segment EBITA was $71 million, up 9% versus the prior year.  Adjusted segment EBITA margin of 7.8% improved 40 basis points over the prior year driven by cost synergies and productivity savings, as well as volume leverage.

[0000833444-18-000004:8k_2_02:39]
Page 3 of 15

[0000833444-18-000004:8k_2_02:40]
Building Solutions Asia Pacific

[0000833444-18-000004:8k_2_02:41]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q1 2017 |  | Q1 2018 |  | Q1 2017 |  | Q1 2018 |  | Change |
| Sales |  | $575 |  | $597 |  | $576 |  | $597 |  | +4% |
| Segment EBITA |  | $63 |  | $74 |  | $72 |  | $74 |  | +3% |
| Segment EBITA margin % |  | 11.0% |  | 12.4% |  | 12.5% |  | 12.4% |  | (10bps) |

[0000833444-18-000004:8k_2_02:42]
Sales in the first quarter of 2018 were $597 million, an increase of 4% versus the prior year quarter.  Excluding M&A and foreign exchange, organic sales increased 2% versus the prior year driven by strong growth in service.

[0000833444-18-000004:8k_2_02:43]
Orders in the quarter, excluding M&A and adjusted for foreign exchange, increased 9% year-over-year.  Backlog at the end of the quarter of $1.4 billion was 11% higher year-over-year, excluding M&A and adjusted for foreign exchange.

[0000833444-18-000004:8k_2_02:44]
Adjusted segment EBITA was $74 million, up 3% versus the prior year.  Adjusted segment EBITA margin of 12.4% declined 10 basis points over the prior year, including a 30 basis point headwind related to foreign exchange.  Adjusting for foreign exchange, the underlying margin improved 20 basis points driven by the benefit of cost synergies and productivity savings, as well as volume leverage, partially offset by pricing pressure in China.

[0000833444-18-000004:8k_2_02:45]
Global Products

[0000833444-18-000004:8k_2_02:46]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q1 2017 |  | Q1 2018 |  | Q1 2017 |  | Q1 2018 |  | Change |
| Sales |  | $1,794 |  | $1,781 |  | $1,800 |  | $1,781 |  | (1%) |
| Segment EBITA |  | $127 |  | $286 |  | $205 |  | $178 |  | (13%) |
| Segment EBITA margin % |  | 7.1% |  | 16.1% |  | 11.4% |  | 10.0% |  | (140bps) |

[0000833444-18-000004:8k_2_02:47]
Sales in the first quarter of 2018 were $1.8 billion, a decrease of 1% versus the prior year quarter.  Excluding M&A and foreign exchange, organic sales increased 6% versus the prior year driven by mid-single digit growth across Building Management, HVAC and Refrigeration Equipment, and Specialty Products.

[0000833444-18-000004:8k_2_02:48]
Adjusted segment EBITA was $178 million, a 13% decline versus the prior year primarily attributable to the impact of the Scott Safety divestiture.  Adjusted segment EBITA margin of 10.0% declined 140 basis points over the prior year including a 110 basis point headwind related to the divestiture of the Scott Safety business.  The underlying margin declined 30 basis points as the benefit of cost synergies and productivity savings, as well as volume leverage, was more than offset by planned product and channel investments and expected price/cost pressure.

[0000833444-18-000004:8k_2_02:49]
Page 4 of 15

[0000833444-18-000004:8k_2_02:50]
Power Solutions

[0000833444-18-000004:8k_2_02:51]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q1 2017 |  | Q1 2018 |  | Q1 2017 |  | Q1 2018 |  | Change |
| Sales |  | $1,900 |  | $2,130 |  | $1,900 |  | $2,130 |  | +12% |
| Segment EBITA |  | $389 |  | $384 |  | $390 |  | $384 |  | (2%) |
| Segment EBITA margin % |  | 20.5% |  | 18.0% |  | 20.5% |  | 18.0% |  | (250bps) |

[0000833444-18-000004:8k_2_02:52]
Sales in the first quarter of 2018 were $2.1 billion, an increase of 12% versus the prior year.  Excluding the impact of higher lead pass-through and foreign exchange, organic sales grew 1% versus the prior year as favorable technology mix more than offset lower unit volumes.  Global original equipment battery shipments declined 1% and aftermarket shipments declined 2% compared to the prior year.  Start-stop battery shipments increased 20% year-over-year, led by growth in China and the Americas.

[0000833444-18-000004:8k_2_02:53]
Power Solutions adjusted segment EBITA was $384 million, a 2% decline compared to the prior year, as favorable product mix and productivity benefits were more than offset by higher transportation costs and planned incremental investments.  Adjusted segment EBITA margin of 18.0% decreased 250 basis points compared with the prior year, including a 150 basis point headwind related to the impact of foreign exchange and lead, and a decrease of 100 basis points primarily due to higher transportation costs and planned investments.

[0000833444-18-000004:8k_2_02:54]
Corporate

[0000833444-18-000004:8k_2_02:55]
|  |  | GAAP |  | GAAP |  | Adjusted |  | Adjusted |  |  |
|  |  | Q1 2017 |  | Q1 2018 |  | Q1 2017 |  | Q1 2018 |  | Change |
| Corporate expense |  | $(193) |  | $(134) |  | $(108) |  | $(101) |  | (6%) |

[0000833444-18-000004:8k_2_02:56]
Adjusted Corporate expense was $101 million in the first quarter, a decrease of 6% compared to the prior year driven primarily by cost synergies and productivity initiatives.

[0000833444-18-000004:8k_2_02:57]
OTHER ITEMS

[0000833444-18-000004:8k_2_02:58]
| • | During the quarter, the Company repurchased 3.6 million shares for approximately $150 million. |

[0000833444-18-000004:8k_2_02:59]
| • | The sale of the Scott Safety business to 3M closed on Oct. 4, 2017. The net cash proceeds from the transaction of approximately $1.9 billion were used to repay a portion of the Tyco International Holding Sarl’s (“TSarl”) $4.0 billion merger-related debt. |

[0000833444-18-000004:8k_2_02:60]
| • | During the quarter, the Company issued €750 million, 0.0% Senior Notes due 2020. Additionally, the Company repaid a $300 million bond and a €150 million loan. |

[0000833444-18-000004:8k_2_02:61]
Page 5 of 15

[0000833444-18-000004:8k_2_02:62]
| • | For the quarter, cash from operating activities was a cash outflow of $0.1 billion. Adjusted free cash outflow was $0.3 billion for the quarter, in-line with normal seasonality. Adjusted free cash flow excludes net cash outflows of $0.1 billion primarily related to integration costs. |

[0000833444-18-000004:8k_2_02:63]
| • | The Company nominated Gretchen R. Haggerty, former Executive Vice President & Chief Financial Officer of United States Steel Corporation, and Simone Menne, former Chief Financial Officer at Boehringer Ingelheim GmbH to the Board of Directors. Both Gretchen and Simone have extensive senior leadership experience and deep financial acumen. In addition, the Board has addressed various corporate governance areas, including executive compensation, which are outlined in the Company’s recently filed proxy. |

[0000833444-18-000004:8k_2_02:64]
###

[0000833444-18-000004:8k_2_02:65]
About Johnson Controls

[0000833444-18-000004:8k_2_02:66]
Johnson Controls is a global diversified technology and multi industrial leader serving a wide range of customers in more than 150 countries. Our 120,000 employees create intelligent buildings, efficient energy solutions, integrated infrastructure and next generation transportation systems that work seamlessly together to deliver on the promise of smart cities and communities. Our commitment to sustainability dates back to our roots in 1885, with the invention of the first electric room thermostat. We are committed to helping our customers win and creating greater value for all of our stakeholders through strategic focus on our buildings and energy growth platforms. For additional information, please visit http://www.johnsoncontrols.com or follow us @johnsoncontrols on Twitter.

[0000833444-18-000004:8k_2_02:67]
###

[0000833444-18-000004:8k_2_02:68]
Johnson Controls International plc Cautionary Statement Regarding Forward-Looking Statements

[0000833444-18-000004:8k_2_02:69]
Page 6 of 15

[0000833444-18-000004:8k_2_02:70]
energy and commodity prices, the availability of raw materials and component products, currency exchange rates, and cancellation of or changes to commercial arrangements. A detailed discussion of risks related to Johnson Controls’ business is included in the section entitled “Risk Factors” in Johnson Controls’ Annual Report on Form 10-K for the 2017 year filed with the SEC on November 21, 2017, and available at www.sec.gov and www.johnsoncontrols.com under the “Investors” tab. Shareholders, potential investors and others should consider these factors in evaluating the forward-looking statements and should not place undue reliance on such statements. The forward-looking statements included in this communication are made only as of the date of this document, unless otherwise specified, and, except as required by law, Johnson Controls assumes no obligation, and disclaims any obligation, to update such statements to reflect events or circumstances occurring after the date of this communication.

[0000833444-18-000004:8k_2_02:71]
###

[0000833444-18-000004:8k_2_02:72]
Non GAAP Financial Information

[0000833444-18-000004:8k_2_02:73]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure. The adjusting items include mark-to-market for pension and postretirement plans, transaction/integration/separation costs, restructuring and impairment costs, nonrecurring purchase accounting impacts related to the Tyco merger, Scott Safety gain on sale and discrete tax items. Financial information regarding adjusted sales, organic sales, adjusted segment EBITA, adjusted segment EBITA margin and adjusted free cash flow are also presented, which are non-GAAP performance measures. Adjusted segment EBITA excludes special items such as transaction/integration/separation costs and nonrecurring purchase accounting impacts because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes that, when considered together with unadjusted amounts, these non-GAAP measures are useful to investors in understanding period-over-period operating results and business trends of the Company. Management may also use these metrics as guides in forecasting, budgeting and long-term planning processes and for compensation purposes. These metrics should be considered in addition to, and not as replacements for, the most comparable GAAP measure.

[0000833444-18-000004:8k_2_02:74]
###

[0000833444-18-000004:8k_2_02:75]
Page 7 of 15

[0000833444-18-000004:8k_2_02:76]
| January 31, 2018JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF INCOME(in millions, except per share data; unaudited) |
|  |  | Three Months Ended December 31, |
|  |  | 2017 |  |  | 2016 |
| Net sales | $ | 7,435 |  |  |  | $ | 7,086 |  |
| Cost of sales | 5,266 |  |  |  | 4,972 |  |
|  | Gross profit | 2,169 |  |  |  | 2,114 |  |
| Selling, general and administrative expenses | (1,417 | ) |  |  | (1,570 | ) |
| Restructuring and impairment costs | (158 | ) |  |  | (78 | ) |
| Net financing charges | (116 | ) |  |  | (136 | ) |
| Equity income | 60 |  |  |  | 55 |  |
| Income from continuing operations before income taxes | 538 |  |  |  | 385 |  |
| Income tax provision (benefit) | 267 |  |  |  | (27 | ) |
| Income from continuing operations | 271 |  |  |  | 412 |  |
| Loss from discontinued operations, net of tax | — |  |  |  | (34 | ) |
| Net income | 271 |  |  |  | 378 |  |
| Less: Income from continuing operations attributable to noncontrolling interests | 41 |  |  |  | 40 |  |
| Less: Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | 9 |  |
| Net income attributable to JCI | $ | 230 |  |  |  | $ | 329 |  |
| Income from continuing operations | $ | 230 |  |  |  | $ | 372 |  |
| Loss from discontinued operations | — |  |  |  | (43 | ) |
| Net income attributable to JCI | $ | 230 |  |  |  | $ | 329 |  |
| Diluted earnings per share from continuing operations | $ | 0.25 |  |  |  | $ | 0.39 |  |
| Diluted loss per share from discontinued operations | — |  |  |  | (0.05 | ) |
| Diluted earnings per share * | $ | 0.25 |  |  |  | $ | 0.35 |  |
| Diluted weighted average shares | 933.3 |  |  |  | 947.4 |  |
| Shares outstanding at period end | 926.1 |  |  |  | 938.7 |  |

[0000833444-18-000004:8k_2_02:77]
* May not sum due to rounding.

[0000833444-18-000004:8k_2_02:78]
Page 8 of 15

[0000833444-18-000004:8k_2_02:79]
| January 31, 2018JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF FINANCIAL POSITION(in millions; unaudited) |
|  |  | December 31,2017 |  | September 30,2017 |
| ASSETS |  |  |  |
| Cash and cash equivalents | $ | 552 |  |  | $ | 321 |  |
| Accounts receivable - net | 6,731 |  |  | 6,666 |  |
| Inventories | 3,459 |  |  | 3,209 |  |
| Assets held for sale | 40 |  |  | 189 |  |
| Other current assets | 1,647 |  |  | 1,907 |  |
|  | Current assets | 12,429 |  |  | 12,292 |  |
| Property, plant and equipment - net | 6,105 |  |  | 6,121 |  |
| Goodwill | 19,717 |  |  | 19,688 |  |
| Other intangible assets - net | 6,657 |  |  | 6,741 |  |
| Investments in partially-owned affiliates | 1,219 |  |  | 1,191 |  |
| Noncurrent assets held for sale | — |  |  | 1,920 |  |
| Other noncurrent assets | 3,640 |  |  | 3,931 |  |
|  | Total assets | $ | 49,767 |  |  | $ | 51,884 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Short-term debt and current portion of long-term debt | $ | 1,605 |  |  | $ | 1,608 |  |
| Accounts payable and accrued expenses | 4,903 |  |  | 5,342 |  |
| Liabilities held for sale | — |  |  | 72 |  |
| Other current liabilities | 4,738 |  |  | 4,832 |  |
|  | Current liabilities | 11,246 |  |  | 11,854 |  |
| Long-term debt | 10,895 |  |  | 11,964 |  |
| Other noncurrent liabilities | 5,900 |  |  | 6,315 |  |
| Noncurrent liabilities held for sale | — |  |  | 173 |  |
| Redeemable noncontrolling interests | 226 |  |  | 211 |  |
| Shareholders' equity attributable to JCI | 20,535 |  |  | 20,447 |  |
| Noncontrolling interests | 965 |  |  | 920 |  |
|  | Total liabilities and equity | $ | 49,767 |  |  | $ | 51,884 |  |

[0000833444-18-000004:8k_2_02:80]
Page 9 of 15

[0000833444-18-000004:8k_2_02:81]
| January 31, 2018JOHNSON CONTROLS INTERNATIONAL PLCCONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS(in millions; unaudited) |
|  |  |  |  |  |  | Three Months Ended December 31, |
|  |  |  |  |  |  | 2017 |  |  | 2016 |
| Operating Activities |  |  |  |  |
| Net income attributable to JCI | $ | 230 |  |  |  | $ | 329 |  |
| Income from continuing operations attributable to noncontrolling interests | 41 |  |  |  | 40 |  |
| Income from discontinued operations attributable to noncontrolling interests | — |  |  |  | 9 |  |
| Net income | 271 |  |  |  | 378 |  |
| Adjustments to reconcile net income to cash used by operating activities: |  |  |  |  |
|  |  | Depreciation and amortization | 272 |  |  |  | 346 |  |
|  |  | Pension and postretirement benefit income | (36 | ) |  |  | (155 | ) |
|  |  | Pension and postretirement contributions | (24 | ) |  |  | (247 | ) |
|  |  | Equity in earnings of partially-owned affiliates, net of dividends received | (36 | ) |  |  | (64 | ) |
|  |  | Deferred income taxes | (79 | ) |  |  | 580 |  |
|  |  | Non-cash restructuring and impairment costs | 30 |  |  |  | 16 |  |
|  |  | Gain on business divestitures | (114 | ) |  |  | — |  |
|  |  | Other - net | 17 |  |  |  | 37 |  |
|  |  | Changes in assets and liabilities, excluding acquisitions and divestitures: |  |  |  |  |
|  |  |  |  | Accounts receivable | (30 | ) |  |  | 37 |  |
|  |  |  |  | Inventories | (233 | ) |  |  | (142 | ) |
|  |  |  |  | Other assets | 64 |  |  |  | (87 | ) |
|  |  |  |  | Restructuring reserves | 93 |  |  |  | 20 |  |
|  |  |  |  | Accounts payable and accrued liabilities | (623 | ) |  |  | (796 | ) |
|  |  |  |  | Accrued income taxes | 299 |  |  |  | (1,808 | ) |
|  |  |  |  |  | Cash used by operating activities | (129 | ) |  |  | (1,885 | ) |
| Investing Activities |  |  |  |  |
| Capital expenditures | (230 | ) |  |  | (371 | ) |
| Sale of property, plant and equipment | 5 |  |  |  | 2 |  |
| Acquisition of businesses, net of cash acquired | — |  |  |  | (3 | ) |
| Business divestitures, net of cash divested | 2,011 |  |  |  | 47 |  |
| Other - net | (12 | ) |  |  | (6 | ) |
|  |  |  |  |  | Cash provided (used) by investing activities | 1,774 |  |  |  | (331 | ) |
| Financing Activities |  |  |  |  |
| Increase (decrease) in short and long-term debt - net | (1,045 | ) |  |  | 556 |  |
| Debt financing costs | (4 | ) |  |  | (6 | ) |
| Stock repurchases | (150 | ) |  |  | — |  |
| Payment of cash dividends | (232 | ) |  |  | — |  |
| Proceeds from the exercise of stock options | 16 |  |  |  | 29 |  |
| Dividends paid to noncontrolling interests | — |  |  |  | (31 | ) |
| Dividend from Adient spin-off | — |  |  |  | 2,050 |  |
| Cash transferred to Adient related to spin-off | — |  |  |  | (564 | ) |
| Cash paid related to prior acquisitions | — |  |  |  | (45 | ) |
| Other - net | (25 | ) |  |  | (25 | ) |
|  |  |  |  |  | Cash provided (used) by financing activities | (1,440 | ) |  |  | 1,964 |  |
| Effect of exchange rate changes on cash and cash equivalents | 17 |  |  |  | (55 | ) |
| Change in cash held for sale | 9 |  |  |  | 105 |  |
| Increase (decrease) in cash and cash equivalents | $ | 231 |  |  |  | $ | (202 | ) |

[0000833444-18-000004:8k_2_02:82]
Page 10 of 15

[0000833444-18-000004:8k_2_02:83]
January 31, 2018

[0000833444-18-000004:8k_2_02:84]
FOOTNOTES

[0000833444-18-000004:8k_2_02:85]
1. Financial Summary

[0000833444-18-000004:8k_2_02:86]
The Company evaluates the performance of its business units primarily on segment earnings before interest, taxes and amortization (EBITA), which represents income from continuing operations before income taxes and noncontrolling interests, excluding general corporate expenses, intangible asset amortization, net financing charges, significant restructuring and impairment costs, and the net mark-to-market adjustments related to pension and postretirement plans.

[0000833444-18-000004:8k_2_02:87]
|  | Three Months Ended December 31, |
| (in millions; unaudited) | 2017 |  | 2016 |
|  | Actual |  | Adjusted Non-GAAP |  | Actual |  | Adjusted Non-GAAP |
| Net sales (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 2,012 |  |  | $ | 2,012 |  |  | $ | 1,942 |  |  | $ | 1,942 |  |
| Building Solutions EMEA/LA | 915 |  |  | 915 |  |  | 875 |  |  | 878 |  |
| Building Solutions Asia Pacific | 597 |  |  | 597 |  |  | 575 |  |  | 576 |  |
| Global Products | 1,781 |  |  | 1,781 |  |  | 1,794 |  |  | 1,800 |  |
| Total Building Technologies & Solutions | 5,305 |  |  | 5,305 |  |  | 5,186 |  |  | 5,196 |  |
| Power Solutions | 2,130 |  |  | 2,130 |  |  | 1,900 |  |  | 1,900 |  |
| Net sales | $ | 7,435 |  |  | $ | 7,435 |  |  | $ | 7,086 |  |  | $ | 7,096 |  |
| Segment EBITA (1) |  |  |  |  |  |  |  |
| Building Solutions North America | $ | 227 |  |  | $ | 236 |  |  | $ | 196 |  |  | $ | 236 |  |
| Building Solutions EMEA/LA | 69 |  |  | 71 |  |  | 49 |  |  | 65 |  |
| Building Solutions Asia Pacific | 74 |  |  | 74 |  |  | 63 |  |  | 72 |  |
| Global Products | 286 |  |  | 178 |  |  | 127 |  |  | 205 |  |
| Total Building Technologies & Solutions | 656 |  |  | 559 |  |  | 435 |  |  | 578 |  |
| Power Solutions | 384 |  |  | 384 |  |  | 389 |  |  | 390 |  |
| Segment EBITA | 1,040 |  |  | 943 |  |  | 824 |  |  | 968 |  |
| Corporate expenses (2) | (134 | ) |  | (101 | ) |  | (193 | ) |  | (108 | ) |
| Amortization of intangible assets (3) | (94 | ) |  | (94 | ) |  | (149 | ) |  | (103 | ) |
| Mark-to-market gain for pension plans (4) | — |  |  | — |  |  | 117 |  |  | — |  |
| Restructuring and impairment costs (5) | (158 | ) |  | — |  |  | (78 | ) |  | — |  |
| EBIT (6) | 654 |  |  | 748 |  |  | 521 |  |  | 757 |  |
| Net financing charges (7) | (116 | ) |  | (116 | ) |  | (136 | ) |  | (119 | ) |
| Income from continuing operations before income taxes | 538 |  |  | 632 |  |  | 385 |  |  | 638 |  |
| Income tax benefit (provision) (8) | (267 | ) |  | (89 | ) |  | 27 |  |  | (96 | ) |
| Income from continuing operations | 271 |  |  | 543 |  |  | 412 |  |  | 542 |  |
| Income from continuing operations attributable to noncontrolling interests | (41 | ) |  | (41 | ) |  | (40 | ) |  | (40 | ) |
| Net income from continuing operations attributable to JCI | $ | 230 |  |  | $ | 502 |  |  | $ | 372 |  |  | $ | 502 |  |

[0000833444-18-000004:8k_2_02:88]
Building Technologies & Solutions - Provides facility systems and services including comfort, energy and security management for the non-residential buildings market, and provides heating, ventilating, and air conditioning products and services, security products and services, and fire detection and suppression products and services.

[0000833444-18-000004:8k_2_02:89]
Power Solutions - Services both automotive original equipment manufacturers and the battery aftermarket by providing advanced battery technology, coupled with systems engineering, marketing and service expertise.

[0000833444-18-000004:8k_2_02:90]
Page 11 of 15

[0000833444-18-000004:8k_2_02:91]
January 31, 2018

[0000833444-18-000004:8k_2_02:92]
(1) The Company's press release contains financial information regarding adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margins, which are non-GAAP performance measures.  The Company's definition of adjusted segment EBITA excludes special items because these costs are not considered to be directly related to the underlying operating performance of its business units.  Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-18-000004:8k_2_02:93]
The following is the three months ended December 31, 2017 and 2016 reconciliation of net sales, segment EBITA and segment EBITA margin as reported to adjusted net sales, adjusted segment EBITA and adjusted segment EBITA margin (unaudited):

[0000833444-18-000004:8k_2_02:94]
| (in millions) | Building SolutionsNorth America |  | Building Solutions EMEA/LA |  | Building Solutions Asia Pacific |  | Global Products |  | Total Building Technologies & Solutions |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net sales as reported | $ | 2,012 |  |  | $ | 1,942 |  |  | $ | 915 |  |  | $ | 875 |  |  | $ | 597 |  |  | $ | 575 |  |  | $ | 1,781 |  |  | $ | 1,794 |  |  | $ | 5,305 |  |  | $ | 5,186 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring purchase accounting impacts | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 1 |  |  | — |  |  | 6 |  |  | — |  |  | 10 |  |
| Adjusted net sales | $ | 2,012 |  |  | $ | 1,942 |  |  | $ | 915 |  |  | $ | 878 |  |  | $ | 597 |  |  | $ | 576 |  |  | $ | 1,781 |  |  | $ | 1,800 |  |  | $ | 5,305 |  |  | $ | 5,196 |  |
| Segment EBITA as reported | $ | 227 |  |  | $ | 196 |  |  | $ | 69 |  |  | $ | 49 |  |  | $ | 74 |  |  | $ | 63 |  |  | $ | 286 |  |  | $ | 127 |  |  | $ | 656 |  |  | $ | 435 |  |
| Segment EBITA margin as reported | 11.3 | % |  | 10.1 | % |  | 7.5 | % |  | 5.6 | % |  | 12.4 | % |  | 11.0 | % |  | 16.1 | % |  | 7.1 | % |  | 12.4 | % |  | 8.4 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | 10 |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |  | — |  |  | 3 |  |  | — |  |  | 17 |  |
| Integration costs | 9 |  |  | 7 |  |  | 2 |  |  | 2 |  |  | — |  |  | 1 |  |  | 6 |  |  | 4 |  |  | 17 |  |  | 14 |  |
| Scott Safety gain on sale | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (114 | ) |  | — |  |  | (114 | ) |  | — |  |
| Nonrecurring purchase accounting impacts | — |  |  | 23 |  |  | — |  |  | 12 |  |  | — |  |  | 6 |  |  | — |  |  | 71 |  |  | — |  |  | 112 |  |
| Adjusted segment EBITA | $ | 236 |  |  | $ | 236 |  |  | $ | 71 |  |  | $ | 65 |  |  | $ | 74 |  |  | $ | 72 |  |  | $ | 178 |  |  | $ | 205 |  |  | $ | 559 |  |  | $ | 578 |  |
| Adjusted segment EBITA margin | 11.7 | % |  | 12.2 | % |  | 7.8 | % |  | 7.4 | % |  | 12.4 | % |  | 12.5 | % |  | 10.0 | % |  | 11.4 | % |  | 10.5 | % |  | 11.1 | % |

[0000833444-18-000004:8k_2_02:95]
| (in millions) | Total Building Technologies & Solutions |  | Power Solutions |  | Consolidated JCI plc |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net sales as reported | $ | 5,305 |  |  | $ | 5,186 |  |  | $ | 2,130 |  |  | $ | 1,900 |  |  | $ | 7,435 |  |  | $ | 7,086 |  |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Nonrecurring purchase accounting impacts | — |  |  | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |
| Adjusted net sales | $ | 5,305 |  |  | $ | 5,196 |  |  | $ | 2,130 |  |  | $ | 1,900 |  |  | $ | 7,435 |  |  | $ | 7,096 |  |
| Segment EBITA as reported | $ | 656 |  |  | $ | 435 |  |  | $ | 384 |  |  | $ | 389 |  |  | $ | 1,040 |  |  | $ | 824 |  |
| Segment EBITA margin as reported | 12.4 | % |  | 8.4 | % |  | 18.0 | % |  | 20.5 | % |  | 14.0 | % |  | 11.6 | % |
| Adjusting items: |  |  |  |  |  |  |  |  |  |  |  |
| Transaction costs | — |  |  | 17 |  |  | — |  |  | 1 |  |  | — |  |  | 18 |  |
| Integration costs | 17 |  |  | 14 |  |  | — |  |  | — |  |  | 17 |  |  | 14 |  |
| Scott Safety gain on sale | (114 | ) |  | — |  |  | — |  |  | — |  |  | (114 | ) |  | — |  |
| Nonrecurring purchase accounting impacts | — |  |  | 112 |  |  | — |  |  | — |  |  | — |  |  | 112 |  |
| Adjusted segment EBITA | $ | 559 |  |  | $ | 578 |  |  | $ | 384 |  |  | $ | 390 |  |  | $ | 943 |  |  | $ | 968 |  |
| Adjusted segment EBITA margin | 10.5 | % |  | 11.1 | % |  | 18.0 | % |  | 20.5 | % |  | 12.7 | % |  | 13.6 | % |

[0000833444-18-000004:8k_2_02:96]
(2) Adjusted Corporate expenses for the three months ended December 31, 2017 excludes $28 million of integration costs and $5 million of transaction costs.  Adjusted Corporate expenses for the three months ended December 31, 2016 excludes $50 million of integration costs, $31 million of transaction costs and $4 million of separation costs.

[0000833444-18-000004:8k_2_02:97]
(3) Adjusted amortization of intangible assets for the three months ended December 31, 2016 excludes $46 million of nonrecurring asset amortization related to Tyco purchase accounting.

[0000833444-18-000004:8k_2_02:98]
(4) The three months ended December 31, 2016 pension and postretirement mark-to-market gain of $117 million due to lump sum payouts for certain U.S. pension plans in the quarter is excluded from the adjusted non-GAAP results.

[0000833444-18-000004:8k_2_02:99]
(5) Restructuring and impairment costs for the three months ended December 31, 2017 and 2016 of $158 million and $78 million, respectively, are excluded from the adjusted non-GAAP results.

[0000833444-18-000004:8k_2_02:100]
(6) Management defines earnings before interest and taxes (EBIT) as income from continuing operations before net financing charges, income taxes and noncontrolling interests.

[0000833444-18-000004:8k_2_02:101]
(7) Adjusted net financing charges for the three months ended December 31, 2016 exclude $17 million of transaction costs related to the debt exchange offers.

[0000833444-18-000004:8k_2_02:102]
(8) Adjusted income tax provision for the three months ended December 31, 2017 excludes the net tax provision related to the U.S. Tax Reform legislation of $204 million and the Scott Safety gain on sale of $30 million, partially offset by the tax benefits for tax audit settlements of $25 million, restructuring and impairment costs of $24 million, integration costs of $6 million and transaction costs of $1 million.  Adjusted income tax provision for the three months ended December 31, 2016 excludes the tax benefits of changes in entity tax status of $101 million, Tyco nonrecurring purchase accounting impacts of $43 million, restructuring and impairment costs of $14 million, integration costs of $7 million and transaction costs of $4 million, partially offset by the tax provision for gain on mark-to-market pension of $46 million.

[0000833444-18-000004:8k_2_02:103]
Page 12 of 15

[0000833444-18-000004:8k_2_02:104]
January 31, 2018

[0000833444-18-000004:8k_2_02:105]
2.  Diluted Earnings Per Share Reconciliation

[0000833444-18-000004:8k_2_02:106]
The Company's press release contains financial information regarding adjusted earnings per share, which is a non-GAAP performance measure.  The adjusting items include transaction/integration/separation costs, nonrecurring purchase accounting impacts related to the Tyco merger, mark-to-market gain or loss for pension and postretirement plans, Scott Safety gain on sale, restructuring and impairment costs and discrete tax items.  The Company excludes these items because they are not considered to be directly related to the underlying operating performance of the Company.  Management believes these non-GAAP measures are useful to investors in understanding the ongoing operations and business trends of the Company.

[0000833444-18-000004:8k_2_02:107]
A reconciliation of diluted earnings per share as reported to diluted adjusted earnings per share for the respective periods is shown below (unaudited):

[0000833444-18-000004:8k_2_02:108]
|  | Net Income Attributableto JCI plc |  | Net Income Attributable toJCI plc from ContinuingOperations |
|  | Three Months Ended |  | Three Months Ended |
|  | December 31, |  | December 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Earnings per share as reported for JCI plc | $ | 0.25 |  |  | $ | 0.35 |  |  | $ | 0.25 |  |  | $ | 0.39 |  |
| Adjusting items: |  |  |  |  |  |  |  |
| Transaction costs | 0.01 |  |  | 0.07 |  |  | 0.01 |  |  | 0.07 |  |
| Integration costs | 0.05 |  |  | 0.07 |  |  | 0.05 |  |  | 0.07 |  |
| Related tax impact | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |  | (0.01 | ) |
| Separation costs | — |  |  | 0.09 |  |  | — |  |  | — |  |
| Nonrecurring purchase accounting impacts | — |  |  | 0.17 |  |  | — |  |  | 0.17 |  |
| Related tax impact | — |  |  | (0.05 | ) |  | — |  |  | (0.05 | ) |
| Mark-to-market gain for pension plans | — |  |  | (0.12 | ) |  | — |  |  | (0.12 | ) |
| Related tax impact | — |  |  | 0.05 |  |  | — |  |  | 0.05 |  |
| Scott Safety gain on sale | (0.12 | ) |  | — |  |  | (0.12 | ) |  | — |  |
| Related tax impact | 0.03 |  |  | — |  |  | 0.03 |  |  | — |  |
| Restructuring and impairment costs | 0.17 |  |  | 0.08 |  |  | 0.17 |  |  | 0.08 |  |
| Related tax impact | (0.03 | ) |  | (0.01 | ) |  | (0.03 | ) |  | (0.01 | ) |
| Discrete tax items | 0.19 |  |  | (0.08 | ) |  | 0.19 |  |  | (0.11 | ) |
| Adjusted earnings per share for JCI plc* | $ | 0.54 |  |  | $ | 0.59 |  |  | $ | 0.54 |  |  | $ | 0.53 |  |

[0000833444-18-000004:8k_2_02:109]
* May not sum due to rounding.

[0000833444-18-000004:8k_2_02:110]
The following table reconciles the denominators used to calculate basic and diluted earnings per share for JCI plc (in millions; unaudited):

[0000833444-18-000004:8k_2_02:111]
|  | Three Months Ended |
|  | December 31, |
|  | 2017 |  | 2016 |
| Weighted Average Shares Outstanding for JCI plc |  |  |  |
| Basic weighted average shares outstanding | 926.1 |  |  | 937.2 |  |
| Effect of dilutive securities: |  |  |  |
| Stock options, unvested restricted stock |  |  |  |
| and unvested performance share awards | 7.2 |  |  | 10.2 |  |
| Diluted weighted average shares outstanding | 933.3 |  |  | 947.4 |  |

[0000833444-18-000004:8k_2_02:112]
The Company has presented forward-looking statements regarding adjusted EPS from continuing operations, adjusted EBIT margin, organic adjusted net sales growth and adjusted free cash flow conversion (defined as adjusted free cash flow divided by adjusted net income from continuing operations attributable to JCI) for the full fiscal year of 2018, which are non-GAAP financial measures. These non-GAAP financial measures are derived by excluding certain amounts, expenses, income or cash flows from the corresponding financial measures determined in accordance with GAAP. The determination of the amounts that are excluded from these non-GAAP financial measures are a matter of management judgment and depends upon, among other factors, the nature of the underlying expense or income amounts recognized in a given period, including but not limited to the high variability of the net mark-to-market adjustments related to pension and postretirement plans and the effect of foreign currency exchange fluctuations.  Our fiscal 2018 outlook for organic adjusted net sales growth also excludes the effect of acquisitions and divestitures, and for our Power Solutions business, the impacts of lead price fluctuations.  We are unable to present a quantitative reconciliation of the aforementioned forward-looking non-GAAP financial measures to their most directly comparable forward-looking GAAP financial measures because such information is not available and management cannot reliably predict all of the necessary components of such GAAP measures without unreasonable effort or expense. The unavailable information could have a significant impact on the Company’s full year 2018 GAAP financial results.

[0000833444-18-000004:8k_2_02:113]
Page 13 of 15

[0000833444-18-000004:8k_2_02:114]
January 31, 2018

[0000833444-18-000004:8k_2_02:115]
3. Organic Adjusted Net Sales Growth Reconciliation

[0000833444-18-000004:8k_2_02:116]
The components of the changes in adjusted net sales for the three months ended December 31, 2017 versus the three months ended December 31, 2016, including organic net sales, is shown below (unaudited):

[0000833444-18-000004:8k_2_02:117]
| (in millions) | Adjusted Net Sales for the Three Months Ended December 31, 2016 |  | Base Year Adjustments -Divestitures |  | Adjusted Base Net Sales for the Three Months Ended December 31, 2016 |  | Foreign Currency |  | Lead Impact |  | Organic Net Sales |  | Adjusted Net Sales for the Three Months EndedDecember 31, 2017 |
| Building Solutions North America | $ | 1,942 |  |  | $ | — |  |  | 0.0 | % |  | $ | 1,942 |  |  | $ | 10 |  |  | 0.5 | % |  | $ | — |  |  | 0.0 | % |  | $ | 60 |  |  | 3.1 | % |  | $ | 2,012 |  |  | 3.6 | % |
| Building Solutions EMEA/LA | 878 |  |  | (43 | ) |  | -4.9 | % |  | 835 |  |  | 47 |  |  | 5.6 | % |  | — |  |  | 0.0 | % |  | 33 |  |  | 4.0 | % |  | 915 |  |  | 9.6 | % |
| Building Solutions Asia Pacific | 576 |  |  | (7 | ) |  | -1.2 | % |  | 569 |  |  | 14 |  |  | 2.5 | % |  | — |  |  | 0.0 | % |  | 14 |  |  | 2.5 | % |  | 597 |  |  | 4.9 | % |
| Global Products | 1,800 |  |  | (138 | ) |  | -7.7 | % |  | 1,662 |  |  | 23 |  |  | 1.4 | % |  | — |  |  | 0.0 | % |  | 96 |  |  | 5.8 | % |  | 1,781 |  |  | 7.2 | % |
| Total Building Technologies & Solutions | 5,196 |  |  | (188 | ) |  | -3.6 | % |  | 5,008 |  |  | 94 |  |  | 1.9 | % |  | — |  |  | 0.0 | % |  | 203 |  |  | 4.1 | % |  | 5,305 |  |  | 5.9 | % |
| Power Solutions | 1,900 |  |  | — |  |  | 0.0 | % |  | 1,900 |  |  | 78 |  |  | 4.1 | % |  | 131 |  |  | 6.9 | % |  | 21 |  |  | 1.1 | % |  | 2,130 |  |  | 12.1 | % |
| Total net sales | $ | 7,096 |  |  | $ | (188 | ) |  | -2.6 | % |  | $ | 6,908 |  |  | $ | 172 |  |  | 2.5 | % |  | $ | 131 |  |  | 1.9 | % |  | $ | 224 |  |  | 3.2 | % |  | $ | 7,435 |  |  | 7.6 | % |

[0000833444-18-000004:8k_2_02:118]
4.  Adjusted Free Cash Flow Reconciliation

[0000833444-18-000004:8k_2_02:119]
The Company's press release contains financial information regarding free cash flow and adjusted free cash flow, which are non-GAAP performance measures.  Free cash flow is defined as cash used by operating activities less capital expenditures.  Adjusted free cash flow excludes special items, as included in the table below, because these cash flows are not considered to be directly related to its underlying business.  Management believes these non-GAAP measures are useful to investors in understanding the strength of the Company and its ability to generate cash.

[0000833444-18-000004:8k_2_02:120]
The following is the three months ended December 31, 2017 and 2016 reconciliation of free cash flow and adjusted free cash flow (unaudited):

[0000833444-18-000004:8k_2_02:121]
| (in billions) | Three Months Ended December 31, 2017 |  | Three Months Ended December 31, 2016 |
| Cash used by operating activities | $ | (0.1 | ) |  | $ | (1.9 | ) |
| Capital expenditures | (0.2 | ) |  | (0.4 | ) |
| Reported free cash flow* | $ | (0.4 | ) |  | $ | (2.3 | ) |
| Adjusting items: |  |  |  |
| Transaction/integration/separation costs | 0.1 |  |  | 0.2 |  |
| Transaction tax payments | — |  |  | 1.2 |  |
| Adient cash outflow | — |  |  | 0.3 |  |
| Change in control pension payment | — |  |  | 0.2 |  |
| Transaction related restructuring | — |  |  | 0.1 |  |
| Total adjusting items | 0.1 |  |  | 2.0 |  |
| Adjusted free cash flow | $ | (0.3 | ) |  | $ | (0.3 | ) |

[0000833444-18-000004:8k_2_02:122]
* May not sum due to rounding

[0000833444-18-000004:8k_2_02:123]
Page 14 of 15

[0000833444-18-000004:8k_2_02:124]
January 31, 2018

[0000833444-18-000004:8k_2_02:125]
5.  Net Debt to Capitalization

[0000833444-18-000004:8k_2_02:126]
The Company provides financial information regarding net debt as a percentage of total capitalization, which is a non-GAAP performance measure.  The Company believes the percentage of total net debt to total capitalization is useful to understanding the Company's financial condition as it provides a review of the extent to which the Company relies on external debt financing for its funding and is a measure of risk to its shareholders.  The following is the December 31, 2017 and September 30, 2017 calculation of net debt as a percentage of total capitalization (unaudited):

[0000833444-18-000004:8k_2_02:127]
| (in millions) | December 31, 2017 |  | September 30, 2017 |
| Short-term debt and current portion of long-term debt | $ | 1,605 |  |  | $ | 1,608 |  |
| Long-term debt | 10,895 |  |  | 11,964 |  |
| Total debt | 12,500 |  |  | 13,572 |  |
| Less: cash and cash equivalents | 552 |  |  | 321 |  |
| Total net debt | 11,948 |  |  | 13,251 |  |
| Shareholders' equity attributable to JCI | 20,535 |  |  | 20,447 |  |
| Total capitalization | $ | 32,483 |  |  | $ | 33,698 |  |
| Total net debt as a % of total capitalization | 36.8 | % |  | 39.3 | % |

[0000833444-18-000004:8k_2_02:128]
6.  Mark-to-Market of Pension and Postretirement Plans

[0000833444-18-000004:8k_2_02:129]
The pension and postretirement mark-to-market gain or loss for each period is excluded from adjusted diluted earnings per share.  There was no mark-to-market gain or loss for pension and postretirement plans for the three months ended December 31, 2017.  The three months ended December 31, 2016 includes a mark-to-market gain for pension plans of $117 million due to lump sum payouts for certain U.S. pension plans in the quarter.

[0000833444-18-000004:8k_2_02:130]
7.  Divestitures

[0000833444-18-000004:8k_2_02:131]
On March 16, 2017, the Company announced that it signed a definitive agreement to sell its Scott Safety business to 3M for approximately $2.0 billion.  The transaction closed on October 4, 2017.  Net cash proceeds from the transaction approximated $1.9 billion and the Company recorded a net gain of $114 million ($84 million after tax).  Scott Safety is a leader in the design, manufacture and sale of high performance respiratory protection, gas and flame detection, thermal imaging and other critical products for fire services, law enforcement, industrial, oil and gas, chemical, armed forces, and homeland defense end markets.  The Scott Safety business is included within assets held for sale and liabilities held for sale in the accompanying condensed consolidated statement of financial position as of September 30, 2017.

[0000833444-18-000004:8k_2_02:132]
On October 31, 2016, the Company completed the spin-off of its Automotive Experience business by way of the transfer of the Automotive Experience business from JCI plc to Adient plc and the issuance of ordinary shares of Adient plc directly to holders of JCI plc ordinary shares on a pro rata basis.  Following the separation, Adient plc is now an independent public company trading on the New York Stock Exchange (NYSE) under the symbol "ADNT." The Company did not retain any equity interest in Adient plc.  Beginning in the first quarter of fiscal 2017, Adient’s historical financial results are reflected in the Company’s consolidated financial statements as a discontinued operation.

[0000833444-18-000004:8k_2_02:133]
8. Income Taxes

[0000833444-18-000004:8k_2_02:134]
The Company's effective tax rate from continuing operations before consideration of the transaction/integration/separation costs, nonrecurring purchase accounting impacts related to the Tyco merger, mark-to-market gains or losses for pension and postretirement plans, Scott Safety gain on sale, restructuring and impairment costs and discrete tax items for the three months ending December 31, 2017 and 2016 is approximately 14 percent and 15 percent, respectively.

[0000833444-18-000004:8k_2_02:135]
9. Restructuring

[0000833444-18-000004:8k_2_02:136]
The three months ended December 31, 2017 include restructuring and impairment costs of $158 million related primarily to workforce reductions, plant closures and asset impairments in the Building Technologies & Solutions and Power Solutions businesses, and at Corporate.  The three months ended December 31, 2016 restructuring and impairment costs of $78 million related primarily to workforce reductions, plant closures and asset impairments in the Building Technologies & Solutions business and at Corporate.

[0000833444-18-000004:8k_2_02:137]
Page 15 of 15
