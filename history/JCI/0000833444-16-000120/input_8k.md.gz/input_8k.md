# JCI 8-K — 0000833444-16-000116 filed 2016-01-29

## item codes, every 8-K on or before 2016-01-29

- 2016-01-29 0000833444-16-000116 — 2.02, 9.01
- 2016-01-27 0001193125-16-439970 — 1.01, 5.02, 9.01
- 2016-01-25 0001193125-16-436237 — 8.01, 9.01
- 2016-01-19 0000833444-16-000105 — 8.01
- 2015-12-22 0000833444-15-000098 — 8.01, 9.01
- 2015-12-04 0000833444-15-000094 — 8.01, 9.01
- 2015-11-13 0000833444-15-000088 — 2.02, 9.01
- 2015-10-13 0000833444-15-000077 — 5.02, 9.01
- 2015-10-09 0000833444-15-000074 — 7.01, 9.01
- 2015-09-14 0001193125-15-319578 — 8.01
- 2015-09-14 0001193125-15-319248 — 1.01, 8.01, 9.01
- 2015-09-11 0000833444-15-000071 — 7.01, 9.01
- 2015-08-20 0000833444-15-000068 — 8.01
- 2015-08-11 0000833444-15-000066 — 1.01, 1.02, 8.01, 9.01
- 2015-07-31 0000833444-15-000060 — 2.02, 9.01
- 2015-04-24 0000833444-15-000028 — 2.02, 9.01
- 2015-03-04 0000833444-15-000015 — 5.07
- 2015-02-25 0001193125-15-062255 — 1.01, 8.01, 9.01
- 2015-01-30 0000833444-15-000010 — 2.02, 9.01
- 2015-01-14 0000833444-15-000002 — 8.01
- 2014-12-10 0000833444-14-000130 — 8.01, 9.01
- 2014-12-02 0000833444-14-000128 — 5.02
- 2014-11-17 0001193125-14-414675 — 1.01, 2.03, 5.02, 7.01, 8.01, 9.01
- 2014-11-13 0000833444-14-000121 — 2.02, 9.01
- 2014-10-14 0000833444-14-000111 — 8.01, 9.01
- 2014-09-11 0000833444-14-000108 — 5.07, 8.01, 9.01
- 2014-07-30 0001193125-14-285133 — 8.01, 9.01
- 2014-07-30 0000833444-14-000104 — 8.01
- 2014-07-25 0000833444-14-000095 — 2.02, 9.01
- 2014-06-04 0000833444-14-000083 — 1.01, 9.01
- 2014-05-29 0000833444-14-000076 — 2.01, 9.01
- 2014-05-22 0000833444-14-000069 — 8.01, 9.01
- 2014-05-16 0000833444-14-000066 — 8.01, 9.01
- 2014-05-16 0000833444-14-000065 — 8.01, 9.01
- 2014-04-25 0000833444-14-000043 — 2.02, 9.01
- 2014-04-09 0000833444-14-000033 — 8.01, 9.01
- 2014-03-10 0000833444-14-000029 — 8.01
- 2014-03-06 0000833444-14-000026 — 5.07
- 2014-03-04 0001193125-14-082304 — 1.01, 7.01, 8.01, 9.01
- 2014-01-31 0000833444-14-000018 — 2.02, 9.01
- 2013-11-22 0000833444-13-000047 — 5.02, 9.01
- 2013-11-14 0001104659-13-084412 — 2.02, 8.01, 9.01
- 2013-07-26 0001104659-13-056833 — 2.02, 9.01
- 2013-07-01 0000833444-13-000027 — 8.01
- 2013-06-20 0001104659-13-050411 — 8.01, 9.01
- 2013-05-17 0001104659-13-042794 — 8.01, 9.01
- 2013-04-26 0001104659-13-033205 — 2.02, 9.01
- 2013-03-08 0001104659-13-018830 — 5.07
- 2013-01-29 0001104659-13-005337 — 2.02, 9.01
- 2012-11-21 0001104659-12-079621 — 5.02
- 2012-11-14 0001104659-12-077609 — 2.02, 9.01
- 2012-10-04 0001193125-12-415566 — 2.01, 9.01
- 2012-10-01 0001193125-12-411575 — 1.01, 2.01, 5.02, 8.01, 9.01
- 2012-09-19 0001193125-12-396968 — 5.02, 9.01
- 2012-09-18 0001193125-12-394755 — 7.01, 9.01
- 2012-09-17 0001193125-12-393309 — 5.07, 7.01, 9.01
- 2012-09-13 0001193125-12-389634 — 8.01, 9.01
- 2012-09-07 0001193125-12-383453 — 8.01, 9.01
- 2012-08-10 0001104659-12-056984 — 7.01, 9.01
- 2012-07-31 0001104659-12-052438 — 2.02, 8.01, 9.01
- 2012-07-31 0001104659-12-052376 — 1.01, 9.01
- 2012-07-16 0001104659-12-049137 — 5.02
- 2012-07-12 0001104659-12-048695 — 7.01, 9.01
- 2012-07-05 0001104659-12-047604 — 1.01, 2.03, 9.01
- 2012-06-27 0001104659-12-046254 — 7.01, 8.01, 9.01
- 2012-06-27 0001104659-12-046035 — 1.01, 1.02, 9.01
- 2012-05-09 0001193125-12-219591 — 8.01, 9.01
- 2012-05-08 0001104659-12-034596 — 5.02, 9.01
- 2012-04-26 0001104659-12-028592 — 2.02, 9.01
- 2012-04-10 0001193125-12-157405 — 8.01, 9.01
- 2012-03-30 0001104659-12-022925 — 1.01, 8.01, 9.01
- 2012-03-28 0001104659-12-021545 — 8.01, 9.01
- 2012-03-12 0001104659-12-017581 — 5.07, 8.01, 9.01
- 2012-01-31 0001104659-12-005214 — 2.02, 7.01
- 2012-01-31 0001104659-12-005213 — 2.02, 9.01
- 2011-11-17 0001104659-11-064889 — 5.02
- 2011-11-16 0001104659-11-064463 — 2.02, 9.01
- 2011-10-14 0001104659-11-056195 — 5.02, 9.01
- 2011-09-19 0001104659-11-052170 — 5.02, 8.01, 9.01
- 2011-09-16 0001104659-11-052076 — 8.01, 9.01
- 2011-07-28 0001104659-11-041275 — 2.02, 9.01
- 2011-06-02 0001104659-11-032793 — 8.01, 9.01 — amendment of 0001104659-11-032568
- 2011-06-01 0001104659-11-032568 — 8.01, 9.01
- 2011-04-28 0001104659-11-023137 — 2.02, 8.01, 9.01
- 2011-03-28 0001104659-11-016822 — 1.01, 1.02, 2.03, 9.01
- 2011-03-21 0001104659-11-015492 — 8.01, 9.01
- 2011-03-14 0001104659-11-014127 — 5.07, 9.01
- 2011-02-23 0001104659-11-009319 — 8.01, 9.01
- 2011-01-27 0001104659-11-003237 — 2.02, 9.01
- 2011-01-25 0001104659-11-002782 — 7.01
- 2011-01-12 0001104659-11-001263 — 1.01, 2.03, 9.01
- 2011-01-10 0001104659-11-000928 — 1.01, 9.01
- 2011-01-05 0001104659-11-000441 — 7.01
- 2010-12-22 0001104659-10-064042 — 8.01, 9.01
- 2010-12-14 0001104659-10-062522 — 2.02, 7.01, 9.01
- 2010-11-29 0001104659-10-060350 — 8.01, 9.01
- 2010-11-10 0001104659-10-057379 — 1.01, 8.01, 9.01
- 2010-11-09 0001104659-10-057083 — 2.02, 9.01
- 2010-10-12 0001104659-10-052041 — 5.02, 9.01
- 2010-09-14 0001104659-10-048534 — 8.01
- 2010-08-17 0001104659-10-044842 — 8.01
- 2010-07-29 0001104659-10-040319 — 2.02, 8.01, 9.01
- 2010-05-28 0001104659-10-031329 — 8.01, 9.01
- 2010-05-14 0001104659-10-028737 — 5.03, 8.01, 9.01 — amendment of 0001104659-10-028613
- 2010-05-14 0001104659-10-028613 — 5.03, 8.01, 9.01
- 2010-05-10 0001104659-10-027227 — 8.01, 9.01
- 2010-05-05 0001104659-10-025703 — 1.01, 2.03, 9.01
- 2010-05-04 0001104659-10-025201 — 8.01
- 2010-05-03 0001104659-10-024481 — 1.01, 9.01
- 2010-04-28 0001104659-10-022581 — 8.01
- 2010-04-27 0001104659-10-021941 — 2.02, 8.01, 9.01
- 2010-03-22 0001104659-10-015662 — 1.01, 8.01, 9.01
- 2010-03-12 0001104659-10-014005 — 5.07, 8.01, 9.01
- 2010-03-11 0001104659-10-013777 — 7.01
- 2010-03-05 0001104659-10-012253 — 8.01
- 2010-03-01 0001104659-10-010600 — 8.01, 9.01
- 2010-02-09 0001104659-10-005548 — 8.01
- 2010-01-28 0001104659-10-003413 — 2.02, 9.01
- 2010-01-19 0001104659-10-001962 — 2.02, 9.01
- 2010-01-19 0001104659-10-001960 — 1.01, 8.01, 9.01
- 2009-12-15 0001104659-09-070021 — 8.01
- 2009-11-19 0001104659-09-065897 — 5.02
- 2009-11-10 0001104659-09-063829 — 2.02, 9.01
- 2009-10-05 0001104659-09-057777 — 5.02, 9.01
- 2009-10-05 0001104659-09-057741 — 1.01, 2.03, 9.01
- 2009-09-30 0001104659-09-056913 — 8.01, 9.01
- 2009-07-30 0001104659-09-045737 — 2.02, 9.01
- 2009-04-30 0001104659-09-027293 — 2.02, 9.01
- 2009-03-17 0001104659-09-018106 — 3.03, 5.03, 7.01, 8.01, 9.01
- 2009-02-03 0001104659-09-006050 — 5.02
- 2009-02-03 0001104659-09-005798 — 2.02, 9.01
- 2009-01-09 0001104659-09-001463 — 1.01, 2.03, 9.01
- 2008-12-19 0001104659-08-077498 — 1.01, 9.01
- 2008-12-11 0001104659-08-075989 — 8.01, 9.01
- 2008-12-10 0001104659-08-075745 — 5.02
- 2008-11-12 0001104659-08-069889 — 2.02, 9.01
- 2008-10-08 0001104659-08-062657 — 8.01, 9.01
- 2008-09-16 0001104659-08-058874 — 1.01, 9.01
- 2008-09-10 0001104659-08-057914 — 8.01, 9.01
- 2008-07-31 0001104659-08-048749 — 2.02, 9.01
- 2008-07-28 0001104659-08-047938 — 8.01, 9.01
- 2008-06-26 0001104659-08-042405 — 1.01, 2.03, 9.01
- 2008-06-05 0001104659-08-038267 — 1.01, 1.02, 2.03, 8.01, 9.01
- 2008-06-03 0001104659-08-037473 — 8.01, 9.01
- 2008-05-12 0001104659-08-032428 — 8.01, 9.01
- 2008-05-01 0001047469-08-005665 — 2.02, 9.01
- 2008-04-29 0001104659-08-027986 — 8.01
- 2008-04-29 0001104659-08-027985 — 8.01, 9.01
- 2008-04-16 0001104659-08-024715 — 8.01, 9.01
- 2008-04-14 0001104659-08-024156 — 8.01, 9.01
- 2008-04-11 0001104659-08-023908 — 8.01, 9.01
- 2008-03-05 0001104659-08-015508 — 7.01, 9.01
- 2008-03-05 0001104659-08-015507 — 8.01
- 2008-02-13 0001104659-08-009989 — 1.01, 9.01
- 2008-02-05 0001104659-08-007037 — 2.02, 9.01
- 2008-01-23 0001104659-08-004065 — 2.02, 9.01
- 2007-11-15 0001047469-07-009310 — 2.02, 9.01
- 2007-10-22 0001047469-07-007797 — 1.01, 9.01
- 2007-09-18 0001104659-07-069721 — 1.01, 8.01
- 2007-09-14 0001104659-07-069058 — 7.01, 9.01
- 2007-08-07 0001104659-07-059342 — 2.02, 9.01
- 2007-07-06 0001104659-07-052697 — 1.01, 1.02, 2.01, 5.02, 5.03, 7.01, 9.01
- 2007-07-03 0001104659-07-052190 — 7.01, 9.01
- 2007-06-26 0001104659-07-050025 — 1.02
- 2007-06-22 0001104659-07-049440 — 1.01, 2.03, 9.01
- 2007-06-13 0001104659-07-047272 — 2.06
- 2007-06-12 0001104659-07-047238 — 7.01, 9.01
- 2007-05-31 0001104659-07-044409 — 5.02, 9.01
- 2007-05-31 0001104659-07-044345 — 1.02
- 2007-05-30 0001104659-07-043969 — 1.01, 2.03, 9.01
- 2007-05-25 0001104659-07-043137 — 8.01, 9.01
- 2007-05-23 0001104659-07-042243 — 8.01, 9.01
- 2007-05-18 0001104659-07-041210 — 8.01, 9.01
- 2007-05-17 0001104659-07-040721 — 8.01, 9.01
- 2007-05-15 0001104659-07-039980 — 8.01, 9.01
- 2007-05-15 0001104659-07-039682 — 8.01, 9.01
- 2007-05-11 0001104659-07-038961 — 8.01, 9.01
- 2007-05-08 0001104659-07-036698 — 2.02
- 2007-04-27 0001104659-07-032168 — 8.01, 9.01
- 2007-04-27 0001104659-07-032013 — 1.01, 2.03, 9.01
- 2007-04-20 0001104659-07-029981 — 7.01, 9.01
- 2007-04-12 0001104659-07-027959 — 5.02, 9.01
- 2007-03-21 0001104659-07-021116 — 4.01
- 2007-03-21 0001104659-07-021114 — 4.01
- 2007-03-02 0001104659-07-015931 — 7.01, 9.01
- 2007-02-20 0001104659-07-012139 — 1.02, 5.02, 9.01
- 2007-02-06 0001104659-07-007369 — 2.02, 9.01
- 2007-01-18 0001104659-07-003155 — 7.01, 9.01
- 2007-01-17 0001104659-07-002865 — 5.02
- 2007-01-10 0001104659-07-001720 — 8.01, 9.01
- 2007-01-08 0001104659-07-001293 — 1.01, 1.02, 9.01
- 2006-12-15 0001104659-06-081885 — 8.01, 9.01
- 2006-12-05 0001104659-06-079560 — 4.01, 9.01
- 2006-12-05 0001104659-06-079559 — 4.01, 9.01
- 2006-11-15 0001104659-06-075215 — 2.02, 8.01, 9.01
- 2006-08-03 0001104659-06-050882 — 1.01, 2.02, 9.01
- 2006-07-19 0001104659-06-047752 — 1.01, 9.01
- 2006-07-19 0001104659-06-047750 — 1.01
- 2006-06-30 0001104659-06-044901 — 1.01
- 2006-05-16 0001104659-06-035276 — 8.01
- 2006-05-04 0001104659-06-030906 — 2.02, 9.01
- 2006-04-20 0001104659-06-026278 — 1.01, 9.01
- 2006-03-24 0001104659-06-019165 — 8.01, 9.01
- 2006-03-22 0001104659-06-018595 — 1.01, 9.01
- 2006-03-03 0001104659-06-013892 — 7.01, 9.01
- 2006-02-22 0001104659-06-011182 — 3.03, 9.01
- 2006-02-21 0001104659-06-010679 — 2.01, 9.01
- 2006-02-02 0001104659-06-005459 — 2.02, 9.01
- 2006-01-23 0001104659-06-003339 — 1.01, 9.01
- 2006-01-13 0001047469-06-000406 — 1.01, 2.02, 7.01, 9.01
- 2005-12-23 0001104659-05-062570 — 1.01, 9.01
- 2005-11-23 0001104659-05-057453 — 1.01
- 2005-11-16 0001104659-05-055980 — 2.02, 9.01
- 2005-09-19 0001104659-05-044691 — 7.01
- 2005-09-12 0001104659-05-043740 — 8.01
- 2005-09-08 0001104659-05-043364 — 7.01, 9.01
- 2005-08-02 0001104659-05-035495 — 2.02, 9.01
- 2005-07-05 0001047469-05-018856 — 8.01, 9.01
- 2005-05-03 0001047469-05-012841 — 8.01
- 2005-05-03 0001047469-05-012840 — 2.02, 9.01
- 2005-03-30 0001104659-05-013488 — 1.01, 1.02, 9.01
- 2005-03-16 0001104659-05-011551 — 1.01, 9.01
- 2005-02-15 0001047469-05-003941 — 1.01, 5.02, 9.01
- 2005-02-01 0001047469-05-001975 — 2.02, 9.01
- 2004-12-22 0001047469-04-037954 — 1.01, 1.02, 2.03, 9.01
- 2004-12-17 0001047469-04-037609 — 1.01, 9.01
- 2004-11-09 0001047469-04-033611 — 5.03
- 2004-11-01 0001047469-04-032638 — 2.02
- 2004-09-24 0001047469-04-029490 — 7.01, 9.01
- 2004-09-08 0001047469-04-028175 — 7.01, 9.01
- 2004-08-03 0001047469-04-025052 — 12, 7
- 2004-05-27 0001047469-04-018776 — 5, 7
- 2004-05-04 0001047469-04-015332 — 12, 7
- 2004-04-21 0001104659-04-010651 — 4, 7
- 2004-04-21 0001104659-04-010650 — 4, 7
- 2004-04-21 0001104659-04-010649 — 4, 7
- 2004-04-21 0001104659-04-010648 — 4, 7
- 2004-04-21 0001104659-04-010647 — 4, 7
- 2004-04-21 0001104659-04-010646 — 4, 7
- 2004-04-21 0001104659-04-010645 — 4, 7
- 2004-03-26 0001047469-04-009594 — 5
- 2004-03-10 0001047469-04-007341 — 5, 7
- 2004-02-18 0001047469-04-004811 — 4, 7
- 2004-02-03 0001047469-04-002931 — 12
- 2004-01-23 0001047469-04-001713 — 4, 7
- 2003-11-04 0001047469-03-035891 — 12
- 2003-08-08 0001047469-03-026793 — 9
- 2003-07-29 0001047469-03-025327 — 9
- 2003-07-29 0001047469-03-025326 — 9
- 2003-06-16 0001047469-03-021461 — 5
- 2003-05-01 0001047469-03-015879 — 5, 9
- 2003-03-13 0001047469-03-008621 — 5
- 2003-02-13 0001047469-03-005204 — 5
- 2003-01-31 0001047469-03-003566 — 9
- 2003-01-23 0001047469-03-002244 — 9
- 2003-01-14 0001047469-03-001274 — 5
- 2003-01-09 0001047469-03-000892 — 5
- 2003-01-07 0001047469-03-000409 — 9
- 2002-12-30 0000950130-02-008787 — 9
- 2002-12-05 0001047469-02-005860 — 9
- 2002-11-18 0001047469-02-003423 — 9
- 2002-11-08 0000912057-02-041607 — 9
- 2002-10-25 0000912057-02-039739 — 5, 7
- 2002-10-08 0000912057-02-037936 — 5
- 2002-09-17 0000912057-02-035700 — 5, 7
- 2002-07-26 0000912057-02-028591 — 5, 7
- 2002-06-04 0000912057-02-022895 — 5, 7
- 2002-05-01 0000912057-02-017856 — 5, 7
- 2002-03-05 0000912057-02-008624 — 7, 9
- 2002-02-26 0000912057-02-007589 — 7, 9
- 2002-02-08 0000912057-02-004656 — 5, 7
- 2002-02-07 0000912057-02-004522 — 7, 9
- 2002-02-06 0000912057-02-004129 — 5, 7
- 2002-01-24 0000912057-02-002570 — 5, 7
- 2001-08-16 0000912057-01-529262 — 5, 7
- 2001-08-16 0000912057-01-529254 — 5, 7
- 2001-08-03 0000922423-01-500605 — 5
- 2001-07-25 0000922423-01-500548 — 5
- 2001-06-15 0000912057-01-520030 — 2, 7
- 2001-05-24 0000912057-01-517464 — 5, 7
- 2001-04-03 0000891092-01-000506 — 5, 7
- 2001-03-29 0000912057-01-008689 — 5, 7
- 2001-03-15 0000922423-01-000279 — 5, 7
- 2001-02-09 0000950130-01-000712 — 5, 7
- 2000-11-15 0000950130-00-006130 — 5, 7
- 2000-11-01 0000922423-00-001256 — 5, 7
- 2000-07-14 0000950130-00-003880 — 5, 7
- 2000-01-20 0000950157-00-000035 — 5, 7
- 1999-12-10 0000922423-99-001458 — 5
- 1999-12-09 0000922423-99-001440 — 5, 7
- 1999-11-22 0000922423-99-001384 — 5, 7
- 1999-11-09 0000922423-99-001281 — 5, 7
- 1999-10-22 0000922423-99-001221 — 5, 7
- 1999-09-14 0000922423-99-001119 — 5
- 1999-08-27 0001047469-99-033900 — 2, 7
- 1999-07-21 0000922423-99-000898 — 5, 7
- 1999-06-03 0000950135-99-003063 — 5, 7
- 1999-04-15 0000922423-99-000538 — 2, 7
- 1998-12-11 0000950135-98-006212 — 5, 7 — amendment of 0000950135-98-006203
- 1998-12-10 0000950135-98-006203 — 5, 7
- 1998-06-24 0000922423-98-000647 — 5, 7
- 1998-05-13 0000950135-98-003189 — 2, 7 — amendment of 0000950135-98-001482
- 1998-04-23 0000950135-98-002594 — 5, 7
- 1998-03-11 0000950135-98-001482 — 2, 7
- 1998-03-06 0001047469-98-008809 — 5, 7
- 1997-09-19 0000922423-97-000778 — 8
- 1997-07-10 0000950135-97-002946 — 2, 7
- 1997-06-04 0000950103-97-000364 — 5, 7
- 1997-03-25 0000950103-97-000177 — 5, 7
- 1996-11-12 0000950144-96-007839 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-23 0000950144-96-007250 — 2, 7 — amendment of 0000950144-96-006445
- 1996-10-01 0000950103-96-001110 — 5, 7
- 1996-09-19 0000950144-96-006445 — 2, 7
- 1996-07-16 0000950103-96-001001 — 5, 7
- 1996-07-11 0000950103-96-000980 — 5, 7
- 1996-06-28 0000950144-96-003829 — 5, 7

## late-filing notifications on or before 2016-01-29

- 2007-08-09 0001104659-07-060911 — NT 10-Q, for the period ended 2007-06-29

## item 2.02 — earnings release, exhibit 99.1

[0000833444-16-000116:8k_2_02:1]
EX-99.1
2
exhibit991-q116.htm
EXHIBIT 99.1

[0000833444-16-000116:8k_2_02:2]
Exhibit

[0000833444-16-000116:8k_2_02:3]
| Investor Contacts: |  | Media Contact: |  |
| Antonella Franzen |  | Stephen Wasdick |  |
| +1-609-720-4665 |  | +1-609-806-2262 |  |
| afranzen@tyco.com |  | swasdick@tyco.com |  |
| Ryan Edelman |  |  |  |
| +1-609-720-4545 |  |  |  |
| redelman@tyco.com |  |  |  |

[0000833444-16-000116:8k_2_02:4]
FOR IMMEDIATE RELEASE

[0000833444-16-000116:8k_2_02:5]
TYCO REPORTS FIRST QUARTER 2016 EARNINGS FROM CONTINUING OPERATIONS

[0000833444-16-000116:8k_2_02:6]
BEFORE SPECIAL ITEMS OF $0.42 PER SHARE AND GAAP EARNINGS OF $0.17 PER SHARE

[0000833444-16-000116:8k_2_02:7]
| • | Exceeds guidance for revenue and earnings per share before special items (EPS) |

[0000833444-16-000116:8k_2_02:8]
| • | Announces strategic combination with Johnson Controls to create the leader in building products and technology, integrated solutions and energy storage |

[0000833444-16-000116:8k_2_02:9]
| • | Enhances business portfolio with additional investment in Middle East business, acquisition of ShopperTrak to expand retail analytics solutions, and divestiture of Australian fire detection and protection business |

[0000833444-16-000116:8k_2_02:10]
| • | Reaches tentative resolution of legacy tax litigation by filing Stipulations of Settled Issues with the U.S. Tax Court |

[0000833444-16-000116:8k_2_02:11]
| • | Provides guidance for second quarter 2016 EPS before special items of $0.44 - $0.46 |

[0000833444-16-000116:8k_2_02:12]
| • | Reaffirms full-year EPS before special items guidance of $2.05 - $2.20 |

[0000833444-16-000116:8k_2_02:13]
CORK, Ireland, Jan. 29, 2016 - Tyco (NYSE: TYC) today reported $0.17 in GAAP diluted earnings per share (EPS) from continuing operations for the fiscal first quarter of 2016.  Diluted EPS from continuing operations before special items of $0.42 exceeded previous guidance of $0.40.  Revenue of $2.4 billion in the quarter decreased 4% versus the prior year, primarily due to a 6% negative impact of the stronger U.S. dollar against foreign currencies.  Organic revenue was flat in the quarter versus previous guidance of a decline of 1% to 3%.  Acquisitions contributed 3 percentage points of growth, which was partially offset by the impact of a divestiture.

[0000833444-16-000116:8k_2_02:14]
“We are off to a solid start to our fiscal year.  Although we operated under challenging macro-economic conditions around the globe, we continued to execute well on what was within our control,” said Tyco Chief Executive Officer George R. Oliver.  “Despite this environment, we remain focused on building our business for the long-term, and the announcement of our planned merger with Johnson Controls is a perfect example.  I am thrilled with the prospect of bringing the unique strengths of two great companies together to deliver best-in-class building technologies and services to customers around the world.

[0000833444-16-000116:8k_2_02:15]
"We believe this transaction will allow us to better capture opportunities created by increased connectivity in homes, buildings and cities. Joining forces with Johnson Controls pairs our leading established businesses with robust innovation pipelines and extensive global footprints to deliver greater value to customers, shareholders and employees of both companies," Mr. Oliver added.

[0000833444-16-000116:8k_2_02:16]
(Income and EPS amounts are attributable to Tyco ordinary shareholders)

[0000833444-16-000116:8k_2_02:17]
($ millions, except per-share amounts)

[0000833444-16-000116:8k_2_02:18]
|  |  | Q1 2016 |  | Q1 2015 |  | % Change |  |
| Revenue |  | $ | 2,376 |  |  | $ | 2,478 |  |  | (4 | )% |  |
| Segment Operating Income |  | $ | 362 |  |  | $ | 323 |  |  | 12 | % |  |
| Restructuring and Repositioning |  | $ | (18 | ) |  | $ | (75 | ) |  | (76 | )% |  |
| Operating Income |  | $ | 293 |  |  | $ | 199 |  |  | 47 | % |  |
| Income from Continuing Operations |  | $ | 72 |  |  | $ | 164 |  |  | (56 | )% |  |
| GAAP Diluted EPS from Continuing Operations |  | $ | 0.17 |  |  | $ | 0.38 |  |  | (55 | )% |  |
| Special Items |  | $ | 0.25 |  |  | $ | — |  |  |  |  |
| Segment Operating Income Before Special Items |  | $ | 306 |  |  | $ | 327 |  |  | (6 | )% |  |
| Restructuring and Repositioning Before Special Items |  | $ | (22 | ) |  | $ | (75 | ) |  | (71 | )% |  |
| Income from Continuing Ops Before Special Items |  | $ | 178 |  |  | $ | 162 |  |  | 10 | % |  |
| Diluted EPS from Continuing Ops Before Special Items |  | $ | 0.42 |  |  | $ | 0.38 |  |  | 11 | % |  |

[0000833444-16-000116:8k_2_02:19]
Organic revenue, free cash flow, adjusted free cash flow, operating income, segment operating income, and diluted EPS from continuing operations before special items are non-GAAP financial measures and are described below.  Special items in the quarter of $0.25 were primarily driven by a loss on early extinguishment of debt and a loss on divestiture, partially offset by a gain on the sale of an equity investment.  For a reconciliation of these non-GAAP measures, see the attached tables. Additional schedules as well as first quarter review slides can be found in the Investor Relations section of Tyco’s website at http://investors.tyco.com.

[0000833444-16-000116:8k_2_02:20]
SEGMENT RESULTS

[0000833444-16-000116:8k_2_02:21]
The financial results presented in the tables below are in accordance with GAAP unless otherwise indicated.  All dollar amounts are pre-tax and stated in millions.  All comparisons are to the fiscal first quarter of 2015 unless otherwise indicated.

[0000833444-16-000116:8k_2_02:22]
North America Integrated Solutions & Services

[0000833444-16-000116:8k_2_02:23]
|  |  | Q1 2016 |  | Q1 2015 |  | % Change |  |
| Revenue |  | $ | 953 |  |  | $ | 951 |  |  | — | % |  |
| Operating Income |  | $ | 132 |  |  | $ | 129 |  |  | 2 | % |  |
| Operating Margin |  | 13.9 | % |  | 13.6 | % |  |  |  |
| Special Items |  | $ | — |  |  | $ | (2 | ) |  |  |  |
| Operating Income Before Special Items |  | $ | 132 |  |  | $ | 131 |  |  | 1 | % |  |
| Operating Margin Before Special Items |  | 13.9 | % |  | 13.8 | % |  |  |  |

[0000833444-16-000116:8k_2_02:24]
Revenue of $953 million was relatively flat compared to the prior year, as organic growth was offset by the weakening of the Canadian dollar.  Organic revenue growth of 2% was driven by 1% growth in service and 2% growth in integrated solutions.  Backlog of $2.51 billion increased 2% year over year and 1% on a quarter sequential basis, excluding the impact of foreign currency.

[0000833444-16-000116:8k_2_02:25]
Operating income for the quarter was $132 million and the operating margin before special items improved 10 basis points to 13.9%.  Normalized for a $6 million charge in the prior year, the operating margin contracted 50 basis points year over year, as the benefits of productivity were offset by incremental investments.

[0000833444-16-000116:8k_2_02:26]
Rest of World Integrated Solutions & Services

[0000833444-16-000116:8k_2_02:27]
|  |  | Q1 2016 |  | Q1 2015 |  | % Change |  |
| Revenue |  | $ | 812 |  |  | $ | 916 |  |  | (11 | )% |  |
| Operating Income |  | $ | 133 |  |  | $ | 89 |  |  | 49 | % |  |
| Operating Margin |  | 16.4 | % |  | 9.7 | % |  |  |  |
| Special Items |  | $ | 56 |  |  | $ | (2 | ) |  |  |  |
| Operating Income Before Special Items |  | $ | 77 |  |  | $ | 91 |  |  | (15 | )% |  |
| Operating Margin Before Special Items |  | 9.5 | % |  | 9.9 | % |  |  |  |

[0000833444-16-000116:8k_2_02:28]
Revenue of $812 million decreased 11% compared to the prior year, driven by an 11% unfavorable impact from foreign currency exchange rates.  Organic revenue declined 1%, as 1% growth in service was more than offset by a 4% decline in integrated solutions.  Acquisition growth of 3% was partially offset by a 2% decline related to a divestiture.  Backlog of $1.87 billion increased 9% both year over year and on a quarter sequential basis, excluding the impact of foreign currency and the divestiture, primarily driven by an acquisition in the quarter.

[0000833444-16-000116:8k_2_02:29]
Operating income for the quarter was $133 million and the operating margin was 16.4%.  Special items primarily consisted of a gain related to an equity investment partially offset by a loss on divestiture, for a net benefit of $56 million.  Before special items, operating income was $77 million and the operating margin was 9.5%.  The operating margin declined 40 basis points, fully driven by non-cash purchase accounting.  Excluding purchase accounting, the operating margin was up slightly year over year, as productivity benefits offset the revenue decline and investment.

[0000833444-16-000116:8k_2_02:30]
Global Products

[0000833444-16-000116:8k_2_02:31]
|  |  | Q1 2016 |  | Q1 2015 |  | % Change |  |
| Revenue |  | $ | 611 |  |  | $ | 611 |  |  | — | % |  |
| Operating Income |  | $ | 97 |  |  | $ | 105 |  |  | (8 | )% |  |
| Operating Margin |  | 15.9 | % |  | 17.2 | % |  |  |  |
| Special Items |  | $ | — |  |  | $ | — |  |  |  |  |
| Operating Income Before Special Items |  | $ | 97 |  |  | $ | 105 |  |  | (8 | )% |  |
| Operating Margin Before Special Items |  | 15.9 | % |  | 17.2 | % |  |  |  |

[0000833444-16-000116:8k_2_02:32]
Revenue of $611 million was flat with the prior year.  Organic revenue declined 1%, driven by Life Safety Products due to increased Air-Pak X3 shipments during the comparable quarter in the prior year.  Acquisitions contributed 6 percentage points of growth, which was mostly offset by changes in foreign currency exchange rates.

[0000833444-16-000116:8k_2_02:33]
Operating income for the quarter was $97 million and the operating margin was 15.9%.  The 130 basis point decline in operating margin included a 70 basis point headwind related to non-cash purchase accounting.  The underlying margin decline of 60 basis points was primarily driven by product mix.

[0000833444-16-000116:8k_2_02:34]
OTHER ITEMS

[0000833444-16-000116:8k_2_02:35]
| • | Cash from operating activities was $189 million and free cash flow was $117 million, which included a cash outflow of $52 million from special items primarily related to prior year restructuring and repositioning activities. Adjusted free cash flow for the quarter was $169 million. The company completed the quarter with $301 million in cash and cash equivalents. |

[0000833444-16-000116:8k_2_02:36]
| • | Corporate expense for the quarter was $52 million before special items and $51 million on a GAAP basis, compared to $55 million before special items for the prior year period. |

[0000833444-16-000116:8k_2_02:37]
| • | Restructuring and repositioning charges were $22 million before special items, compared to $75 million for the prior year period. |

[0000833444-16-000116:8k_2_02:38]
| • | The tax rate before special items was 17.2% for the quarter. |

[0000833444-16-000116:8k_2_02:39]
| • | As previously disclosed, the company entered into Stipulations of Settled Issues with the IRS intended to resolve all outstanding disputes related to intercompany debt issues for the 1997-2000 audit cycle, which are currently before the U.S. Tax Court. The resolution is contingent upon the IRS Appeals Division applying the same settlement to all intercompany debt issues on appeal for subsequent audit cycles (2001-2007). If finalized, the tentative resolution would cover all aspects of the controversy before the U.S. Tax Court and the IRS Appeals Division, and would result in a total cash payment to the IRS in the range of $475 million to $525 million, which includes all interest and penalties. This payment would be shared among the company, Covidien plc and TE Connectivity Ltd., 27%, 42% and 31%, respectively. The company does not expect to recognize any additional charges related to the resolution, as the company had previously recorded sufficient reserves with respect to this matter and its obligations under the Tax Sharing Agreements. Payment is expected to be made to the IRS, and among the company, Covidien and TE Connectivity, within the next six months. |

[0000833444-16-000116:8k_2_02:40]
| • | As previously announced, during the quarter the company made an additional investment in its Tyco UAE joint venture with local partner Suwaidi Engineering Group. Tyco now fully consolidates the financial results of this business into its Rest of World Integrated Solutions & Services segment, which is expected to add approximately $130 million in revenue on an annualized basis. |

[0000833444-16-000116:8k_2_02:41]
| • | As previously announced, during the quarter the company reached an agreement to acquire ShopperTrak, a leading global provider of retail traffic insights and location-based analytics, for approximately $175 million in cash. This business currently generates approximately $75 million in annual revenue. This transaction closed in late January 2016. |

[0000833444-16-000116:8k_2_02:42]
| • | As previously announced, during the quarter the company reached an agreement to divest its fire detection and protection business in Australia. In fiscal year 2015, this business had revenue of approximately $260 million. This transaction closed in late January 2016. |

[0000833444-16-000116:8k_2_02:43]
| • | During the quarter, the company redeemed its 7.0% notes due in 2019 and 6.875% notes due in 2021, which resulted in a loss from retirement of debt of $168 million. |

[0000833444-16-000116:8k_2_02:44]
ABOUT TYCO

[0000833444-16-000116:8k_2_02:45]
Tyco (NYSE: TYC) is the world’s largest pure-play fire protection and security company. Tyco provides more than three million customers around the globe with the latest fire protection and security products and services. Tyco has over 57,000 employees in more than 900 locations across 50 countries serving various end markets, including commercial, institutional, governmental, retail, industrial, energy, residential and small business. For more information, visit www.tyco.com.

[0000833444-16-000116:8k_2_02:46]
CONFERENCE CALL AND WEBCAST

[0000833444-16-000116:8k_2_02:47]
Management will discuss the company’s first quarter results for 2016 during a conference call and webcast today beginning at 8:00 a.m. Eastern time (ET).  Today’s conference call for investors can be accessed in the following ways:

[0000833444-16-000116:8k_2_02:48]
| • | Live via webcast - through the Investor Relations section of Tyco’s website at http://investors.tyco.com, |

[0000833444-16-000116:8k_2_02:49]
| • | Live via telephone (for “listen-only” participants and those who would like to ask a question) - by dialing 800-857-9797 (in the United States) or 517-308-9029 (outside the United States), passcode “Tyco”, |

[0000833444-16-000116:8k_2_02:50]
| • | Replay via telephone - by dialing 800-568-4204 (in the United States) or 203-369-3290 (outside the United States), passcode 2577, from 10:00 a.m. (ET) on January 29, 2016, until 11:59 p.m. (ET) on February 5, 2016, and |

[0000833444-16-000116:8k_2_02:51]
| • | Replay via webcast - through the “Presentations & Webcasts” link on the Investor Relations section of Tyco’s website: http://investors.tyco.com. |

[0000833444-16-000116:8k_2_02:52]
NON-GAAP MEASURES

[0000833444-16-000116:8k_2_02:53]
Organic revenue, free cash flow (outflow) (FCF), and income from continuing operations, earnings per share (EPS) from continuing operations, operating income and segment operating income, in each case “before special items,” are non-GAAP measures and should not be considered replacements for GAAP results.

[0000833444-16-000116:8k_2_02:54]
Organic revenue is a useful measure used by the company to measure the underlying results and trends in the business. The difference between reported net revenue (the most comparable GAAP measure) and organic revenue (the non-GAAP measure) consists of the impact from foreign currency, acquisitions and divestitures, and other changes that either do not reflect the underlying results and trends of the Company’s businesses or are not completely under management’s control. There are limitations associated with organic revenue, such as the fact that, as presented herein, the metric may not be

[0000833444-16-000116:8k_2_02:55]
comparable to similarly titled measures reported by other companies. These limitations are best addressed by using organic revenue in combination with the GAAP numbers. Organic revenue may be used as a component in the company’s incentive compensation plans.

[0000833444-16-000116:8k_2_02:56]
FCF is a useful measure of the company's cash that permits management and investors to gain insight into the number that management employs to measure cash that is free from any significant existing obligation and is available to service debt and make investments. The difference between Cash Flows from Operating Activities (the most comparable GAAP measure) and FCF (the non-GAAP measure) consists mainly of significant cash flows that the company believes are useful to identify. It, or a measure that is based on it, may be used as a component in the company's incentive compensation plans. The difference reflects the impact from:

[0000833444-16-000116:8k_2_02:57]
| • | net capital expenditures, |

[0000833444-16-000116:8k_2_02:58]
| • | dealer generated accounts and bulk accounts purchased, |

[0000833444-16-000116:8k_2_02:59]
| • | cash paid for purchase accounting and holdback liabilities, and |

[0000833444-16-000116:8k_2_02:60]
| • | voluntary pension contributions. |

[0000833444-16-000116:8k_2_02:61]
Capital expenditures and dealer generated and bulk accounts purchased are subtracted because they represent long-term investments that are required for normal business activities. Cash paid for purchase accounting and holdback liabilities is subtracted because these cash outflows are not available for general corporate uses. Voluntary pension contributions are added because this activity is driven by economic financing decisions rather than operating activity. In addition, the company presents adjusted free cash flow, which is free cash flow, adjusted to exclude the cash impact of the special items highlighted below. This number provides information to investors regarding the cash impact of certain items management believes are useful to identify, as described below.

[0000833444-16-000116:8k_2_02:62]
The limitation associated with using these cash flow metrics is that they adjust for cash items that are ultimately within management's and the Board of Directors' discretion to direct and therefore may imply that there is less or more cash that is available for the company's programs than the most comparable GAAP measure. Furthermore, these non-GAAP metrics may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using FCF in combination with the GAAP cash flow numbers.

[0000833444-16-000116:8k_2_02:63]
The company has presented its income and EPS from continuing operations, operating income and segment operating income before special items. Special items include charges and gains related to divestitures, acquisitions, restructurings, impairments, certain changes to accounting methodologies, legacy legal and tax charges and other income or charges that may mask the underlying operating results and/or business trends of the company or business segment, as applicable. The company utilizes these measures to assess overall operating performance and segment level core operating performance, as well as to provide insight to management in evaluating overall and segment operating plan execution and underlying market conditions. The Company also presents its effective tax rate as adjusted for special items for consistency, and presents corporate expense excluding special items. One or more of these measures may be used as components in the company's incentive compensation plans. These measures are useful for investors because they may permit more meaningful comparisons of the company's underlying operating results and business trends between periods. The difference between income and EPS from continuing operations before special items and income and EPS from continuing operations (the most comparable GAAP measures) consists of the impact of the special items noted above on the applicable GAAP measure. The limitation of these measures is that they exclude the impact (which may be material) of items that increase or decrease the company's reported GAAP metrics, and these non-GAAP metrics may not be comparable to similarly titled measures reported by other companies. These limitations are best addressed by using the non-GAAP measures in combination with the most comparable GAAP measures in order to better understand the amounts, character and impact of any increase or decrease on reported results.

[0000833444-16-000116:8k_2_02:64]
The company provides general corporate services to its segments and those costs are reported in the "Corporate and Other" segment. This segment's operating income (loss) is presented as "Corporate Expense." Segment Operating Income represents Tyco’s operating income excluding the Corporate and Other segment, and reflects the results of Tyco’s three operating segments. Segment Operating Income before special items reflects GAAP operating income adjusted for the special items noted in the paragraph above.

[0000833444-16-000116:8k_2_02:65]
NO OFFER OR SOLICITATION

[0000833444-16-000116:8k_2_02:66]
This communication is not intended to and does not constitute an offer to sell or the solicitation of an offer to subscribe for or buy or an invitation to purchase or subscribe for any securities or the solicitation of any vote or approval in any jurisdiction, nor shall there be any sale, issuance or transfer of securities in any jurisdiction in contravention of applicable law.

[0000833444-16-000116:8k_2_02:67]
ADDITIONAL INFORMATION AND WHERE TO FIND IT

[0000833444-16-000116:8k_2_02:68]
In connection with the proposed transaction between Johnson Controls, Inc. (“Johnson Controls”) and Tyco International plc (“Tyco”), Tyco will file with the U.S. Securities and Exchange Commission (the “SEC”) a registration statement on Form S-4 that will include a joint proxy statement of Johnson Controls and Tyco that also constitutes a prospectus of Tyco (the “Joint Proxy Statement/Prospectus”). Johnson Controls and Tyco plan to mail to their respective shareholders the definitive Joint Proxy Statement/Prospectus in connection with the transaction. INVESTORS AND SECURITY HOLDERS OF JOHNSON CONTROLS AND TYCO ARE URGED TO READ THE JOINT PROXY STATEMENT/PROSPECTUS AND OTHER RELEVANT DOCUMENTS FILED OR TO BE FILED WITH THE SEC CAREFULLY WHEN THEY BECOME AVAILABLE BECAUSE THEY WILL CONTAIN IMPORTANT INFORMATION ABOUT JOHNSON CONTROLS, TYCO, THE TRANSACTION AND RELATED MATTERS. Investors and security holders will be able to obtain free copies of the Joint Proxy Statement/Prospectus (when available) and other documents filed with the SEC by Johnson Controls and Tyco through the website maintained by the SEC at www.sec.gov. In addition, investors and security holders will be able to obtain free copies of the documents filed with the SEC by Johnson Controls by contacting Johnson Controls Shareholder Services at Shareholder.Services@jci.com or by calling (800) 524-6220 and will be able to obtain free copies of the documents filed with the SEC by Tyco by contacting Tyco Investor Relations at Investorrelations@Tyco.com or by calling (609) 720-4333.

[0000833444-16-000116:8k_2_02:69]
PARTICIPANTS IN THE SOLICITATION

[0000833444-16-000116:8k_2_02:70]
Johnson Controls, Tyco and certain of their respective directors, executive officers and employees may be considered participants in the solicitation of proxies in connection with the proposed transaction. Information regarding the persons who may, under the rules of the SEC, be deemed participants in the solicitation of the respective shareholders of Johnson Controls and Tyco in connection with the proposed transactions, including a description of their direct or indirect interests, by security holdings or otherwise, will be set forth in the Joint Proxy Statement/Prospectus when it is filed with the SEC. Information regarding Johnson Controls’ directors and executive officers is contained in Johnson Controls’ proxy statement for its 2016 annual meeting of shareholders, which was filed with the SEC on December 14, 2015. Information regarding Tyco’s directors and executive officers is contained in Tyco’s proxy statement for its 2016 annual meeting of shareholders, which was filed with the SEC on January 15, 2016.

[0000833444-16-000116:8k_2_02:71]
FORWARD-LOOKING STATEMENTS

[0000833444-16-000116:8k_2_02:72]
This press release contains a number of forward-looking statements. In many cases forward-looking statements are identified by words, and variations of words, such as "anticipate", "estimate", "believe", "commit", "confident", "continue", "could", "intend", "may", "plan", "potential", "predict", "positioned", "should", "will", "expect", "objective", "projection", "forecast", "goal", "guidance", "outlook", "effort", "target", and other similar words. However, the absence of these words does not mean the statements are not forward-looking. Examples of forward-looking statements include, but are not limited to, revenue, operating income, earnings per share and other financial projections, statements regarding the health and growth prospects of the industries and end markets in which Tyco operates, the leadership, resources, potential, priorities, and opportunities for Tyco in the future, Tyco's credit profile, capital allocation priorities and other capital market related activities, statements regarding Tyco's acquisition, divestiture, restructuring and other productivity initiatives, and statements regarding Tyco’s proposed merger with Johnson Controls and related transactions.

[0000833444-16-000116:8k_2_02:73]
STATEMENT REQUIRED BY THE IRISH TAKEOVER RULES

[0000833444-16-000116:8k_2_02:74]
The directors of Tyco International plc accept responsibility for the information contained in this communication.  To the best of their knowledge and belief (having taken all reasonable care to ensure such is the case), the information contained in this communication is in accordance with the facts and does not omit anything likely to affect the import of such information.

[0000833444-16-000116:8k_2_02:75]
Lazard Freres & Co. LLC, which is a registered broker dealer with the SEC, is acting for Tyco International plc and no one else in connection with the proposed transaction and will not be responsible to anyone other than Tyco International plc for providing the protections afforded to clients of Lazard Freres & Co. LLC, or for giving advice in connection with the proposed transaction or any matter referred to herein.

[0000833444-16-000116:8k_2_02:76]
NOT FOR RELEASE, PUBLICATION OR DISTRIBUTION, IN WHOLE OR IN PART, IN, INTO OR FROM ANY JURISDICTION WHERE TO DO SO WOULD CONSTITUTE A VIOLATION OF THE RELEVANT LAWS OR REGULATIONS OF SUCH JURISDICTION.

[0000833444-16-000116:8k_2_02:77]
This communication is not intended to be and is not a prospectus for the purposes of Part 23 of the Companies Act 2014 of Ireland (the “2014 Act”), Prospectus (Directive 2003/71/EC) Regulations 2005 (S.I. No. 324 of 2005) of Ireland (as amended from time to time) or the Prospectus Rules issued by the Central Bank of Ireland pursuant to section 1363 of the 2014 Act, and the Central Bank of Ireland (“CBI”) has not approved this communication.

[0000833444-16-000116:8k_2_02:78]
# # #

[0000833444-16-000116:8k_2_02:79]
TYCO INTERNATIONAL PLC

[0000833444-16-000116:8k_2_02:80]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0000833444-16-000116:8k_2_02:81]
(in millions, except per share data)

[0000833444-16-000116:8k_2_02:82]
(Unaudited)

[0000833444-16-000116:8k_2_02:83]
|  | Quarters Ended |
|  | December 25, 2015 |  | December 26, 2014 |
| Revenue from product sales | $ | 1,408 |  |  | $ | 1,488 |  |
| Service revenue | 968 |  |  | 990 |  |
| Net revenue | 2,376 |  |  | 2,478 |  |
| Cost of product sales | 962 |  |  | 1,022 |  |
| Cost of services | 536 |  |  | 547 |  |
| Selling, general and administrative expenses | 573 |  |  | 652 |  |
| Restructuring and asset impairment charges, net | 12 |  |  | 58 |  |
| Operating income | 293 |  |  | 199 |  |
| Interest income | 4 |  |  | 3 |  |
| Interest expense | (24 | ) |  | (24 | ) |
| Other (expense) income, net | (165 | ) |  | 4 |  |
| Income from continuing operations before income taxes | 108 |  |  | 182 |  |
| Income tax expense | (36 | ) |  | (19 | ) |
| Income from continuing operations | 72 |  |  | 163 |  |
| Income (loss) from discontinued operations, net of income taxes | 4 |  |  | (2 | ) |
| Net income | 76 |  |  | 161 |  |
| Less: noncontrolling interest in subsidiaries net loss | — |  |  | (1 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 76 |  |  | $ | 162 |  |
| Amounts attributable to Tyco ordinary shareholders: |  |  |  |  |
| Income from continuing operations | $ | 72 |  |  | $ | 164 |  |
| Income (loss) from discontinued operations | 4 |  |  | (2 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 76 |  |  | $ | 162 |  |
| Basic earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |
| Income from continuing operations | $ | 0.17 |  |  | $ | 0.39 |  |
| Income from discontinued operations | 0.01 |  |  | — |  |
| Net income attributable to Tyco ordinary shareholders | $ | 0.18 |  |  | $ | 0.39 |  |
| Diluted earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |
| Income from continuing operations | $ | 0.17 |  |  | $ | 0.38 |  |
| Income from discontinued operations | 0.01 |  |  | — |  |
| Net income attributable to Tyco ordinary shareholders | $ | 0.18 |  |  | $ | 0.38 |  |
| Weighted average number of shares outstanding: |  |  |  |  |
| Basic | 424 |  |  | 420 |  |
| Diluted | 428 |  |  | 427 |  |

[0000833444-16-000116:8k_2_02:84]
Note: These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K filed on November 13, 2015 for the fiscal year ended September 25, 2015.

[0000833444-16-000116:8k_2_02:85]
TYCO INTERNATIONAL PLC

[0000833444-16-000116:8k_2_02:86]
RESULTS OF SEGMENTS

[0000833444-16-000116:8k_2_02:87]
(in millions)

[0000833444-16-000116:8k_2_02:88]
(Unaudited)

[0000833444-16-000116:8k_2_02:89]
|  |  | Quarters Ended |  |  |
|  |  | December 25, 2015 |  |  |  | December 26, 2014 |  |  |
| Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| NA Integrated Solutions & Services |  | $ | 953 |  |  |  |  |  | $ | 951 |  |  |  |  |
| ROW Integrated Solutions & Services |  | 812 |  |  |  |  |  | 916 |  |  |  |  |
| Global Products |  | 611 |  |  |  |  |  | 611 |  |  |  |  |
| Total Net Revenue |  | $ | 2,376 |  |  |  |  |  | $ | 2,478 |  |  |  |  |
| Operating Income and Margin |  |  |  |  |  |  |  |  |  |  |  |  |
| NA Integrated Solutions & Services |  | $ | 132 |  |  | 13.9 | % |  | $ | 129 |  |  | 13.6 | % |
| ROW Integrated Solutions & Services |  | 133 |  |  | 16.4 | % |  | 89 |  |  | 9.7 | % |
| Global Products |  | 97 |  |  | 15.9 | % |  | 105 |  |  | 17.2 | % |
| Segment operating income |  | 362 |  |  | 15.2 | % |  | 323 |  |  | 13.0 | % |
| Corporate and Other expense |  | (51 | ) |  | N/M |  |  | (49 | ) |  | N/M |  |
| Restructuring and repositioning charges, net |  | (18 | ) |  | N/M |  |  | (75 | ) |  | N/M |  |
| Operating income |  | $ | 293 |  |  | 12.3 | % |  | $ | 199 |  |  | 8.0 | % |

[0000833444-16-000116:8k_2_02:90]
TYCO INTERNATIONAL PLC

[0000833444-16-000116:8k_2_02:91]
CONSOLIDATED BALANCE SHEETS

[0000833444-16-000116:8k_2_02:92]
(in millions)

[0000833444-16-000116:8k_2_02:93]
(Unaudited)

[0000833444-16-000116:8k_2_02:94]
|  |  | December 25, 2015 |  | September 25, 2015 |
| Assets |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 301 |  |  | $ | 1,401 |  |
| Accounts receivable, net |  | 1,719 |  |  | 1,732 |  |
| Inventories |  | 647 |  |  | 624 |  |
| Prepaid expenses and other current assets |  | 853 |  |  | 754 |  |
| Deferred income taxes |  | 62 |  |  | 62 |  |
| Assets held for sale |  | 83 |  |  | 102 |  |
| Total Current Assets |  | 3,665 |  |  | 4,675 |  |
| Property, plant and equipment, net |  | 1,167 |  |  | 1,177 |  |
| Goodwill |  | 4,365 |  |  | 4,234 |  |
| Intangible assets, net |  | 927 |  |  | 863 |  |
| Other assets |  | 1,307 |  |  | 1,372 |  |
| Total Assets |  | $ | 11,431 |  |  | $ | 12,321 |  |
| Liabilities and Equity |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |
| Loans payable and current maturities of long-term debt |  | $ | 152 |  |  | $ | 987 |  |
| Accounts payable |  | 789 |  |  | 774 |  |
| Accrued and other current liabilities |  | 1,837 |  |  | 1,661 |  |
| Deferred revenue |  | 349 |  |  | 380 |  |
| Liabilities held for sale |  | 84 |  |  | 50 |  |
| Total Current Liabilities |  | 3,211 |  |  | 3,852 |  |
| Long-term debt |  | 2,146 |  |  | 2,159 |  |
| Deferred revenue |  | 292 |  |  | 303 |  |
| Other liabilities |  | 1,736 |  |  | 1,931 |  |
| Total Liabilities |  | 7,385 |  |  | 8,245 |  |
| Total Tyco shareholders' equity |  | 4,009 |  |  | 4,041 |  |
| Nonredeemable noncontrolling interest |  | 37 |  |  | 35 |  |
| Total Equity |  | 4,046 |  |  | 4,076 |  |
| Total Liabilities and Equity |  | $ | 11,431 |  |  | $ | 12,321 |  |

[0000833444-16-000116:8k_2_02:95]
Note: These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K filed on November 13, 2015 for the fiscal year ended September 25, 2015.

[0000833444-16-000116:8k_2_02:96]
TYCO INTERNATIONAL PLC

[0000833444-16-000116:8k_2_02:97]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000833444-16-000116:8k_2_02:98]
(in millions)

[0000833444-16-000116:8k_2_02:99]
(Unaudited)

[0000833444-16-000116:8k_2_02:100]
|  |  | For the Three Months Ended |
|  |  | December 25, 2015 |  | December 26, 2014 |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |
| Net income attributable to Tyco ordinary shareholders |  | $ | 76 |  |  | $ | 162 |  |
| Noncontrolling interest in subsidiaries net income |  | — |  |  | (1 | ) |
| (Income) loss from discontinued operations, net of income taxes |  | (4 | ) |  | 2 |  |
| Income from continuing operations |  | 72 |  |  | 163 |  |
| Adjustments to reconcile net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  | 83 |  |  | 90 |  |
| Non-cash compensation expense |  | 15 |  |  | 15 |  |
| Deferred income taxes |  | 17 |  |  | (6 | ) |
| Provision for losses on accounts receivable and inventory |  | 12 |  |  | 16 |  |
| Loss on extinguishment of debt |  | 168 |  |  | — |  |
| Loss on divestitures, net |  | 52 |  |  | 1 |  |
| Gain on investments, net |  | (115 | ) |  | (4 | ) |
| Other non-cash items |  | 5 |  |  | 1 |  |
| Changes in assets and liabilities, net of the effects of acquisitions and divestitures: |  |  |  |  |  |
| Accounts receivable, net |  | 29 |  |  | (7 | ) |
| Contracts in progress |  | (9 | ) |  | 8 |  |
| Inventories |  | (34 | ) |  | (43 | ) |
| Prepaid expenses and other assets |  | (48 | ) |  | (25 | ) |
| Asbestos insurance assets |  | 5 |  |  | 22 |  |
| Accounts payable |  | 1 |  |  | (41 | ) |
| Accrued and other liabilities |  | (41 | ) |  | (29 | ) |
| Deferred revenue |  | (37 | ) |  | (38 | ) |
| Income taxes, net |  | 11 |  |  | (2 | ) |
| Gross asbestos liabilities |  | (7 | ) |  | (4 | ) |
| Other |  | 10 |  |  | (22 | ) |
| Net cash provided by operating activities |  | 189 |  |  | 95 |  |
| Net cash provided by discontinued operating activities |  | 2 |  |  | 1 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |
| Capital expenditures |  | (68 | ) |  | (66 | ) |
| Proceeds from disposal of assets |  | — |  |  | 1 |  |
| Acquisition of businesses, net of cash acquired |  | (138 | ) |  | (152 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases |  | (4 | ) |  | (4 | ) |
| Sales and maturities of investments |  | 1 |  |  | 275 |  |
| Purchases of investments |  | (7 | ) |  | (1 | ) |
| Decrease (increase) in restricted cash |  | 5 |  |  | (45 | ) |
| Other |  | — |  |  | (1 | ) |
| Net cash (used in) provided by investing activities |  | (211 | ) |  | 7 |  |
| Net cash used in discontinued investing activities |  | — |  |  | (15 | ) |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |
| Proceeds from issuance of short-term debt |  | 817 |  |  | — |  |
| Repayment of short-term debt |  | (666 | ) |  | — |  |
| Repayment of current portion of long-term debt |  | (1,134 | ) |  | — |  |
| Proceeds from exercise of share options |  | 11 |  |  | 33 |  |
| Dividends paid |  | (87 | ) |  | (75 | ) |
| Repurchase of ordinary shares |  | — |  |  | (417 | ) |
| Transfer from (to) discontinued operations |  | 2 |  |  | (14 | ) |
| Payment of contingent consideration |  | — |  |  | (23 | ) |
| Other |  | (12 | ) |  | (15 | ) |
| Net cash used in financing activities |  | (1,069 | ) |  | (511 | ) |
| Net cash (used in) provided by discontinued financing activities |  | (2 | ) |  | 14 |  |
| Effect of currency translation on cash |  | (9 | ) |  | (10 | ) |
| Net decrease in cash and cash equivalents |  | (1,100 | ) |  | (419 | ) |
| Cash and cash equivalents at beginning of period |  | 1,401 |  |  | 892 |  |
| Cash and cash equivalents at end of period |  | $ | 301 |  |  | $ | 473 |  |

[0000833444-16-000116:8k_2_02:101]
| Reconciliation to "Free Cash Flow": |  |  |  |  |
| Net cash provided by operating activities |  | $ | 189 |  |  | $ | 95 |  |
| Capital expenditures, net |  | (68 | ) |  | (65 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases |  | (4 | ) |  | (4 | ) |
| Payment of contingent consideration |  | — |  |  | (23 | ) |
| Free Cash Flow |  | $ | 117 |  |  | $ | 3 |  |
| Reconciliation to "Adjusted Free Cash Flow": |  |  |  |  |
| IRS litigation costs |  | 3 |  |  | — |  |
| Separation costs |  | — |  |  | 3 |  |
| Restructuring and repositioning costs (FY15 and prior) |  | 45 |  |  | 34 |  |
| Environmental remediation payments |  | 1 |  |  | 7 |  |
| Legal settlements |  | — |  |  | (12 | ) |
| Net asbestos payments |  | 2 |  |  | 5 |  |
| Acquisition / integration costs |  | 1 |  |  | 1 |  |
| Special Items |  | $ | 52 |  |  | $ | 38 |  |
| Adjusted Free Cash Flow |  | $ | 169 |  |  | $ | 41 |  |

[0000833444-16-000116:8k_2_02:102]
Note: Free cash flow is a non-GAAP measure.  See description of non-GAAP measures contained in this release.

[0000833444-16-000116:8k_2_02:103]
TYCO INTERNATIONAL PLC

[0000833444-16-000116:8k_2_02:104]
ORGANIC GROWTH RECONCILIATION - REVENUE

[0000833444-16-000116:8k_2_02:105]
(in millions)

[0000833444-16-000116:8k_2_02:106]
(Unaudited)

[0000833444-16-000116:8k_2_02:107]
|  |  |  |  | Quarter Ended December 25, 2015 |  |  |  |  |
|  |  |  |  | Base Year |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Net Revenue for the Quarter Ended December 26, 2014 |  | Adjustments |  | Adjusted Fiscal 2015 BaseRevenue |  |  |  |  |  |  |  |  |  |  |  |  |  | Net Revenue for the Quarter Ended December 25, 2015 |
|  |  |  | Divestitures / Other |  |  | Foreign Currency |  | Acquisitions |  | Organic Revenue(1) |  |
| NA Integrated Solutions & Services |  | $ | 951 |  |  | $ | — |  |  | — | % |  | $ | 951 |  |  | $ | (16 | ) |  | (1.7 | )% |  | $ | 3 |  |  | 0.3 | % |  | $ | 15 |  |  | 1.6 | % |  | $ | 953 |  |  | 0.2 | % |
| ROW Integrated Solutions & Services |  | 916 |  |  | (22 | ) |  | (2.4 | )% |  | 894 |  |  | (101 | ) |  | (11.0 | )% |  | 29 |  |  | 3.2 | % |  | (10 | ) |  | (1.1 | )% |  | 812 |  |  | (11.4 | )% |
| Global Products |  | 611 |  |  | (1 | ) |  | (0.2 | )% |  | 610 |  |  | (35 | ) |  | (5.7 | )% |  | 39 |  |  | 6.4 | % |  | (3 | ) |  | (0.5 | )% |  | 611 |  |  | — | % |
| Total Net Revenue |  | $ | 2,478 |  |  | $ | (23 | ) |  | (0.9 | )% |  | $ | 2,455 |  |  | $ | (152 | ) |  | (6.1 | )% |  | $ | 71 |  |  | 2.9 | % |  | $ | 2 |  |  | 0.1 | % |  | $ | 2,376 |  |  | (4.1 | )% |

[0000833444-16-000116:8k_2_02:108]
|  | (1) Organic revenue growth percentage based on adjusted fiscal 2015 base revenue. |

[0000833444-16-000116:8k_2_02:109]
Earnings Per Share Summary

[0000833444-16-000116:8k_2_02:110]
(Unaudited)

[0000833444-16-000116:8k_2_02:111]
|  |  | Quarter Ended |  | Quarter Ended |
|  |  | December 25, 2015 |  | December 26, 2014 |
| Diluted EPS from Continuing Operations Attributable to Tyco Shareholders (GAAP) |  | $ | 0.17 |  |  | $ | 0.38 |  |
| expense / (benefit) |  |  |  |  |
| Restructuring and repositioning reversals (FY15 and prior) |  | (0.01 | ) |  | — |  |
| (Gains) / losses on divestitures, net included in SG&A |  | 0.12 |  |  | — |  |
| Gain on equity investment, net |  | (0.26 | ) |  | — |  |
| Settlement with former management |  | — |  |  | (0.01 | ) |
| Loss on extinguishment of debt |  | 0.39 |  |  | — |  |
| Total Before Special Items |  | $ | 0.42 |  |  | $ | 0.38 |  |

[0000833444-16-000116:8k_2_02:112]
Note:  Sum of EPS before special items does not equal total due to rounding.

[0000833444-16-000116:8k_2_02:113]
Tyco International plc

[0000833444-16-000116:8k_2_02:114]
For the Quarter Ended December 25, 2015

[0000833444-16-000116:8k_2_02:115]
(in millions, except per share data)

[0000833444-16-000116:8k_2_02:116]
(Unaudited)

[0000833444-16-000116:8k_2_02:117]
expense / (benefit)

[0000833444-16-000116:8k_2_02:118]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Integrated Solutions& Services |  |  |  | ROW Integrated Solutions & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $953 |  |  |  |  |  | $812 |  |  |  |  |  | $611 |  |  |  |  |  | $2,376 |  |  |  |  |  | $— |  |  |  |  |  | $2,376 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Integrated Solutions& Services |  | Margin |  | ROW Integrated Solutions & Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Restructuring and Repositioning |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other (Expense) Income, net |  | Income Tax (Expense) |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $132 |  |  | 13.9 | % |  |  | $133 |  |  | 16.4 | % |  |  | $97 |  |  | 15.9 | % |  |  | $362 |  |  | 15.2 | % |  |  | ($51 | ) |  |  | ($18 | ) |  |  | $293 |  |  | 12.3 | % |  |  | ($20 | ) |  |  | ($165 | ) |  |  | ($36 | ) |  |  | $— |  |  |  | $72 |  |  | $0.17 |  |
| Restructuring and repositioning reversals (FY15 and prior) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (4 | ) |  | (4 | ) |  |  |  |  |  |  |  | 1 |  |  |  |  | (3 | ) | (0.01 | ) |
| (Gains) / losses on divestitures, net included in SG&A |  |  |  |  |  | 54 |  |  |  |  |  |  |  |  | 54 |  |  |  |  | (2 | ) |  |  |  | 52 |  |  |  |  |  |  |  |  |  |  |  |  | 52 |  | 0.12 |  |
| Acquisition / integration costs |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| IRS litigation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  | — |  | — |  |
| Gain on equity investment, net |  |  |  |  |  | (111 | ) |  |  |  |  |  |  |  | (111 | ) |  |  |  |  |  |  |  | (111 | ) |  |  |  |  |  |  |  | (1 | ) |  |  |  | (112 | ) | (0.26 | ) |
| Loss on extinguishment of debt |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 168 |  |  |  |  |  |  | 168 |  | 0.39 |  |
| Total Before Special Items |  |  | $132 |  |  | 13.9 | % |  |  | $77 |  |  | 9.5 | % |  |  | $97 |  |  | 15.9 | % |  |  | $306 |  |  | 12.9 | % |  |  | ($52 | ) |  |  | ($22 | ) |  |  | $232 |  |  | 9.8 | % |  |  | ($20 | ) |  |  | $3 |  |  |  | ($37 | ) |  |  | $— |  |  |  | $178 |  |  | $0.42 |  |
| Note: Sum of EPS before special items does not equal total due to rounding. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 428 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 428 |  |

[0000833444-16-000116:8k_2_02:119]
Tyco International plc

[0000833444-16-000116:8k_2_02:120]
For the Quarter Ended December 26, 2014

[0000833444-16-000116:8k_2_02:121]
(in millions, except per share data)

[0000833444-16-000116:8k_2_02:122]
(Unaudited)

[0000833444-16-000116:8k_2_02:123]
expense / (benefit)

[0000833444-16-000116:8k_2_02:124]
| Segments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Integrated Solutions& Services |  |  |  | ROW Integrated Solutions & Services |  |  |  | Global Products |  |  |  | Segment Revenue |  |  |  | Corporate and Other |  |  |  | Total Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revenue (GAAP) |  |  | $951 |  |  |  |  |  | $916 |  |  |  |  |  | $611 |  |  |  |  |  | $2,478 |  |  |  |  |  | $— |  |  |  |  |  | $2,478 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | Operating Income |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | NA Integrated Solutions& Services |  | Margin |  | ROW Integrated Solutions & Services |  | Margin |  | GlobalProducts |  | Margin |  | Segment OperatingIncome |  | Margin |  | Corporateand Other |  | Restructuring and Repositioning |  | Total OperatingIncome |  | Margin |  | Interest (Expense), net |  | Other Income, net |  | Income Tax (Expense) |  | Noncontrolling Interest |  | IncomefromContinuingOperations Attributable to Tyco Shareholders | DilutedEPS fromContinuingOperations Attributable to TycoShareholders |
| Operating Income (GAAP) |  |  | $129 |  |  | 13.6 | % |  |  | $89 |  |  | 9.7 | % |  |  | $105 |  |  | 17.2 | % |  |  | $323 |  |  | 13.0 | % |  |  | ($49 | ) |  |  | ($75 | ) |  |  | $199 |  |  | 8.0 | % |  |  | ($21 | ) |  |  | $4 |  |  |  | ($19 | ) |  |  | $1 |  |  |  | $164 |  |  | $0.38 |  |
| Separation costs included in SG&A |  | 2 |  |  |  |  |  |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  | 1 |  | — |  |
| (Gains) / losses on divestitures, net included in SG&A |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Acquisition / integration costs |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  | 1 |  | — |  |
| Settlement with former management |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (7 | ) |  |  |  | (7 | ) |  |  |  |  |  |  |  | 3 |  |  |  |  | (4 | ) | (0.01 | ) |
| Asbestos |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 3 |  |  |  |  | 3 |  |  |  |  |  |  |  |  | (1 | ) |  |  |  | 2 |  | — |  |
| IRS litigation costs |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (2 | ) |  |  |  | (2 | ) |  |  |  |  |  |  |  | 1 |  |  |  |  | (1 | ) | — |  |
| 2012 Tax Sharing Agreement |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (2 | ) |  |  |  |  |  | (2 | ) | — |  |
| Total Before Special Items |  |  | $131 |  |  | 13.8 | % |  |  | $91 |  |  | 9.9 | % |  |  | $105 |  |  | 17.2 | % |  |  | $327 |  |  | 13.2 | % |  |  | ($55 | ) |  |  | ($75 | ) |  |  | $197 |  |  | 7.9 | % |  |  | ($21 | ) |  |  | $2 |  |  |  | ($17 | ) |  |  | $1 |  |  |  | $162 |  |  | $0.38 |  |
| Note: Sum of EPS before special items does not equal total due to rounding. |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding |  |  | 427 |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | Diluted Shares Outstanding - Before Special Items | 427 |  |
