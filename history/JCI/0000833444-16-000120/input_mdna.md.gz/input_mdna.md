# JCI MD&A — 0000833444-16-000120


## mdna

[0000833444-16-000120:mdna:1]
[same as prior period, unchanged from 0000833444-15-000062:mdna:1]

[0000833444-16-000120:mdna:2]
[same as prior period, unchanged from 0000833444-15-000062:mdna:2]

[0000833444-16-000120:mdna:3]
[same as prior period, unchanged from 0000833444-15-000062:mdna:3]

[0000833444-16-000120:mdna:4]
[same as prior period, unchanged from 0000833444-15-000062:mdna:4]

[0000833444-16-000120:mdna:5]
References to 2016 and 2015 are to Tyco's fiscal quarters ending December 25, 2015 and December 26, 2014, respectively, unless otherwise indicated.  The Company has a 52- or 53-week fiscal year that ends on the last Friday in September. Fiscal 2016 is a 53-week year as compared with fiscal 2015, which was 52 weeks, with the additional week occurring in the fourth quarter of fiscal 2016.  Our results for the three months ended December 25, 2015 and December 26, 2014 both consisted of 13 weeks.

[0000833444-16-000120:mdna:6]
On May 30, 2014, Tyco entered into a Merger Agreement ("Merger Agreement") with Tyco International plc, a newly-formed Irish public limited company and a wholly-owned subsidiary of Tyco ("Tyco Ireland").  Under the Merger Agreement, Tyco merged with and into Tyco Ireland, with Tyco Ireland being the surviving company.  This resulted in Tyco Ireland becoming Tyco's publicly-traded parent company and changed the jurisdiction of organization of Tyco from Switzerland to Ireland.  Tyco's shareholders received one ordinary share of Tyco Ireland for each ordinary share of Tyco held immediately prior to the re-domicile to Ireland.  The re-domicile to Ireland became effective on November 17, 2014.

[0000833444-16-000120:mdna:7]
Upon the effectiveness of the re-domicile, the ordinary shares of Tyco Ireland were listed on the New York Stock Exchange (“NYSE”) under the symbol “TYC,” the same symbol under which the ordinary shares in Tyco were previously listed and traded.

[0000833444-16-000120:mdna:8]
During the fourth quarter of fiscal 2015, the Company changed the name of its North America Installation & Services and Rest of World Installation & Services segments to North America Integrated Solutions & Services and Rest of World Integrated Solutions & Services, respectively. The segment reporting structure is consistent with how management reviews the businesses, makes investing and resource decisions and assesses operating performance. The name changes better reflect the Company's focus on providing technology solutions that encompass a mix of products, services and consultation that is tailored to the unique needs of each customer. No changes were made to the segment structure or underlying financial data that comprise each segment as a result of the name changes and there was no impact to previously disclosed segment information.

[0000833444-16-000120:mdna:9]
[same as prior period, unchanged from 0000833444-15-000062:mdna:8]

[0000833444-16-000120:mdna:10]
| • | North America Integrated Solutions & Services ("NA Integrated Solutions & Services") designs, sells, installs, services and monitors integrated electronic security systems and integrated fire detection and suppression systems for commercial, industrial, retail, small business, institutional and governmental customers in North America. |

[0000833444-16-000120:mdna:11]
| • | Rest of World Integrated Solutions & Services ("ROW Integrated Solutions & Services") designs, sells, installs, services and monitors integrated electronic security systems and integrated fire detection and suppression systems for commercial, industrial, retail, residential, small business, institutional and governmental customers in the Rest of World ("ROW") regions. |

[0000833444-16-000120:mdna:12]
| • | Global Products designs, manufactures and sells fire protection, security and life safety products, including intrusion security, anti-theft devices, breathing apparatus and access control and video management systems, for commercial, industrial, retail, residential, small business, institutional and governmental customers worldwide, including products installed and serviced by our NA and ROW Integrated Solutions & Services segments. |

[0000833444-16-000120:mdna:13]
[same as prior period, unchanged from 0000833444-15-000062:mdna:12]

[0000833444-16-000120:mdna:14]
Certain prior period amounts have been reclassified to conform with the current period presentation.

[0000833444-16-000120:mdna:15]
Effective for the first quarter of fiscal 2016, the Company has elected to present operating income by segment, as well as Corporate and Other, excluding restructuring and repositioning charges, net.  Restructuring and repositioning charges, net, are shown in aggregate. This measure of segment operating income (loss) is consistent with how management reviews the businesses, makes investing and resource decisions and assesses operating performance. See Note 14 to the unaudited Consolidated Financial Statements.

[0000833444-16-000120:mdna:16]
During the first quarter of fiscal 2016, the Company approved a plan to divest its Australian fire protection business, included in the ROW Integrated Solutions & Services segment.  The Company expects to complete this divestiture during the second quarter of fiscal 2016.  The assets and liabilities related to this business were classified as held for sale for all periods presented.  Its results of operations are included in continuing operations, as the criteria to be presented as a discontinued operation were not satisfied.

[0000833444-16-000120:mdna:17]
During the second quarter of fiscal 2015, the Company approved a plan to sell a business in its ROW Integrated Solutions & Services segment which the Company expects to complete during the second quarter of fiscal 2016.  The assets and liabilities of this business are classified as held for sale, and its results of operations are presented as discontinued operations for all periods presented. See Note 2 to the unaudited Consolidated Financial Statements.

[0000833444-16-000120:mdna:18]
Recent Transactions

[0000833444-16-000120:mdna:19]
On January 24, 2016, Tyco and Johnson Controls, Inc. announced that they have entered into a definitive merger agreement under which Johnson Controls, Inc., a global multi-industrial company, will combine with Tyco. See Note 19 to the unaudited Consolidated Financial Statements.

[0000833444-16-000120:mdna:20]
On January 15, 2016, Tyco entered into Stipulations of Settled Issues with the IRS intended to resolve all disputes related to the intercompany debt issues for the 1997 - 2000 audit cycle currently before the U.S. Tax Court. The Stipulations of Settled Issues are contingent upon the IRS Appeals Division applying the same settlement to all intercompany debt issues on appeal for subsequent audit cycles (2001 - 2007) and, if applicable, review by the United States Congress Joint Committee on Taxation. If finalized, the tentative resolution would cover all aspects of the controversy before the U.S. Tax Court described above and before the Appeals Division of the IRS, and would result in a total cash payment to the IRS in the range of $475 million to $525 million, which includes all interest and penalties. This payment would be subject to the sharing formula in each Tax Sharing Agreement, and would be shared among Tyco, Covidien and TE Connectivity 27%, 42% and 31%, respectively, with neither ADT nor Pentair being responsible for any payment related to this amount. Assuming the tentative resolution is finalized, Tyco does not expect to recognize any additional charges related to the resolution, as it had previously recorded sufficient reserves with respect to this controversy and its obligations under the Tax Sharing Agreements. Payment is expected to be made to the IRS, and among Tyco, Covidien and TE Connectivity, within the next six months. See Note 5 to the unaudited Consolidated Financial Statements.

[0000833444-16-000120:mdna:21]
The Company continues to make strategic acquisitions and investments to complement its core businesses.  During the quarter ended December 25, 2015, the Company made an additional investment of approximately $128 million in the Company's joint venture, Tyco UAE, with its local partner Suwaidi Engineering Group in the United Arab Emirates ("UAE"). Tyco UAE is a leading provider of fire, security and integrated solutions and services in the UAE and also has operations in Qatar and Oman.  Effective with the date of this transaction, the Company consolidated 100% of Tyco UAE, which is recorded in the Company's ROW Integrated Solutions & Services segment. As a result of this transaction, the Company recorded a net gain of $111 million recorded in Selling, general and administrative expenses within the Company's Consolidated Statements of Operations. See Note 4 to the unaudited Consolidated Financial Statements.

[0000833444-16-000120:mdna:22]
In addition, the Company announced it had reached a definitive agreement to acquire ShopperTrak, a leading global provider of retail consumer behavior insights and location-based analytics, for approximately $175 million in cash.  The transaction closed during the second quarter of fiscal 2016. The financial results of this business will be reported in the ROW Integrated Solutions & Services segment.  See Note 4 to the unaudited Consolidated Financial Statements.

[0000833444-16-000120:mdna:23]
The Company continuously assesses the strategic fit of its various businesses and pursues the divestiture of certain businesses included within the Company's portfolio which do not align with the Company's long-term strategy. During the quarter ended December 25, 2015, the Company approved a plan to sell its Australian fire protection business within its ROW Integrated Solutions & Services segment. The assets and liabilities of this business have been presented separately as held for sale within the Consolidated Balance Sheets for all periods presented. A pre-tax loss of approximately $57 million for the write-down to fair value, less cost to sell, was recorded in Selling, general and administrative expenses within the Company’s Consolidated Statements of Operations in the quarter. This business has not been presented in discontinued operations within the Consolidated Statements of Operations, as the criteria to be presented as a discontinued operation had not been met. The

[0000833444-16-000120:mdna:24]
sale of the business was completed in the second quarter of fiscal 2016. See Note 2 to the unaudited Consolidated Financial Statements.

[0000833444-16-000120:mdna:25]
On September 14, 2015, the Company and TIFSA announced the redemption of all of the outstanding $242 million aggregate principal amount of 7.0% notes due 2019 and $462 million aggregate principal amount of 6.875% notes due 2021. On October 14, 2015, TIFSA paid cash of $876 million to complete the redemption, resulting in a loss on extinguishment of $168 million which was recorded in Other expense, net within the Consolidated Statements of Operations during the first quarter of fiscal 2016. On October 15, 2015, the Company repaid at maturity $258 million aggregate principal amount of 3.375% notes which matured on such date. See Note 8 to the unaudited Consolidated Financial Statements.

[0000833444-16-000120:mdna:26]
[same as prior period, unchanged from 0000833444-15-000062:mdna:14]

[0000833444-16-000120:mdna:27]
We are a leading global provider of security products and services, fire detection and suppression products and services and life safety products. We utilize our extensive global footprint of approximately 900 locations, including manufacturing facilities, service and distribution centers, monitoring centers and sales offices, to provide solutions and localized expertise to our global customer base. We provide an extensive range of product and service offerings to over 3 million customers in more than 100 countries through multiple channels. Our revenues are broadly diversified across the United States and Canada (collectively “North America”); Central America and South America (collectively “Latin America”); Europe, the Middle East, and Africa (collectively “EMEA”) and the Asia-Pacific geographic areas. The following chart reflects our net revenue by geographic area for the three months ended December 25, 2015.

[0000833444-16-000120:mdna:28]
Three Months Ended December 25, 2015

[0000833444-16-000120:mdna:29]
[same as prior period, unchanged from 0000833444-15-000062:mdna:17]

[0000833444-16-000120:mdna:30]
[same as prior period, unchanged from 0000833444-15-000062:mdna:18]

[0000833444-16-000120:mdna:31]
[same as prior period, unchanged from 0000833444-15-000062:mdna:19]

[0000833444-16-000120:mdna:32]
[same as prior period, unchanged from 0000833444-15-000062:mdna:20]

[0000833444-16-000120:mdna:33]
| • | Retail and small business customers, including international, regional and local consumer outlets, from national chains to specialty stores; |

[0000833444-16-000120:mdna:34]
[same as prior period, unchanged from 0000833444-15-000062:mdna:22]

[0000833444-16-000120:mdna:35]
[same as prior period, unchanged from 0000833444-15-000062:mdna:23]

[0000833444-16-000120:mdna:36]
| • | Residential customers outside of North America, including owners of single family homes and local providers of a wide range of goods and services. |

[0000833444-16-000120:mdna:37]
As a global business with a varied customer base and an extensive range of products and services, our operations and results are impacted by global, regional and industry specific factors, and by political factors. Our geographic diversity and the diversity in our customer base and our products and services has helped mitigate the impact of any one industry or the economy of any single country on our consolidated operating results, financial condition and cash flows. Due to the global nature of our business and the variety of our customers, products and services, no single factor is predominantly used to forecast Company results. Rather, management monitors a number of factors to develop expectations regarding future results, including the activity of key competitors and customers, order rates for longer lead time projects, and capital expenditure budgets and spending patterns of our customers. We also monitor trends throughout the commercial and residential fire and security markets, including building codes and fire-safety standards. Our commercial installation businesses are impacted by trends in commercial construction starts, while our residential business, which is located outside of North America, is impacted by new housing starts.

[0000833444-16-000120:mdna:38]
Because we are a global business, with approximately 51% of our revenue generated outside the United States, and because our financial statements are prepared in U.S. Dollars, the results of our operations are impacted by changes in foreign currency exchange rates. During the quarter, the U.S. Dollar has remained strong against the currencies of most of the significant non-U.S. jurisdictions where we operate. The most significant impact on our results has been due to the strengthening of the U.S. Dollar as compared to the Euro and the Canadian Dollar, which has unfavorably impacted our revenue and operating income during fiscal 2015 and 2016.

[0000833444-16-000120:mdna:39]
In addition, the Company sells its products and services into high-hazard, heavy industrial end markets. Revenue from this market vertical is spread across each of the Company’s segments, with the most significant exposure in the United Kingdom in the ROW Integrated Solutions & Services segment and in the Fire Protection Products business in the Global Products segment. As a result of recent volatility in oil prices, this market vertical has seen significant changes in spending patterns, in particular with respect to capital expenditures. The revenue tied to this market vertical was unfavorably impacted during fiscal 2015, and we expect weakness in this sector to continue during fiscal 2016.

[0000833444-16-000120:mdna:40]
45

[0000833444-16-000120:mdna:41]
[same as prior period, unchanged from 0000833444-15-000062:mdna:28]

[0000833444-16-000120:mdna:42]
[same as prior period, unchanged from 0000833444-15-000062:mdna:29]

[0000833444-16-000120:mdna:43]
|  | For the Quarters Ended |
| ($ in millions) | December 25, 2015 |  | December 26, 2014 |
| Net revenue | $ | 2,376 |  |  | $ | 2,478 |  |
| Net revenue decline | (4.1 | )% |  | N/A |  |
| Organic revenue growth | 0.1 | % |  | N/A |  |
| Segment operating income (1) | $ | 362 |  |  | $ | 323 |  |
| Segment operating margin (1) | 15.2 | % |  | 13.0 | % |
| Corporate and other (1) | $ | (51 | ) |  | $ | (49 | ) |
| Restructuring and repositioning charges, net | (18 | ) |  | (75 | ) |
| Operating income | 293 |  |  | 199 |  |
| Operating margin | 12.3 | % |  | 8.0 | % |
| Interest income | $ | 4 |  |  | $ | 3 |  |
| Interest expense | (24 | ) |  | (24 | ) |
| Other (expense) income, net | (165 | ) |  | 4 |  |
| Income tax expense | (36 | ) |  | (19 | ) |
| Income from continuing operations attributable to Tyco ordinary shareholders | 72 |  |  | 164 |  |

[0000833444-16-000120:mdna:44]
(1) Segment operating income and margin, as well as Corporate and Other, exclude Restructuring and repositioning charges, net. This measure of  segment operating income (loss) is consistent with how management reviews the businesses, makes investing and resource decisions and assesses operating performance.

[0000833444-16-000120:mdna:45]
[same as prior period, unchanged from 0000833444-15-000062:mdna:31]

[0000833444-16-000120:mdna:46]
Net revenue for the quarter ended December 25, 2015 decreased by $102 million, or 4.1%, to $2,376 million as compared to net revenue of $2,478 million for the quarter ended December 26, 2014.  Changes in foreign currency exchange rates had an unfavorable impact of $152 million, or 6.1%, on net revenue, primarily in our ROW Integrated Solutions & Services segment, and to a lesser extent, in our Global Products segment.  In addition, divestitures had an unfavorable impact of $23 million, or 0.9%, primarily in the ROW Integrated Solutions & Services segment.  On an organic basis, net revenue was flat year over year, primarily as a result of growth in our NA Integrated Solutions & Services segment, offset by declines in our Global Products and ROW Integrated Solutions & Services segments.  Net revenue was favorably impacted by acquisitions that contributed $71 million, or 2.9%, primarily within our Global Products and ROW Integrated Solutions & Services segments.

[0000833444-16-000120:mdna:47]
Cost of Revenue and Selling, General & Administrative ("SG&A")

[0000833444-16-000120:mdna:48]
The significant components of cost of product sales include material costs, labor and overhead costs, product shipping and warehousing costs. The significant components of cost of services include labor and employee related costs, depreciation expense, costs associated with our equipment and fleet of vehicles, telecommunication costs and material costs. The significant components of SG&A include compensation and compensation related costs, facility and maintenance expenses and professional fees. SG&A for the quarter ended December 25, 2015 includes a net gain on an equity investment of $111 million, partially offset by divestiture charges, net, of $52 million. See Notes 2 and 4 to the unaudited Consolidated Financial Statements.

[0000833444-16-000120:mdna:49]
Restructuring and Repositioning Charges, Net

[0000833444-16-000120:mdna:50]
During fiscal 2015, the Company identified and pursued opportunities for cost savings through restructuring activities and workforce reductions to improve operating efficiencies across the Company's businesses and corporate functions.  In addition, the Company initiated certain global actions designed to reduce its cost structure and improve future profitability by streamlining operations and better aligning functions, which the Company refers to as repositioning actions. These actions may or may not lead to a future restructuring action. During fiscal 2015, the Company recorded restructuring and repositioning charges of $289 million, of which $75 million was recorded during the quarter ended December 26, 2014. The Company expects to incur restructuring and repositioning charges between $75 million and $100 million in fiscal 2016, of which $18 million was recorded during the quarter ended December 25, 2015. See Note 3 to the unaudited Consolidated Financial Statements.

[0000833444-16-000120:mdna:51]
[same as prior period, unchanged from 0000833444-15-000062:mdna:37]

[0000833444-16-000120:mdna:52]
Operating income for the quarter ended December 25, 2015 increased by $94 million, or 47.2%, to $293 million, as compared to operating income of $199 million for the quarter ended December 26, 2014. In conjunction with the additional investment in our UAE joint venture discussed in Recent Transactions above, we recorded a net gain of $111 million within Selling, general and administrative expenses relating to the Company's previously held equity method investment in the joint venture. See Note 4 to the unaudited Consolidated Financial Statements. Operating income also increased due to a $57 million reduction in restructuring and repositioning charges, net. To a lesser extent, operating income increased due to the benefit of previous productivity initiatives. These items were partially offset by $52 million of divestiture charges, net, primarily related to the write down of our Australian fire business to fair value, less cost to sell. See Note 2 to the unaudited Consolidated Financial Statements. Changes in foreign currency exchange rates also had an unfavorable impact on operating income of $14 million, or 4.8%.

[0000833444-16-000120:mdna:53]
Key items impacting operating income for the quarters ended December 25, 2015 and December 26, 2014, respectively, are as follows:

[0000833444-16-000120:mdna:54]
|  | For the Quarters Ended |
| ($ in millions) | December 25, 2015 |  | December 26, 2014 |
| Divestiture charges, net | $ | 52 |  |  | $ | 1 |  |
| Gain on equity investment, net | (111 | ) |  | — |  |
| Legacy legal gains | — |  |  | (7 | ) |
| Restructuring and repositioning charges, net | 18 |  |  | 75 |  |
| Unfavorable impact of foreign currency | 14 |  |  | 9 |  |

[0000833444-16-000120:mdna:55]
[same as prior period, unchanged from 0000833444-15-000062:mdna:43]

[0000833444-16-000120:mdna:56]
Interest income was $4 million and $3 million for the quarters ended December 25, 2015 and December 26, 2014, respectively.

[0000833444-16-000120:mdna:57]
Interest expense was $24 million for both quarters ended December 25, 2015 and December 26, 2014.

[0000833444-16-000120:mdna:58]
Other (Expense) Income, net

[0000833444-16-000120:mdna:59]
Significant components of other expense, net for the quarters ended December 25, 2015 and December 26, 2014 are as follows:

[0000833444-16-000120:mdna:60]
|  | For the Quarters Ended |
| ($ in millions) | December 25, 2015 |  | December 26, 2014 |
| Loss on extinguishment of debt (see Note 8 to the unaudited Consolidated Financial Statements) | $ | (168 | ) |  | $ | — |  |
| 2012 Tax Sharing Agreement income (see Note 5 to the unaudited Consolidated Financial Statements) | — |  |  | 2 |  |
| 2007 Tax Sharing Agreement loss (see Note 5 to the unaudited Consolidated Financial Statements) | — |  |  | (1 | ) |
| Other | 3 |  | 3 |
|  | $ | (165 | ) |  | $ | 4 |  |

[0000833444-16-000120:mdna:61]
[same as prior period, unchanged from 0000833444-15-000062:mdna:49]

[0000833444-16-000120:mdna:62]
Our effective income tax rate was 33.3% and 10.4% during the quarters ended December 25, 2015 and December 26, 2014, respectively.  The increase in our effective tax rate in the current period was primarily due to a non-recurring loss on debt extinguishment incurred in the current period for which the related deferred tax benefits will not be realized. The prior period was favorably impacted by repositioning and restructuring expenses that were primarily incurred in high tax jurisdictions.

[0000833444-16-000120:mdna:63]
The rate can vary from quarter to quarter due to discrete items, such as the settlement of income tax audits and changes in tax laws, as well as recurring factors such as the geographic mix of income before taxes.  The Company has operations and a taxable presence in nearly 60 countries outside the U.S.  All of these countries have a tax rate that is lower than the rate in the U.S.  The countries in which the Company has a material presence that have lower tax rates compared to the U.S. include

[0000833444-16-000120:mdna:64]
Canada, Australia, Ireland, Germany, Switzerland and the United Kingdom.  The Company's ability to obtain a benefit from lower tax rates outside the U.S. is dependent on its relative levels of income in countries outside the U.S. and on the statutory tax rates and tax laws in these countries.  Based on the dispersion of the Company's non-U.S. income and management’s assessment of the likelihood and magnitude of any potential change to statutory tax rates or tax laws affecting the Company, any such changes are not expected to materially affect the Company's income tax provision or net income, aside from any one-time adjustment to reflect the impact of the change in the tax rate to the Company's deferred tax balances.

[0000833444-16-000120:mdna:65]
[same as prior period, unchanged from 0000833444-15-000062:mdna:56]

[0000833444-16-000120:mdna:66]
The following chart reflects our net revenue by operating segment, as well as the percent of net revenue by operating segment, for the quarters ended December 25, 2015 and December 26, 2014, respectively.

[0000833444-16-000120:mdna:67]
[same as prior period, unchanged from 0000833444-15-000062:mdna:58]

[0000833444-16-000120:mdna:68]
NA Integrated Solutions & Services

[0000833444-16-000120:mdna:69]
Financial information for NA Integrated Solutions & Services for the quarters ended December 25, 2015 and December 26, 2014 is as follows:

[0000833444-16-000120:mdna:70]
|  | For the Quarters Ended |
| ($ in millions) | December 25, 2015 |  | December 26, 2014 |
| Net revenue | $ | 953 |  |  | $ | 951 |  |
| Net revenue growth | 0.2 | % |  | N/A |  |
| Organic revenue growth | 1.6 | % |  | N/A |  |
| Segment operating income | $ | 132 |  |  | $ | 129 |  |
| Segment operating margin | 13.9 | % |  | 13.6 | % |

[0000833444-16-000120:mdna:71]
[same as prior period, unchanged from 0000833444-15-000062:mdna:63]

[0000833444-16-000120:mdna:72]
[same as prior period, unchanged from 0000833444-15-000062:mdna:64]

[0000833444-16-000120:mdna:73]
| Factors Contributing to Year-Over-Year Change |  | First QuarterFiscal 2016 Compared toFirst QuarterFiscal 2015 |
| Organic revenue growth |  | $ | 15 |  |
| Acquisitions |  | 3 |  |
| Impact of foreign currency |  | (16 | ) |
| Total change |  | $ | 2 |  |

[0000833444-16-000120:mdna:74]
Net revenue increased $2 million, or 0.2%, to $953 million for the quarter ended December 25, 2015 as compared to $951 million for the quarter ended December 26, 2014. On an organic basis, net revenue grew by 1.6% from the comparable quarter, with growth in both integrated solutions and service revenue, and in particular, in the retail, commercial and institutional vertical markets. Net revenue was also favorably impacted by $3 million, or 0.3%, due to several acquisitions made during fiscal 2015.  Changes in foreign currency exchange rates unfavorably impacted net revenue by $16 million, or 1.7%.

[0000833444-16-000120:mdna:75]
Segment Operating Income

[0000833444-16-000120:mdna:76]
Segment operating income for the quarter ended December 25, 2015 increased $3 million, or 2.3%, to $132 million, as compared to segment operating income of $129 million for the quarter ended December 26, 2014.  Operating income was favorably impacted by the benefit of previous productivity initiatives partially offset by incremental investments in sales and marketing.

[0000833444-16-000120:mdna:77]
ROW Integrated Solutions & Services

[0000833444-16-000120:mdna:78]
Financial information for ROW Integrated Solutions & Services for the quarters ended December 25, 2015 and December 26, 2014 is as follows:

[0000833444-16-000120:mdna:79]
|  | For the Quarters Ended |
| ($ in millions) | December 25, 2015 |  | December 26, 2014 |
| Net revenue | $ | 812 |  |  | $ | 916 |  |
| Net revenue decline | (11.4 | )% |  | N/A |  |
| Organic revenue decline | (1.1 | )% |  | N/A |  |
| Segment operating income | $ | 133 |  |  | $ | 89 |  |
| Segment operating margin | 16.4 | % |  | 9.7 | % |

[0000833444-16-000120:mdna:80]
[same as prior period, unchanged from 0000833444-15-000062:mdna:76]

[0000833444-16-000120:mdna:81]
[same as prior period, unchanged from 0000833444-15-000062:mdna:77]

[0000833444-16-000120:mdna:82]
| Factors Contributing to Year-Over-Year Change |  | First QuarterFiscal 2016 Compared toFirst QuarterFiscal 2015 |
| Organic revenue decline |  | $ | (10 | ) |
| Acquisitions |  | 29 |  |
| Divestitures |  | (22 | ) |
| Impact of foreign currency |  | (101 | ) |
| Total change |  | $ | (104 | ) |

[0000833444-16-000120:mdna:83]
Net revenue decreased $104 million, or 11.4%, to $812 million for the quarter ended December 25, 2015 as compared to $916 million for the quarter ended December 26, 2014. Changes in foreign currency exchange rates unfavorably impacted net revenue by $101 million, or 11.0%. On an organic basis, net revenue declined by $10 million, or 1.1%, driven by a decline in integrated solutions revenue, partially offset by growth in services revenue. The organic revenue decline is primarily in the United Kingdom and the Pacific region as a result of pressure within the high-hazard, heavy industrial end markets, and to a

[0000833444-16-000120:mdna:84]
lesser extent, Asia. These declines were partially offset by organic revenue growth in Continental Europe and our growth markets. In addition, divestitures in Asia had an unfavorable impact of $22 million, or 2.4%. Net revenue was favorably impacted by $29 million, or 3.2%, due to acquisitions primarily within growth markets and retail solutions.

[0000833444-16-000120:mdna:85]
Segment Operating Income

[0000833444-16-000120:mdna:86]
Segment operating income for the quarter ended December 25, 2015 increased $44 million, or 49.4%, to $133 million as compared to segment operating income of $89 million for the quarter ended December 26, 2014. In conjunction with the additional investment in our UAE joint venture discussed in Recent Transactions above, we recorded a net gain of $111 million within Selling, general and administrative expenses relating to the Company's previously held equity method investment in the joint venture. See Note 4 to the unaudited Consolidated Financial Statements. To a lesser extent, segment operating income increased due to the benefit of previous productivity initiatives. These items were partially offset by $54 million of divestiture charges, net, primarily related to the write down of our Australian fire business to fair value, less cost to sell. See Note 2 to the unaudited Consolidated Financial Statements. In addition, changes in foreign currency exchange rates had an unfavorable impact on segment operating income of $9 million, or 6.8%.

[0000833444-16-000120:mdna:87]
Key items impacting segment operating income for the quarters ended December 25, 2015 and December 26, 2014, respectively, are as follows:

[0000833444-16-000120:mdna:88]
|  | For the Quarters Ended |
| ($ in millions) | December 25, 2015 |  | December 26, 2014 |
| Divestiture charges, net | $ | 54 |  |  | $ | 1 |  |
| Gain on equity investment, net | (111 | ) |  | — |  |
| Unfavorable impact of foreign currency | 9 |  |  | 6 |  |

[0000833444-16-000120:mdna:89]
[same as prior period, unchanged from 0000833444-15-000062:mdna:86]

[0000833444-16-000120:mdna:90]
Financial information for Global Products for the quarters ended December 25, 2015 and December 26, 2014 is as follows:

[0000833444-16-000120:mdna:91]
|  | For the Quarters Ended |
| ($ in millions) | December 25, 2015 |  | December 26, 2014 |
| Net revenue | $ | 611 |  |  | $ | 611 |  |
| Net revenue growth | — | % |  | N/A |  |
| Organic revenue decline | (0.5 | )% |  | N/A |  |
| Segment operating income | $ | 97 |  |  | $ | 105 |  |
| Segment operating margin | 15.9 | % |  | 17.2 | % |

[0000833444-16-000120:mdna:92]
[same as prior period, unchanged from 0000833444-15-000062:mdna:89]

[0000833444-16-000120:mdna:93]
[same as prior period, unchanged from 0000833444-15-000062:mdna:90]

[0000833444-16-000120:mdna:94]
| Factors Contributing to Year-Over-Year Change |  | First QuarterFiscal 2016 Compared toFirst QuarterFiscal 2015 |
| Organic revenue decline |  | $ | (3 | ) |
| Acquisitions |  | 39 |  |
| Divestitures |  | (1 | ) |
| Impact of foreign currency |  | (35 | ) |
| Total change |  | $ | — |  |

[0000833444-16-000120:mdna:95]
Net revenue was $611 million for both quarters ended December 25, 2015 and December 26, 2014.  On an organic basis, net revenue declined by $3 million, or 0.5%, driven by the timing of increased shipments of Scott Air-Paks in our life safety business in the comparable quarter, partially offset by organic growth in our security products and fire products businesses.  Net revenue was unfavorably impacted by changes in foreign currency exchange rates of $35 million, or 5.7%.  Net revenue was

[0000833444-16-000120:mdna:96]
favorably impacted during the quarter ended December 25, 2015 by $39 million, or 6.4%, from acquisitions, primarily related to the Industrial Safety Technologies acquisition within our life safety business in fiscal 2015.

[0000833444-16-000120:mdna:97]
Segment Operating Income

[0000833444-16-000120:mdna:98]
Segment operating income for the quarter ended December 25, 2015 decreased by $8 million, or 7.6% to $97 million, as compared to segment operating income of $105 million for the quarter ended December 26, 2014. Segment operating income decreased as a result of higher amortization expense primarily due to acquisitions made during the prior year. In addition, segment operating income decreased due to product mix.

[0000833444-16-000120:mdna:99]
[same as prior period, unchanged from 0000833444-15-000062:mdna:99]

[0000833444-16-000120:mdna:100]
Corporate expense, excluding restructuring and repositioning charges, net, was $51 million and $49 million for the quarters ended December 25, 2015 and December 26, 2014, respectively. The increase in Corporate expense is due to a legacy legal gain of $7 million in the prior comparable quarter partially offset by the benefit of previous productivity initiatives.

[0000833444-16-000120:mdna:101]
Key items included in corporate expense for the quarters ended December 25, 2015 and December 26, 2014, respectively, are as follows:

[0000833444-16-000120:mdna:102]
|  | For the Quarters Ended |
| ($ in millions) | December 25, 2015 |  | December 26, 2014 |
| Legacy legal gains | $ | — |  |  | $ | (7 | ) |

[0000833444-16-000120:mdna:103]
[same as prior period, unchanged from 0000833444-15-000062:mdna:104]

[0000833444-16-000120:mdna:104]
The preparation of the unaudited Consolidated Financial Statements in conformity with U.S. GAAP requires management to use judgment in making estimates and assumptions that affect the reported amounts of assets and liabilities, disclosure of contingent assets and liabilities and the reported amounts of revenue and expenses. We believe that our accounting policies for depreciation and amortization methods of security monitoring-related assets, revenue recognition, loss contingencies, income taxes, goodwill and indefinite-lived intangible assets, long-lived assets and pension and postretirement benefits are based on, among other things, judgments and assumptions made by management that include inherent risks and uncertainties. Effective September 26, 2015, we changed the approach used to measure service and interest costs for pension benefits. For fiscal 2016, we elected to measure service and interest costs by applying the specific spot rates along the yield curve over the projected cash flow period. Management believes the new approach provides a more precise measurement of service and interest costs by improving the correlation between projected benefit cash flows to the corresponding spot rates on the yield curves. We have accounted for this change as a change in accounting estimate and, accordingly, have accounted for it on a prospective basis. See Note 11 to the unaudited Consolidated Financial Statements. During fiscal 2016, there have been no significant changes to these policies or in the underlying accounting assumptions and estimates used in the above critical accounting policies from those disclosed in the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K filed with the SEC on November 13, 2015 for the fiscal year ended September 25, 2015. See Note 1 to the unaudited Consolidated Financial Statements for recently issued and adopted accounting standards.

[0000833444-16-000120:mdna:105]
[same as prior period, unchanged from 0000833444-15-000062:mdna:106]

[0000833444-16-000120:mdna:106]
[same as prior period, unchanged from 0000833444-15-000062:mdna:107]

[0000833444-16-000120:mdna:107]
The primary source of funds to finance our operations and capital expenditures is cash generated by operations. In addition, we maintain a $1.5 billion commercial paper program, backed up by a committed revolving credit facility, and have access to equity and debt capital from public and private sources. We continue to balance our operating, investing, and financing uses of cash through investments and acquisitions in our core businesses, dividends, and share repurchases.  In addition, we believe our available cash, amounts available under our credit facility, commercial paper program and cash provided by operating activities will be adequate to cover our operational, capital and other business needs in the foreseeable future. To the extent it is necessary for us to finance our cash needs through the issuance of commercial paper, by accessing our committed revolving credit facility, or through other public or private sources, our cost of funding may increase depending on market conditions at the time of such borrowing.

[0000833444-16-000120:mdna:108]
As of December 25, 2015 and September 25, 2015, our cash and cash equivalents, short- and long-term debt at carrying value, and Tyco shareholder's equity are as follows:

[0000833444-16-000120:mdna:109]
|  | As of |  | Credit Availability as of |
| ($ in millions) | December 25, 2015 |  | September 25, 2015 |  | December 25, 2015 |
| Cash and cash equivalents | $ | 301 |  |  | $ | 1,401 |  |  | $ | — |  |
| Total debt (excluding revolving credit facility) | 2,298 |  |  | 3,146 |  |  | — |  |
| Revolving credit facility | — |  |  | — |  |  | 1,500 |  |
| Total Tyco shareholders' equity | 4,009 |  |  | 4,041 |  |  | — |  |
| Total debt as a % of total capital (1) | 36.4 | % |  | 43.8 | % |  | N/A |  |

[0000833444-16-000120:mdna:110]
(1) Total capital represents the aggregate amount of total debt and total shareholders' equity which was $6,307 million and $7,187 million as of December 25, 2015 and September 25, 2015, respectively.

[0000833444-16-000120:mdna:111]
Significant uses of capital that are expected in the near- to mid-term include expenditures for (i) capital expenditures and dealer investments in annual amounts expected to approximate 3% to 3.5% of total revenues, (ii) the funding of potential tax liabilities or settlements (see Note 5 to the unaudited Consolidated Financial Statements), including with respect to the divestiture of our ADT Korea business (see Note 2 to the unaudited Consolidated Financial Statements), (iii) estimated restructuring payments, of which $124 million has been accrued as a current liability as of December 25, 2015 (see Note 3 to the unaudited Consolidated Financial Statements), and (iv) quarterly dividend payments, of which $87 million has been accrued as of December 25, 2015 (see Note 12 to the unaudited Consolidated Financial Statements). The Company intends to fund these capital uses through a combination of available cash, cash generated from operations, borrowing in the commercial paper market or under its revolving credit facility, and borrowing in public or private markets for debt securities. In addition, the Company intends, in its discretion, to pursue strategically important acquisitions, may repurchase its shares from time to time and may engage in other capital market activities, in each case depending on a number of factors, including the Company’s strategic priorities, its financial condition and results of operations, the capital requirements of the Company’s businesses, industry and capital markets factors and other relevant factors.

[0000833444-16-000120:mdna:112]
[same as prior period, unchanged from 0000833444-15-000062:mdna:113]

[0000833444-16-000120:mdna:113]
Our cash flows from operating, investing and financing from continuing operations for the three months ended December 25, 2015 and December 26, 2014 are summarized below:

[0000833444-16-000120:mdna:114]
|  | For the Three Months Ended |
| ($ in millions) | December 25, 2015 |  | December 26, 2014 |
| Net cash provided by operating activities | $ | 189 |  |  | $ | 95 |  |
| Net cash (used in) provided by investing activities | (211 | ) |  | 7 |  |
| Net cash used in financing activities | (1,069 | ) |  | (511 | ) |

[0000833444-16-000120:mdna:115]
[same as prior period, unchanged from 0000833444-15-000062:mdna:118]

[0000833444-16-000120:mdna:116]
Cash flow from operating activities can fluctuate significantly from period to period as working capital needs and the timing of payments for items such as restructuring activities, asbestos activities, pension funding, income taxes and other items impact reported cash flow.

[0000833444-16-000120:mdna:117]
The net change in working capital decreased operating cash flow by $120 million in the three months ended December 25, 2015. The significant changes in working capital included a $48 million increase in prepaid expenses and other assets, a $41 million decrease in accrued and other liabilities, a $37 million decrease in deferred revenue, and a $34 million increase in inventories, partially offset by a $29 million decrease in accounts receivable.

[0000833444-16-000120:mdna:118]
The net change in working capital decreased operating cash flow by $181 million in the three months ended December 26, 2014. The significant changes in working capital included a $43 million increase in inventories, a $41 million decrease in accounts payable, a $38 million decrease in deferred revenue and a $29 million decrease in accrued and other liabilities, partially offset by a $22 million decrease in asbestos insurance assets.

[0000833444-16-000120:mdna:119]
During the three months ended December 25, 2015 and December 26, 2014, we paid approximately $26 million and $27 million, respectively, in cash related to restructuring activities. During the three months ended December 25, 2015 and December 26, 2014, we paid approximately $21 million and $7 million, respectively, in cash related to repositioning activities.

[0000833444-16-000120:mdna:120]
52

[0000833444-16-000120:mdna:121]
During the three months ended December 25, 2015 and December 26, 2014, we made required contributions of nil and $1 million, respectively, to our U.S. pension plans and $11 million and $5 million, respectively, to our non-U.S. pension plans. We anticipate that we will contribute at least the minimum required to our pension plans in 2016 of $3 million for our U.S. plans and $25 million for our non-U.S. plans.

[0000833444-16-000120:mdna:122]
Income taxes paid, net of refunds, related to continuing operations were $7 million and $26 million during the three months ended December 25, 2015 and December 26, 2014, respectively.

[0000833444-16-000120:mdna:123]
Net interest paid related to continuing operations was $14 million and $10 million for the three months ended December 25, 2015 and December 26, 2014, respectively.

[0000833444-16-000120:mdna:124]
[same as prior period, unchanged from 0000833444-15-000062:mdna:131]

[0000833444-16-000120:mdna:125]
Cash flows related to investing activities consist primarily of cash used for capital expenditures and acquisitions, proceeds derived from divestitures of businesses and assets and the purchase and sales and maturities of investments.

[0000833444-16-000120:mdna:126]
We made capital expenditures of $68 million and $66 million for the three months ended December 25, 2015 and December 26, 2014, respectively.  The level of capital expenditures in fiscal 2016 is expected to exceed the spending levels in fiscal 2015 and is also expected to exceed depreciation expense.

[0000833444-16-000120:mdna:127]
During the three months ended December 25, 2015, total consideration for acquisitions was $138 million, which was comprised of $176 million of cash paid, including $5 million to settle pre-existing matters and $6 million for pre-paid agency commissions, net of cash acquired of $27 million, which primarily related to our additional investment in the UAE joint venture in our ROW Integrated Solutions & Services segment. During the three months ended December 26, 2014, we paid cash for acquisitions totaling $152 million, net of $23 million cash acquired, which related to acquisitions in in our ROW Integrated Solutions & Services and Global Products segments.

[0000833444-16-000120:mdna:128]
During the three months ended December 25, 2015, we made net purchases of investments including restricted investments of $6 million. During the three months ended December 26, 2014, we had net proceeds from investments and restricted investments of $274 million, primarily relating to the maturity of time deposits of $275 million.

[0000833444-16-000120:mdna:129]
During the three months ended December 25, 2015, our restricted cash decreased by $5 million, primarily due to asbestos-related payments.  During the three months ended December 26, 2014, our restricted cash increased by $45 million.  This increase was primarily driven by $22 million related to the asbestos-related qualified settlement fund and $12 million of cash received from Mr. Swartz.  See Note 10 to the unaudited Consolidated Financial Statements.

[0000833444-16-000120:mdna:130]
[same as prior period, unchanged from 0000833444-15-000062:mdna:139]

[0000833444-16-000120:mdna:131]
[same as prior period, unchanged from 0000833444-15-000062:mdna:140]

[0000833444-16-000120:mdna:132]
During the three months ended December 25, 2015, we repaid a total of approximately $1,134 million of current portion of long-term debt and $666 million of short-term debt.  On October 14, 2015, the Company redeemed its outstanding $242 million aggregate principal amount 7.0% notes due 2019 and $462 million aggregate principal amount 6.875% notes due 2021, which were classified as current as of September 25, 2015, for total cash of $876 million, which included a make-whole premium of $172 million. Also, on October 15, 2015, the Company repaid $258 million aggregate principal amount of 3.375% notes due 2015, which matured on such date. In addition, during the three months ended December 25, 2015, we issued commercial paper of $817 million, $666 million of which was repaid during the quarter.  As of December 25, 2015 and September 25, 2015, TIFSA had commercial paper outstanding of $151 million and nil, respectively.  The maximum aggregate amount of unsecured commercial paper notes available to be issued, on a private placement basis, under the commercial paper program is $1.5 billion as of December 25, 2015.  During the three months ended December 26, 2014, there were no proceeds from or repayments of short-term debt. As of December 25, 2015 and September 25, 2015, there were no amounts drawn under the Company's revolving credit facility.  See Note 8 to the unaudited Consolidated Financial Statements.

[0000833444-16-000120:mdna:133]
Pursuant to our share repurchase program, we may repurchase Tyco shares from time to time in open market purchases at prevailing market prices, in negotiated transactions off the market, or pursuant to an approved trading plan in accordance with applicable regulations. During the three months ended December 25, 2015, we did not repurchase shares. During the three months ended December 26, 2014, we repurchased approximately 10 million ordinary shares for approximately $417 million.

[0000833444-16-000120:mdna:134]
During the three months ended December 25, 2015 and December 26, 2014, we paid cash dividends of approximately $87 million and $75 million, respectively.

[0000833444-16-000120:mdna:135]
During the three months ended December 26, 2014, we paid contingent consideration of $23 million which related to the successful transfer of a business license in China to Tyco.  No contingent consideration was paid during the three months ended December 25, 2015.

[0000833444-16-000120:mdna:136]
Management believes that cash generated by or available to us should be sufficient to fund our capital and operational business needs for the foreseeable future.

[0000833444-16-000120:mdna:137]
Commitments and Contingencies

[0000833444-16-000120:mdna:138]
For a detailed discussion of contingencies related to tax and litigation matters, see Notes 5 and 10 to the unaudited Consolidated Financial Statements.

[0000833444-16-000120:mdna:139]
[same as prior period, unchanged from 0000833444-15-000062:mdna:151]

[0000833444-16-000120:mdna:140]
We had a backlog of unfilled orders of $4,650 million and $4,562 million as of December 25, 2015 and September 25, 2015, respectively.

[0000833444-16-000120:mdna:141]
The Company's backlog includes recurring revenue-in-force and long-term deferred revenue for upfront fees from its NA and ROW Integrated Solutions & Services segments. Revenue-in-force represents 12 months' revenue associated with monitoring and maintenance services under contract in the security and fire business. Backlog by segment was as follows ($ in millions):

[0000833444-16-000120:mdna:142]
|  | NA Integrated Solutions & Services |  | ROW Integrated Solutions & Services |  | GlobalProducts |  | Total |
| As of September 25, 2015 |  |  |  |  |  |  |  |
| Backlog | $ | 1,035 |  |  | $ | 820 |  |  | $ | 195 |  |  | $ | 2,050 |  |
| Recurring revenue in force | 1,229 |  |  | 1,013 |  |  | — |  |  | 2,242 |  |
| Deferred revenue | 235 |  |  | 35 |  |  | — |  |  | 270 |  |
| Total Backlog | $ | 2,499 |  |  | $ | 1,868 |  |  | $ | 195 |  |  | $ | 4,562 |  |
| As of December 25, 2015 |  |  |  |  |  |  |  |  |  |  |  |
| Backlog | $ | 1,057 |  |  | $ | 974 |  |  | $ | 180 |  |  | $ | 2,211 |  |
| Recurring revenue in force | 1,224 |  |  | 954 |  |  | — |  |  | 2,178 |  |
| Deferred revenue | 229 |  |  | 32 |  |  | — |  |  | 261 |  |
| Total Backlog | $ | 2,510 |  |  | $ | 1,960 |  |  | $ | 180 |  |  | $ | 4,650 |  |

[0000833444-16-000120:mdna:143]
Total backlog increased $88 million, or 1.9%, to $4,650 million as of December 25, 2015 compared to $4,562 million as of September 25, 2015. Acquisitions during the first quarter of fiscal 2016 contributed approximately $158 million, or 3.5%, to total backlog, primarily related to our UAE business. This increase was partially offset by changes in foreign currency, which had an unfavorable impact to total backlog of $59 million, or 1.3%, primarily in our ROW Integrated Solutions & Services segment.

[0000833444-16-000120:mdna:144]
[same as prior period, unchanged from 0000833444-15-000062:mdna:156]

[0000833444-16-000120:mdna:145]
[same as prior period, unchanged from 0000833444-15-000062:mdna:157]

[0000833444-16-000120:mdna:146]
There are certain guarantees or indemnifications extended among Tyco, Covidien, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 Separation and Distribution Agreements and the Tax Sharing Agreements. The guarantees primarily relate to certain contingent tax liabilities included in the Tax Sharing Agreements. At the time of the 2007 and 2012 Separations, we recorded liabilities necessary to recognize the fair value of such guarantees and indemnifications. See Note 5 to the unaudited Consolidated Financial Statements. In addition, prior to the 2007 and 2012 Separations we provided support in the form of financial and/or performance guarantees to various Covidien, TE Connectivity, ADT and Tyco Flow Control operating entities. To the extent these guarantees were not assigned in connection with the 2007 and 2012 Separations, we remained as the guarantor, but were typically indemnified by the former subsidiary. See Note 17 to the unaudited Consolidated Financial Statements.

[0000833444-16-000120:mdna:147]
54

[0000833444-16-000120:mdna:148]
In disposing of assets or businesses, we often provide representations, warranties and/or indemnities to cover various risks including, for example, unknown damage to the assets, environmental risks involved in the sale of real estate, liability to investigate and remediate environmental contamination at waste disposal sites and manufacturing facilities, and unidentified tax and other liabilities related to periods prior to disposition. We have no reason to believe that these uncertainties would have a material adverse effect on our financial position, results of operations or cash flows. We have recorded liabilities for known indemnifications included as part of environmental liabilities. See Note 10 to the unaudited Consolidated Financial Statements.

[0000833444-16-000120:mdna:149]
[same as prior period, unchanged from 0000833444-15-000062:mdna:160]

[0000833444-16-000120:mdna:150]
For a detailed discussion of guarantees and indemnifications, see Note 17 to the unaudited Consolidated Financial Statements.

[0000833444-16-000120:mdna:151]
[same as prior period, unchanged from 0000833444-15-000062:mdna:162]

[0000833444-16-000120:mdna:152]
In an effort to provide investors with additional information regarding our results as determined by U.S. GAAP, we also disclose the non-U.S. GAAP measures of organic revenue growth (decline) and segment operating income (loss). We believe that these measures are useful to investors in evaluating our operating performance for the periods presented. When read in conjunction with our U.S. GAAP revenue, organic revenue growth (decline) enables investors to better evaluate our operations without giving effect to fluctuations in foreign exchange rates and acquisition and divestiture activity, either of which may be significant from period to period. When read in conjunction with our U.S. GAAP operating income, segment operating income (loss) enables investors to better evaluate our operations without giving effect to restructuring and repositioning charges, net, which may significantly vary from period to period based on the opportunities and actions undertaken by the Company given various factors including, but not limited to, the Company's operating performance and general macroeconomic conditions. In addition, organic revenue growth (decline) and segment operating income (loss) are factors we use in internal evaluations of the overall performance of our business. These measures are not financial measures under U.S. GAAP and should not be considered as a substitute for revenue and operating income (loss) as determined in accordance with U.S. GAAP, and they may not be comparable to similarly titled measures reported by other companies. Organic revenue growth (decline) presented herein is defined as revenue growth (decline) excluding the effects of foreign currency fluctuations, acquisitions and divestitures and other changes that may not reflect underlying results and trends. Our organic growth (decline) calculations incorporate an estimate of prior year reported net revenue associated with acquired entities that have been fully integrated within the first year, and exclude prior year net revenue associated with entities that do not meet the criteria for discontinued operations which have been divested within the past year ("adjusted number"). We calculate the rate of organic growth (decline) based on the adjusted number to better reflect the rate of growth (decline) of the combined business, in the case of acquisitions, or the remaining business, in the case of dispositions. We base the rate of organic growth (decline) for acquired businesses that are not fully integrated within the first year upon unadjusted historical net revenue.  Foreign currency fluctuations are calculated by subtracting (i) the U.S. dollar equivalent of local currencies for the current period using monthly weighted average exchange rates for the prior period from (ii) the U.S. dollar equivalent of local currencies for the current period using monthly weighted average exchange rates for the current period. We may use organic revenue growth (decline) as a component of our compensation programs. Segment operating income (loss) excluding restructuring and repositioning charges, net, is consistent with how management reviews the businesses, makes investing and resource decisions and assesses operating performance.

[0000833444-16-000120:mdna:153]
[same as prior period, unchanged from 0000833444-15-000062:mdna:116]

[0000833444-16-000120:mdna:154]
[same as prior period, unchanged from 0000833444-15-000062:mdna:164]

[0000833444-16-000120:mdna:155]
Quarter Ended December 25, 2015

[0000833444-16-000120:mdna:156]
|  | Net Revenue for the Quarter Ended December 26, 2014 |  | Base YearAdjustmentsDivestitures / Other |  | AdjustedFiscal 2015Base Revenue |  | ForeignCurrency |  | Acquisitions |  | OrganicRevenue |  | OrganicGrowth (Decline)Percentage(1) |  | Net Revenue for the Quarter Ended December 25, 2015 |
|  | ($ in millions) |
| NA Integrated Solutions & Services | $ | 951 |  |  | $ | — |  |  | $ | 951 |  |  | $ | (16 | ) |  | $ | 3 |  |  | $ | 15 |  |  | 1.6 | % |  | $ | 953 |  |
| ROW Integrated Solutions & Services | 916 |  |  | (22 | ) |  | 894 |  |  | (101 | ) |  | 29 |  |  | (10 | ) |  | (1.1 | )% |  | 812 |  |
| Global Products | 611 |  |  | (1 | ) |  | 610 |  |  | (35 | ) |  | 39 |  |  | (3 | ) |  | (0.5 | )% |  | 611 |  |
| Total Net Revenue | $ | 2,478 |  |  | $ | (23 | ) |  | $ | 2,455 |  |  | $ | (152 | ) |  | $ | 71 |  |  | $ | 2 |  |  | 0.1 | % |  | $ | 2,376 |  |

[0000833444-16-000120:mdna:157]
| (1) | Organic revenue growth (decline) percentage based on adjusted fiscal 2015 base revenue. |

[0000833444-16-000120:mdna:158]
The tables below reconcile the non-U.S. GAAP measure of segment operating income (loss) to U.S. GAAP operating income (loss).

[0000833444-16-000120:mdna:159]
Quarter Ended December 25, 2015

[0000833444-16-000120:mdna:160]
|  | NA Integrated Solutions & Services |  | ROW Integrated Solutions & Services |  | Global Products |  | Total Operating Segments |  | Corporate and Other |  | Total |
|  | ($ in millions) |
| Segment operating income (loss) | $ | 132 |  |  | $ | 133 |  |  | $ | 97 |  |  | $ | 362 |  |  | $ | (51 | ) |  | $ | 311 |  |
| Restructuring and repositioning charges, net | (4 | ) |  | (2 | ) |  | (4 | ) |  | (10 | ) |  | (8 | ) |  | (18 | ) |
| Operating income (loss) | $ | 128 |  |  | $ | 131 |  |  | $ | 93 |  |  | $ | 352 |  |  | $ | (59 | ) |  | $ | 293 |  |

[0000833444-16-000120:mdna:161]
Quarter Ended December 26, 2014

[0000833444-16-000120:mdna:162]
|  | NA Integrated Solutions & Services |  | ROW Integrated Solutions & Services |  | Global Products |  | Total Operating Segments |  | Corporate and Other |  | Total |
|  | ($ in millions) |
| Segment operating income (loss) | $ | 129 |  |  | $ | 89 |  |  | $ | 105 |  |  | $ | 323 |  |  | $ | (49 | ) |  | $ | 274 |  |
| Restructuring and repositioning charges, net | (24 | ) |  | (19 | ) |  | (7 | ) |  | (50 | ) |  | (25 | ) |  | (75 | ) |
| Operating income (loss) | $ | 105 |  |  | $ | 70 |  |  | $ | 98 |  |  | $ | 273 |  |  | $ | (74 | ) |  | $ | 199 |  |

[0000833444-16-000120:mdna:163]
[same as prior period, unchanged from 0000833444-15-000062:mdna:171]

[0000833444-16-000120:mdna:164]
[same as prior period, unchanged from 0000833444-15-000062:mdna:172]

[0000833444-16-000120:mdna:165]
[same as prior period, unchanged from 0000833444-15-000062:mdna:173]

[0000833444-16-000120:mdna:166]
[same as prior period, unchanged from 0000833444-15-000062:mdna:174]

[0000833444-16-000120:mdna:167]
| • | our, and our employees' and agents' ability to comply with complex and continually changing laws and regulations that govern our international operations, including the U.S. Foreign Corrupt Practices Act, similar anti-bribery laws in other jurisdictions, a variety of export control, customs, privacy, currency exchange control and transfer pricing regulations, and our corporate policies governing these matters; |

[0000833444-16-000120:mdna:168]
| • | the outcome of litigation, arbitrations and governmental proceedings; |

[0000833444-16-000120:mdna:169]
| • | effect of income tax audits, litigation, settlements and appeals; |

[0000833444-16-000120:mdna:170]
[same as prior period, unchanged from 0000833444-15-000062:mdna:178]

[0000833444-16-000120:mdna:171]
[same as prior period, unchanged from 0000833444-15-000062:mdna:179]

[0000833444-16-000120:mdna:172]
[same as prior period, unchanged from 0000833444-15-000062:mdna:180]

[0000833444-16-000120:mdna:173]
[same as prior period, unchanged from 0000833444-15-000062:mdna:181]

[0000833444-16-000120:mdna:174]
[same as prior period, unchanged from 0000833444-15-000062:mdna:182]

[0000833444-16-000120:mdna:175]
[same as prior period, unchanged from 0000833444-15-000062:mdna:183]

[0000833444-16-000120:mdna:176]
[same as prior period, unchanged from 0000833444-15-000062:mdna:184]

[0000833444-16-000120:mdna:177]
[same as prior period, unchanged from 0000833444-15-000062:mdna:185]

[0000833444-16-000120:mdna:178]
[same as prior period, unchanged from 0000833444-15-000062:mdna:186]

[0000833444-16-000120:mdna:179]
[same as prior period, unchanged from 0000833444-15-000062:mdna:187]

[0000833444-16-000120:mdna:180]
[same as prior period, unchanged from 0000833444-15-000062:mdna:188]

[0000833444-16-000120:mdna:181]
[same as prior period, unchanged from 0000833444-15-000062:mdna:189]

[0000833444-16-000120:mdna:182]
[same as prior period, unchanged from 0000833444-15-000062:mdna:190]

[0000833444-16-000120:mdna:183]
[same as prior period, unchanged from 0000833444-15-000062:mdna:191]

[0000833444-16-000120:mdna:184]
[same as prior period, unchanged from 0000833444-15-000062:mdna:193]

[0000833444-16-000120:mdna:185]
| • | the possible effects on Tyco of future legislation in the United States that may limit or eliminate potential U.S. tax benefits resulting from Tyco International's incorporation outside of the United States or deny U.S. government contracts to Tyco based upon its jurisdiction of incorporation; |

[0000833444-16-000120:mdna:186]
[same as prior period, unchanged from 0000833444-15-000062:mdna:195]

[0000833444-16-000120:mdna:187]
[same as prior period, unchanged from 0000833444-15-000062:mdna:196]
