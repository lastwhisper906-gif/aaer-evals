# JCI 10-Q controls and the auditor's report


## item_4_controls

[0000833444-16-000120:item_4_controls:1]
Item 4.    Controls and Procedures

[0000833444-16-000120:item_4_controls:2]
The Company, under the supervision and with the participation of its management, including its Chief Executive Officer and Chief Financial Officer, carried out an evaluation of the effectiveness of the design and operation of its disclosure controls and procedures (as such term is defined under Rule 13a-15 of the Securities and Exchange Act (the Exchange Act)) as of the end of the period covered by this report. There are inherent limitations to the effectiveness of any system of disclosure controls

[0000833444-16-000120:item_4_controls:3]
57

[0000833444-16-000120:item_4_controls:4]
and procedures, including the possibility of human error and the circumvention or overriding of the controls and procedures. Accordingly, even effective disclosure controls and procedures can only provide reasonable assurance of achieving their control objectives. Based upon that evaluation, the Chief Executive Officer and Chief Financial Officer concluded that, as of December 25, 2015, the Company's disclosure controls and procedures were effective to provide reasonable assurance that information required to be disclosed in the reports that the Company files or submits under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the applicable rules and forms, and that it is accumulated and communicated to management, including the Chief Executive Officer and Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure.

[0000833444-16-000120:item_4_controls:5]
There has been no change in our internal control over financial reporting during the quarter ended December 25, 2015 that has materially affected, or is reasonably likely to materially affect, the Company's internal control over financial reporting.
