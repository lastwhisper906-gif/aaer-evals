# JCI note change history — 0000833444-15-000062 → 0000833444-16-000120


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2016-01-29):
[0000833444-16-000120:note_history:1]
As previously reported, in recent years, the Company has definitively resolved several lawsuits involving disputes with former management, including Dennis Kozlowski, the Company's former chief executive officer, and Mark Swartz, the Company's former chief financial officer.

- changed (2016-01-29):
[0000833444-16-000120:note_history:2]
In the first quarter of fiscal 2015, the Company reached a definitive agreement with Mark Swartz to resolve all outstanding disputes, and received approximately $12 million in cash from Mr. Swartz, $5 million of which was shared pursuant to the terms of a legacy class action lawsuit, resulting in a net recovery of $7 million for the Company, which was recorded in Selling, general and administrative expenses within the Consolidated Statement of Operations. The cash received has been classified as restricted.
  (was, 2015-07-31, similarity 0.6388):
[0000833444-15-000062:note_history:2]
With respect to Mark Swartz, the Company's former chief financial officer, in November 2014, the parties reached a definitive agreement to resolve all outstanding disputes, with Mr. Swartz agreeing to release the Company from any claims to monetary amounts related to compensation, retention or other arrangements alleged to have existed between him and the Company.  In the first quarter of fiscal 2015, the Company also received approximately $12 million in cash from Mr. Swartz, $5 million of which will be shared pursuant to the terms of a legacy class action lawsuit, resulting in a net recovery of $7 million for the Company, which was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations. The cash received has been classified as restricted.

- added (2016-01-29):
[0000833444-16-000120:note_history:3]
Tyco is involved in various stages of investigation and cleanup related to environmental remediation matters at a number of sites. The ultimate cost of site cleanup is difficult to predict given the uncertainties regarding the extent of the required cleanup, the interpretation of applicable laws and regulations and alternative cleanup methods. As of December 25, 2015, Tyco concluded that it was probable that it would incur remedial costs in the range of approximately $22 million to $71 million. As of December 25, 2015, Tyco concluded that the best estimate within this range is approximately $32 million, of which $11 million is included in Accrued and other current liabilities and $21 million is included in Other liabilities within the Company's Consolidated Balance Sheet.

- changed (2016-01-29):
[0000833444-16-000120:note_history:4]
As previously disclosed, the majority of the liabilities described above relate to ongoing remediation efforts at a facility in the Company's Global Products segment located in Marinette, Wisconsin, which the Company acquired in 1990 in connection with its acquisition of, among other things, the Ansul product line. As of December 25, 2015, the Company concluded that its remaining remediation and monitoring costs related to the Marinette facility were in the range of approximately $14 million to $46 million. The Company's best estimate within that range is approximately $22 million, of which $9 million is included in Accrued and other current liabilities and $13 million is included in Other liabilities within the Company's Consolidated Balance Sheet.  Although the Company has recorded its best estimate of the costs that it will incur to remediate and monitor contamination at the Marinette facility, it is possible that technological, regulatory or enforcement developments, the results of environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows.
  (was, 2015-07-31, similarity 0.6691):
[0000833444-15-000062:note_history:4]
The majority of the liabilities described above relate to ongoing remediation efforts at a facility in the Company's Global Products segment located in Marinette, Wisconsin, which the Company acquired in 1990 in connection with its acquisition of, among other things, the Ansul product line. Prior to Tyco's acquisition, Ansul manufactured arsenic-based agricultural herbicides at the Marinette facility, which resulted in significant arsenic contamination of soil and groundwater on the Marinette site and in parts of the adjoining Menominee River. Ansul has been engaged in ongoing remediation efforts at the Marinette site since 1990, and in February 2009 entered into an Administrative Consent Order (the "Consent Order") with the U.S. Environmental Protection Agency to address the presence of arsenic at the Marinette site. Under this agreement, Ansul's principal obligations are to contain the arsenic contamination on the site, pump and treat on-site groundwater, dredge, treat and properly dispose of contaminated sediments in the adjoining river areas, and monitor contamination levels on an ongoing basis. Activities completed under the Consent Order since 2009 include the installation of a subsurface barrier wall around the facility to contain contaminated groundwater, the installation of a groundwater extraction and treatment system and the dredging and offsite disposal of treated river sediment. As of June 26, 2015, the Company concluded that its remaining remediation and monitoring costs related to the Marinette facility were in the range of approximately $20 million to $47 million. The Company's best estimate within that range is approximately $23 million, of which $11 million is included in Accrued and other current liabilities and $12 million is included in Other liabilities in the Company's Consolidated Balance Sheet.  Although the Company has recorded its best estimate of the costs that it will incur to remediate and monitor the arsenic contamination at the Marinette facility, it is possible that technological, regulatory or enforcement developments, the results of environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows.

- changed (2016-01-29):
[0000833444-16-000120:note_history:5]
The Company and certain of its subsidiaries, including Grinnell LLC (“Grinnell”), along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. Substantially all cases pending against affiliates of the Company have been filed against Grinnell, and have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.
  (was, 2015-07-31, similarity 0.6198):
[0000833444-15-000062:note_history:5]
The Company and certain of its subsidiaries, including Yarway Corporation (“Yarway”) and Grinnell LLC (“Grinnell”), along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. Over 90% of cases pending against affiliates of the Company have been filed against Yarway or Grinnell, and have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components. Claims filed against Yarway derive from Yarway’s purported use of asbestos-containing gaskets and packing in the sale or distribution of steam valves and traps and from its alleged manufacture of asbestos-containing expansion joint packing. Yarway’s alleged manufacture, distribution and/or sale of asbestos-containing materials ceased by 1988, and Yarway ceased substantially all of its manufacturing, distribution and sales operations in 2003. Claims filed against Grinnell typically allege that it manufactured, sold or distributed valves, gaskets, piping and sprinkler systems containing asbestos.

- added (2016-01-29):
[0000833444-16-000120:note_history:6]
During the third quarter of fiscal 2014, the Company, through Grinnell, resolved disputes with certain of its historical insurers and agreed that certain insurance proceeds would be used to establish and fund a qualified settlement fund (“QSF”), within the meaning of the Internal Revenue Code, which would be used for the resolution primarily of Grinnell asbestos liabilities. It is intended that the QSF will receive future insurance payments and proceeds from third party insurers and, in addition, will fund and manage liabilities for certain historical operations of the Company, primarily related to Grinnell. On January 9, 2015, the Company completed a series of restructuring transactions related to the establishment and funding of a dedicated structure pursuant to which a subsidiary of the Company acquired the assets of Grinnell and transferred cash and other assets totaling approximately $278 million (not including $22 million received by the QSF during the quarter ended December 26, 2014 from historic third-party insurers in settlement of coverage disputes) to the structure. As part of the restructuring, subsidiaries in the structure assumed certain liabilities related to historic Grinnell, Scott and Figgie operations, including all historical Grinnell asbestos liabilities, and such subsidiaries purchased additional insurance by, through or from a wholly-owned subsidiary in the structure in order to supplement and enhance existing insurance assets.

- changed (2016-01-29):
[0000833444-16-000120:note_history:7]
The Company consolidates the qualified settlement fund and related entities that were established for the purpose of managing and resolving the liabilities described above. Although the entities in the dedicated structure serve the specific purpose of managing certain liabilities, each entity in the structure is a wholly-owned indirect subsidiary of the Company, and therefore is required to be consolidated under GAAP.
  (was, 2015-07-31, similarity 0.9445):
[0000833444-15-000062:note_history:7]
The Company consolidates the qualified settlement fund and related entities that were established for the purpose of managing and resolving the liabilities described above. Although the entities in the dedicated structure serve the specific purpose of managing certain liabilities, each entity in the structure is a wholly-owned indirect subsidiary of the Company, and therefore is required to be consolidated under U.S. generally accepted accounting principles.

- added (2016-01-29):
[0000833444-16-000120:note_history:8]
As of December 25, 2015, the Company has determined that there were approximately 3,100 claims pending against its subsidiaries, primarily Grinnell. This amount reflects the Company's current estimate of the number of viable claims made against Grinnell and includes adjustments for claims that are not actively being prosecuted, identify incorrect defendants, are duplicative of other actions or for which the Company is indemnified by third parties. Yarway Corporation is no longer a subsidiary of the Company and, as of August 2015, is no longer consolidated. Consequently, any claims pending against the Yarway Corporation are excluded from the claims pending above.

- added (2016-01-29):
[0000833444-16-000120:note_history:9]
As of December 25, 2015, the Company's estimated asbestos related net liability recorded within the Company's Consolidated Balance Sheet is $27 million. The net liability within the Consolidated Balance Sheet is comprised of a liability for pending and future claims and related defense costs of $508 million, of which $19 million is recorded in Accrued and other current liabilities, and $489 million is recorded in Other liabilities. The Company also maintains separate cash, investment and other assets within the Consolidated Balance Sheet of $481 million, of which $44 million is recorded in Prepaid expenses and other current assets, and $437 million is recorded in Other assets. Assets include $6 million of cash and $267 million of investments, which have all been designated as restricted.  As of September 25, 2015, the Company's estimated net liability recorded within the Company's Consolidated Balance Sheet was $28 million. The net liability was comprised of a liability for pending and future claims and related defense costs of $515 million, of which $23 million was recorded in Accrued and other current liabilities, and $492 million was recorded in Other liabilities.  The Company also maintained separate cash, investment and other assets within the Consolidated Balance Sheet of $487 million, of which $38 million was recorded in Prepaid expenses and other current assets, and $449 million was recorded in Other assets. Assets included $11 million of cash and $263 million of investments, which were all designated as restricted.

- changed (2016-01-29):
[0000833444-16-000120:note_history:10]
The Company periodically assesses the sufficiency of its estimated liability for pending and future asbestos claims and defense costs. On a periodic basis, the Company, through the dedicated structure referred to above, evaluates actual experience regarding asbestos claims filed, settled and dismissed, amounts paid in settlements, and the recoverability of its insurance assets. If and when data from actual experience demonstrate a significant unfavorable discernible trend, the Company performs a valuation of its asbestos related liabilities and corresponding insurance assets including a comprehensive review of the underlying assumptions. In addition, the Company evaluates its ability to reasonably estimate claim activity beyond its current look-forward period (through 2056) in order to assess whether such period continues to be appropriate. In addition to claims and litigation experience, the Company considers additional qualitative and quantitative factors such as changes in legislation, the legal environment, the Company’s strategy in managing claims and obtaining insurance, including its defense strategy, and health related trends in the overall population of individuals potentially exposed to asbestos. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance assets is warranted.
  (was, 2015-07-31, similarity 0.8126):
[0000833444-15-000062:note_history:10]
The Company continuously assesses the sufficiency of its estimated liability for pending and future asbestos claims and defense costs. On a quarterly basis, the Company evaluates actual experience regarding asbestos claims filed, settled and dismissed, amounts paid in settlements, and the recoverability of its insurance assets. If and when data from actual experience demonstrate an unfavorable discernible trend, the Company performs a valuation of its asbestos related liabilities and corresponding insurance assets including a comprehensive review of the underlying assumptions. In addition, the Company evaluates its ability to reasonably estimate claim activity beyond its current look-forward period in order to assess whether such period is appropriate. In addition to claims and litigation experience, the Company considers additional qualitative and quantitative factors such as changes in legislation, the legal environment, the Company’s strategy in managing claims and obtaining insurance, including its defense strategy, and health related trends in the overall population of individuals potentially exposed to asbestos. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance assets is warranted.

- added (2016-01-29):
[0000833444-16-000120:note_history:11]
As previously disclosed, on August 19, 2015, the Chapter 11 bankruptcy plan of Yarway Corporation, a former indirect wholly-owned subsidiary of the Company became effective and the Company contributed approximately $325 million in cash to the Yarway Trust and each of the Company Protected Parties (as such term is defined in the plan) received the benefit of a release from Yarway and an injunction under section 524(g) of the Bankruptcy Code permanently enjoining the assertion of Yarway asbestos claims against those parties. As a result of the effectiveness of the Chapter 11 plan, ownership of the Yarway Corporation was transferred to the Yarway Trust and it was deconsolidated from the Company. Upon deconsolidation, the Company recorded a $4 million loss, which is included in Selling, general and administrative expenses within the Company's Consolidated Statement of Operations during the year ended September 25, 2015.

- changed (2016-01-29):
[0000833444-16-000120:note_history:12]
Tyco and its subsidiaries' income tax returns are examined periodically by various tax authorities. In connection with these examinations, tax authorities, including the IRS, have raised issues and proposed tax adjustments, in particular with respect to years preceding the 2007 Separation.  The issues and proposed adjustments related to such years are generally subject to the sharing provisions of the 2007 Tax Sharing Agreement and Tyco's liabilities under the 2007 Tax Sharing Agreement are further subject to the sharing provisions in the 2012 Tax Sharing Agreement. Tyco has previously disclosed that in connection with U.S. federal tax audits, the IRS raised a number of issues and proposed tax adjustments for periods beginning with the 1997 tax year. Although Tyco resolved substantially all of the issues and adjustments proposed by the IRS for tax years through 2007, it was not able to resolve matters related to the treatment of certain intercompany debt transactions during the period. As a result, on June 20, 2013, Tyco received Notices of Deficiency from the IRS asserting that several of Tyco's former U.S. subsidiaries owe additional taxes of $883.3 million plus penalties of $154 million based on audits of the 1997 through 2000 tax years of Tyco and its subsidiaries as they existed at that time. In addition, Tyco received Final Partnership Administrative Adjustments for certain U.S. partnerships owned by former U.S. subsidiaries with respect to which an additional tax deficiency of approximately $30 million has been asserted. These amounts excluded interest and did not reflect the roll-forward impact on subsequent audit periods.
  (was, 2015-07-31, similarity 0.6108):
[0000833444-15-000062:note_history:12]
Tyco and its subsidiaries' income tax returns are examined periodically by various tax authorities. In connection with these examinations, tax authorities, including the IRS, have raised issues and proposed tax adjustments, in particular with respect to years preceding the 2007 Separation. The issues and proposed adjustments related to such years are generally subject to the sharing provisions of a tax sharing agreement entered in 2007 with Medtronic and TE Connectivity (the "2007 Tax Sharing Agreement") under which Tyco, Medtronic and TE Connectivity share 27%, 42% and 31%, respectively, of shared income tax liabilities that arise from adjustments made by tax authorities to Tyco's, Medtronic's and TE Connectivity's U.S. and certain non-U.S. income tax returns. The costs and expenses associated with the management of these shared tax liabilities are generally shared equally among the parties. Tyco has previously disclosed that in connection with U.S. federal tax audits, the IRS has raised a number of issues and proposed tax adjustments for periods beginning with the 1997 tax year. Although Tyco has been able to resolve substantially all of the issues and adjustments proposed by the IRS for tax years through 2007, it has not been able to resolve matters related to the treatment of certain intercompany debt transactions during the period. As a result, on June 20, 2013, Tyco received Notices of Deficiency from the IRS asserting that several of Tyco's former U.S. subsidiaries owe additional taxes of $883.3 million plus penalties of $154 million based on audits of the 1997 through 2000 tax years of Tyco and its subsidiaries as they existed at that time. In addition, Tyco received Final Partnership Administrative Adjustments for certain U.S. partnerships owned by former U.S. subsidiaries with respect to which an additional tax deficiency of approximately $30 million has been asserted. These amounts exclude interest and do not reflect the impact on subsequent periods if the IRS position described below is ultimately proved correct.

- added (2016-01-29):
[0000833444-16-000120:note_history:13]
On January 15, 2016, Tyco entered into Stipulations of Settled Issues with the IRS intended to resolve all disputes related to the intercompany debt issues described above for the 1997 - 2000 audit cycle currently before the U.S. Tax Court. The Stipulations of Settled Issues are contingent upon the IRS Appeals Division applying the same settlement to all intercompany debt issues on appeal for subsequent audit cycles (2001 - 2007) and, if applicable, review by the United States Congress Joint Committee on Taxation.

- added (2016-01-29):
[0000833444-16-000120:note_history:14]
If finalized, the tentative resolution would cover all aspects of the controversy before the U.S. Tax Court described above and before the Appeals Division of the IRS, and would result in a total cash payment to the IRS in the range of $475 million to $525 million, which includes all interest and penalties. This payment would be subject to the sharing formula in each Tax Sharing Agreement, and would be shared among Tyco, Covidien and TE Connectivity 27%, 42% and 31%, respectively, with neither ADT nor Pentair being responsible for any payment related to this amount.

- added (2016-01-29):
[0000833444-16-000120:note_history:15]
Assuming the tentative resolution is finalized, Tyco does not expect to recognize any additional charges related to the resolution, as it had previously recorded sufficient reserves with respect to this controversy and its obligations under the Tax Sharing Agreements. Payment is expected to be made to the IRS, and among Tyco, Covidien and TE Connectivity, within the next six months. See Note 5.

- changed (2016-01-29):
[0000833444-16-000120:note_history:16]
As previously disclosed, SimplexGrinnell LP (“SG”), a subsidiary of the Company in the North America Integrated Solutions & Services segment, has been named as a defendant in lawsuits in several jurisdictions seeking damages for SG’s alleged failure to pay prevailing wages and for other pay-related claims.  Through the first quarter of fiscal 2015, the Company had recorded a total of approximately $17 million in charges related to these lawsuits, which was recorded in the Cost of services within the Consolidated Statement of Operations.  During the quarter ended March 27, 2015, the Company agreed in principle to settle all outstanding lawsuits for a total of approximately $14 million.
  (was, 2015-07-31, similarity 0.9793):
[0000833444-15-000062:note_history:16]
As previously disclosed, SimplexGrinnell LP (“SG”), a subsidiary of the Company in the North America Installation & Services segment, has been named as a defendant in lawsuits in several jurisdictions seeking damages for SG’s alleged failure to pay prevailing wages and for other pay-related claims.  Through the first quarter of fiscal 2015, the Company had recorded a total of approximately $17 million in charges related to these lawsuits, which was recorded in the Cost of services within the Consolidated Statement of Operations.  During the quarter ended March 27, 2015, the Company agreed in principle to settle all outstanding lawsuits for a total of approximately $14 million.

- removed (2016-01-29):
[0000833444-15-000062:note_history:17]
In recent years, the Company has settled several lawsuits involving disputes with former management. With respect to Dennis Kozlowski, the Company's former chief executive officer, in the first quarter of fiscal 2014, the parties signed an agreement resolving all outstanding disputes, with Mr. Kozlowski agreeing to release the Company from any claims to monetary amounts related to compensation, retention or other arrangements. As a result, in the first quarter of fiscal 2014, the Company reversed a non-cash net liability of approximately $92 million which was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations for the amounts allegedly due to him.  Pursuant to the settlement agreement, Tyco will be entitled to a portion of the proceeds, if any, from the future sale of certain assets owned by Mr. Kozlowski, the timing and amount of which is uncertain.  During the quarter ended June 26, 2015, the Company received approximately $4 million in cash from the sale of property owned by Mr. Kozlowski, $2 million of which will be shared pursuant to the terms of a legacy class action lawsuit, resulting in a net recovery of $2 million for the Company, which was recorded in Selling, general and administrative expenses in the Consolidated Statement of Operations.  The cash received has been classified as restricted.

- removed (2016-01-29):
[0000833444-15-000062:note_history:18]
Tyco is involved in various stages of investigation and cleanup related to environmental remediation matters at a number of sites. The ultimate cost of site cleanup is difficult to predict given the uncertainties regarding the extent of the required cleanup, the interpretation of applicable laws and regulations and alternative cleanup methods. As of June 26, 2015, Tyco concluded that it was probable that it would incur remedial costs in the range of approximately $29 million to $72 million. As of June 26, 2015, Tyco concluded that the best estimate within this range is approximately $33 million, of which $15 million is included in Accrued and other current liabilities and $18 million is included in Other liabilities in the Company's Consolidated Balance Sheet.

- removed (2016-01-29):
[0000833444-15-000062:note_history:19]
As of June 26, 2015, the Company has determined that there were approximately 3,400 claims pending against it. This amount reflects the Company's current estimate of the number of viable claims made against it, excludes any claims against Yarway, and includes adjustments for claims that are not actively being prosecuted, identify incorrect defendants, are duplicative of other actions or for which the Company is indemnified by third parties. As a result of the Yarway bankruptcy filing described below, claims against Yarway have been stayed since April 2013.

- removed (2016-01-29):
[0000833444-15-000062:note_history:20]
As of June 26, 2015, the Company's estimated net liability, including Yarway, recorded within the Company's Consolidated Balance Sheet is $331 million.  The net liability is comprised of a liability for pending and future claims and related defense costs of $838 million, of which $344 million is recorded in Accrued and other current liabilities, and $494 million is recorded in Other liabilities.  The Company also maintains separate cash, investment and other assets of $507 million, of which $44 million is recorded in Prepaid expenses and other current assets, and $463 million is recorded in Other assets.  Assets include $16 million of cash and $275 million of investments, which have all been designated as restricted.  The Company believes that the asbestos related liabilities and insurance related assets as of June 26, 2015 are appropriate.  As of September 26, 2014, the Company's estimated net liability, including Yarway, of $608 million was recorded within the Company's Consolidated Balance Sheet as a liability for pending and future claims and related defense costs of $853 million, and separately as an asset for insurance recoveries of $245 million.

- removed (2016-01-29):
[0000833444-15-000062:note_history:21]
As previously disclosed, on April 22, 2013 Yarway filed a voluntary petition for relief under Chapter 11 of the U.S. Bankruptcy Code (“Chapter 11”) in the United States Bankruptcy Court for the District of Delaware (“Bankruptcy Court”). As a result of this filing, the continuation or commencement of asbestos-related litigation against Yarway has been enjoined by the automatic stay imposed by the U.S. Bankruptcy Code. Yarway's goal has been to negotiate, obtain approval of, and consummate a plan of reorganization that establishes a trust to fairly and equitably value and pay current and future Yarway asbestos claims, and that, in exchange for funding of the trust by the Company and/or its subsidiaries, provides permanent injunctive relief protecting the Company, each of its current and former affiliates and various other parties (the “Company Protected Parties”) from any further asbestos claims based on products manufactured, sold, and/or distributed by Yarway. On October 9, 2014, the Company reached an agreement in principle with Yarway, the Official Committee of Asbestos Claimants (“ACC”) appointed in the Yarway Chapter 11 case as the representative of current Yarway asbestos claimants, and the Future Claimants Representative (“FCR”) appointed in the Yarway Chapter 11 case as the representative of future Yarway asbestos claimants, to fund a section 524(g) trust for the resolution and payment of current and future Yarway asbestos claims. The agreement in principle will be implemented through a Chapter 11 plan of reorganization for Yarway, and is intended to resolve the potential liability of the Company Protected Parties for pending and future derivative personal injury claims related to exposure to asbestos-containing products that were allegedly manufactured, distributed, and/or sold by Yarway (“Yarway Asbestos Claims”). Under the Chapter 11 plan, an asbestos settlement trust (the “Yarway Trust”) that conforms to the provisions of Section 524(g) of the U.S. Bankruptcy Code will be established and, on the effective date of the Chapter 11 plan, the Company and Yarway will contribute to the Yarway Trust a total of approximately $325 million in cash (“Settlement Consideration”), which includes approximately $100 million relating to the settlement of intercompany amounts allegedly due to Yarway. In exchange for the Settlement Consideration, each of the Company Protected Parties will receive the benefit of a release from Yarway and an injunction under section 524(g) of the Bankruptcy Code permanently enjoining the assertion of Yarway Asbestos Claims against those Parties.  On April 8, 2015, following the approval of the Plan by the required number of Yarway's current asbestos claimants, the Bankruptcy Court issued an order confirming the Plan, and on July 14, 2015, the United States District Court for the District of Delaware affirmed the Plan.  Yarway expects to schedule an effective date for the Plan in August 2015.

- removed (2016-01-29):
[0000833444-15-000062:note_history:22]
On the effective date of the Plan, the Company and Yarway will pay the Settlement Consideration and Yarway Asbestos Claims against the Company Protected Parties will be permanently enjoined. Yarway is anticipated to become a wholly-owned subsidiary of the Yarway Trust and, accordingly, would no longer be owned by or be part of a consolidated group with the Company.  As a result of the agreement in principle to settle, the Company recorded a charge of $225 million in Selling, general and administrative expenses in the Consolidated Statement of Operations during the fourth fiscal quarter of 2014.

- removed (2016-01-29):
[0000833444-15-000062:note_history:23]
As a result of filing the voluntary bankruptcy petition during the third quarter of fiscal 2013, the Company recorded an expected loss upon deconsolidation of $10 million related to the Yarway Chapter 11 filing, which continues to represent the Company’s best estimate of its loss.

- removed (2016-01-29):
[0000833444-15-000062:note_history:24]
Other Claims

- removed (2016-01-29):
[0000833444-15-000062:note_history:25]
During the fourth quarter of fiscal 2014, the Company concluded that an unfavorable trend had developed in actual claim filing activity compared to projected claim filing activity established during the Company’s most recent valuation. Accordingly, the Company, with the assistance of independent actuarial service providers, performed a revised valuation of its asbestos-related liabilities and corresponding insurance assets. As part of the revised valuation, the Company assessed whether a change in its look-forward period was appropriate, taking into consideration its more extensive history and experience with asbestos-related claims and litigation (including its experience with Yarway), and determined that it was possible to make a reasonable estimate of the actuarially determined ultimate risk of loss for pending and unasserted potential future asbestos-related claims through 2056. In connection with the revised valuation, the Company considered a recent settlement with one of its insurers calling for the establishment of a qualified settlement fund, and the results of a separate independent actuarial consulting firm report conducted in the fourth quarter to assist the Company in obtaining insurance to fully fund all estimable asbestos-related claims (excluding Yarway claims) incurred through 2056.

- removed (2016-01-29):
[0000833444-15-000062:note_history:26]
The independent actuarial service firm calculated a total estimated liability for asbestos-related claims of the Company, which reflects the Company’s best estimate of its ultimate risk of loss to resolve all pending and future claims (excluding Yarway claims) through 2056, which is the Company’s reasonable best estimate of the actuarially determined time period through which asbestos-related claims will be filed against Company affiliates.

- removed (2016-01-29):
[0000833444-15-000062:note_history:27]
In conjunction with determining the total estimated liability, the Company retained an independent third party to assist it in valuing its insurance assets responsive to asbestos-related claims, excluding Yarway claims. These insurance assets represent amounts due to the Company for previously settled claims and the probable reimbursements relating to its total liability for pending and unasserted potential future asbestos claims and defense costs. In calculating this amount, the Company used the estimated asbestos liability for pending and projected future claims and defense costs described above, and it also considered the amount of insurance available, the solvency risk with respect to the Company's insurance carriers, resolution of insurance coverage issues, gaps in coverage, allocation methodologies, and the terms of existing settlement agreements with insurance carriers.

- removed (2016-01-29):
[0000833444-15-000062:note_history:28]
In connection with the foregoing, during the third quarter of fiscal 2014, the Company resolved disputes with certain of its historical insurers and agreed that certain insurance proceeds would be used to establish and fund a qualified settlement fund (“QSF”), within the meaning of the Internal Revenue Code, which would be used for the resolution primarily of Grinnell asbestos liabilities of the Company. It is intended that the QSF will receive future insurance payments and proceeds from third party insurers and, in addition, will fund and manage liabilities for certain historical operations of the Company. On January 9, 2015, the Company completed a series of restructuring transactions related to the establishment and funding of a dedicated structure pursuant to which a subsidiary of the Company acquired the assets of Grinnell and transferred cash and other assets totaling approximately $278 million (not including $22 million received by the QSF during the quarter ended December 26, 2014 from historic third-party insurers in settlement of coverage disputes) to the structure. As part of the restructuring, subsidiaries in the structure assumed certain liabilities related to historic Grinnell, Scott and Figgie operations, including all historical Grinnell asbestos liabilities, and such subsidiaries purchased additional insurance by, through or from a wholly-owned subsidiary in the structure in order to supplement and enhance existing insurance assets. The structure and the QSF fully fund all historic Grinnell asbestos liabilities and provide for the efficient and streamlined management of claims related thereto.

- removed (2016-01-29):
[0000833444-15-000062:note_history:29]
The IRS asserted in the Notices of Deficiency that substantially all of Tyco's intercompany debt originated during the 1997 - 2000 period should not be treated as debt for U.S. federal income tax purposes, and has disallowed interest and related deductions recognized on U.S. income tax returns totaling approximately $2.9 billion. Tyco strongly disagrees with the IRS position and has filed petitions with the U.S. Tax Court contesting the IRS proposed adjustments. A trial date has been set for October 2016. Tyco believes that it has meritorious defenses for its tax filings, that the IRS positions with regard to these matters are inconsistent with the applicable tax laws and existing Treasury regulations, and that the previously reported taxes for the years in question are appropriate.

- removed (2016-01-29):
[0000833444-15-000062:note_history:30]
No payments with respect to these matters would be required until the dispute is definitively resolved, which, based on the experience of other companies, could take several years. Tyco believes that its income tax reserves and the liabilities recorded in the Consolidated Balance Sheet for the tax sharing agreements continue to be appropriate. However, the ultimate resolution of these matters, and the impact of that resolution, are uncertain and could have a material impact on Tyco's financial condition, results of operations and cash flows. In particular, if the IRS is successful in asserting its claim, it would have an adverse impact on interest deductions related to the same intercompany debt in subsequent time periods, totaling approximately $6.6 billion, which is expected to be disallowed by the IRS.

- removed (2016-01-29):
[0000833444-15-000062:note_history:31]
See Note 6 for additional information related to income tax matters.

- removed (2016-01-29):
[0000833444-15-000062:note_history:32]
During the first quarter of fiscal 2015, the Company received and responded to inquiries from the U.S. Department of the Navy regarding the formulation of certain aqueous film forming foam ("AFFF") concentrates. The Company investigated such matters and ceased selling certain AFFF and other foam products pending the outcome of its investigation.  During the course of the investigation, three AFFF products were removed from the Navy’s Qualified Products List ("QPL"); one AFFF product remains on the QPL. The Company has shared the results of its investigation with appropriate governmental authorities and is also communicating with the government regarding the re-qualification of these products.  The government has confirmed that it considers the Company to be “presently responsible,” and that no suspension or debarment is warranted.  At this time, we cannot predict the outcome of these inquiries and whether this will result in further action by the Navy or other governmental authorities, but it is possible that the Company could be required to pay material fines, consent to injunctions on future conduct, or suffer other criminal or civil penalties or adverse impacts, including being subject to lawsuits brought by private litigants.


## tyc:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesAndNewAccountingPronouncementsTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2016-01-29):
[0000833444-16-000120:note_history:33]
References to 2016 and 2015 are to Tyco's fiscal quarters ending December 25, 2015 and December 26, 2014, respectively, unless otherwise indicated.  The Company has a 52- or 53-week fiscal year that ends on the last Friday in September.  Fiscal 2016 is a 53-week year as compared with fiscal 2015, which was 52 weeks, with the additional week occurring in the fourth quarter of fiscal 2016.  The Company's results for the three months ended December 25, 2015 and December 26, 2014 both consisted of 13 weeks.

- added (2016-01-29):
[0000833444-16-000120:note_history:34]
The Company operates and reports financial and operating information in the following three segments: North America Integrated Solutions & Services ("NA Integrated Solutions & Services"), Rest of World Integrated Solutions & Services ("ROW Integrated Solutions & Services") and Global Products. The Company also provides general corporate services to its segments which is reported as a fourth, non-operating segment, Corporate and Other.

- added (2016-01-29):
[0000833444-16-000120:note_history:35]
Change of Jurisdiction— On May 30, 2014, Tyco entered into a Merger Agreement ("Merger Agreement") with Tyco International plc, a newly-formed Irish public limited company and a wholly-owned subsidiary of Tyco ("Tyco Ireland").  Under the Merger Agreement, Tyco merged with and into Tyco Ireland, with Tyco Ireland being the surviving company. This resulted in Tyco Ireland becoming Tyco's publicly-traded parent company and changed the jurisdiction of organization of Tyco from Switzerland to Ireland. Tyco's shareholders received one ordinary share of Tyco Ireland for each ordinary share of Tyco held immediately prior to the re-domicile to Ireland. The re-domicile to Ireland became effective on November 17, 2014.

- added (2016-01-29):
[0000833444-16-000120:note_history:36]
Reclassifications— Certain prior period amounts have been reclassified to conform with the current period presentation.

- added (2016-01-29):
[0000833444-16-000120:note_history:37]
Effective for the first quarter of fiscal 2016, the Company has elected to present operating income by segment, as well as Corporate and Other, excluding restructuring and repositioning charges, net.  Restructuring and repositioning charges, net, are shown in aggregate. This measure of segment operating income (loss) is consistent with how management reviews the businesses, makes investing and resource decisions and assesses operating performance. See Note 14.

- added (2016-01-29):
[0000833444-16-000120:note_history:38]
During the first quarter of fiscal 2016, the Company approved a plan to divest its Australian fire protection business, included in the ROW Integrated Solutions & Services segment. The assets and liabilities related to this business were classified as held for sale for all periods presented.  Its results of operations are included in continuing operations, as the criteria to be presented as a discontinued operation were not satisfied. The sale of the business was completed in the second quarter of fiscal 2016.

- added (2016-01-29):
[0000833444-16-000120:note_history:39]
During the second quarter of fiscal 2015, the Company approved a plan to sell a business in its ROW Integrated Solutions & Services segment which the Company expects to complete during the second quarter of fiscal 2016. The assets and liabilities of this business are classified as held for sale, and its results of operations are presented as discontinued operations for all periods presented. See Note 2.

- added (2016-01-29):
[0000833444-16-000120:note_history:40]
Recently Adopted Accounting Pronouncements - In April 2014, the Financial Accounting Standards Board ("FASB") issued authoritative guidance to change the criteria for reporting discontinued operations. Under the new guidance, only disposals representing a strategic shift that has or will have a major effect on the Company's operations and financial results should be reported as discontinued operations, with expanded disclosures. The guidance became effective for Tyco in the first quarter of fiscal 2016. The Company considers both qualitative and quantitative factors when assessing whether a disposed business represents a strategic shift that will have a major effect on the Company's operations and financial results. The Company considers the level (e.g. individual business or product line, reporting unit or reportable segment) and geographic impact (e.g. country, region, worldwide) of the disposal group. In addition, the Company considers the significance of the disposed business on certain financial measures when assessing whether or not such disposal has a major effect on the Company's operations and financial results. The adoption of this guidance did not have a material impact on the Company's financial position, results of operations or cash flows. During the first quarter of fiscal 2016, the planned divestiture of the Company's Australian fire protection business did not meet the criteria set forth in the new guidance and therefore was not classified as a discontinued operation.  See Note 2.

- changed (2016-01-29):
[0000833444-16-000120:note_history:41]
Recently Issued Accounting Pronouncements - In May 2014, the FASB issued authoritative guidance for revenue from contracts with customers, which provides a single comprehensive revenue recognition model to apply in determining how and when to recognize revenue. The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. When applying the new revenue model to contracts with customers the guidance requires five steps to be applied, which include: 1) identify the contract(s) with a customer, 2) identify the performance obligations in the contract, 3) determine the transaction price, 4) allocate the transaction price to the performance obligations in the contract and 5) recognize revenue when (or as) the entity satisfies a performance obligation. The guidance also requires quantitative and qualitative disclosures that are more comprehensive than existing standards. The disclosures are intended to enable financial statement users to understand the nature, timing and uncertainty of revenue and the related cash flow. The new standard allows for both retrospective and prospective methods of adoption. In August 2015, the FASB issued authoritative guidance to defer the effective date of this guidance, which for Tyco will be the first quarter of fiscal 2019, with early adoption permitted beginning the first quarter of fiscal 2018.  The Company is in the process of determining the adoption method and assessing the impact the guidance is expected to have upon adoption.
  (was, 2015-07-31, similarity 0.7564):
[0000833444-15-000062:note_history:41]
In May 2014, the FASB issued authoritative guidance for revenue from contracts with customers, which provides a single comprehensive revenue recognition model to apply in determining how and when to recognize revenue. The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. When applying the new revenue model to contracts with customers the guidance requires five steps to be applied, which include: 1) identify the contract(s) with a customer, 2) identify the performance obligations in the contract, 3) determine the transaction price, 4) allocate the transaction price to the performance obligations in the contract and 5) recognize revenue when (or as) the entity satisfies a performance obligation. The guidance also requires both quantitative and qualitative disclosures, which are more comprehensive than existing revenue standards. The disclosures are intended to enable financial statement users to understand the nature, timing and uncertainty of revenue and the related cash flow. In July 2015, the FASB issued a deferral of the effective date of this guidance, which for Tyco will be the first quarter of fiscal 2019, with early adoption permitted beginning the first quarter of fiscal 2018.  The Company is currently assessing the impact the guidance will have upon adoption.

- changed (2016-01-29):
[0000833444-16-000120:note_history:42]
In May 2015, the FASB issued authoritative guidance that is intended to improve the existing disclosure requirements for short-duration contracts for insurance entities that issue such contracts.  The guidance requires additional information to be disclosed about the liability for unpaid claims and claim adjustment expenses to increase the transparency of significant estimates made in measuring those liabilities.  This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted.  The Company is currently assessing the impact, if any, the guidance may have upon adoption.
  (was, 2015-07-31, similarity 0.9868):
[0000833444-15-000062:note_history:42]
In May 2015, the FASB issued authoritative guidance which is intended to improve the existing disclosure requirements for short-duration contracts for insurance entities that issue such contracts.  The guidance requires additional information to be disclosed about the liability for unpaid claims and claim adjustment expenses to increase the transparency of significant estimates made in measuring those liabilities.  This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted.  The Company is currently assessing the impact, if any, the guidance will have upon adoption.

- added (2016-01-29):
[0000833444-16-000120:note_history:43]
In July 2015, the FASB issued authoritative guidance intended to simplify the existing guidance under which an entity must measure inventory at the lower of cost or market. Under the new guidance, inventory is “measured at the lower of cost and net realizable value,” and does not apply to inventory that is measured using last-in, first-out or the retail method. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted on a prospective basis. The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- added (2016-01-29):
[0000833444-16-000120:note_history:44]
In September 2015, the FASB issued authoritative guidance intended to reduce the cost and complexity of financial reporting when recognizing adjustments to provisional amounts in connection with a business combination. This guidance eliminates the requirement to restate prior period financial statements, but requires entities to present separately on the face of the income statement, or disclose in the notes, the portion of the amount recorded in current-period earnings by line item that would have been recorded in previous reporting periods if the adjustment to the provisional amounts had been recognized as of the acquisition date. This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted on a prospective basis. The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- added (2016-01-29):
[0000833444-16-000120:note_history:45]
In November 2015, the FASB issued authoritative guidance intended to simplify the presentation of deferred income taxes.  Under the new guidance, deferred tax liabilities and deferred tax assets are to be classified as noncurrent in a classified statement of financial position.  The current requirement that deferred tax liabilities and assets of a tax-paying component of an entity be offset and presented as a single amount is not affected by the amendments in this update. This guidance is effective for Tyco in the first quarter of fiscal 2018, with early adoption permitted on a prospective or retrospective basis.  The Company is currently assessing the impact, if any, the guidance may have upon adoption and the timing of adopting this new guidance.

- added (2016-01-29):
[0000833444-16-000120:note_history:46]
In January 2016, the FASB issued authoritative guidance addressing the recognition, measurement, presentation and disclosure of financial assets and liabilities. The guidance primarily affects the accounting for equity investments, financial liabilities under the fair value option and the presentation and disclosure requirements for financial instruments. In addition, the guidance clarifies the valuation allowance assessment when recognizing deferred tax assets resulting from unrealized losses on available-for-sale debt securities. This guidance is effective for Tyco in the first quarter of fiscal 2019, and early adoption is not permitted, with certain exceptions.  The amendments are required to be applied by means of a cumulative-effect adjustment on the balance sheet as of the beginning of the fiscal year of adoption.  The Company is currently assessing the impact, if any, the guidance may have upon adoption.

- removed (2016-01-29):
[0000833444-15-000062:note_history:47]
References to 2015 and 2014 are to Tyco's fiscal quarters ending June 26, 2015 and June 27, 2014, respectively, unless otherwise indicated.  The Company has a 52- or 53-week fiscal year that ends on the last Friday in September.  Fiscal years 2015 and 2014 are both 52-week years.

- removed (2016-01-29):
[0000833444-15-000062:note_history:48]
Change of Jurisdiction - On November 17, 2014, Tyco International Ltd., an entity organized under the laws of Switzerland ("Tyco Switzerland"), completed its change of jurisdiction of incorporation from Switzerland to Ireland by merging with its subsidiary, Tyco International plc ("Tyco Ireland"), a public limited company incorporated under the laws of Ireland (the "Merger"). As a result of the Merger, Tyco Ireland is the successor issuer to Tyco Switzerland, has succeeded to the attributes of Tyco Switzerland as the registrant under SEC regulations, and has assumed all pre-Merger obligations of Tyco Switzerland.

- removed (2016-01-29):
[0000833444-15-000062:note_history:49]
Reclassifications - Certain prior period amounts have been reclassified to conform with current period presentation. During the quarter ended June 26, 2015, the Company sold three businesses in the Rest of World ("ROW") Installation & Services segment.  The assets and liabilities related to these businesses were classified as held for sale of as September 26, 2014, and the results of operations of two of these businesses are included in discontinued operations for all periods presented, as the criteria to be presented as a discontinued operation were not satisfied for the third business.  The Company expects to complete the sale of another of its ROW Installation & Services businesses during the first half of fiscal 2016.  The assets and liabilities of this business are classified as held for sale, and its results of operations are presented as discontinued operations for all periods presented. See Note 3.

- removed (2016-01-29):
[0000833444-15-000062:note_history:50]
Recently Adopted Accounting Pronouncements - In March 2013, the Financial Accounting Standards Board ("FASB") issued authoritative guidance to resolve diversity in practice on the accounting for the cumulative translation adjustment ("CTA") when a parent either sells a part or all of its investment in a foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets within a foreign entity. The guidance requires that the parent release any CTA into net income when the parent ceases to have a controlling financial interest in a subsidiary or group of assets within a foreign entity which results in a substantially complete liquidation of the foreign entity; when the sale of an investment in a foreign entity results in the loss of a controlling financial interest; or where an acquirer obtains control of an acquiree in which it had an equity interest immediately before the acquisition date. The guidance does not change the requirement to release a pro rata portion of the CTA into net income upon a partial sale of an equity method investment that is a foreign entity. The guidance became effective for Tyco in the first quarter of fiscal 2015. The adoption of this guidance, which was applied on a prospective basis, did not have a material impact on the Company's financial position, results of operations or cash flows.

- removed (2016-01-29):
[0000833444-15-000062:note_history:51]
In July 2013, the FASB issued authoritative guidance for the presentation of an unrecognized tax benefit when a net operating loss (“NOL”) carryforward, a similar tax loss, or a tax credit carryforward exists. The guidance requires an entity to present an unrecognized tax benefit, or a portion of an unrecognized tax benefit, in the financial statements as a reduction to a deferred tax asset for a NOL carryforward, a similar tax loss, or a tax credit carryforward. If the NOL carryforward, a similar tax loss, or a tax credit carryforward is not available at the reporting date under the tax law of the jurisdiction or the tax law of the jurisdiction does not require the entity to use, and the entity does not intend to use, the deferred tax asset for such purpose, the unrecognized tax benefit will be presented in the financial statements as a liability and will not be combined with deferred tax assets.  This guidance does not require any additional recurring disclosures and became effective for Tyco during the first fiscal quarter of fiscal 2015.  The adoption of this guidance, which was applied on a prospective basis, did not have a material impact on the Company's financial position, results of operations or cash flows.

- removed (2016-01-29):
[0000833444-15-000062:note_history:52]
Recently Issued Accounting Pronouncements - In April 2014, the FASB issued authoritative guidance to change the criteria for reporting discontinued operations.  Under the new guidance, only disposals representing a strategic shift in a company's operations and financial results should be reported as discontinued operations, with expanded disclosures. In addition, disclosure of the pre-tax income attributable to a disposal of a significant part of an organization that does not qualify as a discontinued operation is required.  This guidance is effective for Tyco in the first quarter of fiscal 2016, with early adoption permitted only for disposals that have not been reported in financial statements previously issued or available for issuance.  The Company is currently assessing the impact, if any, the guidance will have upon adoption.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-01-29):
[0000833444-16-000120:note_history:53]
The carrying value of the Company's debt as of December 25, 2015 and September 25, 2015 is as follows ($ in millions):
  (was, 2015-07-31, similarity 0.7386):
[0000833444-15-000062:note_history:53]
Debt as of June 26, 2015 and September 26, 2014 is as follows ($ in millions):

- added (2016-01-29):
[0000833444-16-000120:note_history:54]
|  | As of |
|  | December 25, 2015 |  | September 25, 2015 |
| Commercial paper | $ | 151 |  |  | $ | — |  |
| 3.375% public notes due 2015 | — |  |  | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 7.0% public notes due 2019 | — |  |  | 245 |  |
| 6.875% public notes due 2021 | — |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% Euro-denominated public notes due 2025 | 545 |  |  | 558 |  |
| 3.9% public notes due 2026 | 745 |  |  | 745 |  |
| 5.125% public notes due 2045 | 746 |  |  | 746 |  |
| Other | 2 |  |  | 20 |  |
| Total debt | 2,298 |  |  | 3,146 |  |
| Less current portion (1)(2) | 152 |  |  | 987 |  |
| Long-term debt | $ | 2,146 |  |  | $ | 2,159 |  |

- added (2016-01-29):
[0000833444-16-000120:note_history:55]
(1)  The current portion of debt as of December 25, 2015 is comprised of $151 million of commercial paper and $1 million of Other debt.

- added (2016-01-29):
[0000833444-16-000120:note_history:56]
(2) The current portion of debt as of September 25, 2015 is comprised of $258 million notes due 2015, $245 million notes due 2019, $465 million notes due 2021 and $19 million of Other debt.

- added (2016-01-29):
[0000833444-16-000120:note_history:57]
The carrying amount of Tyco's debt subject to the fair value disclosure requirements as of December 25, 2015 and September 25, 2015 was $2,296 million and $3,126 million, respectively. The Company utilizes various valuation methodologies to determine the fair value of its debt, which is primarily dependent on the type of market in which the Company's debt is traded. When available, the Company uses quoted market prices to determine the fair value of its debt that is traded in active markets.  As of December 25, 2015 and September 25, 2015, the fair value of the Company's debt which was actively traded was $2,318 million and $3,291 million, respectively.  As of December 25, 2015 and September 25, 2015, the Company's debt that was subject to the fair value disclosure requirements was all actively traded and is classified as Level 1 in the fair value hierarchy. Additionally, the Company believes the carrying amount of its commercial paper of $151 million as of December 25, 2015 approximates fair value based on the short-term nature of such debt.

- changed (2016-01-29):
[0000833444-16-000120:note_history:58]
Fiscal 2016 Debt Repayment
  (was, 2015-07-31, similarity 0.6087):
[0000833444-15-000062:note_history:58]
Debt Issuance/Repayment

- added (2016-01-29):
[0000833444-16-000120:note_history:59]
On September 14, 2015, the Company and the Company's wholly-owned subsidiary, Tyco International Finance S.A. ("TIFSA") announced the redemption of all of the outstanding $242 million aggregate principal amount of 7.0% notes due 2019 and $462 million aggregate principal amount of 6.875% notes due 2021. On October 14, 2015, TIFSA paid cash of $876 million to complete the redemption, resulting in a loss on extinguishment of $168 million which was recorded in Other expense, net within the Consolidated Statements of Operations during the first quarter of fiscal 2016. The charge is comprised of the make-whole premium of $172 million and the write-off of unamortized debt issuance costs of $1 million, partially offset by the write-off of the unamortized premium of $5 million.

- added (2016-01-29):
[0000833444-16-000120:note_history:60]
On October 15, 2015, the Company repaid $258 million aggregate principal amount of 3.375% notes which matured on such date.

- added (2016-01-29):
[0000833444-16-000120:note_history:61]
From time to time, TIFSA may issue commercial paper for general corporate purposes. The maximum aggregate amount of unsecured commercial paper notes available to be issued, on a private placement basis, under the commercial paper program is $1.5 billion as of December 25, 2015.  As of December 25, 2015 and September 25, 2015, TIFSA had $151 million and nil of commercial paper outstanding, respectively.

- added (2016-01-29):
[0000833444-16-000120:note_history:62]
On August 7, 2015, TIFSA entered into an Amended and Restated Five-Year Senior Unsecured Credit Agreement in the aggregate amount of $1.5 billion (the “2015 Credit Agreement”). The 2015 Credit Agreement amends and restates TIFSA's existing Five-Year Senior Unsecured Credit Agreement, dated June 22, 2012 (the “2012 Credit Agreement”), which provided for revolving credit commitments in the aggregate amount of $1.0 billion, and was scheduled to expire on June 22, 2017.

- added (2016-01-29):
[0000833444-16-000120:note_history:63]
As a result of entering into the 2015 Credit Agreement, the Company's committed revolving credit facility totaled $1.5 billion as of December 25, 2015. This revolving credit facility may be used for working capital, capital expenditures and general corporate purposes. As of December 25, 2015 and September 25, 2015, there were no amounts drawn under the Company's revolving credit facility. Interest under the revolving credit facility is variable and is calculated by reference to LIBOR or an alternate base rate.

- added (2016-01-29):
[0000833444-16-000120:note_history:64]
TIFSA's revolving credit facility contains customary terms and conditions, and financial covenants that limit the ratio of the Company's debt to earnings before interest, taxes, depreciation, and amortization and that limit our ability to incur subsidiary debt or grant liens on its property. The indentures contain customary covenants including limits on negative pledges, subsidiary debt and sale/leaseback transactions. None of these covenants are considered restrictive to the Company's business.

- removed (2016-01-29):
[0000833444-15-000062:note_history:65]
|  | As of |
|  | June 26, 2015 |  | September 26, 2014 |
| 3.375% public notes due 2015 (1) | $ | 258 |  |  | $ | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 8.5% public notes due 2019 | 364 |  |  | 364 |  |
| 7.0% public notes due 2019 | 245 |  |  | 245 |  |
| 6.875% public notes due 2021 | 465 |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% public notes due 2025 | 559 |  |  | — |  |
| Other (2) | 21 |  |  | 22 |  |
| Total debt | 2,021 |  |  | 1,463 |  |
| Less current portion | 277 |  |  | 20 |  |
| Long-term debt | $ | 1,744 |  |  | $ | 1,443 |  |

- removed (2016-01-29):
[0000833444-15-000062:note_history:66]
(1) $258 million of 3.375% public notes due October 2015 is included in the current portion of debt as of June 26, 2015.

- removed (2016-01-29):
[0000833444-15-000062:note_history:67]
(2)  $19 million and $20 million, respectively, of the amount shown as other is included in the current portion of the Company's total debt as of June 26, 2015 and September 26, 2014.

- removed (2016-01-29):
[0000833444-15-000062:note_history:68]
The carrying amount of Tyco's debt subject to the fair value disclosure requirements as of June 26, 2015 and September 26, 2014 was $2,000 million and $1,441 million, respectively.  The Company has determined the fair value of such debt to be $2,177 million and $1,670 million as of June 26, 2015 and September 26, 2014, respectively.  The Company utilizes various valuation methodologies to determine the fair value of its debt, which is primarily dependent on the type of market in which the Company's debt is traded. When available, the Company uses quoted market prices to determine the fair value of its debt that is traded in active markets.  As of June 26, 2015 and September 26, 2014, $2,000 million and $1,441 million, respectively, of the Company's debt, which is actively traded and subject to the fair value disclosure requirements, is classified as Level 1 in the fair value hierarchy.

- removed (2016-01-29):
[0000833444-15-000062:note_history:69]
From time to time, the Company's wholly-owned subsidiary, Tyco International Finance S.A. ("TIFSA") may issue commercial paper for general corporate purposes. The maximum aggregate amount of unsecured commercial paper notes available to be issued on a private placement basis under the commercial paper program is $1 billion as of June 26, 2015.  As of June 26, 2015 and September 26, 2014, TIFSA had no commercial paper outstanding.

- removed (2016-01-29):
[0000833444-15-000062:note_history:70]
The Company's committed revolving credit facility totaled $1 billion as of June 26, 2015. This revolving credit facility may be used for working capital, capital expenditures and general corporate purposes. As of June 26, 2015 and September 26, 2014, there were no amounts drawn under the Company's revolving credit facility. Interest under the revolving credit facility is variable and is calculated by reference to LIBOR or an alternate base rate.

- removed (2016-01-29):
[0000833444-15-000062:note_history:71]
On February 25, 2015, TIFSA issued €500 million aggregate principal amount of 1.375% Notes due February 25, 2025 (the "Notes"), which are fully and unconditionally guaranteed by each of the Company and Tyco Fire & Security Finance S.C.A.  TIFSA received total net proceeds of approximately $563 million after deducting debt issuance costs of approximately $5 million and a debt discount of approximately $1 million.  The net proceeds were made available for general corporate purposes.  The Notes are TIFSA’s senior unsecured obligations and rank equally in right of payment with all of its existing and future senior debt, and senior to any subordinated indebtedness that TIFSA may incur.  The Notes were designated as a net investment hedge.  See Note 10.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-01-29):
[0000833444-16-000120:note_history:72]
The carrying value of the Company's debt as of December 25, 2015 and September 25, 2015 is as follows ($ in millions):
  (was, 2015-07-31, similarity 0.7386):
[0000833444-15-000062:note_history:72]
Debt as of June 26, 2015 and September 26, 2014 is as follows ($ in millions):

- added (2016-01-29):
[0000833444-16-000120:note_history:73]
|  | As of |
|  | December 25, 2015 |  | September 25, 2015 |
| Commercial paper | $ | 151 |  |  | $ | — |  |
| 3.375% public notes due 2015 | — |  |  | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 7.0% public notes due 2019 | — |  |  | 245 |  |
| 6.875% public notes due 2021 | — |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% Euro-denominated public notes due 2025 | 545 |  |  | 558 |  |
| 3.9% public notes due 2026 | 745 |  |  | 745 |  |
| 5.125% public notes due 2045 | 746 |  |  | 746 |  |
| Other | 2 |  |  | 20 |  |
| Total debt | 2,298 |  |  | 3,146 |  |
| Less current portion (1)(2) | 152 |  |  | 987 |  |
| Long-term debt | $ | 2,146 |  |  | $ | 2,159 |  |

- added (2016-01-29):
[0000833444-16-000120:note_history:74]
(1)  The current portion of debt as of December 25, 2015 is comprised of $151 million of commercial paper and $1 million of Other debt.

- added (2016-01-29):
[0000833444-16-000120:note_history:75]
(2) The current portion of debt as of September 25, 2015 is comprised of $258 million notes due 2015, $245 million notes due 2019, $465 million notes due 2021 and $19 million of Other debt.

- removed (2016-01-29):
[0000833444-15-000062:note_history:76]
|  | As of |
|  | June 26, 2015 |  | September 26, 2014 |
| 3.375% public notes due 2015 (1) | $ | 258 |  |  | $ | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 8.5% public notes due 2019 | 364 |  |  | 364 |  |
| 7.0% public notes due 2019 | 245 |  |  | 245 |  |
| 6.875% public notes due 2021 | 465 |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% public notes due 2025 | 559 |  |  | — |  |
| Other (2) | 21 |  |  | 22 |  |
| Total debt | 2,021 |  |  | 1,463 |  |
| Less current portion | 277 |  |  | 20 |  |
| Long-term debt | $ | 1,744 |  |  | $ | 1,443 |  |

- removed (2016-01-29):
[0000833444-15-000062:note_history:77]
(1) $258 million of 3.375% public notes due October 2015 is included in the current portion of debt as of June 26, 2015.

- removed (2016-01-29):
[0000833444-15-000062:note_history:78]
(2)  $19 million and $20 million, respectively, of the amount shown as other is included in the current portion of the Company's total debt as of June 26, 2015 and September 26, 2014.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2016-01-29):
[0000833444-16-000120:note_history:79]
On January 24, 2016, Tyco entered into an Agreement and Plan of Merger (the “Merger Agreement”) with Johnson Controls, Inc., a Wisconsin corporation (“JCI”), and certain other parties named therein, including Jagara Merger Sub LLC, a Wisconsin limited liability company and indirect wholly owned subsidiary of Tyco (“Merger Sub”). Pursuant to the Merger Agreement and subject to the terms and conditions set forth therein, Merger Sub will merge with and into JCI (the “Merger”), with JCI surviving the Merger as an indirect wholly owned subsidiary of Tyco. At the effective time of the Merger, Tyco will change its name to “Johnson Controls plc” and will trade under the ticker symbol “JCI.” Following such time, Tyco is referred to below as the “Combined Company.”

- added (2016-01-29):
[0000833444-16-000120:note_history:80]
As a result of the Merger, each outstanding share of JCI common stock (the “JCI Shares”), other than shares held by JCI, its subsidiaries, Tyco or Merger Sub, will be converted into the right to receive (subject to proration as described below), at the holder’s election, either: (i) one (1) (the “Exchange Ratio”) ordinary share of the Combined Company (the “Share Consideration”); or (ii) an amount in cash equal to $34.88 (the “Cash Consideration”). Elections will be prorated so that JCI shareholders will receive in the aggregate approximately $3.864 billion of cash in the Merger (the “Aggregate Cash Consideration”). Holders that do not make an election will be treated as having elected to receive the Share Consideration. The Exchange Ratio takes into account the effects of a Tyco share consolidation contemplated by the Merger Agreement whereby, immediately prior to the Merger, every issued and unissued ordinary share of Tyco (each, a “Tyco Share”) will be consolidated into 0.955 of a share of Tyco.

- added (2016-01-29):
[0000833444-16-000120:note_history:81]
The completion of the Merger is subject to certain closing conditions, including, among others, (i) the approval and adoption of the Merger Agreement by holders of two-thirds of the JCI Shares entitled to vote on such matter, (ii) the approval by the Tyco shareholders, at a special meeting of the Tyco shareholders (the “Tyco Special Meeting”) of (A) the issuance of Tyco shares in connection with the Merger, (B) the Tyco share consolidation and (C) the increase in Tyco’s authorized share capital, in each case, by a majority of the votes cast on these matters at the Tyco Special Meeting, and of certain amendments to Tyco’s articles of association, including a change of its name to “Johnson Controls plc,” by at least 75% of the votes cast on these matters at the Tyco Special Meeting (clause (ii), collectively, the “Tyco Shareholder Approvals”), (iii) the expiration or termination of any waiting period applicable to the Merger under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, the consent of, or filing with, certain specified antitrust authorities, and certain other customary regulatory approvals, and (iv) Tyco’s obtaining the financing required to close the Merger on the terms set forth in the Merger Agreement.

- added (2016-01-29):
[0000833444-16-000120:note_history:82]
The Merger Agreement contains specified termination rights, including, among others, the right of either party to terminate the Merger Agreement (i) if the requisite shareholder approvals have not been obtained, (ii) if the board of directors of the other party effects a change of recommendation, (iii) if the closing has not occurred by October 24, 2016, subject to extension to January 24, 2017 in certain circumstances, (iv) in response to certain intervening events (subject to the limitations set forth in the Merger Agreement) or (v) if there is a material breach by the other party of any of its representations, warranties or covenants, subject to certain conditions.

- added (2016-01-29):
[0000833444-16-000120:note_history:83]
Tyco expects to finance the cash consideration for the Merger and fees and expenses related to the transactions with up to $4 billion of debt financing. Citigroup Global Markets, Inc. (“CGMI”) is providing committed bridge financing in connection with the Merger.

- added (2016-01-29):
[0000833444-16-000120:note_history:84]
In connection with the contemplated debt financing, TIFSA entered into a commitment letter (the “Term Loan Commitment Letter”) with CGMI, dated as of January 24, 2016, pursuant to which CGMI has, subject to the terms and conditions set forth in the Term Loan Commitment Letter, (i) agreed to use commercially reasonable efforts to arrange a syndicate of lenders that will participate in a three-and-a-half year senior unsecured term loan facility (the “Term Facility,” and the provision of such funds as set forth in the Term Loan Commitment Letter, the “Term Financing”) in an aggregate principal amount of up to $4 billion and (ii) committed to provide up to $400 million of the Term Facility. The Term Facility is available to finance all or a portion of the cash consideration for the Merger and to pay fees and expenses related to the transactions. The borrower under the Term Facility will be Tyco International Holding S.a.r.l. (the “Borrower”), a Luxembourg company and a direct wholly-owned subsidiary of TIFSA.

- added (2016-01-29):
[0000833444-16-000120:note_history:85]
In connection with the contemplated debt financing, TIFSA also entered into a commitment letter (the “Bridge Commitment Letter”) with CGMI, dated as of January 24, 2016, pursuant to which CGMI has committed to provide to the Borrower, subject to the terms and conditions set forth in the Bridge Commitment Letter, the full amount of a 364-day $4 billion senior unsecured bridge loan facility (the “Bridge Facility,” and the provision of such funds as set forth in the Bridge Commitment Letter, the “Bridge Financing”). The Bridge Facility is available to finance all or a portion of the cash consideration for the Merger and to pay fees and expenses related to the transactions to the extent that the Term Facility is not available to finance such amounts.

- added (2016-01-29):
[0000833444-16-000120:note_history:86]
The commitments with respect to both the Term Financing and the Bridge Financing are subject to certain customary closing conditions, including, in the case of the Term Financing, the receipt of commitments from other lenders for the remainder of the Term Facility not committed by CGMI, and in the case of both the Term Financing and the Bridge Financing, the consummation of the Merger in accordance with the terms of the Merger Agreement. Both the Term Facility and the Bridge Facility will contain certain representations and warranties, certain affirmative covenants, certain negative covenants, a financial covenant, and events of default, in each case applicable to the Borrower and, where appropriate, its subsidiaries, that are customarily required for similar financings. In addition, the Bridge Financing will be subject to certain customary mandatory commitment reduction and prepayment events triggered by receipt of proceeds of debt and equity issuances and material asset sales, subject to customary exceptions, and the commitments for the Bridge Financing will be automatically reduced by the amount of commitments for the Term Facility, once the Borrower enters into definitive agreements for such term financing.
