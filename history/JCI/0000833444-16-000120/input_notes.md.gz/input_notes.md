# JCI notes — 0000833444-16-000120


## tyc:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureAndSignificantAccountingPoliciesAndNewAccountingPronouncementsTextBlock

[0000833444-16-000120:notes:1]
Basis of Presentation and Summary of Significant Accounting Policies

[0000833444-16-000120:notes:2]
Basis of Presentation—The Consolidated Financial Statements included herein are unaudited, but in the opinion of management, such financial statements include all adjustments, consisting of normal recurring adjustments, necessary to summarize fairly the Company's financial position, results of operations and cash flows for the interim period. The unaudited Consolidated Financial Statements include the consolidated results of Tyco International plc, a corporation organized under the laws of Ireland, and its subsidiaries (Tyco and all its subsidiaries, hereinafter collectively referred to as the "Company" or "Tyco"). The unaudited Consolidated Financial Statements have been prepared in United States dollars ("USD") and in accordance with the instructions to Form 10-Q under the Securities and Exchange Act of 1934, as amended. The results reported in these unaudited Consolidated Financial Statements should not be taken as indicative of results that may be expected for the entire year.  These financial statements should be read in conjunction with the Consolidated Financial Statements and accompanying notes contained in the Company's Annual Report on Form 10-K for the fiscal year ended September 25, 2015 (the "2015 Form 10-K").

[0000833444-16-000120:notes:3]
References to 2016 and 2015 are to Tyco's fiscal quarters ending December 25, 2015 and December 26, 2014, respectively, unless otherwise indicated.  The Company has a 52- or 53-week fiscal year that ends on the last Friday in September.  Fiscal 2016 is a 53-week year as compared with fiscal 2015, which was 52 weeks, with the additional week occurring in the fourth quarter of fiscal 2016.  The Company's results for the three months ended December 25, 2015 and December 26, 2014 both consisted of 13 weeks.

[0000833444-16-000120:notes:4]
The Company operates and reports financial and operating information in the following three segments: North America Integrated Solutions & Services ("NA Integrated Solutions & Services"), Rest of World Integrated Solutions & Services ("ROW Integrated Solutions & Services") and Global Products. The Company also provides general corporate services to its segments which is reported as a fourth, non-operating segment, Corporate and Other.

[0000833444-16-000120:notes:5]
Change of Jurisdiction— On May 30, 2014, Tyco entered into a Merger Agreement ("Merger Agreement") with Tyco International plc, a newly-formed Irish public limited company and a wholly-owned subsidiary of Tyco ("Tyco Ireland").  Under the Merger Agreement, Tyco merged with and into Tyco Ireland, with Tyco Ireland being the surviving company. This resulted in Tyco Ireland becoming Tyco's publicly-traded parent company and changed the jurisdiction of organization of Tyco from Switzerland to Ireland. Tyco's shareholders received one ordinary share of Tyco Ireland for each ordinary share of Tyco held immediately prior to the re-domicile to Ireland. The re-domicile to Ireland became effective on November 17, 2014.

[0000833444-16-000120:notes:6]
Reclassifications— Certain prior period amounts have been reclassified to conform with the current period presentation.

[0000833444-16-000120:notes:7]
Effective for the first quarter of fiscal 2016, the Company has elected to present operating income by segment, as well as Corporate and Other, excluding restructuring and repositioning charges, net.  Restructuring and repositioning charges, net, are shown in aggregate. This measure of segment operating income (loss) is consistent with how management reviews the businesses, makes investing and resource decisions and assesses operating performance. See Note 14.

[0000833444-16-000120:notes:8]
During the first quarter of fiscal 2016, the Company approved a plan to divest its Australian fire protection business, included in the ROW Integrated Solutions & Services segment. The assets and liabilities related to this business were classified as held for sale for all periods presented.  Its results of operations are included in continuing operations, as the criteria to be presented as a discontinued operation were not satisfied. The sale of the business was completed in the second quarter of fiscal 2016.

[0000833444-16-000120:notes:9]
During the second quarter of fiscal 2015, the Company approved a plan to sell a business in its ROW Integrated Solutions & Services segment which the Company expects to complete during the second quarter of fiscal 2016. The assets and liabilities of this business are classified as held for sale, and its results of operations are presented as discontinued operations for all periods presented. See Note 2.

[0000833444-16-000120:notes:10]
Recently Adopted Accounting Pronouncements - In April 2014, the Financial Accounting Standards Board ("FASB") issued authoritative guidance to change the criteria for reporting discontinued operations. Under the new guidance, only disposals representing a strategic shift that has or will have a major effect on the Company's operations and financial results should be reported as discontinued operations, with expanded disclosures. The guidance became effective for Tyco in the first quarter of fiscal 2016. The Company considers both qualitative and quantitative factors when assessing whether a disposed business represents a strategic shift that will have a major effect on the Company's operations and financial results. The Company considers the level (e.g. individual business or product line, reporting unit or reportable segment) and geographic impact (e.g. country, region, worldwide) of the disposal group. In addition, the Company considers the significance of the disposed business on certain financial measures when assessing whether or not such disposal has a major effect on the Company's operations and financial results. The adoption of this guidance did not have a material impact on the Company's financial position, results of operations or cash flows. During the first quarter of fiscal 2016, the planned divestiture of the Company's Australian fire protection business did not meet the criteria set forth in the new guidance and therefore was not classified as a discontinued operation.  See Note 2.

[0000833444-16-000120:notes:11]
Recently Issued Accounting Pronouncements - In May 2014, the FASB issued authoritative guidance for revenue from contracts with customers, which provides a single comprehensive revenue recognition model to apply in determining how and when to recognize revenue. The core principle of the guidance is that an entity should recognize revenue to depict the transfer of promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. When applying the new revenue model to contracts with customers the guidance requires five steps to be applied, which include: 1) identify the contract(s) with a customer, 2) identify the performance obligations in the contract, 3) determine the transaction price, 4) allocate the transaction price to the performance obligations in the contract and 5) recognize revenue when (or as) the entity satisfies a performance obligation. The guidance also requires quantitative and qualitative disclosures that are more comprehensive than existing standards. The disclosures are intended to enable financial statement users to understand the nature, timing and uncertainty of revenue and the related cash flow. The new standard allows for both retrospective and prospective methods of adoption. In August 2015, the FASB issued authoritative guidance to defer the effective date of this guidance, which for Tyco will be the first quarter of fiscal 2019, with early adoption permitted beginning the first quarter of fiscal 2018.  The Company is in the process of determining the adoption method and assessing the impact the guidance is expected to have upon adoption.

[0000833444-16-000120:notes:12]
In May 2015, the FASB issued authoritative guidance that is intended to improve the existing disclosure requirements for short-duration contracts for insurance entities that issue such contracts.  The guidance requires additional information to be disclosed about the liability for unpaid claims and claim adjustment expenses to increase the transparency of significant estimates made in measuring those liabilities.  This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted.  The Company is currently assessing the impact, if any, the guidance may have upon adoption.

[0000833444-16-000120:notes:13]
In July 2015, the FASB issued authoritative guidance intended to simplify the existing guidance under which an entity must measure inventory at the lower of cost or market. Under the new guidance, inventory is “measured at the lower of cost and net realizable value,” and does not apply to inventory that is measured using last-in, first-out or the retail method. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted on a prospective basis. The Company is currently assessing the impact, if any, the guidance may have upon adoption.

[0000833444-16-000120:notes:14]
In September 2015, the FASB issued authoritative guidance intended to reduce the cost and complexity of financial reporting when recognizing adjustments to provisional amounts in connection with a business combination. This guidance eliminates the requirement to restate prior period financial statements, but requires entities to present separately on the face of the income statement, or disclose in the notes, the portion of the amount recorded in current-period earnings by line item that would have been recorded in previous reporting periods if the adjustment to the provisional amounts had been recognized as of the acquisition date. This guidance is effective for Tyco in the first quarter of fiscal 2017, with early adoption permitted on a prospective basis. The Company is currently assessing the impact, if any, the guidance may have upon adoption.

[0000833444-16-000120:notes:15]
In November 2015, the FASB issued authoritative guidance intended to simplify the presentation of deferred income taxes.  Under the new guidance, deferred tax liabilities and deferred tax assets are to be classified as noncurrent in a classified statement of financial position.  The current requirement that deferred tax liabilities and assets of a tax-paying component of an entity be offset and presented as a single amount is not affected by the amendments in this update. This guidance is effective for Tyco in the first quarter of fiscal 2018, with early adoption permitted on a prospective or retrospective basis.  The Company is currently assessing the impact, if any, the guidance may have upon adoption and the timing of adopting this new guidance.

[0000833444-16-000120:notes:16]
In January 2016, the FASB issued authoritative guidance addressing the recognition, measurement, presentation and disclosure of financial assets and liabilities. The guidance primarily affects the accounting for equity investments, financial liabilities under the fair value option and the presentation and disclosure requirements for financial instruments. In addition, the guidance clarifies the valuation allowance assessment when recognizing deferred tax assets resulting from unrealized losses on available-for-sale debt securities. This guidance is effective for Tyco in the first quarter of fiscal 2019, and early adoption is not permitted, with certain exceptions.  The amendments are required to be applied by means of a cumulative-effect adjustment on the balance sheet as of the beginning of the fiscal year of adoption.  The Company is currently assessing the impact, if any, the guidance may have upon adoption.


## tyc:ScheduleOfIntangibleAssetsTextBlock

[0000833444-16-000120:notes:17]
The following table sets forth the gross carrying amount and accumulated amortization of the Company's intangible assets as of December 25, 2015 and September 25, 2015 ($ in millions):

[0000833444-16-000120:notes:18]
|  | As of |
|  | December 25, 2015 |  | September 25, 2015 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Amortizable: |  |  |  |  |  |  |  |
| Contracts and related customer relationships | $ | 1,287 |  |  | $ | 1,002 |  |  | $ | 1,281 |  |  | $ | 991 |  |
| Intellectual property | 836 |  |  | 503 |  |  | 760 |  |  | 496 |  |
| Other | 9 |  |  | 5 |  |  | 8 |  |  | 5 |  |
| Total | $ | 2,132 |  |  | $ | 1,510 |  |  | $ | 2,049 |  |  | $ | 1,492 |  |
| Non-Amortizable: |  |  |  |  |  |  |  |
| Intellectual property | $ | 210 |  |  |  |  |  | $ | 210 |  |  |  |
| Franchise rights | 76 |  |  |  |  |  | 76 |  |  |  |
| In-process research and development | 19 |  |  |  |  | 20 |  |  |  |
| Total | $ | 305 |  |  |  |  |  | $ | 306 |  |  |  |


## tyc:ScheduleOfNetReceivablesAndLiabilitiesRecordedUnderTaxSharingAgreementsTableTextBlock

[0000833444-16-000120:notes:19]
The receivables and liabilities related to the 2012 and 2007 Tax Sharing Agreements as of December 25, 2015 and September 25, 2015, are as follows ($ in millions):

[0000833444-16-000120:notes:20]
|  | 2012 Tax Sharing Agreement |  | 2007 Tax Sharing Agreement |
|  | As of |  | As of |
|  | December 25, 2015 |  | September 25, 2015 |  | December 25, 2015 |  | September 25, 2015 |
| Tax sharing agreement related receivables: |  |  |  |  |  |  |  |
| Other assets | — |  |  | — |  |  | 18 |  |  | 19 |  |
|  | — |  |  | — |  |  | 18 |  |  | 19 |  |
| Tax sharing agreement related liabilities: |  |  |  |  |  |  |  |
| Accrued and other current liabilities | — |  |  | — |  |  | (209 | ) |  | (15 | ) |
| Other liabilities | (46 | ) |  | (46 | ) |  | — |  |  | (194 | ) |
|  | (46 | ) |  | (46 | ) |  | (209 | ) |  | (209 | ) |
| Net liability | $ | (46 | ) |  | $ | (46 | ) |  | $ | (191 | ) |  | $ | (190 | ) |


## tyc:ScheduleOfRestructuringReserveByBalanceSheetLocationTextBlock

[0000833444-16-000120:notes:21]
As of December 25, 2015 and September 25, 2015, restructuring reserves related to all actions were included within the Company's Consolidated Balance Sheets as follows ($ in millions):

[0000833444-16-000120:notes:22]
|  | As of |
|  | December 25, 2015 |  | September 25, 2015 |
| Accrued and other current liabilities | $ | 124 |  |  | $ | 140 |  |
| Other liabilities | 14 |  |  | 15 |  |
| Total | $ | 138 |  |  | $ | 155 |  |


## tyc:ScheduleOfSegmentReportingInformationNetRevenueAndOperatingIncomeLossBySegmentTableTextBlock

[0000833444-16-000120:notes:23]
[same as prior period, unchanged from 0000833444-15-000062:notes:17]

[0000833444-16-000120:notes:24]
|  | For the Quarters Ended |
|  | December 25, 2015 |  | December 26, 2014 |
| Net revenue(1): |  |  |  |
| NA Integrated Solutions & Services | $ | 953 |  |  | $ | 951 |  |
| ROW Integrated Solutions & Services | 812 |  |  | 916 |  |
| Global Products | 611 |  |  | 611 |  |
|  | $ | 2,376 |  |  | $ | 2,478 |  |

[0000833444-16-000120:notes:25]
(1) Net revenue by operating segment excludes intercompany transactions.

[0000833444-16-000120:notes:26]
|  | For the Quarters Ended |
|  | December 25, 2015 |  | December 26, 2014 |
| Operating income: |  |  |  |
| NA Integrated Solutions & Services | $ | 132 |  |  | $ | 129 |  |
| ROW Integrated Solutions & Services | 133 |  |  | 89 |  |
| Global Products | 97 |  |  | 105 |  |
| Segment operating income | 362 |  |  | 323 |  |
| Corporate and Other | (51 | ) |  | (49 | ) |
| Restructuring and repositioning charges, net | (18 | ) |  | (75 | ) |
| Operating income | $ | 293 |  |  | $ | 199 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000833444-16-000120:notes:27]
[same as prior period, unchanged from 0000833444-15-000062:notes:27]

[0000833444-16-000120:notes:28]
During the quarter ended December 25, 2015, cash consideration for acquisitions included in continuing operations was $138 million, which was comprised of $176 million of cash paid, including $5 million to settle pre-existing matters and $6 million for prepaid agency commissions, net of cash acquired of $27 million. This primarily related to an additional investment in the Company's Tyco UAE joint venture with its local partner Suwaidi Engineering Group ("Suwaidi") in the United Arab Emirates ("UAE") for net cash consideration of $128 million. The cash consideration for this additional investment in the UAE joint venture was comprised of $166 million of cash paid, including settlement of pre-existing matters and prepaid agency commissions net of cash acquired of $27 million. Tyco UAE is a leading provider of fire, security and integrated solutions and services in the UAE and also has operations in Qatar and Oman.  Effective with the date of this transaction, the Company consolidated 100% of Tyco UAE, which is recorded in the Company's ROW Integrated Solutions & Services segment. The total enterprise fair value of the UAE joint venture was allocated as follows: $100 million of assets, $146 million of goodwill, $88 million of intangible assets and the assumption of $32 million of liabilities. The Company's proportionate share of the joint venture's net income was historically recorded in Selling, general and administrative expenses within the Consolidated Statements of Operations for periods prior to the acquisition date. As a result of this transaction, the Company recorded a net gain of $111 million which primarily relates to the Company's previously held 49% equity interest in the joint venture, which was previously accounted for under the equity method of accounting, inclusive of a charge for the settlement of pre-existing matters with the Company's former joint venture partner. The Company recorded the net gain in Selling, general and administrative expenses within the Consolidated Statements of Operations during the quarter ended December 25, 2015.  The balance of the cash paid during the quarter ended December 25, 2015 related to an acquisition within the Company's ROW Integrated Solutions & Services segment which was not material.

[0000833444-16-000120:notes:29]
The final determination of fair value of certain assets and liabilities related to the UAE joint venture acquisition and other acquisition closed during the first quarter of fiscal 2016 remain subject to change based on final valuations of the assets acquired and liabilities assumed.  The Company does not expect the finalization of these matters to have a material effect on the purchase price allocations, which are expected to be completed within fiscal 2016. During the quarter ended December 25, 2015, the Company also finalized the determination of fair value for certain assets and liabilities relating to the fiscal 2015 acquisition of Footfall, with no material adjustment to the preliminary purchase price allocation.

[0000833444-16-000120:notes:30]
During the quarter ended December 25, 2015, the Company announced it had reached a definitive agreement to acquire ShopperTrak, a leading global provider of retail consumer behavior insights and location-based analytics, for approximately $175 million in cash. The transaction closed during the second quarter of fiscal 2016. The financial results of this business will be reported in the ROW Integrated Solutions & Services segment.

[0000833444-16-000120:notes:31]
During the quarter ended December 26, 2014, total cash consideration for acquisitions included in continuing operations totaled $152 million, which was comprised of $175 million cash paid, net of $23 million cash acquired, for five acquisitions, none of which were material individually or in the aggregate. The acquisitions were integrated into the ROW Integrated Solutions & Services and Global Products segments. In connection with one of the acquisitions, the Company acquired a majority interest and recorded a nonredeemable noncontrolling interest of $29 million as of December 26, 2014.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000833444-16-000120:notes:32]
Commitments and Contingencies

[0000833444-16-000120:notes:33]
Legacy Matters Related to Former Management

[0000833444-16-000120:notes:34]
As previously reported, in recent years, the Company has definitively resolved several lawsuits involving disputes with former management, including Dennis Kozlowski, the Company's former chief executive officer, and Mark Swartz, the Company's former chief financial officer.

[0000833444-16-000120:notes:35]
In the first quarter of fiscal 2015, the Company reached a definitive agreement with Mark Swartz to resolve all outstanding disputes, and received approximately $12 million in cash from Mr. Swartz, $5 million of which was shared pursuant to the terms of a legacy class action lawsuit, resulting in a net recovery of $7 million for the Company, which was recorded in Selling, general and administrative expenses within the Consolidated Statement of Operations. The cash received has been classified as restricted.

[0000833444-16-000120:notes:36]
Environmental Matters

[0000833444-16-000120:notes:37]
Tyco is involved in various stages of investigation and cleanup related to environmental remediation matters at a number of sites. The ultimate cost of site cleanup is difficult to predict given the uncertainties regarding the extent of the required cleanup, the interpretation of applicable laws and regulations and alternative cleanup methods. As of December 25, 2015, Tyco concluded that it was probable that it would incur remedial costs in the range of approximately $22 million to $71 million. As of December 25, 2015, Tyco concluded that the best estimate within this range is approximately $32 million, of which $11 million is included in Accrued and other current liabilities and $21 million is included in Other liabilities within the Company's Consolidated Balance Sheet.

[0000833444-16-000120:notes:38]
As previously disclosed, the majority of the liabilities described above relate to ongoing remediation efforts at a facility in the Company's Global Products segment located in Marinette, Wisconsin, which the Company acquired in 1990 in connection with its acquisition of, among other things, the Ansul product line. As of December 25, 2015, the Company concluded that its remaining remediation and monitoring costs related to the Marinette facility were in the range of approximately $14 million to $46 million. The Company's best estimate within that range is approximately $22 million, of which $9 million is included in Accrued and other current liabilities and $13 million is included in Other liabilities within the Company's Consolidated Balance Sheet.  Although the Company has recorded its best estimate of the costs that it will incur to remediate and monitor contamination at the Marinette facility, it is possible that technological, regulatory or enforcement developments, the results of environmental studies or other factors could change the Company's expectations with respect to future charges and cash outlays, and such changes could be material to the Company's future results of operations, financial condition or cash flows.

[0000833444-16-000120:notes:39]
Asbestos Matters

[0000833444-16-000120:notes:40]
The Company and certain of its subsidiaries, including Grinnell LLC (“Grinnell”), along with numerous other third parties, are named as defendants in personal injury lawsuits based on alleged exposure to asbestos containing materials. Substantially all cases pending against affiliates of the Company have been filed against Grinnell, and have typically involved product liability claims based primarily on allegations of manufacture, sale or distribution of industrial products that either contained asbestos or were used with asbestos containing components.

[0000833444-16-000120:notes:41]
During the third quarter of fiscal 2014, the Company, through Grinnell, resolved disputes with certain of its historical insurers and agreed that certain insurance proceeds would be used to establish and fund a qualified settlement fund (“QSF”), within the meaning of the Internal Revenue Code, which would be used for the resolution primarily of Grinnell asbestos liabilities. It is intended that the QSF will receive future insurance payments and proceeds from third party insurers and, in addition, will fund and manage liabilities for certain historical operations of the Company, primarily related to Grinnell. On January 9, 2015, the Company completed a series of restructuring transactions related to the establishment and funding of a dedicated structure pursuant to which a subsidiary of the Company acquired the assets of Grinnell and transferred cash and other assets totaling approximately $278 million (not including $22 million received by the QSF during the quarter ended December 26, 2014 from historic third-party insurers in settlement of coverage disputes) to the structure. As part of the restructuring, subsidiaries in the structure assumed certain liabilities related to historic Grinnell, Scott and Figgie operations, including all historical Grinnell asbestos liabilities, and such subsidiaries purchased additional insurance by, through or from a wholly-owned subsidiary in the structure in order to supplement and enhance existing insurance assets.

[0000833444-16-000120:notes:42]
The Company consolidates the qualified settlement fund and related entities that were established for the purpose of managing and resolving the liabilities described above. Although the entities in the dedicated structure serve the specific purpose of managing certain liabilities, each entity in the structure is a wholly-owned indirect subsidiary of the Company, and therefore is required to be consolidated under GAAP.

[0000833444-16-000120:notes:43]
As of December 25, 2015, the Company has determined that there were approximately 3,100 claims pending against its subsidiaries, primarily Grinnell. This amount reflects the Company's current estimate of the number of viable claims made against Grinnell and includes adjustments for claims that are not actively being prosecuted, identify incorrect defendants, are duplicative of other actions or for which the Company is indemnified by third parties. Yarway Corporation is no longer a subsidiary of the Company and, as of August 2015, is no longer consolidated. Consequently, any claims pending against the Yarway Corporation are excluded from the claims pending above.

[0000833444-16-000120:notes:44]
As of December 25, 2015, the Company's estimated asbestos related net liability recorded within the Company's Consolidated Balance Sheet is $27 million. The net liability within the Consolidated Balance Sheet is comprised of a liability for pending and future claims and related defense costs of $508 million, of which $19 million is recorded in Accrued and other current liabilities, and $489 million is recorded in Other liabilities. The Company also maintains separate cash, investment and other assets within the Consolidated Balance Sheet of $481 million, of which $44 million is recorded in Prepaid expenses and other current assets, and $437 million is recorded in Other assets. Assets include $6 million of cash and $267 million of investments, which have all been designated as restricted.  As of September 25, 2015, the Company's estimated net liability recorded within the Company's Consolidated Balance Sheet was $28 million. The net liability was comprised of a liability for pending and future claims and related defense costs of $515 million, of which $23 million was recorded in Accrued and other current liabilities, and $492 million was recorded in Other liabilities.  The Company also maintained separate cash, investment and other assets within the Consolidated Balance Sheet of $487 million, of which $38 million was recorded in Prepaid expenses and other current assets, and $449 million was recorded in Other assets. Assets included $11 million of cash and $263 million of investments, which were all designated as restricted.

[0000833444-16-000120:notes:45]
The Company periodically assesses the sufficiency of its estimated liability for pending and future asbestos claims and defense costs. On a periodic basis, the Company, through the dedicated structure referred to above, evaluates actual experience regarding asbestos claims filed, settled and dismissed, amounts paid in settlements, and the recoverability of its insurance assets. If and when data from actual experience demonstrate a significant unfavorable discernible trend, the Company performs a valuation of its asbestos related liabilities and corresponding insurance assets including a comprehensive review of the underlying assumptions. In addition, the Company evaluates its ability to reasonably estimate claim activity beyond its current look-forward period (through 2056) in order to assess whether such period continues to be appropriate. In addition to claims and litigation experience, the Company considers additional qualitative and quantitative factors such as changes in legislation, the legal environment, the Company’s strategy in managing claims and obtaining insurance, including its defense strategy, and health related trends in the overall population of individuals potentially exposed to asbestos. The Company evaluates all of these factors and determines whether a change in the estimate of its liability for pending and future claims and defense costs or insurance assets is warranted.

[0000833444-16-000120:notes:46]
The amounts recorded by the Company for asbestos-related liabilities and insurance-related assets are based on the Company's strategies for resolving its asbestos claims, currently available information, and a number of estimates and assumptions. Key variables and assumptions include the number and type of new claims that are filed each year, the average cost of resolution of claims, the identity of defendants, the resolution of coverage issues with insurance carriers, amount of insurance, and the solvency risk with respect to the Company's insurance carriers. Many of these factors are closely linked, such that a change in one variable or assumption will impact one or more of the others, and no single variable or assumption predominately influences the determination of the Company's asbestos-related liabilities and insurance-related assets. Furthermore, predictions with respect to these variables are subject to greater uncertainty in the later portion of the projection period. Other factors that may affect the Company's liability and cash payments for asbestos-related matters include uncertainties surrounding the litigation process from jurisdiction to jurisdiction and from case to case, reforms of state or federal tort legislation and the applicability of insurance policies among subsidiaries. As a result, actual liabilities or insurance recoveries could be significantly higher or lower than those recorded if assumptions used in the Company's calculations vary significantly from actual results.

[0000833444-16-000120:notes:47]
Yarway

[0000833444-16-000120:notes:48]
As previously disclosed, on August 19, 2015, the Chapter 11 bankruptcy plan of Yarway Corporation, a former indirect wholly-owned subsidiary of the Company became effective and the Company contributed approximately $325 million in cash to the Yarway Trust and each of the Company Protected Parties (as such term is defined in the plan) received the benefit of a release from Yarway and an injunction under section 524(g) of the Bankruptcy Code permanently enjoining the assertion of Yarway asbestos claims against those parties. As a result of the effectiveness of the Chapter 11 plan, ownership of the Yarway Corporation was transferred to the Yarway Trust and it was deconsolidated from the Company. Upon deconsolidation, the Company recorded a $4 million loss, which is included in Selling, general and administrative expenses within the Company's Consolidated Statement of Operations during the year ended September 25, 2015.

[0000833444-16-000120:notes:49]
Tax Matters

[0000833444-16-000120:notes:50]
Tyco and its subsidiaries' income tax returns are examined periodically by various tax authorities. In connection with these examinations, tax authorities, including the IRS, have raised issues and proposed tax adjustments, in particular with respect to years preceding the 2007 Separation.  The issues and proposed adjustments related to such years are generally subject to the sharing provisions of the 2007 Tax Sharing Agreement and Tyco's liabilities under the 2007 Tax Sharing Agreement are further subject to the sharing provisions in the 2012 Tax Sharing Agreement. Tyco has previously disclosed that in connection with U.S. federal tax audits, the IRS raised a number of issues and proposed tax adjustments for periods beginning with the 1997 tax year. Although Tyco resolved substantially all of the issues and adjustments proposed by the IRS for tax years through 2007, it was not able to resolve matters related to the treatment of certain intercompany debt transactions during the period. As a result, on June 20, 2013, Tyco received Notices of Deficiency from the IRS asserting that several of Tyco's former U.S. subsidiaries owe additional taxes of $883.3 million plus penalties of $154 million based on audits of the 1997 through 2000 tax years of Tyco and its subsidiaries as they existed at that time. In addition, Tyco received Final Partnership Administrative Adjustments for certain U.S. partnerships owned by former U.S. subsidiaries with respect to which an additional tax deficiency of approximately $30 million has been asserted. These amounts excluded interest and did not reflect the roll-forward impact on subsequent audit periods.

[0000833444-16-000120:notes:51]
On January 15, 2016, Tyco entered into Stipulations of Settled Issues with the IRS intended to resolve all disputes related to the intercompany debt issues described above for the 1997 - 2000 audit cycle currently before the U.S. Tax Court. The Stipulations of Settled Issues are contingent upon the IRS Appeals Division applying the same settlement to all intercompany debt issues on appeal for subsequent audit cycles (2001 - 2007) and, if applicable, review by the United States Congress Joint Committee on Taxation.

[0000833444-16-000120:notes:52]
If finalized, the tentative resolution would cover all aspects of the controversy before the U.S. Tax Court described above and before the Appeals Division of the IRS, and would result in a total cash payment to the IRS in the range of $475 million to $525 million, which includes all interest and penalties. This payment would be subject to the sharing formula in each Tax Sharing Agreement, and would be shared among Tyco, Covidien and TE Connectivity 27%, 42% and 31%, respectively, with neither ADT nor Pentair being responsible for any payment related to this amount.

[0000833444-16-000120:notes:53]
Assuming the tentative resolution is finalized, Tyco does not expect to recognize any additional charges related to the resolution, as it had previously recorded sufficient reserves with respect to this controversy and its obligations under the Tax Sharing Agreements. Payment is expected to be made to the IRS, and among Tyco, Covidien and TE Connectivity, within the next six months. See Note 5.

[0000833444-16-000120:notes:54]
Other Matters

[0000833444-16-000120:notes:55]
As previously disclosed, SimplexGrinnell LP (“SG”), a subsidiary of the Company in the North America Integrated Solutions & Services segment, has been named as a defendant in lawsuits in several jurisdictions seeking damages for SG’s alleged failure to pay prevailing wages and for other pay-related claims.  Through the first quarter of fiscal 2015, the Company had recorded a total of approximately $17 million in charges related to these lawsuits, which was recorded in the Cost of services within the Consolidated Statement of Operations.  During the quarter ended March 27, 2015, the Company agreed in principle to settle all outstanding lawsuits for a total of approximately $14 million.

[0000833444-16-000120:notes:56]
In addition to the foregoing, the Company is subject to claims and suits, including from time to time, contractual disputes and product and general liability claims, incidental to present and former operations, acquisitions and dispositions. With respect to many of these claims, the Company either self-insures or maintains insurance through third-parties, with varying deductibles. While the ultimate outcome of these matters cannot be predicted with certainty, the Company believes that the resolution of any such proceedings, whether the underlying claims are covered by insurance or not, will not have a material adverse effect on the Company's financial condition, results of operations or cash flows beyond amounts recorded for such matters.


## us-gaap:CondensedFinancialStatementsTextBlock

[0000833444-16-000120:notes:57]
[same as prior period, unchanged from 0000833444-15-000062:notes:64]

[0000833444-16-000120:notes:58]
[same as prior period, unchanged from 0000833444-15-000062:notes:65]

[0000833444-16-000120:notes:59]
[same as prior period, unchanged from 0000833444-15-000062:notes:66]

[0000833444-16-000120:notes:60]
For the Quarter Ended December 25, 2015

[0000833444-16-000120:notes:61]
[same as prior period, unchanged from 0000833444-15-000062:notes:68]

[0000833444-16-000120:notes:62]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,376 |  |  | $ | — |  |  | $ | 2,376 |  |
| Cost of product sales | — |  |  | — |  |  | — |  |  | 962 |  |  | — |  |  | 962 |  |
| Cost of services | — |  |  | — |  |  | — |  |  | 536 |  |  | — |  |  | 536 |  |
| Selling, general and administrative expenses | 2 |  |  | — |  |  | — |  |  | 571 |  |  | — |  |  | 573 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | — |  |  | 12 |  |  | — |  |  | 12 |  |
| Operating (loss) income | (2 | ) |  | — |  |  | — |  |  | 295 |  |  | — |  |  | 293 |  |
| Interest income | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Interest expense | — |  |  | — |  |  | (23 | ) |  | (1 | ) |  | — |  |  | (24 | ) |
| Other expense, net | — |  |  | — |  |  | (165 | ) |  | — |  |  | — |  |  | (165 | ) |
| Equity in net income of subsidiaries | 18 |  |  | 16 |  |  | 179 |  |  | — |  |  | (213 | ) |  | — |  |
| Intercompany interest and fees | 60 |  |  | — |  |  | 25 |  |  | (85 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 76 |  |  | 16 |  |  | 16 |  |  | 213 |  |  | (213 | ) |  | 108 |  |
| Income tax expense | — |  |  | — |  |  | — |  |  | (36 | ) |  | — |  |  | (36 | ) |
| Income from continuing operations | 76 |  |  | 16 |  |  | 16 |  |  | 177 |  |  | (213 | ) |  | 72 |  |
| Income from discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Net income | 76 |  |  | 16 |  |  | 16 |  |  | 181 |  |  | (213 | ) |  | 76 |  |
| Net income attributable to Tyco ordinary shareholders | $ | 76 |  |  | $ | 16 |  |  | $ | 16 |  |  | $ | 181 |  |  | $ | (213 | ) |  | $ | 76 |  |

[0000833444-16-000120:notes:63]
[same as prior period, unchanged from 0000833444-15-000062:notes:70]

[0000833444-16-000120:notes:64]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 76 |  |  | $ | 16 |  |  | $ | 16 |  |  | $ | 181 |  |  | $ | (213 | ) |  | $ | 76 |  |
| Other comprehensive (loss) income, net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | (43 | ) |  | — |  |  | 14 |  |  | (57 | ) |  | 43 |  |  | (43 | ) |
| Defined benefit and post retirement plans | 5 |  |  | — |  |  | — |  |  | 5 |  |  | (5 | ) |  | 5 |  |
| Unrealized gain on marketable securities and derivative instruments, net of tax | 1 |  |  | — |  |  | — |  |  | 1 |  |  | (1 | ) |  | 1 |  |
| Total other comprehensive (loss) income, net of tax | (37 | ) |  | — |  |  | 14 |  |  | (51 | ) |  | 37 |  |  | (37 | ) |
| Comprehensive income | 39 |  |  | 16 |  |  | 30 |  |  | 130 |  |  | (176 | ) |  | 39 |  |
| Less: comprehensive income attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Comprehensive income attributable to Tyco ordinary shareholders | $ | 39 |  |  | $ | 16 |  |  | $ | 30 |  |  | $ | 130 |  |  | $ | (176 | ) |  | $ | 39 |  |

[0000833444-16-000120:notes:65]
For the Quarter Ended December 26, 2014

[0000833444-16-000120:notes:66]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net revenue | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,478 |  |  | $ | — |  |  | $ | 2,478 |  |
| Cost of product sales | — |  |  | — |  |  | — |  |  | 1,022 |  |  | — |  |  | 1,022 |  |
| Cost of services | — |  |  | — |  |  | — |  |  | 547 |  |  | — |  |  | 547 |  |
| Selling, general and administrative expenses | 3 |  |  | — |  |  | 1 |  |  | 648 |  |  | — |  |  | 652 |  |
| Restructuring and asset impairment charges, net | — |  |  | — |  |  | — |  |  | 58 |  |  | — |  |  | 58 |  |
| Operating (loss) income | (3 | ) |  | — |  |  | (1 | ) |  | 203 |  |  | — |  |  | 199 |  |
| Interest income | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Interest expense | — |  |  | — |  |  | (24 | ) |  | — |  |  | — |  |  | (24 | ) |
| Other income, net | — |  |  | — |  |  | 4 |  |  | — |  |  | — |  |  | 4 |  |
| Equity in net income of subsidiaries | 143 |  |  | 133 |  |  | 127 |  |  | — |  |  | (403 | ) |  | — |  |
| Intercompany interest and fees | 22 |  |  | — |  |  | 27 |  |  | (49 | ) |  | — |  |  | — |  |
| Income from continuing operations before income taxes | 162 |  |  | 133 |  |  | 133 |  |  | 157 |  |  | (403 | ) |  | 182 |  |
| Income tax expense | — |  |  | — |  |  | — |  |  | (19 | ) |  | — |  |  | (19 | ) |
| Income from continuing operations | 162 |  |  | 133 |  |  | 133 |  |  | 138 |  |  | (403 | ) |  | 163 |  |
| Loss from discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Net income | 162 |  |  | 133 |  |  | 133 |  |  | 136 |  |  | (403 | ) |  | 161 |  |
| Less: noncontrolling interest in subsidiaries net loss | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Net income attributable to Tyco ordinary shareholders | $ | 162 |  |  | $ | 133 |  |  | $ | 133 |  |  | $ | 137 |  |  | $ | (403 | ) |  | $ | 162 |  |

[0000833444-16-000120:notes:67]
CONDENSED CONSOLIDATING STATEMENT OF COMPREHENSIVE INCOME (LOSS)

[0000833444-16-000120:notes:68]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Net income | $ | 162 |  |  | $ | 133 |  |  | $ | 133 |  |  | $ | 136 |  |  | $ | (403 | ) |  | $ | 161 |  |
| Other comprehensive (loss) income, net of tax |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency translation | (198 | ) |  | — |  |  | (1 | ) |  | (197 | ) |  | 198 |  |  | (198 | ) |
| Defined benefit and post retirement plans | 5 |  |  | — |  |  | — |  |  | 5 |  |  | (5 | ) |  | 5 |  |
| Total other comprehensive loss, net of tax | (193 | ) |  | — |  |  | (1 | ) |  | (192 | ) |  | 193 |  |  | (193 | ) |
| Comprehensive (loss) income | (31 | ) |  | 133 |  |  | 132 |  |  | (56 | ) |  | (210 | ) |  | (32 | ) |
| Less: comprehensive loss attributable to noncontrolling interests | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Comprehensive (loss) income attributable to Tyco ordinary shareholders | $ | (31 | ) |  | $ | 133 |  |  | $ | 132 |  |  | $ | (55 | ) |  | $ | (210 | ) |  | $ | (31 | ) |

[0000833444-16-000120:notes:69]
[same as prior period, unchanged from 0000833444-15-000062:notes:81]

[0000833444-16-000120:notes:70]
As of December 25, 2015

[0000833444-16-000120:notes:71]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 301 |  |  | $ | — |  |  | $ | 301 |  |
| Accounts receivable, net | — |  |  | — |  |  | — |  |  | 1,719 |  |  | — |  |  | 1,719 |  |
| Inventories | — |  |  | — |  |  | — |  |  | 647 |  |  | — |  |  | 647 |  |
| Intercompany receivables | 15 |  |  | — |  |  | 451 |  |  | 7,610 |  |  | (8,076 | ) |  | — |  |
| Prepaid expenses and other current assets | — |  |  | — |  |  | 67 |  |  | 786 |  |  | — |  |  | 853 |  |
| Deferred income taxes | — |  |  | — |  |  | — |  |  | 62 |  |  | — |  |  | 62 |  |
| Assets held for sale | — |  |  | — |  |  | — |  |  | 83 |  |  | — |  |  | 83 |  |
| Total current assets | 15 |  |  | — |  |  | 518 |  |  | 11,208 |  |  | (8,076 | ) |  | 3,665 |  |
| Property, plant and equipment, net | — |  |  | — |  |  | — |  |  | 1,167 |  |  | — |  |  | 1,167 |  |
| Goodwill | — |  |  | — |  |  | — |  |  | 4,365 |  |  | — |  |  | 4,365 |  |
| Intangible assets, net | — |  |  | — |  |  | — |  |  | 927 |  |  | — |  |  | 927 |  |
| Investment in subsidiaries | 10,881 |  |  | 11,142 |  |  | 16,146 |  |  | — |  |  | (38,169 | ) |  | — |  |
| Intercompany loans receivable | — |  |  | — |  |  | 2,942 |  |  | 5,086 |  |  | (8,028 | ) |  | — |  |
| Other assets | 1 |  |  | — |  |  | 41 |  |  | 1,265 |  |  | — |  |  | 1,307 |  |
| Total Assets | $ | 10,897 |  |  | $ | 11,142 |  |  | $ | 19,647 |  |  | $ | 24,018 |  |  | $ | (54,273 | ) |  | $ | 11,431 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Loans payable and current maturities of long-term debt | $ | — |  |  | $ | — |  |  | $ | 151 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 152 |  |
| Accounts payable | 1 |  |  | — |  |  | — |  |  | 788 |  |  | — |  |  | 789 |  |
| Accrued and other current liabilities | 88 |  |  | — |  |  | 258 |  |  | 1,491 |  |  | — |  |  | 1,837 |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 349 |  |  | — |  |  | 349 |  |
| Intercompany payables | 3,639 |  |  | — |  |  | 3,974 |  |  | 463 |  |  | (8,076 | ) |  | — |  |
| Liabilities held for sale | — |  |  | — |  |  | — |  |  | 84 |  |  | — |  |  | 84 |  |
| Total current liabilities | 3,728 |  |  | — |  |  | 4,383 |  |  | 3,176 |  |  | (8,076 | ) |  | 3,211 |  |
| Long-term debt | — |  |  | — |  |  | 2,145 |  |  | 1 |  |  | — |  |  | 2,146 |  |
| Intercompany loans payable | 3,160 |  |  | — |  |  | 1,926 |  |  | 2,942 |  |  | (8,028 | ) |  | — |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 292 |  |  | — |  |  | 292 |  |
| Other liabilities | — |  |  | — |  |  | 51 |  |  | 1,685 |  |  | — |  |  | 1,736 |  |
| Total Liabilities | 6,888 |  |  | — |  |  | 8,505 |  |  | 8,096 |  |  | (16,104 | ) |  | 7,385 |  |
| Tyco Shareholders' Equity: |  |  |  |  |  |  |  |  |  |  |  |
| Ordinary shares | 4 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |
| Ordinary shares held in treasury | (14 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (14 | ) |
| Other shareholders' equity | 4,019 |  |  | 11,142 |  |  | 11,142 |  |  | 15,885 |  |  | (38,169 | ) |  | 4,019 |  |
| Total Tyco Shareholders' Equity | 4,009 |  |  | 11,142 |  |  | 11,142 |  |  | 15,885 |  |  | (38,169 | ) |  | 4,009 |  |
| Nonredeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 37 |  |  | — |  |  | 37 |  |
| Total Equity | 4,009 |  |  | 11,142 |  |  | 11,142 |  |  | 15,922 |  |  | (38,169 | ) |  | 4,046 |  |
| Total Liabilities and Equity | $ | 10,897 |  |  | $ | 11,142 |  |  | $ | 19,647 |  |  | $ | 24,018 |  |  | $ | (54,273 | ) |  | $ | 11,431 |  |

[0000833444-16-000120:notes:72]
As of September 25, 2015

[0000833444-16-000120:notes:73]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Current Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,401 |  |  | $ | — |  |  | $ | 1,401 |  |
| Accounts receivable, net | — |  |  | — |  |  | — |  |  | 1,732 |  |  | — |  |  | 1,732 |  |
| Inventories | — |  |  | — |  |  | — |  |  | 624 |  |  | — |  |  | 624 |  |
| Intercompany receivables | 15 |  |  | — |  |  | 332 |  |  | 6,508 |  |  | (6,855 | ) |  | — |  |
| Prepaid expenses and other current assets | — |  |  | — |  |  | 63 |  |  | 691 |  |  | — |  |  | 754 |  |
| Deferred income taxes | — |  |  | — |  |  | — |  |  | 62 |  |  | — |  |  | 62 |  |
| Assets held for sale | — |  |  | — |  |  | — |  |  | 102 |  |  | — |  |  | 102 |  |
| Total current assets | 15 |  |  | — |  |  | 395 |  |  | 11,120 |  |  | (6,855 | ) |  | 4,675 |  |
| Property, plant and equipment, net | — |  |  | — |  |  | — |  |  | 1,177 |  |  | — |  |  | 1,177 |  |
| Goodwill | — |  |  | — |  |  | — |  |  | 4,234 |  |  | — |  |  | 4,234 |  |
| Intangible assets, net | — |  |  | — |  |  | — |  |  | 863 |  |  | — |  |  | 863 |  |
| Investment in subsidiaries | 10,885 |  |  | 11,148 |  |  | 16,001 |  |  | — |  |  | (38,034 | ) |  | — |  |
| Intercompany loans receivable | — |  |  | — |  |  | 2,942 |  |  | 5,066 |  |  | (8,008 | ) |  | — |  |
| Other assets | 1 |  |  | — |  |  | 44 |  |  | 1,327 |  |  | — |  |  | 1,372 |  |
| Total Assets | $ | 10,901 |  |  | $ | 11,148 |  |  | $ | 19,382 |  |  | $ | 23,787 |  |  | $ | (52,897 | ) |  | $ | 12,321 |  |
| Liabilities and Equity |  |  |  |  |  |  |  |  |  |  |  |
| Current Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Loans payable and current maturities of long-term debt | $ | — |  |  | $ | — |  |  | $ | 967 |  |  | $ | 20 |  |  | $ | — |  |  | $ | 987 |  |
| Accounts payable | 1 |  |  | — |  |  | — |  |  | 773 |  |  | — |  |  | 774 |  |
| Accrued and other current liabilities | 88 |  |  | — |  |  | 61 |  |  | 1,512 |  |  | — |  |  | 1,661 |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 380 |  |  | — |  |  | 380 |  |
| Intercompany payables | 3,616 |  |  | — |  |  | 2,892 |  |  | 347 |  |  | (6,855 | ) |  | — |  |
| Liabilities held for sale | — |  |  | — |  |  | — |  |  | 50 |  |  | — |  |  | 50 |  |
| Total current liabilities | 3,705 |  |  | — |  |  | 3,920 |  |  | 3,082 |  |  | (6,855 | ) |  | 3,852 |  |
| Long-term debt | — |  |  | — |  |  | 2,158 |  |  | 1 |  |  | — |  |  | 2,159 |  |
| Intercompany loans payable | 3,155 |  |  | — |  |  | 1,911 |  |  | 2,942 |  |  | (8,008 | ) |  | — |  |
| Deferred revenue | — |  |  | — |  |  | — |  |  | 303 |  |  | — |  |  | 303 |  |
| Other liabilities | — |  |  | — |  |  | 245 |  |  | 1,686 |  |  | — |  |  | 1,931 |  |
| Total Liabilities | 6,860 |  |  | — |  |  | 8,234 |  |  | 8,014 |  |  | (14,863 | ) |  | 8,245 |  |
| Tyco Shareholders' Equity: |  |  |  |  |  |  |  |  |  |  |  |
| Ordinary shares | 4 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |
| Other shareholders' equity | 4,037 |  |  | 11,148 |  |  | 11,148 |  |  | 15,738 |  |  | (38,034 | ) |  | 4,037 |  |
| Total Tyco Shareholders' Equity | 4,041 |  |  | 11,148 |  |  | 11,148 |  |  | 15,738 |  |  | (38,034 | ) |  | 4,041 |  |
| Nonredeemable noncontrolling interest | — |  |  | — |  |  | — |  |  | 35 |  |  | — |  |  | 35 |  |
| Total Equity | 4,041 |  |  | 11,148 |  |  | 11,148 |  |  | 15,773 |  |  | (38,034 | ) |  | 4,076 |  |
| Total Liabilities and Equity | $ | 10,901 |  |  | $ | 11,148 |  |  | $ | 19,382 |  |  | $ | 23,787 |  |  | $ | (52,897 | ) |  | $ | 12,321 |  |

[0000833444-16-000120:notes:74]
[same as prior period, unchanged from 0000833444-15-000062:notes:86]

[0000833444-16-000120:notes:75]
For the Three Months Ended December 25, 2015

[0000833444-16-000120:notes:76]
|  | TycoInternational plc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities | $ | 87 |  |  | $ | — |  |  | $ | 968 |  |  | $ | (866 | ) |  | $ | — |  |  | $ | 189 |  |
| Net cash provided by discontinued operating activities | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | — |  |  | (68 | ) |  | — |  |  | (68 | ) |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | — |  |  | (138 | ) |  | — |  |  | (138 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases | — |  |  | — |  |  | — |  |  | (4 | ) |  | — |  |  | (4 | ) |
| Net decrease in intercompany loans | — |  |  | — |  |  | 15 |  |  | — |  |  | (15 | ) |  | — |  |
| Sales and maturities of investments | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Purchases of investments | — |  |  | — |  |  | — |  |  | (7 | ) |  | — |  |  | (7 | ) |
| Decrease in restricted cash | — |  |  | — |  |  | — |  |  | 5 |  |  | — |  |  | 5 |  |
| Net cash provided by (used in) investing activities | — |  |  | — |  |  | 15 |  |  | (211 | ) |  | (15 | ) |  | (211 | ) |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from issuance of short-term debt | — |  |  | — |  |  | 817 |  |  | — |  |  | — |  |  | 817 |  |
| Repayment of short-term debt | — |  |  | — |  |  | (666 | ) |  | — |  |  | — |  |  | (666 | ) |
| Repayment of current portion of long-term debt | — |  |  | — |  |  | (1,134 | ) |  | — |  |  | — |  |  | (1,134 | ) |
| Proceeds from exercise of share options | 11 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 11 |  |
| Dividends paid | (87 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (87 | ) |
| Net intercompany loan repayments | — |  |  | — |  |  | — |  |  | (15 | ) |  | 15 |  |  | — |  |
| Transfer from discontinued operations | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Other | (11 | ) |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (12 | ) |
| Net cash used in financing activities | (87 | ) |  | — |  |  | (983 | ) |  | (14 | ) |  | 15 |  |  | (1,069 | ) |
| Net cash used in discontinued financing activities | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Effect of currency translation on cash | — |  |  | — |  |  | — |  |  | (9 | ) |  | — |  |  | (9 | ) |
| Net decrease in cash and cash equivalents | — |  |  | — |  |  | — |  |  | (1,100 | ) |  | — |  |  | (1,100 | ) |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | — |  |  | 1,401 |  |  | — |  |  | 1,401 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 301 |  |  | $ | — |  |  | $ | 301 |  |

[0000833444-16-000120:notes:77]
For the Three Months Ended December 26, 2014

[0000833444-16-000120:notes:78]
|  | TycoInternationalplc |  | TycoFire & SecurityFinance SCA |  | TycoInternationalFinance S.A. |  | OtherSubsidiaries |  | ConsolidatingAdjustments |  | Total |
| Cash Flows From Operating Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Net cash (used in) provided by operating activities | $ | (34 | ) |  | $ | — |  |  | $ | 72 |  |  | $ | 57 |  |  | $ | — |  |  | $ | 95 |  |
| Net cash provided by discontinued operating activities | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Cash Flows From Investing Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures | — |  |  | — |  |  | — |  |  | (66 | ) |  | — |  |  | (66 | ) |
| Proceeds from disposal of assets | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Acquisition of businesses, net of cash acquired | — |  |  | — |  |  | — |  |  | (152 | ) |  | — |  |  | (152 | ) |
| Acquisition of dealer generated customer accounts and bulk account purchases | — |  |  | — |  |  | — |  |  | (4 | ) |  | — |  |  | (4 | ) |
| Net increase in intercompany loans | — |  |  | — |  |  | (72 | ) |  | — |  |  | 72 |  |  | — |  |
| Sales and maturities of investments | — |  |  | — |  |  | — |  |  | 275 |  |  | — |  |  | 275 |  |
| Purchases of investments | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Increase in restricted cash | — |  |  | — |  |  | — |  |  | (45 | ) |  | — |  |  | (45 | ) |
| Other | — |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Net cash (used in) provided by investing activities | — |  |  |  |  | (72 | ) |  | 7 |  |  | 72 |  |  | 7 |  |
| Net cash used in discontinued investing activities | — |  |  |  |  | — |  |  | (15 | ) |  | — |  |  | (15 | ) |
| Cash Flows From Financing Activities: |  |  |  |  |  |  |  |  |  |  |  |
| Proceeds from exercise of share options | 27 |  |  | — |  |  | — |  |  | 6 |  |  | — |  |  | 33 |  |
| Dividends paid | (75 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | (75 | ) |
| Repurchase of ordinary shares by treasury | — |  |  | — |  |  | — |  |  | (417 | ) |  | — |  |  | (417 | ) |
| Net intercompany loan borrowings (repayments) | 84 |  |  | — |  |  | — |  |  | (12 | ) |  | (72 | ) |  | — |  |
| Transfer to discontinued operations | — |  |  | — |  |  | — |  |  | (14 | ) |  | — |  |  | (14 | ) |
| Payment of contingent consideration | — |  |  | — |  |  | — |  |  | (23 | ) |  | — |  |  | (23 | ) |
| Other | (2 | ) |  | — |  |  | — |  |  | (13 | ) |  | — |  |  | (15 | ) |
| Net cash provided by (used in) financing activities | 34 |  |  | — |  |  | — |  |  | (473 | ) |  | (72 | ) |  | (511 | ) |
| Net cash provided by discontinued financing activities | — |  |  | — |  |  | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Effect of currency translation on cash | — |  |  | — |  |  | — |  |  | (10 | ) |  | — |  |  | (10 | ) |
| Net decrease in cash and cash equivalents | — |  |  | — |  |  | — |  |  | (419 | ) |  | — |  |  | (419 | ) |
| Cash and cash equivalents at beginning of period | — |  |  | — |  |  | — |  |  | 892 |  |  | — |  |  | 892 |  |
| Cash and cash equivalents at end of period | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 473 |  |  | $ | — |  |  | $ | 473 |  |


## us-gaap:DebtDisclosureTextBlock

[0000833444-16-000120:notes:79]
Debt

[0000833444-16-000120:notes:80]
The carrying value of the Company's debt as of December 25, 2015 and September 25, 2015 is as follows ($ in millions):

[0000833444-16-000120:notes:81]
|  | As of |
|  | December 25, 2015 |  | September 25, 2015 |
| Commercial paper | $ | 151 |  |  | $ | — |  |
| 3.375% public notes due 2015 | — |  |  | 258 |  |
| 3.75% public notes due 2018 | 67 |  |  | 67 |  |
| 7.0% public notes due 2019 | — |  |  | 245 |  |
| 6.875% public notes due 2021 | — |  |  | 465 |  |
| 4.625% public notes due 2023 | 42 |  |  | 42 |  |
| 1.375% Euro-denominated public notes due 2025 | 545 |  |  | 558 |  |
| 3.9% public notes due 2026 | 745 |  |  | 745 |  |
| 5.125% public notes due 2045 | 746 |  |  | 746 |  |
| Other | 2 |  |  | 20 |  |
| Total debt | 2,298 |  |  | 3,146 |  |
| Less current portion (1)(2) | 152 |  |  | 987 |  |
| Long-term debt | $ | 2,146 |  |  | $ | 2,159 |  |

[0000833444-16-000120:notes:82]
_______________________________________________________________________________

[0000833444-16-000120:notes:83]
(1)  The current portion of debt as of December 25, 2015 is comprised of $151 million of commercial paper and $1 million of Other debt.

[0000833444-16-000120:notes:84]
(2) The current portion of debt as of September 25, 2015 is comprised of $258 million notes due 2015, $245 million notes due 2019, $465 million notes due 2021 and $19 million of Other debt.

[0000833444-16-000120:notes:85]
Fair Value

[0000833444-16-000120:notes:86]
The carrying amount of Tyco's debt subject to the fair value disclosure requirements as of December 25, 2015 and September 25, 2015 was $2,296 million and $3,126 million, respectively. The Company utilizes various valuation methodologies to determine the fair value of its debt, which is primarily dependent on the type of market in which the Company's debt is traded. When available, the Company uses quoted market prices to determine the fair value of its debt that is traded in active markets.  As of December 25, 2015 and September 25, 2015, the fair value of the Company's debt which was actively traded was $2,318 million and $3,291 million, respectively.  As of December 25, 2015 and September 25, 2015, the Company's debt that was subject to the fair value disclosure requirements was all actively traded and is classified as Level 1 in the fair value hierarchy. Additionally, the Company believes the carrying amount of its commercial paper of $151 million as of December 25, 2015 approximates fair value based on the short-term nature of such debt.

[0000833444-16-000120:notes:87]
Fiscal 2016 Debt Repayment

[0000833444-16-000120:notes:88]
On September 14, 2015, the Company and the Company's wholly-owned subsidiary, Tyco International Finance S.A. ("TIFSA") announced the redemption of all of the outstanding $242 million aggregate principal amount of 7.0% notes due 2019 and $462 million aggregate principal amount of 6.875% notes due 2021. On October 14, 2015, TIFSA paid cash of $876 million to complete the redemption, resulting in a loss on extinguishment of $168 million which was recorded in Other expense, net within the Consolidated Statements of Operations during the first quarter of fiscal 2016. The charge is comprised of the make-whole premium of $172 million and the write-off of unamortized debt issuance costs of $1 million, partially offset by the write-off of the unamortized premium of $5 million.

[0000833444-16-000120:notes:89]
On October 15, 2015, the Company repaid $258 million aggregate principal amount of 3.375% notes which matured on such date.

[0000833444-16-000120:notes:90]
Commercial Paper

[0000833444-16-000120:notes:91]
From time to time, TIFSA may issue commercial paper for general corporate purposes. The maximum aggregate amount of unsecured commercial paper notes available to be issued, on a private placement basis, under the commercial paper program is $1.5 billion as of December 25, 2015.  As of December 25, 2015 and September 25, 2015, TIFSA had $151 million and nil of commercial paper outstanding, respectively.

[0000833444-16-000120:notes:92]
Credit Facilities

[0000833444-16-000120:notes:93]
On August 7, 2015, TIFSA entered into an Amended and Restated Five-Year Senior Unsecured Credit Agreement in the aggregate amount of $1.5 billion (the “2015 Credit Agreement”). The 2015 Credit Agreement amends and restates TIFSA's existing Five-Year Senior Unsecured Credit Agreement, dated June 22, 2012 (the “2012 Credit Agreement”), which provided for revolving credit commitments in the aggregate amount of $1.0 billion, and was scheduled to expire on June 22, 2017.

[0000833444-16-000120:notes:94]
As a result of entering into the 2015 Credit Agreement, the Company's committed revolving credit facility totaled $1.5 billion as of December 25, 2015. This revolving credit facility may be used for working capital, capital expenditures and general corporate purposes. As of December 25, 2015 and September 25, 2015, there were no amounts drawn under the Company's revolving credit facility. Interest under the revolving credit facility is variable and is calculated by reference to LIBOR or an alternate base rate.

[0000833444-16-000120:notes:95]
TIFSA's revolving credit facility contains customary terms and conditions, and financial covenants that limit the ratio of the Company's debt to earnings before interest, taxes, depreciation, and amortization and that limit our ability to incur subsidiary debt or grant liens on its property. The indentures contain customary covenants including limits on negative pledges, subsidiary debt and sale/leaseback transactions. None of these covenants are considered restrictive to the Company's business.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000833444-16-000120:notes:96]
[same as prior period, unchanged from 0000833444-15-000062:notes:103]

[0000833444-16-000120:notes:97]
During the quarter ended December 25, 2015, the Company issued its annual share-based compensation grants. The total number of awards issued was approximately 3.7 million, of which 2.6 million were stock options, 0.5 million were restricted unit awards and 0.6 million were performance share unit awards. The options and restricted stock units vest in equal annual installments over a period of 4 years, and the performance share unit awards, which are restricted share awards that vest depending upon attainment of various levels of  performance, generally vest in their entirety 3 years from the grant date, and are determined by the Compensation and Human Resources Committee of the Board. The weighted-average grant-date fair value of the stock options, restricted unit awards and performance share unit awards was $7.18, $36.08 and $37.16, respectively. The weighted-average assumptions used in the Black-Scholes option pricing model included an expected stock price volatility of 26%, a risk free interest rate of 1.60%, an expected annual dividend per share of $0.82 and an expected option life of 5.48 years.

[0000833444-16-000120:notes:98]
During the quarter ended December 26, 2014, the Company issued its annual share-based compensation grants. The total number of awards issued was approximately 2.4 million, of which 1.5 million were stock options, 0.4 million were restricted unit awards and 0.5 million were performance share unit awards. The weighted-average grant-date fair value of the stock options, restricted unit awards and performance share unit awards was $11.77, $43.38 and $42.95, respectively. The weighted-average assumptions used in the Black-Scholes option pricing model included an expected stock price volatility of 32%, a risk free interest rate of 1.83%, an expected annual dividend per share of $0.72 and an expected option life of 5.57 years.

[0000833444-16-000120:notes:99]
The fair value of restricted stock units is determined based on the closing market price of the Company’s shares on the grant date. The fair value of performance share units is determined based on the Monte Carlo valuation model. The compensation expense recognized for all restricted share awards is net of estimated forfeitures.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0000833444-16-000120:notes:100]
[same as prior period, unchanged from 0000833444-15-000062:notes:106]

[0000833444-16-000120:notes:101]
The Company has continued to assess the strategic fit of its various businesses and has pursued the divestiture of certain businesses which do not align with its long-term strategy.

[0000833444-16-000120:notes:102]
Fiscal 2016

[0000833444-16-000120:notes:103]
During the first quarter of fiscal 2016, the Company approved a plan to sell its Australian fire protection business, included within its ROW Integrated Solutions & Services segment. As of December 25, 2015, the sale had not been completed. The assets and liabilities of this business have been presented separately as held for sale within the Consolidated Balance Sheets for all periods presented. A pre-tax loss of approximately $57 million for the write-down to fair value, less cost to sell, was recorded in Selling, general and administrative expenses within the Company’s Consolidated Statements of Operations for the quarter ended December 25, 2015. The Company recorded a provision of $24 million for the cumulative translation losses as of December 25, 2015, which is included in the pre-tax loss described above. The Company will realize such cumulative translation losses upon closing of the transaction, which occurred during the second quarter of fiscal 2016.  This business has not been presented in discontinued operations within the Consolidated Statements of Operations, as the criteria to be presented as a discontinued operation were not satisfied.

[0000833444-16-000120:notes:104]
The Company recorded a pre-tax gain of $17 million resulting from the transfer to Pentair Ltd. (formerly known as Tyco Flow Control International Ltd.) of Tyco's equity interest in a joint venture related to the Company's former Flow Control business as repayment of a loan established at the time of the 2012 Separation. This gain was recorded in Income (loss) from discontinued operations, net of income taxes, within the Consolidated Statements of Operations for the quarter ended December 25, 2015.

[0000833444-16-000120:notes:105]
Fiscal 2015

[0000833444-16-000120:notes:106]
During the fourth quarter of fiscal 2015, the Company approved a plan to sell a business within its Global Products segment. The assets and liabilities have not been presented separately as held for sale within the Consolidated Balance Sheets as the amounts were not material to the presentation of all periods. A pre-tax loss of approximately $17 million for the write-down to fair value, less cost to sell was recorded in Selling, general and administrative expenses within the Company’s Consolidated Statements of Operations during the fourth quarter of fiscal 2015. This business has not been presented in discontinued operations as the amounts were not material to the Consolidated Financial Statements. The Company completed the transaction during the second quarter of fiscal 2016.

[0000833444-16-000120:notes:107]
During fiscal 2015, the Company concluded that a business in the ROW Integrated Solutions & Services segment which it intends to sell met the criteria to be classified as held for sale. This business is accounted for as held for sale within the Consolidated Balance Sheets as of December 25, 2015 and September 25, 2015, and its results of operations have been presented as discontinued operations within the Consolidated Statements of Operations for the quarters ended December 25, 2015 and December 26, 2014. The Company expects to complete the sale of this business during the second quarter of fiscal 2016.

[0000833444-16-000120:notes:108]
Divestiture Charges, net

[0000833444-16-000120:notes:109]
During the first quarter of fiscal 2016, the Company recorded a net loss of $52 million in Selling, general and administrative expenses within the Company's Consolidated Statements of Operations, which included the $57 million pre-tax loss related to the Company's planned sale of its Australian fire protection business, as described above. The Company recorded a net divestiture loss of $1 million during the first quarter of fiscal 2015.

[0000833444-16-000120:notes:110]
[same as prior period, unchanged from 0000833444-15-000062:notes:111]

[0000833444-16-000120:notes:111]
The components of income (loss) from discontinued operations, net of income taxes are as follows ($ in millions):

[0000833444-16-000120:notes:112]
|  | For the Quarters Ended |
|  | December 25, 2015 |  | December 26, 2014 |
| Net revenue | $ | 1 |  |  | $ | 5 |  |
| Pre-tax loss from discontinued operations | (1 | ) |  | (3 | ) |
| Pre-tax gain on discontinued operations | 17 |  |  | 1 |  |
| Income tax expense (1) | (12 | ) |  | — |  |
| Income (loss) from discontinued operations, net of income taxes | $ | 4 |  |  | $ | (2 | ) |

[0000833444-16-000120:notes:113]
(1)  Related to the Company’s settlement of an income tax matter in the first quarter of fiscal 2016 pertaining to its divested ADT Korea business for the 2012 period. This matter is unrelated to the liability established of $212 million during fiscal 2014 which relates to the indemnification for certain tax related matters in connection with the sale. The Company continues to maintain such liability until the matter is resolved.

[0000833444-16-000120:notes:114]
Balance sheet information for the assets and liabilities of businesses classified as held for sale as of December 25, 2015 and September 25, 2015 was as follows ($ in millions):

[0000833444-16-000120:notes:115]
|  | As of |
|  | December 25, 2015 |  | September 25, 2015 |
| Accounts receivable, net | $ | 44 |  |  | $ | 44 |  |
| Inventories | 4 |  |  | 3 |  |
| Prepaid expenses and other current assets | 24 |  |  | 22 |  |
| Deferred income taxes | 1 |  |  | 1 |  |
| Property, plant and equipment, net | — |  |  | 13 |  |
| Goodwill | 3 |  |  | 3 |  |
| Intangible assets, net | 7 |  |  | 16 |  |
| Total assets | $ | 83 |  |  | $ | 102 |  |
| Accounts payable | 10 |  |  | 12 |  |
| Accrued and other current liabilities | 63 |  |  | 26 |  |
| Deferred revenue | 2 |  |  | 2 |  |
| Other liabilities | 9 |  |  | 10 |  |
| Total liabilities | $ | 84 |  |  | $ | 50 |  |

[0000833444-16-000120:notes:116]
Because the Company utilizes a centralized approach to cash management and the financing of its operations, all cash that is generated by discontinued operations is routinely transferred to the Company's financing subsidiaries in continuing operations.  As a result, transfers from discontinued operations within the Company's Consolidated Statement of Cash Flows reflects the net cash movements from discontinued operations to continuing operations that have occurred during the period.


## us-gaap:EarningsPerShareTextBlock

[0000833444-16-000120:notes:117]
[same as prior period, unchanged from 0000833444-15-000062:notes:117]

[0000833444-16-000120:notes:118]
[same as prior period, unchanged from 0000833444-15-000062:notes:118]

[0000833444-16-000120:notes:119]
|  | For the Quarter Ended December 25, 2015 |  | For the Quarter Ended December 26, 2014 |
|  | Income |  | Shares |  | Per ShareAmount |  | Income |  | Shares |  | Per ShareAmount |
| Basic earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations | $ | 72 |  |  | 424 |  |  | $ | 0.17 |  |  | $ | 164 |  |  | 420 |  |  | $ | 0.39 |  |
| Share options and restricted share awards | — |  |  | 4 |  |  |  |  | — |  |  | 7 |  |  |  |
| Diluted earnings per share attributable to Tyco ordinary shareholders: |  |  |  |  |  |  |  |  |  |  |  |
| Income from continuing operations attributable to Tyco ordinary shareholders, giving effect to dilutive adjustments | $ | 72 |  |  | 428 |  |  | $ | 0.17 |  |  | $ | 164 |  |  | 427 |  |  | $ | 0.38 |  |

[0000833444-16-000120:notes:120]
The computation of diluted earnings per share for the quarter ended December 25, 2015 excludes the effect of the potential exercise of share options to purchase approximately 6 million shares and excludes restricted stock units of approximately 2 million shares because the effect would be anti-dilutive.

[0000833444-16-000120:notes:121]
The computation of diluted earnings per share for the quarter ended December 26, 2014 excludes the effect of the potential exercise of share options to purchase approximately 3 million shares and excludes restricted stock units of approximately 2 million shares because the effect would be anti-dilutive.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000833444-16-000120:notes:122]
The following table presents the Company's hierarchy for its assets measured at fair value on a recurring basis as of December 25, 2015 and September 25, 2015 ($ in millions):

[0000833444-16-000120:notes:123]
|  |  |  |  |  |  |  | Consolidated Balance SheetClassification |
|  | As of December 25, 2015 |  | Cash and Cash Equivalents |  | Prepaids andOther CurrentAssets |  | Other Assets |
| Investment Assets: | Level 1 |  | Level 2 |  | Total |  |  |  |
| Cash equivalents | $ | 31 |  |  | $ | — |  |  | $ | 31 |  |  | $ | 31 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Exchange traded funds (fixed income) (1) | 184 |  |  | — |  |  | 184 |  |  | — |  |  | 30 |  |  | 154 |  |
| Exchange traded funds (equity) (1) | 83 |  |  | — |  |  | 83 |  |  | — |  |  | — |  |  | 83 |  |
| Trading securities: |  |  |  |  |  |  |  |  |  |  |  |
| Exchange traded funds (equity) | 62 |  |  | — |  |  | 62 |  |  | — |  |  | 62 |  |  | — |  |
|  | $ | 360 |  |  | $ | — |  |  | $ | 360 |  |  | $ | 31 |  |  | $ | 92 |  |  | $ | 237 |  |

[0000833444-16-000120:notes:124]
|  |  |  |  |  |  |  | Consolidated Balance SheetClassification |
|  | As of September 25, 2015 |  | Cash and Cash Equivalents |  | Prepaids andOther CurrentAssets |  | Other Assets |
| Investment Assets: | Level 1 |  | Level 2 |  | Total |  |  |  |
| Cash equivalents | $ | 909 |  |  | $ | — |  |  | $ | 909 |  |  | $ | 909 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities: |  |  |  |  |  |  |  |  |  |  |  |
| Exchange traded funds (fixed income) (1) | 186 |  |  | — |  |  | 186 |  |  | — |  |  | 15 |  |  | 171 |  |
| Exchange traded funds (equity) (1) | 77 |  |  | — |  |  | 77 |  |  | — |  |  | — |  |  | 77 |  |
| Trading securities: |  |  |  |  |  |  |  |  |  |  |  |
| Exchange traded funds (equity) | 59 |  |  | — |  |  | 59 |  |  | — |  |  | 59 |  |  | — |  |
|  | $ | 1,231 |  |  | $ | — |  |  | $ | 1,231 |  |  | $ | 909 |  |  | $ | 74 |  |  | $ | 248 |  |

[0000833444-16-000120:notes:125]
(1) Classified as restricted investments.  See Note 10.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0000833444-16-000120:notes:126]
[same as prior period, unchanged from 0000833444-15-000062:notes:127]

[0000833444-16-000120:notes:127]
The Company's financial instruments consist primarily of cash and cash equivalents, accounts receivable, investments, accounts payable, debt and derivative financial instruments. The fair value of cash, accounts receivable, and accounts payable approximated book value as of December 25, 2015 and September 25, 2015. The fair value of derivative financial instruments was not material to any of the periods presented. See below for the fair value of cash equivalents and investments and Note 8 for the fair value of debt.

[0000833444-16-000120:notes:128]
[same as prior period, unchanged from 0000833444-15-000062:notes:129]

[0000833444-16-000120:notes:129]
In the normal course of business, Tyco is exposed to market risk arising from changes in currency exchange rates, interest rates and commodity prices. The Company may use derivative financial instruments to manage exposures to foreign currency, interest rate and commodity risks. The Company's objective for utilizing derivative financial instruments is to manage these risks using the most effective methods to eliminate or reduce the impacts of these exposures. The Company does not use derivative financial instruments for trading or speculative purposes.  As of and during the three months ended December 25, 2015, the Company did not hold or enter into any commodity derivative instruments or interest rate swaps.

[0000833444-16-000120:notes:130]
For derivative instruments that are designated and qualified as hedging instruments for accounting purposes, the Company documents and links the relationships between the hedging instruments and hedged items.  The Company also assesses and documents at the hedge's inception whether the derivatives used in hedging transactions are effective in offsetting changes in fair values associated with the hedged items. During the quarter ended March 27, 2015, the Company designated its 2025 Euro notes as a net investment hedge of the Company’s investments in certain of its international subsidiaries that use the Euro as their functional currency and intercompany permanent loans in order to reduce the volatility caused by changes in foreign currency exchange rates of the Euro with respect to the U.S. Dollar. During the three months ended December 25, 2015, the change in the carrying value due to remeasurement of the 2025 Euro notes resulted in a $13 million gain reported in Accumulated other comprehensive loss within the Consolidated Statement of Shareholders' Equity. This hedge did not result in any hedge ineffectiveness for the three months ended December 25, 2015. During the three months ended December 26, 2014, the Company did not have hedging instruments that were designated and qualified as hedging instruments for accounting purposes.

[0000833444-16-000120:notes:131]
Foreign Currency Exposures

[0000833444-16-000120:notes:132]
As of December 25, 2015 and September 25, 2015, the total gross notional amount of the Company's foreign exchange contracts was $620 million and $365 million, respectively. The fair value of these derivative financial instruments and impact of such changes in the fair value was not material to the Consolidated Balance Sheets as of December 25, 2015 and September 25, 2015 or Consolidated Statements of Operations and Consolidated Statements of Cash Flows for the three months ended December 25, 2015 and December 26, 2014.

[0000833444-16-000120:notes:133]
[same as prior period, unchanged from 0000833444-15-000062:notes:133]

[0000833444-16-000120:notes:134]
The use of derivative financial instruments exposes the Company to counterparty credit risk.  Tyco has established policies and procedures to limit its exposure to counterparty credit risk, including establishing limits for credit exposure and continually assessing the creditworthiness of counterparties. As a matter of practice, the Company deals with major banks worldwide having strong investment grade long-term credit ratings. To further reduce the risk of loss, the Company generally enters into International Swaps and Derivatives Association master netting agreements with substantially all of its counterparties.  The Company's derivative contracts do not contain any credit risk related contingent features and do not require collateral or other security to be furnished by the Company or the counterparties.  The Company's exposure to credit risk associated with its derivative instruments is measured on an individual counterparty basis, as well as by groups of counterparties that share similar attributes.  The Company does not anticipate any non-performance by any of its counterparties, and the concentration of risk with financial institutions does not present significant credit risk to the Company. The maximum amount of loss that the Company would incur as of December 25, 2015 without giving consideration to the effects of legally enforceable master netting agreements was not material.

[0000833444-16-000120:notes:135]
[same as prior period, unchanged from 0000833444-15-000062:notes:135]

[0000833444-16-000120:notes:136]
The fair value of cash equivalents approximates carrying value and is included in Level 1.

[0000833444-16-000120:notes:137]
[same as prior period, unchanged from 0000833444-15-000062:notes:137]

[0000833444-16-000120:notes:138]
[same as prior period, unchanged from 0000833444-15-000062:notes:138]

[0000833444-16-000120:notes:139]
[same as prior period, unchanged from 0000833444-15-000062:notes:139]

[0000833444-16-000120:notes:140]
During the quarters ended December 25, 2015 and December 26, 2014, the Company did not have any significant transfers between levels within the fair value hierarchy.

[0000833444-16-000120:notes:141]
The Company recorded an unrealized gain of $2 million for the quarter ended December 25, 2015 within Accumulated other comprehensive loss related to the available-for-sale securities. The Company did not hold available-for-sale securities during the quarter ended December 26, 2014. Unrealized gains and losses related to trading securities were $3 million for both the quarters ended December 25, 2015 and December 26, 2014, which are recorded within Other expense (income), net within the Consolidated Statements of Operations.

[0000833444-16-000120:notes:142]
[same as prior period, unchanged from 0000833444-15-000062:notes:142]

[0000833444-16-000120:notes:143]
The Company had $1.3 billion and $1.4 billion of intercompany loans designated as permanent in nature as of December 25, 2015 and September 25, 2015, respectively.  Additionally, for the quarters ended December 25, 2015 and December 26, 2014, the Company recorded cumulative translation losses of $34 million and $70 million, respectively, through Accumulated other comprehensive loss related to these loans.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000833444-16-000120:notes:144]
[same as prior period, unchanged from 0000833444-15-000062:notes:145]

[0000833444-16-000120:notes:145]
Goodwill

[0000833444-16-000120:notes:146]
[same as prior period, unchanged from 0000833444-15-000062:notes:146]

[0000833444-16-000120:notes:147]
|  | NA Integrated Solutions &Services |  | ROWIntegrated Solutions &Services |  | GlobalProducts |  | Total |
| Gross goodwill | $ | 2,102 |  |  | $ | 1,969 |  |  | $ | 1,809 |  |  | $ | 5,880 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of September 26, 2014 | 1,976 |  |  | 901 |  |  | 1,242 |  |  | 4,119 |  |
| 2015 activity: |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions / purchase accounting adjustments | 23 |  |  | 50 |  |  | 274 |  |  | 347 |  |
| Currency translation | (29 | ) |  | (167 | ) |  | (36 | ) |  | (232 | ) |
| Gross goodwill | $ | 2,096 |  |  | $ | 1,852 |  |  | $ | 2,047 |  |  | $ | 5,995 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of September 25, 2015 | 1,970 |  |  | 784 |  |  | 1,480 |  |  | 4,234 |  |
| 2016 activity: |  |  |  |  |  |  |  |  |  |  |  |
| Acquisitions / purchase accounting adjustments | — |  |  | 157 |  |  | — |  |  | 157 |  |
| Currency translation | (5 | ) |  | (11 | ) |  | (10 | ) |  | (26 | ) |
| Gross goodwill | $ | 2,091 |  |  | $ | 1,998 |  |  | $ | 2,037 |  |  | $ | 6,126 |  |
| Accumulated impairment | (126 | ) |  | (1,068 | ) |  | (567 | ) |  | (1,761 | ) |
| Carrying amount of goodwill as of December 25, 2015 | $ | 1,965 |  |  | $ | 930 |  |  | $ | 1,470 |  |  | $ | 4,365 |  |

[0000833444-16-000120:notes:148]
Intangible Assets

[0000833444-16-000120:notes:149]
Intangible asset amortization expense for the quarters ended December 25, 2015 and December 26, 2014 was $23 million and $21 million, respectively.

[0000833444-16-000120:notes:150]
The estimated aggregate amortization expense on intangible assets is expected to be approximately $89 million for 2016, $92 million for 2017, $86 million for 2018, $80 million for 2019, and $275 million for 2020 and thereafter.


## us-gaap:GuaranteesTextBlock

[0000833444-16-000120:notes:151]
[same as prior period, unchanged from 0000833444-15-000062:notes:150]

[0000833444-16-000120:notes:152]
[same as prior period, unchanged from 0000833444-15-000062:notes:151]

[0000833444-16-000120:notes:153]
There are certain guarantees or indemnifications extended among Tyco, Covidien, TE Connectivity, ADT and Pentair in accordance with the terms of the 2007 and 2012 Separation and Distribution Agreements and Tax Sharing Agreements. These guarantees primarily relate to certain contingent tax liabilities included in the Tax Sharing Agreements. See Note 5.

[0000833444-16-000120:notes:154]
In addition, Tyco historically provided support in the form of financial and/or performance guarantees to various Covidien, TE Connectivity, ADT and Tyco Flow Control operating entities. In connection with both the 2012 and 2007 Separations, the Company worked with the guarantee counterparties to cancel or assign these guarantees to Covidien, TE Connectivity, ADT or Pentair, as appropriate. To the extent these guarantees were not assigned prior to the Separation dates, Tyco remained as the guarantor, but was typically indemnified by the former subsidiary. The Company's obligations related to the 2012 Separation were $3 million, which were included in Other liabilities within the Company's Consolidated Balance Sheets as of both December 25, 2015 and September 25, 2015, with an offset to Tyco's shareholders' equity on the 2012 Separation date. The Company's obligations related to the 2007 Separation were $3 million, which were included in Other liabilities within the Company's Consolidated Balance Sheets as of both December 25, 2015 and September 25, 2015, with an offset to Tyco's shareholders' equity on the 2007 Separation date.

[0000833444-16-000120:notes:155]
In disposing of assets or businesses, the Company or its subsidiaries often provides representations, warranties and/or indemnities to cover various risks including, for example, unknown damage to the assets, environmental risks involved in the sale of real estate, liability to investigate and remediate environmental contamination at waste disposal sites and manufacturing facilities and unidentified tax liabilities and legal fees related to periods prior to disposition. The Company has no reason to believe that these contingencies, if realized, would have a material adverse effect on the Company's financial position, results of operations or cash flows. The Company has recorded liabilities for known indemnifications included as part of environmental liabilities. See Note 10 for further information on environmental matters.

[0000833444-16-000120:notes:156]
[same as prior period, unchanged from 0000833444-15-000062:notes:155]

[0000833444-16-000120:notes:157]
The changes in the carrying amount of the Company's warranty accrual from September 25, 2015 to December 25, 2015 were as follows ($ millions):

[0000833444-16-000120:notes:158]
| Balance as of September 25, 2015 | $ | 29 |  |
| Warranties issued | 3 |  |
| Changes in estimates | (1 | ) |
| Settlements | (2 | ) |
| Balance as of December 25, 2015 | $ | 29 |  |

[0000833444-16-000120:notes:159]
Warranty accruals for businesses that are included in Liabilities held for sale within the Consolidated Balance Sheets are excluded from the table above.  See Note 2.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000833444-16-000120:notes:160]
[same as prior period, unchanged from 0000833444-15-000062:notes:159]

[0000833444-16-000120:notes:161]
Tyco did not have a significant change to its unrecognized tax benefits during the quarter ended December 25, 2015.

[0000833444-16-000120:notes:162]
[same as prior period, unchanged from 0000833444-15-000062:notes:161]

[0000833444-16-000120:notes:163]
| Jurisdiction | Years OpenTo Audit |
| Australia | 2004-2015 |
| Canada | 2006-2015 |
| Germany | 2006-2015 |
| Ireland | 2011-2015 |
| Switzerland | 2005-2015 |
| United Kingdom | 2013-2015 |
| United States | 1997-2015 |

[0000833444-16-000120:notes:164]
Based on the current status of its income tax audits, the Company believes the unrecognized tax benefits that may be resolved in the next twelve months are not expected to be material.

[0000833444-16-000120:notes:165]
At each balance sheet date, the Company evaluates whether it is more likely than not that Tyco's deferred tax assets will be realized and if sufficient future taxable income will be available by assessing current period and projected operating results and other pertinent data. As of December 25, 2015, Tyco recorded deferred tax assets of approximately $294 million, which is comprised of $2.4 billion gross deferred tax assets net of $2.1 billion valuation allowances.

[0000833444-16-000120:notes:166]
[same as prior period, unchanged from 0000833444-15-000062:notes:165]

[0000833444-16-000120:notes:167]
In connection with the 2012 and 2007 Separations, Tyco entered into the 2012 and 2007 Tax Sharing Agreements, respectively, that govern the respective rights, responsibilities, and obligations of (i) Tyco, Pentair plc and ADT Corporation after the 2012 Separation and (ii) Tyco, Covidien (subsequently acquired by Medtronic plc) and TE Connectivity Ltd. after the 2007 Separation, with respect to taxes. Specifically, this includes taxes in the ordinary course of business and taxes, if any, incurred as a result of any failure of the respective distributions to qualify tax-free for U.S. federal income tax purposes within the meaning of Section 355 of the Internal Revenue Code ("the Code") or certain internal transactions undertaken in anticipation of the spin-offs to qualify for tax-favored treatment under the Code.

[0000833444-16-000120:notes:168]
Under the 2012 Tax Sharing Agreement, Tyco, Pentair and ADT share (i) certain pre-Distribution income tax liabilities that arise from adjustments made by tax authorities to ADT's, Tyco Flow Control's and Tyco's income tax returns, and (ii) payments required to be made by Tyco with respect to the 2007 Tax Sharing Agreement, excluding approximately $175 million of pre-2012 Separation related tax liabilities (collectively, "Shared Tax Liabilities"). Tyco will be responsible for the first $500 million of Shared Tax Liabilities. Pentair and ADT will share 42% and 58%, respectively, of the next $225 million of Shared Tax Liabilities. Tyco, Pentair and ADT will share 52.5%, 20% and 27.5%, respectively, of Shared Tax Liabilities above $725 million.  All costs and expenses associated with the management of these Shared Tax Liabilities will generally be shared 20%, 27.5% and 52.5% by Pentair, ADT and Tyco, respectively.  In connection with the execution of the 2012 Tax Sharing Arrangement, Tyco established liabilities representing the fair market value of its obligations which is recorded in Other liabilities within the Company's Consolidated Balance Sheet with an offset to Tyco shareholders' equity.

[0000833444-16-000120:notes:169]
Under the 2007 Tax Sharing Agreement, Tyco shares responsibility for certain of Tyco's, Covidien's and TE Connectivity's income tax liabilities, which result in cash payments, based on a sharing formula for periods prior to and including June 29, 2007. More specifically, Tyco, Covidien and TE Connectivity share 27%, 42% and 31%, respectively, of shared income tax liabilities that arise from adjustments made by tax authorities to Tyco's, Covidien's and TE Connectivity's U.S. and certain non-U.S. income tax returns. The costs and expenses associated with the management of these shared tax liabilities are generally shared equally among the parties. In connection with the execution of the 2007 Tax Sharing Agreement, Tyco established a net receivable from Covidien and TE Connectivity representing the amount Tyco expected to receive for pre-2007 Separation uncertain tax positions, including amounts owed to the Internal Revenue Service ("IRS"). Tyco also established liabilities representing the fair market value of its share of Covidien's and TE Connectivity's estimated obligations, primarily to the IRS, for their pre-2007 Separation taxes covered by the 2007 Tax Sharing Agreement.

[0000833444-16-000120:notes:170]
Tyco assesses the shared tax liabilities and related guaranteed liabilities related to both the 2012 and 2007 Tax Sharing Agreements at each reporting period. Tyco will provide payment to Pentair and ADT under the 2012 Tax Sharing Agreement and Covidien and TE Connectivity under the 2007 Tax Sharing Agreement as the shared income tax liabilities are settled. Settlement is expected to occur as the tax audit and legal processes are completed for the impacted years and cash payments are made. Due to the nature of the unresolved adjustments described in the next paragraph, the maximum amount of future payments under the 2012 and 2007 Tax Sharing Agreements is not known. Such cash payments, when they occur, will reduce the guarantor liability as they represent an equivalent reduction of risk. Tyco also assesses the sufficiency of the 2012 and 2007 Tax Sharing Agreements guarantee liabilities on a quarterly basis and will increase the liability when it is probable that cash payments expected to be made exceed the recorded balance.

[0000833444-16-000120:notes:171]
Assuming the tentative resolution is finalized, Tyco does not expect to recognize any additional charges related to the resolution, as it had previously recorded sufficient reserves with respect to this controversy and its obligations under the Tax Sharing Agreements. Payment is expected to be made to the IRS, and among Tyco, Covidien and TE Connectivity, within the next six months. Accordingly, the Company has presented the liabilities related to the 2007 Tax Sharing Agreement in Accrued and other current liabilities within the Consolidated Balance Sheet as of December 25, 2015.

[0000833444-16-000120:notes:172]
As noted above, Tyco has assessed its obligations under the 2007 Tax Sharing Agreement to determine that its recorded liability is sufficient to cover the indemnifications made by it under such agreement. In the absence of observable transactions for identical or similar guarantees, Tyco determined the fair value of these guarantees and indemnifications utilizing expected present value measurement techniques. Significant assumptions utilized to determine fair value included determining a range of potential outcomes, assigning a probability weighting to each potential outcome and estimating the anticipated timing of resolution. The probability weighted outcomes were discounted using Tyco's incremental borrowing rate.  Until the tentative resolution is finalized, the ultimate resolution of these matters is uncertain and could result in a material adverse impact to the Company's financial position, results of operations, cash flows, or the effective tax rate in future reporting periods.

[0000833444-16-000120:notes:173]
In addition to dealing with tax liabilities for periods prior to the respective Separations, the 2012 and 2007 Tax Sharing Agreements contain sharing provisions to address the contingencies that the 2012 or 2007 Separations, or internal transactions related thereto, may be deemed taxable by U.S. or non U.S. taxing authorities. In the event the 2012 Separation is determined to be taxable and such determination was the result of actions taken after the 2012 Separations by Tyco, ADT or Pentair, the party responsible for such failure would be responsible for all taxes imposed on each company as a result thereof. If such determination is not the result of actions taken by Tyco, ADT or Pentair after the 2012 Separation, then Tyco, ADT and Pentair would be responsible for any taxes imposed on any of the companies as a result of such determination in the same manner and in the same proportions as described above. Similar provisions exist in the 2007 Tax Sharing Agreement. If either of the 2007 or 2012 Separation, or internal transactions taken in anticipation thereof, were deemed taxable, the associated liability could be significant. Tyco is responsible for all of its own taxes that are not shared pursuant to the 2012 and 2007 Tax Sharing Agreements' sharing formulas. In addition, Pentair and ADT, and Covidien and TE Connectivity are responsible for their tax liabilities that are not subject to the 2012 or 2007 Tax Sharing Agreements' sharing formula.

[0000833444-16-000120:notes:174]
[same as prior period, unchanged from 0000833444-15-000062:notes:175]

[0000833444-16-000120:notes:175]
[same as prior period, unchanged from 0000833444-15-000062:notes:177]

[0000833444-16-000120:notes:176]
[same as prior period, unchanged from 0000833444-15-000062:notes:178]


## us-gaap:InventoryDisclosureTextBlock

[0000833444-16-000120:notes:177]
[same as prior period, unchanged from 0000833444-15-000062:notes:179]

[0000833444-16-000120:notes:178]
[same as prior period, unchanged from 0000833444-15-000062:notes:180]

[0000833444-16-000120:notes:179]
|  | As of |
|  | December 25, 2015 |  | September 25, 2015 |
| Purchased materials and manufactured parts | $ | 172 |  |  | $ | 165 |  |
| Work in process | 76 |  |  | 84 |  |
| Finished goods | 399 |  |  | 375 |  |
| Inventories | $ | 647 |  |  | $ | 624 |  |

[0000833444-16-000120:notes:180]
[same as prior period, unchanged from 0000833444-15-000062:notes:182]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000833444-16-000120:notes:181]
[same as prior period, unchanged from 0000833444-15-000062:notes:183]

[0000833444-16-000120:notes:182]
[same as prior period, unchanged from 0000833444-15-000062:notes:184]

[0000833444-16-000120:notes:183]
|  | U.S. Plans |
|  | For the Quarters Ended |
|  | December 25, 2015 |  | December 26, 2014 |
| Service cost | $ | 2 |  |  | $ | 2 |  |
| Interest cost | 8 |  |  | 9 |  |
| Expected return on plan assets | (12 | ) |  | (14 | ) |
| Amortization of net actuarial loss | 3 |  |  | 2 |  |
| Net periodic (benefit) cost | $ | 1 |  |  | $ | (1 | ) |

[0000833444-16-000120:notes:184]
|  | Non-U.S. Plans |
|  | For the Quarters Ended |
|  | December 25, 2015 |  | December 26, 2014 |
| Service cost | $ | 2 |  |  | $ | 2 |  |
| Interest cost | 11 |  |  | 13 |  |
| Expected return on plan assets | (18 | ) |  | (20 | ) |
| Amortization of net actuarial loss | 4 |  |  | 4 |  |
| Net periodic (benefit) cost | $ | (1 | ) |  | $ | (1 | ) |

[0000833444-16-000120:notes:185]
Effective September 26, 2015, the Company changed the approach used to measure service and interest costs for pension benefits.  For fiscal 2015, the Company measured service and interest costs utilizing a single weighted-average discount rate derived from the yield curve used to measure the Company’s plan obligations. For fiscal 2016, the Company elected to measure service and interest costs by applying the specific spot rates along the yield curve over the projected cash flow period.  The Company believes the new approach provides a more precise measurement of service and interest costs by improving the correlation between projected benefit cash flows to the corresponding spot rates on the yield curves. Based on current economic conditions, the Company estimates its periodic pension costs for both its U.S. and non-U.S. plans will be reduced by approximately $6 million each in fiscal 2016 as a result of the change. The Company has accounted for this change as a change in accounting estimate and, accordingly, has accounted for it on a prospective basis.

[0000833444-16-000120:notes:186]
The estimated net actuarial loss for U.S. and non-U.S. pension benefit plans that will be amortized from accumulated other comprehensive loss into net periodic benefit cost over the current fiscal year is expected to be $13 million and $15 million, respectively. Amortization of net periodic benefit cost from Accumulated other comprehensive loss for the Company's pension benefit plans is recorded in Selling, general and administrative expenses, Cost of product sales, or Cost of services within the Consolidated Statements of Operations, depending on the employee job classification.

[0000833444-16-000120:notes:187]
The Company's funding policy is to make contributions in accordance with the laws and customs of the various countries in which it operates and to make discretionary voluntary contributions from time to time. The Company anticipates that it will contribute at least the minimum required to its pension plans in fiscal year 2016 of $3 million for U.S. plans and $25 million for non-U.S. plans.

[0000833444-16-000120:notes:188]
During the quarter ended December 25, 2015, the Company made required contributions of nil to its U.S. pension plans and $11 million to its non-U.S. pension plans.  The Company did not make any voluntary contributions to its U.S. and non-U.S. plans during the quarter ended December 25, 2015.

[0000833444-16-000120:notes:189]
[same as prior period, unchanged from 0000833444-15-000062:notes:189]


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000833444-16-000120:notes:190]
[same as prior period, unchanged from 0000833444-15-000062:notes:190]

[0000833444-16-000120:notes:191]
[same as prior period, unchanged from 0000833444-15-000062:notes:191]

[0000833444-16-000120:notes:192]
|  | As of |
|  | December 25, 2015 |  | September 25, 2015 |
| Land | $ | 33 |  |  | $ | 33 |  |
| Buildings | 413 |  |  | 405 |  |
| Subscriber systems | 1,855 |  |  | 1,933 |  |
| Machinery and equipment | 1,263 |  |  | 1,252 |  |
| Construction in progress | 87 |  |  | 81 |  |
| Accumulated depreciation | (2,484 | ) |  | (2,527 | ) |
| Property, plant and equipment, net | $ | 1,167 |  |  | $ | 1,177 |  |


## us-gaap:RestructuringImpairmentAndOtherActivitiesDisclosureTextBlock

[0000833444-16-000120:notes:193]
[same as prior period, unchanged from 0000833444-15-000062:notes:193]

[0000833444-16-000120:notes:194]
During fiscal 2016, the Company identified and pursued additional opportunities for cost savings through restructuring activities and workforce reductions to improve operating efficiencies across the Company's businesses. The Company expects to incur restructuring and restructuring related charges between $50 million and $75 million in fiscal 2016, which does not include repositioning charges, as described below.

[0000833444-16-000120:notes:195]
[same as prior period, unchanged from 0000833444-15-000062:notes:195]

[0000833444-16-000120:notes:196]
|  | For the Quarters Ended |
|  | December 25, 2015 |  | December 26, 2014 |
| 2016 actions | $ | 9 |  |  | $ | — |  |
| 2015 actions | 3 |  |  | 44 |  |
| 2014 and prior actions | — |  |  | 14 |  |
| Total | $ | 12 |  |  | $ | 58 |  |

[0000833444-16-000120:notes:197]
2016 Actions

[0000833444-16-000120:notes:198]
Restructuring and asset impairment charges, net, during the quarter ended December 25, 2015 related to the 2016 actions are as follows ($ in millions):

[0000833444-16-000120:notes:199]
|  | For the Quarter Ended December 25, 2015 |
|  | EmployeeSeverance andBenefits |  | Facility Exit and Other Charges |  | Total |
| NA Integrated Solutions & Services | $ | 2 |  |  | $ | — |  |  | $ | 2 |  |
| ROW Integrated Solutions & Services | 1 |  |  | — |  |  | 1 |  |
| Global Products | 2 |  |  | 1 |  |  | 3 |  |
| Corporate and other | 3 |  |  | — |  |  | 3 |  |
| Total | $ | 8 |  |  | $ | 1 |  |  | $ | 9 |  |

[0000833444-16-000120:notes:200]
The rollforward of the reserves from September 25, 2015 to December 25, 2015 is as follows ($ in millions):

[0000833444-16-000120:notes:201]
| Balance as of September 25, 2015 | $ | — |  |
| Charges | 9 |  |
| Utilization | (2 | ) |
| Balance as of December 25, 2015 | $ | 7 |  |

[0000833444-16-000120:notes:202]
Restructuring reserves for businesses that are included in Liabilities held for sale within the Consolidated Balance Sheets are excluded from the table above.  See Note 2.

[0000833444-16-000120:notes:203]
[same as prior period, unchanged from 0000833444-15-000062:notes:197]

[0000833444-16-000120:notes:204]
Restructuring and asset impairment charges, net, during the quarters ended December 25, 2015 and December 26, 2014 related to the 2015 actions are as follows ($ in millions):

[0000833444-16-000120:notes:205]
|  | For the Quarter Ended December 25, 2015 |  | For the Quarter Ended December 26, 2014 |
|  | EmployeeSeverance andBenefits |  | EmployeeSeverance andBenefits |
| NA Integrated Solutions & Services | $ | 2 |  |  | $ | 22 |  |
| ROW Integrated Solutions & Services | — |  |  | 10 |  |
| Global Products | — |  |  | 2 |  |
| Corporate and Other | 1 |  |  | 10 |  |
| Total | $ | 3 |  |  | $ | 44 |  |

[0000833444-16-000120:notes:206]
Restructuring and asset impairment charges, net, incurred cumulative to date from initiation of the 2015 actions are as follows ($ in millions):

[0000833444-16-000120:notes:207]
|  | EmployeeSeverance andBenefits |  | Facility Exitand OtherCharges |  | Charges Reflected in SG&A |  | Total |
| NA Integrated Solutions & Services | $ | 43 |  |  | $ | 3 |  |  | $ | 1 |  |  | $ | 47 |  |
| ROW Integrated Solutions & Services | 81 |  |  | 9 |  |  | 1 |  |  | 91 |  |
| Global Products | 21 |  |  | 1 |  |  | (1 | ) |  | 21 |  |
| Corporate and Other | 21 |  |  | 1 |  |  | — |  |  | 22 |  |
| Total | $ | 166 |  |  | $ | 14 |  |  | $ | 1 |  |  | $ | 181 |  |

[0000833444-16-000120:notes:208]
| Balance as of September 25, 2015 | $ | 117 |  |
| Charges | 5 |  |
| Reversals | (2 | ) |
| Utilization | (18 | ) |
| Currency translation | (2 | ) |
| Balance as of December 25, 2015 | $ | 100 |  |

[0000833444-16-000120:notes:209]
2014 and prior actions

[0000833444-16-000120:notes:210]
The Company continues to maintain restructuring reserves related to actions initiated prior to fiscal 2015. The total amount of these reserves was $31 million and $38 million as of December 25, 2015 and September 25, 2015, respectively. The Company incurred nil and $14 million of restructuring charges and utilized $6 million and $16 million for the quarters ended December 25, 2015 and December 26, 2014, respectively, related to 2014 and prior actions. The remaining change in reserve during the quarters ended December 25, 2015 and December 26, 2014 relates to currency translation. The aggregate remaining reserves relate to employee severance and benefits as well as facility exit costs for long-term non-cancelable lease obligations primarily within the Company's NA Integrated Solutions & Services and ROW Integrated Solutions & Services segments.

[0000833444-16-000120:notes:211]
[same as prior period, unchanged from 0000833444-15-000062:notes:213]

[0000833444-16-000120:notes:212]
[same as prior period, unchanged from 0000833444-15-000062:notes:214]

[0000833444-16-000120:notes:213]
The Company has initiated certain global actions designed to reduce its cost structure and improve future profitability by streamlining operations and better aligning functions, which the Company refers to as repositioning actions. These actions may or may not lead to a future restructuring action. During the quarters ended December 25, 2015 and December 26, 2014, the Company recorded net repositioning charges of $6 million and $17 million, respectively, primarily related to professional fees which have been reflected in Selling, general and administrative expenses within the Consolidated Statements of Operations.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0000833444-16-000120:notes:214]
A summary of the changes in each component of Accumulated other comprehensive loss, net of tax, for the three months ended December 25, 2015 and December 26, 2014 are as follows ($ in millions):

[0000833444-16-000120:notes:215]
|  | CurrencyTranslationAdjustments |  | Unrealized Gain(Loss) onMarketableSecurities andDerivativeInstruments |  | RetirementPlans |  | Accumulated OtherComprehensive Loss |
| Balance as of September 25, 2015 | $ | (1,233 | ) |  | $ | (9 | ) |  | $ | (599 | ) |  | $ | (1,841 | ) |
| Other comprehensive (loss) income, net of tax | (43 | ) |  | 1 |  |  | — |  |  | (42 | ) |
| Amounts reclassified from accumulated other comprehensive income, net of tax | — |  |  | — |  |  | 5 |  |  | 5 |  |
| Net current period other comprehensive (loss) income | $ | (43 | ) |  | $ | 1 |  |  | $ | 5 |  |  | $ | (37 | ) |
| Balance as of December 25, 2015 | $ | (1,276 | ) |  | $ | (8 | ) |  | $ | (594 | ) |  | $ | (1,878 | ) |

[0000833444-16-000120:notes:216]
|  | CurrencyTranslationAdjustments |  | RetirementPlans |  | Accumulated OtherComprehensive Loss |
| Balance as of September 26, 2014 | $ | (693 | ) |  | $ | (532 | ) |  | $ | (1,225 | ) |
| Other comprehensive (loss) income, net of tax | (198 | ) |  | — |  |  | (198 | ) |
| Amounts reclassified from accumulated other comprehensive income, net of tax | — |  |  | 5 |  |  | 5 |  |
| Net current period other comprehensive (loss) income | $ | (198 | ) |  | $ | 5 |  |  | $ | (193 | ) |
| Balance as of December 26, 2014 | $ | (891 | ) |  | $ | (527 | ) |  | $ | (1,418 | ) |


## us-gaap:ScheduleOfComprehensiveIncomeLossTableTextBlock

[0000833444-16-000120:notes:217]
[same as prior period, unchanged from 0000833444-15-000062:notes:220]

[0000833444-16-000120:notes:218]
|  | For the Quarters Ended |
|  | December 25, 2015 |  | December 26, 2014 |
| Net income | $ | 76 |  |  | $ | 161 |  |
| Foreign currency translation(1) | (43 | ) |  | (198 | ) |
| Amortization of net actuarial losses (2) | 7 |  |  | 6 |  |
| Income tax expense | (2 | ) |  | (1 | ) |
| Defined benefit and post retirement plans, net of tax | 5 |  |  | 5 |  |
| Unrealized gain on marketable securities and derivative instruments (3) | 2 |  |  | — |  |
| Income tax expense | (1 | ) |  | — |  |
| Unrealized gain on marketable securities and derivative instruments, net of tax | 1 |  |  | — |  |
| Total other comprehensive loss, net of tax | (37 | ) |  | (193 | ) |
| Comprehensive income (loss) | 39 |  |  | (32 | ) |
| Less: comprehensive loss attributable to noncontrolling interests | — |  |  | (1 | ) |
| Comprehensive income (loss) attributable to Tyco ordinary shareholders | $ | 39 |  |  | $ | (31 | ) |

[0000833444-16-000120:notes:219]
(1) Includes a $13 million gain related to the net investment hedge for the quarter ended December 25, 2015.  The Company did not hold this net investment hedge during the quarter ended December 26, 2014.  See Note 9.

[0000833444-16-000120:notes:220]
(2) Reclassified to net periodic (benefit) cost.  See Note 11.

[0000833444-16-000120:notes:221]
(3) When sold, the gain (loss) will be reclassified to realized gain (loss) on marketable securities and derivative instruments and be recorded in Other (expense) income, net within the Consolidated Statements of Operations.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000833444-16-000120:notes:222]
[same as prior period, unchanged from 0000833444-15-000062:notes:224]

[0000833444-16-000120:notes:223]
Effective for the first quarter of fiscal 2016, the Company has elected to present operating income by segment, as well as Corporate and Other, excluding restructuring and repositioning charges, net.  Restructuring and repositioning charges, net, are shown in aggregate. This measure of segment operating income (loss) is consistent with how management reviews the businesses, makes investing and resource decisions and assesses operating performance. Comparative periods presented have been reclassified to conform with the current period presentation.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000833444-16-000120:notes:224]
[same as prior period, unchanged from 0000833444-15-000062:notes:226]

[0000833444-16-000120:notes:225]
[same as prior period, unchanged from 0000833444-15-000062:notes:227]

[0000833444-16-000120:notes:226]
As of December 25, 2015 and September 25, 2015, the Company's authorized share capital amounted to $11,000,000 and €40,000, divided into 1,000,000,000 ordinary shares with a par value of $0.01 per share, 100,000,000 preferred shares with a par value of $0.01 per share and 40,000 ordinary A shares with a par value of €1.00 per share.  The authorized share capital includes 40,000 ordinary A shares with a par value of €1.00 per share in order to satisfy statutory requirements for the incorporation of all Irish public limited companies. Tyco Ireland may issue shares subject to the maximum prescribed by its authorized share capital contained in its memorandum of association. In connection with the re-domicile to Ireland, the Company canceled all the outstanding treasury shares, including shares held by subsidiaries, with an offsetting reduction in Additional paid in capital.

[0000833444-16-000120:notes:227]
[same as prior period, unchanged from 0000833444-15-000062:notes:229]

[0000833444-16-000120:notes:228]
The Company issued one authorized ordinary share in exchange for each ordinary share of Tyco Switzerland to the former shareholders of Tyco Switzerland.  All ordinary shares issued at the effective time of the re-domicile were issued as fully paid-up and non-assessable.

[0000833444-16-000120:notes:229]
[same as prior period, unchanged from 0000833444-15-000062:notes:231]

[0000833444-16-000120:notes:230]
The authority to declare and pay dividends is vested in the Board of Directors. The timing, declaration and payment of future dividends to holders of the Company's ordinary shares will be determined by the Company's Board of Directors and will depend upon many factors, including the Company's financial condition and results of operations, the capital requirements of the Company's businesses, industry practice and any other relevant factors.

[0000833444-16-000120:notes:231]
Under Irish law, dividends may only be paid (and share repurchases and redemptions must generally be funded) out of “distributable reserves.” The creation of distributable reserves was accomplished by way of a capital reduction, which the Irish High Court approved on December 18, 2014.

[0000833444-16-000120:notes:232]
On December 8, 2015, the Company declared a quarterly dividend of $0.205 per share, payable on February 17, 2016 to shareholders of record on January 22, 2016. On September 3, 2015, the Company declared a quarterly dividend of $0.205 per share, paid on November 12, 2015 to shareholders of record on October 23, 2015.

[0000833444-16-000120:notes:233]
On March 5, 2014, the Company's shareholders approved an annual cash dividend of $0.72 per ordinary share.  Payment of the dividend was made in four quarterly installments of $0.18 from May 2014 through February 2015.  As a result, during the quarter ended March 28, 2014, the Company recorded an accrued dividend of $332 million within Accrued and other current liabilities and a corresponding reduction to Contributed surplus within the Company's Consolidated Balance Sheet.

[0000833444-16-000120:notes:234]
[same as prior period, unchanged from 0000833444-15-000062:notes:236]

[0000833444-16-000120:notes:235]
The Company's Board of Directors approved $1.75 billion and $1 billion share repurchase programs in March 2014 and September 2014, respectively.  No shares were repurchased during the quarter ended December 25, 2015.  During the quarter ended December 26, 2014, the Company repurchased a total of approximately 10 million shares for approximately $417 million which completed the $1.75 billion share repurchase program.  As of December 25, 2015, a total of approximately $1 billion in share repurchase authority remained outstanding.

[0000833444-16-000120:notes:236]
Comprehensive Income (Loss)


## us-gaap:SubsequentEventsTextBlock

[0000833444-16-000120:notes:237]
On January 24, 2016, Tyco entered into an Agreement and Plan of Merger (the “Merger Agreement”) with Johnson Controls, Inc., a Wisconsin corporation (“JCI”), and certain other parties named therein, including Jagara Merger Sub LLC, a Wisconsin limited liability company and indirect wholly owned subsidiary of Tyco (“Merger Sub”). Pursuant to the Merger Agreement and subject to the terms and conditions set forth therein, Merger Sub will merge with and into JCI (the “Merger”), with JCI surviving the Merger as an indirect wholly owned subsidiary of Tyco. At the effective time of the Merger, Tyco will change its name to “Johnson Controls plc” and will trade under the ticker symbol “JCI.” Following such time, Tyco is referred to below as the “Combined Company.”

[0000833444-16-000120:notes:238]
As a result of the Merger, each outstanding share of JCI common stock (the “JCI Shares”), other than shares held by JCI, its subsidiaries, Tyco or Merger Sub, will be converted into the right to receive (subject to proration as described below), at the holder’s election, either: (i) one (1) (the “Exchange Ratio”) ordinary share of the Combined Company (the “Share Consideration”); or (ii) an amount in cash equal to $34.88 (the “Cash Consideration”). Elections will be prorated so that JCI shareholders will receive in the aggregate approximately $3.864 billion of cash in the Merger (the “Aggregate Cash Consideration”). Holders that do not make an election will be treated as having elected to receive the Share Consideration. The Exchange Ratio takes into account the effects of a Tyco share consolidation contemplated by the Merger Agreement whereby, immediately prior to the Merger, every issued and unissued ordinary share of Tyco (each, a “Tyco Share”) will be consolidated into 0.955 of a share of Tyco.

[0000833444-16-000120:notes:239]
The completion of the Merger is subject to certain closing conditions, including, among others, (i) the approval and adoption of the Merger Agreement by holders of two-thirds of the JCI Shares entitled to vote on such matter, (ii) the approval by the Tyco shareholders, at a special meeting of the Tyco shareholders (the “Tyco Special Meeting”) of (A) the issuance of Tyco shares in connection with the Merger, (B) the Tyco share consolidation and (C) the increase in Tyco’s authorized share capital, in each case, by a majority of the votes cast on these matters at the Tyco Special Meeting, and of certain amendments to Tyco’s articles of association, including a change of its name to “Johnson Controls plc,” by at least 75% of the votes cast on these matters at the Tyco Special Meeting (clause (ii), collectively, the “Tyco Shareholder Approvals”), (iii) the expiration or termination of any waiting period applicable to the Merger under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, the consent of, or filing with, certain specified antitrust authorities, and certain other customary regulatory approvals, and (iv) Tyco’s obtaining the financing required to close the Merger on the terms set forth in the Merger Agreement.

[0000833444-16-000120:notes:240]
The Merger Agreement contains specified termination rights, including, among others, the right of either party to terminate the Merger Agreement (i) if the requisite shareholder approvals have not been obtained, (ii) if the board of directors of the other party effects a change of recommendation, (iii) if the closing has not occurred by October 24, 2016, subject to extension to January 24, 2017 in certain circumstances, (iv) in response to certain intervening events (subject to the limitations set forth in the Merger Agreement) or (v) if there is a material breach by the other party of any of its representations, warranties or covenants, subject to certain conditions.

[0000833444-16-000120:notes:241]
Tyco expects to finance the cash consideration for the Merger and fees and expenses related to the transactions with up to $4 billion of debt financing. Citigroup Global Markets, Inc. (“CGMI”) is providing committed bridge financing in connection with the Merger.

[0000833444-16-000120:notes:242]
In connection with the contemplated debt financing, TIFSA entered into a commitment letter (the “Term Loan Commitment Letter”) with CGMI, dated as of January 24, 2016, pursuant to which CGMI has, subject to the terms and conditions set forth in the Term Loan Commitment Letter, (i) agreed to use commercially reasonable efforts to arrange a syndicate of lenders that will participate in a three-and-a-half year senior unsecured term loan facility (the “Term Facility,” and the provision of such funds as set forth in the Term Loan Commitment Letter, the “Term Financing”) in an aggregate principal amount of up to $4 billion and (ii) committed to provide up to $400 million of the Term Facility. The Term Facility is available to finance all or a portion of the cash consideration for the Merger and to pay fees and expenses related to the transactions. The borrower under the Term Facility will be Tyco International Holding S.a.r.l. (the “Borrower”), a Luxembourg company and a direct wholly-owned subsidiary of TIFSA.

[0000833444-16-000120:notes:243]
In connection with the contemplated debt financing, TIFSA also entered into a commitment letter (the “Bridge Commitment Letter”) with CGMI, dated as of January 24, 2016, pursuant to which CGMI has committed to provide to the Borrower, subject to the terms and conditions set forth in the Bridge Commitment Letter, the full amount of a 364-day $4 billion senior unsecured bridge loan facility (the “Bridge Facility,” and the provision of such funds as set forth in the Bridge Commitment Letter, the “Bridge Financing”). The Bridge Facility is available to finance all or a portion of the cash consideration for the Merger and to pay fees and expenses related to the transactions to the extent that the Term Facility is not available to finance such amounts.

[0000833444-16-000120:notes:244]
The commitments with respect to both the Term Financing and the Bridge Financing are subject to certain customary closing conditions, including, in the case of the Term Financing, the receipt of commitments from other lenders for the remainder of the Term Facility not committed by CGMI, and in the case of both the Term Financing and the Bridge Financing, the consummation of the Merger in accordance with the terms of the Merger Agreement. Both the Term Facility and the Bridge Facility will contain certain representations and warranties, certain affirmative covenants, certain negative covenants, a financial covenant, and events of default, in each case applicable to the Borrower and, where appropriate, its subsidiaries, that are customarily required for similar financings. In addition, the Bridge Financing will be subject to certain customary mandatory commitment reduction and prepayment events triggered by receipt of proceeds of debt and equity issuances and material asset sales, subject to customary exceptions, and the commitments for the Bridge Financing will be automatically reduced by the amount of commitments for the Term Facility, once the Borrower enters into definitive agreements for such term financing.
