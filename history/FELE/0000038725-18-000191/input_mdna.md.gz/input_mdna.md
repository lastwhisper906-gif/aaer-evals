# FELE MD&A — 0000038725-18-000191


## mdna

[0000038725-18-000191:mdna:1]
[same as prior period, unchanged from 0000038725-18-000152:mdna:1]

[0000038725-18-000191:mdna:2]
Third Quarter 2018 vs. Third Quarter 2017

[0000038725-18-000191:mdna:3]
[same as prior period, unchanged from 0000038725-18-000152:mdna:3]

[0000038725-18-000191:mdna:4]
Sales in the third quarter of 2018 increased from the third quarter last year.  The sales increase was led by acquisition related sales, as well as all segments had sales increases from volume and price. The impact on sales due to foreign currency translation was a reduction of about 4 percent. The Company's consolidated gross profit was $113.0 million for the third quarter of 2018, an increase of $9.2 million or about 9 percent from the prior year’s third quarter. Earnings per share in the third quarter of 2018 were up to the same period last year by about 21 percent.

[0000038725-18-000191:mdna:5]
[same as prior period, unchanged from 0000038725-18-000152:mdna:5]

[0000038725-18-000191:mdna:6]
[same as prior period, unchanged from 0000038725-18-000152:mdna:6]

[0000038725-18-000191:mdna:7]
Net sales in the third quarter of 2018 were $341.9 million, an increase of $30.8 million or about 10 percent compared to 2017 third quarter sales of $311.1 million.  Acquisition related sales were $13.4 million. Sales revenue decreased by $11.2 million or about 4 percent in the third quarter of 2018 due to foreign currency translation.

[0000038725-18-000191:mdna:8]
|  | Net Sales |
| (In millions) | Q3 2018 |  | Q3 2017 |  | 2018 v 2017 |
| Water Systems | $ | 198.3 |  |  | $ | 196.0 |  |  | $ | 2.3 |  |
| Fueling Systems | 78.8 |  |  | 64.1 |  |  | 14.7 |  |
| Distribution | 78.0 |  |  | 68.1 |  |  | 9.9 |  |
| Eliminations/Other | (13.2 | ) |  | (17.1 | ) |  | 3.9 |  |
| Consolidated | $ | 341.9 |  |  | $ | 311.1 |  |  | $ | 30.8 |  |

[0000038725-18-000191:mdna:9]
[same as prior period, unchanged from 0000038725-18-000152:mdna:9]

[0000038725-18-000191:mdna:10]
Water Systems sales were $198.3 million in the third quarter 2018, an increase of $2.3 million or about 1 percent versus the third quarter 2017 sales of $196.0 million. In the third quarter of 2018, sales from businesses acquired since the third quarter of 2017 were $3.9 million. Water Systems sales were reduced by $10.6 million or about 5 percent in the quarter due to foreign currency translation. Water Systems sales, excluding acquisitions and the impact of foreign currency translation, were up about 5 percent compared to the third quarter 2017.

[0000038725-18-000191:mdna:11]
Water Systems sales in the U.S. and Canada increased by about 9 percent compared to the third quarter 2017. The impact of foreign currency translation decreased sales by about 1 percent. Sales of Pioneer branded dewatering equipment increased by over 70 percent in the third quarter when compared to the prior year due to continued strength in North American oil and gas markets and diversification of product sales channels and geographies. Sales of other surface pumping equipment increased by about 6 percent primarily due to stronger HVAC and wastewater product sales, versus the third quarter 2017. Sales of

[0000038725-18-000191:mdna:12]
groundwater pumping equipment decreased by about 5 percent on lower residential and agricultural system sales, versus the third quarter 2017.

[0000038725-18-000191:mdna:13]
Water Systems sales in markets outside the U.S. and Canada declined by 6 percent overall. The impact of foreign currency translation decreased sales by about 10 percent. International Water Systems local currency sales improved in Europe, the Middle East, and Africa, but were offset by lower sales in Asia Pacific and Brazil when compared to the third quarter 2017.   Combined, sales in Asia Pacific and Brazil declined by about 9 percent excluding acquisitions and the impact of foreign currency translation.  In Asia Pacific, the Company’s sales decline was nearly all related to lower sales activity in Thailand where sales were adversely impacted by reductions in government funding for water related projects.  In Brazil, the Company’s sales decreased due to an overall slowdown of the economic environment.

[0000038725-18-000191:mdna:14]
[same as prior period, unchanged from 0000038725-18-000152:mdna:13]

[0000038725-18-000191:mdna:15]
Fueling Systems sales were $78.8 million in the third quarter 2018, an increase of $14.7 million or about 23 percent versus the third quarter 2017 sales of $64.1 million. In the third quarter of 2018, sales from businesses acquired since the third quarter of 2017 were $1.3 million.  Fueling Systems sales decreased by $0.6 million or about 1 percent in the quarter due to foreign currency translation. Fueling Systems organic sales increased about 22 percent compared to the third quarter of 2017.

[0000038725-18-000191:mdna:16]
Fueling Systems sales in the U.S. and Canada increased by about 9 percent compared to the third quarter 2017.  The increase was principally in the fuel management, piping and containment systems product lines.  Outside the U.S. and Canada, Fueling Systems revenues grew by about 47 percent, led by stronger sales in China, India and Latin America.  Sales in China were $14.9 million in the third quarter of 2018 compared to third quarter of 2017 sales in China of $6.5 million.

[0000038725-18-000191:mdna:17]
[same as prior period, unchanged from 0000038725-18-000152:mdna:16]

[0000038725-18-000191:mdna:18]
Distribution sales were $78.0 million in the third quarter 2018, versus third quarter 2017 sales of $68.1 million. In the third quarter of 2018, sales from businesses acquired since the third quarter of 2017 were $8.2 million. The Distribution segment organic sales increased about 2 percent compared to the third quarter of 2017.

[0000038725-18-000191:mdna:19]
[same as prior period, unchanged from 0000038725-18-000152:mdna:18]

[0000038725-18-000191:mdna:20]
Cost of sales as a percent of net sales for the third quarter of 2018 and 2017 was 67.0 percent and 66.6 percent, respectively.  Correspondingly, the gross profit margin as a percent of net sales was 33.0 percent in the third quarter of 2018 compared to 33.4 percent in the third quarter of 2017.  The Company's consolidated gross profit was $113.0 million for the third quarter of 2018, an increase of $9.2 million from the gross profit of $103.8 million in the third quarter of 2017. The gross profit increase was primarily due to higher sales. In the third quarter, management believes raw material inflation slightly exceeded achieved sales price increases but that on a year to date basis, through September, raw material inflation has been offset with achieved sales price increases.

[0000038725-18-000191:mdna:21]
[same as prior period, unchanged from 0000038725-18-000152:mdna:20]

[0000038725-18-000191:mdna:22]
Selling, general, and administrative (SG&A) expenses were $72.5 million in the third quarter of 2018 compared to $70.9 million in the third quarter of the prior year.  The increase in SG&A expenses from acquired businesses was $2.9 million.  Excluding the acquired entities, the Company’s SG&A expenses in the third quarter of 2018 were $69.6 million, a decrease of about 2 percent from the third quarter 2017, due primarily to the effect of foreign currency translations in the third quarter of 2018 versus the prior year.

[0000038725-18-000191:mdna:23]
[same as prior period, unchanged from 0000038725-18-000152:mdna:22]

[0000038725-18-000191:mdna:24]
Restructuring expenses for the third quarter of 2018 were $0.3 million, primarily in the Distribution segment and related to miscellaneous branch closings and consolidation. Restructuring expenses for the third quarter of 2017 were $1.0 million, all in the Water segment and primarily from manufacturing realignment activities in Brazil.

[0000038725-18-000191:mdna:25]
[same as prior period, unchanged from 0000038725-18-000152:mdna:24]

[0000038725-18-000191:mdna:26]
Operating income was $40.1 million in the third quarter of 2018, up $8.1 million or 25 percent from $32.0 million in the third quarter of 2017.

[0000038725-18-000191:mdna:27]
|  |  | Operating income (loss) |
| (In millions) |  | Q3 2018 |  | Q3 2017 |  | 2018 v 2017 |
| Water Systems |  | $ | 28.4 |  |  | $ | 28.3 |  |  | $ | 0.1 |  |
| Fueling Systems |  | 20.9 |  |  | 17.1 |  |  | 3.8 |  |
| Distribution |  | 3.1 |  |  | 2.0 |  |  | 1.1 |  |
| Eliminations/Other |  | (12.3 | ) |  | (15.4 | ) |  | 3.1 |  |
| Consolidated |  | $ | 40.1 |  |  | $ | 32.0 |  |  | $ | 8.1 |  |

[0000038725-18-000191:mdna:28]
[same as prior period, unchanged from 0000038725-18-000152:mdna:27]

[0000038725-18-000191:mdna:29]
Water Systems operating income was $28.4 million in the third quarter 2018, flat compared to the $28.3 million in the third quarter 2017.  Operating income margin was 14.3 percent compared to the 14.4 percent in the third quarter 2017. Operating income growth in the U.S. and Canada was offset by declines in international regions, in part due to weakening foreign currencies versus the U.S. dollar.

[0000038725-18-000191:mdna:30]
[same as prior period, unchanged from 0000038725-18-000152:mdna:29]

[0000038725-18-000191:mdna:31]
Fueling Systems operating income was $20.9 million in the third quarter of 2018, up $3.8 million or about 22 percent compared to $17.1 million in the third quarter of 2017.  The increase in operating income was primarily due to higher sales. The third quarter of 2018 operating income margin was 26.5 percent versus the 26.7 percent of net sales in the third quarter of 2017.

[0000038725-18-000191:mdna:32]
[same as prior period, unchanged from 0000038725-18-000152:mdna:31]

[0000038725-18-000191:mdna:33]
Distribution operating income was $3.1 million in the third quarter of 2018 and the third quarter operating income margin was 4.0 percent. Distribution operating income was $2.0 million in the third quarter of 2017 and the third quarter operating income margin was 2.9 percent.

[0000038725-18-000191:mdna:34]
[same as prior period, unchanged from 0000038725-18-000152:mdna:34]

[0000038725-18-000191:mdna:35]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses.  The inter-segment profit elimination impact in the third quarter of 2018 was about $1.0 million of income. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until the transferred product is sold from the Distribution segment to its customer. In the third quarter of 2018 the Distribution segment lowered inventory levels of Water Systems products.  Unallocated general and administrative expenses were higher by $0.3 million or about 2 percent.

[0000038725-18-000191:mdna:36]
[same as prior period, unchanged from 0000038725-18-000152:mdna:36]

[0000038725-18-000191:mdna:37]
Interest expense for the third quarter of 2018 and 2017 was $2.4 million and $2.3 million, respectively.

[0000038725-18-000191:mdna:38]
[same as prior period, unchanged from 0000038725-18-000152:mdna:38]

[0000038725-18-000191:mdna:39]
Other income or expense was a loss of $0.4 million and a gain of $0.4 million in the third quarter of 2018 and 2017, respectively. Included in other income in the third quarter of 2018 and 2017 was interest income of $0.1 million and $0.2 million, respectively, primarily derived from the investment of cash balances in short-term securities. Also included in other income in the third quarter of 2018 was a loss of $0.3 million related to the write-off of a tax indemnification asset.  Other income in the third quarter of 2017 included a gain of $0.4 million on the previously held equity investments in three Distribution entities.

[0000038725-18-000191:mdna:40]
[same as prior period, unchanged from 0000038725-18-000152:mdna:40]

[0000038725-18-000191:mdna:41]
Foreign currency-based transactions produced a loss for the third quarter of 2018 of $1.6 million, primarily due to changes in the Turkish Lira, South African Rand and Brazilian Real relative to the U.S. dollar. Foreign currency-based transactions produced a gain for the third quarter of 2017 of $0.2 million, due to movements in several currencies relative to the U.S. dollar, none of which individually were significant.

[0000038725-18-000191:mdna:42]
[same as prior period, unchanged from 0000038725-18-000152:mdna:42]

[0000038725-18-000191:mdna:43]
The provision for income taxes in the third quarter of 2018 and 2017 was $5.7 million and $5.8 million, respectively. The effective tax rate for the third quarter of 2018 was about 16 percent and, before the impact of discrete events, was about 20 percent. Discrete events in the third quarter included excess tax benefits on stock-based compensation and the statute expiration of uncertain tax positions. The effective tax rate for the third quarter of 2017 was about 19 percent; however, before the impact of discrete events, the tax rate was about 23 percent. Discrete events in the third quarter 2017 included excess tax benefits on stock-based compensation. The tax rate as a percentage of pre-tax earnings for the full year of 2018 is projected to be about 20

[0000038725-18-000191:mdna:44]
percent, compared to the full year 2017 tax rate of about 25 percent, both before adjustments for discrete tax events. The decrease in the effective tax rate was primarily affected by the Tax Act, which reduced the U.S. federal corporate income tax rate from 35 percent to 21 percent effective January 1, 2018. The Company has estimated a tax benefit for the full year 2018 of about $3 million associated with the FDII provisions of the Tax Act that were effective for the first time during 2018.

[0000038725-18-000191:mdna:45]
[same as prior period, unchanged from 0000038725-18-000152:mdna:44]

[0000038725-18-000191:mdna:46]
Net income for the third quarter of 2018 was $29.9 million compared to the prior year third quarter net income of $24.5 million.  Net income attributable to Franklin Electric Co., Inc. for the third quarter of 2018 was $30.0 million, or $0.63 per diluted share, compared to the prior year third quarter net income attributable to Franklin Electric Co., Inc. of $24.5 million or $0.52 per diluted share.

[0000038725-18-000191:mdna:47]
First Nine Months of 2018 vs. First Nine Months of 2017

[0000038725-18-000191:mdna:48]
[same as prior period, unchanged from 0000038725-18-000152:mdna:47]

[0000038725-18-000191:mdna:49]
Sales in the first nine months of 2018 were up from the same period last year.  The sales increase was led by acquisition related sales, as well as volume and price increases from all segments. The impact of foreign currency translation decreased sales by less than 1 percent. The Company's consolidated gross profit was $328.0 million for the first nine months of 2018, an increase of $45.6 million or about 16 percent from the first nine months of 2017. Earnings in the first nine months of 2018 were up from the same period last year.

[0000038725-18-000191:mdna:50]
[same as prior period, unchanged from 0000038725-18-000152:mdna:49]

[0000038725-18-000191:mdna:51]
[same as prior period, unchanged from 0000038725-18-000152:mdna:50]

[0000038725-18-000191:mdna:52]
Net sales in the first nine months of 2018 were $981.5 million, an increase of $144.8 million or about 17 percent compared to 2017 first nine months sales of $836.7 million.  The incremental impact of sales from acquired businesses was $86.2 million or 10 percent.  Sales revenue decreased by $2.3 million or less than 1 percent in the first nine months of 2018 due to foreign currency translation.

[0000038725-18-000191:mdna:53]
|  | Net Sales |
| (In millions) | YTD September 30, 2018 |  | YTD September 30, 2017 |  | 2018 v 2017 |
| Water Systems | $ | 600.5 |  |  | $ | 561.9 |  |  | $ | 38.6 |  |
| Fueling Systems | 212.3 |  |  | 177.8 |  |  | 34.5 |  |
| Distribution | 213.7 |  |  | 127.2 |  |  | 86.5 |  |
| Eliminations/Other | (45.0 | ) |  | (30.2 | ) |  | (14.8 | ) |
| Consolidated | $ | 981.5 |  |  | $ | 836.7 |  |  | $ | 144.8 |  |

[0000038725-18-000191:mdna:54]
[same as prior period, unchanged from 0000038725-18-000152:mdna:53]

[0000038725-18-000191:mdna:55]
Water Systems sales were $600.5 million in the first nine months 2018, an increase of $38.6 million or about 7 percent versus the first nine months of 2017. The incremental impact of sales from acquired businesses was $3.9 million.  Foreign currency translation changes decreased sales $5.9 million, or about 1 percent, compared to sales in the first nine months of 2017. The Water Systems organic sales change in the first nine months of 2018 was an increase of $40.6 million or about 7 percent.

[0000038725-18-000191:mdna:56]
Water Systems sales in the U.S. and Canada increased by about 16 percent compared to the first nine months of 2017. Sales revenue increased by $1.1 million or less than 1 percent in the first nine months of 2018 due to foreign currency translation. In the first nine months of 2018, sales of Pioneer branded dewatering equipment increased by about 90 percent when compared to the prior year due to strength in North American oil and gas markets and continued diversification of product sales channels and geographies. Sales of groundwater pumping equipment increased by about 10 percent on stronger residential and agricultural system sales primarily to the Headwater companies, versus the first nine months of 2017. Sales of other surface pumping equipment increased by about 5 percent in part due to wet weather conditions in the upper Midwest and Canada.

[0000038725-18-000191:mdna:57]
Water Systems sales in markets outside the U.S. and Canada decreased by about 1 percent compared to the first nine months of 2017. Sales revenue decreased by $7.0 million or about 2 percent in the first nine months of 2018 due to foreign currency translation. International Water Systems local currency sales improved in Europe, the Middle East and Africa by about 6 percent, but were more than offset by lower sales volumes in Asia Pacific and Brazil in the first nine months of 2018 compared to last year. Combined, sales in Latin America and Asia Pacific declined by about 8 percent. In Latin America, the sales decline

[0000038725-18-000191:mdna:58]
was primarily in Brazil. The sales decline in Brazil was due to an overall slowdown of the economic environment and from the impact of a trucking strike that hurt the Company’s ability to deliver product to its customers. In Asia Pacific, the Company’s sales in Korea declined due to an overall slowdown of the economic environment; and in Thailand, sales were adversely impacted by declines in government funding for water related projects and by weather.

[0000038725-18-000191:mdna:59]
[same as prior period, unchanged from 0000038725-18-000152:mdna:57]

[0000038725-18-000191:mdna:60]
Fueling Systems sales were $212.3 million in the first nine months of 2018, an increase of $34.5 million or about 19 percent from the first nine months of 2017. The incremental impact of sales from acquired businesses was $1.3 million. Foreign currency translation changes increased sales $3.6 million or about 2 percent compared to sales in the first nine months of 2017. The Fueling Systems organic sales change in the first nine months of 2018 was an increase of $29.6 million or about 17 percent.

[0000038725-18-000191:mdna:61]
Fueling Systems sales in the U.S. and Canada grew by about 9 percent during the first nine months with most of the sales growth coming from fuel management systems and piping. Internationally, Fueling Systems revenues grew by about 35 percent led by stronger sales in China and Europe, partially offset by lower sales in India. China sales were about $36 million in the first nine months of 2018 compared to the first nine months of 2017 Fueling Systems China sales of about $15 million.

[0000038725-18-000191:mdna:62]
[same as prior period, unchanged from 0000038725-18-000152:mdna:60]

[0000038725-18-000191:mdna:63]
Distribution sales were $213.7 million in the first nine months of 2018, versus the first nine months of 2017 sales of $127.2 million. The incremental impact of sales from acquired businesses was $81.0 million. Distribution segment organic sales increased about 4 percent compared to the first nine months of 2017.

[0000038725-18-000191:mdna:64]
[same as prior period, unchanged from 0000038725-18-000152:mdna:62]

[0000038725-18-000191:mdna:65]
Cost of sales as a percent of net sales for the first nine months of 2018 and 2017 was 66.6 percent and 66.2 percent, respectively. Correspondingly, the gross profit margin was 33.4 percent and 33.8 percent, respectively. The Company's consolidated gross profit was $328.0 million for the first nine months of 2018, up $45.6 million from the gross profit of $282.4 million in the first nine months of 2017. The gross profit increase was primarily due to higher sales. For the remainder of the year, management expects there to be about 250 to 300 basis points of selling price increases, in part from announced pricing actions, and that these price increases will offset projected inflation, including tariffs.

[0000038725-18-000191:mdna:66]
[same as prior period, unchanged from 0000038725-18-000152:mdna:64]

[0000038725-18-000191:mdna:67]
Selling, general, and administrative expenses were $223.7 million in the first nine months of 2018 and increased by $27.6 million compared to $196.1 million the first nine months of last year. The increase in SG&A expenses from acquired businesses were $23.9 million. Excluding the acquired entities, the Company’s SG&A expenses in the first nine months of 2018 increased by $3.7 million or about 2 percent.

[0000038725-18-000191:mdna:68]
[same as prior period, unchanged from 0000038725-18-000152:mdna:66]

[0000038725-18-000191:mdna:69]
Restructuring expenses for the first nine months of 2018 were $1.0 million. Restructuring expenses were $0.5 million in the Water segment, $0.2 million in the Fueling segment and $0.3 million in the Distribution segment. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities and branch closings and consolidations in the distribution segment. Restructuring expenses for the first nine months of 2017 were $1.6 million all in the Water segment. Restructuring expenses were primarily related to the Brazilian manufacturing realignments. Restructuring expenses were primarily severance expenses, equipment relocations and other miscellaneous manufacturing realignment activities.

[0000038725-18-000191:mdna:70]
[same as prior period, unchanged from 0000038725-18-000152:mdna:68]

[0000038725-18-000191:mdna:71]
Operating income was $103.3 million in the first nine months of 2018, up $18.5 million or 22 percent from $84.8 million in the first nine months of 2017.

[0000038725-18-000191:mdna:72]
|  |  | Operating income (loss) |
| (In millions) |  | YTD September 30, 2018 |  | YTD September 30, 2017 |  | 2018 v 2017 |
| Water Systems |  | $ | 85.9 |  |  | $ | 82.5 |  |  | $ | 3.4 |  |
| Fueling Systems |  | 53.4 |  |  | 43.0 |  |  | 10.4 |  |
| Distribution |  | 6.3 |  |  | 5.7 |  |  | 0.6 |  |
| Eliminations/Other |  | (42.3 | ) |  | (46.4 | ) |  | 4.1 |  |
| Consolidated |  | $ | 103.3 |  |  | $ | 84.8 |  |  | $ | 18.5 |  |

[0000038725-18-000191:mdna:73]
[same as prior period, unchanged from 0000038725-18-000152:mdna:72]

[0000038725-18-000191:mdna:74]
Water Systems operating income was $85.9 million in the first nine months of 2018 compared to $82.5 million in the first nine months of 2017, an increase of 4 percent. The first nine months operating income margin was 14.3 percent compared to the first nine months of 2017 operating income margin of 14.7 percent. Operating income margin decreased in Water Systems primarily due to product and geographic sales mix shifts.

[0000038725-18-000191:mdna:75]
[same as prior period, unchanged from 0000038725-18-000152:mdna:74]

[0000038725-18-000191:mdna:76]
Fueling Systems operating income was $53.4 million in the first nine months of 2018 compared to $43.0 million in the first nine months of 2017. The first nine months operating income margin was 25.2 percent compared to 24.2 percent of net sales in the first nine months of 2017, an increase of 100 basis points due to leverage on fixed cost from higher sales.

[0000038725-18-000191:mdna:77]
[same as prior period, unchanged from 0000038725-18-000152:mdna:76]

[0000038725-18-000191:mdna:78]
Distribution operating income was $6.3 million in the first nine months of 2018 and operating income margin was 2.9 percent. Distribution operating income was $5.7 million in the first nine months of 2017 and operating income margin was 4.5 percent. The Distribution segment’s operations are seasonal and product sales are significantly slower during the fourth and first quarters, i.e., the winter months in North America. The 2017 Distribution acquisitions were completed during the second quarter of 2017 and; therefore, the 2017 results did not include the impact of the first quarter seasonality.

[0000038725-18-000191:mdna:79]
[same as prior period, unchanged from 0000038725-18-000152:mdna:78]

[0000038725-18-000191:mdna:80]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses.  The inter-segment profit elimination impact in the first nine months of 2018 was $0.4 million. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until the transferred product is sold from the Distribution segment to its third party customer. Unallocated general and administrative expenses were higher by $1.2 million or about 3 percent to last year in the first nine months.

[0000038725-18-000191:mdna:81]
[same as prior period, unchanged from 0000038725-18-000152:mdna:80]

[0000038725-18-000191:mdna:82]
Interest expense for the first nine months of 2018 and 2017 was $7.5 million and $8.1 million, respectively.

[0000038725-18-000191:mdna:83]
[same as prior period, unchanged from 0000038725-18-000152:mdna:82]

[0000038725-18-000191:mdna:84]
Other income or expense was a loss of $0.6 million in the first nine months of 2018. Included in other income in the first nine months of 2018 was interest income of $0.4 million, primarily derived from the investment of cash balances in short-term securities. Also included in other income in the first nine months of 2018 was a loss of $0.3 million related to the write-off of a tax indemnification asset.  The first nine months of 2017 other income or expense was income of $6.6 million. Included in other income in the first nine months of 2017 was a gain of $5.2 million on the previously held equity investments in three Distribution entities. Also, included in other income in the first nine months of 2017 was minority income of $0.6 million and interest income of $0.7 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-18-000191:mdna:85]
[same as prior period, unchanged from 0000038725-18-000152:mdna:84]

[0000038725-18-000191:mdna:86]
Foreign currency-based transactions for the first nine months of 2018 was a loss of $3.2 million due to movements in several currencies relative to the U.S. dollar, with the Turkish Lira, South African Rand and Mexican Peso being the most significant. Foreign currency-based transactions for the first nine months of 2017 was a gain $0.3 million, due to movements in several currencies relative to the U.S. dollar, none of which individually were significant.

[0000038725-18-000191:mdna:87]
[same as prior period, unchanged from 0000038725-18-000152:mdna:86]

[0000038725-18-000191:mdna:88]
The provision for income taxes in the first nine months of 2018 and 2017 was $10.9 million and $12.9 million, respectively. The effective tax rate for the first nine months of 2018 was about 12 percent and, before the impact of discrete events, was about 20 percent. The effective tax rate in the first nine months of 2017 was about 15 percent and, before the impact of discrete events, was about 26 percent. The Company estimates its effective tax rate for 2018 after discrete events will be 13 to 17 percent, or about 10 points lower than the effective tax rate of 25 percent in 2017. The lower tax rate before discrete events is primarily the result of the U.S. Tax Cuts and Jobs Act of 2017. Discrete events in the first nine months of 2018 include the release of a valuation allowance related to state net operating losses and incentives and excess tax benefits on stock-based compensation; and in 2017 included a realized foreign currency translation loss, the release of a valuation allowance related to foreign net operating losses, the recording of a tax benefit on a non-taxable gain recorded on the previously held equity investments and excess tax benefits on stock-based compensation.

[0000038725-18-000191:mdna:89]
[same as prior period, unchanged from 0000038725-18-000152:mdna:88]

[0000038725-18-000191:mdna:90]
Net income for the first nine months of 2018 was $81.2 million compared to 2017 first nine months net income of $70.7 million.  Net income attributable to Franklin Electric Co., Inc. for the first nine months of 2018 was $81.7 million, or $1.72 per diluted share, compared to 2017 first nine months net income attributable to Franklin Electric Co., Inc. of $70.1 million or $1.48 per diluted share.

[0000038725-18-000191:mdna:91]
[same as prior period, unchanged from 0000038725-18-000152:mdna:90]

[0000038725-18-000191:mdna:92]
[same as prior period, unchanged from 0000038725-18-000152:mdna:91]

[0000038725-18-000191:mdna:93]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available.  The Company believes its capital resources and liquidity position at September 30, 2018 is adequate to meet projected needs for the foreseeable future.  The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and exiting credit agreements.

[0000038725-18-000191:mdna:94]
As of September 30, 2018 the Company had $300.0 million revolving credit facility.  The facility is scheduled to mature on October 28, 2021.  As of September 30, 2018, the Company had $205.3 million borrowing capacity under the Credit Agreement as $5.6 million in letters of commercial and standby letters of credit were outstanding and undrawn and $89.1 million in revolver borrowings were drawn and outstanding which were primarily used for acquisition and working capital needs.

[0000038725-18-000191:mdna:95]
The Company also has other long-term debt borrowing outstanding as of September 30, 2018.  See Note 9 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-18-000191:mdna:96]
At September 30, 2018, the Company had $34.2 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations.  There is currently no need to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-18-000191:mdna:97]
[same as prior period, unchanged from 0000038725-18-000152:mdna:96]

[0000038725-18-000191:mdna:98]
The following table summarizes significant sources and uses of cash and cash equivalents for the first nine months of 2018 and 2017.

[0000038725-18-000191:mdna:99]
| (in millions) |  | 2018 |  | 2017 |
| Net cash provided by operating activities |  | $ | 60.4 |  |  | $ | 40.4 |  |
| Net cash used in investing activities |  | (56.4 | ) |  | (73.9 | ) |
| Net cash used in financing activities |  | (28.5 | ) |  | (14.2 | ) |
| Impact of exchange rates on cash and cash equivalents |  | (1.6 | ) |  | 3.5 |  |
| Change in cash and cash equivalents |  | $ | (26.1 | ) |  | $ | (44.2 | ) |

[0000038725-18-000191:mdna:100]
Cash Flows Provided by Operating Activities

[0000038725-18-000191:mdna:101]
[same as prior period, unchanged from 0000038725-18-000152:mdna:100]

[0000038725-18-000191:mdna:102]
Net cash provided by operating activities was $60.4 million for the nine months ended September 30, 2018 compared to the $40.4 million provided by operating activities for the nine months ended September 30, 2017.  The increase in cash provided by operating activities was due to an increase in net earnings of about $16 million before the prior year non-cash gain on equity investments and a reduction in other assets of $10 million, which consisted primarily of prepaid assets. These increases were partially offset by an increase in working capital requirements, primarily customer accounts receivable consistent with increased sales.

[0000038725-18-000191:mdna:103]
[same as prior period, unchanged from 0000038725-18-000152:mdna:102]

[0000038725-18-000191:mdna:104]
[same as prior period, unchanged from 0000038725-18-000152:mdna:103]

[0000038725-18-000191:mdna:105]
Net cash used in investing activities was $56.4 million for the nine months ended September 30, 2018 compared to the $73.9 million used in investing activities for the nine months ended September 30, 2017.  The decrease in cash used in investing activities is primarily attributable to decreased acquisition activity and lower spending for property, plant and equipment during the current year.

[0000038725-18-000191:mdna:106]
Cash Flows Used in Financing Activities

[0000038725-18-000191:mdna:107]
[same as prior period, unchanged from 0000038725-18-000152:mdna:106]

[0000038725-18-000191:mdna:108]
Net cash used in financing activities was $28.5 million for the nine months ended September 30, 2018 compared to the $14.2 million used in financing activities for the nine months ended September 30, 2017.  The overall increase in cash used in

[0000038725-18-000191:mdna:109]
financing activities was attributable to increased stock repurchases of approximately $9 million and net debt repayments of approximately $8 million in the current year compared to net borrowings of approximately $6 million in the prior year.

[0000038725-18-000191:mdna:110]
[same as prior period, unchanged from 0000038725-18-000152:mdna:108]

[0000038725-18-000191:mdna:111]
33
