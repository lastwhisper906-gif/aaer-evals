# FELE 8-K — 0000038725-18-000186 filed 2018-10-26

## item codes, every 8-K on or before 2018-11-02

- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2018-11-02

- none on or before 2018-11-02

## item 2.02 — earnings release, exhibit 99.1

[0000038725-18-000186:8k_2_02:1]
EX-99.1
2
a201810268-kexhibit991.htm
EXHIBIT 99.1

[0000038725-18-000186:8k_2_02:2]
Exhibit

[0000038725-18-000186:8k_2_02:3]
Exhibit 99.1

[0000038725-18-000186:8k_2_02:4]
For Immediate Release

[0000038725-18-000186:8k_2_02:5]
For Further Information

[0000038725-18-000186:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-18-000186:8k_2_02:7]
260-824-2900

[0000038725-18-000186:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS RECORD THIRD

[0000038725-18-000186:8k_2_02:9]
QUARTER 2018 SALES AND EARNINGS

[0000038725-18-000186:8k_2_02:10]
Fort Wayne, IN - October 26, 2018 - Franklin Electric Co., Inc. (NASDAQ: FELE) reported third quarter 2018 GAAP fully diluted earnings per share (EPS) of $0.63, versus a GAAP fully diluted EPS in the third quarter 2017 of $0.52.  Third quarter 2018 sales were $341.9 million, compared to 2017 third quarter sales of $311.1 million.  Third quarter 2018 organic sales increased about 8 percent when excluding the impact of foreign currency translation. Third quarter EPS before the impact of restructuring expenses was $0.64 compared to 2017 third quarter EPS before restructuring of $0.53 (see table below for a reconciliation of GAAP EPS to EPS before restructuring).

[0000038725-18-000186:8k_2_02:11]
Gregg Sengstack, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-18-000186:8k_2_02:12]
“Our third quarter earnings were a record for any third quarter in the Company’s history.  Our earnings per share grew by over 20 percent from the third quarter 2017.  Our consolidated organic sales growth before the impact of foreign exchange was about 8 percent, led by 49 percent organic growth in our Pioneer branded dewatering equipment products and 22 percent organic growth in our Fueling Systems business.

[0000038725-18-000186:8k_2_02:13]
Our results were negatively impacted by a significant and unexpected strengthening of the U.S. dollar in the quarter against many developing world currencies lowered our overall net sales by $11.2 million, or 4 percent and lowered our operating income by an estimated $1.6 million or about 5 percent versus the third quarter of last year.  In addition, we had below the operating income line transactional foreign exchange losses of $1.6 million in the quarter as the sudden declines in the Turkish Lira, South African Rand, and Brazilian Real versus the U.S. dollar exposed us to short term liability valuation adjustments, primarily in August.  The combined impact of foreign exchange reduced our earnings per share by about $0.05.”

[0000038725-18-000186:8k_2_02:14]
Key Performance Indicators:

[0000038725-18-000186:8k_2_02:15]
| Earnings Before and After Restructuring |  | For the Third Quarter |
| (in millions) |  | 2018 | 2017 | Change |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 30.0 |  | $ | 24.5 |  | 22 | % |
| Allocated Earnings |  | $ | (0.2 | ) | $ | (0.2 | ) |  |
| Earnings for EPS Calculations |  | $ | 29.8 |  | $ | 24.3 |  | 23 | % |
| Restructuring (before tax): |  | $ | 0.3 |  | $ | 1.0 |  |  |
| Restructuring, net of tax: |  | $ | 0.2 |  | $ | 0.6 |  |  |
| Earnings Before Restructuring |  | $ | 30.0 |  | $ | 24.9 |  | 20 | % |
| Earnings Per Share |  | For the Third Quarter |
| Before and After Restructuring |  | 2018 | 2017 | Change |
| (in millions except Earnings Per Share) |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 47.2 |  | 47.0 |  | — | % |
| Fully Diluted Earnings Per Share (“EPS”) Reported |  | $ | 0.63 |  | $ | 0.52 |  | 21 | % |
| Restructuring Per Share, net of tax |  | $ | 0.01 |  | $ | 0.01 |  |  |
| Fully Diluted EPS Before Restructuring |  | $ | 0.64 |  | $ | 0.53 |  | 21 | % |

[0000038725-18-000186:8k_2_02:16]
|  | Net Sales |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q3 2017 | $ | 97.1 |  | $ | 32.6 |  | $ | 46.9 |  | $ | 19.4 |  | $ | 196.0 |  | $ | 64.1 |  | $ | 68.1 |  | $ | (17.1 | ) | $ | 311.1 |  |
| Q3 2018 | $ | 105.8 |  | $ | 31.2 |  | $ | 44.0 |  | $ | 17.3 |  | $ | 198.3 |  | $ | 78.8 |  | $ | 78.0 |  | $ | (13.2 | ) | $ | 341.9 |  |
| Change | $ | 8.7 |  | $ | (1.4 | ) | $ | (2.9 | ) | $ | (2.1 | ) | $ | 2.3 |  | $ | 14.7 |  | $ | 9.9 |  | $ | 3.9 |  | $ | 30.8 |  |
| % Change | 9 | % | (4 | )% | (6 | )% | (11 | )% | 1 | % | 23 | % | 15 | % |  | 10 | % |
| Foreign currency translation | $ | (0.6 | ) | $ | (4.2 | ) | $ | (5.2 | ) | $ | (0.6 | ) | $ | (10.6 | ) | $ | (0.6 | ) | $ | — |  |  |  |
| % Change | (1 | )% | (13 | )% | (11 | )% | (3 | )% | (5 | )% | (1 | )% | — | % |  |  |
| Acquisitions |  | $ | 3.9 |  |  |  | $ | 3.9 |  | $ | 1.3 |  | $ | 8.2 |  |  |  |
| Volume/Price | $ | 9.3 |  | $ | (1.1 | ) | $ | 2.3 |  | $ | (1.5 | ) | $ | 9.0 |  | $ | 14.0 |  | $ | 1.7 |  |  |  |
| % Change | 10 | % | (3 | )% | 5 | % | (8 | )% | 5 | % | 22 | % | 2 | % |  |  |

[0000038725-18-000186:8k_2_02:17]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Third Quarter 2018 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 28.4 |  | $ | 20.9 |  | $ | 3.1 |  | $ | (12.3 | ) | $ | 40.1 |  |
| % Operating Income To Net Sales | 14.3 | % | 26.5 | % | 4.0 | % |  | 11.7 | % |
| Restructuring | $ | — |  | $ | — |  | $ | 0.3 |  | $ | — |  | $ | 0.3 |  |
| Operating Income/(Loss) Before Restructuring | $ | 28.4 |  | $ | 20.9 |  | $ | 3.4 |  | $ | (12.3 | ) | $ | 40.4 |  |
| % Operating Income to Net Sales Before Restructuring | 14.3 | % | 26.5 | % | 4.4 | % |  | 11.8 | % |
|  | For the Third Quarter 2017 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 28.3 |  | $ | 17.1 |  | $ | 2.0 |  | $ | (15.4 | ) | $ | 32.0 |  |
| % Operating Income To Net Sales | 14.4 | % | 26.7 | % | 2.9 | % |  | 10.3 | % |
| Restructuring | $ | 1.0 |  | $ | — |  | $ | — |  | $ | — |  | $ | 1.0 |  |
| Operating Income/(Loss) Before Restructuring | $ | 29.3 |  | $ | 17.1 |  | $ | 2.0 |  | $ | (15.4 | ) | $ | 33.0 |  |
| % Operating Income to Net Sales Before Restructuring | 14.9 | % | 26.7 | % | 2.9 | % |  | 10.6 | % |

[0000038725-18-000186:8k_2_02:18]
Water Systems

[0000038725-18-000186:8k_2_02:19]
Water Systems sales were $198.3 million in the third quarter 2018, versus the third quarter 2017 sales of $196.0 million.  Water Systems organic sales increased about 5 percent compared to the third quarter of 2017.  Water Systems sales decreased about 5 percent in the quarter due to foreign currency translation.  In the third quarter of 2018, sales from businesses acquired since the third quarter of 2017 were $3.9 million.

[0000038725-18-000186:8k_2_02:20]
Water Systems sales in the U.S. and Canada increased by about 9 percent compared to the third quarter 2017. Foreign currency translation decreased sales by about 1 percent.  Sales of Pioneer branded dewatering equipment increased by over 70 percent in the third quarter when compared to the prior year due to continued strength in North American oil and gas markets and diversification of product sales channels and geographies. Sales of other surface pumping equipment increased by about 6 percent on stronger HVAC and wastewater products, versus the third quarter 2017. Sales of groundwater pumping equipment decreased by about 5 percent on lower residential and agricultural system sales, versus the third quarter 2017.

[0000038725-18-000186:8k_2_02:21]
Water Systems sales in markets outside the U.S. and Canada were flat organically.  Overall, sales declined about 6 percent with foreign currency translation decreasing  sales by about 10 percent and revenue from acquired units increasing sales by about 4 percent.  International Water Systems local currency sales improved in Europe, the Middle East, and Africa, but were offset by lower sales in Asia Pacific and Brazil when compared to the third quarter 2017.  Combined, sales in Asia Pacific and Brazil declined by about 9 percent organically.  In Asia Pacific, the Company’s sales decline was nearly all related to lower sales activity in Thailand where sales continued to be adversely impacted by reductions in government funding for water related projects.  In Brazil, the Company’s sales decreased due to a continued slowdown of the economic environment.

[0000038725-18-000186:8k_2_02:22]
Water Systems operating income was $28.4 million in the third quarter 2018, flat compared to $28.3 million in the third quarter 2017.  Operating income growth in the U.S. and Canada was offset by declines in international regions, in part due to weakening foreign currencies versus the U.S. dollar.

[0000038725-18-000186:8k_2_02:23]
Fueling Systems

[0000038725-18-000186:8k_2_02:24]
Fueling Systems sales were $78.8 million in the third quarter 2018, a new record for any quarter. The third quarter 2017 sales were $64.1 million.  Fueling Systems organic sales were up about 22 percent compared to the third quarter of 2017.  In the third quarter of 2018, sales from businesses acquired since the third quarter of 2017 were $1.3 million.

[0000038725-18-000186:8k_2_02:25]
Fueling Systems sales in the U.S. and Canada increased by about 9 percent compared to the third quarter 2017.  The increase was principally in the fuel management and piping and containment systems product lines.  Outside the U.S. and Canada, Fueling Systems revenues grew by about 47 percent, led by stronger sales in China, India and Latin America.

[0000038725-18-000186:8k_2_02:26]
Third quarter Fueling Systems operating income was $20.9 million and was a new record for any quarter in the segment’s history.  The third quarter 2017 Fueling Systems operating income was $17.1.  The increase in operating income was primarily related to higher sales.

[0000038725-18-000186:8k_2_02:27]
Distribution

[0000038725-18-000186:8k_2_02:28]
Distribution sales were $78.0 million in the third quarter 2018, versus third quarter 2017 sales of $68.1 million.  In the third quarter of 2018, sales from businesses acquired since the third quarter of 2017 were $8.2 million.  The Distribution segment organic sales increased about 2 percent compared to the third quarter of 2017.

[0000038725-18-000186:8k_2_02:29]
The Distribution segment operating income was $3.1 million in the third quarter of 2018, compared to $2.0 million in the third quarter of 2017.

[0000038725-18-000186:8k_2_02:30]
Overall

[0000038725-18-000186:8k_2_02:31]
The Company’s consolidated gross profit was $113.0 million for the third quarter of 2018, an increase from the third quarter of 2017 gross profit of $103.8 million. The gross profit increase was primarily due to higher sales.  The gross profit as a percent of net sales was 33.0 percent in the third quarter of 2018 compared to 33.4 percent in the third quarter of 2017.

[0000038725-18-000186:8k_2_02:32]
Selling, general, and administrative (SG&A) expenses were $72.5 million in the third quarter of 2018 compared to $70.9 million in the third quarter of the prior year.  The increase in SG&A expenses from acquired businesses was $2.9 million.  Excluding the acquired entities, the Company’s SG&A expenses in the third quarter of 2018 were $69.6 million, a decrease of about 2 percent from the third quarter 2017, due primarily to the effect of foreign currency translations in the third quarter of 2018 versus the prior year.

[0000038725-18-000186:8k_2_02:33]
The Company ended the third quarter of 2018 with a cash balance of $41.2 million, which was $26.0 million lower than at the end of 2017.  Cash has decreased primarily due to acquisitions as well as working capital requirements partially offset by an increase in cash from earnings.

[0000038725-18-000186:8k_2_02:34]
Commenting on the outlook for the remainder of 2018, Mr. Sengstack said:

[0000038725-18-000186:8k_2_02:35]
“As we look to the end of 2018, there are two primary issues that we believe will result in our full year 2018 earnings per share to be below our current guidance of $2.27 to $2.37 before restructuring expenses:

[0000038725-18-000186:8k_2_02:36]
| 1) | we will not recover the impact of the foreign exchange headwinds we experienced in the third quarter which we believe negatively impacted EPS by five cents, and; |

[0000038725-18-000186:8k_2_02:37]
| 2) | continued uncertainty in some international Water Systems end markets will likely continue. |

[0000038725-18-000186:8k_2_02:38]
As a result, we are revising our 2018 full year EPS to now be between $2.22 and $2.26.”

[0000038725-18-000186:8k_2_02:39]
A conference call to review earnings and other developments in the business will commence at 9:00 am EDT.  The third quarter 2018 earnings call will be available via a live webcast.  The webcast will be available in a listen only mode by going to:

[0000038725-18-000186:8k_2_02:40]
https://edge.media-server.com/m6/p/2puhk3z3

[0000038725-18-000186:8k_2_02:41]
If you intend to ask questions during the call, please dial in using 877.643.7158 for domestic calls and 914.495.8565 for international calls.  The conference ID is: 1096938.

[0000038725-18-000186:8k_2_02:42]
A replay of the conference call will be available Friday, October 26, 2018 at 12:00 noon EDT through noon EDT on Friday, November 2, 2018, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls.  The replay passcode is: 1096938.

[0000038725-18-000186:8k_2_02:43]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-18-000186:8k_2_02:44]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
| Net sales | $ | 341,866 |  |  | $ | 311,113 |  |  | $ | 981,466 |  |  | $ | 836,714 |  |
| Cost of sales | 228,900 |  |  | 207,271 |  |  | 653,442 |  |  | 554,303 |  |
| Gross profit | 112,966 |  |  | 103,842 |  |  | 328,024 |  |  | 282,411 |  |
| Selling, general, and administrative expenses | 72,483 |  |  | 70,850 |  |  | 223,723 |  |  | 196,077 |  |
| Restructuring expense | 346 |  |  | 1,009 |  |  | 990 |  |  | 1,575 |  |
| Operating income | 40,137 |  |  | 31,983 |  |  | 103,311 |  |  | 84,759 |  |
| Interest expense | (2,443 | ) |  | (2,297 | ) |  | (7,477 | ) |  | (8,055 | ) |
| Other income/(expense), net | (422 | ) |  | 438 |  |  | (581 | ) |  | 6,616 |  |
| Foreign exchange income/(expense) | (1,601 | ) |  | 193 |  |  | (3,151 | ) |  | 296 |  |
| Income before income taxes | 35,671 |  |  | 30,317 |  |  | 92,102 |  |  | 83,616 |  |
| Income tax expense | 5,739 |  |  | 5,769 |  |  | 10,916 |  |  | 12,890 |  |
| Net income | $ | 29,932 |  |  | $ | 24,548 |  |  | $ | 81,186 |  |  | $ | 70,726 |  |
| Less: Net (income)/loss attributable to noncontrolling interests | 74 |  |  | (78 | ) |  | 491 |  |  | (617 | ) |
| Net income attributable to Franklin Electric Co., Inc. | $ | 30,006 |  |  | $ | 24,470 |  |  | $ | 81,677 |  |  | $ | 70,109 |  |
| Income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.64 |  |  | $ | 0.52 |  |  | $ | 1.74 |  |  | $ | 1.50 |  |
| Diluted | $ | 0.63 |  |  | $ | 0.52 |  |  | $ | 1.72 |  |  | $ | 1.48 |  |

[0000038725-18-000186:8k_2_02:45]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | September 30, 2018 |  | December 31, 2017 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 41,173 |  |  | $ | 67,233 |  |
| Receivables | 193,429 |  |  | 171,007 |  |
| Inventories | 323,215 |  |  | 312,325 |  |
| Other current assets | 31,948 |  |  | 38,566 |  |
| Total current assets | 589,765 |  |  | 589,131 |  |
| Property, plant, and equipment, net | 206,157 |  |  | 215,694 |  |
| Goodwill and other assets | 396,229 |  |  | 380,528 |  |
| Total assets | $ | 1,192,151 |  |  | $ | 1,185,353 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 75,348 |  |  | $ | 79,348 |  |
| Accrued expenses and other current liabilities | 67,567 |  |  | 66,100 |  |
| Current maturities of long-term debt and short-term borrowings | 122,846 |  |  | 100,453 |  |
| Total current liabilities | 265,761 |  |  | 245,901 |  |
| Long-term debt | 94,229 |  |  | 125,596 |  |
| Income taxes payable non-current | 10,365 |  |  | 17,391 |  |
| Deferred income taxes | 29,601 |  |  | 30,913 |  |
| Employee benefit plans | 36,361 |  |  | 42,178 |  |
| Other long-term liabilities | 18,873 |  |  | 19,251 |  |
| Redeemable noncontrolling interest | 616 |  |  | 1,502 |  |
| Total equity | 736,345 |  |  | 702,621 |  |
| Total liabilities and equity | $ | 1,192,151 |  |  | $ | 1,185,353 |  |

[0000038725-18-000186:8k_2_02:46]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
| (In thousands) | September 30, 2018 |  | September 30, 2017 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 81,186 |  |  | $ | 70,726 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 28,987 |  |  | 28,418 |  |
| Share-based compensation | 6,627 |  |  | 6,043 |  |
| Gain on equity investment | — |  |  | (5,165 | ) |
| Other | (1,234 | ) |  | (2,444 | ) |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (30,853 | ) |  | 8,449 |  |
| Inventory | (15,571 | ) |  | (35,758 | ) |
| Accounts payable and accrued expenses | (6,094 | ) |  | (17,942 | ) |
| Income taxes-U.S. Tax Cuts and Jobs Act | (7,026 | ) |  | — |  |
| Other | 4,396 |  |  | (11,963 | ) |
| Net cash flows from operating activities | 60,418 |  |  | 40,364 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (15,108 | ) |  | (22,517 | ) |
| Proceeds from sale of property, plant, and equipment | 432 |  |  | 207 |  |
| Acquisitions and investments | (42,085 | ) |  | (51,783 | ) |
| Other investing activities | 388 |  |  | 149 |  |
| Net cash flows from investing activities | (56,373 | ) |  | (73,944 | ) |
| Cash flows from financing activities: |  |  |  |
| Change in debt | (8,203 | ) |  | 5,594 |  |
| Proceeds from issuance of common stock | 8,747 |  |  | 3,770 |  |
| Purchases of common stock | (12,080 | ) |  | (3,263 | ) |
| Dividends paid | (16,960 | ) |  | (15,245 | ) |
| Purchase of redeemable non-controlling shares | — |  |  | (5,047 | ) |
| Net cash flows from financing activities | (28,496 | ) |  | (14,191 | ) |
| Effect of exchange rate changes on cash | (1,609 | ) |  | 3,569 |  |
| Net change in cash and equivalents | (26,060 | ) |  | (44,202 | ) |
| Cash and equivalents at beginning of period | 67,233 |  |  | 104,331 |  |
| Cash and equivalents at end of period | $ | 41,173 |  |  | $ | 60,129 |  |
