# FELE notes — 0000038725-18-000191


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-18-000191:notes:1]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2017, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 30, 2018, and for the third quarters and nine months ended September 30, 2018 and September 30, 2017 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made.  Operating results for the third quarter and nine months ended September 30, 2018 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2018.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2017.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000038725-18-000191:notes:2]
ACCOUNTING PRONOUNCEMENTS
Adoption of New Accounting Standards

[0000038725-18-000191:notes:3]
In March 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2017-07, Compensation - Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost.  This ASU requires entities to present only the service cost component of net periodic benefit cost as an operating expense (consistent with the presentation of other employee compensation costs).  The other components of net periodic benefit cost are to be presented as a non-operating expense.  The Company adopted ASU 2017-07 during the first quarter ended March 31, 2018. The prior year non-service cost component of net periodic benefit costs as of September 30, 2017 was approximately $0.2 million and is not considered significant.  The Company has included current year non-service costs as non-operating expense.  The adoption of this pronouncement did not have a material impact to the Company’s condensed consolidated financial position, results of operations, or cash flows.

[0000038725-18-000191:notes:4]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606) as modified by subsequently issued ASUs 2015-14, 2016-08, 2016-10, 2016-12 and 2016-20 (collectively ASU 2014-09).  Topic 606 supersedes the revenue recognition requirements in Accounting Standards Codification (“ASC”) Topic 605, Revenue Recognition (“Topic 605”), and requires the recognition of revenue when promised goods or services are transferred to customers in an amount that reflects the considerations to which the entity expects to be entitled to in exchange for those goods or services.  The Company made the accounting policy election allowed by ASC 606-10-32-2A to continue to present sales tax on a net basis, consistent with current guidance in ASC 605-45-15-2(e).  The guidance permits two methods of adoption: retrospectively to each prior reporting period presented (full retrospective method), or retrospectively with the cumulative effect of initially applying the guidance recognized at the date of initial application (modified retrospective method).  The Company adopted ASU 2014-09 during the first quarter ended March 31, 2018 utilizing the modified retrospective approach. The adoption of this ASU did not have a material impact to the Company’s condensed consolidated financial position, results of operations, or cash flow; however, the adoption of this ASU requires the Company to disclose sufficient information to enable users of financial statements to understand the nature, amount, timing, and uncertainty of revenue and cash flows arising from contracts with customers. The Company completed its assessment of the additional disclosure requirements with the following results:

[0000038725-18-000191:notes:5]
Disaggregation of Revenue

[0000038725-18-000191:notes:6]
The adoption of this ASU requires the Company to disaggregate revenue into categories to depict how the nature, timing, and uncertainty of revenue and cash flows are affected by economic factors.  As evidenced in Footnote 13 Segment and Geographic Information, the Company’s business consists of the Water, Fueling, Distribution, and Other segments. The Other segment includes unallocated corporate expenses and intersegment eliminations. A reconciliation of disaggregated revenue to segment revenue as well as Water Segment revenue by geographical regions is provided in Footnote 13, consistent with how the Company evaluates financial performance.

[0000038725-18-000191:notes:7]
Performance Obligations

[0000038725-18-000191:notes:8]
A performance obligation is a promise in a contract to transfer a distinct good or service to the customer, and is the unit of account in ASC Topic 606.  The Company typically sells its products to customers by purchase order, and does not have any additional performance obligations included in contracts to customers other than the shipment of products. The Company records net sales revenues after discounts at the time of sale based on specific discount programs in effect, related historical data, and experience. The Company typically ships products FOB shipping at

[0000038725-18-000191:notes:9]
which point control of the products passes to the customers. Any shipping and handling fees prior to shipment are considered activities required to fulfill the Company’s promise to transfer goods, and do not qualify as a separate performance obligation. Shipping and handling costs are recorded as a component of cost of sales.  Additionally, the Company offers assurance-type warranties (vs. service warranties) which do not qualify as a separate performance obligation. Therefore, the Company allocates the transaction price based on a single performance obligation.  The Company offers normal and customary trade terms to its customers, no significant part of which is of an extended nature.  The Company considers the performance obligation satisfied and recognizes revenue at a point in time, the time of shipment.  The Company does not generally allow for refunds or returns to customers and does not have outstanding performance obligations for contracts with original durations of greater than one year at the end of the reporting period.

[0000038725-18-000191:notes:10]
Contract Costs

[0000038725-18-000191:notes:11]
The Company does not have outstanding contracts with an original term greater than one year; therefore, the Company expenses costs to obtain a contract as incurred.

[0000038725-18-000191:notes:12]
Accounting Standards Issued But Not Yet Adopted

[0000038725-18-000191:notes:13]
In February 2018, the FASB issued ASU 2018-02, Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income. This ASU was issued following the enactment of the U.S. Tax Cuts and Jobs Act of 2017 ("Tax Act") and permits entities to elect a reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Act. The ASU is effective for interim and annual periods beginning after December 15, 2018, with early adoption permitted, and may be applied either at the beginning of the period of adoption or retrospectively to each period in which the effect of the change in the U.S. federal corporate income tax rate in the Tax Act is recognized. The Company is currently assessing the impact of the ASU on the Company’s consolidated financial position, results of operations, and cash flows.

[0000038725-18-000191:notes:14]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.  ASU 2017-04 removes step two from the goodwill impairment test and instead requires an entity to recognize a goodwill impairment charge for the amount by which the goodwill carrying amount exceeds the reporting unit's fair value.  The ASU is effective on a prospective basis for interim and annual periods beginning after December 15, 2019 with early adoption permitted.   The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-18-000191:notes:15]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842), which supersedes existing guidance on accounting for leases found in Accounting Standards Codification (“ASC”) Topic 840.  This ASU requires lessees to present right-of-use assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months.  In July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases and ASU 2018-11, Leases (Topic 842): Targeted Improvements. ASU 2018-10 clarifies certain aspects of Topic 842, including the rate implicit in the lease, impairment of the net investment in the lease, lessee reassessment of lease classification, lessor reassessment of lease term and purchase options, variable payments that depend on an index or rate and certain transition adjustments, among other things. ASU 2018-11 allows entities adopting ASU 2016-02 to choose an additional (and optional) transition method of adoption, under which an entity initially applies the new lease standard at the adoption date and recognizes a cumulative-effect adjustment to the opening balance of retained earnings in the period of adoption. Additionally, ASU 2018-11 allows lessors to not separate non-lease components from the associated lease component if certain conditions are met. The guidance is to be applied using either the transition method prescribed in ASU 2018-11 or a modified retrospective approach at the beginning of the earliest comparative period in the financial statements.  All Topic 842 updates are effective for interim and annual periods beginning after December 15, 2018 with early adoption permitted.  The Company has begun the evaluation process for the adoption of the ASU, and anticipates that the majority of the Company’s outstanding operating leases would be recognized as right-of-use assets and lease liabilities upon adoption, resulting in a significant impact to the Company’s consolidated balance sheets. The Company is implementing a lease accounting software package for lease administration and compliance reporting and is in the process of entering its lease data into this package. The impact of this ASU is non-cash in nature and will not affect the Company’s cash position.  The impact to the Company’s results of operations is still being evaluated.

[0000038725-18-000191:notes:16]
In August 2018, the FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Topic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which modifies the disclosure requirements for employers that sponsor defined benefit pension or other postretirement plans. The amendments remove disclosures that no longer are considered cost beneficial, including the estimated amounts in accumulated other comprehensive income expected to be recognized as components of net periodic expense over the next fiscal year. The amendments clarify the specific requirements of disclosures, and add disclosure requirements identified as relevant, including

[0000038725-18-000191:notes:17]
the reasons for significant gains and losses related to change in the benefit obligation for the period.  The ASU should be applied retrospectively and is effective for interim and annual periods beginning after December 15, 2020. The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-18-000191:notes:18]
In August 2018, the FASB issued ASU 2018-15, Goodwill and Other - Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract. This ASU aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software (and hosting arrangements that include internal-use software license). The ASU should be applied either retrospectively or prospectively to all implementation costs incurred after the date of adoption and is effective for interim and annual periods beginning after December 15, 2019 with early adoption permitted. The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-18-000191:notes:19]
ACQUISITIONS
During the third quarter ended September 30, 2018, the Company acquired, in separate transactions, substantially all of the assets of the Stationary Power Division (“SPD”) of Midtronics, Inc., and 100 percent of the ownership interest in Industrias Rotor Pump S.A. (“Industrias Rotor Pump”), located in the United States and Argentina, respectively. Neither of the acquisitions were material individually or in the aggregate, and the combined preliminary purchase price was approximately $36 million. The operating results of the two businesses from their respective dates of acquisition through September 30, 2018 were not material to the Company as a whole.  SPD offers a variety of products to users in the electrical substation monitoring, data center and mobile telecommunications markets. Annual net sales for SPD are estimated to be less than one percent of consolidated net sales and the fair value of the acquired assets are estimated to be less than one percent of consolidated total assets.  Industrias Rotor Pump is the leading provider of water pumping equipment in Argentina.  Annual net sales of Industrias Rotor Pump are estimated to be less than one percent of consolidated net sales and the fair value of the acquired assets are estimated to be less than three percent of consolidated total assets.

[0000038725-18-000191:notes:20]
The preliminary identifiable intangible assets recognized in the separate transactions were $15.2 million, and consist primarily of customer relationships, which will be amortized utilizing the straight-line method over 15 - 20 years.

[0000038725-18-000191:notes:21]
The preliminary goodwill of $15.3 million resulting from the separate acquisitions consists primarily of the benefits of complimentary product offerings and expanded geographical presence. Goodwill was recorded in the Fueling and Water segments (see Note 6), and only a portion ($4.1 million) is expected to be deductible for tax purposes.

[0000038725-18-000191:notes:22]
The Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interests since the beginning of 2018, as the results of operations for these acquisitions are immaterial.

[0000038725-18-000191:notes:23]
Prior to the acquisition of the Argentina entity the economy in Argentina was classified as highly inflationary.  Beginning from the date of acquisition, the Company will apply the requisite accounting for highly inflationary economies, and the functional currency of the entity will be the U.S. dollar.  Monetary assets and liabilities will be remeasured into U.S. dollars using exchange rates as of the latest balance sheet date while non-monetary assets and liabilities will be remeasured using historical exchange rates.  Remeasurement adjustments will be included in foreign exchange gain / (loss) on the consolidated statements of income.

[0000038725-18-000191:notes:24]
During the first quarter ended March 31, 2018, the Company acquired 100 percent of the ownership interests of Lansing, Michigan-based Valley Farms Supply, Inc. ("Valley Farms"), for a purchase price of approximately $9.2 million.  Valley Farms is a professional groundwater distributor operating four locations in the State of Michigan and one in the State of Indiana.  Valley Farms was acquired to serve customers in this region of the United States as part of the Company’s Distribution Segment, which is a collection of professional groundwater equipment distributors.  The Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2018, as the results of operations for this acquisition is immaterial.

[0000038725-18-000191:notes:25]
[same as prior period, unchanged from 0000038725-18-000152:notes:17]

[0000038725-18-000191:notes:26]
[same as prior period, unchanged from 0000038725-18-000152:notes:18]

[0000038725-18-000191:notes:27]
[same as prior period, unchanged from 0000038725-18-000152:notes:19]

[0000038725-18-000191:notes:28]
[same as prior period, unchanged from 0000038725-18-000152:notes:20]

[0000038725-18-000191:notes:29]
[same as prior period, unchanged from 0000038725-18-000152:notes:21]

[0000038725-18-000191:notes:30]
[same as prior period, unchanged from 0000038725-18-000152:notes:22]

[0000038725-18-000191:notes:31]
[same as prior period, unchanged from 0000038725-18-000152:notes:23]

[0000038725-18-000191:notes:32]
[same as prior period, unchanged from 0000038725-18-000152:notes:24]

[0000038725-18-000191:notes:33]
The following unaudited proforma financial information for the third quarters and nine months ended September 30, 2018 and September 30, 2017 gives effect to the Headwater acquisitions by the Company as if the acquisitions had occurred as of January 1, 2017.  These unaudited proforma condensed consolidated financial statements are prepared for informational purposes only and are not necessarily indicative of actual results or financial position that would have been achieved had the acquisitions been consummated on the dates indicated and are not necessarily indicative of future operating results or financial position of the consolidated companies.  The unaudited proforma condensed consolidated financial statements do not give effect to any cost savings or incremental costs that may result from the integration of the Headwater acquisitions with the Company.

[0000038725-18-000191:notes:34]
| FRANKLIN ELECTRIC CO., INC. |
| PROFORMA CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
|  | Third Quarter Ended |  | Nine Months Ended |
| (in millions, except per share amounts) | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
| Revenue: |  |  |  |  |  |  |  |
| As reported | $ | 341.9 |  |  | $ | 311.1 |  |  | $ | 981.5 |  |  | $ | 836.7 |  |
| Proforma | 341.9 |  |  | 311.1 |  |  | 981.5 |  |  | 896.6 |  |
| Net income Attributable to Franklin Electric Co., Inc.: |  |  |  |  |  |  |  |
| As reported | $ | 30.0 |  |  | $ | 24.5 |  |  | $ | 81.7 |  |  | $ | 70.1 |  |
| Proforma | 30.0 |  |  | 24.5 |  |  | 81.7 |  |  | 71.3 |  |
| Basic earnings per share: |  |  |  |  |  |  |  |
| As reported | $ | 0.64 |  |  | $ | 0.52 |  |  | $ | 1.74 |  |  | $ | 1.50 |  |
| Proforma | 0.64 |  |  | 0.52 |  |  | 1.74 |  |  | 1.52 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |
| As reported | $ | 0.63 |  |  | $ | 0.52 |  |  | $ | 1.72 |  |  | $ | 1.48 |  |
| Proforma | 0.63 |  |  | 0.52 |  |  | 1.72 |  |  | 1.51 |  |

[0000038725-18-000191:notes:35]
Transaction costs were expensed as incurred under the guidance of FASB Accounting Standards Codification Topic 805, Business Combinations.  There were $0.1 million and $0.3 million of transaction costs included in the "Selling, general, and administrative expenses" line of the Company's condensed consolidated statements of income for the third quarter and nine months ended September 30, 2018, respectively.  There were zero and $0.3 million of transactions costs incurred in the third quarter and nine months ended September 30, 2017, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-18-000191:notes:36]
[same as prior period, unchanged from 0000038725-18-000152:notes:28]

[0000038725-18-000191:notes:37]
[same as prior period, unchanged from 0000038725-18-000152:notes:29]

[0000038725-18-000191:notes:38]
[same as prior period, unchanged from 0000038725-18-000152:notes:30]

[0000038725-18-000191:notes:39]
[same as prior period, unchanged from 0000038725-18-000152:notes:31]

[0000038725-18-000191:notes:40]
As of September 30, 2018 and December 31, 2017, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-18-000191:notes:41]
| (In millions) | September 30, 2018 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 4.8 |  | $ | 4.8 |  | $ | — |  | $ | — |  |
|  | December 31, 2017 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 3.0 |  | $ | 3.0 |  | $ | — |  | $ | — |  |

[0000038725-18-000191:notes:42]
[same as prior period, unchanged from 0000038725-18-000152:notes:34]

[0000038725-18-000191:notes:43]
[same as prior period, unchanged from 0000038725-18-000152:notes:35]

[0000038725-18-000191:notes:44]
Total debt, including current maturities, have carrying amounts of $216.9 million and $226.0 million and estimated fair values of $217 million and $230 million as of September 30, 2018 and December 31, 2017, respectively.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-18-000191:notes:45]
FINANCIAL INSTRUMENTSThe Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  The Company has entered into share swap transaction agreements (the "swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price.  The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party.  As of September 30, 2018, the swap had a notional value based on 235,000 shares.  For the third quarter and nine months ended September 30, 2018, the swap resulted in gains of $0.4 million and of $0.1 million, respectively.  For the third quarter and nine months ended September 30, 2017, the swap resulted in gains of $0.7 million and $1.1 million, respectively.  Gains and losses resulting from the the swap were primarily offset by gains and losses on the fair value of the deferred compensation stock liability.  All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-18-000191:notes:46]
[same as prior period, unchanged from 0000038725-18-000152:notes:38]

[0000038725-18-000191:notes:47]
| (In millions) |  | September 30, 2018 |  | December 31, 2017 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortizing intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.5 |  |  | $ | (6.8 | ) |  | $ | 7.5 |  |  | $ | (6.7 | ) |
| Technology |  | 7.5 |  |  | (6.3 | ) |  | 7.5 |  |  | (5.8 | ) |
| Customer relationships |  | 148.4 |  |  | (61.4 | ) |  | 138.9 |  |  | (57.6 | ) |
| Other |  | 2.8 |  |  | (2.5 | ) |  | 2.9 |  |  | (2.4 | ) |
| Total |  | $ | 166.2 |  |  | $ | (77.0 | ) |  | $ | 156.8 |  |  | $ | (72.5 | ) |
| Unamortizing intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 45.5 |  |  | — |  |  | 47.2 |  |  | — |  |
| Total intangibles |  | $ | 211.7 |  |  | $ | (77.0 | ) |  | $ | 204.0 |  |  | $ | (72.5 | ) |

[0000038725-18-000191:notes:48]
Amortization expense related to intangible assets for the third quarters ended September 30, 2018 and September 30, 2017 was $2.2 million and $2.1 million, and for the nine months ended September 30, 2018 and September 30, 2017, $6.6 million and $6.4 million, respectively.

[0000038725-18-000191:notes:49]
[same as prior period, unchanged from 0000038725-18-000152:notes:41]

[0000038725-18-000191:notes:50]
| (In millions) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | 2022 |
|  |  | $ | 8.8 |  |  | $ | 9.0 |  |  | $ | 8.9 |  |  | $ | 8.5 |  |  | $ | 8.3 |  |

[0000038725-18-000191:notes:51]
The change in the carrying amount of goodwill by reportable segment for the nine months ended September 30, 2018, is as follows:

[0000038725-18-000191:notes:52]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2017 |  | $ | 139.3 |  |  | $ | 63.6 |  |  | $ | 33.9 |  |  | $ | 236.8 |  |
| Acquisitions |  | 11.2 |  |  | 4.1 |  |  | 1.8 |  |  | 17.1 |  |
| Foreign currency translation |  | (4.0 | ) |  | (0.2 | ) |  | — |  |  | (4.2 | ) |
| Balance as of September 30, 2018 |  | $ | 146.5 |  |  | $ | 67.5 |  |  | $ | 35.7 |  |  | $ | 249.7 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-18-000191:notes:53]
EMPLOYEE BENEFIT PLANS
Defined Benefit Plans - As of September 30, 2018, the Company maintained two domestic pension plans and three German pension plans.  The Company used a December 31, 2017 measurement date for these plans.  One of the Company's domestic pension plans covers one active management employee, while the other domestic plan covers all eligible employees (plan was frozen as of December 31, 2011).  The two domestic and three German plans collectively comprise the 'Pension Benefits' disclosure caption.

[0000038725-18-000191:notes:54]
[same as prior period, unchanged from 0000038725-18-000152:notes:46]

[0000038725-18-000191:notes:55]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the third quarters and nine months ended September 30, 2018 and September 30, 2017:

[0000038725-18-000191:notes:56]
| (In millions) | Pension Benefits |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
| Service cost | $ | 0.2 |  |  | $ | 0.2 |  |  | $ | 0.6 |  |  | $ | 0.5 |  |
| Interest cost | 1.4 |  |  | 1.4 |  |  | 4.1 |  |  | 4.3 |  |
| Expected return on assets | (2.1 | ) |  | (2.2 | ) |  | (6.4 | ) |  | (6.7 | ) |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | 0.7 |  |  | 0.7 |  |  | 2.2 |  |  | 2.0 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.2 |  |  | $ | 0.1 |  |  | $ | 0.5 |  |  | $ | 0.1 |  |

[0000038725-18-000191:notes:57]
In the nine months ended September 30, 2018, the Company made contributions of $2.1 million to the funded plans.   The amount of contributions to be made to the plans during the calendar year 2018 was finalized by September 15, 2018, based upon the funding level requirements identified and year-end valuation performed at December 31, 2017.

[0000038725-18-000191:notes:58]
The following table sets forth the aggregated net periodic benefit cost for the other post-retirement benefit plan for the third quarters and nine months ended September 30, 2018 and September 30, 2017.

[0000038725-18-000191:notes:59]
| (In millions) | Other Benefits |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 0.1 |  |  | — |  |  | 0.3 |  |  | 0.2 |  |
| Expected return on assets | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | 0.1 |  |  | — |  |  | 0.3 |  |
| Actuarial loss | — |  |  | — |  |  | 0.1 |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 0.4 |  |  | $ | 0.5 |  |

[0000038725-18-000191:notes:60]
The Company adopted ASU 2017-07 in the first quarter ended March 31, 2018.  The service cost component of net periodic benefit cost above is recorded in Selling, General, and Administrative expenses within the Condensed Consolidated Statements of Income, while the remaining components are recorded to Other income/(expense), net.  The prior year amounts have been reclassified to provide comparable presentation in line with the guidance.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-18-000191:notes:61]
INCOME TAXES
The Company’s effective tax rate from continuing operations for the nine months ended September 30, 2018 was 11.9 percent as compared to 15.4 percent for the nine months ended September 30, 2017. The effective tax rate is lower than the U.S. statutory rate of 21 percent primarily due to the recognition of the foreign-derived intangible income (FDII) provisions in the U.S. Tax Cuts and Jobs Act (Tax Act) and certain discrete events.  For the third quarter of  2018 the effective tax rate was 16.1 percent as compared to 19.0 percent for the third quarter of 2017.

[0000038725-18-000191:notes:62]
The decrease in the effective tax rate for the nine months ended September 30, 2018, compared with the same period in 2017, was primarily affected by the Tax Act, which reduced the U.S. federal corporate income tax rate from 35 percent to 21 percent effective January 1, 2018. The Company also reflected an estimated tax benefit of $3 million associated with the FDII provisions of the Tax Act that were effective for the first time during 2018. In addition, during the three months ended March 31, 2018, the Company released a valuation allowance of $5.4 million related to state NOLs and incentives as it is no longer in a three-year cumulative loss position for certain state income tax purposes.

[0000038725-18-000191:notes:63]
During the nine months ended September 30, 2018, the Company paid $1.6 million related to the one time transition tax liability imposed by the Tax Act, and in accordance with the IRS regulations has applied an estimated $5.8 million of 2017 overpayments against this tax.

[0000038725-18-000191:notes:64]
The Company’s accounting for certain aspects of the Tax Act remains provisional. As noted at year-end 2017, the Company was able to reasonably estimate certain effects and, therefore, recorded provisional adjustments associated with the deemed repatriation transition tax and the remeasurement of deferred taxes. The Company made additional measurement period adjustments related to these items during the third quarter. The Company recorded additional expense of $0.4 million related to the deemed repatriation transition tax on the domestic federal return as a result of revised earnings and profits and aggregate cash computations that were calculated during the reporting period, additional expense of $0.2 million for the deemed repatriation transition tax on domestic state tax returns as a result of recent state tax legislation passed during the reporting period, and a benefit of $0.4 million related to the remeasurement of deferred taxes resulting from domestic federal return to provision true ups that were calculated during the reporting period. However, the Company is continuing to gather additional information from foreign subsidiaries and tax authorities to complete our accounting for the tax effects of the Tax Act. The accounting will be completed in 2018.


## us-gaap:DebtDisclosureTextBlock

[0000038725-18-000191:notes:65]
DEBT
Debt consisted of the following:

[0000038725-18-000191:notes:66]
| (In millions) |  | September 30, 2018 |  | December 31, 2017 |
| Prudential Agreement |  | $ | 30.0 |  |  | $ | 60.0 |  |
| Tax increment financing debt |  | 19.7 |  |  | 20.8 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 89.1 |  |  | 67.0 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 3.4 |  |  | 3.5 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 217.0 |  |  | $ | 226.1 |  |
| Less: current maturities |  | (122.8 | ) |  | (100.5 | ) |
| Long-term debt |  | $ | 94.2 |  |  | $ | 125.6 |  |

[0000038725-18-000191:notes:67]
Debt outstanding, excluding unamortized debt issuance costs, at September 30, 2018 matures as follows:

[0000038725-18-000191:notes:68]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 217.2 |  |  | $ | 122.8 |  |  | $ | 1.2 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 89.4 |  |
| Capital leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 217.3 |  |  | $ | 122.8 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 89.4 |  |

[0000038725-18-000191:notes:69]
Prudential Agreement

[0000038725-18-000191:notes:70]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with an initial borrowing capacity of $250.0 million.  The Prudential Agreement bears a coupon of 5.79 percent with a final maturity in 2019.  Principal installments of $30.0 million are payable annually, including the date of maturity of April 30, 2019, with any unpaid balance due at that time.  There is no additional borrowing capacity resulting from principal payments made by the Company.  As of September 30, 2018, the Company has $150.0 million borrowing capacity available under the Prudential Agreement.

[0000038725-18-000191:notes:71]
Project Bonds

[0000038725-18-000191:notes:72]
The Company, Allen County, Indiana and certain institutional investors maintain a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)." The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. These Project Notes ("Tax increment financing debt") bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.

[0000038725-18-000191:notes:73]
New York Life Agreement

[0000038725-18-000191:notes:74]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"), with a maximum aggregate borrowing capacity of $200.0 million.  On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually.  The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of September 30, 2018, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-18-000191:notes:75]
Credit Agreement

[0000038725-18-000191:notes:76]
The Company maintains the Third Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement has a maturity date of October 28, 2021 and commitment amount of $300.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million).  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable

[0000038725-18-000191:notes:77]
quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-18-000191:notes:78]
As of September 30, 2018, the Company had $89.1 million in outstanding borrowings which were primarily used for acquisition and working capital needs, $5.6 million in letters of credit outstanding, and $205.3 million of available capacity under the Credit Agreement.

[0000038725-18-000191:notes:79]
Covenants
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of September 30, 2018.


## us-gaap:EarningsPerShareTextBlock

[0000038725-18-000191:notes:80]
[same as prior period, unchanged from 0000038725-18-000152:notes:72]

[0000038725-18-000191:notes:81]
[same as prior period, unchanged from 0000038725-18-000152:notes:73]

[0000038725-18-000191:notes:82]
[same as prior period, unchanged from 0000038725-18-000152:notes:74]

[0000038725-18-000191:notes:83]
|  | Third Quarter Ended |  | Nine Months Ended |
| (In millions, except per share amounts) | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 30.0 |  |  | $ | 24.5 |  |  | $ | 81.7 |  |  | $ | 70.1 |  |
| Less: Earnings allocated to participating securities | 0.2 |  |  | 0.2 |  |  | 0.6 |  |  | 0.5 |  |
| Net income available to common shareholders | $ | 29.8 |  |  | $ | 24.3 |  |  | $ | 81.1 |  |  | $ | 69.6 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 46.7 |  |  | 46.5 |  |  | 46.7 |  |  | 46.5 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |
| Non-participating employee stock options and performance awards | 0.5 |  |  | 0.5 |  |  | 0.5 |  |  | 0.5 |  |
| Diluted weighted average common shares outstanding | 47.2 |  |  | 47.0 |  |  | 47.2 |  |  | 47.0 |  |
| Basic earnings per share | $ | 0.64 |  |  | $ | 0.52 |  |  | $ | 1.74 |  |  | $ | 1.50 |  |
| Diluted earnings per share | $ | 0.63 |  |  | $ | 0.52 |  |  | $ | 1.72 |  |  | $ | 1.48 |  |

[0000038725-18-000191:notes:84]
There were 0.2 million and 0.4 million stock options outstanding for the third quarters ended September 30, 2018 and September 30, 2017, and 0.2 million and 0.3 million stock options outstanding for the nine months ended September 30, 2018 and September 30, 2017, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-18-000191:notes:85]
EQUITY ROLL FORWARD
The schedule below sets forth equity changes in the nine months ended September 30, 2018:

[0000038725-18-000191:notes:86]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2017 | $ | 4,663 |  |  | $ | 240,136 |  |  | $ | 604,905 |  |  | $ | (49,364 | ) |  | $ | (99,683 | ) |  | $ | 1,964 |  |  | $ | 702,621 |  |  | $ | 1,502 |  |
| Net income |  |  |  |  | 81,677 |  |  |  |  |  |  | 527 |  |  | 82,204 |  |  | (1,018 | ) |
| Dividends on common stock |  |  |  |  | (16,299 | ) |  |  |  |  |  |  |  | (16,299 | ) |  |  |
| Common stock issued | 38 |  |  | 8,709 |  |  |  |  |  |  |  |  |  |  | 8,747 |  |  |  |
| Common stock repurchased | (29 | ) |  |  |  | (12,051 | ) |  |  |  |  |  |  |  | (12,080 | ) |  |  |
| Share-based compensation | 10 |  |  | 6,617 |  |  |  |  |  |  |  |  |  |  | 6,627 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | (661 | ) |  | (661 | ) |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (36,576 | ) |  | (35 | ) |  | (36,611 | ) |  | 132 |  |
| Pension liability, net of tax |  |  |  |  |  |  | 1,797 |  |  |  |  |  |  | 1,797 |  |  |  |
| Balance as of September 30, 2018 | $ | 4,682 |  |  | $ | 255,462 |  |  | $ | 658,232 |  |  | $ | (47,567 | ) |  | $ | (136,259 | ) |  | $ | 1,795 |  |  | $ | 736,345 |  |  | $ | 616 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-18-000191:notes:87]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS) 
Changes in accumulated other comprehensive income/(loss) by component for the nine months ended September 30, 2018 and September 30, 2017, are summarized below:

[0000038725-18-000191:notes:88]
| (In millions) |  |  |  |  |  |
| For the nine months ended September 30, 2018: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| Balance as of December 31, 2017 | $ | (99.7 | ) |  | $ | (49.3 | ) |  | $ | (149.0 | ) |
| Other comprehensive income/(loss) before reclassifications | (36.6 | ) |  | — |  |  | (36.6 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 1.8 |  |  | 1.8 |  |
| Net other comprehensive income/(loss) | (36.6 | ) |  | 1.8 |  |  | (34.8 | ) |
| Balance as of September 30, 2018 | $ | (136.3 | ) |  | $ | (47.5 | ) |  | $ | (183.8 | ) |
| For the nine months ended September 30, 2017 |  |  |  |  |  |
| Balance as of December 31, 2016 | $ | (118.4 | ) |  | $ | (51.5 | ) |  | $ | (169.9 | ) |
| Other comprehensive income/(loss) before reclassifications | 21.6 |  |  | — |  |  | 21.6 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 1.5 |  |  | 1.5 |  |
| Net other comprehensive income/(loss) | 21.6 |  |  | 1.5 |  |  | 23.1 |  |
| Balance as of September 30, 2017 | $ | (96.8 | ) |  | $ | (50.0 | ) |  | $ | (146.8 | ) |

[0000038725-18-000191:notes:89]
[same as prior period, unchanged from 0000038725-18-000152:notes:81]

[0000038725-18-000191:notes:90]
(2) Net of tax expense of $0.5 million and $0.8 million for the nine months ended September 30, 2018 and September 30, 2017, respectively.

[0000038725-18-000191:notes:91]
[same as prior period, unchanged from 0000038725-18-000152:notes:83]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-18-000191:notes:92]
SEGMENT AND GEOGRAPHIC INFORMATION
The accounting policies of the operating segments are the same as those described in Note 1 of the Company's Form 10-K.  Revenue is recognized based on the invoice price at the point in time when the customer obtains control of the product, which is typically upon shipment to the customer.  The Water and Fueling segments include manufacturing operations and supply certain components and finished goods, both between segments and to the Distribution segment.  In the prior year, the Company reported certain product transfers between Water and Fueling as intersegment revenue.  The Company is now reporting these product transfers between Water and Fueling as inventory transfers as a significant number of the Company's manufacturing facilities are shared across segments for scale and efficiency purposes.  The Company continues to report intersegment transfers from Water to Distribution as intersegment revenue at market prices to properly reflect the commercial arrangement of vendor to customer that exists between the Water and Distribution segments.  Segment operating income is a key financial performance measure. Operating income by segment is based on net sales less identifiable operating expenses and allocations and includes profits recorded on sales to other segments of the Company.  The Company has retrospectively revised segment results in prior periods' to conform with current period presentations.  There is no impact on the Company's previously reported consolidated financial position, results of operations, or cash flows.

[0000038725-18-000191:notes:93]
[same as prior period, unchanged from 0000038725-18-000152:notes:85]

[0000038725-18-000191:notes:94]
|  | Third Quarter Ended |  | Nine Months Ended |
| (In millions) | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
|  | Net sales |
| Water Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | $ | 92.6 |  |  | $ | 80.0 |  |  | $ | 267.2 |  |  | $ | 239.1 |  |
| Latin America | 31.2 |  |  | 32.6 |  |  | 89.3 |  |  | 96.6 |  |
| Europe, Middle East & Africa | 44.0 |  |  | 46.9 |  |  | 141.8 |  |  | 133.4 |  |
| Asia Pacific | 17.3 |  |  | 19.4 |  |  | 57.2 |  |  | 62.6 |  |
| Intersegment sales |  |  |  |  |  |  |  |
| United States & Canada | 13.2 |  |  | 17.1 |  |  | 45.0 |  |  | 30.2 |  |
| Total sales | 198.3 |  |  | 196.0 |  |  | 600.5 |  |  | 561.9 |  |
| Distribution |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |  |  |  |  |
| United States & Canada | 78.0 |  |  | 68.1 |  |  | 213.7 |  |  | 127.2 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 78.0 |  |  | 68.1 |  |  | 213.7 |  |  | 127.2 |  |
| Fueling Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |  |  |  |  |
| United States & Canada | 44.7 |  |  | 40.9 |  |  | 116.0 |  |  | 106.5 |  |
| All other | 34.1 |  |  | 23.2 |  |  | 96.3 |  |  | 71.3 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 78.8 |  |  | 64.1 |  |  | 212.3 |  |  | 177.8 |  |
| Intersegment Eliminations/Other | (13.2 | ) |  | (17.1 | ) |  | (45.0 | ) |  | (30.2 | ) |
| Consolidated | $ | 341.9 |  |  | $ | 311.1 |  |  | $ | 981.5 |  |  | $ | 836.7 |  |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | September 30, 2018 |  | September 30, 2017 |  | September 30, 2018 |  | September 30, 2017 |
|  | Operating income/(loss) |
| Water Systems | $ | 28.4 |  |  | $ | 28.3 |  |  | $ | 85.9 |  |  | $ | 82.5 |  |
| Distribution | 3.1 |  |  | 2.0 |  |  | 6.3 |  |  | 5.7 |  |
| Fueling Systems | 20.9 |  |  | 17.1 |  |  | 53.4 |  |  | 43.0 |  |
| Intersegment Eliminations/Other | (12.3 | ) |  | (15.4 | ) |  | (42.3 | ) |  | (46.4 | ) |
| Consolidated | $ | 40.1 |  |  | $ | 32.0 |  |  | $ | 103.3 |  |  | $ | 84.8 |  |

[0000038725-18-000191:notes:95]
|  | September 30, 2018 |  | December 31, 2017 |
|  | Total assets |
| Water Systems | $ | 678.4 |  |  | $ | 695.4 |  |
| Distribution | 175.1 |  |  | 153.1 |  |
| Fueling Systems | 283.1 |  |  | 265.7 |  |
| Other | 55.6 |  |  | 71.2 |  |
| Consolidated | $ | 1,192.2 |  |  | $ | 1,185.4 |  |

[0000038725-18-000191:notes:96]
[same as prior period, unchanged from 0000038725-18-000152:notes:88]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-18-000191:notes:97]
COMMITMENTS AND CONTINGENCIES
The Company is defending various claims and legal actions which have arisen in the ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-18-000191:notes:98]
At September 30, 2018, the Company had $4.1 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-18-000191:notes:99]
The Company provides warranties on most of its products.  The warranty terms vary but are generally two years to five years from date of manufacture or one year to five years from date of installation.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-18-000191:notes:100]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 30, 2018, are as follows:

[0000038725-18-000191:notes:101]
| (In millions) |  |  |
| Balance as of December 31, 2017 |  | $ | 9.5 |  |
| Accruals related to product warranties |  | 6.7 |  |
| Additions related to acquisitions |  | 0.1 |  |
| Reductions for payments made |  | (7.7 | ) |
| Balance as of September 30, 2018 |  | $ | 8.6 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-18-000191:notes:102]
[same as prior period, unchanged from 0000038725-18-000152:notes:94]

[0000038725-18-000191:notes:103]
[same as prior period, unchanged from 0000038725-18-000152:notes:95]

[0000038725-18-000191:notes:104]
[same as prior period, unchanged from 0000038725-18-000152:notes:96]

[0000038725-18-000191:notes:105]
[same as prior period, unchanged from 0000038725-18-000152:notes:97]

[0000038725-18-000191:notes:106]
[same as prior period, unchanged from 0000038725-18-000152:notes:98]

[0000038725-18-000191:notes:107]
[same as prior period, unchanged from 0000038725-18-000152:notes:99]

[0000038725-18-000191:notes:108]
[same as prior period, unchanged from 0000038725-18-000152:notes:100]

[0000038725-18-000191:notes:109]
[same as prior period, unchanged from 0000038725-18-000152:notes:101]

[0000038725-18-000191:notes:110]
[same as prior period, unchanged from 0000038725-18-000152:notes:102]

[0000038725-18-000191:notes:111]
[same as prior period, unchanged from 0000038725-18-000152:notes:103]

[0000038725-18-000191:notes:112]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the nine months ended September 30, 2018 and September 30, 2017 are as follows:

[0000038725-18-000191:notes:113]
|  |  | September 30, 2018 |  | September 30, 2017 |
| Risk-free interest rate |  | 2.69 | % |  | 1.89 | % |
| Dividend yield |  | 1.05 | % |  | 0.94 | % |
| Volatility factor |  | 28.71 | % |  | 31.19 | % |
| Expected term |  | 5.6 years |  |  | 5.5 years |  |

[0000038725-18-000191:notes:114]
A summary of the Company’s outstanding stock option activity and related information for the nine months ended September 30, 2018 is as follows:

[0000038725-18-000191:notes:115]
| (Shares in thousands) |  | September 30, 2018 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,388 |  |  | $ | 28.79 |  |
| Granted |  | 251 |  |  | 40.26 |  |
| Exercised |  | (380 | ) |  | 23.00 |  |
| Forfeited |  | (5 | ) |  | 37.63 |  |
| Outstanding at end of period |  | 1,254 |  |  | $ | 32.80 |  |
| Expected to vest after applying forfeiture rate |  | 1,231 |  |  | $ | 32.68 |  |
| Vested and exercisable at end of period |  | 715 |  |  | $ | 28.76 |  |

[0000038725-18-000191:notes:116]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value as of September 30, 2018 is as follows:

[0000038725-18-000191:notes:117]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 6.27 years |  | $ | 18,111 |  |
| Expected to vest after applying forfeiture rate |  | 6.22 years |  | $ | 17,925 |  |
| Vested and exercisable at end of period |  | 4.58 years |  | $ | 13,211 |  |

[0000038725-18-000191:notes:118]
The total intrinsic value of options exercised during the nine months ended September 30, 2018 and September 30, 2017 was $9.4 million and $4.8 million, respectively.

[0000038725-18-000191:notes:119]
As of September 30, 2018, there was $1.7 million of total unrecognized compensation cost related to non-vested stock options granted under the 2012 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.62 years.

[0000038725-18-000191:notes:120]
[same as prior period, unchanged from 0000038725-18-000152:notes:112]

[0000038725-18-000191:notes:121]
A summary of the Company’s restricted stock/stock unit award activity and related information for the nine months ended September 30, 2018 is as follows:

[0000038725-18-000191:notes:122]
| (Shares in thousands) |  | September 30, 2018 |
| Restricted Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 463 |  |  | $ | 36.71 |  |
| Awarded |  | 164 |  |  | 40.48 |  |
| Vested |  | (87 | ) |  | 40.77 |  |
| Forfeited |  | (35 | ) |  | 36.62 |  |
| Non-vested at end of period |  | 505 |  |  | $ | 37.24 |  |

[0000038725-18-000191:notes:123]
As of September 30, 2018, there was $10.7 million of total unrecognized compensation cost related to non-vested restricted stock/stock unit awards granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.32 years.
