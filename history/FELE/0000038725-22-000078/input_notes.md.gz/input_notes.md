# FELE notes — 0000038725-22-000078


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-22-000078:notes:1]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2021, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2022, and for the first quarters ended March 31, 2022 and March 31, 2021 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the first quarter ended March 31, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2022. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2021.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000038725-22-000078:notes:2]
ACCOUNTING PRONOUNCEMENTS
Adoption of New Accounting Standards

[0000038725-22-000078:notes:3]
In August 2020, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2020-06, Debt – Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging – Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity. ASU 2020-06 reduces the number of accounting models for various convertible instruments and reduces form-over-substance-based accounting conclusions for the derivatives scope exception for contracts in an entity’s own equity. The FASB also updated Earnings Per Share (“EPS”) guidance under Topic 260 by requiring an entity to consider the potential effect of share settlement in the diluted EPS calculation for instruments that may be settled in cash or shares as well as other amendments. ASU 2020-06 is effective for interim and annual periods beginning after December 15, 2021 with early adoption permitted but no earlier than fiscal years beginning after December 15, 2020. The guidance should be adopted at the beginning of a fiscal year. ASU 2020-06 should be applied on either a retrospective or modified retrospective basis. The Company adopted the standard effective January 1, 2022 using the modified retrospective approach, and it did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-22-000078:notes:4]
Accounting Standards Issued But Not Yet Adopted

[0000038725-22-000078:notes:5]
In October 2021, the FASB issued ASU 2021-08, Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers. ASU 2021-08 requires entities to recognize and measure contracts on the acquisition date in accordance with ASC 606, Revenue from Contracts with Customers, as if it had originated the contracts. This will improve comparability after the business combination by providing consistent recognition and measurement guidance for revenue contracts with customers acquired in a business combination and revenue contracts with customers not acquired in a business combination. ASU 2021-08 is effective for interim and annual periods beginning after December 15, 2022 with early adoption permitted. ASU 2021-08 should be applied on a prospective basis to business combinations that occur after the effective date. The Company is still determining the date of adoption for this ASU, but does not anticipate the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-22-000078:notes:6]
ACQUISITIONS
During the fourth quarter ended December 31, 2021, the Company acquired 100 percent of the ownership interests of B&R Industries, Inc. ("B&R"), a water treatment equipment provider located in Mesa, Arizona, for a cash purchase price of $16.2 million after purchase price adjustments based on the level of working capital acquired.  B&R will be included as part of the Water Systems segment of the Company. The Company also acquired, in a separate transaction, 100 percent of the ownership interests of Blake Group Holdings, Inc. ("Blake"), a professional groundwater distributor operating in the northeast United States for a cash purchase price of $28.6 million after purchase price adjustments based on the level of working capital acquired. Blake will be included as part of the Distribution segment of the Company.  The fair value of the assets acquired and liabilities assumed for both acquisitions is preliminary as of  March 31, 2022.

[0000038725-22-000078:notes:7]
During the third quarter ended September 30, 2021, the Company acquired 100 percent of the ownership interests of Minetuff Dewatering Pumps Australia Pty Ltd for a cash purchase price of $13.7 million after purchase price adjustments based on the level of working capital acquired. Minetuff manufactures and sells submersible pumps, spare parts, and accessories to the mining industry and will expand the Company’s existing product offerings and channel access in the Water Systems segment. The fair value of the assets acquired and liabilities assumed for the acquisition is preliminary as of  March 31, 2022.

[0000038725-22-000078:notes:8]
[same as prior period, unchanged from 0000038725-21-000210:notes:9]

[0000038725-22-000078:notes:9]
In another separate transaction during the second quarter ended June 30, 2021, the Company acquired all of the assets of Atlantic Turbine Pump, LLC, a Georgia-based company, which will be included in the Distribution segment of the Company. The Company recorded estimated fair values that exceed the acquisition price by $0.4 million, representing a bargain purchase gain due to favorable market conditions within the "Other income/(expense), net" line in the consolidated statements of income for the year ended December 31, 2021.

[0000038725-22-000078:notes:10]
The combined, all-cash purchase price for all acquisitions in the second quarter was $185.5 million after purchase price adjustments based on the level of working capital acquired. The fair value of the assets acquired and liabilities assumed for all acquisitions are preliminary as of March 31, 2022.

[0000038725-22-000078:notes:11]
The identifiable intangible assets recognized in the separate transactions in 2021, were $131.9 million, and consist primarily of customer relationships and trade names from New Aqua of $93.7 million, which will be amortized using the straight-line method over 12 - 20 years.

[0000038725-22-000078:notes:12]
The goodwill of $65.4 million resulting from the acquisitions in 2021 consists primarily of expanded geographical presence and product channel expansion.  Goodwill deductible for tax purposes is $61.6 million from the acquisitions in 2021. Goodwill was recorded in the Water Systems and Fueling Systems segments.

[0000038725-22-000078:notes:13]
The preliminary purchase price assigned to the major identifiable assets and liabilities for all acquisitions in 2021 on an aggregated basis is as follows:

[0000038725-22-000078:notes:14]
| (In millions) |  |  |
| Assets: |  |  |
| Inventory |  | $ | 34.4 |  |
| Intangible assets |  | 131.9 |
| Goodwill |  | 65.4 |
| Other assets |  | 39.3 |
| Total assets |  | 271.0 |
| Liabilities |  | 26.6 |
| Less: Bargain purchase gain |  | 0.4 |
| Total consideration paid |  | $ | 244.0 |  |

[0000038725-22-000078:notes:15]
For all acquisitions in 2021, consolidated revenue for the first quarter ended  March 31, 2021 was $45.3 million, which would be incremental to the Company's revenue had the acquisitions occurred on the first day of 2021. Consolidated revenue for the first quarter ended March 31, 2022 was $48.2 million. The Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2021, as the results of operations for all acquisitions is immaterial.

[0000038725-22-000078:notes:16]
Transaction costs were expensed as incurred under the guidance of FASB Accounting Standards Codification Topic 805, Business Combinations. There were $0.2 million and $0.1 million of transaction costs included in the "Selling, general, and administrative expenses" line of the Company's condensed consolidated statements of income for the first quarter ended March 31, 2022 and  March 31, 2021, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-22-000078:notes:17]
FAIR VALUE MEASUREMENTSFASB ASC Topic 820, Fair Value Measurements and Disclosures, provides guidance for defining, measuring, and disclosing fair value within an established framework and hierarchy. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. The standard established a fair value hierarchy which 
requires an entity to maximize the use of observable inputs and to minimize the use of unobservable inputs when measuring fair value. The three levels of inputs that may be used to measure fair value within the hierarchy are as follows:

[0000038725-22-000078:notes:18]
[same as prior period, unchanged from 0000038725-21-000210:notes:18]

[0000038725-22-000078:notes:19]
[same as prior period, unchanged from 0000038725-21-000210:notes:19]

[0000038725-22-000078:notes:20]
[same as prior period, unchanged from 0000038725-21-000210:notes:20]

[0000038725-22-000078:notes:21]
As of March 31, 2022 and December 31, 2021, the assets and liabilities measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-22-000078:notes:22]
| (In millions) | March 31, 2022 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 7.2 |  | $ | 7.2 |  | $ | — |  | $ | — |  |
| Share swap transaction | — |  | — |  | — |  | — |  |
| Forward currency contracts assets | 0.1 |  | — |  | 0.1 |  | — |  |
| Total assets | $ | 7.3 |  | $ | 7.2 |  | $ | 0.1 |  | $ | — |  |
| Liabilities: |  |  |  |  |
| Forward currency contracts liabilities | $ | 0.2 |  | $ | — |  | $ | 0.2 |  | $ | — |  |
| Total liabilities | $ | 0.2 |  | $ | — |  | $ | 0.2 |  | $ | — |  |
|  | December 31, 2021 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 5.3 |  | $ | 5.3 |  | $ | — |  | $ | — |  |
| Share swap transaction | 0.6 |  | 0.6 |  | — |  | — |  |
| Total assets | $ | 5.9 |  | $ | 5.9 |  | $ | — |  | $ | — |  |

[0000038725-22-000078:notes:23]
The Company’s Level 1 cash equivalents assets are generally comprised of foreign bank guaranteed certificates of deposit and short term deposits. The share swap transaction and forward currency contracts assets and liabilities are recorded within the "Receivables" and "Accounts Payable" lines of the condensed consolidated balance sheets and are further described in Note 5 - Financial Instruments.

[0000038725-22-000078:notes:24]
The Company has no assets or liabilities measured on a recurring basis classified as Level 3.
Total debt, including current maturities, have carrying amounts of $284.7 million and $188.5 million and estimated fair values of $287.1 million and $196.1 million as of March 31, 2022 and December 31, 2021, respectively. In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value. Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction. In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities. Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-22-000078:notes:25]
FINANCIAL INSTRUMENTSThe Company’s non-employee directors' deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period. The Company has entered into share swap transaction agreements (the "swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price. The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party. As of March 31, 2022, the swap had a notional value based on 210,000 shares. For the first quarter ended 
March 31, 2022 and March 31, 2021, the swap resulted in a loss of $2.4 million and a gain of $2.7 million, respectively. Gains and losses resulting from the swap were largely offset by gains and losses on the fair value of the deferred compensation stock liability. All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.

[0000038725-22-000078:notes:26]
The Company is exposed to foreign currency exchange rate risk arising from transactions in the normal course of business including making sales and purchases of raw materials and finished goods in foreign denominated currencies with third party customers and suppliers as well as to wholly owned subsidiaries of the Company.  To reduce its exposure to foreign currency exchange rate volatility, the Company enters into various forward currency contracts to offset these fluctuations. The Company uses forward currency contracts only in an attempt to limit underlying exposure from foreign currency exchange rate fluctuations and to minimize earnings volatility associated with foreign currency exchange rate fluctuations and has not elected to use hedge accounting. Decisions on whether to use such derivative instruments are primarily based on the amount of exposure to the currency involved and an assessment of the near-term market value for each currency.  For the first quarter ended March 31, 2022, the forward currency contracts resulted in a loss of $0.2 million and is recorded in the Company's condensed consolidated statements of income within the "Foreign exchange income/(expense)" line.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-22-000078:notes:27]
[same as prior period, unchanged from 0000038725-21-000210:notes:26]

[0000038725-22-000078:notes:28]
| (In millions) |  | March 31, 2022 |  | December 31, 2021 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortizing intangibles: |  |  |  |  |  |  |  |  |
| Customer relationships |  | 256.2 |  |  | (92.7) |  |  | 255.1 |  |  | (88.8) |  |
| Patents |  | $ | 7.3 |  |  | $ | (7.3) |  |  | $ | 7.3 |  |  | $ | (7.3) |  |
| Technology |  | 7.5 |  |  | (7.4) |  |  | 7.5 |  |  | (7.3) |  |
| Trade names |  | 42.2 |  |  | (2.1) |  |  | $ | 42.1 |  |  | (1.5) |  |
| Other |  | 2.8 |  |  | (2.7) |  |  | 2.8 |  |  | (2.7) |  |
| Total |  | $ | 316.0 |  |  | $ | (112.2) |  |  | $ | 314.8 |  |  | $ | (107.6) |  |
| Unamortizing intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 43.3 |  |  | — |  |  | 42.5 |  |  | — |  |
| Total intangibles |  | $ | 359.3 |  |  | $ | (112.2) |  |  | $ | 357.3 |  |  | $ | (107.6) |  |

[0000038725-22-000078:notes:29]
Amortization expense related to intangible assets for the first quarters ended March 31, 2022 and March 31, 2021 was $4.3 million and $2.5 million, respectively.

[0000038725-22-000078:notes:30]
[same as prior period, unchanged from 0000038725-21-000210:notes:29]

[0000038725-22-000078:notes:31]
| (In millions) |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 |
|  |  | $ | 17.1 |  |  | $ | 17.0 |  |  | $ | 16.9 |  |  | $ | 16.0 |  |  | $ | 15.1 |  |

[0000038725-22-000078:notes:32]
The change in the carrying amount of goodwill by reportable segment for the three months ended March 31, 2022, is as follows:

[0000038725-22-000078:notes:33]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2021 |  | $ | 213.9 |  |  | $ | 70.7 |  |  | $ | 45.0 |  |  | $ | 329.6 |  |
| Acquisitions |  | — |  |  | — |  |  | — |  |  | — |  |
| Adjustments to prior year acquisitions |  | — |  |  | — |  |  | (0.5) |  |  | (0.5) |  |
| Foreign currency translation |  | 0.4 |  |  | (0.1) |  |  | — |  |  | 0.3 |  |
| Balance as of March 31, 2022 |  | $ | 214.3 |  |  | $ | 70.6 |  |  | $ | 44.5 |  |  | $ | 329.4 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-22-000078:notes:34]
EMPLOYEE BENEFIT PLANS
Defined Benefit Plans - As of March 31, 2022, the Company maintained two domestic pension plans and three German pension plans. The Company used a December 31, 2021 measurement date for these plans. One of the Company's domestic pension plans covers one active management employee, while the other domestic plan covers all eligible employees. Both domestic plans were frozen as of December 31, 2011. The two domestic and three German plans collectively comprise the 'Pension Benefits' disclosure caption.

[0000038725-22-000078:notes:35]
[same as prior period, unchanged from 0000038725-21-000210:notes:34]

[0000038725-22-000078:notes:36]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the first quarters ended March 31, 2022 and March 31, 2021:

[0000038725-22-000078:notes:37]
| (In millions) | Pension Benefits |
|  | First Quarter Ended |  |  |
|  | March 31, 2022 |  | March 31, 2021 |  |  |  |  |
| Service cost | $ | 0.2 |  |  | $ | 0.2 |  |  |  |  |  |
| Interest cost | 0.8 |  |  | 0.7 |  |  |  |  |  |
| Expected return on assets | (1.5) |  |  | (1.4) |  |  |  |  |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  |  |  |  |
| Actuarial loss | 1.2 |  |  | 1.0 |  |  |  |  |  |
| Settlement cost | — |  |  | — |  |  |  |  |  |
| Net periodic benefit cost | $ | 0.7 |  |  | $ | 0.5 |  |  |  |  |  |

[0000038725-22-000078:notes:38]
In the three months ended March 31, 2022, the Company made contributions of $0.1 million to the funded plans. The amount of contributions to be made to the plans during the calendar year 2022 will be finalized by September 15, 2022, based upon the funding level requirements identified and year-end valuation performed at December 31, 2021.

[0000038725-22-000078:notes:39]
The following table sets forth the aggregated net periodic benefit cost for the other post-retirement benefit plan for the first quarters ended March 31, 2022 and March 31, 2021:

[0000038725-22-000078:notes:40]
| (In millions) | Other Benefits |
|  | First Quarter Ended |  |  |
|  | March 31, 2022 |  | March 31, 2021 |  |  |  |  |
| Service cost | $ | — |  |  | $ | — |  |  |  |  |  |
| Interest cost | 0.1 |  |  | — |  |  |  |  |  |
| Expected return on assets | — |  |  | — |  |  |  |  |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  |  |  |  |
| Actuarial loss | — |  |  | 0.1 |  |  |  |  |  |
| Settlement cost | — |  |  | — |  |  |  |  |  |
| Net periodic benefit cost | $ | 0.1 |  |  | $ | 0.1 |  |  |  |  |  |


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0000038725-22-000078:notes:41]
[same as prior period, unchanged from 0000038725-21-000210:notes:40]

[0000038725-22-000078:notes:42]
| (In millions) |  | March 31, 2022 |  | December 31, 2021 |
| Salaries, wages, and commissions |  | 39.6 |  |  | 62.3 |  |
| Product warranty costs |  | 10.6 |  |  | 10.5 |  |
| Insurance |  | 1.8 |  |  | 2.3 |  |
| Employee benefits |  | 5.7 |  |  | 11.9 |  |
| Other |  | 29.6 |  |  | 28.4 |  |
| Total |  | 87.3 |  |  | 115.4 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-22-000078:notes:43]
INCOME TAXES
The Company’s effective tax rate from continuing operations for the three month period ended March 31, 2022 was 19.7 percent as compared to 13.5 percent for the three month period ended March 31, 2021. The effective tax rate is lower than the U.S. statutory rate of 21 percent primarily due to the recognition of the U.S. foreign-derived intangible income (FDII) provisions and certain discrete events including excess tax benefits from share-based compensation partially offset by state taxes.

[0000038725-22-000078:notes:44]
The increase in the effective tax rate was primarily a result of less favorable discrete events recorded in the three month period ended March 31, 2022, as compared to the three month period ended March 31, 2021.


## us-gaap:DebtDisclosureTextBlock

[0000038725-22-000078:notes:45]
DEBT
Debt consisted of the following:

[0000038725-22-000078:notes:46]
| (In millions) |  | March 31, 2022 |  | December 31, 2021 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 191.8 |  |  | 96.6 |  |
| Tax increment financing debt |  | 15.9 |  |  | 16.5 |  |
| Foreign subsidiary debt |  | 2.2 |  |  | 0.5 |  |
| Other |  | — |  |  | 0.1 |  |
| Less: unamortized debt issuance costs |  | (0.2) |  |  | (0.2) |  |
|  |  | $ | 284.7 |  |  | $ | 188.5 |  |
| Less: current maturities |  | (194.8) |  |  | (98.0) |  |
| Long-term debt |  | $ | 89.9 |  |  | 90.5 |

[0000038725-22-000078:notes:47]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2022 matures as follows:

[0000038725-22-000078:notes:48]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 284.9 |  |  | $ | 194.8 |  |  | $ | 1.4 |  |  | $ | 1.4 |  |  | $ | 76.4 |  |  | $ | 1.5 |  |  | $ | 9.4 |  |

[0000038725-22-000078:notes:49]
Prudential Agreement

[0000038725-22-000078:notes:50]
The Company maintains the Fourth Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with PGIM, Inc. and its affiliates, which was renewed on July 30, 2021 and expires on July 30, 2024.  The Prudential Agreement has an initial borrowing capacity of $150.0 million. As of March 31, 2022, the Company had no notes issued and  $150.0 million borrowing capacity available under the Prudential Agreement.

[0000038725-22-000078:notes:51]
Project Bonds

[0000038725-22-000078:notes:52]
The Company, Allen County, Indiana and certain institutional investors maintain a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)." The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. These Project Bonds ("Tax increment financing debt") bear interest at 3.6 percent per annum. Interest and principal balance of the Project Bonds are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.

[0000038725-22-000078:notes:53]
New York Life Agreement

[0000038725-22-000078:notes:54]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC and its affiliates (the "New York Life Agreement"), which was renewed on July 30, 2021 and expires on July 30, 2024. The New York Life Agreement has a maximum aggregate borrowing capacity of $200.0 million. On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of March 31, 2022, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-22-000078:notes:55]
Credit Agreement

[0000038725-22-000078:notes:56]
The Company maintains the Fourth Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement was renewed on May 13, 2021, has a maturity date of May 13, 2026, and commitment amount of $250.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $125.0 million subject to agreement of the lenders (not to exceed a total commitment of $375.0 million). Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.85% to 1.88% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-22-000078:notes:57]
As of March 31, 2022, the Company had $191.8 million outstanding borrowings, $4.0 million in letters of credit outstanding, and $54.2 million of available capacity under the Credit Agreement.

[0000038725-22-000078:notes:58]
The Company also has lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $20.2 million. As of March 31, 2022, there were $1.8 million outstanding borrowings and $18.4 million of available capacity under these lines of credit.

[0000038725-22-000078:notes:59]
Covenants

[0000038725-22-000078:notes:60]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of March 31, 2022.


## us-gaap:EarningsPerShareTextBlock

[0000038725-22-000078:notes:61]
[same as prior period, unchanged from 0000038725-21-000210:notes:59]

[0000038725-22-000078:notes:62]
Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period. Diluted earnings per common share is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.
The following table sets forth the computation of basic and diluted earnings per share:

[0000038725-22-000078:notes:63]
|  | First Quarter Ended |  |  |
| (In millions, except per share amounts) | March 31, 2022 |  | March 31, 2021 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 29.8 |  |  | $ | 27.9 |  |  |  |  |  |
| Less: Earnings allocated to participating securities | 0.1 |  |  | 0.2 |  |  |  |  |  |
| Net income available to common shareholders | $ | 29.7 |  |  | $ | 27.7 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 46.4 |  |  | 46.3 |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Non-participating employee stock options, performance awards, and deferred shares to non-employee directors | 0.7 |  |  | 0.6 |  |  |  |  |  |
| Diluted weighted average common shares outstanding | 47.1 |  |  | 46.9 |  |  |  |  |  |
| Basic earnings per share | $ | 0.64 |  |  | $ | 0.60 |  |  |  |  |  |
| Diluted earnings per share | $ | 0.63 |  |  | $ | 0.59 |  |  |  |  |  |

[0000038725-22-000078:notes:64]
There were 0.1 million and 0.1 million stock options outstanding for the first quarters ended March 31, 2022 and March 31, 2021, respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-22-000078:notes:65]
EQUITY ROLL FORWARD
The schedules below set forth equity changes in the first quarters ended March 31, 2022 and March 31, 2021:

[0000038725-22-000078:notes:66]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2021 | $ | 4,648 |  |  | $ | 310,617 |  |  | $ | 859,817 |  |  | $ | (49,076) |  |  | $ | (179,505) |  |  | $ | 2,161 |  |  | $ | 948,662 |  |  | $ | (19) |  |
| Net income |  |  |  |  | 29,765 |  |  |  |  |  |  | 235 |  |  | 30,000 |  |  | 119 |  |
| Dividends on common stock ($0.195/share) |  |  |  |  | (9,129) |  |  |  |  |  |  |  |  | (9,129) |  |  |  |
| Common stock issued | 1 |  |  | 342 |  |  |  |  |  |  |  |  |  |  | 343 |  |  |  |
| Common stock repurchased | (23) |  |  |  |  | (19,297) |  |  |  |  |  |  |  |  | (19,320) |  |  |  |
| Share-based compensation | 9 |  |  | 3,976 |  |  |  |  |  |  |  |  |  |  | 3,985 |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | 8,630 |  |  | (44) |  |  | 8,586 |  |  | 6 |  |
| Pension liability, net of tax |  |  |  |  |  |  | 932 |  |  |  |  |  |  | 932 |  |  |  |
| Balance as of March 31, 2022 | $ | 4,635 |  |  | $ | 314,935 |  |  | $ | 861,156 |  |  | $ | (48,144) |  |  | $ | (170,875) |  |  | $ | 2,352 |  |  | $ | 964,059 |  |  | $ | 106 |  |

[0000038725-22-000078:notes:67]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2020 | $ | 4,622 |  |  | $ | 283,420 |  |  | $ | 764,562 |  |  | $ | (52,666) |  |  | $ | (152,105) |  |  | $ | 2,116 |  |  | $ | 849,949 |  |  | $ | (245) |  |
| Net Income |  |  |  |  | 27,880 |  |  |  |  |  |  | 207 |  |  | 28,087 |  |  | 76 |  |
| Dividends on common stock ($0.175/share) |  |  |  |  | (8,143) |  |  |  |  |  |  |  |  | (8,143) |  |  |  |
| Common stock issued | 14 |  |  | 5,069 |  |  |  |  |  |  |  |  |  |  | 5,083 |  |  |  |
| Common stock repurchased | (6) |  |  |  |  | (4,843) |  |  |  |  |  |  |  |  | (4,849) |  |  |  |
| Share-based compensation | 11 |  |  | 4,179 |  |  |  |  |  |  |  |  |  |  | 4,190 |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (11,449) |  |  | (66) |  |  | (11,515) |  |  | 1 |  |
| Pension liability, net of taxes |  |  |  |  |  |  | 884 |  |  |  |  |  |  | 884 |  |  |  |
| Balance as of March 31, 2021 | $ | 4,641 |  |  | $ | 292,668 |  |  | $ | 779,456 |  |  | $ | (51,782) |  |  | $ | (163,554) |  |  | $ | 2,257 |  |  | $ | 863,686 |  |  | $ | (168) |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-22-000078:notes:68]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)
Changes in accumulated other comprehensive income/(loss) by component for the three months ended March 31, 2022 and March 31, 2021, are summarized below:

[0000038725-22-000078:notes:69]
| (In millions) | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| For the three months ended March 31, 2022: |  |  |
| Balance as of December 31, 2021 | $ | (179.6) |  |  | $ | (49.0) |  |  | $ | (228.6) |  |
| Other comprehensive income/(loss) before reclassifications | 8.7 |  |  | — |  |  | 8.7 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.9 |  |  | 0.9 |  |
| Net other comprehensive income/(loss) | 8.7 |  |  | 0.9 |  |  | 9.6 |  |
| Balance as of March 31, 2022 | $ | (170.9) |  |  | $ | (48.1) |  |  | $ | (219.0) |  |
| For the three months ended March 31, 2021: |  |  |  |  |  |
| Balance as of December 31, 2020 | $ | (152.2) |  |  | $ | (52.6) |  |  | $ | (204.8) |  |
| Other comprehensive income/(loss) before reclassifications | (11.4) |  |  | — |  |  | (11.4) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.9 |  |  | 0.9 |  |
| Net other comprehensive income/(loss) | (11.4) |  |  | 0.9 |  |  | (10.5) |  |
| Balance as of March 31, 2021 | $ | (163.6) |  |  | $ | (51.7) |  |  | $ | (215.3) |  |

[0000038725-22-000078:notes:70]
[same as prior period, unchanged from 0000038725-21-000210:notes:71]

[0000038725-22-000078:notes:71]
(2) Net of tax expense of $0.3 million and $0.2 million for the three months ended March 31, 2022 and March 31, 2021, respectively.

[0000038725-22-000078:notes:72]
[same as prior period, unchanged from 0000038725-21-000210:notes:73]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-22-000078:notes:73]
[same as prior period, unchanged from 0000038725-21-000210:notes:74]

[0000038725-22-000078:notes:74]
[same as prior period, unchanged from 0000038725-21-000210:notes:75]

[0000038725-22-000078:notes:75]
[same as prior period, unchanged from 0000038725-21-000210:notes:76]

[0000038725-22-000078:notes:76]
|  | First Quarter Ended |  |  |
| (In millions) | March 31, 2022 |  | March 31, 2021 |  |  |  |  |
|  | Net sales |
| Water Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | $ | 134.7 |  |  | $ | 84.2 |  |  |  |  |  |
| Latin America | 37.9 |  |  | 31.7 |  |  |  |  |  |
| Europe, Middle East & Africa | 51.0 |  |  | 44.4 |  |  |  |  |  |
| Asia Pacific | 20.5 |  |  | 20.2 |  |  |  |  |  |
| Intersegment sales |  |  |  |  |  |  |  |
| United States & Canada | 28.5 |  |  | 17.1 |  |  |  |  |  |
| Total sales | 272.6 |  |  | 197.6 |  |  |  |  |  |
| Distribution |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 134.9 |  |  | 95.7 |  |  |  |  |  |
| Intersegment sales | — |  |  | — |  |  |  |  |  |
| Total sales | 134.9 |  |  | 95.7 |  |  |  |  |  |
| Fueling Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 51.9 |  |  | 37.7 |  |  |  |  |  |
| All other | 20.6 |  |  | 19.1 |  |  |  |  |  |
| Intersegment sales | — |  |  | — |  |  |  |  |  |
| Total sales | 72.5 |  |  | 56.8 |  |  |  |  |  |
| Intersegment Eliminations/Other | (28.5) |  |  | (17.1) |  |  |  |  |  |
| Consolidated | $ | 451.5 |  |  | $ | 333.0 |  |  |  |  |  |
|  | First Quarter Ended |  |  |
|  | March 31, 2022 |  | March 31, 2021 |  |  |  |  |
|  | Operating income/(loss) |
| Water Systems | $ | 33.2 |  |  | $ | 31.3 |  |  |  |  |  |
| Distribution | 9.4 |  |  | 2.0 |  |  |  |  |  |
| Fueling Systems | 17.7 |  |  | 14.9 |  |  |  |  |  |
| Intersegment Eliminations/Other | (20.4) |  |  | (14.4) |  |  |  |  |  |
| Consolidated | $ | 39.9 |  |  | $ | 33.8 |  |  |  |  |  |

[0000038725-22-000078:notes:77]
|  | March 31, 2022 |  | December 31, 2021 |  |  |  |  |
|  | Total assets |  |  |  |  |
| Water Systems | $ | 951.2 |  |  | $ | 894.4 |  |  |  |  |  |
| Distribution | 419.4 |  |  | 363.0 |  |  |  |  |  |
| Fueling Systems | 277.1 |  |  | 273.6 |  |  |  |  |  |
| Other | 35.5 |  |  | 44.2 |  |  |  |  |  |
| Consolidated | $ | 1,683.2 |  |  | $ | 1,575.2 |  |  |  |  |  |

[0000038725-22-000078:notes:78]
[same as prior period, unchanged from 0000038725-21-000210:notes:79]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-22-000078:notes:79]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. The subject-matter expert has issued its preliminary report, which indicates that total damages incurred by Esso amounted to approximately 12 million euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company has retained experts to demonstrate that its products did not cause the damage, and in January 2021, submitted its response to the expert’s preliminary report for each station. The expert's response to the Company's report is due to the Court in June 2022. The Company cannot predict the ultimate outcome of this matter. Any exposure related to this matter is neither probable nor estimable at this time. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position,  results of operations, or cash flows.

[0000038725-22-000078:notes:80]
The Company is defending other various claims and legal actions which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-22-000078:notes:81]
At March 31, 2022, the Company had $15.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-22-000078:notes:82]
The Company provides warranties on most of its products. The warranty terms vary but are generally two years to five years from date of manufacture or one year to five years from date of installation. Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified. These estimates are established using historical information about the nature, frequency, and average cost of warranty claims. The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims. The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-22-000078:notes:83]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the three months ended March 31, 2022, are as follows:

[0000038725-22-000078:notes:84]
| (In millions) |  |  |
| Balance as of December 31, 2021 |  | $ | 10.5 |  |
| Accruals related to product warranties |  | 2.0 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (1.9) |  |
| Balance as of March 31, 2022 |  | $ | 10.6 |  |

[0000038725-22-000078:notes:85]
The Company maintains certain warehouses, distribution centers, office space, and equipment operating leases. The Company also has lease agreements that are classified as financing. These financing leases are immaterial to the Company.

[0000038725-22-000078:notes:86]
The Company utilizes interest rates from lease agreements unless the lease agreement does not provide a readily determinable rate. In these instances, the Company utilizes its incremental borrowing rate in effect at the inception of a lease when determining the present value of future lease payments.

[0000038725-22-000078:notes:87]
Some of the Company’s leases include renewal options. The Company excludes these renewal options in the expected lease term unless the Company is reasonably certain that the option will be exercised.

[0000038725-22-000078:notes:88]
The components of the Company’s operating lease portfolio as of the first quarter ended March 31, 2022 are as follows:

[0000038725-22-000078:notes:89]
|  |  | First Quarter Ended |  |  |
| Lease Cost (in millions): |  | March 31, 2022 |  |  |
| Operating lease cost |  | $ | 4.2 |  |  |  |
| Short-term lease cost |  | 0.1 |  |  |  |
| Other Information: |  |  |  |  |
| Weighted-average remaining lease term |  | 4.2 years |  |  |
| Weighted-average discount rate |  | 3.9 | % |  |  |

[0000038725-22-000078:notes:90]
As of March 31, 2022, the Company has approximately $1.5 million of additional ROU assets related to leases that have not yet commenced, but create future lease obligations.

[0000038725-22-000078:notes:91]
The minimum rental payments for non-cancellable operating leases as of March 31, 2022, are as follows:

[0000038725-22-000078:notes:92]
| (In millions) | 2022 | 2023 | 2024 | 2025 | 2026 | Thereafter |
| Future Minimum Rental Payments | $ | 12.6 |  | $ | 13.2 |  | $ | 8.6 |  | $ | 5.5 |  | $ | 4.2 |  | $ | 6.5 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-22-000078:notes:93]
[same as prior period, unchanged from 0000038725-21-000210:notes:93]

[0000038725-22-000078:notes:94]
The Company also maintains the Franklin Electric Co., Inc. 2012 Stock Plan (the "2012 Stock Plan"), which is a stock-based compensation plan that provides for discretionary grants of stock options, stock awards, and stock unit awards to key employees and non-employee directors. The 2012 Stock Plan authorized 2,400,000 shares for issuance as follows:

[0000038725-22-000078:notes:95]
[same as prior period, unchanged from 0000038725-21-000210:notes:96]

[0000038725-22-000078:notes:96]
No additional options and awards are granted out of the 2012 Stock Plan. However, there are still unvested awards and unexercised options under this plan.

[0000038725-22-000078:notes:97]
[same as prior period, unchanged from 0000038725-21-000210:notes:97]

[0000038725-22-000078:notes:98]
[same as prior period, unchanged from 0000038725-21-000210:notes:98]

[0000038725-22-000078:notes:99]
[same as prior period, unchanged from 0000038725-21-000210:notes:99]

[0000038725-22-000078:notes:100]
[same as prior period, unchanged from 0000038725-21-000210:notes:100]

[0000038725-22-000078:notes:101]
[same as prior period, unchanged from 0000038725-21-000210:notes:101]

[0000038725-22-000078:notes:102]
[same as prior period, unchanged from 0000038725-21-000210:notes:102]

[0000038725-22-000078:notes:103]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the three months ended March 31, 2022 and March 31, 2021 are as follows:

[0000038725-22-000078:notes:104]
|  |  | March 31, 2022 |  | March 31, 2021 |
| Risk-free interest rate |  | 1.87 | % |  | 0.66 | % |
| Dividend yield |  | 0.93 | % |  | 0.96 | % |
| Volatility factor |  | 33.88 | % |  | 34.98 | % |
| Expected term |  | 5.5 years |  | 5.5 years |

[0000038725-22-000078:notes:105]
A summary of the Company’s outstanding stock option activity and related information for the three months ended March 31, 2022 is as follows:

[0000038725-22-000078:notes:106]
| (Shares in thousands) |  | March 31, 2022 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,043 |  |  | $ | 49.21 |  |
| Granted |  | 110 |  |  | 83.90 |  |
| Exercised |  | (8) |  |  | 44.09 |  |
| Forfeited |  | (15) |  |  | 73.25 |  |
| Outstanding at end of period |  | 1,130 |  |  | $ | 52.29 |  |
| Expected to vest after applying forfeiture rate |  | 1,127 |  |  | $ | 52.23 |  |
| Vested and exercisable at end of period |  | 891 |  |  | $ | 46.22 |  |

[0000038725-22-000078:notes:107]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value as of March 31, 2022 is as follows:

[0000038725-22-000078:notes:108]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 5.81 years |  | $ | 34,843 |  |
| Expected to vest after applying forfeiture rate |  | 5.80 years |  | $ | 34,829 |  |
| Vested and exercisable at end of period |  | 4.93 years |  | $ | 32,804 |  |

[0000038725-22-000078:notes:109]
The total intrinsic value of options exercised during the three months ended March 31, 2022 and March 31, 2021 was $0.3 million and $5.8 million, respectively.

[0000038725-22-000078:notes:110]
As of March 31, 2022, there was $1.5 million of total unrecognized compensation cost related to non-vested stock options granted under the stock plans. That cost is expected to be recognized over a weighted-average period of 2.10 years.

[0000038725-22-000078:notes:111]
[same as prior period, unchanged from 0000038725-21-000210:notes:111]

[0000038725-22-000078:notes:112]
A summary of the Company’s restricted stock/stock unit award activity and related information for the three months ended March 31, 2022 is as follows:

[0000038725-22-000078:notes:113]
| (Shares in thousands) |  | March 31, 2022 |
| Restricted Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 348 |  |  | $ | 58.20 |  |
| Awarded |  | 104 |  |  | 83.86 |  |
| Vested |  | (129) |  |  | 47.10 |  |
| Forfeited |  | (14) |  |  | 69.64 |  |
| Non-vested at end of period |  | 309 |  |  | $ | 70.98 |  |

[0000038725-22-000078:notes:114]
As of March 31, 2022, there was $14.6 million of total unrecognized compensation cost related to non-vested restricted stock/stock unit awards granted under the stock plans. That cost is expected to be recognized over a weighted-average period of 1.85 years.
