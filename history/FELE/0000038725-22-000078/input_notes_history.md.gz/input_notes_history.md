# FELE note change history — 0000038725-21-000210 → 0000038725-22-000078


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-05-03):
[0000038725-22-000078:note_history:1]
At March 31, 2022, the Company had $15.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.
  (was, 2021-11-02, similarity 0.966):
[0000038725-21-000210:note_history:1]
At September 30, 2021, the Company had $14.1 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

- changed (2022-05-03):
[0000038725-22-000078:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the three months ended March 31, 2022, are as follows:
  (was, 2021-11-02, similarity 0.894):
[0000038725-21-000210:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 30, 2021, are as follows:

- changed (2022-05-03):
[0000038725-22-000078:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2021 |  | $ | 10.5 |  |
| Accruals related to product warranties |  | 2.0 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (1.9) |  |
| Balance as of March 31, 2022 |  | $ | 10.6 |  |
  (was, 2021-11-02, similarity 0.9675):
[0000038725-21-000210:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2020 |  | $ | 9.7 |  |
| Accruals related to product warranties |  | 7.0 |  |
| Additions related to acquisitions |  | 0.1 |  |
| Reductions for payments made |  | (6.5) |  |
| Balance as of September 30, 2021 |  | $ | 10.3 |  |

- changed (2022-05-03):
[0000038725-22-000078:note_history:4]
The Company utilizes interest rates from lease agreements unless the lease agreement does not provide a readily determinable rate. In these instances, the Company utilizes its incremental borrowing rate in effect at the inception of a lease when determining the present value of future lease payments.
  (was, 2021-11-02, similarity 0.7612):
[0000038725-21-000210:note_history:4]
The Company utilizes interest rates from lease agreements unless the lease agreement does not provide a readily determinable rate. In these instances, the Company utilizes its incremental borrowing rate based on the information available as of the adoption of ASU 2016-02 or at the inception of any new leases entered into thereafter when determining the present value of future lease payments.

- changed (2022-05-03):
[0000038725-22-000078:note_history:5]
The components of the Company’s operating lease portfolio as of the first quarter ended March 31, 2022 are as follows:
  (was, 2021-11-02, similarity 0.8699):
[0000038725-21-000210:note_history:5]
The components of the Company’s operating lease portfolio as of the third quarter and nine months ended September 30, 2021 are as follows:

- added (2022-05-03):
[0000038725-22-000078:note_history:6]
|  |  | First Quarter Ended |  |  |
| Lease Cost (in millions): |  | March 31, 2022 |  |  |
| Operating lease cost |  | $ | 4.2 |  |  |  |
| Short-term lease cost |  | 0.1 |  |  |  |
| Other Information: |  |  |  |  |
| Weighted-average remaining lease term |  | 4.2 years |  |  |
| Weighted-average discount rate |  | 3.9 | % |  |  |

- added (2022-05-03):
[0000038725-22-000078:note_history:7]
As of March 31, 2022, the Company has approximately $1.5 million of additional ROU assets related to leases that have not yet commenced, but create future lease obligations.

- changed (2022-05-03):
[0000038725-22-000078:note_history:8]
The minimum rental payments for non-cancellable operating leases as of March 31, 2022, are as follows:
  (was, 2021-11-02, similarity 0.949):
[0000038725-21-000210:note_history:8]
The minimum rental payments for non-cancellable operating leases as of September 30, 2021, are as follows:

- removed (2022-05-03):
[0000038725-21-000210:note_history:9]
| Lease Cost (in millions): | Third Quarter Ended |  | Nine Months Ended |
| Operating lease cost | $ | 3.5 |  |  | $ | 9.2 |  |
| Short-term lease cost | 0.1 |  |  | 0.5 |  |
| Other Information: |  |  |  |
| Weighted-average remaining lease term |  |  | 4.1 years |
| Weighted-average discount rate |  |  | 4.1 | % |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-05-03):
[0000038725-22-000078:note_history:10]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2021, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2022, and for the first quarters ended March 31, 2022 and March 31, 2021 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the first quarter ended March 31, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2022. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2021.
  (was, 2021-11-02, similarity 0.9366):
[0000038725-21-000210:note_history:10]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2020, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 30, 2021, and for the third quarters and nine months ended September 30, 2021 and September 30, 2020 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the third quarter and nine months ended September 30, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2021. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2020.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-05-03):
[0000038725-22-000078:note_history:11]
| (In millions) |  | March 31, 2022 |  | December 31, 2021 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 191.8 |  |  | 96.6 |  |
| Tax increment financing debt |  | 15.9 |  |  | 16.5 |  |
| Foreign subsidiary debt |  | 2.2 |  |  | 0.5 |  |
| Other |  | — |  |  | 0.1 |  |
| Less: unamortized debt issuance costs |  | (0.2) |  |  | (0.2) |  |
|  |  | $ | 284.7 |  |  | $ | 188.5 |  |
| Less: current maturities |  | (194.8) |  |  | (98.0) |  |
| Long-term debt |  | $ | 89.9 |  |  | 90.5 |

- changed (2022-05-03):
[0000038725-22-000078:note_history:12]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2022 matures as follows:
  (was, 2021-11-02, similarity 0.9474):
[0000038725-21-000210:note_history:12]
Debt outstanding, excluding unamortized debt issuance costs, at September 30, 2021 matures as follows:

- changed (2022-05-03):
[0000038725-22-000078:note_history:13]
The Company maintains the Fourth Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with PGIM, Inc. and its affiliates, which was renewed on July 30, 2021 and expires on July 30, 2024.  The Prudential Agreement has an initial borrowing capacity of $150.0 million. As of March 31, 2022, the Company had no notes issued and  $150.0 million borrowing capacity available under the Prudential Agreement.
  (was, 2021-11-02, similarity 0.9831):
[0000038725-21-000210:note_history:13]
The Company maintains the Fourth Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with PGIM, Inc. and its affiliates, which was renewed on July 30, 2021 and expires on July 30, 2024.  The Prudential Agreement has an initial borrowing capacity of $150.0 million. As of September 30, 2021, the Company had no notes issued and  $150.0 million borrowing capacity available under the Prudential Agreement.

- changed (2022-05-03):
[0000038725-22-000078:note_history:14]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC and its affiliates (the "New York Life Agreement"), which was renewed on July 30, 2021 and expires on July 30, 2024. The New York Life Agreement has a maximum aggregate borrowing capacity of $200.0 million. On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of March 31, 2022, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.
  (was, 2021-11-02, similarity 0.9901):
[0000038725-21-000210:note_history:14]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC and its affiliates (the "New York Life Agreement"), which was renewed on July 30, 2021 and expires on July 30, 2024. The New York Life Agreement has a maximum aggregate borrowing capacity of $200.0 million. On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of September 30, 2021, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

- changed (2022-05-03):
[0000038725-22-000078:note_history:15]
The Company maintains the Fourth Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement was renewed on May 13, 2021, has a maturity date of May 13, 2026, and commitment amount of $250.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $125.0 million subject to agreement of the lenders (not to exceed a total commitment of $375.0 million). Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.85% to 1.88% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.
  (was, 2021-11-02, similarity 0.8978):
[0000038725-21-000210:note_history:15]
The Company maintains the Fourth Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement was renewed on May 13, 2021, has a maturity date of May 13, 2026, and commitment amount of $250.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $125.0 million subject to agreement of the lenders (not to exceed a total commitment of $375.0 million). Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based

- changed (2022-05-03):
[0000038725-22-000078:note_history:16]
As of March 31, 2022, the Company had $191.8 million outstanding borrowings, $4.0 million in letters of credit outstanding, and $54.2 million of available capacity under the Credit Agreement.
  (was, 2021-11-02, similarity 0.9719):
[0000038725-21-000210:note_history:16]
As of September 30, 2021, the Company had $105.0 million outstanding borrowings, $4.1 million in letters of credit outstanding, and $140.9 million of available capacity under the Credit Agreement.

- added (2022-05-03):
[0000038725-22-000078:note_history:17]
The Company also has lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $20.2 million. As of March 31, 2022, there were $1.8 million outstanding borrowings and $18.4 million of available capacity under these lines of credit.

- changed (2022-05-03):
[0000038725-22-000078:note_history:18]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of March 31, 2022.
  (was, 2021-11-02, similarity 0.9941):
[0000038725-21-000210:note_history:18]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of September 30, 2021.

- removed (2022-05-03):
[0000038725-21-000210:note_history:19]
| (In millions) |  | September 30, 2021 |  | December 31, 2020 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 105.0 |  |  | — |  |
| Tax increment financing debt |  | 16.5 |  |  | 17.6 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 0.6 |  |  | 1.8 |  |
| Other |  | — |  |  | 0.2 |  |
| Less: unamortized debt issuance costs |  | (0.3) |  |  | (0.1) |  |
|  |  | $ | 196.8 |  |  | $ | 94.6 |  |
| Less: current maturities |  | (106.3) |  |  | (2.6) |  |
| Long-term debt |  | $ | 90.5 |  |  | 92.0 |

- removed (2022-05-03):
[0000038725-21-000210:note_history:20]
on LIBOR plus an applicable margin of 0.85% to 1.88% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-05-03):
[0000038725-22-000078:note_history:21]
| (In millions) |  | March 31, 2022 |  | December 31, 2021 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 191.8 |  |  | 96.6 |  |
| Tax increment financing debt |  | 15.9 |  |  | 16.5 |  |
| Foreign subsidiary debt |  | 2.2 |  |  | 0.5 |  |
| Other |  | — |  |  | 0.1 |  |
| Less: unamortized debt issuance costs |  | (0.2) |  |  | (0.2) |  |
|  |  | $ | 284.7 |  |  | $ | 188.5 |  |
| Less: current maturities |  | (194.8) |  |  | (98.0) |  |
| Long-term debt |  | $ | 89.9 |  |  | 90.5 |

- removed (2022-05-03):
[0000038725-21-000210:note_history:22]
| (In millions) |  | September 30, 2021 |  | December 31, 2020 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 105.0 |  |  | — |  |
| Tax increment financing debt |  | 16.5 |  |  | 17.6 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 0.6 |  |  | 1.8 |  |
| Other |  | — |  |  | 0.2 |  |
| Less: unamortized debt issuance costs |  | (0.3) |  |  | (0.1) |  |
|  |  | $ | 196.8 |  |  | $ | 94.6 |  |
| Less: current maturities |  | (106.3) |  |  | (2.6) |  |
| Long-term debt |  | $ | 90.5 |  |  | 92.0 |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-03):
[0000038725-22-000078:note_history:23]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2022 matures as follows:
  (was, 2021-11-02, similarity 0.9474):
[0000038725-21-000210:note_history:23]
Debt outstanding, excluding unamortized debt issuance costs, at September 30, 2021 matures as follows:
