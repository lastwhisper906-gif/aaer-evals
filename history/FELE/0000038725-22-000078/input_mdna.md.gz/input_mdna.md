# FELE MD&A — 0000038725-22-000078


## mdna

[0000038725-22-000078:mdna:1]
[same as prior period, unchanged from 0000038725-21-000210:mdna:1]

[0000038725-22-000078:mdna:2]
First Quarter 2022 vs. First Quarter 2021

[0000038725-22-000078:mdna:3]
[same as prior period, unchanged from 0000038725-21-000210:mdna:3]

[0000038725-22-000078:mdna:4]
Sales in the first quarter of 2022 increased from the first quarter of last year. Sales in the quarter increased by $118.5 million, or about 36 percent, due to higher sales across all three segments, achieved by price realization, acquisitions, and volume. The Company's consolidated gross profit was $145.3 million for the first quarter of 2022, an increase from the prior year’s first quarter. The gross profit as a percent of net sales was 32.2 percent in the first quarter of 2022 versus 34.7 percent during the first quarter 2021.  For the first quarter of 2022, diluted earnings per share were $0.63, up from the first quarter of 2021 diluted earnings per share of $0.59.

[0000038725-22-000078:mdna:5]
[same as prior period, unchanged from 0000038725-21-000210:mdna:5]

[0000038725-22-000078:mdna:6]
[same as prior period, unchanged from 0000038725-21-000210:mdna:6]

[0000038725-22-000078:mdna:7]
Net sales in the first quarter of 2022 were $451.5 million, an increase of $118.5 million or about 36 percent compared to 2021 first quarter sales of $333.0 million. The sales increase from acquisition related sales was $48.2 million. Sales revenue decreased by $13.1 million or about 4 percent in the first quarter of 2022 due to foreign currency translation. Excluding acquisitions and the impact of foreign currency translation, the Company’s organic sales growth, led by price realization, was about 25 percent.

[0000038725-22-000078:mdna:8]
|  | Net Sales |
| (In millions) | Q1 2022 |  | Q1 2021 |  | 2022 v 2021 |
| Water Systems | $ | 272.6 |  |  | $ | 197.6 |  |  | $ | 75.0 |  |
| Fueling Systems | 72.5 |  |  | 56.8 |  |  | $ | 15.7 |  |
| Distribution | 134.9 |  |  | 95.7 |  |  | $ | 39.2 |  |
| Eliminations/Other | (28.5) |  |  | (17.1) |  |  | $ | (11.4) |  |
| Consolidated | $ | 451.5 |  |  | $ | 333.0 |  |  | $ | 118.5 |  |

[0000038725-22-000078:mdna:9]
[same as prior period, unchanged from 0000038725-21-000210:mdna:9]

[0000038725-22-000078:mdna:10]
Water Systems revenues were $272.6 million in the first quarter 2022, an increase of $75.0 million or about 38 percent versus the first quarter 2021 sales of $197.6 million. In the first quarter of 2022, sales from businesses acquired since the first quarter of 2021 were $33.9 million. Sales were decreased by $12.4 million or 6 percent in the quarter due to foreign currency translation. Water Systems sales were up about 27 percent, excluding acquisitions and foreign currency translation, in the first quarter of 2022 versus the first quarter of 2021.  This revenue growth was primarily from price and volume, which was up due to strong end market demand.

[0000038725-22-000078:mdna:11]
Water Systems sales in the U.S. and Canada were up about 61 percent compared to the first quarter 2021.  Sales from businesses acquired since the first quarter of 2021 were $32.1 million. Sales of groundwater pumping equipment increased by about 45 percent and sales of all surface pumping equipment increased by about 21 percent versus the first quarter 2021, due to strong end market demand.

[0000038725-22-000078:mdna:12]
Water Systems sales in markets outside the U.S. and Canada increased by 14 percent overall. Foreign currency translation decreased sales by 13 percent. Sales from businesses acquired since the first quarter of 2021 were $1.8 million. Outside the U.S. and Canada, Water Systems organic sales increased by 25 percent, driven by higher sales in Latin America, Europe, the Middle East, and African markets, partially offset with lower sales in the Asia Pacific markets.

[0000038725-22-000078:mdna:13]
[same as prior period, unchanged from 0000038725-21-000210:mdna:13]

[0000038725-22-000078:mdna:14]
Fueling Systems sales were $72.5 million in the first quarter of 2022, an increase of $15.7 million or about 28 percent versus the first quarter 2021 sales of $56.8 million. Fueling Systems sales were decreased by $0.7 million or 1 percent in the quarter due to foreign currency translation. Fueling Systems sales, excluding foreign currency translation, increased by about 29 percent, which this growth was from volume and price.

[0000038725-22-000078:mdna:15]
Fueling Systems sales in the U.S. and Canada increased by about 33 percent compared to the first quarter 2021. The increase was in all product lines. Outside the U.S. and Canada, Fueling Systems revenues increased by about 2 percent, as sales increases of 4 percent in the rest of the world outside of China were offset by lower sales in China.

[0000038725-22-000078:mdna:16]
[same as prior period, unchanged from 0000038725-21-000210:mdna:16]

[0000038725-22-000078:mdna:17]
Distribution sales were $134.9 million in the first quarter 2022, an increase of $39.2 million or about 41 percent versus first quarter 2021 sales of $95.7 million. In the first quarter of 2022, sales from businesses acquired since the first quarter of 2021 were $14.3 million. The Distribution segment organic sales increased about 26 percent compared to the first quarter of 2021. Revenue growth was primarily from price and was driven by broad-based demand in all regions and product categories.

[0000038725-22-000078:mdna:18]
[same as prior period, unchanged from 0000038725-21-000210:mdna:18]

[0000038725-22-000078:mdna:19]
Cost of sales as a percentage of net sales for the first quarters of 2022 and 2021 was 67.8 percent and 65.3 percent, respectively. Correspondingly, gross profit margin decreased to 32.2 percent from 34.7 percent. The Company’s consolidated gross profit was $145.3 million for the first quarter of 2022, an increase from the first quarter of 2021 gross profit of $115.5 million. The gross profit margin declined primarily due to inflationary pressures and supply chain challenges, which the Company continues to work to offset with pricing, and to some degree an unfavorable product sales mix shift.

[0000038725-22-000078:mdna:20]
[same as prior period, unchanged from 0000038725-21-000210:mdna:20]

[0000038725-22-000078:mdna:21]
Selling, general, and administrative ("SG&A") expenses were $104.7 million in the first quarter of 2022 compared to $81.6 million in the first quarter of 2021. SG&A expenses from acquired businesses were $12.4 million and excluding the acquired entities, the Company’s SG&A expenses in the first quarter of 2022 were $92.3 million, an increase of about 12 percent from the first quarter 2021, due to higher variable performance-based compensation expenses and increased spending to support sales growth.

[0000038725-22-000078:mdna:22]
[same as prior period, unchanged from 0000038725-21-000210:mdna:22]

[0000038725-22-000078:mdna:23]
There were $0.7 million of restructuring expenses for the first quarter of 2022. Restructuring expenses for the first quarter of 2022 were $0.6 million in the Water segment related to continued miscellaneous manufacturing realignment activities, as well as $0.1 million in the Distribution segment related to miscellaneous branch closings and consolidation.

[0000038725-22-000078:mdna:24]
There were $0.2 million of restructuring expenses for the first quarter of 2021. Restructuring expenses for the first quarter of 2021 were $0.1 million in the Water segment related to continued miscellaneous manufacturing realignment activities, as well as $0.1 million in the Distribution segment related to miscellaneous branch closings and consolidation.

[0000038725-22-000078:mdna:25]
[same as prior period, unchanged from 0000038725-21-000210:mdna:24]

[0000038725-22-000078:mdna:26]
Operating income was $39.9 million in the first quarter of 2022, up $6.1 million or about 18 percent from $33.8 million in the first quarter of 2021.

[0000038725-22-000078:mdna:27]
|  |  | Operating income (loss) |
| (In millions) |  | Q1 2022 |  | Q1 2021 |  | 2022 v 2021 |
| Water Systems |  | 33.2 |  |  | $ | 31.3 |  |  | $ | 1.9 |  |
| Fueling Systems |  | 17.7 |  |  | 14.9 |  |  | 2.8 |  |
| Distribution |  | 9.4 |  |  | 2.0 |  |  | 7.4 |  |
| Eliminations/Other |  | (20.4) |  |  | (14.4) |  |  | (6.0) |  |
| Consolidated |  | $ | 39.9 |  |  | $ | 33.8 |  |  | $ | 6.1 |  |

[0000038725-22-000078:mdna:28]
[same as prior period, unchanged from 0000038725-21-000210:mdna:27]

[0000038725-22-000078:mdna:29]
Water Systems operating income was $33.2 million in the first quarter 2022, up $1.9 million versus the first quarter 2021. Operating income increased in Water Systems primarily due to higher sales volume. The first quarter operating income margin was 12.2 percent, down 360 basis points from 15.8 percent in the first quarter of 2021. Operating income margin decreased primarily due to inflationary pressures and supply chain challenges, which the Company continues to work to offset with pricing, and to some degree an unfavorable product sales mix shift.

[0000038725-22-000078:mdna:30]
[same as prior period, unchanged from 0000038725-21-000210:mdna:29]

[0000038725-22-000078:mdna:31]
Fueling Systems operating income was $17.7 million in the first quarter of 2022 compared to $14.9 million in the first quarter of 2021. The increase in operating income was primarily related to higher sales volume. The first quarter Fueling Systems operating income margin was 24.4 percent, a decrease of 180 basis points from the 26.2 percent of net sales in the first quarter of 2021. Operating income margin decreased primarily due to inflationary pressures and supply chain challenges, which the Company continues to work to offset with pricing, and to some degree an unfavorable product sales mix shift.

[0000038725-22-000078:mdna:32]
[same as prior period, unchanged from 0000038725-21-000210:mdna:32]

[0000038725-22-000078:mdna:33]
The Distribution segment recorded operating income of $9.4 million in the first quarter of 2022 compared to $2.0 million in the first quarter of 2021. Distribution’s increase in operating income was primarily due to higher sales volumes compared to the first quarter 2021. Distribution’s operating income margin was 7.0 percent in the first quarter of 2022 versus 2.1 percent of net

[0000038725-22-000078:mdna:34]
sales in the first quarter of 2021. Operating income margin improved due to leverage on fixed cost from higher sales, price realization and cost management.

[0000038725-22-000078:mdna:35]
[same as prior period, unchanged from 0000038725-21-000210:mdna:34]

[0000038725-22-000078:mdna:36]
Operating income-Eliminations/Other is composed primarily of intersegment sales and profit eliminations and unallocated general and administrative expenses. The intersegment profit elimination impact in the first quarter of 2022 versus the first quarter of 2021 was expense of $3.1 million. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer. General and administrative expenses were higher by $2.9 million to last year, in part due to higher variable performance-based compensation expenses and higher professional fees.

[0000038725-22-000078:mdna:37]
[same as prior period, unchanged from 0000038725-21-000210:mdna:36]

[0000038725-22-000078:mdna:38]
Interest expense for the first quarters of 2022 and 2021 was $1.5 million and $1.1 million, respectively.

[0000038725-22-000078:mdna:39]
[same as prior period, unchanged from 0000038725-21-000210:mdna:38]

[0000038725-22-000078:mdna:40]
Other income or expense was a loss in the first quarter of 2022 of $0.4 million and a loss of $0.1 million in the first quarter of 2021.

[0000038725-22-000078:mdna:41]
[same as prior period, unchanged from 0000038725-21-000210:mdna:40]

[0000038725-22-000078:mdna:42]
Foreign currency-based transactions produced a loss for the first quarter of 2022 of $0.6 million, primarily due to the Argentinian and Mexican Peso relative to the U.S. dollar. Foreign currency-based transactions produced a loss for the first quarter of 2021 of $0.1 million, primarily due to the Argentinian Peso relative to the U.S. dollar.

[0000038725-22-000078:mdna:43]
[same as prior period, unchanged from 0000038725-21-000210:mdna:42]

[0000038725-22-000078:mdna:44]
The provision for income taxes in the first quarter of 2022 and 2021 was $7.4 million and $4.4 million, respectively. The effective tax rate for the first quarter of 2022 was about 20 percent and before the impact of discrete events, was about 21 percent. The effective tax rate for the first quarter of 2021 was about 14 percent and before the impact of discrete events, was about 20 percent. The increase in the effective tax rate was primarily a result of smaller net favorable discrete events recorded in the first quarter of 2022 compared to the first quarter of 2021. The tax rate as a percentage of pre-tax earnings for the full year of 2022 is projected to be about 21 percent, compared to the full year 2021 tax rate of about 21 percent, both before discrete adjustments.

[0000038725-22-000078:mdna:45]
[same as prior period, unchanged from 0000038725-21-000210:mdna:44]

[0000038725-22-000078:mdna:46]
Net income for the first quarter of 2022 was $30.1 million compared to the prior year first quarter net income of $28.2 million. Net income attributable to Franklin Electric Co., Inc. for the first quarter of 2022 was $29.8 million, or $0.63 per diluted share, compared to the prior year first quarter net income attributable to Franklin Electric Co., Inc. of $27.9 million or $0.59 per diluted share.

[0000038725-22-000078:mdna:47]
[same as prior period, unchanged from 0000038725-21-000210:mdna:90]

[0000038725-22-000078:mdna:48]
[same as prior period, unchanged from 0000038725-21-000210:mdna:91]

[0000038725-22-000078:mdna:49]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at March 31, 2022 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-22-000078:mdna:50]
As of March 31, 2022 the Company had a $250.0 million revolving credit facility. The facility is scheduled to mature on May 13, 2026. As of March 31, 2022, the Company had $54.2 million borrowing capacity under the Credit Agreement as $4.0 million in letters of commercial and standby letters of credit were outstanding and undrawn and $191.8 million in revolver borrowings were drawn and outstanding, which were primarily used for funding working capital requirements.

[0000038725-22-000078:mdna:51]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement") with a remaining borrowing capacity of  $125.0 million as of March 31, 2022. The Company also has other long-term debt borrowings outstanding as of March 31, 2022. See Note 10 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-22-000078:mdna:52]
At March 31, 2022, the Company had $34.4 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations. There is currently no need or intent to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-22-000078:mdna:53]
[same as prior period, unchanged from 0000038725-21-000210:mdna:96]

[0000038725-22-000078:mdna:54]
The following table summarizes significant sources and uses of cash and cash equivalents for the first three months of 2022 and 2021.

[0000038725-22-000078:mdna:55]
| (in millions) |  | 2022 |  | 2021 |
| Net cash flows from operating activities |  | $ | (61.3) |  |  | $ | 5.4 |  |
| Net cash flows from investing activities |  | (8.9) |  |  | (6.7) |  |
| Net cash flows from financing activities |  | 68.7 |  |  | (8.4) |  |
| Impact of exchange rates on cash and cash equivalents |  | (0.5) |  |  | (2.8) |  |
| Change in cash and cash equivalents |  | $ | (2.0) |  |  | $ | (12.5) |  |

[0000038725-22-000078:mdna:56]
[same as prior period, unchanged from 0000038725-21-000210:mdna:99]

[0000038725-22-000078:mdna:57]
2022 vs. 2021

[0000038725-22-000078:mdna:58]
Net cash used by operating activities was $61.3 million for the three months ended March 31, 2022 compared to $5.4 million provided by operating activities for the three months ended March 31, 2021. The increase in cash used by operating activities was primarily due to increased working capital requirements in support of supply chain resiliency and meeting the strong demand from our customers.

[0000038725-22-000078:mdna:59]
[same as prior period, unchanged from 0000038725-21-000210:mdna:102]

[0000038725-22-000078:mdna:60]
2022 vs. 2021

[0000038725-22-000078:mdna:61]
Net cash used in investing activities was $8.9 million for the three months ended March 31, 2022 compared to $6.7 million used in investing activities for the  three months ended March 31, 2021. The increase in cash used in investing activities was attributable to increases in additions of property, plant and equipment.

[0000038725-22-000078:mdna:62]
[same as prior period, unchanged from 0000038725-21-000210:mdna:105]

[0000038725-22-000078:mdna:63]
2022 vs. 2021

[0000038725-22-000078:mdna:64]
Net cash provided by financing activities was $68.7 million for the three months ended March 31, 2022 compared to $8.4 million used in financing activities for the three months ended March 31, 2021. The increase in cash provided by financing activities was attributable to increased debt proceeds slightly offset by increased common stock repurchases.

[0000038725-22-000078:mdna:65]
[same as prior period, unchanged from 0000038725-21-000210:mdna:108]
