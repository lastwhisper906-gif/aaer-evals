# FELE 8-K — 0000038725-22-000073 filed 2022-04-26

## item codes, every 8-K on or before 2022-05-03

- 2022-05-03 0000038725-22-000075 — 7.01, 9.01
- 2022-04-26 0000038725-22-000073 — 2.02, 9.01
- 2022-03-24 0000038725-22-000056 — 5.02, 9.01
- 2022-03-08 0000038725-22-000049 — 7.01, 9.01
- 2022-02-15 0000038725-22-000007 — 2.02, 9.01
- 2022-01-04 0000038725-22-000002 — 7.01, 9.01
- 2021-11-03 0000038725-21-000212 — 7.01, 9.01
- 2021-10-26 0000038725-21-000203 — 2.02, 9.01
- 2021-07-27 0000038725-21-000172 — 7.01, 9.01
- 2021-07-27 0000038725-21-000170 — 2.02, 9.01
- 2021-06-14 0000038725-21-000157 — 5.02, 7.01, 9.01
- 2021-05-17 0000038725-21-000120 — 7.01, 9.01
- 2021-05-17 0000038725-21-000118 — 7.01, 9.01
- 2021-05-13 0000038725-21-000102 — 2.03, 9.01
- 2021-05-07 0000038725-21-000096 — 5.07
- 2021-05-07 0000038725-21-000094 — 5.02, 9.01
- 2021-04-27 0000038725-21-000088 — 7.01, 9.01
- 2021-04-27 0000038725-21-000085 — 2.02, 9.01
- 2021-04-01 0000038725-21-000080 — 7.01, 9.01
- 2021-02-17 0000038725-21-000013 — 7.01, 9.01
- 2021-02-16 0000038725-21-000010 — 2.02, 9.01
- 2021-01-04 0000038725-21-000003 — 7.01, 9.01
- 2020-12-18 0000038725-20-000241 — 5.02, 9.01
- 2020-11-09 0000038725-20-000223 — 7.01, 9.01
- 2020-11-02 0000038725-20-000210 — 7.01, 9.01
- 2020-10-27 0000038725-20-000206 — 2.02, 9.01
- 2020-07-28 0000038725-20-000168 — 2.02, 9.01
- 2020-06-25 0000038725-20-000164 — 8.01, 9.01
- 2020-06-25 0000038725-20-000163 — 8.01, 9.01
- 2020-05-11 0000038725-20-000133 — 5.02, 9.01
- 2020-05-08 0000038725-20-000119 — 5.07
- 2020-05-06 0000038725-20-000111 — 5.02, 9.01
- 2020-04-28 0000038725-20-000104 — 2.02, 9.01
- 2020-02-18 0000038725-20-000018 — 2.02, 9.01
- 2020-01-30 0000038725-20-000009 — 5.02, 5.03, 9.01
- 2019-11-04 0000038725-19-000234 — 7.01, 9.01
- 2019-10-29 0000038725-19-000221 — 2.02, 9.01
- 2019-08-01 0000038725-19-000193 — 7.01, 9.01
- 2019-07-23 0000038725-19-000178 — 2.02, 9.01
- 2019-05-07 0000038725-19-000140 — 5.03, 9.01
- 2019-05-03 0000038725-19-000124 — 5.07
- 2019-05-03 0000038725-19-000122 — 7.01, 9.01
- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2022-05-03

- none on or before 2022-05-03

## item 2.02 — earnings release, exhibit 99.1

[0000038725-22-000073:8k_2_02:1]
EX-99.1
2
a20220426ex991earningsrele.htm
EX-99.1

[0000038725-22-000073:8k_2_02:2]
Document

[0000038725-22-000073:8k_2_02:3]
Exhibit 99.1

[0000038725-22-000073:8k_2_02:4]
NEWS RELEASE FOR IMMEDIATE DISTRIBUTION

[0000038725-22-000073:8k_2_02:5]
FRANKLIN ELECTRIC REPORTS RECORD FIRST QUARTER 2022 RESULTS

[0000038725-22-000073:8k_2_02:6]
First Quarter 2022 Highlights

[0000038725-22-000073:8k_2_02:7]
•Record sales of $451.5 million, compared to first quarter 2021 sales of $333.0 million, an increase of 36%

[0000038725-22-000073:8k_2_02:8]
•Strong organic sales growth in all three Segments; Fueling Systems 29%, Water Systems 27%, and Distribution 26%

[0000038725-22-000073:8k_2_02:9]
•Operating income was a record at $39.9 million, compared to first quarter operating income in 2021 of $33.8 million, an increase of 18%

[0000038725-22-000073:8k_2_02:10]
•GAAP fully diluted earnings per share (EPS) was $0.63, a new record for any first quarter

[0000038725-22-000073:8k_2_02:11]
Fort Wayne, IN – April 26, 2022 – Franklin Electric Co. Inc. today announced first quarter financial results for fiscal year 2022.

[0000038725-22-000073:8k_2_02:12]
First quarter 2022 sales were $451.5 million, compared to first quarter 2021 sales of $333.0 million.  First quarter 2022 operating income was $39.9 million, compared to first quarter operating income in 2021 of $33.8 million.

[0000038725-22-000073:8k_2_02:13]
First quarter 2022 GAAP fully diluted earnings per share was $0.63, versus GAAP fully diluted EPS in the first quarter 2021 of $0.59.

[0000038725-22-000073:8k_2_02:14]
“Overall, the first quarter was a strong start to the year as we delivered another record first quarter for revenue, operating income and earnings per share.  We maintained our momentum with continued strong demand across all our businesses.  Our Distribution business posted year-over-year sales growth of 41 percent while our Water Systems and Fueling Systems businesses delivered sales growth of 38 and 28 percent, respectively with all business units benefitting from strong price and volume performance to drive profitable growth,” commented Gregg Sengstack, Franklin Electric’s Chairperson and Chief Executive Officer.

[0000038725-22-000073:8k_2_02:15]
“We achieved record top line results on strong year-over-year organic and acquisition growth, while supply chain and inflationary challenges persisted during the first quarter constraining our margins, and our open order balance increased during the first quarter which is indicative of the current demand environment.  Our team remains focused on managing these impacts while meeting our customers' needs, and we will remain agile in response to the evolving landscape,” concluded Mr. Sengstack.

[0000038725-22-000073:8k_2_02:16]
Segment Summaries

[0000038725-22-000073:8k_2_02:17]
Water Systems sales, a new record for any first quarter, were $272.6 million in the first quarter 2022, an increase of $75.0 million or 38 percent versus the first quarter 2021. Water Systems sales, excluding acquisitions and the impact of foreign currency translation, were up about 27 percent compared to the first quarter 2021.  Sales of groundwater pumping, surface pumping and dewatering equipment increased due to strong end market demand.  Water Systems operating income in the first quarter was $33.2 million driven by higher sales.  First quarter 2021 Water Systems operating income was $31.3 million.

[0000038725-22-000073:8k_2_02:18]
Distribution sales, a new record for any first quarter, were $134.9 million in the first quarter 2022.  The Distribution segment organic sales increased 26 percent compared to the first quarter of 2021.  Revenue growth was driven by solid demand primarily in the U.S. groundwater market due to strong price realization in addition to growth from acquisition. The Distribution segment operating income was $9.4 million in the first quarter of 2022 compared to first quarter 2021 operating income of $2.0 million.

[0000038725-22-000073:8k_2_02:19]
Fueling Systems sales, a new record for any first quarter, were $72.5 million in the first quarter 2022, an increase of $15.7 million or 28 percent versus the first quarter 2021. Fueling Systems sales in the U.S. and Canada increased by about 33 percent compared to the first quarter 2021.  Outside the U.S. and Canada, Fueling Systems revenues increased by about 2 percent, as sales increases of 4 percent in the rest of the world outside of China were offset by lower sales in China. Fueling Systems operating income in the first quarter was $17.7 million, compared to $14.9 million in the first quarter of 2021.

[0000038725-22-000073:8k_2_02:20]
2022 Guidance

[0000038725-22-000073:8k_2_02:21]
The Company is maintaining its full year 2022 sales to be in the range of $1.90 billion to $2.05 billion and full year 2022 earnings per share before restructuring expenses to be in the range from $3.50 to $3.75.

[0000038725-22-000073:8k_2_02:22]
Earnings Conference Call

[0000038725-22-000073:8k_2_02:23]
A conference call to review earnings and other developments in the business will commence at 9:00 am ET. The first quarter 2022 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-22-000073:8k_2_02:24]
https://edge.media-server.com/mmc/p/wuadmxpg

[0000038725-22-000073:8k_2_02:25]
If you intend to ask questions during the call, please dial in using 877.643.7158 for domestic calls and 914.495.8565 for international calls. The conference ID is: 5883286.

[0000038725-22-000073:8k_2_02:26]
A replay of the conference call will be available Tuesday, April 26, 2022, at 12:00 noon ET through noon ET on Tuesday, May 3, 2022, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls. The replay passcode is: 5883286.

[0000038725-22-000073:8k_2_02:27]
Forward Looking Statements

[0000038725-22-000073:8k_2_02:28]
About Franklin Electric

[0000038725-22-000073:8k_2_02:29]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-22-000073:8k_2_02:30]
Franklin Electric Contact:

[0000038725-22-000073:8k_2_02:31]
Jeffery L. Taylor

[0000038725-22-000073:8k_2_02:32]
Franklin Electric Co., Inc.

[0000038725-22-000073:8k_2_02:33]
260-824-2900

[0000038725-22-000073:8k_2_02:34]
Email:jeffery.taylor@fele.com

[0000038725-22-000073:8k_2_02:35]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | First Quarter Ended |  |  |
|  | March 31, 2022 |  | March 31, 2021 |  |  |  |  |
| Net sales | $ | 451,470 |  |  | $ | 333,046 |  |  |  |  |  |
| Cost of sales | 306,136 |  |  | 217,500 |  |  |  |  |  |
| Gross profit | 145,334 |  |  | 115,546 |  |  |  |  |  |
| Selling, general, and administrative expenses | 104,673 |  |  | 81,603 |  |  |  |  |  |
| Restructuring expense | 720 |  |  | 152 |  |  |  |  |  |
| Operating income | 39,941 |  |  | 33,791 |  |  |  |  |  |
| Interest expense | (1,494) |  |  | (1,090) |  |  |  |  |  |
| Other income/(expense), net | (378) |  |  | (100) |  |  |  |  |  |
| Foreign exchange income/(expense) | (585) |  |  | (57) |  |  |  |  |  |
| Income before income taxes | 37,484 |  |  | 32,544 |  |  |  |  |  |
| Income tax (benefit)/ expense | 7,365 |  |  | 4,381 |  |  |  |  |  |
| Net income | $ | 30,119 |  |  | $ | 28,163 |  |  |  |  |  |
| Less: Net (income)/loss attributable to noncontrolling interests | (354) |  |  | (283) |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 29,765 |  |  | $ | 27,880 |  |  |  |  |  |
| Income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.64 |  |  | $ | 0.60 |  |  |  |  |  |
| Diluted | $ | 0.63 |  |  | $ | 0.59 |  |  |  |  |  |

[0000038725-22-000073:8k_2_02:36]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | March 31, 2022 |  | December 31, 2021 |
| ASSETS |  |
| Cash and equivalents | $ | 38,581 |  |  | $ | 40,536 |  |
| Receivables (net) | 229,736 |  |  | 196,173 |  |
| Inventories | 527,867 |  |  | 449,975 |  |
| Other current assets | 37,401 |  |  | 37,963 |  |
| Total current assets | 833,585 |  |  | 724,647 |  |
| Property, plant, and equipment, net | 214,190 |  |  | 210,654 |  |
| Right-of-use asset, net | 46,458 |  |  | 48,379 |  |
| Goodwill and other assets | 588,956 |  |  | 591,485 |  |
| Total assets | $ | 1,683,189 |  |  | $ | 1,575,165 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 190,488 |  |  | $ | 164,758 |  |
| Accrued expenses and other current liabilities | 91,066 |  |  | 117,955 |  |
| Current lease liability | 15,188 |  |  | 15,320 |  |
| Current maturities of long-term debt and short-term borrowings | 194,846 |  |  | 97,981 |  |
| Total current liabilities | 491,588 |  |  | 396,014 |  |
| Long-term debt | 89,933 |  |  | 90,535 |  |
| Long-term lease liability | 31,140 |  |  | 32,937 |  |
| Income taxes payable non-current | 11,610 |  |  | 11,610 |  |
| Deferred income taxes | 29,828 |  |  | 28,162 |  |
| Employee benefit plans | 39,926 |  |  | 40,696 |  |
| Other long-term liabilities | 24,999 |  |  | 26,568 |  |
| Redeemable noncontrolling interest | 106 |  |  | (19) |  |
| Total equity | 964,059 |  |  | 948,662 |  |
| Total liabilities and equity | $ | 1,683,189 |  |  | $ | 1,575,165 |  |

[0000038725-22-000073:8k_2_02:37]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Three Months Ended |
| (In thousands) |  |  |  |
|  | March 31, 2022 |  | March 31, 2021 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 30,119 |  |  | $ | 28,163 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 12,078 |  |  | 9,574 |  |
| Non-cash lease expense | 4,181 |  |  | 3,068 |  |
| Share-based compensation | 3,985 |  |  | 4,190 |  |
| Other | 2,473 |  |  | 359 |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (34,119) |  |  | (24,196) |  |
| Inventory | (74,690) |  |  | (14,327) |  |
| Accounts payable and accrued expenses | (2,753) |  |  | (298) |  |
| Operating leases | (4,181) |  |  | (3,068) |  |
| Other | 1,596 |  |  | 1,917 |  |
| Net cash flows from operating activities | (61,311) |  |  | 5,382 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (9,456) |  |  | (6,744) |  |
| Proceeds from sale of property, plant, and equipment | — |  |  | — |  |
| Acquisitions and investments | 553 |  |  | 70 |  |
| Other investing activities | — |  |  | 3 |  |
| Net cash flows from investing activities | (8,903) |  |  | (6,671) |  |
| Cash flows from financing activities: |  |  |  |
| Net change in debt | 96,851 |  |  | (457) |  |
| Proceeds from issuance of common stock | 343 |  |  | 5,083 |  |
| Purchases of common stock | (19,319) |  |  | (4,849) |  |
| Dividends paid | (9,130) |  |  | (8,143) |  |
| Net cash flows from financing activities | 68,745 |  |  | (8,366) |  |
| Effect of exchange rate changes on cash | (486) |  |  | (2,801) |  |
| Net change in cash and equivalents | (1,955) |  |  | (12,456) |  |
| Cash and equivalents at beginning of period | 40,536 |  |  | 130,787 |  |
| Cash and equivalents at end of period | $ | 38,581 |  |  | $ | 118,331 |  |

[0000038725-22-000073:8k_2_02:38]
Key Performance Indicators: Earnings Per Share Calculations

[0000038725-22-000073:8k_2_02:39]
| Earnings Before and After Restructuring |  | For the First Quarter |  |  |
| (in millions) |  | 2022 | 2021 | Change |  |  |  |  |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 29.8 |  | $ | 27.9 |  | 7 | % |  |  |  |  |
| Allocated Earnings |  | $ | (0.1) |  | $ | (0.2) |  |  |  |  |  |  |
| Earnings for EPS Calculations |  | $ | 29.7 |  | $ | 27.7 |  | 7 | % |  |  |  |  |
| Restructuring (before tax): |  | $ | 0.7 |  | $ | 0.2 |  |  |  |  |  |  |
| Restructuring, net of tax: |  | $ | 0.6 |  | $ | 0.1 |  |  |  |  |  |  |
| Earnings Before Restructuring |  | $ | 30.3 |  | $ | 27.8 |  | 9 | % |  |  |  |  |
| Earnings Per Share |  | For the First Quarter |  |  |
| Before and After Restructuring |  | 2022 | 2021 | Change |  |  |  |  |
| (in millions except Earnings Per Share) |  |  |  |  |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 47.1 |  | 46.9 |  | — | % |  |  |  |  |
| Fully Diluted Earnings Per Share (“EPS”) Reported |  | $ | 0.63 |  | $ | 0.59 |  | 7 | % |  |  |  |  |
| Restructuring Per Share, net of tax |  | $ | 0.01 |  | $ | — |  |  |  |  |  |  |
| Fully Diluted EPS Before Restructuring |  | $ | 0.64 |  | $ | 0.59 |  | 8 | % |  |  |  |  |

[0000038725-22-000073:8k_2_02:40]
Key Performance Indicators: Net Sales Summary

[0000038725-22-000073:8k_2_02:41]
|  | Net Sales |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q1 2021 | $ | 101.3 |  | $ | 31.7 |  | $ | 44.4 |  | $ | 20.2 |  | $ | 197.6 |  | $ | 56.8 |  | $ | 95.7 |  | $ | (17.1) |  | $ | 333.0 |  |
| Q1 2022 | $ | 163.2 |  | $ | 37.9 |  | $ | 51.0 |  | $ | 20.5 |  | $ | 272.6 |  | $ | 72.5 |  | $ | 134.9 |  | $ | (28.5) |  | $ | 451.5 |  |
| Change | $ | 61.9 |  | $ | 6.2 |  | $ | 6.6 |  | $ | 0.3 |  | $ | 75.0 |  | $ | 15.7 |  | $ | 39.2 |  | $ | (11.4) |  | $ | 118.5 |  |
| % Change | 61 | % | 20 | % | 15 | % | 1 | % | 38 | % | 28 | % | 41 | % |  | 36 | % |
| Foreign currency translation | $ | — |  | $ | (0.2) |  | $ | (11.6) |  | $ | (0.6) |  | $ | (12.4) |  | $ | (0.7) |  | $ | — |  |  |  |
| % Change | — | % | (1) | % | (26) | % | (3) | % | (6) | % | (1) | % | — | % |  |  |
| Acquisitions | $ | 32.1 |  | $ | — |  | $ | — |  | $ | 1.8 |  | $ | 33.9 |  | $ | — |  | $ | 14.3 |  |  |  |
| Volume/Price | $ | 29.8 |  | $ | 6.4 |  | $ | 18.2 |  | $ | (0.9) |  | $ | 53.5 |  | $ | 16.4 |  | $ | 24.9 |  |  |  |
| % Change | 29 | % | 20 | % | 41 | % | (4) | % | 27 | % | 29 | % | 26 | % |  |  |

[0000038725-22-000073:8k_2_02:42]
Key Performance Indicators: Operating Income and Margin Summary

[0000038725-22-000073:8k_2_02:43]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the First Quarter 2022 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 33.2 |  | $ | 17.7 |  | $ | 9.4 |  | $ | (20.4) |  | $ | 39.9 |  |
| % Operating Income To Net Sales | 12.2 | % | 24.4 | % | 7.0 | % |  | 8.8 | % |
| Restructuring | $ | 0.6 |  | $ | — |  | $ | 0.1 |  | $ | — |  | $ | 0.7 |  |
| Operating Income/(Loss) Before Restructuring | $ | 33.8 |  | $ | 17.7 |  | $ | 9.5 |  | $ | (20.4) |  | $ | 40.6 |  |
| % Operating Income to Net Sales Before Restructuring | 12.4 | % | 24.4 | % | 7.0 | % |  | 9.0 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the First Quarter 2021 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 31.3 |  | $ | 14.9 |  | $ | 2.0 |  | $ | (14.4) |  | $ | 33.8 |  |
| % Operating Income To Net Sales | 15.8 | % | 26.2 | % | 2.1 | % |  | 10.2 | % |
| Restructuring | $ | 0.1 |  | $ | — |  | $ | 0.1 |  | $ | — |  | $ | 0.2 |  |
| Operating Income/(Loss) Before Restructuring | $ | 31.4 |  | $ | 14.9 |  | $ | 2.1 |  | $ | (14.4) |  | $ | 34.0 |  |
| % Operating Income to Net Sales Before Restructuring | 15.9 | % | 26.2 | % | 2.2 | % |  | 10.2 | % |
