# FELE MD&A — 0000038725-20-000107


## mdna

[0000038725-20-000107:mdna:1]
[same as prior period, unchanged from 0000038725-19-000242:mdna:1]

[0000038725-20-000107:mdna:2]
First Quarter 2020 vs. First Quarter 2019

[0000038725-20-000107:mdna:3]
[same as prior period, unchanged from 0000038725-19-000242:mdna:3]

[0000038725-20-000107:mdna:4]
Sales in the first quarter of 2020 decreased from the first quarter of last year. Sales in the quarter declined by $24 million or about 8 percent primarily due to lower Water and Fueling Systems sales volumes and foreign currency exchange partially offset by achieved price.  The Company's consolidated gross profit was $90.3 million for the first quarter of 2020, an increase from the prior year’s first quarter. The gross profit as a percent of net sales was 33.9 percent in the first quarter of 2020 versus 30.8 percent during the first quarter 2019 and improved primarily due to better price realization and product sales mix.

[0000038725-20-000107:mdna:5]
EFFECTS OF THE GLOBAL PANDEMIC

[0000038725-20-000107:mdna:6]
The top priority of the Company is the health and welfare of its employees and partners around the world.  In response to the health risks posed by the Global Pandemic, the Company implemented and has been following the recommended hygiene and social distancing practices promulgated by the United States Centers for Disease Control and the World Health Organization.

[0000038725-20-000107:mdna:7]
The Company’s products and services are generally viewed as essential in most jurisdictions in which the Company operates.  Accordingly, the Company’s global manufacturing and distribution operations generally remain open subject to temporary government mandated closures which have occurred in China, Italy, South Africa, India and several countries in South America. These temporary closures have not had a material impact on the ability to supply products to the Company’s customers.

[0000038725-20-000107:mdna:8]
The Company has assessed the end markets it serves to determine changes in demand patterns and customer behaviors.  From this assessment, the Company currently believes that the most significant risks to the previously provided financial outlook for 2020 are a reduction of large dewatering equipment sales in the Water Systems segment; Water Systems customers destocking their inventory, particularly in the U.S. and Canada plumbing channel; and, the deferral or cancellation of the construction of new filling stations in the Fueling Systems segment in the U.S and Canada.  Additionally, the strengthening of the U.S. dollar versus most international currencies will result in lower translations of both net sales and earnings from many of the Company’s businesses outside the U.S.  Beyond these specific end market considerations, the Company may experience other negative impacts to profitability from various government mandated closures and related customer behavior.

[0000038725-20-000107:mdna:9]
Additional adverse financial impacts from these risks include lost operational efficiencies, deleveraging of the manufacturing fixed costs base due to lower manufactured volumes, and the potential for higher bad debt expense.  The Company has taken action to offset the negative impacts of these risks by implementing various reductions in all discretionary spending.

[0000038725-20-000107:mdna:10]
The Company ended the first quarter of 2020 with a cash balance of $40 million and had total incremental borrowing capacity of $478 million.  The Company believes it has enough liquidity to meet its operating and cash flow requirements for the foreseeable future.

[0000038725-20-000107:mdna:11]
[same as prior period, unchanged from 0000038725-19-000242:mdna:5]

[0000038725-20-000107:mdna:12]
[same as prior period, unchanged from 0000038725-19-000242:mdna:6]

[0000038725-20-000107:mdna:13]
Net sales in the first quarter of 2020 were $266.8 million, a decrease of $23.9 million or about 8 percent compared to 2019 first quarter sales of $290.7 million.  The sales increase from acquisition related sales was $3.9 million.  Sales revenue decreased by $8.1 million or about 3 percent in the first quarter of 2020 due to foreign currency translation. Excluding acquisitions and the impact of foreign currency translation, the Company’s organic sales growth was negative about 7 percent.

[0000038725-20-000107:mdna:14]
|  | Net Sales |  |  |  |  |
| (In millions) | Q1 2020 |  | Q1 2019 |  | 2020 v 2019 |
| Water Systems | $ | 164.1 |  |  | $ | 188.4 |  |  | $ | (24.3) |  |
| Fueling Systems | 55.3 |  |  | 60.2 |  |  | $ | (4.9) |  |
| Distribution | 60.4 |  |  | 53.3 |  |  | $ | 7.1 |  |
| Eliminations/Other | (13.0) |  |  | (11.2) |  |  | $ | (1.8) |  |
| Consolidated | $ | 266.8 |  |  | $ | 290.7 |  |  | $ | (23.9) |  |

[0000038725-20-000107:mdna:15]
[same as prior period, unchanged from 0000038725-19-000242:mdna:9]

[0000038725-20-000107:mdna:16]
Water Systems revenues were $164.1 million in the first quarter 2020, a decrease of $24.3 million or about 13 percent versus the first quarter 2019 sales of $188.4 million. In the first quarter of 2020, sales from businesses acquired since the first quarter of 2019 were $3.9 million.  Sales were decreased by $7.7 million or 4 percent in the quarter due to foreign currency translation. Water Systems sales were down about 11 percent, excluding acquisitions and foreign currency translation, in the first quarter of 2020 versus the first quarter of 2019.

[0000038725-20-000107:mdna:17]
Water Systems sales in the U.S. and Canada decreased by 14 percent overall compared to the first quarter 2019, primarily due to lower sales of dewatering equipment.  Sales of dewatering equipment decreased by nearly 54 percent due to lower sales in rental channels and substantial uncertainty in oil production end markets. Sales of groundwater pumping equipment increased by 2 percent versus the first quarter 2019, in part due to more normal weather conditions than a year ago.  Sales of surface pumping equipment decreased by 14 percent on lower sales of both wastewater and water transfer systems as customers in this channel began to feel the impact of the Global Pandemic and lowered their own inventory levels.

[0000038725-20-000107:mdna:18]
Water Systems sales in markets outside the U.S. and Canada decreased by 11 percent overall.  Foreign currency translation decreased sales by 9 percent.  Outside the U.S. and Canada, Water Systems organic sales decreased by 2 percent, primarily driven by the Asia Pacific markets as customers in Korea, Japan and China were impacted by the Global Pandemic.

[0000038725-20-000107:mdna:19]
[same as prior period, unchanged from 0000038725-19-000242:mdna:13]

[0000038725-20-000107:mdna:20]
Fueling Systems sales were $55.3 million in the first quarter of 2020, a decrease of $4.9 million or about 8 percent versus the first quarter 2019 sales of $60.2 million. Fueling Systems sales were decreased by $0.4 million or 1 percent in the quarter due to foreign currency translation. Fueling Systems sales, excluding foreign currency translation, declined by about 7 percent.

[0000038725-20-000107:mdna:21]
Fueling Systems sales in the U.S. and Canada increased by about 7 percent compared to the first quarter 2019.  The increase was principally in the piping, pumping and fuel management systems product lines.  Outside the U.S. and Canada, Fueling Systems revenues declined by about 30 percent, driven by lower sales in Asia Pacific, primarily China.

[0000038725-20-000107:mdna:22]
[same as prior period, unchanged from 0000038725-19-000242:mdna:16]

[0000038725-20-000107:mdna:23]
Distribution sales were $60.4 million in the first quarter 2020, an increase of $7.1 million versus first quarter 2019 sales of $53.3 million.  The Distribution segment organic sales increased about 13 percent compared to the first quarter of 2019.   More favorable weather conditions versus the first quarter last year contributed to the revenue growth.

[0000038725-20-000107:mdna:24]
[same as prior period, unchanged from 0000038725-19-000242:mdna:18]

[0000038725-20-000107:mdna:25]
Cost of sales as a percentage of net sales for the first quarters of 2020 and 2019 was 66.1 percent and 69.2 percent, respectively. Correspondingly, the gross profit margin increased to 33.9 percent from 30.8 percent. The Company’s consolidated gross profit was $90.3 million for the first quarter of 2020, an increase from the first quarter of 2019 gross profit of $89.5 million. The gross profit margin improved primarily due to better price realization and product sales mix shifts.

[0000038725-20-000107:mdna:26]
[same as prior period, unchanged from 0000038725-19-000242:mdna:20]

[0000038725-20-000107:mdna:27]
Selling, general, and administrative (SG&A) expenses were $75.6 million in the first quarter of 2020 compared to $76.3 million in the first quarter of 2019. SG&A expenses from acquired businesses were $0.8 million and excluding the acquired entities, the Company’s SG&A expenses in the first quarter of 2020 were $74.8 million, a decrease of about 2 percent from the first quarter 2019. SG&A expenses were lower in part because of foreign currency translation versus the prior year, lower variable compensation expenses, and company wide efforts to lower spending in response to the pending impacts of the Global Pandemic.

[0000038725-20-000107:mdna:28]
[same as prior period, unchanged from 0000038725-19-000242:mdna:22]

[0000038725-20-000107:mdna:29]
There were $0.9 million of restructuring expenses for the first quarter of 2020. Restructuring expenses for the first quarter of 2020 were $0.6 million in the Water and $0.2 million in Fueling segments and related to continued miscellaneous manufacturing realignment activities, as well as $0.1 million in the Distribution segment related to miscellaneous branch closings and consolidation.

[0000038725-20-000107:mdna:30]
There were $1.1 million of restructuring expenses for the first quarter of 2019. Restructuring expenses for the first quarter of 2019 were $0.6 million in the Distribution segment and related to miscellaneous branch closings and consolidation. Restructuring expenses for the first quarter of 2019 were $0.5 million in the Water segment and related to continued miscellaneous manufacturing realignment activities.

[0000038725-20-000107:mdna:31]
[same as prior period, unchanged from 0000038725-19-000242:mdna:24]

[0000038725-20-000107:mdna:32]
Operating income was $13.8 million in the first quarter of 2020, up $1.7 million or about 14 percent from $12.1 million in the first quarter of 2019.

[0000038725-20-000107:mdna:33]
|  |  | Operating income (loss) |  |  |  |  |
| (In millions) |  | Q1 2020 |  | Q1 2019 |  | 2020 v 2019 |
| Water Systems |  | $ | 18.8 |  |  | $ | 19.2 |  |  | $ | (0.4) |  |
| Fueling Systems |  | 12.1 |  |  | 12.3 |  |  | (0.2) |  |
| Distribution |  | (2.2) |  |  | (4.3) |  |  | 2.1 |  |
| Eliminations/Other |  | (14.9) |  |  | (15.1) |  |  | 0.2 |  |
| Consolidated |  | $ | 13.8 |  |  | $ | 12.1 |  |  | $ | 1.7 |  |

[0000038725-20-000107:mdna:34]
[same as prior period, unchanged from 0000038725-19-000242:mdna:27]

[0000038725-20-000107:mdna:35]
Water Systems operating income was $18.8 million in the first quarter 2020, down $0.4 million versus the first quarter 2019. Operating income decreased in Water Systems primarily due to lower sales volume. The first quarter operating income margin was 11.5 percent, up 130 basis points from 10.2 percent in the first quarter of 2019. Operating income margin increased in Water Systems primarily due to better price realization and improved product sales mix.

[0000038725-20-000107:mdna:36]
[same as prior period, unchanged from 0000038725-19-000242:mdna:29]

[0000038725-20-000107:mdna:37]
Fueling Systems operating income was $12.1 million in the first quarter of 2020 compared to $12.3 million in the first quarter of 2019. The decrease in operating income was primarily related to lower sales. The first quarter Fueling Systems operating income margin was 21.9 percent, an increase of 150 basis points from the 20.4 percent of net sales in the first quarter of 2019. Operating income margin improved due to a better geographic and product sales mix.

[0000038725-20-000107:mdna:38]
[same as prior period, unchanged from 0000038725-19-000242:mdna:32]

[0000038725-20-000107:mdna:39]
The Distribution segment recorded an operating loss of $2.2 million in the first quarter of 2020 compared to a $4.3 million loss in the first quarter of 2019. The Distribution loss was primarily due to lost leverage on fixed costs from lower sales. The Distribution segment’s operations are seasonal and product sales are significantly slower during the fourth and first quarters, i.e., the winter months in North America.

[0000038725-20-000107:mdna:40]
[same as prior period, unchanged from 0000038725-19-000242:mdna:34]

[0000038725-20-000107:mdna:41]
Operating income-Eliminations/Other is composed primarily of intersegment sales and profit eliminations and unallocated general and administrative expenses.  The intersegment profit elimination impact in the first quarter of 2020 versus the first quarter of 2019 was income of $0.7 million. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer. General and administrative expenses were higher by $0.5 million or about 4 percent to last year.

[0000038725-20-000107:mdna:42]
[same as prior period, unchanged from 0000038725-19-000242:mdna:36]

[0000038725-20-000107:mdna:43]
Interest expense for the first quarters of 2020 and 2019 was $1.2 million and $2.3 million, respectively.  Interest expense was lower primarily due to lower debt.

[0000038725-20-000107:mdna:44]
[same as prior period, unchanged from 0000038725-19-000242:mdna:38]

[0000038725-20-000107:mdna:45]
Other income or expense was a loss in the first quarter of 2020 of $0.2 million and a gain of $0.2 million in the first quarter of 2019.

[0000038725-20-000107:mdna:46]
[same as prior period, unchanged from 0000038725-19-000242:mdna:40]

[0000038725-20-000107:mdna:47]
Foreign currency-based transactions produced a gain for the first quarters of 2020 and 2019 of $1.0 million and $0.6 million, respectively.

[0000038725-20-000107:mdna:48]
[same as prior period, unchanged from 0000038725-19-000242:mdna:42]

[0000038725-20-000107:mdna:49]
The provision for income taxes in the first quarter of 2020 and 2019 was $2.6 million and $1.5 million, respectively. The effective tax rate for the first quarter of 2020 was about 19 percent and, before the impact of discrete events, was about 20 percent. The effective tax rate for the first quarter of 2019 was about 14 percent and, before the impact of discrete events, was about 20 percent. The increase in the effective tax rate was primarily the result of unfavorable discrete events of $0.4 million during the first quarter of 2020. The tax rate as a percentage of pre-tax earnings for the full year of 2020 is projected to be about 20 percent, compared to the full year 2019 tax rate of about 20 percent, both before discrete adjustments.

[0000038725-20-000107:mdna:50]
[same as prior period, unchanged from 0000038725-19-000242:mdna:44]

[0000038725-20-000107:mdna:51]
Net income for the first quarter of 2020 was $10.8 million compared to the prior year first quarter net income of $9.1 million.  Net income attributable to Franklin Electric Co., Inc. for the first quarter of 2020 was $10.6 million, or $0.23 per diluted share, compared to the prior year first quarter net income attributable to Franklin Electric Co., Inc. of $9.1 million or $0.19 per diluted share.

[0000038725-20-000107:mdna:52]
[same as prior period, unchanged from 0000038725-19-000242:mdna:89]

[0000038725-20-000107:mdna:53]
[same as prior period, unchanged from 0000038725-19-000242:mdna:90]

[0000038725-20-000107:mdna:54]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available.  The Company believes its capital resources and liquidity position at March 31, 2020 is adequate to meet projected needs for the foreseeable future.  The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-20-000107:mdna:55]
As of March 31, 2020 the Company had a $300.0 million revolving credit facility.  The facility is scheduled to mature on October 28, 2021.  As of March 31, 2020, the Company had $256.8 million borrowing capacity under the Credit Agreement as $4.2 million in letters of commercial and standby letters of credit were outstanding and undrawn and $39.0 million in revolver borrowings were drawn and outstanding which were primarily used for working capital needs, the payment of existing indebtedness, and acquisitions.

[0000038725-20-000107:mdna:56]
The Company also has other long-term debt borrowing outstanding as of March 31, 2020.  See Note 9 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-20-000107:mdna:57]
At March 31, 2020, the Company had $34.0 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations.  There is currently no need or intent to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-20-000107:mdna:58]
[same as prior period, unchanged from 0000038725-19-000242:mdna:95]

[0000038725-20-000107:mdna:59]
The following table summarizes significant sources and uses of cash and cash equivalents for the first three months of 2020 and 2019.

[0000038725-20-000107:mdna:60]
| (in millions) |  | 2020 |  | 2019 |
| Net cash flows from operating activities |  | $ | (4.7) |  |  | $ | (2.9) |  |
| Net cash flows from investing activities |  | (11.1) |  |  | (10.6) |  |
| Net cash flows from financing activities |  | (3.7) |  |  | 9.9 |  |
| Impact of exchange rates on cash and cash equivalents |  | (4.9) |  |  | (1.2) |  |
| Change in cash and cash equivalents |  | $ | (24.4) |  |  | $ | (4.8) |  |

[0000038725-20-000107:mdna:61]
[same as prior period, unchanged from 0000038725-19-000242:mdna:98]

[0000038725-20-000107:mdna:62]
2020 vs. 2019

[0000038725-20-000107:mdna:63]
Net cash used in operating activities was $4.7 million for the three months ended March 31, 2020 compared to $2.9 million used in operating activities for the three months ended March 31, 2019.  The increase in cash used was due to a decrease of $4.3 million in other operating activities, primarily in long-term liabilities, offset by lower tax payments of $1.3 million as well as an increase in net income of $1.7 million.

[0000038725-20-000107:mdna:64]
[same as prior period, unchanged from 0000038725-19-000242:mdna:101]

[0000038725-20-000107:mdna:65]
2020 vs. 2019

[0000038725-20-000107:mdna:66]
Net cash used in investing activities was $11.1 million for the three months ended March 31, 2020 compared to $10.6 million used in investing activities for the three months ended March 31, 2019.  The increase in cash used in investing activities is primarily attributable to increased acquisition activity and property, plant and equipment expenditures.

[0000038725-20-000107:mdna:67]
[same as prior period, unchanged from 0000038725-19-000242:mdna:104]

[0000038725-20-000107:mdna:68]
2020 vs. 2019

[0000038725-20-000107:mdna:69]
Net cash used in financing activities was $3.7 million for the three months ended March 31, 2020 compared to $9.9 million provided by financing activities for the three months ended March 31, 2019. The change in net cash from financing activities was primarily attributable to an increase of $12.7 million in common stock repurchases in the current year.

[0000038725-20-000107:mdna:70]
[same as prior period, unchanged from 0000038725-19-000242:mdna:107]
