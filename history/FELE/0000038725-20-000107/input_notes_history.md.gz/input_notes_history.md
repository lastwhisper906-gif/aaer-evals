# FELE note change history — 0000038725-19-000242 → 0000038725-20-000107


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-05-05):
[0000038725-20-000107:note_history:1]
At March 31, 2020, the Company had $5.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.
  (was, 2019-11-05, similarity 0.966):
[0000038725-19-000242:note_history:1]
At September 30, 2019, the Company had $11.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

- changed (2020-05-05):
[0000038725-20-000107:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the first quarter ended March 31, 2020, are as follows:
  (was, 2019-11-05, similarity 0.8921):
[0000038725-19-000242:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 30, 2019, are as follows:

- changed (2020-05-05):
[0000038725-20-000107:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2019 |  | $ | 9.1 |  |
| Accruals related to product warranties |  | 2.1 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (2.5) |  |
| Balance as of March 31, 2020 |  | $ | 8.7 |  |
  (was, 2019-11-05, similarity 0.9574):
[0000038725-19-000242:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2018 |  | $ | 9.0 |  |
| Accruals related to product warranties |  | 7.9 |  |
| Additions related to acquisitions |  | 0.2 |  |
| Reductions for payments made |  | (8.0 | ) |
| Balance as of September 30, 2019 |  | $ | 9.1 |  |

- changed (2020-05-05):
[0000038725-20-000107:note_history:4]
The components of the Company’s operating lease portfolio as of the first quarter ended March 31, 2020 are as follows:
  (was, 2019-11-05, similarity 0.8221):
[0000038725-19-000242:note_history:4]
The components of the Company’s operating lease portfolio for both the third quarter and the nine months ended September 30, 2019 are as follows:

- changed (2020-05-05):
[0000038725-20-000107:note_history:5]
| Lease Cost (in millions): |  |  |  |
| Operating lease cost |  |  | $ | 2.0 |  |
| Short-term lease cost |  |  | 0.1 |  |
| Other Information: |  |  |  |
| Weighted-average remaining lease term |  |  | 4 years |
| Weighted-average discount rate |  |  | 3.8 | % |
  (was, 2019-11-05, similarity 0.8769):
[0000038725-19-000242:note_history:5]
| Lease Cost (in millions): | Third Quarter Ended |  | Nine Months Ended |
| Operating lease cost | $ | 2.4 |  |  | $ | 7.6 |  |
| Short-term lease cost | — |  |  | 0.1 |  |
| Other Information: |  |  |  |
| Weighted-average remaining lease term |  |  | 6 years |  |
| Weighted-average discount rate |  |  | 3.9 | % |

- changed (2020-05-05):
[0000038725-20-000107:note_history:6]
The minimum rental payments for non-cancellable operating leases as of March 31, 2020, are as follows:
  (was, 2019-11-05, similarity 0.949):
[0000038725-19-000242:note_history:6]
The minimum rental payments for non-cancellable operating leases as of September 30, 2019, are as follows:

- removed (2020-05-05):
[0000038725-19-000242:note_history:7]
The minimum rental payments for non-cancellable operating leases as of December 31, 2018, were reported as follows:

- removed (2020-05-05):
[0000038725-19-000242:note_history:8]
| (In millions) | 2019 | 2020 | 2021 | 2022 | 2023 | Thereafter |
| Future Minimum Rental Payments | $ | 8.9 |  | $ | 5.9 |  | $ | 3.5 |  | $ | 2.0 |  | $ | 1.1 |  | $ | 5.7 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-05-05):
[0000038725-20-000107:note_history:9]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2019, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2020, and for the first quarters ended March 31, 2020 and March 31, 2019 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made.  Operating results for the first quarter ended March 31, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2020.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2019.
  (was, 2019-11-05, similarity 0.9363):
[0000038725-19-000242:note_history:9]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2018, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 30, 2019, and for the third quarters and nine months ended September 30, 2019 and September 30, 2018 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made.  Operating results for the third quarter and nine months ended September 30, 2019 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2019.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2018.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-05):
[0000038725-20-000107:note_history:10]
| (In millions) |  | March 31, 2020 |  | December 31, 2019 |
| Tax increment financing debt |  | 18.2 |  |  | 18.7 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 39.0 |  |  | 19.0 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 2.2 |  |  | 2.3 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 134.3 |  |  | $ | 115.0 |  |
| Less: current maturities |  | (41.7) |  |  | (21.9) |  |
| Long-term debt |  | $ | 92.6 |  |  | $ | 93.1 |  |
  (was, 2019-11-05, similarity 0.8647):
[0000038725-19-000242:note_history:10]
| (In millions) |  | September 30, 2019 |  | December 31, 2018 |
| Prudential Agreement |  | $ | — |  |  | $ | 30.0 |  |
| Tax increment financing debt |  | 18.7 |  |  | 19.8 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 79.1 |  |  | 76.3 |  |
| Financing Leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 1.1 |  |  | 5.4 |  |
| Less: unamortized debt issuance costs |  | (0.1 | ) |  | (0.2 | ) |
|  |  | $ | 173.9 |  |  | $ | 206.4 |  |
| Less: current maturities |  | (80.8 | ) |  | (112.0 | ) |
| Long-term debt |  | $ | 93.1 |  |  | $ | 94.4 |  |

- changed (2020-05-05):
[0000038725-20-000107:note_history:11]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2020 matures as follows:
  (was, 2019-11-05, similarity 0.9474):
[0000038725-19-000242:note_history:11]
Debt outstanding, excluding unamortized debt issuance costs, at September 30, 2019 matures as follows:

- changed (2020-05-05):
[0000038725-20-000107:note_history:12]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 134.4 |  |  | $ | 41.7 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.4 |  |  | $ | 87.4 |  |
  (was, 2019-11-05, similarity 0.7048):
[0000038725-19-000242:note_history:12]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 173.9 |  |  | $ | 80.7 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.4 |  |  | $ | 88.0 |  |
| Financing Leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 174.0 |  |  | $ | 80.7 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.4 |  |  | $ | 88.0 |  |

- changed (2020-05-05):
[0000038725-20-000107:note_history:13]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement"), which expires on July 30, 2021 and has an initial borrowing capacity of $250.0 million.  As of March 31, 2020, the Company has $150.0 million borrowing capacity available under the Prudential Agreement.
  (was, 2019-11-05, similarity 0.6608):
[0000038725-19-000242:note_history:13]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with an initial borrowing capacity of $250.0 million.  The Company paid the remaining principal balance of the previously issued notes during the second quarter of 2019.  As of September 30, 2019, the Company has $150.0 million borrowing capacity available under the Prudential Agreement. There is no additional borrowing capacity resulting from principal payments made by the Company.

- changed (2020-05-05):
[0000038725-20-000107:note_history:14]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"), with a maximum aggregate borrowing capacity of $200.0 million.  On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually.  The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of March 31, 2020, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.
  (was, 2019-11-05, similarity 0.9897):
[0000038725-19-000242:note_history:14]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"), with a maximum aggregate borrowing capacity of $200.0 million.  On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually.  The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of September 30, 2019, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

- changed (2020-05-05):
[0000038725-20-000107:note_history:15]
As of March 31, 2020, the Company had $39.0 million in outstanding borrowings which were primarily used for working capital needs, the payment of existing indebtedness and acquisitions, $4.2 million in letters of credit outstanding, and $256.8 million of available capacity under the Credit Agreement.
  (was, 2019-11-05, similarity 0.9757):
[0000038725-19-000242:note_history:15]
As of September 30, 2019, the Company had $79.1 million in outstanding borrowings which were primarily used for working capital needs, the payment of existing indebtedness and acquisitions, $5.0 million in letters of credit outstanding, and $215.9 million of available capacity under the Credit Agreement.

- changed (2020-05-05):
[0000038725-20-000107:note_history:16]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 1.00 to 3.50 and a minimum interest coverage ratio of 1.00 to 3.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of March 31, 2020.
  (was, 2019-11-05, similarity 0.9941):
[0000038725-19-000242:note_history:16]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 1.00 to 3.50 and a minimum interest coverage ratio of 1.00 to 3.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of September 30, 2019.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-05):
[0000038725-20-000107:note_history:17]
| (In millions) |  | March 31, 2020 |  | December 31, 2019 |
| Tax increment financing debt |  | 18.2 |  |  | 18.7 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 39.0 |  |  | 19.0 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 2.2 |  |  | 2.3 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 134.3 |  |  | $ | 115.0 |  |
| Less: current maturities |  | (41.7) |  |  | (21.9) |  |
| Long-term debt |  | $ | 92.6 |  |  | $ | 93.1 |  |
  (was, 2019-11-05, similarity 0.8647):
[0000038725-19-000242:note_history:17]
| (In millions) |  | September 30, 2019 |  | December 31, 2018 |
| Prudential Agreement |  | $ | — |  |  | $ | 30.0 |  |
| Tax increment financing debt |  | 18.7 |  |  | 19.8 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 79.1 |  |  | 76.3 |  |
| Financing Leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 1.1 |  |  | 5.4 |  |
| Less: unamortized debt issuance costs |  | (0.1 | ) |  | (0.2 | ) |
|  |  | $ | 173.9 |  |  | $ | 206.4 |  |
| Less: current maturities |  | (80.8 | ) |  | (112.0 | ) |
| Long-term debt |  | $ | 93.1 |  |  | $ | 94.4 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-05):
[0000038725-20-000107:note_history:18]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2020 matures as follows:
  (was, 2019-11-05, similarity 0.9474):
[0000038725-19-000242:note_history:18]
Debt outstanding, excluding unamortized debt issuance costs, at September 30, 2019 matures as follows:

- changed (2020-05-05):
[0000038725-20-000107:note_history:19]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 134.4 |  |  | $ | 41.7 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.4 |  |  | $ | 87.4 |  |
  (was, 2019-11-05, similarity 0.7048):
[0000038725-19-000242:note_history:19]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 173.9 |  |  | $ | 80.7 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.4 |  |  | $ | 88.0 |  |
| Financing Leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 174.0 |  |  | $ | 80.7 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.4 |  |  | $ | 88.0 |  |
