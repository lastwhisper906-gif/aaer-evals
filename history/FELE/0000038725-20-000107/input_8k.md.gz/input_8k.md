# FELE 8-K — 0000038725-20-000104 filed 2020-04-28

## item codes, every 8-K on or before 2020-05-05

- 2020-04-28 0000038725-20-000104 — 2.02, 9.01
- 2020-02-18 0000038725-20-000018 — 2.02, 9.01
- 2020-01-30 0000038725-20-000009 — 5.02, 5.03, 9.01
- 2019-11-04 0000038725-19-000234 — 7.01, 9.01
- 2019-10-29 0000038725-19-000221 — 2.02, 9.01
- 2019-08-01 0000038725-19-000193 — 7.01, 9.01
- 2019-07-23 0000038725-19-000178 — 2.02, 9.01
- 2019-05-07 0000038725-19-000140 — 5.03, 9.01
- 2019-05-03 0000038725-19-000124 — 5.07
- 2019-05-03 0000038725-19-000122 — 7.01, 9.01
- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2020-05-05

- none on or before 2020-05-05

## item 2.02 — earnings release, exhibit 99.1

[0000038725-20-000104:8k_2_02:1]
EX-99.1
2
a202004288-kexhibit991.htm
EX-99.1

[0000038725-20-000104:8k_2_02:2]
Document

[0000038725-20-000104:8k_2_02:3]
Exhibit 99.1

[0000038725-20-000104:8k_2_02:4]
For Immediate Release

[0000038725-20-000104:8k_2_02:5]
For Further Information

[0000038725-20-000104:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-20-000104:8k_2_02:7]
260-824-2900

[0000038725-20-000104:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS FIRST

[0000038725-20-000104:8k_2_02:9]
QUARTER 2020 SALES AND EARNINGS AND PROVIDES AN UPDATE ON EFFECTS OF THE GLOBAL PANDEMIC

[0000038725-20-000104:8k_2_02:10]
Fort Wayne, IN – April 28, 2020 - Franklin Electric Co., Inc. (NASDAQ: FELE) reported first quarter 2020 GAAP fully diluted earnings per share (EPS) of $0.23, versus a GAAP fully diluted EPS in the first quarter 2019 of $0.19.  First quarter 2020 sales were $266.8 million, compared to 2019 first quarter sales of $290.7 million.  First quarter EPS before the impact of restructuring expenses was $0.24 compared to 2019 first quarter EPS before restructuring of $0.21 (see table below for a reconciliation of GAAP EPS to EPS before restructuring).

[0000038725-20-000104:8k_2_02:11]
Gregg Sengstack, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-20-000104:8k_2_02:12]
“Our first quarter results were better than our expectations. While manufacturing revenue was down double digits, improved mix, margins and reduced operating expenses produced an improvement in our operating income that was higher than our expectations.  With more normal weather, our distribution revenue was ahead of expectations and results were better than last year. Overall, operating income before restructuring expense was up 11 percent on 8 percent lower sales and our earnings per share before restructuring expenses increased 14 percent versus the first quarter 2019..

[0000038725-20-000104:8k_2_02:13]
As we look forward to the remainder of 2020, the Global Pandemic has created significant uncertainty in our outlook and caused disruptions to both our top and bottom lines.  We are pleased to report that our employees around the globe are safe and Franklin Electric products are considered critical to the world’s infrastructure.  Our Company’s balance sheet is strong, and whatever the eventual impact of this crisis, we are confident we can emerge even stronger and better prepared to serve our customers.”

[0000038725-20-000104:8k_2_02:14]
Key Performance Indicators:

[0000038725-20-000104:8k_2_02:15]
| Earnings Before and After Restructuring |  | For the First Quarter |  |  |  |  |  |  |
| (in millions) |  | 2020 | 2019 | Change |  |  |  |  |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 10.6 |  | $ | 9.1 |  | 16 | % |  |  |  |  |
| Allocated Earnings |  | $ | — |  | $ | (0.1) |  |  |  |  |  |  |
| Earnings for EPS Calculations |  | $ | 10.6 |  | $ | 9.0 |  | 18 | % |  |  |  |  |
| Restructuring (before tax): |  | $ | 0.9 |  | $ | 1.1 |  |  |  |  |  |  |
| Restructuring, net of tax: |  | $ | 0.7 |  | $ | 0.9 |  |  |  |  |  |  |
| Earnings Before Restructuring |  | $ | 11.3 |  | $ | 9.9 |  | 14 | % |  |  |  |  |
| Earnings Per Share |  | For the First Quarter |  |  |  |  |  |  |
| Before and After Restructuring |  | 2020 | 2019 | Change |  |  |  |  |
| (in millions except Earnings Per Share) |  |  |  |  |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 46.8 |  | 46.7 |  | — | % |  |  |  |  |
| Fully Diluted Earnings Per Share (“EPS”) Reported |  | $ | 0.23 |  | $ | 0.19 |  | 21 | % |  |  |  |  |
| Restructuring Per Share, net of tax |  | $ | 0.01 |  | $ | 0.02 |  |  |  |  |  |  |
| Fully Diluted EPS Before Restructuring |  | $ | 0.24 |  | $ | 0.21 |  | 14 | % |  |  |  |  |

[0000038725-20-000104:8k_2_02:16]
|  | Net Sales |  |  |  |  |  |  |  |  |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q1 2019 | $ | 98.0 |  | $ | 30.5 |  | $ | 37.7 |  | $ | 22.2 |  | $ | 188.4 |  | $ | 60.2 |  | $ | 53.3 |  | $ | (11.2) |  | $ | 290.7 |  |
| Q1 2020 | $ | 83.9 |  | $ | 28.2 |  | $ | 38.2 |  | $ | 13.8 |  | $ | 164.1 |  | $ | 55.3 |  | $ | 60.4 |  | $ | (13.0) |  | $ | 266.8 |  |
| Change | $ | (14.1) |  | $ | (2.3) |  | $ | 0.5 |  | $ | (8.4) |  | $ | (24.3) |  | $ | (4.9) |  | $ | 7.1 |  | $ | (1.8) |  | $ | (23.9) |  |
| % Change | (14) | % | (8) | % | 1 | % | (38) | % | (13) | % | (8) | % | 13 | % |  | (8) | % |
| Foreign currency translation | $ | 0.1 |  | $ | (4.8) |  | $ | (2.6) |  | $ | (0.4) |  | $ | (7.7) |  | $ | (0.4) |  | $ | — |  |  |  |
| % Change | — | % | (16) | % | (7) | % | (2) | % | (4) | % | (1) | % | — | % |  |  |
| Acquisitions | $ | 3.9 |  | $ | — |  | $ | — |  | $ | — |  | $ | 3.9 |  | $ | — |  | $ | — |  |  |  |
| Volume/Price | $ | (18.1) |  | $ | 2.5 |  | $ | 3.1 |  | $ | (8.0) |  | $ | (20.5) |  | $ | (4.5) |  | $ | 7.1 |  |  |  |
| % Change | (18) | % | 8 | % | 8 | % | (36) | % | (11) | % | (7) | % | 13 | % |  |  |

[0000038725-20-000104:8k_2_02:17]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the First Quarter 2020 |  |  |  |  |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 18.8 |  | $ | 12.1 |  | $ | (2.2) |  | $ | (14.9) |  | $ | 13.8 |  |
| % Operating Income To Net Sales | 11.5 | % | 21.9 | % | (3.6) | % |  | 5.2 | % |
| Restructuring | $ | 0.6 |  | $ | 0.2 |  | $ | 0.1 |  | $ | — |  | $ | 0.9 |  |
| Operating Income/(Loss) Before Restructuring | $ | 19.4 |  | $ | 12.3 |  | $ | (2.1) |  | $ | (14.9) |  | $ | 14.7 |  |
| % Operating Income to Net Sales Before Restructuring | 11.8 | % | 22.2 | % |  |  |  | 5.5 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the First Quarter 2019 |  |  |  |  |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 19.2 |  | $ | 12.3 |  | $ | (4.3) |  | $ | (15.1) |  | $ | 12.1 |  |
| % Operating Income To Net Sales | 10.2 | % | 20.4 | % | (8.1) | % |  | 4.2 | % |
| Restructuring | $ | 0.5 |  | $ | — |  | $ | 0.6 |  | $ | — |  | $ | 1.1 |  |
| Operating Income/(Loss) Before Restructuring | $ | 19.7 |  | $ | 12.3 |  | $ | (3.7) |  | $ | (15.1) |  | $ | 13.2 |  |
| % Operating Income to Net Sales Before Restructuring | 10.5 | % | 20.4 | % |  |  |  | 4.5 | % |

[0000038725-20-000104:8k_2_02:18]
Water Systems

[0000038725-20-000104:8k_2_02:19]
Water Systems sales in the U.S. and Canada decreased by 14 percent overall compared to the first quarter 2019, primarily due to lower sales of dewatering equipment.  Sales of dewatering equipment decreased by nearly 54 percent due to lower sales in rental channels and substantial uncertainty in oil production end markets. Sales of groundwater pumping equipment increased by 2 percent versus the first quarter 2019.  Sales of surface pumping equipment decreased by 14 percent on lower sales of both wastewater and water transfer systems as customers in this channel began to feel the impact of the Global Pandemic and lowered their own inventory levels.

[0000038725-20-000104:8k_2_02:20]
Water Systems sales in markets outside the U.S. and Canada decreased by 11 percent overall.  Foreign currency translation decreased sales by 9 percent.  Outside the U.S. and Canada, Water Systems organic sales decreased by 2 percent, primarily driven by the Asia Pacific markets as customers in Korea, Japan and China were impacted by the Global Pandemic.

[0000038725-20-000104:8k_2_02:21]
Water Systems operating income was $18.8 million in the first quarter 2020, compared to $19.2 million in the first quarter 2019 primarily driven by lower revenues.

[0000038725-20-000104:8k_2_02:22]
Fueling Systems

[0000038725-20-000104:8k_2_02:23]
Fueling Systems sales in the U.S. and Canada increased by 7 percent compared to the first quarter 2019.  The increase was principally in piping, pumping and fuel management systems product lines.  Outside the U.S. and Canada, Fueling Systems revenues declined by 30 percent, driven by lower sales in Asia Pacific, primarily China.

[0000038725-20-000104:8k_2_02:24]
Fueling Systems operating income was $12.1 million in the first quarter of 2020, compared to $12.3 million in the first quarter of 2019.

[0000038725-20-000104:8k_2_02:25]
Distribution

[0000038725-20-000104:8k_2_02:26]
Distribution sales were $60.4 million in the first quarter 2020, versus first quarter 2019 sales of $53.3 million.  The Distribution segment organic sales increased 13 percent compared to the first quarter of 2019.   More favorable weather conditions versus the first quarter last year contributed to the revenue growth.

[0000038725-20-000104:8k_2_02:27]
The Distribution segment recorded an operating loss of $2.2 million in the first quarter of 2020, compared to a loss of $4.3 million in the first quarter of 2019.

[0000038725-20-000104:8k_2_02:28]
Overall

[0000038725-20-000104:8k_2_02:29]
The Company’s consolidated gross profit was $90.3 million for the first quarter of 2020, an increase from the first quarter of 2019 gross profit of $89.5 million.  The gross profit as a percentage of net sales was 33.9 percent in the first quarter of 2020 versus 30.8 percent in the first quarter of 2019 and improved primarily due to better price realization and product sales mix.

[0000038725-20-000104:8k_2_02:30]
Selling, general, and administrative (SG&A) expenses were $75.6 million in the first quarter of 2020 compared to $76.3 million in the first quarter of 2019. SG&A expenses were lower in part because of foreign currency translation versus the prior year and companywide efforts to lower spending in response to the impacts of the Global Pandemic.

[0000038725-20-000104:8k_2_02:31]
Liquidity

[0000038725-20-000104:8k_2_02:32]
The Company ended the first quarter of 2020 with a cash balance of $40 million and had total incremental borrowing capacity of $478 million as follows:

[0000038725-20-000104:8k_2_02:33]
| (In Million USD) |  | At 3/31/20 |
| Current Leverage Ratio Per Bank Agreements (a) |  | 0.63 |  |
| Trailing Twelve Month Free Cash Flow (b) |  | $ | 154.5 |  |
| Trailing Twelve Month Free Cash Flow Conversion (b) |  | 158 | % |
| Additional Borrowing Capacity Available (a) |  | $ | 478.4 |  |
| Cash On Hand |  | $ | 40.0 |  |
| Total Liquidity Available |  | 518.4 |  |
| (a) Per Bank Borrowing Agreements currently in place. |  |  |
| (b) Free Cash Flow is Net Cash Flows from Operating Activities, less net additions to property, plant and equipment. Free Cash Flow Conversion is Free Cash Flow divided by Net Income. |  |  |

[0000038725-20-000104:8k_2_02:34]
The Company believes it has enough liquidity to meet its operating and cash flow requirements for the foreseeable future.

[0000038725-20-000104:8k_2_02:35]
Effects of the Global Pandemic

[0000038725-20-000104:8k_2_02:36]
The top priority of the Company is the health and welfare of its employees and partners around the world.  In response to the health risks posed by the Global Pandemic, the Company implemented and has been following the recommended hygiene and social distancing practices promulgated by the United States Centers for Disease Control and the World Health Organization.

[0000038725-20-000104:8k_2_02:37]
The Company’s products and services are generally viewed as essential in most jurisdictions in which the Company operates.  Accordingly, the Company’s global manufacturing and distribution operations generally remain open subject to temporary government mandated closures which have occurred in China, Italy, South Africa, India and several countries in South America. These temporary closures have not had a material impact on the ability to supply products to the Company’s customers.

[0000038725-20-000104:8k_2_02:38]
The Company has assessed the end markets it serves to determine changes in demand patterns and customer behaviors.  From this assessment, the Company currently believes that the most significant risks to the previously provided financial outlook for 2020 are a reduction of large dewatering equipment sales in the Water Systems segment; Water Systems customers “de-stocking” their inventory, particularly in the U.S. and Canada plumbing channel; and, the deferral or cancellation of the construction of new filling stations in the Fueling Systems segment in the U.S and Canada.  Additionally, the strengthening of the U.S. dollar versus most international currencies will result in lower translations of both Net Sales and earnings from many of the Company’s businesses outside the U.S.  Beyond these specific end market considerations, the Company may experience other negative impacts to profitability from various government mandated closures and related customer behavior.

[0000038725-20-000104:8k_2_02:39]
Additional adverse financial impacts from these risks include lost operational efficiencies, de-leveraging of the manufacturing fixed costs base due to lower manufactured volumes, and the potential for higher bad debt expense.

[0000038725-20-000104:8k_2_02:40]
The Company has taken action to offset the negative impacts of these risks by implementing various reductions in all discretionary spending.

[0000038725-20-000104:8k_2_02:41]
Commenting on the outlook for 2020 and the effects of the Global Pandemic, Mr. Sengstack said:

[0000038725-20-000104:8k_2_02:42]
“After considering the impacts of the Global Pandemic that we have outlined here, we are  withdrawing our 2020 financial guidance. We will revisit the subject of guidance after

[0000038725-20-000104:8k_2_02:43]
the second quarter.

[0000038725-20-000104:8k_2_02:44]
Despite the unprecedented and rapidly evolving environment we’re in, I remain confident

[0000038725-20-000104:8k_2_02:45]
in our Company’s ability to serve our customers and meet whatever marketplace

[0000038725-20-000104:8k_2_02:46]
demands we face.  Our people are our greatest strength and are proving once again

[0000038725-20-000104:8k_2_02:47]
why Franklin Electric is such a great company.”

[0000038725-20-000104:8k_2_02:48]
A conference call to review earnings and other developments in the business will commence at 9:00 am ET.  The first quarter 2020 earnings call will be available via a live webcast.  The webcast will be available in a listen only mode by going to:

[0000038725-20-000104:8k_2_02:49]
https://edge.media-server.com/mmc/p/thsfw4zo

[0000038725-20-000104:8k_2_02:50]
If you intend to ask questions during the call, please dial in using 877.643.7158 for domestic calls and 914.495.8565 for international calls.  The conference ID is: 5472646.

[0000038725-20-000104:8k_2_02:51]
A replay of the conference call will be available Tuesday, April 28, 2020 at 12:00 noon ET through noon ET on Tuesday, May 5, 2020, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls.  The replay passcode is: 5472646.

[0000038725-20-000104:8k_2_02:52]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-20-000104:8k_2_02:53]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |  |  |  |  |  |  |  |  |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |  |  |  |  |  |  |  |  |
| (Unaudited) |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |  |
|  | First Quarter Ended |  |  |  |  |  |  |  |
|  | March 31, 2020 |  | March 31, 2019 |  |  |  |  |  |
| Net sales | $ | 266,754 |  |  | $ | 290,715 |  |  |  |  |  |  |
| Cost of sales | 176,437 |  |  | 201,209 |  |  |  |  |  |  |
| Gross profit | 90,317 |  |  | 89,506 |  |  |  |  |  |  |
| Selling, general, and administrative expenses | 75,623 |  |  | 76,299 |  |  |  |  |  |  |
| Restructuring expense | 873 |  |  | 1,086 |  |  |  |  |  |  |
| Operating income | 13,821 |  |  | 12,121 |  |  |  |  |  |  |
| Interest expense | (1,234) |  |  | (2,342) |  |  |  |  |  |  |
| Other income/(expense), net | (202) |  |  | 239 |  |  |  |  |  |  |
| Foreign exchange income/(expense) | 962 |  |  | 589 |  |  |  |  |  |  |
| Income before income taxes | 13,347 |  |  | 10,607 |  |  |  |  |  |  |
| Income tax expense | 2,555 |  |  | 1,480 |  |  |  |  |  |  |
| Net income | $ | 10,792 |  |  | $ | 9,127 |  |  |  |  |  |  |
| Less: Net (income)/loss attributable to noncontrolling interests | (149) |  |  | (71) |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 10,643 |  |  | $ | 9,056 |  |  |  |  |  |  |
| Income per share: |  |  |  |  |  |  |  |  |
| Basic | $ | 0.23 |  |  | $ | 0.19 |  |  |  |  |  |  |
| Diluted | $ | 0.23 |  |  | $ | 0.19 |  |  |  |  |  |  |

[0000038725-20-000104:8k_2_02:54]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |  |  |
| (Unaudited) |  |  |  |
| (In thousands) |  |  |  |
|  | March 31, 2020 |  | December 31, 2019 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 39,987 |  |  | $ | 64,405 |  |
| Receivables, net | 167,590 |  |  | 173,327 |  |
| Inventories | 310,006 |  |  | 300,246 |  |
| Other current assets | 25,472 |  |  | 29,466 |  |
| Total current assets | 543,055 |  |  | 567,444 |  |
| Property, plant, and equipment, net | 188,646 |  |  | 201,328 |  |
| Right-of-use asset, net | 26,583 |  |  | 27,621 |  |
| Goodwill and other assets | 391,249 |  |  | 398,350 |  |
| Total assets | $ | 1,149,533 |  |  | $ | 1,194,743 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 88,388 |  |  | $ | 82,593 |  |
| Accrued expenses and other current liabilities | 51,828 |  |  | 71,454 |  |
| Current lease liability | 9,451 |  |  | 9,838 |  |
| Current maturities of long-term debt and short-term borrowings | 41,720 |  |  | 21,879 |  |
| Total current liabilities | 191,387 |  |  | 185,764 |  |
| Long-term debt | 92,563 |  |  | 93,141 |  |
| Long-term lease liability | 17,134 |  |  | 17,785 |  |
| Income taxes payable non-current | 11,964 |  |  | 11,965 |  |
| Deferred income taxes | 27,117 |  |  | 27,598 |  |
| Employee benefit plans | 37,057 |  |  | 38,288 |  |
| Other long-term liabilities | 19,090 |  |  | 21,769 |  |
| Redeemable noncontrolling interest | (245) |  |  | (236) |  |
| Total equity | 753,466 |  |  | 798,669 |  |
| Total liabilities and equity | $ | 1,149,533 |  |  | $ | 1,194,743 |  |

[0000038725-20-000104:8k_2_02:55]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |  |  |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  |  |  |
| (Unaudited) |  |  |  |
|  | Three Months Ended |  |  |
| (In thousands) |  |  |  |
|  | March 31, 2020 |  | March 31, 2019 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 10,792 |  |  | $ | 9,127 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 9,199 |  |  | 9,268 |  |
| Non-Cash Lease Expense | 1,962 |  |  | 2,805 |  |
| Share-based compensation | 4,352 |  |  | 3,230 |  |
| Other | (938) |  |  | (96) |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (2,574) |  |  | (6,517) |  |
| Inventory | (19,952) |  |  | (20,986) |  |
| Accounts payable and accrued expenses | (4,223) |  |  | 1,309 |  |
| Operating Leases | (1,962) |  |  | (2,804) |  |
| Other | (1,312) |  |  | 1,729 |  |
| Net cash flows from operating activities | (4,656) |  |  | (2,935) |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (5,535) |  |  | (5,220) |  |
| Proceeds from sale of property, plant, and equipment | 25 |  |  | 64 |  |
| Acquisitions and investments | (5,626) |  |  | (5,405) |  |
| Other investing activities | — |  |  | 3 |  |
| Net cash flows from investing activities | (11,136) |  |  | (10,558) |  |
| Cash flows from financing activities: |  |  |  |
| Change in debt | 19,670 |  |  | 19,669 |  |
| Proceeds from issuance of common stock | 871 |  |  | 1,251 |  |
| Purchases of common stock | (16,981) |  |  | (4,329) |  |
| Dividends paid | (7,240) |  |  | (6,723) |  |
| Net cash flows from financing activities | (3,680) |  |  | 9,868 |  |
| Effect of exchange rate changes on cash | (4,946) |  |  | (1,184) |  |
| Net change in cash and equivalents | (24,418) |  |  | (4,809) |  |
| Cash and equivalents at beginning of period | 64,405 |  |  | 59,173 |  |
| Cash and equivalents at end of period | $ | 39,987 |  |  | $ | 54,364 |  |
