# FELE notes — 0000038725-20-000107


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-20-000107:notes:1]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2019, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2020, and for the first quarters ended March 31, 2020 and March 31, 2019 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made.  Operating results for the first quarter ended March 31, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2020.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2019.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000038725-20-000107:notes:2]
ACCOUNTING PRONOUNCEMENTS
Adoption of New Accounting Standards

[0000038725-20-000107:notes:3]
In January 2017, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.  ASU 2017-04 removes step two from the goodwill impairment test and instead requires an entity to recognize a goodwill impairment charge for the amount by which the goodwill carrying amount exceeds the reporting unit's fair value.  The ASU is effective on a prospective basis for interim and annual periods beginning after December 15, 2019 with early adoption permitted.   The Company adopted the standard effective January 1, 2020. The standard did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-20-000107:notes:4]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which modifies the measurement of expected credit losses on certain financial instruments, including trade receivables.  ASU 2016-13 is effective for interim and annual periods beginning after December 15, 2019 with early adoption permitted.  Amendments should be applied using a modified retrospective approach except for debt securities, which require a prospective transitions approach.  The Company adopted the standard effective January 1, 2020. The standard did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-20-000107:notes:5]
Accounting Standards Issued But Not Yet Adopted

[0000038725-20-000107:notes:6]
In August 2018, the FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Topic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which modifies the disclosure requirements for employers that sponsor defined benefit pension or other postretirement plans. The amendments remove disclosures that no longer are considered cost beneficial, including the estimated amounts in accumulated other comprehensive income expected to be recognized as components of net periodic expense over the next fiscal year. The amendments clarify the specific requirements of disclosures, and add disclosure requirements identified as relevant, including the reasons for significant gains and losses related to change in the benefit obligation for the period.  The ASU should be applied retrospectively and is effective for interim and annual periods beginning after December 15, 2020. The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-20-000107:notes:7]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is expected to reduce cost and complexity related to accounting for income taxes. ASU 2019-12 eliminates the need for the Company to analyze whether certain exceptions apply and improves financial statement preparers' application of income tax-related guidance. ASU 2019-12 is effective for interim and annual periods beginning after December 15, 2020 with early adoption permitted. Amendments related to franchise taxes that are partially based on income should be applied on either a retrospective or modified retrospective basis. All other amendments should be applied on a prospective basis. The Company is still determining the date of adoption of this ASU. Adoption is not expected to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-20-000107:notes:8]
ACQUISITIONSDuring the first quarter ended March 31, 2020, the Company acquired all of the assets of a company that manufactures line shaft turbines and other adjacent product lines for a purchase price of $6.3 million after working capital adjustments.  The fair value of the assets acquired and liabilities assumed are preliminary as of March 31, 2020.  In addition, the Company has not 
presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2020, as the results of operations for this acquisition is immaterial.

[0000038725-20-000107:notes:9]
During the third quarter ended September 30, 2019, the Company acquired 100 percent of the ownership interests of First Sales, LLC for a purchase price of approximately $15.5 million after working capital adjustments.  The acquisition was not material, and the fair value of the assets acquired and liabilities assumed are preliminary as of March 31, 2020.

[0000038725-20-000107:notes:10]
[same as prior period, unchanged from 0000038725-19-000242:notes:20]

[0000038725-20-000107:notes:11]
During the first quarter ended March 31, 2019, the Company acquired 100 percent of the ownership interests of Mt. Pleasant, Michigan-based Milan Supply Company ("Milan Supply").   The fair value of the assets acquired and the liabilities assumed for the acquisition are considered final as of March 31, 2020, and the final purchase price was $6.1 million after working capital adjustments.  The Company has not presented fair values of the assets acquired and the liabilities assumed as the values are not material.

[0000038725-20-000107:notes:12]
Transaction costs were expensed as incurred under the guidance of FASB Accounting Standards Codification Topic 805, Business Combinations.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-20-000107:notes:13]
[same as prior period, unchanged from 0000038725-19-000242:notes:24]

[0000038725-20-000107:notes:14]
[same as prior period, unchanged from 0000038725-19-000242:notes:25]

[0000038725-20-000107:notes:15]
[same as prior period, unchanged from 0000038725-19-000242:notes:26]

[0000038725-20-000107:notes:16]
[same as prior period, unchanged from 0000038725-19-000242:notes:27]

[0000038725-20-000107:notes:17]
As of March 31, 2020 and December 31, 2019, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-20-000107:notes:18]
| (In millions) | March 31, 2020 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 2.6 |  | $ | 2.6 |  | $ | — |  | $ | — |  |
|  | December 31, 2019 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 4.0 |  | $ | 4.0 |  | $ | — |  | $ | — |  |

[0000038725-20-000107:notes:19]
[same as prior period, unchanged from 0000038725-19-000242:notes:30]

[0000038725-20-000107:notes:20]
[same as prior period, unchanged from 0000038725-19-000242:notes:31]

[0000038725-20-000107:notes:21]
Total debt, including current maturities, have carrying amounts of $134.3 million and $115.0 million and estimated fair values of $138.4 million and $121.0 million as of March 31, 2020 and December 31, 2019, respectively.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily 
indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-20-000107:notes:22]
FINANCIAL INSTRUMENTSThe Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  The Company has entered into share swap transaction agreements (the "swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price.  The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party.  As of March 31, 2020, the swap had a notional value based on 260,000 shares. For the first quarters ended March 31, 2020 and March 31, 2019, the swap resulted in a  loss  of $2.7 million and a gain $1.9 million, respectively. Gains and losses resulting from the the swap were primarily offset by gains and losses on the fair value of the deferred compensation stock liability. All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-20-000107:notes:23]
[same as prior period, unchanged from 0000038725-19-000242:notes:34]

[0000038725-20-000107:notes:24]
| (In millions) |  | March 31, 2020 |  |  |  | December 31, 2019 |  |  |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortizing intangibles: |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.4 |  |  | $ | (7.0) |  |  | $ | 7.4 |  |  | $ | (7.0) |  |
| Technology |  | 7.5 |  |  | (6.9) |  |  | 7.5 |  |  | (6.8) |  |
| Customer relationships |  | 151.3 |  |  | (71.8) |  |  | 155.4 |  |  | (71.4) |  |
| Other |  | 3.7 |  |  | (2.7) |  |  | 3.8 |  |  | (2.8) |  |
| Total |  | $ | 169.9 |  |  | $ | (88.4) |  |  | $ | 174.1 |  |  | $ | (88.0) |  |
| Unamortizing intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 43.0 |  |  | — |  |  | 45.0 |  |  | — |  |
| Total intangibles |  | $ | 212.9 |  |  | $ | (88.4) |  |  | $ | 219.1 |  |  | $ | (88.0) |  |

[0000038725-20-000107:notes:25]
Amortization expense related to intangible assets for the first quarters ended March 31, 2020 and March 31, 2019 was $2.4 million and $2.3 million, respectively.

[0000038725-20-000107:notes:26]
[same as prior period, unchanged from 0000038725-19-000242:notes:37]

[0000038725-20-000107:notes:27]
| (In millions) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | 2024 |
|  |  | $ | 9.2 |  |  | $ | 8.8 |  |  | $ | 8.6 |  |  | $ | 8.5 |  |  | $ | 8.3 |  |

[0000038725-20-000107:notes:28]
The change in the carrying amount of goodwill by reportable segment for the three months ended March 31, 2020, is as follows:

[0000038725-20-000107:notes:29]
| (In millions) |  |  |  |  |  |  |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2019 |  | $ | 151.0 |  |  | $ | 67.6 |  |  | $ | 37.5 |  |  | $ | 256.1 |  |
| Acquisitions |  | 2.7 |  |  | — |  |  | — |  |  | 2.7 |  |
| Foreign currency translation |  | (2.8) |  |  | (0.2) |  |  | — |  |  | (3.0) |  |
| Balance as of March 31, 2020 |  | $ | 150.9 |  |  | $ | 67.4 |  |  | $ | 37.5 |  |  | $ | 255.8 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-20-000107:notes:30]
EMPLOYEE BENEFIT PLANSDefined Benefit Plans - As of March 31, 2020, the Company maintained two domestic pension plans and three German pension plans.  The Company used a December 31, 2019 measurement date for these plans.  One of the Company's domestic pension plans covers one active management employee, while the other domestic plan covers all eligible employees (plan was frozen as of December 31, 2011).  The two domestic and three German plans collectively comprise the 'Pension Benefits' disclosure caption. 
Other Benefits - The Company's other post-retirement benefit plan provides health and life insurance to domestic employees hired prior to 1992.

[0000038725-20-000107:notes:31]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the first quarters ended March 31, 2020 and March 31, 2019:

[0000038725-20-000107:notes:32]
| (In millions) | Pension Benefits |  |  |  | Other Benefits |  |  |
|  | First Quarter Ended |  |  |  | First Quarter Ended |  |  |
|  | March 31, 2020 |  | March 31, 2019 |  | March 31, 2020 |  | March 31, 2019 |
| Service cost | $ | 0.1 |  |  | $ | 0.2 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 1.1 |  |  | 1.5 |  |  | 0.1 |  |  | 0.1 |  |
| Expected return on assets | (1.7) |  |  | (2.0) |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | 0.9 |  |  | 0.6 |  |  | — |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.4 |  |  | $ | 0.3 |  |  | $ | 0.1 |  |  | $ | 0.1 |  |

[0000038725-20-000107:notes:33]
In the first quarter ended March 31, 2020, the Company made contributions of $0.1 million to the funded plans.  The amount of contributions to be made to the plans during the calendar year 2020 will be finalized by September 15, 2020, based upon the funding level requirements identified and year-end valuation performed at December 31, 2019.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-20-000107:notes:34]
INCOME TAXES
The Company’s effective tax rate from continuing operations for the three month period ended March 31, 2020 was 19.1 percent as compared to 13.9 percent for the three month period ended March 31, 2019. The effective tax rate is lower than the U.S. statutory rate of 21 percent primarily due to foreign earnings taxed at rates below the U.S. statutory rate, the recognition of the U.S. foreign-derived intangible income (FDII) provisions, and certain discrete events including excess tax benefits from share-based compensation partially offset by state taxes.

[0000038725-20-000107:notes:35]
The increase in the effective tax rate for the three months ended March 31, 2020, compared with the same period in 2019, was primarily a result of unfavorable discrete events of  $0.4 million.


## us-gaap:DebtDisclosureTextBlock

[0000038725-20-000107:notes:36]
DEBT
Debt consisted of the following:

[0000038725-20-000107:notes:37]
| (In millions) |  | March 31, 2020 |  | December 31, 2019 |
| Tax increment financing debt |  | 18.2 |  |  | 18.7 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 39.0 |  |  | 19.0 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 2.2 |  |  | 2.3 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 134.3 |  |  | $ | 115.0 |  |
| Less: current maturities |  | (41.7) |  |  | (21.9) |  |
| Long-term debt |  | $ | 92.6 |  |  | $ | 93.1 |  |

[0000038725-20-000107:notes:38]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2020 matures as follows:

[0000038725-20-000107:notes:39]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 134.4 |  |  | $ | 41.7 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.4 |  |  | $ | 87.4 |  |

[0000038725-20-000107:notes:40]
Prudential Agreement

[0000038725-20-000107:notes:41]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement"), which expires on July 30, 2021 and has an initial borrowing capacity of $250.0 million.  As of March 31, 2020, the Company has $150.0 million borrowing capacity available under the Prudential Agreement.

[0000038725-20-000107:notes:42]
Project Bonds

[0000038725-20-000107:notes:43]
The Company, Allen County, Indiana and certain institutional investors maintain a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)." The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. These Project Notes ("Tax increment financing debt") bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.

[0000038725-20-000107:notes:44]
New York Life Agreement

[0000038725-20-000107:notes:45]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"), with a maximum aggregate borrowing capacity of $200.0 million.  On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually.  The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of March 31, 2020, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-20-000107:notes:46]
Credit Agreement

[0000038725-20-000107:notes:47]
The Company maintains the Third Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement has a maturity date of October 28, 2021 and commitment amount of $300.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million).  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-20-000107:notes:48]
As of March 31, 2020, the Company had $39.0 million in outstanding borrowings which were primarily used for working capital needs, the payment of existing indebtedness and acquisitions, $4.2 million in letters of credit outstanding, and $256.8 million of available capacity under the Credit Agreement.

[0000038725-20-000107:notes:49]
Covenants

[0000038725-20-000107:notes:50]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 1.00 to 3.50 and a minimum interest coverage ratio of 1.00 to 3.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of March 31, 2020.


## us-gaap:EarningsPerShareTextBlock

[0000038725-20-000107:notes:51]
[same as prior period, unchanged from 0000038725-19-000242:notes:65]

[0000038725-20-000107:notes:52]
[same as prior period, unchanged from 0000038725-19-000242:notes:66]

[0000038725-20-000107:notes:53]
[same as prior period, unchanged from 0000038725-19-000242:notes:67]

[0000038725-20-000107:notes:54]
|  | First Quarter Ended |  |  |  |  |  |  |
| (In millions, except per share amounts) | March 31, 2020 |  | March 31, 2019 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 10.6 |  |  | $ | 9.1 |  |  |  |  |  |
| Less: Earnings allocated to participating securities | — |  |  | 0.1 |  |  |  |  |  |
| Net income available to common shareholders | $ | 10.6 |  |  | $ | 9.0 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 46.4 |  |  | 46.3 |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Non-participating employee stock options and performance awards | 0.4 |  |  | 0.4 |  |  |  |  |  |
| Diluted weighted average common shares outstanding | 46.8 |  |  | 46.7 |  |  |  |  |  |
| Basic earnings per share | $ | 0.23 |  |  | $ | 0.19 |  |  |  |  |  |
| Diluted earnings per share | $ | 0.23 |  |  | $ | 0.19 |  |  |  |  |  |

[0000038725-20-000107:notes:55]
There were 0.3 million and 0.1 million stock options outstanding for the first quarters ended March 31, 2020 and March 31, 2019, respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-20-000107:notes:56]
EQUITY ROLL FORWARD
The schedules below set forth equity changes in the first quarters ended March 31, 2020 and March 31, 2019:

[0000038725-20-000107:notes:57]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2019 | $ | 4,639 |  |  | $ | 269,656 |  |  | $ | 712,460 |  |  | $ | (50,089) |  |  | $ | (140,121) |  |  | $ | 2,124 |  |  | $ | 798,669 |  |  | $ | (236) |  |
| Net income |  |  |  |  |  |  | 10,643 |  |  |  |  |  |  |  |  | 187 |  |  | 10,830 |  |  | (38) |  |
| Dividends on common stock ($0.155/share) |  |  |  |  |  |  | (7,240) |  |  |  |  |  |  |  |  |  |  |  | (7,240) |  |  |  |  |
| Common stock issued | 2 |  |  | 869 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 871 |  |  |  |  |
| Common stock repurchased | (35) |  |  |  |  |  | (16,946) |  |  |  |  |  |  |  |  |  |  |  | (16,981) |  |  |  |  |
| Share-based compensation | 8 |  |  | 4,344 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 4,352 |  |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  |  |  |  |  | (37,727) |  |  | (24) |  |  | (37,751) |  |  | 29 |  |
| Pension liability, net of tax |  |  |  |  |  |  |  |  |  | 716 |  |  |  |  |  |  |  |  | 716 |  |  |  |  |
| Balance as of March 31, 2020 | $ | 4,614 |  |  | $ | 274,869 |  |  | $ | 698,917 |  |  | $ | (49,373) |  |  | $ | (177,848) |  |  | $ | 2,287 |  |  | $ | 753,466 |  |  | $ | (245) |  |

[0000038725-20-000107:notes:58]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2018 | $ | 4,632 |  |  | $ | 257,535 |  |  | $ | 654,724 |  |  | $ | (48,585) |  |  | $ | (134,434) |  |  | $ | 1,955 |  |  | $ | 735,827 |  |  | $ | 518 |  |
| Net income |  |  |  |  |  |  | 9,056 |  |  |  |  |  |  |  |  | 174 |  |  | 9,230 |  |  | (103) |  |
| Dividends on common stock ($0.145/share) |  |  |  |  |  |  | (6,723) |  |  |  |  |  |  |  |  |  |  |  | (6,723) |  |  |  |  |
| Common stock issued | 6 |  |  | 1,245 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,251 |  |  |  |  |
| Common stock repurchased | (9) |  |  |  |  |  | (4,320) |  |  |  |  |  |  |  |  |  |  |  | (4,329) |  |  |  |  |
| Share-based compensation | 8 |  |  | 3,222 |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 3,230 |  |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  |  |  |  |  | (2,771) |  |  | (32) |  |  | (2,803) |  |  | (7) |  |
| Pension liability, net of tax |  |  |  |  |  |  |  |  |  | 509 |  |  |  |  |  |  |  |  | 509 |  |  |  |  |
| Balance as of March 31, 2019 | $ | 4,637 |  |  | $ | 262,002 |  |  | $ | 652,737 |  |  | $ | (48,076) |  |  | $ | (137,205) |  |  | $ | 2,097 |  |  | $ | 736,192 |  |  | $ | 408 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-20-000107:notes:59]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)
Changes in accumulated other comprehensive income/(loss) by component for the three months ended March 31, 2020 and March 31, 2019, are summarized below:

[0000038725-20-000107:notes:60]
| (In millions) |  |  |  |  |  |
| For the three months ended March 31, 2020: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| Balance as of December 31, 2019 | $ | (140.2) |  |  | $ | (50.0) |  |  | $ | (190.2) |  |
| Other comprehensive income/(loss) before reclassifications | (37.7) |  |  | — |  |  | (37.7) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.7 |  |  | 0.7 |  |
| Net other comprehensive income/(loss) | (37.7) |  | — |  | 0.7 |  | — |  | (37.0) |  |
| Balance as of March 31, 2020 | $ | (177.9) |  |  | $ | (49.3) |  |  | $ | (227.2) |  |
| For the three months ended March 31, 2019: |  |  |  |  |  |
| Balance as of December 31, 2018 | $ | (134.5) |  |  | $ | (48.5) |  |  | $ | (183.0) |  |
| Other comprehensive income/(loss) before reclassifications | (2.8) |  |  | — |  |  | (2.8) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.5 |  |  | 0.5 |  |
| Net other comprehensive income/(loss) | (2.8) |  | — |  | 0.5 |  | — |  | (2.3) |  |
| Balance as of March 31, 2019 | $ | (137.3) |  | — |  | $ | (48.0) |  |  | $ | (185.3) |  |

[0000038725-20-000107:notes:61]
[same as prior period, unchanged from 0000038725-19-000242:notes:78]

[0000038725-20-000107:notes:62]
(2) Net of tax expense of $0.2 million and $0.1 million for the three months ended March 31, 2020 and March 31, 2019, respectively.

[0000038725-20-000107:notes:63]
[same as prior period, unchanged from 0000038725-19-000242:notes:80]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-20-000107:notes:64]
[same as prior period, unchanged from 0000038725-19-000242:notes:81]

[0000038725-20-000107:notes:65]
Segment operating income is a key financial performance measure. Operating income by segment is based on net sales less identifiable operating expenses and allocations and includes profits recorded on sales to other segments of the Company.

[0000038725-20-000107:notes:66]
[same as prior period, unchanged from 0000038725-19-000242:notes:84]

[0000038725-20-000107:notes:67]
|  | First Quarter Ended |  |  |  |  |  |  |
| (In millions) | March 31, 2020 |  | March 31, 2019 |  |  |  |  |
|  | Net sales |  |  |  |  |  |  |
| Water Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | $ | 70.9 |  |  | $ | 86.8 |  |  |  |  |  |
| Latin America | 28.2 |  |  | 30.5 |  |  |  |  |  |
| Europe, Middle East & Africa | 38.2 |  |  | 37.7 |  |  |  |  |  |
| Asia Pacific | 13.8 |  |  | 22.2 |  |  |  |  |  |
| Intersegment sales |  |  |  |  |  |  |  |
| United States & Canada | 13.0 |  |  | 11.2 |  |  |  |  |  |
| Total sales | 164.1 |  |  | 188.4 |  |  |  |  |  |
| Distribution |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |  |  |
| United States & Canada | 60.4 |  |  | 53.3 |  |  |  |  |  |
| Intersegment sales | — |  |  | — |  |  |  |  |  |
| Total sales | 60.4 |  |  | 53.3 |  |  |  |  |  |
| Fueling Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 37.4 |  |  | 35.1 |  |  |  |  |  |
| All other | 17.9 |  |  | 25.1 |  |  |  |  |  |
| Intersegment sales | — |  |  | — |  |  |  |  |  |
| Total sales | 55.3 |  |  | 60.2 |  |  |  |  |  |
| Intersegment Eliminations/Other | (13.0) |  |  | (11.2) |  |  |  |  |  |
| Consolidated | $ | 266.8 |  |  | $ | 290.7 |  |  |  |  |  |
|  | First Quarter Ended |  |  |  |  |  |  |
|  | March 31, 2020 |  | March 31, 2019 |  |  |  |  |
|  | Operating income/(loss) |  |  |  |  |  |  |
| Water Systems | $ | 18.8 |  |  | $ | 19.2 |  |  |  |  |  |
| Distribution | (2.2) |  |  | (4.3) |  |  |  |  |  |
| Fueling Systems | 12.1 |  |  | 12.3 |  |  |  |  |  |
| Intersegment Eliminations/Other | (14.9) |  |  | (15.1) |  |  |  |  |  |
| Consolidated | $ | 13.8 |  |  | $ | 12.1 |  |  |  |  |  |

[0000038725-20-000107:notes:68]
|  | March 31, 2020 |  | December 31, 2019 |  |  |  |  |
|  | Total assets |  |  |  |  |  |  |
| Water Systems | $ | 635.2 |  |  | $ | 658.3 |  |  |  |  |  |
| Distribution | 192.5 |  |  | 180.2 |  |  |  |  |  |
| Fueling Systems | 272.3 |  |  | 283.8 |  |  |  |  |  |
| Other | 49.5 |  |  | 72.4 |  |  |  |  |  |
| Consolidated | $ | 1,149.5 |  |  | $ | 1,194.7 |  |  |  |  |  |

[0000038725-20-000107:notes:69]
[same as prior period, unchanged from 0000038725-19-000242:notes:87]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-20-000107:notes:70]
COMMITMENTS AND CONTINGENCIES
The Company is defending various claims and legal actions which have arisen in the ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-20-000107:notes:71]
At March 31, 2020, the Company had $5.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-20-000107:notes:72]
The Company provides warranties on most of its products.  The warranty terms vary but are generally two years to five years from date of manufacture or one year to five years from date of installation.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-20-000107:notes:73]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the first quarter ended March 31, 2020, are as follows:

[0000038725-20-000107:notes:74]
| (In millions) |  |  |
| Balance as of December 31, 2019 |  | $ | 9.1 |  |
| Accruals related to product warranties |  | 2.1 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (2.5) |  |
| Balance as of March 31, 2020 |  | $ | 8.7 |  |

[0000038725-20-000107:notes:75]
The Company maintains certain warehouses, distribution centers, office space, and equipment operating leases. The Company also has lease agreements that are classified as financing. These financing leases are immaterial to the Company.

[0000038725-20-000107:notes:76]
The Company utilizes interest rates from lease agreements unless the lease agreement does not provide a readily determinable rate. In these instances, the Company utilizes its incremental borrowing rate based on the information available as of the adoption of ASU 2016-02 or at the inception of any new leases entered into thereafter when determining the present value of future lease payments.

[0000038725-20-000107:notes:77]
Some of the Company’s leases include renewal options. The Company excludes these renewal options in the expected lease term unless the Company is reasonably certain that the option will be exercised.

[0000038725-20-000107:notes:78]
The components of the Company’s operating lease portfolio as of the first quarter ended March 31, 2020 are as follows:

[0000038725-20-000107:notes:79]
| Lease Cost (in millions): |  |  |  |
| Operating lease cost |  |  | $ | 2.0 |  |
| Short-term lease cost |  |  | 0.1 |  |
| Other Information: |  |  |  |
| Weighted-average remaining lease term |  |  | 4 years |
| Weighted-average discount rate |  |  | 3.8 | % |

[0000038725-20-000107:notes:80]
The minimum rental payments for non-cancellable operating leases as of March 31, 2020, are as follows:

[0000038725-20-000107:notes:81]
| (In millions) | 2020 | 2021 | 2022 | 2023 | 2024 | Thereafter |
| Future Minimum Rental Payments | $ | 8.1 |  | $ | 8.6 |  | $ | 5.1 |  | $ | 3.3 |  | $ | 1.5 |  | $ | 2.5 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-20-000107:notes:82]
[same as prior period, unchanged from 0000038725-19-000242:notes:102]

[0000038725-20-000107:notes:83]
[same as prior period, unchanged from 0000038725-19-000242:notes:103]

[0000038725-20-000107:notes:84]
[same as prior period, unchanged from 0000038725-19-000242:notes:104]

[0000038725-20-000107:notes:85]
[same as prior period, unchanged from 0000038725-19-000242:notes:105]

[0000038725-20-000107:notes:86]
[same as prior period, unchanged from 0000038725-19-000242:notes:106]

[0000038725-20-000107:notes:87]
[same as prior period, unchanged from 0000038725-19-000242:notes:107]

[0000038725-20-000107:notes:88]
All options in the 2009 Stock Plan have been awarded and no additional awards are granted out of the plan. However, there are still unvested awards and unexercised options under this plan.

[0000038725-20-000107:notes:89]
[same as prior period, unchanged from 0000038725-19-000242:notes:109]

[0000038725-20-000107:notes:90]
[same as prior period, unchanged from 0000038725-19-000242:notes:110]

[0000038725-20-000107:notes:91]
[same as prior period, unchanged from 0000038725-19-000242:notes:111]

[0000038725-20-000107:notes:92]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the first quarters ended March 31, 2020 and March 31, 2019 are as follows:

[0000038725-20-000107:notes:93]
|  |  | March 31, 2020 |  | March 31, 2019 |
| Risk-free interest rate |  | 1.39 | % |  | 2.53 | % |
| Dividend yield |  | 1.04 | % |  | 1.05 | % |
| Volatility factor |  | 29.45 | % |  | 29.38 | % |
| Expected term |  | 5.5 years |  | 5.5 years |

[0000038725-20-000107:notes:94]
A summary of the Company’s outstanding stock option activity and related information for the first quarter ended March 31, 2020 is as follows:

[0000038725-20-000107:notes:95]
| (Shares in thousands) |  | March 31, 2020 |  |  |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,262 |  |  | $ | 37.99 |  |
| Granted |  | 214 |  |  | 59.71 |  |
| Exercised |  | (23) |  |  | 36.86 |  |
| Forfeited |  | — |  |  | — |  |
| Outstanding at end of period |  | 1,453 |  |  | $ | 41.21 |  |
| Expected to vest after applying forfeiture rate |  | 1,450 |  |  | $ | 41.18 |  |
| Vested and exercisable at end of period |  | 960 |  |  | $ | 35.32 |  |

[0000038725-20-000107:notes:96]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value as of March 31, 2020 is as follows:

[0000038725-20-000107:notes:97]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 6.25 years |  | $ | 12,774 |  |
| Expected to vest after applying forfeiture rate |  | 6.25 years |  | $ | 12,770 |  |
| Vested and exercisable at end of period |  | 4.87 years |  | $ | 11,814 |  |

[0000038725-20-000107:notes:98]
The total intrinsic value of options exercised during the first quarters ended March 31, 2020 and March 31, 2019 was $0.5 million and $2.0 million, respectively.

[0000038725-20-000107:notes:99]
As of March 31, 2020, there was $2.1 million of total unrecognized compensation cost related to non-vested stock options granted under the 2012 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 1.74 years.

[0000038725-20-000107:notes:100]
[same as prior period, unchanged from 0000038725-19-000242:notes:120]

[0000038725-20-000107:notes:101]
A summary of the Company’s restricted stock/stock unit award activity and related information for the first quarter ended March 31, 2020 is as follows:

[0000038725-20-000107:notes:102]
| (Shares in thousands) |  | March 31, 2020 |  |  |
| Restricted Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 463 |  |  | $ | 42.36 |  |
| Awarded |  | 114 |  |  | 59.66 |  |
| Vested |  | (85) |  |  | 29.39 |  |
| Forfeited |  | (1) |  |  | 46.71 |  |
| Non-vested at end of period |  | 491 |  |  | $ | 48.61 |  |

[0000038725-20-000107:notes:103]
As of March 31, 2020, there was $13.0 million of total unrecognized compensation cost related to non-vested restricted stock/stock unit awards granted under the stock plans.  That cost is expected to be recognized over a weighted-average period of 1.79 years.
