# FELE 8-K — 0000038725-21-000085 filed 2021-04-27

## item codes, every 8-K on or before 2021-04-30

- 2021-04-27 0000038725-21-000088 — 7.01, 9.01
- 2021-04-27 0000038725-21-000085 — 2.02, 9.01
- 2021-04-01 0000038725-21-000080 — 7.01, 9.01
- 2021-02-17 0000038725-21-000013 — 7.01, 9.01
- 2021-02-16 0000038725-21-000010 — 2.02, 9.01
- 2021-01-04 0000038725-21-000003 — 7.01, 9.01
- 2020-12-18 0000038725-20-000241 — 5.02, 9.01
- 2020-11-09 0000038725-20-000223 — 7.01, 9.01
- 2020-11-02 0000038725-20-000210 — 7.01, 9.01
- 2020-10-27 0000038725-20-000206 — 2.02, 9.01
- 2020-07-28 0000038725-20-000168 — 2.02, 9.01
- 2020-06-25 0000038725-20-000164 — 8.01, 9.01
- 2020-06-25 0000038725-20-000163 — 8.01, 9.01
- 2020-05-11 0000038725-20-000133 — 5.02, 9.01
- 2020-05-08 0000038725-20-000119 — 5.07
- 2020-05-06 0000038725-20-000111 — 5.02, 9.01
- 2020-04-28 0000038725-20-000104 — 2.02, 9.01
- 2020-02-18 0000038725-20-000018 — 2.02, 9.01
- 2020-01-30 0000038725-20-000009 — 5.02, 5.03, 9.01
- 2019-11-04 0000038725-19-000234 — 7.01, 9.01
- 2019-10-29 0000038725-19-000221 — 2.02, 9.01
- 2019-08-01 0000038725-19-000193 — 7.01, 9.01
- 2019-07-23 0000038725-19-000178 — 2.02, 9.01
- 2019-05-07 0000038725-19-000140 — 5.03, 9.01
- 2019-05-03 0000038725-19-000124 — 5.07
- 2019-05-03 0000038725-19-000122 — 7.01, 9.01
- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2021-04-30

- none on or before 2021-04-30

## item 2.02 — earnings release, exhibit 99.1

[0000038725-21-000085:8k_2_02:1]
EX-99.1
2
a20210427ex991earningsrele.htm
EX-99.1

[0000038725-21-000085:8k_2_02:2]
Document

[0000038725-21-000085:8k_2_02:3]
Exhibit 99.1

[0000038725-21-000085:8k_2_02:4]
NEWS RELEASE FOR IMMEDIATE DISTRIBUTION

[0000038725-21-000085:8k_2_02:5]
FRANKLIN ELECTRIC REPORTS RECORD FIRST QUARTER 2021 RESULTS

[0000038725-21-000085:8k_2_02:6]
First Quarter 2021 Highlights

[0000038725-21-000085:8k_2_02:7]
•Record sales of $333.0 million, compared to first quarter 2020 sales of $266.8 million, an increase of 25%

[0000038725-21-000085:8k_2_02:8]
•Strong organic sales growth for Distribution of 31% and Water Systems of 18%

[0000038725-21-000085:8k_2_02:9]
•Operating income was $33.8 million, compared to first quarter operating income in 2020 of $13.8 million, an increase of a 144%

[0000038725-21-000085:8k_2_02:10]
•GAAP fully diluted earnings per share (EPS) was $0.59, versus GAAP fully diluted EPS in the first quarter 2020 of $0.23, an increase of 157%

[0000038725-21-000085:8k_2_02:11]
•Working capital as a percent of trailing twelve months sales improved 220 basis points to 27.7%

[0000038725-21-000085:8k_2_02:12]
Fort Wayne, IN – April 27, 2021 – Franklin Electric Co. Inc. today announced first quarter 2021 financial results.

[0000038725-21-000085:8k_2_02:13]
First quarter 2021 sales were $333.0 million, compared to first quarter 2020 sales of $266.8 million.  First quarter 2021 operating income was $33.8 million, compared to first quarter operating income in 2020 of $13.8 million, an increase of a 144 percent.

[0000038725-21-000085:8k_2_02:14]
First quarter 2021 GAAP fully diluted earnings per share (EPS) was $0.59, versus GAAP fully diluted EPS in the first quarter 2020 of $0.23.

[0000038725-21-000085:8k_2_02:15]
“Building off a strong fourth quarter, our Water Systems and Distribution businesses maintained their momentum, delivering record sales and earnings for the first quarter. At the same time, our Fueling Systems business hit an inflection point, and appears to have turned the post-pandemic corner, producing solid revenue growth alongside 23 percent operating income growth versus the first quarter last year,” commented Gregg Sengstack, Franklin Electric’s Chairperson and Chief Executive Officer. “While 2021 is off to a great start with significant momentum at our heels and a strong strategy for growth, we remain vigilant in adapting to the ongoing impacts of the global pandemic, which continues to cause disruption across the globe.”

[0000038725-21-000085:8k_2_02:16]
Mr. Sengstack concluded, “We are confident that our approach to grow as a global provider of water and fuel systems positions us well to meet the needs of our customers and generate value for our shareholders. As a result, we are increasing our full year earnings per share before restructuring expense guidance to be in the range of $2.80 to $3.00, given the demand environment we see in most of the end markets we serve.”

[0000038725-21-000085:8k_2_02:17]
Segment Summaries

[0000038725-21-000085:8k_2_02:18]
Water Systems sales were $197.6 million in the first quarter 2021, an increase of $33.5 million or 20 percent versus the first quarter 2020. Water Systems sales, excluding acquisitions and the impact of foreign currency translation, were up about 18 percent compared to the first quarter 2020.  Sales of

[0000038725-21-000085:8k_2_02:19]
groundwater pumping equipment and sales of surface pumping equipment increased due to strong end market demand. These increases were partially offset by lower demand for dewatering equipment.  In 2021, Water Systems operating income was a record for any first quarter at $31.3 million driven by price realization, favorable product sales mix and cost management.  First quarter 2020 Water Systems operating income was $18.8 million.

[0000038725-21-000085:8k_2_02:20]
Distribution sales were a record at $95.7 million in the first quarter 2021.  The Distribution segment organic sales increased 31 percent compared to the first quarter of 2020.  Revenue growth was driven by broad-based demand in all regions and product categories, the Gicon acquisition, customer purchase pull forwards and the Texas winter storm. The Distribution segment operating income was a record at $2.0 million in the first quarter of 2021.

[0000038725-21-000085:8k_2_02:21]
Fueling Systems sales were $56.8 million in the first quarter 2021, an increase of $1.5 million versus the first quarter 2020. Fueling Systems sales in the U.S. and Canada increased by about 1 percent compared to the first quarter 2020. The increase was due to higher demand for Pumping and Fuel Management Systems. Outside the U.S. and Canada, Fueling Systems revenues increased by about 7 percent, driven primarily by higher sales in Latin America and EMENA. Fueling Systems operating income was a record for any first quarter at $14.9 million in the first quarter of 2021, compared to $12.1 million in the first quarter of 2020, driven by price realization and cost management.

[0000038725-21-000085:8k_2_02:22]
Cash Flow

[0000038725-21-000085:8k_2_02:23]
Net cash flows from operating activities in the first quarter 2021 were $5.4 million versus a negative $4.7 million in the same period 2020.  The increase was primarily due to higher Net Income and lower net working capital requirements.

[0000038725-21-000085:8k_2_02:24]
Revised 2021 Guidance

[0000038725-21-000085:8k_2_02:25]
Due to better than expected first quarter earnings and the recently completed Water Treatment acquisitions, the Company is revising its full year 2021 revenue estimates to be in the range of $1.45 billion to $1.48 billion and full year 2021 earnings per share before restructuring expenses to be in the range from $2.80 to $3.00.  The Company’s revised 2021 guidance assumes there will not be any worsening impacts from the global pandemic.

[0000038725-21-000085:8k_2_02:26]
Earnings Conference Call

[0000038725-21-000085:8k_2_02:27]
A conference call to review earnings and other developments in the business will commence at 9:00 am ET. The first quarter 2021 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-21-000085:8k_2_02:28]
https://edge.media-server.com/mmc/p/4c8xwu3v

[0000038725-21-000085:8k_2_02:29]
If you intend to ask questions during the call, please dial in using 877.643.7158 for domestic calls and 914.495.8565 for international calls. The conference ID is: 9894751.

[0000038725-21-000085:8k_2_02:30]
A replay of the conference call will be available Tuesday, April 27, 2021 at 12:00 noon ET through noon ET on Tuesday, May 4, 2021, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls. The replay passcode is: 9894751.

[0000038725-21-000085:8k_2_02:31]
Forward Looking Statements

[0000038725-21-000085:8k_2_02:32]
About Franklin Electric

[0000038725-21-000085:8k_2_02:33]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-21-000085:8k_2_02:34]
Franklin Electric Contact:

[0000038725-21-000085:8k_2_02:35]
John J. Haines

[0000038725-21-000085:8k_2_02:36]
Franklin Electric Co., Inc.

[0000038725-21-000085:8k_2_02:37]
260-824-2900

[0000038725-21-000085:8k_2_02:38]
Email: jhaines@fele.com

[0000038725-21-000085:8k_2_02:39]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | First Quarter Ended |  |  |
|  | March 31, 2021 |  | March 31, 2020 |  |  |  |  |
| Net sales | $ | 333,046 |  |  | $ | 266,754 |  |  |  |  |  |
| Cost of sales | 217,500 |  |  | 176,437 |  |  |  |  |  |
| Gross profit | 115,546 |  |  | 90,317 |  |  |  |  |  |
| Selling, general, and administrative expenses | 81,603 |  |  | 75,623 |  |  |  |  |  |
| Restructuring expense | 152 |  |  | 873 |  |  |  |  |  |
| Operating income | 33,791 |  |  | 13,821 |  |  |  |  |  |
| Interest expense | (1,089) |  |  | (1,234) |  |  |  |  |  |
| Other income/(expense), net | (100) |  |  | (202) |  |  |  |  |  |
| Foreign exchange income/(expense) | (58) |  |  | 962 |  |  |  |  |  |
| Income before income taxes | 32,544 |  |  | 13,347 |  |  |  |  |  |
| Income tax (benefit)/ expense | 4,381 |  |  | 2,555 |  |  |  |  |  |
| Net income | $ | 28,163 |  |  | $ | 10,792 |  |  |  |  |  |
| Less: Net (income)/loss attributable to noncontrolling interests | (283) |  |  | (149) |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 27,880 |  |  | $ | 10,643 |  |  |  |  |  |
| Income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.60 |  |  | $ | 0.23 |  |  |  |  |  |
| Diluted | $ | 0.59 |  |  | $ | 0.23 |  |  |  |  |  |

[0000038725-21-000085:8k_2_02:40]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | March 31, 2021 |  | December 31, 2020 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 118,331 |  |  | $ | 130,787 |  |
| Receivables (net) | 179,439 |  |  | 159,827 |  |
| Inventories | 310,330 |  |  | 300,932 |  |
| Other current assets | 27,150 |  |  | 27,708 |  |
| Total current assets | 635,250 |  |  | 619,254 |  |
| Property, plant, and equipment, net | 205,137 |  |  | 209,021 |  |
| Right-of-use asset, net | 33,449 |  |  | 31,954 |  |
| Goodwill and other assets | 407,843 |  |  | 412,078 |  |
| Total assets | $ | 1,281,679 |  |  | $ | 1,272,307 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 109,984 |  |  | $ | 95,903 |  |
| Accrued expenses and other current liabilities | 75,941 |  |  | 94,160 |  |
| Current lease liability | 11,758 |  |  | 11,090 |  |
| Current maturities of long-term debt and short-term borrowings | 2,671 |  |  | 2,551 |  |
| Total current liabilities | 200,354 |  |  | 203,704 |  |
| Long-term debt | 91,361 |  |  | 91,966 |  |
| Long-term lease liability | 21,704 |  |  | 20,866 |  |
| Income taxes payable non-current | 11,965 |  |  | 11,965 |  |
| Deferred income taxes | 26,521 |  |  | 25,671 |  |
| Employee benefit plans | 42,546 |  |  | 44,443 |  |
| Other long-term liabilities | 23,710 |  |  | 23,988 |  |
| Redeemable noncontrolling interest | (168) |  |  | (245) |  |
| Total equity | 863,686 |  |  | 849,949 |  |
| Total liabilities and equity | $ | 1,281,679 |  |  | $ | 1,272,307 |  |

[0000038725-21-000085:8k_2_02:41]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Three Months Ended |
| (In thousands) |  |  |  |
|  | March 31, 2021 |  | March 31, 2020 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 28,163 |  |  | $ | 10,792 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 9,574 |  |  | 9,199 |  |
| Non-cash lease expense | 3,068 |  |  | 1,962 |  |
| Share-based compensation | 4,190 |  |  | 4,352 |  |
| Other | 359 |  |  | (938) |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (24,196) |  |  | (2,574) |  |
| Inventory | (14,327) |  |  | (19,952) |  |
| Accounts payable and accrued expenses | (298) |  |  | (4,223) |  |
| Operating leases | (3,068) |  |  | (1,962) |  |
| Other | 1,917 |  |  | (1,312) |  |
| Net cash flows from operating activities | 5,382 |  |  | (4,656) |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (6,744) |  |  | (5,535) |  |
| Proceeds from sale of property, plant, and equipment | — |  |  | 25 |  |
| Acquisitions and investments | 70 |  |  | (5,626) |  |
| Other investing activities | 3 |  |  | — |  |
| Net cash flows from investing activities | (6,671) |  |  | (11,136) |  |
| Cash flows from financing activities: |  |  |  |
| Change in debt | (457) |  |  | 19,670 |  |
| Proceeds from issuance of common stock | 5,083 |  |  | 871 |  |
| Purchases of common stock | (4,849) |  |  | (16,981) |  |
| Dividends paid | (8,143) |  |  | (7,240) |  |
| Net cash flows from financing activities | (8,366) |  |  | (3,680) |  |
| Effect of exchange rate changes on cash | (2,801) |  |  | (4,946) |  |
| Net change in cash and equivalents | (12,456) |  |  | (24,418) |  |
| Cash and equivalents at beginning of period | 130,787 |  |  | 64,405 |  |
| Cash and equivalents at end of period | $ | 118,331 |  |  | $ | 39,987 |  |

[0000038725-21-000085:8k_2_02:42]
Key Performance Indicators: Earnings Per Share Calculations

[0000038725-21-000085:8k_2_02:43]
| Earnings Before and After Restructuring |  | For the First Quarter |  |  |
| (in millions) |  | 2021 | 2020 | Change |  |  |  |  |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 27.9 |  | $ | 10.6 |  | 163 | % |  |  |  |  |
| Allocated Earnings |  | $ | (0.2) |  | $ | — |  |  |  |  |  |  |
| Earnings for EPS Calculations |  | $ | 27.7 |  | $ | 10.6 |  | 161 | % |  |  |  |  |
| Restructuring (before tax): |  | $ | 0.2 |  | $ | 0.9 |  |  |  |  |  |  |
| Restructuring, net of tax: |  | $ | 0.1 |  | $ | 0.7 |  |  |  |  |  |  |
| Earnings Before Restructuring |  | $ | 27.8 |  | $ | 11.3 |  | 146 | % |  |  |  |  |
| Earnings Per Share |  | For the First Quarter |  |  |
| Before and After Restructuring |  | 2021 | 2020 | Change |  |  |  |  |
| (in millions except Earnings Per Share) |  |  |  |  |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 46.9 |  | 46.8 |  | — | % |  |  |  |  |
| Fully Diluted Earnings Per Share (“EPS”) Reported |  | $ | 0.59 |  | $ | 0.23 |  | 157 | % |  |  |  |  |
| Restructuring Per Share, net of tax |  | $ | — |  | $ | 0.01 |  |  |  |  |  |  |
| Fully Diluted EPS Before Restructuring |  | $ | 0.59 |  | $ | 0.24 |  | 146 | % |  |  |  |  |

[0000038725-21-000085:8k_2_02:44]
Key Performance Indicators: Sales Summary

[0000038725-21-000085:8k_2_02:45]
|  | Net Sales |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q1 2020 | $ | 83.9 |  | $ | 28.2 |  | $ | 38.2 |  | $ | 13.8 |  | $ | 164.1 |  | $ | 55.3 |  | $ | 60.4 |  | $ | (13.0) |  | $ | 266.8 |  |
| Q1 2021 | $ | 101.3 |  | $ | 31.7 |  | $ | 44.4 |  | $ | 20.2 |  | $ | 197.6 |  | $ | 56.8 |  | $ | 95.7 |  | $ | (17.1) |  | $ | 333.0 |  |
| Change | $ | 17.4 |  | $ | 3.5 |  | $ | 6.2 |  | $ | 6.4 |  | $ | 33.5 |  | $ | 1.5 |  | $ | 35.3 |  | $ | (4.1) |  | $ | 66.2 |  |
| % Change | 21 | % | 12 | % | 16 | % | 46 | % | 20 | % | 3 | % | 58 | % |  | 25 | % |
| Foreign currency translation | $ | 1 |  | $ | (5.7) |  | $ | 0.2 |  | $ | 0.8 |  | $ | (3.7) |  | $ | 0.8 |  | $ | — |  |  |  |
| % Change | 1 | % | (20) | % | 1 | % | 6 | % | (2) | % | 1 | % | — | % |  |  |
| Acquisitions | $ | 7.2 |  | $ | — |  | $ | — |  | $ | — |  | $ | 7.2 |  | $ | — |  | $ | 16.3 |  |  |  |
| Volume/Price | $ | 9.2 |  | $ | 9.2 |  | $ | 6.0 |  | $ | 5.6 |  | $ | 30.0 |  | $ | 0.7 |  | $ | 19.0 |  |  |  |
| % Change | 11 | % | 33 | % | 16 | % | 41 | % | 18 | % | 1 | % | 31 | % |  |  |

[0000038725-21-000085:8k_2_02:46]
Key Performance Indicators: Operating Income and Margin Summary

[0000038725-21-000085:8k_2_02:47]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the First Quarter 2021 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 31.3 |  | $ | 14.9 |  | $ | 2.0 |  | $ | (14.4) |  | $ | 33.8 |  |
| % Operating Income To Net Sales | 15.8 | % | 26.2 | % | 2.1 | % |  | 10.2 | % |
| Restructuring | $ | 0.1 |  | $ | — |  | $ | 0.1 |  | $ | — |  | $ | 0.2 |  |
| Operating Income/(Loss) Before Restructuring | $ | 31.4 |  | $ | 14.9 |  | $ | 2.1 |  | $ | (14.4) |  | $ | 34.0 |  |
| % Operating Income to Net Sales Before Restructuring | 15.9 | % | 26.2 | % | 2.2 | % |  | 10.2 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the First Quarter 2020 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 18.8 |  | $ | 12.1 |  | $ | (2.2) |  | $ | (14.9) |  | $ | 13.8 |  |
| % Operating Income To Net Sales | 11.5 | % | 21.9 | % | (3.6) | % |  | 5.2 | % |
| Restructuring | $ | 0.6 |  | $ | 0.2 |  | $ | 0.1 |  | $ | — |  | $ | 0.9 |  |
| Operating Income/(Loss) Before Restructuring | $ | 19.4 |  | $ | 12.3 |  | $ | (2.1) |  | $ | (14.9) |  | $ | 14.7 |  |
| % Operating Income to Net Sales Before Restructuring | 11.8 | % | 22.2 | % | (3.5) | % |  | 5.5 | % |
