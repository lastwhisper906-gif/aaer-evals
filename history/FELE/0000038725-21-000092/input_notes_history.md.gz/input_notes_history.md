# FELE note change history — 0000038725-20-000208 → 0000038725-21-000092


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-04-30):
[0000038725-21-000092:note_history:1]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. The subject-matter expert has issued their preliminary report, which indicates that total damages incurred by Esso amounted to approximately 12 million euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company has retained experts to demonstrate that its products did not cause the damage, and in January 2021, submitted its response to the expert’s preliminary report for each station. The expert's response to the Company's report is due to the Court in June 2021. The Company cannot predict the ultimate outcome of this matter. Any exposure related to this matter is neither probable nor estimable at this time. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s results of operations.
  (was, 2020-10-30, similarity 0.7153):
[0000038725-20-000208:note_history:1]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. The subject-matter expert has issued their preliminary report, which indicates that total damages incurred by Esso amounted to approximately 12 million euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company has retained experts to demonstrate that its products did not cause the damage, and it has until January 2021 to issue its response to the expert’s preliminary report for each station. The Company cannot predict the ultimate outcome of this matter. Any exposure related to this matter is neither probable nor estimable at this time. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s results of operations.

- changed (2021-04-30):
[0000038725-21-000092:note_history:2]
At March 31, 2021, the Company had $6.8 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.
  (was, 2020-10-30, similarity 0.966):
[0000038725-20-000208:note_history:2]
At September 30, 2020, the Company had $8.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

- changed (2021-04-30):
[0000038725-21-000092:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the first quarter ended March 31, 2021, are as follows:
  (was, 2020-10-30, similarity 0.8921):
[0000038725-20-000208:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 30, 2020, are as follows:

- changed (2021-04-30):
[0000038725-21-000092:note_history:4]
| (In millions) |  |  |
| Balance as of December 31, 2020 |  | $ | 9.7 |  |
| Accruals related to product warranties |  | 0.5 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (0.7) |  |
| Balance as of March 31, 2021 |  | $ | 9.5 |  |
  (was, 2020-10-30, similarity 0.9715):
[0000038725-20-000208:note_history:4]
| (In millions) |  |  |
| Balance as of December 31, 2019 |  | $ | 9.1 |  |
| Accruals related to product warranties |  | 6.9 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (6.7) |  |
| Balance as of September 30, 2020 |  | $ | 9.3 |  |

- changed (2021-04-30):
[0000038725-21-000092:note_history:5]
The components of the Company’s operating lease portfolio as of the first quarter ended March 31, 2021 are as follows:
  (was, 2020-10-30, similarity 0.8699):
[0000038725-20-000208:note_history:5]
The components of the Company’s operating lease portfolio as of the third quarter and nine months ended September 30, 2020 are as follows:

- changed (2021-04-30):
[0000038725-21-000092:note_history:6]
| Lease Cost (in millions): |  |  |  |
| Operating lease cost |  |  | $ | 3.0 |  |
| Short-term lease cost |  |  | 0.3 |  |
| Other Information: |  |  |  |
| Weighted-average remaining lease term |  |  | 4.0 years |
| Weighted-average discount rate |  |  | 4.0 | % |
  (was, 2020-10-30, similarity 0.8801):
[0000038725-20-000208:note_history:6]
| Lease Cost (in millions): | Third Quarter Ended |  | Nine Months Ended |
| Operating lease cost | $ | 3.1 |  |  | $ | 8.3 |  |
| Short-term lease cost | 0.3 |  |  | 0.5 |  |
| Other Information: |  |  |  |
| Weighted-average remaining lease term |  |  | 3.4 years |
| Weighted-average discount rate |  |  | 3.6 | % |

- changed (2021-04-30):
[0000038725-21-000092:note_history:7]
The minimum rental payments for non-cancellable operating leases as of March 31, 2021, are as follows:
  (was, 2020-10-30, similarity 0.949):
[0000038725-20-000208:note_history:7]
The minimum rental payments for non-cancellable operating leases as of September 30, 2020, are as follows:

- removed (2021-04-30):
[0000038725-20-000208:note_history:8]
As of September 30, 2020, the Company has approximately $2.3 million of additional ROU assets related to leases that have not yet commenced, but create future lease obligations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-04-30):
[0000038725-21-000092:note_history:9]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2020, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2021, and for the first quarters ended March 31, 2021 and March 31, 2020 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the first quarter ended March 31, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2021. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2020.
  (was, 2020-10-30, similarity 0.9366):
[0000038725-20-000208:note_history:9]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2019, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 30, 2020, and for the third quarters and nine months ended September 30, 2020 and September 30, 2019 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made.  Operating results for the third quarter and nine months ended September 30, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2020.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2019.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-04-30):
[0000038725-21-000092:note_history:10]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | — |  |  | — |  |
| Tax increment financing debt |  | 17.1 |  |  | 17.6 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 2.1 |  |  | 1.8 |  |
| Other |  | — |  |  | 0.2 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 94.1 |  |  | $ | 94.6 |  |
| Less: current maturities |  | (2.7) |  |  | (2.6) |  |
| Long-term debt |  | $ | 91.4 |  |  | $ | 92.0 |  |
  (was, 2020-10-30, similarity 0.7237):
[0000038725-20-000208:note_history:10]
| (In millions) |  | September 30, 2020 |  | December 31, 2019 |
| Tax increment financing debt |  | 17.6 |  |  | 18.7 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | — |  |  | 19.0 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 1.8 |  |  | 2.3 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 94.3 |  |  | $ | 115.0 |  |
| Less: current maturities |  | (2.4) |  |  | (21.9) |  |
| Long-term debt |  | $ | 91.9 |  |  | $ | 93.1 |  |

- changed (2021-04-30):
[0000038725-21-000092:note_history:11]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2021 matures as follows:
  (was, 2020-10-30, similarity 0.9474):
[0000038725-20-000208:note_history:11]
Debt outstanding, excluding unamortized debt issuance costs, at September 30, 2020 matures as follows:

- changed (2021-04-30):
[0000038725-21-000092:note_history:12]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement"), which expires on July 30, 2021 and has an initial borrowing capacity of $250.0 million. As of March 31, 2021, the Company has $150.0 million borrowing capacity available under the Prudential Agreement.
  (was, 2020-10-30, similarity 0.9773):
[0000038725-20-000208:note_history:12]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement"), which expires on July 30, 2021 and has an initial borrowing capacity of $250.0 million.  As of September 30, 2020, the Company has $150.0 million borrowing capacity available under the Prudential Agreement.

- changed (2021-04-30):
[0000038725-21-000092:note_history:13]
The Company, Allen County, Indiana and certain institutional investors maintain a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)." The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. These Project Bonds ("Tax increment financing debt") bear interest at 3.6 percent per annum. Interest and principal balance of the Project Bonds are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.
  (was, 2020-10-30, similarity 0.9892):
[0000038725-20-000208:note_history:13]
The Company, Allen County, Indiana and certain institutional investors maintain a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)." The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. These Project Notes ("Tax increment financing debt") bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.

- changed (2021-04-30):
[0000038725-21-000092:note_history:14]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"), with a maximum aggregate borrowing capacity of $200.0 million. On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of March 31, 2021, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.
  (was, 2020-10-30, similarity 0.9897):
[0000038725-20-000208:note_history:14]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"), with a maximum aggregate borrowing capacity of $200.0 million.  On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually.  The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of September 30, 2020, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

- changed (2021-04-30):
[0000038725-21-000092:note_history:15]
As of March 31, 2021, the Company had no outstanding borrowings, $4.0 million in letters of credit outstanding, and $296.0 million of available capacity under the Credit Agreement.
  (was, 2020-10-30, similarity 0.9706):
[0000038725-20-000208:note_history:15]
As of September 30, 2020, the Company had no outstanding borrowings, $4.3 million in letters of credit outstanding, and $295.7 million of available capacity under the Credit Agreement.

- changed (2021-04-30):
[0000038725-21-000092:note_history:16]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 1.00 to 3.50 and a minimum interest coverage ratio of 1.00 to 3.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of March 31, 2021.
  (was, 2020-10-30, similarity 0.9941):
[0000038725-20-000208:note_history:16]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 1.00 to 3.50 and a minimum interest coverage ratio of 1.00 to 3.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of September 30, 2020.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-04-30):
[0000038725-21-000092:note_history:17]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | — |  |  | — |  |
| Tax increment financing debt |  | 17.1 |  |  | 17.6 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 2.1 |  |  | 1.8 |  |
| Other |  | — |  |  | 0.2 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 94.1 |  |  | $ | 94.6 |  |
| Less: current maturities |  | (2.7) |  |  | (2.6) |  |
| Long-term debt |  | $ | 91.4 |  |  | $ | 92.0 |  |
  (was, 2020-10-30, similarity 0.7237):
[0000038725-20-000208:note_history:17]
| (In millions) |  | September 30, 2020 |  | December 31, 2019 |
| Tax increment financing debt |  | 17.6 |  |  | 18.7 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | — |  |  | 19.0 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 1.8 |  |  | 2.3 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 94.3 |  |  | $ | 115.0 |  |
| Less: current maturities |  | (2.4) |  |  | (21.9) |  |
| Long-term debt |  | $ | 91.9 |  |  | $ | 93.1 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-04-30):
[0000038725-21-000092:note_history:18]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2021 matures as follows:
  (was, 2020-10-30, similarity 0.9474):
[0000038725-20-000208:note_history:18]
Debt outstanding, excluding unamortized debt issuance costs, at September 30, 2020 matures as follows:


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2021-04-30):
[0000038725-21-000092:note_history:19]
16. SUBSEQUENT EVENT

- added (2021-04-30):
[0000038725-21-000092:note_history:20]
On April 1, 2021, the Company acquired 100 percent of the ownership interests in Puronics, Inc. and its wholly owned subsidiaries, headquartered in Livermore, California,  for approximately $28 million. Puronics is a residential and commercial water treatment products and services provider and will be included as a part of the Water Systems segment of the Company. The initial accounting for this acquisition is incomplete, and the Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2020, as the results of operations for this acquisition is immaterial.
