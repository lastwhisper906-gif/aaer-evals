# FELE notes — 0000038725-21-000092


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-21-000092:notes:1]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2020, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2021, and for the first quarters ended March 31, 2021 and March 31, 2020 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the first quarter ended March 31, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2021. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2020.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000038725-21-000092:notes:2]
ACCOUNTING PRONOUNCEMENTS
Adoption of New Accounting Standards

[0000038725-21-000092:notes:3]
In March 2020, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2020-04, Facilitation of the Effects of Reference Rate Reform on Financial Reporting, which provides optional expedients and exceptions for applying U.S. generally accepted accounting principles to contracts, hedging relationships, and other transactions affected by the discontinuation of the London Interbank Offered Rate ("LIBOR") and other reference rates which are expected to be discontinues due to reference rate reform. ASU 2020-04 is effective on a prospective basis between March 12, 2020 and December 31, 2022. The Company adopted the standard effective January 1, 2021, and it did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-21-000092:notes:4]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is expected to reduce cost and complexity related to accounting for income taxes. ASU 2019-12 eliminates the need for the Company to analyze whether certain exceptions apply and improves financial statement preparers' application of income tax-related guidance. ASU 2019-12 is effective for interim and annual periods beginning after December 15, 2020 with early adoption permitted. Amendments related to franchise taxes that are partially based on income should be applied on either a retrospective or modified retrospective basis. All other amendments should be applied on a prospective basis. The Company adopted the standard effective January 1, 2021, and it did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-21-000092:notes:5]
Accounting Standards Issued But Not Yet Adopted

[0000038725-21-000092:notes:6]
In August 2020, the FASB issued ASU 2020-06, Debt – Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging – Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity. ASU 2020-06 reduces the number of accounting models for various convertible instruments and reduces form-over-substance-based accounting conclusions for the derivatives scope exception for contracts in an entity’s own equity. The FASB also updated Earnings Per Share (“EPS”) guidance under Topic 260 by requiring an entity to consider the potential effect of share settlement in the diluted EPS calculation for instruments that may be settled in cash or shares as well as other amendments. ASU 2020-06 is effective for interim and annual periods beginning after December 15, 2021 with early adoption permitted but no earlier than fiscal years beginning after December 15, 2020. The guidance should be adopted at the beginning of a fiscal year. ASU 2020-06 should be applied on either a retrospective or modified retrospective basis. The Company is planning to adopt on January 1, 2022, but does not expect the ASU to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-21-000092:notes:7]
ACQUISITIONSDuring the fourth quarter ended December 31, 2020, the Company acquired 100 percent of the ownership interests of Gicon Pumps & Equipment, Inc., a professional groundwater distributor operating seven locations in the state of Texas for a purchase price of $28.1 million after working capital adjustments. Gicon will be included as part of the Distribution segment of the Company. As of March 31, 2021, the Company has recorded estimated fair values that exceed the acquisition price by $2.9 million, representing a bargain purchase gain due to favorable market conditions within accrued expenses and other current liabilities in the consolidated balance sheets. Once the determination of fair values is complete in 2021, the Company will recognize the bargain purchase gain in the consolidated statements of income. In a separate transaction during the fourth quarter ended December 31, 2020, the Company acquired 100 percent of the ownership interests in Waterite Inc. and its affiliate Waterite America Inc., headquartered in Winnipeg, Manitoba, Canada, for a purchase price of $21.9 million after working capital adjustments. Waterite will be included as a part of the Water Systems segment of the Company. The fair value of the 
assets acquired and liabilities assumed for both acquisitions are preliminary as of March 31, 2021 and is classified as Level 3 within the valuation hierarchy. In addition, the Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2020, as the results of operations for both acquisitions is immaterial.

[0000038725-21-000092:notes:8]
During the first quarter ended March 31, 2020, the Company acquired all of the assets of a company that manufactures line shaft turbines and other adjacent product lines for a purchase price of $5.9 million after working capital adjustments. The fair value of the assets acquired and liabilities assumed were considered final as of March 31, 2021 and are classified as Level 3 within the valuation hierarchy. In addition, the Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2020, as the results of operations for this acquisition is immaterial.
Transaction costs were expensed as incurred under the guidance of FASB Accounting Standards Codification Topic 805, Business Combinations. There were  $0.1 million and $0.0 million of transaction costs included in the "Selling, general, and administrative expenses" line of the Company's condensed consolidated statements of income for the first quarters ended March 31, 2021 and March 31, 2020, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-21-000092:notes:9]
FAIR VALUE MEASUREMENTS
FASB ASC Topic 820, Fair Value Measurements and Disclosures, provides guidance for defining, measuring, and disclosing fair value within an established framework and hierarchy. Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. The standard established a fair value hierarchy which requires an entity to maximize the use of observable inputs and to minimize the use of unobservable inputs when measuring fair value. The three levels of inputs that may be used to measure fair value within the hierarchy are as follows:

[0000038725-21-000092:notes:10]
[same as prior period, unchanged from 0000038725-20-000208:notes:13]

[0000038725-21-000092:notes:11]
[same as prior period, unchanged from 0000038725-20-000208:notes:14]

[0000038725-21-000092:notes:12]
[same as prior period, unchanged from 0000038725-20-000208:notes:15]

[0000038725-21-000092:notes:13]
As of March 31, 2021 and December 31, 2020, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-21-000092:notes:14]
| (In millions) | March 31, 2021 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 19.9 |  | $ | 19.9 |  | $ | — |  | $ | — |  |
|  | December 31, 2020 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 20.2 |  | $ | 20.2 |  | $ | — |  | $ | — |  |

[0000038725-21-000092:notes:15]
The Company's Level 1 assets consist of cash equivalents which are generally comprised of foreign bank guaranteed certificates of deposit.

[0000038725-21-000092:notes:16]
The Company has no assets measured on a recurring basis classified as Level 2 or Level 3.
Total debt, including current maturities, have carrying amounts of $94.1 million and $94.6 million and estimated fair values of $103.7 million and $107.3 million as of March 31, 2021 and December 31, 2020, respectively. In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value. Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction. In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities. Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-21-000092:notes:17]
FINANCIAL INSTRUMENTSThe Company’s non-employee directors' deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period. The Company has entered into share swap transaction agreements (the "swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price. The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party. As of March 31, 2021, the swap had a notional value based on 280,000 shares. For the first quarters ended March 31, 2021 and March 31, 2020, the swap resulted in a gain of $2.7 million and a loss of $2.7 million, respectively. Gains and losses resulting from the swap were largely offset by gains and losses on the fair value of the deferred compensation stock liability. All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-21-000092:notes:18]
[same as prior period, unchanged from 0000038725-20-000208:notes:20]

[0000038725-21-000092:notes:19]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortizing intangibles: |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.4 |  |  | $ | (7.2) |  |  | $ | 7.5 |  |  | $ | (7.3) |  |
| Technology |  | 7.5 |  |  | (7.2) |  |  | 7.5 |  |  | (7.2) |  |
| Customer relationships |  | 163.7 |  |  | (80.1) |  |  | 165.1 |  |  | (78.5) |  |
| Other |  | 6.2 |  |  | (2.9) |  |  | 6.3 |  |  | (3.0) |  |
| Total |  | $ | 184.8 |  |  | $ | (97.4) |  |  | $ | 186.4 |  |  | $ | (96.0) |  |
| Unamortizing intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 42.9 |  |  | — |  |  | 43.4 |  |  | — |  |
| Total intangibles |  | $ | 227.7 |  |  | $ | (97.4) |  |  | $ | 229.8 |  |  | $ | (96.0) |  |

[0000038725-21-000092:notes:20]
Amortization expense related to intangible assets for the first quarters ended March 31, 2021 and March 31, 2020 was $2.5 million and $2.4 million, respectively.

[0000038725-21-000092:notes:21]
[same as prior period, unchanged from 0000038725-20-000208:notes:23]

[0000038725-21-000092:notes:22]
| (In millions) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025 |
|  |  | $ | 9.9 |  |  | $ | 9.6 |  |  | $ | 9.5 |  |  | $ | 9.3 |  |  | $ | 8.5 |  |

[0000038725-21-000092:notes:23]
The change in the carrying amount of goodwill by reportable segment for the three months ended March 31, 2021, is as follows:

[0000038725-21-000092:notes:24]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2020 |  | $ | 161.5 |  |  | $ | 67.7 |  |  | $ | 37.5 |  |  | $ | 266.7 |  |
| Acquisitions |  | — |  |  | — |  |  | — |  |  | — |  |
| Adjustments to prior year acquisitions |  | (0.1) |  |  | — |  |  | — |  |  | (0.1) |  |
| Foreign currency translation |  | (1.3) |  |  | — |  |  | — |  |  | (1.3) |  |
| Balance as of March 31, 2021 |  | $ | 160.1 |  |  | $ | 67.7 |  |  | $ | 37.5 |  |  | $ | 265.3 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-21-000092:notes:25]
EMPLOYEE BENEFIT PLANS
Defined Benefit Plans - As of March 31, 2021, the Company maintained two domestic pension plans and three German pension plans. The Company used a December 31, 2020 measurement date for these plans. One of the Company's domestic pension plans covers one active management employee, while the other domestic plan covers all eligible employees (plan was frozen as of December 31, 2011). The two domestic and three German plans collectively comprise the 'Pension Benefits' disclosure caption.

[0000038725-21-000092:notes:26]
[same as prior period, unchanged from 0000038725-20-000208:notes:28]

[0000038725-21-000092:notes:27]
The following table sets forth the aggregated net periodic benefit cost for all pension plans and the other post-retirement benefit plan for the first quarters ended March 31, 2021 and March 31, 2020:

[0000038725-21-000092:notes:28]
| (In millions) | Pension Benefits |  | Other Benefits |
|  | First Quarter Ended |  | First Quarter Ended |
|  | March 31, 2021 |  | March 31, 2020 |  | March 31, 2021 |  | March 31, 2020 |
| Service cost | $ | 0.2 |  |  | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 0.7 |  |  | 1.1 |  |  | — |  |  | 0.1 |  |
| Expected return on assets | (1.4) |  |  | (1.7) |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | 1.0 |  |  | 0.9 |  |  | 0.1 |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.5 |  |  | $ | 0.4 |  |  | $ | 0.1 |  |  | $ | 0.1 |  |

[0000038725-21-000092:notes:29]
In the first quarter ended March 31, 2021, the Company made contributions of $0.1 million to the funded plans. The amount of contributions to be made to the plans during the calendar year 2021 will be finalized by September 15, 2021, based upon the funding level requirements identified and year-end valuation performed at December 31, 2020.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-21-000092:notes:30]
INCOME TAXES
The Company’s effective tax rate from continuing operations for the three month period ended March 31, 2021 was 13.5 percent as compared to 19.1 percent for the three month period ended March 31, 2020. The effective tax rate is lower than the U.S. statutory rate of 21 percent primarily due to foreign earnings taxed at rates below the U.S. statutory rate, the recognition of the U.S. foreign-derived intangible income (FDII) provisions, and certain discrete events including excess tax benefits from share-based compensation partially offset by state taxes.

[0000038725-21-000092:notes:31]
The decrease in the effective tax rate was primarily a result of more favorable discrete events, including increased excess tax benefits from share-based compensation, recorded in the three months ended March 31, 2021, compared with the same period in 2020.

[0000038725-21-000092:notes:32]
During the first quarter of 2021, the Company also recorded a deferred tax benefit of $0.8 million as a result of a tax election made in a foreign jurisdiction.


## us-gaap:DebtDisclosureTextBlock

[0000038725-21-000092:notes:33]
DEBT
Debt consisted of the following:

[0000038725-21-000092:notes:34]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | — |  |  | — |  |
| Tax increment financing debt |  | 17.1 |  |  | 17.6 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 2.1 |  |  | 1.8 |  |
| Other |  | — |  |  | 0.2 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 94.1 |  |  | $ | 94.6 |  |
| Less: current maturities |  | (2.7) |  |  | (2.6) |  |
| Long-term debt |  | $ | 91.4 |  |  | $ | 92.0 |  |

[0000038725-21-000092:notes:35]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2021 matures as follows:

[0000038725-21-000092:notes:36]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 94.2 |  |  | $ | 2.7 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.4 |  |  | $ | 76.4 |  |  | $ | 11.1 |  |

[0000038725-21-000092:notes:37]
Prudential Agreement

[0000038725-21-000092:notes:38]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement"), which expires on July 30, 2021 and has an initial borrowing capacity of $250.0 million. As of March 31, 2021, the Company has $150.0 million borrowing capacity available under the Prudential Agreement.

[0000038725-21-000092:notes:39]
Project Bonds

[0000038725-21-000092:notes:40]
The Company, Allen County, Indiana and certain institutional investors maintain a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)." The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. These Project Bonds ("Tax increment financing debt") bear interest at 3.6 percent per annum. Interest and principal balance of the Project Bonds are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.

[0000038725-21-000092:notes:41]
New York Life Agreement

[0000038725-21-000092:notes:42]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"), with a maximum aggregate borrowing capacity of $200.0 million. On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of March 31, 2021, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-21-000092:notes:43]
Credit Agreement

[0000038725-21-000092:notes:44]
The Company maintains the Third Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement has a maturity date of October 28, 2021 and commitment amount of $300.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million). Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-21-000092:notes:45]
As of March 31, 2021, the Company had no outstanding borrowings, $4.0 million in letters of credit outstanding, and $296.0 million of available capacity under the Credit Agreement.

[0000038725-21-000092:notes:46]
Covenants

[0000038725-21-000092:notes:47]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 1.00 to 3.50 and a minimum interest coverage ratio of 1.00 to 3.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of March 31, 2021.


## us-gaap:EarningsPerShareTextBlock

[0000038725-21-000092:notes:48]
EARNINGS PER SHARE
The Company calculates basic and diluted earnings per common share using the two-class method. Under the two-class method, net earnings are allocated to each class of common stock and participating security as if all of the net earnings for the period had been distributed. The Company's participating securities consist of share-based payment awards that contain a non-forfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders.

[0000038725-21-000092:notes:49]
Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period. Diluted earnings per common share is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.

[0000038725-21-000092:notes:50]
[same as prior period, unchanged from 0000038725-20-000208:notes:53]

[0000038725-21-000092:notes:51]
|  | First Quarter Ended |  |  |
| (In millions, except per share amounts) | March 31, 2021 |  | March 31, 2020 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 27.9 |  |  | $ | 10.6 |  |  |  |  |  |
| Less: Earnings allocated to participating securities | 0.2 |  |  | — |  |  |  |  |  |
| Net income available to common shareholders | $ | 27.7 |  |  | $ | 10.6 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 46.3 |  |  | 46.4 |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Non-participating employee stock options and performance awards | 0.6 |  |  | 0.4 |  |  |  |  |  |
| Diluted weighted average common shares outstanding | 46.9 |  |  | 46.8 |  |  |  |  |  |
| Basic earnings per share | $ | 0.60 |  |  | $ | 0.23 |  |  |  |  |  |
| Diluted earnings per share | $ | 0.59 |  |  | $ | 0.23 |  |  |  |  |  |

[0000038725-21-000092:notes:52]
There were 0.1 million and 0.3 million stock options outstanding for the first quarters ended March 31, 2021 and March 31, 2020, respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-21-000092:notes:53]
EQUITY ROLL FORWARD
The schedules below set forth equity changes in the first quarters ended March 31, 2021 and March 31, 2020:

[0000038725-21-000092:notes:54]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2020 | $ | 4,622 |  |  | $ | 283,420 |  |  | $ | 764,562 |  |  | $ | (52,666) |  |  | $ | (152,105) |  |  | $ | 2,116 |  |  | $ | 849,949 |  |  | $ | (245) |  |
| Net income |  |  |  |  | 27,880 |  |  |  |  |  |  | 207 |  |  | 28,087 |  |  | 76 |  |
| Dividends on common stock ($0.175/share) |  |  |  |  | (8,143) |  |  |  |  |  |  |  |  | (8,143) |  |  |  |
| Common stock issued | 14 |  |  | 5,069 |  |  |  |  |  |  |  |  |  |  | 5,083 |  |  |  |
| Common stock repurchased | (6) |  |  |  |  | (4,843) |  |  |  |  |  |  |  |  | (4,849) |  |  |  |
| Share-based compensation | 11 |  |  | 4,179 |  |  |  |  |  |  |  |  |  |  | 4,190 |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (11,449) |  |  | (66) |  |  | (11,515) |  |  | 1 |  |
| Pension liability, net of tax |  |  |  |  |  |  | 884 |  |  |  |  |  |  | 884 |  |  |  |
| Balance as of March 31, 2021 | $ | 4,641 |  |  | $ | 292,668 |  |  | $ | 779,456 |  |  | $ | (51,782) |  |  | $ | (163,554) |  |  | $ | 2,257 |  |  | $ | 863,686 |  |  | $ | (168) |  |

[0000038725-21-000092:notes:55]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2019 | $ | 4,639 |  |  | $ | 269,656 |  |  | $ | 712,460 |  |  | $ | (50,089) |  |  | $ | (140,121) |  |  | $ | 2,124 |  |  | $ | 798,669 |  |  | $ | (236) |  |
| Net Income |  |  |  |  | 10,643 |  |  |  |  |  |  | 187 |  |  | 10,830 |  |  | (38) |  |
| Dividends on common stock ($0.155/share) |  |  |  |  | (7,240) |  |  |  |  |  |  |  |  | (7,240) |  |  |  |
| Common stock issued | 2 |  |  | 869 |  |  |  |  |  |  |  |  |  |  | 871 |  |  |  |
| Common stock repurchased | (35) |  |  |  |  | (16,946) |  |  |  |  |  |  |  |  | (16,981) |  |  |  |
| Share-based compensation | 8 |  |  | 4,344 |  |  |  |  |  |  |  |  |  |  | 4,352 |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (37,727) |  |  | (24) |  |  | (37,751) |  |  | 29 |  |
| Pension liability, net of taxes |  |  |  |  |  |  | 716 |  |  |  |  |  |  | 716 |  |  |  |
| Balance as of March 31, 2020 | $ | 4,614 |  |  | $ | 274,869 |  |  | $ | 698,917 |  |  | $ | (49,373) |  |  | $ | (177,848) |  |  | $ | 2,287 |  |  | $ | 753,466 |  |  | $ | (245) |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-21-000092:notes:56]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)
Changes in accumulated other comprehensive income/(loss) by component for the three months ended March 31, 2021 and March 31, 2020, are summarized below:

[0000038725-21-000092:notes:57]
| (In millions) |  |  |  |  |  |
| For the three months ended March 31, 2021: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| Balance as of December 31, 2020 | $ | (152.2) |  |  | $ | (52.6) |  |  | $ | (204.8) |  |
| Other comprehensive income/(loss) before reclassifications | (11.4) |  |  | — |  |  | (11.4) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.9 |  |  | 0.9 |  |
| Net other comprehensive income/(loss) | (11.4) |  |  | 0.9 |  |  | (10.5) |  |
| Balance as of March 31, 2021 | $ | (163.6) |  |  | $ | (51.7) |  |  | $ | (215.3) |  |
| For the three months ended March 31, 2020: |  |  |  |  |  |
| Balance as of December 31, 2019 | $ | (140.2) |  |  | $ | (50.0) |  |  | $ | (190.2) |  |
| Other comprehensive income/(loss) before reclassifications | (37.7) |  |  | — |  |  | (37.7) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.7 |  |  | 0.7 |  |
| Net other comprehensive income/(loss) | (37.7) |  |  | 0.7 |  |  | (37.0) |  |
| Balance as of March 31, 2020 | $ | (177.9) |  |  | $ | (49.3) |  |  | $ | (227.2) |  |

[0000038725-21-000092:notes:58]
[same as prior period, unchanged from 0000038725-20-000208:notes:64]

[0000038725-21-000092:notes:59]
(2) Net of tax expense of $0.2 million and $0.2 million for the three months ended March 31, 2021 and March 31, 2020, respectively.

[0000038725-21-000092:notes:60]
[same as prior period, unchanged from 0000038725-20-000208:notes:66]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-21-000092:notes:61]
SEGMENT AND GEOGRAPHIC INFORMATION
The accounting policies of the operating segments are the same as those described in Note 1 of the Company's Form 10-K. Revenue is recognized based on the invoice price at the point in time when the customer obtains control of the product, which is typically upon shipment to the customer. The Water and Fueling segments include manufacturing operations and supply certain components and finished goods, both between segments and to the Distribution segment. The Company reports these product transfers between Water and Fueling as inventory transfers as a significant number of the Company's manufacturing facilities are shared across segments for scale and efficiency purposes. The Company reports intersegment transfers from Water to Distribution as intersegment revenue at market prices to properly reflect the commercial arrangement of vendor to customer that exists between the Water and Distribution segments.

[0000038725-21-000092:notes:62]
[same as prior period, unchanged from 0000038725-20-000208:notes:68]

[0000038725-21-000092:notes:63]
[same as prior period, unchanged from 0000038725-20-000208:notes:69]

[0000038725-21-000092:notes:64]
|  | First Quarter Ended |  |  |
| (In millions) | March 31, 2021 |  | March 31, 2020 |  |  |  |  |
|  | Net sales |
| Water Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | $ | 84.2 |  |  | $ | 70.9 |  |  |  |  |  |
| Latin America | 31.7 |  |  | 28.2 |  |  |  |  |  |
| Europe, Middle East & Africa | 44.4 |  |  | 38.2 |  |  |  |  |  |
| Asia Pacific | 20.2 |  |  | 13.8 |  |  |  |  |  |
| Intersegment sales |  |  |  |  |  |  |  |
| United States & Canada | 17.1 |  |  | 13.0 |  |  |  |  |  |
| Total sales | 197.6 |  |  | 164.1 |  |  |  |  |  |
| Distribution |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 95.7 |  |  | 60.4 |  |  |  |  |  |
| Intersegment sales | — |  |  | — |  |  |  |  |  |
| Total sales | 95.7 |  |  | 60.4 |  |  |  |  |  |
| Fueling Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 37.7 |  |  | 37.4 |  |  |  |  |  |
| All other | 19.1 |  |  | 17.9 |  |  |  |  |  |
| Intersegment sales | — |  |  | — |  |  |  |  |  |
| Total sales | 56.8 |  |  | 55.3 |  |  |  |  |  |
| Intersegment Eliminations/Other | (17.1) |  |  | (13.0) |  |  |  |  |  |
| Consolidated | $ | 333.0 |  |  | $ | 266.8 |  |  |  |  |  |
|  | First Quarter Ended |  |  |
|  | March 31, 2021 |  | March 31, 2020 |  |  |  |  |
|  | Operating income/(loss) |
| Water Systems | $ | 31.3 |  |  | $ | 18.8 |  |  |  |  |  |
| Distribution | 2.0 |  |  | (2.2) |  |  |  |  |  |
| Fueling Systems | 14.9 |  |  | 12.1 |  |  |  |  |  |
| Intersegment Eliminations/Other | (14.4) |  |  | (14.9) |  |  |  |  |  |
| Consolidated | $ | 33.8 |  |  | $ | 13.8 |  |  |  |  |  |

[0000038725-21-000092:notes:65]
|  | March 31, 2021 |  | December 31, 2020 |  |  |  |  |
|  | Total assets |  |  |  |  |
| Water Systems | $ | 634.7 |  |  | $ | 645.9 |  |  |  |  |  |
| Distribution | 270.9 |  |  | 249.0 |  |  |  |  |  |
| Fueling Systems | 267.2 |  |  | 268.9 |  |  |  |  |  |
| Other | 108.9 |  |  | 108.5 |  |  |  |  |  |
| Consolidated | $ | 1,281.7 |  |  | $ | 1,272.3 |  |  |  |  |  |

[0000038725-21-000092:notes:66]
[same as prior period, unchanged from 0000038725-20-000208:notes:72]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-21-000092:notes:67]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. The subject-matter expert has issued their preliminary report, which indicates that total damages incurred by Esso amounted to approximately 12 million euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company has retained experts to demonstrate that its products did not cause the damage, and in January 2021, submitted its response to the expert’s preliminary report for each station. The expert's response to the Company's report is due to the Court in June 2021. The Company cannot predict the ultimate outcome of this matter. Any exposure related to this matter is neither probable nor estimable at this time. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s results of operations.

[0000038725-21-000092:notes:68]
The Company is defending other various claims and legal actions which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-21-000092:notes:69]
At March 31, 2021, the Company had $6.8 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-21-000092:notes:70]
The Company provides warranties on most of its products. The warranty terms vary but are generally two years to five years from date of manufacture or one year to five years from date of installation. Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified. These estimates are established using historical information about the nature, frequency, and average cost of warranty claims. The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims. The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-21-000092:notes:71]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the first quarter ended March 31, 2021, are as follows:

[0000038725-21-000092:notes:72]
| (In millions) |  |  |
| Balance as of December 31, 2020 |  | $ | 9.7 |  |
| Accruals related to product warranties |  | 0.5 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (0.7) |  |
| Balance as of March 31, 2021 |  | $ | 9.5 |  |

[0000038725-21-000092:notes:73]
The Company maintains certain warehouses, distribution centers, office space, and equipment operating leases. The Company also has lease agreements that are classified as financing. These financing leases are immaterial to the Company.

[0000038725-21-000092:notes:74]
The Company utilizes interest rates from lease agreements unless the lease agreement does not provide a readily determinable rate. In these instances, the Company utilizes its incremental borrowing rate based on the information available as of the adoption of ASU 2016-02 or at the inception of any new leases entered into thereafter when determining the present value of future lease payments.

[0000038725-21-000092:notes:75]
Some of the Company’s leases include renewal options. The Company excludes these renewal options in the expected lease term unless the Company is reasonably certain that the option will be exercised.

[0000038725-21-000092:notes:76]
The components of the Company’s operating lease portfolio as of the first quarter ended March 31, 2021 are as follows:

[0000038725-21-000092:notes:77]
| Lease Cost (in millions): |  |  |  |
| Operating lease cost |  |  | $ | 3.0 |  |
| Short-term lease cost |  |  | 0.3 |  |
| Other Information: |  |  |  |
| Weighted-average remaining lease term |  |  | 4.0 years |
| Weighted-average discount rate |  |  | 4.0 | % |

[0000038725-21-000092:notes:78]
The minimum rental payments for non-cancellable operating leases as of March 31, 2021, are as follows:

[0000038725-21-000092:notes:79]
| (In millions) | 2021 | 2022 | 2023 | 2024 | 2025 | Thereafter |
| Future Minimum Rental Payments | $ | 10.0 |  | $ | 9.3 |  | $ | 6.3 |  | $ | 3.5 |  | $ | 2.1 |  | $ | 5.2 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-21-000092:notes:80]
SHARE-BASED COMPENSATION
The Franklin Electric Co., Inc. 2017 Stock Plan (the "2017 Stock Plan") is a stock-based compensation plan that provides for discretionary grants of stock options, stock awards, stock unit awards, and stock appreciation rights ("SARs") to key employees and non-employee directors. The number of shares that may be issued under the Plan is 1,400,000. Stock options and SARs reduce the number of available shares by one share for each share subject to the option or SAR, and stock awards and stock unit awards settled in shares reduce the number of available shares by 1.5 shares for every one share delivered.

[0000038725-21-000092:notes:81]
[same as prior period, unchanged from 0000038725-20-000208:notes:88]

[0000038725-21-000092:notes:82]
[same as prior period, unchanged from 0000038725-20-000208:notes:89]

[0000038725-21-000092:notes:83]
[same as prior period, unchanged from 0000038725-20-000208:notes:90]

[0000038725-21-000092:notes:84]
The Company also maintains the Amended and Restated Franklin Electric Co., Inc. Stock Plan (the "2009 Stock Plan") which, as amended in 2009, provided for discretionary grants of stock options and stock awards. The 2009 Stock Plan authorized 4,400,000 shares for issuance as follows:

[0000038725-21-000092:notes:85]
[same as prior period, unchanged from 0000038725-20-000208:notes:92]

[0000038725-21-000092:notes:86]
[same as prior period, unchanged from 0000038725-20-000208:notes:93]

[0000038725-21-000092:notes:87]
[same as prior period, unchanged from 0000038725-20-000208:notes:94]

[0000038725-21-000092:notes:88]
[same as prior period, unchanged from 0000038725-20-000208:notes:95]

[0000038725-21-000092:notes:89]
[same as prior period, unchanged from 0000038725-20-000208:notes:96]

[0000038725-21-000092:notes:90]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the first quarters ended March 31, 2021 and March 31, 2020 are as follows:

[0000038725-21-000092:notes:91]
|  |  | March 31, 2021 |  | March 31, 2020 |
| Risk-free interest rate |  | 0.66 | % |  | 1.39 | % |
| Dividend yield |  | 0.96 | % |  | 1.04 | % |
| Volatility factor |  | 34.98 | % |  | 29.45 | % |
| Expected term |  | 5.5 years |  | 5.5 years |

[0000038725-21-000092:notes:92]
A summary of the Company’s outstanding stock option activity and related information for the first quarter ended March 31, 2021 is as follows:

[0000038725-21-000092:notes:93]
| (Shares in thousands) |  | March 31, 2021 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,331 |  |  | $ | 41.90 |  |
| Granted |  | 152 |  |  | 73.14 |  |
| Exercised |  | (143) |  |  | 35.46 |  |
| Forfeited |  | — |  |  | — |  |
| Outstanding at end of period |  | 1,340 |  |  | $ | 46.12 |  |
| Expected to vest after applying forfeiture rate |  | 1,336 |  |  | $ | 46.07 |  |
| Vested and exercisable at end of period |  | 949 |  |  | $ | 39.71 |  |

[0000038725-21-000092:notes:94]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value as of March 31, 2021 is as follows:

[0000038725-21-000092:notes:95]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 6.08 years |  | $ | 31,522 |  |
| Expected to vest after applying forfeiture rate |  | 6.07 years |  | $ | 31,499 |  |
| Vested and exercisable at end of period |  | 4.93 years |  | $ | 28,004 |  |

[0000038725-21-000092:notes:96]
The total intrinsic value of options exercised during the first quarters ended March 31, 2021 and March 31, 2020 was $5.8 million and $0.5 million, respectively.

[0000038725-21-000092:notes:97]
As of March 31, 2021, there was $1.7 million of total unrecognized compensation cost related to non-vested stock options granted under the stock plans. That cost is expected to be recognized over a weighted-average period of 1.99 years.

[0000038725-21-000092:notes:98]
[same as prior period, unchanged from 0000038725-20-000208:notes:105]

[0000038725-21-000092:notes:99]
A summary of the Company’s restricted stock/stock unit award activity and related information for the first quarter ended March 31, 2021 is as follows:

[0000038725-21-000092:notes:100]
| (Shares in thousands) |  | March 31, 2021 |
| Restricted Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 403 |  |  | $ | 49.34 |  |
| Awarded |  | 92 |  |  | 73.15 |  |
| Vested |  | (107) |  |  | 41.45 |  |
| Forfeited |  | (7) |  |  | 43.34 |  |
| Non-vested at end of period |  | 381 |  |  | $ | 57.41 |  |

[0000038725-21-000092:notes:101]
As of March 31, 2021, there was $12.7 million of total unrecognized compensation cost related to non-vested restricted stock/stock unit awards granted under the stock plans. That cost is expected to be recognized over a weighted-average period of 1.61 years.


## us-gaap:SubsequentEventsTextBlock

[0000038725-21-000092:notes:102]
16. SUBSEQUENT EVENT

[0000038725-21-000092:notes:103]
On April 1, 2021, the Company acquired 100 percent of the ownership interests in Puronics, Inc. and its wholly owned subsidiaries, headquartered in Livermore, California,  for approximately $28 million. Puronics is a residential and commercial water treatment products and services provider and will be included as a part of the Water Systems segment of the Company. The initial accounting for this acquisition is incomplete, and the Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2020, as the results of operations for this acquisition is immaterial.
