# FELE MD&A — 0000038725-21-000092


## mdna

[0000038725-21-000092:mdna:1]
ITEM 2. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000038725-21-000092:mdna:2]
First Quarter 2021 vs. First Quarter 2020

[0000038725-21-000092:mdna:3]
[same as prior period, unchanged from 0000038725-20-000208:mdna:3]

[0000038725-21-000092:mdna:4]
Sales in the first quarter of 2021 increased from the first quarter of last year. Sales in the quarter increased by $66.2 million, or about 25 percent, due to higher Water and Distribution sales volumes, achieved price realization, and acquisitions. The Company's consolidated gross profit was $115.5 million for the first quarter of 2021, an increase from the prior year’s first quarter. The gross profit as a percent of net sales was 34.7 percent in the first quarter of 2021 versus 33.9 percent during the first quarter 2020 and improved primarily due to better price realization and product sales mix. For the first quarter of 2021, diluted earnings per share were $0.59, up from the first quarter of 2020 diluted earnings per share of $0.23.

[0000038725-21-000092:mdna:5]
[same as prior period, unchanged from 0000038725-20-000208:mdna:9]

[0000038725-21-000092:mdna:6]
[same as prior period, unchanged from 0000038725-20-000208:mdna:10]

[0000038725-21-000092:mdna:7]
Net sales in the first quarter of 2021 were $333.0 million, an increase of $66.2 million or about 25 percent compared to 2020 first quarter sales of $266.8 million. The sales increase from acquisition related sales was $23.5 million. Sales revenue decreased by $2.9 million or about 1 percent in the first quarter of 2021 due to foreign currency translation. Excluding acquisitions and the impact of foreign currency translation, the Company’s organic sales growth was about 17 percent.

[0000038725-21-000092:mdna:8]
|  | Net Sales |
| (In millions) | Q1 2021 |  | Q1 2020 |  | 2021 v 2020 |
| Water Systems | $ | 197.6 |  |  | $ | 164.1 |  |  | $ | 33.5 |  |
| Fueling Systems | 56.8 |  |  | 55.3 |  |  | $ | 1.5 |  |
| Distribution | 95.7 |  |  | 60.4 |  |  | $ | 35.3 |  |
| Eliminations/Other | (17.1) |  |  | (13.0) |  |  | $ | (4.1) |  |
| Consolidated | $ | 333.0 |  |  | $ | 266.8 |  |  | $ | 66.2 |  |

[0000038725-21-000092:mdna:9]
[same as prior period, unchanged from 0000038725-20-000208:mdna:13]

[0000038725-21-000092:mdna:10]
Water Systems revenues were $197.6 million in the first quarter 2021, an increase of $33.5 million or about 20 percent versus the first quarter 2020 sales of $164.1 million. In the first quarter of 2021, sales from businesses acquired since the first quarter of 2020 were $7.2 million. Sales were decreased by $3.7 million or 2 percent in the quarter due to foreign currency translation. Water Systems sales were up about 18 percent, excluding acquisitions and foreign currency translation, in the first quarter of 2021 versus the first quarter of 2020.

[0000038725-21-000092:mdna:11]
Water Systems sales in the U.S. and Canada were up about 21 percent compared to the first quarter 2020. Foreign currency translation increased sales by about 1 percent. In the first quarter of 2021, sales from businesses acquired since the first quarter of 2020 were $7.2 million. Sales of groundwater pumping equipment increased by about 24 percent and sales of surface pumping equipment increased by about 10 percent versus the first quarter 2020, due to strong end market demand. These increases were offset by lower sales of dewatering equipment, which were down by about 8 percent, due to lower sales in the rental channel.

[0000038725-21-000092:mdna:12]
Water Systems sales in markets outside the U.S. and Canada increased by 20 percent overall. Foreign currency translation decreased sales by 6 percent. Outside the U.S. and Canada, Water Systems organic sales increased by 26 percent, driven by higher sales in all regions of the world: Latin America, Asia Pacific, Europe, the Middle East, and Africa markets.

[0000038725-21-000092:mdna:13]
[same as prior period, unchanged from 0000038725-20-000208:mdna:18]

[0000038725-21-000092:mdna:14]
Fueling Systems sales were $56.8 million in the first quarter of 2021, an increase of $1.5 million or about 3 percent versus the first quarter 2020 sales of $55.3 million. Fueling Systems sales were increased by $0.8 million in the quarter due to foreign currency translation. Fueling Systems sales, excluding foreign currency translation, increased by about 1 percent.

[0000038725-21-000092:mdna:15]
Fueling Systems sales in the U.S. and Canada increased by about 1 percent compared to the first quarter 2020. The increase was principally in the pumping and fuel management systems product lines. Outside the U.S. and Canada, Fueling Systems revenues increased by about 7 percent, driven by higher sales in Latin America, Europe, the Middle East and Africa.

[0000038725-21-000092:mdna:16]
Net Sales - Distribution

[0000038725-21-000092:mdna:17]
Distribution sales were $95.7 million in the first quarter 2021, an increase of $35.3 million or about 58 percent versus first quarter 2020 sales of $60.4 million. In the first quarter of 2021, sales from businesses acquired since the first quarter of 2020 were $16.3 million. The Distribution segment organic sales increased about 31 percent compared to the first quarter of 2020. Broad based demand in all regions and product categories, customer purchase pull forwards and the Texas winter storm combined to drive the organic revenue growth compared to the first quarter 2020.

[0000038725-21-000092:mdna:18]
[same as prior period, unchanged from 0000038725-20-000208:mdna:23]

[0000038725-21-000092:mdna:19]
Cost of sales as a percentage of net sales for the first quarters of 2021 and 2020 was 65.3 percent and 66.1 percent, respectively. Correspondingly, gross profit margin increased to 34.7 percent from 33.9 percent. The Company’s consolidated gross profit was $115.5 million for the first quarter of 2021, an increase from the first quarter of 2020 gross profit of $90.3 million. The gross profit margin improved primarily due to better price realization, favorable product sales mix shifts and cost management.

[0000038725-21-000092:mdna:20]
Selling, General, and Administrative ("SG&A")

[0000038725-21-000092:mdna:21]
Selling, general, and administrative (SG&A) expenses were $81.6 million in the first quarter of 2021 compared to $75.6 million in the first quarter of 2020. SG&A expenses from acquired businesses were $4.9 million and excluding the acquired entities, the Company’s SG&A expenses in the first quarter of 2021 were $76.7 million, an increase of about 1 percent from the first quarter 2020.

[0000038725-21-000092:mdna:22]
[same as prior period, unchanged from 0000038725-20-000208:mdna:27]

[0000038725-21-000092:mdna:23]
There were $0.2 million of restructuring expenses for the first quarter of 2021. Restructuring expenses for the first quarter of 2021 were $0.1 million in the Water segment related to continued miscellaneous manufacturing realignment activities, as well as $0.1 million in the Distribution segment related to miscellaneous branch closings and consolidation.

[0000038725-21-000092:mdna:24]
There were $0.9 million of restructuring expenses for the first quarter of 2020. Restructuring expenses for the first quarter of 2020 were $0.6 million in the Water and $0.2 million in Fueling segments and related to continued miscellaneous manufacturing realignment activities, as well as $0.1 million in the Distribution segment related to miscellaneous branch closings and consolidation.

[0000038725-21-000092:mdna:25]
[same as prior period, unchanged from 0000038725-20-000208:mdna:29]

[0000038725-21-000092:mdna:26]
Operating income was $33.8 million in the first quarter of 2021, up $20.0 million or about 144 percent from $13.8 million in the first quarter of 2020.

[0000038725-21-000092:mdna:27]
|  |  | Operating income (loss) |
| (In millions) |  | Q1 2021 |  | Q1 2020 |  | 2021 v 2020 |
| Water Systems |  | $ | 31.3 |  |  | $ | 18.8 |  |  | $ | 12.5 |  |
| Fueling Systems |  | 14.9 |  |  | 12.1 |  |  | 2.8 |  |
| Distribution |  | 2.0 |  |  | (2.2) |  |  | 4.2 |  |
| Eliminations/Other |  | (14.4) |  |  | (14.9) |  |  | 0.5 |  |
| Consolidated |  | $ | 33.8 |  |  | $ | 13.8 |  |  | $ | 20.0 |  |

[0000038725-21-000092:mdna:28]
[same as prior period, unchanged from 0000038725-20-000208:mdna:32]

[0000038725-21-000092:mdna:29]
Water Systems operating income was $31.3 million in the first quarter 2021, up $12.5 million versus the first quarter 2020. Operating income increased in Water Systems primarily due to higher sales volume. The first quarter operating income margin was 15.8 percent, up 430 basis points from 11.5 percent in the first quarter of 2020. Operating income margin increased in Water Systems primarily due to leverage from higher sales, price realization, and improved product sales mix.

[0000038725-21-000092:mdna:30]
[same as prior period, unchanged from 0000038725-20-000208:mdna:34]

[0000038725-21-000092:mdna:31]
Fueling Systems operating income was $14.9 million in the first quarter of 2021 compared to $12.1 million in the first quarter of 2020. The increase in operating income was primarily related to higher sales and cost management. The first quarter Fueling Systems operating income margin was 26.2 percent, an increase of 430 basis points from the 21.9 percent of net sales in the first quarter of 2020. Operating income margin increased due to price realization and cost management.

[0000038725-21-000092:mdna:32]
[same as prior period, unchanged from 0000038725-20-000208:mdna:37]

[0000038725-21-000092:mdna:33]
The Distribution segment recorded operating income of $2.0 million in the first quarter of 2021 compared to a $2.2 million loss in the first quarter of 2020. Distribution’s increase in operating income was primarily due to higher sales and the Gicon

[0000038725-21-000092:mdna:34]
acquisition compared to the first quarter 2020. Distribution’s operating income margin was 2.1 percent in the first quarter of 2021 versus a negative 3.6 percent of net sales in the first quarter of 2020. Operating income margin improved due to leverage on fixed cost from higher sales, price realization and cost management.

[0000038725-21-000092:mdna:35]
[same as prior period, unchanged from 0000038725-20-000208:mdna:39]

[0000038725-21-000092:mdna:36]
Operating income-Eliminations/Other is composed primarily of intersegment sales and profit eliminations and unallocated general and administrative expenses. The intersegment profit elimination impact in the first quarter of 2021 versus the first quarter of 2020 was less expense, or an improvement, of $0.3 million. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer. General and administrative expenses were lower by $0.2 million or about 2 percent to last year.

[0000038725-21-000092:mdna:37]
[same as prior period, unchanged from 0000038725-20-000208:mdna:41]

[0000038725-21-000092:mdna:38]
Interest expense for the first quarters of 2021 and 2020 was $1.1 million and $1.2 million, respectively.

[0000038725-21-000092:mdna:39]
[same as prior period, unchanged from 0000038725-20-000208:mdna:43]

[0000038725-21-000092:mdna:40]
Other income or expense was a loss in the first quarter of 2021 of $0.1 million and a loss of $0.2 million in the first quarter of 2020.

[0000038725-21-000092:mdna:41]
[same as prior period, unchanged from 0000038725-20-000208:mdna:45]

[0000038725-21-000092:mdna:42]
Foreign currency-based transactions produced a loss for the first quarter of 2021 of $0.1 million, primarily due to the Argentinian Peso relative to the U.S. dollar. Foreign currency-based transactions produced a gain for the first quarter of 2020 of $1.0 million, primarily due to the Argentinian Peso relative to the U.S. dollar.

[0000038725-21-000092:mdna:43]
[same as prior period, unchanged from 0000038725-20-000208:mdna:47]

[0000038725-21-000092:mdna:44]
The provision for income taxes in the first quarter of 2021 and 2020 was $4.4 million and $2.6 million, respectively. The effective tax rate for the first quarter of 2021 was about 14 percent, and before the impact of discrete events, was about 20 percent. The effective tax rate for the first quarter of 2020 was about 19 percent, and before the impact of discrete events, was about 20 percent. The decrease in the effective tax rate was primarily a result of larger net favorable discrete events, including increased excess tax benefits from share-based compensation and a deferred tax benefit from a  tax election made in a foreign jurisdiction, recorded in the first quarter of 2021 compared to the first quarter of 2020. The tax rate as a percentage of pre-tax earnings for the full year of 2021 is projected to be about 20 percent, compared to the full year 2020 tax rate of about 21 percent, both before discrete adjustments.

[0000038725-21-000092:mdna:45]
[same as prior period, unchanged from 0000038725-20-000208:mdna:49]

[0000038725-21-000092:mdna:46]
Net income for the first quarter of 2021 was $28.2 million compared to the prior year first quarter net income of $10.8 million. Net income attributable to Franklin Electric Co., Inc. for the first quarter of 2021 was $27.9 million, or $0.59 per diluted share, compared to the prior year first quarter net income attributable to Franklin Electric Co., Inc. of $10.6 million or $0.23 per diluted share.

[0000038725-21-000092:mdna:47]
[same as prior period, unchanged from 0000038725-20-000208:mdna:95]

[0000038725-21-000092:mdna:48]
[same as prior period, unchanged from 0000038725-20-000208:mdna:96]

[0000038725-21-000092:mdna:49]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at March 31, 2021 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-21-000092:mdna:50]
As of March 31, 2021 the Company had a $300.0 million revolving credit facility. The facility is scheduled to mature on October 28, 2021. As of March 31, 2021, the Company had $296.0 million borrowing capacity under the Credit Agreement as $4.0 million in letters of commercial and standby letters of credit were outstanding and undrawn and no revolver borrowings were drawn and outstanding.

[0000038725-21-000092:mdna:51]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement") with a remaining borrowing capacity of  $125.0 million as of March 31, 2021. The Company also has other long-term debt borrowings outstanding as of March 31, 2021. See Note 9 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-21-000092:mdna:52]
At March 31, 2021, the Company had $74.4 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations. There is currently no need or intent to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-21-000092:mdna:53]
[same as prior period, unchanged from 0000038725-20-000208:mdna:101]

[0000038725-21-000092:mdna:54]
The following table summarizes significant sources and uses of cash and cash equivalents for the first three months of 2021 and 2020.

[0000038725-21-000092:mdna:55]
| (in millions) |  | 2021 |  | 2020 |
| Net cash flows from operating activities |  | $ | 5.4 |  |  | $ | (4.7) |  |
| Net cash flows from investing activities |  | (6.7) |  |  | (11.1) |  |
| Net cash flows from financing activities |  | (8.4) |  |  | (3.7) |  |
| Impact of exchange rates on cash and cash equivalents |  | (2.8) |  |  | (4.9) |  |
| Change in cash and cash equivalents |  | $ | (12.5) |  |  | $ | (24.4) |  |

[0000038725-21-000092:mdna:56]
[same as prior period, unchanged from 0000038725-20-000208:mdna:104]

[0000038725-21-000092:mdna:57]
2021 vs. 2020

[0000038725-21-000092:mdna:58]
Net cash provided by operating activities was $5.4 million for the three months ended March 31, 2021 compared to $4.7 million used in operating activities for the three months ended March 31, 2020. The increase in cash provided by operating activities was due to increased net income of $17.4 million and increased accrued income taxes of $2.4 million offset by an increase of $12.1 million in working capital requirements, primarily driven by increased receivables due to higher sales.

[0000038725-21-000092:mdna:59]
[same as prior period, unchanged from 0000038725-20-000208:mdna:107]

[0000038725-21-000092:mdna:60]
2021 vs. 2020

[0000038725-21-000092:mdna:61]
Net cash used in investing activities was $6.7 million for the three months ended March 31, 2021 compared to $11.1 million used in investing activities for the  three months ended March 31, 2020. The decrease in cash used in investing activities was attributable to decreased acquisition activity partially offset by increased property, plant, and equipment purchases.

[0000038725-21-000092:mdna:62]
[same as prior period, unchanged from 0000038725-20-000208:mdna:110]

[0000038725-21-000092:mdna:63]
2021 vs. 2020

[0000038725-21-000092:mdna:64]
Net cash used in financing activities was $8.4  million for the three months ended March 31, 2021 compared to $3.7 million used in financing activities for the three months ended March 31, 2020. The increase in cash used in financing activities was attributable to a decrease in net debt proceeds of approximately $20.1 million offset by an increase of $4.2 million in issuance of common stock, primarily through stock option exercises, and decreased common stock repurchases of $12.1 million.

[0000038725-21-000092:mdna:65]
[same as prior period, unchanged from 0000038725-20-000208:mdna:113]
