# FELE 8-K — 0000038725-19-000221 filed 2019-10-29

## item codes, every 8-K on or before 2019-11-05

- 2019-11-04 0000038725-19-000234 — 7.01, 9.01
- 2019-10-29 0000038725-19-000221 — 2.02, 9.01
- 2019-08-01 0000038725-19-000193 — 7.01, 9.01
- 2019-07-23 0000038725-19-000178 — 2.02, 9.01
- 2019-05-07 0000038725-19-000140 — 5.03, 9.01
- 2019-05-03 0000038725-19-000124 — 5.07
- 2019-05-03 0000038725-19-000122 — 7.01, 9.01
- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2019-11-05

- none on or before 2019-11-05

## item 2.02 — earnings release, exhibit 99.1

[0000038725-19-000221:8k_2_02:1]
EX-99.1
2
a201910298-kexhibit991.htm
EX-99.1

[0000038725-19-000221:8k_2_02:2]
Document

[0000038725-19-000221:8k_2_02:3]
Exhibit 99.1

[0000038725-19-000221:8k_2_02:4]
For Immediate Release

[0000038725-19-000221:8k_2_02:5]
For Further Information

[0000038725-19-000221:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-19-000221:8k_2_02:7]
260-824-2900

[0000038725-19-000221:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS RECORD THIRD

[0000038725-19-000221:8k_2_02:9]
QUARTER 2019 SALES AND EARNINGS

[0000038725-19-000221:8k_2_02:10]
Fort Wayne, IN - October 29, 2019 - Franklin Electric Co., Inc. (NASDAQ: FELE) reported record third quarter 2019 GAAP fully diluted earnings per share (EPS) of $0.72, versus a GAAP fully diluted EPS in the third quarter 2018 of $0.63.  Third quarter 2019 sales were a record $348.4 million, compared to 2018 third quarter sales of $341.9 million. Third quarter EPS before the impact of restructuring expenses was also a record at $0.73 compared to 2018 third quarter EPS before restructuring of $0.64 (see table below for a reconciliation of GAAP EPS to EPS before restructuring).

[0000038725-19-000221:8k_2_02:11]
Gregg Sengstack, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-19-000221:8k_2_02:12]
“Our third quarter earnings were a record for any third quarter in the Company’s history.  Our earnings per share grew by 14 percent from the third quarter 2018. Our improvement in earnings was led by our Distribution segment which grew operating income by over 70 percent as a result of more favorable weather conditions in much of the United States and acquisitions.  Our free cash flow after capital expenditures is about 65 percent higher through the first three quarters of the year versus the same period of 2018.  Despite these earnings and cash generation improvements, organic sales growth was below expectations in our Water and Fueling systems businesses.”

[0000038725-19-000221:8k_2_02:13]
Key Performance Indicators:

[0000038725-19-000221:8k_2_02:14]
| Earnings Before and After Restructuring |  | For the Third Quarter |  |  |  |  |  |  |
| (in millions) |  | 2019 | 2018 | Change |  |  |  |  |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 33.9 |  | $ | 30.0 |  | 13 | % |  |  |  |  |
| Allocated Earnings |  | $ | (0.2) |  | $ | (0.2) |  |  |  |  |  |  |
| Earnings for EPS Calculations |  | $ | 33.7 |  | $ | 29.8 |  | 13 | % |  |  |  |  |
| Restructuring (before tax): |  | $ | 0.4 |  | $ | 0.3 |  |  |  |  |  |  |
| Restructuring, net of tax: |  | $ | 0.3 |  | $ | 0.2 |  |  |  |  |  |  |
| Earnings Before Restructuring |  | $ | 34.0 |  | $ | 30.0 |  | 13 | % |  |  |  |  |
| Earnings Per Share |  | For the Third Quarter |  |  |  |  |  |  |
| Before and After Restructuring |  | 2019 |  | 2018 |  | Change |  |  |  |  |
| (in millions except Earnings Per Share) |  |  |  |  |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 46.7 |  | 47.2 |  | (1) | % |  |  |  |  |
| Fully Diluted Earnings Per Share (“EPS”) Reported |  | $ | 0.72 |  | $ | 0.63 |  | 14 | % |  |  |  |  |
| Restructuring Per Share, net of tax |  | $ | 0.01 |  | $ | 0.01 |  |  |  |  |  |  |
| Fully Diluted EPS Before Restructuring |  | $ | 0.73 |  | $ | 0.64 |  | 14 | % |  |  |  |  |

[0000038725-19-000221:8k_2_02:15]
|  | Net Sales |  |  |  |  |  |  |  |  |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q3 2018 | $ | 110.2 |  | $ | 31.0 |  | $ | 40.8 |  | $ | 17.3 |  | $ | 199.3 |  | $ | 77.8 |  | $ | 78.0 |  | $ | (13.2) |  | $ | 341.9 |  |
| Q3 2019 | $ | 111.4 |  | $ | 30.6 |  | $ | 40.8 |  | $ | 17.0 |  | $ | 199.8 |  | $ | 78.1 |  | $ | 87.0 |  | $ | (16.5) |  | $ | 348.4 |  |
| Change | $ | 1.2 |  | $ | (0.4) |  | $ | — |  | $ | (0.3) |  | $ | 0.5 |  | $ | 0.3 |  | $ | 9.0 |  | $ | (3.3) |  | $ | 6.5 |  |
| % Change | 1 | % | (1) | % | — | % | (2) | % | — | % | — | % | 12 | % |  | 2 | % |
| Foreign currency translation | $ | (0.4) |  | $ | (2.3) |  | $ | (2.0) |  | $ | (0.2) |  | $ | (4.9) |  | $ | (0.9) |  | $ | — |  |  |  |
| % Change | — | % | (7) | % | (5) | % | (1) | % | (2) | % | (1) | % | — | % |  |  |
| Acquisitions | $ | 2.3 |  | $ | — |  | $ | — |  | $ | — |  | $ | 2.3 |  | $ | — |  | $ | 7.3 |  |  |  |
| Volume/Price | $ | (0.7) |  | $ | 1.9 |  | $ | 2.0 |  | $ | (0.1) |  | $ | 3.1 |  | $ | 1.2 |  | $ | 1.7 |  |  |  |
| % Change | (1) | % | 6 | % | 5 | % | (1) | % | 2 | % | 2 | % | 2 | % |  |  |

[0000038725-19-000221:8k_2_02:16]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Third Quarter 2019 |  |  |  |  |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 28.4 |  | $ | 21.6 |  | $ | 5.9 |  | $ | (13.2) |  | $ | 42.7 |  |
| % Operating Income To Net Sales | 14.2 | % | 27.7 | % | 6.8 | % |  | 12.3 | % |
| Restructuring | $ | 0.4 |  | $ | — |  | $ | — |  | $ | — |  | $ | 0.4 |  |
| Operating Income/(Loss) Before Restructuring | $ | 28.8 |  | $ | 21.6 |  | $ | 5.9 |  | $ | (13.2) |  | $ | 43.1 |  |
| % Operating Income to Net Sales Before Restructuring | 14.4 | % | 27.7 | % | 6.8 | % |  | 12.4 | % |
|  | For the Third Quarter 2018 |  |  |  |  |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 28.4 |  | $ | 20.9 |  | $ | 3.1 |  | $ | (12.3) |  | $ | 40.1 |  |
| % Operating Income To Net Sales | 14.2 | % | 26.9 | % | 4.0 | % |  | 11.7 | % |
| Restructuring | $ | — |  | $ | — |  | $ | 0.3 |  | $ | — |  | $ | 0.3 |  |
| Operating Income/(Loss) Before Restructuring | $ | 28.4 |  | $ | 20.9 |  | $ | 3.4 |  | $ | (12.3) |  | $ | 40.4 |  |
| % Operating Income to Net Sales Before Restructuring | 14.2 | % | 26.9 | % | 4.4 | % |  | 11.8 | % |

[0000038725-19-000221:8k_2_02:17]
Water Systems

[0000038725-19-000221:8k_2_02:18]
Water Systems sales were $199.8 million in the third quarter 2019, versus the third quarter 2018 sales of $199.3 million.  In the third quarter of 2019, sales from businesses acquired since the third quarter of 2018 were $2.3 million.  Water Systems sales decreased 2 percent in the quarter due to foreign currency translation. Water Systems organic sales were higher by 2 percent compared to the third quarter of 2018.

[0000038725-19-000221:8k_2_02:19]
Water Systems sales in the U.S. and Canada increased by 1 percent overall compared to the third quarter 2018, primarily related to sales from acquisitions.  Sales of dewatering equipment increased by 2 percent on the continued diversification of product sales and channels.  Sales of groundwater pumping equipment increased by 1 percent versus the third quarter 2018.  The increase in groundwater pumping systems was primarily due to improved weather conditions in North America and increased sales to the Company’s Headwater Distribution segment. Sales of surface pumping equipment decreased by 4 percent on lower sales of both wastewater and condensation removal equipment.

[0000038725-19-000221:8k_2_02:20]
Water Systems sales in markets outside the U.S. and Canada declined by 1 percent overall.  Foreign currency translation decreased sales by 5 percent.  Outside the U.S. and Canada, Water Systems organic sales increased by 4 percent, primarily driven by higher sales in Latin America and Europe, Middle East and Africa markets, partially offset by sales declines in Asia Pacific.

[0000038725-19-000221:8k_2_02:21]
Water Systems operating income was $28.4 million in the third quarter 2019, compared to $28.4 million in the third quarter 2018.

[0000038725-19-000221:8k_2_02:22]
Fueling Systems

[0000038725-19-000221:8k_2_02:23]
Fueling Systems sales were $78.1 million in the third quarter 2019 compared to third quarter 2018 sales of $77.8 million and were a record for any third quarter.  Fueling Systems sales decreased 1 percent in the quarter due to foreign currency translation. Fueling Systems organic sales increased 2 percent compared to the third quarter of 2018.

[0000038725-19-000221:8k_2_02:24]
Fueling Systems sales in the U.S. and Canada increased by 10 percent compared to the third quarter 2018.  The increase was principally in the fuel management systems and service station hardware product lines.  Outside the U.S. and Canada, Fueling Systems revenues declined by 6 percent, primarily due to lower sales in China.

[0000038725-19-000221:8k_2_02:25]
Fueling Systems operating income was a record for any third quarter at $21.6 million compared to $20.9 million in the third quarter of 2018.  Fueling Systems operating income was higher in the quarter due to favorable product sales mix.

[0000038725-19-000221:8k_2_02:26]
Distribution

[0000038725-19-000221:8k_2_02:27]
Distribution sales were $87.0 million in the third quarter 2019, versus third quarter 2018 sales of $78.0 million.  In the third quarter of 2019, sales from businesses acquired since the third quarter of 2018 were $7.3 million.  The Distribution segment organic sales increased 2 percent compared to the third quarter of 2018.

[0000038725-19-000221:8k_2_02:28]
The Distribution segment operating income was $5.9 million in the third quarter of 2019, compared to $3.1 million in the third quarter of 2018.  Distribution’s operating income was higher in the third quarter due to higher sales volumes and acquisitions and leverage on operating expenses.

[0000038725-19-000221:8k_2_02:29]
Overall

[0000038725-19-000221:8k_2_02:30]
The Company’s consolidated gross profit was $117.6 million for the third quarter of 2019, an increase from the third quarter of 2018 gross profit of $113.0 million.  The gross profit increase was primarily due to higher Fueling Systems and Distribution sales.  The gross profit as a percent of net sales was 33.8 percent in the third quarter of 2019 versus 33.0 percent in the third quarter of 2018.

[0000038725-19-000221:8k_2_02:31]
Selling, general, and administrative (SG&A) expenses were $74.5 million in the third quarter of 2019 compared to $72.5 million in the third quarter of 2018. SG&A expenses from acquired businesses was $1.5 million and excluding the acquired entities, the Company’s SG&A expenses in the third quarter of 2019 were $73.0 million, an increase of less than 1 percent from the third quarter 2018, partially due to the offsetting effect of foreign currency translation versus the prior year.

[0000038725-19-000221:8k_2_02:32]
Commenting on the outlook for the remainder of 2019, Mr. Sengstack said:

[0000038725-19-000221:8k_2_02:33]
“Based on our third quarter results and our current view of our end markets, we expect our fourth quarter to be similar to last year in both revenue and earnings.  This would result in full year 2019 earnings per share before restructuring at the low end of our current guidance.”

[0000038725-19-000221:8k_2_02:34]
A conference call to review earnings and other developments in the business will commence at 9:00 am Eastern Time.  The third quarter 2019 earnings call will be available via a live webcast.  The webcast will be available in a listen only mode by going to:

[0000038725-19-000221:8k_2_02:35]
https://edge.media-server.com/mmc/p/rxbyt5hx

[0000038725-19-000221:8k_2_02:36]
If you intend to ask questions during the call, please dial in using 877.643.7158 for domestic calls and 914.495.8565 for international calls.  The conference ID is: 5988134.

[0000038725-19-000221:8k_2_02:37]
A replay of the conference call will be available Tuesday, October 29, 2019 at 12:00 noon Eastern Time through noon Eastern Time on Tuesday, November 5, 2019, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls.  The replay passcode is: 5988134.

[0000038725-19-000221:8k_2_02:38]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-19-000221:8k_2_02:39]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |  |  |  |  |  |  |  |  |  |  |  |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |  |  |  |  |  |  |  |  |  |  |  |
| (Unaudited) |  |  |  |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |  |  |  |  |
|  | Third Quarter Ended |  |  |  | Nine Months Ended |  |  |  |  |  |  |
|  | September 30, 2019 |  | September 30, 2018 |  | September 30, 2019 |  | September 30, 2018 |  |  |  |  |
| Net sales | $ | 348,416 |  |  | $ | 341,866 |  |  | $ | 994,471 |  |  | $ | 981,466 |  |  |  |  |  |
| Cost of sales | 230,793 |  |  | 228,900 |  |  | 667,624 |  |  | 653,442 |  |  |  |  |  |
| Gross profit | 117,623 |  |  | 112,966 |  |  | 326,847 |  |  | 328,024 |  |  |  |  |  |
| Selling, general, and administrative expenses | 74,500 |  |  | 72,483 |  |  | 226,581 |  |  | 223,723 |  |  |  |  |  |
| Restructuring expense | 404 |  |  | 346 |  |  | 1,735 |  |  | 990 |  |  |  |  |  |
| Operating income | 42,719 |  |  | 40,137 |  |  | 98,531 |  |  | 103,311 |  |  |  |  |  |
| Interest expense | (2,037) |  |  | (2,443) |  |  | (6,674) |  |  | (7,477) |  |  |  |  |  |
| Other income/(expense), net | (250) |  |  | (422) |  |  | (303) |  |  | (581) |  |  |  |  |  |
| Foreign exchange income/(expense) | 2,082 |  |  | (1,601) |  |  | 2,166 |  |  | (3,151) |  |  |  |  |  |
| Income before income taxes | 42,514 |  |  | 35,671 |  |  | 93,720 |  |  | 92,102 |  |  |  |  |  |
| Income tax expense | 8,439 |  |  | 5,739 |  |  | 17,706 |  |  | 10,916 |  |  |  |  |  |
| Net income | $ | 34,075 |  |  | $ | 29,932 |  |  | $ | 76,014 |  |  | $ | 81,186 |  |  |  |  |  |
| Less: Net (income)/loss attributable to noncontrolling interests | (168) |  |  | 74 |  |  | (306) |  |  | 491 |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 33,907 |  |  | $ | 30,006 |  |  | $ | 75,708 |  |  | $ | 81,677 |  |  |  |  |  |
| Income per share: |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.73 |  |  | $ | 0.64 |  |  | $ | 1.62 |  |  | $ | 1.74 |  |  |  |  |  |
| Diluted | $ | 0.72 |  |  | $ | 0.63 |  |  | $ | 1.61 |  |  | $ | 1.72 |  |  |  |  |  |

[0000038725-19-000221:8k_2_02:40]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |  |  |
| (Unaudited) |  |  |  |
| (In thousands) |  |  |  |
|  | September 30, 2019 |  | December 31, 2018 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 47,805 |  |  | $ | 59,173 |  |
| Receivables | 198,052 |  |  | 172,899 |  |
| Inventories | 333,810 |  |  | 314,049 |  |
| Other current assets | 37,900 |  |  | 33,758 |  |
| Total current assets | 617,567 |  |  | 579,879 |  |
| Property, plant, and equipment, net | 197,712 |  |  | 207,064 |  |
| Right-of-use asset, net | 24,822 |  |  | — |  |
| Goodwill and other assets | 396,839 |  |  | 395,422 |  |
| Total assets | $ | 1,236,940 |  |  | $ | 1,182,365 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 94,531 |  |  | $ | 76,652 |  |
| Accrued expenses and other current liabilities | 73,580 |  |  | 67,230 |  |
| Current lease liability | 8,337 |  |  | — |  |
| Current maturities of long-term debt and short-term borrowings | 80,797 |  |  | 111,975 |  |
| Total current liabilities | 257,245 |  |  | 255,857 |  |
| Long-term debt | 93,123 |  |  | 94,379 |  |
| Long-term lease liability | 16,487 |  |  | — |  |
| Income taxes payable non-current | 11,965 |  |  | 10,881 |  |
| Deferred income taxes | 27,925 |  |  | 28,949 |  |
| Employee benefit plans | 33,404 |  |  | 38,020 |  |
| Other long-term liabilities | 19,964 |  |  | 17,934 |  |
| Redeemable noncontrolling interest | (229) |  |  | 518 |  |
| Total equity | 777,056 |  |  | 735,827 |  |
| Total liabilities and equity | $ | 1,236,940 |  |  | $ | 1,182,365 |  |

[0000038725-19-000221:8k_2_02:41]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |  |  |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  |  |  |
| (Unaudited) |  |  |  |
|  | Nine Months Ended |  |  |
| (In thousands) | September 30, 2019 |  | September 30, 2018 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 76,014 |  |  | $ | 81,186 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 27,705 |  |  | 28,987 |  |
| Non-Cash Lease Expense | 7,640 |  |  | — |  |
| Share-based compensation | 7,459 |  |  | 6,627 |  |
| Other | (1,747) |  |  | (1,234) |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (27,170) |  |  | (30,853) |  |
| Inventory | (19,841) |  |  | (15,571) |  |
| Accounts payable and accrued expenses | 27,391 |  |  | (6,094) |  |
| Operating Leases | (7,637) |  |  | — |  |
| Income taxes-U.S. Tax Cuts and Jobs Act | — |  |  | (7,026) |  |
| Other | 411 |  |  | 4,396 |  |
| Net cash flows from operating activities | 90,225 |  |  | 60,418 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (15,591) |  |  | (15,108) |  |
| Proceeds from sale of property, plant, and equipment | 866 |  |  | 432 |  |
| Acquisitions and investments | (20,871) |  |  | (42,085) |  |
| Other investing activities | 8 |  |  | 388 |  |
| Net cash flows from investing activities | (35,588) |  |  | (56,373) |  |
| Cash flows from financing activities: |  |  |  |
| Change in debt | (31,659) |  |  | (8,203) |  |
| Proceeds from issuance of common stock | 2,331 |  |  | 8,747 |  |
| Purchases of common stock | (10,301) |  |  | (12,080) |  |
| Dividends paid | (20,919) |  |  | (16,960) |  |
| Purchase of redeemable non-controlling shares | (487) |  |  | — |  |
| Net cash flows from financing activities | (61,035) |  |  | (28,496) |  |
| Effect of exchange rate changes on cash | (4,970) |  |  | (1,609) |  |
| Net change in cash and equivalents | (11,368) |  |  | (26,060) |  |
| Cash and equivalents at beginning of period | 59,173 |  |  | 67,233 |  |
| Cash and equivalents at end of period | $ | 47,805 |  |  | $ | 41,173 |  |

[0000038725-19-000221:8k_2_02:42]
Company’s Securities and Exchange Commission filings, included in Item 1A of Part I of the Company’s Annual Report on Form 10-K for the fiscal year ending December 31, 2018, Exhibit 99.1 attached thereto and in Item 1A of Part II of the Company’s Quarterly Reports on Form 10-Q. These risks and uncertainties may cause actual results to differ materially from those indicated by the forward-looking statements. All forward-looking statements made herein are based on information currently available, and the Company assumes no obligation to update any forward-looking statements.
