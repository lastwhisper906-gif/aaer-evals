# FELE MD&A — 0000038725-19-000242


## mdna

[0000038725-19-000242:mdna:1]
[same as prior period, unchanged from 0000038725-19-000185:mdna:1]

[0000038725-19-000242:mdna:2]
Third Quarter 2019 vs. Third Quarter 2018

[0000038725-19-000242:mdna:3]
[same as prior period, unchanged from 0000038725-19-000185:mdna:3]

[0000038725-19-000242:mdna:4]
Sales in the third quarter of 2019 increased from the third quarter last year.  The sales increase was led by acquisition related sales, as well as all segments had sales increases from volume and price. The impact on sales due to foreign currency translation was a reduction of about 2 percent. The Company's consolidated gross profit was $117.6 million for the third quarter of 2019, an increase of $4.6 million or about 4 percent from the prior year’s third quarter. Earnings benefited from foreign exchange gains. Earnings per share in the third quarter of 2019 were up to the same period last year by about 14 percent.

[0000038725-19-000242:mdna:5]
[same as prior period, unchanged from 0000038725-19-000185:mdna:5]

[0000038725-19-000242:mdna:6]
[same as prior period, unchanged from 0000038725-19-000185:mdna:6]

[0000038725-19-000242:mdna:7]
Net sales in the third quarter of 2019 were $348.4 million, an increase of $6.5 million or about 2 percent compared to 2018 third quarter sales of $341.9 million.  Acquisition related sales were $9.6 million. Sales revenue decreased by $5.8 million or about 2 percent in the third quarter of 2019 due to foreign currency translation.

[0000038725-19-000242:mdna:8]
|  | Net Sales |
| (In millions) | Q3 2019 |  | Q3 2018 |  | 2019 v 2018 |
| Water Systems | $ | 199.8 |  |  | $ | 199.3 |  |  | $ | 0.5 |  |
| Fueling Systems | 78.1 |  |  | 77.8 |  |  | $ | 0.3 |  |
| Distribution | 87.0 |  |  | 78.0 |  |  | $ | 9.0 |  |
| Eliminations/Other | (16.5 | ) |  | (13.2 | ) |  | $ | (3.3 | ) |
| Consolidated | $ | 348.4 |  |  | $ | 341.9 |  |  | $ | 6.5 |  |

[0000038725-19-000242:mdna:9]
[same as prior period, unchanged from 0000038725-19-000185:mdna:9]

[0000038725-19-000242:mdna:10]
Water Systems sales were $199.8 million in the third quarter 2019, an increase of $0.5 million versus the third quarter 2018 sales of $199.3 million. In the third quarter of 2019, sales from businesses acquired since the third quarter of 2018 were $2.3 million. Water Systems sales were reduced by $4.9 million or about 2 percent in the quarter due to foreign currency translation. Water Systems sales, excluding acquisitions and the impact of foreign currency translation, were up about 2 percent compared to the third quarter 2018.

[0000038725-19-000242:mdna:11]
Water Systems sales in the U.S. and Canada increased by 1 percent overall compared to the third quarter 2018, primarily related to sales from acquisitions.  Sales of dewatering equipment increased by 2 percent on the continued diversification of product sales and channels.  Sales of groundwater pumping equipment increased by 1 percent versus the third quarter 2018.  The increase in groundwater pumping systems was primarily due to improved weather conditions in North America and increased sales to the Company’s Headwater Distribution segment. Sales of surface pumping equipment decreased by 4 percent on lower sales of both wastewater and condensation removal equipment.

[0000038725-19-000242:mdna:12]
Water Systems sales in markets outside the U.S. and Canada declined by 1 percent overall.  Foreign currency translation decreased sales by 5 percent.  Outside the U.S. and Canada, Water Systems organic sales increased by 4 percent, primarily driven by higher sales in Latin America and Europe, Middle East and Africa markets, partially offset by sales declines in Asia Pacific.

[0000038725-19-000242:mdna:13]
[same as prior period, unchanged from 0000038725-19-000185:mdna:13]

[0000038725-19-000242:mdna:14]
Fueling Systems sales were $78.1 million in the third quarter 2019, an increase of $0.3 million versus the third quarter 2018 sales of $77.8 million. In the third quarter of 2019, sales decreased by $0.9 million or about 1 percent in the quarter due to foreign currency translation. Fueling Systems organic sales increased about 2 percent compared to the third quarter of 2018.

[0000038725-19-000242:mdna:15]
Fueling Systems sales in the U.S. and Canada increased by 10 percent compared to the third quarter 2018.  The increase was principally in the fuel management systems and service station hardware product lines.  Outside the U.S. and Canada, Fueling Systems revenues declined by 6 percent, primarily due to lower sales in China.

[0000038725-19-000242:mdna:16]
[same as prior period, unchanged from 0000038725-19-000185:mdna:16]

[0000038725-19-000242:mdna:17]
Distribution sales were $87.0 million in the third quarter 2019, versus third quarter 2018 sales of $78.0 million. In the third quarter of 2019, sales from businesses acquired since the third quarter of 2018 were $7.3 million. The Distribution segment organic sales increased about 2 percent compared to the third quarter of 2018.

[0000038725-19-000242:mdna:18]
[same as prior period, unchanged from 0000038725-19-000185:mdna:18]

[0000038725-19-000242:mdna:19]
Cost of sales as a percent of net sales for the third quarter of 2019 and 2018 was 66.2 percent and 67.0 percent, respectively. Correspondingly, the gross profit margin as a percent of net sales was 33.8 percent in the third quarter of 2019 compared to 33.0 percent in the third quarter of 2018. The Company's consolidated gross profit was $117.6 million for the third quarter of 2019, an increase of $4.6 million from the gross profit of $113.0 million in the third quarter of 2018. The gross profit increase was primarily due to higher sales. In the third quarter, achieved sales price increases exceeded raw material inflation.

[0000038725-19-000242:mdna:20]
[same as prior period, unchanged from 0000038725-19-000185:mdna:20]

[0000038725-19-000242:mdna:21]
Selling, general, and administrative (SG&A) expenses were $74.5 million in the third quarter of 2019 compared to $72.5 million in the third quarter of the prior year. The increase in SG&A expenses from acquired businesses was $1.5 million. Excluding the acquired entities, the Company’s SG&A expenses in the third quarter of 2019 were $73.0 million, an increase of less than 1 percent from the third quarter 2018, partially due to the effect of foreign currency translations in the third quarter of 2019 versus the prior year.

[0000038725-19-000242:mdna:22]
[same as prior period, unchanged from 0000038725-19-000185:mdna:22]

[0000038725-19-000242:mdna:23]
Restructuring expenses for the third quarter of 2019 were $0.4 million, primarily in the Water segment and related to miscellaneous manufacturing realignment activities. Restructuring expenses for the third quarter of 2018 were $0.3 million, primarily in the Distribution segment and related to miscellaneous branch closings and consolidation.

[0000038725-19-000242:mdna:24]
[same as prior period, unchanged from 0000038725-19-000185:mdna:24]

[0000038725-19-000242:mdna:25]
Operating income was $42.7 million in the third quarter of 2019, up $2.6 million or 6 percent from $40.1 million in the third quarter of 2018.

[0000038725-19-000242:mdna:26]
|  |  | Operating income (loss) |
| (In millions) |  | Q3 2019 |  | Q3 2018 |  | 2019 v 2018 |
| Water Systems |  | $ | 28.4 |  |  | $ | 28.4 |  |  | $ | — |  |
| Fueling Systems |  | 21.6 |  |  | 20.9 |  |  | 0.7 |  |
| Distribution |  | 5.9 |  |  | 3.1 |  |  | 2.8 |  |
| Eliminations/Other |  | (13.2 | ) |  | (12.3 | ) |  | (0.9 | ) |
| Consolidated |  | $ | 42.7 |  |  | $ | 40.1 |  |  | $ | 2.6 |  |

[0000038725-19-000242:mdna:27]
[same as prior period, unchanged from 0000038725-19-000185:mdna:27]

[0000038725-19-000242:mdna:28]
Water Systems operating income was $28.4 million in the third quarter 2019, flat compared to the $28.4 million in the third quarter 2018. Operating income margin was 14.2 percent in both the third quarter of 2019 and 2018.

[0000038725-19-000242:mdna:29]
[same as prior period, unchanged from 0000038725-19-000185:mdna:29]

[0000038725-19-000242:mdna:30]
Fueling Systems operating income was $21.6 million in the third quarter of 2019, up $0.7 million or about 3 percent compared to $20.9 million in the third quarter of 2018. The increase in operating income was primarily due to higher favorable product

[0000038725-19-000242:mdna:31]
sales mix. The third quarter of 2019 operating income margin was 27.7 percent versus 26.9 percent of net sales in the third quarter of 2018.

[0000038725-19-000242:mdna:32]
[same as prior period, unchanged from 0000038725-19-000185:mdna:31]

[0000038725-19-000242:mdna:33]
Distribution operating income was $5.9 million in the third quarter of 2019 and the third quarter operating income margin was 6.8 percent. Distribution operating income was $3.1 million in the third quarter of 2018 and the third quarter operating income margin was 4.0 percent.  Distribution’s operating income was higher in the third quarter due to higher sales volumes and acquisitions and leverage on operating expenses.

[0000038725-19-000242:mdna:34]
[same as prior period, unchanged from 0000038725-19-000185:mdna:33]

[0000038725-19-000242:mdna:35]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses.  The inter-segment profit elimination impact in the third quarter of 2019 compared to the third quarter of 2018 reduced operating income about $0.7 million. The inter-segment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until the transferred product is sold from the Distribution segment to its customer. Unallocated general and administrative expenses were higher by $0.2 million or about 2 percent.

[0000038725-19-000242:mdna:36]
[same as prior period, unchanged from 0000038725-19-000185:mdna:35]

[0000038725-19-000242:mdna:37]
Interest expense for the third quarter of 2019 and 2018 was $2.0 million and $2.4 million, respectively.

[0000038725-19-000242:mdna:38]
[same as prior period, unchanged from 0000038725-19-000185:mdna:37]

[0000038725-19-000242:mdna:39]
Other income or expense was a loss of $0.3 million and $0.4 million in the third quarter of 2019 and 2018, respectively.

[0000038725-19-000242:mdna:40]
[same as prior period, unchanged from 0000038725-19-000185:mdna:39]

[0000038725-19-000242:mdna:41]
Foreign currency-based transactions produced a gain for the third quarter of 2019 of $2.1 million, primarily due to a $2.1 million gain from the Argentinian Peso relative to the U.S. dollar. Foreign currency-based transactions produced a loss for the third quarter of 2018 of $1.6 million, primarily due to changes in the Turkish Lira, South African Rand and Brazilian Real relative to the U.S. dollar.

[0000038725-19-000242:mdna:42]
[same as prior period, unchanged from 0000038725-19-000185:mdna:41]

[0000038725-19-000242:mdna:43]
The provision for income taxes in the third quarter of 2019 and 2018 was $8.4 million and $5.7 million, respectively. The effective tax rate for the third quarter of 2019 was about 20 percent. Discrete events in the third quarter of 2019 were not significant. The effective tax rate for the third quarter of 2018 was about 16 percent and, before the impact of discrete events, was about 20 percent. Discrete events in the third quarter of 2018 included excess tax benefits on stock-based compensation and the statute expiration of uncertain tax positions. The tax rate as a percentage of pre-tax earnings for the full year of 2019 is projected to be about 21 percent, compared to the full year 2018 tax rate of about 19 percent, both before the impact of discrete events.

[0000038725-19-000242:mdna:44]
[same as prior period, unchanged from 0000038725-19-000185:mdna:43]

[0000038725-19-000242:mdna:45]
Net income for the third quarter of 2019 was $34.1 million compared to the prior year third quarter net income of $29.9 million.  Net income attributable to Franklin Electric Co., Inc. for the third quarter of 2019 was $33.9 million, or $0.72 per diluted share, compared to the prior year third quarter net income attributable to Franklin Electric Co., Inc. of $30.0 million or $0.63 per diluted share.

[0000038725-19-000242:mdna:46]
First Nine Months of 2019 vs. First Nine Months of 2018

[0000038725-19-000242:mdna:47]
[same as prior period, unchanged from 0000038725-19-000185:mdna:46]

[0000038725-19-000242:mdna:48]
Sales in the first nine months of 2019 were up from the same period last year.  The sales increase was led by acquisitions. The impact of foreign currency translation decreased sales by about 3 percent. The Company's consolidated gross profit was $326.8 million for the first nine months of 2019, a decrease of $1.2 million or less than 1 percent from the first nine months of 2018. Earnings in the first nine months of 2019 were down from the same period last year.

[0000038725-19-000242:mdna:49]
[same as prior period, unchanged from 0000038725-19-000185:mdna:48]

[0000038725-19-000242:mdna:50]
[same as prior period, unchanged from 0000038725-19-000185:mdna:49]

[0000038725-19-000242:mdna:51]
Net sales in the first nine months of 2019 were $994.5 million, an increase of $13.0 million or about 1 percent compared to 2018 first nine months sales of $981.5 million.  The incremental impact of sales from acquired businesses was $30.2 million.  Sales revenue decreased by $29.0 million or 3 percent in the first nine months of 2019 due to foreign currency translation.

[0000038725-19-000242:mdna:52]
|  | Net Sales |
| (In millions) | YTD September 30, 2019 |  | YTD September 30, 2018 |  | 2019 v 2018 |
| Water Systems | $ | 593.2 |  |  | $ | 603.3 |  |  | $ | (10.1 | ) |
| Fueling Systems | 216.4 |  |  | 209.5 |  |  | $ | 6.9 |  |
| Distribution | 227.4 |  |  | 213.7 |  |  | $ | 13.7 |  |
| Eliminations/Other | (42.5 | ) |  | (45.0 | ) |  | $ | 2.5 |  |
| Consolidated | $ | 994.5 |  |  | $ | 981.5 |  |  | $ | 13.0 |  |

[0000038725-19-000242:mdna:53]
[same as prior period, unchanged from 0000038725-19-000185:mdna:52]

[0000038725-19-000242:mdna:54]
Water Systems sales were $593.2 million in the first nine months 2019, a decrease of $10.1 million or about 2 percent versus the first nine months of 2018. The incremental impact of sales from acquired businesses was $9.9 million. Foreign currency translation changes decreased sales $25.1 million, or about 4 percent, compared to sales in the first nine months of 2018. The Water Systems organic sales change in the first nine months of 2019 was an increase of $5.1 million or about 1 percent.

[0000038725-19-000242:mdna:55]
Water Systems sales in the U.S. and Canada increased by about 1 percent compared to the first nine months of 2018. The incremental impact of sales from acquired businesses was $2.3 million or about 1 percent.   Sales revenue decreased by $2.5 million or about 1 percent in the first nine months of 2019 due to foreign currency translation. In the first nine months of 2019, sales of Pioneer branded dewatering equipment increased by about 7 percent when compared to the prior year due to strength in North American oil and gas markets and continued diversification of product sales channels and geographies. Sales of groundwater pumping equipment decreased by about 5 percent on lower residential and agricultural system sales primarily to the Headwater companies, versus the first nine months of 2018. Sales of other surface pumping equipment increased by about 2 percent in the first nine months of the year, in part due to wet weather conditions in the upper Midwest and Canada in the first half of the year.

[0000038725-19-000242:mdna:56]
Water Systems sales in markets outside the U.S. and Canada decreased by about 4 percent compared to the first nine months of 2018. The incremental impact of sales from acquired businesses was $7.6 million or about 3 percent.   Sales revenue decreased by $22.6 million or about 8 percent in the first nine months of 2019 due to foreign currency translation. International Water Systems sales change in the first nine months of 2019, excluding acquisitions and foreign currency translation, was an increase of about 1 percent.  International Water Systems sales growth in the Asia Pacific and Latin America markets were partially offset by lower sales in the European, Middle East and African markets.

[0000038725-19-000242:mdna:57]
[same as prior period, unchanged from 0000038725-19-000185:mdna:56]

[0000038725-19-000242:mdna:58]
Fueling Systems sales were $216.4 million in the first nine months of 2019, an increase of $6.9 million or about 3 percent from the first nine months of 2018. The incremental impact of sales from acquired businesses was $3.2 million. Foreign currency translation changes decreased sales $3.9 million or about 2 percent compared to sales in the first nine months of 2018. The Fueling Systems organic sales change in the first nine months of 2019 was an increase of $7.6 million or about 4 percent.

[0000038725-19-000242:mdna:59]
Fueling Systems sales in the U.S. and Canada grew by about 11 percent during the first nine months with most of the sales growth coming from fuel management systems and service station hardware product lines.  Internationally, Fueling Systems revenues declined by about 6 percent due to lower sales in Europe, Africa and China partially offset by higher sales in India and other regions.  China sales were about $34 million in the first nine months of 2019 compared to the first nine months of 2018 Fueling Systems China sales of about $36 million.

[0000038725-19-000242:mdna:60]
[same as prior period, unchanged from 0000038725-19-000185:mdna:59]

[0000038725-19-000242:mdna:61]
Distribution sales were $227.4 million in the first nine months of 2019, versus the first nine months of 2018 sales of $213.7 million. The incremental impact of sales from acquired businesses was $17.1 million. Distribution segment organic sales decreased about 2 percent compared to the first nine months of 2018.

[0000038725-19-000242:mdna:62]
[same as prior period, unchanged from 0000038725-19-000185:mdna:61]

[0000038725-19-000242:mdna:63]
Cost of sales as a percent of net sales for the first nine months of 2019 and 2018 was 67.1 percent and 66.6 percent, respectively. Correspondingly, the gross profit margin was 32.9 percent and 33.4 percent, respectively. The Company's consolidated gross profit was $326.8 million for the first nine months of 2019, down $1.2 million from the gross profit of $328.0 million in the first nine months of 2018. The gross profit decrease was primarily due to lower sales in the Water segment.

[0000038725-19-000242:mdna:64]
[same as prior period, unchanged from 0000038725-19-000185:mdna:63]

[0000038725-19-000242:mdna:65]
Selling, general, and administrative expenses were $226.6 million in the first nine months of 2019 and increased by $2.9 million compared to $223.7 million in the first nine months of last year. The increase in SG&A expenses from acquired businesses was $7.3 million. Excluding the acquired entities, the Company’s SG&A expenses in the first nine months of 2019 decreased by $4.4 million or about 2 percent, partially due to the effect of foreign currency translation in 2019 versus the prior year.

[0000038725-19-000242:mdna:66]
[same as prior period, unchanged from 0000038725-19-000185:mdna:65]

[0000038725-19-000242:mdna:67]
Restructuring expenses for the first nine months of 2019 were $1.8 million. Restructuring expenses were $1.0 million in the Water segment and $0.8 million in the Distribution segment. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities and branch closings and consolidations in the Distribution segment. Restructuring expenses for the first nine months of 2018 were $1.0 million. Restructuring expenses were $0.5 million in the Water segment, $0.2 million in the Fueling segment and $0.3 million in the Distribution segment. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities and branch closings and consolidations in the Distribution segment.

[0000038725-19-000242:mdna:68]
[same as prior period, unchanged from 0000038725-19-000185:mdna:67]

[0000038725-19-000242:mdna:69]
Operating income was $98.5 million in the first nine months of 2019, down $4.8 million or 5 percent from $103.3 million in the first nine months of 2018.

[0000038725-19-000242:mdna:70]
|  |  | Operating income (loss) |
| (In millions) |  | YTD September 30, 2019 |  | YTD September 30, 2018 |  | 2019 v 2018 |
| Water Systems |  | $ | 78.5 |  |  | $ | 85.7 |  |  | $ | (7.2 | ) |
| Fueling Systems |  | 55.6 |  |  | 53.6 |  |  | 2.0 |  |
| Distribution |  | 6.1 |  |  | 6.3 |  |  | (0.2 | ) |
| Eliminations/Other |  | (41.7 | ) |  | (42.3 | ) |  | 0.6 |  |
| Consolidated |  | $ | 98.5 |  |  | $ | 103.3 |  |  | $ | (4.8 | ) |

[0000038725-19-000242:mdna:71]
[same as prior period, unchanged from 0000038725-19-000185:mdna:71]

[0000038725-19-000242:mdna:72]
Water Systems operating income was $78.5 million in the first nine months of 2019 compared to $85.7 million in the first nine months of 2018, a decrease of 8 percent. The first nine months operating income margin was 13.2 percent compared to the first nine months of 2018 operating income margin of 14.2 percent. Operating income margin decreased in Water Systems primarily due to lower sales volumes and unfavorable product and geographic sales mix shifts.

[0000038725-19-000242:mdna:73]
[same as prior period, unchanged from 0000038725-19-000185:mdna:73]

[0000038725-19-000242:mdna:74]
Fueling Systems operating income was $55.6 million in the first nine months of 2019 compared to $53.6 million in the first nine months of 2018. The first nine months operating income margin was 25.7 percent compared to 25.6 percent of net sales in the first nine months of 2018. Operating income margin increased in Fueling Systems primarily due to higher sales volumes and favorable product and geographic sales mix shifts.

[0000038725-19-000242:mdna:75]
[same as prior period, unchanged from 0000038725-19-000185:mdna:75]

[0000038725-19-000242:mdna:76]
Distribution operating income was $6.1 million in the first nine months of 2019 and operating income margin was 2.7 percent. Distribution operating income was $6.3 million in the first nine months of 2018 and operating income margin was 2.9 percent. Operating income margin decreased in Distribution due to lower sales volumes, partially offset by acquisitions.

[0000038725-19-000242:mdna:77]
[same as prior period, unchanged from 0000038725-19-000185:mdna:77]

[0000038725-19-000242:mdna:78]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses.  The inter-segment profit elimination impact in the first nine months of 2019 increased operating income about $0.1 million. The inter-segment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until the transferred product is sold from the Distribution segment to its third-party customer. Unallocated general and administrative expenses were lower by $0.5 million or about 1 percent to last year in the first nine months.

[0000038725-19-000242:mdna:79]
[same as prior period, unchanged from 0000038725-19-000185:mdna:79]

[0000038725-19-000242:mdna:80]
Interest expense for the first nine months of 2019 and 2018 was $6.7 million and $7.5 million, respectively.

[0000038725-19-000242:mdna:81]
[same as prior period, unchanged from 0000038725-19-000185:mdna:81]

[0000038725-19-000242:mdna:82]
Other income or expense was a loss of $0.3 million and $0.6 million, respectively in the first nine months of 2019 and 2018.

[0000038725-19-000242:mdna:83]
[same as prior period, unchanged from 0000038725-19-000185:mdna:83]

[0000038725-19-000242:mdna:84]
Foreign currency–based transactions produced a gain for the first nine months of 2019 of $2.2 million, primarily due to a $2.3 million gain from the Argentinian Peso relative to the U.S. dollar. Foreign currency-based transactions for the first nine months of 2018 was a loss of $3.2 million due to movements in several currencies relative to the U.S. dollar, with the Turkish Lira, South African Rand and Mexican Peso being the most significant.

[0000038725-19-000242:mdna:85]
[same as prior period, unchanged from 0000038725-19-000185:mdna:85]

[0000038725-19-000242:mdna:86]
The provision for income taxes in the first nine months of 2019 and 2018 was $17.7 million and $10.9 million, respectively. The effective tax rate for the first nine months of 2019 was about 19 percent and, before the impact of discrete events, was about 21 percent. The effective tax rate for the first nine months of 2018 was about 12 percent and, before the impact of discrete events, was about 20 percent. Discrete events in 2018 included a net benefit related to the release of valuation allowances on deferred taxes in multiple jurisdictions. The tax rate as a percentage of pre-tax earnings for the full year of 2019 is projected to be about 21 percent, compared to the full year 2018 tax rate of about 19 percent, both before the impact of discrete events.

[0000038725-19-000242:mdna:87]
[same as prior period, unchanged from 0000038725-19-000185:mdna:87]

[0000038725-19-000242:mdna:88]
Net income for the first nine months of 2019 was $76.0 million compared to 2018 first nine months net income of $81.2 million.  Net income attributable to Franklin Electric Co., Inc. for the first nine months of 2019 was $75.7 million, or $1.61 per diluted share, compared to 2018 first nine months net income attributable to Franklin Electric Co., Inc. of $81.7 million or $1.72 per diluted share.

[0000038725-19-000242:mdna:89]
[same as prior period, unchanged from 0000038725-19-000185:mdna:89]

[0000038725-19-000242:mdna:90]
[same as prior period, unchanged from 0000038725-19-000185:mdna:90]

[0000038725-19-000242:mdna:91]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available.  The Company believes its capital resources and liquidity position at September 30, 2019 is adequate to meet projected needs for the foreseeable future.  The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-19-000242:mdna:92]
As of September 30, 2019 the Company had a $300.0 million revolving credit facility.  The facility is scheduled to mature on October 28, 2021.  As of September 30, 2019, the Company had $215.9 million borrowing capacity under the Credit Agreement as $5.0 million in letters of commercial and standby letters of credit were outstanding and undrawn and $79.1 million in revolver borrowings were drawn and outstanding which were primarily used for working capital needs, the payment of existing indebtedness, and acquisitions.

[0000038725-19-000242:mdna:93]
The Company also has other long-term debt borrowing outstanding as of September 30, 2019.  See Note 9 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-19-000242:mdna:94]
At September 30, 2019, the Company had $41.3 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations.  There is currently no need to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-19-000242:mdna:95]
[same as prior period, unchanged from 0000038725-19-000185:mdna:95]

[0000038725-19-000242:mdna:96]
The following table summarizes significant sources and uses of cash and cash equivalents for the first nine months of 2019 and 2018.

[0000038725-19-000242:mdna:97]
| (in millions) |  | 2019 |  | 2018 |
| Net cash flows from operating activities |  | $ | 90.2 |  |  | $ | 60.4 |  |
| Net cash flows from investing activities |  | (35.6 | ) |  | (56.4 | ) |
| Net cash flows from financing activities |  | (61.0 | ) |  | (28.5 | ) |
| Impact of exchange rates on cash and cash equivalents |  | (5.0 | ) |  | (1.6 | ) |
| Change in cash and cash equivalents |  | $ | (11.4 | ) |  | $ | (26.1 | ) |

[0000038725-19-000242:mdna:98]
[same as prior period, unchanged from 0000038725-19-000185:mdna:98]

[0000038725-19-000242:mdna:99]
[same as prior period, unchanged from 0000038725-19-000185:mdna:99]

[0000038725-19-000242:mdna:100]
Net cash provided by operating activities was $90.2 million for the nine months ended September 30, 2019 compared to $60.4 million provided by operating activities for the nine months ended September 30, 2018.  The increase in cash provided by operating activities was due to a decrease of $32.9 million in working capital requirements, primarily in accounts payable and accrued expenses due to better payment terms with vendors as well as lower tax payments and contributions to employee benefit plans.  Increases in cash provided were offset by uses of cash for other assets, which consisted primarily of prepaid assets.

[0000038725-19-000242:mdna:101]
[same as prior period, unchanged from 0000038725-19-000185:mdna:102]

[0000038725-19-000242:mdna:102]
[same as prior period, unchanged from 0000038725-19-000185:mdna:103]

[0000038725-19-000242:mdna:103]
Net cash used in investing activities was $35.6 million for the nine months ended September 30, 2019 compared to $56.4 million used in investing activities for the nine months ended September 30, 2018.  The decrease in cash used in investing activities is primarily attributable to decreased acquisition activity.

[0000038725-19-000242:mdna:104]
[same as prior period, unchanged from 0000038725-19-000185:mdna:105]

[0000038725-19-000242:mdna:105]
[same as prior period, unchanged from 0000038725-19-000185:mdna:106]

[0000038725-19-000242:mdna:106]
Net cash used in financing activities was $61.0 million for the nine months ended September 30, 2019 compared to $28.5 million used in financing activities for the nine months ended September 30, 2018.  The increase in cash used in financing activities was primarily attributable to higher debt repayments, up approximately $23.5 million in the current year consistent with reduced acquisition activity.  Other uses of cash in financing activities include dividend payments, which increased by $3.9 million in the current year compared to dividends paid in the prior year, and proceeds from common stock issuance, which decreased $6.4 million compared to prior year.  These were offset by a decrease in common stock repurchases of $1.8 million in the current year compared to common stock repurchases in the prior year.

[0000038725-19-000242:mdna:107]
[same as prior period, unchanged from 0000038725-19-000185:mdna:108]
