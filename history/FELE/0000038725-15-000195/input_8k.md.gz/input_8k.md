# FELE 8-K — 0000038725-15-000190 filed 2015-10-27

## item codes, every 8-K on or before 2015-11-03

- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2015-11-03

- none on or before 2015-11-03

## item 2.02 — earnings release, exhibit 99.1

[0000038725-15-000190:8k_2_02:1]
EX-99.1
2
a201510278-kexhibit991.htm
EXHIBIT 99.1

[0000038725-15-000190:8k_2_02:2]
Exhibit

[0000038725-15-000190:8k_2_02:3]
Exhibit 99.1

[0000038725-15-000190:8k_2_02:4]
For Immediate Release

[0000038725-15-000190:8k_2_02:5]
For Further Information

[0000038725-15-000190:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-15-000190:8k_2_02:7]
260-824-2900

[0000038725-15-000190:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS THIRD QUARTER

[0000038725-15-000190:8k_2_02:9]
2015 SALES AND EARNINGS

[0000038725-15-000190:8k_2_02:10]
Fort Wayne, Indiana - October 27, 2015 - Franklin Electric Co., Inc. (NASDAQ:FELE) reported third quarter 2015 adjusted earnings per share (EPS) of $0.45 compared to 2014 third quarter adjusted EPS of $0.50, a 10 percent decrease (see table below for a reconciliation of GAAP EPS to the adjusted EPS).  In the third quarter of 2015, the Company’s GAAP fully diluted EPS was $0.43, down 7 percent to the GAAP fully diluted EPS from the third quarter of 2014.

[0000038725-15-000190:8k_2_02:11]
Third quarter 2015 sales were $232.5 million, a decrease of 16 percent compared to 2014 third quarter sales of $278.1 million.  The Company’s organic sales decline was 7 percent excluding acquisitions and the impact of foreign currency translation.

[0000038725-15-000190:8k_2_02:12]
Gregg Sengstack, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-15-000190:8k_2_02:13]
“In the third quarter, the two principle factors behind our 16 percent revenue decline were the continued deterioration of foreign currencies against the U.S. dollar, and the impact of lower oil prices reducing oil well rig counts, and therefore sharply reducing demand for our Pioneer branded de-watering equipment. However, due to improved costs, sales mix and pricing, the decline in our adjusted operating income, of 17 percent, was significantly less than the decline in the second quarter 2015, and our adjusted operating income margin of 12.7 percent equaled the third quarter of last year.

[0000038725-15-000190:8k_2_02:14]
Sequentially, versus the second quarter 2015, while revenues declined 6 percent, our adjusted operating income increased 18 percent, and, due to a favorable tax rate and a meaningful number of shares repurchased during the quarter, our adjusted earnings per share increased 29 percent.”

[0000038725-15-000190:8k_2_02:15]
Key Performance Indicators:

[0000038725-15-000190:8k_2_02:16]
| Earnings Before and After Non-GAAP Adjustments |  | For the Third Quarter |
| (in millions) |  | 2015 | 2014 | Change |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 20.8 |  | $ | 22.7 |  | (8 | )% |
| Allocated Undistributed Earnings |  | $ | (0.4 | ) | $ | (0.6 | ) |  |
| Adjusted Earnings for EPS Calculations |  | $ | 20.4 |  | $ | 22.1 |  | (8 | )% |
| Non-GAAP adjustments (before tax): |  |  |  |  |
| Restructuring |  | $ | 1.3 |  | $ | 1.1 |  |  |
| Non-GAAP items |  | $ | 0.4 |  | $ | 1.9 |  |  |
| Non-GAAP adjustments, net of tax: |  |  |  |  |
| Restructuring |  | $ | 0.8 |  | $ | 0.7 |  |  |
| Non-GAAP items |  | $ | 0.2 |  | $ | 1.2 |  |  |
| Earnings after Non-GAAP Adjustments |  | $ | 21.4 |  | $ | 24.0 |  | (11 | )% |
| Earnings Per Share |  | For the Third Quarter |
| Before and After Non-GAAP Adjustments |  | 2015 | 2014 | Change |
| (in millions except Earnings Per Share) |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 47.3 |  | 48.1 |  | (2 | )% |
| Fully Diluted Earnings Per Share ("EPS") Reported |  | $ | 0.43 |  | $ | 0.46 |  | (7 | )% |
| Restructuring Per Share, net of tax |  | $ | 0.02 |  | $ | 0.01 |  |  |
| Non-GAAP items, net of tax |  | $ | — |  | $ | 0.03 |  |  |
| Fully Diluted EPS after Non-GAAP Adjustments(Adjusted EPS) |  | $ | 0.45 |  | $ | 0.50 |  | (10 | )% |

[0000038725-15-000190:8k_2_02:17]
| Net Sales | For the Third Quarter |
| (in millions) | Water | Fueling | Consolidated |
| Sales for 2014 | $ | 216.6 |  | $ | 61.5 |  | $ | 278.1 |  |
| Acquisitions | $ | 2.4 |  | $ | 0.2 |  | $ | 2.6 |  |
| Foreign currency translation | $ | (24.2 | ) | $ | (3.2 | ) | $ | (27.4 | ) |
| Volume/Price Change | $ | (21.3 | ) | $ | 0.5 |  | $ | (20.8 | ) |
| Sales for 2015 | $ | 173.5 |  | $ | 59.0 |  | $ | 232.5 |  |

[0000038725-15-000190:8k_2_02:18]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the Third Quarter 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 23.1 |  | $ | 15.4 |  | $ | (10.7 | ) | $ | 27.8 |  |
| % Operating Income To Net Sales | 13.3 | % | 26.1 | % |  | 12.0 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 1.3 |  | $ | — |  | $ | — |  | $ | 1.3 |  |
| Non-GAAP | $ | 0.1 |  | $ | — |  | $ | 0.3 |  | $ | 0.4 |  |
| Operating Income after Non-GAAP Adjustments | $ | 24.5 |  | $ | 15.4 |  | $ | (10.4 | ) | $ | 29.5 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 14.1 | % | 26.1 | % |  | 12.7 | % |
|  | For the Third Quarter 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 28.3 |  | $ | 15.4 |  | $ | (11.3 | ) | $ | 32.4 |  |
| % Operating Income To Net Sales | 13.1 | % | 25.0 | % |  | 11.7 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 1.0 |  | $ | 0.1 |  | $ | — |  | $ | 1.1 |  |
| Non-GAAP | $ | 1.7 |  | $ | 0.2 |  | $ | — |  | $ | 1.9 |  |
| Operating Income after Non-GAAP Adjustments | $ | 31.0 |  | $ | 15.7 |  | $ | (11.3 | ) | $ | 35.4 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 14.3 | % | 25.5 | % |  | 12.7 | % |

[0000038725-15-000190:8k_2_02:19]
Water Systems

[0000038725-15-000190:8k_2_02:20]
Water Systems sales were $173.5 million in the third quarter 2015, a decrease of $43.1 million or about 20 percent versus the third quarter 2014 sales of $216.6 million.  Sales from businesses acquired since the third quarter of 2014 were $2.4 million or about 1 percent.  Water Systems sales were reduced by $24.2 million or about 11 percent in the quarter due to foreign currency translation.  Excluding acquisitions and foreign currency translation, Water Systems sales declined about 10 percent compared to the third quarter 2014.

[0000038725-15-000190:8k_2_02:21]
Water Systems sales in the U.S. and Canada represented 37 percent of consolidated sales and declined by about 22 percent compared to the prior year. Water Systems sales in the U.S and Canada were reduced by $1.9 million or about 2 percent in the quarter due to foreign currency translation.  In the third quarter 2015, U.S. and Canada sales of Pioneer branded mobile dewatering equipment declined by 60 percent. The decline in mobile dewatering equipment is primarily attributed to reduced demand in the oil and gas end markets.  Sales of groundwater pumping equipment declined by about 10 percent.  The decline in groundwater equipment sales is attributable primarily to weak demand for agricultural related products in key end markets in the central region of the U.S.  Finally, sales of surface water pumping equipment declined by about 12 percent versus the third quarter 2014, primarily due to lower wastewater product sales.

[0000038725-15-000190:8k_2_02:22]
Water Systems sales in Latin America were about 13 percent of consolidated sales for the third quarter and declined by about 23 percent compared to the third quarter of the prior year.  Water Systems sales were reduced by $12.3 million or about 31 percent in the quarter due to foreign currency translation. Excluding the impact of foreign currency translation, Latin American sales increased by about 8 percent compared to the third quarter 2014.  This growth in sales was led by increased sales in Central America and Argentina.  Sales of Water Systems products in Brazil increased about 3 percent in local currency during the third quarter.

[0000038725-15-000190:8k_2_02:23]
Water Systems sales in the Middle East and Africa were about 10 percent of consolidated sales and decreased by about 18 percent compared to the third quarter 2014.  Water Systems sales were reduced by about 16 percent in the quarter due to foreign currency translation.  Excluding the impact of foreign currency translation, sales decreased by about 2 percent compared to the third quarter 2014. The decline was driven by lower sales in Turkey.

[0000038725-15-000190:8k_2_02:24]
Water Systems sales in the Asia Pacific region were 7 percent of consolidated sales and were down about 4 percent compared to the third quarter prior year.  Excluding acquisitions and the impact of foreign currency translation, Asia Pacific sales decreased by about 1 percent compared to the third quarter 2014.  The Asia Pacific region experienced year over year growth in groundwater product sales of 7 percent, but this improvement was offset by a decline in Pioneer branded mobile dewatering equipment in Australia compared to a very strong third quarter 2014.

[0000038725-15-000190:8k_2_02:25]
Water Systems sales in Europe were about 7 percent of consolidated sales and decreased by about 20 percent compared to the third quarter 2014.  The impact of foreign currency translation decreased sales by about 20 percent compared to the third quarter 2014.  Excluding currency translation, European sales were flat versus the third quarter of 2014.

[0000038725-15-000190:8k_2_02:26]
Water Systems operating income, after non-GAAP adjustments, was $24.5 million in the third quarter 2015, down $6.5 million versus the third quarter 2014. The third quarter operating income margin after non-GAAP adjustments was 14.1 percent, down 20 basis points from 14.3 percent in the third quarter of 2014.

[0000038725-15-000190:8k_2_02:27]
Fueling Systems

[0000038725-15-000190:8k_2_02:28]
Fueling Systems sales represented 25 percent of consolidated sales and were $59.0 million in the third quarter 2015, a decrease of $2.5 million or about 4 percent versus the third quarter 2014 sales of $61.5 million.  Fueling Systems sales decreased by $3.2 million or about 5 percent in the quarter due to foreign currency translation. Fueling Systems sales were up about 1 percent, after excluding foreign currency translation.

[0000038725-15-000190:8k_2_02:29]
Fueling Systems sales in the U.S. and Canada grew by about 8 percent during the quarter with most of the sales growth coming from fuel dispensing products and piping.  Fueling Systems revenues declined in India and China due to the timing of tender awards made in India and the ongoing reduction in State owned oil company procurements in China.  Sales also declined in Europe principally due to a 45 percent decline in the sale of storage tanks that support North Sea oil production.

[0000038725-15-000190:8k_2_02:30]
Fueling Systems operating income after non-GAAP adjustments was $15.4 million in the third quarter of 2015 compared to $15.7 million after non-GAAP adjustments in the third quarter of 2014, a decrease of about 2 percent. The third quarter operating income margin after non-GAAP adjustments was 26.1 percent, an increase of 60 basis points from the 25.5 percent of net sales in the third quarter of 2014.

[0000038725-15-000190:8k_2_02:31]
Overall

[0000038725-15-000190:8k_2_02:32]
The Company’s consolidated gross profit was $76.8 million for the third quarter of 2015, a decrease of $12.4 million, or about 14 percent, from the third quarter of 2014 gross profit of $89.2 million. The gross profit as a percent of net sales was 33.0 percent in the third quarter of 2015 and increased about 90 basis points versus 32.1 percent during the third quarter 2014.  The gross profit margin increase was primarily due to lower direct material costs and an improved sales mix of Water Systems products.

[0000038725-15-000190:8k_2_02:33]
Selling, general, and administrative (SG&A) expenses were $47.7 million in the third quarter of 2015 compared to $55.6 million in the third quarter of prior year, a decrease of $7.9 million or about 14 percent.  The Company’s SG&A expenses decreased in the quarter primarily due to lower marketing and selling related expenses, as well as lower costs for incentive compensation.  Approximately half of the lower SG&A expenses was related to foreign exchange.

[0000038725-15-000190:8k_2_02:34]
The Company ended the third quarter of 2015 with a cash balance of $84.9 million, which was $25.8 million higher than at the end of 2014.  The cash balance increase is attributable to cash generated from operations of about $60.3 million, or 105 percent of the year to date reported net income.  The Company purchased about 1.3 million shares of its common stock for approximately $37 million in the open market during the third quarter 2015.

[0000038725-15-000190:8k_2_02:35]
Commenting on the outlook, Mr. Sengstack said:

[0000038725-15-000190:8k_2_02:36]
“Our third quarter revenue was weaker than we expected due to the further deterioration of foreign currencies against the U.S. dollar and reduced demand for equipment that supports oil and gas exploration.  These factors show no signs of abating in the fourth quarter.  Therefore, we anticipate fourth quarter revenues to be down between 10 and 12 percent when compared to the fourth quarter last year. However, excluding the impact of exchange rates and weak demand for oil and gas end market equipment, we are expecting organic growth across both segments.  Despite this revenue decline, with the costs and price actions taken to date, we believe adjusted operating income will increase significantly compared to the fourth quarter 2014 and adjusted earnings per share will be in the range of $0.34 to $0.37 cents.”

[0000038725-15-000190:8k_2_02:37]
A conference call to review earnings and other developments in the business will commence at 9:00 am EDT.  The third quarter 2015 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-15-000190:8k_2_02:38]
http://edge.media-server.com/m/p/jk3q4nkm

[0000038725-15-000190:8k_2_02:39]
If you intend to ask questions during the call, please dial in using (877) 643-7158 for domestic calls and (914) 495-8565 for international calls. The Conference ID is: 58348270.

[0000038725-15-000190:8k_2_02:40]
A replay of the conference call will be available Tuesday, October 27, 2015 at 12:00 noon EDT through midnight EDT on Tuesday, November 3, 2015, by dialing (855) 859-2056 for domestic calls and (404) 537-3406 for international calls. The replay passcode is: 58348270.

[0000038725-15-000190:8k_2_02:41]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-15-000190:8k_2_02:42]
The Company presents the non-GAAP financial measures of earnings after non-GAAP adjustments, fully diluted earnings per share after non-GAAP adjustments (or adjusted EPS), operating income after non-GAAP adjustments and percent operating income to net sales after non-GAAP adjustments (or operating income margin after non-GAAP adjustments) because the Company believes the information helps investors understand underlying trends in the Company's business more easily. The differences between these measures and the most comparable GAAP measures are reconciled in the tables above.

[0000038725-15-000190:8k_2_02:43]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |
| Net sales | $ | 232,485 |  |  | $ | 278,053 |  |  | $ | 705,640 |  |  | $ | 793,940 |  |
| Cost of sales | 155,693 |  |  | 188,902 |  |  | 477,150 |  |  | 527,284 |  |
| Gross profit | 76,792 |  |  | 89,151 |  |  | 228,490 |  |  | 266,656 |  |
| Selling, general, and administrative expenses | 47,722 |  |  | 55,635 |  |  | 159,160 |  |  | 167,621 |  |
| Restructuring expense | 1,304 |  |  | 1,086 |  |  | 2,525 |  |  | 1,517 |  |
| Operating income | 27,766 |  |  | 32,430 |  |  | 66,805 |  |  | 97,518 |  |
| Interest expense | (2,604 | ) |  | (2,744 | ) |  | (7,717 | ) |  | (8,038 | ) |
| Other income, net | 1,616 |  |  | 355 |  |  | 6,025 |  |  | 1,551 |  |
| Foreign exchange expense | (96 | ) |  | (510 | ) |  | (39 | ) |  | (602 | ) |
| Income before income taxes | 26,682 |  |  | 29,531 |  |  | 65,074 |  |  | 90,429 |  |
| Income tax expense | 5,656 |  |  | 6,726 |  |  | 7,634 |  |  | 22,745 |  |
| Net income | $ | 21,026 |  |  | $ | 22,805 |  |  | $ | 57,440 |  |  | $ | 67,684 |  |
| Less: Net income attributable to noncontrolling interests | (201 | ) |  | (132 | ) |  | (656 | ) |  | (980 | ) |
| Net income attributable to Franklin Electric Co., Inc. | $ | 20,825 |  |  | $ | 22,673 |  |  | $ | 56,784 |  |  | $ | 66,704 |  |
| Income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.44 |  |  | $ | 0.46 |  |  | $ | 1.18 |  |  | $ | 1.37 |  |
| Diluted | $ | 0.43 |  |  | $ | 0.46 |  |  | $ | 1.17 |  |  | $ | 1.36 |  |

[0000038725-15-000190:8k_2_02:44]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | October 3, 2015 |  | January 3, 2015 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 84,898 |  |  | $ | 59,141 |  |
| Receivables | 131,767 |  |  | 143,787 |  |
| Inventories | 209,191 |  |  | 220,528 |  |
| Other current assets | 50,373 |  |  | 46,083 |  |
| Total current assets | 476,229 |  |  | 469,539 |  |
| Property, plant, and equipment, net | 188,034 |  |  | 209,786 |  |
| Goodwill and other assets | 371,926 |  |  | 396,562 |  |
| Total assets | $ | 1,036,189 |  |  | $ | 1,075,887 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 59,865 |  |  | $ | 70,806 |  |
| Accrued expenses and other current liabilities | 62,345 |  |  | 96,207 |  |
| Current maturities of long-term debt and short-term borrowings | 55,088 |  |  | 34,092 |  |
| Total current liabilities | 177,298 |  |  | 201,105 |  |
| Long-term debt | 188,150 |  |  | 143,695 |  |
| Deferred income taxes | 43,719 |  |  | 45,568 |  |
| Employee benefit plans | 50,363 |  |  | 58,709 |  |
| Other long-term liabilities | 16,715 |  |  | 21,407 |  |
| Redeemable noncontrolling interest | 6,436 |  |  | 6,420 |  |
| Total equity | 553,508 |  |  | 598,983 |  |
| Total liabilities and equity | $ | 1,036,189 |  |  | $ | 1,075,887 |  |

[0000038725-15-000190:8k_2_02:45]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Nine Months Ended |
| (In thousands) | October 3, 2015 |  | September 27, 2014 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 57,440 |  |  | $ | 67,684 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 26,804 |  |  | 27,791 |  |
| Share-based compensation | 4,579 |  |  | 6,314 |  |
| Realized gain on share purchase liability | (2,723 | ) |  | — |  |
| Other | (6,147 | ) |  | 926 |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (527 | ) |  | (50,070 | ) |
| Inventory | (3,366 | ) |  | (49,888 | ) |
| Accounts payable and accrued expenses | (10,345 | ) |  | 12,469 |  |
| Other | (5,374 | ) |  | (11,745 | ) |
| Net cash flows from operating activities | 60,341 |  |  | 3,481 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (15,528 | ) |  | (25,094 | ) |
| Proceeds from sale of property, plant, and equipment | 959 |  |  | 1,592 |  |
| Acquisitions and investments | (3,888 | ) |  | (42,619 | ) |
| Other investing activities | 99 |  |  | (2,244 | ) |
| Net cash flows from investing activities | (18,358 | ) |  | (68,365 | ) |
| Cash flows from financing activities: |  |  |  |
| Change in debt | 65,787 |  |  | 32,925 |  |
| Proceeds from issuance of common stock | 1,240 |  |  | 1,351 |  |
| Excess tax from share-based payment arrangements | 819 |  |  | 1,800 |  |
| Purchases of common stock | (43,330 | ) |  | (8,642 | ) |
| Dividends paid | (14,393 | ) |  | (13,119 | ) |
| Purchase of redeemable non-controlling shares | — |  |  | (2,875 | ) |
| Share purchase liability payment | (20,200 | ) |  | — |  |
| Net cash flows from financing activities | (10,077 | ) |  | 11,440 |  |
| Effect of exchange rate changes on cash | (6,149 | ) |  | (3,689 | ) |
| Net change in cash and equivalents | 25,757 |  |  | (57,133 | ) |
| Cash and equivalents at beginning of period | 59,141 |  |  | 134,553 |  |
| Cash and equivalents at end of period | $ | 84,898 |  |  | $ | 77,420 |  |
