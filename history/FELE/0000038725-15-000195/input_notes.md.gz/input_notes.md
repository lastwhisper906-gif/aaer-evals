# FELE notes — 0000038725-15-000195


## fele:DisclosureOfShareBasedCompensationArrangementsAuthorizedSharesTableTextBlock

[0000038725-15-000195:notes:1]
[same as prior period, unchanged from 0000038725-15-000161:notes:1]

[0000038725-15-000195:notes:2]
[same as prior period, unchanged from 0000038725-15-000161:notes:2]

[0000038725-15-000195:notes:3]
[same as prior period, unchanged from 0000038725-15-000161:notes:3]

[0000038725-15-000195:notes:4]
[same as prior period, unchanged from 0000038725-15-000161:notes:4]


## fele:ScheduleOfFiniteAndIndefiniteLivedIntangibleAssetsTableTextBlock

[0000038725-15-000195:notes:5]
[same as prior period, unchanged from 0000038725-15-000161:notes:5]

[0000038725-15-000195:notes:6]
| (In millions) |  | October 3, 2015 |  | January 3, 2015 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortized intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.4 |  |  | $ | (6.1 | ) |  | $ | 7.6 |  |  | $ | (6.1 | ) |
| Supply agreements |  | 4.4 |  |  | (4.4 | ) |  | 4.4 |  |  | (4.4 | ) |
| Technology |  | 7.5 |  |  | (4.7 | ) |  | 7.5 |  |  | (4.3 | ) |
| Customer relationships |  | 133.0 |  |  | (40.6 | ) |  | 140.2 |  |  | (36.5 | ) |
| Software |  | 2.5 |  |  | (1.7 | ) |  | 2.9 |  |  | (1.7 | ) |
| Other |  | 1.0 |  |  | (1.0 | ) |  | 1.2 |  |  | (1.2 | ) |
| Total |  | $ | 155.8 |  |  | $ | (58.5 | ) |  | $ | 163.8 |  |  | $ | (54.2 | ) |
| Unamortized intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 46.6 |  |  | — |  |  | 50.7 |  |  | — |  |
| Total intangibles |  | $ | 202.4 |  |  | $ | (58.5 | ) |  | $ | 214.5 |  |  | $ | (54.2 | ) |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-15-000195:notes:7]
[same as prior period, unchanged from 0000038725-15-000161:notes:7]

[0000038725-15-000195:notes:8]
[same as prior period, unchanged from 0000038725-15-000161:notes:8]

[0000038725-15-000195:notes:9]
[same as prior period, unchanged from 0000038725-15-000161:notes:9]

[0000038725-15-000195:notes:10]
Goodwill increased by $0.3 million and current assets decreased by $0.3 million in the second quarter ended July 4, 2015 due to working capital adjustments.  In addition, the Company paid an additional $0.3 million to the sellers of Bombas Leao during the second quarter ended July 4, 2015 to satisfy amounts previously accrued per the original purchase agreement.  The final purchase price assigned to the major identifiable assets and liabilities for the Bombas Leao acquisition is as follows:

[0000038725-15-000195:notes:11]
[same as prior period, unchanged from 0000038725-15-000161:notes:11]

[0000038725-15-000195:notes:12]
The fair values of the identifiable assets, property, plant, and equipment, and liabilities were final as of the second quarter ended July 4, 2015.  The Company utilized management estimates and consultation with an independent third-party valuation firm to assist in the valuation.

[0000038725-15-000195:notes:13]
Transaction costs for all acquisition related activity were expensed as incurred under the guidance of FASB ASC Topic 805, Business Combinations.  Transaction costs included in selling, general, and administrative expenses in the Company’s condensed consolidated statements of income were $0.2 million and $1.1 million for the nine months ended October 3, 2015 and September 27, 2014, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000038725-15-000195:notes:14]
In August 2010, the California Air Resources Board (“CARB”) and South Coast Air Quality Management District (“SCAQMD”) filed civil complaints in the Los Angeles Superior Court against the Company and Franklin Fueling Systems, Inc.  The complaints related to a third-party-supplied component part of the Company's Healy 900 Series nozzle, which is part of the Company's Enhanced Vapor Recovery (“EVR”) Systems installed in California gasoline filling stations.  This part, a diaphragm, was the subject of a retrofit during the first half of 2008.  As the Company previously reported, in October 2008 CARB issued a Notice of Violation to the Company alleging that the circumstances leading to the retrofit program violated California statutes and regulations.

[0000038725-15-000195:notes:15]
The claims in the complaints mirrored those that CARB presented to the Company in the Notice of Violation, and included claims that the Company negligently and intentionally sold nozzles with a modified diaphragm without required CARB certification. Those complaints were consolidated into one case in the Superior Court of California, County of Los Angeles (People of the State of California vs. Franklin Fueling Systems, Inc. et al.) which was tried in the later part of December 2012 and early part of January 2013 (“CARB Case”).

[0000038725-15-000195:notes:16]
On July 25, 2013, the Court issued a Final Statement of Decision (“Decision”) in the CARB Case.  In its Decision, the Court found on behalf of the Company and issued a complete defense verdict.  Judgment was entered on August 27, 2013.  An Amended Judgment awarding the Company $0.1 million in costs was entered by the Court on January 22, 2014. On July 16, 2014, CARB appealed and filed its brief in support of the appeal. The Company filed its response brief on December 23, 2014 and CARB filed its Reply brief on February 2, 2015.  On September 29, 2015, both sides made oral arguments in front of the California Court of Appeals. The Appellate Court has ninety days to issue a ruling.

[0000038725-15-000195:notes:17]
Neither of these suits has had any effect on CARB's certification of the Company's EVR System or any other products of the Company or its subsidiaries, and did not interfere with continuing sales.  CARB has never decertified the Company's EVR System and has never proposed to do so.

[0000038725-15-000195:notes:18]
The Company is defending various other claims and legal actions, including environmental matters, which have arisen in the

[0000038725-15-000195:notes:19]
ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with

[0000038725-15-000195:notes:20]
counsel, these claims and legal actions can be successfully defended or resolved without a material effect on the

[0000038725-15-000195:notes:21]
Company’s financial position, results of operations, and net cash flows.

[0000038725-15-000195:notes:22]
At October 3, 2015, the Company had $12.4 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-15-000195:notes:23]
The Company provides warranties on most of its products.  The warranty terms vary but are generally 2 years from date of manufacture or 1 year from date of installation.  In 2007, the Company began offering an extended warranty program to certain Water Systems customers which provides warranty coverage up to 5 years from date of manufacture.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-15-000195:notes:24]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended October 3, 2015, are as follows:

[0000038725-15-000195:notes:25]
| (In millions) |  |  |
| Balance as of January 3, 2015 |  | $ | 9.4 |  |
| Accruals related to product warranties |  | 5.5 |  |
| Reductions for payments made |  | (5.8 | ) |
| Balance as of October 3, 2015 |  | $ | 9.1 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-15-000195:notes:26]
[same as prior period, unchanged from 0000038725-15-000161:notes:26]

[0000038725-15-000195:notes:27]
Changes in accumulated other comprehensive income/(loss) by component for the nine months ended October 3, 2015 and September 27, 2014, are summarized below:

[0000038725-15-000195:notes:28]
| (In millions) |  |  |  |  |  |
| For the nine months ended October 3, 2015: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments |  | Total |
| Balance as of January 3, 2015 | $ | (51.8 | ) |  | $ | (56.1 | ) |  | $ | (107.9 | ) |
| Other comprehensive loss before reclassifications: |  |  |  |  |  |
| Pre-tax loss | (54.4 | ) |  | — |  |  | (54.4 | ) |
| Income tax expense | — |  |  | — |  |  | — |  |
| Other comprehensive loss before reclassifications, net of income taxes | (54.4 | ) |  | — |  |  | (54.4 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income | — |  |  | 2.9 |  | (1) | 2.9 |  |
| Income tax expense | — |  |  | (1.0 | ) |  | (1.0 | ) |
| Amounts reclassified from accumulated other comprehensive income, net of income taxes | — |  |  | 1.9 |  |  | 1.9 |  |
| Net current period other comprehensive income/(loss), net of income taxes | (54.4 | ) |  | 1.9 |  |  | (52.5 | ) |
| Other comprehensive loss attributable to noncontrolling interest | (0.6 | ) |  | — |  |  | (0.6 | ) |
| Balance as of October 3, 2015 | $ | (105.6 | ) |  | $ | (54.2 | ) |  | $ | (159.8 | ) |
| For the nine months ended September 27, 2014: |  |  |  |  |  |
| Balance as of December 28, 2013 | $ | (16.0 | ) |  | $ | (38.7 | ) |  | $ | (54.7 | ) |
| Other comprehensive loss before reclassifications: |  |  |  |  |  |
| Pre-tax loss | (18.2 | ) |  | — |  |  | (18.2 | ) |
| Income tax expense | — |  |  | — |  |  | — |  |
| Other comprehensive loss before reclassifications, net of income taxes | (18.2 | ) |  | — |  |  | (18.2 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income | — |  |  | 2.2 |  | (1) | 2.2 |  |
| Income tax expense | — |  |  | (0.7 | ) |  | (0.7 | ) |
| Amounts reclassified from accumulated other comprehensive income, net of income taxes | — |  |  | 1.5 |  |  | 1.5 |  |
| Net current period other comprehensive income/(loss), net of income taxes | (18.2 | ) |  | 1.5 |  |  | (16.7 | ) |
| Other comprehensive loss attributable to noncontrolling interest | (0.4 | ) |  | — |  |  | (0.4 | ) |
| Balance as of September 27, 2014 | $ | (33.8 | ) |  | $ | (37.2 | ) |  | $ | (71.0 | ) |

[0000038725-15-000195:notes:29]
[same as prior period, unchanged from 0000038725-15-000161:notes:29]


## us-gaap:DebtDisclosureTextBlock

[0000038725-15-000195:notes:30]
DEBT

[0000038725-15-000195:notes:31]
Debt consisted of the following:

[0000038725-15-000195:notes:32]
| (In millions) |  | October 3, 2015 |  | January 3, 2015 |
| Prudential Agreement - 5.79 percent |  | $ | 120.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 22.8 |  |  | 23.7 |  |
| New York Life |  | 75.0 |  |  | — |  |
| Revolver |  | 20.5 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.6 |  |
| Foreign subsidiary debt |  | 4.9 |  |  | 3.5 |  |
|  |  | $ | 243.3 |  |  | 177.8 |  |
| Less current maturities |  | (55.1 | ) |  | (34.1 | ) |
| Long-term debt |  | $ | 188.2 |  |  | $ | 143.7 |  |

[0000038725-15-000195:notes:33]
On May 5, 2015, the Company executed the following amendments: Amendment No. 6 to the Second Amended and Restated Note Purchase and Private Shelf Agreement with Prudential Investment Management, Inc.; Amendment No. 3 to the Credit Agreement; and Amendment No. 1 to the Bond Purchase and Loan Agreement.  Each of those amendments provides for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.

[0000038725-15-000195:notes:34]
On May 27, 2015, the Company entered into an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement") for $150.0 million maximum aggregate principal borrowing capacity and the Company authorized the issuance of $75.0 million of floating rate senior notes due May 27, 2025.  These series notes have a floating interest rate of one-month USD LIBOR plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  The New York Life Agreement contains customary affirmative and negative covenants and a cross default provision in the event the Company defaults on any obligation exceeding $10.0 million.  As of October 3, 2015, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-15-000195:notes:35]
On May 28, 2015, the Company entered into a Third Amended and Restated Note Purchase and Private Shelf Agreement with Prudential Investment Management, Inc. (the "Prudential Agreement") to increase the total borrowing capacity from $200.0 million to $250.0 million.  As of October 3, 2015, $120.0 million was outstanding under the Prudential Agreement.  Principal installments of $30.0 million are payable annually commencing on April 30, 2015 and continuing to and including April 30, 2019, with any unpaid balance due at maturity.  As of October 3, 2015, the Company had $100.0 million borrowing capacity under the Prudential Agreement.

[0000038725-15-000195:notes:36]
The following debt payments are expected to be paid in accordance with the following schedule:

[0000038725-15-000195:notes:37]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 243.2 |  |  | $ | 55.0 |  |  | $ | 31.5 |  |  | $ | 31.0 |  |  | $ | 31.2 |  |  | $ | 1.3 |  |  | $ | 93.2 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 243.3 |  |  | $ | 55.1 |  |  | $ | 31.5 |  |  | $ | 31.0 |  |  | $ | 31.2 |  |  | $ | 1.3 |  |  | $ | 93.2 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-15-000195:notes:38]
[same as prior period, unchanged from 0000038725-15-000161:notes:38]

[0000038725-15-000195:notes:39]
The Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  During February 2014, the Company entered into a share swap transaction agreement ("the swap") to mitigate the Company’s exposure to these fluctuations in the Company's stock price.  The Company renewed the swap agreement in February 2015. The swap was not designated as a hedge for accounting purposes and is cancellable with 30 days written notice by either party.  As of October 3, 2015, the swap has a notional value based on 175,000 shares.  For the third quarter and nine months ended October 3, 2015, the swap resulted in losses of $0.9 million and $1.9 million, respectively.  For the third quarter and nine months ended September 27, 2014, the swap resulted in losses of $0.8 million and $1.1 million, respectively.  Losses resulting from the swap were primarily offset by gains on the fair value of the deferred compensation stock liability.  All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-15-000195:notes:40]
[same as prior period, unchanged from 0000038725-15-000161:notes:40]

[0000038725-15-000195:notes:41]
[same as prior period, unchanged from 0000038725-15-000161:notes:41]

[0000038725-15-000195:notes:42]
[same as prior period, unchanged from 0000038725-15-000161:notes:42]

[0000038725-15-000195:notes:43]
[same as prior period, unchanged from 0000038725-15-000161:notes:43]

[0000038725-15-000195:notes:44]
[same as prior period, unchanged from 0000038725-15-000161:notes:44]

[0000038725-15-000195:notes:45]
[same as prior period, unchanged from 0000038725-15-000161:notes:45]

[0000038725-15-000195:notes:46]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the nine months ended October 3, 2015 and September 27, 2014, are as follows:

[0000038725-15-000195:notes:47]
|  |  | October 3, 2015 |  | September 27, 2014 |
| Risk-free interest rate |  | 1.59 | % |  | 1.68 | % |
| Dividend yield |  | 0.95 | % |  | 0.70 | % |
| Volatility factor |  | 0.379 |  |  | 0.387 |  |
| Expected term |  | 5.5 years |  |  | 5.6 years |  |
| Forfeiture rate |  | 3.67 | % |  | 3.81 | % |

[0000038725-15-000195:notes:48]
There were no stock options granted during the third quarters ended October 3, 2015 and September 27, 2014.

[0000038725-15-000195:notes:49]
A summary of the Company’s outstanding stock option activity and related information for the nine months ended October 3, 2015 and September 27, 2014 is as follows:

[0000038725-15-000195:notes:50]
| (Shares in thousands) |  | October 3, 2015 |  | September 27, 2014 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,397 |  |  | $ | 21.17 |  |  | 1,476 |  |  | $ | 19.01 |  |
| Granted |  | 185 |  |  | 36.67 |  |  | 115 |  |  | 42.24 |  |
| Exercised |  | (70 | ) |  | 17.63 |  |  | (76 | ) |  | 17.68 |  |
| Forfeited |  | (2 | ) |  | 34.93 |  |  | (4 | ) |  | 27.12 |  |
| Expired |  | — |  |  | — |  |  | (17 | ) |  | 16.34 |  |
| Outstanding at end of period |  | 1,510 |  |  | $ | 23.22 |  |  | 1,494 |  |  | $ | 20.88 |  |
| Expected to vest after applying forfeiture rate |  | 1,491 |  |  | $ | 23.04 |  |  | 1,479 |  |  | $ | 20.73 |  |
| Vested and exercisable at end of period |  | 1,144 |  |  | $ | 19.13 |  |  | 1,180 |  |  | $ | 17.69 |  |

[0000038725-15-000195:notes:51]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value as of October 3, 2015 is as follows:

[0000038725-15-000195:notes:52]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 4.94 years |  | $ | 10,271 |  |
| Expected to vest after applying forfeiture rate |  | 4.89 years |  | $ | 10,269 |  |
| Vested and exercisable at end of period |  | 3.78 years |  | $ | 10,157 |  |

[0000038725-15-000195:notes:53]
The total intrinsic value of options exercised during the nine months ended October 3, 2015 and September 27, 2014, was $1.3 million and $1.8 million, respectively.

[0000038725-15-000195:notes:54]
As of October 3, 2015, there was $1.8 million of total unrecognized compensation cost related to non-vested stock options granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.64 years.

[0000038725-15-000195:notes:55]
[same as prior period, unchanged from 0000038725-15-000161:notes:55]

[0000038725-15-000195:notes:56]
A summary of the Company’s restricted stock/stock unit award activity and related information for the nine months ended October 3, 2015 and September 27, 2014 is as follows:

[0000038725-15-000195:notes:57]
| (Shares in thousands) |  | October 3, 2015 |  | September 27, 2014 |
| Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 554 |  |  | $ | 32.72 |  |  | 551 |  |  | $ | 24.75 |  |
| Awarded |  | 134 |  |  | 36.28 |  |  | 208 |  |  | 42.39 |  |
| Vested |  | (169 | ) |  | 30.39 |  |  | (124 | ) |  | 16.76 |  |
| Forfeited |  | (9 | ) |  | 32.31 |  |  | (65 | ) |  | 28.79 |  |
| Non-vested at end of period |  | 510 |  |  | $ | 34.44 |  |  | 570 |  |  | $ | 32.46 |  |

[0000038725-15-000195:notes:58]
As of October 3, 2015, there was $9.0 million of total unrecognized compensation cost related to non-vested stock/stock unit awards granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.38 years.


## us-gaap:EarningsPerShareTextBlock

[0000038725-15-000195:notes:59]
[same as prior period, unchanged from 0000038725-15-000161:notes:59]

[0000038725-15-000195:notes:60]
[same as prior period, unchanged from 0000038725-15-000161:notes:60]

[0000038725-15-000195:notes:61]
[same as prior period, unchanged from 0000038725-15-000161:notes:61]

[0000038725-15-000195:notes:62]
[same as prior period, unchanged from 0000038725-15-000161:notes:62]

[0000038725-15-000195:notes:63]
|  | Third Quarter Ended |  | Nine Months Ended |
| (In millions, except per share amounts) | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 20.8 |  |  | $ | 22.7 |  |  | $ | 56.8 |  |  | $ | 66.7 |  |
| Less: Undistributed earnings allocated to participating securities | 0.2 |  |  | 0.2 |  |  | 0.5 |  |  | 0.7 |  |
| Less: Undistributed earnings allocated to redeemable noncontrolling interest | 0.2 |  |  | 0.4 |  |  | 0.4 |  |  | 0.6 |  |
|  | $ | 20.4 |  |  | $ | 22.1 |  |  | $ | 55.9 |  |  | $ | 65.4 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  |  |  |  |  |  |
| Weighted average common shares | 46.9 |  |  | 47.6 |  |  | 47.4 |  |  | 47.7 |  |
| Diluted |  |  |  |  |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |
| Non-participating employee incentive stock options and performance awards | 0.4 |  |  | 0.5 |  |  | 0.4 |  |  | 0.5 |  |
| Adjusted weighted average common shares | 47.3 |  |  | 48.1 |  |  | 47.8 |  |  | 48.2 |  |
| Basic earnings per share | $ | 0.44 |  |  | $ | 0.46 |  |  | $ | 1.18 |  |  | $ | 1.37 |  |
| Diluted earnings per share | $ | 0.43 |  |  | $ | 0.46 |  |  | $ | 1.17 |  |  | $ | 1.36 |  |
| Anti-dilutive stock options | 0.5 |  |  | 0.1 |  |  | 0.3 |  |  | 0.1 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000038725-15-000195:notes:64]
As of October 3, 2015 and January 3, 2015, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-15-000195:notes:65]
| (In millions) | October 3, 2015 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 3.2 |  | $ | 3.2 |  | $ | — |  | $ | — |  |
|  | January 3, 2015 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 5.4 |  | $ | 5.4 |  | $ | — |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-15-000195:notes:66]
[same as prior period, unchanged from 0000038725-15-000161:notes:66]

[0000038725-15-000195:notes:67]
[same as prior period, unchanged from 0000038725-15-000161:notes:67]

[0000038725-15-000195:notes:68]
[same as prior period, unchanged from 0000038725-15-000161:notes:68]

[0000038725-15-000195:notes:69]
[same as prior period, unchanged from 0000038725-15-000161:notes:69]

[0000038725-15-000195:notes:70]
[same as prior period, unchanged from 0000038725-15-000161:notes:70]

[0000038725-15-000195:notes:71]
[same as prior period, unchanged from 0000038725-15-000161:notes:71]

[0000038725-15-000195:notes:72]
Total debt, including current maturities, have carrying amounts of $243.2 million and $177.2 million and estimated fair values of $248.0 million and $191.1 million as of October 3, 2015 and January 3, 2015, respectively.  The fair value assumed short-term floating rate debt was valued at par.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.

[0000038725-15-000195:notes:73]
As of October 3, 2015, the Company had $1.6 million of assets held for sale recorded at carrying value in the Water Systems segment relating to a facility in Brazil.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-15-000195:notes:74]
[same as prior period, unchanged from 0000038725-15-000161:notes:74]

[0000038725-15-000195:notes:75]
Changes in carrying values for intangible assets are primarily attributed to the impact of foreign exchange for the nine months ended October 3, 2015.

[0000038725-15-000195:notes:76]
Amortization expense related to intangible assets for the third quarters ended October 3, 2015 and September 27, 2014 was $2.1 million and $2.7 million, respectively, and $6.5 million and $6.8 million for the nine months ended October 3, 2015 and September 27, 2014, respectively.

[0000038725-15-000195:notes:77]
[same as prior period, unchanged from 0000038725-15-000161:notes:77]

[0000038725-15-000195:notes:78]
| (In millions) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | 2019 |
|  |  | $ | 8.5 |  |  | $ | 8.4 |  |  | $ | 8.4 |  |  | $ | 8.3 |  |  | $ | 8.2 |  |

[0000038725-15-000195:notes:79]
The change in the carrying amount of goodwill by reporting segment for the nine months ended October 3, 2015, is as follows:

[0000038725-15-000195:notes:80]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Consolidated |
| Balance as of January 3, 2015 |  | $ | 145.3 |  |  | $ | 63.5 |  |  | $ | 208.8 |  |
| Adjustments to prior year acquisitions |  | 0.3 |  |  | (0.2 | ) |  | 0.1 |  |
| Foreign currency translation |  | (6.8 | ) |  | (0.2 | ) |  | (7.0 | ) |
| Balance as of October 3, 2015 |  | $ | 138.8 |  |  | $ | 63.1 |  |  | $ | 201.9 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-15-000195:notes:81]
[same as prior period, unchanged from 0000038725-15-000161:notes:81]

[0000038725-15-000195:notes:82]
[same as prior period, unchanged from 0000038725-15-000161:notes:82]

[0000038725-15-000195:notes:83]
The Company’s net unrecognized tax benefits decreased $1.8 million for federal and state income tax liabilities of prior years based on the expiration of statute of limitations and foreign currency fluctuations during the third quarter ending October 3, 2015.

[0000038725-15-000195:notes:84]
If recognized, the effective tax rate would be affected by the net unrecognized tax benefits of $4.4 million as of October 3, 2015.

[0000038725-15-000195:notes:85]
It is reasonably possible that the amounts of unrecognized tax benefits could change in the next twelve months due to the expiration of a statute of limitation by an amount up to $0.7 million.


## us-gaap:MinorityInterestDisclosureTextBlock

[0000038725-15-000195:notes:86]
[same as prior period, unchanged from 0000038725-15-000161:notes:83]

[0000038725-15-000195:notes:87]
[same as prior period, unchanged from 0000038725-15-000161:notes:84]

[0000038725-15-000195:notes:88]
The Company uses the interest method to accrete changes in the anticipated redemption value of the Impo redeemable noncontrolling interest over an amortization period to the earliest projected redemption date.  Accretion adjustments were $0.2 million and $0.4 million for the third quarter and nine months ended ended October 3, 2015, respectively, and $0.4 million and $0.6 million for the third quarter and nine months ended ended September 27, 2014.  These adjustments were reflected in the computation of earnings per share using the two-class method.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000038725-15-000195:notes:89]
ACCOUNTING PRONOUNCEMENTS

[0000038725-15-000195:notes:90]
Adoption of New Accounting Standards

[0000038725-15-000195:notes:91]
In February 2015, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2015-02, Consolidation (Topic 810), Amendments to the Consolidation Analysis.  The amendments affect both the variable interest entity and voting interest entity consolidation models.  The need to assess an entity under a different consolidation model may change previous consolidation conclusions.  The standard is effective for both interim and annual reporting periods beginning after December 15, 2015 and early adoption is permitted.  The Company has adopted this standard with no impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-15-000195:notes:92]
Accounting Standards Issued But Not Yet Adopted

[0000038725-15-000195:notes:93]
In September 2015, the FASB issued ASU 2015-16, Business Combinations (Topic 805): Simplifying the Accounting for Measurement-Period Adjustments.  The ASU will require an acquirer to recognize provisional amounts that are identified during the measurement period in the reporting period in which the adjustment amounts are determined rather than restating prior periods.  The ASU will be effective on a prospective basis for interim and annual period beginning after December 15, 2015.  The Company will adopt this new standard beginning with the 2016 fiscal year, and does not expect the adoption of this standard to have a material impact on the Company's consolidated financial position, results of operations, cash flows, and related disclosures.

[0000038725-15-000195:notes:94]
In July 2015, the FASB issued ASU 2015-11, Inventory (Topic 330): Simplifying the Measurement of Inventory.  The ASU will change the measurement principle for inventory from the lower of cost or market to the lower of cost and net realizable value.  Net realizable value is defined as the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal and transportation. ASU 2015-11 eliminates the guidance that entities consider replacement cost or net realizable value less an approximately normal profit margin in the subsequent measurement of inventory when cost is determined on a first-in, first-out or average cost basis.  The ASU will be effective on a prospective basis for interim and annual periods beginning after December 15, 2016, and early adoption is permitted.  The Company plans to early adopt this standard beginning with the 2016 fiscal year, but does not expect the adoption of this standard to have a material impact on the Company's consolidated financial position, results of operations, and related disclosures.

[0000038725-15-000195:notes:95]
In April 2015, the FASB issued ASU 2015-05, Intangibles-Goodwill and Other Internal-Use Software (Subtopic 350-40): Customer's Accounting for Fees Paid in a Cloud Computing Agreement.  The ASU will require an entity's management to assess, for each annual and interim period, whether a cloud computing arrangement includes a software license.  All software licenses within the scope of Subtopic 350-40 will be accounted for consistent with other licenses of intangible assets.  If the arrangement does not include a software license, the arrangement should be accounted for as a service contract.  The ASU will be effective for interim and annual periods beginning after December 15, 2015 and early adoption is permitted.  Entities will have the choice of prospective or retrospective adoption of the standard.  The Company does not expect the adoption of this standard beginning in the 2016 fiscal year to have a material impact on the Company's consolidated financial position, results of operations, cash flows, and related disclosures.

[0000038725-15-000195:notes:96]
In April 2015, the FASB issued ASU 2015-04, Compensation - Retirement Benefits (Topic 715): Practical Expedient for the Measurement Date of an Employer's Defined Benefit Obligation and Plan Assets, which allows an entity a practical expedient to measure defined benefit plan assets and obligations using the month end date that is closest to the entity's fiscal year end and apply that practical expedient consistently from year to year.  The practical expedient should be applied consistently to all plans if the entity has more than one plan.  The ASU will be effective on a prospective basis for interim and annual periods beginning after December 15, 2015 and early adoption is permitted.  The Company does not currently plan on electing the practical expedient for the 2016 fiscal year.

[0000038725-15-000195:notes:97]
In April 2015, the FASB issued ASU 2015-03, Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs, which requires debt issuance costs to be presented in the balance sheet as a direct deduction from the associated debt liability.  The standard will not change the amortization of debt issuance costs, which will continue to follow the existing accounting guidance.  In August 2015, the FASB issued ASU 2015-15, Interest-Imputation of Interest (Subtopic 835-30): Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements, which indicates the SEC staff would not object to an entity deferring and presenting debt issuance costs related to line-of-credit arrangements as an asset and subsequently amortizing the deferred debt issuance costs ratably over the term of the line-of-credit arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement.  These ASU's will be effective for interim and annual periods beginning after December 15, 2015 and early adoption is permitted.  These new standards will be adopted by the Company beginning with the 2016 fiscal year with the required change in accounting principle disclosures.  The Company does not expect the adoption of these standards to have a material impact on the Company's consolidated financial position, results of operations, cash flows, or related disclosures.

[0000038725-15-000195:notes:98]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606).  ASU 2014-09 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes current revenue recognition guidance.  In August 2015, the FASB issued ASU 2015-14, Revenue from Contracts with Customers (Topic 606): Deferral of the Effective Date.  The amendment in this update defers the effective date of ASU 2014-09 for all entities by one year to annual periods beginning after December 15, 2017.  Early adoption is permitted as of the original effective date, interim and annual reporting periods after December 15, 2016.  Entities have the option of using either a full retrospective or a modified retrospective approach to adopt ASU 2014-09.  The Company is still in the process of analyzing the effect of this new standard, including the transition method, to determine the impact on the Company's consolidated financial position, results of operations, cash flows, and related disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-15-000195:notes:99]
[same as prior period, unchanged from 0000038725-15-000161:notes:95]

[0000038725-15-000195:notes:100]
The accompanying condensed consolidated balance sheet as of January 3, 2015, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of October 3, 2015, and for the third quarter and nine months ended October 3, 2015 and September 27, 2014, have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the third quarter and nine months ended October 3, 2015, are not necessarily indicative of the results that may be expected for the fiscal year ending January 2, 2016.  For further information, including a description of the Company’s critical accounting policies, refer to the consolidated financial statements and notes thereto included in Franklin Electric Co., Inc.'s Annual Report on Form 10-K for the year ended January 3, 2015.


## us-gaap:OtherAssetsDisclosureTextBlock

[0000038725-15-000195:notes:101]
[same as prior period, unchanged from 0000038725-15-000161:notes:97]

[0000038725-15-000195:notes:102]
The Company has equity interests in various companies for various strategic purposes.  The investments are accounted for under the equity method and are included in “Other assets” on the Company’s condensed consolidated balance sheet.  The carrying amount of the investments is adjusted for the Company's proportionate share of earnings, losses, and dividends.  The investments are not considered material to the Company’s financial position, neither individually nor in the aggregate.  The Company’s proportionate share of earnings from its equity interests, included in the "Other income, net" line of the Company's condensed consolidated statements of income, were immaterial for the third quarter and nine months ended October 3, 2015 and September 27, 2014.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-15-000195:notes:103]
[same as prior period, unchanged from 0000038725-15-000161:notes:99]

[0000038725-15-000195:notes:104]
Defined Benefit Plans - As of October 3, 2015, the Company maintained two domestic pension plans and three German pension plans.  The Company used a January 3, 2015 measurement date for these plans.  One of the Company's domestic pension plans covers two management employees, while the other domestic plan covers all other eligible employees.  The two domestic and three German plans collectively comprise the 'Pension Benefits' disclosure caption.

[0000038725-15-000195:notes:105]
[same as prior period, unchanged from 0000038725-15-000161:notes:101]

[0000038725-15-000195:notes:106]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the third quarters and nine months ended October 3, 2015 and September 27, 2014, respectively:

[0000038725-15-000195:notes:107]
| (In millions) | Pension Benefits |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |
| Service cost | $ | 0.2 |  |  | $ | 0.3 |  |  | $ | 0.8 |  |  | $ | 1.0 |  |
| Interest cost | 1.9 |  |  | 2.1 |  |  | 5.5 |  |  | 6.2 |  |
| Expected return on assets | (2.4 | ) |  | (2.7 | ) |  | (7.4 | ) |  | (7.9 | ) |
| Amortization of prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of loss | 0.8 |  |  | 0.7 |  |  | 2.4 |  |  | 1.9 |  |
| Net periodic benefit cost | $ | 0.5 |  |  | $ | 0.4 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |
| Settlement cost | 0.3 |  |  | 0.3 |  |  | 0.9 |  |  | 0.7 |  |
| Total net periodic benefit cost | $ | 0.8 |  |  | $ | 0.7 |  |  | $ | 2.2 |  |  | $ | 1.9 |  |

[0000038725-15-000195:notes:108]
In the nine months ended October 3, 2015, the Company made contributions of $3.3 million to the funded plans.  The amount of contributions to be made to the plans during the calendar year 2015 were finalized by September 15, 2015, based upon the plans' year-end valuation at January 3, 2015, and the funding level required for the plans' year ended January 3, 2015.

[0000038725-15-000195:notes:109]
The following table sets forth the aggregated net periodic benefit cost for the postretirement benefit plan for the third quarters and nine months ended October 3, 2015 and September 27, 2014, respectively:

[0000038725-15-000195:notes:110]
|  | Other Benefits |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 0.1 |  |
| Interest cost | 0.1 |  |  | 0.2 |  |  | 0.3 |  |  | 0.4 |  |
| Expected return on assets | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | 0.3 |  |  | 0.3 |  |
| Amortization of loss | 0.1 |  |  | — |  |  | 0.3 |  |  | — |  |
| Net periodic benefit cost | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 0.9 |  |  | $ | 0.8 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Total net periodic benefit cost | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 0.9 |  |  | $ | 0.8 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000038725-15-000195:notes:111]
[same as prior period, unchanged from 0000038725-15-000161:notes:107]

[0000038725-15-000195:notes:112]
[same as prior period, unchanged from 0000038725-15-000161:notes:108]

[0000038725-15-000195:notes:113]
Costs incurred in the third quarter and nine months ended October 3, 2015, included in the “Restructuring expense” line of the Company's condensed consolidated statements of income, are as follows:

[0000038725-15-000195:notes:114]
|  |  | Third Quarter Ended |
|  |  | October 3, 2015 |
| (In millions) |  | Water Systems |  | Fueling Systems |  | Other |  | Consolidated |
| Employee severance |  | $ | 0.6 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.6 |  |
| Equipment relocation |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Other |  | 0.6 |  |  | — |  |  | — |  |  | 0.6 |  |
| Total |  | $ | 1.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 1.3 |  |
|  |  | Nine Months Ended |
|  |  | October 3, 2015 |
| (In millions) |  | Water Systems |  | Fueling Systems |  | Other |  | Consolidated |
| Employee severance |  | $ | 0.7 |  |  | $ | 0.3 |  |  | $ | — |  |  | $ | 1.0 |  |
| Equipment relocation |  | 0.4 |  |  | — |  |  | — |  |  | 0.4 |  |
| Other |  | 1.1 |  |  | — |  |  | — |  |  | 1.1 |  |
| Total |  | $ | 2.2 |  |  | $ | 0.3 |  |  | $ | — |  |  | $ | 2.5 |  |

[0000038725-15-000195:notes:115]
Restructuring expenses for the third quarter ended September 27, 2014 were approximately $1.1 million and primarily related to equipment relocation costs and other restructuring costs associated with various continued manufacturing realignments.  Restructuring expenses for the nine months ended September 27, 2014 were $1.5 million and primarily related to severance and equipment relocation.

[0000038725-15-000195:notes:116]
As of October 3, 2015, there were $3.6 million of restructuring reserves.  As of September 27, 2014, there were $0.3 million of restructuring reserves.  The restructuring reserves were primarily for severance.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000038725-15-000195:notes:117]
[same as prior period, unchanged from 0000038725-15-000161:notes:113]

[0000038725-15-000195:notes:118]
|  | Third Quarter Ended |  | Nine Months Ended |
| (In millions) | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |
|  | Net sales to external customers |
| Water Systems | $ | 173.5 |  |  | $ | 216.6 |  |  | $ | 544.3 |  |  | $ | 627.8 |  |
| Fueling Systems | 59.0 |  |  | 61.5 |  |  | 161.3 |  |  | 166.1 |  |
| Other | — |  |  | — |  |  | — |  |  | — |  |
| Consolidated | $ | 232.5 |  |  | $ | 278.1 |  |  | $ | 705.6 |  |  | $ | 793.9 |  |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | October 3, 2015 |  | September 27, 2014 |  | October 3, 2015 |  | September 27, 2014 |
|  | Operating income/(loss) |
| Water Systems | $ | 23.1 |  |  | $ | 28.3 |  |  | $ | 66.8 |  |  | $ | 99.3 |  |
| Fueling Systems | 15.4 |  |  | 15.4 |  |  | 37.4 |  |  | 37.9 |  |
| Other | (10.7 | ) |  | (11.3 | ) |  | (37.4 | ) |  | (39.7 | ) |
| Consolidated | $ | 27.8 |  |  | $ | 32.4 |  |  | $ | 66.8 |  |  | $ | 97.5 |  |
|  | October 3, 2015 |  | January 3, 2015 |  |  |  |  |
|  | Total assets |  |  |  |  |
| Water Systems | $ | 701.6 |  |  | $ | 757.5 |  |  |  |  |  |
| Fueling Systems | 249.6 |  |  | 252.7 |  |  |  |  |  |
| Other | 85.0 |  |  | 65.7 |  |  |  |  |  |
| Consolidated | $ | 1,036.2 |  |  | $ | 1,075.9 |  |  |  |  |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0000038725-15-000195:notes:119]
The schedule below sets forth equity changes in the nine months ended October 3, 2015:

[0000038725-15-000195:notes:120]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of January 3, 2015 | $ | 4,759 |  |  | $ | 207,446 |  |  | $ | 492,548 |  |  | $ | (56,124 | ) |  | $ | (51,789 | ) |  | $ | 2,143 |  |  | $ | 598,983 |  |  | $ | 6,420 |  |
| Net income |  |  |  |  | 56,784 |  |  |  |  |  |  | 468 |  |  | 57,252 |  |  | 188 |  |
| Adjustment to Impo redemption value |  |  |  |  | (369 | ) |  |  |  |  |  |  |  | (369 | ) |  | 369 |  |
| Dividends on common stock |  |  |  |  | (13,570 | ) |  |  |  |  |  |  |  | (13,570 | ) |  |  |
| Common stock issued | 7 |  |  | 1,233 |  |  |  |  |  |  |  |  |  |  | 1,240 |  |  |  |
| Common stock repurchased | (145 | ) |  |  |  | (43,185 | ) |  |  |  |  |  |  |  | (43,330 | ) |  |  |
| Share-based compensation | 15 |  |  | 4,564 |  |  |  |  |  |  |  |  |  |  | 4,579 |  |  |  |
| Tax benefit of stock options exercised |  |  | 1,542 |  |  |  |  |  |  |  |  |  |  | 1,542 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | (823 | ) |  | (823 | ) |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (53,851 | ) |  | (108 | ) |  | (53,959 | ) |  | (541 | ) |
| Pension liability, net of tax |  |  |  |  |  |  | 1,963 |  |  |  |  |  |  | 1,963 |  |  |  |
| Balance as of October 3, 2015 | $ | 4,636 |  |  | $ | 214,785 |  |  | $ | 492,208 |  |  | $ | (54,161 | ) |  | $ | (105,640 | ) |  | $ | 1,680 |  |  | $ | 553,508 |  |  | $ | 6,436 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-15-000195:notes:121]
[same as prior period, unchanged from 0000038725-15-000161:notes:117]

[0000038725-15-000195:notes:122]
Property, plant, and equipment is the major asset group in "Other" of total assets as of October 3, 2015 and January 3, 2015.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-15-000195:notes:123]
[same as prior period, unchanged from 0000038725-15-000161:notes:119]
