# FELE MD&A — 0000038725-15-000195


## mdna

[0000038725-15-000195:mdna:1]
[same as prior period, unchanged from 0000038725-15-000161:mdna:1]

[0000038725-15-000195:mdna:2]
Third Quarter 2015 vs. Third Quarter 2014

[0000038725-15-000195:mdna:3]
[same as prior period, unchanged from 0000038725-15-000161:mdna:3]

[0000038725-15-000195:mdna:4]
Sales and adjusted earnings in the third quarter of 2015 decreased from the third quarter last year.  The sales decrease was primarily due to volume decreases and the negative impact of foreign currency translation. The Company's consolidated gross profit was $76.8 million for the third quarter of 2015, a decrease of $12.4 million or about 14 percent from the prior year’s third quarter.

[0000038725-15-000195:mdna:5]
[same as prior period, unchanged from 0000038725-15-000161:mdna:5]

[0000038725-15-000195:mdna:6]
[same as prior period, unchanged from 0000038725-15-000161:mdna:6]

[0000038725-15-000195:mdna:7]
Net sales in the third quarter of 2015 were $232.5 million, a decrease of $45.6 million or about 16 percent compared to 2014 third quarter sales of $278.1 million.  The incremental impact of sales from acquired businesses was $2.6 million or about 1 percent.  Sales revenue decreased by $27.4 million or about 10 percent in the third quarter of 2015 due to foreign currency translation. The sales change in the third quarter of 2015, excluding acquisitions and foreign currency translation, was a decrease of $20.8 million or about 7 percent.

[0000038725-15-000195:mdna:8]
|  | Net Sales |
| (In millions) | Q3 2015 |  | Q3 2014 |  | 2015 v 2014 |
| Water Systems | $ | 173.5 |  |  | $ | 216.6 |  |  | $ | (43.1 | ) |
| Fueling Systems | 59.0 |  |  | 61.5 |  |  | (2.5 | ) |
| Consolidated | $ | 232.5 |  |  | $ | 278.1 |  |  | $ | (45.6 | ) |

[0000038725-15-000195:mdna:9]
[same as prior period, unchanged from 0000038725-15-000161:mdna:9]

[0000038725-15-000195:mdna:10]
Water Systems sales were $173.5 million in the third quarter 2015, a decrease of $43.1 million or about 20 percent versus the third quarter 2014 sales of $216.6 million.  Sales from businesses acquired since the third quarter of 2014 were $2.4 million or about 1 percent.  Water Systems sales were reduced by $24.2 million or about 11 percent in the quarter due to foreign currency translation.  Excluding acquisitions and foreign currency translation, Water Systems sales were down about 10 percent compared to the third quarter 2014.

[0000038725-15-000195:mdna:11]
Water Systems sales in the U.S. and Canada represented 37 percent of consolidated sales and declined by about 22 percent compared to the prior year. Water Systems sales in the U.S and Canada were reduced by $1.9 million or about 2 percent in the quarter due to foreign currency translation.  In the third quarter 2015, U.S. and Canada sales of Pioneer branded mobile dewatering equipment declined by 60 percent. The decline in mobile dewatering equipment is primarily attributed to reduced demand in the oil and gas end markets.  Sales of groundwater pumping equipment declined by about 10 percent.  The decline in groundwater equipment sales is attributable primarily to weak demand for agricultural related products in key end markets in the central region of the U.S.  Finally, sales of surface water pumping equipment declined by about 12 percent versus the third quarter 2014, primarily due to lower wastewater product sales.

[0000038725-15-000195:mdna:12]
Water Systems sales in Latin America were about 13 percent of consolidated sales for the third quarter and declined by about 23 percent compared to the third quarter of the prior year.  Water Systems sales were reduced by $12.3 million or about 31 percent in the quarter due to foreign currency translation. Excluding the impact of foreign currency translation, Latin American sales increased by about 8 percent compared to the third quarter 2014.  This growth in sales was led by increased sales in Central America and Argentina.  Sales of Water Systems products in Brazil increased about 3 percent in local currency during the third quarter.

[0000038725-15-000195:mdna:13]
Water Systems sales in the Middle East and Africa were about 10 percent of consolidated sales and decreased by about 18 percent compared to the third quarter 2014.  Water Systems sales were reduced by about 16 percent in the quarter due to foreign currency translation.  Excluding the impact of foreign currency translation, sales decreased by about 2 percent compared to the third quarter 2014. The decline was driven by lower sales in Turkey.

[0000038725-15-000195:mdna:14]
Water Systems sales in the Asia Pacific region were 7 percent of consolidated sales and were down about 4 percent compared

[0000038725-15-000195:mdna:15]
to the third quarter prior year.  Excluding acquisitions and the impact of foreign currency translation, Asia Pacific sales decreased by about 1 percent compared to the third quarter 2014.  The Asia Pacific region experienced year over year growth in groundwater product sales of 7 percent, but this improvement was offset by a decline in Pioneer branded mobile dewatering equipment in Australia compared to a very strong third quarter 2014.

[0000038725-15-000195:mdna:16]
Water Systems sales in Europe were about 7 percent of consolidated sales and decreased by about 20 percent compared to the third quarter 2014.  The impact of foreign currency translation decreased sales by about 20 percent compared to the third quarter 2014.  Excluding currency translation, European sales were flat versus the third quarter of 2014.

[0000038725-15-000195:mdna:17]
[same as prior period, unchanged from 0000038725-15-000161:mdna:18]

[0000038725-15-000195:mdna:18]
Fueling Systems sales represented 25 percent of consolidated sales and were $59.0 million in the third quarter 2015, a decrease of $2.5 million or about 4 percent versus the third quarter 2014 sales of $61.5 million. Sales from businesses acquired since the third quarter of 2014 were $0.2 million or less than 1 percent. Fueling Systems sales decreased by $3.2 million or about 5 percent in the quarter due to foreign currency translation. Fueling Systems sales increased by $0.5 million or about 1 percent after excluding acquisitions and foreign currency translation.

[0000038725-15-000195:mdna:19]
Fueling Systems sales in the U.S. and Canada grew by about 8 percent during the quarter with most of the sales growth coming from fuel dispensing products and piping.  Fueling Systems revenues declined in India and China due to the timing of tender awards made in India and the ongoing reduction in State owned oil company procurements in China.  Sales also declined in Europe principally due to a 45 percent decline in the sale of storage tanks that support North Sea oil production.

[0000038725-15-000195:mdna:20]
[same as prior period, unchanged from 0000038725-15-000161:mdna:21]

[0000038725-15-000195:mdna:21]
Cost of sales as a percent of net sales for the third quarter of 2015 and 2014 was 67.0 percent and 67.9 percent, respectively. Correspondingly, the gross profit margin increased to 33.0 percent from 32.1 percent, a 90 basis point improvement.  The Company’s consolidated gross profit was $76.8 million for the third quarter of 2015, a decrease of $12.4 million, or about 14 percent, from the third quarter of 2014 gross profit of $89.2 million. The decrease in gross profit is due to lower sales volume. The gross profit margin increase was primarily due to lower direct material costs and an improved sales mix of Water Systems products.

[0000038725-15-000195:mdna:22]
[same as prior period, unchanged from 0000038725-15-000161:mdna:23]

[0000038725-15-000195:mdna:23]
Selling, general, and administrative (SG&A) expenses were $47.7 million in the third quarter of 2015 compared to $55.6 million in the third quarter of prior year, a decrease of $7.9 million or about 14 percent.  The Company’s SG&A expenses decreased in the quarter primarily due to lower marketing and selling related expenses, as well as lower costs for incentive compensation.  Approximately half of the lower SG&A expenses was related to foreign exchange.

[0000038725-15-000195:mdna:24]
[same as prior period, unchanged from 0000038725-15-000161:mdna:25]

[0000038725-15-000195:mdna:25]
Restructuring expenses for the third quarter of 2015 were $1.3 million and had a $0.02 impact on diluted earnings per share. Restructuring expenses for the third quarter 2015 included $0.6 million in severance cost, $0.1 million in expenses related to equipment transfers, freight and relocation cost primarily in Europe related to the transfer of production activities from Germany to the Czech Republic and $0.6 million of other restructuring costs from continued manufacturing realignments.

[0000038725-15-000195:mdna:26]
Restructuring expenses for the third quarter of 2014 were $1.1 million or about $0.01 diluted earnings per share.

[0000038725-15-000195:mdna:27]
Restructuring expenses for the third quarter 2014 included $0.4 million of expenses related to equipment transfers, freight and relocation cost incurred in Brazil moving into the new manufacturing facility and in Europe related to the transfer of production activities from Germany to the Czech Republic, $0.4 million of other restructuring costs related to Europe and other continued manufacturing realignments, $0.2 million in severance cost and $0.1 million in asset write-offs.

[0000038725-15-000195:mdna:28]
[same as prior period, unchanged from 0000038725-15-000161:mdna:27]

[0000038725-15-000195:mdna:29]
Operating income was $27.8 million in the third quarter of 2015, down $4.6 million or about 14 percent from $32.4 million in the third quarter of 2014.

[0000038725-15-000195:mdna:30]
|  |  | Operating income (loss) |
| (In millions) |  | Q3 2015 |  | Q3 2014 |  | 2015 v 2014 |
| Water Systems |  | $ | 23.1 |  |  | $ | 28.3 |  |  | $ | (5.2 | ) |
| Fueling Systems |  | 15.4 |  |  | 15.4 |  |  | — |  |
| Other |  | (10.7 | ) |  | (11.3 | ) |  | 0.6 |  |
| Consolidated |  | $ | 27.8 |  |  | $ | 32.4 |  |  | $ | (4.6 | ) |

[0000038725-15-000195:mdna:31]
There were specific items in the third quarter of 2015 and 2014 that impacted operating income that were not operational in nature.  In the third quarter of 2015 there were three such items: $1.3 million of restructuring charges, $0.3 million related to executive transition and $0.1 million related to business realignment cost, primarily severance, in targeted fixed cost reduction actions.

[0000038725-15-000195:mdna:32]
In the third quarter of 2014 there were three such items: $1.1 million of restructuring charges, $1.1 in software write-offs related to Pioneer rental and $0.8 million for pending and completed acquisition related activities.

[0000038725-15-000195:mdna:33]
The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of operating income after non-GAAP adjustments and percent operating income after non-GAAP adjustments to net sales (operating income margin after non-GAAP adjustments).  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-15-000195:mdna:34]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (In millions) | For the Third Quarter 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 23.1 |  | $ | 15.4 |  | $ | (10.7 | ) | $ | 27.8 |  |
| % Operating Income To Net Sales | 13.3 | % | 26.1 | % |  | 12.0 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 1.3 |  | $ | — |  | $ | — |  | $ | 1.3 |  |
| Non-GAAP | $ | 0.1 |  | $ | — |  | $ | 0.3 |  | $ | 0.4 |  |
| Operating Income after Non-GAAP Adjustments | $ | 24.5 |  | $ | 15.4 |  | $ | (10.4 | ) | $ | 29.5 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 14.1 | % | 26.1 | % |  | 12.7 | % |
|  | For the Third Quarter 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 28.3 |  | $ | 15.4 |  | $ | (11.3 | ) | $ | 32.4 |  |
| % Operating Income To Net Sales | 13.1 | % | 25.0 | % |  | 11.7 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 1.0 |  | $ | 0.1 |  | $ | — |  | $ | 1.1 |  |
| Non-GAAP | $ | 1.7 |  | $ | 0.2 |  | $ | — |  | $ | 1.9 |  |
| Operating Income after Non-GAAP Adjustments | $ | 31.0 |  | $ | 15.7 |  | $ | (11.3 | ) | $ | 35.4 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 14.3 | % | 25.5 | % |  | 12.7 | % |

[0000038725-15-000195:mdna:35]
25

[0000038725-15-000195:mdna:36]
[same as prior period, unchanged from 0000038725-15-000161:mdna:33]

[0000038725-15-000195:mdna:37]
Water Systems operating income, after non-GAAP adjustments, was $24.5 million in the third quarter 2015, down $6.5 million versus the third quarter 2014. The third quarter operating income margin after non-GAAP adjustments was 14.1 percent, down 20 basis points from 14.3 percent in the third quarter of 2014.

[0000038725-15-000195:mdna:38]
[same as prior period, unchanged from 0000038725-15-000161:mdna:37]

[0000038725-15-000195:mdna:39]
Fueling Systems operating income after non-GAAP adjustments was $15.4 million in the third quarter of 2015 compared to $15.7 million after non-GAAP adjustments in the third quarter of 2014, a decrease of about 2 percent. The third quarter operating income margin after non-GAAP adjustments was 26.1 percent, an increase of 60 basis points from the 25.5 percent of net sales in the third quarter of 2014.  The increase in basis points was primarily due to improved margins from lower variable costs.

[0000038725-15-000195:mdna:40]
[same as prior period, unchanged from 0000038725-15-000161:mdna:39]

[0000038725-15-000195:mdna:41]
Operating income-other is composed primarily of unallocated general and administrative expenses.  General and administrative expenses after non-GAAP adjustments were lower about 8 percent after adjusting our cost structure in reaction to the lower sales run rate.

[0000038725-15-000195:mdna:42]
[same as prior period, unchanged from 0000038725-15-000161:mdna:41]

[0000038725-15-000195:mdna:43]
Interest expense for the third quarter of 2015 and 2014 was $2.6 million and $2.7 million, respectively.

[0000038725-15-000195:mdna:44]
[same as prior period, unchanged from 0000038725-15-000161:mdna:43]

[0000038725-15-000195:mdna:45]
Other income or expense was income of $1.6 million in the third quarter of 2015 and income of $0.4 million in the third quarter of 2014.  Included in other income in the third quarter of 2015 was minority income of $1.0 million and interest income of $0.3 million, primarily derived from the investment of cash balances in short-term securities. Included in other income in the third quarter of 2014 was interest income of $0.5 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-15-000195:mdna:46]
[same as prior period, unchanged from 0000038725-15-000161:mdna:45]

[0000038725-15-000195:mdna:47]
Foreign currency-based transactions produced a loss for the third quarter of 2015 of $0.1 million.  Foreign currency-based transactions produced a loss for the third quarter of 2014 of $0.5 million primarily due to the Turkish lira relative to the U.S. dollar.

[0000038725-15-000195:mdna:48]
[same as prior period, unchanged from 0000038725-15-000161:mdna:47]

[0000038725-15-000195:mdna:49]
The provision for income taxes in the third quarter of 2015 and 2014 was $5.7 million and $6.7 million, respectively. The effective tax rate for the third quarter of 2015 was about 27 percent, up from the third quarter 2014 tax rate before discrete adjustments of about 25 percent.  The tax rate as a percentage of pre-tax earnings for the third quarter of 2015 was about 21 percent primarily due to the completion of income tax audits and the favorable resolution of matters previously under review. The projected tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings and reduced taxes on foreign and repatriated earnings after the restructuring of certain foreign entities. The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations, current cash on hand and available credit.

[0000038725-15-000195:mdna:50]
[same as prior period, unchanged from 0000038725-15-000161:mdna:49]

[0000038725-15-000195:mdna:51]
Net income for the third quarter of 2015 was $21.0 million compared to the prior year third quarter net income of $22.8 million.  Net income attributable to Franklin Electric Co., Inc. for the third quarter of 2015 was $20.8 million, or $0.43 per diluted share, compared to the prior year third quarter net income attributable to Franklin Electric Co., Inc. of $22.7 million or $0.46 per diluted share. Earnings after non-GAAP adjustments for the third quarter of 2015 were $21.4 million, or $0.45 per diluted share, compared to the prior year third quarter earnings after non-GAAP adjustments of $24.0 million or $0.50 per diluted share.

[0000038725-15-000195:mdna:52]
There were specific items in the third quarter of 2015 and 2014 that impacted net income attributable to Franklin Electric Co., Inc. that were not operational in nature.  The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of earnings after non-GAAP adjustments and adjusted EPS.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-15-000195:mdna:53]
| Earnings Before and After Non-GAAP Adjustments | For the Third Quarter Ended |
| (In millions) | 2015 | 2014 | Change |
| Net Income attributable to Franklin Electric Co., Inc. Reported | $ | 20.8 |  | $ | 22.7 |  | (8 | )% |
| Allocated Undistributed Earnings | $ | (0.4 | ) | $ | (0.6 | ) |  |
| Adjusted Earnings for EPS Calculations | $ | 20.4 |  | $ | 22.1 |  | (8 | )% |
| Non-GAAP adjustments, before tax: |  |  |  |
| Restructuring | $ | 1.3 |  | $ | 1.1 |  |  |
| Non-GAAP items | $ | 0.4 |  | $ | 1.9 |  |  |
| Non-GAAP adjustments, net of tax: |  |  |  |
| Restructuring | $ | 0.8 |  | $ | 0.7 |  |  |
| Non-GAAP items | $ | 0.2 |  | $ | 1.2 |  |  |
| Net Income attributable to Franklin Electric Co., Inc. after Non-GAAP Adjustments (Adjusted Net Income) | $ | 21.4 |  | $ | 24.0 |  | (11 | )% |

[0000038725-15-000195:mdna:54]
| Earnings Per Share Before and After Non-GAAP Adjustments | For the Third Quarter Ended |
| (In millions, except per share data) | 2015 | 2014 | Change |
| Average Fully Diluted Shares Outstanding | 47.3 |  | 48.1 |  | (2 | )% |
| Fully Diluted Earnings Per Share ("EPS") Reported | $ | 0.43 |  | $ | 0.46 |  | (7 | )% |
| Restructuring per Share, net of tax | $ | 0.02 |  | $ | 0.01 |  |  |
| Non-GAAP items | $ | — |  | $ | 0.03 |  |  |
| Fully Diluted EPS after Non-GAAP Adjustments (Adjusted EPS) | $ | 0.45 |  | $ | 0.50 |  | (10 | )% |

[0000038725-15-000195:mdna:55]
First Nine Months of 2015 vs. First Nine Months of 2014

[0000038725-15-000195:mdna:56]
[same as prior period, unchanged from 0000038725-15-000161:mdna:55]

[0000038725-15-000195:mdna:57]
Sales and earnings in the first nine months of 2015 were down from the same period last year.  The sales decrease was related to the negative impact of foreign currency translation on sales and volume decreases partially offset by acquisitions and price increases. The Company's consolidated gross profit was $228.5 million for the first nine months of 2015, a decrease of $38.2 million or about 14 percent from the first nine months of 2014.

[0000038725-15-000195:mdna:58]
[same as prior period, unchanged from 0000038725-15-000161:mdna:57]

[0000038725-15-000195:mdna:59]
[same as prior period, unchanged from 0000038725-15-000161:mdna:58]

[0000038725-15-000195:mdna:60]
Net sales in the first nine months of 2015 were $705.6 million, a decrease of $88.3 million or about 11 percent compared to 2014 first nine months sales of $793.9 million.  The incremental impact of sales from acquired businesses was $20.0 million or about 3 percent.  Sales revenue decreased by $66.4 million or about 8 percent in the first nine months of 2015 due to foreign currency translation. The sales change in the first nine months of 2015, excluding acquisitions and foreign currency translation, was a decrease of $41.9 million or about 5 percent.

[0000038725-15-000195:mdna:61]
27

[0000038725-15-000195:mdna:62]
| (In millions) | YTD October 3, 2015 |  | YTD September 27, 2014 |  | 2015 v 2014 |
|  | Net Sales |
| Water Systems | $ | 544.3 |  |  | $ | 627.8 |  |  | $ | (83.5 | ) |
| Fueling Systems | 161.3 |  |  | 166.1 |  |  | (4.8 | ) |
| Consolidated | $ | 705.6 |  |  | $ | 793.9 |  |  | $ | (88.3 | ) |

[0000038725-15-000195:mdna:63]
[same as prior period, unchanged from 0000038725-15-000161:mdna:62]

[0000038725-15-000195:mdna:64]
Water Systems sales were $544.3 million in the first nine months 2015, a decrease of $83.5 million or about 13 percent versus the first nine months 2014. The incremental impact of sales from acquired businesses was $19.5 million or 3 percent. Foreign currency translation rate changes decreased sales $57.4 million, or about 9 percent, compared to sales in the first nine months of 2014. The Water Systems sales change in the first nine months of 2015, excluding acquisitions and foreign currency translation, was a decrease of $45.6 million or about 7 percent.

[0000038725-15-000195:mdna:65]
Water Systems sales in the U.S. and Canada were 37 percent of consolidated sales and declined by about 20 percent compared to the first nine months of 2014. Sales revenue decreased by $4.3 million or about 1 percent in the first nine months of 2015 due to foreign currency translation.  In the first nine months of 2015, U.S. and Canada sales of Pioneer branded mobile dewatering equipment declined by about 57 percent. The decline in mobile dewatering equipment is primarily attributed to reduced demand in the oil and gas end markets. Sales of groundwater pumping equipment declined by about 15 percent, and sales of surface water pumping equipment declined by about 7 percent versus the first nine months of 2014.  The decline in groundwater equipment sales is attributable primarily to the near record precipitation experienced in many key markets and across the U.S. in general.  Additionally, demand for groundwater and surface pumping equipment declined due to excessive customer inventories that were being worked down.  Sales of surface water pumping equipment also declined due to lower condensate pump sales as cooler temperatures delayed the start to the HVAC season.

[0000038725-15-000195:mdna:66]
Water Systems sales in Latin America were about 14 percent of consolidated sales for the first nine months and declined by about 3 percent compared to the prior year's first nine months.  The incremental impact of sales from acquired businesses was $10.4 million or about 10 percent. Sales revenue decreased by $23.9 million or about 24 percent in the first nine months of 2015 due to foreign currency translation. The sales change in the first nine months of 2015, excluding acquisitions and foreign currency translation, was an increase of $10.3 million or about 10 percent.  The growth in sales was led by increased sales in Mexico and Brazil, in local currency.  This sales growth is a result of increasing demand for Franklin submersible pumps and motors, customer acceptance of the many product line upgrades that have been implemented over the past two years, and general market conditions.

[0000038725-15-000195:mdna:67]
Water Systems sales in the Middle East and Africa were about 11 percent of consolidated sales and declined by about 10 percent compared to the first nine months of 2014. Water Systems in the Middle East and Africa were reduced by $11.5 million or about 12 percent due to foreign currency translation. Excluding the impact of foreign currency translation, sales were up $2.8 million or about 3 percent compared to the first nine months of 2014. The growth was driven by strong sales of groundwater pumping equipment in Turkey.

[0000038725-15-000195:mdna:68]
Water Systems sales in the Asia Pacific region were 8 percent of consolidated sales and increased by about 11 percent compared to the first nine months of the prior year. The incremental impact of sales from acquired businesses was $6.1 million or about 12 percent.  Sales revenue decreased by about 6 percent in the first nine months of 2015 due to foreign currency translation. The sales change in the first nine months of 2015, excluding acquisitions and foreign currency translation, was an increase about 5 percent. The Asia Pacific region experienced strong year over year growth in Southeast Asia and Korea.

[0000038725-15-000195:mdna:69]
Water Systems sales in Europe were about 7 percent of consolidated sales and declined by about 20 percent compared to the first nine months of 2014.  Sales in Europe in the first nine months of 2015 decreased by $14.8 million or about 23 percent due to foreign currency translation. Excluding the impact of foreign currency translation, European sales increased by about 3 percent compared to the first nine months of 2014.

[0000038725-15-000195:mdna:70]
[same as prior period, unchanged from 0000038725-15-000161:mdna:70]

[0000038725-15-000195:mdna:71]
Fueling Systems sales were $161.3 million or about 23 percent of consolidated sales in the first nine months of 2015 and decreased $4.8 million or about 3 percent from the first nine months of 2014. The incremental impact of sales from acquired businesses was $0.5 million or less than 1 percent. Foreign currency translation rate changes decreased sales $9.0 million or about 5 percent compared to sales in the first nine months of 2014. The Fueling Systems sales change in the first nine months of 2015, excluding acquisitions and foreign currency translation, was an increase of $3.7 million or about 2 percent.

[0000038725-15-000195:mdna:72]
Fueling Systems sales in the U.S. and Canada grew by about 6 percent during the first nine months with sales growth coming from most product lines, especially in piping.  Fueling Systems revenues declined in India and China due to the timing of tender awards made in India and the ongoing reduction in State owned oil company procurements in China.  Sales also declined in Europe principally due to a reduction in the sale of storage tanks that support North Sea oil production.

[0000038725-15-000195:mdna:73]
[same as prior period, unchanged from 0000038725-15-000161:mdna:74]

[0000038725-15-000195:mdna:74]
Cost of sales as a percent of net sales for the first nine months of 2015 and 2014 was 67.6 percent and 66.4 percent, respectively. Correspondingly, the gross profit margin was 32.4 percent and 33.6 percent for the first nine months of both years. The Company's consolidated gross profit was $228.5 million for the first nine months of 2015, down $38.2 million from the gross profit of $266.7 million in the first nine months of 2014. The gross profit margin decrease was primarily due to higher raw material costs and fixed costs deleverage on lower sales.

[0000038725-15-000195:mdna:75]
[same as prior period, unchanged from 0000038725-15-000161:mdna:76]

[0000038725-15-000195:mdna:76]
Selling, general, and administrative expenses were $159.2 million in the first nine months of 2015 and decreased by $8.4 million or 5 percent in the first nine months of 2015 compared to $167.6 million the first nine months of last year. There were $1.6 million of costs included in non-GAAP adjustments related to executive transition, business realignment cost and pending or completed acquisitions in the first nine months of 2015. There were $4.7 million of costs included in non-GAAP adjustments related to executive transition and pending or completed acquisitions in the first nine months of 2014. Excluding these non-GAAP adjustments, SG&A expenses were $157.6 million in the first nine months of 2015 and decreased by $5.3 million or about 3 percent in the first nine months of 2015 compared to $162.9 million the first nine months of last year. In the first nine months of 2015, increases in SG&A attributable to acquisitions were $4.9 million. Excluding the acquisitions, the Company’s overall SG&A expenses in the first nine months of 2015 decreased by $10.2 million or about 6 percent to prior year a portion of which was related to foreign exchange.

[0000038725-15-000195:mdna:77]
[same as prior period, unchanged from 0000038725-15-000161:mdna:78]

[0000038725-15-000195:mdna:78]
Restructuring expenses for the first nine months of 2015 were $2.5 million and reduced diluted earnings per share by approximately $0.03. Restructuring expenses were primarily related to the continuing European and Brazilian manufacturing realignments started last year. Restructuring expenses were primarily severance expenses, equipment relocations and other miscellaneous manufacturing realignment activities. Restructuring expenses for the first nine months of 2014 were $1.5 million and reduced diluted earnings per share by $0.01.

[0000038725-15-000195:mdna:79]
[same as prior period, unchanged from 0000038725-15-000161:mdna:80]

[0000038725-15-000195:mdna:80]
Operating income was $66.8 million in the first nine months of 2015, down $30.7 million or about 31 percent from $97.5 million in the first nine months of 2014.

[0000038725-15-000195:mdna:81]
| (In millions) |  | YTDOctober 3, 2015 |  | YTDSeptember 27, 2014 |  | 2015 v 2014 |
|  |  | Operating income (loss) |
| Water Systems |  | $ | 66.8 |  |  | $ | 99.3 |  |  | $ | (32.5 | ) |
| Fueling Systems |  | 37.4 |  |  | 37.9 |  |  | (0.5 | ) |
| Other |  | (37.4 | ) |  | (39.7 | ) |  | 2.3 |  |
| Consolidated |  | $ | 66.8 |  |  | $ | 97.5 |  |  | $ | (30.7 | ) |

[0000038725-15-000195:mdna:82]
There were specific items in the first nine months of 2015 and 2014 that impacted operating income that were not operational in nature.

[0000038725-15-000195:mdna:83]
In the first nine months of 2015 they were as follows:

[0000038725-15-000195:mdna:84]
| • | There were $2.5 million of restructuring charges. Restructuring expenses were severance expenses and other miscellaneous manufacturing realignment activities, primarily related to the continued European and Brazilian realignment activities. |

[0000038725-15-000195:mdna:85]
| • | Executive transition costs were $0.9 million. |

[0000038725-15-000195:mdna:86]
| • | Business realignment cost, primarily severance, in targeted fixed cost reduction actions of $0.5 million. |

[0000038725-15-000195:mdna:87]
| • | Other miscellaneous costs related to closed and pending acquisitions were $0.2 million. |

[0000038725-15-000195:mdna:88]
In the first nine months of 2014 they were as follows:

[0000038725-15-000195:mdna:89]
| • | There were $1.5 million of restructuring charges. Restructuring expenses were severance expenses and other miscellaneous manufacturing realignment activities, primarily related to the continued European and Brazilian realignment activities. |

[0000038725-15-000195:mdna:90]
| • | Executive transition costs were $2.5 million. |

[0000038725-15-000195:mdna:91]
| • | Other miscellaneous costs related to closed and pending acquisitions were $1.7 million. |

[0000038725-15-000195:mdna:92]
| • | Software write-offs related to Pioneer rental were $1.1 million. |

[0000038725-15-000195:mdna:93]
The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of operating income after non-GAAP adjustments and percent operating income after non-GAAP adjustments to net sales (operating income margin after non-GAAP adjustments).  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-15-000195:mdna:94]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the First Nine Months of 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 66.8 |  | $ | 37.4 |  | $ | (37.4 | ) | $ | 66.8 |  |
| % Operating Income To Net Sales | 12.3 | % | 23.2 | % |  | 9.5 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 2.2 |  | $ | 0.3 |  | $ | — |  | $ | 2.5 |  |
| Non-GAAP | $ | 0.6 |  | $ | 0.1 |  | $ | 0.9 |  | $ | 1.6 |  |
| Operating Income after Non-GAAP Adjustments | $ | 69.6 |  | $ | 37.8 |  | $ | (36.5 | ) | $ | 70.9 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 12.8 | % | 23.4 | % |  | 10.0 | % |
|  | For the First Nine Months of 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 99.3 |  | $ | 37.9 |  | $ | (39.7 | ) | $ | 97.5 |  |
| % Operating Income To Net Sales | 15.8 | % | 22.8 | % |  | 12.3 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 1.4 |  | $ | 0.1 |  | $ | — |  | $ | 1.5 |  |
| Non-GAAP | $ | 2.2 |  | $ | 0.6 |  | $ | 2.5 |  | $ | 5.3 |  |
| Operating Income after Non-GAAP Adjustments | $ | 102.9 |  | $ | 38.6 |  | $ | (37.2 | ) | $ | 104.3 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 16.4 | % | 23.2 | % |  | 13.1 | % |

[0000038725-15-000195:mdna:95]
[same as prior period, unchanged from 0000038725-15-000161:mdna:96]

[0000038725-15-000195:mdna:96]
Water Systems operating income, after non-GAAP adjustments, was $69.6 million in the first nine months of 2015 compared to $102.9 million after non-GAAP adjustments in the first nine months of 2014, a decrease of 32 percent. The first nine months operating income margin after non-GAAP adjustments was 12.8 percent and decreased by 360 basis points compared to the first nine months of 2014. Operating income margin after non-GAAP adjustments decreased in Water Systems primarily due to loss of operating leverage.

[0000038725-15-000195:mdna:97]
30

[0000038725-15-000195:mdna:98]
[same as prior period, unchanged from 0000038725-15-000161:mdna:98]

[0000038725-15-000195:mdna:99]
Fueling Systems operating income after non-GAAP adjustments was $37.8 million in the first nine months of 2015 compared to $38.6 million after non-GAAP adjustments in the first nine months of 2014, a decrease of 2 percent. The first nine months operating income margin after non-GAAP adjustments was 23.4 percent flat compared to the percent of net sales in the first nine months of 2014.

[0000038725-15-000195:mdna:100]
[same as prior period, unchanged from 0000038725-15-000161:mdna:100]

[0000038725-15-000195:mdna:101]
Operating income-other is composed primarily of unallocated general and administrative expenses.  General and administrative expenses after non-GAAP adjustments were down about 2 percent compared to last year primarily due to lower incentive compensation.

[0000038725-15-000195:mdna:102]
[same as prior period, unchanged from 0000038725-15-000161:mdna:102]

[0000038725-15-000195:mdna:103]
Interest expense for the first nine months of 2015 and 2014 was $7.7 million and $8.0 million, respectively.

[0000038725-15-000195:mdna:104]
[same as prior period, unchanged from 0000038725-15-000161:mdna:104]

[0000038725-15-000195:mdna:105]
Other income or expense was a gain of $6.0 million in the first nine months of 2015. Included in other income in the first nine months of 2015 was minority income $2.7 million and interest income of $0.6 million, primarily derived from the investment of cash balances in short-term securities. The Company also realized a gain on the redeemable non-controlling interest liability in the first quarter of this year of about $2.7 million. The first nine months of 2014 was a gain of $1.6 million. Included in other income in the first nine months of 2014 was interest income of $1.5 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-15-000195:mdna:106]
[same as prior period, unchanged from 0000038725-15-000161:mdna:106]

[0000038725-15-000195:mdna:107]
Foreign currency-based transactions had no impact for the first nine months of 2015.  Foreign currency-based transactions produced a loss for the first nine months of 2014 of $0.6 million, primarily due to several currency rate changes relative to the U.S. dollar.

[0000038725-15-000195:mdna:108]
[same as prior period, unchanged from 0000038725-15-000161:mdna:108]

[0000038725-15-000195:mdna:109]
The provision for income taxes in the first nine months of 2015 and 2014 was $7.6 million and $22.7 million, respectively. The effective tax rate for the first nine months of 2015 was about 12 percent and, before the impact of discrete events, was about 27 percent.   Discrete adjustments during the first nine months of 2015 were the reversal of a deferred tax liability created in 2012 when the Company acquired the controlling interest in the Pioneer subsidiary and realized a gain on the then equity investment in Pioneer.  This first nine months tax benefit of about $4.8 million was treated as a non-GAAP adjustment.  Because in 2012, the gain was treated as a non-GAAP adjustment, the Company is now consistently treating the reversal of the tax liability related to that gain as a non-GAAP adjustment and reducing reported Earnings per Share in the first nine months of 2015 by $0.10 cents. The Company also realized a gain on the redeemable non-controlling interest liability in the first nine months of this year of about $2.7 million which is included in ‘Other income’.  This purchase transaction also resulted in other tax benefits of about $2.5 million, which were expensed through the Company’s earnings in prior years as well as a current period benefit of about $1.0 million related to the 2015 gain.  The effective tax rate for the first nine months of 2015 and 2014 was about 27 percent before discrete adjustments.  The projected tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings and reduced taxes on foreign and repatriated earnings after the restructuring of certain foreign entities. The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations, current cash on hand and available credit.

[0000038725-15-000195:mdna:110]
[same as prior period, unchanged from 0000038725-15-000161:mdna:111]

[0000038725-15-000195:mdna:111]
Net income for the first nine months of 2015 was $57.4 million compared to 2014 first nine months net income of $67.7 million.  Net income attributable to Franklin Electric Co., Inc. for the first nine months of 2015 was $56.8 million, or $1.17 per diluted share, compared to 2014 first nine months net income attributable to Franklin Electric Co., Inc. of $66.7 million or $1.36 per diluted share. Earnings after non-GAAP adjustments for the first nine months of 2015 were $53.6 million, or $1.12 per diluted share, compared to the prior year first nine months earnings after non-GAAP adjustments of $69.5 million or $1.45 per diluted share.

[0000038725-15-000195:mdna:112]
There were specific items in the first nine months of 2015 and 2014 that impacted net income attributable to Franklin Electric Co., Inc. that were not operational in nature.  The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of earnings after non-GAAP adjustments and adjusted EPS.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-15-000195:mdna:113]
| Earnings Before and After Non-GAAP Adjustments | For the First Nine Months |
| (in millions) | 2015 | 2014 | Change |
| Net Income attributable to Franklin Electric Co., Inc. Reported | $ | 56.8 |  | $ | 66.7 |  | (15 | )% |
| Allocated Undistributed Earnings | $ | (0.9 | ) | $ | (1.3 | ) |  |
| Adjusted Earnings for EPS Calculation | $ | 55.9 |  | $ | 65.4 |  | (15 | )% |
| Non-GAAP adjustments (before tax): |  |  |  |
| Restructuring | $ | 2.5 |  | $ | 1.5 |  |  |
| Non-GAAP items | $ | 1.6 |  | $ | 5.3 |  |  |
| Pioneer tax benefits on equity gain | $ | (4.8 | ) | $ | — |  |  |
| Non-GAAP adjustments, net of tax: |  |  |  |
| Restructuring | $ | 1.5 |  | $ | 0.9 |  |  |
| Non-GAAP items | $ | 1.0 |  | $ | 3.2 |  |  |
| Pioneer tax benefits on equity gain | $ | (4.8 | ) | $ | — |  |  |
| Earnings after Non-GAAP Adjustments | $ | 53.6 |  | $ | 69.5 |  | (23 | )% |

[0000038725-15-000195:mdna:114]
| Earnings Per Share Before and After Non-GAAP Adjustments | For the First Nine Months |
| (in millions except Earnings Per Share) | 2015 | 2014 | Change |
| Average Fully Diluted Shares Outstanding | 47.8 |  | 48.2 |  | (1 | )% |
| Fully Diluted Earnings Per Share ("EPS") Reported | $ | 1.17 |  | $ | 1.36 |  | (14 | )% |
| Restructuring Per Share, net of tax | $ | 0.03 |  | $ | 0.01 |  |  |
| Non-GAAP items | $ | 0.02 |  | $ | 0.08 |  |  |
| Pioneer tax benefits on equity gain | $ | (0.10 | ) | $ | — |  |  |
| Fully Diluted EPS after Non-GAAP Adjustments (Adjusted EPS) | $ | 1.12 |  | $ | 1.45 |  | (23 | )% |

[0000038725-15-000195:mdna:115]
[same as prior period, unchanged from 0000038725-15-000161:mdna:116]

[0000038725-15-000195:mdna:116]
[same as prior period, unchanged from 0000038725-15-000161:mdna:117]

[0000038725-15-000195:mdna:117]
[same as prior period, unchanged from 0000038725-15-000161:mdna:118]

[0000038725-15-000195:mdna:118]
On May 5, 2015, the Company executed the following amendments:  Amendment No. 6 to the Second Amended and Restated Note Purchase and Private Shelf Agreement with Prudential Investment Management, Inc.; Amendment No. 3 to the Credit Agreement; and Amendment No. 1 to the Bond Purchase and Loan Agreement. Each of those amendments provides for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-15-000195:mdna:119]
32

[0000038725-15-000195:mdna:120]
On May 27, 2015, the Company entered into an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement") for $150.0 million maximum aggregate principal borrowing capacity and the Company authorized the issuance of $75.0 million of floating rate senior notes due May 27, 2025.  These series notes have a floating interest rate of one-month USD LIBOR plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  The New York Life Agreement contains customary affirmative and negative covenants and a cross default provision in the event the Company defaults on any obligation exceeding $10.0 million.  As of October 3, 2015, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-15-000195:mdna:121]
On May 28, 2015, the Company entered into a Third Amended and Restated Note Purchase and Private Shelf Agreement with Prudential Investment Management, Inc. (the "Prudential Agreement") to increase the total borrowing capacity from $200.0 million to $250.0 million.  As of October 3, 2015, $120.0 million was outstanding under the Prudential Agreement.  Principal installments of $30.0 million are payable annually commencing on April 30, 2015 and continuing to and including April 30, 2019, with any unpaid balance due at maturity.  As of October 3, 2015, the Company had $100.0 million borrowing capacity under the Prudential Agreement.

[0000038725-15-000195:mdna:122]
In addition, the Company has a committed, unsecured, revolving credit agreement maturing on December 14, 2016 (the “Credit Agreement”) in the amount of $150.0 million. As of October 3, 2015, the Company had $125.5 million borrowing capacity under the Credit Agreement as $4.0 million in letters of commercial and standby letters of credit were outstanding and undrawn and $20.5 million of revolver borrowing was drawn and outstanding at the end of the quarter.

[0000038725-15-000195:mdna:123]
The Credit Agreement, the Prudential Agreement, the Project Bonds, and the New York Life Agreement contain customary affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Credit Agreement, the Prudential Agreement, the Project Bonds, and the New York Life Agreement, but only if the Company is defaulting on an obligation exceeding $10.0 million.

[0000038725-15-000195:mdna:124]
At October 3, 2015, the Company had $84.9 million of cash on hand at various locations worldwide. Approximately 29 percent of the cash and equivalents was in the U.S. and readily accessible. Approximately 40 percent was in Europe, and the remaining 31 percent was in Asia Pacific, Africa, and other locations combined. On a regular basis the Company reviews international cash balances and, if appropriate based on forecasted expenditures and considerations for the post-tax economic efficiency, will reposition cash among its global entities. Cash investments worldwide are invested according to a written policy, and are generally in bank demand accounts and bank time deposits with the preservation of principal as the highest priority.

[0000038725-15-000195:mdna:125]
Net cash provided by operating activities was $60.3 million for nine months ended October 3, 2015 and $3.5 million for the nine months ended September 27, 2014.  Cash generated from operations during the first nine months of 2015 was greater than the first nine months of 2014 as trade receivables and inventory increases during the first nine months of 2014 were higher consistent with the higher sales volumes in 2014.  During the first nine months of 2015, excluding the impact of foreign currency, trade receivables were flat to the prior year end and inventory increased less than 3 percent from end of year 2014. During the first quarter of 2015, the mandatory share purchase liability for PPH was settled, resulting in a non-cash gain and reversal of certain deferred tax liabilities, also non-cash, both of which were adjustments to net income.

[0000038725-15-000195:mdna:126]
Net cash used in investing activities was $18.4 million for the nine months ended October 3, 2015, compared to $68.4 million for the nine months ended September 27, 2014. During the first nine months of 2015 less cash was used in investing activities for acquisitions and equity investments compared to the first nine months of 2014 (the Bombas Leao acquisition was completed during the first nine months of 2014).  In addition, capital expenditures during the first nine months of 2015 were down from the first nine months of 2014 primarily due to the completion of a new manufacturing facility in Brazil in 2014.

[0000038725-15-000195:mdna:127]
Net cash used in financing activities was $10.1 million for the nine months ended October 3, 2015, compared to $11.4 million of cash provided by financing activities for the nine months ended September 27, 2014. The increase in cash used by financing activities in the first nine months of 2015 was primarily due to the payment made during the first quarter for the PPH mandatory share purchase liability.  In addition, during the first nine months of 2015, the Company completed the repurchase of approximately 1.4 million common shares for $41.3 million.  The Company repurchased approximately 0.2 million shares of common stock during the first nine months of 2014 for $7.6 million.

[0000038725-15-000195:mdna:128]
[same as prior period, unchanged from 0000038725-15-000161:mdna:129]
