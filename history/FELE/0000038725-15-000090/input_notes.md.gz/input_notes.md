# FELE notes — 0000038725-15-000090


## fele:DisclosureOfShareBasedCompensationArrangementsAuthorizedSharesTableTextBlock

[0000038725-15-000090:notes:1]
The 2012 Stock Plan authorizes 2,400,000 shares for issuance as follows:

[0000038725-15-000090:notes:2]
| 2012 Stock Plan |  | Authorized Shares |
| Stock Options |  | 1,680,000 |
| Stock/Stock Unit Awards |  | 720,000 |

[0000038725-15-000090:notes:3]
The Company also maintains the Amended and Restated Franklin Electric Co., Inc. Stock Plan (the "2009 Stock Plan") which, as amended in 2009, provided for discretionary grants of stock options and stock awards.  The 2009 Stock Plan authorized 4,400,000 shares for issuance as follows:

[0000038725-15-000090:notes:4]
| 2009 Stock Plan | Authorized Shares |
| Stock Options | 3,200,000 |
| Stock Awards | 1,200,000 |


## fele:ScheduleOfFiniteAndIndefiniteLivedIntangibleAssetsTableTextBlock

[0000038725-15-000090:notes:5]
The carrying amounts of the Company’s intangible assets are as follows:

[0000038725-15-000090:notes:6]
| (In millions) |  | April 4, 2015 |  | January 3, 2015 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortized intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.5 |  |  | $ | (6.1 | ) |  | $ | 7.6 |  |  | $ | (6.1 | ) |
| Supply agreements |  | 4.4 |  |  | (4.4 | ) |  | 4.4 |  |  | (4.4 | ) |
| Technology |  | 7.5 |  |  | (4.4 | ) |  | 7.5 |  |  | (4.3 | ) |
| Customer relationships |  | 137.1 |  |  | (37.6 | ) |  | 140.2 |  |  | (36.5 | ) |
| Software |  | 2.7 |  |  | (1.7 | ) |  | 2.9 |  |  | (1.7 | ) |
| Other |  | 1.0 |  |  | (1.0 | ) |  | 1.2 |  |  | (1.2 | ) |
| Total |  | $ | 160.2 |  |  | $ | (55.2 | ) |  | $ | 163.8 |  |  | $ | (54.2 | ) |
| Unamortized intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 48.5 |  |  | — |  |  | 50.7 |  |  | — |  |
| Total intangibles |  | $ | 208.7 |  |  | $ | (55.2 | ) |  | $ | 214.5 |  |  | $ | (54.2 | ) |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-15-000090:notes:7]
[same as prior period, unchanged from 0000038725-14-000200:notes:1]

[0000038725-15-000090:notes:8]
In 2012, the Company acquired a controlling interest in Pioneer Pump Holdings, Inc. ("PPH").  Pursuant to the terms of the 2012 stock purchase agreement, the remaining 29.5 percent noncontrolling interest was recorded at $22.9 million and accounted for as a share purchase liability.  During the first quarter of 2015, the Company purchased the remaining 29.5 percent of outstanding shares of PPH for $20.2 million, increasing the Company's ownership in PPH to 100 percent.  The purchase was considered the settlement of a financing obligation, and the resulting $2.7 million gain is recorded in the Company's condensed consolidated statements of income in the "Other income, net" line.

[0000038725-15-000090:notes:9]
Transaction costs for all acquisition related activity were expensed as incurred under the guidance of FASB ASC Topic 805, Business Combinations.  Transaction costs included in selling, general, and administrative expenses in the Company’s condensed consolidated statements of income were $0.1 million for the first quarters ended April 4, 2015 and March 29, 2014.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000038725-15-000090:notes:10]
In August 2010, the California Air Resources Board (“CARB”) and South Coast Air Quality Management District (“SCAQMD”) filed civil complaints in the Los Angeles Superior Court against the Company and Franklin Fueling Systems, Inc.  The complaints related to a third-party-supplied component part of the Company's Healy 900 Series nozzle, which is part of the Company's Enhanced Vapor Recovery (“EVR”) Systems installed in California gasoline filling stations.  This part, a diaphragm, was the subject of a retrofit during the first half of 2008.  As the Company previously reported, in October 2008 CARB issued a Notice of Violation to the Company alleging that the circumstances leading to the retrofit program violated California statutes and regulations.

[0000038725-15-000090:notes:11]
The claims in the complaints mirrored those that CARB presented to the Company in the Notice of Violation, and included claims that the Company negligently and intentionally sold nozzles with a modified diaphragm without required CARB certification. Those complaints were consolidated into one case in the Superior Court of California, County of Los Angeles (People of the State of California vs. Franklin Fueling Systems, Inc. et al.) which was tried in the later part of December 2012 and early part of January 2013 (“CARB Case”).

[0000038725-15-000090:notes:12]
On July 25, 2013, the Court issued a Final Statement of Decision (“Decision”) in the CARB Case.  In its Decision, the Court found on behalf of the Company and issued a complete defense verdict.  Judgment was entered on August 27, 2013.  An Amended Judgment awarding the Company $0.1 million in costs was entered by the Court on January 22, 2014. On July 16, 2014, CARB appealed and filed its brief in support of the appeal. The Company filed its response brief on December 23, 2014 and CARB filed its reply brief on February 2, 2015.  The case is now with the California Court of Appeals to either make a ruling on these briefs or schedule an oral argument.  The Company has not been notified regarding the status of this matter at this time.

[0000038725-15-000090:notes:13]
Neither of these suits has had any effect on CARB's certification of the Company's EVR System or any other products of the Company or its subsidiaries, and did not interfere with continuing sales.  CARB has never decertified the Company's EVR System and has never proposed to do so.

[0000038725-15-000090:notes:14]
The Company is defending various other claims and legal actions, including environmental matters, which have arisen in the

[0000038725-15-000090:notes:15]
ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with

[0000038725-15-000090:notes:16]
counsel, these claims and legal actions can be successfully defended or resolved without a material adverse effect on the

[0000038725-15-000090:notes:17]
Company’s financial position, results of operations, and net cash flows.

[0000038725-15-000090:notes:18]
At April 4, 2015, the Company had $12.0 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-15-000090:notes:19]
The Company provides warranties on most of its products.  The warranty terms vary but are generally 2 years from date of manufacture or 1 year from date of installation.  In 2007, the Company began offering an extended warranty program to certain Water Systems customers which provides warranty coverage up to 5 years from date of manufacture.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-15-000090:notes:20]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the first quarter ended April 4, 2015, are as follows:

[0000038725-15-000090:notes:21]
| (In millions) |  |  |
| Balance as of January 3, 2015 |  | $ | 9.4 |  |
| Accruals related to product warranties |  | 1.4 |  |
| Reductions for payments made |  | (2.1 | ) |
| Balance as of April 4, 2015 |  | $ | 8.7 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-15-000090:notes:22]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)

[0000038725-15-000090:notes:23]
Changes in accumulated other comprehensive income/(loss) by component for the first quarters ended April 4, 2015 and March 29, 2014, are summarized below:

[0000038725-15-000090:notes:24]
| (In millions) |  |  |  |  |  |
| For the first quarter ended April 4, 2015: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments |  | Total |
| Balance as of January 3, 2015 | $ | (51.8 | ) |  | $ | (56.1 | ) |  | $ | (107.9 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | (27.8 | ) |  | — |  |  | (27.8 | ) |
| Income tax expense | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | (27.8 | ) |  | — |  |  | (27.8 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income | — |  |  | 1.0 |  | (1) | 1.0 |  |
| Income tax expense | — |  |  | (0.4 | ) |  | (0.4 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | 0.6 |  |  | 0.6 |  |
| Net current period other comprehensive income/(loss), net of income taxes | (27.8 | ) |  | 0.6 |  |  | (27.2 | ) |
| Other comprehensive income/(loss) attributable to noncontrolling interest | (0.3 | ) |  | — |  |  | (0.3 | ) |
| Balance as of April 4, 2015 | $ | (79.3 | ) |  | $ | (55.5 | ) |  | $ | (134.8 | ) |
| For the first quarter ended March 29, 2014: |  |  |  |  |  |
| Balance as of December 28, 2013 | $ | (16.0 | ) |  | $ | (38.7 | ) |  | $ | (54.7 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | 2.1 |  |  | — |  |  | 2.1 |  |
| Income tax expense | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | 2.1 |  |  | — |  |  | 2.1 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income | — |  |  | 0.7 |  | (1) | 0.7 |  |
| Income tax expense | — |  |  | (0.3 | ) |  | (0.3 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | 0.4 |  |  | 0.4 |  |
| Net current period other comprehensive income/(loss), net of income taxes | 2.1 |  |  | 0.4 |  |  | 2.5 |  |
| Other comprehensive income/(loss) attributable to noncontrolling interest | (0.3 | ) |  | — |  |  | (0.3 | ) |
| Balance as of March 29, 2014 | $ | (13.6 | ) |  | $ | (38.3 | ) |  | $ | (51.9 | ) |

[0000038725-15-000090:notes:25]
(1) This accumulated other comprehensive income/(loss) component is included in the computation of net periodic pension cost (refer to Note 9 for additional details) and is included in the "Selling, general, and administrative expenses" line of the Company's condensed consolidated statements of income.


## us-gaap:DebtDisclosureTextBlock

[0000038725-15-000090:notes:26]
DEBT

[0000038725-15-000090:notes:27]
Debt consisted of the following:

[0000038725-15-000090:notes:28]
| (In millions) |  | April 4, 2015 |  | January 3, 2015 |
| Prudential Agreement - 5.79 percent |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 23.2 |  |  | 23.7 |  |
| Revolver |  | 69.9 |  |  | — |  |
| Capital leases |  | 0.6 |  |  | 0.6 |  |
| Foreign subsidiary debt |  | 2.7 |  |  | 3.5 |  |
|  |  | 246.4 |  |  | 177.8 |  |
| Less current maturities |  | (103.2 | ) |  | (34.1 | ) |
| Long-term debt |  | $ | 143.2 |  |  | $ | 143.7 |  |

[0000038725-15-000090:notes:29]
During the first quarter ended April 4, 2015, a portion of the Revolver borrowing (the "Credit Agreement") was used for working capital needs.

[0000038725-15-000090:notes:30]
On May 5, 2015, the Company executed the following agreements:  Amendment No. 6 to the Prudential Agreement; Amendment No. 3 to the Credit Agreement; and Amendment No. 1 to the Bond Purchase and Loan Agreement.  Each of those agreements provides for debt repayment guarantees from certain Company subsidiaries and waives certain non-financial covenants related to subsidiary guarantees.

[0000038725-15-000090:notes:31]
The following debt payments are expected to be paid in accordance with the following schedule:

[0000038725-15-000090:notes:32]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 245.8 |  |  | $ | 102.9 |  |  | $ | 31.1 |  |  | $ | 31.1 |  |  | $ | 31.4 |  |  | $ | 31.1 |  |  | $ | 18.2 |  |
| Capital leases |  | 0.6 |  |  | 0.3 |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |
|  |  | $ | 246.4 |  |  | $ | 103.2 |  |  | $ | 31.2 |  |  | $ | 31.2 |  |  | $ | 31.5 |  |  | $ | 31.1 |  |  | $ | 18.2 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-15-000090:notes:33]
[same as prior period, unchanged from 0000038725-14-000200:notes:38]

[0000038725-15-000090:notes:34]
The Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  During February 2014, the Company entered into a share swap transaction agreement ("the swap") to mitigate the Company’s exposure to these fluctuations in the Company's stock price.  The Company renewed the swap agreement in February 2015.  The swap was not designated as a hedge for accounting purposes and is cancellable with 30 days written notice by either party.  The swap has a notional value based on 147,750 shares.  For the first quarters ended April 4, 2015 and March 29, 2014, the swap resulted in losses of $0.1 million and $0.2 million, respectively.  All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-15-000090:notes:35]
[same as prior period, unchanged from 0000038725-14-000200:notes:40]

[0000038725-15-000090:notes:36]
The Company maintains the Franklin Electric Co., Inc. 2012 Stock Plan (the "2012 Stock Plan"), which is a stock-based compensation plan that provides for discretionary grants of stock options, stock awards, and stock unit awards to key employees and non-employee directors.

[0000038725-15-000090:notes:37]
[same as prior period, unchanged from 0000038725-14-000200:notes:46]

[0000038725-15-000090:notes:38]
[same as prior period, unchanged from 0000038725-14-000200:notes:47]

[0000038725-15-000090:notes:39]
[same as prior period, unchanged from 0000038725-14-000200:notes:48]

[0000038725-15-000090:notes:40]
[same as prior period, unchanged from 0000038725-14-000200:notes:49]

[0000038725-15-000090:notes:41]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the first quarters ended April 4, 2015 and March 29, 2014, are as follows:

[0000038725-15-000090:notes:42]
|  |  | April 4, 2015 |  | March 29, 2014 |
| Risk-free interest rate |  | 1.59 | % |  | 1.68 | % |
| Dividend yield |  | 0.95 | % |  | 0.70 | % |
| Volatility factor |  | 0.379 |  |  | 0.387 |  |
| Expected term |  | 5.5 years |  |  | 5.6 years |  |
| Forfeiture rate |  | 3.67 | % |  | 3.81 | % |

[0000038725-15-000090:notes:43]
There were 184,706 and 92,946 stock options granted during the first quarters ended April 4, 2015 and March 29, 2014.

[0000038725-15-000090:notes:44]
A summary of the Company’s outstanding stock option activity and related information for the first quarters ended April 4, 2015 and March 29, 2014, is as follows:

[0000038725-15-000090:notes:45]
| (Shares in thousands) |  | April 4, 2015 |  | March 29, 2014 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,397 |  |  | $ | 21.17 |  |  | 1,476 |  |  | $ | 19.01 |  |
| Granted |  | 185 |  |  | 36.67 |  |  | 93 |  |  | 43.27 |  |
| Exercised |  | (46 | ) |  | 19.36 |  |  | (34 | ) |  | 18.57 |  |
| Forfeited |  | — |  |  | — |  |  | (2 | ) |  | 26.95 |  |
| Outstanding at end of period |  | 1,536 |  |  | $ | 23.09 |  |  | 1,533 |  |  | $ | 20.48 |  |
| Expected to vest after applying forfeiture rate |  | 1,511 |  |  | $ | 22.86 |  |  | 1,511 |  |  | $ | 20.31 |  |
| Vested and exercisable at end of period |  | 1,124 |  |  | $ | 18.75 |  |  | 1,070 |  |  | $ | 16.34 |  |

[0000038725-15-000090:notes:46]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value for the first quarter ended April 4, 2015 is as follows:

[0000038725-15-000090:notes:47]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 5.87 years |  | $ | 23,421 |  |
| Expected to vest after applying forfeiture rate |  | 5.82 years |  | $ | 23,365 |  |
| Vested and exercisable at end of period |  | 4.77 years |  | $ | 21,781 |  |

[0000038725-15-000090:notes:48]
The total intrinsic value of options exercised was $0.8 million during the first quarters ended April 4, 2015 and March 29, 2014.

[0000038725-15-000090:notes:49]
As of April 4, 2015, there was $2.5 million of total unrecognized compensation cost related to non-vested share-based compensation arrangements related to stock options granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 3.03 years.

[0000038725-15-000090:notes:50]
[same as prior period, unchanged from 0000038725-14-000200:notes:59]

[0000038725-15-000090:notes:51]
A summary of the Company’s restricted stock/stock unit award activity and related information for the first quarters ended April 4, 2015 and March 29, 2014, is as follows:

[0000038725-15-000090:notes:52]
| (Shares in thousands) |  | April 4, 2015 |  | March 29, 2014 |
| Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 554 |  |  | $ | 32.72 |  |  | 551 |  |  | $ | 24.75 |  |
| Awarded |  | 120 |  |  | 36.67 |  |  | 172 |  |  | 43.37 |  |
| Vested |  | (74 | ) |  | 25.01 |  |  | (110 | ) |  | 15.75 |  |
| Forfeited |  | — |  |  | — |  |  | (56 | ) |  | 27.81 |  |
| Non-vested at end of period |  | 600 |  |  | $ | 34.47 |  |  | 557 |  |  | $ | 31.96 |  |

[0000038725-15-000090:notes:53]
As of April 4, 2015, there was $11.7 million of total unrecognized compensation cost related to non-vested share-based compensation arrangements related to stock/stock unit awards granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.70 years.


## us-gaap:EarningsPerShareTextBlock

[0000038725-15-000090:notes:54]
[same as prior period, unchanged from 0000038725-14-000200:notes:63]

[0000038725-15-000090:notes:55]
[same as prior period, unchanged from 0000038725-14-000200:notes:64]

[0000038725-15-000090:notes:56]
[same as prior period, unchanged from 0000038725-14-000200:notes:65]

[0000038725-15-000090:notes:57]
[same as prior period, unchanged from 0000038725-14-000200:notes:66]

[0000038725-15-000090:notes:58]
|  | First Quarter Ended |
| (In millions, except per share amounts) | April 4, 2015 |  | March 29, 2014 |
| Numerator: |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 19.8 |  |  | $ | 17.0 |  |
| Less: Undistributed earnings allocated to participating securities | 0.2 |  |  | 0.3 |  |
| Less: Undistributed earnings allocated to redeemable noncontrolling interest | 0.1 |  |  | — |  |
|  | $ | 19.5 |  |  | $ | 16.7 |  |
| Denominator: |  |  |  |  |  |
| Basic |  |  |  |  |  |
| Weighted average common shares | 47.6 |  |  | 47.7 |  |
| Diluted |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |
| Non-participating employee incentive stock options and performance awards | 0.5 |  |  | 0.6 |  |
| Adjusted weighted average common shares | 48.1 |  |  | 48.3 |  |
| Basic earnings per share | $ | 0.41 |  |  | $ | 0.35 |  |
| Diluted earnings per share | $ | 0.41 |  |  | $ | 0.35 |  |
| Anti-dilutive stock options | 0.2 |  |  | — |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000038725-15-000090:notes:59]
As of April 4, 2015 and January 3, 2015, the assets measured at fair value on a recurring basis were as set forth in the table below.

[0000038725-15-000090:notes:60]
| (In millions) | April 4, 2015 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 3.1 |  | $ | 3.1 |  | $ | — |  | $ | — |  |
|  | January 3, 2015 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 5.4 |  | $ | 5.4 |  | $ | — |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-15-000090:notes:61]
[same as prior period, unchanged from 0000038725-14-000200:notes:70]

[0000038725-15-000090:notes:62]
[same as prior period, unchanged from 0000038725-14-000200:notes:71]

[0000038725-15-000090:notes:63]
[same as prior period, unchanged from 0000038725-14-000200:notes:72]

[0000038725-15-000090:notes:64]
[same as prior period, unchanged from 0000038725-14-000200:notes:73]

[0000038725-15-000090:notes:65]
[same as prior period, unchanged from 0000038725-14-000200:notes:74]

[0000038725-15-000090:notes:66]
[same as prior period, unchanged from 0000038725-14-000200:notes:75]

[0000038725-15-000090:notes:67]
Total debt, including current maturities, have carrying amounts of $245.8 million and $177.2 million and estimated fair values of $259.7 million and $191.1 million as of April 4, 2015 and January 3, 2015, respectively.  The fair value assumed floating rate debt was valued at par.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.

[0000038725-15-000090:notes:68]
As of April 4, 2015, the Company had $2.0 million of assets held for sale recorded at carrying value in the Water Systems segment relating to a facility in Brazil.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-15-000090:notes:69]
[same as prior period, unchanged from 0000038725-14-000200:notes:77]

[0000038725-15-000090:notes:70]
Changes in carrying values for intangible assets are primarily attributed to the impact of foreign exchange for the first quarter ended April 4, 2015.

[0000038725-15-000090:notes:71]
Amortization expense related to intangible assets for the first quarters ended April 4, 2015 and March 29, 2014 was $2.2 million and $2.0 million, respectively.

[0000038725-15-000090:notes:72]
[same as prior period, unchanged from 0000038725-14-000200:notes:81]

[0000038725-15-000090:notes:73]
| (In millions) |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | 2019 |
|  |  | $ | 8.7 |  |  | $ | 8.7 |  |  | $ | 8.5 |  |  | $ | 8.5 |  |  | $ | 8.2 |  |

[0000038725-15-000090:notes:74]
The change in the carrying amount of goodwill by reporting segment for the first quarter ended April 4, 2015, is as follows:

[0000038725-15-000090:notes:75]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Consolidated |
| Balance as of January 3, 2015 |  | $ | 145.3 |  |  | $ | 63.5 |  |  | $ | 208.8 |  |
| Acquisitions |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Foreign currency translation |  | (4.6 | ) |  | (0.2 | ) |  | (4.8 | ) |
| Balance as of April 4, 2015 |  | $ | 140.8 |  |  | $ | 63.3 |  |  | $ | 204.1 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-15-000090:notes:76]
[same as prior period, unchanged from 0000038725-14-000200:notes:85]

[0000038725-15-000090:notes:77]
The effective tax rate continues to be lower than the U.S. statutory rate of 35.0 percent primarily due to the indefinite reinvestment of foreign earnings taxed at rates below the U.S. statutory rate, recognition of U.S and foreign tax credits and  discrete items in the quarter.  The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its operations as well as cash on hand and available credit.  In addition, the Company redeemed the minority shareholdings of a subsidiary during the first quarter.  This transaction resulted in the recording of tax benefits in the first quarter of $7.3 million from the reversal of related deferred tax liabilities along with an additional $1.0 million current benefit related to the gain of the mandatory share purchase liability included in the "Other income, net" line in the Company’s condensed consolidated statements of income.


## us-gaap:MinorityInterestDisclosureTextBlock

[0000038725-15-000090:notes:78]
[same as prior period, unchanged from 0000038725-14-000200:notes:90]

[0000038725-15-000090:notes:79]
On May 2, 2011, the Company completed the acquisition of 80 percent of Impo.  In 2014, the Company redeemed 10 percent of the noncontrolling interest of Impo, increasing the Company's ownership to 90 percent.  The noncontrolling interest holders have the option, which is embedded in the noncontrolling interest, to require the Company to redeem their ownership interests.  The combination of a noncontrolling interest and a redemption feature resulted in a redeemable noncontrolling interest.

[0000038725-15-000090:notes:80]
The Company uses the interest method to accrete changes in the anticipated redemption value of the Impo redeemable noncontrolling interest over an amortization period to the earliest projected redemption date.  Accretion adjustments for the first quarter ended April 4, 2015 were $0.1 million.  No adjustments were necessary for the first quarter ended March 29, 2014.  These adjustments were reflected in the computation of earnings per share using the two-class method.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000038725-15-000090:notes:81]
ACCOUNTING PRONOUNCEMENTS

[0000038725-15-000090:notes:82]
Adoption of New Accounting Standards

[0000038725-15-000090:notes:83]
In February 2015, the FASB issued ASU 2015-02, Consolidation (Topic 810), Amendments to the Consolidation Analysis.  The amendments affect both the variable interest entity and voting interest entity consolidation models.  The need to assess an entity under a different consolidation model may change previous consolidation conclusions.  The standard is effective for both interim and annual reporting periods beginning after December 15, 2015 and early adoption is permitted.  The Company has adopted this standard with no impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-15-000090:notes:84]
Accounting Standards Issued But Not Yet Adopted

[0000038725-15-000090:notes:85]
In April 2015, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2015-03, Simplifying the Presentation of Debt Issuance Costs, which requires debt issuance costs to be presented in the balance sheet as a direct deduction from the associated debt liability.  The standard will not change the amortization of debt issuance costs, which will continue to follow the existing accounting guidance.  The ASU will be effective for interim and annual periods beginning after December 15, 2015 and early adoption is permitted.  The Company is still in the process of analyzing the effect of this new standard to determine the impact on the Company's consolidated financial position, results of operations, and cash flows.

[0000038725-15-000090:notes:86]
In May 2014, the FASB issued ASU 2014-09 Revenue from Contracts with Customers.  ASU 2014-09 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes current revenue recognition guidance.  The ASU is effective for annual reporting periods beginning after December 15, 2016 and early adoption is not permitted.  However, on April 1, 2015, the FASB voted to propose a one-year deferral to the effective date, but to permit entities to adopt one year earlier if they choose (i.e., the original effective date). The proposal will be subject to the FASB's due process requirement, which includes a period for public comments.  Entities have the option of using either a full retrospective or a modified retrospective approach to adopt the new ASU.  The Company is still in the process of analyzing the effect of this new standard to determine the impact on the Company's consolidated financial position, results of operations, and cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-15-000090:notes:87]
[same as prior period, unchanged from 0000038725-14-000200:notes:100]

[0000038725-15-000090:notes:88]
The accompanying condensed consolidated balance sheet as of January 3, 2015, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of April 4, 2015, and for the first quarters ended April 4, 2015 and March 29, 2014, have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the first quarter ended April 4, 2015 are not necessarily indicative of the results that may be expected for the fiscal year ending January 2, 2016.  For further information, including a description of the Company’s critical accounting policies, refer to the consolidated financial statements and notes thereto included in Franklin Electric Co., Inc.'s Annual Report on Form 10-K for the year ended January 3, 2015.


## us-gaap:OtherAssetsDisclosureTextBlock

[0000038725-15-000090:notes:89]
[same as prior period, unchanged from 0000038725-14-000200:notes:103]

[0000038725-15-000090:notes:90]
The Company has equity interests in various companies for strategic purposes.  The investments are accounted for under the equity method and are included in the “Other assets” line on the Company’s condensed consolidated balance sheet.  The carrying amount of the investments are adjusted for the Company's proportionate share of earnings, losses, and dividends.  The investments are not considered material to the Company’s financial position, neither individually nor in the aggregate.  The Company’s proportionate share of earnings from its equity interests, included in the "Other income, net" line of the Company's condensed consolidated statements of income, was immaterial for the first quarters ended April 4, 2015 and March 29, 2014.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-15-000090:notes:91]
[same as prior period, unchanged from 0000038725-14-000200:notes:106]

[0000038725-15-000090:notes:92]
Defined Benefit Plans - As of April 4, 2015, the Company maintained two domestic pension plans and three German pension plans.  The Company used a January 3, 2015 measurement date for these plans.  One of the Company's domestic pension plans covers two management employees, while the other domestic plan covers all other eligible employees.  The two domestic and  three German plans collectively comprise the 'Pension Benefits' disclosure caption.

[0000038725-15-000090:notes:93]
[same as prior period, unchanged from 0000038725-14-000200:notes:108]

[0000038725-15-000090:notes:94]
The following table sets forth the aggregated net periodic benefit cost for all pension and postretirement plans for the first quarters ended April 4, 2015 and March 29, 2014, respectively:

[0000038725-15-000090:notes:95]
| (In millions) | Pension Benefits |  | Other Benefits |
|  | First Quarter Ended |  | First Quarter Ended |
|  | April 4, 2015 |  | March 29, 2014 |  | April 4, 2015 |  | March 29, 2014 |
| Service cost | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 1.8 |  |  | 2.0 |  |  | 0.1 |  |  | 0.1 |  |
| Expected return on assets | (2.5 | ) |  | (2.6 | ) |  | — |  |  | — |  |
| Amortization of prior service cost | — |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Amortization of loss | 0.8 |  |  | 0.6 |  |  | 0.1 |  |  | — |  |
| Net periodic benefit cost | $ | 0.4 |  |  | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 0.2 |  |
| Settlement cost | 0.3 |  |  | 0.2 |  |  | — |  |  | — |  |
| Total net periodic benefit cost | $ | 0.7 |  |  | $ | 0.5 |  |  | $ | 0.3 |  |  | $ | 0.2 |  |

[0000038725-15-000090:notes:96]
In the first quarter ended April 4, 2015, the Company made contributions of $0.8 million to the funded plans.  The amount of contributions to be made to the plans during the calendar year 2015 will be finalized September 15, 2015, based upon the plan's year-end valuation at January 3, 2015, and the funding level required for the plan year ended January 3, 2015.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000038725-15-000090:notes:97]
[same as prior period, unchanged from 0000038725-14-000200:notes:114]

[0000038725-15-000090:notes:98]
On July 1, 2014, the Company announced a plan to close its Wittlich, Germany manufacturing facility.  As part of this action, the Company will transfer the existing Wittlich manufacturing activity to its Brno, Czech Republic facility.  The Company will maintain its European Water Systems headquarters and distribution center in Wittlich, only the manufacturing operations will be relocating.  The realignment began in the third quarter of 2014 and is estimated to conclude by the end of 2016.  Charges for the realignment are expected to be approximately $19.4 million and will include severance expenses, professional service fees, asset write-offs, and temporarily leased facilities costs.

[0000038725-15-000090:notes:99]
Costs incurred in the first quarter ended April 4, 2015, included in the “Restructuring expense” line of the Company's condensed consolidated statements of income, are as follows:

[0000038725-15-000090:notes:100]
|  |  | First Quarter Ended |
|  |  | April 4, 2015 |
| (In millions) |  | Water Systems |  | Fueling Systems |  | Other |  | Consolidated |
| Employee severance |  | $ | — |  |  | $ | 0.2 |  |  | $ | — |  |  | $ | 0.2 |  |
| Equipment relocation |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Other |  | 0.2 |  |  | — |  |  | — |  |  | 0.2 |  |
| Total |  | $ | 0.3 |  |  | $ | 0.2 |  |  | $ | — |  |  | $ | 0.5 |  |

[0000038725-15-000090:notes:101]
Restructuring expenses, relating primarily to severance for the first quarter ended March 29, 2014, were approximately $0.1 million.

[0000038725-15-000090:notes:102]
As of April 4, 2015, there was $6.4 million in restructuring reserves primarily for severance.  As of March 29, 2014, there were no restructuring reserves.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000038725-15-000090:notes:103]
[same as prior period, unchanged from 0000038725-14-000200:notes:120]

[0000038725-15-000090:notes:104]
|  | First Quarter Ended |  |
| (In millions) | April 4, 2015 |  | March 29, 2014 |  |
|  | Net sales to external customers |
| Water Systems | $ | 179.2 |  |  | $ | 184.6 |  |  |
| Fueling Systems | 46.5 |  |  | 46.8 |  |  |
| Other | — |  |  | — |  |  |
| Consolidated | $ | 225.7 |  |  | $ | 231.4 |  |  |
|  | First Quarter Ended |  |
|  | April 4, 2015 |  | March 29, 2014 |  |
|  | Operating income (loss) |
| Water Systems | $ | 19.4 |  |  | $ | 29.2 |  |  |
| Fueling Systems | 9.6 |  |  | 9.1 |  |  |
| Other | (13.1 | ) |  | (12.3 | ) |  |
| Consolidated | $ | 15.9 |  |  | $ | 26.0 |  |  |
|  | April 4, 2015 |  | January 3, 2015 |  |
|  | Total assets |  |
| Water Systems | $ | 761.6 |  |  | $ | 757.5 |  |  |
| Fueling Systems | 251.6 |  |  | 252.7 |  |  |
| Other | 67.6 |  |  | 65.7 |  |  |
| Consolidated | $ | 1,080.8 |  |  | $ | 1,075.9 |  |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0000038725-15-000090:notes:105]
The schedule below sets forth equity changes in the first quarter ended April 4, 2015:

[0000038725-15-000090:notes:106]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of January 3, 2015 | $ | 4,759 |  |  | $ | 207,446 |  |  | $ | 492,548 |  |  | $ | (56,124 | ) |  | $ | (51,789 | ) |  | $ | 2,143 |  |  | $ | 598,983 |  |  | $ | 6,420 |  |
| Net income |  |  |  |  | 19,795 |  |  |  |  |  |  | 150 |  |  | 19,945 |  |  | 31 |  |
| Adjustment to Impo redemption value |  |  |  |  | (81 | ) |  |  |  |  |  |  |  | (81 | ) |  | 81 |  |
| Dividends on common stock |  |  |  |  | (4,283 | ) |  |  |  |  |  |  |  | (4,283 | ) |  |  |
| Common stock issued | 5 |  |  | 878 |  |  |  |  |  |  |  |  |  |  | 883 |  |  |  |
| Common stock repurchased or received for stock options exercised | (6 | ) |  |  |  | (2,282 | ) |  |  |  |  |  |  |  | (2,288 | ) |  |  |
| Share-based compensation | 5 |  |  | 2,349 |  |  |  |  |  |  |  |  |  |  | 2,354 |  |  |  |
| Tax benefit of stock options exercised |  |  | 514 |  |  |  |  |  |  |  |  |  |  | 514 |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (27,531 | ) |  | (154 | ) |  | (27,685 | ) |  | (197 | ) |
| Pension liability, net of tax |  |  |  |  |  |  | 654 |  |  |  |  |  |  | 654 |  |  |  |
| Balance as of April 4, 2015 | $ | 4,763 |  |  | $ | 211,187 |  |  | $ | 505,697 |  |  | $ | (55,470 | ) |  | $ | (79,320 | ) |  | $ | 2,139 |  |  | $ | 588,996 |  |  | $ | 6,335 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-15-000090:notes:107]
[same as prior period, unchanged from 0000038725-14-000200:notes:124]

[0000038725-15-000090:notes:108]
Property, plant, and equipment is the major asset group in "Other" of total assets at April 4, 2015 and January 3, 2015.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-15-000090:notes:109]
[same as prior period, unchanged from 0000038725-14-000200:notes:126]
