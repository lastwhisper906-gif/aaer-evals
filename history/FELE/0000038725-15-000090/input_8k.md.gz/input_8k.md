# FELE 8-K — 0000038725-15-000087 filed 2015-04-28

## item codes, every 8-K on or before 2015-05-06

- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2015-05-06

- none on or before 2015-05-06

## item 2.02 — earnings release, exhibit 99.1

[0000038725-15-000087:8k_2_02:1]
EX-99.1
2
a20150428exhibit991.htm
EXHIBIT 99.1

[0000038725-15-000087:8k_2_02:2]
2015.04.28 Exhibit 99.1

[0000038725-15-000087:8k_2_02:3]
Exhibit 99.1

[0000038725-15-000087:8k_2_02:4]
For Immediate Release

[0000038725-15-000087:8k_2_02:5]
For Further Information

[0000038725-15-000087:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-15-000087:8k_2_02:7]
260-824-2900

[0000038725-15-000087:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS FIRST QUARTER

[0000038725-15-000087:8k_2_02:9]
2015 SALES AND EARNINGS

[0000038725-15-000087:8k_2_02:10]
Fort Wayne, Indiana - April 28, 2015 - Franklin Electric Co., Inc. (NASDAQ:FELE) reported first quarter 2015 adjusted earnings per share (EPS) of $0.32 compared to 2014 first quarter adjusted EPS of $0.35, a 9 percent decrease (see table below for a reconciliation of GAAP EPS to the adjusted EPS).  In the first quarter of 2015, the Company’s GAAP fully diluted EPS was $0.41 which was up 17 percent to the GAAP fully diluted EPS from the first quarter of 2014.

[0000038725-15-000087:8k_2_02:11]
First quarter 2015 sales were $225.7 million, a decrease of 2 percent compared to 2014 first quarter sales of $231.4 million.  The Company’s organic sales growth was 1 percent excluding acquisitions and the impact of foreign currency translation.

[0000038725-15-000087:8k_2_02:12]
Gregg Sengstack, Franklin Electric’s Chief Executive Officer, commented:

[0000038725-15-000087:8k_2_02:13]
“While our GAAP earnings per share were 17 percent higher than last year, our operating earnings were well below our expectations and guidance for two principal reasons: the material strengthening of the U.S. dollar and the dramatically lower price of oil. The impact of these two factors was greater than we originally forecasted and over shadowed our continued positive organic growth across many markets. Beyond currency translation, operating margins were further compressed in our business units outside the U.S. that purchase commodities or components in U.S. dollars. To recover margins we have taken pricing actions, are controlling fixed costs and are using our global sourcing network to reduce input costs.

[0000038725-15-000087:8k_2_02:14]
Excluding the impact of foreign currency translation and lower Pioneer branded mobile pumping equipment sales that are used in upstream oil and gas development, our organic growth was 4 percent, led by our Water Systems businesses in several developing regions. With 5 percent organic growth, our Fueling Systems business posted another record quarter.

[0000038725-15-000087:8k_2_02:15]
Finally, our reported earnings per share of $0.41 were positively impacted by the purchase of the remaining minority shares of Pioneer Pump that was completed in the quarter and resulted in the realization of certain tax benefits and other income.”

[0000038725-15-000087:8k_2_02:16]
Key Performance Indicators:

[0000038725-15-000087:8k_2_02:17]
| Earnings Before and After Non-GAAP Adjustments |  | For the First Quarter |
| (in millions) |  | 2015 | 2014 | Change |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 19.8 |  | $ | 17.0 |  | 16 | % |
| Allocated Undistributed Earnings |  | $ | (0.3 | ) | $ | (0.3 | ) |  |
| Adjusted Earnings for EPS Calculations |  | $ | 19.5 |  | $ | 16.7 |  | 17 | % |
| Non-GAAP adjustments (before tax): |  |  |  |  |
| Restructuring |  | $ | 0.5 |  | $ | 0.1 |  |  |
| Non-GAAP items |  | $ | 0.3 |  | $ | 0.1 |  |  |
| Pioneer tax benefits on equity gain |  | $ | (4.8 | ) | $ | — |  |  |
| Non-GAAP adjustments, net of tax: |  |  |  |  |
| Restructuring |  | $ | 0.3 |  | $ | 0.1 |  |  |
| Non-GAAP items |  | $ | 0.2 |  | $ | 0.1 |  |  |
| Pioneer tax benefits on equity gain |  | $ | (4.8 | ) | $ | — |  |  |
| Earnings after Non-GAAP Adjustments |  | $ | 15.2 |  | $ | 16.9 |  | (10 | )% |
| Earnings Per Share |  | For the First Quarter |
| Before and After Non-GAAP Adjustments |  | 2015 | 2014 | Change |
| (in millions except Earnings Per Share) |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 48.1 |  | 48.3 |  | — | % |
| Fully Diluted Earnings Per Share ("EPS") Reported |  | $ | 0.41 |  | $ | 0.35 |  | 17 | % |
| Restructuring Per Share, net of tax |  | $ | 0.01 |  | $ | — |  |  |
| Non-GAAP items, net of tax |  | $ | — |  | $ | — |  |  |
| Pioneer tax benefits on equity gain |  | $ | (0.10 | ) | $ | — |  |  |
| Fully Diluted EPS after Non-GAAP Adjustments(Adjusted EPS) |  | $ | 0.32 |  | $ | 0.35 |  | (9 | )% |

[0000038725-15-000087:8k_2_02:18]
| Net Sales | For the First Quarter |
| (in millions) | Water | Fueling | Consolidated |
| Sales for 2014 | $ | 184.6 |  | $ | 46.8 |  | $ | 231.4 |  |
| Acquisitions | $ | 8.8 |  | $ | 0.1 |  | $ | 8.9 |  |
| Foreign currency translation | $ | (13.8 | ) | $ | (2.7 | ) | $ | (16.5 | ) |
| Volume/Price Change | $ | (0.4 | ) | $ | 2.3 |  | $ | 1.9 |  |
| Sales for 2015 | $ | 179.2 |  | $ | 46.5 |  | $ | 225.7 |  |

[0000038725-15-000087:8k_2_02:19]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the First Quarter 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 19.4 |  | $ | 9.6 |  | $ | (13.1 | ) | $ | 15.9 |  |
| % Operating Income To Net Sales | 10.8 | % | 20.6 | % |  | 7.0 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.3 |  | $ | 0.2 |  | $ | — |  | $ | 0.5 |  |
| Non-GAAP | $ | — |  | $ | — |  | $ | 0.3 |  | $ | 0.3 |  |
| Operating Income after Non-GAAP Adjustments | $ | 19.7 |  | $ | 9.8 |  | $ | (12.8 | ) | $ | 16.7 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 11.0 | % | 21.1 | % |  | 7.4 | % |
|  | For the First Quarter 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 29.2 |  | $ | 9.1 |  | $ | (12.3 | ) | $ | 26.0 |  |
| % Operating Income To Net Sales | 15.8 | % | 19.4 | % |  | 11.2 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.1 |  | $ | — |  | $ | — |  | $ | 0.1 |  |
| Non-GAAP | $ | — |  | $ | 0.1 |  | $ | — |  | $ | 0.1 |  |
| Operating Income after Non-GAAP Adjustments | $ | 29.3 |  | $ | 9.2 |  | $ | (12.3 | ) | $ | 26.2 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 15.9 | % | 19.7 | % |  | 11.3 | % |

[0000038725-15-000087:8k_2_02:20]
Water Systems

[0000038725-15-000087:8k_2_02:21]
Water Systems sales were $179.2 million in the first quarter 2015, a decrease of $5.4 million or about 3 percent versus the first quarter 2014 sales of $184.6 million.  Sales from businesses acquired since the first quarter of 2014 were $8.8 million or about 5 percent.  Water Systems sales were reduced by $13.8 million or about 8 percent in the quarter due to foreign currency translation.  Excluding acquisitions and foreign currency translation, Water Systems sales were flat compared to the first quarter 2014.

[0000038725-15-000087:8k_2_02:22]
Water Systems sales in the U.S. and Canada represented 35 percent of consolidated sales and declined by about 10 percent compared to the prior year. Water Systems sales were reduced by $1.1 million or about 1 percent in the quarter due to foreign currency translation. Sales of mobile pumping equipment in the U.S. and Canada declined by about 50 percent in the first quarter of 2015 compared to the prior year first quarter due primarily to reduced demand in the oil and gas end markets. Sales of ground water pumping equipment declined by 6 percent and sales of surface water pumping equipment increased by about 4 percent in the U.S. and Canada compared to the first quarter 2014.

[0000038725-15-000087:8k_2_02:23]
Water Systems sales in Latin America were about 16 percent of consolidated sales for the first quarter and grew by about 21 percent compared to the first quarter of the prior year.  Sales from businesses acquired since the first quarter of 2014 were $6.3 million or about 21 percent. Water Systems sales were reduced by $4.8 million or about 16 percent in the quarter due to foreign currency translation. Excluding acquisitions and the impact of foreign currency translation, Latin American sales increased by about 16 percent compared to the first quarter 2014.  The strong growth in sales was led by a 45 percent increase in sales in Mexico and continued double digit sales growth in Brazil.

[0000038725-15-000087:8k_2_02:24]
Water Systems sales in the Middle East and Africa were about 12 percent of consolidated sales and decreased by about 3 percent compared to the first quarter 2014.  Water Systems sales were reduced by about 7 percent in the quarter due to foreign currency translation.  Excluding the impact of foreign currency translation, sales increased by about 4 percent compared to the first quarter 2014. The growth was driven by strong sales of groundwater pumping equipment sold under both the Impo and Franklin Electric brand names in Central and Southern Africa as well as Turkey, offset by weakness in North Africa and the Middle East due to increased political unrest.

[0000038725-15-000087:8k_2_02:25]
Water Systems sales in the Asia Pacific region were 8 percent of consolidated sales and were up about 4 percent compared to the first quarter prior year.  Sales from businesses acquired since the first quarter of 2014 were $2.5 million or about 14 percent.  Asia Pacific sales were reduced by about 4 percent in the quarter due to foreign currency translation. Excluding acquisitions and the impact of foreign currency translation, Asia Pacific sales decreased by about 5 percent compared to the first quarter 2014.  The Asia Pacific region experienced a slowdown of sales in several end markets as customers deferred purchases due to the higher cost of U.S. dollar sourced product that resulted from the strengthening of the U.S. dollar against local currencies.

[0000038725-15-000087:8k_2_02:26]
Water Systems sales in Europe were about 8 percent of consolidated sales and decreased by about 11 percent compared to the first quarter 2014.   The impact of foreign currency translation decreased sales by about 26 percent compared to the first quarter 2014.  Excluding the impact of foreign currency translation, European sales were up about 15 percent to the first quarter 2014 due to strong motor and pump sales.

[0000038725-15-000087:8k_2_02:27]
Water Systems operating income, after non-GAAP adjustments, was $19.7 million in the first quarter 2015, down $9.6 million versus the first quarter 2014. The first quarter operating income margin after non-GAAP adjustments was 11.0 percent, down 490 basis points from 15.9 percent in the first quarter of 2014.  Operating income after non-GAAP adjustments decreased in Water Systems primarily due to

[0000038725-15-000087:8k_2_02:28]
foreign currency translation and reduced sales of Pioneer branded equipment for the oil and gas industry.  The strengthening U.S. dollar also lowered margins in foreign business units due to the increased cost of U.S. dollar sourced products in advance of offsetting price increases.  Additionally, higher promotional activity in the U.S. contributed to the decline in operating income and operating margins.

[0000038725-15-000087:8k_2_02:29]
Fueling Systems

[0000038725-15-000087:8k_2_02:30]
Fueling Systems sales represented 21 percent of consolidated sales and were $46.5 million in the first quarter 2015, a decrease of $0.3 million or about 1 percent versus the first quarter 2014 sales of $46.8 million.  Fueling Systems sales decreased by $2.7 million or about 6 percent in the quarter due to foreign currency translation.  Sales from businesses acquired since the first quarter of 2014 were $0.1 million. Fueling Systems sales were up about 5 percent, excluding foreign currency translation and acquisitions. Fueling Systems sales growth was primarily from fuel management systems and pressure pumping systems partially offset by a decline in sales of dispensing systems and storage tanks.

[0000038725-15-000087:8k_2_02:31]
Fueling Systems operating income after non-GAAP adjustments was a record $9.8 million in the first quarter of 2015 compared to $9.2 million after non-GAAP adjustments in the first quarter of 2014, an increase of about 7 percent. The first quarter operating income margin after non-GAAP adjustments was 21.1 percent, an increase of 140 basis points from the 19.7 percent of net sales in the first quarter of 2014.  The increase was driven by a positive product sales mix.

[0000038725-15-000087:8k_2_02:32]
Overall

[0000038725-15-000087:8k_2_02:33]
The Company’s consolidated gross profit was $71.5 million for the first quarter of 2015, a decrease of $6.6 million, or about 8 percent, from the first quarter of 2014 gross profit of $78.1 million. The gross profit as a percent of net sales was 31.7 percent in the first quarter of 2015 and declined about 210 basis points versus 33.8 percent during the first quarter 2014.  The gross profit margin decrease was due in large part to the same factors that impacted the Water Systems operating income after non-GAAP adjustments.

[0000038725-15-000087:8k_2_02:34]
Selling, general, and administrative (SG&A) expenses were $55.2 million in the first quarter of 2015 compared to $52.0 million in the first quarter of prior year, an increase of $3.2 million or about 6 percent.  The increase in SG&A expenses from acquired businesses was $2.0 million.  Excluding the acquisitions, the Company’s overall SG&A expenses in the first quarter of 2015 increased by $1.2 million or about 2 percent to prior year first quarter.

[0000038725-15-000087:8k_2_02:35]
The Company acquired the minority shareholdings of Pioneer during the first quarter.  This transaction created additional accretive benefits for the Company relative to the purchase of this subsidiary.  The first was the reversal of a deferred tax liability created in 2012 when the Company acquired a controlling interest in the Pioneer subsidiary and realized a gain on the then equity investment in Pioneer.  This first quarter tax benefit of about $4.8 million was treated as a non-GAAP adjustment to the Company’s earnings consistent with the treatment of the gain on the equity investment in 2012.  The Company also realized a gain on the redeemable non-controlling interest liability in the first quarter of this year of about $2.7 million which is included in ‘Other income’.  The accounting for this transaction resulted in certain tax benefits of about $3.5 million, most of which were expensed through the Company’s earnings in prior years.

[0000038725-15-000087:8k_2_02:36]
The Company ended the first quarter of 2015 with a cash balance of $69.6 million, which was $10.5 million higher than at the end of 2014.  The cash balance increase is primarily due to borrowing on the revolver to fund the Pioneer purchase and working capital requirements.

[0000038725-15-000087:8k_2_02:37]
Commenting on the outlook for the second quarter of 2015, Mr. Sengstack said:

[0000038725-15-000087:8k_2_02:38]
“Most of the factors that contributed to our first quarter 2015 operating results will remain with us in the second quarter.  We believe the impact of foreign currency translation will lower our Net Sales and Operating Income by about 8 percent when compared to the second quarter of 2014, and, the continued impact of lower oil and gas prices will reduce sales an additional 3 percent. Further, unfavorable early season weather and higher than normal inventories in regions of the U.S. will continue to dampen our domestic ground water business. Offsetting these headwinds, are strong organic growth in many of our developing region markets, and, the pricing actions and fixed costs controls that we have put in place.

[0000038725-15-000087:8k_2_02:39]
Because of these factors, we estimate our second quarter 2015 Water Systems Net Sales to be flat to the second quarter 2014 and our Water Systems adjusted Operating Income to decline by 6 to 8 percent as compared to the 33 percent decline in the first quarter.

[0000038725-15-000087:8k_2_02:40]
In our Fueling Systems segment, we have seen a general slowdown in quote and order activity in both China and India, two sources of significant growth in the past.  Although some of this may only be timing, political uncertainty regarding the large state owned Chinese oil companies may serve to defer equipment purchases to later in the year or beyond.  As a result, we believe our Fueling Systems Net Sales and Operating Income will be flat to increase by 3 percent in the second quarter when compared to the second quarter 2014.

[0000038725-15-000087:8k_2_02:41]
As a result, we are estimating our second quarter 2015 Adjusted Earnings per Share will be between $0.54 and $0.58.”

[0000038725-15-000087:8k_2_02:42]
A conference call to review earnings and other developments in the business will commence at 9:00 am EDT.  The first quarter 2015 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-15-000087:8k_2_02:43]
http://edge.media-server.com/m/p/frwtnend

[0000038725-15-000087:8k_2_02:44]
If you intend to ask questions during the call, please dial in using (877) 643-7158 for domestic calls and (914) 495-8565 for international calls.

[0000038725-15-000087:8k_2_02:45]
A replay of the conference call will be available Tuesday, April 28, 2015 at 12:00 noon EDT through midnight EDT on Tuesday, May 5, 2015, by dialing (855) 859-2056 for domestic calls and (404) 537-3406 for international calls. The replay passcode is: 24883377

[0000038725-15-000087:8k_2_02:46]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-15-000087:8k_2_02:47]
The Company presents the non-GAAP financial measures of earnings after non-GAAP adjustments, fully diluted earnings per share after non-GAAP adjustments (or adjusted EPS), operating income after non-GAAP adjustments and percent operating income to net sales after non-GAAP adjustments (or operating income margin after non-GAAP adjustments) because the Company believes the information helps investors understand underlying trends in the Company's business more easily. The differences between these measures and the most comparable GAAP measures are reconciled in the tables above.

[0000038725-15-000087:8k_2_02:48]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |
|  | First Quarter Ended |  |
|  | April 4, 2015 |  | March 29, 2014 |  |
| Net sales | $ | 225,728 |  |  | $ | 231,421 |  |  |
| Cost of sales | 154,238 |  |  | 153,310 |  |  |
| Gross profit | 71,490 |  |  | 78,111 |  |  |
| Selling, general, and administrative expenses | 55,160 |  |  | 52,015 |  |  |
| Restructuring (income)/expense | 463 |  |  | 136 |  |  |
| Operating income | 15,867 |  |  | 25,960 |  |  |
| Interest expense | (2,708 | ) |  | (2,784 | ) |  |
| Other income/(expense) | 3,019 |  |  | 325 |  |  |
| Foreign exchange income/(expense) | 416 |  |  | (420 | ) |  |
| Income before income taxes | 16,594 |  |  | 23,081 |  |  |
| Income tax expense/(benefit) | (3,382 | ) |  | 5,660 |  |  |
| Net income | $ | 19,976 |  |  | $ | 17,421 |  |  |
| Less: Net income attributable to noncontrolling interests | (181 | ) |  | (464 | ) |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 19,795 |  |  | $ | 16,957 |  |  |
| Income per share: |  |  |  |  |
| Basic | $ | 0.41 |  |  | $ | 0.35 |  |  |
| Diluted | $ | 0.41 |  |  | $ | 0.35 |  |  |

[0000038725-15-000087:8k_2_02:49]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | April 4, 2015 |  | January 3, 2015 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 69,593 |  |  | $ | 59,141 |  |
| Receivables | 155,087 |  |  | 143,787 |  |
| Inventories | 221,496 |  |  | 220,528 |  |
| Other current assets | 53,442 |  |  | 46,083 |  |
| Total current assets | 499,618 |  |  | 469,539 |  |
| Property, plant, and equipment, net | 198,179 |  |  | 209,786 |  |
| Goodwill and other assets | 382,960 |  |  | 396,562 |  |
| Total assets | $ | 1,080,757 |  |  | $ | 1,075,887 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 59,143 |  |  | $ | 70,806 |  |
| Accrued expenses and other current liabilities | 59,169 |  |  | 96,207 |  |
| Current maturities of long-term debt and short-term borrowings | 103,237 |  |  | 34,092 |  |
| Total current liabilities | 221,549 |  |  | 201,105 |  |
| Long-term debt | 143,189 |  |  | 143,695 |  |
| Deferred income taxes | 43,915 |  |  | 45,568 |  |
| Employee benefit plans | 55,989 |  |  | 58,709 |  |
| Other long-term liabilities | 20,784 |  |  | 21,407 |  |
| Redeemable noncontrolling interest | 6,335 |  |  | 6,420 |  |
| Total equity | 588,996 |  |  | 598,983 |  |
| Total liabilities and equity | $ | 1,080,757 |  |  | $ | 1,075,887 |  |

[0000038725-15-000087:8k_2_02:50]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | First Quarter Ended |
| (In thousands) | April 4, 2015 |  | March 29, 2014 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 19,976 |  |  | $ | 17,421 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 8,840 |  |  | 8,847 |  |
| Share-based compensation | 2,354 |  |  | 1,392 |  |
| Realized gain on share purchase liability | (2,723 | ) |  | — |  |
| Other | (7,425 | ) |  | (1,237 | ) |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (17,901 | ) |  | (31,451 | ) |
| Inventory | (7,360 | ) |  | (31,408 | ) |
| Accounts payable and accrued expenses | (18,081 | ) |  | 8,408 |  |
| Other | 504 |  |  | (7,352 | ) |
| Net cash flows from operating activities | (21,816 | ) |  | (35,380 | ) |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (4,205 | ) |  | (8,172 | ) |
| Proceeds from sale of property, plant, and equipment | 8 |  |  | 1,592 |  |
| Acquisitions and investments | (3,616 | ) |  | (2,449 | ) |
| Net cash flows from investing activities | (7,813 | ) |  | (9,029 | ) |
| Cash flows from financing activities: |  |  |  |
| Change in debt | 68,813 |  |  | 14,641 |  |
| Proceeds from issuance of common stock | 883 |  |  | 635 |  |
| Excess tax from share-based payment arrangements | 515 |  |  | 1,448 |  |
| Purchases of common stock | (2,288 | ) |  | (1,581 | ) |
| Dividends paid | (4,283 | ) |  | (3,709 | ) |
| Share purchase liability payment | (20,200 | ) |  | — |  |
| Net cash flows from financing activities | 43,400 |  |  | 11,434 |  |
| Effect of exchange rate changes on cash | (3,359 | ) |  | 559 |  |
| Net change in cash and equivalents | 10,452 |  |  | (32,416 | ) |
| Cash and equivalents at beginning of period | 59,141 |  |  | 134,553 |  |
| Cash and equivalents at end of period | $ | 69,593 |  |  | $ | 102,137 |  |
