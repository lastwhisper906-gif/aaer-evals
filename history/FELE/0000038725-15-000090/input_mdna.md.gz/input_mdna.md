# FELE MD&A — 0000038725-15-000090


## mdna

[0000038725-15-000090:mdna:1]
[same as prior period, unchanged from 0000038725-14-000200:mdna:1]

[0000038725-15-000090:mdna:2]
First Quarter 2015 vs. First Quarter 2014

[0000038725-15-000090:mdna:3]
[same as prior period, unchanged from 0000038725-14-000200:mdna:3]

[0000038725-15-000090:mdna:4]
Sales in the first quarter of 2015 decreased from the first quarter last year.  The sales decrease was primarily due to the negative impact of foreign currency translation. The Company's consolidated gross profit was $71.5 million for the first quarter of 2015, a decrease of $6.6 million or about 8 percent from the prior year’s first quarter. The gross profit as a percent of net sales decreased 210 basis points to 31.7 percent in 2015 from 33.8 percent in first quarter of 2014. Reported earnings per share of $0.41 were positively impacted by the purchase of the remaining minority shares of Pioneer Pump that was completed in the quarter and resulted in the realization of certain tax benefits and other income.

[0000038725-15-000090:mdna:5]
[same as prior period, unchanged from 0000038725-14-000200:mdna:5]

[0000038725-15-000090:mdna:6]
[same as prior period, unchanged from 0000038725-14-000200:mdna:6]

[0000038725-15-000090:mdna:7]
Net sales in the first quarter of 2015 were $225.7 million, a decrease of $5.7 million or about 2 percent compared to 2014 first quarter sales of $231.4 million.  The incremental impact of sales from acquired businesses was $8.9 million or about 4 percent.  Sales revenue decreased by $16.5 million or about 7 percent in the first quarter of 2015 due to foreign currency translation. The sales change in the first quarter of 2015, excluding acquisitions and foreign currency translation, was an increase of $1.9 million or about 1 percent.

[0000038725-15-000090:mdna:8]
|  | Net Sales |
| (In millions) | Q1 2015 |  | Q1 2014 |  | 2015 v 2014 |
| Water Systems | $ | 179.2 |  |  | $ | 184.6 |  |  | $ | (5.4 | ) |
| Fueling Systems | 46.5 |  |  | 46.8 |  |  | (0.3 | ) |
| Consolidated | $ | 225.7 |  |  | $ | 231.4 |  |  | $ | (5.7 | ) |

[0000038725-15-000090:mdna:9]
[same as prior period, unchanged from 0000038725-14-000200:mdna:9]

[0000038725-15-000090:mdna:10]
Water Systems revenues were $179.2 million in the first quarter 2015, a decrease of $5.4 million or about 3 percent versus the first quarter 2014 sales of $184.6 million. Sales from businesses acquired since the first quarter of 2014 were $8.8 million or about 5 percent. Water Systems sales were reduced by $13.8 million or about 8 percent in the quarter due to foreign currency translation. Water Systems sales were flat, excluding acquisitions and foreign currency translation, in the first quarter of 2015 versus the first quarter of 2014.

[0000038725-15-000090:mdna:11]
Water Systems sales in the U.S. and Canada represented 35 percent of consolidated sales and declined by about 10 percent compared to the prior year. Water Systems sales were reduced by $1.1 million or about 1 percent in the quarter due to foreign currency translation. Sales of mobile pumping equipment in the U.S. and Canada declined by about 50 percent in the first quarter of 2015 compared to the prior year first quarter due primarily to reduced demand in the oil and gas end markets. Sales of ground water pumping equipment declined by 6 percent and sales of surface water pumping equipment increased by about 4 percent in the U.S. and Canada compared to the first quarter 2014.

[0000038725-15-000090:mdna:12]
Water Systems sales in Latin America were about 16 percent of consolidated sales for the first quarter and grew by about 21 percent compared to the first quarter of the prior year.  Sales from businesses acquired since the first quarter of 2014 were $6.3 million or about 21 percent. Water Systems sales were reduced by $4.8 million or about 16 percent in the quarter due to foreign currency translation. Excluding acquisitions and the impact of foreign currency translation, Latin American sales increased by about 16 percent compared to the first quarter 2014.  The strong growth in sales was led by a 45 percent increase in sales in Mexico and continued double digit sales growth in Brazil.

[0000038725-15-000090:mdna:13]
Water Systems sales in the Middle East and Africa were about 12 percent of consolidated sales and decreased by about 3 percent compared to the first quarter 2014.  Water Systems sales were reduced by about 7 percent in the quarter due to foreign currency translation.  Excluding the impact of foreign currency translation, sales increased by about 4 percent compared to the first quarter 2014. The growth was driven by strong sales of groundwater pumping equipment sold under both the Impo and Franklin Electric brand names in Central and Southern Africa as well as Turkey, offset by weakness in North Africa and the Middle East due to increased political unrest.

[0000038725-15-000090:mdna:14]
Water Systems sales in the Asia Pacific region were 8 percent of consolidated sales and were up about 4 percent compared to the first quarter prior year.  Sales from businesses acquired since the first quarter of 2014 were $2.5 million or about 14 percent.  Asia Pacific sales were reduced by about 4 percent in the quarter due to foreign currency translation. Excluding acquisitions and the impact of foreign currency translation, Asia Pacific sales decreased by about 5 percent compared to the first quarter 2014.  The Asia Pacific region experienced a slowdown of sales in several end markets as customers deferred purchases due to the higher cost of U.S. dollar sourced product that resulted from the strengthening of the U.S. dollar against local currencies.

[0000038725-15-000090:mdna:15]
Water Systems sales in Europe were about 8 percent of consolidated sales and decreased by about 11 percent compared to the first quarter 2014.   The impact of foreign currency translation decreased sales by about 26 percent compared to the first quarter 2014.  Excluding the impact of foreign currency translation, European sales were up about 15 percent to the first quarter 2014 due to strong motor and pump sales.

[0000038725-15-000090:mdna:16]
[same as prior period, unchanged from 0000038725-14-000200:mdna:16]

[0000038725-15-000090:mdna:17]
Fueling Systems sales were $46.5 million in the first quarter 2015, a decrease of $0.3 million or about 1 percent versus the first quarter 2014 sales of $46.8 million. Sales from businesses acquired since the first quarter of 2014 were $0.1 million. Fueling Systems sales were decreased by $2.7 million or 6 percent in the quarter due to foreign currency translation. Fueling Systems sales growth, excluding acquisitions and foreign currency translation, was about 5 percent. Fueling Systems sales growth was primarily from fuel management systems and pressure pumping systems partially offset by a decline in sales of dispensing systems and storage tanks.

[0000038725-15-000090:mdna:18]
[same as prior period, unchanged from 0000038725-14-000200:mdna:19]

[0000038725-15-000090:mdna:19]
Cost of sales as a percentage of net sales for the first quarters of 2015 and 2014 was 68.3 percent and 66.2 percent, respectively. Correspondingly, the gross profit margin decreased to 31.7 percent from 33.8 percent, a 210 basis point decline. The Company’s consolidated gross profit was $71.5 million for the first quarter of 2015, a decrease of $6.6 million, or about 8 percent, from the first quarter of 2014 gross profit of $78.1 million.  The gross profit decrease was primarily due to foreign currency translation and reduced sales of Pioneer branded equipment for the oil and gas industry.  Additionally, gross profit decreased due to higher fixed cost and higher raw material costs due to the increased cost of U.S. dollar sourced products in advance of offsetting price increases, partially offset by lowered direct labor and variable costs.

[0000038725-15-000090:mdna:20]
[same as prior period, unchanged from 0000038725-14-000200:mdna:21]

[0000038725-15-000090:mdna:21]
Selling, general, and administrative (SG&A) expenses were $55.2 million in the first quarter of 2015 compared to $52.0 million in the first quarter of prior year, an increase of $3.2 million or about 6 percent.  The increase in SG&A expenses from acquired businesses was $2.0 million.  Excluding the acquisitions, the Company’s overall SG&A expenses in the first quarter of 2015 increased by $1.2 million or about 2 percent to prior year first quarter.

[0000038725-15-000090:mdna:22]
[same as prior period, unchanged from 0000038725-14-000200:mdna:23]

[0000038725-15-000090:mdna:23]
Restructuring expenses for the first quarter of 2015 were $0.5 million or about $0.01 impact on diluted earnings per share. Restructuring expenses were primarily for the continuing European manufacturing realignment started by the Company last year and include severance expenses and other miscellaneous manufacturing realignment activities. Restructuring expenses for the first quarter of 2014 were $0.1 million and had no impact on diluted earnings per share. Restructuring expenses were primarily severance expenses and other miscellaneous manufacturing realignment activities.

[0000038725-15-000090:mdna:24]
[same as prior period, unchanged from 0000038725-14-000200:mdna:25]

[0000038725-15-000090:mdna:25]
Operating income was $15.9 million in the first quarter of 2015, down $10.1 million or about 39 percent from $26.0 million in the first quarter of 2014.

[0000038725-15-000090:mdna:26]
|  |  | Operating income (loss) |
| (In millions) |  | Q1 2015 |  | Q1 2014 |  | 2015 v 2014 |
| Water Systems |  | $ | 19.4 |  |  | $ | 29.2 |  |  | $ | (9.8 | ) |
| Fueling Systems |  | 9.6 |  |  | 9.1 |  |  | 0.5 |  |
| Other |  | (13.1 | ) |  | (12.3 | ) |  | (0.8 | ) |
| Consolidated |  | $ | 15.9 |  |  | $ | 26.0 |  |  | $ | (10.1 | ) |

[0000038725-15-000090:mdna:27]
There were specific items in the first quarters of 2015 and 2014 that impacted operating income that were not operational in

[0000038725-15-000090:mdna:28]
nature.  In the first quarter of 2015, there were two such items: $0.5 million of restructuring charges and $0.3 million in higher pension cost related to a CEO  who retired in May 2014.  In the first quarter of 2014, there were two such items: $0.1 million of restructuring charges and $0.1 million for acquisition related activities.

[0000038725-15-000090:mdna:29]
The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of operating income after non-GAAP adjustments and percent operating income to net sales after non-GAAP adjustments to net sales (operating income margin after non-GAAP adjustments).  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-15-000090:mdna:30]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (In millions) | For the First Quarter 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 19.4 |  | $ | 9.6 |  | $ | (13.1 | ) | $ | 15.9 |  |
| % Operating Income To Net Sales | 10.8 | % | 20.6 | % |  | 7.0 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.3 |  | $ | 0.2 |  | $ | — |  | $ | 0.5 |  |
| Non-GAAP | $ | — |  | $ | — |  | $ | 0.3 |  | $ | 0.3 |  |
| Operating Income after Non-GAAP Adjustments | $ | 19.7 |  | $ | 9.8 |  | $ | (12.8 | ) | $ | 16.7 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 11.0 | % | 21.1 | % |  | 7.4 | % |
|  | For the First Quarter 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 29.2 |  | $ | 9.1 |  | $ | (12.3 | ) | $ | 26.0 |  |
| % Operating Income To Net Sales | 15.8 | % | 19.4 | % |  | 11.2 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.1 |  | $ | — |  | $ | — |  | $ | 0.1 |  |
| Non-GAAP | $ | — |  | $ | 0.1 |  | $ | — |  | $ | 0.1 |  |
| Operating Income after Non-GAAP Adjustments | $ | 29.3 |  | $ | 9.2 |  | $ | (12.3 | ) | $ | 26.2 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 15.9 | % | 19.7 | % |  | 11.3 | % |

[0000038725-15-000090:mdna:31]
[same as prior period, unchanged from 0000038725-14-000200:mdna:39]

[0000038725-15-000090:mdna:32]
Water Systems operating income, after non-GAAP adjustments, was $19.7 million in the first quarter 2015, down $9.6 million versus the first quarter 2014. The first quarter operating income margin after non-GAAP adjustments was 11.0 percent, down 490 basis points from 15.9 percent in the first quarter of 2014.  Operating income after non-GAAP adjustments decreased in Water Systems primarily due to foreign currency translation and reduced sales of Pioneer branded equipment for the oil and gas industry.  The strengthening U.S. dollar also lowered margins in foreign business units due to the increased cost of U.S. dollar sourced products in advance of offsetting price increases.  Additionally, higher promotional activity in the U.S. contributed to the decline in operating income and operating margins.

[0000038725-15-000090:mdna:33]
[same as prior period, unchanged from 0000038725-14-000200:mdna:41]

[0000038725-15-000090:mdna:34]
Fueling Systems operating income after non-GAAP adjustments was a record $9.8 million in the first quarter of 2015 compared to $9.2 million after non-GAAP adjustments in the first quarter of 2014, an increase of about 7 percent. The first quarter operating income margin after non-GAAP adjustments was 21.1 percent, an increase of 140 basis points from the 19.7 percent of net sales in the first quarter of 2014.  The increase was driven by a positive product sales mix.

[0000038725-15-000090:mdna:35]
[same as prior period, unchanged from 0000038725-14-000200:mdna:43]

[0000038725-15-000090:mdna:36]
Operating income-other is composed primarily of unallocated general and administrative expenses.

[0000038725-15-000090:mdna:37]
[same as prior period, unchanged from 0000038725-14-000200:mdna:45]

[0000038725-15-000090:mdna:38]
Interest expense for the first quarters of 2015 and 2014 was $2.7 million and $2.8 million, respectively.

[0000038725-15-000090:mdna:39]
[same as prior period, unchanged from 0000038725-14-000200:mdna:47]

[0000038725-15-000090:mdna:40]
Other income or expense was income of $3.0 million in the first quarter of 2015 and income of $0.3 million in the first quarter of 2014.  Included in other income in the first quarter of 2015 was interest income of $0.2 million, primarily derived from the investment of cash balances in short-term securities. The Company also realized a gain on the settlement of the share purchase liability related to Pioneer Pump in the first quarter of this year of about $2.7 million. Included in other income in the first quarter of 2014 was interest income of $0.4 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-15-000090:mdna:41]
[same as prior period, unchanged from 0000038725-14-000200:mdna:50]

[0000038725-15-000090:mdna:42]
Foreign currency-based transactions produced a gain of $0.4 million for the first quarter of 2015, primarily due to the euro.  Foreign currency-based transactions produced a loss of $0.4 million for the first quarter of 2014, primarily due to the Canadian dollar.

[0000038725-15-000090:mdna:43]
[same as prior period, unchanged from 0000038725-14-000200:mdna:52]

[0000038725-15-000090:mdna:44]
The provision for income taxes in the first quarters of 2015 and 2014 was a credit of $(3.4) million and expense of $5.7 million, respectively. The effective tax rate for the first quarter of 2015 was about negative 20 percent and, before the impact of discrete events, was about 27 percent.   Discrete adjustments during the first quarter of 2015 were the reversal of a deferred tax liability created in 2012 when the Company acquired the controlling interest in the Pioneer subsidiary and realized a gain on the then equity investment in Pioneer.  This first quarter tax benefit of about $4.8 million was treated as a non-GAAP adjustment.  Because in 2012, the gain was treated as a non-GAAP adjustment, the Company is now consistently treating the reversal of the tax liability related to that gain as a non-GAAP adjustment and reducing reported Earnings per Share in the first quarter of 2015 by $0.10 cents. The Company also realized a gain on the settlement of the share purchase liability in the first quarter of this year of about $2.7 million which is included in ‘Other income’.  The transaction to acquire the remaining minority shares of Pioneer Pump also resulted in other tax benefits of about $2.5 million, which were expensed through the Company’s earnings in prior years as well as a current period tax benefit of about $1.0 million related to the 2015 gain. The Company’s tax rate as a percentage of pre-tax earnings for the second quarter of 2015 is projected to be about 27 percent, flat to the second quarter of 2014 tax rate, before discrete adjustments.  The projected tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings and reduced taxes on foreign and repatriated earnings after the restructuring of certain foreign entities. The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations, current cash on hand, and available credit.

[0000038725-15-000090:mdna:45]
[same as prior period, unchanged from 0000038725-14-000200:mdna:54]

[0000038725-15-000090:mdna:46]
Net income for the first quarter of 2015 was $20.0 million compared to the prior year first quarter net income of $17.4 million.  Net income attributable to Franklin Electric Co., Inc. for the first quarter of 2015 was $19.8 million, or $0.41 per diluted share, compared to the prior year first quarter net income attributable to Franklin Electric Co., Inc. of $17.0 million or $0.35 per diluted share. Earnings after non-GAAP adjustments for the first quarter of 2015 were $15.2 million, or $0.32 per diluted share, compared to the prior year first quarter earnings after non-GAAP adjustments of $16.9 million or $0.35 per diluted share.

[0000038725-15-000090:mdna:47]
There were specific items in the first quarters of 2015 and 2014 that impacted net income attributable to Franklin Electric Co., Inc. that were not operational in nature.  The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of earnings after non-GAAP adjustments and adjusted EPS.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-15-000090:mdna:48]
| Earnings Before and After Non-GAAP Adjustments | For the First Quarter Ended |
| (In millions) | 2015 | 2014 | Change |
| Net Income attributable to Franklin Electric Co., Inc. Reported | $ | 19.8 |  | $ | 17.0 |  | 16 | % |
| Allocated Undistributed Earnings | $ | (0.3 | ) | $ | (0.3 | ) |  |
| Adjusted Earnings for EPS Calculations | $ | 19.5 |  | $ | 16.7 |  | 17 | % |
| Non-GAAP adjustments, before tax: |  |  |  |
| Restructuring | $ | 0.5 |  | $ | 0.1 |  |  |
| Non-GAAP items | $ | 0.3 |  | $ | 0.1 |  |  |
| Pioneer tax benefits on equity gain | $ | (4.8 | ) | $ | — |  |  |
| Non-GAAP adjustments, net of tax: |  |  |  |
| Restructuring | $ | 0.3 |  | $ | 0.1 |  |  |
| Non-GAAP items | $ | 0.2 |  | $ | 0.1 |  |  |
| Pioneer tax benefits on equity gain | $ | (4.8 | ) | $ | — |  |  |
| Net Income attributable to Franklin Electric Co., Inc. after Non-GAAP Adjustments (Adjusted Net Income) | $ | 15.2 |  | $ | 16.9 |  | (10 | )% |

[0000038725-15-000090:mdna:49]
| Earnings Per Share Before and After Non-GAAP Adjustments | For the First Quarter Ended |
| (In millions, except per share data) | 2015 | 2014 | Change |
| Average Fully Diluted Shares Outstanding | 48.1 |  | $ | 48.3 |  | — | % |
| Fully Diluted Earnings Per Share ("EPS") Reported | $ | 0.41 |  | $ | 0.35 |  | 17 | % |
| Restructuring per Share, net of tax | $ | 0.01 |  | $ | — |  |  |
| Non-GAAP items | $ | — |  | $ | — |  |  |
| Pioneer tax benefits on equity gain | $ | (0.10 | ) |  |  |
| Fully Diluted EPS after Non-GAAP Adjustments (Adjusted EPS) | $ | 0.32 |  | $ | 0.35 |  | (9 | )% |

[0000038725-15-000090:mdna:50]
[same as prior period, unchanged from 0000038725-14-000200:mdna:120]

[0000038725-15-000090:mdna:51]
[same as prior period, unchanged from 0000038725-14-000200:mdna:121]

[0000038725-15-000090:mdna:52]
On December 31, 2012, the Company, Allen County, Indiana and certain institutional investors entered into a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project).” The aggregate principal amount of the Project Bonds that were issued and authenticated was limited to $25.0 million. Interest and principal balance of the Project Bonds are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.

[0000038725-15-000090:mdna:53]
The Company also has an amended and restated uncommitted note purchase and private shelf agreement (the “Prudential Agreement”) in the amount of $200.0 million, with $150.0 million of notes issued thereunder.  The Company has scheduled principal payments under the Prudential Agreement beginning in 2015 at which time it amortizes for 5 years at an amount of $30.0 million per year.  As of April 4, 2015, the Company had $50.0 million borrowing capacity under the Prudential Agreement.

[0000038725-15-000090:mdna:54]
25

[0000038725-15-000090:mdna:55]
In addition, the Company has a committed, unsecured, revolving credit agreement maturing on December 14, 2016 (the “Credit Agreement”) in the amount of $150.0 million. As of April 4, 2015, the Company had $75.1 million borrowing capacity under the Credit Agreement as $5.0 million in letters of commercial and standby letters of credit were outstanding and undrawn and $69.9 million of revolver borrowing was drawn and outstanding at the end of the quarter.  There were no other outstanding borrowings as of April 4, 2015 on the Credit Agreement.

[0000038725-15-000090:mdna:56]
The Credit Agreement, the Prudential Agreement, and the Project Bonds contain customary affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00.  Cross default is applicable with the Credit Agreement, the Prudential Agreement, and the Project Bonds, but only if the Company is defaulting on an obligation exceeding $10.0 million.  On May 5, 2015, the Company executed the following agreements:  Amendment No. 6 to the Prudential Agreement; Amendment No. 3 to the Credit Agreement; and Amendment No. 1 to the Bond  Purchase and Loan Agreement.  Each of those agreements provides for debt repayment guarantees from certain Company subsidiaries and waives certain non-financial covenants related to subsidiary guarantees.  The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-15-000090:mdna:57]
At April 4, 2015, the Company had $69.6 million of cash on hand at various locations worldwide. Approximately 29 percent of the cash and equivalents was in the U.S. and readily accessible.  Approximately 39 percent was in Europe, and the remaining 32 percent was in South America, Asia Pacific, and other locations combined. On a regular basis the Company reviews international cash balances and, if appropriate based on forecasted expenditures and considerations for the post-tax economic efficiency, will reposition cash among its global entities.  Cash investments worldwide are invested according to a written policy, and are generally in bank demand accounts and bank time deposits with the preservation of principal as the highest priority.

[0000038725-15-000090:mdna:58]
Net cash used by operating activities was $21.8 million for the first quarter ended April 4, 2015 compared to $35.4 million for the first quarter ended March 29, 2014.  The reduction in cash used by operations during the first quarter of 2015 was primarily due to higher collections of outstanding receivables during the first quarter of 2015 compared to the first quarter of 2014.  During the first quarter of 2015, the mandatory share purchase liability of $22.9 million for PPH was settled, resulting in a non-cash gain and reversal of certain deferred tax liabilities, also non-cash, both of which were adjustments to net income.

[0000038725-15-000090:mdna:59]
Net cash used in investing activities was $7.8 million for the first quarter ended April 4, 2015, compared to $9.0 million for the first quarter ended March 29, 2014.  The decrease in cash used can be primarily attributed to decreased capital expenditures during the first quarter of 2015 compared to the first quarter of 2014.

[0000038725-15-000090:mdna:60]
Net cash provided by financing activities was $43.4 million for the first quarter ended April 4, 2015, compared to $11.4 million for the first quarter ended March 29, 2014. The increase in cash provided by financing activities in the first quarter of 2015 was primarily due to increased borrowings against the Credit Agreement to fund operating requirements and the payment for the PPH mandatory share purchase liability.

[0000038725-15-000090:mdna:61]
[same as prior period, unchanged from 0000038725-14-000200:mdna:132]

[0000038725-15-000090:mdna:62]
Form 10-K for the fiscal year ended January 3, 2015, and in Exhibit 99.1 thereto. Any forward-looking statements included in this Form 10-Q are based upon information presently available. The Company does not assume any obligation to update any forward-looking information, except as required by law.
