# FELE note change history — 0000038725-14-000200 → 0000038725-15-000090


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-05-06):
[0000038725-15-000090:note_history:1]
On July 25, 2013, the Court issued a Final Statement of Decision (“Decision”) in the CARB Case.  In its Decision, the Court found on behalf of the Company and issued a complete defense verdict.  Judgment was entered on August 27, 2013.  An Amended Judgment awarding the Company $0.1 million in costs was entered by the Court on January 22, 2014. On July 16, 2014, CARB appealed and filed its brief in support of the appeal. The Company filed its response brief on December 23, 2014 and CARB filed its reply brief on February 2, 2015.  The case is now with the California Court of Appeals to either make a ruling on these briefs or schedule an oral argument.  The Company has not been notified regarding the status of this matter at this time.
  (was, 2014-11-06, similarity 0.6534):
[0000038725-14-000200:note_history:1]
On July 25, 2013, the Court issued a Final Statement of Decision (“Decision”) in the CARB Case.  In its Decision, the Court found on behalf of the Company and issued a complete defense verdict.  Judgment was entered on August 27, 2013.  An Amended Judgment awarding the Company $0.1 million in costs was entered by the Court on January 22, 2014. On July 16, 2014, CARB appealed and filed its brief in support of the appeal. The Company has until December 12, 2014 to file its response brief.  If a hearing is held on the appeal it will likely occur sometime late in the second quarter of 2015.

- changed (2015-05-06):
[0000038725-15-000090:note_history:2]
At April 4, 2015, the Company had $12.0 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.
  (was, 2014-11-06, similarity 0.8791):
[0000038725-14-000200:note_history:2]
At September 27, 2014, the Company had $8.7 million of commitments primarily for the purchase of raw materials to be used in production.

- changed (2015-05-06):
[0000038725-15-000090:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the first quarter ended April 4, 2015, are as follows:
  (was, 2014-11-06, similarity 0.8963):
[0000038725-14-000200:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 27, 2014, are as follows:

- added (2015-05-06):
[0000038725-15-000090:note_history:4]
| (In millions) |  |  |
| Balance as of January 3, 2015 |  | $ | 9.4 |  |
| Accruals related to product warranties |  | 1.4 |  |
| Reductions for payments made |  | (2.1 | ) |
| Balance as of April 4, 2015 |  | $ | 8.7 |  |

- removed (2015-05-06):
[0000038725-14-000200:note_history:5]
CONTINGENCIES AND COMMITMENTS

- removed (2015-05-06):
[0000038725-14-000200:note_history:6]
| (In millions) |  |  |
| Balance as of December 28, 2013 |  | $ | 9.5 |  |
| Accruals related to product warranties |  | 6.3 |  |
| Reductions for payments made |  | (6.9 | ) |
| Balance as of September 27, 2014 |  | $ | 8.9 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-05-06):
[0000038725-15-000090:note_history:7]
The accompanying condensed consolidated balance sheet as of January 3, 2015, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of April 4, 2015, and for the first quarters ended April 4, 2015 and March 29, 2014, have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the first quarter ended April 4, 2015 are not necessarily indicative of the results that may be expected for the fiscal year ending January 2, 2016.  For further information, including a description of the Company’s critical accounting policies, refer to the consolidated financial statements and notes thereto included in Franklin Electric Co., Inc.'s Annual Report on Form 10-K for the year ended January 3, 2015.
  (was, 2014-11-06, similarity 0.9192):
[0000038725-14-000200:note_history:7]
The accompanying condensed consolidated balance sheet as of December 28, 2013, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 27, 2014, and for the third quarters and nine months ended September 27, 2014 and September 28, 2013, have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the third quarter and nine months ended September 27, 2014 are not necessarily indicative of the results that may be expected for the fiscal year ending January 3, 2015.  For further information, including a description of the Company’s critical accounting policies, refer to the consolidated financial statements and notes thereto included in Franklin Electric Co., Inc.'s Annual Report on Form 10-K/A for the year ended December 28, 2013.

- removed (2015-05-06):
[0000038725-14-000200:note_history:8]
Certain prior year amounts in the investing activities section on the condensed consolidated statement of cash flows were reclassified into the "Other, net" line to conform with the current year presentation.  The reclassification within the investing activities section of the condensed consolidated statement of cash flows had no impact on the operating cash flows or any other financial statement.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-06):
[0000038725-15-000090:note_history:9]
| (In millions) |  | April 4, 2015 |  | January 3, 2015 |
| Prudential Agreement - 5.79 percent |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 23.2 |  |  | 23.7 |  |
| Revolver |  | 69.9 |  |  | — |  |
| Capital leases |  | 0.6 |  |  | 0.6 |  |
| Foreign subsidiary debt |  | 2.7 |  |  | 3.5 |  |
|  |  | 246.4 |  |  | 177.8 |  |
| Less current maturities |  | (103.2 | ) |  | (34.1 | ) |
| Long-term debt |  | $ | 143.2 |  |  | $ | 143.7 |  |
  (was, 2014-11-06, similarity 0.9409):
[0000038725-14-000200:note_history:9]
| (In millions) |  | September 27, 2014 |  | December 28, 2013 |
| Prudential Agreement - 5.79 percent |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 23.7 |  |  | 24.6 |  |
| Revolver |  | 45.7 |  |  | — |  |
| Capital leases |  | 0.8 |  |  | 0.8 |  |
| Foreign subsidiary debt |  | 7.2 |  |  | 14.2 |  |
|  |  | 227.4 |  |  | 189.6 |  |
| Less current maturities |  | (82.7 | ) |  | (15.4 | ) |
| Long-term debt |  | $ | 144.7 |  |  | $ | 174.2 |  |

- added (2015-05-06):
[0000038725-15-000090:note_history:10]
During the first quarter ended April 4, 2015, a portion of the Revolver borrowing (the "Credit Agreement") was used for working capital needs.

- added (2015-05-06):
[0000038725-15-000090:note_history:11]
On May 5, 2015, the Company executed the following agreements:  Amendment No. 6 to the Prudential Agreement; Amendment No. 3 to the Credit Agreement; and Amendment No. 1 to the Bond Purchase and Loan Agreement.  Each of those agreements provides for debt repayment guarantees from certain Company subsidiaries and waives certain non-financial covenants related to subsidiary guarantees.

- changed (2015-05-06):
[0000038725-15-000090:note_history:12]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 245.8 |  |  | $ | 102.9 |  |  | $ | 31.1 |  |  | $ | 31.1 |  |  | $ | 31.4 |  |  | $ | 31.1 |  |  | $ | 18.2 |  |
| Capital leases |  | 0.6 |  |  | 0.3 |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |
|  |  | $ | 246.4 |  |  | $ | 103.2 |  |  | $ | 31.2 |  |  | $ | 31.2 |  |  | $ | 31.5 |  |  | $ | 31.1 |  |  | $ | 18.2 |  |
  (was, 2014-11-06, similarity 0.7417):
[0000038725-14-000200:note_history:12]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 226.6 |  |  | $ | 82.4 |  |  | $ | 31.6 |  |  | $ | 31.3 |  |  | $ | 31.4 |  |  | $ | 31.1 |  |  | $ | 18.8 |  |
| Capital leases |  | 0.8 |  |  | 0.3 |  |  | 0.1 |  |  | 0.2 |  |  | 0.1 |  |  | 0.1 |  |  | — |  |
|  |  | $ | 227.4 |  |  | $ | 82.7 |  |  | $ | 31.7 |  |  | $ | 31.5 |  |  | $ | 31.5 |  |  | $ | 31.2 |  |  | $ | 18.8 |  |

- removed (2015-05-06):
[0000038725-14-000200:note_history:13]
Foreign subsidiary debt denoted in the table above is predominately comprised of debt at Impo and Bombas Leao.

- removed (2015-05-06):
[0000038725-14-000200:note_history:14]
During the third quarter ended September 27, 2014, a portion of the Revolver borrowing was used to retire $16.5 million of third-party bank loans in Turkey and Brazil.

- removed (2015-05-06):
[0000038725-14-000200:note_history:15]
On June 6, 2014, the Company assumed debt relating to the acquisition of Bombas Leao (see Note 3) of BRL 12.6 million, $5.6 million at the then current exchange rate.  The debt instruments bear interest rates ranging from 2.5 percent to 19.4 percent, with due dates ranging from November 2014 to November 2017.  There are no financial covenants associated with these debt instruments.  The value of the debt assumed in the Bombas Leao acquisition increased by BRL 0.2 million ($0.1 million) during the third quarter ended September 27, 2014 resulting from additional information provided for the provisional valuation and working capital adjustments.

- removed (2015-05-06):
[0000038725-14-000200:note_history:16]
The total estimated fair value of debt was $241.4 million and $203.7 million at September 27, 2014 and December 28, 2013, respectively.  The fair value assumed floating rate debt was valued at par.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its long-term debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as a Level 2 within the valuations hierarchy.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-06):
[0000038725-15-000090:note_history:17]
| (In millions) |  | April 4, 2015 |  | January 3, 2015 |
| Prudential Agreement - 5.79 percent |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 23.2 |  |  | 23.7 |  |
| Revolver |  | 69.9 |  |  | — |  |
| Capital leases |  | 0.6 |  |  | 0.6 |  |
| Foreign subsidiary debt |  | 2.7 |  |  | 3.5 |  |
|  |  | 246.4 |  |  | 177.8 |  |
| Less current maturities |  | (103.2 | ) |  | (34.1 | ) |
| Long-term debt |  | $ | 143.2 |  |  | $ | 143.7 |  |
  (was, 2014-11-06, similarity 0.9409):
[0000038725-14-000200:note_history:17]
| (In millions) |  | September 27, 2014 |  | December 28, 2013 |
| Prudential Agreement - 5.79 percent |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 23.7 |  |  | 24.6 |  |
| Revolver |  | 45.7 |  |  | — |  |
| Capital leases |  | 0.8 |  |  | 0.8 |  |
| Foreign subsidiary debt |  | 7.2 |  |  | 14.2 |  |
|  |  | 227.4 |  |  | 189.6 |  |
| Less current maturities |  | (82.7 | ) |  | (15.4 | ) |
| Long-term debt |  | $ | 144.7 |  |  | $ | 174.2 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-06):
[0000038725-15-000090:note_history:18]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 245.8 |  |  | $ | 102.9 |  |  | $ | 31.1 |  |  | $ | 31.1 |  |  | $ | 31.4 |  |  | $ | 31.1 |  |  | $ | 18.2 |  |
| Capital leases |  | 0.6 |  |  | 0.3 |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |
|  |  | $ | 246.4 |  |  | $ | 103.2 |  |  | $ | 31.2 |  |  | $ | 31.2 |  |  | $ | 31.5 |  |  | $ | 31.1 |  |  | $ | 18.2 |  |
  (was, 2014-11-06, similarity 0.7417):
[0000038725-14-000200:note_history:18]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 226.6 |  |  | $ | 82.4 |  |  | $ | 31.6 |  |  | $ | 31.3 |  |  | $ | 31.4 |  |  | $ | 31.1 |  |  | $ | 18.8 |  |
| Capital leases |  | 0.8 |  |  | 0.3 |  |  | 0.1 |  |  | 0.2 |  |  | 0.1 |  |  | 0.1 |  |  | — |  |
|  |  | $ | 227.4 |  |  | $ | 82.7 |  |  | $ | 31.7 |  |  | $ | 31.5 |  |  | $ | 31.5 |  |  | $ | 31.2 |  |  | $ | 18.8 |  |
