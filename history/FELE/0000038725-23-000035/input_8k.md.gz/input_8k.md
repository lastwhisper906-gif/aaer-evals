# FELE 8-K — 0000038725-23-000002 filed 2023-02-14

## item codes, every 8-K on or before 2023-02-22

- 2023-02-21 0000038725-23-000016 — 8.01, 9.01
- 2023-02-14 0000038725-23-000002 — 2.02, 9.01
- 2022-10-28 0000038725-22-000180 — 7.01, 9.01
- 2022-10-25 0000038725-22-000177 — 2.02, 9.01
- 2022-08-04 0000038725-22-000150 — 7.01, 9.01
- 2022-07-26 0000038725-22-000142 — 2.02, 9.01
- 2022-05-11 0000038725-22-000106 — 2.03, 9.01
- 2022-05-06 0000038725-22-000082 — 5.07
- 2022-05-06 0000038725-22-000081 — 5.02, 9.01
- 2022-05-03 0000038725-22-000075 — 7.01, 9.01
- 2022-04-26 0000038725-22-000073 — 2.02, 9.01
- 2022-03-24 0000038725-22-000056 — 5.02, 9.01
- 2022-03-08 0000038725-22-000049 — 7.01, 9.01
- 2022-02-15 0000038725-22-000007 — 2.02, 9.01
- 2022-01-04 0000038725-22-000002 — 7.01, 9.01
- 2021-11-03 0000038725-21-000212 — 7.01, 9.01
- 2021-10-26 0000038725-21-000203 — 2.02, 9.01
- 2021-07-27 0000038725-21-000172 — 7.01, 9.01
- 2021-07-27 0000038725-21-000170 — 2.02, 9.01
- 2021-06-14 0000038725-21-000157 — 5.02, 7.01, 9.01
- 2021-05-17 0000038725-21-000120 — 7.01, 9.01
- 2021-05-17 0000038725-21-000118 — 7.01, 9.01
- 2021-05-13 0000038725-21-000102 — 2.03, 9.01
- 2021-05-07 0000038725-21-000096 — 5.07
- 2021-05-07 0000038725-21-000094 — 5.02, 9.01
- 2021-04-27 0000038725-21-000088 — 7.01, 9.01
- 2021-04-27 0000038725-21-000085 — 2.02, 9.01
- 2021-04-01 0000038725-21-000080 — 7.01, 9.01
- 2021-02-17 0000038725-21-000013 — 7.01, 9.01
- 2021-02-16 0000038725-21-000010 — 2.02, 9.01
- 2021-01-04 0000038725-21-000003 — 7.01, 9.01
- 2020-12-18 0000038725-20-000241 — 5.02, 9.01
- 2020-11-09 0000038725-20-000223 — 7.01, 9.01
- 2020-11-02 0000038725-20-000210 — 7.01, 9.01
- 2020-10-27 0000038725-20-000206 — 2.02, 9.01
- 2020-07-28 0000038725-20-000168 — 2.02, 9.01
- 2020-06-25 0000038725-20-000164 — 8.01, 9.01
- 2020-06-25 0000038725-20-000163 — 8.01, 9.01
- 2020-05-11 0000038725-20-000133 — 5.02, 9.01
- 2020-05-08 0000038725-20-000119 — 5.07
- 2020-05-06 0000038725-20-000111 — 5.02, 9.01
- 2020-04-28 0000038725-20-000104 — 2.02, 9.01
- 2020-02-18 0000038725-20-000018 — 2.02, 9.01
- 2020-01-30 0000038725-20-000009 — 5.02, 5.03, 9.01
- 2019-11-04 0000038725-19-000234 — 7.01, 9.01
- 2019-10-29 0000038725-19-000221 — 2.02, 9.01
- 2019-08-01 0000038725-19-000193 — 7.01, 9.01
- 2019-07-23 0000038725-19-000178 — 2.02, 9.01
- 2019-05-07 0000038725-19-000140 — 5.03, 9.01
- 2019-05-03 0000038725-19-000124 — 5.07
- 2019-05-03 0000038725-19-000122 — 7.01, 9.01
- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2023-02-22

- none on or before 2023-02-22

## item 2.02 — earnings release, exhibit 99.1

[0000038725-23-000002:8k_2_02:1]
EX-99.1
2
a20230214ex991earningsrele.htm
EX-99.1

[0000038725-23-000002:8k_2_02:2]
Document

[0000038725-23-000002:8k_2_02:3]
Exhibit 99.1

[0000038725-23-000002:8k_2_02:4]
NEWS RELEASE FOR IMMEDIATE DISTRIBUTION

[0000038725-23-000002:8k_2_02:5]
FRANKLIN ELECTRIC REPORTS RECORD FOURTH QUARTER 2022 AND FULL YEAR 2022 RESULTS

[0000038725-23-000002:8k_2_02:6]
Fourth Quarter 2022 Highlights

[0000038725-23-000002:8k_2_02:7]
•Sales of $489.4 million, an increase of 13% over the prior year, was a fourth quarter record

[0000038725-23-000002:8k_2_02:8]
•Strong sales growth in all three Segments; Distribution up 27%, Water Systems up 9%, and Fueling Systems up 8%

[0000038725-23-000002:8k_2_02:9]
•Operating income was a fourth quarter record at $56.2 million, an increase of 19% over the prior year

[0000038725-23-000002:8k_2_02:10]
•GAAP fully diluted earnings per share (EPS) was $0.84, a decrease of $0.01 to prior year

[0000038725-23-000002:8k_2_02:11]
Full Year 2022 Highlights

[0000038725-23-000002:8k_2_02:12]
•Full Year record sales of $2.0 billion, an increase of 23% over the prior year

[0000038725-23-000002:8k_2_02:13]
•Strong sales growth in all three Segments; Distribution up 34%, Water Systems up 20%, and Fueling Systems up 16%

[0000038725-23-000002:8k_2_02:14]
•Operating income for 2022 was a record at $257.2 million, an increase of 36% over the prior year

[0000038725-23-000002:8k_2_02:15]
•GAAP fully diluted EPS was a record at $3.97, an increase of 22% over the prior year

[0000038725-23-000002:8k_2_02:16]
Fort Wayne, IN – February 14, 2023 – Franklin Electric Co. Inc. today announced fourth quarter and full year financial results for fiscal year 2022.

[0000038725-23-000002:8k_2_02:17]
Fourth quarter 2022 sales were $489.4 million, compared to fourth quarter 2021 sales of $432.5 million.  Fourth quarter 2022 operating income was $56.2 million, compared to fourth quarter operating income in 2021 of $47.2 million.  Fourth quarter 2022 GAAP fully diluted EPS was $0.84, versus GAAP fully diluted EPS in the fourth quarter 2021 of $0.85.  Worth noting, the Company’s fourth quarter 2021 results included a $6.5 million one-time gain on a bargain purchase price transaction.

[0000038725-23-000002:8k_2_02:18]
Full year 2022 sales were $2.0 billion, compared to full year 2021 sales of $1.7 billion.  Full year 2022 operating income was $257.2 million, compared to operating income in 2021 of $189.2 million.  Full year 2022 GAAP fully diluted EPS was $3.97, versus GAAP fully diluted EPS in 2021 of $3.25.

[0000038725-23-000002:8k_2_02:19]
“Franklin Electric delivered a solid fourth quarter finish to 2022 with our eighth consecutive quarter of double-digit sales and operating income growth over the prior-year quarter, which capped another record full year for sales, operating income and earnings per share. Once again, our global team rose to the occasion and delivered in a challenging, but improving, operating environment,” commented Gregg Sengstack, Franklin Electric’s Chairperson and Chief Executive Officer.

[0000038725-23-000002:8k_2_02:20]
“Demand remained strong across our business in the fourth quarter, demonstrated by sustained top-line growth and the elevated backlog at year-end which carries over into 2023. Looking forward, we are well positioned to continue our momentum based on the robust demand across our end markets, our diverse customer base, and the growing global need for clean water and safe, cost-effective fueling solutions.” Mr. Sengstack concluded.

[0000038725-23-000002:8k_2_02:21]
Segment Summaries

[0000038725-23-000002:8k_2_02:22]
Water Systems sales, a new fourth quarter record, were $281.3 million in the fourth quarter 2022, an increase of $23.3 million compared to the fourth quarter 2021.  Sales increases were led by pricing actions and healthy end market demand across all major product lines in groundwater pumping, surface pumping and water treatment.  Water Systems operating income in the fourth quarter was $44.6 million, a new fourth quarter record, driven by higher sales and operating leverage.  Fourth quarter 2021 Water Systems operating income was $36.4 million.

[0000038725-23-000002:8k_2_02:23]
Distribution sales, a new fourth quarter record, were $148.9 million in the fourth quarter 2022, an increase of $32.0 million compared to the fourth quarter 2021.  The Distribution segment operating income was $2.9 million in the fourth quarter of 2022 compared to fourth quarter 2021 operating income of $5.6 million. Distribution segment sales and operating income were both negatively impacted by weather, seasonality and margin compression from unfavorable pricing of commodity-based products sold through the business.

[0000038725-23-000002:8k_2_02:24]
Fueling Systems sales, a new fourth quarter record, were $85.5 million in the fourth quarter 2022, an increase of $6.5 million compared to the fourth quarter 2021. Fueling Systems sales increases in the U.S. and Canada were led by higher demand for Fuel Management Systems compared to the fourth quarter 2021.  Outside the U.S. and Canada, Fueling Systems revenues were flat.  Fueling Systems operating income, a new fourth quarter record, was $24.3 million in the fourth quarter of 2022, compared to $22.2 million in the fourth quarter 2021.

[0000038725-23-000002:8k_2_02:25]
Cash Flow

[0000038725-23-000002:8k_2_02:26]
Net cash flows from operating activities for 2022 were $101.7 million versus $129.8 million in the same period in 2021. The decrease was primarily due to higher working capital requirements in support of higher revenues.

[0000038725-23-000002:8k_2_02:27]
2023 Guidance

[0000038725-23-000002:8k_2_02:28]
The Company expects its full year 2023 sales to be in the range of $2.1 billion to $2.2 billion and full year 2023 EPS to be in the range of $4.10 to $4.30.

[0000038725-23-000002:8k_2_02:29]
Earnings Conference Call

[0000038725-23-000002:8k_2_02:30]
A conference call to review earnings and other developments in the business will commence at 9:00 am ET. The fourth quarter and fiscal year 2022 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-23-000002:8k_2_02:31]
https://edge.media-server.com/mmc/p/usehvppx

[0000038725-23-000002:8k_2_02:32]
For those interested in participating in the question-and-answer portion of the call, please register for the call at the link below.

[0000038725-23-000002:8k_2_02:33]
https://register.vevent.com/register/BI060baf2deda443b988b32fb943569249

[0000038725-23-000002:8k_2_02:34]
All registrants will receive dial-in information and a PIN allowing them to access the live call. It is recommended that you join 10 minutes prior to the event start (although you may register and dial in at any time during the call).

[0000038725-23-000002:8k_2_02:35]
A replay of the conference call will be available from Tuesday, February 14, 2023, through 9AM ET on Tuesday, February 21, 2023, by visiting the listen-only webcast link above.

[0000038725-23-000002:8k_2_02:36]
Forward Looking Statements

[0000038725-23-000002:8k_2_02:37]
About Franklin Electric

[0000038725-23-000002:8k_2_02:38]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-23-000002:8k_2_02:39]
Franklin Electric Contact:

[0000038725-23-000002:8k_2_02:40]
Jeffery L. Taylor

[0000038725-23-000002:8k_2_02:41]
Franklin Electric Co., Inc.

[0000038725-23-000002:8k_2_02:42]
260-824-2900

[0000038725-23-000002:8k_2_02:43]
Email: jeffery.taylor@fele.com

[0000038725-23-000002:8k_2_02:44]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Fourth Quarter Ended |  | Fiscal Year End |
|  | December 31, 2022 |  | December 31, 2021 |  | December 31, 2022 |  | December 31, 2021 |
| Net sales | $ | 489,431 |  |  | $ | 432,520 |  |  | $ | 2,043,711 |  |  | $ | 1,661,865 |  |
| Cost of sales | 323,213 |  |  | 287,332 |  |  | 1,352,276 |  |  | 1,085,776 |  |
| Gross profit | 166,218 |  |  | 145,188 |  |  | 691,435 |  |  | 576,089 |  |
| Selling, general, and administrative expenses | 109,724 |  |  | 97,741 |  |  | 432,076 |  |  | 386,275 |  |
| Restructuring expense | 272 |  |  | 240 |  |  | 2,170 |  |  | 621 |  |
| Operating income | 56,222 |  |  | 47,207 |  |  | 257,189 |  |  | 189,193 |  |
| Interest expense | (4,033) |  |  | (1,356) |  |  | (11,525) |  |  | (5,196) |  |
| Other income/(expense), net | (414) |  |  | 6,447 |  |  | (3,201) |  |  | 7,978 |  |
| Foreign exchange income/(expense) | (2,946) |  |  | (615) |  |  | (7,236) |  |  | (2,269) |  |
| Income before income taxes | 48,829 |  |  | 51,683 |  |  | 235,227 |  |  | 189,706 |  |
| Income tax expense | 8,872 |  |  | 10,688 |  |  | 46,416 |  |  | 34,731 |  |
| Net income | $ | 39,957 |  |  | $ | 40,995 |  |  | $ | 188,811 |  |  | $ | 154,975 |  |
| Less: Net (income)/loss attributable to noncontrolling interests | (378) |  |  | (328) |  |  | (1,479) |  |  | (1,115) |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 39,579 |  |  | $ | 40,667 |  |  | $ | 187,332 |  |  | $ | 153,860 |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.85 |  |  | $ | 0.87 |  |  | $ | 4.02 |  |  | $ | 3.29 |  |
| Diluted | $ | 0.84 |  |  | $ | 0.85 |  |  | $ | 3.97 |  |  | $ | 3.25 |  |

[0000038725-23-000002:8k_2_02:45]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | December 31, 2022 |  | December 31, 2021 |
| ASSETS |  |
| Cash and equivalents | $ | 45,790 |  |  | $ | 40,536 |  |
| Receivables (net) | 230,404 |  |  | 196,173 |  |
| Inventories | 544,980 |  |  | 449,975 |  |
| Other current assets | 36,916 |  |  | 37,963 |  |
| Total current assets | 858,090 |  |  | 724,647 |  |
| Property, plant, and equipment, net | 215,154 |  |  | 210,654 |  |
| Lease right-of-use assets, net | 48,948 |  |  | 48,379 |  |
| Goodwill and other assets | 572,009 |  |  | 591,485 |  |
| Total assets | $ | 1,694,201 |  |  | $ | 1,575,165 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 139,266 |  |  | $ | 164,758 |  |
| Accrued expenses and other current liabilities | 123,788 |  |  | 117,955 |  |
| Current lease liability | 15,959 |  |  | 15,320 |  |
| Current maturities of long-term debt and short-term borrowings | 126,756 |  |  | 97,981 |  |
| Total current liabilities | 405,769 |  |  | 396,014 |  |
| Long-term debt | 89,271 |  |  | 90,535 |  |
| Long-term lease liability | 32,858 |  |  | 32,937 |  |
| Income taxes payable non-current | 8,707 |  |  | 11,610 |  |
| Deferred income taxes | 29,744 |  |  | 28,162 |  |
| Employee benefit plans | 31,889 |  |  | 40,696 |  |
| Other long-term liabilities | 25,209 |  |  | 26,568 |  |
| Redeemable noncontrolling interest | 620 |  |  | (19) |  |
| Total equity | 1,070,134 |  |  | 948,662 |  |
| Total liabilities and equity | $ | 1,694,201 |  |  | $ | 1,575,165 |  |

[0000038725-23-000002:8k_2_02:46]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | 2022 |  | 2021 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 188,811 |  |  | $ | 154,975 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 50,374 |  |  | 44,572 |  |
| Non-cash lease expense | 17,406 |  |  | 13,808 |  |
| Share-based compensation | 10,973 |  |  | 11,731 |  |
| Gain from bargain purchase of business | — |  |  | (6,482) |  |
| Other | 7,291 |  |  | 2,126 |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (44,800) |  |  | (31,925) |  |
| Inventory | (101,080) |  |  | (123,076) |  |
| Accounts payable and accrued expenses | (12,283) |  |  | 89,038 |  |
| Operating leases | (17,406) |  |  | (13,808) |  |
| Income taxes-U.S. Tax Cuts and Jobs Act | (355) |  | — |
| Other | 2,743 |  |  | (11,196) |  |
| Net cash flows from operating activities | 101,674 |  |  | 129,763 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (41,903) |  |  | (30,116) |  |
| Proceeds from sale of property, plant, and equipment | 6 |  |  | 979 |  |
| Acquisitions and investments | (1,186) |  |  | (235,701) |  |
| Other investing activities | 9 |  |  | 33 |  |
| Net cash flows from investing activities | (43,074) |  |  | (264,805) |  |
| Cash flows from financing activities: |  |  |  |
| Net change in debt | 28,936 |  |  | 94,716 |  |
| Proceeds from issuance of common stock | 3,859 |  |  | 15,524 |  |
| Purchases of common stock | (40,490) |  |  | (25,949) |  |
| Dividends paid | (36,991) |  |  | (33,398) |  |
| Deferred payments for acquisitions | (3,786) |  |  | — |  |
| Net cash flows from financing activities | (48,472) |  |  | 50,893 |  |
| Effect of exchange rate changes on cash and equivalents | (4,874) |  |  | (6,102) |  |
| Net change in cash and equivalents | 5,254 |  |  | (90,251) |  |
| Cash and equivalents at beginning of period | 40,536 |  |  | 130,787 |  |
| Cash and equivalents at end of period | $ | 45,790 |  |  | $ | 40,536 |  |

[0000038725-23-000002:8k_2_02:47]
Key Performance Indicators: Earnings Per Share Calculations

[0000038725-23-000002:8k_2_02:48]
| Earnings Before and After Restructuring |  | For the Fourth Quarter |  |  |
| (in millions) |  | 2022 | 2021 | Change |  |  |  |  |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 39.6 |  | $ | 40.7 |  | (3) | % |  |  |  |  |
| Allocated Earnings |  | $ | (0.2) |  | $ | (0.2) |  |  |  |  |  |  |
| Earnings for EPS Calculations |  | $ | 39.4 |  | $ | 40.5 |  | (3) | % |  |  |  |  |
| Restructuring (before tax): |  | $ | 0.3 |  | $ | 0.2 |  |  |  |  |  |  |
| Restructuring, net of tax: |  | $ | 0.2 |  | $ | 0.2 |  |  |  |  |  |  |
| Earnings Before Restructuring |  | $ | 39.6 |  | $ | 40.7 |  | (3) | % |  |  |  |  |
| Earnings Per Share |  | For the Fourth Quarter |  |  |
| Before and After Restructuring |  | 2022 | 2021 | Change |  |  |  |  |
| (in millions except Earnings Per Share) |  |  |  |  |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 47.0 |  | 47.0 |  | — | % |  |  |  |  |
| Fully Diluted Earnings Per Share (“EPS”) Reported |  | $ | 0.84 |  | $ | 0.85 |  | (1) | % |  |  |  |  |
| Restructuring Per Share, net of tax |  | $ | — |  | $ | 0.01 |  |  |  |  |  |  |
| Fully Diluted EPS Before Restructuring |  | $ | 0.84 |  | $ | 0.86 |  | (2) | % |  |  |  |  |

[0000038725-23-000002:8k_2_02:49]
| Earnings Before and After Restructuring |  | For the Full Year of |  |  |
| (in millions) |  | 2022 | 2021 | Change |  |  |  |  |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 187.3 |  | $ | 153.9 |  | 22 | % |  |  |  |  |
| Allocated Earnings |  | $ | (0.7) |  | $ | (0.9) |  |  |  |  |  |  |
| Earnings for EPS Calculations |  | $ | 186.6 |  | $ | 153.0 |  | 22 | % |  |  |  |  |
| Restructuring (before tax): |  | $ | 2.2 |  | $ | 0.6 |  |  |  |  |  |  |
| Restructuring, net of tax: |  | $ | 1.8 |  | $ | 0.5 |  |  |  |  |  |  |
| Earnings Before Restructuring |  | $ | 188.4 |  | $ | 153.5 |  | 23 | % |  |  |  |  |
| Earnings Per Share |  | For the Full Year of |  |  |
| Before and After Restructuring |  | 2022 | 2021 | Change |  |  |  |  |
| (in millions except Earnings Per Share) |  |  |  |  |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 47.0 |  | 47.0 |  | — | % |  |  |  |  |
| Fully Diluted Earnings Per Share (“EPS”) Reported |  | $ | 3.97 |  | $ | 3.25 |  | 22 | % |  |  |  |  |
| Restructuring Per Share, net of tax |  | $ | 0.03 |  | $ | 0.01 |  |  |  |  |  |  |
| Fully Diluted EPS Before Restructuring |  | $ | 4.00 |  | $ | 3.26 |  | 23 | % |  |  |  |  |

[0000038725-23-000002:8k_2_02:50]
Key Performance Indicators: Net Sales Summary

[0000038725-23-000002:8k_2_02:51]
|  | Net Sales For the Fourth Quarter |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q4 2021 | $ | 148.9 |  | $ | 36.6 |  | $ | 47.3 |  | $ | 25.2 |  | $ | 258.0 |  | $ | 79.0 |  | $ | 116.9 |  | $ | (21.4) |  | $ | 432.5 |  |
| Q4 2022 | $ | 171.0 |  | $ | 38.4 |  | $ | 46.0 |  | $ | 25.9 |  | $ | 281.3 |  | $ | 85.5 |  | $ | 148.9 |  | $ | (26.3) |  | $ | 489.4 |  |
| Change | $ | 22.1 |  | $ | 1.8 |  | $ | (1.3) |  | $ | 0.7 |  | $ | 23.3 |  | $ | 6.5 |  | $ | 32.0 |  | $ | (4.9) |  | $ | 56.9 |  |
| % Change | 15 | % | 5 | % | (3) | % | 3 | % | 9 | % | 8 | % | 27 | % |  | 13 | % |
| Foreign currency translation | $ | (1.4) |  | $ | (2.8) |  | $ | (12.2) |  | $ | (1.8) |  | $ | (18.2) |  | $ | (1.5) |  | $ | — |  |  |  |
| % Change | (1) | % | (8) | % | (26) | % | (7) | % | (7) | % | (2) | % | — | % |  |  |
| Acquisitions | $ | 3.5 |  | $ | — |  | $ | — |  | $ | — |  | $ | 3.5 |  | $ | — |  | $ | 17.5 |  |  |  |
| Volume/Price | $ | 20.0 |  | $ | 4.6 |  | $ | 10.9 |  | $ | 2.5 |  | $ | 38.0 |  | $ | 8.0 |  | $ | 14.5 |  |  |  |
| % Change | 13 | % | 13 | % | 23 | % | 10 | % | 15 | % | 10 | % | 12 | % |  |  |

[0000038725-23-000002:8k_2_02:52]
|  | Net Sales For the Full Year |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| FY 2021 | $ | 549.2 |  | $ | 139.5 |  | $ | 189.8 |  | $ | 85.1 |  | $ | 963.6 |  | $ | 289.1 |  | $ | 497.6 |  | $ | (88.4) |  | $ | 1,661.9 |  |
| FY 2022 | $ | 712.9 |  | $ | 159.3 |  | $ | 192.8 |  | $ | 92.5 |  | $ | 1,157.5 |  | $ | 334.1 |  | $ | 668.1 |  | $ | (116.0) |  | $ | 2,043.7 |  |
| Change | $ | 163.7 |  | $ | 19.8 |  | $ | 3.0 |  | $ | 7.4 |  | $ | 193.9 |  | $ | 45.0 |  | $ | 170.5 |  | $ | (27.6) |  | $ | 381.8 |  |
| % Change | 30 | % | 14 | % | 2 | % | 9 | % | 20 | % | 16 | % | 34 | % |  | 23 | % |
| Foreign currency translation | $ | (3.0) |  | $ | (5.7) |  | $ | (58.3) |  | $ | (4.7) |  | $ | (71.7) |  | $ | (5.4) |  | $ | — |  |  |  |
| % Change | (1) | % | (4) | % | (31) | % | (6) | % | (7) | % | (2) | % | — | % |  |  |
| Acquisitions | $ | 54.1 |  | $ | — |  | $ | — |  | $ | 4.7 |  | $ | 58.8 |  | $ | — |  | $ | 73.1 |  |  |  |
| Volume/Price | $ | 112.6 |  | $ | 25.5 |  | $ | 61.3 |  | $ | 7.4 |  | $ | 206.8 |  | $ | 50.4 |  | $ | 97.4 |  |  |  |
| % Change | 21 | % | 18 | % | 32 | % | 9 | % | 21 | % | 17 | % | 20 | % |  |  |

[0000038725-23-000002:8k_2_02:53]
Key Performance Indicators: Operating Income and Margin Summary

[0000038725-23-000002:8k_2_02:54]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Fourth Quarter 2022 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 44.6 |  | $ | 24.3 |  | $ | 2.9 |  | $ | (15.6) |  | $ | 56.2 |  |
| % Operating Income To Net Sales | 15.9 | % | 28.4 | % | 1.9 | % |  | 11.5 | % |
| Restructuring | $ | 0.2 |  | $ | 0.1 |  | $ | — |  | $ | — |  | $ | 0.3 |  |
| Operating Income/(Loss) Before Restructuring | $ | 44.8 |  | $ | 24.4 |  | $ | 2.9 |  | $ | (15.6) |  | $ | 56.5 |  |
| % Operating Income to Net Sales Before Restructuring | 15.9 | % | 28.5 | % | 1.9 | % |  | 11.5 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Fourth Quarter 2021 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 36.4 |  | $ | 22.2 |  | $ | 5.6 |  | $ | (17.0) |  | $ | 47.2 |  |
| % Operating Income To Net Sales | 14.1 | % | 28.1 | % | 4.8 | % |  | 10.9 | % |
| Restructuring | $ | 0.2 |  | $ | — |  | $ | — |  | $ | — |  | $ | 0.2 |  |
| Operating Income/(Loss) Before Restructuring | $ | 36.6 |  | $ | 22.2 |  | $ | 5.6 |  | $ | (17.0) |  | $ | 47.4 |  |
| % Operating Income to Net Sales Before Restructuring | 14.2 | % | 28.1 | % | 4.8 | % |  | 11.0 | % |

[0000038725-23-000002:8k_2_02:55]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Full Year 2022 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 172.3 |  | $ | 96.8 |  | $ | 54.5 |  | $ | (66.4) |  | $ | 257.2 |  |
| % Operating Income To Net Sales | 14.9 | % | 29.0 | % | 8.2 | % |  | 12.6 | % |
| Restructuring | $ | 1.3 |  | $ | 0.7 |  | $ | 0.2 |  | $ | — |  | $ | 2.2 |  |
| Operating Income/(Loss) Before Restructuring | $ | 173.6 |  | $ | 97.5 |  | $ | 54.7 |  | $ | (66.4) |  | $ | 259.4 |  |
| % Operating Income to Net Sales Before Restructuring | 15.0 | % | 29.2 | % | 8.2 | % |  | 12.7 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Full Year 2021 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 139.1 |  | $ | 79.5 |  | $ | 35.9 |  | $ | (65.3) |  | $ | 189.2 |  |
| % Operating Income To Net Sales | 14.4 | % | 27.5 | % | 7.2 | % |  | 11.4 | % |
| Restructuring | $ | 0.5 |  | $ | — |  | $ | 0.1 |  | $ | — |  | $ | 0.6 |  |
| Operating Income/(Loss) Before Restructuring | $ | 139.6 |  | $ | 79.5 |  | $ | 36.0 |  | $ | (65.3) |  | $ | 189.8 |  |
| % Operating Income to Net Sales Before Restructuring | 14.5 | % | 27.5 | % | 7.2 | % |  | 11.4 | % |
