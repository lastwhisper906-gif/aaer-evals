# FELE MD&A — 0000038725-23-000035


## mdna

[0000038725-23-000035:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000038725-23-000035:mdna:2]
Discussion of the year-over-year comparison of changes in the Company's financial condition and results of operation as of and for the fiscal years ended December 31, 2021 and December 31, 2020 can be found in Part II, Item 7. "Management’s Discussion and Analysis of Financial Condition and Results of Operations" of our Annual Report on Form 10-K for the fiscal year ended December 31, 2021.

[0000038725-23-000035:mdna:3]
2022 vs. 2021

[0000038725-23-000035:mdna:4]
OVERVIEW

[0000038725-23-000035:mdna:5]
Net sales in 2022 increased 23 percent compared to the prior year. The sales increase was primarily due to price and acquisitions. The impact of foreign currency translation decreased sales by about 5 percent. The Company's consolidated gross profit was $691.4 million for 2022, an increase of $115.3 million, or about 20 percent, from 2021.  Net income attributable to the Company was $187.3 million, an increase of $33.5 million, or about 22 percent, from 2021.

[0000038725-23-000035:mdna:6]
RESULTS OF OPERATIONS

[0000038725-23-000035:mdna:7]
Net Sales

[0000038725-23-000035:mdna:8]
Net sales in 2022 were $2,043.7 million, an increase of $381.8 million, or about 23 percent, compared to 2021 sales of $1,661.9 million. The incremental impact to sales from acquired businesses was $131.9 million. Sales decreased by $77.1 million, or about 5 percent, in 2022 due to foreign currency translation.

[0000038725-23-000035:mdna:9]
|  | Net Sales |
| (In millions) | 2022 |  | 2021 |  | 2022 v 2021 |
| Water Systems | $ | 1,157.5 |  |  | $ | 963.6 |  |  | $ | 193.9 |  |
| Fueling Systems | 334.1 |  |  | 289.1 |  |  | 45.0 |  |
| Distribution | 668.1 |  |  | 497.6 |  |  | 170.5 |  |
| Eliminations/Other | (116.0) |  |  | (88.4) |  |  | (27.6) |  |
| Consolidated | $ | 2,043.7 |  |  | $ | 1,661.9 |  |  | $ | 381.8 |  |

[0000038725-23-000035:mdna:10]
Net Sales-Water Systems

[0000038725-23-000035:mdna:11]
Water Systems sales were $1,157.5 million in 2022, an increase of $193.9 million, or about 20 percent, versus 2021. The incremental impact to sales from acquired businesses was $58.8 million. Foreign currency translation changes decreased sales $71.7 million, or about 7 percent, compared to 2021.

[0000038725-23-000035:mdna:12]
Water Systems sales in the U.S. and Canada increased by about 30 percent compared to 2021. The incremental impact to sales from acquired businesses was $54.1 million. Sales decreased by $3.0 million in 2022 due to foreign currency translation. In 2022, sales of groundwater pumping equipment increased by about 22 percent and sales of all surface pumping equipment increased by about 23 percent versus 2021, due to strong end market demand and pricing.

[0000038725-23-000035:mdna:13]
Water Systems sales in markets outside the U.S. and Canada increased by about 7 percent compared to 2021. The incremental impact to sales from acquired businesses was $4.7 million. Sales decreased by $68.7 million, or 17 percent, in 2022 due to foreign currency translation. Excluding the impact of acquisitions and foreign currency translation, sales increased in all major markets; EMEA, Latin America, and Asia Pacific.

[0000038725-23-000035:mdna:14]
Net Sales-Fueling Systems

[0000038725-23-000035:mdna:15]
Fueling Systems sales were $334.1 million in 2022, an increase of $45.0 million, or about 16 percent, from 2021. Foreign currency translation changes decreased sales $5.4 million, or about 2 percent, compared to 2021.

[0000038725-23-000035:mdna:16]
Fueling Systems sales in the U.S. and Canada increased by about 22 percent during 2022, primarily due to pricing actions and higher demand across all product lines. Outside the U.S. and Canada, Fueling Systems sales increased with sales growth in India more than offsetting lower sales in China. China sales were about $7 million in 2022 compared to about $12 million in 2021.

[0000038725-23-000035:mdna:17]
Net Sales-Distribution

[0000038725-23-000035:mdna:18]
Distribution sales were $668.1 million in 2022, an increase of $170.5 million, or about 34 percent, from 2021.  The incremental impact to sales from acquired businesses was $73.1 million. Sales growth was driven by acquisitions, pricing and broad-based demand in all regions and product categories.

[0000038725-23-000035:mdna:19]
Cost of Sales

[0000038725-23-000035:mdna:20]
Cost of sales as a percent of net sales for 2022 and 2021 was 66.2 percent and 65.3 percent, respectively. Correspondingly, the gross profit margin was 33.8 percent and 34.7 percent, respectively. The gross profit margin decline was primarily a result of supply disruptions causing unfavorable absorption variances and higher inbound freight that was partially offset by realized pricing actions that more than offset inflationary cost increases. The Company's consolidated gross profit was $691.4 million for 2022, up $115.3 million from the gross profit of $576.1 million in 2021. The gross profit increase was primarily due to higher sales.

[0000038725-23-000035:mdna:21]
Selling, General and Administrative (“SG&A”)

[0000038725-23-000035:mdna:22]
SG&A expenses were $432.1 million in 2022 and increased $45.8 million compared to $386.3 million in the prior year. The increase was primarily due to incremental expenses from acquired businesses of $31 million. Additionally, higher travel and advertising expenses were partially offset by lower variable performance-based compensation expenses. SG&A costs as a percent of net sales decreased to 21.1 percent in 2022 from 23.2 percent in 2021.

[0000038725-23-000035:mdna:23]
Restructuring Expenses

[0000038725-23-000035:mdna:24]
Restructuring expenses were $2.2 million and $0.6 million in 2022 and 2021, respectively. Restructuring expenses were primarily from continued miscellaneous manufacturing realignment activities and branch closings and consolidations in the Distribution and Water Systems segments.

[0000038725-23-000035:mdna:25]
Operating Income

[0000038725-23-000035:mdna:26]
Operating income was $257.2 million in 2022, up $68.0 million, or 36 percent, from $189.2 million in 2021.

[0000038725-23-000035:mdna:27]
|  |  | Operating income (loss) |
| (In millions) |  | 2022 |  | 2021 |  | 2022 v 2021 |
| Water Systems |  | $ | 172.3 |  |  | $ | 139.1 |  |  | $ | 33.2 |  |
| Fueling Systems |  | 96.8 |  |  | 79.5 |  |  | 17.3 |  |
| Distribution |  | 54.5 |  |  | 35.9 |  |  | 18.6 |  |
| Eliminations/Other |  | (66.4) |  |  | (65.3) |  |  | (1.1) |  |
| Consolidated |  | $ | 257.2 |  |  | $ | 189.2 |  |  | $ | 68.0 |  |

[0000038725-23-000035:mdna:28]
Operating Income-Water Systems

[0000038725-23-000035:mdna:29]
Water Systems operating income was $172.3 million in 2022 compared to $139.1 million in 2021, an increase of 24 percent. Operating income increased in Water Systems primarily due to higher sales volumes and SG&A cost controls. The 2022 operating income margin was 14.9 percent compared to 2021 operating income margin of 14.4 percent of net sales. Operating income margin increased in Water Systems primarily due to operating leverage on higher sales.

[0000038725-23-000035:mdna:30]
Operating Income-Fueling Systems

[0000038725-23-000035:mdna:31]
Fueling Systems operating income was $96.8 million in 2022 compared to $79.5 million in 2021, an increase of 22 percent. Operating income increased in Fueling Systems primarily due to higher sales volumes. The 2022 operating income margin was 29.0 percent compared to 27.5 percent of net sales in 2021. Operating income margin increased in Fueling Systems primarily due to operating leverage on higher sales.

[0000038725-23-000035:mdna:32]
Operating Income-Distribution

[0000038725-23-000035:mdna:33]
Distribution operating income was $54.5 million in 2022 compared to $35.9 million in 2021, an increase of 52 percent. Operating income increased in Distribution due to higher sales volumes. The 2022 operating income margin was 8.2 percent compared to 7.2 percent of net sales in 2021. The increase in operating income margin was primarily due to sales growth and operating leverage.

[0000038725-23-000035:mdna:34]
Operating Income-Eliminations/Other

[0000038725-23-000035:mdna:35]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses. The inter-segment profit elimination impact in 2022 decreased operating income by about $3.0 million more compared to 2021. The inter-segment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until the transferred product is sold from the Distribution segment to its third-party customer. Additionally, unallocated general and administrative expenses decreased $1.9 million compared to last year.

[0000038725-23-000035:mdna:36]
Interest Expense

[0000038725-23-000035:mdna:37]
Interest expense increased in 2022 to $11.5 million from $5.2 million in 2021 primarily due to higher outstanding debt levels and higher interest rates.

[0000038725-23-000035:mdna:38]
Other Income or Expense

[0000038725-23-000035:mdna:39]
Other income or expense was a loss of $3.2 million in 2022 compared to income of $8.0 million in 2021. Included in other income or expense in 2022 was a loss of $2.1 million related to a settlement of an indirect tax dispute. Other income or expense in 2021 included a bargain purchase gain of $6.5 million and a gain of $2.5 million related to a settlement of an indirect tax dispute.

[0000038725-23-000035:mdna:40]
Foreign Exchange

[0000038725-23-000035:mdna:41]
Foreign exchange was a loss of $7.2 million and $2.3 million in 2022 and 2021, respectively.  The increase in 2022 was primarily due to transaction losses associated with the Argentine Peso and Turkish Lira. The Company reports the results of its subsidiaries in Argentina and Turkey using highly inflationary accounting, which requires that the functional currency of the entity be changed to the reporting currency of its parent.

[0000038725-23-000035:mdna:42]
Income Taxes

[0000038725-23-000035:mdna:43]
The provision for income taxes in 2022 and 2021 was $46.4 million and $34.7 million, respectively. The effective tax rate for 2022 both before and after the impact of discrete events was about 20 percent. The effective tax rate for 2021 was about 18 percent and, before the impact of discrete events, was about 21 percent. The tax rate was lower than the statutory rate of 21 percent primarily due to the recognition of the U.S. deduction for Foreign Derived Intangible Income, certain incentives, and discrete events. The increase in the effective tax rate in 2022 was primarily a result of smaller net favorable discrete events recorded in 2022 compared to 2021, primarily related to excess tax benefits from share-based compensation.

[0000038725-23-000035:mdna:44]
Net Income

[0000038725-23-000035:mdna:45]
Net income for 2022 was $188.8 million compared to 2021 net income of $155.0 million. Net income attributable to Franklin Electric Co., Inc. for 2022 was $187.3 million, or $3.97 per diluted share, compared to 2021 net income attributable to Franklin Electric Co., Inc. of $153.9 million, or $3.25 per diluted share.

[0000038725-23-000035:mdna:46]
CAPITAL RESOURCES AND LIQUIDITY

[0000038725-23-000035:mdna:47]
Sources of Liquidity

[0000038725-23-000035:mdna:48]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at December 31, 2022 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-23-000035:mdna:49]
As of December 31, 2022, the Company had a $350.0 million revolving credit facility. The facility is scheduled to mature on May 13, 2026. As of December 31, 2022, the Company had $223.2 million borrowing capacity under the Credit Agreement as $4.0 million in letters of commercial and standby letters of credit were outstanding and undrawn and $122.8 million in revolver borrowings were drawn and outstanding, which were primarily used for funding working capital requirements.

[0000038725-23-000035:mdna:50]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement") with a remaining borrowing capacity of $125.0 million as of December 31, 2022. The New York Life Agreement matures on July 30, 2024. The Company also has other long-term debt borrowings outstanding as of December 31, 2022. See Note 10 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-23-000035:mdna:51]
At December 31, 2022, the Company had $43.4 million of cash and cash equivalents held in foreign jurisdictions, which the Company intends to use to fund foreign operations. There is currently no need to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-23-000035:mdna:52]
Cash Flows

[0000038725-23-000035:mdna:53]
The following table summarizes significant sources and uses of cash and cash equivalents:

[0000038725-23-000035:mdna:54]
| (in thousands) | 2022 |  | 2021 |
| Cash flows from operating activities | $ | 101.7 |  |  | $ | 129.8 |  |
| Cash flows from investing activities | $ | (43.1) |  |  | $ | (264.8) |  |
| Cash flows from financing activities | $ | (48.5) |  |  | $ | 50.9 |  |
| Impact of exchange rates on cash and cash equivalents | $ | (4.9) |  |  | $ | (6.1) |  |
| Change in cash and cash equivalents | $ | 5.2 |  |  | $ | (90.2) |  |

[0000038725-23-000035:mdna:55]
Cash Flows from Operating Activities

[0000038725-23-000035:mdna:56]
2022 vs 2021

[0000038725-23-000035:mdna:57]
Net cash provided by operating activities was $101.7 million for 2022 compared to $129.8 million for 2021. The decrease in cash provided by operating activities was primarily due to increased working capital requirements in support of higher revenues.

[0000038725-23-000035:mdna:58]
Cash Flows from Investing Activities

[0000038725-23-000035:mdna:59]
2022 vs. 2021

[0000038725-23-000035:mdna:60]
Net cash used in investing activities was $43.1 million in 2022 compared to $264.8 million in 2021. The decrease was primarily attributable to decreased acquisition activity in 2022.

[0000038725-23-000035:mdna:61]
Cash Flows from Financing Activities

[0000038725-23-000035:mdna:62]
2022 vs. 2021

[0000038725-23-000035:mdna:63]
Net cash used by financing activities was $48.5 million in 2022 compared to $50.9 million provided by financing activities in 2021. The change in financing cash flows was attributable to decreased net proceeds from debt and common stock issuances, increased stock repurchases, higher dividend payments and deferred payments related to acquisitions.

[0000038725-23-000035:mdna:64]
AGGREGATE CONTRACTUAL OBLIGATIONS

[0000038725-23-000035:mdna:65]
The majority of the Company’s contractual obligations to third parties relate to debt obligations. In addition, the Company has certain contractual obligations for future lease payments and purchase obligations. The payment schedule for these contractual obligations is as follows:

[0000038725-23-000035:mdna:66]
| (In millions) |  |  |  |  |  |  |  |  | More than |
|  | Total |  | 2023 |  | 2024-2025 |  | 2026-2027 |  | 5 years |
| Debt | $ | 216.2 |  |  | $ | 126.8 |  |  | $ | 77.8 |  |  | $ | 2.9 |  |  | $ | 8.7 |  |
| Debt interest | 19.9 |  |  | 9.4 |  |  | 8.2 |  |  | 1.3 |  |  | 1.0 |  |
| Operating leases | 52.9 |  |  | 17.1 |  |  | 20.5 |  |  | 10.6 |  |  | 4.7 |  |
| Purchase obligations | 12.8 |  |  | 12.8 |  |  | — |  |  | — |  |  | — |  |
| Income Taxes-U.S. Tax Cuts and Jobs Act transition tax | $ | 11.6 |  |  | $ | 2.9 |  |  | $ | 8.7 |  |  | $ | — |  |  | $ | — |  |
|  | $ | 313.4 |  |  | $ | 169.0 |  |  | $ | 115.2 |  |  | $ | 14.8 |  |  | $ | 14.4 |  |

[0000038725-23-000035:mdna:67]
Interest payments on debt obligations are calculated for future periods using interest rates in effect at the end of 2022. Certain of these projected interest payments may differ in the future based on interest rates or other factors or events. The projected interest payments only pertain to obligations and agreements outstanding at December 31, 2022.

[0000038725-23-000035:mdna:68]
The Company has pension and other post-retirement benefit obligations not included in the table above which will result in estimated future payments of approximately $0.8 million in 2023. In addition, due to the timing of funding in future periods being uncertain and dependent on future movements in interest rates, investment returns, changes in laws and regulations and other variables, the table above excludes the non-current liability of $24.9 million for cash outflows related to the Company's pension plans.

[0000038725-23-000035:mdna:69]
The Company also has unrecognized tax benefits, none of which are included in the table above. The unrecognized tax benefits of approximately $0.9 million have been recorded as liabilities and the Company is uncertain as to if or when such amounts may be settled. Related to the unrecognized tax benefits, the Company has also recorded a liability for potential penalties and interest of $0.2 million.

[0000038725-23-000035:mdna:70]
ACCOUNTING PRONOUNCEMENTS

[0000038725-23-000035:mdna:71]
For information regarding recent accounting pronouncements, refer to Note 2 - Accounting Pronouncements, in the Notes to Consolidated Financial Statements in the sections entitled ""Adoption of New Accounting Standards" and "Accounting Standards Issued But Not Yet Adopted", included in Part II, Item 8, "Financial Statements and Supplementary Data" of this Annual Report on Form 10-K.

[0000038725-23-000035:mdna:72]
CRITICAL ACCOUNTING ESTIMATES

[0000038725-23-000035:mdna:73]
Management’s discussion and analysis of its financial condition and results of operations are based upon the Company’s consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires management to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and the related disclosure of contingent assets and liabilities. Management evaluates estimates on an ongoing basis. Estimates are based on historical experience and on other

[0000038725-23-000035:mdna:74]
assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying value of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. There were no material changes to estimates or methodologies used to develop those estimates in 2022. The Company’s critical accounting estimates are identified below:

[0000038725-23-000035:mdna:75]
Inventory Valuation

[0000038725-23-000035:mdna:76]
The Company uses certain estimates and judgments to value inventory. Inventory is recorded at the lower of cost or net realizable value. The Company reviews its inventories for excess or obsolete products or components. Based on an analysis of historical usage, management’s evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts, carrying values are adjusted. The carrying value is reduced regularly to reflect the age and current anticipated product demand. If actual demand differs from the estimates, additional reductions would be necessary in the period such determination is made. Excess and obsolete inventory is periodically disposed of through sale to third parties, scrapping, or other means.

[0000038725-23-000035:mdna:77]
Business Combinations and Valuation of Acquired Intangible Assets

[0000038725-23-000035:mdna:78]
The Company follows the guidance under FASB ASC Topic 805, Business Combinations. The acquisition purchase price is allocated to the assets acquired and liabilities assumed based upon their respective fair values. The Company utilizes management estimates and an independent third-party valuation firm to assist in determining the fair values of assets acquired, including intangible assets, and liabilities assumed. The identifiable intangible assets acquired typically include customer relationships and trade names. Identifiable intangible assets are initially valued using a methodology commensurate with the intended use of the asset. The fair value of customer relationships is measured using the multi-period excess earnings method ("MPEEM"). The fair value of trade names is measured using a relief-from-royalty ("RFR") approach, which assumes the value of the trade name is the discounted amount of cash flows that would be paid to third parties had the Company not owned the trade name and instead licensed the trade name from another company. Higher royalty rates are assigned to premium brands within the marketplace based on name recognition and profitability, while other brands receive lower royalty rates. The basis for future sales projections for both the RFR and MPEEM are based on internal revenue forecasts which the Company believes represents reasonable market participant assumptions. The future cash flows are discounted using an applicable discount rate as well as any potential risk premium to reflect the inherent risk of holding a standalone intangible asset.  The key uncertainties in the RFR and MPEEM calculations, as applicable, are the selection of an appropriate royalty rate, assumptions used in developing estimates of future cash flows, including revenue growth and expense forecasts, assumed customer attrition rates, as well as the perceived risk associated with those forecasts in determining the discount rate and risk premium.  There is inherent uncertainty in forecasted future cash flows and therefore, actual results may differ and could result in subsequent impairment charges of acquired intangibles and/or goodwill.

[0000038725-23-000035:mdna:79]
Indefinite-Lived Intangible Asset and Goodwill Impairment Evaluation

[0000038725-23-000035:mdna:80]
According to FASB ASC Topic 350, Intangibles - Goodwill and Other, intangible assets with indefinite lives must be tested for impairment at least annually or more frequently as warranted by triggering events that indicate potential impairment. The Company uses a variety of methodologies in conducting impairment assessments including income and market approaches. For indefinite-lived assets apart from goodwill, primarily trade names for the Company, if the fair value is less than the carrying amount, an impairment charge is recognized in an amount equal to that excess. The Company has not made any material changes to the method of evaluating impairments during the last three years.

[0000038725-23-000035:mdna:81]
In compliance with FASB ASC Topic 350, goodwill is not amortized. Goodwill is tested at the reporting unit level for impairment annually or more frequently as warranted by triggering events that indicate potential impairment. Reporting units are operating segments or one level below, known as components, which can be aggregated for testing purposes. The Company’s goodwill is allocated to the Global Water Systems, Fueling Systems and Distribution reporting units. As the Company’s business model evolves, management will continue to evaluate its reporting units and review the aggregation criteria.

[0000038725-23-000035:mdna:82]
In assessing the recoverability of goodwill, the Company determines the fair value of its reporting units by utilizing a combination of both the market value and income approaches. The market value approach compares the reporting units’ current and projected financial results to entities of similar size and industry to determine the market value of the reporting unit. The income approach utilizes assumptions regarding estimated future cash flows and other factors to determine the fair value of the respective assets. These cash flows consider factors regarding expected future operating income and historical trends, as well as the effects of demand and competition. The Company is required to record an impairment if these assumptions and estimates change whereby the fair value of the reporting units is below their associated carrying values. Goodwill included on the balance sheet as of the year ended December 31, 2022 was $328.0 million.

[0000038725-23-000035:mdna:83]
During the fourth quarter of 2022, the Company completed its annual impairment test of goodwill and indefinite-lived trade names and determined the fair value of all intangibles were substantially in excess of the respective carrying values. Significant judgment is required to determine if an indication of impairment has taken place. Factors to be considered include the following: adverse changes in operating results, decline in strategic business plans, significantly lower future cash flows, and sustainable declines in market data such as market capitalization. A 10 percent decrease in the fair value estimates used in the impairment tests would not have changed this determination. The sensitivity analysis required the use of numerous subjective assumptions, which, if actual experience varies, could result in material differences in the requirements for impairment charges. Further, an extended downturn in the economy may impact certain components of the operating segments more significantly and could result in changes to the aggregation assumptions and impairment determination.

[0000038725-23-000035:mdna:84]
Income Taxes

[0000038725-23-000035:mdna:85]
Under the requirements of FASB ASC Topic 740, Income Taxes, the Company records deferred tax assets and liabilities for the future tax consequences attributable to differences between financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company analyzes the deferred tax assets and liabilities for their future realization based on the estimated existence of sufficient taxable income. This analysis considers the following sources of taxable income: prior year taxable income, future reversals of existing taxable temporary differences, future taxable income exclusive of reversing temporary differences and tax planning strategies that would generate taxable income in the relevant period. If sufficient taxable income is not projected then the Company will record a valuation allowance against the relevant deferred tax assets.

[0000038725-23-000035:mdna:86]
The Company’s operations involve dealing with uncertainties and judgments in the application of complex tax regulations in multiple jurisdictions. These jurisdictions have different tax rates, and the Company determines the allocation of income to each of these jurisdictions based upon various estimates and assumptions. In the normal course of business, the Company will undergo tax audits by various tax jurisdictions. Such audits often require an extended period of time to complete and may result in income tax adjustments if changes to the allocation are required between jurisdictions with different tax rates. The final taxes paid are dependent upon many factors, including negotiations with taxing authorities in the various jurisdictions and resolution of disputes arising from federal, state, and international tax audits. Although the Company has recorded all income tax uncertainties in accordance with FASB ASC Topic 740, these accruals represent estimates that are subject to the inherent uncertainties associated with the tax audit process. Management judgment is required in determining the Company’s provision for income taxes, deferred tax assets and liabilities, which, if actual experience varies, could result in material adjustments to tax expense and/or deferred tax assets and liabilities.

[0000038725-23-000035:mdna:87]
Pension and Employee Benefit Obligations

[0000038725-23-000035:mdna:88]
The Company consults with its actuaries to assist with the calculation of discount rates used in its pension and post retirement plans. The discount rates used to determine domestic pension and post-retirement plan liabilities are calculated using a full yield curve approach. Market conditions have caused the weighted-average discount rate to move from 2.68 percent last year to 5.15 percent this year for the domestic pension plans and from 2.57 percent last year to 5.08 percent this year for the postretirement health and life insurance plan. A change in the discount rate selected by the Company of 25 basis points would result in a change of about $0.1 million to employee benefit expense and a change of about $3.7 million of liability.

[0000038725-23-000035:mdna:89]
The Company consults with actuaries and investment advisors in making its determination of the expected long-term rate of return on plan assets. Using input from these consultations such as long-term investment sector expected returns, the correlations and standard deviations thereof, and the plan asset allocation, the Company will use an expected long-term rate of return on plan assets of 5.70 percent in measuring net periodic cost for 2023. Market conditions have caused the expected long-term rate or return to increase from 4.50 percent as used in measuring net periodic cost for 2022. A change in the long-term rate of return selected by the Company of 25 basis points would result in a change of about $0.3 million of employee benefit expense.

[0000038725-23-000035:mdna:90]
FACTORS THAT MAY AFFECT FUTURE RESULTS

[0000038725-23-000035:mdna:91]
various factors, including general economic and currency conditions, various conditions specific to the Company’s business and industry, new housing starts, weather conditions, epidemics and pandemics, market demand, competitive factors, changes in distribution channels, supply constraints, effect of price increases, raw material costs, technology factors, integration of acquisitions, litigation, government and regulatory actions, the Company’s accounting policies, and other risks, all as described in Item 1A and Exhibit 99.1 of this Form 10-K. Any forward-looking statements included in this Form 10-K are based upon information presently available. The Company does not assume any obligation to update any forward-looking information, except as required by law.
