# FELE note change history — 0000038725-14-000108 → 0000038725-14-000166


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-08-07):
[0000038725-14-000166:note_history:1]
On July 25, 2013, the Court issued a Final Statement of Decision (“Decision”) in the CARB Case.  In its Decision, the Court found on behalf of the Company and issued a complete defense verdict.  Judgment was entered on August 27, 2013.  An Amended Judgment awarding the Company $0.1 million in costs was entered by the Court on January 22, 2014.  On July 16, 2014, CARB appealed and filed its brief in support of the appeal. The Company has until September 29, 2014 to file its response brief.  If a hearing is held on the appeal it will likely occur sometime late in the fourth quarter 2014 or early first quarter 2015.
  (was, 2014-05-08, similarity 0.7195):
[0000038725-14-000108:note_history:1]
On July 25, 2013, the Court issued a Final Statement of Decision (“Decision”) in the CARB Case.  In its Decision, the Court found on behalf of the Company and issued a complete defense verdict.  Judgment was entered on August 27, 2013.  An Amended Judgment awarding the Company $0.1 million in costs was entered by the Court on January 22, 2014.  CARB has filed a notice of appeal.

- changed (2014-08-07):
[0000038725-14-000166:note_history:2]
At June 28, 2014, the Company had $12.3 million of commitments primarily for the purchase of raw materials to be used in production.
  (was, 2014-05-08, similarity 0.6936):
[0000038725-14-000108:note_history:2]
At March 29, 2014, the Company had $18.5 million of commitments primarily for the purchase of machinery and equipment as well as conditional agreements related to building expansions.

- added (2014-08-07):
[0000038725-14-000166:note_history:3]
The company provides warranties on most of its products.  The warranty terms vary but are generally 2 years from date of manufacture or 1 year from date of installation.  In 2007, the Company began offering an extended warranty program to certain Water Systems customers which provides warranty coverage up to 5 years from date of manufacture.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

- changed (2014-08-07):
[0000038725-14-000166:note_history:4]
The changes in the carrying amount of the warranty accrual, as recorded in "Accrued expenses" in the Company's condensed consolidated balance sheet for the six months ended June 28, 2014, are as follows:
  (was, 2014-05-08, similarity 0.9302):
[0000038725-14-000108:note_history:4]
The changes in the carrying amount of the warranty accrual, as recorded in "Accrued expenses" in the Company's consolidated balance sheet for the three months ended March 29, 2014, are as follows:

- changed (2014-08-07):
[0000038725-14-000166:note_history:5]
| (In millions) |  |  |
| Balance as of December 28, 2013 |  | $ | 9.5 |  |
| Accruals related to product warranties |  | 3.4 |  |
| Reductions for payments made |  | (4.4 | ) |
| Balance as of June 28, 2014 |  | $ | 8.5 |  |
  (was, 2014-05-08, similarity 0.9773):
[0000038725-14-000108:note_history:5]
| (In millions) |  |  |
| Balance as of December 28, 2013 |  | $ | 9.5 |  |
| Accruals related to product warranties |  | 1.4 |  |
| Reductions for payments made |  | (2.0 | ) |
| Balance as of March 29, 2014 |  | $ | 8.9 |  |

- removed (2014-08-07):
[0000038725-14-000108:note_history:6]
The company provides warranties on most of its products.  The warranty terms vary but are generally two years from date of manufacture or one year from date of installation.  In 2007, the Company began offering an extended warranty program to certain Water Systems customers which provides warranty coverage up to five years from date of manufacture.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-08-07):
[0000038725-14-000166:note_history:7]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
  (was, 2014-05-08, similarity 0.9773):
[0000038725-14-000108:note_history:7]
1. CONDENSED CONSOLIDATED FINANCIAL STATEMENTS

- changed (2014-08-07):
[0000038725-14-000166:note_history:8]
The accompanying condensed consolidated balance sheet as of December 28, 2013, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 28, 2014, and for the second quarters ended June 28, 2014 and June 29, 2013, have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the second quarter ended June 28, 2014, are not necessarily indicative of the results that may be expected for the fiscal year ending January 3, 2015.  For further information, including a description of the Company’s critical accounting policies, refer to the consolidated financial statements and notes thereto included in Franklin Electric Co., Inc.'s Annual Report on Form 10-K/A for the year ended December 28, 2013.
  (was, 2014-05-08, similarity 0.9596):
[0000038725-14-000108:note_history:8]
The accompanying condensed consolidated balance sheet as of December 28, 2013, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 29, 2014, and for the first quarters ended March 29, 2014 and March 30, 2013, have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the first quarter ended March 29, 2014, are not necessarily indicative of the results that may be expected for the fiscal year ending January 3, 2015.  For further information, including a description of the Company’s critical accounting policies, refer to the consolidated financial statements and notes thereto included in Franklin Electric Co., Inc.'s Annual Report on Form 10-K/A for the year ended December 28, 2013.

- added (2014-08-07):
[0000038725-14-000166:note_history:9]
Certain prior year amounts in the “investing activities” section on the condensed consolidated statement of cash flows were reclassified into the "Other, net" line to conform with the current year presentation.  The reclassification within the investing activities section of the condensed consolidated statement of cash flows had no impact on the operating cash flows or any other financial statement.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-08-07):
[0000038725-14-000166:note_history:10]
| (In millions) |  | June 28, 2014 |  | December 28, 2013 |
| Prudential Agreement - 5.79 percent |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 24.1 |  |  | 24.6 |  |
| Revolver |  | 48.2 |  |  | — |  |
| Capital leases |  | 1.0 |  |  | 0.8 |  |
| Foreign subsidiary debt |  | 21.9 |  |  | 14.2 |  |
|  |  | 245.2 |  |  | 189.6 |  |
| Less current maturities |  | (69.8 | ) |  | (15.4 | ) |
| Long-term debt |  | $ | 175.4 |  |  | $ | 174.2 |  |
  (was, 2014-05-08, similarity 0.9881):
[0000038725-14-000108:note_history:10]
| (In millions) |  | March 29, 2014 |  | December 28, 2013 |
| Prudential Agreement - 5.79 percent |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 24.1 |  |  | 24.6 |  |
| Revolver |  | 15.0 |  |  | — |  |
| Capital leases |  | 0.7 |  |  | 0.8 |  |
| Foreign subsidiary debt |  | 14.5 |  |  | 14.2 |  |
|  |  | 204.3 |  |  | 189.6 |  |
| Less current maturities |  | (30.6 | ) |  | (15.4 | ) |
| Long-term debt |  | $ | 173.7 |  |  | $ | 174.2 |  |

- changed (2014-08-07):
[0000038725-14-000166:note_history:11]
Foreign subsidiary debt denoted in the table above is predominately comprised of debt at Impo and Bombas Leao.
  (was, 2014-05-08, similarity 0.9216):
[0000038725-14-000108:note_history:11]
Foreign subsidiary debt denoted in the table above is predominately comprised of debt at Impo.

- added (2014-08-07):
[0000038725-14-000166:note_history:12]
On June 6, 2014, the Company assumed debt relating to the acquisition of Bombas Leao (see Note 3) of BRL 12.4 million, $5.5 million at the then current exchange rate.  The debt instruments bear interest rates ranging from 2.50 percent to 19.42 percent, with due dates ranging from November 2014 - November 2017.  There are no financial covenants associated with these debt instruments.

- added (2014-08-07):
[0000038725-14-000166:note_history:13]
The total estimated fair value of debt was $259.9 million and $203.7 million at June 28, 2014 and December 28, 2013, respectively.  The fair value assumed floating rate debt was valued at par.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its long-term debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as a Level 2 within the valuations hierarchy.

- removed (2014-08-07):
[0000038725-14-000108:note_history:14]
The total estimated fair value of debt was $218.3 million and $203.7 million at March 29, 2014 and December 28, 2013, respectively.  The fair value assumed floating rate debt was valued at par.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its long term debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as a Level 2 within the valuations hierarchy.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-08-07):
[0000038725-14-000166:note_history:15]
| (In millions) |  | June 28, 2014 |  | December 28, 2013 |
| Prudential Agreement - 5.79 percent |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 24.1 |  |  | 24.6 |  |
| Revolver |  | 48.2 |  |  | — |  |
| Capital leases |  | 1.0 |  |  | 0.8 |  |
| Foreign subsidiary debt |  | 21.9 |  |  | 14.2 |  |
|  |  | 245.2 |  |  | 189.6 |  |
| Less current maturities |  | (69.8 | ) |  | (15.4 | ) |
| Long-term debt |  | $ | 175.4 |  |  | $ | 174.2 |  |
  (was, 2014-05-08, similarity 0.9881):
[0000038725-14-000108:note_history:15]
| (In millions) |  | March 29, 2014 |  | December 28, 2013 |
| Prudential Agreement - 5.79 percent |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 24.1 |  |  | 24.6 |  |
| Revolver |  | 15.0 |  |  | — |  |
| Capital leases |  | 0.7 |  |  | 0.8 |  |
| Foreign subsidiary debt |  | 14.5 |  |  | 14.2 |  |
|  |  | 204.3 |  |  | 189.6 |  |
| Less current maturities |  | (30.6 | ) |  | (15.4 | ) |
| Long-term debt |  | $ | 173.7 |  |  | $ | 174.2 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2014-08-07):
[0000038725-14-000166:note_history:16]
SUBSEQUENT EVENTS

- added (2014-08-07):
[0000038725-14-000166:note_history:17]
On July 1, 2014, the Company announced a plan to close its Wittlich, Germany manufacturing facility.  As part of this action, the Company will transfer the existing Wittlich manufacturing activity to its Brno, Czech Republic facility.  The Company will maintain its European Water Systems Headquarters and distribution center in Wittlich, only the manufacturing operations will be relocating
