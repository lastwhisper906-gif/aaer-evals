# FELE notes — 0000038725-14-000166


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-14-000166:notes:1]
[same as prior period, unchanged from 0000038725-14-000108:notes:1]

[0000038725-14-000166:notes:2]
In an agreement dated June 6, 2014, between the Company and Bombas Leao S.A. ("Bombas Leao"), the Company acquired rights to 100 percent of the outstanding shares of Bombas Leao for a cash purchase price of approximately BRL 69.0 million, $30.7 million at the then current exchange rate, subject to certain terms and conditions.  The Company also acquired debt and certain liabilities of Bombas Leao.  The Company funded the acquisition with cash on hand and short-term borrowings from the Company's Revolver (see Note 11).

[0000038725-14-000166:notes:3]
Bombas Leao, based in Monte Azul Paulista, State of Sao Paulo, Brazil, designs, manufactures, and distributes submersible groundwater pumping equipment through manufacturing and distribution facilities.

[0000038725-14-000166:notes:4]
The Bombas Leao intangible assets of $26.5 million consist primarily of customer relationships, which will be amortized utilizing the straight line method over 20 years, and trade names, which are classified as indefinite lived assets and will not be amortized.

[0000038725-14-000166:notes:5]
The preliminary goodwill of $5.2 million resulting from the Bombas Leao acquisition consists primarily of broadened product offerings and expanded customer base.  All of the goodwill was recorded as part of the Water Systems segment and is not expected to be deductible for tax purposes.

[0000038725-14-000166:notes:6]
The preliminary purchase price assigned to the major identifiable assets and liabilities for the acquisition is as follows:

[0000038725-14-000166:notes:7]
| (In millions) |  |
| Assets: |  |
| Cash acquired | $ | 0.9 |  |
| Current assets | 14.0 |  |
| Property, plant, and equipment | 2.1 |  |
| Intangible assets | 26.5 |  |
| Goodwill | 5.2 |  |
| Other assets | 3.2 |  |
| Total assets | 51.9 |  |
| Liabilities | (21.2 | ) |
| Total consideration paid | $ | 30.7 |  |

[0000038725-14-000166:notes:8]
The fair values of the Bombas Leao identifiable intangible assets and property, plant and equipment are provisional amounts as of June 28, 2014, pending final valuations and purchase accounting adjustments.  The Company utilized management estimates and consultation with an independent third-party valuation firm to assist in the valuation process.

[0000038725-14-000166:notes:9]
The results of operations of Bombas Leao were included in the Company's condensed consolidated statement of income, from the respective acquisition date through the second quarter ended June 28, 2014. The difference between actual sales for the Company and proforma sales including Bombas Leao as if they were acquired at the beginning of each period was not material as a component of the Company's consolidated sales for the six months ended June 28, 2014 and June 29, 2013, respectively. Due to the immaterial nature of the acquisition, the Company has not included full year proforma statements of income for the acquisition year and previous year.

[0000038725-14-000166:notes:10]
Transaction costs were expensed as incurred under the guidance of FASB ASC Topic 805, Business Combinations.  Transaction costs included in selling, general, and administrative expenses in the Company’s condensed consolidated statements of income for the six months ended June 28, 2014, were $0.9 million.  No transaction costs were included in selling, general, and administrative expenses for the six months ended June 29, 2013.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000038725-14-000166:notes:11]
CONTINGENCIES AND COMMITMENTS

[0000038725-14-000166:notes:12]
In August 2010, the California Air Resources Board (“CARB”) and South Coast Air Quality Management District (“SCAQMD”) filed civil complaints in the Los Angeles Superior Court against the Company and Franklin Fueling Systems, Inc.  The complaints related to a third-party-supplied component part of the Company's Healy 900 Series nozzle, which is part of the Company's Enhanced Vapor Recovery (“EVR”) Systems installed in California gasoline filling stations.  This part, a diaphragm, was the subject of a retrofit during the first half of 2008.  As the Company previously reported, in October 2008 CARB issued a Notice of Violation to the Company alleging that the circumstances leading to the retrofit program violated California statutes and regulations.

[0000038725-14-000166:notes:13]
The claims in the complaints mirrored those that CARB presented to the Company in the Notice of Violation, and included claims that the Company negligently and intentionally sold nozzles with a modified diaphragm without required CARB certification. Those complaints were consolidated into one case in the Superior Court of California, County of Los Angeles (People of the State of California vs. Franklin Fueling Systems, Inc. et al.) which was tried in the later part of December 2012 and early part of January 2013 (“CARB Case”).

[0000038725-14-000166:notes:14]
On July 25, 2013, the Court issued a Final Statement of Decision (“Decision”) in the CARB Case.  In its Decision, the Court found on behalf of the Company and issued a complete defense verdict.  Judgment was entered on August 27, 2013.  An Amended Judgment awarding the Company $0.1 million in costs was entered by the Court on January 22, 2014.  On July 16, 2014, CARB appealed and filed its brief in support of the appeal. The Company has until September 29, 2014 to file its response brief.  If a hearing is held on the appeal it will likely occur sometime late in the fourth quarter 2014 or early first quarter 2015.

[0000038725-14-000166:notes:15]
Neither of these suits has had any effect on CARB's certification of the Company's EVR System or any other products of the Company or its subsidiaries, and did not interfere with continuing sales.  CARB has never decertified the Company's EVR System and has never proposed to do so.

[0000038725-14-000166:notes:16]
The Company is defending various other claims and legal actions, including environmental matters, which have arisen in the

[0000038725-14-000166:notes:17]
ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with

[0000038725-14-000166:notes:18]
counsel, these claims and legal actions can be successfully defended or resolved without a material adverse effect on the

[0000038725-14-000166:notes:19]
Company’s financial position, results of operations, and net cash flows.

[0000038725-14-000166:notes:20]
At June 28, 2014, the Company had $12.3 million of commitments primarily for the purchase of raw materials to be used in production.

[0000038725-14-000166:notes:21]
The company provides warranties on most of its products.  The warranty terms vary but are generally 2 years from date of manufacture or 1 year from date of installation.  In 2007, the Company began offering an extended warranty program to certain Water Systems customers which provides warranty coverage up to 5 years from date of manufacture.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-14-000166:notes:22]
The changes in the carrying amount of the warranty accrual, as recorded in "Accrued expenses" in the Company's condensed consolidated balance sheet for the six months ended June 28, 2014, are as follows:

[0000038725-14-000166:notes:23]
| (In millions) |  |  |
| Balance as of December 28, 2013 |  | $ | 9.5 |  |
| Accruals related to product warranties |  | 3.4 |  |
| Reductions for payments made |  | (4.4 | ) |
| Balance as of June 28, 2014 |  | $ | 8.5 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-14-000166:notes:24]
[same as prior period, unchanged from 0000038725-14-000108:notes:16]

[0000038725-14-000166:notes:25]
Changes in accumulated other comprehensive income (loss) by component for the six months ended June 28, 2014 and June 29, 2013, are summarized below:

[0000038725-14-000166:notes:26]
| (In millions) |  |  |  |  |  |
| For the six months ended June 28, 2014: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments |  | Total |
| Balance as of December 28, 2013 | $ | (16.0 | ) |  | $ | (38.7 | ) |  | $ | (54.7 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | 4.7 |  |  | — |  |  | 4.7 |  |
| Income tax expense | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | 4.7 |  |  | — |  |  | 4.7 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income | — |  |  | 1.5 |  | (1) | 1.5 |  |
| Income tax expense | — |  |  | (0.5 | ) |  | (0.5 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | 1.0 |  |  | 1.0 |  |
| Net current period other comprehensive income/(loss), net of income taxes | 4.7 |  |  | 1.0 |  |  | 5.7 |  |
| Other comprehensive (income)/loss attributable to noncontrolling interest | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Balance as of June 28, 2014 | $ | (11.4 | ) |  | $ | (37.7 | ) |  | $ | (49.1 | ) |
| For the six months ended June 29, 2013: |  |  |  |  |  |
| Balance as of December 29, 2012 | $ | (0.3 | ) |  | $ | (56.8 | ) |  | $ | (57.1 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | (15.6 | ) |  | — |  |  | (15.6 | ) |
| Income tax expense | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | (15.6 | ) |  | — |  |  | (15.6 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income | — |  |  | 2.1 |  | (1) | 2.1 |  |
| Income tax expense | — |  |  | (0.8 | ) |  | (0.8 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | 1.3 |  |  | 1.3 |  |
| Net current period other comprehensive income/(loss), net of income taxes | (15.6 | ) |  | 1.3 |  |  | (14.3 | ) |
| Other comprehensive (income)/loss attributable to noncontrolling interest | (0.1 | ) |  | — |  |  | (0.1 | ) |
| Balance as of June 29, 2013 | $ | (16.0 | ) |  | $ | (55.5 | ) |  | $ | (71.5 | ) |

[0000038725-14-000166:notes:27]
(1) This accumulated other comprehensive income (loss) component is included in the computation of net periodic pension cost (refer to Note 9 for additional details) and is included in the "Selling, general, and administrative expenses" line of the condensed consolidated statements of income.


## us-gaap:DebtDisclosureTextBlock

[0000038725-14-000166:notes:28]
DEBT

[0000038725-14-000166:notes:29]
Debt consisted of the following:

[0000038725-14-000166:notes:30]
| (In millions) |  | June 28, 2014 |  | December 28, 2013 |
| Prudential Agreement - 5.79 percent |  | $ | 150.0 |  |  | $ | 150.0 |  |
| Tax increment financing debt |  | 24.1 |  |  | 24.6 |  |
| Revolver |  | 48.2 |  |  | — |  |
| Capital leases |  | 1.0 |  |  | 0.8 |  |
| Foreign subsidiary debt |  | 21.9 |  |  | 14.2 |  |
|  |  | 245.2 |  |  | 189.6 |  |
| Less current maturities |  | (69.8 | ) |  | (15.4 | ) |
| Long-term debt |  | $ | 175.4 |  |  | $ | 174.2 |  |

[0000038725-14-000166:notes:31]
Foreign subsidiary debt denoted in the table above is predominately comprised of debt at Impo and Bombas Leao.

[0000038725-14-000166:notes:32]
On June 6, 2014, the Company assumed debt relating to the acquisition of Bombas Leao (see Note 3) of BRL 12.4 million, $5.5 million at the then current exchange rate.  The debt instruments bear interest rates ranging from 2.50 percent to 19.42 percent, with due dates ranging from November 2014 - November 2017.  There are no financial covenants associated with these debt instruments.

[0000038725-14-000166:notes:33]
The total estimated fair value of debt was $259.9 million and $203.7 million at June 28, 2014 and December 28, 2013, respectively.  The fair value assumed floating rate debt was valued at par.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its long-term debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as a Level 2 within the valuations hierarchy.

[0000038725-14-000166:notes:34]
The following debt payments are expected to be paid in accordance with the following schedule:

[0000038725-14-000166:notes:35]
| (In millions) |  | Total |  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | 2018 |  | More than 5 years |
| Debt |  | $ | 244.2 |  |  | $ | 69.4 |  |  | $ | 31.2 |  |  | $ | 32.2 |  |  | $ | 31.1 |  |  | $ | 31.0 |  |  | $ | 49.3 |  |
| Capital leases |  | 1.0 |  |  | 0.4 |  |  | 0.2 |  |  | 0.2 |  |  | 0.1 |  |  | 0.1 |  |  | — |  |
|  |  | $ | 245.2 |  |  | $ | 69.8 |  |  | $ | 31.4 |  |  | $ | 32.4 |  |  | $ | 31.2 |  |  | $ | 31.1 |  |  | $ | 49.3 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-14-000166:notes:36]
[same as prior period, unchanged from 0000038725-14-000108:notes:27]

[0000038725-14-000166:notes:37]
The Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  During February 2014, the Company entered into a share swap transaction agreement ("the swap") to mitigate the Company’s exposure to these fluctuations in the Company's stock price.  The swap was not designated as a hedge for accounting purposes and is cancellable with 30 days written notice by either party.  The swap has a notional value of 147,750 shares.  For the second quarter and six months ended June 28, 2014, the swap transaction resulted in a loss of $0.1 million and a loss of $0.3 million, respectively.  All gains or losses and expenses related to the total return swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-14-000166:notes:38]
[same as prior period, unchanged from 0000038725-14-000108:notes:29]

[0000038725-14-000166:notes:39]
The Company maintains the Franklin Electric Co., Inc. 2012 Stock Plan (the "2012 Stock Plan"), which is a stock-based compensation plan that provides for discretionary grants of stock options, stock awards, and stock unit awards to key employees and non-employee directors.  Shares and per share data below have been adjusted for all periods presented to reflect the two-for-one stock split effective March 18, 2013.

[0000038725-14-000166:notes:40]
[same as prior period, unchanged from 0000038725-14-000108:notes:31]

[0000038725-14-000166:notes:41]
[same as prior period, unchanged from 0000038725-14-000108:notes:32]

[0000038725-14-000166:notes:42]
[same as prior period, unchanged from 0000038725-14-000108:notes:33]

[0000038725-14-000166:notes:43]
[same as prior period, unchanged from 0000038725-14-000108:notes:34]

[0000038725-14-000166:notes:44]
[same as prior period, unchanged from 0000038725-14-000108:notes:35]

[0000038725-14-000166:notes:45]
[same as prior period, unchanged from 0000038725-14-000108:notes:36]

[0000038725-14-000166:notes:46]
[same as prior period, unchanged from 0000038725-14-000108:notes:37]

[0000038725-14-000166:notes:47]
[same as prior period, unchanged from 0000038725-14-000108:notes:38]

[0000038725-14-000166:notes:48]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the six months ended June 28, 2014 and June 29, 2013, are as follows:

[0000038725-14-000166:notes:49]
|  |  | June 28, 2014 |  | June 29, 2013 |
| Risk-free interest rate |  | 1.68 | % |  | 1.03 | % |
| Dividend yield |  | 0.70 | % |  | 0.89 | % |
| Volatility factor |  | 0.387 |  |  | 0.394 |  |
| Expected term |  | 5.6 years |  |  | 6.0 years |  |
| Forfeiture rate |  | 3.81 | % |  | 4.52 | % |

[0000038725-14-000166:notes:50]
There were 22,050 stock options granted during the second quarter ended June 28, 2014.  There were no stock options granted during the second quarter ended June 29, 2013.

[0000038725-14-000166:notes:51]
A summary of the Company’s outstanding stock option activity and related information for the six months ended June 28, 2014 and June 29, 2013 is as follows:

[0000038725-14-000166:notes:52]
| (Shares in thousands) |  | June 28, 2014 |  | June 29, 2013 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,476 |  |  | $ | 19.01 |  |  | 2,184 |  |  | $ | 16.69 |  |
| Granted |  | 115 |  |  | 42.24 |  |  | 176 |  |  | 32.53 |  |
| Exercised |  | (63 | ) |  | 18.89 |  |  | (632 | ) |  | 15.06 |  |
| Forfeited |  | (3 | ) |  | 26.95 |  |  | (3 | ) |  | 10.60 |  |
| Expired |  | (16 | ) |  | 16.34 |  |  | — |  |  | — |  |
| Outstanding at end of period |  | 1,509 |  |  | $ | 20.80 |  |  | 1,725 |  |  | $ | 18.91 |  |
| Expected to vest after applying forfeiture rate |  | 1,491 |  |  | $ | 20.63 |  |  | 1,698 |  |  | $ | 18.77 |  |
| Vested and exercisable at end of period |  | 1,194 |  |  | $ | 17.62 |  |  | 1,191 |  |  | $ | 16.05 |  |

[0000038725-14-000166:notes:53]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value for the six months ended June 28, 2014 is as follows:

[0000038725-14-000166:notes:54]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 5.70 years |  | $ | 29,880 |  |
| Expected to vest after applying forfeiture rate |  | 5.66 years |  | $ | 29,767 |  |
| Vested and exercisable at end of period |  | 4.93 years |  | $ | 27,225 |  |

[0000038725-14-000166:notes:55]
The total intrinsic value of options exercised during the six months ended June 28, 2014 and June 29, 2013, was $1.4 million and $11.5 million, respectively.

[0000038725-14-000166:notes:56]
As of June 28, 2014, there was $2.0 million of total unrecognized compensation cost related to non-vested share-based compensation arrangements related to stock options granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.62 years.

[0000038725-14-000166:notes:57]
[same as prior period, unchanged from 0000038725-14-000108:notes:48]

[0000038725-14-000166:notes:58]
A summary of the Company’s restricted stock/stock unit award activity and related information for the six months ended June 28, 2014 and June 29, 2013 is as follows:

[0000038725-14-000166:notes:59]
| (Shares in thousands) |  | June 28, 2014 |  | June 29, 2013 |
| Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 551 |  |  | $ | 24.75 |  |  | 458 |  |  | $ | 20.90 |  |
| Awarded |  | 193 |  |  | 42.81 |  |  | 153 |  |  | 32.50 |  |
| Vested |  | (124 | ) |  | 16.75 |  |  | (60 | ) |  | 18.90 |  |
| Forfeited |  | (59 | ) |  | 28.04 |  |  | (2 | ) |  | 17.70 |  |
| Non-vested at end of period |  | 561 |  |  | $ | 32.38 |  |  | $ | 549 |  |  | $ | 24.37 |  |

[0000038725-14-000166:notes:60]
As of June 28, 2014, there was $10.2 million of total unrecognized compensation cost related to non-vested share-based compensation arrangements related to stock/stock unit awards granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.58 years.


## us-gaap:EarningsPerShareTextBlock

[0000038725-14-000166:notes:61]
[same as prior period, unchanged from 0000038725-14-000108:notes:52]

[0000038725-14-000166:notes:62]
[same as prior period, unchanged from 0000038725-14-000108:notes:53]

[0000038725-14-000166:notes:63]
[same as prior period, unchanged from 0000038725-14-000108:notes:54]

[0000038725-14-000166:notes:64]
[same as prior period, unchanged from 0000038725-14-000108:notes:55]

[0000038725-14-000166:notes:65]
|  | Second Quarter Ended |  | Six Months Ended |
| (In millions, except per share amounts) | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 27.1 |  |  | $ | 28.1 |  |  | $ | 44.0 |  |  | $ | 43.6 |  |
| Less: Undistributed earnings allocable to participating securities | 0.3 |  |  | 0.3 |  |  | 0.5 |  |  | 0.5 |  |
| Less: Undistributed earnings allocated to redeemable non-controlling interest | 0.2 |  |  | — |  |  | 0.2 |  |  | — |  |
|  | $ | 26.6 |  |  | $ | 27.8 |  |  | $ | 43.3 |  |  | $ | 43.1 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  |  |  |  |  |  |
| Weighted average common shares | 47.6 |  |  | 47.5 |  |  | 47.7 |  |  | 47.4 |  |
| Diluted |  |  |  |  |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |
| Non-participating employee and director incentive stock options and performance awards | 0.6 |  |  | 0.6 |  |  | 0.6 |  |  | 0.6 |  |
| Adjusted weighted average common shares | 48.2 |  |  | 48.1 |  |  | 48.3 |  |  | 48.0 |  |
| Basic earnings per share | $ | 0.56 |  |  | $ | 0.59 |  |  | $ | 0.91 |  |  | $ | 0.91 |  |
| Diluted earnings per share | $ | 0.55 |  |  | $ | 0.58 |  |  | $ | 0.90 |  |  | $ | 0.90 |  |
| Anti-dilutive stock options | 0.1 |  |  | 0.1 |  |  | 0.1 |  |  | 0.1 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000038725-14-000166:notes:66]
As of June 28, 2014 and December 28, 2013, the assets and liabilities measured at fair value on a recurring basis were as set forth in the table below.

[0000038725-14-000166:notes:67]
| (In millions) | June 28, 2014 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) | Recognized Loss |
| Cash equivalents | $ | 11.3 |  | $ | 11.3 |  | $ | — |  | $ | — |  | $ | — |  |
|  | December 28, 2013 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) | Recognized Loss |
| Cash equivalents | $ | 6.6 |  | $ | 6.6 |  | $ | — |  | $ | — |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-14-000166:notes:68]
[same as prior period, unchanged from 0000038725-14-000108:notes:59]

[0000038725-14-000166:notes:69]
[same as prior period, unchanged from 0000038725-14-000108:notes:60]

[0000038725-14-000166:notes:70]
[same as prior period, unchanged from 0000038725-14-000108:notes:61]

[0000038725-14-000166:notes:71]
[same as prior period, unchanged from 0000038725-14-000108:notes:62]

[0000038725-14-000166:notes:72]
[same as prior period, unchanged from 0000038725-14-000108:notes:63]

[0000038725-14-000166:notes:73]
[same as prior period, unchanged from 0000038725-14-000108:notes:64]

[0000038725-14-000166:notes:74]
[same as prior period, unchanged from 0000038725-14-000108:notes:65]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-14-000166:notes:75]
[same as prior period, unchanged from 0000038725-14-000108:notes:66]

[0000038725-14-000166:notes:76]
[same as prior period, unchanged from 0000038725-14-000108:notes:67]

[0000038725-14-000166:notes:77]
| (In millions) |  | June 28, 2014 |  | December 28, 2013 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortized intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.8 |  |  | $ | (6.0 | ) |  | $ | 7.8 |  |  | $ | (5.9 | ) |
| Supply agreements |  | 4.4 |  |  | (4.4 | ) |  | 4.4 |  |  | (4.4 | ) |
| Technology |  | 7.5 |  |  | (4.0 | ) |  | 7.5 |  |  | (3.8 | ) |
| Customer relationships |  | 145.4 |  |  | (33.5 | ) |  | 125.1 |  |  | (29.7 | ) |
| Software |  | 2.1 |  |  | (0.5 | ) |  | 2.1 |  |  | (0.4 | ) |
| Other |  | 1.3 |  |  | (1.3 | ) |  | 1.3 |  |  | (1.2 | ) |
| Total |  | $ | 168.5 |  |  | $ | (49.7 | ) |  | $ | 148.2 |  |  | $ | (45.4 | ) |
| Unamortized intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 53.5 |  |  | — |  |  | 45.9 |  |  | — |  |
| Total intangibles |  | $ | 222.0 |  |  | $ | (49.7 | ) |  | $ | 194.1 |  |  | $ | (45.4 | ) |

[0000038725-14-000166:notes:78]
Amortization expense related to intangible assets for the second quarters ended June 28, 2014 and June 29, 2013 was $2.1 million and $2.0 million, respectively, and $4.1 million and $4.0 million for the six months ended June 28, 2014 and June 29, 2013, respectively.

[0000038725-14-000166:notes:79]
[same as prior period, unchanged from 0000038725-14-000108:notes:70]

[0000038725-14-000166:notes:80]
| (In millions) |  | 2014 |  | 2015 |  | 2016 |  | 2017 |  | 2018 |
|  |  | $ | 8.7 |  |  | $ | 9.1 |  |  | $ | 9.1 |  |  | $ | 8.8 |  |  | $ | 8.7 |  |

[0000038725-14-000166:notes:81]
The change in the carrying amount of goodwill by reporting segment for the six months ended June 28, 2014, is as follows:

[0000038725-14-000166:notes:82]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Consolidated |
| Balance as of December 28, 2013 |  | $ | 144.1 |  |  | $ | 63.1 |  |  | $ | 207.2 |  |
| Acquisitions |  | 5.2 |  |  | — |  |  | 5.2 |  |
| Foreign currency translation |  | 0.8 |  |  | 0.1 |  |  | 0.9 |  |
| Balance as of June 28, 2014 |  | $ | 150.1 |  |  | $ | 63.2 |  |  | $ | 213.3 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-14-000166:notes:83]
[same as prior period, unchanged from 0000038725-14-000108:notes:74]

[0000038725-14-000166:notes:84]
The effective tax rate continues to be lower than the U.S. statutory rate of 35.0 percent primarily due to the indefinite reinvestment of foreign earnings taxed at rates below the U.S. statutory rate as well as recognition of U.S. and foreign tax credits.  The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations as well as cash on hand and available credit.

[0000038725-14-000166:notes:85]
The Company recorded additional unrecognized tax benefits of $4.1 million.  This amount is associated with uncertain tax positions taken by newly acquired companies in tax years prior to the acquisition of these companies by the Company.


## us-gaap:MinorityInterestDisclosureTextBlock

[0000038725-14-000166:notes:86]
[same as prior period, unchanged from 0000038725-14-000108:notes:76]

[0000038725-14-000166:notes:87]
On May 2, 2011, the Company completed the acquisition of 80 percent of Impo.  The original 20 percent noncontrolling interest was recorded at fair value as of the acquisition date.  The noncontrolling interest holders have the option, which is embedded in the noncontrolling interest, to require the Company to redeem their ownership interests after May 2, 2014, three years after the original agreement was signed.  The combination of a noncontrolling interest and a redemption feature resulted in a redeemable noncontrolling interest.

[0000038725-14-000166:notes:88]
During the second quarter of 2014, 10 percent of the noncontrolling interest was redeemed, increasing the Company's ownership to 90 percent (see Note 3).  The remaining 10 percent noncontrolling interest will continue to be recorded as a redeemable noncontrolling interest on the balance sheet.

[0000038725-14-000166:notes:89]
During the second quarter, the Company redeemed 10 percent of the noncontrolling interest of Impo, increasing the Company's ownership to 90 percent for approximately TRY 6.2 million, $2.9 million at the then current exchange rate.  The 10 percent redemption value was calculated using a specified formula and resulted in a carrying value adjustment of TRY 0.2 million ($0.1 million).  The redemption reduced the "Redeemable noncontrolling interest" line in the Company's condensed consolidated balance sheet.  Due to the immaterial nature of the redemption, the Company has not included full year proforma statements of income for the acquisition year or previous year.  The original 80 percent controlling interest was acquired in the second quarter of 2011.

[0000038725-14-000166:notes:90]
The remaining redeemable noncontrolling interest in Impo is redeemable at other than fair value as the redemption value is determined based on a specified formula.  The noncontrolling interest becomes redeemable after the passage of time, and therefore the Company records the carrying amount of the noncontrolling interest at the greater of (1) the initial carrying amount, increased or decreased for each noncontrolling interest's share of net income or loss and its share of other comprehensive income or loss and dividends (“carrying amount”) or (2) the redemption value which is determined based on the greater of the redemption floor value or the then-current specified earnings multiple.  As of June 28, 2014, the Impo redeemable noncontrolling interest was recorded at the redemption value.

[0000038725-14-000166:notes:91]
According to FASB ASC Topic 810, Consolidation and Emerging Issues Task Force ("EITF") Topic No. D-98, Classification and Measurement of Redeemable Securities, redeemable noncontrolling interests issued in the form of common securities, to the extent that the noncontrolling interest holder has a contractual right to receive an amount upon share redemption that is other than the fair value of such shares, then the noncontrolling interest holder has, in substance, received a dividend distribution that is different from other common shareholders.  Therefore, adjustments to the noncontrolling interest to reflect the redemption amount should be reflected in the computation of earnings per share using the two-class method.  Under the two-class method, the Company has elected to treat as a dividend only the portion of the periodic redemption value adjustment (if any) that reflects a redemption value in excess of carrying value.  Adjustments for both the redeemed and redeemable noncontrolling interests totaled $0.2 million for the second quarter and six months ended June 28, 2014.  No adjustments were necessary for the second quarter and six months ended June 29, 2013.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000038725-14-000166:notes:92]
ACCOUNTING PRONOUNCEMENTS

[0000038725-14-000166:notes:93]
In April 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2014-08 Presentation of Financial Statements and Property, Plant and Equipment: Reporting Discontinued Operations and Disclosures of Disposals of Components of an Entity.  ASU 2014-08 raises the threshold for a disposal to qualify as a discontinued operation and requires new disclosures of both discontinued operations and certain other disposals that do not meet the definition of a discontinued operation. ASU 2014-08 is effective for annual periods beginning after December 15, 2014, and interim periods within annual periods beginning on or after December 15, 2015, with early adoption permitted.  The Company has adopted this standard with no impact on the Company’s consolidated financial position, results of operations, or cash flows.

[0000038725-14-000166:notes:94]
In May 2014, the FASB issued ASU 2014-09 Revenue from Contracts with Customers.  ASU 2014-09 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes current revenue recognition guidance.  The ASU is effective for annual reporting periods beginning after December 15, 2016 and early adoption is not permitted.  Entities have the option of using either a full retrospective or a modified retrospective approach to adopt the new ASU.  The Company is still in the process of analyzing the effect of this new standard to determine the impact on the Company's consolidated financial position, results of operations, and cash flows.

[0000038725-14-000166:notes:95]
In June 2014, the FASB issued ASU 2014-12, Compensation - Stock Compensation (Topic 718): Accounting for Share-Based Payments When the Terms of an Award Provide That the Performance Target Could Be Achieved After the Requisite Service Period.  The amendments in the ASU require that a performance target that affects vesting and that could be achieved after the requisite service period be treated as a performance condition.  A reporting entity should apply existing guidance in Topic 718, Compensation - Stock Compensation, as it relates to awards with performance conditions that affect vesting to account for such awards.  The amendments in the ASU are effective for annual periods beginning after December 15, 2015, and interim periods within annual periods beginning on or after December 15, 2015, with early adoption permitted.  The Company is still in the process of analyzing the effect of this new standard to determine the impact on the Company's consolidated financial position, results of operations, and cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-14-000166:notes:96]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS

[0000038725-14-000166:notes:97]
The accompanying condensed consolidated balance sheet as of December 28, 2013, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 28, 2014, and for the second quarters ended June 28, 2014 and June 29, 2013, have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the second quarter ended June 28, 2014, are not necessarily indicative of the results that may be expected for the fiscal year ending January 3, 2015.  For further information, including a description of the Company’s critical accounting policies, refer to the consolidated financial statements and notes thereto included in Franklin Electric Co., Inc.'s Annual Report on Form 10-K/A for the year ended December 28, 2013.

[0000038725-14-000166:notes:98]
Certain prior year amounts in the “investing activities” section on the condensed consolidated statement of cash flows were reclassified into the "Other, net" line to conform with the current year presentation.  The reclassification within the investing activities section of the condensed consolidated statement of cash flows had no impact on the operating cash flows or any other financial statement.


## us-gaap:OtherAssetsDisclosureTextBlock

[0000038725-14-000166:notes:99]
[same as prior period, unchanged from 0000038725-14-000108:notes:84]

[0000038725-14-000166:notes:100]
The Company has equity interests in various companies for various strategic purposes.  The investments are accounted for under the equity method and are included in “Other assets” on the Company’s condensed consolidated balance sheet.  The carrying amount of the investment is adjusted for the Company's proportionate share of earnings, losses, and dividends.  The investments are not considered material to the Company’s financial position, neither individually nor in the aggregate.  The Company’s proportionate share of earnings from its equity interests, included in the "Other income" line of the Company's condensed consolidated statements of income, were immaterial for the second quarter and six months ended June 28, 2014.

[0000038725-14-000166:notes:101]
The Company has a loan agreement with the parent company of a customer.  The current maturity is included in "Receivables" and the long-term portion is included in "Other assets" on the Company's condensed consolidated balance sheet.  The agreement provides for interest on the loan at a variable market interest rate with the debtor to repay the loan plus interest in semi-annual installments.  The Company has a long-term relationship with the customer and considers the loan fully collectible.   The loan is not considered material to the Company’s financial position.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-14-000166:notes:102]
[same as prior period, unchanged from 0000038725-14-000108:notes:87]

[0000038725-14-000166:notes:103]
Defined Benefit Plans - As of June 28, 2014, the Company maintained two domestic pension plans and three German pension plans.  The Company used a December 28, 2013 measurement date for these plans.

[0000038725-14-000166:notes:104]
[same as prior period, unchanged from 0000038725-14-000108:notes:89]

[0000038725-14-000166:notes:105]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the second quarters and six months ended June 28, 2014 and June 29, 2013:

[0000038725-14-000166:notes:106]
| (In millions) | Pension Benefits |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |
| Service cost | $ | 0.4 |  |  | $ | 0.6 |  |  | $ | 0.7 |  |  | $ | 1.0 |  |
| Interest cost | 2.1 |  |  | 1.9 |  |  | 4.1 |  |  | 3.8 |  |
| Expected return on assets | (2.6 | ) |  | (2.5 | ) |  | (5.2 | ) |  | (5.0 | ) |
| Amortization of prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of loss | 0.6 |  |  | 0.8 |  |  | 1.2 |  |  | 1.7 |  |
| Net periodic benefit cost | $ | 0.5 |  |  | $ | 0.8 |  |  | $ | 0.8 |  |  | $ | 1.5 |  |
| Settlement cost | 0.2 |  |  | — |  |  | 0.4 |  |  | — |  |
| Total net periodic benefit cost | $ | 0.7 |  |  | $ | 0.8 |  |  | $ | 1.2 |  |  | $ | 1.5 |  |

[0000038725-14-000166:notes:107]
In the six months ended June 28, 2014, the Company made contributions of $4.3 million to the funded plans.  The amount of contributions to be made to the plans during the calendar year 2014 will be finalized by September 15, 2014, based upon the plan's year-end valuation at December 28, 2013, and the funding level required for the plan year ended December 28, 2013.

[0000038725-14-000166:notes:108]
The following table sets forth the aggregated net periodic benefit cost for the postretirement benefit plan for the second quarters and six months ended June 28, 2014 and June 29, 2013, respectively:

[0000038725-14-000166:notes:109]
|  | Other Benefits |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |
| Service cost | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 0.1 |  |
| Interest cost | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.2 |  |
| Expected return on assets | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.2 |  |
| Amortization of loss | — |  |  | — |  |  | — |  |  | 0.1 |  |
| Net periodic benefit cost | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 0.5 |  |  | $ | 0.6 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Total net periodic benefit cost | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 0.5 |  |  | $ | 0.6 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000038725-14-000166:notes:110]
[same as prior period, unchanged from 0000038725-14-000108:notes:93]

[0000038725-14-000166:notes:111]
Costs incurred in the second quarter and six months ended June 28, 2014, included in the “Restructuring expense” line of the Company's condensed consolidated statements of income, are as follows:

[0000038725-14-000166:notes:112]
|  |  | Second Quarter Ended |
|  |  | June 28, 2014 |
| (In millions) |  | Water Systems |  | Fueling Systems |  | Other |  | Consolidated |
| Employee severance |  | $ | 0.2 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.2 |  |
| Asset write-off |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Total |  | $ | 0.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.3 |  |
|  |  | Six Months Ended |
|  |  | June 28, 2014 |
| (In millions) |  | Water Systems |  | Fueling Systems |  | Other |  | Consolidated |
| Employee severance |  | $ | 0.3 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.3 |  |
| Asset write-off |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Total |  | $ | 0.4 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.4 |  |

[0000038725-14-000166:notes:113]
Restructuring expenses for the second quarter ended June 29, 2013 were approximately $0.7 million, and primarily related to the relocation of the Company to the new Corporate Headquarters and Engineering Center in Fort Wayne, Indiana.  Restructuring expenses of $1.4 million were incurred in the six months ended June 29, 2013, primarily relating to severance.

[0000038725-14-000166:notes:114]
As of June 28, 2014, there were no restructuring reserves.  As of June 29, 2013, there were $0.3 million in restructuring reserves.  The restructuring reserves were primarily for severance.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000038725-14-000166:notes:115]
Financial information by reportable business segment is included in the following summary:

[0000038725-14-000166:notes:116]
|  | Second Quarter Ended |  | Six Months Ended |
| (In millions) | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |
|  | Net sales to external customers |
| Water Systems | $ | 226.7 |  |  | $ | 213.7 |  |  | $ | 411.3 |  |  | $ | 390.2 |  |
| Fueling Systems | 57.8 |  |  | 49.7 |  |  | 104.6 |  |  | 95.8 |  |
| Other | — |  |  | — |  |  | $ | — |  |  | $ | — |  |
| Consolidated | $ | 284.5 |  |  | $ | 263.4 |  |  | $ | 515.9 |  |  | $ | 486.0 |  |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |
|  | Operating income (loss) |
| Water Systems | $ | 41.7 |  |  | $ | 42.7 |  |  | $ | 71.0 |  |  | $ | 71.4 |  |
| Fueling Systems | 13.5 |  |  | 10.8 |  |  | 22.5 |  |  | 17.1 |  |
| Other | (16.1 | ) |  | (12.8 | ) |  | (28.4 | ) |  | (24.6 | ) |
| Consolidated | $ | 39.1 |  |  | $ | 40.7 |  |  | $ | 65.1 |  |  | $ | 63.9 |  |
|  | June 28, 2014 |  | December 28, 2013 |  |  |  |  |
|  | Total assets |  |  |  |  |
| Water Systems | $ | 849.0 |  |  | $ | 714.7 |  |  |  |  |  |
| Fueling Systems | 260.1 |  |  | 247.9 |  |  |  |  |  |
| Other | 57.3 |  |  | 89.3 |  |  |  |  |  |
| Consolidated | $ | 1,166.4 |  |  | $ | 1,051.9 |  |  |  |  |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0000038725-14-000166:notes:117]
The schedule below sets forth equity changes in the six months ended June 28, 2014:

[0000038725-14-000166:notes:118]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 28, 2013 | $ | 4,771 |  |  | $ | 194,810 |  |  | $ | 450,855 |  |  | $ | (38,707 | ) |  | $ | (16,022 | ) |  | $ | 2,509 |  |  | $ | 598,216 |  |  | $ | 5,171 |  |
| Net income |  |  |  |  | 44,031 |  |  |  |  |  |  | 382 |  |  | 44,413 |  |  | 466 |  |
| Adjustment to Impo redemption value |  |  |  |  | (235 | ) |  |  |  |  |  |  |  | (235 | ) |  | 235 |  |
| Dividends on common stock |  |  |  |  | (8,017 | ) |  |  |  |  |  |  |  | (8,017 | ) |  |  |
| Common stock issued | 6 |  |  | 1,178 |  |  |  |  |  |  |  |  |  |  | 1,184 |  |  |  |
| Common stock repurchased or received for stock options exercised | (16 | ) |  |  |  | (6,459 | ) |  |  |  |  |  |  |  | (6,475 | ) |  |  |
| Share-based compensation | (1 | ) |  | 5,077 |  |  |  |  |  |  |  |  |  |  | 5,076 |  |  |  |
| Tax benefit of stock options exercised |  |  | 1,469 |  |  |  |  |  |  |  |  |  |  | 1,469 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | (800 | ) |  | (800 | ) |  |  |
| Purchase of redeemable non-controlling shares |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (2,875 | ) |
| Currency translation adjustment |  |  |  |  |  |  |  |  | 4,681 |  |  | (27 | ) |  | 4,654 |  |  | 25 |  |
| Pension liability, net of tax |  |  |  |  |  |  | 976 |  |  |  |  |  |  | 976 |  |  |  |
| Balance as of June 28, 2014 | $ | 4,760 |  |  | $ | 202,534 |  |  | $ | 480,175 |  |  | $ | (37,731 | ) |  | $ | (11,341 | ) |  | $ | 2,064 |  |  | $ | 640,461 |  |  | $ | 3,022 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-14-000166:notes:119]
[same as prior period, unchanged from 0000038725-14-000108:notes:102]

[0000038725-14-000166:notes:120]
Property, plant, and equipment is the major asset group in "Other" of total assets as of June 28, 2014.  Cash is the major asset group in “Other” of total assets as of December 28, 2013.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-14-000166:notes:121]
[same as prior period, unchanged from 0000038725-14-000108:notes:107]


## us-gaap:SubsequentEventsTextBlock

[0000038725-14-000166:notes:122]
SUBSEQUENT EVENTS

[0000038725-14-000166:notes:123]
On July 1, 2014, the Company announced a plan to close its Wittlich, Germany manufacturing facility.  As part of this action, the Company will transfer the existing Wittlich manufacturing activity to its Brno, Czech Republic facility.  The Company will maintain its European Water Systems Headquarters and distribution center in Wittlich, only the manufacturing operations will be relocating
