# FELE 8-K — 0000038725-14-000158 filed 2014-07-28

## item codes, every 8-K on or before 2014-08-07

- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2014-08-07

- none on or before 2014-08-07

## item 2.02 — earnings release, exhibit 99.1

[0000038725-14-000158:8k_2_02:1]
EX-99.1
2
a20140728exhibit991.htm
EXHIBIT

[0000038725-14-000158:8k_2_02:2]
2014.07.28. Exhibit 99.1

[0000038725-14-000158:8k_2_02:3]
Exhibit 99.1

[0000038725-14-000158:8k_2_02:4]
For Immediate Release

[0000038725-14-000158:8k_2_02:5]
For Further Information

[0000038725-14-000158:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-14-000158:8k_2_02:7]
260-824-2900

[0000038725-14-000158:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS RECORD SECOND QUARTER

[0000038725-14-000158:8k_2_02:9]
2014 SALES

[0000038725-14-000158:8k_2_02:10]
Fort Wayne, Indiana - July 28, 2014 - Franklin Electric Co., Inc. (NASDAQ:FELE) reported second quarter 2014 adjusted earnings per share (EPS) of $0.60 compared to 2013 second quarter adjusted EPS of $0.59, a 2 percent increase (see table below for a reconciliation of GAAP EPS to the adjusted EPS).  In the second quarter of 2014, the Company’s GAAP fully diluted EPS was $0.55 which was down 5 percent to the GAAP fully diluted EPS from the second quarter of 2013.

[0000038725-14-000158:8k_2_02:11]
Second quarter 2014 sales were $284.5 million, an increase of 8 percent compared to 2013 second quarter sales of $263.4 million.  The Company’s organic sales growth was about 9 percent excluding acquisitions and the impact of foreign currency translation.

[0000038725-14-000158:8k_2_02:12]
Gregg Sengstack, Franklin Electric’s Chief Executive Officer, commented:

[0000038725-14-000158:8k_2_02:13]
“We are pleased to report that our sales and adjusted net income for the second quarter of 2014 were again records for any quarter in the Company’s history. During the second quarter 2014, our consolidated operating income after non-GAAP adjustments grew by 3 percent compared to the second quarter of 2013 driven by a 25 percent increase in Fueling Systems operating income, a near doubling of Pioneer Pump sales globally and double digit earnings growth of our Water Systems businesses in Europe and the Middle East. These positive factors were partially offset in the quarter by lower Water Systems profitability due to a shift in sales mix.  Additionally, in certain developing region markets, most notably Asia Pacific, a combination of factors lowered overall profitability.  Consolidated adjusted operating income margin declined in the second quarter by 80 basis points.”

[0000038725-14-000158:8k_2_02:14]
Key Performance Indicators:

[0000038725-14-000158:8k_2_02:15]
| Earnings Before and After Non-GAAP Adjustments |  | For the Second Quarter |
| (in millions) |  | 2014 | 2013 | Change |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 27.1 |  | $ | 28.1 |  | (4 | )% |
| Allocated Undistributed Earnings |  | $ | (0.5 | ) | $ | (0.3 | ) |  |
| Adjusted Earnings for EPS Calculations |  | $ | 26.6 |  | $ | 27.8 |  | (4 | )% |
| Non-GAAP adjustments (before tax): |  |  |  |  |
| Restructuring |  | $ | 0.3 |  | $ | 0.7 |  |  |
| Non-GAAP items |  | $ | 3.3 |  | $ | 0.2 |  |  |
| Non-GAAP adjustments, net of tax: |  |  |  |  |
| Restructuring |  | $ | 0.2 |  | $ | 0.4 |  |  |
| Non-GAAP items |  | $ | 2.0 |  | $ | 0.2 |  |  |
| Earnings after Non-GAAP Adjustments |  | $ | 28.8 |  | $ | 28.4 |  | 1 | % |
| Earnings Per Share |  | For the Second Quarter |
| Before and After Non-GAAP Adjustments |  | 2014 | 2013 | Change |
| (in millions except Earnings Per Share) |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 48.2 |  | 48.1 |  | — | % |
| Fully Diluted Earnings Per Share ("EPS") Reported |  | $ | 0.55 |  | $ | 0.58 |  | (5 | )% |
| Restructuring Per Share, net of tax |  | $ | — |  | $ | 0.01 |  |  |
| Non-GAAP items |  | $ | 0.05 |  | $ | — |  |  |
| Fully Diluted EPS after Non-GAAP Adjustments(Adjusted EPS) |  | $ | 0.60 |  | $ | 0.59 |  | 2 | % |

[0000038725-14-000158:8k_2_02:16]
| Net Sales | For the Second Quarter |
| (in millions) | Water | Fueling | Consolidated |
| Sales for 2013 | $ | 213.7 |  | $ | 49.7 |  | $ | 263.4 |  |
| Acquisitions | $ | 2.3 |  | $ | — |  | $ | 2.3 |  |
| Foreign Exchange | $ | (4.3 | ) | $ | 0.8 |  | $ | (3.5 | ) |
| Volume/Price Change | $ | 15.0 |  | $ | 7.3 |  | $ | 22.3 |  |
| Sales for 2014 | $ | 226.7 |  | $ | 57.8 |  | $ | 284.5 |  |

[0000038725-14-000158:8k_2_02:17]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the Second Quarter 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 41.7 |  | $ | 13.5 |  | $ | (16.1 | ) | $ | 39.1 |  |
| % Operating Income To Net Sales | 18.4 | % | 23.4 | % |  | 13.7 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.3 |  | $ | — |  | $ | — |  | $ | 0.3 |  |
| Non-GAAP | $ | 0.4 |  | $ | 0.4 |  | $ | 2.5 |  | $ | 3.3 |  |
| Operating Income after Non-GAAP Adjustments | $ | 42.4 |  | $ | 13.9 |  | $ | (13.6 | ) | $ | 42.7 |  |
| % Operating Income to Net Sales After non-GAAP adjustments (Operating Income Margin after Non-GAAP Adjustments) | 18.7 | % | 24.0 | % |  | 15.0 | % |
|  | For the Second Quarter 2013 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 42.7 |  | $ | 10.8 |  | $ | (12.8 | ) | $ | 40.7 |  |
| % Operating Income To Net Sales | 20.0 | % | 21.7 | % |  | 15.5 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.5 |  | $ | 0.2 |  | $ | — |  | $ | 0.7 |  |
| Non-GAAP | $ | 0.1 |  | $ | 0.1 |  | $ | — |  | $ | 0.2 |  |
| Operating Income after Non-GAAP Adjustments | $ | 43.3 |  | $ | 11.1 |  | $ | (12.8 | ) | $ | 41.6 |  |
| % Operating Income to Net Sales After non-GAAP adjustments (Operating Income Margin after Non-GAAP Adjustments) | 20.3 | % | 22.3 | % |  | 15.8 | % |

[0000038725-14-000158:8k_2_02:18]
Water Systems

[0000038725-14-000158:8k_2_02:19]
Water Systems sales were $226.7 million in the second quarter 2014, an increase of $13.0 million or about 6 percent versus the second quarter 2013 sales of $213.7 million.  Sales from businesses acquired since the second quarter of 2013 were $2.3 million or about 1 percent.  Water Systems sales were reduced by $4.3 million or about 2 percent in the quarter due to foreign currency translation.  Water Systems sales growth, excluding acquisitions and foreign currency translation, was about 7 percent.

[0000038725-14-000158:8k_2_02:20]
Water Systems sales in the U.S. and Canada represented 43 percent of consolidated sales and increased by about 7 percent compared to the prior year.  U.S. and Canada sales of groundwater pumping equipment declined about 4 percent in the quarter due, in part, to the regional distributor reset previously announced by the Company and weak demand in the agriculture sector.  Sales of Pioneer branded mobile pumping equipment and surface water pumping equipment grew at a double digit pace in the quarter.  U.S. and Canada sales excluding the impact of foreign currency translation grew by 8 percent compared to the second quarter 2013.

[0000038725-14-000158:8k_2_02:21]
Water Systems sales in the Middle East and Africa were about 12 percent of consolidated sales and were flat compared to the second quarter 2013.  Excluding the impact of foreign currency translation, sales increased by about 9 percent compared to the second quarter 2013. The growth was driven by strong sales of groundwater pumping equipment in Turkey.

[0000038725-14-000158:8k_2_02:22]
Water Systems sales in Latin America were about 11 percent of consolidated sales for the second quarter and increased by about 4 percent compared to the second quarter 2013.  Excluding the impact of foreign currency translation, Latin American sales increased by about 9 percent compared to the second quarter prior year.  Acquisition related sales were about 6 percent of consolidated sales.  After excluding acquisitions and the impact of foreign currency translation, Latin American sales increased 3 percent.  New distribution outlets in Chile and Colombia contributed to significantly increased sales in these markets compared to the second quarter 2013.

[0000038725-14-000158:8k_2_02:23]
During June 2014, the Company completed the acquisition of Bombas Leao S.A. based in Monte Azul Paulista, Brazil.  Bombas Leao is a leading supplier of groundwater pumps principally used in agriculture, industrial and municipal applications.  Additionally, the Company opened its new manufacturing facility in Brazil during the second quarter.

[0000038725-14-000158:8k_2_02:24]
Water Systems sales in Europe were about 9 percent of consolidated sales and grew by about 22 percent compared to the second quarter 2013.  Acquisition related sales were about 3 percent.  The impact of foreign currency translation increased sales by about 4 percent compared to the second quarter 2013.  Excluding acquisitions and the impact of foreign currency translation, European sales increased about 15 percent compared to the second quarter 2013. Sales improvements in Europe were broad based and include the Pioneer rental business in the United Kingdom which had nominal sales in the second quarter 2013.

[0000038725-14-000158:8k_2_02:25]
Water Systems sales in the Asia Pacific region were 5 percent of consolidated sales and declined by about 6 percent compared to the second quarter 2013.  Excluding the impact of foreign currency translation, Asia Pacific sales decreased by about 5 percent compared to the second quarter prior year.  Sales increases in Australia and China were not enough to offset declines in Japan, Korea and Thailand.  Pioneer product sales in the region improved significantly; however, this increase was offset by a double digit decline in other Water Systems pumping equipment sales due to timing of customer orders and the political and economic uncertainty in Thailand.

[0000038725-14-000158:8k_2_02:26]
Water Systems operating income, after non-GAAP adjustments, was $42.4 million in the second quarter 2014, a decrease of about 2 percent versus the second quarter 2013. The second quarter operating income margin after non-GAAP adjustments was 18.7 percent, down 160 basis points from 20.3 percent in the second quarter of 2013.

[0000038725-14-000158:8k_2_02:27]
Water Systems adjusted operating income margin declined in the second quarter due, in part, to a global shift in sales mix including a larger portion of Pioneer dewatering equipment sales.  Additionally, in Asia Pacific, but also Southern Africa and Brazil, a combination of factors, primarily lost leverage on fixed costs, contributed to lower earnings in those regions.  Sales in the U.S. and Canada (excluding Pioneer products) declined marginally; however, profitability for these same sales was flat compared to the second quarter 2013 which improved the operating income margin.  Water Systems adjusted operating income margin also improved for product sales in European and Middle East markets.

[0000038725-14-000158:8k_2_02:28]
Fueling Systems

[0000038725-14-000158:8k_2_02:29]
Fueling Systems sales represented 20 percent of consolidated sales and were $57.8 million in the second quarter 2014, an increase of $8.1 million or about 16 percent versus the second quarter 2013 sales of $49.7 million. Fueling Systems sales increased by $0.8 million or about 1 percent in the quarter due to foreign currency translation. Fueling Systems sales increased 15 percent after excluding foreign currency translation.

[0000038725-14-000158:8k_2_02:30]
During the second quarter, Fueling Systems shipped about $2.0 million of equipment to India to partially fill a large tender order. Excluding the impact of these India tender sales, Fueling Systems sales grew by about 12 percent. Sales growth was across all product lines and all regions of the world, with sales in Brazil, Russia, India and China more than doubling.

[0000038725-14-000158:8k_2_02:31]
Fueling Systems operating income after non-GAAP adjustments was $13.9 million in the second quarter of 2014 compared to $11.1 million after non-GAAP adjustments in the second quarter of 2013, an increase of about 25 percent. The second quarter operating income margin after non-GAAP adjustments was 24.0 percent, an increase of 170 basis points from the 22.3 percent of net sales in the second quarter of 2013. The increase was driven by a combination of productivity, favorable pricing, and synergies from the Flex-ing acquisition.

[0000038725-14-000158:8k_2_02:32]
Overall

[0000038725-14-000158:8k_2_02:33]
The Company’s consolidated gross profit was $99.4 million for the second quarter of 2014, an increase of $4.8 million, or about 5 percent, from the second quarter of 2013 gross profit of $94.6 million. The gross profit as a percent of net sales was 34.9 percent in the second quarter of 2014 down about 100 basis points versus 35.9 percent during the second quarter 2013.  The gross profit margin decrease was primarily due to sales mix and loss of operating leverage in developing regions.

[0000038725-14-000158:8k_2_02:34]
Selling, general, and administrative (SG&A) expenses were $60.0 million in the second quarter of 2014 compared to $53.2 million in the second quarter of prior year, an increase of $6.8 million or about 13 percent.  Increases in SG&A were primarily driven by higher Marketing and Selling expenses in support of higher sales and $3.2 million of costs included in non-GAAP adjustments related to executive transition and pending or completed acquisitions.  After these non-GAAP adjustments, SG&A expenses increased by $3.6 million or about 7 percent from the second quarter 2013.

[0000038725-14-000158:8k_2_02:35]
The Company ended the second quarter of 2014 with a cash balance of $87.7 million, which was $46.9 million lower than at the end of 2013.  The cash balance decrease is primarily attributable to the

[0000038725-14-000158:8k_2_02:36]
seasonality of the business and acquisitions.  The cash balance at the end of the second quarter 2014 increased by 14 percent versus the $77.1 million balance at the end of the second quarter 2013.

[0000038725-14-000158:8k_2_02:37]
Commenting on the outlook for the third quarter of 2014, Mr. Sengstack said:

[0000038725-14-000158:8k_2_02:38]
“As we look forward to the third quarter, the continued weakness in the U.S. agriculture market coupled with the previously announced changes we made to our U.S. distribution footprint in certain regions of the country are causing some customer inventory liquidations and slowing inventory build-up for other customers. In spite of these factors, we are projecting U.S. Water Systems sales up slightly in the third quarter. These inventory adjustments may continue through year-end; however, we are confident that when this activity is complete, we will have stronger overall U.S. distribution relationships and our sales will benefit. Outside the U.S. we expect Europe to continue to post solid results and for our developing regions Water Systems business to strengthen, with the exception of South Africa, where our operation was shut down for most of July due to a nationwide strike. Additionally, we expect sales of Pioneer branded mobile dewatering equipment to continue to be strong in the third quarter, but these sales have a lower overall profitability.   As a result, we are projecting that our third quarter 2014 global Water Systems sales will increase by 8 to 10 percent before acquisitions, and, due to mix, adjusted operating income will grow 3 to 5 percent.

[0000038725-14-000158:8k_2_02:39]
In the third quarter, we estimate that our Fueling Systems sales and adjusted operating earnings will grow by 8 to 10 percent; therefore sequentially, we expect our Fueling Systems business to have similar revenue and operating income that was achieved in the second quarter.

[0000038725-14-000158:8k_2_02:40]
Finally, our consolidated adjusted earnings per share growth is expected to be in the 3 to 5 percent range.”

[0000038725-14-000158:8k_2_02:41]
A conference call to review earnings and other developments in the business will commence at 5:00pm EDT.  The second quarter 2014 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-14-000158:8k_2_02:42]
http://www.media-server.com/m/p/9q23zdaz

[0000038725-14-000158:8k_2_02:43]
If you intend to ask questions during the call, please dial in using (877) 643-7158 for domestic calls and (914) 495-8565 for international calls.

[0000038725-14-000158:8k_2_02:44]
A replay of the conference call will be available Monday, July 28, 2014 at 8pm EDT through midnight EDT on Monday, August 4, 2014, by dialing (855) 859-2056 for domestic calls and (404) 537-3406 for international calls. The replay passcode is: 73673120.

[0000038725-14-000158:8k_2_02:45]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and automotive fuels. Recognized as a technical leader in its specialties, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-14-000158:8k_2_02:46]
The Company presents the non-GAAP financial measures of earnings after non-GAAP adjustments, fully diluted earnings per share after non-GAAP adjustments (or adjusted EPS), operating income after non-GAAP adjustments and percent operating income to net sales after non-GAAP adjustments (or operating income margin after non-GAAP adjustments) because the Company believes the information helps investors understand underlying trends in the Company's business more easily.  The differences between these measures and the most comparable GAAP measures are reconciled in the tables above.

[0000038725-14-000158:8k_2_02:47]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 28, 2014 |  | June 29, 2013 |  | June 28, 2014 |  | June 29, 2013 |
| Net sales | $ | 284,466 |  |  | $ | 263,443 |  |  | $ | 515,887 |  |  | $ | 485,967 |  |
| Cost of sales | 185,072 |  |  | 168,852 |  |  | 338,382 |  |  | 317,435 |  |
| Gross profit | 99,394 |  |  | 94,591 |  |  | 177,505 |  |  | 168,532 |  |
| Selling, general, and administrative expenses | 59,971 |  |  | 53,188 |  |  | 111,986 |  |  | 103,253 |  |
| Restructuring (income)/expense | 295 |  |  | 697 |  |  | 431 |  |  | 1,407 |  |
| Operating income | 39,128 |  |  | 40,706 |  |  | 65,088 |  |  | 63,872 |  |
| Interest expense | (2,510 | ) |  | (2,556 | ) |  | (5,294 | ) |  | (5,146 | ) |
| Other income/(expense) | 871 |  |  | 364 |  |  | 1,196 |  |  | 811 |  |
| Foreign exchange income/(expense) | 328 |  |  | (541 | ) |  | (92 | ) |  | (712 | ) |
| Income before income taxes | 37,817 |  |  | 37,973 |  |  | 60,898 |  |  | 58,825 |  |
| Income taxes | 10,359 |  |  | 9,534 |  |  | 16,019 |  |  | 14,771 |  |
| Net income | $ | 27,458 |  |  | $ | 28,439 |  |  | $ | 44,879 |  |  | $ | 44,054 |  |
| Less: Net income attributable to noncontrolling interests | (384 | ) |  | (304 | ) |  | (848 | ) |  | (463 | ) |
| Net income attributable to Franklin Electric Co., Inc. | $ | 27,074 |  |  | $ | 28,135 |  |  | $ | 44,031 |  |  | $ | 43,591 |  |
| Income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.56 |  |  | $ | 0.59 |  |  | $ | 0.91 |  |  | $ | 0.91 |  |
| Diluted | $ | 0.55 |  |  | $ | 0.58 |  |  | $ | 0.90 |  |  | $ | 0.90 |  |

[0000038725-14-000158:8k_2_02:48]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | June 28, 2014 |  | December 28, 2013 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 87,680 |  |  | $ | 134,553 |  |
| Receivables | 176,110 |  |  | 115,127 |  |
| Inventories | 239,534 |  |  | 191,561 |  |
| Other current assets | 35,254 |  |  | 31,113 |  |
| Total current assets | 538,578 |  |  | 472,354 |  |
| Property, plant, and equipment, net | 215,752 |  |  | 208,596 |  |
| Goodwill and other assets | 412,047 |  |  | 370,923 |  |
| Total assets | $ | 1,166,377 |  |  | $ | 1,051,873 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 75,778 |  |  | $ | 57,755 |  |
| Accrued expenses | 61,619 |  |  | 65,356 |  |
| Current maturities of long-term debt and short-term borrowings | 69,766 |  |  | 15,363 |  |
| Total current liabilities | 207,163 |  |  | 138,474 |  |
| Long-term debt | 175,405 |  |  | 174,166 |  |
| Deferred income taxes | 54,674 |  |  | 54,618 |  |
| Employee benefit plans | 36,825 |  |  | 41,685 |  |
| Other long-term liabilities | 48,827 |  |  | 39,543 |  |
| Redeemable noncontrolling interest | 3,022 |  |  | 5,171 |  |
| Total equity | 640,461 |  |  | 598,216 |  |
| Total liabilities and equity | $ | 1,166,377 |  |  | $ | 1,051,873 |  |

[0000038725-14-000158:8k_2_02:49]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Six Months Ended |
| (In thousands) | June 28, 2014 |  | June 29, 2013 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 44,879 |  |  | $ | 44,054 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 18,173 |  |  | 14,877 |  |
| Share-based compensation | 5,076 |  |  | 3,337 |  |
| Other | (2,336 | ) |  | (2,929 | ) |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (53,359 | ) |  | (48,420 | ) |
| Inventory | (41,858 | ) |  | (20,113 | ) |
| Accounts payable and accrued expenses | 8,307 |  |  | (872 | ) |
| Other | (5,125 | ) |  | 4,460 |  |
| Net cash flows from operating activities | (26,243 | ) |  | (5,606 | ) |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (17,947 | ) |  | (37,017 | ) |
| Proceeds from sale of property, plant, and equipment | 1,623 |  |  | 64 |  |
| Acquisitions and investments | (36,529 | ) |  | — |  |
| Other investing activities | (2,275 | ) |  | 326 |  |
| Net cash flows from investing activities | (55,128 | ) |  | (36,627 | ) |
| Cash flows from financing activities: |  |  |  |
| Change in debt | 49,942 |  |  | 27,231 |  |
| Proceeds from issuance of common stock | 1,184 |  |  | 9,782 |  |
| Excess tax from share-based payment arrangements | 1,678 |  |  | 3,675 |  |
| Purchases of common stock | (6,475 | ) |  | (9,376 | ) |
| Dividends paid | (8,817 | ) |  | (7,113 | ) |
| Purchase of redeemable non-controlling shares | (2,875 | ) |  | — |  |
| Payment of contingent consideration liability | — |  |  | (5,555 | ) |
| Net cash flows from financing activities | 34,637 |  |  | 18,644 |  |
| Effect of exchange rate changes on cash | (139 | ) |  | (2,661 | ) |
| Net change in cash and equivalents | (46,873 | ) |  | (26,250 | ) |
| Cash and equivalents at beginning of period | 134,553 |  |  | 103,338 |  |
| Cash and equivalents at end of period | $ | 87,680 |  |  | $ | 77,088 |  |
