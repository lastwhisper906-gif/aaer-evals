# FELE MD&A — 0000038725-14-000166


## mdna

[0000038725-14-000166:mdna:1]
[same as prior period, unchanged from 0000038725-14-000108:mdna:1]

[0000038725-14-000166:mdna:2]
Second Quarter 2014 vs. Second Quarter 2013

[0000038725-14-000166:mdna:3]
[same as prior period, unchanged from 0000038725-14-000108:mdna:3]

[0000038725-14-000166:mdna:4]
Sales and adjusted earnings in the second quarter of 2014 increased from the second quarter last year.  The sales increase was primarily due to volume increases which were partially offset by the negative impact of foreign currency translation. The Company's consolidated gross profit was $99.4 million for the second quarter of 2014, an increase of $4.8 million or about 5 percent from the prior year’s second quarter.

[0000038725-14-000166:mdna:5]
[same as prior period, unchanged from 0000038725-14-000108:mdna:5]

[0000038725-14-000166:mdna:6]
[same as prior period, unchanged from 0000038725-14-000108:mdna:6]

[0000038725-14-000166:mdna:7]
Net sales in the second quarter of 2014 were $284.5 million, an increase of $21.1 million or about 8 percent compared to 2013 second quarter sales of $263.4 million.  The incremental impact of sales from acquired businesses was $2.3 million or less than 1 percent.  Sales revenue decreased by $3.5 million or about 1 percent in the second quarter of 2014 due to foreign currency translation. The sales change in the second quarter of 2014, excluding acquisitions and foreign currency translation, was an increase of $22.3 million or about 8 percent.

[0000038725-14-000166:mdna:8]
|  | Net Sales |
| (In millions) | Q2 2014 |  | Q2 2013 |  | 2014 v 2013 |
| Water Systems | $ | 226.7 |  |  | $ | 213.7 |  |  | $ | 13.0 |  |
| Fueling Systems | 57.8 |  |  | 49.7 |  |  | 8.1 |  |
| Consolidated | $ | 284.5 |  |  | $ | 263.4 |  |  | $ | 21.1 |  |

[0000038725-14-000166:mdna:9]
[same as prior period, unchanged from 0000038725-14-000108:mdna:9]

[0000038725-14-000166:mdna:10]
Water Systems sales were $226.7 million in the second quarter 2014, an increase of $13.0 million or about 6 percent versus the second quarter 2013 sales of $213.7 million.  Sales from businesses acquired since the second quarter of 2013 were $2.3 million or about 1 percent.  Water Systems sales were reduced by $4.3 million or about 2 percent in the quarter due to foreign currency translation.  Water Systems sales growth, excluding acquisitions and foreign currency translation, was about 7 percent.

[0000038725-14-000166:mdna:11]
Water Systems sales in the U.S. and Canada represented 43 percent of consolidated sales and increased by about 7 percent compared to the prior year.  U.S. and Canada sales of groundwater pumping equipment declined about 4 percent in the quarter due, in part, to the regional distributor reset previously announced by the Company.  Sales of Pioneer branded mobile pumping equipment and surface water pumping equipment grew at double digit pace in the quarter.  U.S. and Canada sales excluding the impact of foreign currency translation grew by 8 percent compared to the second quarter 2013.

[0000038725-14-000166:mdna:12]
Water Systems sales in the Middle East and Africa were about 12 percent of consolidated sales and were flat compared to the second quarter 2013.  Excluding the impact of foreign currency translation, sales increased by about 9 percent compared to the second quarter 2013. The growth was driven by strong sales of groundwater pumping equipment in Turkey.

[0000038725-14-000166:mdna:13]
Water Systems sales in Latin America were about 11 percent of consolidated sales for the second quarter and increased by about 4 percent compared to the second quarter 2013.  Excluding the impact of foreign currency translation, Latin American sales increased by about 9 percent compared to the second quarter prior year.  Acquisition-related sales were about 6 percent.  New distribution outlets in Chile and Columbia contributed to significantly increased sales in these markets compared to the second quarter 2013.

[0000038725-14-000166:mdna:14]
During June 2014, the Company completed the acquisition of Bombas Leao S.A. based in Monte Azul Paulista, Brazil.  Bombas Leao is a leading supplier of groundwater pumps principally used in agriculture, industrial and municipal applications.  Additionally, the Company opened its new manufacturing facility in Brazil during the second quarter.

[0000038725-14-000166:mdna:15]
Water Systems sales in Europe were about 9 percent of consolidated sales and grew by about 22 percent compared to the second quarter 2013.  Acquisition related sales were about 3 percent.  The impact of foreign currency translation increased sales by about 4 percent compared to the second quarter 2013.  Excluding acquisitions and the impact of foreign currency translation,

[0000038725-14-000166:mdna:16]
European sales increased about 15 percent compared to the second quarter 2013. Sales improvements in Europe were broad based and include the Pioneer rental business in the United Kingdom which had nominal sales in the second quarter 2013.

[0000038725-14-000166:mdna:17]
Water Systems sales in the Asia Pacific region were 5 percent of consolidated sales and declined by about 6 percent compared to the second quarter 2013.  Excluding the impact of foreign currency translation, Asia Pacific sales decreased by about 5 percent compared to the second quarter prior year.  Sales increases in Australia and China were not enough to offset declines in Japan, Korea and Thailand.  Pioneer product sales in the region improved significantly; however, this increase was offset by a double digit decline in other Water Systems pumping equipment sales due to timing of customer orders and the current political and economic uncertainty in Thailand.

[0000038725-14-000166:mdna:18]
Water Systems operating income, after non-GAAP adjustments, was $42.4 million in the second quarter 2014, a decrease of about 2 percent versus the second quarter 2013. The second quarter operating income margin after non-GAAP adjustments was 18.7 percent, down 160 basis points from 20.3 percent in the second quarter of 2013.

[0000038725-14-000166:mdna:19]
Water Systems adjusted operating income margin declined in the second quarter in part, due to a global shift in sales mix including a larger portion of Pioneer de-watering equipment sales.  Additionally, in Asia Pacific, but also Southern Africa and Brazil, a combination of factors, primarily lost leverage, contributed to lower earnings in those regions.  While sales in the U.S. and Canada excluding Pioneer products declined marginally, profitability for these same sales was flat compared to the second quarter 2013. Europe adjusted operating income margin also improved.

[0000038725-14-000166:mdna:20]
[same as prior period, unchanged from 0000038725-14-000108:mdna:18]

[0000038725-14-000166:mdna:21]
Fueling Systems sales represented 20 percent of consolidated sales and were $57.8 million in the second quarter 2014, an increase of $8.1 million or about 16 percent versus the second quarter 2013 sales of $49.7 million. Fueling Systems sales increased by $0.8 million or about 1 percent in the quarter due to foreign currency translation. Fueling Systems sales increased 15 percent after excluding foreign currency translation.

[0000038725-14-000166:mdna:22]
During the second quarter, Fueling Systems shipped about $2.0 million of equipment to India to partially fill a large tender order. Excluding the impact of these India tender sales, Fueling Systems sales grew by about 12 percent. Sales growth was across all product lines and all regions of the world, with sales in Brazil, Russia, India and China more than doubling.

[0000038725-14-000166:mdna:23]
[same as prior period, unchanged from 0000038725-14-000108:mdna:21]

[0000038725-14-000166:mdna:24]
Cost of sales as a percent of net sales for the second quarter of 2014 and 2013 was 65.1 percent and 64.1 percent, respectively. Correspondingly, the gross profit margin decreased to 34.9 percent from 35.9 percent, a 100 basis point decline. The Company’s consolidated gross profit was $99.4 million for the second quarter of 2014, an increase of $4.8 million, or about 5 percent, from the second quarter of 2013 gross profit of $94.6 million. The gross profit margin decrease was primarily due to sales mix and loss of operating leverage in developing regions.

[0000038725-14-000166:mdna:25]
[same as prior period, unchanged from 0000038725-14-000108:mdna:23]

[0000038725-14-000166:mdna:26]
Selling, general, and administrative (SG&A) expenses were $60.0 million in the second quarter of 2014 compared to $53.2 million from the second quarter of prior year, an increase of $6.8 million or about 13 percent. There were $3.2 million of costs included in non-GAAP adjustments related to executive transition and pending or completed acquisitions. Excluding these non-GAAP adjustments, SG&A expenses increased by $3.6 million or about 7 percent from the second quarter 2013. In the second quarter 2014, increases in SG&A attributable to acquisitions were $0.5 million. Additional increases in SG&A were primarily driven by higher Marketing and Selling expenses of in support of higher sales and increased research, development and engineering expenses.

[0000038725-14-000166:mdna:27]
[same as prior period, unchanged from 0000038725-14-000108:mdna:25]

[0000038725-14-000166:mdna:28]
Restructuring expenses for the second quarter of 2014 were $0.3 million and had no impact on diluted earnings per share and were primarily severance expenses and other miscellaneous manufacturing realignment activities. Restructuring expenses for the second quarter of 2013 were $0.7 million or about $0.01 diluted earnings per share. Restructuring expenses for the second quarter 2013 included $0.5 million of expenses primarily related to relocation to the new corporate headquarters and engineering center in Fort Wayne, Indiana and $0.2 million related to integration costs of the previously announced Flexing acquisition in Franklin Fueling Systems.

[0000038725-14-000166:mdna:29]
[same as prior period, unchanged from 0000038725-14-000108:mdna:27]

[0000038725-14-000166:mdna:30]
Operating income was $39.1 million in the second quarter of 2014, down $1.6 million or about 4 percent from $40.7 million in the second quarter of 2013.

[0000038725-14-000166:mdna:31]
|  |  | Operating income (loss) |
| (In millions) |  | Q2 2014 |  | Q2 2013 |  | 2014 v 2013 |
| Water Systems |  | $ | 41.7 |  |  | $ | 42.7 |  |  | $ | (1.0 | ) |
| Fueling Systems |  | 13.5 |  |  | 10.8 |  |  | 2.7 |  |
| Other |  | (16.1 | ) |  | (12.8 | ) |  | (3.3 | ) |
| Consolidated |  | $ | 39.1 |  |  | $ | 40.7 |  |  | $ | (1.6 | ) |

[0000038725-14-000166:mdna:32]
There were specific items in the second quarter of 2014 and 2013 that impacted operating income that were not operational in nature.  In the second quarter of 2014 there were three such items: $0.3 million of restructuring charges, $2.5 million related to executive transition and $0.8 million for pending and completed acquisition related activities.  In the second quarter of 2013 there were three such items: $0.7 million of restructuring charges, $0.1 million for acquisition related activities and $0.1 million for certain legal matters.

[0000038725-14-000166:mdna:33]
[same as prior period, unchanged from 0000038725-14-000108:mdna:31]

[0000038725-14-000166:mdna:34]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (In millions) | For the Second Quarter 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 41.7 |  | $ | 13.5 |  | $ | (16.1 | ) | $ | 39.1 |  |
| % Operating Income To Net Sales | 18.4 | % | 23.4 | % |  | 13.7 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.3 |  | $ | — |  | $ | — |  | $ | 0.3 |  |
| Non-GAAP | $ | 0.4 |  | $ | 0.4 |  | $ | 2.5 |  | $ | 3.3 |  |
| Operating Income after Non-GAAP Adjustments | $ | 42.4 |  | $ | 13.9 |  | $ | (13.6 | ) | $ | 42.7 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 18.7 | % | 24.0 | % |  | 15.0 | % |
|  | For the Second Quarter 2013 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 42.7 |  | $ | 10.8 |  | $ | (12.8 | ) | $ | 40.7 |  |
| % Operating Income To Net Sales | 20.0 | % | 21.7 | % |  | 15.5 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.5 |  | $ | 0.2 |  | $ | — |  | $ | 0.7 |  |
| Non-GAAP | $ | 0.1 |  | $ | 0.1 |  | $ | — |  | $ | 0.2 |  |
| Operating Income after Non-GAAP Adjustments | $ | 43.3 |  | $ | 11.1 |  | $ | (12.8 | ) | $ | 41.6 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 20.3 | % | 22.3 | % |  | 15.8 | % |

[0000038725-14-000166:mdna:35]
[same as prior period, unchanged from 0000038725-14-000108:mdna:33]

[0000038725-14-000166:mdna:36]
Water Systems adjusted operating income margin declined in the second quarter due, in part, to a global shift in sales mix including a larger portion of Pioneer de-watering equipment sales.  Additionally, in Asia Pacific, but also Southern Africa and Brazil, a combination of factors, primarily lost leverage, contributed to lower earnings in those regions.  While sales in the U.S.

[0000038725-14-000166:mdna:37]
26

[0000038725-14-000166:mdna:38]
and Canada excluding Pioneer products declined marginally, profitability for these same sales was flat compared to the second quarter 2013. Europe’s adjusted operating income margin also improved.

[0000038725-14-000166:mdna:39]
[same as prior period, unchanged from 0000038725-14-000108:mdna:35]

[0000038725-14-000166:mdna:40]
Fueling Systems operating income after non-GAAP adjustments was $13.9 million in the second quarter of 2014 compared to $11.1 million after non-GAAP adjustments in the second quarter of 2013, an increase of about 25 percent. The second quarter operating income margin after non-GAAP adjustments was 24.0 percent, an increase of 170 basis points from the 22.3 percent of net sales in the second quarter of 2013. The increase was driven by a combination of productivity, favorable pricing, and synergies from the Flexing acquisition.

[0000038725-14-000166:mdna:41]
[same as prior period, unchanged from 0000038725-14-000108:mdna:38]

[0000038725-14-000166:mdna:42]
Operating income-other is composed primarily of unallocated general and administrative expenses.  General and administrative expenses were higher primarily due to depreciation expense and increases in other expenses related to the new Headquarters and Engineering facility in Fort Wayne, Indiana.

[0000038725-14-000166:mdna:43]
[same as prior period, unchanged from 0000038725-14-000108:mdna:40]

[0000038725-14-000166:mdna:44]
Interest expense for the second quarter of 2014 and 2013 was $2.5 million and $2.6 million, respectively.

[0000038725-14-000166:mdna:45]
[same as prior period, unchanged from 0000038725-14-000108:mdna:42]

[0000038725-14-000166:mdna:46]
Other income or expense was income of $0.9 million in the second quarter of 2014 and income of $0.4 million in the second quarter of 2013.  Included in other income in the second quarter of 2014 was interest income of $0.6 million, primarily derived from the investment of cash balances in short-term securities. Included in other income in the second quarter of 2013 was interest income of $0.4 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-14-000166:mdna:47]
[same as prior period, unchanged from 0000038725-14-000108:mdna:44]

[0000038725-14-000166:mdna:48]
Foreign currency-based transactions produced a gain for the second quarter of 2014 of $0.3 million, primarily due to the Canadian dollar which strengthened relative to the U.S. dollar.  Foreign currency-based transactions produced a loss for the second quarter of 2013 of $0.5 million primarily due to the Canadian dollar which weakened relative to the U.S. dollar.

[0000038725-14-000166:mdna:49]
[same as prior period, unchanged from 0000038725-14-000108:mdna:46]

[0000038725-14-000166:mdna:50]
The provision for income taxes in the second quarter of 2014 and 2013 was $10.4 million and $9.5 million, respectively. The effective tax rate for the second quarter of 2014 was about 27 percent, flat to the second quarter of 2013 tax rate before discrete adjustments.  The tax rate as a percentage of pre-tax earnings for the second quarter of 2013 was about 25 percent primarily due the completion of income tax audits and the favorable resolution of matters previously under review.  The average effective tax rate after discrete events for the back half of 2014 is projected to be 25 percent, an improvement of over 150 basis points from the back half of 2013.  The projected tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings and reduced taxes on foreign and repatriated earnings after the restructuring of certain foreign entities.  The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations, current cash on hand and available credit.

[0000038725-14-000166:mdna:51]
[same as prior period, unchanged from 0000038725-14-000108:mdna:48]

[0000038725-14-000166:mdna:52]
Net income for the second quarter of 2014 was $27.5 million compared to the prior year second quarter net income of $28.4 million.  Net income attributable to Franklin Electric Co., Inc. for the second quarter of 2014 was $27.1 million, or $0.55 per diluted share, compared to the prior year second quarter net income attributable to Franklin Electric Co., Inc. of $28.1 million or $0.58 per diluted share. Earnings after non-GAAP adjustments for the second quarter of 2014 were $28.8 million, or $0.60 per diluted share, compared to the prior year second quarter earnings after non-GAAP adjustments of $28.4 million or $0.59 per diluted share.

[0000038725-14-000166:mdna:53]
The Company purchased an additional 10 percent of Impo during the second quarter, increasing its ownership to 90 percent.  The cost of the additional 10 percent was more than the estimated redemption value for the non-controlling interest and the incremental cost was considered a dividend distribution.  Accordingly, earnings per share for the second quarter of 2014 were reduced by about $0.01 for this incremental cost.

[0000038725-14-000166:mdna:54]
There were specific items in the second quarter of 2014 and 2013 that impacted net income attributable to Franklin Electric Co., Inc. that were not operational in nature.  The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of earnings after non-GAAP adjustments and adjusted EPS.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-14-000166:mdna:55]
| Earnings Before and After Non-GAAP Adjustments | For the Second Quarter Ended |
| (In millions) | 2014 | 2013 | Change |
| Net Income attributable to Franklin Electric Co., Inc. Reported | $ | 27.1 |  | $ | 28.1 |  | (4 | )% |
| Allocated Undistributed Earnings | $ | (0.5 | ) | $ | (0.3 | ) |  |
| Adjusted Earnings for EPS Calculations | $ | 26.6 |  | $ | 27.8 |  | (4 | )% |
| Non-GAAP adjustments, before tax: |  |  |  |
| Restructuring | $ | 0.3 |  | $ | 0.7 |  |  |
| Non-GAAP items | $ | 3.3 |  | $ | 0.2 |  |  |
| Non-GAAP adjustments, net of tax: |  |  |  |
| Restructuring | $ | 0.2 |  | $ | 0.4 |  |  |
| Non-GAAP items | $ | 2.0 |  | $ | 0.2 |  |  |
| Net Income attributable to Franklin Electric Co., Inc. after Non-GAAP Adjustments (Adjusted Net Income) | $ | 28.8 |  | $ | 28.4 |  | 1 | % |

[0000038725-14-000166:mdna:56]
| Earnings Per Share Before and After Non-GAAP Adjustments | For the Second Quarter Ended |
| (In millions, except per share data) | 2014 | 2013 | Change |
| Average Fully Diluted Shares Outstanding | 48.2 |  | $ | 48.1 |  | — | % |
| Fully Diluted Earnings Per Share ("EPS") Reported | $ | 0.55 |  | $ | 0.58 |  | (5 | )% |
| Restructuring per Share, net of tax | $ | — |  | $ | 0.01 |  |  |
| Non-GAAP items | $ | 0.05 |  | $ | — |  |  |
| Fully Diluted EPS after Non-GAAP Adjustments (Adjusted EPS) | $ | 0.60 |  | $ | 0.59 |  | 2 | % |

[0000038725-14-000166:mdna:57]
First Half of 2014 vs. First Half of 2013

[0000038725-14-000166:mdna:58]
OVERVIEW

[0000038725-14-000166:mdna:59]
Sales and earnings in the first half of 2014 were up from the same period last year.  The sales increase was related to sales volume and price increases, partially offset by the impact of foreign currency translation. The Company's consolidated gross profit was $177.5 million for the first half of 2014, an increase of $9.0 million or about 5 percent from the first half of 2013.  During the first half of 2014, the Company completed the acquisition of Bombas Leao S.A. based in Monte Azul Paulista, Brazil.  Bombas Leao is a leading supplier of groundwater pumps principally used in agriculture, industrial and municipal applications.  Additionally, the Company opened its new manufacturing facility in Brazil.

[0000038725-14-000166:mdna:60]
RESULTS OF OPERATIONS

[0000038725-14-000166:mdna:61]
Net Sales

[0000038725-14-000166:mdna:62]
Net sales in the first half of 2014 were $515.9 million, an increase of $29.9 million or about 6 percent compared to 2013 first half sales of $486.0 million.  The incremental impact of sales from acquired businesses was $3.1 million or less than 1 percent.  Sales revenue decreased by $11.6 million or about 2 percent in the first half of 2014 due to foreign currency translation. The sales change in the first half of 2014, excluding acquisitions and foreign currency translation, was an increase of $38.4 million or about 8 percent.

[0000038725-14-000166:mdna:63]
28

[0000038725-14-000166:mdna:64]
| (In millions) | YTD June 28, 2014 |  | YTDJune 29, 2013 |  | 2014 v 2013 |
|  | Net Sales |
| Water Systems | $ | 411.3 |  |  | $ | 390.2 |  |  | $ | 21.1 |  |
| Fueling Systems | 104.6 |  |  | 95.8 |  |  | 8.8 |  |
| Consolidated | $ | 515.9 |  |  | $ | 486.0 |  |  | $ | 29.9 |  |

[0000038725-14-000166:mdna:65]
Net Sales-Water Systems

[0000038725-14-000166:mdna:66]
Water Systems sales were $411.3 million in the first half 2014, an increase of $21.1 million or about 5 percent versus the first half 2013. The incremental impact of sales from acquired businesses was $3.1 million or less than 1 percent. Foreign currency translation rate changes decreased sales $13.0 million, or about 3 percent, compared to sales in the first half of 2013. The Water Systems sales change in the first half of 2014, excluding acquisitions and foreign currency translation, was an increase of $31.0 million or about 8 percent.

[0000038725-14-000166:mdna:67]
Water Systems sales in the U.S. and Canada were 41 percent of consolidated sales and grew by 5 percent compared to the first half of 2013. Sales revenue decreased by $1.8 million or about 1 percent in the first half of 2014 due to foreign currency translation. The sales change in the first half of 2014, excluding foreign currency translation, was an increase of $11.5 million or about 6 percent.

[0000038725-14-000166:mdna:68]
Leading the Company's growth in the U.S. and Canada were sales of Pioneer mobile pumping equipment product line. The sales increase is attributable to demand for mobile pumps in the upstream oil and gas market.  These sales gains partially offset declines in groundwater pumping systems for clean water products compared to the first half of the prior year.

[0000038725-14-000166:mdna:69]
Water Systems sales in Latin America were about 12 percent of consolidated sales for the first half and grew by 1 percent compared to the prior year first half.  The incremental impact of sales from acquired businesses was $1.7 million or about 3 percent. Sales revenue decreased by $4.8 million or about 8 percent in the first half of 2014 due to foreign currency translation. The sales change in the first half of 2014, excluding acquisitions and foreign currency translation, was an increase of $3.8 million or about 6 percent.  The first half year-on-year sales increase in Brazil, in local currency, was about 13 percent. The sales growth in Brazil is a result of increasing demand for Franklin submersible pumps and motors, customer acceptance of the many product line upgrades that have been implemented over the past two years, and general market conditions.

[0000038725-14-000166:mdna:70]
Water Systems sales in the Middle East and Africa were about 12 percent of consolidated sales and grew by about 5 percent compared to the first half of 2013.  Water Systems in the Middle East and Africa were reduced by $7.1 million or about 12 percent in the quarter due to foreign currency translation. Excluding the impact of foreign currency translation, sales were up $9.7 million or about 17 percent compared to the first half of 2013. The growth was driven by strong sales of groundwater pumping equipment in Turkey.

[0000038725-14-000166:mdna:71]
Water Systems sales in Europe were about 9 percent of consolidated sales and grew by about 25 percent compared to the first half of 2013.  The incremental impact of sales from acquired businesses was $1.4 million or about 4 percent.  Sales in Europe in the first half of 2014 increased by $1.5 million or about 4 percent due to foreign currency translation. Excluding acquisitions and the impact of foreign currency translation, European sales increased $6.0 million or about 17 percent compared to the first half of 2013.  Sales improvements in Europe were broad based and include the Pioneer rental business in the United Kingdom which had nominal sales in the first half of 2013.

[0000038725-14-000166:mdna:72]
Water Systems sales in the Asia Pacific region were 6 percent of consolidated sales and declined by about 2 percent compared to the first half of the prior year. Sales revenue decreased by about 3 percent in the first half of 2014 due to foreign currency translation. The sales change in the first half of 2014, excluding foreign currency translation, was an increase about 1 percent. Sales increases in Australia, Taiwan and China were not enough to offset declines in Korea and Thailand.

[0000038725-14-000166:mdna:73]
Net Sales-Fueling Systems

[0000038725-14-000166:mdna:74]
Fueling Systems sales were $104.6 million or about 20 percent of consolidated sales in the first half of 2014 and increased $8.8 million or about 9 percent from the first half of 2013. Foreign currency translation rate changes increased sales $1.4 million or about 1 percent compared to sales in the first half of 2013. The Fueling Systems sales change in the first half of 2014, excluding foreign currency translation, was an increase of $7.4 million or about 8 percent.

[0000038725-14-000166:mdna:75]
This growth was driven primarily by sales increases in international markets, which grew by about 15 percent compared to the first half of the prior year, as customers outside North America continue to invest in the Company’s pressure pumping systems

[0000038725-14-000166:mdna:76]
for transferring gasoline from underground tanks.  As well, demand for the Company’s electronic fuel management products is increasing among international customers.  Fueling sales in the U.S. and Canada grew by about 5 percent, as growth of pumping, fuel management, pipe and containment product lines were offset by declines in service station and tank truck hardware.

[0000038725-14-000166:mdna:77]
Cost of Sales

[0000038725-14-000166:mdna:78]
Cost of sales as a percent of net sales for the first half of 2014 and 2013 was 65.6 percent and 65.3 percent, respectively. Correspondingly, the gross profit margin was 34.4 percent and 34.7 percent for both first halves. The Company's consolidated gross profit was $177.5 million for the first half of 2014, up $9.0 million from the gross profit of $168.5 million in the first half of 2013. The gross profit margin increase was primarily due to fixed costs leverage on higher sales and lower direct labor and other variable conversion costs, offset by higher raw material costs.

[0000038725-14-000166:mdna:79]
Selling, General, and Administrative (“SG&A”)

[0000038725-14-000166:mdna:80]
Selling, general, and administrative expenses were $112.0 million in the first half of 2014 and increased by $8.7 million or about 8 percent in the first half of 2014 compared to the first half of last year. There were $3.3 million of costs included in non-GAAP adjustments related to executive transition and pending or completed acquisitions. Excluding these non-GAAP adjustments, SG&A expenses increased by $5.4 million or about 5 percent from the second quarter 2013. In the first half of 2014, increases in SG&A attributable to acquisitions were $0.5 million. Additional increases in SG&A were primarily driven by higher Marketing and Selling expenses of in support of higher sales and increased RD&E expenses.

[0000038725-14-000166:mdna:81]
Restructuring Expenses

[0000038725-14-000166:mdna:82]
Restructuring expenses for the first half of 2014 were $0.4 million and had no impact on diluted earnings per share. Restructuring expenses were primarily severance expenses and other miscellaneous manufacturing realignment activities. Restructuring expenses for the first half of 2013 were $1.4 million and reduced diluted earnings per share by approximately $0.02. Restructuring expenses were primarily severance expenses.

[0000038725-14-000166:mdna:83]
Operating Income

[0000038725-14-000166:mdna:84]
Operating income was $65.1 million in the first half of 2014, up $1.2 million from $63.9 million in the first half of 2013.

[0000038725-14-000166:mdna:85]
| (In millions) |  | YTDJune 28, 2014 |  | YTDJune 29, 2013 |  | 2014 v 2013 |
|  |  | Operating income (loss) |
| Water Systems |  | $ | 71.0 |  |  | $ | 71.4 |  |  | $ | (0.4 | ) |
| Fueling Systems |  | 22.5 |  |  | 17.1 |  |  | 5.4 |  |
| Other |  | (28.4 | ) |  | (24.6 | ) |  | (3.8 | ) |
| Consolidated |  | $ | 65.1 |  |  | $ | 63.9 |  |  | $ | 1.2 |  |

[0000038725-14-000166:mdna:86]
There were specific items in the first half of 2014 and 2013 that impacted operating income that were not operational in nature.

[0000038725-14-000166:mdna:87]
In the first half of 2014 they were as follows:

[0000038725-14-000166:mdna:88]
| • | In the first half of 2014, there were $0.4 million of restructuring charges. Restructuring expenses were primarily severance expenses and other miscellaneous manufacturing realignment activities. |

[0000038725-14-000166:mdna:89]
| • | The first half of 2014 included $2.5 million related to executive transition. |

[0000038725-14-000166:mdna:90]
| • | The first half of 2014 included $0.9 million in other miscellaneous costs related to pending acquisitions. |

[0000038725-14-000166:mdna:91]
In the first half of 2013 they were as follows:

[0000038725-14-000166:mdna:92]
| • | In the first half of 2013, there were $1.4 million of restructuring charges. Restructuring expenses were primarily severance expenses of $1.0 million, and other miscellaneous manufacturing realignment activities. As well as $0.4 million related to relocation to the new corporate headquarters and engineering center in Fort Wayne, Indiana. |

[0000038725-14-000166:mdna:93]
| • | The first half of 2013 included $0.5 million of legal fees incurred in Franklin Fueling Systems. |

[0000038725-14-000166:mdna:94]
| • | The second quarter of 2013 included $0.1 million in other miscellaneous costs related to pending acquisitions. |

[0000038725-14-000166:mdna:95]
The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of operating income after non-GAAP adjustments and percent operating income after non-GAAP adjustments to net sales.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the

[0000038725-14-000166:mdna:96]
following tables:

[0000038725-14-000166:mdna:97]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the First Half of 2014 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 71.0 |  | $ | 22.5 |  | $ | (28.4 | ) | $ | 65.1 |  |
| % Operating Income To Net Sales | 17.3 | % | 21.5 | % |  | 12.6 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 0.4 |  | $ | — |  | $ | — |  | $ | 0.4 |  |
| Non-GAAP | $ | 0.5 |  | $ | 0.4 |  | $ | 2.5 |  | $ | 3.4 |  |
| Operating Income after Non-GAAP Adjustments | $ | 71.9 |  | $ | 22.9 |  | $ | (25.9 | ) | $ | 68.9 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 17.5 | % | 21.9 | % |  | 13.4 | % |
|  | For the First Half of 2013 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income | $ | 71.4 |  | $ | 17.1 |  | $ | (24.6 | ) | $ | 63.9 |  |
| % Operating Income To Net Sales | 18.3 | % | 17.8 | % |  | 13.1 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 1.0 |  | $ | 0.4 |  | $ | — |  | $ | 1.4 |  |
| Non-GAAP | $ | 0.1 |  | $ | 0.5 |  | $ | — |  | $ | 0.6 |  |
| Operating Income after Non-GAAP Adjustments | $ | 72.5 |  | $ | 18.0 |  | $ | (24.6 | ) | $ | 65.9 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 18.6 | % | 18.8 | % |  | 13.6 | % |

[0000038725-14-000166:mdna:98]
Operating Income-Water Systems

[0000038725-14-000166:mdna:99]
Water Systems operating income, after non-GAAP adjustments, was $71.9 million in the first half of 2014 compared to $72.5 million after non-GAAP adjustments in the first half of 2013, a decrease of 1 percent. The first half operating income margin after non-GAAP adjustments was 17.5 percent and decreased by 110 basis points compared to the first half of 2013. Operating income margin after non-GAAP adjustments decreased in Water Systems primarily due to sales mix, loss of operating leverage in some developing regions, and continued investment in sales growth initiatives.

[0000038725-14-000166:mdna:100]
Operating Income-Fueling Systems

[0000038725-14-000166:mdna:101]
Fueling Systems operating income after non-GAAP adjustments was $22.9 million in the first half of 2014 compared to $18.0 million after non-GAAP adjustments in the first half of 2013, an increase of 27 percent. The first half operating income margin after non-GAAP adjustments was 21.9 percent and increased by 310 basis points compared to the 18.8 percent of net sales in the first half of 2013 due to sales growth and expense control.

[0000038725-14-000166:mdna:102]
Operating Income-Other

[0000038725-14-000166:mdna:103]
Operating income-other is composed primarily of unallocated general and administrative expenses.  General and administrative expenses were higher primarily due to depreciation expense and increases in other expenses related to the new Headquarters and Engineering facility in Fort Wayne, Indiana.

[0000038725-14-000166:mdna:104]
Interest Expense

[0000038725-14-000166:mdna:105]
Interest expense for the first half of 2014 and 2013 was $5.3 million and $5.1 million, respectively.

[0000038725-14-000166:mdna:106]
Other Income or Expense

[0000038725-14-000166:mdna:107]
Other income or expense was a gain of $1.2 million in the first half of 2014.  Included in other income in the first half of 2014 was interest income of $0.9 million, primarily derived from the investment of cash balances in short-term securities. The first

[0000038725-14-000166:mdna:108]
half of 2013 was a gain of $0.8 million.  Included in other income was interest income of $0.8 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-14-000166:mdna:109]
Foreign Exchange

[0000038725-14-000166:mdna:110]
Foreign currency-based transactions produced a loss for the first half of 2014 of $0.1 million, primarily due to several currency rate changes relative to the U.S. dollar.  Foreign currency-based transactions produced a loss for the first half of 2013 of $0.7 million, primarily due to several currency rate changes relative to the U.S. dollar, the largest being the Canadian dollar.

[0000038725-14-000166:mdna:111]
Income Taxes

[0000038725-14-000166:mdna:112]
The provision for income taxes in the first half of 2014 and 2013 was $16.0 million and $14.8 million, respectively. The effective tax rate for the second quarter of 2014 was about 27 percent, flat to the second quarter of 2013 tax rate before discrete adjustments.  The tax rate as a percentage of pre-tax earnings for the second quarter of 2013 was about 25 percent primarily due the completion of income tax audits and the favorable resolution of matters previously under review.  The average effective tax rate after discrete events for the back half of 2014 is projected to be 25 percent, an improvement of over 150 basis points from the back half of 2013.  The projected tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings and reduced taxes on foreign and repatriated earnings after the restructuring of certain foreign entities.  The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations, current cash on hand and available credit.

[0000038725-14-000166:mdna:113]
Net Income

[0000038725-14-000166:mdna:114]
Net income for the first half of 2014 was $44.9 million compared to 2013 first half net income of $44.1 million.  Net income attributable to Franklin Electric Co., Inc. for the first half of 2014 was $44.0 million, or $0.90 per diluted share, compared to 2013 first half net income attributable to Franklin Electric Co., Inc. of $43.6 million or $0.90 per diluted share. Earnings after non-GAAP adjustments for the first half of 2014 were $45.6 million, or $0.95 per diluted share, compared to the prior year first half earnings after non-GAAP adjustments of $44.3 million or $0.93 per diluted share.

[0000038725-14-000166:mdna:115]
There were specific items in the second quarter of 2014 and 2013 that impacted net income attributable to Franklin Electric Co., Inc. that were not operational in nature.  The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of earnings after non-GAAP adjustments and adjusted EPS.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-14-000166:mdna:116]
| Earnings Before and After Non-GAAP Adjustments | For the First Half |
| (in millions) | 2014 | 2013 | Change |
| Net Income attributable to Franklin Electric Co., Inc. Reported | $ | 44.0 |  | $ | 43.6 |  | 1 | % |
| Allocated Undistributed Earnings | $ | (0.7 | ) | $ | (0.5 | ) |  |
| Adjusted Earnings for EPS Calculation | $ | 43.3 |  | $ | 43.1 |  | — | % |
| Non-GAAP adjustments (before tax): |  |  |  |
| Restructuring | $ | 0.4 |  | $ | 1.4 |  |  |
| Non-GAAP items | $ | 3.4 |  | $ | 0.6 |  |  |
| Non-GAAP adjustments, net of tax: |  |  |  |
| Restructuring | $ | 0.2 |  | $ | 0.8 |  |  |
| Non-GAAP items | $ | 2.1 |  | $ | 0.4 |  |  |
| Earnings after Non-GAAP Adjustments | $ | 45.6 |  | $ | 44.3 |  | 3 | % |

[0000038725-14-000166:mdna:117]
| Earnings Per Share Before and After Non-GAAP Adjustments | For the First Half |
| (in millions except Earnings Per Share) | 2014 | 2013 | Change |
| Average Fully Diluted Shares Outstanding | 48.3 |  | 48.0 |  | 1 | % |
| Fully Diluted Earnings Per Share ("EPS") Reported | $ | 0.90 |  | $ | 0.90 |  | — | % |
| Restructuring Per Share, net of tax | $ | — |  | $ | 0.02 |  |  |
| Non-GAAP items | $ | 0.05 |  | $ | 0.01 |  |  |
| Fully Diluted EPS after Non-GAAP Adjustments (Adjusted EPS) | $ | 0.95 |  | $ | 0.93 |  | 2 | % |

[0000038725-14-000166:mdna:118]
[same as prior period, unchanged from 0000038725-14-000108:mdna:53]

[0000038725-14-000166:mdna:119]
[same as prior period, unchanged from 0000038725-14-000108:mdna:54]

[0000038725-14-000166:mdna:120]
The Company has a committed, unsecured, revolving credit agreement maturing on December 14, 2016 (the “Revolver”) in the amount of $150.0 million. As of June 28, 2014, the Company had $96.4 million borrowing capacity under the Revolver as $5.4 million in letters of credit were outstanding and undrawn and $48.2 million of revolver borrowing had been drawn and was outstanding at the end of the quarter.

[0000038725-14-000166:mdna:121]
The Company also has an amended and restated uncommitted note purchase and private shelf agreement (the “Prudential Agreement”) in the amount of $200.0 million, with $150.0 million of notes issued thereunder beginning to mature in 2015. The Company has no scheduled principal payments under the Prudential Agreement until 2015 at which time it amortizes for 5 years at an amount of $30.0 million per year. As of June 28, 2014, the Company had $50.0 million borrowing capacity under the Prudential Agreement.

[0000038725-14-000166:mdna:122]
On December 31, 2012, the Company, Allen County, Indiana and certain institutional investors entered into a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project).” The aggregate principal amount of the Project Bonds that were issued, authenticated, and outstanding thereunder was limited to $25.0 million. The Company then borrowed the proceeds under the Project Bonds through the issuance of Project Notes to finance the cost of acquisition, construction, installation, and equipping of the new Global Corporate Headquarters and Engineering Center of Excellence. The Project Notes (tax increment financing debt) bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033. The use of the proceeds from the Project Notes was limited to assist in the financing of the new Global Corporate Headquarters and Engineering Center of Excellence.

[0000038725-14-000166:mdna:123]
The Revolver, the Prudential Agreement, and the tax increment financing debt contain customary affirmative and negative covenants. The affirmative covenants include financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans or advances, investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Revolver, the Prudential Agreement, and the tax increment financing debt, but only if the Company is defaulting on an obligation exceeding $10.0 million. As of June 28, 2014, the Company was in compliance with all covenants.  The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-14-000166:mdna:124]
At June 28, 2014, the Company had $87.7 million of cash and equivalents at various locations worldwide. Approximately 23 percent of the cash and equivalents was in U.S. and Canada entities and readily accessible.  Approximately 46 percent was in various European subsidiaries, and 17 percent was in Mexico and Brazil. On a regular basis the Company reviews international cash balances and, if appropriate based on forecasted expenditures and considerations for the post-tax economic efficiency, will reposition cash among its global entities. Cash investments worldwide are invested according to a written policy and are generally in bank demand accounts and bank time deposits with the preservation of principal as the highest priority. Also, historically the Company has generally sourced inputs and sold outputs both in the local currency of operations on a country by country basis, thereby insulating local cash balances from currency volatility.

[0000038725-14-000166:mdna:125]
Net use of cash from operating activities was $26.2 million for the six months ended June 28, 2014 compared to $5.6 million for the six months ended June 29, 2013.  The use of cash increased during the first half of 2014 primarily due to increases in inventory balances for the seasonal inventory build and anticipated increase in Pioneer rental product demand, and due to increases in accounts receivable due to higher sales.

[0000038725-14-000166:mdna:126]
Net cash used in investing activities was $55.1 million for the six months ended June 28, 2014, compared to $36.6 million for the six months ended June 29, 2013.  The increase can be attributed to spending for acquisitions and equity investments during the first half of 2014.  During the second quarter of 2014, the Company completed the acquisition of Bombas Leao with cash on hand and short-term borrowings.  In evaluating potential future acquisitions that impact cash from investing, the Company reviews opportunities with an emphasis on increasing global distribution and also with an emphasis on adding complementary product lines that can be effectively marketed through existing global distribution. Additions to property, plant and equipment were significantly lower in the first half of 2014 compared to first half of 2013. During 2013 the Company’s higher capital spending was due to the Global Corporate Headquarters and Engineering Center project.

[0000038725-14-000166:mdna:127]
Net cash provided by financing activities was $34.6 million for the six months ended June 28, 2014, compared to $18.6 million for the six months ended June 29, 2013. The primary increase in cash provided by financing activities in the first half of 2014 is attributed to revolver borrowings for acquisitions.  In 2013, the primary source of proceeds from debt was $25.0 million from the TIF debt proceeds received in the first quarter.  In addition, stock option exercises were significantly lower in the first half of 2014 compared to the first half of 2013.

[0000038725-14-000166:mdna:128]
FACTORS THAT MAY AFFECT FUTURE RESULTS
