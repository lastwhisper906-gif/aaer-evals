# FELE 8-K — 0000038725-26-000022 filed 2026-04-28

## item codes, every 8-K on or before 2026-04-29

- 2026-04-28 0000038725-26-000024 — 7.01, 9.01
- 2026-04-28 0000038725-26-000022 — 2.02, 9.01
- 2026-02-26 0000038725-26-000015 — 7.01, 9.01
- 2026-02-18 0000038725-26-000006 — 7.01, 9.01
- 2026-02-17 0000038725-26-000004 — 7.01, 9.01
- 2026-02-17 0000038725-26-000002 — 2.02, 9.01
- 2025-11-13 0000038725-25-000180 — 7.01, 9.01
- 2025-10-28 0000038725-25-000176 — 7.01, 9.01
- 2025-10-28 0000038725-25-000174 — 2.02, 9.01
- 2025-10-02 0000038725-25-000172 — 1.01, 2.03, 9.01
- 2025-07-29 0000038725-25-000160 — 7.01, 9.01
- 2025-07-29 0000038725-25-000158 — 2.02, 9.01
- 2025-07-28 0000038725-25-000156 — 1.01, 8.01, 9.01
- 2025-07-11 0000038725-25-000153 — 5.02, 7.01, 9.01
- 2025-06-13 0000038725-25-000144 — 1.01, 8.01, 9.01
- 2025-05-20 0000038725-25-000117 — 2.03, 9.01
- 2025-05-08 0000038725-25-000108 — 5.02, 9.01
- 2025-05-06 0000038725-25-000104 — 7.01, 9.01
- 2025-05-05 0000038725-25-000088 — 5.02, 5.07
- 2025-04-29 0000038725-25-000080 — 7.01, 9.01
- 2025-04-29 0000038725-25-000078 — 2.02, 9.01
- 2025-04-03 0000038725-25-000066 — 5.02, 9.01
- 2025-02-28 0000038725-25-000054 — 7.01, 9.01
- 2025-02-24 0000038725-25-000040 — 5.02
- 2025-02-18 0000038725-25-000013 — 7.01, 9.01
- 2025-02-18 0000038725-25-000011 — 2.02, 9.01
- 2025-02-14 0000038725-25-000009 — 7.01, 9.01
- 2024-11-12 0000038725-24-000175 — 7.01, 9.01
- 2024-11-06 0000038725-24-000169 — 7.01, 9.01
- 2024-10-29 0000038725-24-000164 — 7.01, 9.01
- 2024-10-29 0000038725-24-000162 — 2.02, 9.01
- 2024-07-24 0000038725-24-000140 — 7.01, 9.01
- 2024-07-23 0000038725-24-000138 — 2.02, 9.01
- 2024-07-01 0000038725-24-000132 — 5.02
- 2024-05-22 0000038725-24-000119 — 5.02, 9.01 — amendment of 0000038725-24-000101
- 2024-05-16 0000038725-24-000105 — 1.01, 2.03, 9.01
- 2024-05-14 0000038725-24-000101 — 5.02, 7.01, 9.01
- 2024-05-03 0000038725-24-000097 — 7.01, 9.01
- 2024-05-03 0000038725-24-000096 — 5.07
- 2024-04-30 0000038725-24-000074 — 2.02, 9.01
- 2024-02-13 0000038725-24-000012 — 7.01, 9.01
- 2024-02-13 0000038725-24-000010 — 2.02, 9.01
- 2023-11-06 0000038725-23-000184 — 7.01, 9.01
- 2023-10-24 0000038725-23-000177 — 2.02, 9.01
- 2023-08-04 0000038725-23-000160 — 5.02, 9.01
- 2023-08-03 0000038725-23-000158 — 7.01, 9.01
- 2023-07-25 0000038725-23-000149 — 2.02, 9.01
- 2023-07-05 0000038725-23-000144 — 5.02, 7.01, 9.01
- 2023-05-09 0000038725-23-000094 — 5.02, 9.01
- 2023-05-09 0000038725-23-000092 — 5.07
- 2023-05-08 0000038725-23-000087 — 7.01, 9.01
- 2023-05-02 0000038725-23-000065 — 2.02, 9.01
- 2023-03-08 0000038725-23-000046 — 7.01, 9.01
- 2023-02-21 0000038725-23-000016 — 8.01, 9.01
- 2023-02-14 0000038725-23-000002 — 2.02, 9.01
- 2022-10-28 0000038725-22-000180 — 7.01, 9.01
- 2022-10-25 0000038725-22-000177 — 2.02, 9.01
- 2022-08-04 0000038725-22-000150 — 7.01, 9.01
- 2022-07-26 0000038725-22-000142 — 2.02, 9.01
- 2022-05-11 0000038725-22-000106 — 2.03, 9.01
- 2022-05-06 0000038725-22-000082 — 5.07
- 2022-05-06 0000038725-22-000081 — 5.02, 9.01
- 2022-05-03 0000038725-22-000075 — 7.01, 9.01
- 2022-04-26 0000038725-22-000073 — 2.02, 9.01
- 2022-03-24 0000038725-22-000056 — 5.02, 9.01
- 2022-03-08 0000038725-22-000049 — 7.01, 9.01
- 2022-02-15 0000038725-22-000007 — 2.02, 9.01
- 2022-01-04 0000038725-22-000002 — 7.01, 9.01
- 2021-11-03 0000038725-21-000212 — 7.01, 9.01
- 2021-10-26 0000038725-21-000203 — 2.02, 9.01
- 2021-07-27 0000038725-21-000172 — 7.01, 9.01
- 2021-07-27 0000038725-21-000170 — 2.02, 9.01
- 2021-06-14 0000038725-21-000157 — 5.02, 7.01, 9.01
- 2021-05-17 0000038725-21-000120 — 7.01, 9.01
- 2021-05-17 0000038725-21-000118 — 7.01, 9.01
- 2021-05-13 0000038725-21-000102 — 2.03, 9.01
- 2021-05-07 0000038725-21-000096 — 5.07
- 2021-05-07 0000038725-21-000094 — 5.02, 9.01
- 2021-04-27 0000038725-21-000088 — 7.01, 9.01
- 2021-04-27 0000038725-21-000085 — 2.02, 9.01
- 2021-04-01 0000038725-21-000080 — 7.01, 9.01
- 2021-02-17 0000038725-21-000013 — 7.01, 9.01
- 2021-02-16 0000038725-21-000010 — 2.02, 9.01
- 2021-01-04 0000038725-21-000003 — 7.01, 9.01
- 2020-12-18 0000038725-20-000241 — 5.02, 9.01
- 2020-11-09 0000038725-20-000223 — 7.01, 9.01
- 2020-11-02 0000038725-20-000210 — 7.01, 9.01
- 2020-10-27 0000038725-20-000206 — 2.02, 9.01
- 2020-07-28 0000038725-20-000168 — 2.02, 9.01
- 2020-06-25 0000038725-20-000164 — 8.01, 9.01
- 2020-06-25 0000038725-20-000163 — 8.01, 9.01
- 2020-05-11 0000038725-20-000133 — 5.02, 9.01
- 2020-05-08 0000038725-20-000119 — 5.07
- 2020-05-06 0000038725-20-000111 — 5.02, 9.01
- 2020-04-28 0000038725-20-000104 — 2.02, 9.01
- 2020-02-18 0000038725-20-000018 — 2.02, 9.01
- 2020-01-30 0000038725-20-000009 — 5.02, 5.03, 9.01
- 2019-11-04 0000038725-19-000234 — 7.01, 9.01
- 2019-10-29 0000038725-19-000221 — 2.02, 9.01
- 2019-08-01 0000038725-19-000193 — 7.01, 9.01
- 2019-07-23 0000038725-19-000178 — 2.02, 9.01
- 2019-05-07 0000038725-19-000140 — 5.03, 9.01
- 2019-05-03 0000038725-19-000124 — 5.07
- 2019-05-03 0000038725-19-000122 — 7.01, 9.01
- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2026-04-29

- none on or before 2026-04-29

## item 2.02 — earnings release, exhibit 99.1

[0000038725-26-000022:8k_2_02:1]
EX-99.1
2
a20260428ex991earningsrele.htm
EX-99.1

[0000038725-26-000022:8k_2_02:2]
Document

[0000038725-26-000022:8k_2_02:3]
Exhibit 99.1

[0000038725-26-000022:8k_2_02:4]
NEWS RELEASE FOR IMMEDIATE DISTRIBUTION

[0000038725-26-000022:8k_2_02:5]
FRANKLIN ELECTRIC REPORTS FIRST QUARTER 2026 RESULTS

[0000038725-26-000022:8k_2_02:6]
First Quarter 2026 Highlights

[0000038725-26-000022:8k_2_02:7]
•Consolidated net sales of $500.4 million, an increase of 10% to the prior year

[0000038725-26-000022:8k_2_02:8]
•Net sales increased across all three segments: 11% in Water Systems, 7% in Energy Systems, and 6% in Distribution

[0000038725-26-000022:8k_2_02:9]
•Operating income was $48.1 million, an increase of 9% to the prior year, with operating margin of 9.6%

[0000038725-26-000022:8k_2_02:10]
•GAAP fully diluted earnings per share (EPS) was $0.77, an increase of 15 percent; Adjusted diluted EPS was $0.831, an increase of 24 percent

[0000038725-26-000022:8k_2_02:11]
Fort Wayne, IN – April 28, 2026 – Franklin Electric Co., Inc. today announced its first quarter financial results for fiscal year 2026.

[0000038725-26-000022:8k_2_02:12]
First quarter 2026 net sales were $500.4 million compared to first quarter 2025 net sales of $455.2 million. First quarter 2026 operating income was $48.1 million, compared to first quarter 2025 operating income of $44.1 million. First quarter 2026 diluted EPS was $0.77, compared to first quarter 2025 EPS of $0.67. First quarter adjusted diluted EPS1 was $0.83, compared to 2025 first quarter adjusted diluted EPS1 of $0.67.

[0000038725-26-000022:8k_2_02:13]
1 – Adjusted diluted EPS is a non-GAAP measure.  Please refer to our Note Regarding Non-GAAP Financial Measures below for further explanation as well as the final page of this release for a reconciliation of non-GAAP measures to the appropriate GAAP measure.

[0000038725-26-000022:8k_2_02:14]
“Our teams delivered a strong start to 2026, with first quarter results in line with our expectations and reflecting solid execution across the business.  Sales increased nearly 10 percent year‑over‑year, driven by higher volumes, effective pricing, and incremental contributions from acquisitions, while operating income and adjusted earnings grew meaningfully faster than revenue.  We remain focused on driving profitable growth through our investment in innovation, focus on faster growing markets, disciplined pricing, and productivity initiatives, while continuing to enhance our global manufacturing footprint to better serve our customers,” commented Joe Ruzynski, Franklin Electric’s CEO.

[0000038725-26-000022:8k_2_02:15]
“While we continue to closely monitor the global macroeconomic and geopolitical environment, underlying demand and order activity remain healthy. As we move through the year, our focus remains on executing our strategy to deliver volume growth predictably and efficiently. With improving operating margins and a strong balance sheet, we are well positioned to support our customers and drive profitable growth while delivering long term value for our shareholders,” concluded Mr. Ruzynski.

[0000038725-26-000022:8k_2_02:16]
Segment Summaries

[0000038725-26-000022:8k_2_02:17]
Water Systems net sales were $318.0 million in the first quarter, an increase of $30.7 million or 11 percent compared to the first quarter of 2025. The incremental sales were driven by higher volume and price realization, favorable foreign exchange, and the incremental sales impact of recent acquisitions.  Water Systems operating income in the first quarter of 2026 was $44.4 million, an increase of 2 percent over first quarter 2025 operating income of $43.4 million. Water Systems operating income in the first quarter of 2026 included $3.9 million of restructuring expense compared to $0.0 million in the first quarter of 2025.  Water Systems adjusted operating income2 was $48.3 million, an increase of 11 percent over the first quarter of 2025 adjusted operating income2 of $43.4 million.

[0000038725-26-000022:8k_2_02:18]
Distribution net sales were $150.9 million, an increase of $9.0 million or 6 percent compared to the first quarter of 2025. Sales increases were driven by higher volumes and price realization. The Distribution segment operating income in the first quarter 2026 was $3.0 million, an increase of 43 percent over first quarter 2025 operating income of $2.1 million. Distribution operating income in the first quarter of 2026 included $0.0 million of restructuring expense compared to $0.2 million in the first quarter of 2025.  Distribution adjusted operating income2 was $3.0 million, an increase of 30 percent over the first quarter of 2025 adjusted operating income2 of $2.3 million.

[0000038725-26-000022:8k_2_02:19]
Energy Systems net sales were $71.8 million in the first quarter 2026, an increase of $5.0 million or 7 percent compared to the first quarter 2025. Sales increases were driven by higher volumes and price realization. Energy Systems operating income in the first quarter of 2026 was $24.2 million, an increase of 11 percent over first quarter 2025 operating income of $21.9 million.

[0000038725-26-000022:8k_2_02:20]
2 – Adjusted operating income is a non-GAAP measure.  Please refer to our Note Regarding Non-GAAP Financial Measures below for further explanation as well as the final page of this release for a reconciliation of non-GAAP measures to the appropriate GAAP measure.

[0000038725-26-000022:8k_2_02:21]
2026 Guidance

[0000038725-26-000022:8k_2_02:22]
The Company is maintaining its guidance for full year 2026 net sales to be in the range of $2.17 billion to $2.24 billion and full year 2026 Adjusted Diluted EPS to be in the range of $4.40 to $4.60.

[0000038725-26-000022:8k_2_02:23]
Earnings Conference Call

[0000038725-26-000022:8k_2_02:24]
A conference call to review earnings and other developments in the business will commence at 11:00 am ET. The first quarter 2026 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-26-000022:8k_2_02:25]
https://edge.media-server.com/mmc/p/h2get6o9

[0000038725-26-000022:8k_2_02:26]
For those interested in participating in the question-and-answer portion of the call, please register for the call at the link below.

[0000038725-26-000022:8k_2_02:27]
https://register-conf.media-server.com/register/BIcf2a85f3283f459faa88aeb69269ccab

[0000038725-26-000022:8k_2_02:28]
All registrants will receive dial-in information and a PIN allowing them to access the live call. It is recommended that you join 10 minutes prior to the event start (although you may register and dial in at any time during the call).

[0000038725-26-000022:8k_2_02:29]
A replay of the conference call will be available from Tuesday, April 28, 2026, through 11:00 am ET on Tuesday, May 5, 2026, by visiting the listen-only webcast link above.

[0000038725-26-000022:8k_2_02:30]
Forward Looking Statements

[0000038725-26-000022:8k_2_02:31]
and other risks which are detailed in the Company’s Securities and Exchange Commission filings, included in Item 1A of Part I of the Company’s Annual Report on Form 10-K for the fiscal year ending December 31, 2025, Exhibit 99.1 attached thereto and in Item 1A of Part II of the Company’s Quarterly Reports on Form 10-Q. These risks and uncertainties may cause actual results to differ materially from those indicated by the forward-looking statements. All forward-looking statements made herein are based on information currently available, and the Company assumes no obligation to update any forward-looking statements.

[0000038725-26-000022:8k_2_02:32]
Note Regarding Non-GAAP Financial Measures

[0000038725-26-000022:8k_2_02:33]
The company reports its financial results in accordance with U.S. generally accepted accounting principles (GAAP). Management believes that the non-GAAP financial measure Adjusted Diluted EPS and Adjusted Operating Income provide additional meaningful information regarding the company’s performance and financial strength. Non-GAAP financial measures should be viewed in addition to and not as an alternative for the company’s reported results prepared in accordance with GAAP. In addition, not all companies use identical calculations for Adjusted Diluted EPS and Adjusted Operating Income; therefore, Adjusted Diluted EPS and Adjusted Operating Income included in this release may not be comparable to similarly titled measures of other companies.  Adjusted Diluted EPS and Adjusted Operating Income are defined and reconciled to what management believes to be the most comparable GAAP measures in a schedule at the end of this release, except for forward-looking measures where a reconciliation to the corresponding GAAP measures is not available due to the variability, complexity and limited visibility of the items that are excluded from the non-GAAP outlook measure.

[0000038725-26-000022:8k_2_02:34]
About Franklin Electric

[0000038725-26-000022:8k_2_02:35]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and energy. Recognized as a technical leader in its products and services, Franklin Electric serves customers worldwide in residential, commercial, agricultural, industrial, municipal and fueling applications. Franklin Electric is proud to be recognized in Newsweek’s lists of America’s Most Responsible Companies 2025, Most Trustworthy Companies 2025, and Greenest Companies 2025.

[0000038725-26-000022:8k_2_02:36]
Franklin Electric Contact:

[0000038725-26-000022:8k_2_02:37]
Jennifer Wolfenbarger / Dean Cantrell

[0000038725-26-000022:8k_2_02:38]
Franklin Electric Co., Inc.

[0000038725-26-000022:8k_2_02:39]
InvestorRelations@fele.com

[0000038725-26-000022:8k_2_02:40]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |  |  |  |  |
|  | First Quarter Ended |  |  |  |  |
|  | March 31, 2026 |  | March 31, 2025 |  |  |  |  |  |  |  |  |
| Net sales | $ | 500,437 |  |  | $ | 455,247 |  |  |  |  |  |  |  |  |  |
| Cost of sales | 325,468 |  |  | 291,344 |  |  |  |  |  |  |  |  |  |
| Gross profit | 174,969 |  |  | 163,903 |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative expenses | 123,012 |  |  | 119,643 |  |  |  |  |  |  |  |  |  |
| Restructuring expense | 3,872 |  |  | 159 |  |  |  |  |  |  |  |  |  |
| Operating income | 48,085 |  |  | 44,101 |  |  |  |  |  |  |  |  |  |
| Interest expense | (2,311) |  |  | (1,799) |  |  |  |  |  |  |  |  |  |
| Other income (expense), net | (374) |  |  | 843 |  |  |  |  |  |  |  |  |  |
| Foreign exchange income (expense), net | 375 |  |  | (1,293) |  |  |  |  |  |  |  |  |  |
| Income before income taxes | 45,775 |  |  | 41,852 |  |  |  |  |  |  |  |  |  |
| Income tax expense | 11,080 |  |  | 10,478 |  |  |  |  |  |  |  |  |  |
| Net income | $ | 34,695 |  |  | $ | 31,374 |  |  |  |  |  |  |  |  |  |
| Less: Net income attributable to noncontrolling interests | (365) |  |  | (412) |  |  |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 34,330 |  |  | $ | 30,962 |  |  |  |  |  |  |  |  |  |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 0.77 |  |  | $ | 0.67 |  |  |  |  |  |  |  |  |  |
| Diluted | $ | 0.77 |  |  | $ | 0.67 |  |  |  |  |  |  |  |  |  |

[0000038725-26-000022:8k_2_02:41]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | March 31, 2026 |  | December 31, 2025 |
| ASSETS |  |
| Cash and cash equivalents | $ | 80,400 |  |  | $ | 99,662 |  |
| Receivables (net) | 297,859 |  |  | 247,511 |  |
| Inventories | 583,208 |  |  | 552,981 |  |
| Other current assets | 53,818 |  |  | 58,472 |  |
| Total current assets | 1,015,285 |  |  | 958,626 |  |
| Property, plant, and equipment, net | 252,074 |  |  | 252,164 |  |
| Lease right-of-use assets, net | 67,351 |  |  | 67,867 |  |
| Goodwill and other assets | 661,855 |  |  | 665,728 |  |
| Total assets | $ | 1,996,565 |  |  | $ | 1,944,385 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 174,095 |  |  | $ | 174,954 |  |
| Accrued expenses and other current liabilities | 95,552 |  |  | 116,747 |  |
| Current lease liability | 20,319 |  |  | 20,518 |  |
| Current maturities of long-term debt and short-term borrowings | 89,779 |  |  | 31,827 |  |
| Total current liabilities | 379,745 |  |  | 344,046 |  |
| Long-term debt | 134,406 |  |  | 135,184 |  |
| Long-term lease liability | 46,018 |  |  | 46,481 |  |
| Deferred income taxes | 40,798 |  |  | 39,275 |  |
| Employee benefit plans | 22,507 |  |  | 22,833 |  |
| Other long-term liabilities | 28,513 |  |  | 29,541 |  |
| Redeemable noncontrolling interest | 1,908 |  |  | 1,657 |  |
| Total equity | 1,342,670 |  |  | 1,325,368 |  |
| Total liabilities and equity | $ | 1,996,565 |  |  | $ | 1,944,385 |  |

[0000038725-26-000022:8k_2_02:42]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Three Months Ended |
| (In thousands) |  |  |  |
|  | March 31, 2026 |  | March 31, 2025 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 34,695 |  |  | $ | 31,374 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 16,527 |  |  | 14,433 |  |
| Non-cash lease expense | 5,574 |  |  | 5,241 |  |
| Share-based compensation | 3,615 |  |  | 4,962 |  |
| Other | (991) |  |  | 1,080 |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (49,578) |  |  | (29,376) |  |
| Inventory | (28,896) |  |  | (43,669) |  |
| Accounts payable and accrued expenses | (18,250) |  |  | (3,744) |  |
| Operating leases | (5,723) |  |  | (5,091) |  |
| Other | 2,152 |  |  | 5,322 |  |
| Net cash flows from operating activities | (40,875) |  |  | (19,468) |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (9,479) |  |  | (6,836) |  |
| Proceeds from sale of property, plant, and equipment | 351 |  |  | 397 |  |
| Acquisitions and investments | (430) |  |  | (109,687) |  |
| Other investing activities | 20 |  |  | 9 |  |
| Net cash flows from investing activities | (9,538) |  |  | (116,117) |  |
| Cash flows from financing activities: |  |  |  |
| Net change in debt | 57,235 |  |  | 20,366 |  |
| Proceeds from issuance of common stock | 2,700 |  |  | 1,438 |  |
| Purchases of common stock | (13,186) |  |  | (6,902) |  |
| Dividends paid | (12,446) |  |  | (13,160) |  |
| Deferred payments for acquisitions | (1,696) |  |  | (4,300) |  |
| Net cash flows from financing activities | 32,607 |  |  | (2,558) |  |
| Effect of exchange rate changes on cash and cash equivalents | (1,456) |  |  | 1,597 |  |
| Net change in cash and cash equivalents | (19,262) |  |  | (136,546) |  |
| Cash and cash equivalents at beginning of period | 99,662 |  |  | 220,540 |  |
| Cash and cash equivalents at end of period | $ | 80,400 |  |  | $ | 83,994 |  |

[0000038725-26-000022:8k_2_02:43]
Key Performance Indicators: Net Sales Summary

[0000038725-26-000022:8k_2_02:44]
|  | Net Sales For the First Quarter |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Energy | Distribution | Other/Elims | Consolidated |
| Q1 2025 | $ | 175.7 |  | $ | 39.5 |  | $ | 51.5 |  | $ | 20.6 |  | $ | 287.3 |  | $ | 66.8 |  | $ | 141.9 |  | $ | (40.8) |  | $ | 455.2 |  |
| Q1 2026 | $ | 187.2 |  | $ | 49.9 |  | $ | 55.8 |  | $ | 25.1 |  | $ | 318.0 |  | $ | 71.8 |  | $ | 150.9 |  | $ | (40.3) |  | $ | 500.4 |  |
| Change | $ | 11.5 |  | $ | 10.4 |  | $ | 4.3 |  | $ | 4.5 |  | $ | 30.7 |  | $ | 5.0 |  | $ | 9.0 |  | $ | 0.5 |  | $ | 45.2 |  |
| % Change | 7 | % | 26 | % | 8 | % | 22 | % | 11 | % | 7 | % | 6 | % |  | 10 | % |
| Foreign currency translation, net* | $ | 1.0 |  | $ | 3.2 |  | $ | 4.2 |  | $ | 1.2 |  | $ | 9.6 |  | $ | 0.1 |  | $ | — |  |  | $ | 9.7 |  |
| % Change | 1 | % | 8 | % | 8 | % | 6 | % | 3 | % | — | % | — | % |  | 2 | % |
| Acquisitions | $ | 0.3 |  | $ | 6.2 |  | $ | 1.1 |  | $ | 0.9 |  | $ | 8.5 |  | $ | — |  | $ | 0.3 |  |  | $ | 8.8 |  |
| % Change | — | % | 16 | % | 2 | % | 4 | % | 3 | % | — | % | — | % |  | 2 | % |
| Volume/Price | $ | 10.2 |  | $ | 1.0 |  | $ | (1.0) |  | $ | 2.4 |  | $ | 12.6 |  | $ | 4.9 |  | $ | 8.7 |  | $ | 0.5 |  | $ | 26.7 |  |
| % Change | 6 | % | 3 | % | (2) | % | 12 | % | 4 | % | 7 | % | 6 | % | 1 | % | 6 | % |

[0000038725-26-000022:8k_2_02:45]
*The Company has presented local currency price increases used to offset currency devaluation in the highly inflationary economies of Argentina and Turkey within the foreign currency translation, net row above.

[0000038725-26-000022:8k_2_02:46]
Key Performance Indicators: Operating Income and Margin Summary

[0000038725-26-000022:8k_2_02:47]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the First Quarter 2026 |
|  | Water | Energy | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 44.4 |  | $ | 24.2 |  | $ | 3.0 |  | $ | (23.5) |  | $ | 48.1 |  |
| % Operating Income To Net Sales | 14.0 | % | 33.7 | % | 2.0 | % |  | 9.6 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the First Quarter 2025 |
|  | Water | Energy | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 43.4 |  | $ | 21.9 |  | $ | 2.1 |  | $ | (23.3) |  | $ | 44.1 |  |
| % Operating Income To Net Sales | 15.1 | % | 32.8 | % | 1.5 | % |  | 9.7 | % |

[0000038725-26-000022:8k_2_02:48]
Reconciliation of Non-GAAP Financial Measure: Adjusted Diluted EPS

[0000038725-26-000022:8k_2_02:49]
|  | For the First Quarter |  |  |  |  |
|  | 2026 | 2025 | Change |  |  |  |  |
| Diluted Earnings per Share "EPS" (as reported - US GAAP) | $ | 0.77 |  | $ | 0.67 |  | 15 | % |  |  |  |  |
| Restructuring | $ | 0.06 |  | $ | — |  |  |  |  |  |  |
| Adjusted Diluted EPS (non-GAAP) | $ | 0.83 |  | $ | 0.67 |  | 24 | % |  |  |  |  |

[0000038725-26-000022:8k_2_02:50]
Reconciliation of Non-GAAP Financial Measure: Adjusted Operating Income

[0000038725-26-000022:8k_2_02:51]
| (in millions) | For the First Quarter 2026 |
|  | Water | Energy | Distribution | Other/Elims | Consolidated |
| GAAP Operating Income / (Loss) | $ | 44.4 |  | $ | 24.2 |  | $ | 3.0 |  | $ | (23.5) |  | $ | 48.1 |  |
| Restructuring, gross of tax | $ | 3.9 |  | $ | — |  | $ | — |  | $ | — |  | $ | 3.9 |  |
| Non-GAAP Adjusted Operating Income / (Loss) | $ | 48.3 |  | $ | 24.2 |  | $ | 3.0 |  | $ | (23.5) |  | $ | 52.0 |  |
| (in millions) | For the First Quarter 2025 |
|  | Water | Energy | Distribution | Other/Elims | Consolidated |
| GAAP Operating Income / (Loss) | $ | 43.4 |  | $ | 21.9 |  | $ | 2.1 |  | $ | (23.3) |  | $ | 44.1 |  |
| Restructuring, gross of tax | $ | — |  | $ | — |  | $ | 0.2 |  | $ | — |  | $ | 0.2 |  |
| Non-GAAP Adjusted Operating Income / (Loss) | $ | 43.4 |  | $ | 21.9 |  | $ | 2.3 |  | $ | (23.3) |  | $ | 44.3 |  |
| % Operating Income to Net Sales Before Restructuring |  |  |  |  |  |
