# FELE notes — 0000038725-26-000026


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-26-000026:notes:1]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2025, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2026, and for the first quarters ended March 31, 2026 and March 31, 2025 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the first quarter ended March 31, 2026 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2026. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2025.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000038725-26-000026:notes:2]
ACCOUNTING PRONOUNCEMENTS
Adoption of New Accounting Standards

[0000038725-26-000026:notes:3]
In July 2025, the FASB issued ASU 2025-05, Financial Instruments — Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets. ASU 2025-05 provides an optional practical expedient to simplify the measurement of credit losses for certain receivables and contract assets. ASU 2025-05 is effective for interim and annual periods beginning after December 15, 2025, with early adoption permitted. The guidance is to be applied prospectively. The Company adopted this ASU prospectively, effective with its 2026 interim financial statements and the adoption did not have a material impact on its financial statements.

[0000038725-26-000026:notes:4]
Accounting Standards Issued But Not Yet Adopted

[0000038725-26-000026:notes:5]
In November 2024, the FASB issued ASU 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires additional disclosure of the nature of expenses included in the income statement. The standard requires disclosures about specific types of expenses included in the expense captions presented in the income statement. This ASU is effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027, with early adoption permitted. The requirements should be applied on a prospective basis while retrospective application is permitted. The Company is currently evaluating the impact that the adoption of this guidance will have on its disclosures.

[0000038725-26-000026:notes:6]
In September 2025, the FASB issued ASU 2025-06, Intangibles – Goodwill and Other – Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software. ASU 2025-06 removes all references to software development project stages and requires entities to start capitalizing software costs when both of the following occur: (i) management has authorized and committed to funding the software project and (ii) it is probable that the project will be completed and the software will be used to perform the function intended. ASU 2025-06 is effective for interim and annual periods beginning after December 15, 2027, with early adoption permitted. The guidance can be applied prospectively, retrospectively, or utilizing a modified transition method. The Company is currently evaluating the impact of this ASU on the Company's financial statements and does not expect it will have a material impact.

[0000038725-26-000026:notes:7]
In December 2025, the FASB issued ASU 2025-11, Interim Reporting (Topic 270): Narrow-Scope Improvements. ASU 2025-11 amends the existing guidance in ASC 270 to clarify the applicability, form, and content of interim financial statements and to improve the organization and usability of interim reporting requirements. The amendments introduce a disclosure principle requiring entities to provide information about events and changes that occur since the most recent annual reporting period that could have a material impact on the entity.  This ASU also compiles interim disclosure requirements within ASC 270 and other Topics into a single location. ASU 2025-11 is effective for interim periods within annual periods beginning after December 15, 2027, with early adoption permitted. The guidance can be applied prospectively or retrospectively. The Company is currently evaluating the impact of this ASU on the Company’s financial statements and disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-26-000026:notes:8]
[same as prior period, unchanged from 0000038725-25-000178:notes:5]

[0000038725-26-000026:notes:9]
[same as prior period, unchanged from 0000038725-25-000178:notes:6]

[0000038725-26-000026:notes:10]
In March 2025, the Company acquired 100 percent of Barnes de Colombia S.A. ("Barnes"), a leading manufacturer and distributor of industrial and commercial pumps based in Cota, Cundinamarca, Colombia, for total upfront cash consideration of $96.8 million, net of cash acquired. The valuation of assets acquired and liabilities assumed is final as of March 31, 2026, with no material changes from the preliminary allocation previously disclosed.

[0000038725-26-000026:notes:11]
The following table summarizes the fair values of the assets acquired and liabilities assumed as of the acquisition date:

[0000038725-26-000026:notes:12]
| (in millions) |  |
| Assets acquired and liabilities assumed |  |
| Cash and cash equivalents | $ | 3.4 |  |
| Receivables | 9.6 |  |
| Inventories | 23.6 |  |
| Other current assets | 3.9 |  |
| Property, plant and equipment | 13.5 |  |
| Goodwill | 43.4 |  |
| Other intangible assets | 45.5 |  |
| Other non-current assets | 3.6 |  |
| Debt | (13.8) |  |
| Accounts payable | (8.7) |  |
| Accrued expenses and other current liabilities | (2.4) |  |
| Deferred tax liabilities | (18.6) |  |
| Other non-current liabilities | (2.8) |  |
| Total assets acquired and liabilities assumed | $ | 100.2 |  |

[0000038725-26-000026:notes:13]
The Company allocated $33.4 million of the total consideration to customer relationships with a useful life of 8 years, $9.3 million to trade names with a useful life of 11 years, and $2.8 million to developed technology with a useful life of 7 years. The fair values of the intangible assets were determined using the income approach. The Company considers the fair value of the intangible assets to be Level 3 measurements due to the significant estimates and assumptions used by management in establishing the estimated fair values.

[0000038725-26-000026:notes:14]
[same as prior period, unchanged from 0000038725-25-000178:notes:11]

[0000038725-26-000026:notes:15]
The results of operations of the acquired business have been included in the Company’s consolidated statement of income since the date the business was acquired. The Barnes acquisition contributed $6.2 million of incremental net sales for the three months ended March 31, 2026 while the impact on net income was not significant. The Company has not presented pro forma financial information for the Barnes acquisition because its results are not material to the Company’s condensed consolidated financial statements.

[0000038725-26-000026:notes:16]
[same as prior period, unchanged from 0000038725-25-000178:notes:13]

[0000038725-26-000026:notes:17]
[same as prior period, unchanged from 0000038725-25-000178:notes:14]

[0000038725-26-000026:notes:18]
[same as prior period, unchanged from 0000038725-25-000178:notes:16]

[0000038725-26-000026:notes:19]
There were $0.2 million and $1.5 million of transaction costs for the first quarters ended March 31, 2026 and March 31, 2025 respectively.

[0000038725-26-000026:notes:20]
Subsequent Event

[0000038725-26-000026:notes:21]
In April 2026, the Company acquired 100 percent of the ownership interests of Benson Pump Corporation ("Benson Pump") for a purchase price of $21.3 million, subject to working capital and other closing adjustments. Benson Pump is a professional groundwater distributor based in Arkansas.  The Company expects the purchase price to be primarily allocated to working capital, goodwill, and other intangibles assets.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-26-000026:notes:22]
[same as prior period, unchanged from 0000038725-25-000178:notes:18]

[0000038725-26-000026:notes:23]
| (In millions) |  | March 31, 2026 |  | December 31, 2025 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortizing intangibles: |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 310.7 |  |  | $ | (155.0) |  |  | $ | 309.5 |  |  | $ | (149.7) |  |
| Patents |  | 7.4 |  |  | (7.4) |  |  | 7.4 |  |  | (7.4) |  |
| Technology |  | 10.6 |  |  | (8.0) |  |  | 10.5 |  |  | (7.8) |  |
| Trade names |  | 59.0 |  |  | (12.6) |  |  | 58.6 |  |  | (11.6) |  |
| Other |  | 3.1 |  |  | (2.5) |  |  | 3.1 |  |  | (2.5) |  |
| Total |  | $ | 390.8 |  |  | $ | (185.5) |  |  | $ | 389.1 |  |  | $ | (179.0) |  |
| Non-amortizing intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 41.9 |  |  | — |  |  | 41.6 |  |  | — |  |
| Total intangibles |  | $ | 432.7 |  |  | $ | (185.5) |  |  | $ | 430.7 |  |  | $ | (179.0) |  |

[0000038725-26-000026:notes:24]
Amortization expense related to intangible assets for the first quarters ended March 31, 2026 and March 31, 2025 was $6.4 million and $5.1 million, respectively.

[0000038725-26-000026:notes:25]
The change in the carrying amount of goodwill by reportable segment for the three months ended March 31, 2026 is as follows:

[0000038725-26-000026:notes:26]
| (In millions) |  |  |
|  |  | Water Systems |  | Energy Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2025 |  | $ | 277.0 |  |  | $ | 70.5 |  |  | $ | 50.6 |  |  | $ | 398.1 |  |
| Acquisitions |  | — |  |  | — |  |  | — |  |  | — |  |
| Adjustments to prior year acquisitions |  | 0.2 |  |  | — |  |  | — |  |  | 0.2 |  |
| Foreign currency translation |  | 1.4 |  |  | (0.1) |  |  | — |  |  | 1.3 |  |
| Balance as of March 31, 2026 |  | $ | 278.6 |  |  | $ | 70.4 |  |  | $ | 50.6 |  |  | $ | 399.6 |  |


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0000038725-26-000026:notes:27]
[same as prior period, unchanged from 0000038725-25-000178:notes:23]

[0000038725-26-000026:notes:28]
| (In millions) |  | March 31, 2026 |  | December 31, 2025 |
| Salaries, wages, and commissions |  | $ | 39.3 |  |  | $ | 49.2 |  |
| Product warranty costs |  | 8.5 |  |  | 9.1 |  |
| Insurance |  | 3.5 |  |  | 3.3 |  |
| Employee benefits |  | 11.7 |  |  | 20.7 |  |
| Other |  | 24.7 |  |  | 25.7 |  |
| Total |  | $ | 87.7 |  |  | $ | 108.0 |  |


## us-gaap:DebtDisclosureTextBlock

[0000038725-26-000026:notes:29]
DEBT
Debt consisted of the following:

[0000038725-26-000026:notes:30]
| (In millions) |  | March 31, 2026 |  | December 31, 2025 |
| Prudential Agreement |  | $ | 50.0 |  |  | $ | 50.0 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 87.0 |  |  | 30.0 |  |
| Project Bonds |  | 10.8 |  |  | 11.5 |  |
| Foreign subsidiary debt |  | 1.5 |  |  | 0.6 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 224.2 |  |  | $ | 167.0 |  |
| Less: current maturities |  | (89.8) |  |  | (31.8) |  |
| Long-term debt |  | $ | 134.4 |  |  | $ | 135.2 |  |

[0000038725-26-000026:notes:31]
Prudential Agreement

[0000038725-26-000026:notes:32]
The Company maintains the Fourth Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with PGIM, Inc. and its affiliates. On May 15, 2024, the Company entered into Amendment No. 1 that increased the total available facility amount from lenders to $250.0 million from $150.0 million and changed the expiration date from July 30, 2024 to May 15, 2027. On September 26, 2025, the Company issued and sold $50.0 million of fixed rate senior notes due September 26, 2032. These senior notes bear an interest rate of 5.01 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of March 31, 2026, there was $200.0 million remaining borrowing capacity under the Prudential Agreement.

[0000038725-26-000026:notes:33]
New York Life Agreement

[0000038725-26-000026:notes:34]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"). On May 15, 2024, the Company entered into Amendment No. 1 to the renewal that increased the total available facility amount from lenders to $250.0 million from $200.0 million and changed the expiration date from July 30, 2024 to May 15, 2027. On September 26, 2025, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2032. These senior notes bear an interest rate of 5.01 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of March 31, 2026, there was $175.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-26-000026:notes:35]
Credit Agreement

[0000038725-26-000026:notes:36]
On May 14, 2025, the Company entered into the Fifth Amended and Restated Credit Agreement (the “Credit Agreement”).  The Fifth Amended and Restated Credit Agreement extended the maturity date of the Company’s Fourth Amended and Restated Credit Agreement, as amended (which is referred to in this current report as the “Previous Credit Agreement”) to May 14, 2030 while keeping the revolving commitment amount unchanged at $350.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $175.0 million (not to exceed a total commitment of $525.0 million) subject to the conditions contained therein. The Previous Credit Agreement provided the Borrowers could request an increase in the aggregate revolving commitments by up to $125.0 million (not to exceed a total commitment of $475.0 million). All of the Company's present and future material domestic subsidiaries unconditionally guaranty all of the Borrowers' obligations under and in connection with the Credit Agreement. Additionally, the Company unconditionally guarantees all of the obligations of Franklin Electric B.V. under the Credit Agreement.  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a commitment fee of 0.10% to 0.25% (depending on the Company's leverage ratio) of the aggregate commitment, payable quarterly in arrears. The Credit Agreement contains customary affirmative and negative covenants.  Loans may be made either at (i) a Term Benchmark rate based on SOFR, for borrowings denominated in Dollars, or EURIBOR, for borrowings denominated in Euros,  plus an applicable margin of  1.00% to 1.75% (depending on the Company's leverage ratio), or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-26-000026:notes:37]
As of March 31, 2026, the Company had $87.0 million outstanding borrowings with a weighted-average interest rate of 4.7 percent, $6.4 million in letters of credit undrawn and outstanding, and $256.6 million of available capacity under the Credit Agreement. As of December 31, 2025, the Company had $30.0 million outstanding borrowings with a weighted-average interest rate of 2.9 percent, $6.4 million in letters of credit outstanding, and $313.6 million of available capacity under the Credit Agreement.

[0000038725-26-000026:notes:38]
Project Bonds

[0000038725-26-000026:notes:39]
On December 31, 2012, the Company, Allen County, Indiana and certain institutional investors entered into a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project).” The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. The Company then borrowed the proceeds under the Project Bonds through the issuance of Project Notes to finance the cost of acquisition, construction, installation and equipping of the new Global Corporate Headquarters and Engineering Center. These Project Notes (“Tax increment financing debt”) bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033. The use of the proceeds from the Project Notes was limited to assist the financing of the new Global Corporate Headquarters and Engineering Center. On May 5, 2015, the Company entered into Amendment No. 1 to the Bond Purchase and Loan Agreement. This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.

[0000038725-26-000026:notes:40]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $20.4 million. As of March 31, 2026, there were $2.3 million outstanding borrowings and $18.1 million of available capacity under these lines of credit. As of December 31, 2025, there were $19.7 million overdraft lines of credit with $1.5 million outstanding borrowings and $18.1 million of available capacity under these lines of credit.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-26-000026:notes:41]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022, the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company submitted its response to the expert's final report in February  2023.  The next court hearing is expected to occur late in the second quarter of 2026.  The Company cannot predict the ultimate outcome of this matter. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position, results of operations, or cash flows.

[0000038725-26-000026:notes:42]
The Company is defending other various claims and legal actions which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-26-000026:notes:43]
At March 31, 2026, the Company had $10.5 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production and finished goods.

[0000038725-26-000026:notes:44]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the three months ended March 31, 2026, are as follows:

[0000038725-26-000026:notes:45]
| (In millions) |  |  |
| Balance as of December 31, 2025 |  | $ | 9.1 |  |
| Accruals related to product warranties |  | 2.7 |  |
| Reductions for payments made |  | (3.3) |  |
| Balance as of March 31, 2026 |  | $ | 8.5 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-26-000026:notes:46]
EQUITY ROLL FORWARD
The schedules below set forth equity changes in the first quarters ended March 31, 2026 and March 31, 2025:

[0000038725-26-000026:notes:47]
| (In thousands) | Common Stock |  | Additional Paid-in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2025 | $ | 4,418 |  |  | $ | 391,496 |  |  | $ | 1,084,149 |  |  |  |  |  |  | $ | (157,484) |  |  | $ | 2,789 |  |  | $ | 1,325,368 |  |  | $ | 1,657 |  |
| Net income | — |  |  | — |  |  | 34,330 |  |  |  |  |  |  | — |  |  | 98 |  |  | 34,428 |  |  | 267 |  |
| Dividends on common stock ($0.280/share) | — |  |  | — |  |  | (12,446) |  |  |  |  |  |  | — |  |  | — |  |  | (12,446) |  |  | — |  |
| Common stock issued | 4 |  |  | 2,972 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 2,976 |  |  | — |  |
| Common stock repurchased | (14) |  |  | — |  |  | (13,212) |  |  |  |  |  |  | — |  |  | — |  |  | (13,226) |  |  | — |  |
| Share-based compensation | 8 |  |  | 3,607 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 3,615 |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | 2,005 |  |  | (37) |  |  | 1,968 |  |  | (16) |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | (13) |  |  | — |  |  | (13) |  |  | — |  |
| Balance as of March 31, 2026 | $ | 4,416 |  |  | $ | 398,075 |  |  | $ | 1,092,821 |  |  |  |  |  |  | $ | (155,492) |  |  | $ | 2,850 |  |  | $ | 1,342,670 |  |  | $ | 1,908 |  |
| (In thousands) | Common Stock |  | Additional Paid-in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2024 | $ | 4,571 |  |  | $ | 363,956 |  |  | $ | 1,151,575 |  |  |  |  |  |  | $ | (254,003) |  |  | $ | 2,511 |  |  | $ | 1,268,610 |  |  | $ | 1,224 |  |
| Net income | — |  |  | — |  |  | 30,962 |  |  |  |  |  |  | — |  |  | 316 |  |  | 31,278 |  |  | 96 |  |
| Dividends on common stock ($0.265/share) | — |  |  | — |  |  | (12,198) |  |  |  |  |  |  | — |  |  | — |  |  | (12,198) |  |  | — |  |
| Common stock issued | 2 |  |  | 1,436 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 1,438 |  |  | — |  |
| Common stock repurchased | (8) |  |  | — |  |  | (7,466) |  |  |  |  |  |  | — |  |  | — |  |  | (7,474) |  |  | — |  |
| Share-based compensation | 7 |  |  | 4,955 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 4,962 |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | 13,147 |  |  | (152) |  |  | 12,995 |  |  | 53 |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 311 |  |  | — |  |  | 311 |  |  | — |  |
| Balance as of March 31, 2025 | $ | 4,572 |  |  | $ | 370,347 |  |  | $ | 1,162,873 |  |  |  |  |  |  | $ | (240,545) |  |  | $ | 2,675 |  |  | $ | 1,299,922 |  |  | $ | 1,373 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-26-000026:notes:48]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)
Changes in accumulated other comprehensive income/(loss) by component for the three months ended March 31, 2026 and March 31, 2025, are summarized below:

[0000038725-26-000026:notes:49]
| (In millions) | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments |  | Total |
| For the three months ended March 31, 2026: |  |  |
| Balance as of December 31, 2025 | $ | (166.2) |  |  | $ | 8.7 |  |  | $ | (157.5) |  |
| Other comprehensive income/(loss) before reclassifications | 2.0 |  |  | — |  |  | 2.0 |  |
| Net other comprehensive income/(loss) | 2.0 |  |  | — |  |  | 2.0 |  |
| Balance as of March 31, 2026 | $ | (164.2) |  |  | $ | 8.7 |  |  | $ | (155.5) |  |
| For the three months ended March 31, 2025: |  |  |  |  |  |
| Balance as of December 31, 2024 | $ | (215.0) |  |  | $ | (39.0) |  |  | $ | (254.0) |  |
| Other comprehensive income/(loss) before reclassifications | 13.1 |  |  | — |  |  | 13.1 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.3 |  |  | 0.3 |  |
| Net other comprehensive income/(loss) | 13.1 |  |  | 0.3 |  |  | 13.4 |  |
| Balance as of March 31, 2025 | $ | (201.9) |  |  | $ | (38.7) |  |  | $ | (240.6) |  |

[0000038725-26-000026:notes:50]
[same as prior period, unchanged from 0000038725-25-000178:notes:45]

[0000038725-26-000026:notes:51]
[same as prior period, unchanged from 0000038725-25-000178:notes:47]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-26-000026:notes:52]
EMPLOYEE BENEFIT PLANS
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the first quarters ended March 31, 2026 and March 31, 2025:

[0000038725-26-000026:notes:53]
| (In millions) | Pension Benefits |
|  | First Quarter Ended |  |  |
|  | March 31, 2026 |  | March 31, 2025 |  |  |  |  |
| Service cost | $ | — |  |  | $ | — |  |  |  |  |  |
| Interest cost | 0.2 |  |  | 1.4 |  |  |  |  |  |
| Expected return on assets | — |  |  | (1.6) |  |  |  |  |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  |  |  |  |
| Actuarial loss | — |  |  | 0.4 |  |  |  |  |  |
| Settlement cost | — |  |  | — |  |  |  |  |  |
| Net periodic benefit cost | $ | 0.2 |  |  | $ | 0.2 |  |  |  |  |  |

[0000038725-26-000026:notes:54]
The following table sets forth the aggregated net periodic benefit cost for the other post-retirement benefit plan for the first quarters ended March 31, 2026 and March 31, 2025:

[0000038725-26-000026:notes:55]
| (In millions) | Other Benefits |
|  | First Quarter Ended |  |  |
|  | March 31, 2026 |  | March 31, 2025 |  |  |  |  |
| Service cost | $ | — |  |  | $ | — |  |  |  |  |  |
| Interest cost | 0.1 |  |  | 0.1 |  |  |  |  |  |
| Expected return on assets | — |  |  | — |  |  |  |  |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  |  |  |  |
| Actuarial loss | — |  |  | — |  |  |  |  |  |
| Settlement cost | — |  |  | — |  |  |  |  |  |
| Net periodic benefit cost | $ | 0.1 |  |  | $ | 0.1 |  |  |  |  |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-26-000026:notes:56]
INCOME TAXES
The Company’s effective tax rate for the three-month period ended March 31, 2026 was 24.2 percent as compared to 25.0 percent for the three-month period ended March 31, 2025. The effective tax rate differs from the U.S. statutory rate of 21 percent primarily due to foreign earnings taxed at rates different than the U.S. statutory rate and U.S. state taxes partially offset by an object exemption of foreign business profits in the Netherlands and the recognition of the U.S. foreign-derived intangible income (FDII) provisions.
The decrease in the effective tax rate for the first quarter of 2026 compared to the comparable period in the prior year was primarily due to mix of foreign earnings taxed at rates different than the U.S. statutory rate.


## us-gaap:EarningsPerShareTextBlock

[0000038725-26-000026:notes:57]
[same as prior period, unchanged from 0000038725-25-000178:notes:56]

[0000038725-26-000026:notes:58]
[same as prior period, unchanged from 0000038725-25-000178:notes:57]

[0000038725-26-000026:notes:59]
[same as prior period, unchanged from 0000038725-25-000178:notes:58]

[0000038725-26-000026:notes:60]
|  | First Quarter Ended |  |  |
| (In millions, except per share amounts) | March 31, 2026 |  | March 31, 2025 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 34.3 |  |  | $ | 31.0 |  |  |  |  |  |
| Less: Earnings allocated to participating securities | 0.1 |  |  | 0.1 |  |  |  |  |  |
| Net income available to common shareholders | $ | 34.2 |  |  | $ | 30.9 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 44.2 |  |  | 45.7 |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Non-participating employee stock options, performance awards, and deferred shares to non-employee directors | 0.5 |  |  | 0.6 |  |  |  |  |  |
| Diluted weighted average common shares outstanding | 44.7 |  |  | 46.3 |  |  |  |  |  |
| Basic earnings per share | $ | 0.77 |  |  | $ | 0.67 |  |  |  |  |  |
| Diluted earnings per share | $ | 0.77 |  |  | $ | 0.67 |  |  |  |  |  |

[0000038725-26-000026:notes:61]
There were 0.2 million and 0.1 million stock options outstanding for the first quarters ended March 31, 2026 and March 31, 2025, respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-26-000026:notes:62]
FINANCIAL INSTRUMENTS
The Company’s non-employee directors' deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period. The Company has entered into share swap transaction agreements (the "swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price. The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party. As of March 31, 2026 and December 31, 2025, the swap had a notional value based on 150,000 shares. For the first quarter ended March 31, 2026, changes in the fair value of the swap resulted in a loss of $0.7 million. For the first quarter ended March 31, 2025, changes in the fair value of the swap resulted in loss of $1.2 million. Gains and losses resulting from the swap were largely offset by gains and losses on the fair value of the deferred compensation stock liability. All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.

[0000038725-26-000026:notes:63]
The Company is exposed to foreign currency exchange rate risk arising from transactions in the normal course of business including making sales and purchases of raw materials and finished goods in foreign denominated currencies with third party customers and suppliers as well as to wholly owned subsidiaries of the Company. To reduce its exposure to foreign currency exchange rate volatility, the Company enters into various forward currency contracts to offset these fluctuations. The Company uses forward currency contracts only in an attempt to limit underlying exposure from foreign currency exchange rate fluctuations and to minimize earnings volatility associated with foreign currency exchange rate fluctuations and has not elected to use hedge accounting. Decisions on whether to use such derivative instruments are primarily based on the amount of exposure to the currency involved and an assessment of the near-term market value for each currency.  As of March 31, 2026, the Company had a notional amount of $49.5 million in forward currency contracts outstanding and the related fair value of those contracts was a net liability of $2.8 million. The forward currency contracts asset and liability are recorded within the "Receivables" and "Accounts Payable" lines of the condensed consolidated balance sheets. As of December 31, 2025, the Company had no foreign currency contracts outstanding. For the first quarter ended March 31, 2026, changes in the fair value of the forward currency contracts resulted in a loss of $2.2 million. For the first quarter ended March 31, 2025, changes in the fair value of the forward currency contracts resulted in a gain of $4.4 million. These gains and losses are recorded in the Company's condensed consolidated statements of income within the "Foreign exchange income/(expense), net" line.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-26-000026:notes:64]
[same as prior period, unchanged from 0000038725-25-000178:notes:64]

[0000038725-26-000026:notes:65]
[same as prior period, unchanged from 0000038725-25-000178:notes:65]

[0000038725-26-000026:notes:66]
[same as prior period, unchanged from 0000038725-25-000178:notes:66]

[0000038725-26-000026:notes:67]
[same as prior period, unchanged from 0000038725-25-000178:notes:67]

[0000038725-26-000026:notes:68]
As of March 31, 2026 and December 31, 2025, the assets and liabilities measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-26-000026:notes:69]
| (In millions) | March 31, 2026 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 10.7 |  | $ | 10.7 |  | $ | — |  | $ | — |  |
| Marketable securities | 4.1 |  | 4.1 |  | — |  | — |  |
| Total assets | $ | 14.8 |  | $ | 14.8 |  | $ | — |  | $ | — |  |
| Liabilities: |  |  |  |  |
| Share swap transaction | $ | 0.4 |  | $ | 0.4 |  | $ | — |  | $ | — |  |
| Forward currency contracts | 2.8 |  | — |  | 2.8 |  | — |  |
| Total liabilities | $ | 3.2 |  | $ | 0.4 |  | $ | 2.8 |  | $ | — |  |
| (In millions) | December 31, 2025 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 10.2 |  | $ | 10.2 |  | $ | — |  | $ | — |  |
| Marketable securities | $ | 9.7 |  | $ | 9.7 |  | $ | — |  | $ | — |  |
| Total assets | $ | 19.9 |  | $ | 19.9 |  | $ | — |  | $ | — |  |
| Liabilities: |  |  |  |  |
| Total liabilities | $ | — |  | $ | — |  | $ | — |  | $ | — |  |

[0000038725-26-000026:notes:70]
The Company’s Level 1 cash equivalents assets are generally comprised of foreign bank guaranteed certificates of deposit and short term deposits. The Company’s Level 1 marketable securities assets are comprised of short term investment funds. The marketable securities asset is recorded within the "Other current assets" line of the condensed consolidated balance sheets. These marketable securities were excess plan assets from the pension settlement disclosed in Note 10 – Employee Benefit Plans included in the Company's Annual Report on Form 10-K for the year ended December 31, 2025. The forward currency contracts liability and the share swap transaction liability are recorded within the "Accounts payable" line of the condensed consolidated balance sheets. The forward currency contracts and share swap transaction are further described in Note 13 - Financial Instruments.

[0000038725-26-000026:notes:71]
The Company's Level 3 category includes contingent consideration related to acquisitions, which valuation inputs are unobservable and significant to the fair value measurement. Projections and estimated probabilities are used to estimate future contingent earn-out payments, which are discounted back to present value to compute contingent earn-out liabilities. The following table provides a roll-forward of the contingent consideration liability, which is included in "Accrued expenses and other current liabilities" as of March 31, 2026 and March 31, 2025:

[0000038725-26-000026:notes:72]
|  | First Quarter Ended |
| (In millions) | March 31, 2026 | March 31, 2025 |
| Fair value at beginning of period | $ | — |  | $ | 5.0 |  |
| Adjustments to prior year acquisition | — |  | — |  |
| Change in fair value recognized in earnings | — |  | — |  |
| Payments | — |  | (5.0) |  |
| Fair value at end of period | $ | — |  | $ | — |  |

[0000038725-26-000026:notes:73]
Total debt, including current maturities, have carrying amounts of $224.2 million and $167.0 million and estimated fair values of $218.0 million and $160.6 million as of March 31, 2026 and December 31, 2025, respectively. In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value. Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction. In determining the fair value of its debt, 
the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities. Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-26-000026:notes:74]
[same as prior period, unchanged from 0000038725-25-000178:notes:74]

[0000038725-26-000026:notes:75]
The accounting policies of the operating segments are the same as those described in Note 1 of the Company's Annual Report on Form 10-K for the year ended December 31, 2025. Revenue is recognized based on the invoice price at the point in time when the customer obtains control of the product, which is typically upon shipment to the customer. The Water Systems and Energy Systems segments include manufacturing operations and supply certain components and finished goods, both between segments and to the Distribution segment. The Company reports these product transfers between Water Systems and Energy Systems as inventory transfers as a significant number of the Company's manufacturing facilities are shared across segments for scale and efficiency purposes. The Company reports intersegment transfers from Water Systems to Distribution as intersegment revenue at market prices to properly reflect the commercial arrangement of vendor to customer that exists between the Water Systems and Distribution segments.

[0000038725-26-000026:notes:76]
The Company's chief operating decision maker is its Chief Executive Officer. Performance is evaluated based on the sales and operating income of the segments. Operating income and margin are used to evaluate income generated from segment assets in deciding whether to reinvest profits into each segment or other parts of the entity. Operating income is also used to monitor budget versus actual results for purposes of determining portions of management compensation and for benchmarking against similar measures used by peers and competitors. These results are not necessarily indicative of the results of operations that would have occurred had each segment been an independent, stand-alone entity during the periods presented as corporate expenses are not allocated to segments. Interest expense, other income/(expense), net, foreign exchange income/(expense), net, and income tax expense are also not allocated to each segment.

[0000038725-26-000026:notes:77]
[same as prior period, unchanged from 0000038725-25-000178:notes:77]

[0000038725-26-000026:notes:78]
| First Quarter Ended March 31, 2026 | Water Systems |  | Distribution |  | Energy Systems |  | Total |
| (In millions) |
| External sales | $ | 277.7 |  |  | $ | 150.9 |  |  | $ | 71.8 |  |  | $ | 500.4 |  |
| Intersegment sales | 40.3 |  |  | — |  |  | — |  |  | 40.3 |  |
|  | $ | 318.0 |  |  | $ | 150.9 |  |  | $ | 71.8 |  |  | $ | 540.7 |  |
| Elimination of intersegment sales |  |  |  |  |  |  | $ | (40.3) |  |
| Total consolidated sales |  |  |  |  |  |  | $ | 500.4 |  |
| Cost of sales | $ | 214.3 |  |  | $ | 109.9 |  |  | $ | 37.3 |  |  |  |
| Selling, general and administrative expenses | 55.4 |  |  | 38.0 |  |  | 10.3 |  |  |  |
| Restructuring expense | 3.9 |  |  | — |  |  | — |  |  |  |
| Segment operating income | $ | 44.4 |  |  | $ | 3.0 |  |  | $ | 24.2 |  |  | $ | 71.6 |  |
| Reconciliation of segment operating income to income before income taxes |  |  |  |  |  |  |  |
| Deferred intersegment profit |  |  |  |  |  |  | $ | (4.2) |  |
| Corporate general and administrative expenses |  |  |  |  |  |  | (19.3) |  |
| Interest expense |  |  |  |  |  |  | (2.3) |  |
| Other income/(expense), net |  |  |  |  |  |  | (0.4) |  |
| Foreign exchange expense, net |  |  |  |  |  |  | 0.4 |  |
| Consolidated income before income taxes |  |  |  |  |  |  | $ | 45.8 |  |

[0000038725-26-000026:notes:79]
| First Quarter Ended March 31, 2025 | Water Systems |  | Distribution |  | Energy Systems |  | Total |
| (In millions) |
| External sales | $ | 246.5 |  |  | $ | 141.9 |  |  | $ | 66.8 |  |  | $ | 455.2 |  |
| Intersegment sales | 40.8 |  |  | — |  |  | — |  |  | 40.8 |  |
|  | $ | 287.3 |  |  | $ | 141.9 |  |  | $ | 66.8 |  |  | $ | 496.0 |  |
| Elimination of intersegment sales |  |  |  |  |  |  | $ | (40.8) |  |
| Total consolidated sales |  |  |  |  |  |  | $ | 455.2 |  |
| Cost of sales | $ | 191.3 |  |  | $ | 102.4 |  |  | $ | 34.3 |  |  |  |
| Selling, general and administrative expenses | 52.6 |  |  | 37.2 |  |  | 10.6 |  |  |  |
| Restructuring expense | — |  |  | 0.2 |  |  | — |  |  |  |
| Segment operating income | $ | 43.4 |  |  | $ | 2.1 |  |  | $ | 21.9 |  |  | $ | 67.4 |  |
| Reconciliation of segment operating income to income before income taxes |  |  |  |  |  |  |  |
| Deferred intersegment profit |  |  |  |  |  |  | $ | (4.1) |  |
| Corporate general and administrative expenses |  |  |  |  |  |  | (19.2) |  |
| Interest expense |  |  |  |  |  |  | (1.8) |  |
| Other income/(expense), net |  |  |  |  |  |  | 0.8 |  |
| Foreign exchange income, net |  |  |  |  |  |  | (1.3) |  |
| Consolidated income before income taxes |  |  |  |  |  |  | $ | 41.8 |  |

[0000038725-26-000026:notes:80]
|  | First Quarter Ended |  |  |
| (In millions) | March 31, 2026 |  | March 31, 2025 |  |  |  |  |
| Depreciation and amortization |  |  |  |  |  |  |  |
| Water Systems | $ | 12.3 |  |  | $ | 10.2 |  |  |  |  |  |
| Distribution | 2.3 |  |  | 2.3 |  |  |  |  |  |
| Energy Systems | 1.1 |  |  | 1.1 |  |  |  |  |  |
| Total segment depreciation and amortization | $ | 15.7 |  |  | $ | 13.6 |  |  |  |  |  |
| Corporate | 0.8 |  |  | 0.8 |  |  |  |  |  |
| Total depreciation and amortization | $ | 16.5 |  |  | $ | 14.4 |  |  |  |  |  |
| Capital Expenditures |  |  |  |  |  |  |  |
| Water Systems | $ | 5.1 |  |  | $ | 3.2 |  |  |  |  |  |
| Distribution | 3.7 |  |  | 1.7 |  |  |  |  |  |
| Energy Systems | 0.2 |  |  | 0.8 |  |  |  |  |  |
| Total segment capital expenditure | $ | 9.0 |  |  | $ | 5.7 |  |  |  |  |  |
| Corporate | 0.5 |  |  | 0.4 |  |  |  |  |  |
| Total capital expenditures | $ | 9.5 |  |  | $ | 6.1 |  |  |  |  |  |
| Assets |  |  |  |  |  |
| Water Systems | $ | 1,249.2 |  |  | $ | 1,228.5 |  |  |  |  |  |
| Distribution | 407.7 |  |  | 383.6 |  |  |  |  |  |
| Energy Systems | 265.8 |  |  | 255.6 |  |  |  |  |  |
| Total segment assets | $ | 1,922.7 |  |  | $ | 1,867.7 |  |  |  |  |  |
| Corporate | 73.9 |  |  | 61.2 |  |  |  |  |  |
| Total assets | $ | 1,996.6 |  |  | $ | 1,928.9 |  |  |  |  |  |

[0000038725-26-000026:notes:81]
Cash and property, plant and equipment are the major asset groups in “Corporate” of total assets for the quarters ended March 31, 2026 and March 31, 2025.

[0000038725-26-000026:notes:82]
[same as prior period, unchanged from 0000038725-25-000178:notes:84]

[0000038725-26-000026:notes:83]
|  | First Quarter Ended |  |  |
| (In millions) | March 31, 2026 |  | March 31, 2025 |  |  |  |  |
|  | Net sales |
| Water Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | $ | 146.9 |  |  | $ | 134.9 |  |  |  |  |  |
| Latin America | 49.9 |  |  | 39.5 |  |  |  |  |  |
| Europe, Middle East & Africa | 55.8 |  |  | 51.5 |  |  |  |  |  |
| Asia Pacific | 25.1 |  |  | 20.6 |  |  |  |  |  |
| Intersegment sales |  |  |  |  |  |  |  |
| United States & Canada | 40.3 |  |  | 40.8 |  |  |  |  |  |
| Total sales | 318.0 |  |  | 287.3 |  |  |  |  |  |
| Distribution |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 150.9 |  |  | 141.9 |  |  |  |  |  |
| Intersegment sales | — |  |  | — |  |  |  |  |  |
| Total sales | 150.9 |  |  | 141.9 |  |  |  |  |  |
| Energy Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 53.1 |  |  | 52.2 |  |  |  |  |  |
| All other | 18.7 |  |  | 14.6 |  |  |  |  |  |
| Intersegment sales | — |  |  | — |  |  |  |  |  |
| Total sales | 71.8 |  |  | 66.8 |  |  |  |  |  |
| Intersegment Eliminations/Other | (40.3) |  |  | (40.8) |  |  |  |  |  |
| Consolidated | $ | 500.4 |  |  | $ | 455.2 |  |  |  |  |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000038725-26-000026:notes:84]
None of the Company’s directors or officers adopted, modified, or terminated a Rule 10b5-1 trading arrangement or a non-Rule 10b5-1 trading arrangement during the Company’s fiscal quarter ended March 31, 2026.
