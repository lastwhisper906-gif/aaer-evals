# FELE note change history — 0000038725-25-000178 → 0000038725-26-000026


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-04-29):
[0000038725-26-000026:note_history:1]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022, the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company submitted its response to the expert's final report in February  2023.  The next court hearing is expected to occur late in the second quarter of 2026.  The Company cannot predict the ultimate outcome of this matter. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position, results of operations, or cash flows.
  (was, 2025-10-30, similarity 0.9705):
[0000038725-25-000178:note_history:1]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022, the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company submitted its response to the expert's final report in February  2023. The Company cannot predict the ultimate outcome of this matter. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position, results of operations, or cash flows.

- changed (2026-04-29):
[0000038725-26-000026:note_history:2]
At March 31, 2026, the Company had $10.5 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production and finished goods.
  (was, 2025-10-30, similarity 0.9699):
[0000038725-25-000178:note_history:2]
At September 30, 2025, the Company had $9.0 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production and finished goods.

- changed (2026-04-29):
[0000038725-26-000026:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the three months ended March 31, 2026, are as follows:
  (was, 2025-10-30, similarity 0.894):
[0000038725-25-000178:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 30, 2025, are as follows:

- changed (2026-04-29):
[0000038725-26-000026:note_history:4]
| (In millions) |  |  |
| Balance as of December 31, 2025 |  | $ | 9.1 |  |
| Accruals related to product warranties |  | 2.7 |  |
| Reductions for payments made |  | (3.3) |  |
| Balance as of March 31, 2026 |  | $ | 8.5 |  |
  (was, 2025-10-30, similarity 0.965):
[0000038725-25-000178:note_history:4]
| (In millions) |  |  |
| Balance as of December 31, 2024 |  | $ | 9.0 |  |
| Accruals related to product warranties |  | 8.5 |  |
| Reductions for payments made |  | (8.5) |  |
| Balance as of September 30, 2025 |  | $ | 9.0 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-04-29):
[0000038725-26-000026:note_history:5]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2025, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2026, and for the first quarters ended March 31, 2026 and March 31, 2025 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the first quarter ended March 31, 2026 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2026. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2025.
  (was, 2025-10-30, similarity 0.9367):
[0000038725-25-000178:note_history:5]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2024, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 30, 2025, and for the third quarters and nine months ended September 30, 2025 and September 30, 2024 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the third quarter and nine months ended September 30, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2025. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2024.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-04-29):
[0000038725-26-000026:note_history:6]
| (In millions) |  | March 31, 2026 |  | December 31, 2025 |
| Prudential Agreement |  | $ | 50.0 |  |  | $ | 50.0 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 87.0 |  |  | 30.0 |  |
| Project Bonds |  | 10.8 |  |  | 11.5 |  |
| Foreign subsidiary debt |  | 1.5 |  |  | 0.6 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 224.2 |  |  | $ | 167.0 |  |
| Less: current maturities |  | (89.8) |  |  | (31.8) |  |
| Long-term debt |  | $ | 134.4 |  |  | $ | 135.2 |  |

- changed (2026-04-29):
[0000038725-26-000026:note_history:7]
The Company maintains the Fourth Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with PGIM, Inc. and its affiliates. On May 15, 2024, the Company entered into Amendment No. 1 that increased the total available facility amount from lenders to $250.0 million from $150.0 million and changed the expiration date from July 30, 2024 to May 15, 2027. On September 26, 2025, the Company issued and sold $50.0 million of fixed rate senior notes due September 26, 2032. These senior notes bear an interest rate of 5.01 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of March 31, 2026, there was $200.0 million remaining borrowing capacity under the Prudential Agreement.
  (was, 2025-10-30, similarity 0.991):
[0000038725-25-000178:note_history:7]
The Company maintains the Fourth Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with PGIM, Inc. and its affiliates. On May 15, 2024, the Company entered into Amendment No. 1 that increased the total available facility amount from lenders to $250.0 million from $150.0 million and changed the expiration date from July 30, 2024 to May 15, 2027. On September 26, 2025, the Company issued and sold $50.0 million of fixed rate senior notes due September 26, 2032. These senior notes bear an interest rate of 5.01 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of September 30, 2025, there was $200.0 million remaining borrowing capacity under the Prudential Agreement.

- changed (2026-04-29):
[0000038725-26-000026:note_history:8]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"). On May 15, 2024, the Company entered into Amendment No. 1 to the renewal that increased the total available facility amount from lenders to $250.0 million from $200.0 million and changed the expiration date from July 30, 2024 to May 15, 2027. On September 26, 2025, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2032. These senior notes bear an interest rate of 5.01 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of March 31, 2026, there was $175.0 million remaining borrowing capacity under the New York Life Agreement.
  (was, 2025-10-30, similarity 0.9917):
[0000038725-25-000178:note_history:8]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"). On May 15, 2024, the Company entered into Amendment No. 1 to the renewal that increased the total available facility amount from lenders to $250.0 million from $200.0 million and changed the expiration date from July 30, 2024 to May 15, 2027. On September 26, 2025, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2032. These senior notes bear an interest rate of 5.01 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of September 30, 2025, there was $175.0 million remaining borrowing capacity under the New York Life Agreement.

- changed (2026-04-29):
[0000038725-26-000026:note_history:9]
As of March 31, 2026, the Company had $87.0 million outstanding borrowings with a weighted-average interest rate of 4.7 percent, $6.4 million in letters of credit undrawn and outstanding, and $256.6 million of available capacity under the Credit Agreement. As of December 31, 2025, the Company had $30.0 million outstanding borrowings with a weighted-average interest rate of 2.9 percent, $6.4 million in letters of credit outstanding, and $313.6 million of available capacity under the Credit Agreement.
  (was, 2025-10-30, similarity 0.9628):
[0000038725-25-000178:note_history:9]
As of September 30, 2025, the Company had $66.3 million outstanding borrowings with a weighted-average interest rate of 3.6 percent, $6.4 million in letters of credit outstanding, and $277.3 million of available capacity under the Credit Agreement. As of December 31, 2024, the Company had $41.4 million outstanding borrowings with a weighted-average interest rate of 3.7 percent, $4.5 million in letters of credit outstanding, and $304.1 million of available capacity under the Previous Credit Agreement.

- added (2026-04-29):
[0000038725-26-000026:note_history:10]
Project Bonds

- added (2026-04-29):
[0000038725-26-000026:note_history:11]
On December 31, 2012, the Company, Allen County, Indiana and certain institutional investors entered into a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project).” The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. The Company then borrowed the proceeds under the Project Bonds through the issuance of Project Notes to finance the cost of acquisition, construction, installation and equipping of the new Global Corporate Headquarters and Engineering Center. These Project Notes (“Tax increment financing debt”) bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033. The use of the proceeds from the Project Notes was limited to assist the financing of the new Global Corporate Headquarters and Engineering Center. On May 5, 2015, the Company entered into Amendment No. 1 to the Bond Purchase and Loan Agreement. This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.

- changed (2026-04-29):
[0000038725-26-000026:note_history:12]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $20.4 million. As of March 31, 2026, there were $2.3 million outstanding borrowings and $18.1 million of available capacity under these lines of credit. As of December 31, 2025, there were $19.7 million overdraft lines of credit with $1.5 million outstanding borrowings and $18.1 million of available capacity under these lines of credit.
  (was, 2025-10-30, similarity 0.9165):
[0000038725-25-000178:note_history:12]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $19.8 million. As of September 30, 2025, there were $1.3 million outstanding borrowings and $18.5 million of available capacity under these lines of credit. As of December 31, 2024, there were $16.8 million overdraft lines of credit with no outstanding borrowings and $16.8 million of available capacity under these lines of credit.

- removed (2026-04-29):
[0000038725-25-000178:note_history:13]
| (In millions) |  | September 30, 2025 |  | December 31, 2024 |
| Prudential Agreement |  | $ | 50.0 |  |  | $ | — |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 66.3 |  |  | 41.4 |  |
| Tax increment financing debt |  | 11.5 |  |  | 12.8 |  |
| Foreign subsidiary debt |  | 1.5 |  |  | 0.3 |  |
| Less: unamortized debt issuance costs |  | — |  |  | (0.1) |  |
|  |  | $ | 204.3 |  |  | $ | 129.4 |  |
| Less: current maturities |  | (69.1) |  |  | (117.8) |  |
| Long-term debt |  | $ | 135.2 |  |  | $ | 11.6 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-04-29):
[0000038725-26-000026:note_history:14]
| (In millions) |  | March 31, 2026 |  | December 31, 2025 |
| Prudential Agreement |  | $ | 50.0 |  |  | $ | 50.0 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 87.0 |  |  | 30.0 |  |
| Project Bonds |  | 10.8 |  |  | 11.5 |  |
| Foreign subsidiary debt |  | 1.5 |  |  | 0.6 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 224.2 |  |  | $ | 167.0 |  |
| Less: current maturities |  | (89.8) |  |  | (31.8) |  |
| Long-term debt |  | $ | 134.4 |  |  | $ | 135.2 |  |

- removed (2026-04-29):
[0000038725-25-000178:note_history:15]
| (In millions) |  | September 30, 2025 |  | December 31, 2024 |
| Prudential Agreement |  | $ | 50.0 |  |  | $ | — |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 66.3 |  |  | 41.4 |  |
| Tax increment financing debt |  | 11.5 |  |  | 12.8 |  |
| Foreign subsidiary debt |  | 1.5 |  |  | 0.3 |  |
| Less: unamortized debt issuance costs |  | — |  |  | (0.1) |  |
|  |  | $ | 204.3 |  |  | $ | 129.4 |  |
| Less: current maturities |  | (69.1) |  |  | (117.8) |  |
| Long-term debt |  | $ | 135.2 |  |  | $ | 11.6 |  |
