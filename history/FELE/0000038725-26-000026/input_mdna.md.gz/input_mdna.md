# FELE MD&A — 0000038725-26-000026


## mdna

[0000038725-26-000026:mdna:1]
[same as prior period, unchanged from 0000038725-25-000178:mdna:1]

[0000038725-26-000026:mdna:2]
Refer to the Company's Annual Report on Form 10-K for the year ended December 31, 2025 for management’s discussion and analysis of its financial condition and results of operations. The following is management’s discussion and analysis of the Company's financial condition and results of operations for the three months ended March 31, 2026 and 2025.

[0000038725-26-000026:mdna:3]
In February of 2025, the Company acquired PumpEng Pty Ltd ("PumpEng"), an Australia-based company that specializes in the design, manufacture and service of submersible pumps for the mining sector. In March 2025, the Company acquired Barnes de Colombia S.A. (Barnes), a leading manufacturer and distributor of industrial and commercial pumps based in Colombia. Acquisitions contributed $8.8 million of incremental net sales in the first three months of 2026 compared to the same period in 2025. Refer to Note 3 in Item 1 of this Quarterly Report on Form 10-Q for additional information on the Barnes and PumpEng acquisitions.

[0000038725-26-000026:mdna:4]
[same as prior period, unchanged from 0000038725-25-000178:mdna:5]

[0000038725-26-000026:mdna:5]
First Quarter 2026 vs. 2025

[0000038725-26-000026:mdna:6]
[same as prior period, unchanged from 0000038725-25-000178:mdna:7]

[0000038725-26-000026:mdna:7]
Net sales in the first quarter of 2026 increased 10 percent from the first quarter of last year. The sales increase was primarily due to higher sales volumes and price realization in all three segments. The Company's consolidated gross profit was $175.0 million for the first quarter of 2026, an increase of $11.1 million from the prior year’s first quarter. The gross profit as a percent of net sales was 35.0 percent in the first quarter of 2026 compared to 36.0 percent in the first quarter of 2025.  Diluted earnings per share for the first quarter of 2026 was $0.77, an increase of $0.10, or 15 percent, from the first quarter of 2025 diluted earnings per share of $0.67.

[0000038725-26-000026:mdna:8]
[same as prior period, unchanged from 0000038725-25-000178:mdna:9]

[0000038725-26-000026:mdna:9]
[same as prior period, unchanged from 0000038725-25-000178:mdna:10]

[0000038725-26-000026:mdna:10]
Net sales in the first quarter of 2026 were $500.4 million, an increase of $45.2 million or 10 percent compared to 2025 first quarter sales of $455.2 million. The sales increase was primarily due to higher sales volumes and price realization of 6 percent, positive impact of foreign exchange rates of 2 percent, and incremental sales impact from recent acquisitions of 2 percent.

[0000038725-26-000026:mdna:11]
|  | Net Sales |
| (In millions) | Q1 2026 |  | Q1 2025 |  | 2026 v 2025 |
| Water Systems | $ | 318.0 |  |  | $ | 287.3 |  |  | $ | 30.7 |  |
| Energy Systems | 71.8 |  |  | 66.8 |  |  | 5.0 |  |
| Distribution | 150.9 |  |  | 141.9 |  |  | 9.0 |  |
| Eliminations/Other | (40.3) |  |  | (40.8) |  |  | 0.5 |  |
| Consolidated | $ | 500.4 |  |  | $ | 455.2 |  |  | $ | 45.2 |  |

[0000038725-26-000026:mdna:12]
[same as prior period, unchanged from 0000038725-25-000178:mdna:14]

[0000038725-26-000026:mdna:13]
Water Systems net sales were $318.0 million in the first quarter of 2026, an increase of $30.7 million or 11 percent compared to the first quarter of 2025 net sales of $287.3 million. The sales increase was due to higher sales volumes and price realization, the positive impact of foreign exchange rates, and the incremental sales impact from recent acquisitions.

[0000038725-26-000026:mdna:14]
Water Systems net sales in the U.S. and Canada increased 7 percent compared to the first quarter of 2025. Sales increased 1 percent in the first quarter due to the positive impact of foreign exchange rates, as compared to prior year. Sales increased less than 1 percent in the first quarter due to the incremental sales impact from recent acquisitions. The sales increase was led by sales of all other surface pumping equipment up 17 percent, as sales of water treatment products increased 8 percent and sales

[0000038725-26-000026:mdna:15]
of groundwater pumping equipment increased 3 percent. These sales increases were partially offset by lower sales of large dewatering equipment of 9 percent compared to 2025. Water Systems net sales in markets outside the U.S. and Canada increased 17 percent compared to the first quarter of 2025. Sales increased 8 percent in the first quarter of 2026 due to the positive impact from foreign exchange rates, as compared to the prior year. Sales increased 7 percent in the first quarter due to the incremental sales impact from recent acquisitions. Outside the U.S. and Canada, sales increased primarily in Asia Pacific and Latin America, as EMEA sales were down year over year.

[0000038725-26-000026:mdna:16]
[same as prior period, unchanged from 0000038725-25-000178:mdna:18]

[0000038725-26-000026:mdna:17]
Energy Systems net sales were $71.8 million in the first quarter of 2026, an increase of $5.0 million or 7 percent compared to the first quarter of 2025 net sales of $66.8 million. The sales increase was primarily due to higher volumes and price realization.

[0000038725-26-000026:mdna:18]
Energy Systems net sales in the U.S. and Canada increased 3 percent compared to the first quarter of 2025 due to increases in sales of fuel management and pumping systems. Outside the U.S. and Canada, Energy Systems net sales increased 29 percent, due primarily to higher sales in Asia Pacific.

[0000038725-26-000026:mdna:19]
[same as prior period, unchanged from 0000038725-25-000178:mdna:21]

[0000038725-26-000026:mdna:20]
Distribution net sales were $150.9 million in the first quarter of 2026, an increase of $9.0 million or 6 percent compared to the first quarter of 2025 net sales of $141.9 million. The Distribution segment sales increase was primarily due to higher volumes and price realization. Sales increased less than 1 percent in the first quarter due to the incremental sales impact from recent acquisitions.

[0000038725-26-000026:mdna:21]
[same as prior period, unchanged from 0000038725-25-000178:mdna:23]

[0000038725-26-000026:mdna:22]
|  | Three Months Ended March 31, |
| (In millions) | 2026 |  | % of Net Sales |  | 2025 |  | % of Net Sales |
| Gross Profit | $ | 175.0 |  |  | 35.0 | % |  | $ | 163.9 |  |  | 36.0 | % |
| Selling, General and Administrative Expense | 123.0 |  |  | 24.6 | % |  | 119.6 |  |  | 26.3 | % |

[0000038725-26-000026:mdna:23]
[same as prior period, unchanged from 0000038725-25-000178:mdna:26]

[0000038725-26-000026:mdna:24]
The gross profit margin ratio was 35.0 percent in 2026 and 36.0 percent in first quarter of 2025. The gross profit margin was unfavorably impacted in the first quarter of  2026 by higher material costs, primarily tariff costs, and an unfavorable product and geographic sales mix shift.

[0000038725-26-000026:mdna:25]
[same as prior period, unchanged from 0000038725-25-000178:mdna:28]

[0000038725-26-000026:mdna:26]
SG&A expenses were $123.0 million in the first quarter of 2026 compared to $119.6 million in the first quarter of 2025. The increase was primarily due to the incremental expense impact from recent acquisitions. SG&A as a percent of net sales was 24.6 percent in the first quarter of 2026 and 26.3 percent in the first quarter of 2025.

[0000038725-26-000026:mdna:27]
[same as prior period, unchanged from 0000038725-25-000178:mdna:30]

[0000038725-26-000026:mdna:28]
There were $3.9 million restructuring expenses in the Water Systems segment in first quarter of 2026 compared to $0.0 million in the first quarter of 2025.  There were $0.0 million restructuring expense in the Distribution segment in the first quarter of 2026 compared to$0.2 million in first quarter of 2025. Restructuring expenses were primarily from continued manufacturing and business realignment activities.

[0000038725-26-000026:mdna:29]
[same as prior period, unchanged from 0000038725-25-000178:mdna:32]

[0000038725-26-000026:mdna:30]
Operating income was $48.1 million in the first quarter of 2026, an increase of $4.0 million or 9 percent from $44.1 million in the first quarter of 2025.

[0000038725-26-000026:mdna:31]
|  |  | Operating income (loss) |
| (In millions) |  | Q1 2026 |  | Q1 2025 |  | 2026 v 2025 |
| Water Systems |  | $ | 44.4 |  |  | $ | 43.4 |  |  | $ | 1.0 |  |
| Energy Systems |  | 24.2 |  |  | 21.9 |  |  | 2.3 |  |
| Distribution |  | 3.0 |  |  | 2.1 |  |  | 0.9 |  |
| Eliminations/Other |  | (23.5) |  |  | (23.3) |  |  | (0.2) |  |
| Consolidated |  | $ | 48.1 |  |  | $ | 44.1 |  |  | $ | 4.0 |  |

[0000038725-26-000026:mdna:32]
[same as prior period, unchanged from 0000038725-25-000178:mdna:36]

[0000038725-26-000026:mdna:33]
Water Systems operating income was $44.4 million in the first quarter of 2026, an increase of $1.0 million compared to the first quarter of 2025. Operating income increased in Water Systems primarily due to higher sales. The first quarter operating income margin was 14.0 percent, a decrease of 110 basis points from 15.1 percent in the first quarter 2025. Operating income margin decreased primarily due to restructuring charges and higher tariff costs.

[0000038725-26-000026:mdna:34]
[same as prior period, unchanged from 0000038725-25-000178:mdna:39]

[0000038725-26-000026:mdna:35]
Energy Systems operating income was $24.2 million in the first quarter of 2026, an increase of $2.3 million compared to the first quarter of 2025. Operating income increased in Energy Systems primarily due to higher sales. The first quarter operating income margin was 33.7 percent, an increase of 90 basis points from 32.8 percent in the first quarter of 2025. Operating income margin increased primarily due to leverage on SG&A cost from higher sales.

[0000038725-26-000026:mdna:36]
[same as prior period, unchanged from 0000038725-25-000178:mdna:41]

[0000038725-26-000026:mdna:37]
Distribution operating income was $3.0 million in the first quarter of 2026, an increase of $0.9 million compared to the first quarter of 2025. Operating income increased primarily due to higher sales. The first quarter operating income margin was 2.0 percent, an increase of 50 basis points from 1.5 percent in the first quarter of 2025. Operating income margin improved due to leverage on SG&A cost from higher sales.

[0000038725-26-000026:mdna:38]
[same as prior period, unchanged from 0000038725-25-000178:mdna:43]

[0000038725-26-000026:mdna:39]
Operating income-eliminations/other is composed primarily of intersegment sales and profit eliminations and unallocated general and administrative expenses. The intersegment profit elimination impact in the first quarter of 2026 compared to the first quarter of 2025 was unfavorable $0.2 million. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer. General and administrative expenses were flat compared to the prior year.

[0000038725-26-000026:mdna:40]
[same as prior period, unchanged from 0000038725-25-000178:mdna:45]

[0000038725-26-000026:mdna:41]
Interest expense was $2.3 million in the first quarter of 2026 and $1.8 million in the first quarter of 2025, respectively.

[0000038725-26-000026:mdna:42]
Other income/(expense), net

[0000038725-26-000026:mdna:43]
Other income or expense was a loss in the first quarter of 2026 of $0.4 million and a gain of $0.8 million in the first quarters of 2025, respectively.

[0000038725-26-000026:mdna:44]
Foreign Exchange income (expense), net

[0000038725-26-000026:mdna:45]
Foreign currency-based transactions produced a gain in the first quarter of 2026 of $0.4 million and a loss of $1.3 million in the first quarter of 2025. The expense in 2025 was primarily due to transaction losses associated with the Argentine Peso and Turkish Lira relative to the U.S. dollar. The Company reports the results of its subsidiaries in Argentina and Turkey using highly inflationary accounting, which requires that the functional currency of the entity be changed to the reporting currency of its parent.

[0000038725-26-000026:mdna:46]
[same as prior period, unchanged from 0000038725-25-000178:mdna:53]

[0000038725-26-000026:mdna:47]
The provision for income taxes in the first quarters of 2026 and 2025 was $11.1 million and $10.5 million, respectively. The effective tax rate for the first quarters of 2026 and 2025 was 24.2 percent and 25.0 percent, respectively. The decrease in the effective tax rate was primarily due to mix of foreign earnings taxed at rates different than the U.S. statutory rate.

[0000038725-26-000026:mdna:48]
[same as prior period, unchanged from 0000038725-25-000178:mdna:56]

[0000038725-26-000026:mdna:49]
Net income for the first quarter of 2026 was $34.7 million compared to the prior year first quarter net income of $31.4 million. Net income attributable to Franklin Electric Co., Inc. for the first quarter of 2026 was $34.3 million, or $0.77 per diluted share, compared to the prior year first quarter net income attributable to Franklin Electric Co., Inc. of $31.0 million, or $0.67 per diluted share.

[0000038725-26-000026:mdna:50]
[same as prior period, unchanged from 0000038725-25-000178:mdna:58]

[0000038725-26-000026:mdna:51]
[same as prior period, unchanged from 0000038725-25-000178:mdna:59]

[0000038725-26-000026:mdna:52]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at March 31, 2026 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-26-000026:mdna:53]
As of March 31, 2026, the Company had a $350.0 million revolving credit facility. The facility is scheduled to mature on May 14, 2030. As of March 31, 2026, the Company had $256.6 million borrowing capacity under its credit agreement as $6.4 million in letters of commercial and standby letters of credit were outstanding and undrawn and $87.0 million revolver borrowings were drawn or outstanding.

[0000038725-26-000026:mdna:54]
The Company maintains the Fourth Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with PGIM, Inc. and its affiliates, with a remaining borrowing capacity of $200.0 million as of March 31, 2026. The maturity date of the agreement is May 15, 2027.

[0000038725-26-000026:mdna:55]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement") with a remaining borrowing capacity on the New York Life Agreement of $175.0 million as of March 31, 2026. The maturity date of the agreement is May 15, 2027.

[0000038725-26-000026:mdna:56]
The Company also has other long-term debt borrowings outstanding as of March 31, 2026. See Note 6 - Debt included in the Company's Annual Report on Form 10-K for the year ended December 31, 2025, for additional information regarding these obligations and future maturities as well as Note 6 - Debt of this current quarterly report for changes to these agreements since December 31, 2025.

[0000038725-26-000026:mdna:57]
The Company has a firm, non‑cancellable purchase commitment with a vendor for copper with an aggregate remaining obligation of approximately $4.0 million, expected to be fulfilled within the next year.

[0000038725-26-000026:mdna:58]
At March 31, 2026, the Company had $72.2 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations. There is currently no need or intent to repatriate the majority of these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-26-000026:mdna:59]
[same as prior period, unchanged from 0000038725-25-000178:mdna:66]

[0000038725-26-000026:mdna:60]
The following table summarizes significant sources and uses of cash and cash equivalents for the first three months of 2026 and 2025.

[0000038725-26-000026:mdna:61]
| (In millions) |  | 2026 |  | 2025 |
| Net cash flows from operating activities |  | $ | (40.9) |  |  | $ | (19.5) |  |
| Net cash flows from investing activities |  | (9.5) |  |  | (116.1) |  |
| Net cash flows from financing activities |  | 32.6 |  |  | (2.6) |  |
| Impact of exchange rates on cash and cash equivalents |  | (1.5) |  |  | 1.6 |  |
| Change in cash and cash equivalents |  | $ | (19.3) |  |  | $ | (136.6) |  |

[0000038725-26-000026:mdna:62]
[same as prior period, unchanged from 0000038725-25-000178:mdna:69]

[0000038725-26-000026:mdna:63]
2026 vs. 2025

[0000038725-26-000026:mdna:64]
Net cash used by operating activities was $40.9 million for the three months ended March 31, 2026 compared to $19.5 million used by operating activities for the three months ended March 31, 2025. The change in operating cash flow was primarily attributable to changes in working capital.

[0000038725-26-000026:mdna:65]
[same as prior period, unchanged from 0000038725-25-000178:mdna:72]

[0000038725-26-000026:mdna:66]
2026 vs. 2025

[0000038725-26-000026:mdna:67]
Net cash used in investing activities was $9.5 million for the three months ended March 31, 2026 compared to $116.1 million used in investing activities for the three months ended March 31, 2025. The change in investing cash flow was primarily attributable to decreased acquisition activity in the first three months of 2026.

[0000038725-26-000026:mdna:68]
[same as prior period, unchanged from 0000038725-25-000178:mdna:75]

[0000038725-26-000026:mdna:69]
2026 vs. 2025

[0000038725-26-000026:mdna:70]
Net cash provided by financing activities was $32.6 million for the three months ended March 31, 2026 compared to $2.6 million used in financing activities for the three months ended March 31, 2025. The change in financing cash flow was primarily due to increased net borrowings under the Company's credit facility in 2026 compared to 2025, partially offset by increased repurchases of Company stock.

[0000038725-26-000026:mdna:71]
[same as prior period, unchanged from 0000038725-25-000178:mdna:78]

[0000038725-26-000026:mdna:72]
30
