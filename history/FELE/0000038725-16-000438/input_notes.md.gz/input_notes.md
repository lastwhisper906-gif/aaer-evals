# FELE notes — 0000038725-16-000438


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-16-000438:notes:1]
COMMITMENTS AND CONTINGENCIES

[0000038725-16-000438:notes:2]
The Company is defending various claims and legal actions which have arisen in the ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-16-000438:notes:3]
At October 1, 2016, the Company had $20.3 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-16-000438:notes:4]
The Company provides warranties on most of its products.  The warranty terms vary but are generally two to five years from date of manufacture or one to five years from date of installation.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-16-000438:notes:5]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended October 1, 2016, are as follows:

[0000038725-16-000438:notes:6]
| (In millions) |  |  |
| Balance as of January 2, 2016 |  | $ | 9.3 |  |
| Accruals related to product warranties |  | 4.6 |  |
| Reductions for payments made |  | (5.3 | ) |
| Balance as of October 1, 2016 |  | $ | 8.6 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-16-000438:notes:7]
[same as prior period, unchanged from 0000038725-16-000385:notes:7]

[0000038725-16-000438:notes:8]
Changes in accumulated other comprehensive income/(loss) by component for the nine months ended October 1, 2016 and October 3, 2015, are summarized below:

[0000038725-16-000438:notes:9]
| (In millions) |  |  |  |  |  |
| For the nine months ended October 1, 2016: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments |  | Total |
| Balance as of January 2, 2016 | $ | (110.1 | ) |  | $ | (51.5 | ) |  | $ | (161.6 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | 12.1 |  |  | — |  |  | 12.1 |  |
| Income tax (expense)/benefit | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | 12.1 |  |  | — |  |  | 12.1 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income/(loss) | — |  |  | 2.2 |  | (1) | 2.2 |  |
| Income tax (expense)/benefit | — |  |  | (0.8 | ) |  | (0.8 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | 1.4 |  |  | 1.4 |  |
| Net current period other comprehensive income/(loss), net of income taxes | 12.1 |  |  | 1.4 |  |  | 13.5 |  |
| Less: Other comprehensive income/(loss) attributable to noncontrolling interests | — |  |  | — |  |  | — |  |
| Balance as of October 1, 2016 | $ | (98.0 | ) |  | $ | (50.1 | ) |  | $ | (148.1 | ) |
| For the nine months ended October 3, 2015: |  |  |  |  |  |
| Balance as of January 3, 2015 | $ | (51.8 | ) |  | $ | (56.1 | ) |  | $ | (107.9 | ) |
| Other comprehensive income/(loss) before reclassifications: |  |  |  |  |  |
| Pre-tax income/(loss) | (54.4 | ) |  | — |  |  | (54.4 | ) |
| Income tax (expense)/benefit | — |  |  | — |  |  | — |  |
| Other comprehensive income/(loss) before reclassifications, net of income taxes | (54.4 | ) |  | — |  |  | (54.4 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss): |  |  |  |  |  |
| Pre-tax income/(loss) | — |  |  | 2.9 |  | (1) | 2.9 |  |
| Income tax (expense)/benefit | — |  |  | (1.0 | ) |  | (1.0 | ) |
| Amounts reclassified from accumulated other comprehensive income/(loss), net of income taxes | — |  |  | 1.9 |  |  | 1.9 |  |
| Net current period other comprehensive income/(loss), net of income taxes | (54.4 | ) |  | 1.9 |  |  | (52.5 | ) |
| Less: Other comprehensive income/(loss) attributable to noncontrolling interests | (0.6 | ) |  | — |  |  | (0.6 | ) |
| Balance as of October 3, 2015 | $ | (105.6 | ) |  | $ | (54.2 | ) |  | $ | (159.8 | ) |

[0000038725-16-000438:notes:10]
[same as prior period, unchanged from 0000038725-16-000385:notes:10]


## us-gaap:DebtDisclosureTextBlock

[0000038725-16-000438:notes:11]
DEBT

[0000038725-16-000438:notes:12]
Debt consisted of the following:

[0000038725-16-000438:notes:13]
| (In millions) |  | October 1, 2016 |  | January 2, 2016 |
| Prudential Agreement |  | $ | 90.0 |  |  | $ | 120.0 |  |
| Tax increment financing debt |  | 21.8 |  |  | 22.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 3.5 |  |  | 3.1 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 190.1 |  |  | $ | 220.7 |  |
| Less: current maturities |  | (33.4 | ) |  | (32.9 | ) |
| Long-term debt |  | $ | 156.7 |  |  | $ | 187.8 |  |

[0000038725-16-000438:notes:14]
Debt outstanding, excluding unamortized debt issuance costs, at October 1, 2016 matures as follows:

[0000038725-16-000438:notes:15]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 190.3 |  |  | $ | 33.4 |  |  | $ | 31.1 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 92.0 |  |
| Capital leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 190.4 |  |  | $ | 33.4 |  |  | $ | 31.2 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 92.0 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-16-000438:notes:16]
[same as prior period, unchanged from 0000038725-16-000385:notes:17]

[0000038725-16-000438:notes:17]
The Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  The Company has entered into share swap transaction agreements ("the swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price.  The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party.  As of October 1, 2016, the swap had a notional value based on 205,000 shares.  For the third quarter and nine months ended October 1, 2016, the swap resulted in gains of $1.5 million and $2.6 million, respectively.  For the third quarter and nine months ended October 3, 2015, the swap resulted in losses of $0.9 million and $1.9 million, respectively.  Gains and losses on the swap were primarily offset by gains and losses on the fair value of the deferred compensation stock liability.  All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-16-000438:notes:18]
[same as prior period, unchanged from 0000038725-16-000385:notes:19]

[0000038725-16-000438:notes:19]
[same as prior period, unchanged from 0000038725-16-000385:notes:20]

[0000038725-16-000438:notes:20]
[same as prior period, unchanged from 0000038725-16-000385:notes:21]

[0000038725-16-000438:notes:21]
[same as prior period, unchanged from 0000038725-16-000385:notes:22]

[0000038725-16-000438:notes:22]
[same as prior period, unchanged from 0000038725-16-000385:notes:23]

[0000038725-16-000438:notes:23]
[same as prior period, unchanged from 0000038725-16-000385:notes:24]

[0000038725-16-000438:notes:24]
[same as prior period, unchanged from 0000038725-16-000385:notes:25]

[0000038725-16-000438:notes:25]
[same as prior period, unchanged from 0000038725-16-000385:notes:26]

[0000038725-16-000438:notes:26]
[same as prior period, unchanged from 0000038725-16-000385:notes:27]

[0000038725-16-000438:notes:27]
[same as prior period, unchanged from 0000038725-16-000385:notes:28]

[0000038725-16-000438:notes:28]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the nine months ended October 1, 2016 and October 3, 2015 are as follows:

[0000038725-16-000438:notes:29]
|  |  | October 1, 2016 |  | October 3, 2015 |
| Risk-free interest rate |  | 1.21 | % |  | 1.59 | % |
| Dividend yield |  | 1.32 | % |  | 0.95 | % |
| Volatility factor |  | 0.377 |  |  | 0.379 |  |
| Expected term |  | 5.5 years |  |  | 5.5 years |  |
| Forfeiture rate |  | 3.77 | % |  | 3.67 | % |

[0000038725-16-000438:notes:30]
There were no stock options granted during the third quarters ended October 1, 2016 or October 3, 2015.

[0000038725-16-000438:notes:31]
A summary of the Company’s outstanding stock option activity and related information for the nine months ended October 1, 2016 and October 3, 2015 is as follows:

[0000038725-16-000438:notes:32]
| (Shares in thousands) |  | October 1, 2016 |  | October 3, 2015 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,472 |  |  | $ | 23.26 |  |  | 1,397 |  |  | $ | 21.17 |  |
| Granted |  | 265 |  |  | 29.08 |  |  | 185 |  |  | 36.67 |  |
| Exercised |  | (167 | ) |  | 19.09 |  |  | (70 | ) |  | 17.63 |  |
| Forfeited |  | (5 | ) |  | 33.94 |  |  | (2 | ) |  | 34.93 |  |
| Outstanding at end of period |  | 1,565 |  |  | $ | 24.66 |  |  | 1,510 |  |  | $ | 23.22 |  |
| Expected to vest after applying forfeiture rate |  | 1,539 |  |  | $ | 24.53 |  |  | 1,491 |  |  | $ | 23.04 |  |
| Vested and exercisable at end of period |  | 1,082 |  |  | $ | 20.96 |  |  | 1,144 |  |  | $ | 19.13 |  |

[0000038725-16-000438:notes:33]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value as of October 1, 2016 is as follows:

[0000038725-16-000438:notes:34]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 5.61 years |  | $ | 25,360 |  |
| Expected to vest after applying forfeiture rate |  | 5.56 years |  | $ | 25,126 |  |
| Vested and exercisable at end of period |  | 4.23 years |  | $ | 21,494 |  |

[0000038725-16-000438:notes:35]
The total intrinsic value of options exercised during the nine months ended October 1, 2016 and October 3, 2015 was $3.0 million and $1.3 million, respectively.

[0000038725-16-000438:notes:36]
As of October 1, 2016, there was $1.9 million of total unrecognized compensation cost related to non-vested stock options granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.34 years.

[0000038725-16-000438:notes:37]
[same as prior period, unchanged from 0000038725-16-000385:notes:38]

[0000038725-16-000438:notes:38]
A summary of the Company’s restricted stock/stock unit award activity and related information for the nine months ended October 1, 2016 and October 3, 2015 is as follows:

[0000038725-16-000438:notes:39]
| (Shares in thousands) |  | October 1, 2016 |  | October 3, 2015 |
| Restricted Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 510 |  |  | $ | 34.43 |  |  | 554 |  |  | $ | 32.72 |  |
| Awarded |  | 172 |  |  | 29.45 |  |  | 134 |  |  | 36.28 |  |
| Vested |  | (174 | ) |  | 28.30 |  |  | (169 | ) |  | 30.39 |  |
| Forfeited |  | (27 | ) |  | 34.09 |  |  | (9 | ) |  | 32.31 |  |
| Non-vested at end of period |  | 481 |  |  | $ | 34.89 |  |  | 510 |  |  | $ | 34.44 |  |

[0000038725-16-000438:notes:40]
As of October 1, 2016, there was $9.2 million of total unrecognized compensation cost related to non-vested restricted stock/stock unit awards granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.38 years.


## us-gaap:EarningsPerShareTextBlock

[0000038725-16-000438:notes:41]
[same as prior period, unchanged from 0000038725-16-000385:notes:42]

[0000038725-16-000438:notes:42]
[same as prior period, unchanged from 0000038725-16-000385:notes:43]

[0000038725-16-000438:notes:43]
[same as prior period, unchanged from 0000038725-16-000385:notes:44]

[0000038725-16-000438:notes:44]
[same as prior period, unchanged from 0000038725-16-000385:notes:45]

[0000038725-16-000438:notes:45]
|  | Third Quarter Ended |  | Nine Months Ended |
| (In millions, except per share amounts) | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 23.7 |  |  | $ | 20.8 |  |  | $ | 61.1 |  |  | $ | 56.8 |  |
| Less: Undistributed earnings allocated to participating securities | 0.2 |  |  | 0.2 |  |  | 0.6 |  |  | 0.5 |  |
| Less: Undistributed earnings allocated to redeemable noncontrolling interest | 0.1 |  |  | 0.2 |  |  | 0.8 |  |  | 0.4 |  |
|  | $ | 23.4 |  |  | $ | 20.4 |  |  | $ | 59.7 |  |  | $ | 55.9 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Basic |  |  |  |  |  |  |  |  |  |
| Weighted average common shares | 46.3 |  |  | 46.9 |  |  | 46.2 |  |  | 47.4 |  |
| Diluted |  |  |  |  |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |
| Non-participating employee stock options and performance awards | 0.6 |  |  | 0.4 |  |  | 0.5 |  |  | 0.4 |  |
| Adjusted weighted average common shares | 46.9 |  |  | 47.3 |  |  | 46.7 |  |  | 47.8 |  |
| Basic earnings per share | $ | 0.51 |  |  | $ | 0.44 |  |  | $ | 1.29 |  |  | $ | 1.18 |  |
| Diluted earnings per share | $ | 0.50 |  |  | $ | 0.43 |  |  | $ | 1.28 |  |  | $ | 1.17 |  |
| Anti-dilutive stock options | 0.2 |  |  | 0.5 |  |  | 0.6 |  |  | 0.3 |  |


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0000038725-16-000438:notes:46]
[same as prior period, unchanged from 0000038725-16-000385:notes:47]

[0000038725-16-000438:notes:47]
The Company has equity interests in various companies for various strategic purposes.  The investments are accounted for under the equity method and are included in “Other assets” on the Company’s condensed consolidated balance sheets.  The carrying amount of the investments is adjusted for the Company's proportionate share of earnings, losses, and dividends.  The investments are not considered material to the Company’s financial position, neither individually nor in the aggregate.  The Company’s proportionate share of earnings from its equity interests, included in the "Other income, net" line of the Company's condensed consolidated statements of income, were immaterial for the third quarters and nine months ended October 1, 2016 and October 3, 2015.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000038725-16-000438:notes:48]
As of October 1, 2016 and January 2, 2016, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-16-000438:notes:49]
| (In millions) | October 1, 2016 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 3.4 |  | $ | 3.4 |  | $ | — |  | $ | — |  |
|  | January 2, 2016 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 3.9 |  | $ | 3.9 |  | $ | — |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-16-000438:notes:50]
[same as prior period, unchanged from 0000038725-16-000385:notes:51]

[0000038725-16-000438:notes:51]
[same as prior period, unchanged from 0000038725-16-000385:notes:52]

[0000038725-16-000438:notes:52]
[same as prior period, unchanged from 0000038725-16-000385:notes:53]

[0000038725-16-000438:notes:53]
[same as prior period, unchanged from 0000038725-16-000385:notes:54]

[0000038725-16-000438:notes:54]
[same as prior period, unchanged from 0000038725-16-000385:notes:55]

[0000038725-16-000438:notes:55]
The Company's Level 1 assets consist of cash equivalents which are generally made up of foreign bank guaranteed certificates of deposit.

[0000038725-16-000438:notes:56]
Total debt, including current maturities, have carrying amounts of $190.1 million and $220.7 million and estimated fair values of $194 million and $225 million as of October 1, 2016 and January 2, 2016, respectively.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.

[0000038725-16-000438:notes:57]
As of October 1, 2016, the Company had no assets held for sale.  At January 2, 2016, $1.6 million of assets were held for sale, recorded at carrying value in the Water Systems segment relating to an idle facility in Brazil.  The sale of the facility in Brazil was completed during the third quarter of 2016.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-16-000438:notes:58]
[same as prior period, unchanged from 0000038725-16-000385:notes:59]

[0000038725-16-000438:notes:59]
[same as prior period, unchanged from 0000038725-16-000385:notes:60]

[0000038725-16-000438:notes:60]
| (In millions) |  | October 1, 2016 |  | January 2, 2016 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortized intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.5 |  |  | $ | (6.4 | ) |  | $ | 7.4 |  |  | $ | (6.2 | ) |
| Technology |  | 7.5 |  |  | (5.2 | ) |  | 7.5 |  |  | (4.8 | ) |
| Customer relationships |  | 135.0 |  |  | (48.4 | ) |  | 132.6 |  |  | (42.3 | ) |
| Software |  | 2.5 |  |  | (1.8 | ) |  | 2.5 |  |  | (1.7 | ) |
| Other |  | 0.3 |  |  | (0.3 | ) |  | 1.0 |  |  | (1.0 | ) |
| Total |  | $ | 152.8 |  |  | $ | (62.1 | ) |  | $ | 151.0 |  |  | $ | (56.0 | ) |
| Unamortized intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 47.6 |  |  | — |  |  | 46.4 |  |  | — |  |
| Total intangibles |  | $ | 200.4 |  |  | $ | (62.1 | ) |  | $ | 197.4 |  |  | $ | (56.0 | ) |

[0000038725-16-000438:notes:61]
Amortization expense related to intangible assets for the third quarters ended October 1, 2016 and October 3, 2015 was $2.2 million and $2.1 million, respectively and $6.3 million and $6.5 million for the nine months ended October 1, 2016 and October 3, 2015, respectively.

[0000038725-16-000438:notes:62]
[same as prior period, unchanged from 0000038725-16-000385:notes:63]

[0000038725-16-000438:notes:63]
| (In millions) |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | 2020 |
|  |  | $ | 8.6 |  |  | $ | 8.5 |  |  | $ | 8.4 |  |  | $ | 8.3 |  |  | $ | 8.2 |  |

[0000038725-16-000438:notes:64]
The change in the carrying amount of goodwill by reporting segment for the nine months ended October 1, 2016, is as follows:

[0000038725-16-000438:notes:65]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Consolidated |
| Balance as of January 2, 2016 |  | $ | 136.8 |  |  | $ | 63.0 |  |  | $ | 199.8 |  |
| Acquisitions |  | — |  |  | 0.8 |  |  | 0.8 |  |
| Foreign currency translation |  | 1.7 |  |  | (0.3 | ) |  | 1.4 |  |
| Balance as of October 1, 2016 |  | $ | 138.5 |  |  | $ | 63.5 |  |  | $ | 202.0 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-16-000438:notes:66]
[same as prior period, unchanged from 0000038725-16-000385:notes:67]

[0000038725-16-000438:notes:67]
The Company’s effective tax rate from continuing operations for the nine month period ended October 1, 2016 was 25.3 percent as compared to 11.7 percent for the nine month period ended October 3, 2015.

[0000038725-16-000438:notes:68]
[same as prior period, unchanged from 0000038725-16-000385:notes:69]

[0000038725-16-000438:notes:69]
In addition during the three month period ended April 4, 2015, the Company settled the liability for the noncontrolling interest of a subsidiary during the first quarter.  This transaction created additional accretive benefits for the Company from the reversal of a deferred tax liability created in 2012 when the Company acquired the controlling interest and realized a gain on the then equity investment in such subsidiary. The Company also realized a gain on the mandatorily redeemable noncontrolling interest liability.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000038725-16-000438:notes:70]
ACCOUNTING PRONOUNCEMENTS

[0000038725-16-000438:notes:71]
Adoption of New Accounting Standards

[0000038725-16-000438:notes:72]
In March 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2016-09, Compensation - Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting.  This standard simplifies several aspects of the accounting for employee share-based payment transactions including the recognition of excess tax benefits and deficiencies, the classification of those excess tax benefits on the statement of cash flows, an accounting policy election for forfeitures, the amount an employer can withhold to cover income taxes and still qualify for equity classification, and the classification of those taxes paid on the statement of cash flows. This ASU is effective for annual and interim periods beginning after December 15, 2016 with early adoption permitted.

[0000038725-16-000438:notes:73]
The Company early adopted ASU 2016-09 during the second quarter ended July 2, 2016.  The primary impact of adoption was the recognition of excess tax benefits or deficiencies in the provision for income taxes rather than paid-in capital for all periods in fiscal year 2016.  The Company has elected to continue its current policy of estimating forfeitures rather than recognizing forfeitures when they occur.

[0000038725-16-000438:notes:74]
Under ASU 2016-09, excess income tax benefits from stock-based compensation arrangements are classified as cash flows from operations, rather than as cash flows from financing activities.  The Company elected to apply the cash flow presentation requirements prospectively.

[0000038725-16-000438:notes:75]
The standard also clarifies that cash flows related to employee taxes paid by withheld shares should be classified as a financing activity.  This provision had no impact to the Company, because these cash flows have historically been presented as financing activities.

[0000038725-16-000438:notes:76]
Early adoption of the standard requires reflected adjustments as of January 3, 2016, the beginning of the annual period that includes the interim period of adoption.  As such, previously reported first quarter 2016 results were impacted as follows:

[0000038725-16-000438:notes:77]
| (In thousands, except per share amounts) | First Quarter Ended April 2, 2016 |
|  | As previously reported |  | Adjustment |  | As adjusted |
| Income statements: |  |  |  |  |  |
| Income tax expense | $ | 4,955 |  |  | $ | 12 |  |  | $ | 4,967 |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 13,457 |  |  | $ | (12 | ) |  | $ | 13,445 |  |
| Basic earnings per share | $ | 0.28 |  |  | $ | — |  |  | $ | 0.28 |  |
| Diluted earnings per share | $ | 0.28 |  |  | $ | — |  |  | $ | 0.28 |  |
| Diluted weighted average shares outstanding | 46,445 |  |  | 60 |  |  | 46,505 |  |
| Cash flow statements: |  |  |  |  |  |
| Net cash from operating activities | $ | (437 | ) |  | $ | 53 |  |  | $ | (384 | ) |
| Net cash from financing activities | $ | 3,572 |  |  | $ | (53 | ) |  | $ | 3,519 |  |
| Balance sheets: |  |  |  |  |  |
| Additional capital | $ | 219,400 |  |  | $ | 12 |  |  | $ | 219,412 |  |
| Retained earnings | $ | 502,512 |  |  | $ | (12 | ) |  | $ | 502,500 |  |

[0000038725-16-000438:notes:78]
In April 2015, the FASB issued ASU 2015-03, Interest - Imputation of Interest (Subtopic 835-30): Simplifying the Presentation of Debt Issuance Costs, which requires debt issuance costs to be presented in the balance sheet as a direct deduction from the associated debt liability instead of a deferred asset.  The standard does not change the amortization of debt issuance costs, which will continue to follow the existing accounting guidance.  The Company adopted ASU 2015-03 during the first quarter ended April 2, 2016.  The retrospective adoption of this ASU required a total of approximately $0.3 million of unamortized debt issuance costs as of year-end 2015 to be reclassified from "Other assets" and "Other current assets" to a direct deduction from "Long-term debt" in the Company's condensed consolidated balance sheet as of January 2, 2016.  In addition, there were no impacts to the Company's results of operations, retained earnings, or cash flows in the current or previous interim and annual reporting periods.

[0000038725-16-000438:notes:79]
Accounting Standards Issued But Not Yet Adopted

[0000038725-16-000438:notes:80]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842), which supersedes existing guidance on accounting for leases found in Accounting Standards Codification ("ASC") Topic 840.  This ASU requires lessees to present right-of-use assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months.  The guidance is to be applied using a modified retrospective approach at the beginning of the earliest comparative period in the financial statements and is effective for interim and annual periods beginning after December 15, 2018 with early adoption permitted.  The Company is still in the process of analyzing the effect of this new standard to determine the impact on the Company's consolidated financial position, results of operations, cash flows, and related disclosures.

[0000038725-16-000438:notes:81]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606).  ASU 2014-09 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes current revenue recognition guidance.  In March 2016, the FASB issued ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net).  ASU 2016-08 clarifies the implementation guidance on principal versus agent considerations.  In April 2016, the FASB issued ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing.  ASU 2016-10 clarifies the implementation guidance on identifying performance obligations.  These ASUs are effective for interim and annual reporting periods beginning after December 15, 2017.  Early adoption is permitted, but not before interim and annual reporting periods beginning after December 15, 2016.  Entities have the option of using either a full retrospective or a modified retrospective approach to adopt these standards.  The Company is still in the process of analyzing the effect of these new standards, including the transition method, to determine the impact on the Company's consolidated financial position, results of operations, cash flows, and related disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-16-000438:notes:82]
[same as prior period, unchanged from 0000038725-16-000385:notes:83]

[0000038725-16-000438:notes:83]
The accompanying condensed consolidated balance sheet as of January 2, 2016, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of October 1, 2016, and for the third quarters and nine months ended October 1, 2016 and October 3, 2015 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the third quarter and nine months ended October 1, 2016 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2016.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended January 2, 2016.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-16-000438:notes:84]
[same as prior period, unchanged from 0000038725-16-000385:notes:85]

[0000038725-16-000438:notes:85]
Defined Benefit Plans - As of October 1, 2016, the Company maintained two domestic pension plans and three German pension plans.  The Company used a January 2, 2016 measurement date for these plans.  One of the Company's domestic pension plans covers two management employees (one active employee and one former employee), while the other domestic plan covers all other eligible employees.  The two domestic and three German plans collectively comprise the 'Pension Benefits' disclosure caption.

[0000038725-16-000438:notes:86]
[same as prior period, unchanged from 0000038725-16-000385:notes:87]

[0000038725-16-000438:notes:87]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the third quarters and nine months ended October 1, 2016 and October 3, 2015:

[0000038725-16-000438:notes:88]
| (In millions) | Pension Benefits |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |
| Service cost | $ | 0.3 |  |  | $ | 0.2 |  |  | $ | 0.8 |  |  | $ | 0.8 |  |
| Interest cost | 1.6 |  |  | 1.9 |  |  | 4.7 |  |  | 5.5 |  |
| Expected return on assets | (2.3 | ) |  | (2.4 | ) |  | (7.0 | ) |  | (7.4 | ) |
| Amortization of loss | 0.6 |  |  | 0.8 |  |  | 1.9 |  |  | 2.4 |  |
| Net periodic benefit cost | $ | 0.2 |  |  | $ | 0.5 |  |  | $ | 0.4 |  |  | $ | 1.3 |  |
| Settlement cost | 0.3 |  |  | 0.3 |  |  | 0.9 |  |  | 0.9 |  |
| Total net periodic benefit cost | $ | 0.5 |  |  | $ | 0.8 |  |  | $ | 1.3 |  |  | $ | 2.2 |  |

[0000038725-16-000438:notes:89]
In the nine months ended October 1, 2016, the Company made contributions of $2.1 million to the funded plans.  The amount of contributions to be made to the plans during the calendar year 2016 were finalized by September 15, 2016, based upon the plans' year-end valuation at January 2, 2016, and the funding level required for the plans' year ended January 2, 2016.

[0000038725-16-000438:notes:90]
The following table sets forth the aggregated net periodic benefit cost for the postretirement benefit plan for the third quarters and nine months ended October 1, 2016 and October 3, 2015, respectively:

[0000038725-16-000438:notes:91]
| (In millions) | Other Benefits |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 0.1 |  |  | 0.1 |  |  | 0.3 |  |  | 0.3 |  |
| Expected return on assets | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of prior service cost | 0.1 |  |  | 0.1 |  |  | 0.3 |  |  | 0.3 |  |
| Amortization of loss | — |  |  | 0.1 |  |  | — |  |  | 0.3 |  |
| Net periodic benefit cost | $ | 0.2 |  |  | $ | 0.3 |  |  | $ | 0.6 |  |  | $ | 0.9 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Total net periodic benefit cost | $ | 0.2 |  |  | $ | 0.3 |  |  | $ | 0.6 |  |  | $ | 0.9 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000038725-16-000438:notes:92]
[same as prior period, unchanged from 0000038725-16-000385:notes:93]

[0000038725-16-000438:notes:93]
On July 1, 2014, the Company announced a plan to close its Wittlich, Germany manufacturing facility.  As part of this action, the Company is transferring the existing Wittlich manufacturing activity to its Brno, Czech Republic facility.  The Company will maintain its European Water Systems headquarters and distribution center in Wittlich, only the manufacturing operations are relocating.  The realignment began in the third quarter of 2014 and is expected to conclude by the end of 2016.  Charges for the realignment are expected to be approximately $19.4 million and will include severance expenses, professional service fees, asset write-offs, and temporarily leased facilities costs.

[0000038725-16-000438:notes:94]
Costs incurred in the third quarter and nine months ended October 1, 2016, included in the “Restructuring (income)/expense” line of the Company's condensed consolidated statements of income, are as follows:

[0000038725-16-000438:notes:95]
|  |  | Third Quarter Ended |
|  |  | October 1, 2016 |
| (In millions) |  | Water Systems |  | Fueling Systems |  | Other |  | Consolidated |
| Employee severance |  | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.1 |  |
| Equipment relocation |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Asset write-off |  | (2.0 | ) |  | — |  |  | — |  |  | (2.0 | ) |
| Other |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Total |  | $ | (1.8 | ) |  | $ | 0.1 |  |  | $ | — |  |  | $ | (1.7 | ) |

[0000038725-16-000438:notes:96]
|  |  | Nine Months Ended |
|  |  | October 1, 2016 |
| (In millions) |  | Water Systems |  | Fueling Systems |  | Other |  | Consolidated |
| Employee severance |  | $ | 0.1 |  |  | $ | — |  |  | $ | — |  |  | $ | 0.1 |  |
| Equipment relocation |  | — |  |  | 0.1 |  |  | — |  |  | 0.1 |  |
| Asset write-off |  | (2.0 | ) |  | 0.4 |  |  | — |  |  | (1.6 | ) |
| Other |  | 0.5 |  |  | — |  |  | — |  |  | 0.5 |  |
| Total |  | $ | (1.4 | ) |  | $ | 0.5 |  |  | $ | — |  |  | $ | (0.9 | ) |

[0000038725-16-000438:notes:97]
The $2.0 million gain disclosed above within the "asset write-off" caption relates to the sale of a facility in Brazil that was completed during the third quarter of 2016.

[0000038725-16-000438:notes:98]
Restructuring expenses for the third quarter and nine months ended October 3, 2015 were approximately $1.3 million and $2.5 million, primarily for the Water Systems realignment.

[0000038725-16-000438:notes:99]
As of October 1, 2016, there were no restructuring reserves.  As of October 3, 2015, there were $3.6 million of restructuring reserves.  The restructuring reserves were primarily for severance.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000038725-16-000438:notes:100]
[same as prior period, unchanged from 0000038725-16-000385:notes:100]

[0000038725-16-000438:notes:101]
|  | Third Quarter Ended |  | Nine Months Ended |
| (In millions) | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |
|  | Net sales to external customers |
| Water Systems | $ | 182.0 |  |  | $ | 173.5 |  |  | $ | 545.4 |  |  | $ | 544.3 |  |
| Fueling Systems | 57.8 |  |  | 59.0 |  |  | 164.9 |  |  | 161.3 |  |
| Other | — |  |  | — |  |  | — |  |  | — |  |
| Consolidated | $ | 239.8 |  |  | $ | 232.5 |  |  | $ | 710.3 |  |  | $ | 705.6 |  |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |
|  | Operating income/(loss) |
| Water Systems | $ | 30.0 |  |  | $ | 23.1 |  |  | $ | 85.6 |  |  | $ | 66.8 |  |
| Fueling Systems | 15.2 |  |  | 15.4 |  |  | 40.9 |  |  | 37.4 |  |
| Other | (13.4 | ) |  | (10.7 | ) |  | (40.9 | ) |  | (37.4 | ) |
| Consolidated | $ | 31.8 |  |  | $ | 27.8 |  |  | $ | 85.6 |  |  | $ | 66.8 |  |
|  | October 1, 2016 |  | January 2, 2016 |  |  |  |  |
|  | Total assets |  |  |  |  |
| Water Systems | $ | 706.4 |  |  | $ | 677.6 |  |  |  |  |  |
| Fueling Systems | 250.1 |  |  | 248.5 |  |  |  |  |  |
| Other | 88.1 |  |  | 70.0 |  |  |  |  |  |
| Consolidated | $ | 1,044.6 |  |  | $ | 996.1 |  |  |  |  |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0000038725-16-000438:notes:102]
The schedule below sets forth equity changes in the nine months ended October 1, 2016:

[0000038725-16-000438:notes:103]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of January 2, 2016 | $ | 4,622 |  |  | $ | 216,472 |  |  | $ | 498,214 |  |  | $ | (51,558 | ) |  | $ | (110,050 | ) |  | $ | 1,765 |  |  | $ | 559,465 |  |  | $ | 6,856 |  |
| Net income |  |  |  |  | 61,103 |  |  |  |  |  |  | 458 |  |  | 61,561 |  |  | (47 | ) |
| Adjustment to Impo redemption value |  |  |  |  | (834 | ) |  |  |  |  |  |  |  | (834 | ) |  | 834 |  |
| Dividends on common stock |  |  |  |  | (13,810 | ) |  |  |  |  |  |  |  | (13,810 | ) |  |  |
| Common stock issued | 16 |  |  | 3,176 |  |  |  |  |  |  |  |  |  |  | 3,192 |  |  |  |
| Common stock repurchased | (21 | ) |  |  |  | (6,172 | ) |  |  |  |  |  |  |  | (6,193 | ) |  |  |
| Share-based compensation | 13 |  |  | 5,899 |  |  |  |  |  |  |  |  |  |  | 5,912 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | (673 | ) |  | (673 | ) |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | 12,098 |  |  | 44 |  |  | 12,142 |  |  | (46 | ) |
| Pension liability, net of tax |  |  |  |  |  |  | 1,429 |  |  |  |  |  |  | 1,429 |  |  |  |
| Balance as of October 1, 2016 | $ | 4,630 |  |  | $ | 225,547 |  |  | $ | 538,501 |  |  | $ | (50,129 | ) |  | $ | (97,952 | ) |  | $ | 1,594 |  |  | $ | 622,191 |  |  | $ | 7,597 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-16-000438:notes:104]
[same as prior period, unchanged from 0000038725-16-000385:notes:104]

[0000038725-16-000438:notes:105]
Property, plant, and equipment is the major asset group in "Other" of total assets as of October 1, 2016 and January 2, 2016.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-16-000438:notes:106]
[same as prior period, unchanged from 0000038725-16-000385:notes:106]


## us-gaap:SubsequentEventsTextBlock

[0000038725-16-000438:notes:107]
SUBSEQUENT EVENT

[0000038725-16-000438:notes:108]
On October 28, 2016, the Company entered into the Third Amended and Restated Credit Agreement among Franklin Electric Co., Inc., Franklin Electric B.V., a Netherlands private company with limited liability (“Franklin B.V”, and together with Franklin Electric Co., Inc., the “Borrowers”), JPMorgan Chase Bank, N.A. (“JPMorgan”), as administrative agent, and Bank of America, N.A., as Syndication Agent, and the lenders identified therein (the “Third Amended and Restated Credit Agreement”.  JPMorgan and Bank of America Merrill Lynch were joint bookrunners and joint lead arrangers.  The Third Amended and Restated Credit Agreement extended the maturity date of the Company’s Second Amended and Restated Credit Agreement, as amended (which is referred to in this footnote as the “Previous Credit Agreement”) to October 28, 2021 and increased the commitment amount from $150.0 million to $300.0 million.

[0000038725-16-000438:notes:109]
The Third Amended and Restated Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million) subject to the conditions contained therein.  All of the Company's present and future material domestic subsidiaries unconditionally guaranty all of the Borrowers' obligations under and in connection with the Third Amended and Restated Credit Agreement.  Additionally, the Company unconditionally guaranties all of the obligations of Franklin B.V. under the Third Amended and Restated Credit Agreement.

[0000038725-16-000438:notes:110]
Under the Third Amended and Restated Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of .100% to .275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears.

[0000038725-16-000438:notes:111]
The Third Amended and Restated Credit Agreement contains customary affirmative and negative covenants. The affirmative covenants include financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The affirmative covenants also include financial covenants with a maximum leverage ratio of 3.50 to 1.00 (using net debt in the measure of leverage ratio, whereas the Previous Credit Agreement used gross debt in such measure) and an interest coverage ratio equal to or greater than 3.00 to 1.00 (using EBITDA in the measure, whereas the Previous Credit Agreement used EBIT). Under the Third Amended and Restated Credit Agreement, the priority debt cap is measured as 20 percent of total tangible assets, whereas the Previous Credit Agreement used net equity rather than total tangible assets. The negative covenants include limitations on loans or advances, investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets (which restrictions on sales and transfers of assets were reduced to some degree versus the Previous Credit Agreement).

[0000038725-16-000438:notes:112]
As was the case in the Previous Credit Agreement, the Third Amended and Restated Credit Agreement also contains customary events of defaults (with customary grace periods, as applicable, for certain of those events of default). If an event of default occurs, the Third Amended and Restated Credit Agreement provides that (i) the commitments may be terminated and (ii) the loans then outstanding may be declared due and payable. For certain events of default relating to insolvency, bankruptcy or liquidation, the commitments are automatically terminated and the loans outstanding automatically become due and payable. The full amount of the aggregate commitment may be borrowed as multicurrency loans, in Euros, Japanese Yen, Australian Dollars, Pounds Sterling, Canadian Dollars or any other agreed currency.

[0000038725-16-000438:notes:113]
As in the Previous Credit Agreement, the Third Amended and Restated Credit Agreement also provides for a swingline loan sub-facility of up to $15.0 million (with an additional discretionary amount of up to $15.0 million, which was not included under the Previous Credit Agreement), and a letter of credit subfacility of up to $50.0 million (increased from $25.0 million under the Previous Credit Agreement).

[0000038725-16-000438:notes:114]
Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of .75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Third Amended and Restated Credit Agreement.  The Third Amended and Restated Credit Agreement also includes a competitive bid option that permits the Borrowers to request that the lenders provide bids for the interest rate that will apply to specific loans.

[0000038725-16-000438:notes:115]
In addition, on October 28, 2016, the Company entered into (1) First Amendment (the “First Amendment”) to Note Purchase and Private Shelf Agreement dated as of May 27, 2015 (the “New York Life Agreement”) by and among NYL Investors LLC and each of the undersigned holders of notes that are signatories thereto, and (2) Amendment No. 1 (“Amendment No. 1” and together with the First Amendment, the “Private Shelf Amendments”) to Third Amended and Restated Note Purchase and Private Shelf Agreement dated as of May 28, 2015 (the “Prudential Agreement”) by and among the Company and PGIM, Inc. (“Prudential”) and the Prudential affiliates party thereto.  The Private Shelf Amendments were intended to make the covenants within the New York Life Agreement and Prudential Agreement consistent with those covenants that were modified in the Third Amended and Restated Credit Agreement as compared to the Previous Credit Agreement.

[0000038725-16-000438:notes:116]
The foregoing description is qualified in its entirety by reference to the Third Amended and Restated Credit Agreement and the Private Shelf Amendments, copies of which are filed as Exhibits 10.2 - 10.4 to this Quarterly Report on Form 10-Q and are incorporated herein by reference.
