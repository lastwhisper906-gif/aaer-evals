# FELE MD&A — 0000038725-16-000438


## mdna

[0000038725-16-000438:mdna:1]
[same as prior period, unchanged from 0000038725-16-000385:mdna:1]

[0000038725-16-000438:mdna:2]
Third Quarter 2016 vs. Third Quarter 2015

[0000038725-16-000438:mdna:3]
[same as prior period, unchanged from 0000038725-16-000385:mdna:3]

[0000038725-16-000438:mdna:4]
Sales and earnings in the third quarter of 2016 increased from the third quarter last year.  The sales increase was due to price and volume partially offset by the negative impact of foreign currency translation.  The Company's consolidated gross profit was $85.5 million for the third quarter of 2016, an increase of $8.7 million or about 11 percent from the prior year’s third quarter.

[0000038725-16-000438:mdna:5]
[same as prior period, unchanged from 0000038725-16-000385:mdna:5]

[0000038725-16-000438:mdna:6]
[same as prior period, unchanged from 0000038725-16-000385:mdna:6]

[0000038725-16-000438:mdna:7]
Net sales in the third quarter of 2016 were $239.8 million, an increase of $7.3 million or about 3 percent compared to 2015 third quarter sales of $232.5 million.  Sales revenue decreased by $0.5 million in the third quarter of 2016 due to foreign currency translation.  The sales change in the third quarter of 2016, excluding foreign currency translation, was an increase of $7.8 million or about 3 percent.

[0000038725-16-000438:mdna:8]
|  | Net Sales |
| (In millions) | Q3 2016 |  | Q3 2015 |  | 2016 v 2015 |
| Water Systems | $ | 182.0 |  |  | $ | 173.5 |  |  | $ | 8.5 |  |
| Fueling Systems | 57.8 |  |  | 59.0 |  |  | (1.2 | ) |
| Consolidated | $ | 239.8 |  |  | $ | 232.5 |  |  | $ | 7.3 |  |

[0000038725-16-000438:mdna:9]
[same as prior period, unchanged from 0000038725-16-000385:mdna:9]

[0000038725-16-000438:mdna:10]
Water Systems sales were $182.0 million in the third quarter 2016, an increase of $8.5 million or about 5 percent versus the third quarter 2015 sales of $173.5 million.  Water Systems sales were reduced by $0.2 million in the quarter due to foreign currency translation.  Excluding foreign currency translation, Water Systems sales were up about 5 percent compared to the third quarter 2015.

[0000038725-16-000438:mdna:11]
Water Systems sales in the U.S. and Canada represented 37 percent of consolidated sales and increased by about 2 percent compared to the prior year.  Water Systems sales in the U.S and Canada were reduced by $0.1 million in the quarter due to foreign currency translation.  In the third quarter 2016, sales of groundwater pumping equipment grew by about 13 percent.  The growth in groundwater equipment sales was led by a 17 percent increase in residential systems.  Sales of groundwater pumping systems for agricultural applications grew by about 2 percent.  Third quarter 2016 sales of mobile dewatering equipment in the U.S. and Canada declined sharply due to reduced demand from equipment rental customer.

[0000038725-16-000438:mdna:12]
Water Systems sales in Europe, the Middle East and Africa were about 16 percent of consolidated sales and declined by about 3 percent compared to the third quarter 2015.  Water Systems sales were reduced by about 3 percent in the quarter due to foreign currency translation.  Sales in  the Europe, Middle East and Africa region were flat excluding the impact of foreign currency translation.  Within this region, our business unit in Turkey had increased sales which were offset by lower sales in other regional business units primarily due to the political and economic turmoil in certain parts of the region as well as the lower price of oil.

[0000038725-16-000438:mdna:13]
Water Systems sales in Latin America were about 15 percent of consolidated sales for the third quarter and increased by about 15 percent compared to the third quarter of the prior year. Water Systems sales grew by $0.9 million or about 3 percent in the quarter due to foreign currency translation.  Excluding the impact of foreign currency translation, Latin American sales increased by about 12 percent compared to the third quarter 2015.  This growth in sales was led by increased sales in Brazil and Mexico.  This sales growth is a result of increasing demand for Franklin submersible pumps and motors, customer acceptance of the many product line upgrades that have been implemented over the past two years, and general market conditions.

[0000038725-16-000438:mdna:14]
Water Systems sales in the Asia Pacific region were 8 percent of consolidated sales and grew about 19 percent compared to the third quarter prior year.  Excluding the impact of foreign currency translation, Asia Pacific sales grew by about 18 percent compared to the third quarter 2015.  The Asia Pacific region experienced year over year growth in groundwater product sales of 24 percent due in part to generally favorable weather conditions.

[0000038725-16-000438:mdna:15]
[same as prior period, unchanged from 0000038725-16-000385:mdna:17]

[0000038725-16-000438:mdna:16]
Fueling Systems sales represented 24 percent of consolidated sales and were $57.8 million in the third quarter 2016, a decrease of $1.2 million or about 2 percent versus the third quarter 2015 sales of $59.0 million.  Fueling Systems sales decreased by $0.3 million or about 1 percent in the quarter due to foreign currency translation.  Fueling Systems sales decreased by $0.9 million or about 1 percent after excluding foreign currency translation.

[0000038725-16-000438:mdna:17]
Fueling Systems sales in the U.S. and Canada grew by about 5 percent during the quarter with most of the sales growth coming from fuel pumping products, piping and containment systems.  Fueling Systems revenues were down in Europe and Asia Pacific in part due to lower capital spending on new filling station development by major oil companies and due to the timing of customer shipments.

[0000038725-16-000438:mdna:18]
[same as prior period, unchanged from 0000038725-16-000385:mdna:20]

[0000038725-16-000438:mdna:19]
Cost of sales as a percent of net sales for the third quarter of 2016 and 2015 was 64.4 percent and 67.0 percent, respectively. Correspondingly, the gross profit margin increased to 35.6 percent from 33.0 percent, a 260 basis point improvement.  The Company’s consolidated gross profit was $85.5 million for the third quarter of 2016, an increase of $8.7 million, or about 11 percent, from the third quarter of 2015 gross profit of $76.8 million.  The gross profit margin increase was primarily due to favorable pricing, lower direct material costs and an improved sales mix of Water Systems products.

[0000038725-16-000438:mdna:20]
[same as prior period, unchanged from 0000038725-16-000385:mdna:22]

[0000038725-16-000438:mdna:21]
Selling, general, and administrative (SG&A) expenses were $55.4 million in the third quarter of 2016 compared to $47.7 million in the third quarter of prior year, an increase of $7.7 million or about 16 percent.  The Company’s SG&A expense increase in the quarter was primarily due to higher variable compensation expenses of about $4.0 million.  Marketing and Selling related expenses increased about $1.0 million to support sales growth and Research Development & Engineering (RD&E) expense increased by $0.8 million in the quarter.

[0000038725-16-000438:mdna:22]
Restructuring (Income)/Expense

[0000038725-16-000438:mdna:23]
Restructuring income for the third quarter of 2016 was $1.7 million and caused a $0.02 increase in diluted earnings per share. Restructuring income for the third quarter 2016 included a gain of $2.0 million from the sale of land and building in Brazil and $0.3 million in expenses related to equipment transfers, freight and relocation cost related to the transfer of production activities and other restructuring costs from continued manufacturing realignments.

[0000038725-16-000438:mdna:24]
Restructuring expenses for the third quarter of 2015 were $1.3 million and caused a $0.02 reduction in diluted earnings per share. Restructuring expenses for the third quarter 2015 included $0.6 million in severance cost, $0.1 million in expenses related to equipment transfers, freight and relocation cost primarily in Europe related to the transfer of production activities from Germany to the Czech Republic and $0.6 million of other restructuring costs from continued manufacturing realignments.

[0000038725-16-000438:mdna:25]
[same as prior period, unchanged from 0000038725-16-000385:mdna:26]

[0000038725-16-000438:mdna:26]
Operating income was $31.8 million in the third quarter of 2016, up $4.0 million or about 14 percent from $27.8 million in the third quarter of 2015.

[0000038725-16-000438:mdna:27]
|  |  | Operating income (loss) |
| (In millions) |  | Q3 2016 |  | Q3 2015 |  | 2016 v 2015 |
| Water Systems |  | $ | 30.0 |  |  | $ | 23.1 |  |  | $ | 6.9 |  |
| Fueling Systems |  | 15.2 |  |  | 15.4 |  |  | (0.2 | ) |
| Other |  | (13.4 | ) |  | (10.7 | ) |  | (2.7 | ) |
| Consolidated |  | $ | 31.8 |  |  | $ | 27.8 |  |  | $ | 4.0 |  |

[0000038725-16-000438:mdna:28]
There were specific items in the third quarter of 2016 and 2015 that impacted operating income that were not operational in nature.  In the third quarter of 2016 there were two such items: $1.7 million of restructuring income and $0.3 million related to

[0000038725-16-000438:mdna:29]
executive transition.

[0000038725-16-000438:mdna:30]
In the third quarter of 2015 there were three such items: $1.3 million of restructuring charges, $0.3 million related to executive transition and $0.1 million related to business realignment cost, primarily severance, in targeted fixed cost reduction actions.

[0000038725-16-000438:mdna:31]
The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of operating income after non-GAAP adjustments and percent operating income to net sales after non–GAAP adjustments (operating income margin after non-GAAP adjustments).  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-16-000438:mdna:32]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (In millions) | For the Third Quarter 2016 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income / (Loss) | $ | 30.0 |  | $ | 15.2 |  | $ | (13.4 | ) | $ | 31.8 |  |
| % Operating Income To Net Sales | 16.5 | % | 26.3 | % |  | 13.3 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | (1.8 | ) | $ | 0.1 |  | $ | — |  | $ | (1.7 | ) |
| Non-GAAP | $ | — |  | $ | — |  | $ | 0.3 |  | $ | 0.3 |  |
| Operating Income / (Loss) after Non-GAAP Adjustments | $ | 28.2 |  | $ | 15.3 |  | $ | (13.1 | ) | $ | 30.4 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 15.5 | % | 26.5 | % |  | 12.7 | % |
|  | For the Third Quarter 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income / (Loss) | $ | 23.1 |  | $ | 15.4 |  | $ | (10.7 | ) | $ | 27.8 |  |
| % Operating Income To Net Sales | 13.3 | % | 26.1 | % |  | 12.0 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 1.3 |  | $ | — |  | $ | — |  | $ | 1.3 |  |
| Non-GAAP | $ | 0.1 |  | $ | — |  | $ | 0.3 |  | $ | 0.4 |  |
| Operating Income / (Loss) after Non-GAAP Adjustments | $ | 24.5 |  | $ | 15.4 |  | $ | (10.4 | ) | $ | 29.5 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 14.1 | % | 26.1 | % |  | 12.7 | % |

[0000038725-16-000438:mdna:33]
[same as prior period, unchanged from 0000038725-16-000385:mdna:33]

[0000038725-16-000438:mdna:34]
Water Systems operating income was $30.0 million in the third quarter 2016, up $6.9 million or 30 percent versus the third quarter 2015 as reported and up $3.7 million or 15 percent versus the third quarter 2015 after non-GAAP adjustments.  The third quarter operating income margin was 16.5 percent, up 320 basis points from 13.3 percent in the third quarter of 2015.  The third quarter operating income margin after non-GAAP adjustments was 15.5 percent, an increase of 140 basis points from the 14.1 percent of net sales in the third quarter of 2015 after non-GAAP adjustments.  The increase in basis points was primarily due to improved margins from lower variable costs.

[0000038725-16-000438:mdna:35]
[same as prior period, unchanged from 0000038725-16-000385:mdna:35]

[0000038725-16-000438:mdna:36]
Fueling Systems operating income was $15.2 million in the third quarter of 2016, down $0.2 million or about 1 percent compared to $15.4 million in the third quarter of 2015 as reported, and down $0.1 million or 1 percent compared to $15.4 million after non-GAAP adjustments in the third quarter of 2015.  The third quarter operating income margin was 26.3 percent, an increase of 20 basis points from the as reported 26.1 percent of net sales in the third quarter of 2015.  The third quarter operating income margin after non-GAAP adjustments was 26.5 percent, an increase of 40 basis points from the 26.1 percent of net sales in the third quarter of 2015 after non-GAAP adjustments.  The increase in basis points was primarily due to improved

[0000038725-16-000438:mdna:37]
margins from lower variable costs.

[0000038725-16-000438:mdna:38]
[same as prior period, unchanged from 0000038725-16-000385:mdna:37]

[0000038725-16-000438:mdna:39]
Operating income-other is composed primarily of unallocated general and administrative expenses.  General and administrative expenses after non-GAAP adjustments were higher by about 26 percent, primarily due to higher variable compensation expenses.

[0000038725-16-000438:mdna:40]
[same as prior period, unchanged from 0000038725-16-000385:mdna:39]

[0000038725-16-000438:mdna:41]
Interest expense for the third quarter of 2016 and 2015 was $2.0 million and $2.6 million, respectively, lower primarily due to reduced average borrowings outstanding.

[0000038725-16-000438:mdna:42]
[same as prior period, unchanged from 0000038725-16-000385:mdna:41]

[0000038725-16-000438:mdna:43]
Other income or expense was income of $1.4 million in the third quarter of 2016 and income of $1.6 million in the third quarter of 2015.  Included in other income in the third quarter of 2016 was income from minority interests of $1.2 million and interest income of $0.2 million, primarily derived from the investment of cash balances in short-term securities.  Included in other income in the third quarter of 2015 was minority income of $1.0 million and interest income of $0.3 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-16-000438:mdna:44]
[same as prior period, unchanged from 0000038725-16-000385:mdna:43]

[0000038725-16-000438:mdna:45]
Foreign currency-based transactions produced a gain for the third quarter of 2016 of $0.4 million.  Foreign currency-based transactions produced a loss for the third quarter of 2015 of $0.1 million.

[0000038725-16-000438:mdna:46]
[same as prior period, unchanged from 0000038725-16-000385:mdna:45]

[0000038725-16-000438:mdna:47]
The provision for income taxes in the third quarter of 2016 and 2015 was $7.9 million and $5.7 million, respectively.  The effective tax rate for the third quarter of 2016 was about 27 percent, flat to the third quarter 2015 tax rate before discrete adjustments.  The tax rate after discrete adjustments as a percentage of pre-tax earnings for the third quarter of 2016 was about 25 percent primarily due to the favorable impact from share based equity compensation payments.  The projected tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings and reduced taxes on foreign and repatriated earnings after the restructuring of certain foreign entities.  The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations, current cash on hand and available credit.

[0000038725-16-000438:mdna:48]
[same as prior period, unchanged from 0000038725-16-000385:mdna:47]

[0000038725-16-000438:mdna:49]
Net income for the third quarter of 2016 was $23.7 million compared to the prior year third quarter net income of $21.0 million.  Net income attributable to Franklin Electric Co., Inc. for the third quarter of 2016 was $23.7 million, or $0.50 per diluted share, compared to the prior year third quarter net income attributable to Franklin Electric Co., Inc. of $20.8 million or $0.43 per diluted share.  Earnings after non-GAAP adjustments for the third quarter of 2016 were $22.6 million, or $0.48 per diluted share, compared to the prior year third quarter earnings after non-GAAP adjustments of $21.4 million or $0.45 per diluted share.

[0000038725-16-000438:mdna:50]
There were specific items in the third quarter of 2016 and 2015 that impacted net income attributable to Franklin Electric Co., Inc. that were not operational in nature.  The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of earnings after non-GAAP adjustments and adjusted EPS.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-16-000438:mdna:51]
| Earnings Before and After Non-GAAP Adjustments | For the Third Quarter Ended |
| (In millions) | 2016 | 2015 | Change |
| Net Income attributable to Franklin Electric Co., Inc. Reported | $ | 23.7 |  | $ | 20.8 |  | 14 | % |
| Allocated Undistributed Earnings | $ | (0.3 | ) | $ | (0.4 | ) |  |
| Earnings for EPS Calculations | $ | 23.4 |  | $ | 20.4 |  | 15 | % |
| Non-GAAP adjustments, before tax: |  |  |  |
| Restructuring | $ | (1.7 | ) | $ | 1.3 |  |  |
| Non-GAAP items | $ | 0.3 |  | $ | 0.4 |  |  |
| Non-GAAP adjustments, net of tax: |  |  |  |
| Restructuring | $ | (1.0 | ) | $ | 0.8 |  |  |
| Non-GAAP items | $ | 0.2 |  | $ | 0.2 |  |  |
| Earnings after Non-GAAP Adjustments | $ | 22.6 |  | $ | 21.4 |  | 6 | % |

[0000038725-16-000438:mdna:52]
| Earnings Per Share Before and After Non-GAAP Adjustments | For the Third Quarter Ended |
| (In millions, except per share data) | 2016 | 2015 | Change |
| Average Fully Diluted Shares Outstanding | 46.9 |  | 47.3 |  | (1 | )% |
| Fully Diluted Earnings Per Share ("EPS") Reported | $ | 0.50 |  | $ | 0.43 |  | 16 | % |
| Restructuring per Share, net of tax | $ | (0.02 | ) | $ | 0.02 |  |  |
| Non-GAAP items, net of tax | $ | — |  | $ | — |  |  |
| Fully Diluted EPS after Non-GAAP Adjustments (Adjusted EPS) | $ | 0.48 |  | $ | 0.45 |  | 7 | % |

[0000038725-16-000438:mdna:53]
First Nine Months of 2016 vs. First Nine Months of 2015

[0000038725-16-000438:mdna:54]
[same as prior period, unchanged from 0000038725-16-000385:mdna:53]

[0000038725-16-000438:mdna:55]
Sales and earnings in the first nine months of 2016 were up from the same period last year.  The sales increase was related to volume and price increases partially offset by the negative impact of foreign currency translation on sales. The Company's consolidated gross profit was $250.4 million for the first nine months of 2016, an increase of $21.9 million or about 10 percent from the first nine months of 2015.

[0000038725-16-000438:mdna:56]
[same as prior period, unchanged from 0000038725-16-000385:mdna:55]

[0000038725-16-000438:mdna:57]
[same as prior period, unchanged from 0000038725-16-000385:mdna:56]

[0000038725-16-000438:mdna:58]
Net sales in the first nine months of 2016 were $710.3 million, an increase of $4.7 million or about 1 percent compared to sales in the first nine months of 2015 of $705.6 million.  The incremental impact of sales from acquired businesses was $0.7 million.  Sales revenue decreased by $21.8 million or about 3 percent in the first nine months of 2016 due to foreign currency translation.  The sales change in the first nine months of 2016, excluding acquisitions and foreign currency translation, was an increase of $25.8 million or about 4 percent.

[0000038725-16-000438:mdna:59]
26

[0000038725-16-000438:mdna:60]
| (In millions) | YTD October 1, 2016 |  | YTD October 3, 2015 |  | 2016 v 2015 |
|  | Net Sales |
| Water Systems | $ | 545.4 |  |  | $ | 544.3 |  |  | $ | 1.1 |  |
| Fueling Systems | 164.9 |  |  | 161.3 |  |  | 3.6 |  |
| Consolidated | $ | 710.3 |  |  | $ | 705.6 |  |  | $ | 4.7 |  |

[0000038725-16-000438:mdna:61]
[same as prior period, unchanged from 0000038725-16-000385:mdna:59]

[0000038725-16-000438:mdna:62]
Water Systems sales were $545.4 million in the first nine months 2016, flat versus the first nine months 2015.  The incremental impact of sales from acquired businesses was $0.7 million.  Foreign currency translation rate changes decreased sales $20.7 million, or about 4 percent, compared to sales in the first nine months of 2015.  The Water Systems sales change in the first nine months of 2016, excluding acquisitions and foreign currency translation, was an increase of $21.1 million or about 4 percent.

[0000038725-16-000438:mdna:63]
Water Systems sales in the U.S. and Canada were 37 percent of consolidated sales and increased by about 2 percent compared to the first nine months of 2015.  Sales revenue decreased by $1.9 million or about 1 percent in the first nine months of 2016 due to foreign currency translation.  Sales of groundwater pumping equipment increased by about 7 percent.  The growth in groundwater equipment sales was led by a 10 percent increase in residential systems.  Sales of groundwater pumping systems for agricultural applications grew by about 2 percent.  Sales of Pioneer branded mobile dewatering equipment declined by about 14 percent.  The decline in mobile dewatering equipment is primarily attributed to reduced demand in the oil and gas end markets.

[0000038725-16-000438:mdna:64]
Water Systems sales in Europe, Middle East and Africa were about 18 percent of consolidated sales and declined by about 6 percent compared to the first nine months of 2015.  Water Systems in Europe, the Middle East and Africa were reduced by $8.2 million or about 6 percent due to foreign currency translation.  Sales in the Europe, Middle East and Africa region were flat excluding the impact of foreign currency translation.  Within this region, our business unit in Turkey had increased sales which were offset by lower sales in other regional business units primarily due to the political and economic turmoil in certain parts of the region as well as the lower price of oil.

[0000038725-16-000438:mdna:65]
Water Systems sales in Latin America were about 13 percent of consolidated sales for the first nine months and declined by about 4 percent compared to the prior year's first nine months.  Sales revenue decreased by $10.1 million or about 10 percent in the first nine months of 2016 due to foreign currency translation.  The sales change in the first nine months of 2016, excluding foreign currency translation, was an increase of $6.1 million or about 6 percent.  The growth in sales was led by increased sales in Mexico and Brazil, in local currency.  This sales growth is a result of increasing demand for Franklin submersible pumps and motors, customer acceptance of the many product line upgrades that have been implemented over the past two years, and general market conditions.

[0000038725-16-000438:mdna:66]
Water Systems sales in the Asia Pacific region were 9 percent of consolidated sales and increased by about 15 percent compared to the first nine months of the prior year.  Sales revenue decreased by about 1 percent in the first nine months of 2016 due to foreign currency translation.  The sales change in the first nine months of 2016, excluding foreign currency translation, was an increase about 16 percent.  The Asia Pacific region experienced strong year over year growth in Southeast Asia and Australia.

[0000038725-16-000438:mdna:67]
[same as prior period, unchanged from 0000038725-16-000385:mdna:67]

[0000038725-16-000438:mdna:68]
Fueling Systems sales were $164.9 million or about 23 percent of consolidated sales in the first nine months of 2016 and increased $3.6 million or about 2 percent from the first nine months of 2015.  Foreign currency translation rate changes decreased sales $1.1 million or about 1 percent compared to sales in the first nine months of 2015.  The Fueling Systems sales change in the first nine months of 2016, excluding foreign currency translation, was an increase of $4.7 million or about 3 percent.

[0000038725-16-000438:mdna:69]
Fueling Systems sales in the U.S. and Canada grew by about 6 percent during the first nine months with sales growth coming from most product lines, especially in piping.  Outside the U.S. and Canada, Fueling Systems revenues were down overall with increased sales in India more than offset by a sales decline in Europe principally due to a reduction in the sale of storage tanks that support North Sea oil production.

[0000038725-16-000438:mdna:70]
[same as prior period, unchanged from 0000038725-16-000385:mdna:70]

[0000038725-16-000438:mdna:71]
Cost of sales as a percent of net sales for the first nine months of 2016 and 2015 was 64.7 percent and 67.6 percent, respectively.  Correspondingly, the gross profit margin was 35.3 percent and 32.4 percent for the first nine months of both years.  The Company's consolidated gross profit was $250.4 million for the first nine months of 2016, up $21.9 million from the gross profit of $228.5 million in the first nine months of 2015.  The gross profit margin increase was primarily due to favorable pricing, lower direct material costs and lower fixed costs.

[0000038725-16-000438:mdna:72]
[same as prior period, unchanged from 0000038725-16-000385:mdna:72]

[0000038725-16-000438:mdna:73]
Selling, general, and administrative expenses were $165.7 million in the first nine months of 2016 and increased by $6.5 million or 4 percent in the first nine months of 2016 compared to $159.2 million the first nine months of last year.  The Company’s SG&A expense increase in the first nine months of 2016 was primarily due to higher variable compensation expenses of about $6.5 million and RD&E spending of $1.2 million on new product development costs.  These increases were partially offset by lower fixed cost from the effect of foreign currency translation.

[0000038725-16-000438:mdna:74]
Restructuring (Income)/Expense

[0000038725-16-000438:mdna:75]
Restructuring income for the first nine months of 2016 was $0.9 million and improved diluted earnings per share by approximately $0.01.  Restructuring income for the first nine months of 2016 included a gain of $2.0 million from the sale of land and building in Brazil and $1.1 million in expenses related to severance, equipment transfers, freight and relocation cost related to the transfer of production activities and other restructuring costs from continued manufacturing realignments. Restructuring expenses for the first nine months of 2015 were $2.5 million and reduced diluted earnings per share by $0.03. Restructuring expenses were primarily related to the continuing European and Brazilian manufacturing realignments. Restructuring expenses were primarily severance expenses, equipment relocations and other miscellaneous manufacturing realignment activities.

[0000038725-16-000438:mdna:76]
[same as prior period, unchanged from 0000038725-16-000385:mdna:76]

[0000038725-16-000438:mdna:77]
Operating income was $85.6 million in the first nine months of 2016, up $18.8 million or about 28 percent from $66.8 million in the first nine months of 2015.

[0000038725-16-000438:mdna:78]
| (In millions) |  | YTDOctober 1, 2016 |  | YTDOctober 3, 2015 |  | 2016 v 2015 |
|  |  | Operating income (loss) |
| Water Systems |  | $ | 85.6 |  |  | $ | 66.8 |  |  | $ | 18.8 |  |
| Fueling Systems |  | 40.9 |  |  | 37.4 |  |  | 3.5 |  |
| Other |  | (40.9 | ) |  | (37.4 | ) |  | (3.5 | ) |
| Consolidated |  | $ | 85.6 |  |  | $ | 66.8 |  |  | $ | 18.8 |  |

[0000038725-16-000438:mdna:79]
There were specific items in the first nine months of 2016 and 2015 that impacted operating income that were not operational in nature.

[0000038725-16-000438:mdna:80]
In the first nine months of 2016 they were as follows:

[0000038725-16-000438:mdna:81]
| • | There was $0.9 million of restructuring income. Restructuring included a gain of $2.0 million from the sale of land and building in Brazil and restructuring expenses of $1.1 million in other miscellaneous manufacturing realignment activities, primarily related to the continued European and Brazilian realignment activities. |

[0000038725-16-000438:mdna:82]
| • | Executive transition costs were $0.9 million. |

[0000038725-16-000438:mdna:83]
In the first nine months of 2015 they were as follows:

[0000038725-16-000438:mdna:84]
| • | There were $2.5 million of restructuring charges. Restructuring expenses were severance expenses and other miscellaneous manufacturing realignment activities, primarily related to the continued European and Brazilian realignment activities. |

[0000038725-16-000438:mdna:85]
| • | Executive transition costs were $0.9 million. |

[0000038725-16-000438:mdna:86]
| • | Business realignment cost, primarily severance, in targeted fixed cost reduction actions of $0.5 million. |

[0000038725-16-000438:mdna:87]
| • | Other miscellaneous costs related to closed and pending acquisitions were $0.2 million. |

[0000038725-16-000438:mdna:88]
The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of operating income after non-GAAP adjustments and percent operating income to net sales after non-GAAP adjustments

[0000038725-16-000438:mdna:89]
(operating income margin after non-GAAP adjustments).  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-16-000438:mdna:90]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the First Nine Months of 2016 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income / (Loss) | $ | 85.6 |  | $ | 40.9 |  | $ | (40.9 | ) | $ | 85.6 |  |
| % Operating Income To Net Sales | 15.7 | % | 24.8 | % |  | 12.1 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | (1.4 | ) | $ | 0.5 |  | $ | — |  | $ | (0.9 | ) |
| Non-GAAP | $ | — |  | $ | — |  | $ | 0.9 |  | $ | 0.9 |  |
| Operating Income / (Loss) after Non-GAAP Adjustments | $ | 84.2 |  | $ | 41.4 |  | $ | (40.0 | ) | $ | 85.6 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 15.4 | % | 25.1 | % |  | 12.1 | % |
|  | For the First Nine Months of 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income / (Loss) | $ | 66.8 |  | $ | 37.4 |  | $ | (37.4 | ) | $ | 66.8 |  |
| % Operating Income To Net Sales | 12.3 | % | 23.2 | % |  | 9.5 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 2.2 |  | $ | 0.3 |  | $ | — |  | $ | 2.5 |  |
| Non-GAAP | $ | 0.6 |  | $ | 0.1 |  | $ | 0.9 |  | $ | 1.6 |  |
| Operating Income / (Loss) after Non-GAAP Adjustments | $ | 69.6 |  | $ | 37.8 |  | $ | (36.5 | ) | $ | 70.9 |  |
| % Operating Income to Net Sales after Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 12.8 | % | 23.4 | % |  | 10.0 | % |

[0000038725-16-000438:mdna:91]
[same as prior period, unchanged from 0000038725-16-000385:mdna:83]

[0000038725-16-000438:mdna:92]
Water Systems operating income was $85.6 million in the first none months of 2016, up $18.8 million or 28 percent versus the first nine months of 2015 as reported and up $14.6 million or 21 percent versus the first nine months of 2015 after non-GAAP adjustments.  The first nine months of 2016 as reported operating income margin was 15.7 percent, up 340 basis points from 12.3 percent in the first nine months of 2015.  The first nine months operating income margin after non-GAAP adjustments was 15.4 percent and increased by 260 basis points compared to the first nine months of 2015.  Operating income margin after non-GAAP adjustments increased in Water Systems primarily due to pricing, lower direct material costs and operating leverage.

[0000038725-16-000438:mdna:93]
[same as prior period, unchanged from 0000038725-16-000385:mdna:85]

[0000038725-16-000438:mdna:94]
Fueling Systems operating income was $40.9 million in the first nine months of 2016, up $3.5 million or about 9 percent compared to $37.4 million in the first nine months of 2015 as reported, and up $3.6 million or 10 percent compared to $37.8 million after non-GAAP adjustments in the first nine months of 2015.  The first nine months of 2016 as reported operating income margin was 24.8 percent, an increase of 160 basis points from the as reported 23.2 percent of net sales in the first nine months of 2015.  The first nine months operating income margin after non-GAAP adjustments was 25.1 percent up 170 basis points compared to the 23.4 percent of net sales in the first nine months of 2015.  Operating income margin after non-GAAP adjustments increased in Fueling Systems due to pricing, lower direct material costs and operating leverage.

[0000038725-16-000438:mdna:95]
[same as prior period, unchanged from 0000038725-16-000385:mdna:87]

[0000038725-16-000438:mdna:96]
Operating income-other is composed primarily of unallocated general and administrative expenses.  General and administrative expenses after non-GAAP adjustments were up about 10 percent compared to last year primarily due to higher incentive compensation.

[0000038725-16-000438:mdna:97]
[same as prior period, unchanged from 0000038725-16-000385:mdna:89]

[0000038725-16-000438:mdna:98]
Interest expense for the first nine months of 2016 and 2015 was $6.6 million and $7.7 million, respectively.

[0000038725-16-000438:mdna:99]
[same as prior period, unchanged from 0000038725-16-000385:mdna:91]

[0000038725-16-000438:mdna:100]
Other income or expense was a gain of $2.8 million in the first nine months of 2016.  Included in other income in the first nine months of 2016 was minority income $1.7 million and interest income of $0.8 million, primarily derived from the investment of cash balances in short-term securities.  The first nine months of 2015 was a gain of $6.0 million.  Included in other income in the first nine months of 2015 was minority income $2.7 million and interest income of $0.6 million, primarily derived from the investment of cash balances in short-term securities.  The Company also realized a gain on the redeemable non-controlling interest liability in the first nine months of 2015 of about $2.7 million.

[0000038725-16-000438:mdna:101]
[same as prior period, unchanged from 0000038725-16-000385:mdna:93]

[0000038725-16-000438:mdna:102]
Foreign currency-based transactions produced a gain for the first nine months of 2016 of $0.6 million.  Foreign currency-based transactions had no impact for the first nine months of 2015.

[0000038725-16-000438:mdna:103]
[same as prior period, unchanged from 0000038725-16-000385:mdna:95]

[0000038725-16-000438:mdna:104]
The provision for income taxes in the first nine months of 2016 and 2015 was $20.8 million and $7.6 million, respectively.  The effective tax rate for the first nine months of 2016 was about 25 percent and, before the impact of discrete events, was about 27 percent.  Discrete adjustments during the first nine months of 2016 were primarily due to the favorable impact from equity compensation share based payments.  The effective tax rate for the first nine months of 2015 was about 12 percent and, before the impact of discrete events, was about 27 percent.  Discrete adjustments during the first nine months of 2015 were the reversal of a deferred tax liability created in 2012 when the Company acquired the controlling interest in the Pioneer subsidiary and realized a gain on the then equity investment in Pioneer.  This first nine months tax benefit of about $4.8 million was treated as a non-GAAP adjustment.  Because in 2012, the gain was treated as a non-GAAP adjustment, the Company is now consistently treating the reversal of the tax liability related to that gain as a non-GAAP adjustment and reducing reported Earnings per Share in the first nine months of 2015 by $0.10 cents.  The Company also realized a gain on the redeemable non-controlling interest liability in the first nine months of 2015 of about $2.7 million which is included in ‘Other income’.  This purchase transaction also resulted in other tax benefits of about $2.5 million, which were expensed through the Company’s earnings in prior years as well as a 2015 benefit of about $1.0 million related to the 2015 gain.  The effective tax rate for the first nine months of 2016 and 2015 was about 27 percent before discrete adjustments.  The projected tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings and reduced taxes on foreign and repatriated earnings after the restructuring of certain foreign entities.  The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations, current cash on hand and available credit.

[0000038725-16-000438:mdna:105]
[same as prior period, unchanged from 0000038725-16-000385:mdna:97]

[0000038725-16-000438:mdna:106]
Net income for the first nine months of 2016 was $61.5 million compared to 2015 first nine months net income of $57.4 million.  Net income attributable to Franklin Electric Co., Inc. for the first nine months of 2016 was $61.1 million, or $1.28 per diluted share, compared to 2015 first nine months net income attributable to Franklin Electric Co., Inc. of $56.8 million or $1.17 per diluted share.  Earnings after non-GAAP adjustments for the first nine months of 2016 were $59.7 million, or $1.28 per diluted share, compared to the prior year first nine months earnings after non-GAAP adjustments of $53.6 million or $1.12 per diluted share.

[0000038725-16-000438:mdna:107]
There were specific items in the first nine months of 2016 and 2015 that impacted net income attributable to Franklin Electric Co., Inc. that were not operational in nature.  The Company refers to these items as “non-GAAP adjustments” for purposes of presenting the non-GAAP financial measures of earnings after non-GAAP adjustments and adjusted EPS.  The Company believes this information helps investors understand underlying trends in the Company's business more easily.  The differences between these non-GAAP financial measures and the most comparable GAAP measures are reconciled in the following tables:

[0000038725-16-000438:mdna:108]
| Earnings Before and After Non-GAAP Adjustments | For the First Nine Months |
| (in millions) | 2016 | 2015 | Change |
| Net Income attributable to Franklin Electric Co., Inc. Reported | $ | 61.1 |  | $ | 56.8 |  | 8 | % |
| Allocated Undistributed Earnings | $ | (1.4 | ) | $ | (0.9 | ) |  |
| Earnings for EPS Calculations | $ | 59.7 |  | $ | 55.9 |  | 7 | % |
| Non-GAAP adjustments (before tax): |  |  |  |
| Restructuring | $ | (0.9 | ) | $ | 2.5 |  |  |
| Non-GAAP items | $ | 0.9 |  | $ | 1.6 |  |  |
| Pioneer tax benefits on equity gain | $ | — |  | $ | (4.8 | ) |  |
| Non-GAAP adjustments, net of tax: |  |  |  |
| Restructuring | $ | (0.5 | ) | $ | 1.5 |  |  |
| Non-GAAP items | $ | 0.5 |  | $ | 1.0 |  |  |
| Pioneer tax benefits on equity gain | $ | — |  | $ | (4.8 | ) |  |
| Earnings after Non-GAAP Adjustments | $ | 59.7 |  | $ | 53.6 |  | 11 | % |

[0000038725-16-000438:mdna:109]
| Earnings Per Share Before and After Non-GAAP Adjustments | For the First Nine Months |
| (in millions except Earnings Per Share) | 2016 | 2015 | Change |
| Average Fully Diluted Shares Outstanding | 46.7 |  | 47.8 |  | (2 | )% |
| Fully Diluted Earnings Per Share ("EPS") Reported | $ | 1.28 |  | $ | 1.17 |  | 9 | % |
| Restructuring Per Share, net of tax | $ | (0.01 | ) | $ | 0.03 |  |  |
| Non-GAAP items, net of tax | $ | 0.01 |  | $ | 0.02 |  |  |
| Pioneer tax benefits on equity gain | $ | — |  | $ | (0.10 | ) |  |
| Fully Diluted EPS after Non-GAAP Adjustments (Adjusted EPS) | $ | 1.28 |  | $ | 1.12 |  | 14 | % |

[0000038725-16-000438:mdna:110]
[same as prior period, unchanged from 0000038725-16-000385:mdna:103]

[0000038725-16-000438:mdna:111]
[same as prior period, unchanged from 0000038725-16-000385:mdna:104]

[0000038725-16-000438:mdna:112]
[same as prior period, unchanged from 0000038725-16-000385:mdna:105]

[0000038725-16-000438:mdna:113]
On May 27, 2015, the Company entered into an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement") for $150.0 million maximum aggregate principal borrowing capacity and the Company authorized the issuance of $75.0 million of floating rate senior notes due May 27, 2025. These senior notes have a floating interest rate of one-month USD LIBOR plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  As of October 1, 2016, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-16-000438:mdna:114]
On December 31, 2012, the Company, Allen County, Indiana and certain institutional investors entered into a Bond Purchase and Loan Agreement.  Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)."  The aggregate principal amount of the Project Bonds that were issued and authenticated was limited to $25.0 million.  The Company then borrowed the proceeds under the Project

[0000038725-16-000438:mdna:115]
31

[0000038725-16-000438:mdna:116]
Bonds through the issuance of Project Notes to finance the cost of acquisition, construction, installation and equipping of the new Global Corporate Headquarters and Engineering Center. These Project Notes (tax increment financing debt) bear interest at 3.6 percent per annum.  Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.  On May 5, 2015, the Company entered into Amendment No. 1 to the Bond Purchase and Loan Agreement.  This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.

[0000038725-16-000438:mdna:117]
On April 9, 2007, the Company entered into the Amended and Restated Note Purchase and Private Shelf Agreement (as amended as described in this paragraph, the "Prudential Agreement") in the amount of $175.0 million.  Under the Prudential Agreement, the Company issued notes in an aggregate principal amount of $110.0 million on April 30, 2007 (the “B-1 Notes”) and $40.0 million on September 7, 2007 (the “B-2 Notes”).  The B-1 Notes and B-2 Notes bear a coupon of 5.79 percent and had at issuance an average life of 10 years with a final maturity in 2019.  On July 22, 2010, the Company entered into Amendment No. 3 to the Prudential Agreement to increase its borrowing capacity by $25.0 million.  On December 14, 2011, the Company entered into Amendment No. 4 to the Second Amended and Restated Note Purchase and Private Shelf Agreement to redefine the debt to EBITDA ratio covenant in order to be equivalent to that under the Credit Agreement.  On December 31, 2012, the Company and Prudential Insurance Company of America entered into an amendment to the Second Amended and Restated Note Purchase and Private Shelf Agreement to extend the effective date to December 31, 2015.  On May 5, 2015, the Company entered into Amendment No. 6 to the Second Amended and Restated Note Purchase and Private Shelf Agreement.   This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.  On May 28, 2015, the Company entered into a Third Amended and Restated Note Purchase and Private Shelf Agreement with Prudential to increase the total borrowing capacity from $200.0 million to $250.0 million.  As of October 1, 2016, the Company has $100.0 million borrowing capacity available under the Prudential Agreement.  Principal installments of $30.0 million are payable annually commencing on April 30, 2015 and continuing to and including April 30, 2019, with any unpaid balance due at maturity.

[0000038725-16-000438:mdna:118]
On December 14, 2006, the Company entered into an amended and restated unsecured, 60-month $120.0 million revolving credit agreement (as amended as described in this paragraph, the “Credit Agreement”).  The Credit Agreement provides for various borrowing rate options including interest rates based on the London Interbank Offered Rates (LIBOR) plus interest spreads keyed to the Company’s ratio of debt to earnings before interest, taxes, depreciation, and amortization (“EBITDA”).  On December 14, 2011, the Company executed the Second Amended and Restated Credit Agreement, which extended the maturity of the Credit Agreement to December 14, 2016, and increased the commitment amount to $150.0 million.  On May 5, 2015, the Company entered into Amendment No. 3 to the Credit Agreement.  This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.  As of October 1, 2016, the Company had $144.5 million borrowing capacity under the Credit Agreement as $5.5 million in letters of commercial and standby letters of credit were outstanding and undrawn and no revolver borrowing was drawn and outstanding as of the end of the quarter.

[0000038725-16-000438:mdna:119]
The New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement contain customary affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws, and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales, and transfers of assets. The covenants also include financial requirements, including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement, but only if the Company is defaulting on an obligation exceeding $10.0 million.  As of October 1, 2016, the Company was in compliance with all financial covenants.  The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-16-000438:mdna:120]
At October 1, 2016, the Company had $79.0 million of cash on hand at various locations worldwide.  Approximately 12 percent of the cash on hand was in the U.S. and readily accessible.  Approximately 59 percent was in Europe, and the remaining 29 percent was in Mexico, Asia Pacific, and other locations combined.  On a regular basis the Company reviews international cash balances and, if appropriate based on forecasted expenditures and considerations for the post-tax economic efficiency, will reposition cash among its global entities.  Global cash balances are invested according to a written policy, and are generally in bank demand accounts and bank time deposits with the preservation of principal as the highest priority.

[0000038725-16-000438:mdna:121]
On October 28, 2016, the Company entered into certain amendments to the Credit Agreement, New York Life Agreement and Prudential Agreement, as described in footnote 17 - Subsequent Event.

[0000038725-16-000438:mdna:122]
[same as prior period, unchanged from 0000038725-16-000385:mdna:113]

[0000038725-16-000438:mdna:123]
Net cash provided by operating activities was $70.9 million for the nine months ended October 1, 2016 compared to $60.3 million for the nine months ended October 3, 2015.  The increase in cash provided by operations in the first nine months of 2016 in comparison to the first nine months of 2015 was largely attributable to large cash outflows in the first half of 2015 related to restructuring costs previously accrued at year-end 2014.  In addition, during the first quarter of 2015, the mandatory share purchase liability of $22.9 million for Pioneer was settled, resulting in a non-cash gain and reversal of certain deferred tax liabilities, also non-cash, both of which were adjustments to net income.

[0000038725-16-000438:mdna:124]
[same as prior period, unchanged from 0000038725-16-000385:mdna:115]

[0000038725-16-000438:mdna:125]
Net cash used in investing activities was $25.1 million for the nine months ended October 1, 2016 compared to $18.4 million for the nine months ended October 3, 2015.  The increase was primarily attributable to an increase in capital expenditures during the current period including the purchase of a building during the first quarter of 2016.

[0000038725-16-000438:mdna:126]
[same as prior period, unchanged from 0000038725-16-000385:mdna:117]

[0000038725-16-000438:mdna:127]
Net cash used in financing activities was $48.1 million for the nine months ended October 1, 2016 compared to cash used of $10.1 million for the nine months ended October 3, 2015.  During the nine months ended October 3, 2015, the Company incurred higher borrowings to fund operating requirements and for the Pioneer mandatory share purchase liability and common stock repurchases.

[0000038725-16-000438:mdna:128]
[same as prior period, unchanged from 0000038725-16-000385:mdna:119]
