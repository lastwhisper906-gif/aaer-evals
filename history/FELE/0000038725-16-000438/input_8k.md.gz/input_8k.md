# FELE 8-K — 0000038725-16-000429 filed 2016-10-25

## item codes, every 8-K on or before 2016-11-01

- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2016-11-01

- none on or before 2016-11-01

## item 2.02 — earnings release, exhibit 99.1

[0000038725-16-000429:8k_2_02:1]
EX-99.1
2
a201610258-kexhibit991.htm
EXHIBIT 99.1

[0000038725-16-000429:8k_2_02:2]
Exhibit

[0000038725-16-000429:8k_2_02:3]
Exhibit 99.1

[0000038725-16-000429:8k_2_02:4]
For Immediate Release

[0000038725-16-000429:8k_2_02:5]
For Further Information

[0000038725-16-000429:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-16-000429:8k_2_02:7]
260-824-2900

[0000038725-16-000429:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS THIRD QUARTER

[0000038725-16-000429:8k_2_02:9]
2016 SALES AND EARNINGS

[0000038725-16-000429:8k_2_02:10]
Fort Wayne, Indiana - October 25, 2016 - Franklin Electric Co., Inc. (NASDAQ: FELE) reported third quarter 2016 GAAP fully diluted earnings per share (EPS) of $0.50, versus a GAAP fully diluted EPS in the third quarter 2015 of $0.43, a an increase of 16 percent.  In the third quarter of 2016, the Company’s adjusted EPS was $0.48 compared to 2015 third quarter adjusted EPS of $0.45, a 7 percent increase (see table below for a reconciliation of GAAP EPS to the adjusted EPS).

[0000038725-16-000429:8k_2_02:11]
Third quarter 2016 sales were $239.8 million, an increase of 3 percent compared to 2015 third quarter sales of $232.5 million.  The Company’s organic sales growth was also 3 percent. The impact of foreign currency translation was not significant.

[0000038725-16-000429:8k_2_02:12]
Gregg Sengstack, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-16-000429:8k_2_02:13]
“Overall, we’re pleased with the Company’s results in the third quarter, particularly the performance of our Water Systems segment where strong sales performance in Asia Pacific, Latin America and North America drove organic sales growth of 5 percent.  Our Water Systems adjusted operating income margin was 140 basis points higher in the third quarter than the same quarter of 2015.  Our Fueling Systems segment slowed in the third quarter to an organic sales decline of about 1 percent after excluding the impact of foreign currency translation.  The Fueling Systems revenue decline can be attributed to weaker international markets as revenues in the U.S. and Canada increased by 5 percent in the third quarter.”

[0000038725-16-000429:8k_2_02:14]
Key Performance Indicators:

[0000038725-16-000429:8k_2_02:15]
| Earnings Before and After Non-GAAP Adjustments |  | For the Third Quarter |
| (in millions) |  | 2016 | 2015 | Change |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 23.7 |  | $ | 20.8 |  | 14 | % |
| Allocated Undistributed Earnings |  | $ | (0.3 | ) | $ | (0.4 | ) |  |
| Earnings for EPS Calculations |  | $ | 23.4 |  | $ | 20.4 |  | 15 | % |
| Non-GAAP adjustments (before tax): |  |  |  |  |
| Restructuring |  | $ | (1.7 | ) | $ | 1.3 |  |  |
| Non-GAAP items |  | $ | 0.3 |  | $ | 0.4 |  |  |
| Non-GAAP adjustments, net of tax: |  |  |  |  |
| Restructuring |  | $ | (1.0 | ) | $ | 0.8 |  |  |
| Non-GAAP items |  | $ | 0.2 |  | $ | 0.2 |  |  |
| Earnings after Non-GAAP Adjustments |  | $ | 22.6 |  | $ | 21.4 |  | 6 | % |
| Earnings Per Share |  | For the Third Quarter |
| Before and After Non-GAAP Adjustments |  | 2016 | 2015 | Change |
| (in millions except Earnings Per Share) |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 46.9 |  | 47.3 |  | (1 | )% |
| Fully Diluted Earnings Per Share ("EPS") Reported |  | $ | 0.50 |  | $ | 0.43 |  | 16 | % |
| Restructuring Per Share, net of tax |  | $ | (0.02 | ) | $ | 0.02 |  |  |
| Non-GAAP items, net of tax |  | $ | — |  | $ | — |  |  |
| Fully Diluted EPS after Non-GAAP Adjustments(Adjusted EPS) |  | $ | 0.48 |  | $ | 0.45 |  | 7 | % |

[0000038725-16-000429:8k_2_02:16]
|  | Net Sales |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Consolidated |
| Q3 2015 | $ | 85.6 |  | $ | 30.9 |  | $ | 40.0 |  | $ | 17.0 |  | $ | 173.5 |  | $ | 59.0 |  | $ | 232.5 |  |
| Q3 2016 | $ | 87.4 |  | $ | 35.5 |  | $ | 38.9 |  | $ | 20.2 |  | $ | 182.0 |  | $ | 57.8 |  | $ | 239.8 |  |
| Change | $ | 1.8 |  | $ | 4.6 |  | $ | (1.1 | ) | $ | 3.2 |  | $ | 8.5 |  | $ | (1.2 | ) | $ | 7.3 |  |
| % Change | 2 | % | 15 | % | (3 | )% | 19 | % | 5 | % | (2 | )% | 3 | % |
| Foreign currency translation | $ | (0.1 | ) | $ | 0.9 |  | $ | (1.2 | ) | $ | 0.2 |  | $ | (0.2 | ) | $ | (0.3 | ) | $ | (0.5 | ) |
| % Change | — | % | 3 | % | (3 | )% | 1 | % | — | % | (1 | )% | — | % |
| Volume/Price | $ | 1.9 |  | $ | 3.7 |  | $ | 0.1 |  | $ | 3.0 |  | $ | 8.7 |  | $ | (0.9 | ) | $ | 7.8 |  |
| % Change | 2 | % | 12 | % | — | % | 18 | % | 5 | % | (1 | )% | 3 | % |

[0000038725-16-000429:8k_2_02:17]
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the Third Quarter 2016 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income/(Loss) | $ | 30.0 |  | $ | 15.2 |  | $ | (13.4 | ) | $ | 31.8 |  |
| % Operating Income To Net Sales | 16.5 | % | 26.3 | % |  | 13.3 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | (1.8 | ) | $ | 0.1 |  | $ | — |  | $ | (1.7 | ) |
| Non-GAAP | $ | — |  | $ | — |  | $ | 0.3 |  | $ | 0.3 |  |
| Operating Income/(Loss) after Non-GAAP Adjustments | $ | 28.2 |  | $ | 15.3 |  | $ | (13.1 | ) | $ | 30.4 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 15.5 | % | 26.5 | % |  | 12.7 | % |
| Operating Income and Margins |  |  |  |  |
| Before and After Non-GAAP Adjustments |  |  |  |  |
| (in millions) | For the Third Quarter 2015 |
|  | Water | Fueling | Other | Consolidated |
| Reported Operating Income/(Loss) | $ | 23.1 |  | $ | 15.4 |  | $ | (10.7 | ) | $ | 27.8 |  |
| % Operating Income To Net Sales | 13.3 | % | 26.1 | % |  | 12.0 | % |
| Non-GAAP Adjustments: |  |  |  |  |
| Restructuring | $ | 1.3 |  | $ | — |  | $ | — |  | $ | 1.3 |  |
| Non-GAAP | $ | 0.1 |  | $ | — |  | $ | 0.3 |  | $ | 0.4 |  |
| Operating Income/(Loss) after Non-GAAP Adjustments | $ | 24.5 |  | $ | 15.4 |  | $ | (10.4 | ) | $ | 29.5 |  |
| % Operating Income to Net Sales After Non-GAAP Adjustments (Operating Income Margin after Non-GAAP Adjustments) | 14.1 | % | 26.1 | % |  | 12.7 | % |

[0000038725-16-000429:8k_2_02:18]
Water Systems

[0000038725-16-000429:8k_2_02:19]
Water Systems sales were $182.0 million in the third quarter 2016, an increase of $8.5 million or about 5 percent versus the third quarter 2015 sales of $173.5 million.  Water Systems organic sales growth was also about 5 percent compared to the third quarter 2015. The impact of foreign currency translation was not significant.

[0000038725-16-000429:8k_2_02:20]
Water Systems sales in the U.S. and Canada were up about 2 percent compared to the prior year third quarter. In the third quarter 2016, sales of groundwater pumping equipment grew by about 13 percent.  The growth in groundwater equipment sales was led by a 17 percent increase in residential systems.  Sales of ground water pumping systems for agricultural applications grew by about 2 percent.  Water Systems sales in markets outside the U.S. and Canada experienced overall growth of about 8 percent, after excluding the impact of foreign currency translation.  International Water Systems sales growth was led by improved groundwater product sales in the Asia Pacific and Latin America markets.  Sales in Europe, the Middle East and Africa were flat in the quarter compared to last year, after excluding the impact of foreign currency translation.

[0000038725-16-000429:8k_2_02:21]
Water Systems operating income was $30.0 million in the third quarter 2016, up $6.9 million or 30 percent versus the third quarter 2015 as reported and up $3.7 million or 15 percent versus the third quarter 2015 after non-GAAP adjustments. The third quarter operating income margin was 16.5 percent, up 320 basis points from 13.3 percent in the third quarter of 2015. The third quarter operating income margin after non-GAAP adjustments was 15.5 percent, an increase of 140 basis points from the 14.1 percent of net sales in the third quarter of 2015 after non-GAAP adjustments.

[0000038725-16-000429:8k_2_02:22]
Reported operating income of $30.0 million in the third quarter was positively impacted by the gain of about $2.0 million on the sale of a facility in Brazil that was completed in the quarter.

[0000038725-16-000429:8k_2_02:23]
Fueling Systems

[0000038725-16-000429:8k_2_02:24]
Fueling Systems sales were $57.8 million in the third quarter 2016, a decrease of $1.2 million or about 2 percent versus the third quarter 2015 sales of $59.0 million.  Fueling Systems sales decreased by $0.3 million or about 1 percent in the quarter due to foreign currency translation. Fueling Systems sales declined about 1 percent, after excluding foreign currency translation.

[0000038725-16-000429:8k_2_02:25]
Fueling Systems sales in the U.S. and Canada grew by about 5 percent during the quarter.  The increase was broad based and included pumping, pipe and containment systems.  Internationally, Fueling Systems revenues were down in Europe and Asia Pacific.  Management believes this was in part due to lower capital spending on new filling station development by major oil companies and due to the timing of customer shipments.

[0000038725-16-000429:8k_2_02:26]
Fueling Systems operating income was $15.2 million in the third quarter of 2016, down $0.2 million or about 1 percent compared to $15.4 million in the third quarter of 2015 as reported, and down $0.1 million or 1 percent compared to $15.4 million after non-GAAP adjustments in the third quarter of 2015. The third quarter operating income margin was 26.3 percent, an increase of 20 basis points from the as reported 26.1 percent of net sales in the third quarter of 2015. The third quarter operating income margin after non-GAAP adjustments was 26.5 percent, an increase of 40 basis points from the 26.1 percent of net sales in the third quarter of 2015 after non-GAAP adjustments.

[0000038725-16-000429:8k_2_02:27]
Overall

[0000038725-16-000429:8k_2_02:28]
The Company’s consolidated gross profit was $85.5 million for the third quarter of 2016, an increase of $8.7 million, or about 11 percent, from the third quarter of 2015 gross profit of $76.8 million. The gross profit as a percent of net sales was 35.6 percent in the third quarter of 2016 and increased about 260 basis points versus 33.0 percent during the third quarter 2015.  The gross profit margin increase was primarily due to favorable pricing, lower direct material costs and sales mix.

[0000038725-16-000429:8k_2_02:29]
Selling, general, and administrative (SG&A) expenses were $55.4 million in the third quarter of 2016 compared to $47.7 million in the third quarter of the prior year, an increase of $7.7 million or about 16 percent.  Roughly half of the Company’s SG&A expense increase in the quarter, or about $4.0 million, was due to higher variable compensation expenses. Marketing and Selling related expenses increased about $1.0 million to support sales growth and Research Development & Engineering expense increased by $0.8 million in the quarter.

[0000038725-16-000429:8k_2_02:30]
The Company ended the third quarter of 2016 with a cash balance of about $79 million, which was about 3 percent lower than at the end of 2015.  The cash balance decreased primarily due to higher capital expenditures and seasonal working capital requirements in the Northern hemisphere.

[0000038725-16-000429:8k_2_02:31]
Commenting on the outlook, Mr. Sengstack said:

[0000038725-16-000429:8k_2_02:32]
“As we look forward to the fourth quarter, we expect continued strength in the North American end markets, but are cautious about certain international end markets in both our Water and Fueling segments.  Customer demand is uneven and economic and political uncertainty continues to negatively impact important markets for us around the world. Considering these factors, we are narrowing our full year 2016 adjusted earnings per share guidance to $1.62 to $1.67.”

[0000038725-16-000429:8k_2_02:33]
A conference call to review earnings and other developments in the business will commence at 9:00 am EDT.  The third quarter 2016 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-16-000429:8k_2_02:34]
http://edge.media-server.com/m/p/3qyhxcic

[0000038725-16-000429:8k_2_02:35]
If you intend to ask questions during the call, please dial in using (877) 643-7158 for domestic calls and (914) 495-8565 for international calls.  The conference ID is: 95793831.

[0000038725-16-000429:8k_2_02:36]
A replay of the conference call will be available Tuesday, October 25, 2016 at 12:00 noon EDT through midnight EDT on Tuesday, November 1, 2016, by dialing (855) 859-2056 for domestic calls and (404) 537-3406 for international calls. The replay passcode is: 95793831.

[0000038725-16-000429:8k_2_02:37]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-16-000429:8k_2_02:38]
The Company presents the non-GAAP financial measures of earnings after non-GAAP adjustments, fully diluted earnings per share after non-GAAP adjustments (or adjusted EPS), operating income after non-GAAP adjustments and percent operating income to net sales after non-GAAP adjustments (or operating income margin after non-GAAP adjustments) because the Company believes the information helps investors understand underlying trends in the Company's business more easily. The differences between these measures and the most comparable GAAP measures are reconciled in the tables above.

[0000038725-16-000429:8k_2_02:39]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Third Quarter Ended |  | Nine Months Ended |
|  | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |
| Net sales | $ | 239,755 |  |  | $ | 232,485 |  |  | $ | 710,266 |  |  | $ | 705,640 |  |
| Cost of sales | 154,286 |  |  | 155,693 |  |  | 459,883 |  |  | 477,150 |  |
| Gross profit | 85,469 |  |  | 76,792 |  |  | 250,383 |  |  | 228,490 |  |
| Selling, general, and administrative expenses | 55,373 |  |  | 47,722 |  |  | 165,672 |  |  | 159,160 |  |
| Restructuring (income)/expense | (1,715 | ) |  | 1,304 |  |  | (850 | ) |  | 2,525 |  |
| Operating income | 31,811 |  |  | 27,766 |  |  | 85,561 |  |  | 66,805 |  |
| Interest expense | (1,983 | ) |  | (2,604 | ) |  | (6,631 | ) |  | (7,717 | ) |
| Other income, net | 1,446 |  |  | 1,616 |  |  | 2,787 |  |  | 6,025 |  |
| Foreign exchange income/(expense) | 399 |  |  | (96 | ) |  | 637 |  |  | (39 | ) |
| Income before income taxes | 31,673 |  |  | 26,682 |  |  | 82,354 |  |  | 65,074 |  |
| Income tax expense | 7,926 |  |  | 5,656 |  |  | 20,840 |  |  | 7,634 |  |
| Net income | $ | 23,747 |  |  | $ | 21,026 |  |  | $ | 61,514 |  |  | $ | 57,440 |  |
| Less: Net income attributable to noncontrolling interests | (83 | ) |  | (201 | ) |  | (411 | ) |  | (656 | ) |
| Net income attributable to Franklin Electric Co., Inc. | $ | 23,664 |  |  | $ | 20,825 |  |  | $ | 61,103 |  |  | $ | 56,784 |  |
| Income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.51 |  |  | $ | 0.44 |  |  | $ | 1.29 |  |  | $ | 1.18 |  |
| Diluted | $ | 0.50 |  |  | $ | 0.43 |  |  | $ | 1.28 |  |  | $ | 1.17 |  |

[0000038725-16-000429:8k_2_02:40]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | October 1, 2016 |  | January 2, 2016 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 78,981 |  |  | $ | 81,561 |  |
| Receivables | 152,093 |  |  | 127,251 |  |
| Inventories | 215,067 |  |  | 194,594 |  |
| Other current assets | 31,289 |  |  | 34,715 |  |
| Total current assets | 477,430 |  |  | 438,121 |  |
| Property, plant, and equipment, net | 198,675 |  |  | 190,039 |  |
| Goodwill and other assets | 368,512 |  |  | 367,951 |  |
| Total assets | $ | 1,044,617 |  |  | $ | 996,111 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 60,695 |  |  | $ | 57,822 |  |
| Accrued expenses and other current liabilities | 64,356 |  |  | 53,903 |  |
| Current maturities of long-term debt and short-term borrowings | 33,418 |  |  | 32,946 |  |
| Total current liabilities | 158,469 |  |  | 144,671 |  |
| Long-term debt | 156,712 |  |  | 187,806 |  |
| Deferred income taxes | 38,950 |  |  | 33,404 |  |
| Employee benefit plans | 40,799 |  |  | 47,398 |  |
| Other long-term liabilities | 19,899 |  |  | 16,511 |  |
| Redeemable noncontrolling interest | 7,597 |  |  | 6,856 |  |
| Total equity | 622,191 |  |  | 559,465 |  |
| Total liabilities and equity | $ | 1,044,617 |  |  | $ | 996,111 |  |

[0000038725-16-000429:8k_2_02:41]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Nine Months Ended |
| (In thousands) | October 1, 2016 |  | October 3, 2015 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 61,514 |  |  | $ | 57,440 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 26,752 |  |  | 26,804 |  |
| Share-based compensation | 5,912 |  |  | 4,579 |  |
| Realized gain on share purchase liability | — |  |  | (2,723 | ) |
| Other | 2,148 |  |  | (6,147 | ) |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (22,088 | ) |  | (527 | ) |
| Inventory | (14,910 | ) |  | (3,366 | ) |
| Accounts payable and accrued expenses | 9,333 |  |  | (10,345 | ) |
| Other | 2,204 |  |  | (5,374 | ) |
| Net cash flows from operating activities | 70,865 |  |  | 60,341 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (30,109 | ) |  | (15,528 | ) |
| Proceeds from sale of property, plant, and equipment | 5,839 |  |  | 959 |  |
| Acquisitions and investments | (1,007 | ) |  | (3,888 | ) |
| Other investing activities | 174 |  |  | 99 |  |
| Net cash flows from investing activities | (25,103 | ) |  | (18,358 | ) |
| Cash flows from financing activities: |  |  |  |
| Change in debt | (30,626 | ) |  | 65,787 |  |
| Proceeds from issuance of common stock | 3,192 |  |  | 1,240 |  |
| Excess tax from share-based payment arrangements | — |  |  | 819 |  |
| Purchases of common stock | (6,193 | ) |  | (43,330 | ) |
| Dividends paid | (14,483 | ) |  | (14,393 | ) |
| Share purchase liability payment | — |  |  | (20,200 | ) |
| Net cash flows from financing activities | (48,110 | ) |  | (10,077 | ) |
| Effect of exchange rate changes on cash | (232 | ) |  | (6,149 | ) |
| Net change in cash and equivalents | (2,580 | ) |  | 25,757 |  |
| Cash and equivalents at beginning of period | 81,561 |  |  | 59,141 |  |
| Cash and equivalents at end of period | $ | 78,981 |  |  | $ | 84,898 |  |
