# FELE MD&A — 0000038725-17-000145


## mdna

[0000038725-17-000145:mdna:1]
[same as prior period, unchanged from 0000038725-17-000089:mdna:1]

[0000038725-17-000145:mdna:2]
Second Quarter 2017 vs. Second Quarter 2016

[0000038725-17-000145:mdna:3]
[same as prior period, unchanged from 0000038725-17-000089:mdna:3]

[0000038725-17-000145:mdna:4]
Sales and earnings in the second quarter of 2017 increased from the second quarter last year.  The sales increase was primarily due to distribution companies acquired in the quarter, reported in a new segment.  The Water and Fueling Systems segments both experienced sales increases from price and volume partially offset by the negative impact of foreign currency translation. The Company's consolidated gross profit was $102.8 million for the second quarter of 2017, an increase of $12.1 million or about 13 percent from the prior year’s second quarter.

[0000038725-17-000145:mdna:5]
[same as prior period, unchanged from 0000038725-17-000089:mdna:5]

[0000038725-17-000145:mdna:6]
[same as prior period, unchanged from 0000038725-17-000089:mdna:6]

[0000038725-17-000145:mdna:7]
Net sales in the second quarter of 2017 were $305.3 million, an increase of $53.2 million or about 21 percent compared to 2016 second quarter sales of $252.1 million.  Acquisition related sales, from the new distribution segment, were $59.1 million.  Sales revenue decreased by $2.5 million or about 1 percent in the second quarter of 2017 due to foreign currency translation.

[0000038725-17-000145:mdna:8]
|  | Net Sales |
| (In millions) | Q2 2017 |  | Q2 2016 |  | 2017 v 2016 |
| Water Systems | $ | 203.4 |  |  | $ | 194.6 |  |  | $ | 8.8 |  |
| Fueling Systems | 61.4 |  |  | 57.5 |  |  | 3.9 |  |
| Distribution | 59.1 |  |  | — |  |  | 59.1 |  |
| Eliminations/Other | (18.6 | ) |  | — |  |  | (18.6 | ) |
| Consolidated | $ | 305.3 |  |  | $ | 252.1 |  |  | $ | 53.2 |  |

[0000038725-17-000145:mdna:9]
[same as prior period, unchanged from 0000038725-17-000089:mdna:9]

[0000038725-17-000145:mdna:10]
Water Systems sales were $203.4 million in the second quarter 2017, an increase of $8.8 million or about 5 percent versus the second quarter 2016 sales of $194.6 million. Water Systems sales were reduced by $1.8 million or about 1 percent in the quarter due to foreign currency translation. Excluding foreign currency translation, Water Systems sales were up about 6 percent compared to the second quarter 2016.

[0000038725-17-000145:mdna:11]
Water Systems sales in the U.S. and Canada were up about 10 percent compared to the prior year second quarter.   Sales of dewatering equipment increased by 25 percent in the second quarter when compared to the prior year resulting from the continued diversification of customers and new channel development for Pioneer branded equipment.  Sales of other surface pumping equipment increased by 8 percent in part due to wet weather conditions in the upper Midwest and Canada.  Sales of groundwater pumping equipment increased about 5 percent.

[0000038725-17-000145:mdna:12]
Water Systems sales in markets outside the U.S. and Canada overall declined by about 1 percent, due primarily to the impact of foreign currency translation.  International Water Systems sales were led by improved sales in Europe, the Middle East and Africa, but were offset by lower sales volumes in the Latin American and Asia Pacific markets in the quarter compared to last year.

[0000038725-17-000145:mdna:13]
[same as prior period, unchanged from 0000038725-17-000089:mdna:16]

[0000038725-17-000145:mdna:14]
Fueling Systems sales were $61.4 million in the second quarter 2017, an increase of $3.9 million or about 7 percent versus the second quarter 2016 sales of $57.5 million.  Fueling Systems sales decreased by $0.7 million or about 1 percent in the quarter due to foreign currency translation. Fueling Systems organic sales increased about 8 percent compared to the second quarter of 2016.

[0000038725-17-000145:mdna:15]
Fueling Systems sales in the U.S. and Canada grew by about 4 percent during the quarter.  The increase was primarily in pumping systems.  Outside of the U.S. and Canada, Fueling Systems revenues grew by about 18 percent, led by stronger sales in Europe, Africa and Asia.

[0000038725-17-000145:mdna:16]
Net Sales-Distribution

[0000038725-17-000145:mdna:17]
Distribution sales were $59.1 million in the second quarter 2017.  Based on the information provided for second quarter 2016 sales, management estimates second quarter Distribution sales declined by about 2 percent from the second quarter of 2016 primarily driven by adverse weather conditions in the Western portion of the United States.

[0000038725-17-000145:mdna:18]
[same as prior period, unchanged from 0000038725-17-000089:mdna:18]

[0000038725-17-000145:mdna:19]
Cost of sales as a percent of net sales for the second quarter of 2017 and 2016 was 66.3 percent and 64.0 percent, respectively. Correspondingly, the gross profit margin decreased to 33.7 percent from 36.0 percent, a 230 basis point decline. The decline in gross profit margin percentage is due to the lower gross profit margin of the Distribution segment.  The second quarter 2017 gross profit margin percent declined as well due to higher direct material costs. The Company’s consolidated gross profit was $102.8 million for the second quarter of 2017, an increase of $12.1 million, or about 13 percent, from the second quarter of 2016 gross profit of $90.7. The gross profit increase was primarily due to higher sales.

[0000038725-17-000145:mdna:20]
[same as prior period, unchanged from 0000038725-17-000089:mdna:20]

[0000038725-17-000145:mdna:21]
Selling, general, and administrative (SG&A) expenses were $68.3 million in the second quarter of 2017 compared to $58.0 million in the second quarter of the prior year, an increase of $10.3 million or about 18 percent.  The increase in SG&A expenses from acquired businesses were $13.0 million.  Excluding the acquired entities, the Company’s SG&A expenses in the second quarter of 2017 decreased by $2.7 million or about 5 percent. Overall, the lower SG&A spending outside the acquired entities is due to lower advertising and promotion, engineering and engineering related project costs, and certain variable employee benefit costs.

[0000038725-17-000145:mdna:22]
[same as prior period, unchanged from 0000038725-17-000089:mdna:22]

[0000038725-17-000145:mdna:23]
Restructuring expenses for the second quarter of 2017 were $0.3 million, primarily from continued Brazilian miscellaneous manufacturing realignment activities. Restructuring expenses for the second quarter of 2016 were not significant.

[0000038725-17-000145:mdna:24]
[same as prior period, unchanged from 0000038725-17-000089:mdna:25]

[0000038725-17-000145:mdna:25]
Operating income was $34.2 million in the second quarter of 2017, up $1.5 million or about 5 percent from $32.7 million in the second quarter of 2016.

[0000038725-17-000145:mdna:26]
|  |  | Operating income (loss) |
| (In millions) |  | Q2 2017 |  | Q2 2016 |  | 2017 v 2016 |
| Water Systems |  | $ | 32.8 |  |  | $ | 31.5 |  |  | $ | 1.3 |  |
| Fueling Systems |  | 14.9 |  |  | 15.5 |  |  | (0.6 | ) |
| Distribution |  | 3.7 |  |  | — |  |  | 3.7 |  |
| Eliminations/Other |  | (17.2 | ) |  | (14.3 | ) |  | (2.9 | ) |
| Consolidated |  | $ | 34.2 |  |  | $ | 32.7 |  |  | $ | 1.5 |  |

[0000038725-17-000145:mdna:27]
[same as prior period, unchanged from 0000038725-17-000089:mdna:28]

[0000038725-17-000145:mdna:28]
Water Systems operating income was $32.8 million in the second quarter 2017, up $1.3 million or 4 percent versus the second quarter 2016 and operating income margin was 16.1 percent compared to the 16.2 percent in the second quarter 2016.

[0000038725-17-000145:mdna:29]
[same as prior period, unchanged from 0000038725-17-000089:mdna:30]

[0000038725-17-000145:mdna:30]
Fueling Systems operating income was $14.9 million in the second quarter of 2017, down $0.6 million or about 4 percent compared to $15.5 million in the second quarter of 2016 and the second quarter operating income margin was 24.3 percent, a decrease of 270 basis points from the 27.0 percent of net sales in the second quarter of 2016.  The decline in operating income was primarily due to adverse product and geography sales mix shifts.

[0000038725-17-000145:mdna:31]
Operating Income-Distribution

[0000038725-17-000145:mdna:32]
Distribution operating income was $3.7 million in the second quarter of 2017 and the second quarter operating income margin was 6.3 percent.

[0000038725-17-000145:mdna:33]
Operating Income-Eliminations/Other

[0000038725-17-000145:mdna:34]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses.  The inter-segment profit elimination impact in the second quarter of 2017 was $3.3 million. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems

[0000038725-17-000145:mdna:35]
to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its customer.  General and administrative expenses were lower by $0.4 million or about 3 percent due to decreases in Finance expenses, primarily lower banking expenses.

[0000038725-17-000145:mdna:36]
[same as prior period, unchanged from 0000038725-17-000089:mdna:35]

[0000038725-17-000145:mdna:37]
Interest expense for both the second quarter of 2017 and 2016 was $2.2 million.

[0000038725-17-000145:mdna:38]
[same as prior period, unchanged from 0000038725-17-000089:mdna:37]

[0000038725-17-000145:mdna:39]
Other income or expense was income of $5.6 million and $1.4 million in the second quarter of 2017 and 2016, respectively.  Included in other income in the second quarter of 2017 was a gain of $4.8 million on the previously held equity investments in three Distribution entities as indicated in the announcement made on April 10, 2017 regarding the acquisition of the controlling interests of these entities. Also, included in other income in the second quarter of 2017 was minority income of $0.1 million and interest income of $0.3 million, primarily derived from the investment of cash balances in short-term securities. Included in other income in the second quarter of 2016 was minority income of $0.7 million and interest income of $0.3 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-17-000145:mdna:40]
[same as prior period, unchanged from 0000038725-17-000089:mdna:39]

[0000038725-17-000145:mdna:41]
Foreign currency-based transactions produced a loss for the second quarter of 2017 of $0.3 million, due to movements in several currencies relative to the U.S. dollar, none of which individually were significant.   Foreign currency-based transactions produced a gain for the second quarter of 2016 of $0.3 million, due to movements in several currencies relative to the U.S. dollar, none of which individually were significant.

[0000038725-17-000145:mdna:42]
[same as prior period, unchanged from 0000038725-17-000089:mdna:41]

[0000038725-17-000145:mdna:43]
The provision for income taxes in the second quarter of 2017 and 2016 was $6.9 million and $8.0 million, respectively. The effective tax rate for the second quarter of 2017 was about 19 percent and, before the impact of discrete events, was about 27 percent.  Discrete events in the second quarter included the tax benefit on the non-taxable gain recorded on the previously held equity investments and the statute expiration on foreign uncertain tax positions.  The effective tax rate for the second quarter of 2016 was about 25 percent and, before the impact of discrete events, was about 26 percent. The tax rate as a percentage of pre-tax earnings for the full year of 2017 is projected to be 25 percent to 28 percent, compared to the full year 2016 tax rate of about 26 percent, before discrete adjustments. The projected tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings and reduced taxes on foreign and repatriated earnings. The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations, current cash on hand and available credit.

[0000038725-17-000145:mdna:44]
[same as prior period, unchanged from 0000038725-17-000089:mdna:43]

[0000038725-17-000145:mdna:45]
Net income for the second quarter of 2017 was $30.2 million compared to the prior year second quarter net income of $24.2 million.  Net income attributable to Franklin Electric Co., Inc. for the second quarter of 2017 was $29.9 million, or $0.64 per diluted share, compared to the prior year second quarter net income attributable to Franklin Electric Co., Inc. of $24.0 million or $0.50 per diluted share.

[0000038725-17-000145:mdna:46]
First Half of 2017 vs. First Half of 2016

[0000038725-17-000145:mdna:47]
OVERVIEW

[0000038725-17-000145:mdna:48]
Sales in the first half of 2017 were up from the same period last year.  The sales increase was primarily due to distribution companies acquired in the second quarter, reported in a new segment.  The Water and Fueling Systems segments both experienced sales increases from price and volume partially offset by the negative impact of foreign currency translation. The Company's consolidated gross profit was $178.6 million for the first half of 2017, an increase of $13.7 million or about 8 percent from the first half of 2016. Earnings in the first half of 2017 were up from the same period last year.

[0000038725-17-000145:mdna:49]
RESULTS OF OPERATIONS

[0000038725-17-000145:mdna:50]
Net Sales

[0000038725-17-000145:mdna:51]
Net sales in the first half of 2017 were $525.6 million, an increase of $55.1 million or about 12 percent compared to 2016 first half sales of $470.5 million.  The incremental impact of sales from acquired businesses was $59.1 million or 13 percent.  Sales revenue decreased by $2.5 million or less than 1 percent in the first half of 2017 due to foreign currency translation.

[0000038725-17-000145:mdna:52]
|  | Net Sales |
| (In millions) | YTD June 30, 2017 |  | YTD July 2, 2016 |  | 2017 v 2016 |
| Water Systems | $ | 370.6 |  |  | $ | 363.4 |  |  | $ | 7.2 |  |
| Fueling Systems | 114.5 |  |  | 107.1 |  |  | 7.4 |  |
| Distribution | 59.1 |  |  | — |  |  | 59.1 |  |
| Eliminations/Other | (18.6 | ) |  | — |  |  | (18.6 | ) |
| Consolidated | $ | 525.6 |  |  | $ | 470.5 |  |  | $ | 55.1 |  |

[0000038725-17-000145:mdna:53]
Net Sales-Water Systems

[0000038725-17-000145:mdna:54]
Water Systems sales were $370.6 million in the first half 2017, an increase of $7.2 million or about 2 percent versus the first half 2016. Foreign currency translation rate changes decreased sales $1.0 million, or less than 1 percent, compared to sales in the first half of 2016. The Water Systems sales change in the first half of 2017, excluding foreign currency translation, was an increase of $8.2 million or about 2 percent.

[0000038725-17-000145:mdna:55]
Water Systems sales in the U.S. and Canada increased by about 2 percent compared to the first half of 2016. Sales revenue decreased by $0.8 million or less than 1 percent in the first half of 2017 due to foreign currency translation. In the first half of 2017, Sales of dewatering equipment increased by about 20 percent when compared to the prior year resulting from the continued diversification of customers and new channel development for Pioneer branded equipment.  Sales of other surface pumping equipment increased by 3 percent in part due to wet weather conditions in the upper Midwest and Canada.  Sales of groundwater pumping equipment decreased about 5 percent.

[0000038725-17-000145:mdna:56]
Water Systems sales in markets outside the U.S. and Canada increased by about 2 percent compared to the first half of 2016. Sales revenue decreased by $0.2 million or less than 1 percent in the first half of 2017 due to foreign currency translation. International Water Systems sales were led by improved sales in Latin America, Europe, the Middle East and Africa, but were offset by lower sales volumes in the Asia Pacific markets in the first half of 2017 compared to last year.

[0000038725-17-000145:mdna:57]
Net Sales-Fueling Systems

[0000038725-17-000145:mdna:58]
Fueling Systems sales were $114.5 million in the first half 2017, an increased $7.4 million or about 7 percent from the first half of 2016. Foreign currency translation rate changes decreased sales $1.5 million or about 1 percent compared to sales in the first half of 2016. The Fueling Systems sales change in the first half of 2017, excluding foreign currency translation, was an increase of $8.9 million or about 8 percent.

[0000038725-17-000145:mdna:59]
Fueling Systems sales in the U.S. and Canada grew by about 4 percent during the first half with most of the sales growth coming from fuel management systems and piping. Internationally, Fueling Systems revenues grew by about 17 percent with increased sales in Europe, Africa and Asia.

[0000038725-17-000145:mdna:60]
Net Sales-Distribution

[0000038725-17-000145:mdna:61]
Distribution sales were $59.1 million in the first half of 2017 and were all acquisition related.  Based on the information provided, management estimates Distribution sales declined by about 2 percent from the same period in 2016 primarily driven by adverse weather conditions in the Western portion of the United States.

[0000038725-17-000145:mdna:62]
Cost of Sales

[0000038725-17-000145:mdna:63]
Cost of sales as a percent of net sales for the first half of 2017 and 2016 was 66.0 percent and 65.0 percent, respectively. Correspondingly, the gross profit margin was 34.0 percent and 35.0 percent for both first halves. The Company's consolidated gross profit was $178.6 million for the first half of 2017, up $13.7 million from the gross profit of $164.9 million in the first half of 2016. The gross profit increase was primarily due to higher sales.

[0000038725-17-000145:mdna:64]
Selling, General, and Administrative (“SG&A”)

[0000038725-17-000145:mdna:65]
Selling, general, and administrative expenses were $125.3 million in the first half of 2017 and increased by $15.0 million or 14 percent in the first half of 2017 compared to $110.3 million the first half of last year. The increase in SG&A expenses from acquired businesses were $13.0 million.  Excluding the acquired entities, the Company’s SG&A expenses in the second quarter of 2017 increased by $2.0 million or about 2 percent.

[0000038725-17-000145:mdna:66]
Restructuring Expenses

[0000038725-17-000145:mdna:67]
Restructuring expenses for the first half of 2017 were $0.6 million. Restructuring expenses were primarily related to manufacturing realignment activities in Brazil. Restructuring expenses for the first half of 2016 were $0.9 million.

[0000038725-17-000145:mdna:68]
Restructuring expenses were split across both segments, $0.4 million in Water and $0.5 million in Fueling, and included asset write-offs, severance expenses and other miscellaneous manufacturing realignment activities.

[0000038725-17-000145:mdna:69]
Operating Income

[0000038725-17-000145:mdna:70]
Operating income was $52.7 million in the first half of 2017, down $1.1 million from $53.8 million in the first half

[0000038725-17-000145:mdna:71]
of 2016.

[0000038725-17-000145:mdna:72]
|  |  | Operating income (loss) |
| (In millions) |  | YTD June 30, 2017 |  | YTD July 2, 2016 |  | 2017 v 2016 |
| Water Systems |  | $ | 54.2 |  |  | $ | 55.6 |  |  | $ | (1.4 | ) |
| Fueling Systems |  | 25.8 |  |  | 25.8 |  |  | — |  |
| Distribution |  | 3.7 |  |  | — |  |  | 3.7 |  |
| Eliminations/Other |  | (31.0 | ) |  | (27.6 | ) |  | (3.4 | ) |
| Consolidated |  | $ | 52.7 |  |  | $ | 53.8 |  |  | $ | (1.1 | ) |

[0000038725-17-000145:mdna:73]
Operating Income-Water Systems

[0000038725-17-000145:mdna:74]
Water Systems operating income was $54.2 million in the first half of 2017 compared to $55.6 million in the first half of 2016, a decrease of 3 percent. The first half operating income margin was 14.6 percent and decreased by 70 basis points compared to the first half of 2016. Operating income margin decreased in Water Systems primarily due to higher material costs.

[0000038725-17-000145:mdna:75]
Operating Income-Fueling Systems

[0000038725-17-000145:mdna:76]
Fueling Systems operating income was $25.8 million in the first half of 2017 compared to $25.8 million in the first half of 2016. The first half operating income margin was 22.6 percent compared to 24.1 percent of net sales in the first half of 2016, a decrease of 150 basis points due to adverse product and geographic sales mix shifts.

[0000038725-17-000145:mdna:77]
Operating Income-Distribution

[0000038725-17-000145:mdna:78]
Distribution operating income was $3.7 million in the first half of 2017 and operating income margin was 6.3 percent.

[0000038725-17-000145:mdna:79]
Operating Income-Eliminations/Other

[0000038725-17-000145:mdna:80]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses.  The inter-segment profit elimination impact in the first half of 2017 was $3.3 million. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer.  General and administrative expenses were flat to last year in the first half.

[0000038725-17-000145:mdna:81]
Interest Expense

[0000038725-17-000145:mdna:82]
Interest expense for the first half of 2017 and 2016 was $5.8 million and $4.6 million, respectively.  The increase in interest expense in the first half of 2017 is due to recorded interest charges on prior years' VAT taxes as a result of an audit in an international jurisdiction.

[0000038725-17-000145:mdna:83]
Other Income or Expense

[0000038725-17-000145:mdna:84]
Other income or expense was a gain of $6.2 million in the first half of 2017. Included in other income in the first half of 2017 was a gain of $4.8 million on the previously held equity investments in three Distribution entities as indicated in the announcement made on April 10, 2017 regarding the acquisition of the controlling interests of these entities. Also, included in other income in the first half of 2017 was minority income $0.6 million and interest income of $0.6 million, primarily derived from the investment of cash balances in short-term securities. The first half of 2016 other income or expense was a gain of $1.3 million in the first half of 2016. Included in other income in the first half of 2016 was minority income $0.4 million and interest income of $0.6 million, primarily derived from the investment of cash balances in short-term securities.

[0000038725-17-000145:mdna:85]
Foreign Exchange

[0000038725-17-000145:mdna:86]
Foreign currency-based transactions for the first half of 2017 and 2016 was a gain of $0.1 million and a gain $0.2 million, respectively.

[0000038725-17-000145:mdna:87]
Income Taxes

[0000038725-17-000145:mdna:88]
The provision for income taxes in the first half of 2017 and 2016 was $7.1 million and $12.9 million, respectively. The effective tax rate for the first half of 2017 was about 13 percent and, before the impact of discrete events, was about 27 percent. The effective tax rate for the second quarter of 2016 was about 25 percent and, before the impact of discrete events, was about 26 percent. The tax rate as a percentage of pre-tax earnings for the full year of 2017 is projected to be 25 percent to 28 percent, compared to the full year 2016 tax rate of about 26 percent, before discrete adjustments. The projected tax rate is lower than the statutory rate of 35 percent primarily due to the indefinite reinvestment of foreign earnings and reduced taxes on foreign and repatriated earnings. The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations, current cash on hand and available credit.

[0000038725-17-000145:mdna:89]
Net Income

[0000038725-17-000145:mdna:90]
Net income for the first half of 2017 was $46.2 million compared to 2016 first half net income of $37.8 million.  Net income attributable to Franklin Electric Co., Inc. for the first half of 2017 was $45.6 million, or $0.97 per diluted share, compared to 2016 first half net income attributable to Franklin Electric Co., Inc. of $37.4 million or $0.78 per diluted share.

[0000038725-17-000145:mdna:91]
[same as prior period, unchanged from 0000038725-17-000089:mdna:45]

[0000038725-17-000145:mdna:92]
[same as prior period, unchanged from 0000038725-17-000089:mdna:46]

[0000038725-17-000145:mdna:93]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available.  The Company believes its capital resources and liquidity position at June 30, 2017 is adequate to meet projected needs for the foreseeable future.  The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-17-000145:mdna:94]
As of June 30, 2017, the Company had a $300.0 million revolving credit facility.  The facility is scheduled to mature on October 28, 2021.  As of June 30, 2017, the Company had $182.7 million borrowing capacity under the Credit Agreement as $6.0 million in letters of commercial and standby letters of credit were outstanding and undrawn and $111.3 million in revolver borrowings were drawn and outstanding as of the end of the quarter which were primarily used for acquisition and working capital needs.

[0000038725-17-000145:mdna:95]
The Company also has other long-term debt borrowings outstanding as of June 30, 2017.  See Note 10 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-17-000145:mdna:96]
At June 30, 2017, the Company had $44.6 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations.  There is currently no need to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-17-000145:mdna:97]
[same as prior period, unchanged from 0000038725-17-000089:mdna:51]

[0000038725-17-000145:mdna:98]
The following table summarizes significant sources and uses of cash and cash equivalents for the first six months of 2017 and 2016.

[0000038725-17-000145:mdna:99]
| (in millions) |  | 2017 |  | 2016 |
| Net cash provided by (used in) operating activities |  | $ | (12.5 | ) |  | $ | 29.3 |  |
| Net cash used in investing activities |  | (70.6 | ) |  | (17.1 | ) |
| Net cash provided by (used in) financing activities |  | 31.6 |  |  | (21.8 | ) |
| Impact of exchange rates on cash and cash equivalents |  | 2.3 |  |  | (0.3 | ) |
| Change in cash and cash equivalents |  | $ | (49.2 | ) |  | $ | (9.9 | ) |

[0000038725-17-000145:mdna:100]
Cash Flows Provided by (Used in) Operating Activities

[0000038725-17-000145:mdna:101]
[same as prior period, unchanged from 0000038725-17-000089:mdna:55]

[0000038725-17-000145:mdna:102]
Net cash used in operating activities was $12.5 million for the six months ended June 30, 2017 compared to the $29.3 million provided by operating activities for the six months ended July 2, 2016.  The increase in cash used in operations was largely attributable to an increase in inventory due to sales projections for the current year which are anticipated to be higher than the same period for the prior year.  Higher sales resulted in increased receivables throughout the first six months of 2017, and excluding the impact of the Distribution acquisitions in the second quarter of 2017, the Company also had higher uses of cash related to paying down accounts payable, primarily timing of inventory receipts, and payments and incentive compensation, as

[0000038725-17-000145:mdna:103]
well as higher tax payments in the first half of 2017 based on prior year earnings and relative to payments in the first half of the prior year.

[0000038725-17-000145:mdna:104]
[same as prior period, unchanged from 0000038725-17-000089:mdna:57]

[0000038725-17-000145:mdna:105]
[same as prior period, unchanged from 0000038725-17-000089:mdna:58]

[0000038725-17-000145:mdna:106]
Net cash used in investing activities was $70.6 million for the six months ended June 30, 2017 compared to $17.1 million in the six months ended July 2, 2016 in the prior year.  The increase was almost entirely attributable to cash paid related to the Distribution acquisitions during the second quarter of 2017.

[0000038725-17-000145:mdna:107]
[same as prior period, unchanged from 0000038725-17-000089:mdna:60]

[0000038725-17-000145:mdna:108]
[same as prior period, unchanged from 0000038725-17-000089:mdna:61]

[0000038725-17-000145:mdna:109]
Net cash provided by financing activities was $31.6 million for the six months ended June 30, 2017 compared to $21.8 million used in financing activities for the six months ended July 2, 2016 in the prior year.  The provision of cash related to financing activities was primarily attributable to increased borrowings used to fund the Distribution acquisitions during the second quarter of 2017.

[0000038725-17-000145:mdna:110]
[same as prior period, unchanged from 0000038725-17-000089:mdna:63]
