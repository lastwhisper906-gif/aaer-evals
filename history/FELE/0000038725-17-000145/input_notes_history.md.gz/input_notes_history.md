# FELE note change history — 0000038725-17-000089 → 0000038725-17-000145


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-08-01):
[0000038725-17-000145:note_history:1]
At June 30, 2017, the Company had $7.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.
  (was, 2017-05-02, similarity 0.9689):
[0000038725-17-000089:note_history:1]
At March 31, 2017, the Company had $15.6 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

- changed (2017-08-01):
[0000038725-17-000145:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended June 30, 2017, are as follows:
  (was, 2017-05-02, similarity 0.9118):
[0000038725-17-000089:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the first quarter ended March 31, 2017, are as follows:

- changed (2017-08-01):
[0000038725-17-000145:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2016 |  | $ | 8.2 |  |
| Accruals related to product warranties |  | 4.7 |  |
| Additions related to acquisitions |  | 1.5 |  |
| Reductions for payments made |  | (3.8 | ) |
| Balance as of June 30, 2017 |  | $ | 10.6 |  |
  (was, 2017-05-02, similarity 0.8758):
[0000038725-17-000089:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2016 |  | $ | 8.2 |  |
| Accruals related to product warranties |  | 2.0 |  |
| Reductions for payments made |  | (1.5 | ) |
| Balance as of March 31, 2017 |  | $ | 8.7 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-08-01):
[0000038725-17-000145:note_history:4]
The accompanying condensed consolidated balance sheet as of December 31, 2016, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 30, 2017, and for the second quarters and six months ended June 30, 2017 and July 2, 2016 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the second quarter and six months ended June 30, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2017.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2016.
  (was, 2017-05-02, similarity 0.9413):
[0000038725-17-000089:note_history:4]
The accompanying condensed consolidated balance sheet as of December 31, 2016, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2017, and for the first quarters ended March 31, 2017 and April 2, 2016 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the first quarter ended March 31, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2017.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2016.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-01):
[0000038725-17-000145:note_history:5]
| (In millions) |  | June 30, 2017 |  | December 31, 2016 |
| Prudential Agreement |  | $ | 60.0 |  |  | $ | 90.0 |  |
| Tax increment financing debt |  | 21.3 |  |  | 21.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Revolver |  | 111.3 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 4.0 |  |  | 3.6 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 271.4 |  |  | $ | 190.2 |  |
| Less: current maturities |  | (145.4 | ) |  | (33.7 | ) |
| Long-term debt |  | $ | 126.0 |  |  | $ | 156.5 |  |
  (was, 2017-05-02, similarity 0.9586):
[0000038725-17-000089:note_history:5]
| (In millions) |  | March 31, 2017 |  | December 31, 2016 |
| Prudential Agreement |  | $ | 90.0 |  |  | $ | 90.0 |  |
| Tax increment financing debt |  | 21.3 |  |  | 21.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 3.9 |  |  | 3.6 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 190.0 |  |  | $ | 190.2 |  |
| Less: current maturities |  | (33.8 | ) |  | (33.7 | ) |
| Long-term debt |  | $ | 156.2 |  |  | $ | 156.5 |  |

- changed (2017-08-01):
[0000038725-17-000145:note_history:6]
Debt outstanding, excluding unamortized debt issuance costs, at June 30, 2017 matures as follows:
  (was, 2017-05-02, similarity 0.9514):
[0000038725-17-000089:note_history:6]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2017 matures as follows:

- changed (2017-08-01):
[0000038725-17-000145:note_history:7]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 271.6 |  |  | $ | 145.3 |  |  | $ | 31.2 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 91.3 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 271.7 |  |  | $ | 145.4 |  |  | $ | 31.2 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 91.3 |  |
  (was, 2017-05-02, similarity 0.6306):
[0000038725-17-000089:note_history:7]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 190.2 |  |  | $ | 33.8 |  |  | $ | 31.2 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 91.3 |  |
| Capital leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 190.3 |  |  | $ | 33.8 |  |  | $ | 31.3 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 91.3 |  |

- changed (2017-08-01):
[0000038725-17-000145:note_history:8]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with an initial borrowing capacity of $250.0 million.  The Prudential Agreement bears a coupon of 5.79 percent with a final maturity in 2019.  Principal installments of $30.0 million are payable annually, including the date of maturity of April 30, 2019, with any unpaid balance due at that time.  There is no additional borrowing capacity resulting from principal payments made by the Company.  As of June 30, 2017, the Company has $100.0 million borrowing capacity available under the Prudential Agreement.
  (was, 2017-05-02, similarity 0.6479):
[0000038725-17-000089:note_history:8]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with a limited borrowing capacity of $250.0 million.  The Prudential Agreement bears a coupon of 5.79 percent with a final maturity in 2019.  As of March 31, 2017, the Company has $100.0 million borrowing capacity available under the Prudential Agreement.  Principal installments of $30.0 million are payable annually, including the date of maturity of April 30, 2019, with any unpaid balance due at that time.

- changed (2017-08-01):
[0000038725-17-000145:note_history:9]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement"), entered into on May 27, 2015 for $150.0 million maximum aggregate principal borrowing capacity and authorized issuance of $75.0 million of floating rate senior notes due May 27, 2025. These senior notes have a floating interest rate of one-month USD LIBOR (1.22 percent as of June 30, 2017) plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  As of June 30, 2017, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.
  (was, 2017-05-02, similarity 0.9851):
[0000038725-17-000089:note_history:9]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement"), entered into on May 27, 2015 for $150.0 million maximum aggregate principal borrowing capacity and authorized issuance of $75.0 million of floating rate senior notes due May 27, 2025. These senior notes have a floating interest rate of one-month USD LIBOR (0.98 percent as of March 31, 2017) plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  As of March 31, 2017, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

- changed (2017-08-01):
[0000038725-17-000145:note_history:10]
As of June 30, 2017, the Company had $111.3 million in outstanding borrowings which were primarily used for acquisition and working capital needs, $6.0 million in letters of credit outstanding, and $182.7 million of available capacity under the Credit Agreement.
  (was, 2017-05-02, similarity 0.7826):
[0000038725-17-000089:note_history:10]
As of March 31, 2017, the Company had no outstanding borrowings, $6.0 million in letters of credit outstanding, and $294.0 million of available capacity under the Credit Agreement.

- changed (2017-08-01):
[0000038725-17-000145:note_history:11]
The New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement contain customary affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of June 30, 2017.
  (was, 2017-05-02, similarity 0.9956):
[0000038725-17-000089:note_history:11]
The New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement contain customary affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of March 31, 2017.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-01):
[0000038725-17-000145:note_history:12]
| (In millions) |  | June 30, 2017 |  | December 31, 2016 |
| Prudential Agreement |  | $ | 60.0 |  |  | $ | 90.0 |  |
| Tax increment financing debt |  | 21.3 |  |  | 21.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Revolver |  | 111.3 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 4.0 |  |  | 3.6 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 271.4 |  |  | $ | 190.2 |  |
| Less: current maturities |  | (145.4 | ) |  | (33.7 | ) |
| Long-term debt |  | $ | 126.0 |  |  | $ | 156.5 |  |
  (was, 2017-05-02, similarity 0.9586):
[0000038725-17-000089:note_history:12]
| (In millions) |  | March 31, 2017 |  | December 31, 2016 |
| Prudential Agreement |  | $ | 90.0 |  |  | $ | 90.0 |  |
| Tax increment financing debt |  | 21.3 |  |  | 21.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 3.9 |  |  | 3.6 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 190.0 |  |  | $ | 190.2 |  |
| Less: current maturities |  | (33.8 | ) |  | (33.7 | ) |
| Long-term debt |  | $ | 156.2 |  |  | $ | 156.5 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-08-01):
[0000038725-17-000145:note_history:13]
Debt outstanding, excluding unamortized debt issuance costs, at June 30, 2017 matures as follows:
  (was, 2017-05-02, similarity 0.9514):
[0000038725-17-000089:note_history:13]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2017 matures as follows:

- changed (2017-08-01):
[0000038725-17-000145:note_history:14]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 271.6 |  |  | $ | 145.3 |  |  | $ | 31.2 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 91.3 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 271.7 |  |  | $ | 145.4 |  |  | $ | 31.2 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 91.3 |  |
  (was, 2017-05-02, similarity 0.6306):
[0000038725-17-000089:note_history:14]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 190.2 |  |  | $ | 33.8 |  |  | $ | 31.2 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 91.3 |  |
| Capital leases |  | 0.1 |  |  | — |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 190.3 |  |  | $ | 33.8 |  |  | $ | 31.3 |  |  | $ | 31.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 91.3 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2017-08-01):
[0000038725-17-000089:note_history:15]
SUBSEQUENT EVENT

- removed (2017-08-01):
[0000038725-17-000089:note_history:16]
Subsequent to the end of the first quarter, the Company entered into agreements to acquire controlling interests in certain distributors in the U.S. professional groundwater market.  These companies will continue to operate as full line wholesale distributors with a focus on total water systems support, including products from other industry manufacturers.

- removed (2017-08-01):
[0000038725-17-000089:note_history:17]
The Company previously held equity interests in these entities, each of which was less than 50 percent, and accounted for by the equity method of accounting.  As a result of the additional acquisition, the Company’s total interest in each of the entities is now 100 percent and the entities will be included in the Company’s consolidated results effective from the date of acquisition.

- removed (2017-08-01):
[0000038725-17-000089:note_history:18]
The Company acquired the controlling interests of the entities for approximately $89 million, including assumed debt, subject to certain terms and conditions.

- removed (2017-08-01):
[0000038725-17-000089:note_history:19]
For financial reporting purposes, the acquired businesses will be reported separately from the Company’s existing Water Systems segment within a newly-established Distribution segment.
