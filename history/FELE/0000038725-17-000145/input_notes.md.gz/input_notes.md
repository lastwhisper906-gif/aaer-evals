# FELE notes — 0000038725-17-000145


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000038725-17-000145:notes:1]
| FRANKLIN ELECTRIC CO., INC. |
| PROFORMA CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
|  |  | Second Quarter Ended |  | Six Months Ended |
| (in millions, except per share amounts) |  | June 30, 2017 |  | July 2, 2016 |  | June 30, 2017 |  | July 2, 2016 |
| Revenue: |  |  |  |  |  |  |  |  |
| As reported |  | $ | 305.3 |  |  | $ | 252.1 |  |  | $ | 525.6 |  |  | $ | 470.5 |  |
| Proforma |  | 315.2 |  |  | 309.8 |  |  | 585.5 |  |  | 571.0 |  |
| Net income: |  |  |  |  |  |  |  |  |
| As reported |  | $ | 29.9 |  |  | $ | 24.0 |  |  | $ | 45.6 |  |  | $ | 37.4 |  |
| Proforma |  | 30.3 |  |  | 26.3 |  |  | 46.9 |  |  | 40.6 |  |
| Basic earnings per share: |  |  |  |  |  |  |  |  |
| As reported |  | $ | 0.64 |  |  | $ | 0.51 |  |  | $ | 0.97 |  |  | $ | 0.79 |  |
| Proforma |  | 0.65 |  |  | 0.56 |  |  | 1.00 |  |  | 0.84 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |
| As reported |  | $ | 0.64 |  |  | $ | 0.50 |  |  | $ | 0.97 |  |  | $ | 0.78 |  |
| Proforma |  | 0.64 |  |  | 0.55 |  |  | 0.99 |  |  | 0.83 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-17-000145:notes:2]
ACQUISITIONS

[0000038725-17-000145:notes:3]
During the second quarter of 2017, the Company redeemed 10 percent of the noncontrolling interest of Impo, a Turkish subsidiary, increasing the Company’s ownership to 100 percent for approximately TRY 17.0 million, $5.0 million at the then current exchange rate.  The 10 percent redemption value was calculated using a specified formula and resulted in a reduction to the carrying value of TRY 0.6 million ($0.2 million).  Due to the immaterial nature of the redemption, the Company has not included full year proforma statements of income for the acquisition year or previous year.

[0000038725-17-000145:notes:4]
During the second quarter of 2017, the Company acquired controlling interests in three distributors (2M Company, Inc. (“2M”), Drillers Service, Inc. (“DSI”), and Western Hydro, LLC (“Western Hydro”), collectively referred to below as the “Headwater acquisitions”) in the U.S. professional groundwater market for a combined purchase price of approximately $57.9 million, subject to certain terms and conditions.  The Company had previously prepaid a $3.0 million portion of the purchase price at the time of original investment.  The Company funded the Headwater acquisitions with cash on hand and short-term borrowings from the Company’s Revolver (see Note 10 - Debt).  The Headwater acquisitions will be reported within a new “Distribution” segment (see Note 14 - Segment Information).  The Headwater acquisitions provide the Company with a robust groundwater distribution channel throughout the United States.

[0000038725-17-000145:notes:5]
The Company previously held equity interests in these entities, each of which was less than 50 percent, and accounted for by the equity method of accounting.  The Company’s total interest in each of the entities is now 100 percent and the entities are included in the Company’s consolidated results effective from the date of acquisition.  The original equity interests in the acquired entities were remeasured to their fair values as of the acquisition date (which aggregated was $20.2 million) based on the income approach, which utilized management estimates and consultation with an independent third-party valuation firm.  Inputs included an analysis of the enterprise value based on financial projections and ownership percentages.  As a result, the Company recognized an aggregate one-time gain on the acquisitions of $4.8 million, and none of the individual entity gains were material.  This gain is included in the “Other income, net” line of the Company’s condensed consolidated statements of income for the second quarter and six months ended June 30, 2017.

[0000038725-17-000145:notes:6]
The preliminary identifiable intangible assets recognized due to the Headwater acquisitions were $5.7 million and consist of customer relationships, which will be amortized utilizing the straight-line method over 15 years.

[0000038725-17-000145:notes:7]
The preliminary goodwill of $34.4 million resulting from the Headwater acquisitions consists primarily of the benefits of forward channel integration opportunities and broadened product offerings. All of the goodwill was recorded as part of the Distribution segment, and only a portion ($12.1 million) is expected to be deductible for tax purposes.

[0000038725-17-000145:notes:8]
The preliminary purchase price assigned to the major identifiable assets and liabilities for the Headwater acquisitions on an aggregated basis is as follows:

[0000038725-17-000145:notes:9]
| (In millions) |  |  |
| Cash |  | $ | 2.7 |  |
| Receivables |  | 30.4 |  |
| Inventory |  | 56.9 |  |
| Other current assets |  | 2.9 |  |
| Total current assets |  | 92.9 |  |
| Property, plant, and equipment |  | 9.4 |  |
| Intangible assets |  | 5.7 |  |
| Goodwill |  | 34.4 |  |
| Other assets |  | 1.7 |  |
| Total assets |  | 144.1 |  |
| Accounts payable |  | (20.2 | ) |
| Accrued liabilities and other current liabilities |  | (11.5 | ) |
| Current maturities of long-term debt |  | (31.6 | ) |
| Total current liabilities |  | (63.3 | ) |
| Long-term debt |  | (2.0 | ) |
| Other long-term liabilities |  | (0.7 | ) |
| Total liabilities |  | (66.0 | ) |
| Total |  | 78.1 |  |
| Less: Fair value of original equity interest |  | (20.2 | ) |
| Total purchase price |  | $ | 57.9 |  |

[0000038725-17-000145:notes:10]
The fair values of the identifiable intangible assets and property, plant, and equipment related to the Headwater acquisition are provisional amounts as of June 30, 2017, pending final valuations and purchase accounting adjustments.  The Company utilized management estimates and consultation with an independent third-party valuation firm to assist in the valuation process.

[0000038725-17-000145:notes:11]
The following unaudited proforma financial information for the second quarters and six months ended June 30, 2017 and July 2, 2016 gives effect to the Headwater acquisitions by the Company as if the acquisitions had occurred as of January 3, 2016.  These unaudited proforma condensed consolidated financial statements are prepared for informational purposes only and are not necessarily indicative of actual results or financial position that would have been achieved had the acquisitions been consummated on the dates indicated and are not necessarily indicative of future operating results or financial position of the consolidated companies.  The unaudited proforma condensed consolidated financial statements do not give effect to any cost savings or incremental costs that may result from the integration of the Headwater acquisitions with the Company.

[0000038725-17-000145:notes:12]
The Headwater entities contributed a total of $59.1 million of revenue and $1.9 million of net income to the Company's condensed consolidated statements of income from their acquisition dates through June 30, 2017.

[0000038725-17-000145:notes:13]
Transaction costs were expensed as incurred under the guidance of FASB Accounting Standards Codification Topic 805, Business Combinations.  There were $0.1 million and $0.3 million of transaction costs included in the "Selling, general, and administrative expenses" line of the Company's condensed consolidated statements of income for the second quarter and six months ended June 30, 2017, respectively.  There were no transaction costs incurred in the second quarter or six months ended July 2, 2016.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-17-000145:notes:14]
COMMITMENTS AND CONTINGENCIES

[0000038725-17-000145:notes:15]
The Company is defending various claims and legal actions which have arisen in the ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-17-000145:notes:16]
At June 30, 2017, the Company had $7.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-17-000145:notes:17]
The Company provides warranties on most of its products.  The warranty terms vary but are generally two to five years from date of manufacture or one to five years from date of installation.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-17-000145:notes:18]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended June 30, 2017, are as follows:

[0000038725-17-000145:notes:19]
| (In millions) |  |  |
| Balance as of December 31, 2016 |  | $ | 8.2 |  |
| Accruals related to product warranties |  | 4.7 |  |
| Additions related to acquisitions |  | 1.5 |  |
| Reductions for payments made |  | (3.8 | ) |
| Balance as of June 30, 2017 |  | $ | 10.6 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-17-000145:notes:20]
[same as prior period, unchanged from 0000038725-17-000089:notes:7]

[0000038725-17-000145:notes:21]
Changes in accumulated other comprehensive income/(loss) by component for the six months ended June 30, 2017 and July 2, 2016, are summarized below:

[0000038725-17-000145:notes:22]
| (In millions) |  |  |  |  |  |
| For the six months ended June 30, 2017: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| Balance as of December 31, 2016 | $ | (118.4 | ) |  | $ | (51.5 | ) |  | $ | (169.9 | ) |
| Other comprehensive income/(loss) before reclassifications | 15.2 |  | — |  |  | 15.2 |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 1.0 |  |  | 1.0 |  |
| Net other comprehensive income/(loss) | 15.2 |  |  | 1.0 |  |  | 16.2 |  |
| Balance as of June 30, 2017 | $ | (103.2 | ) |  | $ | (50.5 | ) |  | $ | (153.7 | ) |
| For the six months ended July 2, 2016: |  |  |  |  |  |
| Balance as of January 2, 2016 | $ | (110.1 | ) |  | $ | (51.5 | ) |  | $ | (161.6 | ) |
| Other comprehensive income/(loss) before reclassifications | 13.9 |  |  | — |  |  | 13.9 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.9 |  |  | 0.9 |  |
| Net other comprehensive income/(loss) | 13.9 |  |  | 0.9 |  |  | 14.8 |  |
| Balance as of July 2, 2016 | $ | (96.2 | ) |  | $ | (50.6 | ) |  | $ | (146.8 | ) |

[0000038725-17-000145:notes:23]
(1) This accumulated other comprehensive income/(loss) component is included in the computation of net periodic pension cost (refer to Note 8 for additional details) and is included in the "Selling, general, and administrative expenses" line of the Company's condensed consolidated statements of income.

[0000038725-17-000145:notes:24]
(2) Net of tax (benefit)/expense of $0.5 million for both the six months ended June 30, 2017 and July 2, 2016.

[0000038725-17-000145:notes:25]
[same as prior period, unchanged from 0000038725-17-000089:notes:12]


## us-gaap:DebtDisclosureTextBlock

[0000038725-17-000145:notes:26]
DEBT

[0000038725-17-000145:notes:27]
Debt consisted of the following:

[0000038725-17-000145:notes:28]
| (In millions) |  | June 30, 2017 |  | December 31, 2016 |
| Prudential Agreement |  | $ | 60.0 |  |  | $ | 90.0 |  |
| Tax increment financing debt |  | 21.3 |  |  | 21.8 |  |
| New York Life |  | 75.0 |  |  | 75.0 |  |
| Revolver |  | 111.3 |  |  | — |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 4.0 |  |  | 3.6 |  |
| Less: unamortized debt issuance costs |  | (0.3 | ) |  | (0.3 | ) |
|  |  | $ | 271.4 |  |  | $ | 190.2 |  |
| Less: current maturities |  | (145.4 | ) |  | (33.7 | ) |
| Long-term debt |  | $ | 126.0 |  |  | $ | 156.5 |  |

[0000038725-17-000145:notes:29]
Debt outstanding, excluding unamortized debt issuance costs, at June 30, 2017 matures as follows:

[0000038725-17-000145:notes:30]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 271.6 |  |  | $ | 145.3 |  |  | $ | 31.2 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 91.3 |  |
| Capital leases |  | 0.1 |  |  | 0.1 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
|  |  | $ | 271.7 |  |  | $ | 145.4 |  |  | $ | 31.2 |  |  | $ | 1.3 |  |  | $ | 1.2 |  |  | $ | 1.3 |  |  | $ | 91.3 |  |

[0000038725-17-000145:notes:31]
Prudential Agreement

[0000038725-17-000145:notes:32]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with an initial borrowing capacity of $250.0 million.  The Prudential Agreement bears a coupon of 5.79 percent with a final maturity in 2019.  Principal installments of $30.0 million are payable annually, including the date of maturity of April 30, 2019, with any unpaid balance due at that time.  There is no additional borrowing capacity resulting from principal payments made by the Company.  As of June 30, 2017, the Company has $100.0 million borrowing capacity available under the Prudential Agreement.

[0000038725-17-000145:notes:33]
Project Bonds

[0000038725-17-000145:notes:34]
The Company, Allen County, Indiana and certain institutional investors maintain a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)." The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. These Project Notes ("Tax increment financing debt") bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.

[0000038725-17-000145:notes:35]
New York Life

[0000038725-17-000145:notes:36]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life (the "New York Life Agreement"), entered into on May 27, 2015 for $150.0 million maximum aggregate principal borrowing capacity and authorized issuance of $75.0 million of floating rate senior notes due May 27, 2025. These senior notes have a floating interest rate of one-month USD LIBOR (1.22 percent as of June 30, 2017) plus a spread of 1.35 percent with interest-only payments due on a monthly basis.  As of June 30, 2017, there was $75.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-17-000145:notes:37]
Credit Agreement

[0000038725-17-000145:notes:38]
The Company maintains the Third Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement has a maturity date of October 28, 2021 and commitment amount of $300.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million).  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-17-000145:notes:39]
As of June 30, 2017, the Company had $111.3 million in outstanding borrowings which were primarily used for acquisition and working capital needs, $6.0 million in letters of credit outstanding, and $182.7 million of available capacity under the Credit Agreement.

[0000038725-17-000145:notes:40]
Covenants

[0000038725-17-000145:notes:41]
The New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement contain customary affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of June 30, 2017.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-17-000145:notes:42]
[same as prior period, unchanged from 0000038725-17-000089:notes:29]

[0000038725-17-000145:notes:43]
The Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  The Company has entered into share swap transaction agreements ("the swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price.  The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party.  As of June 30, 2017, the swap had a notional value based on 215,000 shares.  For the second quarter and six months ended June 30, 2017, the swap resulted in a loss of $0.4 million and a gain of $0.4 million, respectively.  For the second quarter and six months ended July 2, 2016, the swap resulted in gains of $0.3 million and $1.1 million, respectively.  Gains and losses resulting from the the swap were primarily offset by gains and losses on the fair value of the deferred compensation stock liability.  All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-17-000145:notes:44]
[same as prior period, unchanged from 0000038725-17-000089:notes:31]

[0000038725-17-000145:notes:45]
Effective May 5, 2017, the shareholders of the Company approved the Franklin Electric Co., Inc. 2017 Stock Plan (the "2017 Stock Plan").  The Board of Directors had previously approved the 2017 Stock Plan on March 15, 2017 subject to shareholder approval.  The 2017 Stock Plan was enacted in addition to the previously approved 2009 and 2012 Stock Plans and is a stock-based compensation plan that provides for discretionary grants of stock options, stock awards, stock unit awards, and stock appreciation rights ("SARs") to key employees and non-employee directors.  The number of shares that may be issued under the Plan is 1,400,000.  Stock options and SARs reduce the number of available shares by one share for each share subject to the option or SAR, and stock awards and stock unit awards settled in shares reduce the number of available shares by 1.5 shares for every one share delivered.

[0000038725-17-000145:notes:46]
The Company also maintains the Franklin Electric Co., Inc. 2012 Stock Plan (the "2012 Stock Plan"), which is a stock-based compensation plan that provides for discretionary grants of stock options, stock awards, and stock unit awards to key employees and non-employee directors.

[0000038725-17-000145:notes:47]
[same as prior period, unchanged from 0000038725-17-000089:notes:33]

[0000038725-17-000145:notes:48]
[same as prior period, unchanged from 0000038725-17-000089:notes:34]

[0000038725-17-000145:notes:49]
[same as prior period, unchanged from 0000038725-17-000089:notes:35]

[0000038725-17-000145:notes:50]
[same as prior period, unchanged from 0000038725-17-000089:notes:36]

[0000038725-17-000145:notes:51]
[same as prior period, unchanged from 0000038725-17-000089:notes:37]

[0000038725-17-000145:notes:52]
The Company currently issues new shares from its common stock balance to satisfy option exercises and the settlement of stock awards and stock unit awards made under the outstanding stock plans.

[0000038725-17-000145:notes:53]
[same as prior period, unchanged from 0000038725-17-000089:notes:39]

[0000038725-17-000145:notes:54]
[same as prior period, unchanged from 0000038725-17-000089:notes:40]

[0000038725-17-000145:notes:55]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the six months ended June 30, 2017 and July 2, 2016 are as follows:

[0000038725-17-000145:notes:56]
|  |  | June 30, 2017 |  | July 2, 2016 |
| Risk-free interest rate |  | 1.89 | % |  | 1.21 | % |
| Dividend yield |  | 0.94 | % |  | 1.32 | % |
| Volatility factor |  | 31.19 | % |  | 37.70 | % |
| Expected term |  | 5.5 years |  |  | 5.5 years |  |

[0000038725-17-000145:notes:57]
A summary of the Company’s outstanding stock option activity and related information for the six months ended June 30, 2017 is as follows:

[0000038725-17-000145:notes:58]
| (Shares in thousands) |  | June 30, 2017 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,455 |  |  | $ | 25.02 |  |
| Granted |  | 192 |  |  | 42.49 |  |
| Exercised |  | (88 | ) |  | 23.23 |  |
| Forfeited |  | (2 | ) |  | 35.99 |  |
| Outstanding at end of period |  | 1,557 |  |  | $ | 27.26 |  |
| Expected to vest after applying forfeiture rate |  | 1,531 |  |  | $ | 27.10 |  |
| Vested and exercisable at end of period |  | 1,070 |  |  | $ | 23.12 |  |

[0000038725-17-000145:notes:59]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value as of June 30, 2017 is as follows:

[0000038725-17-000145:notes:60]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 5.58 years |  | $ | 22,390 |  |
| Expected to vest after applying forfeiture rate |  | 5.52 years |  | $ | 22,256 |  |
| Vested and exercisable at end of period |  | 4.13 years |  | $ | 19,689 |  |

[0000038725-17-000145:notes:61]
The total intrinsic value of options exercised during the six months ended June 30, 2017 and July 2, 2016 was $1.6 million and $0.5 million, respectively.

[0000038725-17-000145:notes:62]
As of June 30, 2017, there was $2.2 million of total unrecognized compensation cost related to non-vested stock options granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.16 years.

[0000038725-17-000145:notes:63]
[same as prior period, unchanged from 0000038725-17-000089:notes:49]

[0000038725-17-000145:notes:64]
A summary of the Company’s restricted stock/stock unit award activity and related information for the six months ended June 30, 2017 is as follows:

[0000038725-17-000145:notes:65]
| (Shares in thousands) |  | June 30, 2017 |
| Restricted Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 473 |  |  | $ | 34.89 |  |
| Awarded |  | 136 |  |  | 42.23 |  |
| Vested |  | (96 | ) |  | 34.95 |  |
| Forfeited |  | (34 | ) |  | 36.61 |  |
| Non-vested at end of period |  | 479 |  |  | $ | 36.84 |  |

[0000038725-17-000145:notes:66]
As of June 30, 2017, there was $11.5 million of total unrecognized compensation cost related to non-vested restricted stock/stock unit awards granted under the 2012 Stock Plan and the 2009 Stock Plan.  That cost is expected to be recognized over a weighted-average period of 2.49 years.


## us-gaap:EarningsPerShareTextBlock

[0000038725-17-000145:notes:67]
[same as prior period, unchanged from 0000038725-17-000089:notes:53]

[0000038725-17-000145:notes:68]
[same as prior period, unchanged from 0000038725-17-000089:notes:54]

[0000038725-17-000145:notes:69]
[same as prior period, unchanged from 0000038725-17-000089:notes:55]

[0000038725-17-000145:notes:70]
[same as prior period, unchanged from 0000038725-17-000089:notes:56]

[0000038725-17-000145:notes:71]
|  | Second Quarter Ended |  | Six Months Ended |
| (In millions, except per share amounts) | June 30, 2017 |  | July 2, 2016 |  | June 30, 2017 |  | July 2, 2016 |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 29.9 |  |  | $ | 24.0 |  |  | $ | 45.6 |  |  | $ | 37.4 |  |
| Less: Undistributed earnings allocated to participating securities | 0.2 |  |  | 0.2 |  |  | 0.3 |  |  | 0.3 |  |
| Less: Undistributed earnings allocated to redeemable noncontrolling interest | (0.2 | ) |  | 0.3 |  |  | — |  |  | 0.8 |  |
| Net income available to common shareholders | $ | 29.9 |  |  | $ | 23.5 |  |  | $ | 45.3 |  |  | $ | 36.3 |  |
| Denominator: |  |  |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 46.5 |  |  | 46.2 |  |  | 46.4 |  |  | 46.2 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |
| Non-participating employee stock options and performance awards | 0.5 |  |  | 0.5 |  |  | 0.6 |  |  | 0.4 |  |
| Diluted weighted average common shares outstanding | 47.0 |  |  | 46.7 |  |  | 47.0 |  |  | 46.6 |  |
| Basic earnings per share | $ | 0.64 |  |  | $ | 0.51 |  |  | $ | 0.97 |  |  | $ | 0.79 |  |
| Diluted earnings per share | $ | 0.64 |  |  | $ | 0.50 |  |  | $ | 0.97 |  |  | $ | 0.78 |  |

[0000038725-17-000145:notes:72]
There were 0.4 million and 0.5 million stock options outstanding for the second quarters ended June 30, 2017 and July 2, 2016, and 0.3 million and 0.7 million stock options outstanding for the six months ended June 30, 2017 and July 2, 2016, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:EquityMethodInvestmentsDisclosureTextBlock

[0000038725-17-000145:notes:73]
[same as prior period, unchanged from 0000038725-17-000089:notes:59]

[0000038725-17-000145:notes:74]
Through the second quarter of 2017, the Company held equity interests in the acquired companies identified in Note 3 - Acquisitions for various strategic purposes.  The investments were accounted for under the equity method and were included in “Other assets” on the Company’s condensed consolidated balance sheets.  The carrying amount of the investments were adjusted for the Company's proportionate share of earnings, losses, and dividends.  The investments were not considered material to the Company’s financial position, either individually or in the aggregate.  The Company’s proportionate share of earnings from its equity interests, included in the "Other income, net" line of the Company's condensed consolidated statements of income, were immaterial for the second quarters ended June 30, 2017 and July 2, 2016.

[0000038725-17-000145:notes:75]
During the second quarter of 2017, the remaining interests of these equity method investments were purchased (see Note 3 - Acquisitions), bringing total ownership of these entities to 100 percent.  As of June 30, 2017, there were no equity method investments recorded on the Company's condensed consolidated balance sheets.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000038725-17-000145:notes:76]
As of June 30, 2017 and December 31, 2016, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-17-000145:notes:77]
| (In millions) | June 30, 2017 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 3.0 |  | $ | 3.0 |  | $ | — |  | $ | — |  |
|  | December 31, 2016 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 3.6 |  | $ | 3.6 |  | $ | — |  | $ | — |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-17-000145:notes:78]
[same as prior period, unchanged from 0000038725-17-000089:notes:63]

[0000038725-17-000145:notes:79]
[same as prior period, unchanged from 0000038725-17-000089:notes:64]

[0000038725-17-000145:notes:80]
[same as prior period, unchanged from 0000038725-17-000089:notes:65]

[0000038725-17-000145:notes:81]
[same as prior period, unchanged from 0000038725-17-000089:notes:66]

[0000038725-17-000145:notes:82]
[same as prior period, unchanged from 0000038725-17-000089:notes:67]

[0000038725-17-000145:notes:83]
[same as prior period, unchanged from 0000038725-17-000089:notes:68]

[0000038725-17-000145:notes:84]
[same as prior period, unchanged from 0000038725-17-000089:notes:69]

[0000038725-17-000145:notes:85]
Total debt, including current maturities, have carrying amounts of $271.4 million and $190.2 million and estimated fair values of $276 million and $195 million as of June 30, 2017 and December 31, 2016, respectively.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-17-000145:notes:86]
[same as prior period, unchanged from 0000038725-17-000089:notes:71]

[0000038725-17-000145:notes:87]
[same as prior period, unchanged from 0000038725-17-000089:notes:72]

[0000038725-17-000145:notes:88]
| (In millions) |  | June 30, 2017 |  | December 31, 2016 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortized intangibles: |  |  |  |  |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.5 |  |  | $ | (6.6 | ) |  | $ | 7.4 |  |  | $ | (6.4 | ) |
| Technology |  | 7.5 |  |  | (5.6 | ) |  | 7.5 |  |  | (5.3 | ) |
| Customer relationships |  | 140.0 |  |  | (53.8 | ) |  | 133.4 |  |  | (49.6 | ) |
| Other |  | 3.1 |  |  | (2.5 | ) |  | 2.7 |  |  | (2.1 | ) |
| Total |  | $ | 158.1 |  |  | $ | (68.5 | ) |  | $ | 151.0 |  |  | $ | (63.4 | ) |
| Unamortized intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 47.2 |  |  | — |  |  | 47.1 |  |  | — |  |
| Total intangibles |  | $ | 205.3 |  |  | $ | (68.5 | ) |  | $ | 198.1 |  |  | $ | (63.4 | ) |

[0000038725-17-000145:notes:89]
Amortization expense related to intangible assets for the second quarters ended June 30, 2017 and July 2, 2016 was $2.2 million and $2.1 million, respectively and $4.3 million and $4.1 million for the six months ended June 30, 2017 and July 2, 2016, respectively.

[0000038725-17-000145:notes:90]
[same as prior period, unchanged from 0000038725-17-000089:notes:75]

[0000038725-17-000145:notes:91]
[same as prior period, unchanged from 0000038725-17-000089:notes:76]

[0000038725-17-000145:notes:92]
The change in the carrying amount of goodwill by reporting segment for the six months ended June 30, 2017, is as follows:

[0000038725-17-000145:notes:93]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2016 |  | $ | 136.3 |  |  | $ | 63.3 |  |  | $ | — |  |  | $ | 199.6 |  |
| Acquisitions |  | — |  |  | — |  |  | 34.4 |  |  | 34.4 |  |
| Foreign currency translation |  | 2.0 |  |  | 0.2 |  |  | — |  |  | 2.2 |  |
| Balance as of June 30, 2017 |  | $ | 138.3 |  |  | $ | 63.5 |  |  | $ | 34.4 |  |  | $ | 236.2 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-17-000145:notes:94]
[same as prior period, unchanged from 0000038725-17-000089:notes:79]

[0000038725-17-000145:notes:95]
The Company’s effective tax rate from continuing operations for the six month period ended June 30, 2017 was 13.4 percent as compared to 25.5 percent for the six month period ended July 2, 2016.  For the second quarters of 2017 and 2016 the effective tax rate was 18.6 percent and 24.8 percent, respectively.

[0000038725-17-000145:notes:96]
The effective tax rate continues to be lower than the U.S. statutory rate primarily due to the indefinite reinvestment of foreign earnings taxed at rates below the U.S. statutory rate as well as recognition of U.S. incentives and certain discrete events.  The Company has the ability to indefinitely reinvest these foreign earnings based on the earnings and cash projections of its other operations as well as cash on hand and available credit.

[0000038725-17-000145:notes:97]
During the second quarter ended June 30, 2017, the Company acquired controlling interests in three U.S. distributors (see Note 3 - Acquisitions).  These transactions created a discrete non-taxable gain recognized on the original minority equity investments resulting in a tax benefit of $1.8 million.  In addition, the Company's unrecognized tax benefits decreased $0.8 million for foreign tax liabilities due to statute expirations during the second quarter.

[0000038725-17-000145:notes:98]
During the first quarter ended March 31, 2017, the Company realized a loss on discrete intercompany loans that were long-term-investment in nature resulting in a permanent tax benefit of $1.7 million and the Company released a valuation allowance on deferred tax of $1.9 million in a foreign jurisdiction where a restructuring occurred.


## us-gaap:NewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000038725-17-000145:notes:99]
ACCOUNTING PRONOUNCEMENTS

[0000038725-17-000145:notes:100]
Accounting Standards Issued But Not Yet Adopted

[0000038725-17-000145:notes:101]
In March 2017, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2017-07, Compensation - Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost.  This ASU requires entities to present only the service cost component of net periodic benefit cost as an operating expense (consistent with the presentation of other employee compensation costs).  The other components of net periodic benefit cost are to be presented as a non-operating expense.  The ASU is effective on a retrospective basis for interim and annual periods beginning after December 15, 2017.  Early adoption is permitted as of the beginning of any annual period for which an entity's financial statements have not been issued or made available for issuance.  The Company plans to adopt the ASU in the first quarter ended March 31, 2018 and does not expect the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-17-000145:notes:102]
In January 2017, the FASB issued ASU 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.  ASU 2017-04 removes step two from the goodwill impairment test and instead requires an entity to recognize a goodwill impairment charge for the amount by which the goodwill carrying amount exceeds the reporting unit's fair value.  The ASU is effective on a prospective basis for interim and annual periods beginning after December 15, 2019 with early adoption permitted.   The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-17-000145:notes:103]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842), which supersedes existing guidance on accounting for leases found in Accounting Standards Codification ("ASC") Topic 840.  This ASU requires lessees to present right-of-use assets and lease liabilities on the balance sheet for all leases with terms longer than 12 months.  The guidance is to be applied using a modified retrospective approach at the beginning of the earliest comparative period in the financial statements and is effective for interim and annual periods beginning after December 15, 2018 with early adoption permitted.  The Company has begun the evaluation process for the adoption of the ASU, and anticipates that the majority of the Company’s outstanding operating leases would be recognized as right-of-use assets and lease liabilities upon adoption, resulting in a significant impact to the Company’s consolidated balance sheets. The impact of this ASU is non-cash in nature and will not affect the Company’s cash position.  The impact to the Company’s results of operations is still being evaluated.

[0000038725-17-000145:notes:104]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606).  ASU 2014-09 outlines a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes current revenue recognition guidance.  This ASU is effective for interim and annual reporting periods beginning after December 15, 2017.  Entities have the option of using either a full retrospective or a modified retrospective approach to adopt this standard.  The Company will adopt ASU 2014-09 beginning in the first quarter of 2018 using the modified retrospective approach.  The Company does expect to expand some disclosures in response to this ASU upon adoption; however, the Company does not expect the adoption of this ASU to have a material impact on the Company’s consolidated financial position, results of operations, or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-17-000145:notes:105]
[same as prior period, unchanged from 0000038725-17-000089:notes:89]

[0000038725-17-000145:notes:106]
The accompanying condensed consolidated balance sheet as of December 31, 2016, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 30, 2017, and for the second quarters and six months ended June 30, 2017 and July 2, 2016 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim period have been made.  Operating results for the second quarter and six months ended June 30, 2017 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2017.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2016.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-17-000145:notes:107]
[same as prior period, unchanged from 0000038725-17-000089:notes:91]

[0000038725-17-000145:notes:108]
Defined Benefit Plans - As of June 30, 2017, the Company maintained two domestic pension plans and three German pension plans.  The Company used a December 31, 2016 measurement date for these plans.  One of the Company's domestic pension plans covers one active management employee, while the other domestic plan covers all other eligible employees (plan was frozen as of December 31, 2011).  The two domestic and three German plans collectively comprise the 'Pension Benefits' disclosure caption.

[0000038725-17-000145:notes:109]
Other Benefits - The Company's other post-retirement benefit plan provides health and life insurance to domestic employees hired prior to 1992.

[0000038725-17-000145:notes:110]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the second quarters and six months ended June 30, 2017 and July 2, 2016:

[0000038725-17-000145:notes:111]
| (In millions) | Pension Benefits |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2017 |  | July 2, 2016 |  | June 30, 2017 |  | July 2, 2016 |
| Service cost | $ | 0.2 |  |  | $ | 0.3 |  |  | $ | 0.3 |  |  | $ | 0.5 |  |
| Interest cost | 1.5 |  |  | 1.6 |  |  | 2.9 |  |  | 3.1 |  |
| Expected return on assets | (2.3 | ) |  | (2.4 | ) |  | (4.5 | ) |  | (4.7 | ) |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | 0.7 |  |  | 0.7 |  |  | 1.3 |  |  | 1.3 |  |
| Settlement cost | — |  |  | 0.3 |  |  | — |  |  | 0.6 |  |
| Net periodic benefit cost | $ | 0.1 |  |  | $ | 0.5 |  |  | $ | — |  |  | $ | 0.8 |  |

[0000038725-17-000145:notes:112]
In the six months ended June 30, 2017, the Company made contributions of $2.2 million to the funded plans.   The amount of contributions to be made to the plans during the calendar year 2017 will be finalized by September 15, 2017, based upon the funding level requirements identified and year-end valuation performed at December 31, 2016.

[0000038725-17-000145:notes:113]
The following table sets forth the aggregated net periodic benefit cost for the post-retirement benefit plan for the second quarters and six months ended June 30, 2017 and July 2, 2016:

[0000038725-17-000145:notes:114]
| (In millions) | Other Benefits |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2017 |  | July 2, 2016 |  | June 30, 2017 |  | July 2, 2016 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.2 |  |
| Expected return on assets | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | 0.1 |  |  | 0.1 |  |  | 0.2 |  |  | 0.2 |  |
| Actuarial loss | — |  |  | — |  |  | — |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.2 |  |  | $ | 0.2 |  |  | $ | 0.4 |  |  | $ | 0.4 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000038725-17-000145:notes:115]
[same as prior period, unchanged from 0000038725-17-000089:notes:97]

[0000038725-17-000145:notes:116]
|  | Second Quarter Ended |  | Six Months Ended |
| (In millions) | June 30, 2017 |  | July 2, 2016 |  | June 30, 2017 |  | July 2, 2016 |
|  | Net sales |
| Water Systems |  |  |  |  |  |  |  |
| External sales | $ | 185.8 |  |  | $ | 194.6 |  |  | $ | 353.0 |  |  | $ | 363.4 |  |
| Intersegment sales | 17.6 |  |  | — |  |  | 17.6 |  |  | — |  |
| Total sales | 203.4 |  |  | 194.6 |  |  | 370.6 |  |  | 363.4 |  |
| Distribution |  |  |  |  |  |  |  |
| External sales | 59.1 |  |  | — |  |  | 59.1 |  |  | — |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 59.1 |  |  | — |  |  | 59.1 |  |  | — |  |
| Fueling Systems |  |  |  |  |  |  |  |
| External sales | 60.4 |  |  | 57.5 |  |  | 113.5 |  |  | 107.1 |  |
| Intersegment sales | 1.0 |  |  | — |  |  | 1.0 |  |  | — |  |
| Total sales | 61.4 |  |  | 57.5 |  |  | 114.5 |  |  | 107.1 |  |
| Intersegment Eliminations/Other | (18.6 | ) |  | — |  |  | (18.6 | ) |  | — |  |
| Consolidated | $ | 305.3 |  |  | $ | 252.1 |  |  | $ | 525.6 |  |  | $ | 470.5 |  |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2017 |  | July 2, 2016 |  | June 30, 2017 |  | July 2, 2016 |
|  | Operating income/(loss) |
| Water Systems | $ | 32.8 |  |  | $ | 31.5 |  |  | $ | 54.2 |  |  | $ | 55.6 |  |
| Distribution | 3.7 |  |  | — |  |  | 3.7 |  |  | — |  |
| Fueling Systems | 14.9 |  |  | 15.5 |  |  | 25.8 |  |  | 25.8 |  |
| Intersegment Eliminations/Other | (17.2 | ) |  | (14.3 | ) |  | (31.0 | ) |  | (27.6 | ) |
| Consolidated | $ | 34.2 |  |  | $ | 32.7 |  |  | $ | 52.7 |  |  | $ | 53.8 |  |

[0000038725-17-000145:notes:117]
|  | June 30, 2017 |  | December 31, 2016 |  |  |  |  |
|  | Total assets |  |  |  |  |
| Water Systems | $ | 685.4 |  |  | $ | 671.5 |  |  |  |  |  |
| Distribution | 161.8 |  |  | — |  |  |  |  |  |
| Fueling Systems | 262.4 |  |  | 251.1 |  |  |  |  |  |
| Other | 70.5 |  |  | 117.3 |  |  |  |  |  |
| Consolidated | $ | 1,180.1 |  |  | $ | 1,039.9 |  |  |  |  |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0000038725-17-000145:notes:118]
The schedule below sets forth equity changes in the six months ended June 30, 2017:

[0000038725-17-000145:notes:119]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2016 | $ | 4,638 |  |  | $ | 228,564 |  |  | $ | 550,095 |  |  | $ | (51,568 | ) |  | $ | (118,284 | ) |  | $ | 1,643 |  |  | $ | 615,088 |  |  | $ | 7,652 |  |
| Net income |  |  |  |  | 45,639 |  |  |  |  |  |  | 374 |  |  | 46,013 |  |  | 165 |  |
| Adjustment to Impo redemption value |  |  |  |  | 27 |  |  |  |  |  |  |  |  | 27 |  |  | (27 | ) |
| Dividends on common stock |  |  |  |  | (9,695 | ) |  |  |  |  |  |  |  | (9,695 | ) |  |  |
| Common stock issued | 9 |  |  | 2,038 |  |  |  |  |  |  |  |  |  |  | 2,047 |  |  |  |
| Common stock repurchased | (6 | ) |  |  |  | (2,368 | ) |  |  |  |  |  |  |  | (2,374 | ) |  |  |
| Share-based compensation | 7 |  |  | 4,539 |  |  |  |  |  |  |  |  |  |  | 4,546 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | (504 | ) |  | (504 | ) |  |  |
| Purchase of redeemable noncontrolling shares |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (5,047 | ) |
| Currency translation adjustment |  |  |  |  |  |  |  |  | 15,196 |  |  | 103 |  |  | 15,299 |  |  | (795 | ) |
| Pension liability, net of tax |  |  |  |  |  |  | 986 |  |  |  |  |  |  | 986 |  |  |  |
| Balance as of June 30, 2017 | $ | 4,648 |  |  | $ | 235,141 |  |  | $ | 583,698 |  |  | $ | (50,582 | ) |  | $ | (103,088 | ) |  | $ | 1,616 |  |  | $ | 671,433 |  |  | $ | 1,948 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-17-000145:notes:120]
[same as prior period, unchanged from 0000038725-17-000089:notes:101]

[0000038725-17-000145:notes:121]
The accounting policies of the operating segments are the same as those described in Note 1 of the Company's Form 10-K.  During the second quarter of 2017, as a result of recent acquisitions, the Company revised its reportable segments to now include a Distribution segment.  The Water and Fueling segments include manufacturing operations and supply certain components and finished goods, both between segments and to the Distribution segment.  The Company accounts for intersegment revenue transactions consistent with independent third party transactions, that is, at current market prices.  Operating income by segment is based on net sales less identifiable operating expenses and allocations and includes profits recorded on sales to other segments of the Company.

[0000038725-17-000145:notes:122]
Property, plant, and equipment is the major asset group in "Other" of total assets at June 30, 2017.  Cash is the major asset group in "Other" of total assets at December 31, 2016.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-17-000145:notes:123]
[same as prior period, unchanged from 0000038725-17-000089:notes:103]
