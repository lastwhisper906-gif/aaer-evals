# FELE 8-K — 0000038725-17-000141 filed 2017-07-25

## item codes, every 8-K on or before 2017-08-01

- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2017-08-01

- none on or before 2017-08-01

## item 2.02 — earnings release, exhibit 99.1

[0000038725-17-000141:8k_2_02:1]
EX-99.1
2
a201707258-kexhibit991.htm
EXHIBIT 99.1

[0000038725-17-000141:8k_2_02:2]
Exhibit

[0000038725-17-000141:8k_2_02:3]
Exhibit 99.1

[0000038725-17-000141:8k_2_02:4]
For Immediate Release

[0000038725-17-000141:8k_2_02:5]
For Further Information

[0000038725-17-000141:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-17-000141:8k_2_02:7]
260-824-2900

[0000038725-17-000141:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS SECOND QUARTER

[0000038725-17-000141:8k_2_02:9]
2017 SALES AND EARNINGS

[0000038725-17-000141:8k_2_02:10]
Fort Wayne, IN - July 25, 2017 - Franklin Electric Co., Inc. (NASDAQ: FELE) reported second quarter 2017 GAAP fully diluted earnings per share (EPS) of $0.64, versus a GAAP fully diluted EPS in the second quarter 2016 of $0.50, an increase of 28 percent.  Second quarter 2017 sales were $305.3 million, an increase of 21 percent compared to 2016 second quarter sales of $252.1 million.

[0000038725-17-000141:8k_2_02:11]
Gregg Sengstack, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-17-000141:8k_2_02:12]
“We’re pleased with the overall performance of our Company in the second quarter in which we achieved solid organic sales growth in both our Water and Fueling Systems segments, led by a 10 percent Water Systems sales growth in the United States and Canada. The Distribution companies that we acquired in the quarter, reported in a new segment, started off with a strong second quarter achieving higher than expected operating income margins and exceeding our earnings expectation.  Although our reported earnings per share of $0.64 were a record for any second quarter in our history, about six cents of this amount was related to a one-time gain.  We are optimistic about the second half of 2017 and are raising our full year 2017 earnings per share guidance range to $1.87 to $1.97.”

[0000038725-17-000141:8k_2_02:13]
Key Performance Indicators:

[0000038725-17-000141:8k_2_02:14]
|  | Net Sales |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q2 2016 | $ | 96.0 |  | $ | 31.2 |  | $ | 43.7 |  | $ | 23.7 |  | $ | 194.6 |  | $ | 57.5 |  | $ | — |  | $ | — |  | $ | 252.1 |  |
| Q2 2017 | $ | 105.4 |  | $ | 31.3 |  | $ | 45.1 |  | $ | 21.6 |  | $ | 203.4 |  | $ | 61.4 |  | $ | 59.1 |  | $ | (18.6 | ) | $ | 305.3 |  |
| Change | $ | 9.4 |  | $ | 0.1 |  | $ | 1.4 |  | $ | (2.1 | ) | $ | 8.8 |  | $ | 3.9 |  | $ | 59.1 |  | $ | (18.6 | ) | $ | 53.2 |  |
| % Change | 10 | % | — | % | 3 | % | (9 | )% | 5 | % | 7 | % |  |  |  |  | 21 | % |
| Foreign currency translation | $ | (0.8 | ) | $ | 1.3 |  | $ | (2.3 | ) | $ | — |  | $ | (1.8 | ) | $ | (0.7 | ) |  |  |  |
| % Change | (1 | )% | 4 | % | (5 | )% | — | % | (1 | )% | (1 | )% |  |  |  |
| Volume/Price | $ | 10.2 |  | $ | (1.2 | ) | $ | 3.7 |  | $ | (2.1 | ) | $ | 10.6 |  | $ | 4.6 |  |  |  |  |
| % Change | 11 | % | (4 | )% | 8 | % | (9 | )% | 6 | % | 8 | % |  |  |  |

[0000038725-17-000141:8k_2_02:15]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Second Quarter 2017 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Reported Operating Income/(Loss) | $ | 32.8 |  | $ | 14.9 |  | $ | 3.7 |  | $ | (17.2 | ) | $ | 34.2 |  |
| % Operating Income To Net Sales | 16.1 | % | 24.3 | % | 6.3 | % |  | 11.2 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Second Quarter 2016 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Reported Operating Income/(Loss) | $ | 31.5 |  | $ | 15.5 |  | $ | — |  | $ | (14.3 | ) | $ | 32.7 |  |
| % Operating Income To Net Sales | 16.2 | % | 27.0 | % |  |  | 13.0 | % |

[0000038725-17-000141:8k_2_02:16]
Water Systems

[0000038725-17-000141:8k_2_02:17]
Water Systems sales were $203.4 million in the second quarter 2017, an increase of $8.8 million or about 5 percent versus the second quarter 2016 sales of $194.6 million.  Water Systems sales decreased by $1.8 million or about 1 percent in the quarter due to foreign currency translation. Water Systems organic sales were up about 6 percent compared to the second quarter 2016.

[0000038725-17-000141:8k_2_02:18]
Water Systems sales in the U.S. and Canada were up about 10 percent compared to the prior year second quarter.   Sales of dewatering equipment increased by 25 percent in the second quarter when compared to the prior year resulting from the continued diversification of customers and new channel development for Pioneer branded equipment.  Sales of other surface pumping equipment increased by 8 percent in part due to wet weather conditions in the upper Midwest and Canada.  Sales of groundwater pumping equipment increased about 5 percent.

[0000038725-17-000141:8k_2_02:19]
Water Systems sales in markets outside the U.S. and Canada overall declined by about 1 percent, due primarily to the impact of foreign currency translation.  International Water Systems sales were led by improved sales in Europe, the Middle East and

[0000038725-17-000141:8k_2_02:20]
Africa, but were offset by lower sales volumes in the Latin American and Asia Pacific markets in the quarter compared to last year.

[0000038725-17-000141:8k_2_02:21]
Water Systems operating income was $32.8 million in the second quarter 2017, up $1.3 million or 4 percent versus the second quarter 2016 and operating income margin was 16.1 percent compared to the 16.2 percent in the second quarter 2016.

[0000038725-17-000141:8k_2_02:22]
Fueling Systems

[0000038725-17-000141:8k_2_02:23]
Fueling Systems sales were $61.4 million in the second quarter 2017, an increase of $3.9 million or about 7 percent versus the second quarter 2016 sales of $57.5 million.  Fueling Systems sales decreased by $0.7 million or about 1 percent in the quarter due to foreign currency translation. Fueling Systems organic sales increased about 8 percent compared to the second quarter of 2016.

[0000038725-17-000141:8k_2_02:24]
Fueling Systems sales in the U.S. and Canada grew by about 4 percent during the quarter.  The increase was primarily in pumping systems.  Outside of the U.S. and Canada, Fueling Systems revenues grew by about 18 percent, led by stronger sales in Europe, Africa and Asia.

[0000038725-17-000141:8k_2_02:25]
Fueling Systems operating income was $14.9 million in the second quarter of 2017, down $0.6 million or about 4 percent compared to $15.5 million in the second quarter of 2016 and the second quarter operating income margin was 24.3 percent, a decrease of 270 basis points from the 27.0 percent of net sales in the second quarter of 2016.  The decline in operating income was primarily due to adverse product and geography sales mix shifts.

[0000038725-17-000141:8k_2_02:26]
Distribution

[0000038725-17-000141:8k_2_02:27]
Distribution sales were $59.1 million in the second quarter 2017.  Based on the information provided for second quarter 2016 sales, management estimates second quarter Distribution sales declined by about 2 percent from the second quarter of 2016 primarily driven by adverse weather conditions in the Western portion of the United States.

[0000038725-17-000141:8k_2_02:28]
Distribution operating income was $3.7 million in the second quarter of 2017 and the second quarter operating income margin was 6.3 percent.

[0000038725-17-000141:8k_2_02:29]
Overall

[0000038725-17-000141:8k_2_02:30]
The Company’s consolidated gross profit was $102.8 million for the second quarter of 2017, an increase of $12.1 million, or about 13 percent, from the second quarter of 2016 gross profit of $90.7 million. The gross profit as a percent of net sales was 33.7 percent in the second quarter of 2017 and decreased about 230 basis points versus 36.0 percent during the second quarter 2016.  The gross profit increase was primarily due to higher sales.  The decline in gross profit margin percentage is primarily due to the lower gross profit margin of the Distribution segment.  Excluding the Distribution segment, gross profit margin was 34.5 percent.

[0000038725-17-000141:8k_2_02:31]
Selling, general, and administrative (SG&A) expenses were $68.3 million in the second quarter of 2017 compared to $58.0 million in the second quarter of the prior year, an increase of $10.3 million or about 18 percent.  The increase in SG&A expenses from acquired businesses were $13.0 million.  Excluding the acquired entities, the Company’s SG&A expenses in the second quarter of 2017 decreased by $2.7 million or about 5 percent.

[0000038725-17-000141:8k_2_02:32]
The Company’s second quarter 2017 earnings include a gain on the previously held equity investments in the three Distribution entities as indicated in the announcement made on April 10, 2017 regarding the acquisition of the controlling interests of these entities.  This gain, included in “Other Income” in the Company’s Income Statement, represents about $4.8 million of pre-tax earnings or $0.06 of earnings per share.

[0000038725-17-000141:8k_2_02:33]
The Company ended the second quarter of 2017 with a cash balance of about $55 million versus about $104 million at the end of 2016, down primarily due to acquisitions and increased working capital needs.  Inventory levels at the end of the second quarter 2017 were $297 million versus year end 2016 of $203 million. About $60 million of the inventory increase is due to the Distribution segment acquisitions.

[0000038725-17-000141:8k_2_02:34]
Commenting on the outlook, Mr. Sengstack said:

[0000038725-17-000141:8k_2_02:35]
“As we look forward to the back half of 2017, we are encouraged by the start we’ve had in our new Distribution segment and the strength of our Water Systems businesses in North America.  However, we remain mindful of continued weakness in many of the international Water Systems end markets that we serve.  We expect our Fueling Systems segment to have a strong top and bottom line in the second half.  As a result of this outlook for the rest of the year, and the six-cent gain that was taken on the Distribution segment minority investments in the second quarter, we are increasing our full year 2017 earnings per share guidance from a range of $1.77 to $1.87 to a range of $1.87 to $1.97.”

[0000038725-17-000141:8k_2_02:36]
A conference call to review earnings and other developments in the business will commence at 9:00 am EDT.  The second quarter 2017 earnings call will be available via a live webcast.  The webcast will be available in a listen only mode by going to:

[0000038725-17-000141:8k_2_02:37]
http://edge.media-server.com/m/p/wpkekoqj

[0000038725-17-000141:8k_2_02:38]
If you intend to ask questions during the call, please dial in using 877.643.7158 for domestic calls and 914.495.8565 for international calls.  The conference ID is: 50852283.

[0000038725-17-000141:8k_2_02:39]
A replay of the conference call will be available Tuesday, July 25, 2017 at 12:00 noon EDT through noon EDT on Tuesday, August 1, 2017, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls.  The replay passcode is: 50852283.

[0000038725-17-000141:8k_2_02:40]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-17-000141:8k_2_02:41]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2017 |  |  | July 2, 2016 |  | June 30, 2017 |  | July 2, 2016 |
| Net sales | $ | 305,349 |  |  | $ | 252,081 |  |  | $ | 525,601 |  |  | $ | 470,511 |  |
| Cost of sales | 202,596 |  |  | 161,403 |  |  | 347,032 |  |  | 305,597 |  |
| Gross profit | 102,753 |  |  | 90,678 |  |  | 178,569 |  |  | 164,914 |  |
| Selling, general, and administrative expenses | 68,298 |  |  | 57,954 |  |  | 125,289 |  |  | 110,299 |  |
| Restructuring expense | 251 |  |  | 45 |  |  | 566 |  |  | 865 |  |
| Operating income | 34,204 |  |  | 32,679 |  |  | 52,714 |  |  | 53,750 |  |
| Interest expense | (2,244 | ) |  | (2,221 | ) |  | (5,758 | ) |  | (4,648 | ) |
| Other income, net | 5,573 |  |  | 1,373 |  |  | 6,240 |  |  | 1,341 |  |
| Foreign exchange income/(expense) | (372 | ) |  | 315 |  |  | 103 |  |  | 238 |  |
| Income before income taxes | 37,161 |  |  | 32,146 |  |  | 53,299 |  |  | 50,681 |  |
| Income tax expense | 6,917 |  |  | 7,959 |  |  | 7,121 |  |  | 12,914 |  |
| Net income | $ | 30,244 |  |  | $ | 24,187 |  |  | $ | 46,178 |  |  | $ | 37,767 |  |
| Less: Net income attributable to noncontrolling interests | (335 | ) |  | (205 | ) |  | (539 | ) |  | (328 | ) |
| Net income attributable to Franklin Electric Co., Inc. | $ | 29,909 |  |  | $ | 23,982 |  |  | $ | 45,639 |  |  | $ | 37,439 |  |
| Income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.64 |  |  | $ | 0.51 |  |  | $ | 0.97 |  |  | $ | 0.79 |  |
| Diluted | $ | 0.64 |  |  | $ | 0.50 |  |  | $ | 0.97 |  |  | $ | 0.78 |  |

[0000038725-17-000141:8k_2_02:42]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | June 30, 2017 |  | December 31, 2016 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 55,095 |  |  | $ | 104,331 |  |
| Receivables | 190,650 |  |  | 145,999 |  |
| Inventories | 296,687 |  |  | 203,471 |  |
| Other current assets | 37,194 |  |  | 30,018 |  |
| Total current assets | 579,626 |  |  | 483,819 |  |
| Property, plant, and equipment, net | 214,652 |  |  | 196,137 |  |
| Goodwill and other assets | 385,832 |  |  | 359,949 |  |
| Total assets | $ | 1,180,110 |  |  | $ | 1,039,905 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 73,266 |  |  | $ | 63,927 |  |
| Accrued expenses and other current liabilities | 60,870 |  |  | 60,119 |  |
| Current maturities of long-term debt and short-term borrowings | 145,381 |  |  | 33,715 |  |
| Total current liabilities | 279,517 |  |  | 157,761 |  |
| Long-term debt | 126,030 |  |  | 156,544 |  |
| Deferred income taxes | 40,842 |  |  | 40,460 |  |
| Employee benefit plans | 42,705 |  |  | 45,307 |  |
| Other long-term liabilities | 17,635 |  |  | 17,093 |  |
| Redeemable noncontrolling interest | 1,948 |  |  | 7,652 |  |
| Total equity | 671,433 |  |  | 615,088 |  |
| Total liabilities and equity | $ | 1,180,110 |  |  | $ | 1,039,905 |  |

[0000038725-17-000141:8k_2_02:43]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Six Months Ended |
| (In thousands) | June 30, 2017 |  | July 2, 2016 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 46,178 |  |  | $ | 37,767 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 18,412 |  |  | 17,633 |  |
| Share-based compensation | 4,546 |  |  | 4,155 |  |
| Gain on equity investment | (4,788 | ) |  | — |  |
| Other | (3,286 | ) |  | 4,404 |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (9,289 | ) |  | (31,221 | ) |
| Inventory | (31,792 | ) |  | (10,982 | ) |
| Accounts payable and accrued expenses | (24,712 | ) |  | 3,091 |  |
| Other | (7,774 | ) |  | 4,464 |  |
| Net cash flows from operating activities | (12,505 | ) |  | 29,311 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (18,621 | ) |  | (19,490 | ) |
| Proceeds from sale of property, plant, and equipment | 109 |  |  | 2,166 |  |
| Acquisitions and investments | (52,255 | ) |  | — |  |
| Other investing activities | 153 |  |  | 178 |  |
| Net cash flows from investing activities | (70,614 | ) |  | (17,146 | ) |
| Cash flows from financing activities: |  |  |  |
| Change in debt | 47,196 |  |  | (7,851 | ) |
| Proceeds from issuance of common stock | 2,047 |  |  | 610 |  |
| Purchases of common stock | (2,374 | ) |  | (4,736 | ) |
| Dividends paid | (10,199 | ) |  | (9,821 | ) |
| Purchase of redeemable non-controlling shares | (5,047 | ) |  | — |  |
| Net cash flows from financing activities | 31,623 |  |  | (21,798 | ) |
| Effect of exchange rate changes on cash | 2,260 |  |  | (346 | ) |
| Net change in cash and equivalents | (49,236 | ) |  | (9,979 | ) |
| Cash and equivalents at beginning of period | 104,331 |  |  | 81,561 |  |
| Cash and equivalents at end of period | $ | 55,095 |  |  | $ | 71,582 |  |
