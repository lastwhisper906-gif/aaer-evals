# FELE note change history — 0000038725-23-000182 → 0000038725-24-000078


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-04-30):
[0000038725-24-000078:note_history:1]
At March 31, 2024, the Company had $9.5 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production and finished goods.
  (was, 2023-10-27, similarity 0.9073):
[0000038725-23-000182:note_history:1]
At September 30, 2023, the Company had $9.6 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

- added (2024-04-30):
[0000038725-24-000078:note_history:2]
At March 31, 2024, the Company has a contingent consideration liability with an estimated fair value of $4.5 million that could result in a payment up to $5.0 million if a future profitability milestone is achieved.

- changed (2024-04-30):
[0000038725-24-000078:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the three months ended March 31, 2024, are as follows:
  (was, 2023-10-27, similarity 0.894):
[0000038725-23-000182:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 30, 2023, are as follows:

- changed (2024-04-30):
[0000038725-24-000078:note_history:4]
| (In millions) |  |  |
| Balance as of December 31, 2023 |  | $ | 9.3 |  |
| Accruals related to product warranties |  | 2.7 |  |
| Reductions for payments made |  | (3.1) |  |
| Balance as of March 31, 2024 |  | $ | 8.9 |  |
  (was, 2023-10-27, similarity 0.965):
[0000038725-23-000182:note_history:4]
| (In millions) |  |  |
| Balance as of December 31, 2022 |  | $ | 11.2 |  |
| Accruals related to product warranties |  | 9.4 |  |
| Reductions for payments made |  | (10.3) |  |
| Balance as of September 30, 2023 |  | $ | 10.3 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-04-30):
[0000038725-24-000078:note_history:5]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2023, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2024, and for the first quarters ended March 31, 2024 and March 31, 2023 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the first quarter ended March 31, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2024. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2023.
  (was, 2023-10-27, similarity 0.9363):
[0000038725-23-000182:note_history:5]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2022, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 30, 2023, and for the third quarters and nine months ended September 30, 2023 and September 30, 2022 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the third quarter and nine months ended September 30, 2023 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2023. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2022.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-04-30):
[0000038725-24-000078:note_history:6]
| (In millions) |  | March 31, 2024 |  | December 31, 2023 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 23.0 |  |  | 11.0 |  |
| Tax increment financing debt |  | 13.5 |  |  | 14.1 |  |
| Foreign subsidiary debt |  | 0.4 |  |  | 0.5 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 111.8 |  |  | $ | 100.5 |  |
| Less: current maturities |  | (24.4) |  |  | (12.4) |  |
| Long-term debt |  | $ | 87.4 |  |  | $ | 88.1 |  |
  (was, 2023-10-27, similarity 0.9831):
[0000038725-23-000182:note_history:6]
| (In millions) |  | September 30, 2023 |  | December 31, 2022 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 39.0 |  |  | 122.8 |  |
| Tax increment financing debt |  | 14.1 |  |  | 15.3 |  |
| Foreign subsidiary debt |  | 0.4 |  |  | 3.1 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 128.4 |  |  | $ | 216.1 |  |
| Less: current maturities |  | (40.4) |  |  | (126.8) |  |
| Long-term debt |  | $ | 88.0 |  |  | $ | 89.3 |  |

- changed (2024-04-30):
[0000038725-24-000078:note_history:7]
As of March 31, 2024, the Company had $23.0 million outstanding borrowings with a weighted-average interest rate of 6.3 percent, $3.5 million in letters of credit outstanding, and $323.5 million of available capacity under its credit agreement. As of December 31, 2023, the Company had $11.0 million outstanding borrowings with a weighted-average interest rate of 6.3 percent, $3.6 million in letters of credit outstanding, and $335.4 million of available capacity under its credit agreement.
  (was, 2023-10-27, similarity 0.9848):
[0000038725-23-000182:note_history:7]
As of September 30, 2023, the Company had $39.0 million outstanding borrowings with a weighted-average interest rate of 6.3 percent, $3.6 million in letters of credit outstanding, and $307.4 million of available capacity under its credit agreement. As of December 31, 2022, the Company had $122.8 million outstanding borrowings with a weighted-average interest rate of 5.0 percent, $4.0 million in letters of credit outstanding, and $223.2 million of available capacity under its credit agreement.

- changed (2024-04-30):
[0000038725-24-000078:note_history:8]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $17.4 million. As of March 31, 2024, there were no outstanding borrowings and $17.4 million of available capacity under these lines of credit. As of December 31, 2023, there were $17.9 million overdraft lines of credit with no outstanding borrowings and $17.9 million of available capacity under these lines of credit.
  (was, 2023-10-27, similarity 0.9123):
[0000038725-23-000182:note_history:8]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $18.1 million. As of September 30, 2023, there were no outstanding borrowings and $18.1 million of available capacity under these lines of credit. As of December 31, 2022, there were $22.0 million overdraft lines of credit with $2.7 million of outstanding borrowings and $19.3 million of available capacity under these lines of credit.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-04-30):
[0000038725-24-000078:note_history:9]
| (In millions) |  | March 31, 2024 |  | December 31, 2023 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 23.0 |  |  | 11.0 |  |
| Tax increment financing debt |  | 13.5 |  |  | 14.1 |  |
| Foreign subsidiary debt |  | 0.4 |  |  | 0.5 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 111.8 |  |  | $ | 100.5 |  |
| Less: current maturities |  | (24.4) |  |  | (12.4) |  |
| Long-term debt |  | $ | 87.4 |  |  | $ | 88.1 |  |
  (was, 2023-10-27, similarity 0.9831):
[0000038725-23-000182:note_history:9]
| (In millions) |  | September 30, 2023 |  | December 31, 2022 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 39.0 |  |  | 122.8 |  |
| Tax increment financing debt |  | 14.1 |  |  | 15.3 |  |
| Foreign subsidiary debt |  | 0.4 |  |  | 3.1 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 128.4 |  |  | $ | 216.1 |  |
| Less: current maturities |  | (40.4) |  |  | (126.8) |  |
| Long-term debt |  | $ | 88.0 |  |  | $ | 89.3 |  |
