# FELE MD&A — 0000038725-24-000078


## mdna

[0000038725-24-000078:mdna:1]
[same as prior period, unchanged from 0000038725-23-000182:mdna:1]

[0000038725-24-000078:mdna:2]
First Quarter 2024 vs. 2023

[0000038725-24-000078:mdna:3]
[same as prior period, unchanged from 0000038725-23-000182:mdna:3]

[0000038725-24-000078:mdna:4]
Net sales in the first quarter of 2024 decreased 5 percent from the first quarter of last year. The sales decrease was primarily due to lower sales in Water Systems and Fueling Systems, partially offset by higher sales in the Distribution segment. The Company's consolidated gross profit was $163.6 million for the first quarter of 2024, an increase of $1.3 million from the prior year’s first quarter. The gross profit as a percent of net sales was 35.5 percent in the first quarter of 2024 compared to 33.5 percent in the first quarter of 2023. Diluted earnings per share for the first quarter of 2024 was $0.70, a decrease of $0.09 from the first quarter of 2023 diluted earnings per share of $0.79.

[0000038725-24-000078:mdna:5]
[same as prior period, unchanged from 0000038725-23-000182:mdna:5]

[0000038725-24-000078:mdna:6]
[same as prior period, unchanged from 0000038725-23-000182:mdna:6]

[0000038725-24-000078:mdna:7]
Net sales in the first quarter of 2024 were $460.9 million, a decrease of $23.7 million or 5 percent compared to 2023 first quarter sales of $484.6 million primarily due to lower volumes in Water Systems and Fueling Systems. Sales were negatively impacted by changes in foreign exchange rates, principally due to the strengthening of the U.S. Dollar relative to the Argentine Peso and Turkish Lira. However, the Company increases prices in the local currency to offset the impact of currency devaluation in the Argentina and Turkey hyperinflationary economies.  As a result, the net impact of foreign currency exchange rates on net sales was not significant in the first quarter of 2024 compared to the same period in the prior year.

[0000038725-24-000078:mdna:8]
|  | Net Sales |
| (In millions) | Q1 2024 |  | Q1 2023 |  | 2024 v 2023 |
| Water Systems | $ | 286.6 |  |  | $ | 306.6 |  |  | $ | (20.0) |  |
| Fueling Systems | 62.1 |  |  | 72.7 |  |  | (10.6) |  |
| Distribution | 147.0 |  |  | 143.0 |  |  | 4.0 |  |
| Eliminations/Other | (34.8) |  |  | (37.7) |  |  | 2.9 |  |
| Consolidated | $ | 460.9 |  |  | $ | 484.6 |  |  | $ | (23.7) |  |

[0000038725-24-000078:mdna:9]
[same as prior period, unchanged from 0000038725-23-000182:mdna:10]

[0000038725-24-000078:mdna:10]
Water Systems sales were $286.6 million in the first quarter of 2024, a decrease of $20.0 million or 7 percent compared to the first quarter of 2023 sales of $306.6 million. The sales decline was primarily due to lower volume, partially offset by the incremental sales impact from recent acquisitions.

[0000038725-24-000078:mdna:11]
Water Systems sales in the U.S. and Canada decreased 12 percent compared to the first quarter of 2023.  Sales of large dewatering equipment and groundwater pumping equipment decreased 50 percent and 8 percent, respectively.  These sales declines were partially offset by the incremental sales impact from recent acquisitions in the Water Treatment product portfolio.

[0000038725-24-000078:mdna:12]
Water Systems sales in markets outside the U.S. and Canada increased 4 percent compared to the first quarter of 2023 as sales increased in all major markets: Latin America, EMEA, and Asia Pacific.

[0000038725-24-000078:mdna:13]
[same as prior period, unchanged from 0000038725-23-000182:mdna:14]

[0000038725-24-000078:mdna:14]
Fueling Systems sales were $62.1 million in the first quarter of 2024, a decrease of $10.6 million or 15 percent compared to the first quarter of 2023 sales of $72.7 million. The sales decline was primarily due to lower volume.

[0000038725-24-000078:mdna:15]
Fueling Systems sales in the U.S. and Canada decreased 11 percent compared to the first quarter of 2023 due to declines in sales across all major product lines as customer buying patterns have normalized after record first quarter sales in 2023. Outside the U.S. and Canada, Fueling Systems sales decreased 16 percent, due primarily to lower sales in Asia Pacific.

[0000038725-24-000078:mdna:16]
[same as prior period, unchanged from 0000038725-23-000182:mdna:17]

[0000038725-24-000078:mdna:17]
Distribution sales were $147.0 million in the first quarter of 2024, an increase of $4.0 million or 3 percent compared to the first quarter of 2023 sales of $143.0 million. The Distribution segment sales growth was primarily due to the incremental sales impact from a recent acquisition.

[0000038725-24-000078:mdna:18]
[same as prior period, unchanged from 0000038725-23-000182:mdna:19]

[0000038725-24-000078:mdna:19]
|  | Three Months Ended March 31, |
| (In Millions) | 2024 |  | % of Net Sales |  | 2023 |  | % of Net Sales |
| Gross Profit | $ | 163.6 |  |  | 35.5 | % |  | $ | 162.3 |  |  | 33.5 | % |
| Selling, General and Administrative Expense | 115.6 |  |  | 25.1 | % |  | 109.5 |  |  | 22.6 | % |

[0000038725-24-000078:mdna:20]
[same as prior period, unchanged from 0000038725-23-000182:mdna:22]

[0000038725-24-000078:mdna:21]
The gross profit margin ratio was 35.5 percent in 2024 and 33.5 percent in first quarter of 2023. The gross profit margin was favorably impacted in 2024 by product mix and lower freight costs in Water Systems and Fueling, partially offset by margin compression from unfavorable pricing of commodity-based products sold through the Distribution business.

[0000038725-24-000078:mdna:22]
[same as prior period, unchanged from 0000038725-23-000182:mdna:24]

[0000038725-24-000078:mdna:23]
SG&A expenses were $115.6 million in the first quarter of 2024 compared to $109.5 million in the first quarter of 2023. The increase was primarily due to the incremental expense impact from recent acquisitions and higher compensation costs. SG&A costs as a percent of net sales was 25.1 percent in the first quarter of 2024 and 22.6 percent in the first quarter of 2023.

[0000038725-24-000078:mdna:24]
[same as prior period, unchanged from 0000038725-23-000182:mdna:26]

[0000038725-24-000078:mdna:25]
There were no restructuring expenses in the first quarter of 2024 and $0.1 million in the first quarter of 2023.

[0000038725-24-000078:mdna:26]
[same as prior period, unchanged from 0000038725-23-000182:mdna:28]

[0000038725-24-000078:mdna:27]
Operating income was $47.9 million in the first quarter of 2024, a decrease of $4.7 million or 9 percent from $52.6 million in the first quarter of 2023.

[0000038725-24-000078:mdna:28]
|  |  | Operating income (loss) |
| (In millions) |  | Q1 2024 |  | Q1 2023 |  | 2024 v 2023 |
| Water Systems |  | $ | 47.1 |  |  | $ | 49.0 |  |  | $ | (1.9) |  |
| Fueling Systems |  | 18.8 |  |  | 20.8 |  |  | (2.0) |  |
| Distribution |  | 1.8 |  |  | 4.7 |  |  | (2.9) |  |
| Eliminations/Other |  | (19.8) |  |  | (21.9) |  |  | 2.1 |  |
| Consolidated |  | $ | 47.9 |  |  | $ | 52.6 |  |  | $ | (4.7) |  |

[0000038725-24-000078:mdna:29]
[same as prior period, unchanged from 0000038725-23-000182:mdna:32]

[0000038725-24-000078:mdna:30]
Water Systems operating income was $47.1 million in the first quarter of 2024, a decrease of $1.9 million compared to the first quarter of 2023. Operating income decreased in Water Systems primarily due to lower sales. The first quarter operating income margin was 16.4 percent, an increase of 40 basis points from 16.0 percent in the first quarter 2023. Operating income margin increased primarily due to favorable product mix shifts and lower freight costs.

[0000038725-24-000078:mdna:31]
[same as prior period, unchanged from 0000038725-23-000182:mdna:34]

[0000038725-24-000078:mdna:32]
Fueling Systems operating income was $18.8 million in the first quarter of 2024, a decrease of $2.0 million compared to the first quarter of 2023. Operating income decreased in Fueling Systems primarily due to lower sales. The first quarter operating income margin was 30.3 percent, an increase of 170 basis points from 28.6 percent in the first quarter of 2023. Operating income margin increased primarily due to price realization, overall cost management including lower freight costs and a favorable product sales mix shift.

[0000038725-24-000078:mdna:33]
[same as prior period, unchanged from 0000038725-23-000182:mdna:36]

[0000038725-24-000078:mdna:34]
Distribution operating income was $1.8 million in the first quarter of 2024, a decrease of $2.9 million compared to the first quarter of 2023. The first quarter operating income margin was 1.2 percent, a decrease of 210 basis points from 3.3 percent in the first quarter of 2023. Operating income and operating income margin decreased primarily due to unfavorable pricing of commodity-based products sold through the business.

[0000038725-24-000078:mdna:35]
[same as prior period, unchanged from 0000038725-23-000182:mdna:38]

[0000038725-24-000078:mdna:36]
Operating income-eliminations/other is composed primarily of intersegment sales and profit eliminations and unallocated general and administrative expenses. The intersegment profit elimination impact in the first quarter of 2024 compared to the first quarter of 2023 was favorable $1.6 million. The intersegment elimination of operating income effectively defers the

[0000038725-24-000078:mdna:37]
operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer. General and administrative expenses decreased $0.5 million compared to the prior year.

[0000038725-24-000078:mdna:38]
[same as prior period, unchanged from 0000038725-23-000182:mdna:40]

[0000038725-24-000078:mdna:39]
Interest expense was $1.4 million in the first quarter of 2024 and decreased $1.7 million from $3.1 million in the first quarter of 2023 primarily due to lower outstanding debt levels.

[0000038725-24-000078:mdna:40]
Other Income, Net

[0000038725-24-000078:mdna:41]
Other income was $0.7 million and $0.4 million in the first quarters of 2024 and 2023, respectively.

[0000038725-24-000078:mdna:42]
[same as prior period, unchanged from 0000038725-23-000182:mdna:44]

[0000038725-24-000078:mdna:43]
Foreign currency-based transactions produced an expense for the first quarter of 2024 of $4.9 million, primarily due to the Argentinian Peso relative to the U.S. dollar. The expense in 2023 was primarily due to transaction losses associated with the Argentine Peso and Mexican Peso relative to the U.S. dollar.  The Company reports the results of its subsidiaries in Argentina and Turkey using highly inflationary accounting, which requires that the functional currency of the entity be changed to the reporting currency of its parent.

[0000038725-24-000078:mdna:44]
[same as prior period, unchanged from 0000038725-23-000182:mdna:46]

[0000038725-24-000078:mdna:45]
The provision for income taxes in the first quarters of 2024 and 2023 was $9.2 million and $10.2 million, respectively. The effective tax rate for the first quarters of 2024 and 2023 was 22 percent and 21 percent, respectively. The increase in the effective tax rate was due to an increase in the rate on foreign earnings with the implementation of the European Union’s Pillar Two Directive.

[0000038725-24-000078:mdna:46]
[same as prior period, unchanged from 0000038725-23-000182:mdna:48]

[0000038725-24-000078:mdna:47]
Net income for the first quarter of 2024 was $33.1 million compared to the prior year first quarter net income of $37.6 million. Net income attributable to Franklin Electric Co., Inc. for the first quarter of 2024 was $33.0 million, or $0.70 per diluted share, compared to the prior year first quarter net income attributable to Franklin Electric Co., Inc. of $37.3 million, or $0.79 per diluted share.

[0000038725-24-000078:mdna:48]
[same as prior period, unchanged from 0000038725-23-000182:mdna:50]

[0000038725-24-000078:mdna:49]
[same as prior period, unchanged from 0000038725-23-000182:mdna:51]

[0000038725-24-000078:mdna:50]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at March 31, 2024 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-24-000078:mdna:51]
As of March 31, 2024, the Company had a $350.0 million revolving credit facility. The facility is scheduled to mature on May 13, 2026. As of March 31, 2024, the Company had $323.5 million borrowing capacity under its credit agreement as $3.5 million in letters of commercial and standby letters of credit were outstanding and undrawn and $23.0 million in revolver borrowings were drawn and outstanding, which were primarily used for funding working capital requirements.

[0000038725-24-000078:mdna:52]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement") with a remaining borrowing capacity of  $125.0 million as of March 31, 2024. The Company also has other long-term debt borrowings outstanding as of March 31, 2024. See Note 10 - Debt included in the Company's Annual Report on Form 10-K for the year ended December 31, 2023, for additional information regarding these obligations and future maturities as well as Note 10 - Debt of this current quarterly report for changes to these agreements since December 31, 2023.

[0000038725-24-000078:mdna:53]
At March 31, 2024, the Company had $59.6 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations. There is currently no need or intent to repatriate the majority of these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-24-000078:mdna:54]
[same as prior period, unchanged from 0000038725-23-000182:mdna:56]

[0000038725-24-000078:mdna:55]
The following table summarizes significant sources and uses of cash and cash equivalents for the first three months of 2024 and 2023.

[0000038725-24-000078:mdna:56]
| (in millions) |  | 2024 |  | 2023 |
| Net cash flows from operating activities |  | $ | (1.4) |  |  | $ | (12.0) |  |
| Net cash flows from investing activities |  | (10.2) |  |  | (14.6) |  |
| Net cash flows from financing activities |  | (6.3) |  |  | 33.1 |  |
| Impact of exchange rates on cash and cash equivalents |  | (1.7) |  |  | (0.4) |  |
| Change in cash and cash equivalents |  | $ | (19.6) |  |  | $ | 6.1 |  |

[0000038725-24-000078:mdna:57]
[same as prior period, unchanged from 0000038725-23-000182:mdna:59]

[0000038725-24-000078:mdna:58]
2024 vs. 2023

[0000038725-24-000078:mdna:59]
Net cash used by operating activities was $1.4 million for the three months ended March 31, 2024 compared to $12.0 million used by operating activities for the three months ended March 31, 2023. The change in operating cash flow was primarily due to continued actions to improve working capital including inventory reductions.

[0000038725-24-000078:mdna:60]
[same as prior period, unchanged from 0000038725-23-000182:mdna:62]

[0000038725-24-000078:mdna:61]
2024 vs. 2023

[0000038725-24-000078:mdna:62]
Net cash used in investing activities was $10.2 million for the three months ended March 31, 2024 compared to $14.6 million used in investing activities for the three months ended March 31, 2023. The change in investing cash flow was primarily attributable to decreased acquisition activity in the first three months of 2024.

[0000038725-24-000078:mdna:63]
[same as prior period, unchanged from 0000038725-23-000182:mdna:65]

[0000038725-24-000078:mdna:64]
2024 vs. 2023

[0000038725-24-000078:mdna:65]
Net cash used by financing activities was $6.3 million for the three months ended March 31, 2024 compared to $33.1 million provided by financing activities for the three months ended March 31, 2023. The change in financing cash flow was primarily attributable to reduced borrowings under the Company's revolving credit facility in 2024 compared to 2023.

[0000038725-24-000078:mdna:66]
[same as prior period, unchanged from 0000038725-23-000182:mdna:68]
