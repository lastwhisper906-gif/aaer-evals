# FELE 8-K — 0000038725-24-000074 filed 2024-04-30

## item codes, every 8-K on or before 2024-04-30

- 2024-04-30 0000038725-24-000074 — 2.02, 9.01
- 2024-02-13 0000038725-24-000012 — 7.01, 9.01
- 2024-02-13 0000038725-24-000010 — 2.02, 9.01
- 2023-11-06 0000038725-23-000184 — 7.01, 9.01
- 2023-10-24 0000038725-23-000177 — 2.02, 9.01
- 2023-08-04 0000038725-23-000160 — 5.02, 9.01
- 2023-08-03 0000038725-23-000158 — 7.01, 9.01
- 2023-07-25 0000038725-23-000149 — 2.02, 9.01
- 2023-07-05 0000038725-23-000144 — 5.02, 7.01, 9.01
- 2023-05-09 0000038725-23-000094 — 5.02, 9.01
- 2023-05-09 0000038725-23-000092 — 5.07
- 2023-05-08 0000038725-23-000087 — 7.01, 9.01
- 2023-05-02 0000038725-23-000065 — 2.02, 9.01
- 2023-03-08 0000038725-23-000046 — 7.01, 9.01
- 2023-02-21 0000038725-23-000016 — 8.01, 9.01
- 2023-02-14 0000038725-23-000002 — 2.02, 9.01
- 2022-10-28 0000038725-22-000180 — 7.01, 9.01
- 2022-10-25 0000038725-22-000177 — 2.02, 9.01
- 2022-08-04 0000038725-22-000150 — 7.01, 9.01
- 2022-07-26 0000038725-22-000142 — 2.02, 9.01
- 2022-05-11 0000038725-22-000106 — 2.03, 9.01
- 2022-05-06 0000038725-22-000082 — 5.07
- 2022-05-06 0000038725-22-000081 — 5.02, 9.01
- 2022-05-03 0000038725-22-000075 — 7.01, 9.01
- 2022-04-26 0000038725-22-000073 — 2.02, 9.01
- 2022-03-24 0000038725-22-000056 — 5.02, 9.01
- 2022-03-08 0000038725-22-000049 — 7.01, 9.01
- 2022-02-15 0000038725-22-000007 — 2.02, 9.01
- 2022-01-04 0000038725-22-000002 — 7.01, 9.01
- 2021-11-03 0000038725-21-000212 — 7.01, 9.01
- 2021-10-26 0000038725-21-000203 — 2.02, 9.01
- 2021-07-27 0000038725-21-000172 — 7.01, 9.01
- 2021-07-27 0000038725-21-000170 — 2.02, 9.01
- 2021-06-14 0000038725-21-000157 — 5.02, 7.01, 9.01
- 2021-05-17 0000038725-21-000120 — 7.01, 9.01
- 2021-05-17 0000038725-21-000118 — 7.01, 9.01
- 2021-05-13 0000038725-21-000102 — 2.03, 9.01
- 2021-05-07 0000038725-21-000096 — 5.07
- 2021-05-07 0000038725-21-000094 — 5.02, 9.01
- 2021-04-27 0000038725-21-000088 — 7.01, 9.01
- 2021-04-27 0000038725-21-000085 — 2.02, 9.01
- 2021-04-01 0000038725-21-000080 — 7.01, 9.01
- 2021-02-17 0000038725-21-000013 — 7.01, 9.01
- 2021-02-16 0000038725-21-000010 — 2.02, 9.01
- 2021-01-04 0000038725-21-000003 — 7.01, 9.01
- 2020-12-18 0000038725-20-000241 — 5.02, 9.01
- 2020-11-09 0000038725-20-000223 — 7.01, 9.01
- 2020-11-02 0000038725-20-000210 — 7.01, 9.01
- 2020-10-27 0000038725-20-000206 — 2.02, 9.01
- 2020-07-28 0000038725-20-000168 — 2.02, 9.01
- 2020-06-25 0000038725-20-000164 — 8.01, 9.01
- 2020-06-25 0000038725-20-000163 — 8.01, 9.01
- 2020-05-11 0000038725-20-000133 — 5.02, 9.01
- 2020-05-08 0000038725-20-000119 — 5.07
- 2020-05-06 0000038725-20-000111 — 5.02, 9.01
- 2020-04-28 0000038725-20-000104 — 2.02, 9.01
- 2020-02-18 0000038725-20-000018 — 2.02, 9.01
- 2020-01-30 0000038725-20-000009 — 5.02, 5.03, 9.01
- 2019-11-04 0000038725-19-000234 — 7.01, 9.01
- 2019-10-29 0000038725-19-000221 — 2.02, 9.01
- 2019-08-01 0000038725-19-000193 — 7.01, 9.01
- 2019-07-23 0000038725-19-000178 — 2.02, 9.01
- 2019-05-07 0000038725-19-000140 — 5.03, 9.01
- 2019-05-03 0000038725-19-000124 — 5.07
- 2019-05-03 0000038725-19-000122 — 7.01, 9.01
- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2024-04-30

- none on or before 2024-04-30

## item 2.02 — earnings release, exhibit 99.1

[0000038725-24-000074:8k_2_02:1]
EX-99.1
2
a20240430ex991earningsrele.htm
EX-99.1

[0000038725-24-000074:8k_2_02:2]
Document

[0000038725-24-000074:8k_2_02:3]
Exhibit 99.1

[0000038725-24-000074:8k_2_02:4]
NEWS RELEASE FOR IMMEDIATE DISTRIBUTION

[0000038725-24-000074:8k_2_02:5]
FRANKLIN ELECTRIC REPORTS FIRST QUARTER 2024 RESULTS

[0000038725-24-000074:8k_2_02:6]
First Quarter 2024 Highlights

[0000038725-24-000074:8k_2_02:7]
•Consolidated net sales of $460.9 million, a decrease of 5% to the prior year

[0000038725-24-000074:8k_2_02:8]
•Distribution net sales increased 3%, while Water Systems and Fueling Systems net sales decreased 7% and 15%, respectively

[0000038725-24-000074:8k_2_02:9]
•Operating income was $47.9 million with operating margin of 10.4%

[0000038725-24-000074:8k_2_02:10]
•GAAP fully diluted earnings per share (EPS) was $0.70

[0000038725-24-000074:8k_2_02:11]
Fort Wayne, IN – April 30, 2024 – Franklin Electric Co., Inc. today announced its first quarter financial results for fiscal year 2024.

[0000038725-24-000074:8k_2_02:12]
First quarter 2024 net sales were $460.9 million, compared to first quarter 2023 net sales of $484.6 million. First quarter 2024 operating income was $47.9 million, compared to first quarter 2023 operating income of $52.6 million.  First quarter 2024 EPS was $0.70, versus EPS in the first quarter 2023 of $0.79.

[0000038725-24-000074:8k_2_02:13]
“Our first quarter started slower than expected but improved as we moved through the quarter and demand seasonally increased. While results were slightly below our expectations due to the impact from unfavorable weather patterns and lingering commodity price headwinds in our Distribution business, underlying demand in our core markets remains healthy. Strong execution by our global teams drove improved margins on lower sales in our Water Systems and Fueling Systems segments,” commented Gregg Sengstack, Franklin Electric’s Chairperson and Chief Executive Officer.

[0000038725-24-000074:8k_2_02:14]
“Our disciplined management of working capital delivered an improvement in cash flow from operations. Open orders increased sequentially, as expected, which combined with our further strengthening balance sheet, leaves us well-positioned to build momentum as we move into the busier summer months,” concluded Mr. Sengstack.

[0000038725-24-000074:8k_2_02:15]
Segment Summaries

[0000038725-24-000074:8k_2_02:16]
Water Systems net sales were $286.6 million in the first quarter, a decrease of $20.0 million or 7 percent compared to the record first quarter sales of 2023. Sales decreases were driven by lower sales of large dewatering pumps, which had a record quarter last year. Additionally, sales increases in Water Treatment products were partially offset by lower sales of groundwater products. Water Systems operating income in the first quarter 2024 was $47.1 million. First quarter 2023 Water Systems operating income was $49.0 million.

[0000038725-24-000074:8k_2_02:17]
Distribution net sales were $147.0 million, an increase of $4.0 million or 3 percent compared to the first quarter 2023. Sales increases were driven by higher volumes and the sales from a recent acquisition, partially offset by unfavorable pricing of commodity-based products sold through the business. The Distribution segment operating income decreased to $1.8 million in the first quarter 2024 compared to first quarter 2023 operating income of $4.7 million primarily due to continued margin compression from unfavorable pricing of commodity-based products.

[0000038725-24-000074:8k_2_02:18]
Fueling Systems net sales were $62.1 million in the first quarter 2024, a decrease of $10.6 million or 15 percent compared to the record sales of the first quarter 2023. Sales decreases were driven by lower

[0000038725-24-000074:8k_2_02:19]
volumes as demand and order patterns have normalized. Fueling Systems operating income in the first quarter 2024 was $18.8 million. First quarter 2023 Fueling Systems operating income was $20.8 million.

[0000038725-24-000074:8k_2_02:20]
2024 Guidance

[0000038725-24-000074:8k_2_02:21]
The Company is maintaining its guidance for full year 2024 sales to be in the range of $2.10 billion to $2.17 billion and full year 2024 EPS to be in the range of $4.22 to $4.40.

[0000038725-24-000074:8k_2_02:22]
Earnings Conference Call

[0000038725-24-000074:8k_2_02:23]
A conference call to review earnings and other developments in the business will commence at 9:00 am ET. The first quarter 2024 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-24-000074:8k_2_02:24]
https://edge.media-server.com/mmc/p/np8yrgn4

[0000038725-24-000074:8k_2_02:25]
For those interested in participating in the question-and-answer portion of the call, please register for the call at the link below.

[0000038725-24-000074:8k_2_02:26]
https://register.vevent.com/register/BI69e000919c5c4cc4ab5f19c089297b7b

[0000038725-24-000074:8k_2_02:27]
All registrants will receive dial-in information and a PIN allowing them to access the live call. It is recommended that you join 10 minutes prior to the start of the event (although you may register and dial in at any time during the call).

[0000038725-24-000074:8k_2_02:28]
A replay of the conference call will be available from Tuesday, April 30, 2024, through 9:00 am ET on Tuesday, May 7, 2024, by visiting the listen-only webcast link above.

[0000038725-24-000074:8k_2_02:29]
Forward Looking Statements

[0000038725-24-000074:8k_2_02:30]
About Franklin Electric

[0000038725-24-000074:8k_2_02:31]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and energy. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications. Franklin Electric is proud to be named in Newsweek’s lists of America’s Most

[0000038725-24-000074:8k_2_02:32]
Responsible Companies and Most Trustworthy Companies for 2023 and America’s Climate Leaders 2023 by USA Today.

[0000038725-24-000074:8k_2_02:33]
Franklin Electric Contact:

[0000038725-24-000074:8k_2_02:34]
Jeffery L. Taylor

[0000038725-24-000074:8k_2_02:35]
Franklin Electric Co., Inc.

[0000038725-24-000074:8k_2_02:36]
InvestorRelations@fele.com

[0000038725-24-000074:8k_2_02:37]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | First Quarter Ended |  |  |
|  | March 31, 2024 |  | March 31, 2023 |  |  |  |  |
| Net sales | $ | 460,900 |  |  | $ | 484,551 |  |  |  |  |  |
| Cost of sales | 297,320 |  |  | 322,286 |  |  |  |  |  |
| Gross profit | 163,580 |  |  | 162,265 |  |  |  |  |  |
| Selling, general, and administrative expenses | 115,644 |  |  | 109,535 |  |  |  |  |  |
| Restructuring expense | — |  |  | 124 |  |  |  |  |  |
| Operating income | 47,936 |  |  | 52,606 |  |  |  |  |  |
| Interest expense | (1,448) |  |  | (3,147) |  |  |  |  |  |
| Other income, net | 706 |  |  | 409 |  |  |  |  |  |
| Foreign exchange expense | (4,880) |  |  | (2,044) |  |  |  |  |  |
| Income before income taxes | 42,314 |  |  | 47,824 |  |  |  |  |  |
| Income tax expense | 9,222 |  |  | 10,248 |  |  |  |  |  |
| Net income | $ | 33,092 |  |  | $ | 37,576 |  |  |  |  |  |
| Less: Net income attributable to noncontrolling interests | (133) |  |  | (251) |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 32,959 |  |  | $ | 37,325 |  |  |  |  |  |
| Earnings per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.71 |  |  | $ | 0.81 |  |  |  |  |  |
| Diluted | $ | 0.70 |  |  | $ | 0.79 |  |  |  |  |  |

[0000038725-24-000074:8k_2_02:38]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | March 31, 2024 |  | December 31, 2023 |
| ASSETS |  |
| Cash and cash equivalents | $ | 65,314 |  |  | $ | 84,963 |  |
| Receivables (net) | 262,632 |  |  | 222,418 |  |
| Inventories | 532,242 |  |  | 508,696 |  |
| Other current assets | 41,175 |  |  | 37,718 |  |
| Total current assets | 901,363 |  |  | 853,795 |  |
| Property, plant, and equipment, net | 227,206 |  |  | 229,739 |  |
| Lease right-of-use assets, net | 60,916 |  |  | 57,014 |  |
| Goodwill and other assets | 583,622 |  |  | 587,574 |  |
| Total assets | $ | 1,773,107 |  |  | $ | 1,728,122 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 185,504 |  |  | $ | 152,419 |  |
| Accrued expenses and other current liabilities | 88,312 |  |  | 104,949 |  |
| Current lease liability | 18,018 |  |  | 17,316 |  |
| Current maturities of long-term debt and short-term borrowings | 24,414 |  |  | 12,355 |  |
| Total current liabilities | 316,248 |  |  | 287,039 |  |
| Long-term debt | 87,406 |  |  | 88,056 |  |
| Long-term lease liability | 41,638 |  |  | 38,549 |  |
| Income taxes payable non-current | 4,837 |  |  | 4,837 |  |
| Deferred income taxes | 29,514 |  |  | 29,461 |  |
| Employee benefit plans | 35,785 |  |  | 35,973 |  |
| Other long-term liabilities | 33,591 |  |  | 33,914 |  |
| Redeemable noncontrolling interest | 1,109 |  |  | 1,145 |  |
| Total equity | 1,222,979 |  |  | 1,209,148 |  |
| Total liabilities and equity | $ | 1,773,107 |  |  | $ | 1,728,122 |  |

[0000038725-24-000074:8k_2_02:39]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Three Months Ended |
| (In thousands) |  |  |  |
|  | March 31, 2024 |  | March 31, 2023 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 33,092 |  |  | $ | 37,576 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 13,792 |  |  | 12,837 |  |
| Non-cash lease expense | 5,194 |  |  | 4,239 |  |
| Share-based compensation | 4,042 |  |  | 3,912 |  |
| Other | 4,036 |  |  | 3,250 |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (43,365) |  |  | (43,408) |  |
| Inventory | (28,105) |  |  | (50,725) |  |
| Accounts payable and accrued expenses | 8,576 |  |  | 13,163 |  |
| Operating leases | (5,305) |  |  | (4,239) |  |
| Other | 6,681 |  |  | 11,376 |  |
| Net cash flows from operating activities | (1,362) |  |  | (12,019) |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (9,184) |  |  | (9,563) |  |
| Proceeds from sale of property, plant, and equipment | 102 |  |  | — |  |
| Acquisitions and investments | (1,151) |  |  | (4,990) |  |
| Other investing activities | 17 |  |  | — |  |
| Net cash flows from investing activities | (10,216) |  |  | (14,553) |  |
| Cash flows from financing activities: |  |  |  |
| Net change in debt | 11,397 |  |  | 57,733 |  |
| Proceeds from issuance of common stock | 4,050 |  |  | 2,938 |  |
| Purchases of common stock | (9,047) |  |  | (17,133) |  |
| Dividends paid | (12,395) |  |  | (10,440) |  |
| Deferred payments for acquisitions | (348) |  |  | — |  |
| Net cash flows from financing activities | (6,343) |  |  | 33,098 |  |
| Effect of exchange rate changes on cash and cash equivalents | (1,728) |  |  | (443) |  |
| Net change in cash and cash equivalents | (19,649) |  |  | 6,083 |  |
| Cash and cash equivalents at beginning of period | 84,963 |  |  | 45,790 |  |
| Cash and cash equivalents at end of period | $ | 65,314 |  |  | $ | 51,873 |  |

[0000038725-24-000074:8k_2_02:40]
Key Performance Indicators: Net Sales Summary

[0000038725-24-000074:8k_2_02:41]
|  | Net Sales |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q1 2023 | $ | 197.1 |  | $ | 40.3 |  | $ | 50.4 |  | $ | 18.8 |  | $ | 306.6 |  | $ | 72.7 |  | $ | 143.0 |  | $ | (37.7) |  | $ | 484.6 |  |
| Q1 2024 | $ | 172.7 |  | $ | 41.3 |  | $ | 52.3 |  | $ | 20.3 |  | $ | 286.6 |  | $ | 62.1 |  | $ | 147.0 |  | $ | (34.8) |  | $ | 460.9 |  |
| Change | $ | (24.4) |  | $ | 1.0 |  | $ | 1.9 |  | $ | 1.5 |  | $ | (20.0) |  | $ | (10.6) |  | $ | 4.0 |  | $ | 2.9 |  | $ | (23.7) |  |
| % Change | (12) | % | 2 | % | 4 | % | 8 | % | (7) | % | (15) | % | 3 | % |  | (5) | % |
| Foreign currency translation, net* | $ | 0.1 |  | $ | 1.4 |  | $ | (2.6) |  | $ | (0.8) |  | $ | (1.9) |  | $ | — |  | $ | — |  |  | $ | (1.9) |  |
| % Change | — | % | 3 | % | (5) | % | (4) | % | (1) | % | — | % | — | % |  | — | % |
| Acquisitions | $ | 5.1 |  | $ | — |  | $ | — |  | $ | — |  | $ | 5.1 |  | $ | — |  | $ | 3.7 |  |  | $ | 8.8 |  |
| % Change | 3 | % | — | % | — | % | — | % | 2 | % | — | % | 3 | % |  | 2 | % |
| Volume/Price | $ | (29.6) |  | $ | (0.4) |  | $ | 4.5 |  | $ | 2.3 |  | $ | (23.2) |  | $ | (10.6) |  | $ | 0.3 |  | $ | 2.9 |  | $ | (30.6) |  |
| % Change | (15) | % | (1) | % | 9 | % | 12 | % | (8) | % | (15) | % | — | % | 8 | % | (6) | % |

[0000038725-24-000074:8k_2_02:42]
*Beginning in 2024, the Company has presented local currency price increases used to offset currency devaluation in the Argentina and Turkey hyperinflationary economies within the foreign currency translation, net row above.

[0000038725-24-000074:8k_2_02:43]
Key Performance Indicators: Operating Income and Margin Summary

[0000038725-24-000074:8k_2_02:44]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the First Quarter 2024 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 47.1 |  | $ | 18.8 |  | $ | 1.8 |  | $ | (19.8) |  | $ | 47.9 |  |
| % Operating Income To Net Sales | 16.4 | % | 30.3 | % | 1.2 | % |  | 10.4 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the First Quarter 2023 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 49.0 |  | $ | 20.8 |  | $ | 4.7 |  | $ | (21.9) |  | $ | 52.6 |  |
| % Operating Income To Net Sales | 16.0 | % | 28.6 | % | 3.3 | % |  | 10.9 | % |
