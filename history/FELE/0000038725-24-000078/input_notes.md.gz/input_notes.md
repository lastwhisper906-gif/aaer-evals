# FELE notes — 0000038725-24-000078


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-24-000078:notes:1]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2023, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2024, and for the first quarters ended March 31, 2024 and March 31, 2023 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the first quarter ended March 31, 2024 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2024. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2023.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000038725-24-000078:notes:2]
ACCOUNTING PRONOUNCEMENTS
Accounting Standards Issued But Not Yet Adopted

[0000038725-24-000078:notes:3]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures. ASU 2023-07 is intended to improve reportable segment disclosure requirements, primarily through additional and more detailed information about a reportable segment's expenses. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The guidance is to be applied retrospectively to all prior periods presented in the financial statements. The Company plans to adopt this ASU for its fiscal year end December 31, 2024 disclosures, but does not anticipate the adoption to have a material impact on the Company's financial disclosures.

[0000038725-24-000078:notes:4]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. This amendment modifies the rules on income tax disclosures to require entities to disclose (1) specific categories in the rate reconciliation and additional information for reconciling items that meet a quantitative threshold, (2) the amount of income taxes paid (net of refunds received) (disaggregated by federal, state, and foreign taxes) as well as individual jurisdictions in which income taxes paid is equal to or greater than 5 percent of total income taxes paid net of refunds, (3) the income or loss from continuing operations before income tax expense or benefit (disaggregated between domestic and foreign) and (4) income tax expense or benefit from continuing operations (disaggregated by federal, state and foreign). ASU 2023-09 is effective for annual periods beginning after December 15, 2024, with early adoption permitted. ASU 2023-09 should be applied on a prospective basis, while retrospective application is permitted. The Company is still determining the date of adoption for this ASU, but does not anticipate the adoption to have a material impact on the Company's financial disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-24-000078:notes:5]
[same as prior period, unchanged from 0000038725-23-000182:notes:5]

[0000038725-24-000078:notes:6]
During the fourth quarter ended December 31, 2023, the Company acquired substantially all of the assets of Aqua Systems of Fort Myers, a water treatment systems distributor.  In another separate transaction, the Company acquired substantially all of the assets of Action Manufacturing and Supply, Inc., a water treatment equipment provider located in southwest Florida. The Company also acquired, in a separate transaction, substantially all of the assets of LCA Pump, LLC, which operates Water Works Pump, a Missouri based professional groundwater distributor. The combined purchase price for the acquisitions in the fourth quarter of 2023, was $36.0 million, including contingent consideration with an estimated fair value of $4.3 million, after purchase price adjustments based on the level of working capital acquired. In the first quarter of 2024, the Company recorded a measurement period adjustment of $1.3 million to increase the acquisition-date fair value of the contingent consideration transferred. The measurement period adjustment resulted in an increase to acquired identifiable intangible assets of $2.3 million and a reduction to acquired goodwill of $1.0 million. The measurement period adjustments did not have a significant impact on the Company’s results of operations. The fair value of the assets acquired and liabilities assumed for all acquisitions is preliminary as of March 31, 2024.

[0000038725-24-000078:notes:7]
During the first quarter ended March 31, 2023, the Company acquired all of the assets of Phil-Good Products, Inc. ("Phil-Good"). Phil-Good is an injection molded plastics component manufacturer. In another separate transaction in the first quarter of 2023, the Company acquired 100 percent of the ownership interests of Hydropompe S.r.l. ("Hydropompe"). Hydropompe is a pump manufacturer with a focus in dewatering and sewage products. The combined, all-cash purchase price for both acquisitions in the first quarter of 2023 was $8.7 million after purchase price adjustments based on the level of working capital acquired. The fair value of the assets acquired and liabilities assumed for both acquisitions is final as of March 31, 2024.

[0000038725-24-000078:notes:8]
The Company has not presented separate results of operations of the acquired companies since the closing of the acquisitions or combined pro forma financial information of the Company and the acquired interests as the results of operations for all 2023 acquisitions are immaterial.

[0000038725-24-000078:notes:9]
[same as prior period, unchanged from 0000038725-23-000182:notes:7]


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-24-000078:notes:10]
[same as prior period, unchanged from 0000038725-23-000182:notes:8]

[0000038725-24-000078:notes:11]
[same as prior period, unchanged from 0000038725-23-000182:notes:9]

[0000038725-24-000078:notes:12]
[same as prior period, unchanged from 0000038725-23-000182:notes:10]

[0000038725-24-000078:notes:13]
[same as prior period, unchanged from 0000038725-23-000182:notes:11]

[0000038725-24-000078:notes:14]
As of March 31, 2024 and December 31, 2023, the assets and liabilities measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-24-000078:notes:15]
| (In millions) | March 31, 2024 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 11.3 |  | $ | 11.3 |  | $ | — |  | $ | — |  |
| Share swap transaction | 0.6 |  | 0.6 |  | — |  | — |  |
| Forward currency contracts | 0.3 |  | — |  | 0.3 |  | — |  |
| Total assets | $ | 12.2 |  | $ | 11.9 |  | $ | 0.3 |  | $ | — |  |
| Liabilities: |  |  |  |  |
| Contingent payments related to acquisition | $ | 4.5 |  | $ | — |  | $ | — |  | $ | 4.5 |  |
| Total liabilities | $ | 4.5 |  | $ | — |  | $ | — |  | $ | 4.5 |  |
|  | December 31, 2023 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |
| Cash equivalents | $ | 10.9 |  | $ | 10.9 |  | $ | — |  | $ | — |  |
| Share swap transaction | 1.1 |  | 1.1 |  | — |  | — |  |
| Total assets | $ | 12.0 |  | $ | 12.0 |  | $ | — |  | $ | — |  |
| Liabilities: |  |  |  |  |
| Contingent payments related to acquisition | $ | 3.0 |  | $ | — |  | $ | — |  | $ | 3.0 |  |
| Total liabilities | $ | 3.0 |  | $ | — |  | $ | — |  | $ | 3.0 |  |

[0000038725-24-000078:notes:16]
The Company’s Level 1 cash equivalents assets are generally comprised of foreign bank guaranteed certificates of deposit and short term deposits. The share swap transaction and forward currency contracts assets are recorded within the "Receivables" lines of the condensed consolidated balance sheets and are further described in Note 5 - Financial Instruments.

[0000038725-24-000078:notes:17]
The Company's Level 3 category includes contingent consideration related to acquisitions, which valuation inputs are unobservable and significant to the fair value measurement.  Projections and estimated probabilities are used to estimate future contingent earn-out payments, which are discounted back to present value to compute contingent earn-out liabilities. The following table provides a roll-forward of the contingent consideration liability, which is included in "Other long-term liabilities" as of December 31, 2023 and "Accrued expenses and other current liabilities" as of March 31, 2024 in the condensed consolidated balance sheets:

[0000038725-24-000078:notes:18]
|  | Three Months Ended |
| (In millions) | March 31, 2024 |
| Fair value at beginning of period | $ | 3.0 |  |
| Adjustments to prior year acquisition | 1.3 |  |
| Change in fair value recognized in earnings | 0.2 |  |
| Payments | — |  |
| Fair value at end of period | $ | 4.5 |  |

[0000038725-24-000078:notes:19]
Total debt, including current maturities, have carrying amounts of $111.8 million and $100.5 million and estimated fair values of $109.1 million and $98.6 million as of March 31, 2024 and December 31, 2023, respectively. In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value. Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction. In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities. Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-24-000078:notes:20]
FINANCIAL INSTRUMENTS
The Company’s non-employee directors' deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period. The Company has entered into share swap transaction agreements (the "swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price. The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party. As of March 31, 2024 and December 31, 2023, the swap had a notional value based on 240,000 shares. For the first quarters ended March 31, 2024 and March 31, 2023, changes in the fair value of the swap resulted in gains of $2.1 million and $2.9 million, respectively. Gains resulting from the swap were largely offset by losses on the fair value of the deferred compensation stock liability. All gains and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.

[0000038725-24-000078:notes:21]
The Company is exposed to foreign currency exchange rate risk arising from transactions in the normal course of business including making sales and purchases of raw materials and finished goods in foreign denominated currencies with third party customers and suppliers as well as to wholly owned subsidiaries of the Company.  To reduce its exposure to foreign currency exchange rate volatility, the Company enters into various forward currency contracts to offset these fluctuations. The Company uses forward currency contracts only in an attempt to limit underlying exposure from foreign currency exchange rate fluctuations and to minimize earnings volatility associated with foreign currency exchange rate fluctuations and has not elected to use hedge accounting. Decisions on whether to use such derivative instruments are primarily based on the amount of exposure to the currency involved and an assessment of the near-term market value for each currency.  As of March 31, 2024, the Company had a notional amount of $26.5 million in forward currency contracts outstanding and the related fair value of those contracts was not material.  As of December 31, 2023, the Company had no foreign currency contracts outstanding.  For the first quarters ended March 31, 2024 and March 31, 2023, changes in the fair value of the forward currency contracts resulted in gains of $0.6 million and $1.0 million, respectively. These gains are recorded in the Company's condensed consolidated statements of income within the "Foreign exchange expense" line.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-24-000078:notes:22]
[same as prior period, unchanged from 0000038725-23-000182:notes:17]

[0000038725-24-000078:notes:23]
| (In millions) |  | March 31, 2024 |  | December 31, 2023 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Definite-lived intangibles: |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 264.7 |  |  | $ | (118.9) |  |  | $ | 263.7 |  |  | $ | (115.5) |  |
| Patents |  | 7.3 |  |  | (7.3) |  |  | 7.3 |  |  | (7.3) |  |
| Technology |  | 7.5 |  |  | (7.5) |  |  | 7.5 |  |  | (7.5) |  |
| Trade names |  | 44.1 |  |  | (6.4) |  |  | 44.1 |  |  | (5.8) |  |
| Other |  | 3.3 |  |  | (2.8) |  |  | 3.4 |  |  | (2.8) |  |
| Total |  | $ | 326.9 |  |  | $ | (142.9) |  |  | $ | 326.0 |  |  | $ | (138.9) |  |
| Indefinite-lived intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 42.7 |  |  | — |  |  | 42.9 |  |  | — |  |
| Total intangibles |  | $ | 369.6 |  |  | $ | (142.9) |  |  | $ | 368.9 |  |  | $ | (138.9) |  |

[0000038725-24-000078:notes:24]
Amortization expense related to intangible assets for the first quarters ended March 31, 2024 and March 31, 2023 was $4.8 million and $4.2 million, respectively.

[0000038725-24-000078:notes:25]
The change in the carrying amount of goodwill by reportable segment for the three months ended March 31, 2024 is as follows:

[0000038725-24-000078:notes:26]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2023 |  | $ | 221.4 |  |  | $ | 70.4 |  |  | $ | 50.6 |  |  | $ | 342.4 |  |
| Adjustments to prior year acquisitions |  | (0.7) |  |  | — |  |  | (0.1) |  |  | (0.8) |  |
| Foreign currency translation |  | (1.1) |  |  | — |  |  | — |  |  | (1.1) |  |
| Balance as of March 31, 2024 |  | $ | 219.6 |  |  | $ | 70.4 |  |  | $ | 50.5 |  |  | $ | 340.5 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-24-000078:notes:27]
EMPLOYEE BENEFIT PLANS
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the first quarters ended March 31, 2024 and March 31, 2023:

[0000038725-24-000078:notes:28]
| (In millions) | Pension Benefits |
|  | First Quarter Ended |  |  |
|  | March 31, 2024 |  | March 31, 2023 |  |  |  |  |
| Service cost | $ | 0.1 |  |  | $ | 0.1 |  |  |  |  |  |
| Interest cost | 1.5 |  |  | 1.5 |  |  |  |  |  |
| Expected return on assets | (1.9) |  |  | (1.8) |  |  |  |  |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  |  |  |  |
| Actuarial loss | 0.6 |  |  | 0.6 |  |  |  |  |  |
| Settlement cost | — |  |  | — |  |  |  |  |  |
| Net periodic benefit cost | $ | 0.3 |  |  | $ | 0.4 |  |  |  |  |  |

[0000038725-24-000078:notes:29]
The following table sets forth the aggregated net periodic benefit cost for the other post-retirement benefit plan for the first quarters ended March 31, 2024 and March 31, 2023:

[0000038725-24-000078:notes:30]
| (In millions) | Other Benefits |
|  | First Quarter Ended |  |  |
|  | March 31, 2024 |  | March 31, 2023 |  |  |  |  |
| Service cost | $ | — |  |  | $ | — |  |  |  |  |  |
| Interest cost | 0.1 |  |  | 0.1 |  |  |  |  |  |
| Expected return on assets | — |  |  | — |  |  |  |  |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  |  |  |  |
| Actuarial loss | — |  |  | — |  |  |  |  |  |
| Settlement cost | — |  |  | — |  |  |  |  |  |
| Net periodic benefit cost | $ | 0.1 |  |  | $ | 0.1 |  |  |  |  |  |


## us-gaap:AccountsPayableAccruedLiabilitiesAndOtherLiabilitiesDisclosureCurrentTextBlock

[0000038725-24-000078:notes:31]
[same as prior period, unchanged from 0000038725-23-000182:notes:25]

[0000038725-24-000078:notes:32]
| (In millions) |  | March 31, 2024 |  | December 31, 2023 |
| Salaries, wages, and commissions |  | $ | 33.8 |  |  | $ | 45.9 |  |
| Product warranty costs |  | 8.9 |  |  | 9.3 |  |
| Insurance |  | 1.9 |  |  | 2.5 |  |
| Employee benefits |  | 6.1 |  |  | 13.8 |  |
| Other |  | 25.7 |  |  | 28.7 |  |
| Total |  | $ | 76.4 |  |  | $ | 100.2 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-24-000078:notes:33]
INCOME TAXES
The Company’s effective tax rate for the three-month period ended March 31, 2024 was 21.8 percent as compared to 21.4 percent for the three-month period ended March 31, 2023. The effective tax rate differs from the U.S. statutory rate of 21 percent primarily due to state taxes and foreign earnings taxed at rates higher than the U.S. statutory rate partially offset by the recognition of the U.S. foreign-derived intangible income (FDII) provisions and certain discrete events including excess tax benefits from share-based compensation..

[0000038725-24-000078:notes:34]
The increase in the effective tax rate for the first quarter of 2024 compared to the comparable period in the prior year was primarily due to an increase in the rate on foreign earnings with the implementation of the European Union’s Pillar Two Directive.


## us-gaap:DebtDisclosureTextBlock

[0000038725-24-000078:notes:35]
DEBT
Debt consisted of the following:

[0000038725-24-000078:notes:36]
| (In millions) |  | March 31, 2024 |  | December 31, 2023 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 23.0 |  |  | 11.0 |  |
| Tax increment financing debt |  | 13.5 |  |  | 14.1 |  |
| Foreign subsidiary debt |  | 0.4 |  |  | 0.5 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 111.8 |  |  | $ | 100.5 |  |
| Less: current maturities |  | (24.4) |  |  | (12.4) |  |
| Long-term debt |  | $ | 87.4 |  |  | $ | 88.1 |  |

[0000038725-24-000078:notes:37]
Credit Agreement

[0000038725-24-000078:notes:38]
As of March 31, 2024, the Company had $23.0 million outstanding borrowings with a weighted-average interest rate of 6.3 percent, $3.5 million in letters of credit outstanding, and $323.5 million of available capacity under its credit agreement. As of December 31, 2023, the Company had $11.0 million outstanding borrowings with a weighted-average interest rate of 6.3 percent, $3.6 million in letters of credit outstanding, and $335.4 million of available capacity under its credit agreement.

[0000038725-24-000078:notes:39]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $17.4 million. As of March 31, 2024, there were no outstanding borrowings and $17.4 million of available capacity under these lines of credit. As of December 31, 2023, there were $17.9 million overdraft lines of credit with no outstanding borrowings and $17.9 million of available capacity under these lines of credit.


## us-gaap:EarningsPerShareTextBlock

[0000038725-24-000078:notes:40]
[same as prior period, unchanged from 0000038725-23-000182:notes:34]

[0000038725-24-000078:notes:41]
Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period. Diluted earnings per common share is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.

[0000038725-24-000078:notes:42]
The following table sets forth the computation of basic and diluted earnings per share:

[0000038725-24-000078:notes:43]
|  | First Quarter Ended |  |  |
| (In millions, except per share amounts) | March 31, 2024 |  | March 31, 2023 |  |  |  |  |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 33.0 |  |  | $ | 37.3 |  |  |  |  |  |
| Less: Earnings allocated to participating securities | 0.1 |  |  | 0.1 |  |  |  |  |  |
| Net income available to common shareholders | $ | 32.9 |  |  | $ | 37.2 |  |  |  |  |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 46.1 |  |  | 46.2 |  |  |  |  |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Non-participating employee stock options, performance awards, and deferred shares to non-employee directors | 0.6 |  |  | 0.7 |  |  |  |  |  |
| Diluted weighted average common shares outstanding | 46.7 |  |  | 46.9 |  |  |  |  |  |
| Basic earnings per share | $ | 0.71 |  |  | $ | 0.81 |  |  |  |  |  |
| Diluted earnings per share | $ | 0.70 |  |  | $ | 0.79 |  |  |  |  |  |

[0000038725-24-000078:notes:44]
There were 0.1 million stock options outstanding for the first quarters ended March 31, 2024 and March 31, 2023, respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-24-000078:notes:45]
EQUITY ROLL FORWARD
The schedules below set forth equity changes in the first quarters ended March 31, 2024 and March 31, 2023:

[0000038725-24-000078:notes:46]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2023 | $ | 4,607 |  |  | $ | 344,717 |  |  | $ | 1,078,512 |  |  |  |  |  |  | $ | (221,114) |  |  | $ | 2,426 |  |  | $ | 1,209,148 |  |  | $ | 1,145 |  |
| Net income | — |  |  | — |  |  | 32,959 |  |  |  |  |  |  | — |  |  | 169 |  |  | 33,128 |  |  | (36) |  |
| Dividends on common stock ($0.250/share) | — |  |  | — |  |  | (11,560) |  |  |  |  |  |  | — |  |  | — |  |  | (11,560) |  |  | — |  |
| Common stock issued | 7 |  |  | 4,043 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 4,050 |  | 0 | — |  |
| Common stock repurchased | (10) |  |  | — |  |  | (9,037) |  |  |  |  |  |  | — |  |  | — |  |  | (9,047) |  |  | — |  |
| Share-based compensation | 5 |  |  | 4,037 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 4,042 |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | (7,174) |  |  | (41) |  |  | (7,215) |  |  | — |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 433 |  |  | — |  |  | 433 |  |  | — |  |
| Balance as of March 31, 2024 | $ | 4,609 |  |  | $ | 352,797 |  |  | $ | 1,090,874 |  |  |  |  |  |  | $ | (227,855) |  |  | $ | 2,554 |  |  | $ | 1,222,979 |  |  | $ | 1,109 |  |
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  |  |  |  |  | Accumulated Other Comprehensive Income/(Loss) |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2022 | $ | 4,619 |  |  | $ | 325,426 |  |  | $ | 969,261 |  |  |  |  |  |  | $ | (231,448) |  |  | $ | 2,276 |  |  | $ | 1,070,134 |  |  | $ | 620 |  |
| Net income | — |  |  | — |  |  | 37,325 |  |  |  |  |  |  | — |  |  | 238 |  |  | 37,563 |  |  | 13 |  |
| Dividends on common stock ($0.225/share) | — |  |  | — |  |  | (10,440) |  |  |  |  |  |  | — |  |  | — |  |  | (10,440) |  |  | — |  |
| Common stock issued | 7 |  |  | 2,931 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 2,938 |  |  | — |  |
| Common stock repurchased | (18) |  |  | — |  |  | (16,032) |  |  |  |  |  |  | — |  |  | — |  |  | (16,050) |  |  | — |  |
| Share-based compensation | 6 |  |  | 3,906 |  |  | — |  |  |  |  |  |  | — |  |  | — |  |  | 3,912 |  |  | — |  |
| Currency translation adjustment | — |  |  | — |  |  | — |  |  |  |  |  |  | 6,471 |  |  | 23 |  |  | 6,494 |  |  | — |  |
| Pension and other post retirement plans, net of taxes | — |  |  | — |  |  | — |  |  |  |  |  |  | 417 |  |  | — |  |  | 417 |  |  | — |  |
| Balance as of March 31, 2023 | $ | 4,614 |  |  | $ | 332,263 |  |  | $ | 980,114 |  |  |  |  |  |  | $ | (224,560) |  |  | $ | 2,537 |  |  | $ | 1,094,968 |  |  | $ | 633 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-24-000078:notes:47]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)
Changes in accumulated other comprehensive income/(loss) by component for the three months ended March 31, 2024 and March 31, 2023, are summarized below:

[0000038725-24-000078:notes:48]
| (In millions) | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| For the three months ended March 31, 2024: |  |  |
| Balance as of December 31, 2023 | $ | (179.3) |  |  | $ | (41.8) |  |  | $ | (221.1) |  |
| Other comprehensive income/(loss) before reclassifications | (7.2) |  |  | — |  |  | (7.2) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.4 |  |  | 0.4 |  |
| Net other comprehensive income/(loss) | (7.2) |  |  | 0.4 |  |  | (6.8) |  |
| Balance as of March 31, 2024 | $ | (186.5) |  |  | $ | (41.4) |  |  | $ | (227.9) |  |
| For the three months ended March 31, 2023: |  |  |  |  |  |
| Balance as of December 31, 2022 | $ | (191.3) |  |  | $ | (40.1) |  |  | $ | (231.4) |  |
| Other comprehensive income/(loss) before reclassifications | 6.5 |  |  | — |  |  | 6.5 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.3 |  |  | 0.3 |  |
| Net other comprehensive income/(loss) | 6.5 |  |  | 0.3 |  |  | 6.8 |  |
| Balance as of March 31, 2023 | $ | (184.8) |  |  | $ | (39.8) |  |  | $ | (224.6) |  |

[0000038725-24-000078:notes:49]
(1) This accumulated other comprehensive income/(loss) component is included in the computation of net periodic pension cost (refer to Note 7 for additional details) and is included in the "Other income, net" line of the Company's condensed consolidated statements of income.

[0000038725-24-000078:notes:50]
(2) Net of tax expense of $0.1 million for the three months ended March 31, 2024 and March 31, 2023, respectively.

[0000038725-24-000078:notes:51]
[same as prior period, unchanged from 0000038725-23-000182:notes:45]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-24-000078:notes:52]
SEGMENT AND GEOGRAPHIC INFORMATION
The accounting policies of the operating segments are the same as those described in Note 1 of the Company's Annual Report on Form 10-K for the year ended December 31, 2023. Revenue is recognized based on the invoice price at the point in time when the customer obtains control of the product, which is typically upon shipment to the customer. The Water and Fueling segments include manufacturing operations and supply certain components and finished goods, both between segments and to the Distribution segment. The Company reports these product transfers between Water and Fueling as inventory transfers as a significant number of the Company's manufacturing facilities are shared across segments for scale and efficiency purposes. The Company reports intersegment transfers from Water to Distribution as intersegment revenue at market prices to properly reflect the commercial arrangement of vendor to customer that exists between the Water and Distribution segments.

[0000038725-24-000078:notes:53]
[same as prior period, unchanged from 0000038725-23-000182:notes:47]

[0000038725-24-000078:notes:54]
[same as prior period, unchanged from 0000038725-23-000182:notes:48]

[0000038725-24-000078:notes:55]
|  | First Quarter Ended |  |  |
| (In millions) | March 31, 2024 |  | March 31, 2023 |  |  |  |  |
|  | Net sales |
| Water Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | $ | 137.9 |  |  | $ | 159.4 |  |  |  |  |  |
| Latin America | 41.3 |  |  | 40.3 |  |  |  |  |  |
| Europe, Middle East & Africa | 52.3 |  |  | 50.4 |  |  |  |  |  |
| Asia Pacific | 20.3 |  |  | 18.8 |  |  |  |  |  |
| Intersegment sales |  |  |  |  |  |  |  |
| United States & Canada | 34.8 |  |  | 37.7 |  |  |  |  |  |
| Total sales | 286.6 |  |  | 306.6 |  |  |  |  |  |
| Distribution |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 147.0 |  |  | 143.0 |  |  |  |  |  |
| Intersegment sales | — |  |  | — |  |  |  |  |  |
| Total sales | 147.0 |  |  | 143.0 |  |  |  |  |  |
| Fueling Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 46.8 |  |  | 54.0 |  |  |  |  |  |
| All other | 15.3 |  |  | 18.7 |  |  |  |  |  |
| Intersegment sales | — |  |  | — |  |  |  |  |  |
| Total sales | 62.1 |  |  | 72.7 |  |  |  |  |  |
| Intersegment Eliminations/Other | (34.8) |  |  | (37.7) |  |  |  |  |  |
| Consolidated | $ | 460.9 |  |  | $ | 484.6 |  |  |  |  |  |
|  | First Quarter Ended |  |  |
|  | March 31, 2024 |  | March 31, 2023 |  |  |  |  |
|  | Operating income/(loss) |
| Water Systems | $ | 47.1 |  |  | $ | 49.0 |  |  |  |  |  |
| Distribution | 1.8 |  |  | 4.7 |  |  |  |  |  |
| Fueling Systems | 18.8 |  |  | 20.8 |  |  |  |  |  |
| Intersegment Eliminations/Other | (19.8) |  |  | (21.9) |  |  |  |  |  |
| Consolidated | $ | 47.9 |  |  | $ | 52.6 |  |  |  |  |  |

[0000038725-24-000078:notes:56]
|  | March 31, 2024 |  | December 31, 2023 |  |  |  |  |
|  | Total assets |  |  |  |  |
| Water Systems | $ | 1,053.7 |  |  | $ | 1,044.4 |  |  |  |  |  |
| Distribution | 402.2 |  |  | 365.6 |  |  |  |  |  |
| Fueling Systems | 254.5 |  |  | 256.4 |  |  |  |  |  |
| Other | 62.7 |  |  | 61.7 |  |  |  |  |  |
| Consolidated | $ | 1,773.1 |  |  | $ | 1,728.1 |  |  |  |  |  |

[0000038725-24-000078:notes:57]
[same as prior period, unchanged from 0000038725-23-000182:notes:51]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-24-000078:notes:58]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022, the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company submitted its response to the expert's final report in February  2023. The Company cannot predict the ultimate outcome of this matter. Any exposure related to this matter is neither probable nor estimable at this time. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position, results of operations, or cash flows.

[0000038725-24-000078:notes:59]
The Company is defending other various claims and legal actions which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-24-000078:notes:60]
At March 31, 2024, the Company had $9.5 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production and finished goods.

[0000038725-24-000078:notes:61]
At March 31, 2024, the Company has a contingent consideration liability with an estimated fair value of $4.5 million that could result in a payment up to $5.0 million if a future profitability milestone is achieved.

[0000038725-24-000078:notes:62]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the three months ended March 31, 2024, are as follows:

[0000038725-24-000078:notes:63]
| (In millions) |  |  |
| Balance as of December 31, 2023 |  | $ | 9.3 |  |
| Accruals related to product warranties |  | 2.7 |  |
| Reductions for payments made |  | (3.1) |  |
| Balance as of March 31, 2024 |  | $ | 8.9 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000038725-24-000078:notes:64]
None of the Company’s directors or officers adopted, modified, or terminated a Rule 10b5-1 trading arrangement or a non-Rule 10b5-1 trading arrangement during the Company’s fiscal quarter ended March 31, 2024.
