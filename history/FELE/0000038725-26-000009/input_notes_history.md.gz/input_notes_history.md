# FELE note change history — 0000038725-25-000162 → 0000038725-25-000178


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-10-30):
[0000038725-25-000178:note_history:1]
At September 30, 2025, the Company had $9.0 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production and finished goods.
  (was, 2025-07-31, similarity 0.9668):
[0000038725-25-000162:note_history:1]
At June 30, 2025, the Company had $8.0 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production and finished goods.

- changed (2025-10-30):
[0000038725-25-000178:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the nine months ended September 30, 2025, are as follows:
  (was, 2025-07-31, similarity 0.9582):
[0000038725-25-000162:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended June 30, 2025, are as follows:

- changed (2025-10-30):
[0000038725-25-000178:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2024 |  | $ | 9.0 |  |
| Accruals related to product warranties |  | 8.5 |  |
| Reductions for payments made |  | (8.5) |  |
| Balance as of September 30, 2025 |  | $ | 9.0 |  |
  (was, 2025-07-31, similarity 0.9724):
[0000038725-25-000162:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2024 |  | $ | 9.0 |  |
| Accruals related to product warranties |  | 5.4 |  |
| Reductions for payments made |  | (5.5) |  |
| Balance as of June 30, 2025 |  | $ | 8.9 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-10-30):
[0000038725-25-000178:note_history:4]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2024, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of September 30, 2025, and for the third quarters and nine months ended September 30, 2025 and September 30, 2024 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the third quarter and nine months ended September 30, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2025. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2024.
  (was, 2025-07-31, similarity 0.9346):
[0000038725-25-000162:note_history:4]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2024, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 30, 2025, and for the second quarters and six months ended June 30, 2025 and June 30, 2024 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the second quarter and six months ended June 30, 2025 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2025. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2024.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-10-30):
[0000038725-25-000178:note_history:5]
| (In millions) |  | September 30, 2025 |  | December 31, 2024 |
| Prudential Agreement |  | $ | 50.0 |  |  | $ | — |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 66.3 |  |  | 41.4 |  |
| Tax increment financing debt |  | 11.5 |  |  | 12.8 |  |
| Foreign subsidiary debt |  | 1.5 |  |  | 0.3 |  |
| Less: unamortized debt issuance costs |  | — |  |  | (0.1) |  |
|  |  | $ | 204.3 |  |  | $ | 129.4 |  |
| Less: current maturities |  | (69.1) |  |  | (117.8) |  |
| Long-term debt |  | $ | 135.2 |  |  | $ | 11.6 |  |
  (was, 2025-07-31, similarity 0.8472):
[0000038725-25-000162:note_history:5]
| (In millions) |  | June 30, 2025 |  | December 31, 2024 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 186.0 |  |  | 41.4 |  |
| Tax increment financing debt |  | 12.2 |  |  | 12.8 |  |
| Foreign subsidiary debt |  | 11.5 |  |  | 0.3 |  |
| Less: unamortized debt issuance costs |  | — |  |  | (0.1) |  |
|  |  | $ | 284.7 |  |  | $ | 129.4 |  |
| Less: current maturities |  | (270.2) |  |  | (117.8) |  |
| Long-term debt |  | $ | 14.5 |  |  | $ | 11.6 |  |

- added (2025-10-30):
[0000038725-25-000178:note_history:6]
Prudential Agreement

- added (2025-10-30):
[0000038725-25-000178:note_history:7]
The Company maintains the Fourth Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with PGIM, Inc. and its affiliates. On May 15, 2024, the Company entered into Amendment No. 1 that increased the total available facility amount from lenders to $250.0 million from $150.0 million and changed the expiration date from July 30, 2024 to May 15, 2027. On September 26, 2025, the Company issued and sold $50.0 million of fixed rate senior notes due September 26, 2032. These senior notes bear an interest rate of 5.01 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of September 30, 2025, there was $200.0 million remaining borrowing capacity under the Prudential Agreement.

- added (2025-10-30):
[0000038725-25-000178:note_history:8]
New York Life Agreement

- added (2025-10-30):
[0000038725-25-000178:note_history:9]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"). On May 15, 2024, the Company entered into Amendment No. 1 to the renewal that increased the total available facility amount from lenders to $250.0 million from $200.0 million and changed the expiration date from July 30, 2024 to May 15, 2027. On September 26, 2025, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2032. These senior notes bear an interest rate of 5.01 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of September 30, 2025, there was $175.0 million remaining borrowing capacity under the New York Life Agreement.

- added (2025-10-30):
[0000038725-25-000178:note_history:10]
As of September 30, 2025, the Company had $66.3 million outstanding borrowings with a weighted-average interest rate of 3.6 percent, $6.4 million in letters of credit outstanding, and $277.3 million of available capacity under the Credit Agreement. As of December 31, 2024, the Company had $41.4 million outstanding borrowings with a weighted-average interest rate of 3.7 percent, $4.5 million in letters of credit outstanding, and $304.1 million of available capacity under the Previous Credit Agreement.

- changed (2025-10-30):
[0000038725-25-000178:note_history:11]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $19.8 million. As of September 30, 2025, there were $1.3 million outstanding borrowings and $18.5 million of available capacity under these lines of credit. As of December 31, 2024, there were $16.8 million overdraft lines of credit with no outstanding borrowings and $16.8 million of available capacity under these lines of credit.
  (was, 2025-07-31, similarity 0.6674):
[0000038725-25-000162:note_history:11]
The Company also has overdraft lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $20.1 million. As of June 30, 2025, there were no outstanding borrowings and $20.1 million of available capacity under these lines of credit. As of December 31, 2024, there were $16.8 million overdraft lines of credit with no outstanding borrowings and $16.8 million of available capacity under these lines of credit.

- removed (2025-10-30):
[0000038725-25-000162:note_history:12]
As of June 30, 2025, the Company had $186.0 million outstanding borrowings with a weighted-average interest rate of 4.3 percent, $4.6 million in letters of credit outstanding, and $159.4 million of available capacity under the Credit Agreement. As of December 31, 2024, the Company had $41.4 million outstanding borrowings with a weighted-average interest rate of 3.7

- removed (2025-10-30):
[0000038725-25-000162:note_history:13]
percent, $4.5 million in letters of credit outstanding, and $304.1 million of available capacity under the Previous Credit Agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-10-30):
[0000038725-25-000178:note_history:14]
| (In millions) |  | September 30, 2025 |  | December 31, 2024 |
| Prudential Agreement |  | $ | 50.0 |  |  | $ | — |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 66.3 |  |  | 41.4 |  |
| Tax increment financing debt |  | 11.5 |  |  | 12.8 |  |
| Foreign subsidiary debt |  | 1.5 |  |  | 0.3 |  |
| Less: unamortized debt issuance costs |  | — |  |  | (0.1) |  |
|  |  | $ | 204.3 |  |  | $ | 129.4 |  |
| Less: current maturities |  | (69.1) |  |  | (117.8) |  |
| Long-term debt |  | $ | 135.2 |  |  | $ | 11.6 |  |
  (was, 2025-07-31, similarity 0.8472):
[0000038725-25-000162:note_history:14]
| (In millions) |  | June 30, 2025 |  | December 31, 2024 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Credit Agreement |  | 186.0 |  |  | 41.4 |  |
| Tax increment financing debt |  | 12.2 |  |  | 12.8 |  |
| Foreign subsidiary debt |  | 11.5 |  |  | 0.3 |  |
| Less: unamortized debt issuance costs |  | — |  |  | (0.1) |  |
|  |  | $ | 284.7 |  |  | $ | 129.4 |  |
| Less: current maturities |  | (270.2) |  |  | (117.8) |  |
| Long-term debt |  | $ | 14.5 |  |  | $ | 11.6 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2025-10-30):
[0000038725-25-000162:note_history:15]
SUBSEQUENT EVENT
In July 2025, the Company began the process of terminating the Franklin Electric Co,, Inc. Pension Plan by making lump sum payments of $59.9 million directly to eligible participants who elected that payment option. Additionally, the Company purchased a single premium group annuity contract from an independent insurance company, in which $30 million in future pension obligations were transferred to the insurance company to pay the outstanding accrued benefits to participants and beneficiaries of the plan.The annuity contract and lump sum payments do not exceed the assets of the plan, there will be no cash or asset contributions made by the Company. Management estimates that the Company will recognize a one-time non-cash pre-tax pension settlement charge of approximately $60 million in the fiscal third quarter of 2025 related to actuarial losses previously recorded in Accumulated Other Comprehensive Loss. The actual charge will depend on finalization of the actuarial and other assumptions. As a result of the plan’s over-funded status, remaining surplus plan assets are expected to be utilized to fund certain employer contributions associated with one of the Company's qualified 401(k) plans.
