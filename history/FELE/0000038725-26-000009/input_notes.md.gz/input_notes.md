# FELE notes — 0000038725-26-000009


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000038725-26-000009:notes:1]
A portion of the Proxy Statement for the Annual Meeting of Shareholders to be held on May 8, 2026 (Part III).


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0000038725-26-000009:notes:2]
Risk Management and Strategy

[0000038725-26-000009:notes:3]
The Company’s data protection and privacy program is designed to help it assess, identify, manage, and mitigate risks relating to cybersecurity threats and incidents. The Company designs its cybersecurity standards, policies, processes and controls to operate in an integrated manner, leveraging applicable industry standards and security frameworks, including the National Institute of Standards and Technology (NIST) Cybersecurity Framework and Center for Internet Security, Inc (CIS) Controls, as guides in supporting its ability to perform such functions.

[0000038725-26-000009:notes:4]
The Company manages its data protection and privacy program, fostering collaboration with partners across business units and functional areas to identify and assess material cybersecurity threats, evaluate their severity, and explore ways to mitigate and manage such risks. Third parties are engaged to assess the Company’s cybersecurity posture and adherence to the NIST Cybersecurity Framework and CIS Controls, and the Company evaluates cybersecurity risks as part of its annual risk assessment process. Cybersecurity risk mitigation strategies and initiatives are developed based on these assessments.

[0000038725-26-000009:notes:5]
As part of the Company’s data protection and privacy program, it maintains a cyber risk management program that seeks to address key risk management concepts, including mission and vision, escalation path for risk mitigation, risk assessments, and risk treatment. The Company does so by conducting a variety of planning and preparedness activities, including employing monitoring tools to identify suspicious or anomalous activity, vulnerabilities, or signs of compromise across its networks, systems, and data. The Company utilizes data from attack surface management tools to produce a prioritized set of vulnerabilities for remediation.  A key area for the program is employee cybersecurity education. The Company’s employees play a key role in cybersecurity and participate in mandatory cybersecurity training, phishing attack simulations, educational events, and receive news bulletins. The Company’s data protection and privacy program is designed to adhere to and adapt to global privacy and data protection laws.

[0000038725-26-000009:notes:6]
The Company has established policies, processes, and controls that are designed to monitor, detect, investigate, respond to, and escalate management of cybersecurity threats and incidents. If the Company experiences a cybersecurity incident, the Company activates an incident response plan, which includes processes to enable it to triage, assess severity of, escalate, contain, investigate, and remediate the incident, as well as to comply with applicable legal obligations and mitigate brand and reputational harm. Based on initial investigation into such incident’s impact to the Company, the actor(s) involved, and other factors, the Company assigns a severity level to an incident, which dictates the escalation path for a given incident. Incidents rising to higher levels of severity and potential materiality are escalated to designated members of the Company’s senior management for further assessment, response, and remediation. Additionally, the Company has established a Cyber Crisis Management Team, responsible for addressing and responding to the most severe cyber incidents. If warranted, senior management notifies the Audit Committee and/or the full Board of Directors, as appropriate. Throughout this process, the Company continues to investigate the incident and, as its understanding of the incident evolves, updates its severity assessment, as necessary.


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0000038725-26-000009:notes:7]
Governance

[0000038725-26-000009:notes:8]
The Company’s cybersecurity program and approach is overseen by its Board of Directors, in coordination with the Audit Committee, and Senior Leadership, along with its Vice President, Information Technology. The Vice President, Information Technology reports to the Chief Administration Officer and has more than 25 years of IT experience with over 10 years of cybersecurity and international business experience. The Board of Directors receives annual reports from Senior Leadership on the Company’s cybersecurity risks. In addition, Senior Leadership updates the Board of Directors, as necessary, regarding any significant cybersecurity incidents. The Board of Directors and Senior Leadership review the strategy, tools, metrics and latest trends affecting cybersecurity utilizing the NIST Cybersecurity Framework and CIS Controls as the foundation for its cybersecurity strategy and approach.


## cyd:CybersecurityRiskMateriallyAffectedOrReasonablyLikelyToMateriallyAffectRegistrantTextBlock

[0000038725-26-000009:notes:9]
The Company’s business strategy, results of operations and financial condition have not been materially affected and are not reasonably likely to be affected by risks from cybersecurity threats, including as a result of previously identified cybersecurity incidents, but it cannot provide assurance that they will not be materially affected in the future by such risks or any future material incidents. For more information on the Company’s information technology related risks, see Item 1A Risk Factors of this Annual Report on Form 10-K.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000038725-26-000009:notes:10]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
Company--“Franklin Electric” or the “Company” shall refer to Franklin Electric Co., Inc. and its consolidated subsidiaries.

[0000038725-26-000009:notes:11]
Fiscal Year--The financial statements and accompanying notes are as of and for the years ended December 31, 2025, December 31, 2024 and December 31, 2023, and referred to as 2025, 2024 and 2023, respectively.

[0000038725-26-000009:notes:12]
Principles of Consolidation--The consolidated financial statements include the accounts of Franklin Electric Co., Inc. and its consolidated subsidiaries. All intercompany transactions have been eliminated.

[0000038725-26-000009:notes:13]
Business Combinations--The Company allocates the purchase price of its acquisitions to the assets acquired, liabilities assumed, and noncontrolling interests based upon their respective fair values at the acquisition date. The Company utilizes management estimates and may use inputs from an independent third-party valuation firm to assist in determining these fair values. The excess of the acquisition price over estimated fair values of the net assets acquired is recorded as goodwill. Goodwill is adjusted for any changes to acquisition date fair value amounts made within the measurement period, which may be up to one year from the acquisition date. If the preliminary, estimated fair values of the net assets acquired are in excess of the acquisition price, that represents a bargain purchase gain, and the Company records this amount in "Accrued expenses and other current liabilities" on the consolidated balance sheet until it completes its determination of fair values for the net assets acquired. Once that fair value determination is completed, the bargain purchase gain is recognized on the consolidated statements of income in "Other income, net". Acquisition-related transaction costs are recognized separately from the business combination and expensed as incurred.

[0000038725-26-000009:notes:14]
Revenue Recognition--Revenue is recognized when promised goods or services are transferred to customers in an amount that reflects the consideration to which the entity expects to be entitled to in exchange for those goods or services. The promise in a contract to transfer goods or services to a customer represents a performance obligation. The Company typically sells its products to customers by purchase order and does not have any additional performance obligations included in contracts to customers. Shipping and handling activities are considered to be fulfillment activities and are not considered to be a separate performance obligation. Therefore, the Company allocates the transaction price based on a single performance obligation. The Company typically ships products Free on Board (FOB) shipping point at which point control of the products passes to the customers. The Company considers the performance obligation satisfied and recognizes revenue at a point in time, the time of shipment. The Company applies a practical expedient to expense as incurred costs to obtain a contract with a customer when the amortization period would have been one year or less as well as applies the financing component practical expedient when the duration of the financing is one year or less.

[0000038725-26-000009:notes:15]
The Company’s products may include routine assurance-type warranties which do not qualify as separate performance obligations. In the event that significant post-shipment obligations were to exist for the Company’s products, revenue recognition would be deferred until the performance obligations were satisfied.

[0000038725-26-000009:notes:16]
The Company records net sales after discounts at the time of sale based on specific discount programs in effect, related historical data, and experience.

[0000038725-26-000009:notes:17]
The following table disaggregates the Company's net sales from contracts with customers by segment:

[0000038725-26-000009:notes:18]
| Net Sales |
| (In millions) | 2025 |  | 2024 |  | 2023 |
| Water Systems |  |  |  |  |  |
| External sales |  |  |  |  |  |
| United States & Canada | $ | 607.9 |  |  | $ | 586.6 |  |  | $ | 636.0 |  |
| Latin America | 204.7 |  |  | 170.9 |  |  | 174.2 |  |
| Europe, Middle East & Africa | 218.1 |  |  | 211.4 |  |  | 198.3 |  |
| Asia Pacific | 100.9 |  |  | 93.2 |  |  | 86.8 |  |
| Intersegment sales |  |  |  |  |  |
| United States & Canada | 124.8 |  |  | 121.9 |  |  | 108.4 |  |
| Total sales | 1,256.4 |  |  | 1,184.0 |  |  | 1,203.7 |  |
| Distribution |  |  |  |  |  |
| External sales |  |  |  |  |  |
| United States & Canada | 700.7 |  |  | 685.5 |  |  | 673.3 |  |
| Total sales | 700.7 |  |  | 685.5 |  |  | 673.3 |  |
| Energy Systems |  |  |  |  |  |
| External sales |  |  |  |  |  |
| United States & Canada | 229.0 |  |  | 212.4 |  |  | 220.9 |  |
| All other | 70.0 |  |  | 61.3 |  |  | 75.6 |  |
| Total sales | 299.0 |  |  | 273.7 |  |  | 296.5 |  |
| Intersegment Eliminations/Other | (124.8) |  |  | (121.9) |  |  | (108.4) |  |
| Consolidated | $ | 2,131.3 |  |  | $ | 2,021.3 |  |  | $ | 2,065.1 |  |

[0000038725-26-000009:notes:19]
Shipping and Handling Costs--Shipping and handling costs are considered activities required to fulfill the Company’s promise to transfer goods, and do not qualify as a separate performance obligation. Shipping and handling costs in the Company's Water Systems and Energy Systems segments are recorded as a component of cost of sales whereas shipping and handling costs in the Company's Distribution segment are recorded as a component of selling, general and administrative expenses.

[0000038725-26-000009:notes:20]
Research and Development Expense--The Company’s research and development activities are charged to expense in the period incurred. The Company incurred expenses of approximately $20.0 million in 2025, $21.5 million in 2024, and $17.7 million in 2023 related to research and development.

[0000038725-26-000009:notes:21]
Cash and Cash Equivalents--The Company considers cash on hand, demand deposits, and highly liquid investments with an original maturity date of three months or less to be cash and cash equivalents.

[0000038725-26-000009:notes:22]
Fair Value of Financial Instruments--Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. The standard established a fair value hierarchy which requires an entity to maximize the use of observable inputs and to minimize the use of unobservable inputs when measuring fair value. The three levels of inputs that may be used to measure fair value within the hierarchy are as follows:

[0000038725-26-000009:notes:23]
Level 1 – Quoted prices for identical assets and liabilities in active markets;

[0000038725-26-000009:notes:24]
Level 2 – Quoted prices for similar assets and liabilities in active markets, quoted prices for identical or similar assets and liabilities in markets that are not active, and model-derived valuations in which all significant inputs and significant value drivers are observable in active markets; and

[0000038725-26-000009:notes:25]
Level 3 – Valuations derived from valuation techniques in which one or more significant inputs or significant value drivers are unobservable.

[0000038725-26-000009:notes:26]
Accounts Receivable, Earned Discounts, and Allowance for Credit Losses--Accounts receivable are stated at estimated net realizable value. Accounts receivable are comprised of balances due from customers, net of earned discounts and estimated allowances for credit losses. Earned discounts are based on specific customer agreement terms. In determining allowances for credit losses, historical collection experience, current trends and reasonable, supportable future forecasts, aging of accounts receivable, and periodic credit evaluations of customers’ financial condition are reviewed.

[0000038725-26-000009:notes:27]
Inventories--Inventories are stated at the lower of cost or net realizable value. The majority of the cost of inventories is determined using the first in, first out (FIFO) method with a portion of inventory costs determined using the average cost method. The Company reviews its inventories for excess or obsolete products or components based on an analysis of historical usage and management’s evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts.

[0000038725-26-000009:notes:28]
Property, Plant, and Equipment--Property, plant, and equipment are stated at historical cost. The Company capitalizes certain computer software and software development costs incurred in connection with developing or obtaining computer software for internal use, which are included in property, plant, and equipment. Depreciation of property, plant and equipment is calculated on a straight line basis over the following estimated useful lives:

[0000038725-26-000009:notes:29]
| Land improvement and buildings | 10 - 40 years |
| Machinery and equipment | 5 - 10 years |
| Software | 3 - 7 years |
| Furniture and fixtures | 3 - 7 years |

[0000038725-26-000009:notes:30]
Maintenance, repairs, and renewals of a minor nature are expensed as incurred. Betterments and major renewals which extend the useful lives or add to the productive capacity of buildings, improvements, and equipment are capitalized. The Company reviews its property, plant, and equipment for impairment at the asset group level whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. If an indicator is present, the Company compares carrying values to undiscounted future cash flows; if the undiscounted future cash flows are less than the carrying value, an impairment would be recognized for the difference between the fair value and the carrying value.

[0000038725-26-000009:notes:31]
The Company’s depreciation expense was $39.3 million, $37.2 million, and $35.1 million in 2025, 2024, and 2023, respectively.

[0000038725-26-000009:notes:32]
Leases--The Company determines if an arrangement is a lease, or contains a lease, at the inception of the arrangement and determines whether it is an operating or financing lease. Operating and financing leases result in the Company recording a right-of-use ("ROU") asset, current lease liability, and long term lease liability on its balance sheet. The Company has elected to not present leases with an initial term of 12 months or less on the balance sheet. The ROU assets and liabilities are initially recognized based on the present value of lease payments over the lease term. Initial direct costs and lease incentives are generally not material when measuring the ROU asset present value. Lease expense for operating lease payments is recognized on a straight-line basis over the lease term.

[0000038725-26-000009:notes:33]
In determining the present value of the ROU liability, the Company utilizes interest rates from lease agreements unless the lease agreement does not provide a readily determinable rate. In these instances, the Company utilizes its incremental borrowing rate based on the Company’s borrowing information available at inception of the lease. A portion of the Company’s leases include renewal options. The Company excludes these renewal options in the expected lease term unless the Company is reasonably certain that the option will be exercised. In addition, the Company has elected not to separate non-lease components from lease components when initially recording the ROU asset and liability.

[0000038725-26-000009:notes:34]
Goodwill and Other Intangible Assets--Goodwill is the excess of the purchase price over the fair value of acquired assets and liabilities in a business combination. Goodwill is not amortized but is subject to an impairment review annually and whenever indicators of impairment exist. The Company has the option to assess goodwill for impairment by initially performing a qualitative assessment to determine whether it is more-likely-than-not that the fair value of a reporting unit is less than its carrying amount. If the Company determines that it is not more-likely-than-not that the fair value of a reporting unit is less than its carrying amount, then the quantitative goodwill impairment test is not required to be performed. If the Company determines that it is more-likely-than-not that the fair value of a reporting unit is less than its carrying amount, or if it does not elect the option to perform an initial qualitative assessment, the Company performs a quantitative goodwill impairment test. In the quantitative impairment test, the Company calculates the estimated fair value of the reporting unit. If the carrying amount of the reporting unit exceeds the estimated fair value, an impairment charge is recorded for the amount that its carrying amount, including goodwill, exceeds its fair value, limited to the total amount of goodwill allocated to that reporting unit.

[0000038725-26-000009:notes:35]
Indefinite-lived intangible assets, such as certain trade names with indefinite lives, are subject to an impairment review annually and whenever indicators of impairment exist. The Company has the option to assess indefinite-lived intangible assets for impairment by first performing qualitative assessments to determine whether it is more-likely-than-not that the fair values of the indefinite-lived intangible assets are less than the carrying amounts. If the Company determines that it is more-likely-than-not that an indefinite-lived intangible asset is impaired, or if the Company elects not to perform an initial qualitative assessment, the Company then performs the quantitative impairment test by comparing the fair value of the indefinite-lived intangible asset with its carrying amount. If the carrying amount exceeds the fair value of the indefinite-lived intangible asset, the Company writes the carrying amount down to the fair value.

[0000038725-26-000009:notes:36]
Amortization is recorded and calculated for definite-lived intangible assets on a basis that reflects cash flows over the estimated useful lives. The estimated useful lives over which each intangible class is amortized is as follows:

[0000038725-26-000009:notes:37]
| Customer relationships | 8 - 20 years |
| Patents | 17 years |
| Technology | 15 years |
| Trade names | 5 - 20 years |
| Other | 5 - 8 years |

[0000038725-26-000009:notes:38]
Definite-lived intangible assets are evaluated for impairment whenever a triggering event, including a significant change in the use of the asset or unexpected change in financial condition, occurs that indicates the carrying value may be impaired. The Company tests for impairment at the asset group level by comparing the carrying value of an asset group that includes the applicable definite lived intangible asset(s) to that asset group's undiscounted future cash flows. An impairment exists if the carrying value of the definite-lived intangible asset(s) is higher than the fair value, and the Company would record an impairment charge for the difference.

[0000038725-26-000009:notes:39]
Warranty Obligations--The Company provides warranties on most of its products. The warranty terms vary but are generally 2 years to 5 years from the date of manufacture or 1 year to 5 years from the date of installation. Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified. These estimates are established using historical information about the nature, frequency, and average cost of warranty claims. The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.

[0000038725-26-000009:notes:40]
Income Taxes--Deferred tax assets and liabilities are determined based on the difference between the financial statement and tax basis of assets and liabilities and net operating loss and credit carry forwards using enacted tax rates in effect for the year in which the differences are expected to reverse. Valuation allowances are established when necessary to reduce deferred tax assets to the amounts expected to be realized. The Company records a liability for uncertain tax positions by establishing a more likely than not recognition threshold and measurement attribute for recognition and measurement of a tax position taken or expected to be taken in a tax return.

[0000038725-26-000009:notes:41]
Defined Benefit Plans--The Company makes its determination for pension, post retirement, and post employment benefit plans liabilities based on management estimates and consultation with actuaries. The Company incorporates estimates and assumptions of future plan service costs, future interest costs on projected benefit obligations, rates of compensation increases, employee turnover rates, anticipated mortality rates, expected investment returns on plan assets, asset allocation assumptions of plan assets, and other factors.

[0000038725-26-000009:notes:42]
Earnings Per Common Share--The Company utilizes the two-class method to compute earnings available to common shareholders. Under the two-class method, the Company allocates net earnings to each class of common stock and participating security as if all of the net earnings for the period had been distributed. The Company’s participating securities consist of share-based payment awards that contain a non-forfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders. Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period. Diluted earnings per common share is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards and non-employee deferred shares.

[0000038725-26-000009:notes:43]
Translation of Foreign Currency Financial Statements--All assets and liabilities of foreign subsidiaries in functional currency other than the U.S. dollar are translated at year end exchange rates with the exception of the non-monetary assets and liabilities

[0000038725-26-000009:notes:44]
in countries with highly inflationary economies, which are translated at historical exchange rates. All revenue and expense accounts are translated at average rates in effect during the respective period with the exception of expenses related to the non-monetary assets and liabilities, which are translated at historical exchange rates. Adjustments for translating longer term foreign currency assets and liabilities in U.S. dollars are included as a component of other comprehensive income/(loss) except for hyperinflation accounting adjustments. Transaction gains and losses that arise from shorter term exchange rate fluctuations and hyperinflation accounting adjustments are included in “Foreign exchange expense, net” within the Company’s consolidated statements of income, as incurred.  The Company's operations in Argentina and Turkey have been accounted for using the highly inflationary accounting rules since 2018 and 2022, respectively.

[0000038725-26-000009:notes:45]
Significant Estimates--The preparation of financial statements in conformity with accounting principles generally accepted in the United States requires management to make significant estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of expenses during the reporting periods. Although the Company regularly assesses these estimates, actual results could materially differ. The Company bases its estimates on historical experience and various other assumptions that it believes to be reasonable under the circumstances.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000038725-26-000009:notes:46]
ACCOUNTING PRONOUNCEMENTS
Adoption of New Accounting Standards

[0000038725-26-000009:notes:47]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures. ASU 2023-09 is intended to enhance the transparency and decision usefulness of income tax disclosures. This amendment modifies the rules on income tax disclosures to require entities to disclose (1) specific categories in the rate reconciliation and additional information for reconciling items that meet a quantitative threshold, (2) the amount of income taxes paid (net of refunds received) (disaggregated by federal, state, and foreign taxes) as well as individual jurisdictions in which income taxes paid is equal to or greater than 5 percent of total income taxes paid net of refunds, (3) the income or loss from continuing operations before income tax expense or benefit (disaggregated between domestic and foreign) and (4) income tax expense or benefit from continuing operations (disaggregated by federal, state and foreign). ASU 2023-09 is effective for annual periods beginning after December 15, 2024, with early adoption permitted. ASU 2023-09 should be applied on a prospective basis, while retrospective application is permitted. The Company adopted this ASU prospectively, effective with its 2025 annual financial statements and the adoption did not have a material impact on its financial statements.

[0000038725-26-000009:notes:48]
Accounting Standards Issued But Not Yet Adopted

[0000038725-26-000009:notes:49]
In November 2024, the FASB issued ASU 2024-03, Income Statement - Reporting Comprehensive Income - Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, which requires additional disclosure of the nature of expenses included in the income statement. The standard requires disclosures about specific types of expenses included in the expense captions presented in the income statement. This ASU is effective for fiscal years beginning after December 15, 2026, and interim periods beginning after December 15, 2027, with early adoption permitted. The requirements should be applied on a prospective basis while retrospective application is permitted. The Company is currently evaluating the impact that the adoption of this guidance will have on its disclosures.

[0000038725-26-000009:notes:50]
In July 2025, the FASB issued ASU 2025-05, Financial Instruments — Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets. ASU 2025-05 provides an optional practical expedient to simplify the measurement of credit losses for certain receivables and contract assets. ASU 2025-05 is effective for interim and annual periods beginning after December 15, 2025, with early adoption permitted. The guidance is to be applied prospectively. The Company will adopt this ASU in 2026 and does not anticipate the adoption to have material impact on the Company's financial statements.

[0000038725-26-000009:notes:51]
In September 2025, the FASB issued ASU 2025-06, Intangibles – Goodwill and Other – Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software. ASU 2025-06 removes all references to software development project stages and requires entities to start capitalizing software costs when both of the following occur: (i) management has authorized and committed to funding the software project and (ii) it is probable that the project will be completed and the software will be used to perform the function intended. ASU 2025-06 is effective for interim and annual periods beginning after December 15, 2027, with early adoption permitted. The guidance can be applied prospectively, retrospectively, or utilizing a modified transition method. The Company is currently evaluating the impact of this ASU on the Company's financial statements.

[0000038725-26-000009:notes:52]
In December 2025, the FASB issued ASU 2025-11, Interim Reporting (Topic 270): Narrow-Scope Improvements. ASU 2025-11 amends the existing guidance in ASC 270 to clarify the applicability, form, and content of interim financial statements and to improve the organization and usability of interim reporting requirements. The amendments introduce a disclosure principle requiring entities to provide information about events and changes that occur since the most recent annual reporting

[0000038725-26-000009:notes:53]
period that could have a material impact on the entity.  This ASU also compiles interim disclosure requirements within ASC 270 and other Topics into a single location. ASU 2025-11 is effective for interim periods within annual periods beginning after December 15, 2027, with early adoption permitted. The guidance can be applied prospectively or retrospectively. The Company is currently evaluating the impact of this ASU on the Company’s financial statements and disclosures.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-26-000009:notes:54]
ACQUISITIONS
2025

[0000038725-26-000009:notes:55]
Barnes

[0000038725-26-000009:notes:56]
In March 2025, the Company acquired 100 percent of Barnes de Colombia S.A. ("Barnes"), a leading manufacturer and distributor of industrial and commercial pumps based in Cota, Cundinamarca, Colombia, for total upfront cash consideration of $96.8 million, net of cash acquired.

[0000038725-26-000009:notes:57]
The valuation of assets acquired and liabilities assumed has not yet been finalized as of December 31, 2025. As a result, the Company recorded preliminary estimates for the fair value of assets acquired and liabilities assumed as of the acquisition date. Finalization of the valuation during the measurement period could result in a change in the amounts recorded for the acquisition date fair value of intangible assets, goodwill and income taxes among other items. The completion of the valuation will occur no later than one year from the acquisition date. The following table summarizes the preliminary fair values of the assets acquired and liabilities assumed as of the acquisition date:

[0000038725-26-000009:notes:58]
| (in millions) |  |
| Assets acquired and liabilities assumed |  |
| Cash and cash equivalents | $ | 3.4 |  |
| Receivables | $ | 9.6 |  |
| Inventories | $ | 23.6 |  |
| Other current assets | $ | 3.9 |  |
| Property, plant and equipment | $ | 13.5 |  |
| Goodwill | $ | 44.5 |  |
| Other intangible assets | $ | 45.5 |  |
| Other non-current assets | $ | 3.6 |  |
| Debt | $ | (13.8) |  |
| Accounts payable | $ | (9.8) |  |
| Accrued expenses and other current liabilities | $ | (2.4) |  |
| Deferred tax liabilities | $ | (18.6) |  |
| Other non-current liabilities | $ | (2.8) |  |
| Total assets acquired and liabilities assumed | $ | 100.2 |  |

[0000038725-26-000009:notes:59]
The Company allocated $33.4 million of the total consideration to customer relationships with a useful life of 8 years, $9.3 million to trade names with a useful life of 11 years, and $2.8 million to developed technology with a useful life of 7 years. The fair values of the intangible assets were determined using the income approach. The Company considers the fair value of the intangible assets to be Level 3 measurements due to the significant estimates and assumptions used by management in establishing the estimated fair values. In 2025, the Company recorded various immaterial measurement period adjustments, resulting in a decrease to goodwill of $1.3 million. The measurement period adjustments did not have a significant impact on the Company’s results of operations.

[0000038725-26-000009:notes:60]
The goodwill, which is not deductible for tax purposes, includes the value of an assembled workforce, potential future technologies as well as the overall strategic benefits provided to the Company’s product portfolio and is included in the Water Systems segment.

[0000038725-26-000009:notes:61]
The results of operations of the acquired business have been included in the Company’s consolidated statement of income since the date the business was acquired. The Barnes acquisition contributed $38.8 million of net sales for the twelve months ended December 31, 2025 while the impact on net income was not significant. The Company has not presented pro forma financial information for the Barnes acquisition because its results are not material to the Company’s condensed consolidated financial statements.

[0000038725-26-000009:notes:62]
PumpEng

[0000038725-26-000009:notes:63]
In February 2025, the Company acquired 100 percent of the ownership interests of PumpEng Pty Ltd ("PumpEng") for a purchase price of AUD 24.0 million (approximately $15.0 million). PumpEng, based in Australia, specializes in the design, manufacture and service of submersible pumps for the mining sector. The fair value of the assets acquired and liabilities assumed is final as of December 31, 2025.

[0000038725-26-000009:notes:64]
The Company has not included various disclosures for the PumpEng acquisition including presenting separate results of operations of the acquired company since the closing of the acquisition or combined pro forma financial information of the Company and the acquired business, as the Company does not consider the acquisition to be material.

[0000038725-26-000009:notes:65]
2024

[0000038725-26-000009:notes:66]
During the fourth quarter ended December 31, 2024, the Company acquired substantially all of the assets of FSHS Incorporated, a water treatment systems distributor.  The all-cash purchase price for the acquisition was $4.5 million. The fair value of the assets acquired and liabilities assumed is final as of December 31, 2025.

[0000038725-26-000009:notes:67]
2023

[0000038725-26-000009:notes:68]
During the fourth quarter ended December 31, 2023, the Company acquired substantially all of the assets of Aqua Systems of Fort Myers, a water treatment systems distributor.  In another separate transaction, the Company acquired substantially all of the assets of Action Manufacturing and Supply, Inc., a water treatment equipment provider located in southwest Florida. The Company also acquired, in a separate transaction, substantially all of the assets of LCA Pump, LLC, which operates Water Works Pump, a Missouri based professional groundwater distributor. The combined, all-cash purchase price for the acquisitions in the fourth quarter of 2023 was $36.0 million, including contingent consideration with an estimated fair value of $4.3 million, after purchase price adjustments based on the level of working capital acquired. In 2024, the Company recorded a measurement period adjustment of $1.3 million to increase the acquisition-date fair value of the contingent consideration transferred. The measurement period adjustment resulted in an increase to acquired identifiable intangible assets of $2.3 million and a reduction to acquired goodwill of $1.0 million. The measurement period adjustments did not have a significant impact on the Company’s results of operations.

[0000038725-26-000009:notes:69]
During the first quarter ended March 31, 2023, the Company acquired substantially all of the assets of Phil-Good Products, Inc. ("Phil-Good"). Phil-Good is an injection molded plastics component manufacturer. In another separate transaction in the first quarter of 2023, the Company acquired 100 percent of the ownership interests of Hydropompe S.r.l. ("Hydropompe"). Hydropompe is a pump manufacturer with a focus in dewatering and sewage products. The combined, all-cash purchase price for both acquisitions in the first quarter of 2023 was $8.7 million after purchase price adjustments based on the level of working capital acquired.

[0000038725-26-000009:notes:70]
The fair value of the assets acquired and liabilities assumed for all 2023 acquisitions was final as of December 31, 2024.

[0000038725-26-000009:notes:71]
The Company has not included various disclosures for the 2023 through 2025 acquisitions including presenting separate results of operations of any of the acquired companies since the closing of the acquisitions or combined pro forma financial information of the Company and the acquired interests, as the Company does not consider any of the acquisitions to be material individually or in the aggregate.
Transaction costs for all acquisition-related activity were expensed as incurred under the guidance of FASB ASC Topic 805, Business Combinations. Transaction costs are included in the "Selling, general, and administrative expenses" line of the Company’s consolidated statements of income and were $2.4 million for the year ended December 31, 2025, and immaterial for all other periods presented.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-26-000009:notes:72]
GOODWILL AND OTHER INTANGIBLE ASSETS
The carrying amounts of the Company’s intangible assets, excluding goodwill, are as follows:

[0000038725-26-000009:notes:73]
| (In millions) |  | 2025 |  | 2024 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortizing intangibles: |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 309.5 |  |  | $ | (149.7) |  |  | $ | 263.4 |  |  | $ | (128.8) |  |
| Patents |  | 7.4 |  |  | (7.4) |  |  | 7.2 |  |  | (7.2) |  |
| Technology |  | 10.5 |  |  | (7.8) |  |  | 7.5 |  |  | (7.5) |  |
| Trade names |  | 58.6 |  |  | (11.6) |  |  | 44.5 |  |  | (8.1) |  |
| Other |  | 3.1 |  |  | (2.5) |  |  | 2.8 |  |  | (2.4) |  |
| Total |  | $ | 389.1 |  |  | $ | (179.0) |  |  | $ | 325.4 |  |  | $ | (154.0) |  |
| Non-amortizing intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 41.6 |  |  | — |  |  | 41.6 |  |  | — |  |
| Total intangibles |  | $ | 430.7 |  |  | $ | (179.0) |  |  | $ | 367.0 |  |  | $ | (154.0) |  |

[0000038725-26-000009:notes:74]
Amortization expense related to intangible assets for the years ended December 31, 2025, 2024, and 2023, was $23.6 million, $18.8 million, and $17.1 million, respectively.

[0000038725-26-000009:notes:75]
Amortization expense for each of the five succeeding years is projected as follows:

[0000038725-26-000009:notes:76]
| (In millions) |  | 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 |
|  |  | $ | 24.0 |  |  | $ | 22.5 |  |  | $ | 21.9 |  |  | $ | 20.9 |  |  | $ | 20.3 |  |

[0000038725-26-000009:notes:77]
The change in the carrying amount of goodwill by reportable segment for 2025 and 2024, is as follows:

[0000038725-26-000009:notes:78]
| (In millions) |  | Water Systems |  | Energy Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2023 |  | $ | 221.4 |  |  | $ | 70.4 |  |  | $ | 50.6 |  |  | $ | 342.4 |  |
| Acquisitions |  | 0.8 |  |  | — |  |  | — |  |  | 0.8 |  |
| Adjustments to prior year acquisitions |  | (1.0) |  |  | — |  |  | — |  |  | (1.0) |  |
| Foreign currency translation |  | (3.6) |  |  | (0.1) |  |  | — |  |  | (3.7) |  |
| Balance as of December 31, 2024 |  | $ | 217.6 |  |  | $ | 70.3 |  |  | $ | 50.6 |  |  | $ | 338.5 |  |
| Acquisitions |  | 55.2 |  |  | — |  |  | — |  |  | 55.2 |  |
| Adjustments to prior year acquisitions |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Foreign currency translation |  | 4.1 |  |  | 0.2 |  |  | — |  |  | 4.3 |  |
| Balance as of December 31, 2025 |  | $ | 277.0 |  |  | $ | 70.5 |  |  | 50.6 |  |  | $ | 398.1 |  |


## us-gaap:AccountsPayableAndAccruedLiabilitiesDisclosureTextBlock

[0000038725-26-000009:notes:79]
ACCRUED EXPENSES AND OTHER CURRENT LIABILITIES
Accrued expenses and other current liabilities consist of:

[0000038725-26-000009:notes:80]
| (In millions) |  | 2025 |  | 2024 |
| Salaries, wages, and commissions |  | $ | 49.2 |  |  | $ | 49.0 |  |
| Product warranty costs |  | 9.1 |  |  | 9.0 |  |
| Insurance |  | 3.3 |  |  | 2.4 |  |
| Employee benefits |  | 20.7 |  |  | 19.9 |  |
| Other |  | 25.7 |  |  | 39.5 |  |
|  |  | $ | 108.0 |  |  | $ | 119.8 |  |


## us-gaap:DebtDisclosureTextBlock

[0000038725-26-000009:notes:81]
DEBT
Debt consisted of the following:

[0000038725-26-000009:notes:82]
| (In millions) |  | 2025 |  | 2024 |
| New York Life Agreement |  | $ | 75.0 |  |  | $ | 75.0 |  |
| Prudential Agreement |  | 50.0 |  |  | — |  |
| Credit Agreement |  | 30.0 |  |  | 41.4 |  |
| Project Bonds |  | 11.5 |  |  | 12.8 |  |
| Foreign subsidiary debt |  | 0.6 |  |  | 0.3 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | 167.0 |  |  | 129.4 |  |
| Less current maturities |  | (31.8) |  |  | (117.8) |  |
| Long-term debt |  | $ | 135.2 |  |  | $ | 11.6 |  |

[0000038725-26-000009:notes:83]
Debt outstanding at December 31, 2025, excluding unamortized debt issuance costs, matures as follows:

[0000038725-26-000009:notes:84]
| (In millions) |  | Total |  | 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 |  | Thereafter |
| Debt |  | $ | 167.1 |  |  | $ | 31.8 |  |  | $ | 1.5 |  |  | $ | 1.5 |  |  | $ | 1.5 |  |  | $ | 1.6 |  |  | $ | 129.2 |  |

[0000038725-26-000009:notes:85]
New York Life Agreement

[0000038725-26-000009:notes:86]
On May 27, 2015, the Company entered into an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the “New York Life Agreement”) for $150.0 million maximum aggregate principal borrowing capacity. On October 28, 2016, the Company entered into the First Amendment to the Note Purchase and Private Shelf Agreement. The Amendment was intended to make the covenants within the New York Life Agreement consistent with the covenants that were modified in the Third Amended and Restated Credit Agreement. On September 26, 2018, the Company entered into the Second Amendment to the Note Purchase and Private Shelf Agreement which increased the aggregate borrowing capacity to $200.0 million and authorized the issuance of $75.0 million of fixed rate senior noted due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable rate indebtedness with New York Life. On July 30, 2021, the New York Life agreement was renewed with an expiration date of July 30, 2024. On May 15, 2024, the Company entered into Amendment No. 1 to the renewal that increased the total available facility amount from lenders to $250.0 million from $200.0 million and changed the expiration date from July 30, 2024 to May 15, 2027. On September 26, 2025, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2032. These senior notes bear an interest rate of 5.01 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of December 31, 2025, there was $175.0 million of remaining borrowing capacity under the New York Life Agreement.

[0000038725-26-000009:notes:87]
Prudential Agreement

[0000038725-26-000009:notes:88]
On April 9, 2007, the Company entered into the uncommitted and unsecured Amended and Restated Note Purchase and Private Shelf Agreement (the “Prudential Agreement”) in the amount of $175.0 million. Under the Prudential Agreement, the Company issued notes in an aggregate principal amount of $110.0 million on April 30, 2007 (the “B-1 Notes”) and $40.0 million on September 7, 2007 (the “B-2 Notes”). The B-1 Notes and B-2 Notes bear a coupon of 5.79 percent and had, at issuance, an average life of 10 years with a final maturity in 2019. On July 22, 2010, the Company entered into Amendment No. 3 to the Prudential Agreement to increase its borrowing capacity by $25.0 million. On December 14, 2011, the Company entered into Amendment No. 4 to the Second Amended and Restated Note Purchase and Private Shelf Agreement to redefine the debt to EBITDA ratio covenant in order to be equivalent to that under the Agreement. On December 31, 2012, the Company and Prudential Insurance Company of America entered into an amendment to the Second Amended and Restated Note Purchase and Private Shelf Agreement to extend the effective date to December 31, 2015. On May 5, 2015, the Company entered into Amendment No. 6 to the Second Amended and Restated Note Purchase and Private Shelf Agreement. This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees. On May 28, 2015, the Company entered into a Third Amended and Restated Note Purchase and Private Shelf Agreement with Prudential to increase the total borrowing capacity from $200.0 million to $250.0 million. On October 28, 2016, the Company entered into Amendment No. 1 to the Third Amended and Restated Note Purchase and Private Shelf Agreement. This amendment was intended to make the covenants within the Prudential Agreement consistent with the covenants that were modified in the Credit Agreement (below). On July 30, 2021, the Company entered into the Fourth Amended and Restated Note Purchase and Private Shelf Agreement, which reduced the borrowing capacity to $150.0 million

[0000038725-26-000009:notes:89]
and extended the expiration date to July 30, 2024. On May 15, 2024, the Company entered into Amendment No. 1 to the Fourth Amended and Restated Note Purchase and Private Shelf Agreement that increased the total available facility amount from lenders to $250.0 million from $150.0 million and changed the expiration date from July 30, 2024 to May 15, 2027. On September 26, 2025, the Company issued and sold $50.0 million of fixed rate senior notes due September 26, 2032. These senior notes bear an interest rate of 5.01 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of December 31, 2025, the Company has $200.0 million borrowing capacity available under the Prudential Agreement.

[0000038725-26-000009:notes:90]
Credit Agreement

[0000038725-26-000009:notes:91]
On May 13, 2021, the Company entered into the Fourth Amended and Restated Credit Agreement (the “Previous Credit Agreement”). The Previous Credit Agreement extended the maturity date of the Company’s previous credit agreement to May 13, 2026, and decreased the commitment amount from $300.0 million to $250.0 million. On May 11, 2022, the Company entered into Amendment No. 1 that increased the commitment amount from $250.0 million to $350.0 million. On May 14, 2025, the Company entered into the Fifth Amended and Restated Credit Agreement (the “Credit Agreement”).  The Fifth Amended and Restated Credit Agreement extended the maturity date of the Previous Credit Agreement to May 14, 2030 while keeping the revolving commitment amount unchanged at $350.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $175.0 million (not to exceed a total commitment of $525.0 million) subject to the conditions contained therein. All of the Company’s present and future material domestic subsidiaries unconditionally guaranty all of the Borrowers’ obligations under and in connection with the Credit Agreement. Additionally, the Company unconditionally guaranties all of the obligations of Franklin Electric B.V. under the Credit Agreement. Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100 percent to 0.275 percent (depending on the Company’s leverage ratio) of the aggregate commitment, payable quarterly in arrears. USD loans may be made either at (i) a Secured Overnight Financing Rate (SOFR) Term Benchmark, with a zero percent floor, plus an applicable margin of 0.950 percent to 1.975 percent (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement. EUR loans may be made in Euro Interbank Offer Rate (EURIBOR) Term Benchmark, with a zero percent floor, plus an applicable margin of 0.850 percent to 1.875 percent (depending on the Company’s leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-26-000009:notes:92]
Project Bonds

[0000038725-26-000009:notes:93]
On December 31, 2012, the Company, Allen County, Indiana and certain institutional investors entered into a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project).” The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. The Company then borrowed the proceeds under the Project Bonds through the issuance of Project Notes to finance the cost of acquisition, construction, installation and equipping of the new Global Corporate Headquarters and Engineering Center. These Project Notes (“Tax increment financing debt”) bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033. The use of the proceeds from the Project Notes was limited to assist the financing of the new Global Corporate Headquarters and Engineering Center. On May 5, 2015, the Company entered into Amendment No. 1 to the Bond Purchase and Loan Agreement. This amendment provided for debt repayment guarantees from certain Company subsidiaries and waived certain non-financial covenants related to subsidiary guarantees.

[0000038725-26-000009:notes:94]
As of December 31, 2025, the Company had $30.0 million outstanding borrowings with a weighted-average interest rate of 2.9 percent, $6.4 million in letters of credit outstanding, and $313.6 million of available capacity under the Credit Agreement. As of December 31, 2024, the Company had $41.4 million outstanding borrowings with a weighted average interest rate of 3.7 percent, $4.5 million in letters of credit outstanding, and $304.1 million of available capacity under the Credit Agreement.

[0000038725-26-000009:notes:95]
The Company also has lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $19.7 million. As of December 31, 2025, there were $1.5 million outstanding borrowings and $18.1 million of available capacity under these lines of credit. As of December 31, 2024, there were $16.8 million overdraft lines of credit with no outstanding borrowings and $16.8 million of available capacity under these lines of credit.

[0000038725-26-000009:notes:96]
Covenants

[0000038725-26-000009:notes:97]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the 
granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Credit Agreement, the Prudential Agreement, the Project Bonds, and the New York Life Agreement, but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of December 31, 2025.


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-26-000009:notes:98]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022, the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company submitted its response to the expert's final report in February  2023. The Company cannot predict the ultimate outcome of this matter. Any exposure related to this matter is neither probable nor reasonably estimable at this time. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position,  results of operations, or cash flows.

[0000038725-26-000009:notes:99]
The Company is defending other various claims and legal actions which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-26-000009:notes:100]
At December 31, 2025, the Company had $8.5 million of commitments primarily for capital expenditures and the purchase of raw materials to be used in production.

[0000038725-26-000009:notes:101]
The changes in the carrying amount of the warranty accrual, as recorded in the “Accrued expenses and other current liabilities” line of the Company’s consolidated balance sheets for 2025 and 2024, are as follows:

[0000038725-26-000009:notes:102]
| (In millions) |  | 2025 |  | 2024 |
| Beginning balance |  | $ | 9.0 |  |  | $ | 9.3 |  |
| Accruals related to product warranties |  | 11.5 |  |  | 12.7 |  |
| Reductions for payments made |  | (11.4) |  |  | (13.0) |  |
| Ending balance |  | $ | 9.1 |  |  | $ | 9.0 |  |

[0000038725-26-000009:notes:103]
The Company maintains certain warehouses, distribution centers, office space, and equipment operating leases. The Company also has lease agreements that are classified as financing. However, these financing leases are immaterial to the Company.

[0000038725-26-000009:notes:104]
The components of the Company's operating lease portfolio as of 2025, 2024, and 2023 are as follows:

[0000038725-26-000009:notes:105]
| Lease Cost (In millions): |  | 2025 |  | 2024 |  | 2023 |
| Operating lease cost |  | $ | 22.9 |  |  | $ | 22.0 |  |  | $ | 18.8 |  |
| Variable lease cost |  | $ | 9.3 |  |  | $ | 8.1 |  |  | $ | 7.6 |  |
| Other Information: |  |  |  |  |  |  |
| Weighted-average remaining lease term |  | 4.4 years |  | 4.2 years |  | 4.0 years |
| Weighted-average discount rate |  | 5.5 | % |  | 5.0 | % |  | 4.3 | % |

[0000038725-26-000009:notes:106]
The Company has entered into lease agreements with aggregate future minimum payments of approximately $2.0 million that have not yet commenced as of December 31, 2025.

[0000038725-26-000009:notes:107]
The future minimum rental payments for non-cancellable operating leases as of December 31, 2025, are as follows:

[0000038725-26-000009:notes:108]
| (In millions) | Total |  | 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 |  | Thereafter |
| Undiscounted future minimum rental payments | $ | 77.6 |  |  | $ | 24.4 |  |  | $ | 17.8 |  |  | $ | 13.2 |  |  | $ | 8.4 |  |  | $ | 5.1 |  |  | $ | 8.7 |  |
| Less: Imputed Interest | 10.6 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Present value of lease liabilities | $ | 67.0 |  |  |  |  |  |  |  |  |  |  |  |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-26-000009:notes:109]
Share-based Compensation

[0000038725-26-000009:notes:110]
In 2023, the Company amended The Franklin Electric Co., Inc. 2017 Stock Plan, which is called The Franklin Electric Co., Inc. Amended and Restated 2017 Stock Plan ("the 2017 Amended and Restated Stock Plan") and increased the number of shares available under the Plan by 900,000 to 2,300,000. The 2017 Amended and Restated Stock Plan is a stock-based compensation plan that provides for discretionary grants of stock options, stock awards, stock unit awards, and stock appreciation rights (“SARs”) to key employees and non-employee directors. Stock options and SARs reduce the number of available shares by one share for each share subject to the option or SAR, and stock awards and stock unit awards settled in shares reduce the number of available shares by 1.5 shares for every one share delivered.

[0000038725-26-000009:notes:111]
The Company also maintains the Franklin Electric Co., Inc. 2012 Stock Plan (the “2012 Stock Plan”), which is a share-based compensation plan that provides for discretionary grants of stock options, stock awards and stock unit awards to key employees and non-employee directors.

[0000038725-26-000009:notes:112]
The 2012 Stock Plan authorized 2,400,000 shares for issuance as follows:

[0000038725-26-000009:notes:113]
| 2012 Stock Plan |  | Authorized Shares |
| Stock Options |  | 1,680,000 |
| Stock/Stock Unit Awards |  | 720,000 |

[0000038725-26-000009:notes:114]
No additional options and awards are granted out of the 2012 Stock Plan. However, there are still unvested awards and unexercised options under this plan.

[0000038725-26-000009:notes:115]
The Company currently issues new shares from its common stock balance to satisfy option exercises and the settlement of stock awards and stock unit awards made under the outstanding stock plans.

[0000038725-26-000009:notes:116]
The Company recognizes share-based compensation expense only for the portion of shares that it expects to vest. As such, an estimated forfeiture rate is applied to calculate the share-based compensation expense, which is based on historical forfeiture data. The total share-based compensation expense recognized in 2025, 2024, and 2023 was $13.2 million, $12.1 million, and $10.1 million, respectively. The tax benefit recognized in 2025, 2024, and 2023 was $3.7 million, $5.0 million, and $5.6 million. Included in the benefit in 2025, 2024, and 2023 were excess tax benefits on share-based compensation of $0.6 million,  $2.3 million, and $3.2 million, respectively.

[0000038725-26-000009:notes:117]
Stock Options:

[0000038725-26-000009:notes:118]
Under the above plans, the exercise price of each option equals the market price of the Company’s common stock on the date of grant, and the options expire 10 years after the date of the grant. Options vest at 33 percent a year and become fully vested and fully exercisable after 3 years. Vesting is accelerated upon retirement, death or disability. Subject to the terms of the plans, in general, the aggregate option exercise price and any applicable tax withholding may be satisfied in cash or its equivalent, by the plan participant’s delivery of shares of the Company’s common stock having a fair market value at the time of exercise equal to the aggregate option exercise price and/or the applicable tax withholding or by having shares otherwise subject to the award withheld by the Company or via cashless exercise through a broker-dealer.

[0000038725-26-000009:notes:119]
The fair value of each option award is estimated on the date of grant using the Black-Scholes option valuation model with a single approach and amortized using a straight-line attribution method over the option’s vesting period. Options granted to retirement eligible employees are immediately expensed. The Company uses historical data to estimate the expected volatility of its stock, the weighted average expected life, the period of time options granted are expected to be outstanding, and its dividend yield. The risk-free rates for periods within the contractual life of the option are based on the U.S. Treasury yield curve in effect at the time of the grant.

[0000038725-26-000009:notes:120]
The table below provides the weighted average grant-date fair values and key assumptions used for the Black-Scholes model to determine the fair value of options granted during 2025, 2024, and 2023:

[0000038725-26-000009:notes:121]
|  |  | 2025 |  | 2024 |  | 2023 |
| Risk-free interest rate |  | 4.39 | % |  | 4.38 | % |  | 4.02 | % |
| Dividend yield |  | 1.00 | % |  | 1.03 | % |  | 0.95 | % |
| Volatility factor |  | 32.50 | % |  | 33.01 | % |  | 33.81 | % |
| Expected term |  | 6.0 years |  | 6.0 years |  | 6.0 years |
| Weighted average grant-date fair value of options |  | $ | 38.08 |  |  | $ | 35.03 |  |  | $ | 34.51 |  |

[0000038725-26-000009:notes:122]
A summary of the Company’s outstanding stock option activity and related information is as follows:

[0000038725-26-000009:notes:123]
| (Shares in thousands) |  | Shares |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | AggregateIntrinsic Value (000’s) |
| Stock Options |  |  |  |  |
| Outstanding at beginning of 2025 |  | 861 |  |  | $ | 66.15 |  |  |  |  |  |
| Granted |  | 63 |  |  | 106.00 |  |  |  |  |  |
| Exercised |  | (93) |  |  | 57.48 |  |  |  |  |  |
| Forfeited |  | (5) |  |  | 102.01 |  |  |  |  |  |
| Expired |  | (15) |  |  | 96.71 |  |  |  |  |  |
| Outstanding at end of 2025 |  | 811 |  |  | $ | 69.44 |  |  | 4.60 years |  | $ | 21,974 |  |
| Expected to vest after applying forfeiture rate |  | 808 |  |  | $ | 69.32 |  |  | 4.59 years |  | $ | 21,972 |  |
| Vested and exercisable at end of period |  | 695 |  |  | $ | 64.18 |  |  | 3.93 years |  | $ | 21,927 |  |

[0000038725-26-000009:notes:124]
| (In millions) |  | 2025 |  | 2024 |  | 2023 |
| Intrinsic value of options exercised |  | $ | 3.6 |  |  | $ | 8.8 |  |  | $ | 11.6 |  |
| Cash received from the exercise of options |  | 5.3 |  |  | 7.2 |  |  | 9.2 |  |
| Fair value of shares vested |  | 4.2 |  |  | 2.5 |  |  | 3.1 |  |
| Tax benefit of options exercised |  | 0.6 |  |  | 1.8 |  |  | 2.9 |  |

[0000038725-26-000009:notes:125]
As of December 31, 2025, there was $2.1 million of total unrecognized compensation cost related to non-vested stock options granted under the stock plans. That cost is expected to be recognized over a weighted-average period of 1.63 years.

[0000038725-26-000009:notes:126]
Stock/Stock Unit Awards:

[0000038725-26-000009:notes:127]
Under the 2017 Stock Plan, non-employee directors and employees may be granted stock awards and stock units. Stock awards to non-employee directors are generally fully vested when made. Stock/stock unit awards to employees cliff vest over 3 years (subject to accelerated vesting of a pro rata portion in the case of retirement, death or disability) and may be contingent on the attainment of certain performance goals, which are based on specified growth objectives measured relative to an established market benchmark. Dividends are paid to the recipient prior to vesting, except that dividends on performance-based stock awards under the 2012 Stock Plan and the 2017 Stock Plan will be paid only to the extent the performance goals are met.

[0000038725-26-000009:notes:128]
Stock/stock unit awards granted to retirement eligible employees are expensed over the vesting period. Compensation cost for the performance stock/stock unit awards is accrued based on the probable outcome of specified performance conditions.

[0000038725-26-000009:notes:129]
A summary of the Company’s restricted stock/stock unit award activity and related information is as follows:

[0000038725-26-000009:notes:130]
| (Shares in thousands) |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Restricted Stock/Stock Unit Awards |  |  |
| Non-vested at beginning of 2025 |  | 314 |  |  | $ | 92.83 |  |
| Awarded |  | 120 |  |  | 101.28 |  |
| Vested |  | (98) |  |  | 84.89 |  |
| Forfeited |  | (23) |  |  | 96.50 |  |
| Non-vested at end of 2025 |  | 313 |  |  | $ | 98.28 |  |

[0000038725-26-000009:notes:131]
The weighted-average grant date fair value of restricted stock/stock unit awards granted in 2025, 2024, and 2023, is $101.28, $93.97, and $87.31, respectively. The fair value of restricted stock/stock unit awards that vested in 2025, 2024, and 2023, was $8.3 million, $7.9 million, and $8 million, respectively. 
As of December 31, 2025, there was $11.1 million of total unrecognized compensation cost related to non-vested stock/stock unit awards granted under the stock plans. That cost is expected to be recognized over a weighted-average period of 1.22 years.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-26-000009:notes:132]
Authorized Shares

[0000038725-26-000009:notes:133]
The Company has the authority to issue 65,000,000, $0.10 par value common shares.

[0000038725-26-000009:notes:134]
The Company also has the authority to issue 100,000 preference shares with no par value and 5,000,000 preferred shares with no par value. No preference or preferred shares have been issued.

[0000038725-26-000009:notes:135]
Repurchased Shares

[0000038725-26-000009:notes:136]
During 2025, 2024, and 2023, pursuant to a stock repurchase program authorized by the Company’s Board of Directors, the Company repurchased and retired the following amounts and number of shares:

[0000038725-26-000009:notes:137]
| (In millions, except share amounts) |  | 2025 |  | 2024 |  | 2023 |
| Repurchases |  | $ | 160.0 |  |  | $ | 53.1 |  |  | $ | 32.5 |  |
| Shares |  | 1,790,958 |  |  | 549,062 |  |  | 371,452 |  |

[0000038725-26-000009:notes:138]
The Company retired shares in the amount of 54,506, 74,513, and 101,690 in 2025, 2024, and 2023, respectively, that were received from employees as payment for the exercise price of their stock options and taxes owed upon the exercise of their stock options and release of their restricted awards. The Company also reduced outstanding shares in the amount of 16,856, 5,930, and 0 in 2025, 2024, and 2023, respectively, that had been previously granted as stock awards to employees but were forfeited upon not meeting the required restriction criteria or termination.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-26-000009:notes:139]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)
Changes in accumulated other comprehensive income/(loss), net of tax, by component are summarized below:

[0000038725-26-000009:notes:140]
| (In millions) | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments |  | Total |
| Balance, December 31, 2022 | $ | (191.3) |  |  | $ | (40.1) |  |  | $ | (231.4) |  |
| Other comprehensive income/(loss) before reclassifications(1) | 12.0 |  |  | (3.3) |  |  | 8.7 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (2)(3) | — |  |  | 1.6 |  |  | 1.6 |  |
| Net other comprehensive income/(loss) | 12.0 |  |  | (1.7) |  |  | 10.3 |  |
| Balance, December 31, 2023 | $ | (179.3) |  |  | $ | (41.8) |  |  | $ | (221.1) |  |
| Other comprehensive income/(loss) before reclassifications(1) | (35.7) |  |  | 1.1 |  |  | (34.6) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (2)(3) | — |  |  | 1.7 |  |  | 1.7 |  |
| Net other comprehensive income/(loss) | (35.7) |  |  | 2.8 |  |  | (32.9) |  |
| Balance, December 31, 2024 | $ | (215.0) |  |  | $ | (39.0) |  |  | $ | (254.0) |  |
| Other comprehensive income/(loss) before reclassifications(1) | 48.8 |  |  | 5.6 |  |  | 54.4 |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (2)(3) | — |  |  | 0.6 |  |  | 0.6 |  |
| Pension settlement, net of tax(4) | — |  |  | 41.5 |  |  | 41.5 |  |
| Net other comprehensive income/(loss) | 48.8 |  |  | 47.7 |  |  | 96.5 |  |
| Balance, December 31, 2025 | $ | (166.2) |  |  | $ | 8.7 |  |  | $ | (157.5) |  |

[0000038725-26-000009:notes:141]
(1) Net of tax (benefit)/expense of $2.0 million,  $0.3 million and $(1.1) million for 2025, 2024, and 2022, respectively.

[0000038725-26-000009:notes:142]
(2) This accumulated other comprehensive income/(loss) component is included in the computation of net periodic pension cost (refer to Note 10 - Employee Benefit Plans for additional details) and is included in the “Other income, net” line of the Company’s consolidated statements of income.

[0000038725-26-000009:notes:143]
(3) Net of tax expense of $0.2 million, $0.6 million and $0.5 million for 2025, 2024, and 2023, respectively

[0000038725-26-000009:notes:144]
(4) Net of tax expense of $13.5 million for 2025.
Amounts related to noncontrolling interests were not material.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-26-000009:notes:145]
EMPLOYEE BENEFIT PLANS
Defined Benefit Plans - As of December 31, 2025, the Company maintained one domestic pension plan and three German pension plans. The Company used a December 31, 2025 measurement date for these plans. The Company’s remaining domestic pension plan covers two retired participants.

[0000038725-26-000009:notes:146]
On February 13, 2025, the Company's Board of Directors approved the termination of the domestic Franklin Electric Co, Inc. Pension Plan (the “Plan”). On July 9, 2025, lump sum distributions of $59.9 million were made to eligible participants who elected that payment option to settle the obligation. On July 29, 2025, the Company settled its benefit obligation under the Plan for the remaining participants with the purchase of a nonparticipating, single premium annuity contract from a third-party insurance company, for $28.6 million. In connection with the termination and settlement of the Plan, the Company recognized a non-cash pension settlement gross loss of $55.3 million during the third quarter of 2025 related to the actuarial losses previously accumulated in Accumulated Other Comprehensive Loss, which was included in the “Pension settlement loss” line of the Company’s condensed consolidated statements of income. The Plan was terminated on July 31st, 2025. Excess plan assets were reverted to the Company and will be contributed to the Company's defined contribution plan. The amount that exceeded the annual contribution limit is held in a suspense account until it can be contributed in future periods.

[0000038725-26-000009:notes:147]
The terminated Plan, the single domestic and three German plans collectively comprise the ‘Pension Benefits’ disclosure caption.

[0000038725-26-000009:notes:148]
Other Benefits - The Company’s other post-retirement benefit plan provides health and life insurance to domestic employees hired prior to 1992. The Company effectively capped its cost for those benefits through plan amendments made in 1992, freezing Company contributions for insurance benefits at 1991 levels for current and future beneficiaries with actuarially

[0000038725-26-000009:notes:149]
reduced benefits for employees who retire before age 65. The disclosures surrounding this plan are reflected in the “Other Benefits” caption.

[0000038725-26-000009:notes:150]
The following table sets forth aggregated information related to the Company’s pension benefits and other postretirement benefits, including changes in the benefit obligations, changes in plan assets, funded status, amounts recognized in the balance sheet, amounts recognized in Accumulated Other Comprehensive Loss, and actuarial assumptions that the Company considered in its determination of benefit obligations and plan costs.

[0000038725-26-000009:notes:151]
| (In millions) |  | Pension Benefits |  | Other Benefits |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Accumulated benefit obligation, end of year |  | $ | 27.0 |  |  | $ | 127.1 |  |  | $ | 4.3 |  |  | $ | 4.6 |  |
| Change in projected benefit obligation: |  |  |  |  |  |  |  |  |
| Benefit obligation, beginning of year |  | $ | 127.9 |  |  | $ | 137.5 |  |  | $ | 4.6 |  |  | $ | 5.6 |  |
| Service cost |  | 0.6 |  |  | 0.6 |  |  | — |  |  | — |  |
| Interest cost |  | 4.3 |  |  | 6.1 |  |  | 0.2 |  |  | 0.3 |  |
| Actuarial (gain)/loss |  | (4.4) |  |  | (5.3) |  |  | 0.1 |  |  | (0.6) |  |
| Settlements paid |  | — |  |  | — |  |  | — |  |  | — |  |
| Benefits paid |  | (14.6) |  |  | (9.8) |  |  | (0.6) |  |  | (0.7) |  |
| Foreign currency exchange |  | 2.4 |  |  | (1.2) |  |  | — |  |  | — |  |
| Plan settlement |  | (88.5) |  |  | — |  |  | — |  |  | — |  |
| Benefit obligation, end of year |  | $ | 27.7 |  |  | $ | 127.9 |  |  | $ | 4.3 |  |  | $ | 4.6 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |
| Fair value of assets, beginning of year |  | $ | 105.3 |  |  | $ | 111.7 |  |  | $ | — |  |  | $ | — |  |
| Actual return on plan assets |  | 7.3 |  |  | 3.1 |  |  | — |  |  | — |  |
| Company contributions |  | (4.9) |  |  | 0.6 |  |  | 0.6 |  |  | 0.7 |  |
| Settlements paid |  | — |  |  | — |  |  | — |  |  | — |  |
| Benefits paid |  | (14.6) |  |  | (9.8) |  |  | (0.6) |  |  | (0.7) |  |
| Foreign currency exchange |  | 0.5 |  |  | (0.3) |  |  | — |  |  | — |  |
| Plan settlement |  | (88.5) |  |  | — |  |  | — |  |  | — |  |
| Plan assets, end of year |  | $ | 5.1 |  |  | $ | 105.3 |  |  | $ | — |  |  | $ | — |  |
| Funded status |  | $ | (22.6) |  |  | $ | (22.6) |  |  | $ | (4.3) |  |  | $ | (4.6) |  |
| Amounts recognized in balance sheet: |  |  |  |  |  |  |  |  |
| Non current assets |  | $ | — |  |  | $ | 7.6 |  |  | $ | — |  |  | $ | — |  |
| Current liabilities |  | (5.6) |  |  | (6.1) |  |  | (0.6) |  |  | (0.7) |  |
| Non current liabilities |  | (17.0) |  |  | (24.1) |  |  | (3.7) |  |  | (3.9) |  |
| Net liability, end of year |  | $ | (22.6) |  |  | $ | (22.6) |  |  | $ | (4.3) |  |  | $ | (4.6) |  |
| Amount recognized in accumulated other comprehensive loss: |  |  |  |  |  |  |  |  |
| Prior service cost |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Net actuarial gain (loss) |  | (33.5) |  |  | (39.8) |  |  | 0.7 |  |  | 0.8 |  |
| Settlement |  | — |  |  | — |  |  | — |  |  | — |  |
| Pension settlement loss, net of tax |  | 41.5 |  |  | — |  |  | — |  |  | — |  |
| Total recognized in accumulated other comprehensive loss |  | $ | 8.0 |  |  | $ | (39.8) |  |  | $ | 0.7 |  |  | $ | 0.8 |  |

[0000038725-26-000009:notes:152]
As of December 31, 2025, the pension benefits' aggregate accumulated benefit obligation and projected benefit obligation for plans that have an accumulated benefit obligation and projected benefit obligation in excess of plan assets was $27.0 million

[0000038725-26-000009:notes:153]
and $27.7 million, respectively and as of December 31, 2024, was $33.6 million and $34.5 million, respectively. As of December 31, 2025 and December 31, 2024, the aggregate fair value of plan assets related to these plans was $5.1 million and $4.3 million, respectively.

[0000038725-26-000009:notes:154]
The following table sets forth other changes in plan assets and benefit obligation recognized in other comprehensive income/(loss) for 2025 and 2024:

[0000038725-26-000009:notes:155]
| (In millions) |  | Pension Benefits |  | Other Benefits |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net actuarial (gain)/loss |  | $ | (7.8) |  |  | $ | (0.9) |  |  | $ | 0.1 |  |  | $ | (0.6) |  |
| Amortization of: |  |  |  |  |  |  |  |  |
| Net actuarial loss |  | (0.9) |  |  | (2.3) |  |  | 0.1 |  |  | — |  |
| Prior service credit |  | — |  |  | — |  |  | — |  |  | — |  |
| Settlement recognition |  | — |  |  | — |  |  | — |  |  | — |  |
| Pension settlement loss |  | (54.9) |  |  | — |  |  | — |  |  | — |  |
| Deferred tax asset |  | 15.7 |  |  | 0.8 |  |  | (0.1) |  |  | 0.1 |  |
| Foreign currency exchange |  | — |  |  | 0.1 |  |  | — |  |  | — |  |
| Total recognized in other comprehensive income/(loss) |  | $ | (47.9) |  |  | $ | (2.3) |  |  | $ | 0.1 |  |  | $ | (0.5) |  |

[0000038725-26-000009:notes:156]
The settlement of the Plan was the largest contributor to the net actuarial losses recorded in 2025. The increased discount rate, partially offset by unfavorable returns on assets were the largest contributors to the net actuarial gains recorded in 2024.

[0000038725-26-000009:notes:157]
Weighted-average assumptions used to determine domestic benefit obligations:

[0000038725-26-000009:notes:158]
|  |  | Pension Benefits |  | Other Benefits |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Discount rate |  | 4.07 | % |  | 5.48 | % |  | 5.04 | % |  | 5.47 | % |
| Rate of increase in future compensation |  | — | % | * | — | % | * | 2.00 - 9.00%(Graded) |  | 2.00 - 9.00%(Graded) |

[0000038725-26-000009:notes:159]
*No rate of increases in future compensation were used in the assumptions for 2025 and 2024, as the cash balance component of the domestic Pension Plan was frozen and the other domestic Pension Plan components do not base benefits on compensation. The weighted-average interest crediting rate of the cash balance component of the domestic Pension Plan was 0.0 percent, 4.50 percent, and 4.50 percent for 2025, 2024, and 2023, respectively and is based on the approximate 30-year Treasury rate as of November of the prior year with a minimum of 4.5 percent.

[0000038725-26-000009:notes:160]
Assumptions used to determine domestic periodic benefit cost:

[0000038725-26-000009:notes:161]
|  |  | Pension Benefits |  | Other Benefits |
|  |  | 2025 |  | 2024 |  | 2023 |  | 2025 |  | 2024 |  | 2023 |
| Discount rate |  | 4.07 | % |  | 4.95 | % |  | 5.14 | % |  | 5.47 | % |  | 4.88 | % |  | 5.08 | % |
| Rate of increase in future compensation |  | — | % | * | — | % | * | — | % | * | 2.00 - 9.00%(Graded) |  | 2.00 - 9.00%(Graded) |  | 2.00 - 9.00%(Graded) |
| Expected long-term rate of return on plan assets |  | — | % |  | 6.20 | % |  | 5.70 | % |  | — | % |  | — | % |  | — | % |

[0000038725-26-000009:notes:162]
*No rate of increases in future compensation were used in the assumptions for 2025, 2024, and 2023, as the cash balance component of the domestic Pension Plan was frozen and the other domestic Pension Plan components do not base benefits on compensation.

[0000038725-26-000009:notes:163]
For the years ended December 31, 2025 and December 31, 2024, the Company used the PRI-2012 aggregate mortality table, and then projected forward from 2012 using Scale MP-2021 released by the Society of Actuaries during 2021 to estimate future mortality rates based upon current data.

[0000038725-26-000009:notes:164]
The following table sets forth the aggregated net periodic benefit cost for all defined benefit plans for 2025, 2024, and 2023:

[0000038725-26-000009:notes:165]
| (In millions) | Pension Benefits |  | Other Benefits |
|  | 2025 |  | 2024 |  | 2023 |  | 2025 |  | 2024 |  | 2023 |
| Service cost | $ | 0.6 |  |  | $ | 0.6 |  |  | $ | 0.6 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 4.3 |  |  | 6.1 |  |  | 6.4 |  |  | 0.2 |  |  | 0.3 |  |  | 0.3 |  |
| Expected return on assets | (3.9) |  |  | (7.5) |  |  | (7.2) |  |  |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Transition obligation | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | 0.9 |  |  | 2.3 |  |  | 2.1 |  |  | — |  |  | — |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Pension settlement loss | 54.9 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 56.8 |  |  | $ | 1.5 |  |  | $ | 1.9 |  |  | $ | 0.2 |  |  | $ | 0.3 |  |  | $ | 0.3 |  |

[0000038725-26-000009:notes:166]
The Company consults with a third party investment manager for the assets of the funded domestic defined benefit plan. Before settlement of the Plan, the plan assets were invested primarily in pooled funds, where each fund in turn is composed of mutual funds that have at least daily net asset valuations. Thus, the Company’s funded domestic defined benefit plan assets were invested in a “fund of funds” approach.

[0000038725-26-000009:notes:167]
The Company’s Board has delegated oversight and guidance to an appointed Employee Benefits Committee. The Committee has the tasks of reviewing plan performance and asset allocation, ensuring plan compliance with applicable laws, establishing plan policies, procedures, and controls, monitoring expenses, and other related activities.

[0000038725-26-000009:notes:168]
The plan’s investment policies and strategies focused on the ability to fund benefit obligations as they come due. Considerations include the plan’s current funded level, plan design, benefit payment assumptions, funding regulations, impact of potentially volatile business results on the Company’s ability to make certain levels of contributions, and interest rate and asset return volatility among other considerations. Before settlement of the Plan, the Company attempted to maintain plan funded status at approximately 80 percent or greater pursuant to the Pension Protection Act of 2007. Prior to the settlement of the Plan, the Company saw ample liquidity to achieve this goal given the Company’s cash on hand, cash historically generated from business operations, and cash available under committed credit facilities.

[0000038725-26-000009:notes:169]
Risk management and continuous monitoring requirements were met through monthly investment portfolio reports, quarterly Employee Benefits Committee meetings, annual valuations, asset/liability studies, and the annual assumption process focusing primarily on the return on asset assumption and the discount rate assumption. As of December 31, 2025 and December 31, 2024, funds were invested in equity, fixed income, and other investments as follows:

[0000038725-26-000009:notes:170]
|  |  | Target Percentage |  | Plan Asset Allocation at Year-End |
| Asset Category |  | at Year-End 2025 |  | 2025 |  | 2024 |
| Equity securities |  | — | % |  | — | % |  | 16 | % |
| Fixed income securities |  | — | % |  | — | % |  | 79 | % |
| Other |  | 100 | % |  | 100 | % |  | 5 | % |
| Total |  | 100 | % |  | 100 | % |  | 100 | % |

[0000038725-26-000009:notes:171]
Prior to settlement of the Plan, the Company did not see any particular concentration of risk within the plans, nor any plan assets that posed difficulties for fair value assessment. The Company had no allocation to potentially illiquid or potentially difficult to value assets such as hedge funds, venture capital, private equity, and real estate.

[0000038725-26-000009:notes:172]
The Company works with actuaries and consultants in making its determination of the asset rate of return assumption and also the discount rate assumption.

[0000038725-26-000009:notes:173]
Asset class assumptions are set using a combination of empirical and forward-looking analysis for long-term rate of return on plan assets. A variety of models are applied for filtering historical data and isolating the fundamental characteristics of asset classes. These models provide empirical return estimates for each asset class, which are then reviewed and combined with a

[0000038725-26-000009:notes:174]
qualitative assessment of long-term relationships between asset classes before a return estimate is finalized. This provides an additional means for correcting for the effect of unrealistic or unsustainable short-term valuations or trends, opting instead for return levels and behavior that are more likely to prevail over long periods.

[0000038725-26-000009:notes:175]
The Company uses the Aon Hewitt AA Above Median curve to determine the discount rate. All cash flow obligations under the plan are matched to bonds in the Aon Hewitt universe of liquid, high-quality, non-callable / non-puttable corporate bonds with outliers removed. From that matching exercise, a discount rate is determined.

[0000038725-26-000009:notes:176]
The Company’s German pension plans are funded by insurance contract policies whereby the insurance company guarantees a fixed minimum return. Due to tax legislation, individual pension benefits can only be financed using direct insurance policies up to certain maximums. These maximum amounts in respect of each member are paid into such an arrangement on a yearly basis.

[0000038725-26-000009:notes:177]
The Company designated all equity and most domestic fixed income plan assets as Level 1, as they are mutual funds with prices that are readily available. The U.S. Treasury securities and German plan assets are designated as Level 2 inputs. The fair value of the German plan assets are measured by the reserve that is supervised by the German Federal Financial Supervisory Authority. The U.S. Treasury securities are administered by the United States government.

[0000038725-26-000009:notes:178]
The fair values of the Company’s pension plan assets for 2025 and 2024 by asset category are as follows:

[0000038725-26-000009:notes:179]
| (In millions) |  | 2025 |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |
| Other |  |  |  |  |  |  |  |  |
| Insurance contracts |  | 5.1 |  |  | — |  |  | 5.1 |  |  | — |  |
| Cash and equivalents |  | — |  |  | — |  |  | — |  |  | — |  |
| Total |  | $ | 5.1 |  |  | $ | — |  |  | $ | 5.1 |  |  | $ | — |  |

[0000038725-26-000009:notes:180]
| (In millions) |  | 2024 |  | Quoted Prices in Active Markets for Identical Assets(Level 1) |  | Significant Other Observable Inputs(Level 2) |  | Significant Unobservable Inputs(Level 3) |
| Equity |  |  |  |  |  |  |  |  |
| International equity mutual funds |  | $ | 17.2 |  |  | $ | 17.2 |  |  | $ | — |  |  | $ | — |  |
| Fixed income |  |  |  |  |  |  |  |  |
| U.S. treasury and government agency securities |  | 11.1 |  |  | — |  |  | 11.1 |  |  | — |  |
| Fixed income mutual funds |  | 72.1 |  |  | 72.1 |  |  | — |  |  | — |  |
| Other |  |  |  |  |  |  |  |  |
| Insurance contracts |  | 4.3 |  |  | — |  |  | 4.3 |  |  | — |  |
| Cash and equivalents |  | 0.6 |  |  | 0.6 |  |  | — |  |  | — |  |
| Total |  | $ | 105.3 |  |  | $ | 89.9 |  |  | $ | 15.4 |  |  | $ | — |  |

[0000038725-26-000009:notes:181]
The Company estimates total contributions to the plans of about $6.2 million in 2026.

[0000038725-26-000009:notes:182]
The following benefit payments, which reflect expected future service, as appropriate, are expected to be paid in accordance with the following schedule:

[0000038725-26-000009:notes:183]
| (In millions) |  | Pension Benefits |  | Other Benefits |
| 2026 |  | $ | 5.6 |  |  | $ | 0.6 |  |
| 2027 |  | $ | 5.1 |  |  | $ | 0.6 |  |
| 2028 |  | $ | 0.8 |  |  | $ | 0.5 |  |
| 2029 |  | $ | 0.8 |  |  | $ | 0.5 |  |
| 2030 |  | $ | 0.9 |  |  | $ | 0.5 |  |
| Years 2030 through 2034 |  | $ | 5.2 |  |  | $ | 1.9 |  |

[0000038725-26-000009:notes:184]
Defined Contribution Plans - The Company maintained two defined contribution plans during 2025, 2024, and 2023. The Company’s cash contributions are allocated to participant’s accounts based on investment elections.

[0000038725-26-000009:notes:185]
The following table sets forth Company contributions to the defined contribution plans:

[0000038725-26-000009:notes:186]
| (In millions) |  | 2025 |  | 2024 |  | 2023 |
| Company contributions to the plans |  | $ | 11.8 |  |  | $ | 11.4 |  |  | $ | 11.5 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-26-000009:notes:187]
INCOME TAXES
Income before income taxes consisted of the following:

[0000038725-26-000009:notes:188]
| (In millions) |  | 2025 |  | 2024 |  | 2023 |
| Domestic |  | $ | 108.9 |  |  | $ | 169.5 |  |  | $ | 163.9 |  |
| Foreign |  | 85.8 |  |  | 62.3 |  |  | 78.3 |  |
|  |  | $ | 194.7 |  |  | $ | 231.8 |  |  | $ | 242.2 |  |

[0000038725-26-000009:notes:189]
The income tax provision/(benefit) consisted of the following:

[0000038725-26-000009:notes:190]
| (In millions) |  | 2025 |  | 2024 |  | 2023 |
| Current: |  |  |  |  |  |  |
| Federal |  | $ | 22.0 |  |  | $ | 42.5 |  |  | $ | 27.0 |  |
| Foreign |  | 25.5 |  |  | 17.3 |  |  | 14.9 |  |
| State |  | 6.1 |  |  | 10.0 |  |  | 7.2 |  |
| Total current |  | 53.6 |  |  | 69.8 |  |  | 49.1 |  |
| Deferred: |  |  |  |  |  |  |
| Federal |  | (2.5) |  |  | (16.0) |  |  | (1.1) |  |
| Foreign |  | (3.8) |  |  | (0.8) |  |  | (0.3) |  |
| State |  | (1.3) |  |  | (2.8) |  |  | (0.2) |  |
| Total deferred |  | $ | (7.6) |  |  | $ | (19.6) |  |  | $ | (1.6) |  |
|  |  | $ | 46.0 |  |  | $ | 50.2 |  |  | $ | 47.5 |  |

[0000038725-26-000009:notes:191]
The table below provides the updated requirements of ASU 2023-09 for 2025.

[0000038725-26-000009:notes:192]
A reconciliation of the tax provision for continuing operations at the U.S. statutory rate to the effective income tax expense rate as reported is as follows:

[0000038725-26-000009:notes:193]
| (In millions) |  | 2025(a) |
|  |  | Amount |  | Percent |
| U.S. Federal Statutory Tax Rate |  | $ | 40.9 |  |  | 21.0 | % |
| U.S. State and Local Income Taxes, Net of Federal Income Tax Effect (a) |  | 3.4 |  |  | 1.7 |  |
| Foreign Tax Effects |  |  |  |  |
| Netherlands |  |  |  |  |
| Exemption of Foreign Business Profits |  | (7.2) |  |  | (3.7) |  |
| Pillar Two Global Minimum Tax |  | 2.9 |  |  | 1.5 |  |
| Other |  | 1.3 |  |  | 0.6 |  |
| Other foreign jurisdictions |  | 7.3 |  |  | 3.7 |  |
| Effect of Cross-Border under U.S. Tax Laws |  |  |  |  |
| Foreign-derived intangible income |  | (4.0) |  |  | (2.1) |  |
| Other |  | (0.3) |  |  | (0.1) |  |
| U.S. Nontaxable or Nondeductible Items |  |  |  |  |
| Nondeductible officer's compensation |  | 2.5 |  |  | 1.3 |  |
| Other |  | 0.1 |  |  | 0.1 |  |
| Other U.S. Adjustments |  | (0.9) |  |  | (0.4) |  |
| Effective Tax Rate |  | $ | 46.0 |  |  | 23.6 | % |

[0000038725-26-000009:notes:194]
(a) The following jurisdictions made up the majority (greater than 50 percent) of the tax effect in this category:

[0000038725-26-000009:notes:195]
2025 - California, Texas, Florida, Michigan, Pennsylvania, Illinois, and New York;

[0000038725-26-000009:notes:196]
As previously disclosed for the years ended December 31, 2024 and 2023, prior to the adoption of ASU 2023-09, the reconciliation of the tax provision for continuing operations at the U.S. statutory rate to the effective income tax expense rate as reported is as follows.

[0000038725-26-000009:notes:197]
|  |  | 2024 |  | 2023 |
| U.S. Federal statutory rate |  | 21.0 | % |  | 21.0 | % |
| State income taxes, net of federal benefit |  | 2.3 |  |  | 2.3 |  |
| Foreign operations |  | 1.0 |  |  | (0.7) |  |
| R&D tax credits |  | (0.6) |  |  | (0.4) |  |
| Uncertain tax position adjustments |  | 0.2 |  |  | (0.1) |  |
| Valuation allowance on state and foreign deferred tax |  | 0.2 |  |  | (0.2) |  |
| Share-based compensation |  | (0.8) |  |  | (1.0) |  |
| Other items |  | 0.9 |  |  | (0.1) |  |
| Foreign Derived Intangible Income |  | (3.5) |  |  | (2.4) |  |
| Nondeductible officer's compensation |  | 1.0 |  |  | 1.2 |  |
| Effective tax rate |  | 21.7 | % |  | 19.6 | % |

[0000038725-26-000009:notes:198]
The effective tax rate differs from the U.S. statutory rate of 21 percent primarily due to U.S. state taxes, foreign earnings taxed at rates higher than the U.S. statutory rate, U.S. state taxes, Pillar Two Global Minimum Tax, and nondeductible officer’s compensation, which were partially offset by an object exemption of foreign business profits in the Netherlands, the recognition of the U.S. foreign-derived intangible income (FDII) provisions, certain incentives, and discrete events.

[0000038725-26-000009:notes:199]
Significant components of the Company’s deferred tax assets and liabilities were as follows:

[0000038725-26-000009:notes:200]
| (In millions) |  | 2025 |  | 2024 |
| Deferred tax assets: |  |  |  |  |
| Accrued expenses and reserves |  | $ | 16.7 |  |  | $ | 15.5 |  |
| Compensation and employee benefits |  | 11.9 |  |  | 16.0 |  |
| Intercompany prepayments (FDII related) |  | 14.9 |  |  | 16.9 |  |
| Net operating losses, tax credit carryforwards, and other |  | 10.3 |  |  | 11.8 |  |
| Lease liability |  | 16.8 |  |  | 15.7 |  |
| Research and development expenditures, net |  | 4.5 |  |  | 7.4 |  |
| Valuation allowance on state and foreign deferred tax |  | (4.4) |  |  | (4.4) |  |
| Total deferred tax assets |  | 70.7 |  |  | 78.9 |  |
| Deferred tax liabilities: |  |  |  |  |
| Accelerated depreciation on fixed assets |  | 17.3 |  |  | 15.6 |  |
| Amortization of intangibles |  | 68.7 |  |  | 49.2 |  |
| Lease right-of-use asset, net |  | 16.8 |  |  | 15.7 |  |
| Other items |  | 0.6 |  |  | 0.4 |  |
| Total deferred tax liabilities |  | 103.4 |  |  | 80.9 |  |
| Net deferred tax liabilities |  | $ | (32.7) |  |  | $ | (2.0) |  |

[0000038725-26-000009:notes:201]
The Company assesses the available positive and negative evidence to estimate whether sufficient future taxable income will be generated to permit use of the existing deferred tax assets. A significant piece of objective negative evidence evaluated was the cumulative loss for certain foreign income tax purposes incurred over the 3-year period ended December 31, 2025. Such objective evidence limits the ability to consider other subjective evidence, such as the Company's projections for future growth.

[0000038725-26-000009:notes:202]
On the basis of this evaluation, as of December 31, 2025, a valuation allowance of $4.4 million has been recorded to recognize only the portion of the deferred tax asset that is more likely than not to be realized. The Company has foreign income tax net operating loss (“NOL”) and credit carryforwards of $6.5 million and U.S. state income tax credit carryforwards of $3.8 million, which will expire on various dates as follows:

[0000038725-26-000009:notes:203]
| (In millions) |  |
| 2026-2029 | $ | 3.2 |  |
| 2030-2034 | 1.6 |  |
| 2035-2039 | 0.6 |  |
| 2040-2045 | 0.3 |  |
| Unlimited | 4.6 |  |
|  | $ | 10.3 |  |

[0000038725-26-000009:notes:204]
The Company believes that it is more likely than not that the benefit from certain foreign NOL carryforwards as well as certain U.S. state credit carryforwards will not be realized. In recognition of this risk, the Company has provided a valuation allowance of $3.2 million on the deferred tax assets related to these foreign NOL carryforwards and a valuation allowance of $1.2 million on the deferred tax assets related to these U.S. state credit carryforwards.

[0000038725-26-000009:notes:205]
As of December 31, 2025, the Company has estimated accumulated undistributed earnings generated by the Company's foreign subsidiaries of approximately $656.4 million. Any taxes due with respect to such earnings or the excess of the amount for financial reporting over the tax basis of its foreign investments would generally be limited to foreign and U.S. state taxes. The Company intends, however, to indefinitely reinvest these earnings and expects future U.S. cash generation to be sufficient to meet future U.S. cash needs. The Company, therefore, has not recorded a deferred tax liability of approximately $7.5 million.

[0000038725-26-000009:notes:206]
As of the beginning of 2025, the Company had gross unrecognized tax benefits of $1.3 million, excluding accrued interest and penalties. The unrecognized tax benefits increased due to uncertain tax positions identified for the current and prior years based on evaluations made during 2025, which were offset by statute expirations. The Company had gross unrecognized tax benefits, excluding accrued interest and penalties, of $3.0 million as of December 31, 2025.

[0000038725-26-000009:notes:207]
During the first quarter of 2025, the Company recorded additional unrecognized tax benefits (excluding accrued interest and penalties) of $1.5 million. This amount is associated with uncertain tax positions taken by newly acquired companies in tax years prior to the acquisition of these companies. The stock purchase agreement related to the acquisition provides the Company the right to recover tax liabilities related to pre-acquisition tax years from the sellers and has accordingly recognized an indemnification receivable.

[0000038725-26-000009:notes:208]
A reconciliation of the beginning and ending amount of gross unrecognized tax benefits for 2025, 2024, and 2023 (excluding interest and penalties) is as follows:

[0000038725-26-000009:notes:209]
| (In millions) |  | 2025 |  | 2024 |  | 2023 |
| Beginning balance |  | $ | 1.3 |  |  | $ | 0.8 |  |  | $ | 0.9 |  |
| Additions for tax positions of the current year |  | 0.3 |  |  | 0.6 |  |  | 0.3 |  |
| Additions for tax positions of prior years |  | 1.5 |  |  | 0.2 |  |  | — |  |
| Statute expirations |  | (0.1) |  |  | (0.3) |  |  | (0.4) |  |
| Ending balance |  | $ | 3.0 |  |  | $ | 1.3 |  |  | $ | 0.8 |  |

[0000038725-26-000009:notes:210]
The Company recognizes interest and penalties related to unrecognized tax benefits as a component of income tax expense. The Company has accrued interest and penalties as of December 31, 2025, December 31, 2024, and December 31, 2023 of approximately $1.1 million, $0.1 million, and $0.1 million, respectively.

[0000038725-26-000009:notes:211]
The Company is subject to taxation in the United States and various U.S. state and foreign jurisdictions. With few exceptions, as of  December 31, 2025, the Company is no longer subject to U.S. federal income tax examinations by tax authorities for years before 2022 and is no longer subject to foreign or U.S. state income tax examinations by tax authorities for years before 2020.

[0000038725-26-000009:notes:212]
Total cash paid for income taxes, net of refunds are as follows:

[0000038725-26-000009:notes:213]
| (In millions) |  | 2025 |
| Federal |  | $ | 43.8 |  |
| State |  | 9.2 |  |
| Foreign |  | 23.7 |  |
| Total |  | $ | 76.7 |  |

[0000038725-26-000009:notes:214]
Income taxes paid (net of refunds) exceeded 5 percent of total income taxes paid (net of refunds) in the following jurisdictions:

[0000038725-26-000009:notes:215]
| (In millions) |  | 2025 |
| Federal |  |  |
| United States |  | $ | 43.8 |  |
| Foreign |  |  |
| Brazil |  | $ | 4.7 |  |


## us-gaap:EarningsPerShareTextBlock

[0000038725-26-000009:notes:216]
EARNINGS PER SHARE
The Company calculates basic and diluted earnings per common share using the two-class method. Under the two-class method, net earnings are allocated to each class of common stock and participating security as if all of the net earnings for the period had been distributed. The Company’s participating securities consist of share-based payment awards that contain a non-forfeitable right to receive dividends and therefore are considered to participate in undistributed earnings with common shareholders.

[0000038725-26-000009:notes:217]
Basic earnings per common share excludes dilution and is calculated by dividing net earnings allocable to common shares by the weighted-average number of common shares outstanding for the period. Diluted earnings per common share is calculated by dividing net earnings allocated to common shares by the weighted-average number of common shares outstanding for the period, as adjusted for the potential dilutive effect of non-participating share-based awards.

[0000038725-26-000009:notes:218]
The following table sets forth the computation of basic and diluted earnings per share:

[0000038725-26-000009:notes:219]
| (In millions, except per share amounts) |  | 2025 |  | 2024 |  | 2023 |
| Numerator: |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. |  | $ | 147.1 |  |  | $ | 180.3 |  |  | $ | 193.3 |  |
| Less: Earnings allocated to participating securities |  | 0.6 |  |  | 0.7 |  |  | 0.7 |  |
| Net income available to common shareholders |  | $ | 146.5 |  |  | $ | 179.6 |  |  | $ | 192.6 |  |
| Denominator: |  |  |  |  |  |  |
| Basic weighted average common shares outstanding |  | 45.0 |  |  | 45.9 |  |  | 46.2 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |
| Non-participating employee stock options, performance awards, and deferred shares to non-employee directors |  | 0.5 |  |  | 0.6 |  |  | 0.7 |  |
| Diluted weighted average common shares outstanding |  | 45.5 |  |  | 46.5 |  |  | 46.9 |  |
| Basic earnings per share |  | $ | 3.25 |  |  | $ | 3.92 |  |  | $ | 4.17 |  |
| Diluted earnings per share |  | $ | 3.22 |  |  | $ | 3.86 |  |  | $ | 4.11 |  |

[0000038725-26-000009:notes:220]
There were 0.2 million, 0.1 million, and 0.1 million stock options outstanding as of 2025, 2024, and 2023, respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-26-000009:notes:221]
FINANCIAL INSTRUMENTS
The Company’s non-employee directors' deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period. The Company has entered into share swap transaction agreements (“the swap”) to mitigate the Company’s exposure to these fluctuations in the Company’s stock price. The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days written notice by either party. As of December 31, 2025 and December 31, 2024, the swap had a notional value based on 150,000 shares and 250,000 shares, respectively. For the years ended December 31, 2025, December 31, 2024, and December 31, 2023, the swap resulted in a loss of $2.3 million, a loss of $1.3 million, and a gain of $2.5 million, respectively. Gains and losses resulting from the swap were primarily offset by gains and losses on the fair value of the deferred compensation stock liability. All gains or losses and expenses related to the deferred compensation stock liability and the swap are recorded in the Company’s consolidated statements of income within the “Selling, general, and administrative expenses” line.
The Company is exposed to foreign currency exchange rate risk arising from transactions in the normal course of business including making sales and purchases of raw materials and finished goods in foreign denominated currencies with third party customers and suppliers as well as to wholly owned subsidiaries of the Company.  To reduce its exposure to foreign currency exchange rate volatility, the Company enters into various forward currency contracts to offset these fluctuations. The Company uses forward currency contracts only in an attempt to limit underlying exposure from foreign currency exchange rate fluctuations and to minimize earnings volatility associated with foreign currency exchange rate fluctuations and has not elected to use hedge accounting. Decisions on whether to use such derivative instruments are primarily based on the amount of exposure to the currency involved and an assessment of the near-term market value for each currency.  As of December 31, 2025 and December 31, 2024, the Company had no foreign currency contracts outstanding. For the years ended December 31, 2025, December 31, 2024, and December 31, 2023, the forward currency contracts resulted in a gain of $11.0 million, a loss of $0.2 million, and a gain of $1.6 million, respectively. This is recorded in the Company's consolidated statements of income within the "Foreign exchange expense, net" line.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-26-000009:notes:222]
FAIR VALUE MEASUREMENTS
As of December 31, 2025 and December 31, 2024, the assets and liabilities measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-26-000009:notes:223]
| (In millions) |  | December 31, 2025 |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 10.2 |  |  | $ | 10.2 |  |  | $ | — |  |  | $ | — |  |
| Marketable securities |  | $ | 9.7 |  |  | $ | 9.7 |  |  | $ | — |  |  | $ | — |  |
| Total assets |  | $ | 19.9 |  |  | $ | 19.9 |  |  | $ | — |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Total liabilities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
|  |  | December 31, 2024 |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  | Significant Other Observable Inputs (Level 2) |  | Significant Unobservable Inputs (Level 3) |
| Assets: |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | 5.0 |  |  | $ | 5.0 |  |  | $ | — |  |  | $ | — |  |
| Total assets |  | $ | 5.0 |  |  | $ | 5.0 |  |  | $ | — |  |  | $ | — |  |
| Liabilities: |  |  |  |  |  |  |  |  |
| Share swap transaction |  | $ | 2.5 |  |  | $ | 2.5 |  |  | $ | — |  |  | $ | — |  |
| Contingent payments related to acquisition |  | $ | 5.0 |  |  | — |  |  | — |  |  | $ | 5.0 |  |
| Total liabilities |  | $ | 7.5 |  |  | $ | 2.5 |  |  | $ | — |  |  | $ | 5.0 |  |

[0000038725-26-000009:notes:224]
The Company’s Level 1 cash equivalents assets are generally comprised of foreign bank guaranteed certificates of deposit and short term deposits. The Company’s Level 1 marketable securities assets are comprised of short term investment funds. The marketable securities asset is recorded within the "Other current assets" line of the condensed consolidated balance sheets. These marketable securities were excess plan assets from the pension settlement disclosed in Note 10 – Employee Benefit Plans. The excess plan assets were reclassified to “Other current assets” during the third quarter as a result of the pension settlement. The forward currency contracts asset and the share swap transaction asset are recorded within the "Receivables" line of the condensed consolidated balance sheets. The forward currency contracts liability and the share swap transaction liability are recorded within the "Accounts payable" line of the condensed consolidated balance sheets. The forward currency contracts and share swap transaction are further described in Note 13 - Financial Instruments.

[0000038725-26-000009:notes:225]
The Company's Level 3 category includes contingent consideration related to acquisitions, which valuation inputs are unobservable and significant to the fair value measurement.  Projections and estimated probabilities are used to estimate future contingent earn-out payments, which are discounted back to present value to compute contingent earn-out liabilities. The following table provides a roll-forward of the contingent consideration liability, which is included in "Accrued expenses and other liabilities" as of December 31, 2025 and "Other long-term liabilities" as of December 31, 2024 in the consolidated balance sheets:

[0000038725-26-000009:notes:226]
| (In millions) | 2025 |  | 2024 |
| Fair value at beginning of period | $ | 5.0 |  |  | $ | 3.0 |  |
| Additions | — |  |  | — |  |
| Adjustment to prior year acquisition | — |  |  | 1.3 |  |
| Change in fair value recognized in earnings | — |  |  | 0.7 |  |
| Payments | (5.0) |  |  | — |  |
| Fair value at end of period | $ | — |  |  | 5.0 |  |

[0000038725-26-000009:notes:227]
Total debt, including current maturities, have carrying amounts of $167.0 million as of December 31, 2025 and $129.4 million at December 31, 2024. The estimated fair value of all debt was $160.6 million and $128.0 million as of December 31, 2025 and 
December 31, 2024, respectively. In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value. Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction. In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities. Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-26-000009:notes:228]
SEGMENT AND GEOGRAPHIC INFORMATION
The Company’s business consists of the Water Systems, Distribution, and Energy Systems reportable segments, based on the principal end market served. The Company changed the name of the Fueling Systems segment to Energy Systems to reflect its diverse portfolio and growth strategy, as well as to better reflect the markets and customers served by the segment. The Company includes unallocated corporate expenses and intercompany eliminations that are not part of a reportable segment in its reconciliations to consolidated results.

[0000038725-26-000009:notes:229]
The Water Systems segment designs, manufactures and sells motors, pumps, electronic controls, water treatment systems and related parts and equipment primarily for use in submersible water or other fluid system applications. The Energy Systems segment designs, manufactures and sells pumps, electronic controls and related parts and equipment primarily for use in submersible fueling system applications. The Energy Systems segment integrates and sells motors and electronic controls produced by the Water Systems segment. The Company reports these product transfers between Water Systems and Energy Systems as inventory transfers since a significant number of the Company's manufacturing facilities are shared across segments for scale and efficiency purposes. The Distribution segment sells to and provides presale support and specifications to the installing contractors. The Distribution segment sells products produced by the Water Systems segment. The Company reports intersegment transfers from Water Systems to Distribution as intersegment sales at market prices to properly reflect the commercial arrangement of vendor to customer that exists between the Water Systems and Distribution segments.

[0000038725-26-000009:notes:230]
The accounting policies of the Company’s reportable segments are the same as those described in Note 1 - Summary of Significant Accounting Policies. The Company's chief operating decision maker is its Chief Executive Officer. Performance is evaluated based on the sales and operating income of the segments. Operating income and margin are used to evaluate income generated from segment assets in deciding whether to reinvest profits into each segment or other parts of the entity.  Operating income is also used to monitor budget versus actual results, for purposes of determining portions of management compensation and for benchmarking against similar measures used by peers and competitors. These results are not necessarily indicative of the results of operations that would have occurred had each segment been an independent, stand-alone entity during the periods presented as corporate expenses are not allocated to segments. Interest expense, other income (expense), net, foreign exchange expense and income tax expense are also not allocated to each segment.

[0000038725-26-000009:notes:231]
Financial information by reportable business segment is included in the following summary:

[0000038725-26-000009:notes:232]
| 2025 | Water Systems |  | Distribution |  | Energy Systems |  | Total |
| (In millions) |
| External sales | $ | 1,131.6 |  |  | $ | 700.7 |  |  | $ | 299.0 |  |  | $ | 2,131.3 |  |
| Intersegment sales | 124.8 |  |  | — |  |  | — |  |  | 124.8 |  |
|  | $ | 1,256.4 |  |  | $ | 700.7 |  |  | $ | 299.0 |  |  | $ | 2,256.1 |  |
| Elimination of intersegment sales |  |  |  |  |  |  | $ | (124.8) |  |
| Total consolidated sales |  |  |  |  |  |  | $ | 2,131.3 |  |
| Cost of sales | $ | 830.1 |  |  | $ | 511.2 |  |  | $ | 156.6 |  |  |  |
| Selling, general and administrative expenses | 218.7 |  |  | 149.4 |  |  | 43.3 |  |  |  |
| Restructuring expense | 0.4 |  |  | 0.3 |  |  | — |  |  |  |
| Segment operating income | $ | 207.2 |  |  | $ | 39.8 |  |  | $ | 99.1 |  |  | $ | 346.1 |  |
| Reconciliation of segment operating income to income before income taxes |  |  |  |  |  |  |  |
| Deferred intersegment loss |  |  |  |  |  |  | $ | (2.4) |  |
| Corporate general and administrative expenses |  |  |  |  |  |  | (74.8) |  |
| Interest expense |  |  |  |  |  |  | (10.6) |  |
| Other income, net |  |  |  |  |  |  | 0.6 |  |
| Foreign exchange expense |  |  |  |  |  |  | (9.3) |  |
| Pension settlement loss |  |  |  |  |  |  | (54.9) |  |
| Consolidated income before income taxes |  |  |  |  |  |  | $ | 194.7 |  |

[0000038725-26-000009:notes:233]
| 2024 | Water Systems |  | Distribution |  | Energy Systems |  | Total |
| (In millions) |
| External sales | $ | 1,062.1 |  |  | $ | 685.5 |  |  | $ | 273.7 |  |  | $ | 2,021.3 |  |
| Intersegment sales | 121.9 |  |  | — |  |  | — |  |  | 121.9 |  |
|  | $ | 1,184.0 |  |  | $ | 685.5 |  |  | $ | 273.7 |  |  | $ | 2,143.2 |  |
| Elimination of intersegment sales |  |  |  |  |  |  | $ | (121.9) |  |
| Total consolidated sales |  |  |  |  |  |  | $ | 2,021.3 |  |
| Cost of sales | $ | 782.0 |  |  | $ | 505.9 |  |  | $ | 137.6 |  |  |  |
| Selling, general and administrative expenses | 201.7 |  |  | 154.6 |  |  | 42.1 |  |  |  |
| Restructuring expense | 2.4 |  |  | 0.7 |  |  | 0.4 |  |  |  |
| Segment operating income | $ | 197.9 |  |  | $ | 24.3 |  |  | $ | 93.6 |  |  | $ | 315.8 |  |
| Reconciliation of segment operating income to income before income taxes |  |  |  |  |  |  |  |
| Deferred intersegment loss |  |  |  |  |  |  | $ | (0.5) |  |
| Corporate general and administrative expenses |  |  |  |  |  |  | (71.7) |  |
| Interest expense |  |  |  |  |  |  | (6.3) |  |
| Other income, net |  |  |  |  |  |  | 1.3 |  |
| Foreign exchange expense |  |  |  |  |  |  | (6.8) |  |
| Consolidated income before income taxes |  |  |  |  |  |  | $ | 231.8 |  |

[0000038725-26-000009:notes:234]
| 2023 | Water Systems |  | Distribution |  | Energy Systems |  | Consolidated |
| (In millions) |
| External sales | $ | 1,095.3 |  |  | $ | 673.3 |  |  | $ | 296.5 |  |  | $ | 2,065.1 |  |
| Intersegment sales | 108.4 |  |  | — |  |  | — |  |  | 108.4 |  |
|  | $ | 1,203.7 |  |  | $ | 673.3 |  |  | $ | 296.5 |  |  | $ | 2,173.5 |  |
| Elimination of intersegment sales |  |  |  |  |  |  | $ | (108.4) |  |
| Total consolidated sales |  |  |  |  |  |  | $ | 2,065.1 |  |
| Cost of sales | $ | 819.3 |  |  | 497.4 |  | $ | 162.0 |  |  |  |
| Selling, general and administrative expenses | 187.3 |  |  | 141.6 |  |  | 41.2 |  |  |  |
| Restructuring expense | 0.5 |  |  | — |  |  | 0.6 |  |  |  |
| Segment operating income | $ | 196.6 |  |  | $ | 34.3 |  |  | $ | 92.7 |  |  | $ | 323.6 |  |
| Reconciliation of segment operating income to income before income taxes |  |  |  |  |  |  |  |
| Deferred intersegment profit |  |  |  |  |  |  | $ | 2.2 |  |
| Corporate general and administrative expenses |  |  |  |  |  |  | (63.4) |  |
| Interest expense |  |  |  |  |  |  | (11.8) |  |
| Other income, net |  |  |  |  |  |  | 3.7 |  |
| Foreign exchange expense |  |  |  |  |  |  | (12.1) |  |
| Consolidated income before income taxes |  |  |  |  |  |  | $ | 242.2 |  |

[0000038725-26-000009:notes:235]
| (In millions) | 2025 |  | 2024 |  | 2023 |
| Depreciation and amortization |  |  |  |  |  |
| Water Systems | $ | 45.8 |  |  | $ | 39.0 |  |  | $ | 36.9 |  |
| Distribution | 9.3 |  | 9.6 |  | 7.6 |
| Energy Systems | 4.3 |  | 4.3 |  | 4.2 |
| Total segment depreciation and amortization | $ | 59.4 |  |  | $ | 52.9 |  |  | $ | 48.7 |  |
| Corporate | 3.5 |  | 3.2 |  | 3.6 |
| Total depreciation and amortization | $ | 62.9 |  |  | $ | 56.1 |  |  | $ | 52.3 |  |
| Capital Expenditures |  |  |  |  |  |
| Water Systems | $ | 32.7 |  |  | $ | 27.8 |  |  | $ | 28.6 |  |
| Distribution | 6.2 |  | 9.3 |  | 9.3 |
| Energy Systems | 2.6 |  | 2.3 |  | 3.0 |
| Total segment capital expenditure | $ | 41.5 |  |  | $ | 39.4 |  |  | $ | 40.9 |  |
| Corporate | 3.5 |  | 1.8 |  | 2.3 |
| Total capital expenditure | $ | 45.0 |  |  | $ | 41.2 |  |  | $ | 43.2 |  |
| Assets |  |  |  |  |  |
| Water Systems | $ | 1,235.0 |  |  | $ | 998.8 |  |  | $ | 1,044.4 |  |
| Distribution | 367.2 |  | 358.9 |  | 365.6 |
| Energy Systems | 259.5 |  | 250.4 |  | 256.4 |
| Total segment assets | $ | 1,861.7 |  |  | $ | 1,608.1 |  |  | $ | 1,666.4 |  |
| Corporate | 82.7 |  | 212.5 |  | 61.7 |
| Total assets | $ | 1,944.4 |  |  | $ | 1,820.6 |  |  | $ | 1,728.1 |  |

[0000038725-26-000009:notes:236]
Cash and property, plant and equipment are the major asset groups in “Corporate” of total assets for the years ended December 31, 2025 and December 31, 2024.

[0000038725-26-000009:notes:237]
Financial information by geographic region is as follows:

[0000038725-26-000009:notes:238]
|  | Net sales |  | Long-lived assets |
| (In millions) | 2025 |  | 2024 |  | 2023 |  | 2025 |  | 2024 |  | 2023 |
| United States | $ | 1,446.5 |  |  | $ | 1,400.4 |  |  | $ | 1,441.6 |  |  | $ | 610.3 |  |  | $ | 626.6 |  |  | $ | 625.3 |  |
| Foreign | 684.8 |  |  | 620.9 |  |  | 623.5 |  |  | 368.9 |  |  | 221.6 |  |  | 240.3 |  |
| Consolidated | $ | 2,131.3 |  |  | $ | 2,021.3 |  |  | $ | 2,065.1 |  |  | $ | 979.2 |  |  | $ | 848.2 |  |  | $ | 865.6 |  |

[0000038725-26-000009:notes:239]
Net sales are attributed to geographic regions based upon the ship to location of the customer. Long-lived assets are attributed to geographic regions based upon the country of domicile.

[0000038725-26-000009:notes:240]
The Company offers a large array of products and systems to multiple markets and customers. Product sales information is tracked regionally and products are categorized differently between regions based on local needs and reporting requirements. However, net sales by segment are representative of the Company’s sales by major product category. The Company sells its products through various distribution channels including wholesale and retail distributors, specialty distributors, industrial and petroleum equipment distributors, as well as major oil and utility companies and original equipment manufacturers.

[0000038725-26-000009:notes:241]
No single customer accounted for more than 10 percent of the Company’s net sales in 2025, 2024, or 2023. No single customer accounted for more than 10 percent of the Company’s gross accounts receivable in 2025 or 2024.


## us-gaap:SubsequentEventsTextBlock

[0000038725-26-000009:notes:242]
SUBSEQUENT EVENTS
The Company evaluated subsequent events from December 31, 2025 through the date these financial statements were issued and except for those noted below has noted no subsequent events after December 31, 2025 for which disclosure is required.

[0000038725-26-000009:notes:243]
In January 2026, management approved restructuring actions intended to improve operational efficiency and cost structure.  There are no amounts recognized in our consolidated financial statements as of December 31, 2025 related to these plans as they did not meet the criteria for recognition under ASC 420 and 855. Management currently estimates that the total costs associated with these actions will be approximately $4.0 million and they are expected to be recorded in the first quarter of 2026.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000038725-26-000009:notes:244]
None of the Company’s directors or officers adopted, modified, or terminated a Rule 10b5-1 trading arrangement or a non-Rule 10b5-1 trading arrangement during the Company’s fiscal quarter ended December 31, 2025.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000038725-26-000009:notes:245]
SCHEDULE II - VALUATION AND QUALIFYING ACCOUNTS

[0000038725-26-000009:notes:246]
| (In millions) |  | Balance at Beginning of Period |  | Charged to Costs and Expenses |  | Deductions (a) |  | Other (b) |  | Balance at End of Period |
| 2025 |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 3.5 |  |  | $ | 0.7 |  |  | $ | 0.6 |  |  | $ | 0.2 |  |  | $ | 3.8 |  |
| Allowance for deferred taxes |  | 4.4 |  |  | 0.2 |  |  | 0.2 |  |  | — |  |  | 4.4 |  |
| 2024 |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 3.6 |  |  | $ | 1.6 |  |  | $ | 1.7 |  |  | $ | — |  |  | $ | 3.5 |  |
| Allowance for deferred taxes |  | 4.1 |  |  | 0.7 |  |  | 0.4 |  |  | — |  |  | 4.4 |  |
| 2023 |  |  |  |  |  |  |  |  |  |  |
| Allowance for credit losses |  | $ | 4.2 |  |  | $ | (0.3) |  |  | $ | 0.4 |  |  | $ | 0.1 |  |  | $ | 3.6 |  |
| Allowance for deferred taxes |  | 4.9 |  |  | — |  |  | 0.8 |  |  | — |  |  | 4.1 |  |

[0000038725-26-000009:notes:247]
(a) Charges for which allowances were created.

[0000038725-26-000009:notes:248]
(b) Primarily related to acquisitions
