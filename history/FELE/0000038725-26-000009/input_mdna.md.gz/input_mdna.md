# FELE MD&A — 0000038725-26-000009


## mdna

[0000038725-26-000009:mdna:1]
ITEM 7. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0000038725-26-000009:mdna:2]
Discussion of the year-over-year comparison of changes in the Company's financial condition and results of operation as of and for the fiscal years ended December 31, 2024 and December 31, 2023 can be found in Part II, Item 7. "Management’s Discussion and Analysis of Financial Condition and Results of Operations" of our Annual Report on Form 10-K for the fiscal year ended December 31, 2024.

[0000038725-26-000009:mdna:3]
In the first quarter of 2025, the Company acquired Barnes de Colombia S.A. ("Barnes"), a leading manufacturer and distributor of industrial and commercial pumps based in Colombia. Also in the first quarter of 2025, the Company acquired PumpEng Pty Ltd ("PumpEng"), an Australia-based company that specializes in the design, manufacture and service of submersible pumps for the mining sector. Acquisitions contributed $48.9 million in incremental net sales in 2025. Refer to Note 3 – Acquisitions in the Notes to Consolidated Financial Statements included in Part II, Item 8, "Financial Statements and Supplementary Data" of this Annual Report on Form 10-K for additional information on the Barnes and PumpEng acquisitions.

[0000038725-26-000009:mdna:4]
In 2025, the Company completed the process of settling the Franklin Electric Co,, Inc. Pension Plan and a partial settlement of the Franklin Electric Co. Restoration plan resulting in a pre-tax pension settlement charge of $54.9 million related to actuarial losses previously recorded in Accumulated Other Comprehensive Loss. Refer to Note 10 in Item 8 of this Annual Report on Form 10-K for additional information on the pension settlement charge.

[0000038725-26-000009:mdna:5]
2025 vs. 2024

[0000038725-26-000009:mdna:6]
OVERVIEW

[0000038725-26-000009:mdna:7]
Net sales in 2025 were $2.1 billion and increased 5 percent, as compared to the prior year. The sales increases were due to the incremental sales impact from recent acquisitions, price realization and higher volumes. The Company's consolidated gross profit was $755.9 million and $717.3 million, respectively, for 2025 and 2024, and increased 5 percent from the prior year. Diluted earnings per share was $3.22 for 2025, a decrease of $0.64 from the prior year.  Diluted earnings per share for 2025 was negatively impacted by the pension settlement charge of $41.5 million net of tax benefit ($54.9 million gross of tax benefit)  related to actuarial losses previously recorded in Accumulated Other Comprehensive Loss.  Refer to Note 10 in Item 8 of this Annual Report on Form 10-K for additional information on the pension settlement charge.

[0000038725-26-000009:mdna:8]
RESULTS OF OPERATIONS

[0000038725-26-000009:mdna:9]
Net Sales

[0000038725-26-000009:mdna:10]
Net sales in 2025 were $2.1 billion and increased 5 percent compared to the prior year. The sales growth in 2025 was due to incremental sales impact from recent acquisitions of approximately 3 percent, price realization, and favorable volumes. Sales were negatively impacted by changes in foreign exchange rates, principally due to the strengthening of the U.S. Dollar relative to the Argentine Peso, Turkish Lira and Brazilian Real. However, the Company increased prices in the local currency to offset the impact of currency devaluation in the Argentina and Turkey highly inflationary economies. As a result, the net negative impact of foreign currency exchange rates on net sales was less than 1 percent in 2025.

[0000038725-26-000009:mdna:11]
|  | Net Sales |
| (In millions) | 2025 |  | 2024 |  | 2025 v 2024 |
| Water Systems | $ | 1,256.4 |  |  | $ | 1,184.0 |  |  | $ | 72.4 |  |
| Energy Systems | 299.0 |  |  | 273.7 |  |  | 25.3 |  |
| Distribution | 700.7 |  |  | 685.5 |  |  | 15.2 |  |
| Eliminations | (124.8) |  |  | (121.9) |  |  | (2.9) |  |
| Consolidated | $ | 2,131.3 |  |  | $ | 2,021.3 |  |  | $ | 110.0 |  |

[0000038725-26-000009:mdna:12]
Net Sales-Water Systems

[0000038725-26-000009:mdna:13]
Water Systems net sales increased 6 percent in 2025, as compared to the prior year. The sales growth in 2025 was due to incremental sales impact from recent acquisitions of approximately 4 percent and price realization.

[0000038725-26-000009:mdna:14]
Water Systems net sales in the U.S. and Canada increased 3 percent in 2025, as compared to the prior year. In 2025, sales of large dewatering equipment increased 7 percent, sales of water treatment products increased 6 percent, and sales of groundwater pumping equipment increased 1 percent, and sales of all other surface pumping equipment decreased 1 percent compared to 2024.

[0000038725-26-000009:mdna:15]
Water Systems net sales in markets outside the U.S. and Canada increased 10 percent in 2025, as compared to the prior year. The sales increase compared to prior year period was primarily due to the incremental sales impact from recent acquisitions.

[0000038725-26-000009:mdna:16]
Net Sales-Energy Systems

[0000038725-26-000009:mdna:17]
Energy Systems net sales increased 9 percent in 2025, as compared to the prior year. This sales increase was primarily due to price realization and favorable volumes.

[0000038725-26-000009:mdna:18]
Energy Systems net sales in the U.S. and Canada increased 8 percent in 2025, as compared to the prior year. The increase was broad based across all major product lines, led by fuel pumping systems. Outside the U.S. and Canada, Energy Systems sales increased 13 percent in 2025, as compared to the prior year, due primarily to sales growth in the Asia Pacific region.

[0000038725-26-000009:mdna:19]
Net Sales-Distribution

[0000038725-26-000009:mdna:20]
Distribution net sales increased 2 percent in 2025, as compared to the prior year.  The Distribution segment sales increased due to higher volumes and price realization.

[0000038725-26-000009:mdna:21]
Gross Profit and Expense Ratios

[0000038725-26-000009:mdna:22]
|  | Twelve months ended Dec 31, |
| (In Millions) | 2025 |  | % of Net Sales |  | 2024 |  | % of Net Sales |
| Gross Profit | $ | 755.9 |  |  | 35.5 | % |  | $ | 717.3 |  |  | 35.5 | % |
| Selling, General and Administrative Expense | 486.2 |  |  | 22.8 | % |  | 470.1 |  |  | 23.3 | % |

[0000038725-26-000009:mdna:23]
Gross Profit

[0000038725-26-000009:mdna:24]
The gross profit margin ratio was 35.5 percent in 2025 and 2024, respectively.  Gross profit has remained consistent with prior year primarily due to pricing and volume increases offset by increased costs related to tariffs.

[0000038725-26-000009:mdna:25]
Selling, General and Administrative (“SG&A”)

[0000038725-26-000009:mdna:26]
SG&A expenses were $486.2 million in 2025 compared to $470.1 million in 2024. SG&A expenses increased in 2025 primarily due to the incremental expense impact from recent acquisitions and higher employee compensation costs. The SG&A expenses ratio was 22.8 percent and 23.3 percent in 2025 and 2024, respectively.

[0000038725-26-000009:mdna:27]
Restructuring Expenses

[0000038725-26-000009:mdna:28]
There were $0.7 million and $3.5 million in restructuring expenses in 2025 and 2024, respectively. Restructuring expenses were primarily from various manufacturing realignment activities.

[0000038725-26-000009:mdna:29]
Operating Income

[0000038725-26-000009:mdna:30]
Operating income in 2025 was $268.9 million and $243.6 million in 2024, an increase of 10 percent, as compared to the prior year.

[0000038725-26-000009:mdna:31]
|  |  | Operating income (loss) |
| (In millions) |  | 2025 |  | 2024 |  | 2025 v 2024 |
| Water Systems |  | $ | 207.2 |  |  | $ | 197.9 |  |  | $ | 9.3 |  |
| Energy Systems |  | 99.1 |  |  | 93.6 |  |  | 5.5 |  |
| Distribution |  | 39.8 |  |  | 24.3 |  |  | 15.5 |  |
| Corporate Expenses and Eliminations |  | (77.2) |  |  | (72.2) |  |  | (5.0) |  |
| Consolidated |  | $ | 268.9 |  |  | $ | 243.6 |  |  | $ | 25.3 |  |

[0000038725-26-000009:mdna:32]
Operating Income-Water Systems

[0000038725-26-000009:mdna:33]
Water Systems operating income in 2025 was $207.2 million, an increase of $9.3 million as compared to the prior year. The increase in operating income was primarily due to higher sales. The 2025 operating income margin was 16.5 percent, a decrease of 20 basis points from 16.7 percent in 2024.  The decrease in operating income margin was primarily due to incremental expenses associated with recent acquisitions and an unfavorable product and geographic sales mix shift.

[0000038725-26-000009:mdna:34]
Operating Income-Energy Systems

[0000038725-26-000009:mdna:35]
Energy Systems operating income in 2025 was $99.1 million, an increase of $5.5 million as compared to the prior year. The increase was primarily due to higher sales. The 2025 operating income margin was 33.1 percent, a decrease of 110 basis points

[0000038725-26-000009:mdna:36]
from 34.2 percent in 2024. Operating income margin decreased primarily due to higher tariff cost and an unfavorable geographic sales mix shift.

[0000038725-26-000009:mdna:37]
Operating Income-Distribution

[0000038725-26-000009:mdna:38]
Distribution operating income in 2025 was $39.8 million, an increase of $15.5 million as compared to the prior year. The 2025 operating income margin was 5.7 percent, an increase of 210 basis points from 3.5 percent in 2024. Operating income and operating income margins increased primarily due to higher sales and reduced SG&A expenses as a result of cost actions implemented in 2024 to improve the performance of the segment.

[0000038725-26-000009:mdna:39]
Operating Income-Corporate Expenses and Eliminations

[0000038725-26-000009:mdna:40]
Operating income-Eliminations/Other is composed primarily of intersegment sales and profit eliminations and unallocated general and administrative expenses. The intersegment profit elimination impact in 2025 compared to the prior year of 2024 was an unfavorable $2.0 million. The intersegment elimination of operating income effectively defers the operating income on sales from Water Systems to Distribution in the consolidated financial results until such time as the transferred product is sold from the Distribution segment to its end third party customer. General and administrative expenses increased $3.0 million compared to the prior year, primarily due to higher employee compensation costs, including incremental expenses associated with the Company’s executive leadership transitions.

[0000038725-26-000009:mdna:41]
Interest Expense

[0000038725-26-000009:mdna:42]
Interest expense was $10.6 million and $6.3 million in 2025 and 2024, respectively. The increase in 2025 was primarily driven by higher average amount of outstanding debt.

[0000038725-26-000009:mdna:43]
Other Income, net

[0000038725-26-000009:mdna:44]
Other income, net was a net gain of $0.6 million and $1.3 million in 2025 and 2024, respectively.

[0000038725-26-000009:mdna:45]
Pension settlement loss

[0000038725-26-000009:mdna:46]
The loss in 2025 is primarily due to the Company’s settlement of its US Pension Plan and a partial settlement of the Franklin Electric Co. Restoration plan, which resulted in a pre-tax loss of $54.9 million related to actuarial losses previously recorded in Accumulated Other Comprehensive Loss. Refer to Note 10 in Item 8 of this Annual Report on Form 10-K for additional information on the pension settlement charge.

[0000038725-26-000009:mdna:47]
Foreign Exchange

[0000038725-26-000009:mdna:48]
Foreign currency-based transactions produced an expense of $9.3 million and an expense of $6.8 in 2025 and 2024, respectively. The results in 2025 and 2024 are primarily due to transaction losses associated with the Argentine Peso and Turkish Lira relative to the U.S. dollar. The Company reports the results of its subsidiaries in Argentina and Turkey using highly inflationary accounting, which requires that the functional currency of the entity be changed to the reporting currency of its parent.

[0000038725-26-000009:mdna:49]
Income Taxes

[0000038725-26-000009:mdna:50]
The provision for income taxes 2025 and 2024 were $46.0 million and $50.2 million, respectively. The effective tax rate for 2025 was about 24 percent before and after the impact of discrete events. The effective tax rate for 2024 was about 22 percent and included a favorable benefit from discrete events of 1 percent. The effective tax rate differs from the U.S. statutory rate of 21 percent primarily due to foreign earnings taxed at rates higher than the U.S. statutory rate, U.S. state taxes, Pillar Two Global Minimum Tax, and nondeductible officer’s compensation, which were partially offset by an object exemption of foreign business profits in the Netherlands, the recognition of the U.S. foreign-derived intangible income (FDII) provisions, certain incentives, and discrete events.

[0000038725-26-000009:mdna:51]
Net Income

[0000038725-26-000009:mdna:52]
Net income for 2025 was $148.7 million compared to 2024 net income of $181.6 million. Net income attributable to Franklin Electric Co., Inc. for 2025 was $147.1 million, or $3.22 per diluted share, compared to 2024 net income attributable to Franklin Electric Co., Inc. of $180.3 million, or $3.86 per diluted share.

[0000038725-26-000009:mdna:53]
CAPITAL RESOURCES AND LIQUIDITY

[0000038725-26-000009:mdna:54]
Sources of Liquidity

[0000038725-26-000009:mdna:55]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at December 31, 2025 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations,

[0000038725-26-000009:mdna:56]
capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-26-000009:mdna:57]
As of December 31, 2025, the Company had a $350.0 million revolving credit facility. The facility is scheduled to mature on May 14, 2030. As of December 31, 2025, the Company had $313.6 million borrowing capacity under the Credit Agreement as $6.4 million in letters of commercial and standby letters of credit were outstanding and undrawn and $30.0 million in revolver borrowings were drawn or outstanding.

[0000038725-26-000009:mdna:58]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"). On May 15, 2024, the Company entered into Amendment No. 1 that increased the total available facility amount from lenders to $250.0 million from $200.0 million. On September 26, 2025, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2032. As of December 31, 2025, the remaining borrowing capacity on the New York Life Agreement was $175.0 million. The Company also maintains an uncommitted and unsecured note purchase and private shelf agreement with PGIM, Inc. and its affiliates (the "Prudential Agreement"). On May 15, 2024, the Company entered into Amendment No. 1 that increased the total available facility amount from lenders to $250.0 million from $150.0 million. On September 26, 2025, the Company issued and sold $50.0 million of fixed rate senior notes due September 26, 2032.

[0000038725-26-000009:mdna:59]
At December 31, 2025, the Company had $67.3 million of cash and cash equivalents held in foreign jurisdictions, which the Company intends to use to fund foreign operations. There is currently no need to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-26-000009:mdna:60]
Cash Flows

[0000038725-26-000009:mdna:61]
The following table summarizes significant sources and uses of cash and cash equivalents:

[0000038725-26-000009:mdna:62]
| (in millions) | 2025 |  | 2024 |
| Cash flows from operating activities | $ | 238.9 |  |  | $ | 261.4 |  |
| Cash flows from investing activities | $ | (157.1) |  |  | $ | (45.6) |  |
| Cash flows from financing activities | $ | (197.3) |  |  | $ | (74.1) |  |
| Impact of exchange rates on cash and cash equivalents | $ | (5.3) |  |  | $ | (6.1) |  |
| Change in cash and cash equivalents | $ | (120.9) |  |  | $ | 135.6 |  |

[0000038725-26-000009:mdna:63]
Cash Flows from Operating Activities

[0000038725-26-000009:mdna:64]
2025 vs 2024

[0000038725-26-000009:mdna:65]
Net cash provided by operating activities was $238.9 million for 2025 compared to $261.4 million for 2024. The change in operating cash flow was primarily attributable to changes in working capital offset by an increase in cash earnings.

[0000038725-26-000009:mdna:66]
Cash Flows from Investing Activities

[0000038725-26-000009:mdna:67]
2025 vs. 2024

[0000038725-26-000009:mdna:68]
Net cash used in investing activities was $157.1 million in 2025 compared to $45.6 million in 2024. The change in investing cash flow was primarily attributable to increased acquisition activity in 2025.

[0000038725-26-000009:mdna:69]
Cash Flows from Financing Activities

[0000038725-26-000009:mdna:70]
2025 vs. 2024

[0000038725-26-000009:mdna:71]
Net cash used by financing activities was $197.3 million in 2025 compared to $74.1 million in 2024. The change in financing cash flow was primarily due to increased repurchases of Company stock, offset by higher net borrowings under the Company's credit facility in 2025 compared to 2024.

[0000038725-26-000009:mdna:72]
AGGREGATE CONTRACTUAL OBLIGATIONS

[0000038725-26-000009:mdna:73]
The majority of the Company’s contractual obligations to third parties relate to debt obligations. In addition, the Company has certain contractual obligations for future lease payments and purchase obligations. The payment schedule for these contractual obligations is as follows:

[0000038725-26-000009:mdna:74]
| (In millions) |  |  |  |  |  |  |  |  | More than |
|  | Total |  | 2026 |  | 2027-2028 |  | 2029-2030 |  | 5 years |
| Debt | $ | 167.1 |  |  | $ | 31.8 |  |  | $ | 3.0 |  |  | $ | 3.1 |  |  | $ | 129.2 |  |
| Debt interest | 49.5 |  |  | 8.5 |  |  | 14.4 |  |  | 13.8 |  |  | 12.8 |  |
| Operating leases | 77.6 |  |  | 24.4 |  |  | 31.0 |  |  | 13.5 |  |  | 8.7 |  |
| Purchase obligations | 8.5 |  |  | 8.5 |  |  | — |  |  | — |  |  | — |  |
|  | $ | 302.7 |  |  | $ | 73.2 |  |  | $ | 48.4 |  |  | $ | 30.4 |  |  | $ | 150.7 |  |

[0000038725-26-000009:mdna:75]
Interest payments on debt obligations are calculated for future periods using interest rates in effect at the end of 2025. Certain of these projected interest payments may differ in the future based on interest rates or other factors or events. The projected interest payments only pertain to obligations and agreements outstanding at December 31, 2025.

[0000038725-26-000009:mdna:76]
The Company has pension and other post-retirement benefit obligations not included in the table above which will result in estimated future payments of approximately $6.2 million in 2026. In addition, due to the timing of funding in future periods being uncertain and dependent on future movements in interest rates, investment returns, changes in laws and regulations and other variables, the table above excludes the non-current liability of $17.0 million for cash outflows related to the Company's pension plans.

[0000038725-26-000009:mdna:77]
The Company also has unrecognized tax benefits, none of which are included in the table above. The unrecognized tax benefits of approximately $3.0 million have been recorded as liabilities and the Company is uncertain as to if or when such amounts may be settled. Related to the unrecognized tax benefits, the Company has also recorded a liability for potential penalties and interest of $1.1 million.

[0000038725-26-000009:mdna:78]
ACCOUNTING PRONOUNCEMENTS

[0000038725-26-000009:mdna:79]
For information regarding recent accounting pronouncements, refer to Note 2 - Accounting Pronouncements, in the Notes to Consolidated Financial Statements in the sections entitled "Adoption of New Accounting Standards" and "Accounting Standards Issued But Not Yet Adopted", included in Part II, Item 8, "Financial Statements and Supplementary Data" of this Annual Report on Form 10-K.

[0000038725-26-000009:mdna:80]
CRITICAL ACCOUNTING ESTIMATES

[0000038725-26-000009:mdna:81]
Management’s discussion and analysis of its financial condition and results of operations are based upon the Company’s consolidated financial statements, which have been prepared in accordance with accounting principles generally accepted in the United States of America. The preparation of these financial statements requires management to make estimates and judgments that affect the reported amounts of assets, liabilities, revenues and expenses, and the related disclosure of contingent assets and liabilities. Management evaluates estimates on an ongoing basis. Estimates are based on historical experience and on other assumptions that are believed to be reasonable under the circumstances, the results of which form the basis for making judgments about the carrying value of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. There were no material changes to estimates or methodologies used to develop those estimates in 2025. The Company’s critical accounting estimates are identified below:

[0000038725-26-000009:mdna:82]
Inventory Valuation

[0000038725-26-000009:mdna:83]
The Company uses certain estimates and judgments to value inventory. Inventory is recorded at the lower of cost or net realizable value. The Company reviews its inventories for excess or obsolete products or components. Based on an analysis of historical usage, management’s evaluation of estimated future demand, market conditions, and alternative uses for possible excess or obsolete parts, carrying values are adjusted. The carrying value is reduced regularly to reflect the age and current anticipated product demand. If actual demand differs from the estimates, additional reductions would be necessary in the period such determination is made. Excess and obsolete inventory is periodically disposed of through sale to third parties, scrapping, or other means.

[0000038725-26-000009:mdna:84]
Business Combinations and Valuation of Acquired Intangible Assets

[0000038725-26-000009:mdna:85]
The Company follows the guidance under FASB ASC Topic 805, Business Combinations. The acquisition purchase price is allocated to the assets acquired and liabilities assumed based upon their respective fair values. The Company utilizes management estimates and may use an independent third-party valuation firm to assist in determining the fair values of assets

[0000038725-26-000009:mdna:86]
acquired, including intangible assets, and liabilities assumed. The identifiable intangible assets acquired typically include customer relationships and trade names. Identifiable intangible assets are initially valued using a methodology commensurate with the intended use of the asset. The fair value of customer relationships is measured using the multi-period excess earnings method ("MPEEM"). The fair value of trade names is measured using a relief-from-royalty ("RFR") approach, which assumes the value of the trade name is the discounted amount of cash flows that would be paid to third parties had the Company not owned the trade name and instead licensed the trade name from another company. Higher royalty rates are assigned to premium brands within the marketplace based on name recognition and profitability, while other brands receive lower royalty rates. The basis for future sales projections for both the RFR and MPEEM are based on internal revenue forecasts which the Company believes represents reasonable market participant assumptions. The future cash flows are discounted using an applicable discount rate as well as any potential risk premium to reflect the inherent risk of holding a standalone intangible asset.  The key uncertainties in the RFR and MPEEM calculations, as applicable, are the selection of an appropriate royalty rate, assumptions used in developing estimates of future cash flows, including revenue growth and expense forecasts, assumed customer attrition rates, as well as the perceived risk associated with those forecasts in determining the discount rate and risk premium.  There is inherent uncertainty in forecasted future cash flows and therefore, actual results may differ and could result in subsequent impairment charges of acquired intangible assets and/or goodwill.

[0000038725-26-000009:mdna:87]
Indefinite-Lived Intangible Asset and Goodwill Impairment Evaluation

[0000038725-26-000009:mdna:88]
According to FASB ASC Topic 350, Intangibles - Goodwill and Other, goodwill and other intangible assets with indefinite lives must be tested for impairment at least annually or more frequently as warranted by triggering events that indicate potential impairment. The Company has the option to assess goodwill and other indefinite-lived intangible assets for impairment by initially performing a qualitative assessment to determine whether it is more-likely-than-not that the fair value of a reporting unit or indefinite-lived intangible asset is less than its carrying amount. If the Company determines that it is not more-likely-than-not that the fair value of a reporting unit or indefinite-lived intangible asset is less than its carrying amount, then a quantitative impairment test is not required to be performed. If the Company determines that it is more-likely-than-not that the fair value of a reporting unit or indefinite-lived intangible asset is less than its carrying amount, or if it does not elect the option to perform an initial qualitative assessment, it performs a quantitative impairment test.

[0000038725-26-000009:mdna:89]
The Company uses a variety of methodologies in conducting impairment assessments including qualitative reviews as well as quantitative reviews using the income and market approaches.

[0000038725-26-000009:mdna:90]
The market value approach compares the reporting units’ current and projected financial results to entities of similar size and industry to determine the market value of the reporting unit. The income approach utilizes assumptions regarding estimated future cash flows and other factors to determine the fair value of the respective assets. These cash flows consider factors regarding expected future operating income and historical trends, as well as the effects of demand and competition. The future cash flows are discounted using an applicable discount rate. The Company is required to record an impairment if these assumptions and estimates change whereby the fair value of the reporting units or indefinite-lived intangible assets are below their associated carrying values.

[0000038725-26-000009:mdna:91]
During the fourth quarter of 2025, the Company completed its annual impairment tests of goodwill and indefinite-lived trade names. The Company determined that the fair value of goodwill and all intangibles were substantially in excess of the respective carrying values. A 10 percent decrease in the estimated fair value of goodwill or any of the indefinite-lived trade names would not have changed this determination. The sensitivity analysis required the use of numerous subjective assumptions, which, if actual experience varies, could result in material differences in the requirements for impairment charges. Further, an extended downturn in the economy may impact certain components of the operating segments more significantly and could result in an impairment determination.

[0000038725-26-000009:mdna:92]
Income Taxes

[0000038725-26-000009:mdna:93]
Under the requirements of FASB ASC Topic 740, Income Taxes, the Company records deferred tax assets and liabilities for the future tax consequences attributable to differences between financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using enacted tax rates expected to apply to taxable income in the years in which those temporary differences are expected to be recovered or settled. The Company analyzes the deferred tax assets and liabilities for their future realization based on the estimated existence of sufficient taxable income. This analysis considers the following sources of taxable income: prior year taxable income, future reversals of existing taxable temporary differences, future taxable income exclusive of reversing temporary differences and tax planning strategies that would generate taxable income in the relevant period. If sufficient taxable income is not projected then the Company will record a valuation allowance against the relevant deferred tax assets.

[0000038725-26-000009:mdna:94]
The Company’s operations involve dealing with uncertainties and judgments in the application of complex tax regulations in multiple jurisdictions. These jurisdictions have different tax rates, and the Company determines the allocation of income to each

[0000038725-26-000009:mdna:95]
of these jurisdictions based upon various estimates and assumptions. In the normal course of business, the Company will undergo tax audits by various tax jurisdictions. Such audits often require an extended period of time to complete and may result in income tax adjustments if changes to the allocation are required between jurisdictions with different tax rates. The final taxes paid are dependent upon many factors, including negotiations with taxing authorities in the various jurisdictions and resolution of disputes arising from federal, state, and international tax audits. Although the Company has recorded all income tax uncertainties in accordance with FASB ASC Topic 740, these accruals represent estimates that are subject to the inherent uncertainties associated with the tax audit process. Management judgment is required in determining the Company’s provision for income taxes, deferred tax assets and liabilities, which, if actual experience varies, could result in material adjustments to tax expense and/or deferred tax assets and liabilities.

[0000038725-26-000009:mdna:96]
Pension and Employee Benefit Obligations

[0000038725-26-000009:mdna:97]
The Company consults with its actuaries to assist with the calculation of discount rates used in its pension and post retirement plans. The discount rates used to determine domestic pension and post-retirement plan liabilities are calculated using a full yield curve approach. The weighted-average discount rate was 5.48 percent last year compared to 4.07 percent this year for the domestic pension plans and from 5.47 percent last year to 5.04 percent this year for the postretirement health and life insurance plan. A change in the discount rate selected by the Company of 25 basis points would result in no material change to employee benefit expense and a change of about $0.2 million of liability.

[0000038725-26-000009:mdna:98]
One of the Company's domestic defined benefit plans was settled and terminated in 2025. For additional information, see note 10 - Employee Benefit Plans.

[0000038725-26-000009:mdna:99]
FACTORS THAT MAY AFFECT FUTURE RESULTS
