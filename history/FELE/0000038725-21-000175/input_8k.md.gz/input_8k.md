# FELE 8-K — 0000038725-21-000170 filed 2021-07-27

## item codes, every 8-K on or before 2021-08-03

- 2021-07-27 0000038725-21-000172 — 7.01, 9.01
- 2021-07-27 0000038725-21-000170 — 2.02, 9.01
- 2021-06-14 0000038725-21-000157 — 5.02, 7.01, 9.01
- 2021-05-17 0000038725-21-000120 — 7.01, 9.01
- 2021-05-17 0000038725-21-000118 — 7.01, 9.01
- 2021-05-13 0000038725-21-000102 — 2.03, 9.01
- 2021-05-07 0000038725-21-000096 — 5.07
- 2021-05-07 0000038725-21-000094 — 5.02, 9.01
- 2021-04-27 0000038725-21-000088 — 7.01, 9.01
- 2021-04-27 0000038725-21-000085 — 2.02, 9.01
- 2021-04-01 0000038725-21-000080 — 7.01, 9.01
- 2021-02-17 0000038725-21-000013 — 7.01, 9.01
- 2021-02-16 0000038725-21-000010 — 2.02, 9.01
- 2021-01-04 0000038725-21-000003 — 7.01, 9.01
- 2020-12-18 0000038725-20-000241 — 5.02, 9.01
- 2020-11-09 0000038725-20-000223 — 7.01, 9.01
- 2020-11-02 0000038725-20-000210 — 7.01, 9.01
- 2020-10-27 0000038725-20-000206 — 2.02, 9.01
- 2020-07-28 0000038725-20-000168 — 2.02, 9.01
- 2020-06-25 0000038725-20-000164 — 8.01, 9.01
- 2020-06-25 0000038725-20-000163 — 8.01, 9.01
- 2020-05-11 0000038725-20-000133 — 5.02, 9.01
- 2020-05-08 0000038725-20-000119 — 5.07
- 2020-05-06 0000038725-20-000111 — 5.02, 9.01
- 2020-04-28 0000038725-20-000104 — 2.02, 9.01
- 2020-02-18 0000038725-20-000018 — 2.02, 9.01
- 2020-01-30 0000038725-20-000009 — 5.02, 5.03, 9.01
- 2019-11-04 0000038725-19-000234 — 7.01, 9.01
- 2019-10-29 0000038725-19-000221 — 2.02, 9.01
- 2019-08-01 0000038725-19-000193 — 7.01, 9.01
- 2019-07-23 0000038725-19-000178 — 2.02, 9.01
- 2019-05-07 0000038725-19-000140 — 5.03, 9.01
- 2019-05-03 0000038725-19-000124 — 5.07
- 2019-05-03 0000038725-19-000122 — 7.01, 9.01
- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2021-08-03

- none on or before 2021-08-03

## item 2.02 — earnings release, exhibit 99.1

[0000038725-21-000170:8k_2_02:1]
EX-99.1
2
a20210727ex991earningsrele.htm
EX-99.1

[0000038725-21-000170:8k_2_02:2]
Document

[0000038725-21-000170:8k_2_02:3]
Exhibit 99.1

[0000038725-21-000170:8k_2_02:4]
NEWS RELEASE FOR IMMEDIATE DISTRIBUTION

[0000038725-21-000170:8k_2_02:5]
FRANKLIN ELECTRIC REPORTS RECORD SECOND QUARTER 2021 RESULTS

[0000038725-21-000170:8k_2_02:6]
Second Quarter 2021 Highlights

[0000038725-21-000170:8k_2_02:7]
•Record sales of $437.3 million, compared to second quarter 2020 sales of $308.3 million, an increase of 42%

[0000038725-21-000170:8k_2_02:8]
•Strong organic sales growth in all three Segments: Distribution 41%; Fueling Systems 27%; and Water Systems 23%

[0000038725-21-000170:8k_2_02:9]
•Operating income was $51.6 million, compared to second quarter 2020 operating income of $33.9 million, an increase of 52%

[0000038725-21-000170:8k_2_02:10]
•GAAP fully diluted earnings per share (EPS) was $0.83 a record for any quarter

[0000038725-21-000170:8k_2_02:11]
•Working capital as a percent of trailing twelve months sales improved 450 basis points to 27.2%

[0000038725-21-000170:8k_2_02:12]
Fort Wayne, IN – July 27, 2021 – Franklin Electric Co. Inc. today announced second quarter 2021 financial results.

[0000038725-21-000170:8k_2_02:13]
Second quarter 2021 sales were $437.3 million, compared to second quarter 2020 sales of $308.3 million, an increase of 42 percent.  Second quarter 2021 operating income was $51.6 million, compared to second quarter 2020 operating income of $33.9 million, an increase of 52 percent.

[0000038725-21-000170:8k_2_02:14]
Second quarter 2021 GAAP fully diluted earnings per share (EPS) was $0.83, versus second quarter 2020 GAAP fully diluted EPS of $0.52.

[0000038725-21-000170:8k_2_02:15]
“In the second quarter of 2021, we delivered the highest sales and operating income for any quarter in Franklin’s history, which included record revenue in Water Systems and Distribution, record operating income in Distribution and a strong performance in Fueling Systems, most notably in the U.S. This robust performance was propelled by a favorable demand environment and solid execution by our team. Further, our international businesses posted strong results across almost all regions, as we continued to carefully navigate a challenging operating environment. As a result, we posted year-over-year revenue and earnings per share growth of 42 percent and 60 percent, respectively. While supply chain constraints and inflation have presented challenges, we have remained agile and disciplined, positioning us to further capitalize on the opportunities in front of us,” commented Gregg Sengstack, Franklin Electric’s Chairperson and Chief Executive Officer.

[0000038725-21-000170:8k_2_02:16]
Mr. Sengstack continued, “Our second quarter acquisitions have further established a meaningful Water Treatment platform in North America. We remain confident as we look to the remainder of the year, as we believe we have ample runway to execute on our strategic plan and drive continued growth across the business.”

[0000038725-21-000170:8k_2_02:17]
Segment Summaries

[0000038725-21-000170:8k_2_02:18]
Water Systems sales, a new record for any quarter, were $247.2 million in the second quarter 2021, an increase of $68.8 million or 39 percent versus the second quarter 2020. Water Systems sales, excluding acquisitions and the impact of foreign currency translation, were up about 23 percent compared to the second quarter 2020. Sales of groundwater, surface and dewatering pump equipment all increased significantly due to strong end market demand and because the second quarter of 2020 was impacted negatively by the global pandemic. Water Systems operating income in the second quarter was $34.6 million driven by higher sales but offset in part by the inflationary impact of higher raw material and freight costs. Second quarter 2020 Water Systems operating income was $28.7 million.

[0000038725-21-000170:8k_2_02:19]
Distribution sales were a record at $144.8 million in the second quarter 2021. The Distribution segment organic sales increased 41 percent compared to the second quarter of 2020. Revenue growth was driven by broad-based demand in all regions and product categories. The Distribution segment operating income was a record at $16.0 million in the second quarter of 2021 compared to second quarter 2020 operating income of $6.8 million.

[0000038725-21-000170:8k_2_02:20]
Fueling Systems sales were $72.2 million in the second quarter 2021, an increase of $16.2 million versus the second quarter 2020. Fueling Systems sales in the U.S. and Canada increased by about 40 percent compared to the second quarter 2020. The increase was due to higher demand for Piping, Pumping and Fuel Management Systems. Outside the U.S. and Canada, Fueling Systems revenues increased by about 1 percent, driven primarily by higher sales in Latin America and EMENA, partially offset by lower sales in China. Fueling Systems operating income in the second quarter was $18.5 million, compared to $13.5 million in the second quarter of 2020, driven by higher sales.

[0000038725-21-000170:8k_2_02:21]
Cash Flow

[0000038725-21-000170:8k_2_02:22]
Net cash flows from operating activities for the first half of 2021 were $35.5 million versus $47.0 million in the same period in 2020. The decrease was primarily due to higher working capital requirements in support of higher revenues.

[0000038725-21-000170:8k_2_02:23]
2021 Guidance

[0000038725-21-000170:8k_2_02:24]
The Company is maintaining its most recent full year 2021 earnings per share before restructuring expenses to be in the range from $2.85 to $3.05.  The Company’s 2021 guidance assumes there will not be any worsening impacts from supply chain disruptions and the global pandemic.

[0000038725-21-000170:8k_2_02:25]
Earnings Conference Call

[0000038725-21-000170:8k_2_02:26]
A conference call to review earnings and other developments in the business will commence at 9:00 am ET. The second quarter 2021 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-21-000170:8k_2_02:27]
https://edge.media-server.com/mmc/p/br8axpfg

[0000038725-21-000170:8k_2_02:28]
If you intend to ask questions during the call, please dial in using 877.643.7158 for domestic calls and 914.495.8565 for international calls. The conference ID is 6592147.

[0000038725-21-000170:8k_2_02:29]
A replay of the conference call will be available Tuesday, July 27, 2021 at 12:00 noon ET through noon ET on Tuesday, August 3, 2021, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls. The replay passcode is 6592147.

[0000038725-21-000170:8k_2_02:30]
Forward Looking Statements

[0000038725-21-000170:8k_2_02:31]
About Franklin Electric

[0000038725-21-000170:8k_2_02:32]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-21-000170:8k_2_02:33]
Franklin Electric Contact:

[0000038725-21-000170:8k_2_02:34]
Jeffery L. Taylor

[0000038725-21-000170:8k_2_02:35]
Franklin Electric Co., Inc.

[0000038725-21-000170:8k_2_02:36]
260-824-2900

[0000038725-21-000170:8k_2_02:37]
Email: jeffery.taylor@fele.com

[0000038725-21-000170:8k_2_02:38]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |
| (Unaudited) |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2021 |  | June 30, 2020 |  | June 30, 2021 |  | June 30, 2020 |
| Net sales | $ | 437,280 |  |  | $ | 308,281 |  |  | $ | 770,326 |  |  | $ | 575,035 |  |
| Cost of sales | 285,041 |  |  | 201,159 |  |  | 502,541 |  |  | 377,596 |  |
| Gross profit | 152,239 |  |  | 107,122 |  |  | 267,785 |  |  | 197,439 |  |
| Selling, general, and administrative expenses | 100,485 |  |  | 72,314 |  |  | 182,088 |  |  | 147,937 |  |
| Restructuring expense | 153 |  |  | 875 |  |  | 305 |  |  | 1,748 |  |
| Operating income | 51,601 |  |  | 33,933 |  |  | 85,392 |  |  | 47,754 |  |
| Interest expense | (1,366) |  |  | (1,132) |  |  | (2,456) |  |  | (2,366) |  |
| Other income/(expense), net | (430) |  |  | (397) |  |  | (530) |  |  | (599) |  |
| Foreign exchange income/(expense) | (1,189) |  |  | (906) |  |  | (1,246) |  |  | 56 |  |
| Income before income taxes | 48,616 |  |  | 31,498 |  |  | 81,160 |  |  | 44,845 |  |
| Income tax (benefit)/ expense | 9,253 |  |  | 6,696 |  |  | 13,634 |  |  | 9,251 |  |
| Net income | $ | 39,363 |  |  | $ | 24,802 |  |  | $ | 67,526 |  |  | $ | 35,594 |  |
| Less: Net (income)/loss attributable to noncontrolling interests | (222) |  |  | (151) |  |  | (505) |  |  | (300) |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 39,141 |  |  | $ | 24,651 |  |  | $ | 67,021 |  |  | $ | 35,294 |  |
| Income per share: |  |  |  |  |  |  |  |
| Basic | $ | 0.84 |  |  | $ | 0.53 |  |  | $ | 1.44 |  |  | $ | 0.76 |  |
| Diluted | $ | 0.83 |  |  | $ | 0.52 |  |  | $ | 1.42 |  |  | $ | 0.75 |  |

[0000038725-21-000170:8k_2_02:39]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED BALANCE SHEETS |
| (Unaudited) |
| (In thousands) |  |  |  |
|  | June 30, 2021 |  | December 31, 2020 |
| ASSETS |  |
| Cash and equivalents | $ | 81,597 |  |  | $ | 130,787 |  |
| Receivables (net) | 226,074 |  |  | 159,827 |  |
| Inventories | 350,121 |  |  | 300,932 |  |
| Other current assets | 33,474 |  |  | 27,708 |  |
| Total current assets | 691,266 |  |  | 619,254 |  |
| Property, plant, and equipment, net | 210,423 |  |  | 209,021 |  |
| Right-of-use asset, net | 35,881 |  |  | 31,954 |  |
| Goodwill and other assets | 573,275 |  |  | 412,078 |  |
| Total assets | $ | 1,510,845 |  |  | $ | 1,272,307 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 148,862 |  |  | $ | 95,903 |  |
| Accrued expenses and other current liabilities | 93,035 |  |  | 94,160 |  |
| Current lease liability | 12,680 |  |  | 11,090 |  |
| Current maturities of long-term debt and short-term borrowings | 132,428 |  |  | 2,551 |  |
| Total current liabilities | 387,005 |  |  | 203,704 |  |
| Long-term debt | 91,279 |  |  | 91,966 |  |
| Long-term lease liability | 23,416 |  |  | 20,866 |  |
| Income taxes payable non-current | 11,610 |  |  | 11,965 |  |
| Deferred income taxes | 27,373 |  |  | 25,671 |  |
| Employee benefit plans | 41,386 |  |  | 44,443 |  |
| Other long-term liabilities | 25,145 |  |  | 23,988 |  |
| Redeemable noncontrolling interest | (209) |  |  | (245) |  |
| Total equity | 903,840 |  |  | 849,949 |  |
| Total liabilities and equity | $ | 1,510,845 |  |  | $ | 1,272,307 |  |

[0000038725-21-000170:8k_2_02:40]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |
| (Unaudited) |
|  | Six Months Ended |
| (In thousands) |  |  |  |
|  | June 30, 2021 |  | June 30, 2020 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 67,526 |  |  | $ | 35,594 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 20,535 |  |  | 17,990 |  |
| Non-cash lease expense | 6,471 |  |  | 5,283 |  |
| Share-based compensation | 6,573 |  |  | 7,015 |  |
| Other | 1,753 |  |  | 267 |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (62,860) |  |  | (17,820) |  |
| Inventory | (41,848) |  |  | (7,520) |  |
| Accounts payable and accrued expenses | 50,262 |  |  | 8,561 |  |
| Operating leases | (6,471) |  |  | (5,283) |  |
| Income taxes-U.S. Tax Cuts and Jobs Act | (355) |  | — |
| Other | (6,056) |  |  | 2,914 |  |
| Net cash flows from operating activities | 35,530 |  |  | 47,001 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (12,777) |  |  | (9,445) |  |
| Proceeds from sale of property, plant, and equipment | 8 |  |  | 25 |  |
| Acquisitions and investments | (180,917) |  |  | (5,826) |  |
| Other investing activities | 27 |  |  | 3 |  |
| Net cash flows from investing activities | (193,659) |  |  | (15,243) |  |
| Cash flows from financing activities: |  |  |  |
| Change in debt | 129,264 |  |  | (17,908) |  |
| Proceeds from issuance of common stock | 8,989 |  |  | 1,520 |  |
| Purchases of common stock | $ | (11,231) |  |  | $ | (17,724) |  |
| Dividends paid | (16,320) |  |  | (14,446) |  |
| Purchase of redeemable non-controlling shares | — |  |  | — |  |
| Net cash flows from financing activities | 110,702 |  |  | (48,558) |  |
| Effect of exchange rate changes on cash | (1,763) |  |  | (4,522) |  |
| Net change in cash and equivalents | (49,190) |  |  | (21,322) |  |
| Cash and equivalents at beginning of period | 130,787 |  |  | 64,405 |  |
| Cash and equivalents at end of period | $ | 81,597 |  |  | $ | 43,083 |  |

[0000038725-21-000170:8k_2_02:41]
Key Performance Indicators: Earnings Per Share Calculations

[0000038725-21-000170:8k_2_02:42]
| Earnings Before and After Restructuring |  | For the Second Quarter |  |  |
| (in millions) |  | 2021 | 2020 | Change |  |  |  |  |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 39.1 |  | $ | 24.7 |  | 58 | % |  |  |  |  |
| Allocated Earnings |  | $ | (0.2) |  | $ | (0.2) |  |  |  |  |  |  |
| Earnings for EPS Calculations |  | $ | 38.9 |  | $ | 24.5 |  | 59 | % |  |  |  |  |
| Restructuring (before tax): |  | $ | 0.2 |  | $ | 0.9 |  |  |  |  |  |  |
| Restructuring, net of tax: |  | $ | 0.2 |  | $ | 0.7 |  |  |  |  |  |  |
| Earnings Before Restructuring |  | $ | 39.1 |  | $ | 25.2 |  | 55 | % |  |  |  |  |
| Earnings Per Share |  | For the Second Quarter |  |  |
| Before and After Restructuring |  | 2021 | 2020 | Change |  |  |  |  |
| (in millions except Earnings Per Share) |  |  |  |  |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 47.1 |  | 46.5 |  | 1 | % |  |  |  |  |
| Fully Diluted Earnings Per Share (“EPS”) Reported |  | $ | 0.83 |  | $ | 0.52 |  | 60 | % |  |  |  |  |
| Restructuring Per Share, net of tax |  | $ | — |  | $ | 0.02 |  |  |  |  |  |  |
| Fully Diluted EPS Before Restructuring |  | $ | 0.83 |  | $ | 0.54 |  | 54 | % |  |  |  |  |

[0000038725-21-000170:8k_2_02:43]
Key Performance Indicators: Net Sales Summary

[0000038725-21-000170:8k_2_02:44]
|  | Net Sales |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q2 2020 | $ | 99.0 |  | $ | 24.2 |  | $ | 35.5 |  | $ | 19.7 |  | $ | 178.4 |  | $ | 56.0 |  | $ | 92.1 |  | $ | (18.2) |  | $ | 308.3 |  |
| Q2 2021 | $ | 141.0 |  | $ | 34.7 |  | $ | 51.4 |  | $ | 20.1 |  | $ | 247.2 |  | $ | 72.2 |  | $ | 144.8 |  | $ | (26.9) |  | $ | 437.3 |  |
| Change | $ | 42.0 |  | $ | 10.5 |  | $ | 15.9 |  | $ | 0.4 |  | $ | 68.8 |  | $ | 16.2 |  | $ | 52.7 |  | $ | (8.7) |  | $ | 129.0 |  |
| % Change | 42 | % | 43 | % | 45 | % | 2 | % | 39 | % | 29 | % | 57 | % |  | 42 | % |
| Foreign currency translation | $ | 1.5 |  | $ | (0.2) |  | $ | 2.7 |  | $ | 0.8 |  | $ | 4.8 |  | $ | 1.3 |  | $ | — |  |  |  |
| % Change | 2 | % | (1) | % | 8 | % | 4 | % | 3 | % | 2 | % | — | % |  |  |
| Acquisitions | $ | 23.8 |  | $ | — |  | $ | — |  | $ | — |  | $ | 23.8 |  | $ | — |  | $ | 15.1 |  |  |  |
| Volume/Price | $ | 16.7 |  | $ | 10.7 |  | $ | 13.2 |  | $ | (0.4) |  | $ | 40.2 |  | $ | 14.9 |  | $ | 37.6 |  |  |  |
| % Change | 17 | % | 44 | % | 37 | % | (2) | % | 23 | % | 27 | % | 41 | % |  |  |

[0000038725-21-000170:8k_2_02:45]
Key Performance Indicators: Operating Income and Margin Summary

[0000038725-21-000170:8k_2_02:46]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Second Quarter 2021 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 34.6 |  | $ | 18.5 |  | $ | 16.0 |  | $ | (17.5) |  | $ | 51.6 |  |
| % Operating Income To Net Sales | 14.0 | % | 25.6 | % | 11.0 | % |  | 11.8 | % |
| Restructuring | $ | 0.1 |  | $ | — |  | $ | — |  | $ | — |  | $ | 0.1 |  |
| Operating Income/(Loss) Before Restructuring | $ | 34.7 |  | $ | 18.5 |  | $ | 16.0 |  | $ | (17.5) |  | $ | 51.7 |  |
| % Operating Income to Net Sales Before Restructuring | 14.0 | % | 25.6 | % | 11.0 | % |  | 11.8 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Second Quarter 2020 |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 28.7 |  | $ | 13.5 |  | $ | 6.8 |  | $ | (15.1) |  | $ | 33.9 |  |
| % Operating Income To Net Sales | 16.1 | % | 24.1 | % | 7.4 | % |  | 11.0 | % |
| Restructuring | $ | 0.9 |  | $ | — |  | $ | — |  | $ | — |  | $ | 0.9 |  |
| Operating Income/(Loss) Before Restructuring | $ | 29.6 |  | $ | 13.5 |  | $ | 6.8 |  | $ | (15.1) |  | $ | 34.8 |  |
| % Operating Income to Net Sales Before Restructuring | 16.6 | % | 24.1 | % | 7.4 | % |  | 11.3 | % |
