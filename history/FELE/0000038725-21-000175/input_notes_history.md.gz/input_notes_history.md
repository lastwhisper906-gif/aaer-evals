# FELE note change history — 0000038725-21-000092 → 0000038725-21-000175


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-08-03):
[0000038725-21-000175:note_history:1]
At June 30, 2021, the Company had $7.8 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.
  (was, 2021-04-30, similarity 0.9689):
[0000038725-21-000092:note_history:1]
At March 31, 2021, the Company had $6.8 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

- changed (2021-08-03):
[0000038725-21-000175:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended June 30, 2021, are as follows:
  (was, 2021-04-30, similarity 0.9118):
[0000038725-21-000092:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the first quarter ended March 31, 2021, are as follows:

- changed (2021-08-03):
[0000038725-21-000175:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2020 |  | $ | 9.7 |  |
| Accruals related to product warranties |  | 6.5 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (6.4) |  |
| Balance as of June 30, 2021 |  | $ | 9.8 |  |
  (was, 2021-04-30, similarity 0.9815):
[0000038725-21-000092:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2020 |  | $ | 9.7 |  |
| Accruals related to product warranties |  | 0.5 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (0.7) |  |
| Balance as of March 31, 2021 |  | $ | 9.5 |  |

- changed (2021-08-03):
[0000038725-21-000175:note_history:4]
The components of the Company’s operating lease portfolio as of the second quarter and six months ended June 30, 2021 are as follows:
  (was, 2021-04-30, similarity 0.8631):
[0000038725-21-000092:note_history:4]
The components of the Company’s operating lease portfolio as of the first quarter ended March 31, 2021 are as follows:

- changed (2021-08-03):
[0000038725-21-000175:note_history:5]
| Lease Cost (in millions): | Second Quarter Ended |  | Six Months Ended |
| Operating lease cost | $ | 2.7 |  |  | $ | 5.7 |  |
| Short-term lease cost | 0.1 |  |  | 0.4 |  |
| Other Information: |  |  |  |
| Weighted-average remaining lease term |  |  | 4.1 years |
| Weighted-average discount rate |  |  | 4.0 | % |
  (was, 2021-04-30, similarity 0.8801):
[0000038725-21-000092:note_history:5]
| Lease Cost (in millions): |  |  |  |
| Operating lease cost |  |  | $ | 3.0 |  |
| Short-term lease cost |  |  | 0.3 |  |
| Other Information: |  |  |  |
| Weighted-average remaining lease term |  |  | 4.0 years |
| Weighted-average discount rate |  |  | 4.0 | % |

- added (2021-08-03):
[0000038725-21-000175:note_history:6]
As of June 30, 2021, the Company has approximately $2.5 million of additional ROU assets related to leases that have not yet commenced, but create future lease obligations.

- changed (2021-08-03):
[0000038725-21-000175:note_history:7]
The minimum rental payments for non-cancellable operating leases as of June 30, 2021, are as follows:
  (was, 2021-04-30, similarity 0.9529):
[0000038725-21-000092:note_history:7]
The minimum rental payments for non-cancellable operating leases as of March 31, 2021, are as follows:


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-08-03):
[0000038725-21-000175:note_history:8]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2020, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 30, 2021, and for the second quarters and six months ended June 30, 2021 and June 30, 2020 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the second quarter and six months ended June 30, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2021. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2020.
  (was, 2021-04-30, similarity 0.9431):
[0000038725-21-000092:note_history:8]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2020, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2021, and for the first quarters ended March 31, 2021 and March 31, 2020 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the first quarter ended March 31, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2021. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2020.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-08-03):
[0000038725-21-000175:note_history:9]
| (In millions) |  | June 30, 2021 |  | December 31, 2020 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 130.0 |  |  | — |  |
| Tax increment financing debt |  | 17.1 |  |  | 17.6 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 1.7 |  |  | 1.8 |  |
| Other |  | — |  |  | 0.2 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 223.7 |  |  | $ | 94.6 |  |
| Less: current maturities |  | (132.4) |  |  | (2.6) |  |
| Long-term debt |  | $ | 91.3 |  |  | 92.0 |

- changed (2021-08-03):
[0000038725-21-000175:note_history:10]
Debt outstanding, excluding unamortized debt issuance costs, at June 30, 2021 matures as follows:
  (was, 2021-04-30, similarity 0.9514):
[0000038725-21-000092:note_history:10]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2021 matures as follows:

- changed (2021-08-03):
[0000038725-21-000175:note_history:11]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement"), which expires on July 30, 2021 and has an initial borrowing capacity of $250.0 million. As of June 30, 2021, the Company had no notes issued and  $150.0 million borrowing capacity available under the Prudential Agreement.
  (was, 2021-04-30, similarity 0.891):
[0000038725-21-000092:note_history:11]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement"), which expires on July 30, 2021 and has an initial borrowing capacity of $250.0 million. As of March 31, 2021, the Company has $150.0 million borrowing capacity available under the Prudential Agreement.

- changed (2021-08-03):
[0000038725-21-000175:note_history:12]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"), with a maximum aggregate borrowing capacity of $200.0 million. On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of June 30, 2021, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.
  (was, 2021-04-30, similarity 0.9934):
[0000038725-21-000092:note_history:12]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"), with a maximum aggregate borrowing capacity of $200.0 million. On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of March 31, 2021, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

- changed (2021-08-03):
[0000038725-21-000175:note_history:13]
The Company maintains the Fourth Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement was renewed on May 13, 2021, has a maturity date of May 13, 2026, and commitment amount of $250.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $125.0 million subject to agreement of the lenders (not to exceed a total commitment of $375.0 million). Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.85% to 1.88% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.
  (was, 2021-04-30, similarity 0.9246):
[0000038725-21-000092:note_history:13]
The Company maintains the Third Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement has a maturity date of October 28, 2021 and commitment amount of $300.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million). Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

- changed (2021-08-03):
[0000038725-21-000175:note_history:14]
As of June 30, 2021, the Company had $130.0 million outstanding borrowings, $4.0 million in letters of credit outstanding, and $116.0 million of available capacity under the Credit Agreement.
  (was, 2021-04-30, similarity 0.9446):
[0000038725-21-000092:note_history:14]
As of March 31, 2021, the Company had no outstanding borrowings, $4.0 million in letters of credit outstanding, and $296.0 million of available capacity under the Credit Agreement.

- changed (2021-08-03):
[0000038725-21-000175:note_history:15]
Covenants 
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of June 30, 2021.
  (was, 2021-04-30, similarity 0.992):
[0000038725-21-000092:note_history:15]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 1.00 to 3.50 and a minimum interest coverage ratio of 1.00 to 3.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of March 31, 2021.

- removed (2021-08-03):
[0000038725-21-000092:note_history:16]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | — |  |  | — |  |
| Tax increment financing debt |  | 17.1 |  |  | 17.6 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 2.1 |  |  | 1.8 |  |
| Other |  | — |  |  | 0.2 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 94.1 |  |  | $ | 94.6 |  |
| Less: current maturities |  | (2.7) |  |  | (2.6) |  |
| Long-term debt |  | $ | 91.4 |  |  | $ | 92.0 |  |

- removed (2021-08-03):
[0000038725-21-000092:note_history:17]
Covenants


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-08-03):
[0000038725-21-000175:note_history:18]
| (In millions) |  | June 30, 2021 |  | December 31, 2020 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 130.0 |  |  | — |  |
| Tax increment financing debt |  | 17.1 |  |  | 17.6 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 1.7 |  |  | 1.8 |  |
| Other |  | — |  |  | 0.2 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 223.7 |  |  | $ | 94.6 |  |
| Less: current maturities |  | (132.4) |  |  | (2.6) |  |
| Long-term debt |  | $ | 91.3 |  |  | 92.0 |

- removed (2021-08-03):
[0000038725-21-000092:note_history:19]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | — |  |  | — |  |
| Tax increment financing debt |  | 17.1 |  |  | 17.6 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 2.1 |  |  | 1.8 |  |
| Other |  | — |  |  | 0.2 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 94.1 |  |  | $ | 94.6 |  |
| Less: current maturities |  | (2.7) |  |  | (2.6) |  |
| Long-term debt |  | $ | 91.4 |  |  | $ | 92.0 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-03):
[0000038725-21-000175:note_history:20]
Debt outstanding, excluding unamortized debt issuance costs, at June 30, 2021 matures as follows:
  (was, 2021-04-30, similarity 0.9514):
[0000038725-21-000092:note_history:20]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2021 matures as follows:


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2021-08-03):
[0000038725-21-000175:note_history:21]
SUBSEQUENT EVENT
Amended and Restated Note Purchase and Private Shelf Agreement - NYL Shelf Agreement

- added (2021-08-03):
[0000038725-21-000175:note_history:22]
On July 30, 2021, Franklin Electric Co., Inc. and Franklin Electric B.V. ("Dutch Subsidiary Issuer") entered into a new unsecured $200.0 million uncommitted maximum aggregate principal amount private shelf facility for a period of up to 3 years pursuant to that certain Amended and Restated Note Purchase and Private Shelf Agreement with NYL Investors LLC, New York Life Insurance Company and New York Life Insurance and Annuity Corporation (collectively, “New York Life”) dated as of July 30, 2021 (the “NYL Shelf Agreement”). Subject to the terms and conditions set forth therein, the NYL Shelf Agreement allows the Company to issue senior promissory notes to New York Life at floating or fixed rate economic terms to be agreed upon at the time of issuance, from time to time during a three year issuance period ending July 30, 2024.

- added (2021-08-03):
[0000038725-21-000175:note_history:23]
The minimum principal amount of the private shelf note that can be issued under the NYL Shelf Agreement is $5.0 million with an issuance fee of 0.10% of the aggregate principal amount of the issued shelf note, payable on the date of issuance in Dollars. The NYL Shelf Agreement also provides for other fees, including a varying leverage fee payable for periods during which the ratio of the Company’s consolidated total debt to earnings before interest, taxes, depreciation and amortization is equal to or greater than 2.00 to 1.00.

- added (2021-08-03):
[0000038725-21-000175:note_history:24]
The term of each note issuance under the NYL Shelf Agreement will be selected by the Company and will not exceed 12 years for fixed rate notes and 10 years for floating rate notes. The proceeds of any issuance under the NYL Shelf Agreement will be used as set forth in the applicable Request for Purchase.

- added (2021-08-03):
[0000038725-21-000175:note_history:25]
The NYL Shelf Agreement has customary affirmative and negative covenants for agreements of these types. The affirmative covenants include delivery of financial statements, permitting of inspections of the property of the Company and its subsidiaries, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans or advances, acquisitions (including investments), and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Under specific acquisition factors, the maximum leverage ratio can increase to 4.00 to 1.00 for up to four consecutive Fiscal Quarters. Cross default is applicable with the NYL Shelf Agreement, but only if the Company is defaulting on an obligation exceeding $10.0 million. The NYL Shelf Agreement also contains customary events of default (with customary grace periods, as applicable, for certain of those events of default). If an event of default occurs, all payment obligations under the private shelf notes outstanding plus a yield maintenance amount (if any) may be declared due and payable. For certain events of default relating to insolvency, bankruptcy or liquidation, all payment obligations under outstanding private shelf notes plus a yield maintenance amount (if any) automatically become due and payable. The covenants in the NYL Shelf Agreement are subject to a number of important exceptions and qualifications set forth therein.

- added (2021-08-03):
[0000038725-21-000175:note_history:26]
All notes issued under the NYL Shelf Agreement are unsecured and rank pari passu in right of payment with the Company’s other senior unsecured indebtedness. The payment of outstanding amounts due under any notes and the performance by the Company of its obligations under the NYL Shelf Agreement have been guaranteed by certain wholly-owned U.S. subsidiaries of the Company.

- added (2021-08-03):
[0000038725-21-000175:note_history:27]
The description of the NYL Shelf Agreement contained herein is qualified in its entirety by reference to the NYL Shelf Agreement, a copy of which is filed hereto as Exhibit 10.5.

- added (2021-08-03):
[0000038725-21-000175:note_history:28]
Fourth Amended and Restated Note Purchase and Private Shelf Agreement - Pru Shelf Agreement

- added (2021-08-03):
[0000038725-21-000175:note_history:29]
Also on July 30, 2021, Franklin Electric Co., Inc. and Franklin Electric B.V. ("Dutch Subsidiary Issuer") entered into an unsecured $150.0 million uncommitted maximum aggregate principal amount private shelf facility for a period of up to 3 years pursuant to that certain Fourth Amended and Restated Note Purchase and Private Shelf Agreement, dated as of July 30, 2021, with Prudential Investment Management, Inc. (“Prudential”) and the purchasers named therein (the “Pru Shelf Agreement”). The Pru Shelf Agreement amended and restated the Third Amended and Restated Note Purchase and Private Shelf Agreement, dated as of May 28, 2015, between the Company and Prudential and the purchasers named therein (the “Existing 2015 Shelf Agreement”) and amended and restated the Existing 2004 Shelf Agreement and the Series B-1 Notes and Series B-2 Notes (collectively, the "Series B Notes"). The Series B Notes that were issued under the 2004 Shelf Agreement that were outstanding under the Existing 2015 Shelf Agreement in the original principal amount of $150.0 million became outstanding under the Pru Shelf Agreement. The minimum principal amount of the private shelf note that can be issued under the Pru Shelf Agreement is $5.0 million payable on the date of issuance. The Pru Shelf Agreement also provides for other fees,

- added (2021-08-03):
[0000038725-21-000175:note_history:30]
including a varying leverage fee payable for periods during which the ratio of the Company’s consolidated total debt to earnings before interest, taxes, depreciation and amortization is equal to or greater than 2.00 to 1.00.

- added (2021-08-03):
[0000038725-21-000175:note_history:31]
Any private shelf note issued under the Pru Shelf Agreement during the issuance period may have a maturity of up to 15 years, provided that the average life for each private shelf note issued is no more than 12 years after the date of original issuance. The private shelf notes may be issued in U.S. dollars or in the equivalent thereof at the time of issuance in British Pounds and Euros. The proceeds of any issuance under the Pru Shelf Agreement will be used for general corporate purposes, including the repayment of existing indebtedness.

- added (2021-08-03):
[0000038725-21-000175:note_history:32]
The Pru Shelf Agreement has customary affirmative and negative covenants for agreements of these types. The affirmative covenants include delivery of financial statements, permitting of inspections of the property of the Company and its subsidiaries, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans or advances, acquisitions (including investments), and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Under specific acquisition factors, the maximum leverage ratio can increase to 4.00 to 1.00 for up to four consecutive Fiscal Quarters. Cross default is applicable with the Pru Shelf Agreement, but only if the Company is defaulting on an obligation exceeding $10.0 million. The Pru Shelf Agreement also contains customary events of default (with customary grace periods, as applicable, for certain of those events of default). If an event of default occurs, all payment obligations under the private shelf notes outstanding plus a yield maintenance amount (if any) may be declared due and payable. For certain events of default relating to insolvency, bankruptcy or liquidation, all payment obligations under outstanding private shelf notes plus a yield maintenance amount (if any) automatically become due and payable. The covenants in the Pru Shelf Agreement are subject to a number of important exceptions and qualifications set forth therein.

- added (2021-08-03):
[0000038725-21-000175:note_history:33]
All notes issued under the Pru Shelf Agreement are unsecured and rank pari passu in right of payment with the Company’s other senior unsecured indebtedness. The payment of outstanding amounts due under any notes and the performance by the Company of its obligations under the Pru Shelf Agreement have been guaranteed by certain wholly-owned U.S. subsidiaries of the Company.

- added (2021-08-03):
[0000038725-21-000175:note_history:34]
The description of the Pru Shelf Agreement contained herein is qualified in its entirety by reference to the Pru Shelf Agreement, a copy of which is filed hereto as Exhibit 10.6.

- removed (2021-08-03):
[0000038725-21-000092:note_history:35]
16. SUBSEQUENT EVENT

- removed (2021-08-03):
[0000038725-21-000092:note_history:36]
On April 1, 2021, the Company acquired 100 percent of the ownership interests in Puronics, Inc. and its wholly owned subsidiaries, headquartered in Livermore, California,  for approximately $28 million. Puronics is a residential and commercial water treatment products and services provider and will be included as a part of the Water Systems segment of the Company. The initial accounting for this acquisition is incomplete, and the Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2020, as the results of operations for this acquisition is immaterial.
