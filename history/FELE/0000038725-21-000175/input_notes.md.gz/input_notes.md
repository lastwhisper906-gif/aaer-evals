# FELE notes — 0000038725-21-000175


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-21-000175:notes:1]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2020, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 30, 2021, and for the second quarters and six months ended June 30, 2021 and June 30, 2020 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the second quarter and six months ended June 30, 2021 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2021. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2020.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000038725-21-000175:notes:2]
ACCOUNTING PRONOUNCEMENTS
Adoption of New Accounting Standards

[0000038725-21-000175:notes:3]
In March 2020, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2020-04, Facilitation of the Effects of Reference Rate Reform on Financial Reporting, which provides optional expedients and exceptions for applying U.S. generally accepted accounting principles to contracts, hedging relationships, and other transactions affected by the discontinuation of the London Interbank Offered Rate ("LIBOR") and other reference rates which are expected to be discontinues due to reference rate reform. ASU 2020-04 is effective on a prospective basis between March 12, 2020 and December 31, 2022. The Company adopted the standard effective January 1, 2021, and it did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-21-000175:notes:4]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is expected to reduce cost and complexity related to accounting for income taxes. ASU 2019-12 eliminates the need for the Company to analyze whether certain exceptions apply and improves financial statement preparers' application of income tax-related guidance. ASU 2019-12 is effective for interim and annual periods beginning after December 15, 2020 with early adoption permitted. Amendments related to franchise taxes that are partially based on income should be applied on either a retrospective or modified retrospective basis. All other amendments should be applied on a prospective basis. The Company adopted the standard effective January 1, 2021, and it did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-21-000175:notes:5]
Accounting Standards Issued But Not Yet Adopted

[0000038725-21-000175:notes:6]
In August 2020, the FASB issued ASU 2020-06, Debt – Debt with Conversion and Other Options (Subtopic 470-20) and Derivatives and Hedging – Contracts in Entity’s Own Equity (Subtopic 815-40): Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity. ASU 2020-06 reduces the number of accounting models for various convertible instruments and reduces form-over-substance-based accounting conclusions for the derivatives scope exception for contracts in an entity’s own equity. The FASB also updated Earnings Per Share (“EPS”) guidance under Topic 260 by requiring an entity to consider the potential effect of share settlement in the diluted EPS calculation for instruments that may be settled in cash or shares as well as other amendments. ASU 2020-06 is effective for interim and annual periods beginning after December 15, 2021 with early adoption permitted but no earlier than fiscal years beginning after December 15, 2020. The guidance should be adopted at the beginning of a fiscal year. ASU 2020-06 should be applied on either a retrospective or modified retrospective basis. The Company is planning to adopt on January 1, 2022, but does not expect the ASU to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-21-000175:notes:7]
ACQUISITIONS
During the second quarter ended June 30, 2021, the Company acquired, in separate transactions, 100 percent of the ownership interests of Puronics, Inc. and its wholly owned subsidiaries, headquartered in Livermore, California, and 100 percent of the ownership interests of New Aqua, LLC and its wholly owned subsidiaries, headquartered in Indianapolis, Indiana. Both Puronics and New Aqua are water treatment equipment providers and will be included as a part of the Water Systems segment of the Company. In a separate transaction during the second quarter ended June 30, 2021, the Company acquired all of the assets of Power Integrity Services, LLC, a North Carolina-based company, which will be included in the Fueling Systems segment of the Company.

[0000038725-21-000175:notes:8]
In another separate transaction during the second quarter ended June 30, 2021, the Company acquired all of the assets of Atlantic Turbine Pump, LLC, a Georgia-based company, which will be included in the Distribution segment of the Company.

[0000038725-21-000175:notes:9]
As of June 30, 2021, the Company has recorded estimated fair values that exceed the acquisition price by $0.5 million, representing a bargain purchase gain due to favorable market conditions within accrued expenses and other current liabilities in the consolidated balance sheets for the Atlantic Turbine Pump acquisition. Once the determination of fair values is complete in 2022, the Company will recognize the bargain purchase gain in the consolidated statements of income.

[0000038725-21-000175:notes:10]
The combined purchase price for all acquisitions in the quarter was $184.3 million after working capital adjustments, which were all cash transactions. All acquisitions in the quarter expand the Company's geographical presence and product channels. The fair value of the assets acquired and liabilities assumed for all acquisitions are preliminary as of June 30, 2021 and is classified as Level 3 within the valuation hierarchy.

[0000038725-21-000175:notes:11]
The identifiable intangible assets recognized in the separate transactions in the second quarter ended June 30, 2021, were $115.6 million, and consist primarily of customer relationships and trade names, which will be amortized using the straight-line method over 12 - 20 years.

[0000038725-21-000175:notes:12]
The goodwill of $50.1 million resulting from the acquisitions in the second quarter ended June 30, 2021, is expected to be deductible for tax purposes and consists primarily of expanded geographical presence and product channel expansion.  Goodwill was recorded in the Water Systems and Fueling Systems segment (see Note 6 - Goodwill and Other Intangible Assets).

[0000038725-21-000175:notes:13]
For all acquisitions in the second quarter ended June 30, 2021, consolidated annual revenue for the full year 2020 was $97.3 million, which would be incremental to the Company's revenue had the acquisition occurred on the first day of 2020. Since acquisition in the second quarter of 2021, consolidated revenue was $15.6 million. The Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2020, as the results of operations for all acquisitions is immaterial.

[0000038725-21-000175:notes:14]
During the fourth quarter ended December 31, 2020, the Company acquired 100 percent of the ownership interests of Gicon Pumps & Equipment, Inc., a professional groundwater distributor operating seven locations in the state of Texas for a purchase price of $28.1 million after working capital adjustments. Gicon will be included as part of the Distribution segment of the Company. As of June 30, 2021, the Company has recorded estimated fair values that exceed the acquisition price by $3.4 million, representing a bargain purchase gain due to favorable market conditions within accrued expenses and other current liabilities in the consolidated balance sheets. Once the determination of fair values is complete in 2021, the Company will recognize the bargain purchase gain in the consolidated statements of income. In a separate transaction during the fourth quarter ended December 31, 2020, the Company acquired 100 percent of the ownership interests in Waterite Inc. and its affiliate Waterite America Inc., headquartered in Winnipeg, Manitoba, Canada, for a purchase price of $21.9 million after working capital adjustments. Waterite will be included as a part of the Water Systems segment of the Company. The fair value of the assets acquired and liabilities assumed for both acquisitions are preliminary as of June 30, 2021 and is classified as Level 3 within the valuation hierarchy. In addition, the Company has not presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2020, as the results of operations for both acquisitions is immaterial.

[0000038725-21-000175:notes:15]
Transaction costs were expensed as incurred under the guidance of FASB Accounting Standards Codification Topic 805, Business Combinations. There were $0.8 million and $0.9 million of transaction costs included in the "Selling, general, and administrative expenses" line of the Company's condensed consolidated statements of income for the second quarter and six months ended June 30, 2021, respectively. Transaction costs were immaterial in the second quarter and six months ended June 30, 2020.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-21-000175:notes:16]
[same as prior period, unchanged from 0000038725-21-000092:notes:9]

[0000038725-21-000175:notes:17]
[same as prior period, unchanged from 0000038725-21-000092:notes:10]

[0000038725-21-000175:notes:18]
[same as prior period, unchanged from 0000038725-21-000092:notes:11]

[0000038725-21-000175:notes:19]
[same as prior period, unchanged from 0000038725-21-000092:notes:12]

[0000038725-21-000175:notes:20]
As of June 30, 2021 and December 31, 2020, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-21-000175:notes:21]
| (In millions) | June 30, 2021 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 5.9 |  | $ | 5.9 |  | $ | — |  | $ | — |  |
|  | December 31, 2020 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 20.2 |  | $ | 20.2 |  | $ | — |  | $ | — |  |

[0000038725-21-000175:notes:22]
[same as prior period, unchanged from 0000038725-21-000092:notes:15]

[0000038725-21-000175:notes:23]
The Company has no assets measured on a recurring basis classified as Level 2 or Level 3.
Total debt, including current maturities, have carrying amounts of $223.7 million and $94.6 million and estimated fair values of $233.6 million and $107.3 million as of June 30, 2021 and December 31, 2020, respectively. In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value. Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction. In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities. Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-21-000175:notes:24]
FINANCIAL INSTRUMENTSThe Company’s non-employee directors' deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period. The Company has entered into share swap transaction agreements (the "swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price. The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party. As of June 30, 2021, the swap had a notional value based on 210,000 shares. For the second quarter and six months ended June 30, 2021, the swap resulted in a gain of $0.6 million and a gain of $3.3 million, respectively. For the second quarter and six months ended June 30, 2020 the swap resulted in a gain of $1.3 million and a loss of $1.5 million respectively. Gains and losses resulting from the swap were largely offset by gains and losses on the fair value of the deferred compensation stock liability. All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-21-000175:notes:25]
[same as prior period, unchanged from 0000038725-21-000092:notes:18]

[0000038725-21-000175:notes:26]
| (In millions) |  | June 30, 2021 |  | December 31, 2020 |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortizing intangibles: |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.4 |  |  | $ | (7.3) |  |  | $ | 7.5 |  |  | $ | (7.3) |  |
| Technology |  | 7.5 |  |  | (7.3) |  |  | 7.5 |  |  | (7.2) |  |
| Customer relationships |  | 246.7 |  |  | (83.4) |  |  | 165.1 |  |  | (78.5) |  |
| Trade names |  | 37.2 |  |  | (0.4) |  |  | $ | 3.4 |  |  | (0.2) |  |
| Other |  | 3.1 |  |  | (2.8) |  |  | 2.9 |  |  | (2.8) |  |
| Total |  | $ | 301.9 |  |  | $ | (101.2) |  |  | $ | 186.4 |  |  | $ | (96.0) |  |
| Unamortizing intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 43.6 |  |  | — |  |  | 43.4 |  |  | — |  |
| Total intangibles |  | $ | 345.5 |  |  | $ | (101.2) |  |  | $ | 229.8 |  |  | $ | (96.0) |  |

[0000038725-21-000175:notes:27]
Amortization expense related to intangible assets for the second quarters ended June 30, 2021 and June 30, 2020 was $3.5 million and $2.3 million respectively, and for the six months ended June 30, 2021 and June 30, 2020, $6.0 million and $4.7 million  respectively.

[0000038725-21-000175:notes:28]
[same as prior period, unchanged from 0000038725-21-000092:notes:21]

[0000038725-21-000175:notes:29]
| (In millions) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025 |
|  |  | $ | 12.6 |  |  | $ | 14.4 |  |  | $ | 14.3 |  |  | $ | 14.1 |  |  | $ | 13.3 |  |

[0000038725-21-000175:notes:30]
The change in the carrying amount of goodwill by reportable segment for the six months ended June 30, 2021, is as follows:

[0000038725-21-000175:notes:31]
| (In millions) |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2020 |  | $ | 161.5 |  |  | $ | 67.7 |  |  | $ | 37.5 |  |  | $ | 266.7 |  |
| Acquisitions |  | 47.5 |  |  | 2.6 |  |  | — |  |  | 50.1 |  |
| Adjustments to prior year acquisitions |  | 0.1 |  |  | — |  |  | — |  |  | 0.1 |  |
| Foreign currency translation |  | (0.5) |  |  | — |  |  | — |  |  | (0.5) |  |
| Balance as of June 30, 2021 |  | $ | 208.6 |  |  | $ | 70.3 |  |  | $ | 37.5 |  |  | $ | 316.4 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-21-000175:notes:32]
EMPLOYEE BENEFIT PLANS
Defined Benefit Plans - As of June 30, 2021, the Company maintained two domestic pension plans and three German pension plans. The Company used a December 31, 2020 measurement date for these plans. One of the Company's domestic pension plans covers one active management employee, while the other domestic plan covers all eligible employees (plan was frozen as of December 31, 2011). The two domestic and three German plans collectively comprise the 'Pension Benefits' disclosure caption.

[0000038725-21-000175:notes:33]
[same as prior period, unchanged from 0000038725-21-000092:notes:26]

[0000038725-21-000175:notes:34]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the second quarters and six months ended June 30, 2021 and June 30, 2020:

[0000038725-21-000175:notes:35]
| (In millions) | Pension Benefits |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2021 |  | June 30, 2020 |  | June 30, 2021 |  | June 30, 2020 |
| Service cost | $ | 0.2 |  |  | $ | 0.2 |  |  | $ | 0.4 |  |  | $ | 0.3 |  |
| Interest cost | 0.7 |  |  | 1.1 |  |  | 1.4 |  |  | 2.2 |  |
| Expected return on assets | (1.4) |  |  | (1.7) |  |  | (2.8) |  |  | (3.4) |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | 1.1 |  |  | 0.9 |  |  | 2.1 |  |  | 1.8 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.6 |  |  | $ | 0.5 |  |  | $ | 1.1 |  |  | $ | 0.9 |  |

[0000038725-21-000175:notes:36]
In the six months ended June 30, 2021, the Company made contributions of $0.1 million to the funded plans. The amount of contributions to be made to the plans during the calendar year 2021 will be finalized by September 15, 2021, based upon the funding level requirements identified and year-end valuation performed at December 31, 2020.

[0000038725-21-000175:notes:37]
The following table sets forth the aggregated net periodic benefit cost for the other post-retirement benefit plan for the second quarters and six months ended June 30, 2021 and June 30, 2020:

[0000038725-21-000175:notes:38]
| (In millions) | Other Benefits |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2021 |  | June 30, 2020 |  | June 30, 2021 |  | June 30, 2020 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | 0.1 |  |  | — |  |  | 0.1 |  |  | 0.1 |  |
| Expected return on assets | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | — |  |  | — |  |  | 0.1 |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.1 |  |  | $ | — |  |  | $ | 0.2 |  |  | $ | 0.1 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-21-000175:notes:39]
INCOME TAXES
The Company’s effective tax rate from continuing operations for the six month period ended June 30, 2021 was 16.8 percent as compared to 20.6 percent for the six month period ended June 30, 2020. The effective tax rate is lower than the U.S. statutory rate of 21 percent primarily due to foreign earnings taxed at rates below the U.S. statutory rate, the recognition of the U.S. foreign-derived intangible income (FDII) provisions, and certain discrete events including excess tax benefits from share-based compensation partially offset by state taxes. For the second quarter of 2021 the effective tax rate was 19.0 percent as compared to 21.3 percent for the second quarter of 2020.

[0000038725-21-000175:notes:40]
The decrease in the effective tax rate was primarily a result of net favorable discrete events of $0.5 million, including increased excess tax benefits from share-based compensation, recorded in the second quarter of 2021 compared to net unfavorable discrete events of $0.4 million in the second quarter of 2020 due to a valuation allowance on deferred tax assets in foreign jurisdictions. During the first quarter of 2021, the Company also recorded a deferred tax benefit of $0.8 million as a result of a tax election made in a foreign jurisdiction.


## us-gaap:DebtDisclosureTextBlock

[0000038725-21-000175:notes:41]
DEBT
Debt consisted of the following:

[0000038725-21-000175:notes:42]
| (In millions) |  | June 30, 2021 |  | December 31, 2020 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 130.0 |  |  | — |  |
| Tax increment financing debt |  | 17.1 |  |  | 17.6 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 1.7 |  |  | 1.8 |  |
| Other |  | — |  |  | 0.2 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 223.7 |  |  | $ | 94.6 |  |
| Less: current maturities |  | (132.4) |  |  | (2.6) |  |
| Long-term debt |  | $ | 91.3 |  |  | 92.0 |

[0000038725-21-000175:notes:43]
Debt outstanding, excluding unamortized debt issuance costs, at June 30, 2021 matures as follows:

[0000038725-21-000175:notes:44]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 223.8 |  |  | $ | 132.5 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.4 |  |  | $ | 76.4 |  |  | $ | 10.9 |  |

[0000038725-21-000175:notes:45]
Prudential Agreement

[0000038725-21-000175:notes:46]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement"), which expires on July 30, 2021 and has an initial borrowing capacity of $250.0 million. As of June 30, 2021, the Company had no notes issued and  $150.0 million borrowing capacity available under the Prudential Agreement.

[0000038725-21-000175:notes:47]
Project Bonds

[0000038725-21-000175:notes:48]
The Company, Allen County, Indiana and certain institutional investors maintain a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)." The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. These Project Bonds ("Tax increment financing debt") bear interest at 3.6 percent per annum. Interest and principal balance of the Project Bonds are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.

[0000038725-21-000175:notes:49]
New York Life Agreement

[0000038725-21-000175:notes:50]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"), with a maximum aggregate borrowing capacity of $200.0 million. On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of June 30, 2021, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-21-000175:notes:51]
Credit Agreement

[0000038725-21-000175:notes:52]
The Company maintains the Fourth Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement was renewed on May 13, 2021, has a maturity date of May 13, 2026, and commitment amount of $250.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $125.0 million subject to agreement of the lenders (not to exceed a total commitment of $375.0 million). Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.85% to 1.88% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-21-000175:notes:53]
As of June 30, 2021, the Company had $130.0 million outstanding borrowings, $4.0 million in letters of credit outstanding, and $116.0 million of available capacity under the Credit Agreement.

[0000038725-21-000175:notes:54]
Covenants 
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of June 30, 2021.


## us-gaap:EarningsPerShareTextBlock

[0000038725-21-000175:notes:55]
[same as prior period, unchanged from 0000038725-21-000092:notes:48]

[0000038725-21-000175:notes:56]
[same as prior period, unchanged from 0000038725-21-000092:notes:49]

[0000038725-21-000175:notes:57]
[same as prior period, unchanged from 0000038725-21-000092:notes:50]

[0000038725-21-000175:notes:58]
|  | Second Quarter Ended |  | Six Months Ended |
| (In millions, except per share amounts) | June 30, 2021 |  | June 30, 2020 |  | June 30, 2021 |  | June 30, 2020 |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 39.1 |  |  | $ | 24.7 |  |  | $ | 67.0 |  |  | $ | 35.3 |  |
| Less: Earnings allocated to participating securities | 0.2 |  |  | 0.2 |  |  | 0.4 |  |  | 0.2 |  |
| Net income available to common shareholders | $ | 38.9 |  |  | $ | 24.5 |  |  | $ | 66.6 |  |  | $ | 35.1 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 46.5 |  |  | 46.2 |  |  | 46.4 |  |  | 46.3 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Non-participating employee stock options and performance awards | 0.6 |  |  | 0.3 |  |  | 0.6 |  |  | 0.4 |  |
| Diluted weighted average common shares outstanding | 47.1 |  |  | 46.5 |  |  | 47.0 |  |  | 46.7 |  |
| Basic earnings per share | $ | 0.84 |  |  | $ | 0.53 |  |  | $ | 1.44 |  |  | $ | 0.76 |  |
| Diluted earnings per share | $ | 0.83 |  |  | $ | 0.52 |  |  | $ | 1.42 |  |  | $ | 0.75 |  |

[0000038725-21-000175:notes:59]
There were 0.0 million and 0.4 million stock options outstanding for the second quarters ended June 30, 2021 and June 30, 2020, and 0.1 million and 0.3 million  stock options outstanding for the six months ended June 30, 2021 and June 30, 2020 respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-21-000175:notes:60]
EQUITY ROLL FORWARD
The schedules below set forth equity changes in the second quarters ended June 30, 2021 and June 30, 2020:

[0000038725-21-000175:notes:61]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of March 31, 2021 | $ | 4,641 |  |  | $ | 292,668 |  |  | $ | 779,456 |  |  | $ | (51,782) |  |  | $ | (163,554) |  |  | $ | 2,257 |  |  | $ | 863,686 |  |  | $ | (168) |  |
| Net income |  |  |  |  | 39,141 |  |  |  |  |  |  | 270 |  |  | 39,411 |  |  | (48) |  |
| Dividends on common stock ($0.175/share) |  |  |  |  | (8,177) |  |  |  |  |  |  |  |  | (8,177) |  |  |  |
| Common stock issued | 12 |  |  | 3,894 |  |  |  |  |  |  |  |  |  |  | 3,906 |  |  |  |
| Common stock repurchased | (9) |  |  |  |  | (6,373) |  |  |  |  |  |  |  |  | (6,382) |  |  |  |
| Share-based compensation | 1 |  |  | 2,382 |  |  |  |  |  |  |  |  |  |  | 2,383 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | — |  |  | — |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | 8,114 |  |  | 14 |  |  | 8,128 |  |  | 7 |  |
| Pension liability, net of tax |  |  |  |  |  |  | 885 |  |  |  |  |  |  | 885 |  |  |  |
| Balance as of June 30, 2021 | $ | 4,645 |  |  | $ | 298,944 |  |  | $ | 804,047 |  |  | $ | (50,897) |  |  | $ | (155,440) |  |  | $ | 2,541 |  |  | $ | 903,840 |  |  | $ | (209) |  |

[0000038725-21-000175:notes:62]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of March 31, 2020 | $ | 4,614 |  |  | $ | 274,869 |  |  | $ | 698,917 |  |  | $ | (49,373) |  |  | $ | (177,848) |  |  | $ | 2,287 |  |  | $ | 753,466 |  |  | $ | (245) |  |
| Net Income |  |  |  |  | 24,651 |  |  |  |  |  |  | 169 |  |  | 24,820 |  |  | (18) |  |
| Dividends on common stock ($0.155/share) |  |  |  |  | (7,206) |  |  |  |  |  |  |  |  | (7,206) |  |  |  |
| Common stock issued | 2 |  |  | 647 |  |  |  |  |  |  |  |  |  |  | 649 |  |  |  |
| Common stock repurchased | (2) |  |  |  |  | (741) |  |  |  |  |  |  |  |  | (743) |  |  |  |
| Share-based compensation | 4 |  |  | 2,659 |  |  |  |  |  |  |  |  |  |  | 2,663 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | (830) |  |  | (830) |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | 1,955 |  |  | 21 |  |  | 1,976 |  |  | 1 |  |
| Pension liability, net of taxes |  |  |  |  |  |  | 716 |  |  |  |  |  |  | 716 |  |  |  |
| Balance as of June 30, 2020 | $ | 4,618 |  |  | $ | 278,175 |  |  | $ | 715,621 |  |  | $ | (48,657) |  |  | $ | (175,893) |  |  | $ | 1,647 |  |  | $ | 775,511 |  |  | $ | (262) |  |

[0000038725-21-000175:notes:63]
The schedule below set forth equity changes in the six months ended June 30, 2021 and June 30, 2020:

[0000038725-21-000175:notes:64]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2020 | $ | 4,622 |  |  | $ | 283,420 |  |  | $ | 764,562 |  |  | $ | (52,666) |  |  | $ | (152,105) |  |  | $ | 2,116 |  |  | $ | 849,949 |  |  | $ | (245) |  |
| Net Income |  |  |  |  | 67,021 |  |  |  |  |  |  | 477 |  |  | 67,498 |  |  | 28 |  |
| Dividends on common stock ($0.3500/share) |  |  |  |  | (16,320) |  |  |  |  |  |  |  |  | (16,320) |  |  |  |
| Common stock issued | 26 |  |  | 8,963 |  |  |  |  |  |  |  |  |  |  | 8,989 |  |  |  |
| Common stock repurchased | (15) |  |  |  |  | (11,216) |  |  |  |  |  |  |  |  | (11,231) |  |  |  |
| Share-based compensation | 12 |  |  | 6,561 |  |  |  |  |  |  |  |  |  |  | 6,573 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | — |  |  | — |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (3,335) |  |  | (52) |  |  | (3,387) |  |  | 8 |  |
| Pension liability, net of taxes |  |  |  |  |  |  | 1,769 |  |  |  |  |  |  | 1,769 |  |  |  |
| Balance as of June 30, 2021 | $ | 4,645 |  |  | $ | 298,944 |  |  | $ | 804,047 |  |  | $ | (50,897) |  |  | $ | (155,440) |  |  | $ | 2,541 |  |  | $ | 903,840 |  |  | $ | (209) |  |
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2019 | $ | 4,639 |  |  | $ | 269,656 |  |  | $ | 712,460 |  |  | $ | (50,089) |  |  | $ | (140,121) |  |  | $ | 2,124 |  |  | $ | 798,669 |  |  | $ | (236) |  |
| Net Income |  |  |  |  | 35,294 |  |  |  |  |  |  | 356 |  |  | 35,650 |  |  | (56) |  |
| Dividends on common stock ($0.3100/share) |  |  |  |  | (14,446) |  |  |  |  |  |  |  |  | (14,446) |  |  |  |
| Common stock issued | 4 |  |  | 1,516 |  |  |  |  |  |  |  |  |  |  | 1,520 |  |  |  |
| Common stock repurchased | (37) |  |  |  |  | (17,687) |  |  |  |  |  |  |  |  | (17,724) |  |  |  |
| Share-based compensation | 12 |  |  | 7,003 |  |  |  |  |  |  |  |  |  |  | 7,015 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | (830) |  |  | (830) |  |  |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (35,772) |  |  | (3) |  |  | (35,775) |  |  | 30 |  |
| Pension liability, net of taxes |  |  |  |  |  |  | 1,432 |  |  |  |  |  |  | 1,432 |  |  |  |
| Balance as of June 30, 2020 | $ | 4,618 |  |  | $ | 278,175 |  |  | $ | 715,621 |  |  | $ | (48,657) |  |  | $ | (175,893) |  |  | $ | 1,647 |  |  | $ | 775,511 |  |  | $ | (262) |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-21-000175:notes:65]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)
Changes in accumulated other comprehensive income/(loss) by component for the six months ended June 30, 2021 and June 30, 2020, are summarized below:

[0000038725-21-000175:notes:66]
| (In millions) |  |  |  |  |  |
| For the six months ended June 30, 2021: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| Balance as of December 31, 2020 | $ | (152.2) |  |  | $ | (52.6) |  |  | $ | (204.8) |  |
| Other comprehensive income/(loss) before reclassifications | (3.3) |  |  | — |  |  | (3.3) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 1.8 |  |  | 1.8 |  |
| Net other comprehensive income/(loss) | (3.3) |  |  | 1.8 |  |  | (1.5) |  |
| Balance as of June 30, 2021 | $ | (155.5) |  |  | $ | (50.8) |  |  | $ | (206.3) |  |
| For the six months ended June 30, 2020: |  |  |  |  |  |
| Balance as of December 31, 2019 | $ | (140.2) |  |  | $ | (50.0) |  |  | $ | (190.2) |  |
| Other comprehensive income/(loss) before reclassifications | (35.8) |  |  | — |  |  | (35.8) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 1.4 |  |  | 1.4 |  |
| Net other comprehensive income/(loss) | (35.8) |  |  | 1.4 |  |  | (34.4) |  |
| Balance as of June 30, 2020 | $ | (176.0) |  |  | $ | (48.6) |  |  | $ | (224.6) |  |

[0000038725-21-000175:notes:67]
[same as prior period, unchanged from 0000038725-21-000092:notes:58]

[0000038725-21-000175:notes:68]
(2) Net of tax expense of $0.5 million and $0.4 million for the six months ended June 30, 2021 and June 30, 2020, respectively.

[0000038725-21-000175:notes:69]
[same as prior period, unchanged from 0000038725-21-000092:notes:60]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-21-000175:notes:70]
[same as prior period, unchanged from 0000038725-21-000092:notes:61]

[0000038725-21-000175:notes:71]
[same as prior period, unchanged from 0000038725-21-000092:notes:62]

[0000038725-21-000175:notes:72]
[same as prior period, unchanged from 0000038725-21-000092:notes:63]

[0000038725-21-000175:notes:73]
|  | Second Quarter Ended |  | Six Months Ended |
| (In millions) | June 30, 2021 |  | June 30, 2020 |  | June 30, 2021 |  | June 30, 2020 |
|  | Net sales |
| Water Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | $ | 114.1 |  |  | $ | 80.8 |  |  | $ | 198.3 |  |  | $ | 151.7 |  |
| Latin America | 34.7 |  |  | 24.2 |  |  | 66.4 |  |  | 52.4 |  |
| Europe, Middle East & Africa | 51.4 |  |  | 35.5 |  |  | 95.8 |  |  | 73.7 |  |
| Asia Pacific | 20.1 |  |  | 19.7 |  |  | 40.3 |  |  | 33.5 |  |
| Intersegment sales |  |  |  |  |  |  |  |
| United States & Canada | 26.9 |  |  | 18.2 |  |  | 44.0 |  |  | 31.2 |  |
| Total sales | 247.2 |  |  | 178.4 |  |  | 444.8 |  |  | 342.5 |  |
| Distribution |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 144.8 |  |  | 92.1 |  |  | 240.5 |  |  | 152.5 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 144.8 |  |  | 92.1 |  |  | 240.5 |  |  | 152.5 |  |
| Fueling Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 50.6 |  |  | 35.3 |  |  | 88.1 |  |  | 72.6 |  |
| All other | 21.6 |  |  | 20.7 |  |  | 40.9 |  |  | 38.6 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 72.2 |  |  | 56.0 |  |  | 129.0 |  |  | 111.2 |  |
| Intersegment Eliminations/Other | (26.9) |  |  | (18.2) |  |  | (44.0) |  |  | (31.2) |  |
| Consolidated | $ | 437.3 |  |  | $ | 308.3 |  |  | $ | 770.3 |  |  | $ | 575.0 |  |
|  | Second Quarter Ended |  | Six Months Ended |
|  | June 30, 2021 |  | June 30, 2020 |  | June 30, 2021 |  | June 30, 2020 |
|  | Operating income/(loss) |
| Water Systems | $ | 34.6 |  |  | $ | 28.7 |  |  | $ | 65.9 |  |  | $ | 47.5 |  |
| Distribution | 16.0 |  |  | 6.8 |  |  | 18.0 |  |  | 4.6 |  |
| Fueling Systems | 18.5 |  |  | 13.5 |  |  | 33.4 |  |  | 25.6 |  |
| Intersegment Eliminations/Other | (17.5) |  |  | (15.1) |  |  | (31.9) |  |  | (29.9) |  |
| Consolidated | $ | 51.6 |  |  | $ | 33.9 |  |  | $ | 85.4 |  |  | $ | 47.8 |  |

[0000038725-21-000175:notes:74]
|  | June 30, 2021 |  | December 31, 2020 |  |  |  |  |
|  | Total assets |  |  |  |  |
| Water Systems | $ | 863.0 |  |  | $ | 645.9 |  |  |  |  |  |
| Distribution | 296.6 |  |  | 249.0 |  |  |  |  |  |
| Fueling Systems | 270.0 |  |  | 268.9 |  |  |  |  |  |
| Other | 81.2 |  |  | 108.5 |  |  |  |  |  |
| Consolidated | $ | 1,510.8 |  |  | $ | 1,272.3 |  |  |  |  |  |

[0000038725-21-000175:notes:75]
[same as prior period, unchanged from 0000038725-21-000092:notes:66]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-21-000175:notes:76]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. The subject-matter expert has issued their preliminary report, which indicates that total damages incurred by Esso amounted to approximately 12 million euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company has retained experts to demonstrate that its products did not cause the damage, and in January 2021, submitted its response to the expert’s preliminary report for each station. The expert's response to the Company's report is due to the Court in June 2022. The Company cannot predict the ultimate outcome of this matter. Any exposure related to this matter is neither probable nor estimable at this time. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s results of operations.

[0000038725-21-000175:notes:77]
The Company is defending other various claims and legal actions which have arisen in the ordinary course of business. In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-21-000175:notes:78]
At June 30, 2021, the Company had $7.8 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-21-000175:notes:79]
The Company provides warranties on most of its products. The warranty terms vary but are generally two years to five years from date of manufacture or one year to five years from date of installation. Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified. These estimates are established using historical information about the nature, frequency, and average cost of warranty claims. The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims. The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-21-000175:notes:80]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended June 30, 2021, are as follows:

[0000038725-21-000175:notes:81]
| (In millions) |  |  |
| Balance as of December 31, 2020 |  | $ | 9.7 |  |
| Accruals related to product warranties |  | 6.5 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (6.4) |  |
| Balance as of June 30, 2021 |  | $ | 9.8 |  |

[0000038725-21-000175:notes:82]
The Company maintains certain warehouses, distribution centers, office space, and equipment operating leases. The Company also has lease agreements that are classified as financing. These financing leases are immaterial to the Company.

[0000038725-21-000175:notes:83]
The Company utilizes interest rates from lease agreements unless the lease agreement does not provide a readily determinable rate. In these instances, the Company utilizes its incremental borrowing rate based on the information available as of the adoption of ASU 2016-02 or at the inception of any new leases entered into thereafter when determining the present value of future lease payments.

[0000038725-21-000175:notes:84]
Some of the Company’s leases include renewal options. The Company excludes these renewal options in the expected lease term unless the Company is reasonably certain that the option will be exercised.

[0000038725-21-000175:notes:85]
The components of the Company’s operating lease portfolio as of the second quarter and six months ended June 30, 2021 are as follows:

[0000038725-21-000175:notes:86]
| Lease Cost (in millions): | Second Quarter Ended |  | Six Months Ended |
| Operating lease cost | $ | 2.7 |  |  | $ | 5.7 |  |
| Short-term lease cost | 0.1 |  |  | 0.4 |  |
| Other Information: |  |  |  |
| Weighted-average remaining lease term |  |  | 4.1 years |
| Weighted-average discount rate |  |  | 4.0 | % |

[0000038725-21-000175:notes:87]
As of June 30, 2021, the Company has approximately $2.5 million of additional ROU assets related to leases that have not yet commenced, but create future lease obligations.

[0000038725-21-000175:notes:88]
The minimum rental payments for non-cancellable operating leases as of June 30, 2021, are as follows:

[0000038725-21-000175:notes:89]
| (In millions) | 2021 | 2022 | 2023 | 2024 | 2025 | Thereafter |
| Future Minimum Rental Payments | $ | 9.2 |  | $ | 10.3 |  | $ | 7.0 |  | $ | 4.0 |  | $ | 2.5 |  | $ | 6.6 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-21-000175:notes:90]
[same as prior period, unchanged from 0000038725-21-000092:notes:80]

[0000038725-21-000175:notes:91]
[same as prior period, unchanged from 0000038725-21-000092:notes:81]

[0000038725-21-000175:notes:92]
[same as prior period, unchanged from 0000038725-21-000092:notes:82]

[0000038725-21-000175:notes:93]
[same as prior period, unchanged from 0000038725-21-000092:notes:83]

[0000038725-21-000175:notes:94]
[same as prior period, unchanged from 0000038725-21-000092:notes:84]

[0000038725-21-000175:notes:95]
[same as prior period, unchanged from 0000038725-21-000092:notes:85]

[0000038725-21-000175:notes:96]
[same as prior period, unchanged from 0000038725-21-000092:notes:86]

[0000038725-21-000175:notes:97]
[same as prior period, unchanged from 0000038725-21-000092:notes:87]

[0000038725-21-000175:notes:98]
[same as prior period, unchanged from 0000038725-21-000092:notes:88]

[0000038725-21-000175:notes:99]
[same as prior period, unchanged from 0000038725-21-000092:notes:89]

[0000038725-21-000175:notes:100]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the six months ended June 30, 2021 and June 30, 2020 are as follows:

[0000038725-21-000175:notes:101]
|  |  | June 30, 2021 |  | June 30, 2020 |
| Risk-free interest rate |  | 0.66 | % |  | 1.39 | % |
| Dividend yield |  | 0.96 | % |  | 1.04 | % |
| Volatility factor |  | 34.98 | % |  | 29.45 | % |
| Expected term |  | 5.5 years |  | 5.5 years |

[0000038725-21-000175:notes:102]
A summary of the Company’s outstanding stock option activity and related information for the six months ended June 30, 2021 is as follows:

[0000038725-21-000175:notes:103]
| (Shares in thousands) |  | June 30, 2021 |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,331 |  |  | $ | 41.90 |  |
| Granted |  | 152 |  |  | 73.14 |  |
| Exercised |  | (256) |  |  | 35.10 |  |
| Forfeited |  | — |  |  | — |  |
| Outstanding at end of period |  | 1,227 |  |  | $ | 47.18 |  |
| Expected to vest after applying forfeiture rate |  | 1,224 |  |  | $ | 47.13 |  |
| Vested and exercisable at end of period |  | 839 |  |  | $ | 40.45 |  |

[0000038725-21-000175:notes:104]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value as of June 30, 2021 is as follows:

[0000038725-21-000175:notes:105]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 6.19 years |  | $ | 41,025 |  |
| Expected to vest after applying forfeiture rate |  | 6.18 years |  | $ | 40,981 |  |
| Vested and exercisable at end of period |  | 5.06 years |  | $ | 33,700 |  |

[0000038725-21-000175:notes:106]
The total intrinsic value of options exercised during the six months ended June 30, 2021 and June 30, 2020 was $11.2 million and $0.9 million, respectively.

[0000038725-21-000175:notes:107]
As of June 30, 2021, there was $1.4 million of total unrecognized compensation cost related to non-vested stock options granted under the stock plans. That cost is expected to be recognized over a weighted-average period of 1.74 years.

[0000038725-21-000175:notes:108]
[same as prior period, unchanged from 0000038725-21-000092:notes:98]

[0000038725-21-000175:notes:109]
A summary of the Company’s restricted stock/stock unit award activity and related information for the six months ended June 30, 2021 is as follows:

[0000038725-21-000175:notes:110]
| (Shares in thousands) |  | June 30, 2021 |
| Restricted Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 403 |  |  | $ | 49.34 |  |
| Awarded |  | 104 |  |  | 74.23 |  |
| Vested |  | (118) |  |  | 43.21 |  |
| Forfeited |  | (9) |  |  | 47.76 |  |
| Non-vested at end of period |  | 380 |  |  | $ | 58.12 |  |

[0000038725-21-000175:notes:111]
As of June 30, 2021, there was $11.5 million of total unrecognized compensation cost related to non-vested restricted stock/stock unit awards granted under the stock plans. That cost is expected to be recognized over a weighted-average period of 1.38 years.


## us-gaap:SubsequentEventsTextBlock

[0000038725-21-000175:notes:112]
SUBSEQUENT EVENT
Amended and Restated Note Purchase and Private Shelf Agreement - NYL Shelf Agreement

[0000038725-21-000175:notes:113]
On July 30, 2021, Franklin Electric Co., Inc. and Franklin Electric B.V. ("Dutch Subsidiary Issuer") entered into a new unsecured $200.0 million uncommitted maximum aggregate principal amount private shelf facility for a period of up to 3 years pursuant to that certain Amended and Restated Note Purchase and Private Shelf Agreement with NYL Investors LLC, New York Life Insurance Company and New York Life Insurance and Annuity Corporation (collectively, “New York Life”) dated as of July 30, 2021 (the “NYL Shelf Agreement”). Subject to the terms and conditions set forth therein, the NYL Shelf Agreement allows the Company to issue senior promissory notes to New York Life at floating or fixed rate economic terms to be agreed upon at the time of issuance, from time to time during a three year issuance period ending July 30, 2024.

[0000038725-21-000175:notes:114]
The minimum principal amount of the private shelf note that can be issued under the NYL Shelf Agreement is $5.0 million with an issuance fee of 0.10% of the aggregate principal amount of the issued shelf note, payable on the date of issuance in Dollars. The NYL Shelf Agreement also provides for other fees, including a varying leverage fee payable for periods during which the ratio of the Company’s consolidated total debt to earnings before interest, taxes, depreciation and amortization is equal to or greater than 2.00 to 1.00.

[0000038725-21-000175:notes:115]
The term of each note issuance under the NYL Shelf Agreement will be selected by the Company and will not exceed 12 years for fixed rate notes and 10 years for floating rate notes. The proceeds of any issuance under the NYL Shelf Agreement will be used as set forth in the applicable Request for Purchase.

[0000038725-21-000175:notes:116]
The NYL Shelf Agreement has customary affirmative and negative covenants for agreements of these types. The affirmative covenants include delivery of financial statements, permitting of inspections of the property of the Company and its subsidiaries, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans or advances, acquisitions (including investments), and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Under specific acquisition factors, the maximum leverage ratio can increase to 4.00 to 1.00 for up to four consecutive Fiscal Quarters. Cross default is applicable with the NYL Shelf Agreement, but only if the Company is defaulting on an obligation exceeding $10.0 million. The NYL Shelf Agreement also contains customary events of default (with customary grace periods, as applicable, for certain of those events of default). If an event of default occurs, all payment obligations under the private shelf notes outstanding plus a yield maintenance amount (if any) may be declared due and payable. For certain events of default relating to insolvency, bankruptcy or liquidation, all payment obligations under outstanding private shelf notes plus a yield maintenance amount (if any) automatically become due and payable. The covenants in the NYL Shelf Agreement are subject to a number of important exceptions and qualifications set forth therein.

[0000038725-21-000175:notes:117]
All notes issued under the NYL Shelf Agreement are unsecured and rank pari passu in right of payment with the Company’s other senior unsecured indebtedness. The payment of outstanding amounts due under any notes and the performance by the Company of its obligations under the NYL Shelf Agreement have been guaranteed by certain wholly-owned U.S. subsidiaries of the Company.

[0000038725-21-000175:notes:118]
The description of the NYL Shelf Agreement contained herein is qualified in its entirety by reference to the NYL Shelf Agreement, a copy of which is filed hereto as Exhibit 10.5.

[0000038725-21-000175:notes:119]
Fourth Amended and Restated Note Purchase and Private Shelf Agreement - Pru Shelf Agreement

[0000038725-21-000175:notes:120]
Also on July 30, 2021, Franklin Electric Co., Inc. and Franklin Electric B.V. ("Dutch Subsidiary Issuer") entered into an unsecured $150.0 million uncommitted maximum aggregate principal amount private shelf facility for a period of up to 3 years pursuant to that certain Fourth Amended and Restated Note Purchase and Private Shelf Agreement, dated as of July 30, 2021, with Prudential Investment Management, Inc. (“Prudential”) and the purchasers named therein (the “Pru Shelf Agreement”). The Pru Shelf Agreement amended and restated the Third Amended and Restated Note Purchase and Private Shelf Agreement, dated as of May 28, 2015, between the Company and Prudential and the purchasers named therein (the “Existing 2015 Shelf Agreement”) and amended and restated the Existing 2004 Shelf Agreement and the Series B-1 Notes and Series B-2 Notes (collectively, the "Series B Notes"). The Series B Notes that were issued under the 2004 Shelf Agreement that were outstanding under the Existing 2015 Shelf Agreement in the original principal amount of $150.0 million became outstanding under the Pru Shelf Agreement. The minimum principal amount of the private shelf note that can be issued under the Pru Shelf Agreement is $5.0 million payable on the date of issuance. The Pru Shelf Agreement also provides for other fees,

[0000038725-21-000175:notes:121]
including a varying leverage fee payable for periods during which the ratio of the Company’s consolidated total debt to earnings before interest, taxes, depreciation and amortization is equal to or greater than 2.00 to 1.00.

[0000038725-21-000175:notes:122]
Any private shelf note issued under the Pru Shelf Agreement during the issuance period may have a maturity of up to 15 years, provided that the average life for each private shelf note issued is no more than 12 years after the date of original issuance. The private shelf notes may be issued in U.S. dollars or in the equivalent thereof at the time of issuance in British Pounds and Euros. The proceeds of any issuance under the Pru Shelf Agreement will be used for general corporate purposes, including the repayment of existing indebtedness.

[0000038725-21-000175:notes:123]
The Pru Shelf Agreement has customary affirmative and negative covenants for agreements of these types. The affirmative covenants include delivery of financial statements, permitting of inspections of the property of the Company and its subsidiaries, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans or advances, acquisitions (including investments), and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Under specific acquisition factors, the maximum leverage ratio can increase to 4.00 to 1.00 for up to four consecutive Fiscal Quarters. Cross default is applicable with the Pru Shelf Agreement, but only if the Company is defaulting on an obligation exceeding $10.0 million. The Pru Shelf Agreement also contains customary events of default (with customary grace periods, as applicable, for certain of those events of default). If an event of default occurs, all payment obligations under the private shelf notes outstanding plus a yield maintenance amount (if any) may be declared due and payable. For certain events of default relating to insolvency, bankruptcy or liquidation, all payment obligations under outstanding private shelf notes plus a yield maintenance amount (if any) automatically become due and payable. The covenants in the Pru Shelf Agreement are subject to a number of important exceptions and qualifications set forth therein.

[0000038725-21-000175:notes:124]
All notes issued under the Pru Shelf Agreement are unsecured and rank pari passu in right of payment with the Company’s other senior unsecured indebtedness. The payment of outstanding amounts due under any notes and the performance by the Company of its obligations under the Pru Shelf Agreement have been guaranteed by certain wholly-owned U.S. subsidiaries of the Company.

[0000038725-21-000175:notes:125]
The description of the Pru Shelf Agreement contained herein is qualified in its entirety by reference to the Pru Shelf Agreement, a copy of which is filed hereto as Exhibit 10.6.
