# FELE MD&A — 0000038725-21-000175


## mdna

[0000038725-21-000175:mdna:1]
[same as prior period, unchanged from 0000038725-21-000092:mdna:1]

[0000038725-21-000175:mdna:2]
Second Quarter 2021 vs. Second Quarter 2020

[0000038725-21-000175:mdna:3]
[same as prior period, unchanged from 0000038725-21-000092:mdna:3]

[0000038725-21-000175:mdna:4]
Sales in the second quarter of 2021 increased from the second quarter of last year. The sales increase was primarily from higher volumes, in part created by the business recovering from the uncertainty and general disruptions around the global pandemic last year and from acquisition related sales. The Company's consolidated gross profit was $152.2 million for the second quarter of 2021, an increase from the prior year’s second quarter. The gross profit as a percent of net sales was 34.8 percent in the second quarter of 2021 versus 34.7 percent during the second quarter of 2020. Diluted earnings per share in the second quarter of 2021 were up from the same period last year.

[0000038725-21-000175:mdna:5]
[same as prior period, unchanged from 0000038725-21-000092:mdna:5]

[0000038725-21-000175:mdna:6]
[same as prior period, unchanged from 0000038725-21-000092:mdna:6]

[0000038725-21-000175:mdna:7]
Net sales in the second quarter of 2021 were $437.3 million, an increase of $129.0 million or about 42 percent compared to 2020 second quarter sales of $308.3 million. Acquisition related sales were $38.9 million. Sales revenue increased by $6.1 million or about 2 percent in the second quarter of 2021 due to foreign currency translation. Organic sales increased about 28 percent compared to the second quarter of 2020.

[0000038725-21-000175:mdna:8]
|  | Net Sales |
| (In millions) | Q2 2021 |  | Q2 2020 |  | 2021 v 2020 |
| Water Systems | $ | 247.2 |  |  | $ | 178.4 |  |  | $ | 68.8 |  |
| Fueling Systems | 72.2 |  |  | 56.0 |  |  | $ | 16.2 |  |
| Distribution | 144.8 |  |  | 92.1 |  |  | $ | 52.7 |  |
| Eliminations/Other | (26.9) |  |  | (18.2) |  |  | $ | (8.7) |  |
| Consolidated | $ | 437.3 |  |  | $ | 308.3 |  |  | $ | 129.0 |  |

[0000038725-21-000175:mdna:9]
[same as prior period, unchanged from 0000038725-21-000092:mdna:9]

[0000038725-21-000175:mdna:10]
Water Systems sales were $247.2 million in the second quarter of  2021, an increase of $68.8 million or about 39 percent versus the second quarter of 2020 sales of $178.4 million. Acquisition related sales were $23.8 million. Water Systems sales increased by $4.8 million or about 3 percent in the quarter due to foreign currency translation. Excluding acquisitions and foreign currency translation, Water Systems sales were up $40.2 million or about 23 percent compared to the second quarter of 2020.

[0000038725-21-000175:mdna:11]
Water Systems sales in the U.S. and Canada were up about 42 percent compared to the second quarter of 2020. The impact of foreign currency translation increased sales by about 2 percent.  In the second quarter of 2021, sales from businesses acquired since the second quarter of 2020 were $23.8 million. Organic Water Systems sales in the U.S. and Canada were 17 percent in the second quarter.  Sales of groundwater pumping equipment increased by about 16 percent, sales of dewatering equipment were up about 90 percent, and sales of surface pumping equipment increased by about 13 percent versus the second quarter of 2020, all due to strong end market demand and in part resulting from lower sales last year due to the pandemic.

[0000038725-21-000175:mdna:12]
Water Systems sales in markets outside the U.S. and Canada increased by 34 percent overall. The impact of foreign currency translation increased sales by about 4 percent. Excluding the impact of foreign currency translation, Water Systems sales in markets outside the U.S. and Canada, increased by 30 percent, primarily driven by higher sales in Latin America, Europe, the Middle East and African markets (EMEA).

[0000038725-21-000175:mdna:13]
[same as prior period, unchanged from 0000038725-21-000092:mdna:13]

[0000038725-21-000175:mdna:14]
Fueling Systems sales were $72.2 million in the second quarter of 2021, an increase of $16.2 million or about 29 percent versus the second quarter of 2020 sales of $56.0 million. Fueling Systems sales increased by $1.3 million or about 2 percent in the quarter due to foreign currency translation. Fueling Systems organic sales increased about 27 percent compared to the second quarter of 2020.

[0000038725-21-000175:mdna:15]
Fueling Systems sales in the U.S. and Canada increased by about 40 percent compared to the second quarter of 2020. The increase was due to higher demand for Piping, Pumping and Fuel Management Systems. Outside the U.S. and Canada, Fueling Systems revenues increased by about 1 percent, driven primarily by higher sales in Latin America and EMEA, partially offset by lower sales in China.

[0000038725-21-000175:mdna:16]
[same as prior period, unchanged from 0000038725-21-000092:mdna:16]

[0000038725-21-000175:mdna:17]
Distribution sales were $144.8 million in the second quarter of 2021, versus the second quarter of 2020 sales of $92.1 million. In the second quarter of 2021, sales from businesses acquired since the second quarter of 2020 were $15.1 million.  The Distribution segment organic sales increased 41 percent compared to the second quarter of 2020. Revenue growth was driven by broad-based demand in all regions and product categories.

[0000038725-21-000175:mdna:18]
[same as prior period, unchanged from 0000038725-21-000092:mdna:18]

[0000038725-21-000175:mdna:19]
Cost of sales as a percent of net sales for the second quarter of 2021 was 65.2 percent and 65.3 percent for the second quarter of 2020. Correspondingly, the gross profit margin was 34.8 percent and 34.7 percent for the second quarters of 2021 and 2020, respectively. The Company's consolidated gross profit was $152.2 million for the second quarter of 2021, up $45.1 million from the gross profit of $107.1 million in the second quarter of 2020. The gross profit increase was due to higher sales. In the second quarter, the gross profit margin percentage was flat.

[0000038725-21-000175:mdna:20]
[same as prior period, unchanged from 0000038725-21-000092:mdna:20]

[0000038725-21-000175:mdna:21]
Selling, general, and administrative (SG&A) expenses were $100.5 million in the second quarter of 2021 compared to $72.3 million in the second quarter of 2020.  SG&A expenses from acquired businesses were $9.9 million and excluding the acquired entities, SG&A expenses were higher by $18.3 million versus the prior year. The primary increase was about $10 million in variable compensation expense and commissions on higher sales.  In addition, transaction, legal and other administrative costs were about $2 million.  SG&A costs as a percent of Net Sales were slightly below the second quarter of 2020.

[0000038725-21-000175:mdna:22]
[same as prior period, unchanged from 0000038725-21-000092:mdna:22]

[0000038725-21-000175:mdna:23]
Restructuring expenses for the second quarter of 2021 were $0.2 million and related to continued miscellaneous manufacturing and distribution realignment activities in the Water Systems segment. Restructuring expenses for the second quarter of 2020 were $0.9 million and related to continued miscellaneous manufacturing and distribution realignment activities in the Water Systems segment.

[0000038725-21-000175:mdna:24]
[same as prior period, unchanged from 0000038725-21-000092:mdna:25]

[0000038725-21-000175:mdna:25]
Operating income was $51.6 million in the second quarter of 2021, up $17.7 million or about 52 percent from $33.9 million in the second quarter of 2020.

[0000038725-21-000175:mdna:26]
|  |  | Operating income (loss) |
| (In millions) |  | Q2 2021 |  | Q2 2020 |  | 2021 v 2020 |
| Water Systems |  | 34.6 |  |  | $ | 28.7 |  |  | $ | 5.9 |  |
| Fueling Systems |  | 18.5 |  |  | 13.5 |  |  | 5.0 |  |
| Distribution |  | 16.0 |  |  | 6.8 |  |  | 9.2 |  |
| Eliminations/Other |  | (17.5) |  |  | (15.1) |  |  | (2.4) |  |
| Consolidated |  | $ | 51.6 |  |  | $ | 33.9 |  |  | $ | 17.7 |  |

[0000038725-21-000175:mdna:27]
[same as prior period, unchanged from 0000038725-21-000092:mdna:28]

[0000038725-21-000175:mdna:28]
Water Systems operating income was $34.6 million in the second quarter of 2021, up $5.9 million or about 21 percent versus the second quarter of 2020 and operating income margin was 14.0 percent compared to the 16.1 percent in the second quarter of 2020. Operating income margin decreased in Water Systems primarily due to higher shipping and freight costs of about $3 million, which were not fully offset by price increases, mostly in North America and about $2 million for transaction, legal and other charges incurred in the second quarter.

[0000038725-21-000175:mdna:29]
[same as prior period, unchanged from 0000038725-21-000092:mdna:30]

[0000038725-21-000175:mdna:30]
Fueling Systems operating income was $18.5 million in the second quarter of 2021, up $5.0 million or about 37 percent compared to $13.5 million in the second quarter of 2020, and the second quarter operating income margin was 25.6 percent, an increase of 150 basis points from the 24.1 percent of net sales in the second quarter of 2020. The increase in operating income was primarily due to higher sales.

[0000038725-21-000175:mdna:31]
[same as prior period, unchanged from 0000038725-21-000092:mdna:32]

[0000038725-21-000175:mdna:32]
Distribution operating income was $16.0 million in the second quarter of 2021, and the second quarter operating income margin was 11.0 percent. Distribution operating income was $6.8 million in the second quarter of 2020, and the second quarter

[0000038725-21-000175:mdna:33]
operating income margin was 7.4 percent. The increase in operating income margin is primarily related to higher revenues and operating leverage.

[0000038725-21-000175:mdna:34]
[same as prior period, unchanged from 0000038725-21-000092:mdna:35]

[0000038725-21-000175:mdna:35]
Operating income-Eliminations/Other is composed primarily of unallocated general and administrative expenses and inter-segment sales and profit eliminations. The inter-segment profit elimination impact in the second quarter of 2021 versus the second quarter of 2020 was $0.3 million.  General and administrative expenses were higher by $2.7 million primarily due to higher variable compensation.

[0000038725-21-000175:mdna:36]
[same as prior period, unchanged from 0000038725-21-000092:mdna:37]

[0000038725-21-000175:mdna:37]
Interest expense for the second quarter of 2021 and 2020 was $1.4 million and $1.1 million, respectively.

[0000038725-21-000175:mdna:38]
[same as prior period, unchanged from 0000038725-21-000092:mdna:39]

[0000038725-21-000175:mdna:39]
Other income or expense was a loss of $0.4 million in the second quarter of 2021 and 2020.

[0000038725-21-000175:mdna:40]
[same as prior period, unchanged from 0000038725-21-000092:mdna:41]

[0000038725-21-000175:mdna:41]
Foreign currency-based transactions produced a loss for the second quarter of 2021 of $1.2 million, primarily due to the Argentinian peso relative to the U.S. dollar. Foreign currency-based transactions produced a loss for the second quarter of 2020 of $0.9 million, primarily due to the Argentinian peso relative to the U.S. dollar.

[0000038725-21-000175:mdna:42]
[same as prior period, unchanged from 0000038725-21-000092:mdna:43]

[0000038725-21-000175:mdna:43]
The provision for income taxes in the second quarter of 2021 and 2020 was $9.3 million and $6.7 million, respectively. The effective tax rate for the second quarter of 2021 was about 19 percent and, before the impact of discrete events, was about 20 percent. The effective tax rate for the second quarter of 2020 was about 21 percent and, before the impact of discrete events, was about 20 percent. The decrease in the effective tax rate was primarily a result of net favorable discrete events, including increased excess tax benefits from share-based compensation, recorded in the second quarter of 2021 compared to net unfavorable discrete events recorded in the second quarter of 2020 from a valuation allowance on foreign deferred tax assets. The tax rate as a percentage of pre-tax earnings for the full year 2021 is projected to be about 20 percent, compared to the full year 2020 tax rate of about 21 percent, both before discrete adjustments.

[0000038725-21-000175:mdna:44]
[same as prior period, unchanged from 0000038725-21-000092:mdna:45]

[0000038725-21-000175:mdna:45]
Net income for the second quarter of 2021 was $39.4 million compared to the prior year second quarter net income of $24.8 million. Net income attributable to Franklin Electric Co., Inc. for the second quarter of 2021 was $39.1 million, or $0.83 per diluted share, compared to the prior year second quarter net income attributable to Franklin Electric Co., Inc. of $24.7 million or $0.52 per diluted share.

[0000038725-21-000175:mdna:46]
First Half 2021 vs. First Half 2020

[0000038725-21-000175:mdna:47]
OVERVIEW

[0000038725-21-000175:mdna:48]
Sales in the first half of 2021 were up from the same period last year. The sales increase was primarily from higher volumes, in part created by the business recovering from the uncertainty and general disruptions around the global pandemic last year and from acquisition related sales. The Company's consolidated gross profit was $267.8 million for the first half of 2021, an increase of $70.4 million or about 36 percent from the first half of 2020. Diluted earnings per share in the first half of 2021 were up from the same period last year.

[0000038725-21-000175:mdna:49]
RESULTS OF OPERATIONS

[0000038725-21-000175:mdna:50]
Net Sales

[0000038725-21-000175:mdna:51]
Sales in the first half of 2021 were up from the same period last year. The sales increase was primarily from higher volumes, in part created by the business recovering from the uncertainty and general disruptions around the global pandemic last year and from acquisition related sales. The Company's consolidated gross profit was $267.8 million for the first half of 2021, an increase of $70.4 million or about 36 percent from the first half of 2020. Diluted earnings per share in the first half of 2021 were up from the same period last year.

[0000038725-21-000175:mdna:52]
|  | Net Sales |
| (In millions) | YTD June 30, 2021 |  | YTD June 30, 2020 |  | 2021 v 2020 |
| Water Systems | $ | 444.8 |  |  | $ | 342.5 |  |  | $ | 102.3 |  |
| Fueling Systems | 129.0 |  |  | 111.2 |  |  | $ | 17.8 |  |
| Distribution | 240.5 |  |  | 152.5 |  |  | $ | 88.0 |  |
| Eliminations/Other | (44.0) |  |  | (31.2) |  |  | $ | (12.8) |  |
| Consolidated | $ | 770.3 |  |  | $ | 575.0 |  |  | $ | 195.3 |  |

[0000038725-21-000175:mdna:53]
Net Sales-Water Systems

[0000038725-21-000175:mdna:54]
Water Systems sales were $444.8 million in the first half of 2021, an increase of $102.3 million or about 30 percent versus the first half of 2020. The incremental impact of sales from acquired businesses was $31.0 million. Foreign currency translation changes increased sales $1.1 million compared to sales in the first half of 2020. The Water Systems sales change in the first half of 2021, excluding acquisitions and foreign currency translation, was an increase of $70.2 million or about 20 percent.

[0000038725-21-000175:mdna:55]
Water Systems sales in the U.S. and Canada increased by about 32 percent compared to the first half of 2020. The incremental impact of sales from acquired businesses was $31.0 million. Sales revenue increased by $2.5 million in the first half of 2021 due to foreign currency translation. In the first half of 2021, organic Water Systems sales in the U.S. and Canada were 14 percent.  Sales of groundwater pumping equipment increased by about 20 percent, sales of dewatering equipment were up about 30 percent, and sales of surface pumping equipment increased by about 12 percent versus the second quarter of 2020, all due to strong end market demand and in part resulting from lower sales last year due to the pandemic.

[0000038725-21-000175:mdna:56]
Water Systems sales in markets outside the U.S. and Canada increased by about 27 percent compared to the first half of 2020. Sales revenue decreased by $1.4 million or about 1 percent in the first half of 2021 due to foreign currency translation. International Water Systems organic sales change in the first half of 2021, excluding foreign currency translation, was an increase of about 28 percent. International Water Systems sales grew in all major geographic regions; Latin America, EMEA and the Asia Pacific markets, in part by the business recovering from the global pandemic last year.

[0000038725-21-000175:mdna:57]
Net Sales-Fueling Systems

[0000038725-21-000175:mdna:58]
Fueling Systems sales were $129.0 million in the first half of 2021, an increase of $17.8 million or about 16 percent from the first half of 2020. Foreign currency translation changes increased sales $2.1 million or about 2 percent compared to sales in the first half of 2020. The Fueling Systems sales change in the first half of 2021, excluding acquisitions and foreign currency translation, was an increase of about 14 percent.

[0000038725-21-000175:mdna:59]
Fueling Systems sales in the U.S. and Canada increased by about 20 percent during the first half. The increase was due to higher demand for Piping, Pumping and Fuel Management Systems.  Outside the U.S. and Canada, Fueling Systems revenues increased by about 4 percent, driven primarily by higher sales in Latin America and EMEA, partially offset by lower sales in China.

[0000038725-21-000175:mdna:60]
Net Sales - Distribution

[0000038725-21-000175:mdna:61]
Distribution sales were $240.5 million in the first half of 2021, versus the first half of 2020 sales of $152.5 million. The incremental impact of sales from acquired businesses was $31.4 million. Distribution segment organic sales increased about 37 percent compared to the first half of 2020, driven by broad-based demand in all regions and product categories.

[0000038725-21-000175:mdna:62]
Cost of Sales

[0000038725-21-000175:mdna:63]
Cost of sales as a percent of net sales for the first half of 2021 and 2020 was 65.2 percent and 65.7 percent, respectively. Correspondingly, the gross profit margin was 34.8 percent and 34.3 percent, respectively. The Company's consolidated gross profit was $267.8 million for the first half of 2021, up $70.4 million from the gross profit of $197.4 million in the first half of 2020. The gross profit increase was primarily due to higher sales. The improvement in gross profit margin percentage is partially attributable to better selling price realization and improved product and geographic sales mix shifts.

[0000038725-21-000175:mdna:64]
Selling, General, and Administrative ("SG&A")

[0000038725-21-000175:mdna:65]
Selling, general, and administrative expenses were $182.1 million in the first half of 2021, and increased by $34.2 million or 23 percent in the first half of 2021 compared to $147.9 million in the first half of last year. SG&A expenses from acquired businesses were $14.8 million and excluding the acquired entities, SG&A expenses were higher by $19.4 million versus the prior year. The primary increase was about $13 million in variable compensation expense and commissions on higher sales.

[0000038725-21-000175:mdna:66]
Restructuring Expenses

[0000038725-21-000175:mdna:67]
Restructuring expenses for the first half of 2021 were $0.3 million. Restructuring expenses were $0.2 million in the Water Systems segment from continued miscellaneous manufacturing and distribution realignment activities and $0.1 in distribution related to branch consolidations and other asset rationalizations in the Headwater distribution segment. Restructuring expenses for the first half of 2020 were $1.7 million. Restructuring expenses were $1.5 million in the Water Systems segment and $0.1 million in the Fueling Systems segment from continued miscellaneous manufacturing and distribution realignment activities and $0.1 in distribution related to branch consolidations and other asset rationalizations in the Headwater distribution.

[0000038725-21-000175:mdna:68]
Operating Income

[0000038725-21-000175:mdna:69]
Operating income was $85.4 million in the first half of 2021, up $37.6 million or about 79 percent from $47.8 million in the first half of 2020.

[0000038725-21-000175:mdna:70]
|  |  | Operating income (loss) |
| (In millions) |  | YTD June 30, 2021 |  | YTD June 30, 2020 |  | 2021 v 2020 |
| Water Systems |  | 65.9 |  |  | 47.5 |  |  | $ | 18.4 |  |
| Fueling Systems |  | 33.4 |  |  | 25.6 |  |  | 7.8 |  |
| Distribution |  | 18.0 |  |  | 4.6 |  |  | 13.4 |  |
| Eliminations/Other |  | (31.9) |  |  | (29.9) |  |  | (2.0) |  |
| Consolidated |  | $ | 85.4 |  |  | $ | 47.8 |  |  | $ | 37.6 |  |

[0000038725-21-000175:mdna:71]
Operating Income-Water Systems

[0000038725-21-000175:mdna:72]
Water Systems operating income was $65.9 million in the first half of 2021 compared to $47.5 million in the first half of 2020, an increase of about 39 percent. The first half operating income margin was 14.8 percent and increased by 90 basis points compared to the first half of 2020. Operating income margin increased in Water Systems primarily related to higher revenues and operating leverage.

[0000038725-21-000175:mdna:73]
Operating Income-Fueling Systems

[0000038725-21-000175:mdna:74]
Fueling Systems operating income was $33.4 million in the first half of 2021 compared to $25.6 million in the first half of 2020. The first half operating income margin was 25.9 percent compared to 23.0 percent of net sales in the first half of 2020, an increase of 290 basis points. The increase in operating income was primarily due to higher sales. Operating income margin increased in Fueling Systems primarily due to product and geographic sales mix shifts.

[0000038725-21-000175:mdna:75]
Operating Income-Distribution

[0000038725-21-000175:mdna:76]
Distribution operating income was $18.0 million in the first half of 2021 and operating income margin was 7.5 percent. Distribution operating income was $4.6 million in the first half of 2020 and operating income margin was 3.0 percent. The increase in operating income and margin is primarily related to higher revenues and operating leverage.

[0000038725-21-000175:mdna:77]
Operating Income-Eliminations/Other

[0000038725-21-000175:mdna:78]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses. The inter-segment profit elimination impact in the first half of 2021 versus the first half of 2020 was $0.4 million. General and administrative expenses were higher by $2.4 million or about 9 percent to last year in the first half primarily due to higher variable compensation.

[0000038725-21-000175:mdna:79]
Interest Expense

[0000038725-21-000175:mdna:80]
Interest expense for the first half of 2021 and 2020 was $2.5 million and $2.4 million, respectively.

[0000038725-21-000175:mdna:81]
Other Income or Expense

[0000038725-21-000175:mdna:82]
Other income or expense was a loss of $0.5 million in the first half of 2021. Other income or expense was a loss of $0.6 million in the first half of 2020.

[0000038725-21-000175:mdna:83]
Foreign Exchange

[0000038725-21-000175:mdna:84]
Foreign currency-based transactions for the first half of 2021 was a loss $1.2 million, primarily due to the Argentinian peso relative to the U.S. dollar.  Foreign currency-based transactions for the first half of 2020 was a gain $0.1 million due to movements in several currencies relative to the U.S. dollar, none of which individually were significant.

[0000038725-21-000175:mdna:85]
Income Taxes

[0000038725-21-000175:mdna:86]
The provision for income taxes in the first half of 2021 and 2020 was $13.6 million and $9.3 million, respectively. The effective tax rate for the first half of 2021 was about 17 percent, and before the impact of discrete events, was about 20 percent. The effective tax rate in the first half of 2020 was about 21 percent, and before the impact of discrete events, was about 20 percent. The decrease in the effective tax rate was primarily a result of net favorable discrete events recorded in the first half of 2021 compared to net unfavorable discrete events in the first half of 2020. The tax rate as a percentage of pre-tax earnings for the full year 2021 is projected to be about 20 percent, compared to the full year 2020 tax rate of about 21 percent, both before discrete adjustments.

[0000038725-21-000175:mdna:87]
Net Income

[0000038725-21-000175:mdna:88]
Net income for the first half of 2021 was $67.5 million compared to 2020 first half net income of $35.6 million. Net income attributable to Franklin Electric Co., Inc. for the first half of 2021 was $67.0 million, or $1.42 per diluted share, compared to 2020 first half net income attributable to Franklin Electric Co., Inc. of $35.3 million or $0.75 per diluted share.

[0000038725-21-000175:mdna:89]
[same as prior period, unchanged from 0000038725-21-000092:mdna:47]

[0000038725-21-000175:mdna:90]
[same as prior period, unchanged from 0000038725-21-000092:mdna:48]

[0000038725-21-000175:mdna:91]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at June 30, 2021 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-21-000175:mdna:92]
As of June 30, 2021 the Company had a $250.0 million revolving credit facility. The facility is scheduled to mature on May 13, 2026. As of June 30, 2021, the Company had $116.0 million borrowing capacity under the Credit Agreement as $4.0 million in letters of commercial and standby letters of credit were outstanding and undrawn and $130 million in revolver borrowings were drawn and outstanding, which were primarily used for funding recent acquisitions.

[0000038725-21-000175:mdna:93]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement") with a remaining borrowing capacity of  $125.0 million as of June 30, 2021. The Company also has other long-term debt borrowings outstanding as of June 30, 2021. See Note 9 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-21-000175:mdna:94]
At June 30, 2021, the Company had $65.1 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations. There is currently no need or intent to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-21-000175:mdna:95]
[same as prior period, unchanged from 0000038725-21-000092:mdna:53]

[0000038725-21-000175:mdna:96]
The following table summarizes significant sources and uses of cash and cash equivalents for the first six months of 2021 and 2020.

[0000038725-21-000175:mdna:97]
| (in millions) |  | 2021 |  | 2020 |
| Net cash flows from operating activities |  | $ | 35.5 |  |  | $ | 47.0 |  |
| Net cash flows from investing activities |  | (193.7) |  |  | (15.2) |  |
| Net cash flows from financing activities |  | 110.7 |  |  | (48.6) |  |
| Impact of exchange rates on cash and cash equivalents |  | (1.7) |  |  | (4.5) |  |
| Change in cash and cash equivalents |  | $ | (49.2) |  |  | $ | (21.3) |  |

[0000038725-21-000175:mdna:98]
[same as prior period, unchanged from 0000038725-21-000092:mdna:56]

[0000038725-21-000175:mdna:99]
[same as prior period, unchanged from 0000038725-21-000092:mdna:57]

[0000038725-21-000175:mdna:100]
Net cash provided by operating activities was $35.5 million for the six months ended June 30, 2021 compared to $47.0 million provided by operating activities for the six months ended June 30, 2020. The decrease in cash provided by operating activities was primarily due to increased working capital requirements in support of higher revenues.

[0000038725-21-000175:mdna:101]
[same as prior period, unchanged from 0000038725-21-000092:mdna:59]

[0000038725-21-000175:mdna:102]
[same as prior period, unchanged from 0000038725-21-000092:mdna:60]

[0000038725-21-000175:mdna:103]
Net cash used in investing activities was $193.7 million for the six months ended June 30, 2021 compared to $15.2 million used in investing activities for the  six months ended June 30, 2020. The increase in cash used in investing activities was attributable to increased acquisition activity in 2021.

[0000038725-21-000175:mdna:104]
[same as prior period, unchanged from 0000038725-21-000092:mdna:62]

[0000038725-21-000175:mdna:105]
[same as prior period, unchanged from 0000038725-21-000092:mdna:63]

[0000038725-21-000175:mdna:106]
Net cash provided by financing activities was $110.7  million for the six months ended June 30, 2021 compared to $48.6 million used in financing activities for the six months ended June 30, 2020. The increase in cash provided by financing activities was attributable to increased debt proceeds and issuance of common stock, primarily through stock option exercises, and decreased common stock repurchases.

[0000038725-21-000175:mdna:107]
[same as prior period, unchanged from 0000038725-21-000092:mdna:65]

[0000038725-21-000175:mdna:108]
33
