# FELE note change history — 0000038725-22-000078 → 0000038725-22-000148


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-08-02):
[0000038725-22-000148:note_history:1]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. In May 2022 the subject-matter expert issued its final report, which indicates that total damages incurred by Esso amounted to approximately 9.5 million Euro. It is the Company’s continuing position that its products were not the cause of any alleged damage. The Company's response to the expert's final report is due in January 2023, at which time the French court will determine whether the merits of the claim warrant additional proceedings. The Company cannot predict the ultimate outcome of this matter. Any exposure related to this matter is neither probable nor estimable at this time. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position, results of operations, or cash flows.
  (was, 2022-05-03, similarity 0.6292):
[0000038725-22-000078:note_history:1]
COMMITMENTS AND CONTINGENCIES
In 2011, the Company became aware of a review of alleged issues with certain underground piping connections installed in filling stations in France owned by the French Subsidiary of Exxon Mobile, Esso S.A.F. A French court ordered that a designated, subject-matter expert review 103 filling stations to determine what, if any, damages are present and the cause of those damages. The Company has participated in this investigation since 2011, along with several other third parties including equipment installers, engineering design firms who designed and provided specifications for the stations, and contract manufacturers of some of the installed equipment. The subject-matter expert has issued its preliminary report, which indicates that total damages incurred by Esso amounted to approximately 12 million euro. It is the Company’s position that its products were not the cause of any alleged damage. The Company has retained experts to demonstrate that its products did not cause the damage, and in January 2021, submitted its response to the expert’s preliminary report for each station. The expert's response to the Company's report is due to the Court in June 2022. The Company cannot predict the ultimate outcome of this matter. Any exposure related to this matter is neither probable nor estimable at this time. If payments result from a resolution of this matter, depending on the amount, they could have a material effect on the Company’s financial position,  results of operations, or cash flows.

- changed (2022-08-02):
[0000038725-22-000148:note_history:2]
At June 30, 2022, the Company had $13.9 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.
  (was, 2022-05-03, similarity 0.9689):
[0000038725-22-000078:note_history:2]
At March 31, 2022, the Company had $15.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

- changed (2022-08-02):
[0000038725-22-000148:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended June 30, 2022, are as follows:
  (was, 2022-05-03, similarity 0.9053):
[0000038725-22-000078:note_history:3]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the three months ended March 31, 2022, are as follows:

- changed (2022-08-02):
[0000038725-22-000148:note_history:4]
| (In millions) |  |  |
| Balance as of December 31, 2021 |  | $ | 10.5 |  |
| Accruals related to product warranties |  | 4.8 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (4.3) |  |
| Balance as of June 30, 2022 |  | $ | 11.0 |  |
  (was, 2022-05-03, similarity 0.9815):
[0000038725-22-000078:note_history:4]
| (In millions) |  |  |
| Balance as of December 31, 2021 |  | $ | 10.5 |  |
| Accruals related to product warranties |  | 2.0 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (1.9) |  |
| Balance as of March 31, 2022 |  | $ | 10.6 |  |

- changed (2022-08-02):
[0000038725-22-000148:note_history:5]
The components of the Company’s operating lease portfolio as of the second quarter and six months ended June 30, 2022 are as follows:
  (was, 2022-05-03, similarity 0.8631):
[0000038725-22-000078:note_history:5]
The components of the Company’s operating lease portfolio as of the first quarter ended March 31, 2022 are as follows:

- added (2022-08-02):
[0000038725-22-000148:note_history:6]
|  |  | Second Quarter Ended |  | Six Months Ended |
| Lease Cost (in millions): |  | June 30, 2022 |  | June 30, 2021 |  | June 30, 2022 |  | June 30, 2021 |
| Operating lease cost |  | $ | 4.3 |  |  | $ | 2.7 |  |  | $ | 8.5 |  |  | $ | 5.7 |  |
| Short-term lease cost |  | — |  |  | 0.1 |  |  | 0.1 |  |  | 0.4 |  |
| Other Information: |  |  |  |  |  |  |  |  |
| Weighted-average remaining lease term |  |  |  |  |  | 4.2 years |  | 4.1 years |
| Weighted-average discount rate |  |  |  |  |  | 3.8 | % |  | 4.0 | % |

- changed (2022-08-02):
[0000038725-22-000148:note_history:7]
As of June 30, 2022, the Company has approximately $2.9 million of additional ROU assets related to leases that have not yet commenced, but create future lease obligations.
  (was, 2022-05-03, similarity 0.9726):
[0000038725-22-000078:note_history:7]
As of March 31, 2022, the Company has approximately $1.5 million of additional ROU assets related to leases that have not yet commenced, but create future lease obligations.

- changed (2022-08-02):
[0000038725-22-000148:note_history:8]
The minimum rental payments for non-cancellable operating leases as of June 30, 2022, are as follows:
  (was, 2022-05-03, similarity 0.9529):
[0000038725-22-000078:note_history:8]
The minimum rental payments for non-cancellable operating leases as of March 31, 2022, are as follows:

- removed (2022-08-02):
[0000038725-22-000078:note_history:9]
|  |  | First Quarter Ended |  |  |
| Lease Cost (in millions): |  | March 31, 2022 |  |  |
| Operating lease cost |  | $ | 4.2 |  |  |  |
| Short-term lease cost |  | 0.1 |  |  |  |
| Other Information: |  |  |  |  |
| Weighted-average remaining lease term |  | 4.2 years |  |  |
| Weighted-average discount rate |  | 3.9 | % |  |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-08-02):
[0000038725-22-000148:note_history:10]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTS
The accompanying condensed consolidated balance sheet as of December 31, 2021, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 30, 2022, and for the second quarters and six months ended June 30, 2022 and June 30, 2021 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the second quarter and six months ended June 30, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2022. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2021.
  (was, 2022-05-03, similarity 0.9428):
[0000038725-22-000078:note_history:10]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2021, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2022, and for the first quarters ended March 31, 2022 and March 31, 2021 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X. Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations. In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made. Operating results for the first quarter ended March 31, 2022 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2022. For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2021.

- added (2022-08-02):
[0000038725-22-000148:note_history:11]
In the second quarter of 2022, the Company concluded that Turkey represents a highly inflationary economy as its projected three-year cumulative inflation rate exceeds 100%. As a result, the Company started remeasuring the financial statements for the Company’s Turkish operations in accordance with  the highly inflationary accounting rules in ASC 830, Foreign Currency Matters, as of April 1, 2022. As a result, all gains and losses resulting from the remeasurement of the financial results of operations and other transactional foreign exchange gains and losses would be reflected in earnings rather than as a component of the Company’s comprehensive income within stockholders’ equity. As of June 30, 2022, this impact was not significant to the Company’s results.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-02):
[0000038725-22-000148:note_history:12]
DEBTDebt consisted of the following:
  (was, 2022-05-03, similarity 0.9863):
[0000038725-22-000078:note_history:12]
DEBT
Debt consisted of the following:

- changed (2022-08-02):
[0000038725-22-000148:note_history:13]
| (In millions) |  | June 30, 2022 |  | December 31, 2021 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 217.7 |  |  | 96.6 |  |
| Tax increment financing debt |  | 15.9 |  |  | 16.5 |  |
| Foreign subsidiary debt |  | 4.5 |  |  | 0.5 |  |
| Other |  | — |  |  | 0.1 |  |
| Less: unamortized debt issuance costs |  | (0.2) |  |  | (0.2) |  |
|  |  | $ | 312.9 |  |  | $ | 188.5 |  |
| Less: current maturities |  | (223.1) |  |  | (98.0) |  |
| Long-term debt |  | $ | 89.8 |  |  | 90.5 |
  (was, 2022-05-03, similarity 0.9894):
[0000038725-22-000078:note_history:13]
| (In millions) |  | March 31, 2022 |  | December 31, 2021 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 191.8 |  |  | 96.6 |  |
| Tax increment financing debt |  | 15.9 |  |  | 16.5 |  |
| Foreign subsidiary debt |  | 2.2 |  |  | 0.5 |  |
| Other |  | — |  |  | 0.1 |  |
| Less: unamortized debt issuance costs |  | (0.2) |  |  | (0.2) |  |
|  |  | $ | 284.7 |  |  | $ | 188.5 |  |
| Less: current maturities |  | (194.8) |  |  | (98.0) |  |
| Long-term debt |  | $ | 89.9 |  |  | 90.5 |

- changed (2022-08-02):
[0000038725-22-000148:note_history:14]
Debt outstanding, excluding unamortized debt issuance costs, at June 30, 2022 matures as follows:
  (was, 2022-05-03, similarity 0.9514):
[0000038725-22-000078:note_history:14]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2022 matures as follows:

- changed (2022-08-02):
[0000038725-22-000148:note_history:15]
The Company maintains the Fourth Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with PGIM, Inc. and its affiliates, which was renewed on July 30, 2021 and expires on July 30, 2024.  The Prudential Agreement has an initial borrowing capacity of $150.0 million. As of June 30, 2022, the Company had no notes issued and  $150.0 million borrowing capacity available under the Prudential Agreement.
  (was, 2022-05-03, similarity 0.9891):
[0000038725-22-000078:note_history:15]
The Company maintains the Fourth Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement") with PGIM, Inc. and its affiliates, which was renewed on July 30, 2021 and expires on July 30, 2024.  The Prudential Agreement has an initial borrowing capacity of $150.0 million. As of March 31, 2022, the Company had no notes issued and  $150.0 million borrowing capacity available under the Prudential Agreement.

- changed (2022-08-02):
[0000038725-22-000148:note_history:16]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC and its affiliates (the "New York Life Agreement"), which was renewed on July 30, 2021 and expires on July 30, 2024. The New York Life Agreement has a maximum aggregate borrowing capacity of $200.0 million. On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of June 30, 2022, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.
  (was, 2022-05-03, similarity 0.9936):
[0000038725-22-000078:note_history:16]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC and its affiliates (the "New York Life Agreement"), which was renewed on July 30, 2021 and expires on July 30, 2024. The New York Life Agreement has a maximum aggregate borrowing capacity of $200.0 million. On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually. The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of March 31, 2022, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

- changed (2022-08-02):
[0000038725-22-000148:note_history:17]
The Company maintains the Fourth Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement was renewed on May 13, 2021, has a maturity date of May 13, 2026. On May 11, 2022, the Company entered into Amendment No. 1 that increased the commitment amount from $250.0 million to $350.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $125.0 million subject to agreement of the lenders (not to exceed a total commitment of $475.0 million). Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100 percent to 0.275 percent (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. USD loans may be made either at (i) a Secured Overnight Financing Rate (SOFR) Term Benchmark, with a zero percent floor, plus an applicable margin of 0.950 percent to 1.975 percent (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement. EUR loans may be made in Euro Interbank Offer Rate (EURIBOR) Term Benchmark, with a zero percent floor, plus an applicable margin of 0.850 percent to 1.875 percent (depending on the Company’s leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.
  (was, 2022-05-03, similarity 0.6519):
[0000038725-22-000078:note_history:17]
The Company maintains the Fourth Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement was renewed on May 13, 2021, has a maturity date of May 13, 2026, and commitment amount of $250.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $125.0 million subject to agreement of the lenders (not to exceed a total commitment of $375.0 million). Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.85% to 1.88% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

- changed (2022-08-02):
[0000038725-22-000148:note_history:18]
As of June 30, 2022, the Company had $217.7 million outstanding borrowings, $4.0 million in letters of credit outstanding, and $128.3 million of available capacity under the Credit Agreement.
  (was, 2022-05-03, similarity 0.9744):
[0000038725-22-000078:note_history:18]
As of March 31, 2022, the Company had $191.8 million outstanding borrowings, $4.0 million in letters of credit outstanding, and $54.2 million of available capacity under the Credit Agreement.

- changed (2022-08-02):
[0000038725-22-000148:note_history:19]
The Company also has lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $19.3 million. As of June 30, 2022, there were $4.0 million outstanding borrowings and $15.3 million of available capacity under these lines of credit.
  (was, 2022-05-03, similarity 0.9855):
[0000038725-22-000078:note_history:19]
The Company also has lines of credit for certain subsidiaries with various expiration dates. The aggregate maximum borrowing capacity of these overdraft lines of credits is $20.2 million. As of March 31, 2022, there were $1.8 million outstanding borrowings and $18.4 million of available capacity under these lines of credit.

- changed (2022-08-02):
[0000038725-22-000148:note_history:20]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a 
minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of June 30, 2022.
  (was, 2022-05-03, similarity 0.9962):
[0000038725-22-000078:note_history:20]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 3.50 to 1.00 and a minimum interest coverage ratio of 3.00 to 1.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of March 31, 2022.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-02):
[0000038725-22-000148:note_history:21]
| (In millions) |  | June 30, 2022 |  | December 31, 2021 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 217.7 |  |  | 96.6 |  |
| Tax increment financing debt |  | 15.9 |  |  | 16.5 |  |
| Foreign subsidiary debt |  | 4.5 |  |  | 0.5 |  |
| Other |  | — |  |  | 0.1 |  |
| Less: unamortized debt issuance costs |  | (0.2) |  |  | (0.2) |  |
|  |  | $ | 312.9 |  |  | $ | 188.5 |  |
| Less: current maturities |  | (223.1) |  |  | (98.0) |  |
| Long-term debt |  | $ | 89.8 |  |  | 90.5 |
  (was, 2022-05-03, similarity 0.9894):
[0000038725-22-000078:note_history:21]
| (In millions) |  | March 31, 2022 |  | December 31, 2021 |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 191.8 |  |  | 96.6 |  |
| Tax increment financing debt |  | 15.9 |  |  | 16.5 |  |
| Foreign subsidiary debt |  | 2.2 |  |  | 0.5 |  |
| Other |  | — |  |  | 0.1 |  |
| Less: unamortized debt issuance costs |  | (0.2) |  |  | (0.2) |  |
|  |  | $ | 284.7 |  |  | $ | 188.5 |  |
| Less: current maturities |  | (194.8) |  |  | (98.0) |  |
| Long-term debt |  | $ | 89.9 |  |  | 90.5 |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-08-02):
[0000038725-22-000148:note_history:22]
Debt outstanding, excluding unamortized debt issuance costs, at June 30, 2022 matures as follows:
  (was, 2022-05-03, similarity 0.9514):
[0000038725-22-000078:note_history:22]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2022 matures as follows:
