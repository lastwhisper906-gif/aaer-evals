# FELE MD&A — 0000038725-22-000148


## mdna

[0000038725-22-000148:mdna:1]
[same as prior period, unchanged from 0000038725-22-000078:mdna:1]

[0000038725-22-000148:mdna:2]
Second Quarter 2022 vs. Second Quarter 2021

[0000038725-22-000148:mdna:3]
[same as prior period, unchanged from 0000038725-22-000078:mdna:3]

[0000038725-22-000148:mdna:4]
Sales in the second quarter of 2022 increased from the second quarter of last year. Sales in the quarter increased by $113.8 million, or about 26 percent, due to higher sales across all three segments, achieved by price realization, acquisitions, and volume. The Company's consolidated gross profit was $189.3 million for the second quarter of 2022, an increase from the prior year’s second quarter. The gross profit as a percent of net sales was 34.3 percent in the second quarter of 2022 versus 34.8 percent during the second quarter of 2021. Diluted earnings per share in the second quarter of 2022 were up from the same period last year.

[0000038725-22-000148:mdna:5]
[same as prior period, unchanged from 0000038725-22-000078:mdna:5]

[0000038725-22-000148:mdna:6]
[same as prior period, unchanged from 0000038725-22-000078:mdna:6]

[0000038725-22-000148:mdna:7]
Net sales in the second quarter of 2022 were $551.1 million, an increase of $113.8 million or about 26 percent compared to 2021 second quarter sales of $437.3 million. Acquisition related sales were $34.4 million. Sales decreased by $19.4 million or about 4 percent in the second quarter of 2022 due to foreign currency translation. The Company’s organic sales growth, led by price realization, increased about 23 percent compared to the second quarter of 2021.

[0000038725-22-000148:mdna:8]
|  | Net Sales |
| (In millions) | Q2 2022 |  | Q2 2021 |  | 2022 v 2021 |
| Water Systems | $ | 310.5 |  |  | $ | 247.2 |  |  | $ | 63.3 |  |
| Fueling Systems | 86.0 |  |  | 72.2 |  |  | 13.8 |  |
| Distribution | 191.1 |  |  | 144.8 |  |  | 46.3 |  |
| Eliminations/Other | (36.5) |  |  | (26.9) |  |  | (9.6) |  |
| Consolidated | $ | 551.1 |  |  | $ | 437.3 |  |  | $ | 113.8 |  |

[0000038725-22-000148:mdna:9]
[same as prior period, unchanged from 0000038725-22-000078:mdna:9]

[0000038725-22-000148:mdna:10]
Water Systems sales were $310.5 million in the second quarter of 2022, an increase of $63.3 million or about 26 percent versus the second quarter of 2021 sales of $247.2 million. Acquisition related sales were $14.8 million. Water Systems sales decreased by $17.9 million or about 7 percent in the quarter due to foreign currency translation. Excluding acquisitions and foreign currency translation, Water Systems sales were up $66.4 million or about 27 percent compared to the second quarter of 2021. This revenue growth was primarily from price and volume, which was up due to strong end market demand.

[0000038725-22-000148:mdna:11]
Water Systems sales in the U.S. and Canada were up about 38 percent compared to the second quarter of 2021. The impact of foreign currency translation decreased sales by about 1 percent. In the second quarter of 2022, sales from businesses acquired since the second quarter of 2021 were $12.9 million. Organic Water Systems sales in the U.S. and Canada were 30 percent in the second quarter. Sales of groundwater pumping equipment increased by about 38 percent and sales of all surface pumping equipment increased by about 22 percent versus the first quarter 2021, due to strong end market demand and pricing.

[0000038725-22-000148:mdna:12]
Water Systems sales in markets outside the U.S. and Canada increased by 9 percent overall. The impact of foreign currency translation decreased sales by about 16 percent. In the second quarter of 2022, sales from businesses acquired since the second quarter of 2021 were $1.9 million.  Organic Water Systems sales in markets outside the U.S. and Canada, increased by 23 percent, primarily driven by higher sales in Europe, the Middle East and African (EMEA) markets.  The Company also had higher sales in the Latin American and the Asia Pacific markets.

[0000038725-22-000148:mdna:13]
[same as prior period, unchanged from 0000038725-22-000078:mdna:13]

[0000038725-22-000148:mdna:14]
Fueling Systems sales were $86.0 million in the second quarter of 2022, an increase of $13.8 million or about 19 percent versus the second quarter of 2021 sales of $72.2 million. Fueling Systems sales decreased by $1.5 million or about 2 percent in the quarter due to foreign currency translation. Fueling Systems organic sales increased by $15.3 million or about 21 percent compared to the second quarter of 2021, this revenue growth was from price and volume.

[0000038725-22-000148:mdna:15]
Fueling Systems sales in the U.S. and Canada increased by about 20 percent compared to the second quarter of 2021. The increase was due, in part, to robust demand for infrastructure buildout in the U.S.  Outside the U.S. and Canada, Fueling

[0000038725-22-000148:mdna:16]
Systems revenues decreased by about 6 percent, as sales increases of 3 percent in the rest of the world outside of China were not enough to offset lower sales in China.

[0000038725-22-000148:mdna:17]
[same as prior period, unchanged from 0000038725-22-000078:mdna:16]

[0000038725-22-000148:mdna:18]
Distribution sales were $191.1 million in the second quarter of 2022, versus the second quarter of 2021 sales of $144.8 million. In the second quarter of 2022, sales from businesses acquired since the second quarter of 2021 were $19.6 million. The Distribution segment organic sales increased 18 percent compared to the second quarter of 2021.  Revenue growth was primarily from price and was driven by broad-based demand in all regions and product categories.

[0000038725-22-000148:mdna:19]
[same as prior period, unchanged from 0000038725-22-000078:mdna:18]

[0000038725-22-000148:mdna:20]
Cost of sales as a percent of net sales for the second quarter of 2022 was 65.7 percent and 65.2 percent for the second quarter of 2021. Correspondingly, the gross profit margin was 34.3 percent and 34.8 percent for the second quarters of 2022 and 2021, respectively. The Company's consolidated gross profit was $189.3 million for the second quarter of 2022, up $37.1 million from the gross profit of $152.2 million in the second quarter of 2021. The gross profit increase was due to higher sales. In the second quarter, the gross profit margin percentage was down 50 basis points, as realized pricing actions offset inflationary cost increases; however, supply constraints caused some unfavorable manufacturing absorption variances.

[0000038725-22-000148:mdna:21]
[same as prior period, unchanged from 0000038725-22-000078:mdna:20]

[0000038725-22-000148:mdna:22]
Selling, general, and administrative (SG&A) expenses were $108.3 million in the second quarter of 2022 compared to $100.5 million in the second quarter of 2021. SG&A expenses from acquired businesses were $7.6 million and excluding the acquired entities, SG&A expenses were higher by $0.2 million versus the prior year.

[0000038725-22-000148:mdna:23]
[same as prior period, unchanged from 0000038725-22-000078:mdna:22]

[0000038725-22-000148:mdna:24]
There were no restructuring expenses for the second quarter of 2022.  Restructuring expenses for the second quarter of 2021 were $0.2 million and related to continued miscellaneous manufacturing and distribution realignment activities in the Water Systems segment.

[0000038725-22-000148:mdna:25]
[same as prior period, unchanged from 0000038725-22-000078:mdna:25]

[0000038725-22-000148:mdna:26]
Operating income was $81.0 million in the second quarter of 2022, up $29.4 million or about 57 percent from $51.6 million in the second quarter of 2021.

[0000038725-22-000148:mdna:27]
|  |  | Operating income (loss) |
| (In millions) |  | Q2 2022 |  | Q2 2021 |  | 2022 v 2021 |
| Water Systems |  | $ | 49.0 |  |  | $ | 34.6 |  |  | $ | 14.4 |  |
| Fueling Systems |  | 26.1 |  |  | 18.5 |  |  | 7.6 |  |
| Distribution |  | 23.3 |  |  | 16.0 |  |  | 7.3 |  |
| Eliminations/Other |  | (17.4) |  |  | (17.5) |  |  | 0.1 |  |
| Consolidated |  | $ | 81.0 |  |  | $ | 51.6 |  |  | $ | 29.4 |  |

[0000038725-22-000148:mdna:28]
[same as prior period, unchanged from 0000038725-22-000078:mdna:28]

[0000038725-22-000148:mdna:29]
Water Systems operating income was $49.0 million in the second quarter of 2022, up $14.4 million or about 42 percent versus the second quarter of 2021 and operating income margin was 15.8 percent, an increase of 180 basis points, compared to the 14.0 percent in the second quarter of 2021. The increase in operating income was primarily due to higher sales. Operating income margin improved due to leverage on fixed cost from higher sales, price realization and cost management.

[0000038725-22-000148:mdna:30]
[same as prior period, unchanged from 0000038725-22-000078:mdna:30]

[0000038725-22-000148:mdna:31]
Fueling Systems operating income was $26.1 million in the second quarter of 2022, up $7.6 million or about 41 percent compared to $18.5 million in the second quarter of 2021, and the second quarter operating income margin was 30.3 percent, an increase of 470 basis points from the 25.6 percent of net sales in the second quarter of 2021. The increase in operating income was primarily due to higher sales. Operating income margin improved due to leverage on fixed cost from higher sales, price realization and cost management.

[0000038725-22-000148:mdna:32]
[same as prior period, unchanged from 0000038725-22-000078:mdna:32]

[0000038725-22-000148:mdna:33]
Distribution operating income was $23.3 million in the second quarter of 2022, and the second quarter operating income margin was 12.2 percent. Distribution operating income was $16.0 million in the second quarter of 2021, and the second quarter operating income margin was 11.0 percent. The increase in operating income was primarily due to higher sales. The increase in operating income margin was related to higher revenues, primarily price realization.

[0000038725-22-000148:mdna:34]
[same as prior period, unchanged from 0000038725-22-000078:mdna:35]

[0000038725-22-000148:mdna:35]
Operating income-Eliminations/Other is composed primarily of unallocated general and administrative expenses and inter-segment sales and profit eliminations. The inter-segment profit elimination impact in the second quarter of 2022 versus the second quarter of 2021 was unfavorable by $1.8 million. General and administrative expenses were lower by $1.9 million primarily due to lower variable compensation.

[0000038725-22-000148:mdna:36]
[same as prior period, unchanged from 0000038725-22-000078:mdna:37]

[0000038725-22-000148:mdna:37]
Interest expense for the second quarter of 2022 was $2.9 million, up due to higher debt and $0.7 million from interest penalties on an indirect tax settlement in a foreign jurisdiction.  Interest expense for the second quarter of 2021 was $1.4 million.

[0000038725-22-000148:mdna:38]
[same as prior period, unchanged from 0000038725-22-000078:mdna:39]

[0000038725-22-000148:mdna:39]
Other income or expense was a loss of $1.2 million in the second quarter of 2022 and included an unfavorable indirect tax settlement in a foreign jurisdiction of about $1.0 million and a loss of $0.4 million in the second quarter of 2021.

[0000038725-22-000148:mdna:40]
[same as prior period, unchanged from 0000038725-22-000078:mdna:41]

[0000038725-22-000148:mdna:41]
Foreign currency-based transactions produced a loss for the second quarter of 2022 of $0.3 million, primarily due to the Turkish lira relative to the U.S. dollar. Foreign currency-based transactions produced a loss for the second quarter of 2021 of $1.2 million, primarily due to the Argentinian peso relative to the U.S. dollar.

[0000038725-22-000148:mdna:42]
[same as prior period, unchanged from 0000038725-22-000078:mdna:43]

[0000038725-22-000148:mdna:43]
The provision for income taxes in the second quarter of 2022 and 2021 was $16.8 million and $9.3 million, respectively. The effective tax rate for the second quarter of 2022 was about 22 percent and, before the impact of discrete events, was about 21 percent. The effective tax rate for the second quarter of 2021 was about 19 percent and, before the impact of discrete events, was about 20 percent. The increase in the effective tax rate was primarily a result of net unfavorable discrete events recorded in the second quarter of 2022, as opposed to net favorable discrete events, recorded in the second quarter of 2021, primarily related to excess tax benefits from share-based compensation. The tax rate as a percentage of pre-tax earnings for the full year 2022 is projected to be about 21 percent, compared to the full year 2021 tax rate of about 21 percent, both before discrete adjustments.

[0000038725-22-000148:mdna:44]
[same as prior period, unchanged from 0000038725-22-000078:mdna:45]

[0000038725-22-000148:mdna:45]
Net income for the second quarter of 2022 was $59.8 million compared to the prior year second quarter net income of $39.4 million. Net income attributable to Franklin Electric Co., Inc. for the second quarter of 2022 was $59.4 million, or $1.26 per diluted share, compared to the prior year second quarter net income attributable to Franklin Electric Co., Inc. of $39.1 million or $0.83 per diluted share.

[0000038725-22-000148:mdna:46]
First Half of 2022 vs. First Half of 2021

[0000038725-22-000148:mdna:47]
OVERVIEW

[0000038725-22-000148:mdna:48]
Sales in the first half of 2022 were up from the same period last year. Sales in the first half increased by $232.3 million, or about 30 percent, due to higher sales across all three segments, achieved by price realization, acquisitions, and volume. The Company's consolidated gross profit was $334.6 million for the first half of 2022, an increase of $66.8 million or about 25 percent from the first half of 2021. Diluted earnings per share in the first half of 2022 were up from the same period last year.

[0000038725-22-000148:mdna:49]
RESULTS OF OPERATIONS

[0000038725-22-000148:mdna:50]
Net Sales

[0000038725-22-000148:mdna:51]
Net sales in the first half of 2022 were $1,002.6 million, an increase of $232.3 million or about 30 percent compared to 2021 first half sales of $770.3 million. Acquisition related sales were $82.6 million. Sales decreased by $32.5 million or about 4 percent in the first half of 2022 due to foreign currency translation. The Company’s organic sales growth, led by price realization, was about 24 percent.

[0000038725-22-000148:mdna:52]
|  | Net Sales |
| (In millions) | YTD June 30, 2022 |  | YTD June 30, 2021 |  | 2022 v 2021 |
| Water Systems | $ | 583.1 |  |  | $ | 444.8 |  |  | $ | 138.3 |  |
| Fueling Systems | 158.5 |  |  | 129.0 |  |  | 29.5 |  |
| Distribution | 326.0 |  |  | 240.5 |  |  | 85.5 |  |
| Eliminations/Other | (65.0) |  |  | (44.0) |  |  | (21.0) |  |
| Consolidated | $ | 1,002.6 |  |  | $ | 770.3 |  |  | $ | 232.3 |  |

[0000038725-22-000148:mdna:53]
Net Sales-Water Systems

[0000038725-22-000148:mdna:54]
Water Systems sales were $583.1 million in the first half of 2022, an increase of $138.3 million or about 31 percent versus the first half of 2021. The incremental impact of sales from acquired businesses was $48.7 million. Foreign currency translation changes decreased sales $30.3 million or about 7 percent compared to sales in the first half of 2021. The Water Systems sales change in the first half of 2022, excluding acquisitions and foreign currency translation, was an increase of $119.9 million or about 27 percent. This revenue growth was primarily from price and volume, which was up due to strong end market demand.

[0000038725-22-000148:mdna:55]
Water Systems sales in the U.S. and Canada increased by about 48 percent compared to the first half of 2021. The incremental impact of sales from acquired businesses was $45.0 million. Sales revenue decreased by $0.8 million in the first half of 2022 due to foreign currency translation. In the first half of 2022, organic Water Systems sales in the U.S. and Canada were 30 percent. Sales of groundwater pumping equipment increased by about 40 percent and sales of all surface pumping equipment increased by about 21 percent versus the first quarter 2021, due to strong end market demand and pricing.

[0000038725-22-000148:mdna:56]
Water Systems sales in markets outside the U.S. and Canada increased by about 11 percent compared to the first half of 2021. The incremental impact of sales from acquired businesses was $3.7 million. Sales revenue decreased by $29.5 million or about 15 percent in the first half of 2022 due to foreign currency translation. Water Systems organic sales in markets outside the U.S. and Canada change in the first half of 2022, excluding foreign currency translation and acquisitions, was an increase of about 24 percent. Water Systems sales grew in all major geographic regions; EMEA, Latin America and the Asia Pacific markets, on strong end market demand and pricing.

[0000038725-22-000148:mdna:57]
Net Sales-Fueling Systems

[0000038725-22-000148:mdna:58]
Fueling Systems sales were $158.5 million in the first half of 2022, an increase of $29.5 million or about 23 percent from the first half of 2021. Foreign currency translation changes decreased sales $2.2 million or about 2 percent compared to sales in the first half of 2021. The Fueling Systems sales change in the first half of 2022, excluding foreign currency translation, was an increase of about 25 percent. Revenue growth was from price and volume.

[0000038725-22-000148:mdna:59]
Fueling Systems sales in the U.S. and Canada increased by about 26 percent during the first half. The increase was due, in part, to robust demand for infrastructure buildout in the U.S.  Outside the U.S. and Canada, Fueling Systems revenues decreased by about 2 percent, as sales increases of 4 percent in the rest of the world outside of China were not enough to offset lower sales in China.

[0000038725-22-000148:mdna:60]
Net Sales - Distribution

[0000038725-22-000148:mdna:61]
Distribution sales were $326.0 million in the first half of 2022, an increase of $85.5 million or about 36 percent, versus the first half of 2021 sales of $240.5 million. The incremental impact of sales from acquired businesses was $33.9 million. Distribution segment organic sales increased about 21 percent compared to the first half of 2021.  Revenue growth was primarily from price and was driven by broad-based demand in all regions and product categories.

[0000038725-22-000148:mdna:62]
Cost of Sales

[0000038725-22-000148:mdna:63]
Cost of sales as a percent of net sales for the first half of 2022 and 2021 was 66.6 percent and 65.2 percent, respectively. Correspondingly, the gross profit margin was 33.4 percent and 34.8 percent, respectively. The Company's consolidated gross profit was $334.6 million for the first half of 2022, up $66.8 million from the gross profit of $267.8 million in the first half of 2021. The gross profit increase was primarily due to higher sales. The decline in gross profit margin percentage is partially attributable to supply constraints causing unfavorable manufacturing absorption variances, as selling price actions offset inflationary cost increases.

[0000038725-22-000148:mdna:64]
Selling, General, and Administrative ("SG&A")

[0000038725-22-000148:mdna:65]
Selling, general, and administrative expenses were $213.0 million in the first half of 2022, and increased by $30.9 million or 17 percent in the first half of 2022 compared to $182.1 million in the first half of last year. SG&A expenses from acquired

[0000038725-22-000148:mdna:66]
businesses were $20.0 million and excluding the acquired entities, SG&A expenses were higher by $10.9 million or 6 percent versus the prior year. SG&A costs as a percent of Net Sales were below 2021.

[0000038725-22-000148:mdna:67]
Restructuring Expenses

[0000038725-22-000148:mdna:68]
Restructuring expenses for the first half of 2022 were $0.7 million. Restructuring expenses were $0.6 million in the Water Systems segment from continued miscellaneous manufacturing and distribution realignment activities and $0.1 in distribution related to branch consolidations and other asset rationalizations in the Headwater distribution segment. Restructuring expenses for the first half of 2021 were $0.3 million. Restructuring expenses were $0.2 million in the Water Systems segment from continued miscellaneous manufacturing and distribution realignment activities and $0.1 in distribution related to branch consolidations and other asset rationalizations in the Headwater distribution segment.

[0000038725-22-000148:mdna:69]
Operating Income

[0000038725-22-000148:mdna:70]
Operating income was $120.9 million in the first half of 2022, up $35.5 million or about 42 percent from $85.4 million in the first half of 2021.

[0000038725-22-000148:mdna:71]
|  |  | Operating income (loss) |
| (In millions) |  | YTD June 30, 2022 |  | YTD June 30, 2021 |  | 2022 v 2021 |
| Water Systems |  | $ | 82.2 |  |  | $ | 65.9 |  |  | $ | 16.3 |  |
| Fueling Systems |  | 43.8 |  |  | 33.4 |  |  | 10.4 |  |
| Distribution |  | 32.7 |  |  | 18.0 |  |  | 14.7 |  |
| Eliminations/Other |  | (37.8) |  |  | (31.9) |  |  | (5.9) |  |
| Consolidated |  | $ | 120.9 |  |  | $ | 85.4 |  |  | $ | 35.5 |  |

[0000038725-22-000148:mdna:72]
Operating Income-Water Systems

[0000038725-22-000148:mdna:73]
Water Systems operating income was $82.2 million in the first half of 2022 compared to $65.9 million in the first half of 2021, an increase of about 25 percent. The first half operating income margin was 14.1 percent and decreased by 70 basis points compared to the first half of 2021. Operating income margin decreased in Water Systems primarily because supply constraints caused unfavorable absorption variances, as selling price actions offset inflationary cost increases.

[0000038725-22-000148:mdna:74]
Operating Income-Fueling Systems

[0000038725-22-000148:mdna:75]
Fueling Systems operating income was $43.8 million in the first half of 2022 compared to $33.4 million in the first half of 2021. The first half operating income margin was 27.6 percent compared to 25.9 percent of net sales in the first half of 2021, an increase of 170 basis points. The increase in operating income was primarily due to higher sales. Operating income margin increased in Fueling Systems primarily due to leverage on fixed cost from higher sales, price realization and cost management.

[0000038725-22-000148:mdna:76]
Operating Income-Distribution

[0000038725-22-000148:mdna:77]
Distribution operating income was $32.7 million in the first half of 2022 and operating income margin was 10.0 percent. Distribution operating income was $18.0 million in the first half of 2021 and operating income margin was 7.5 percent. The increase in operating income and margin is related to higher revenues, primarily price realization.

[0000038725-22-000148:mdna:78]
Operating Income-Eliminations/Other

[0000038725-22-000148:mdna:79]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses. The inter-segment profit elimination impact in the first half of 2022 versus the first half of 2021 was $4.9 million. General and administrative expenses were higher by $1.0 million or about 3 percent to last year in the first half.

[0000038725-22-000148:mdna:80]
Interest Expense

[0000038725-22-000148:mdna:81]
Interest expense for the first half of 2022 was $4.4 million, up due to higher debt and included a $0.7 million from interest penalties on an indirect tax settlement in a foreign jurisdiction. Interest expense for the first half of 2021 was $2.5 million.

[0000038725-22-000148:mdna:82]
Other Income or Expense

[0000038725-22-000148:mdna:83]
Other income or expense was a loss of $1.5 million in the first half of 2022 and included an unfavorable indirect tax settlement in a foreign jurisdiction of about $1.0 million. Other income or expense was a loss of $0.5 million in the first half of 2021.

[0000038725-22-000148:mdna:84]
Foreign Exchange

[0000038725-22-000148:mdna:85]
Foreign currency-based transactions for the first half of 2022 was a loss $0.9 million, primarily due to the Argentinian peso relative to the U.S. dollar. Foreign currency-based transactions for the first half of 2021 was a loss $1.2 million, primarily due to the Argentinian peso relative to the U.S. dollar.

[0000038725-22-000148:mdna:86]
Income Taxes

[0000038725-22-000148:mdna:87]
The provision for income taxes in the first half of 2022 and 2021 was $24.2 million and $13.6 million, respectively. The effective tax rate for the first half of 2022 before and after the impact of discrete events was about 21 percent. The effective tax rate in the first half of 2021 was about 17 percent and, before the impact of discrete events, was about 20 percent. The increase in the effective tax rate was primarily a result of net unfavorable discrete events recorded in the first half of 2022 compared to net favorable discrete events in the first half of 2021, primarily related to excess tax benefits from share-based compensation. The tax rate as a percentage of pre-tax earnings for the full year 2022 is projected to be about 21 percent, compared to the full year 2021 tax rate of about 21 percent, both before discrete adjustments.

[0000038725-22-000148:mdna:88]
Net Income

[0000038725-22-000148:mdna:89]
Net income for the first half of 2022 was $89.9 million compared to 2021 first half net income of $67.5 million. Net income attributable to Franklin Electric Co., Inc. for the first half of 2022 was $89.1 million, or $1.89 per diluted share, compared to 2021 first half net income attributable to Franklin Electric Co., Inc. of $67.0 million or $1.42 per diluted share.

[0000038725-22-000148:mdna:90]
[same as prior period, unchanged from 0000038725-22-000078:mdna:47]

[0000038725-22-000148:mdna:91]
[same as prior period, unchanged from 0000038725-22-000078:mdna:48]

[0000038725-22-000148:mdna:92]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available. The Company believes its capital resources and liquidity position at June 30, 2022 is adequate to meet projected needs for the foreseeable future. The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-22-000148:mdna:93]
As of June 30, 2022 the Company had a $350.0 million revolving credit facility. The facility is scheduled to mature on May 13, 2026. As of June 30, 2022, the Company had $128.3 million borrowing capacity under the Credit Agreement as $4.0 million in letters of commercial and standby letters of credit were outstanding and undrawn and $217.7 million in revolver borrowings were drawn and outstanding, which were primarily used for funding working capital requirements.

[0000038725-22-000148:mdna:94]
In addition, the Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement") with a remaining borrowing capacity of  $125.0 million as of June 30, 2022. The Company also has other long-term debt borrowings outstanding as of June 30, 2022. See Note 10 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-22-000148:mdna:95]
At June 30, 2022, the Company had $28.5 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations. There is currently no need or intent to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-22-000148:mdna:96]
[same as prior period, unchanged from 0000038725-22-000078:mdna:53]

[0000038725-22-000148:mdna:97]
The following table summarizes significant sources and uses of cash and cash equivalents for the first six months of 2022 and 2021.

[0000038725-22-000148:mdna:98]
| (in millions) |  | 2022 |  | 2021 |
| Net cash flows from operating activities |  | $ | (62.5) |  |  | $ | 35.5 |  |
| Net cash flows from investing activities |  | (21.5) |  |  | (193.7) |  |
| Net cash flows from financing activities |  | 79.3 |  |  | 110.7 |  |
| Impact of exchange rates on cash and cash equivalents |  | (2.6) |  |  | (1.7) |  |
| Change in cash and cash equivalents |  | $ | (7.3) |  |  | $ | (49.2) |  |

[0000038725-22-000148:mdna:99]
[same as prior period, unchanged from 0000038725-22-000078:mdna:56]

[0000038725-22-000148:mdna:100]
[same as prior period, unchanged from 0000038725-22-000078:mdna:57]

[0000038725-22-000148:mdna:101]
Net cash used by operating activities was $62.5 million for the six months ended June 30, 2022 compared to $35.5 million provided by operating activities for the six months ended June 30, 2021. The increase in cash used by operating activities was primarily due to increased working capital requirements in support of supply chain resiliency and meeting the strong demand from our customers.

[0000038725-22-000148:mdna:102]
[same as prior period, unchanged from 0000038725-22-000078:mdna:59]

[0000038725-22-000148:mdna:103]
[same as prior period, unchanged from 0000038725-22-000078:mdna:60]

[0000038725-22-000148:mdna:104]
Net cash used in investing activities was $21.5 million for the six months ended June 30, 2022 compared to $193.7 million used in investing activities for the six months ended June 30, 2021. The decrease in cash used in investing activities was attributable to decreased acquisition activity in 2022.

[0000038725-22-000148:mdna:105]
[same as prior period, unchanged from 0000038725-22-000078:mdna:62]

[0000038725-22-000148:mdna:106]
[same as prior period, unchanged from 0000038725-22-000078:mdna:63]

[0000038725-22-000148:mdna:107]
Net cash provided by financing activities was $79.3 million for the six months ended June 30, 2022 compared to $110.7 million provided by financing activities for the six months ended June 30, 2021. The decrease in cash provided by financing activities was attributable to increased common stock repurchases slightly offset by decreased proceeds from debt and common stock issuances.

[0000038725-22-000148:mdna:108]
[same as prior period, unchanged from 0000038725-22-000078:mdna:65]
