# FELE 8-K — 0000038725-20-000168 filed 2020-07-28

## item codes, every 8-K on or before 2020-08-04

- 2020-07-28 0000038725-20-000168 — 2.02, 9.01
- 2020-06-25 0000038725-20-000164 — 8.01, 9.01
- 2020-06-25 0000038725-20-000163 — 8.01, 9.01
- 2020-05-11 0000038725-20-000133 — 5.02, 9.01
- 2020-05-08 0000038725-20-000119 — 5.07
- 2020-05-06 0000038725-20-000111 — 5.02, 9.01
- 2020-04-28 0000038725-20-000104 — 2.02, 9.01
- 2020-02-18 0000038725-20-000018 — 2.02, 9.01
- 2020-01-30 0000038725-20-000009 — 5.02, 5.03, 9.01
- 2019-11-04 0000038725-19-000234 — 7.01, 9.01
- 2019-10-29 0000038725-19-000221 — 2.02, 9.01
- 2019-08-01 0000038725-19-000193 — 7.01, 9.01
- 2019-07-23 0000038725-19-000178 — 2.02, 9.01
- 2019-05-07 0000038725-19-000140 — 5.03, 9.01
- 2019-05-03 0000038725-19-000124 — 5.07
- 2019-05-03 0000038725-19-000122 — 7.01, 9.01
- 2019-04-23 0000038725-19-000100 — 2.02, 9.01
- 2019-02-19 0000038725-19-000008 — 2.02, 9.01
- 2019-01-07 0000038725-19-000004 — 5.02
- 2019-01-02 0000038725-19-000002 — 7.01, 9.01
- 2018-11-06 0000038725-18-000193 — 7.01, 9.01
- 2018-10-26 0000038725-18-000186 — 2.02, 9.01
- 2018-10-01 0000038725-18-000184 — 1.01, 2.03, 9.01
- 2018-07-24 0000038725-18-000145 — 2.02, 9.01
- 2018-07-03 0000038725-18-000143 — 7.01, 9.01
- 2018-07-02 0000038725-18-000141 — 7.01, 9.01
- 2018-05-07 0000038725-18-000090 — 5.07
- 2018-05-04 0000038725-18-000088 — 7.01, 9.01
- 2018-05-01 0000038725-18-000085 — 2.02, 9.01
- 2018-04-03 0000038725-18-000067 — 7.01, 9.01
- 2018-02-20 0000038725-18-000020 — 2.02, 9.01
- 2018-01-03 0000038725-18-000002 — 7.01, 9.01
- 2017-11-07 0000038725-17-000173 — 7.01, 9.01
- 2017-10-24 0000038725-17-000163 — 2.02, 9.01
- 2017-07-25 0000038725-17-000141 — 2.02, 9.01
- 2017-05-31 0000038725-17-000133 — 7.01, 9.01
- 2017-05-09 0000038725-17-000113 — 5.02, 9.01
- 2017-05-09 0000038725-17-000111 — 5.07
- 2017-05-05 0000038725-17-000095 — 7.01, 9.01
- 2017-04-27 0000038725-17-000086 — 2.02, 9.01
- 2017-04-10 0000038725-17-000070 — 7.01, 9.01
- 2017-02-21 0000038725-17-000019 — 2.02, 9.01
- 2016-12-21 0000038725-16-000469 — 5.03, 9.01
- 2016-11-08 0000038725-16-000441 — 7.01, 9.01
- 2016-10-25 0000038725-16-000429 — 2.02, 9.01
- 2016-09-12 0000038725-16-000417 — 7.01, 9.01
- 2016-07-26 0000038725-16-000381 — 2.02, 9.01
- 2016-06-01 0000038725-16-000370 — 7.01, 9.01
- 2016-05-11 0000038725-16-000349 — 5.07
- 2016-05-06 0000038725-16-000313 — 7.01, 9.01
- 2016-05-02 0000038725-16-000308 — 2.02, 9.01
- 2016-03-01 0000038725-16-000273 — 5.02, 5.03, 9.01
- 2016-02-23 0000038725-16-000253 — 2.02, 9.01
- 2015-11-09 0000038725-15-000204 — 7.01, 9.01
- 2015-10-27 0000038725-15-000190 — 2.02, 9.01
- 2015-09-02 0000038725-15-000181 — 5.02, 5.03, 9.01
- 2015-08-03 0000038725-15-000156 — 8.01, 9.01
- 2015-07-28 0000038725-15-000154 — 2.02, 9.01
- 2015-07-10 0000038725-15-000151 — 2.02, 9.01
- 2015-06-02 0000038725-15-000145 — 1.01, 2.03, 9.01
- 2015-05-27 0000038725-15-000123 — 7.01, 9.01
- 2015-05-13 0000038725-15-000117 — 5.03, 9.01
- 2015-05-11 0000038725-15-000099 — 5.07
- 2015-05-08 0000038725-15-000097 — 7.01, 9.01
- 2015-05-08 0000038725-15-000096 — 7.01, 9.01
- 2015-04-28 0000038725-15-000087 — 2.02, 9.01
- 2015-04-20 0000038725-15-000084 — 1.01, 5.02, 9.01
- 2015-02-24 0000038725-15-000024 — 2.02, 9.01
- 2015-01-16 0000038725-15-000008 — 5.03, 9.01
- 2014-12-03 0000038725-14-000232 — 2.05, 9.01 — amendment, the index does not say of what
- 2014-11-17 0000038725-14-000212 — 5.02, 5.03, 9.01
- 2014-11-10 0000038725-14-000205 — 7.01, 9.01
- 2014-10-29 0000038725-14-000189 — 2.02, 9.01
- 2014-08-04 0000038725-14-000160 — 7.01, 9.01
- 2014-07-28 0000038725-14-000158 — 2.02, 9.01
- 2014-07-01 0000038725-14-000156 — 2.05, 9.01
- 2014-06-09 0000038725-14-000149 — 7.01, 9.01
- 2014-05-28 0000038725-14-000124 — 7.01, 9.01
- 2014-05-07 0000038725-14-000093 — 5.02, 5.03, 5.07, 9.01
- 2014-05-06 0000038725-14-000089 — 5.02, 9.01 — amendment of 0000038725-14-000093
- 2014-05-02 0000038725-14-000087 — 7.01, 9.01
- 2014-04-29 0000038725-14-000080 — 2.02, 9.01
- 2014-02-19 0000038725-14-000013 — 5.02, 9.01
- 2014-02-19 0000038725-14-000012 — 2.02, 9.01
- 2013-11-05 0000038725-13-000226 — 7.01, 9.01
- 2013-10-30 0000038725-13-000220 — 2.02, 9.01
- 2013-09-04 0000038725-13-000199 — 7.01, 9.01
- 2013-07-30 0000038725-13-000166 — 2.02, 9.01
- 2013-05-29 0000038725-13-000138 — 7.01, 9.01
- 2013-05-07 0000038725-13-000122 — 5.02, 9.01
- 2013-05-06 0000038725-13-000095 — 5.07
- 2013-05-03 0000038725-13-000093 — 7.01, 9.01
- 2013-05-03 0000038725-13-000092 — 7.01, 9.01
- 2013-04-30 0000038725-13-000089 — 2.02, 9.01
- 2013-03-19 0000038725-13-000083 — 7.01, 9.01
- 2013-03-12 0000038725-13-000074 — 5.02, 9.01
- 2013-02-22 0000038725-13-000022 — 8.01, 9.01
- 2013-02-20 0000038725-13-000018 — 2.02, 9.01
- 2013-01-02 0000038725-13-000002 — 1.01, 2.03, 9.01
- 2012-11-16 0000038725-12-000166 — 7.01, 9.01
- 2012-11-07 0000038725-12-000153 — 7.01, 9.01
- 2012-11-05 0000038725-12-000150 — 2.02, 9.01
- 2012-08-10 0000038725-12-000133 — 7.01, 9.01
- 2012-07-31 0000038725-12-000121 — 2.02, 9.01
- 2012-06-04 0000038725-12-000102 — 5.02
- 2012-05-30 0000038725-12-000097 — 7.01, 9.01
- 2012-05-09 0000038725-12-000089 — 5.07
- 2012-05-04 0000038725-12-000068 — 5.02, 9.01
- 2012-05-04 0000038725-12-000064 — 7.01, 9.01
- 2012-05-04 0000038725-12-000063 — 7.01, 9.01
- 2012-05-02 0000038725-12-000052 — 2.02, 9.01
- 2012-03-07 0000038725-12-000036 — 7.01, 9.01
- 2012-03-01 0000038725-12-000027 — 5.02
- 2012-02-21 0000038725-12-000015 — 2.02, 9.01
- 2011-12-15 0000038725-11-000123 — 2.03, 9.01
- 2011-12-15 0000038725-11-000121 — 1.01, 2.03, 9.01
- 2011-12-05 0000038725-11-000119 — 5.02, 9.01
- 2011-11-09 0001104659-11-062571 — 7.01, 9.01
- 2011-11-02 0000038725-11-000100 — 2.02, 9.01
- 2011-10-11 0000038725-11-000096 — 1.01, 9.01
- 2011-08-03 0000038725-11-000081 — 2.02
- 2011-06-20 0000038725-11-000073 — 2.05, 9.01
- 2011-06-01 0000038725-11-000070 — 7.01, 9.01
- 2011-05-10 0000038725-11-000049 — 5.07
- 2011-05-10 0000038725-11-000048 — 5.07
- 2011-05-06 0000038725-11-000046 — 2.02, 9.01 — amendment, the index does not say of what
- 2011-05-06 0000038725-11-000044 — 7.01
- 2011-05-06 0000038725-11-000042 — 7.01, 9.01
- 2011-05-04 0000038725-11-000040 — 2.02, 9.01
- 2011-02-28 0000038725-11-000009 — 2.02, 9.01 — amendment of 0000038725-11-000007
- 2011-02-28 0000038725-11-000007 — 2.05, 9.01
- 2010-11-09 0000038725-10-000104 — 7.01, 9.01
- 2010-11-01 0000038725-10-000096 — 2.02, 9.01
- 2010-08-02 0000038725-10-000078 — 2.02, 9.01
- 2010-07-27 0000038725-10-000073 — 5.02, 9.01
- 2010-06-30 0000038725-10-000071 — 5.02
- 2010-06-01 0000038725-10-000061 — 7.01, 9.01
- 2010-05-04 0000038725-10-000050 — 5.02, 5.07, 9.01
- 2010-04-30 0000038725-10-000042 — 7.01
- 2010-04-29 0000038725-10-000040 — 7.01, 9.01
- 2010-04-29 0000038725-10-000038 — 2.02, 9.01 — amendment, the index does not say of what
- 2010-04-29 0000038725-10-000036 — 2.02, 9.01
- 2010-02-17 0000038725-10-000007 — 2.02, 9.01
- 2010-02-12 0000038725-10-000005 — 2.05
- 2009-11-10 0000038725-09-000098 — 7.01, 9.01
- 2009-10-26 0000038725-09-000094 — 2.02, 9.01
- 2009-09-24 0000038725-09-000091 — 7.01, 9.01
- 2009-07-27 0000038725-09-000071 — 2.02, 9.01
- 2009-06-02 0000038725-09-000065 — 7.01, 9.01
- 2009-04-27 0000038725-09-000043 — 1.01, 9.01
- 2009-04-24 0000038725-09-000041 — 7.01, 9.01
- 2009-04-23 0000038725-09-000039 — 2.02, 9.01
- 2009-03-10 0000038725-09-000026 — 5.02
- 2009-03-02 0000038725-09-000010 — 2.02, 9.01
- 2008-12-17 0000038725-08-000100 — 5.02, 9.01
- 2008-12-10 0000038725-08-000096 — 2.05, 9.01
- 2008-11-12 0000038725-08-000089 — 7.01, 9.01
- 2008-10-28 0000038725-08-000083 — 7.01, 9.01
- 2008-10-27 0000038725-08-000081 — 2.02, 9.01
- 2008-08-07 0000038725-08-000060 — 7.01, 9.01
- 2008-07-29 0000038725-08-000056 — 5.03, 9.01
- 2008-07-28 0000038725-08-000054 — 2.02, 9.01
- 2008-06-05 0000038725-08-000048 — 7.01, 9.01
- 2008-05-02 0000038725-08-000034 — 7.01, 9.01
- 2008-04-28 0000038725-08-000029 — 2.02, 9.01
- 2008-04-07 0000038725-08-000026 — 5.02, 9.01
- 2008-02-25 0000038725-08-000011 — 2.02, 9.01
- 2008-01-16 0000038725-08-000001 — 5.02, 9.01
- 2007-12-20 0000038725-07-000096 — 5.03, 9.01
- 2007-11-07 0000038725-07-000089 — 7.01, 9.01
- 2007-10-29 0000038725-07-000085 — 2.02, 9.01
- 2007-09-11 0000038725-07-000081 — 1.01, 2.03
- 2007-07-30 0000038725-07-000069 — 2.02, 9.01
- 2007-07-16 0000038725-07-000060 — 1.01, 3.03, 9.01
- 2007-06-12 0000038725-07-000055 — 7.01, 9.01
- 2007-05-03 0000038725-07-000046 — 1.01, 2.03, 5.03
- 2007-04-27 0000038725-07-000039 — 2.02, 9.01
- 2007-04-11 0000895813-07-000043 — 5.02
- 2007-02-06 0000038725-07-000003 — 2.02, 9.01
- 2006-12-21 0000038725-06-000088 — 1.01, 2.04, 9.01
- 2006-11-13 0000038725-06-000081 — 1.01, 9.01
- 2006-11-08 0000038725-06-000076 — 7.01, 9.01
- 2006-10-26 0000038725-06-000072 — 2.02, 9.01
- 2006-09-20 0000038725-06-000069 — 1.01, 2.01
- 2006-07-31 0000038725-06-000059 — 9.01 — amendment of 0000038725-06-000027
- 2006-07-20 0000038725-06-000055 — 2.02, 9.01
- 2006-04-26 0000038725-06-000027 — 2.01, 9.01
- 2006-04-19 0000038725-06-000023 — 2.02, 9.01
- 2006-03-21 0000038725-06-000021 — 1.01, 9.01
- 2006-01-31 0000038725-06-000003 — 2.02, 9.01
- 2005-10-25 0000038725-05-000106 — 5.02
- 2005-10-17 0000038725-05-000104 — 2.02, 9.01
- 2005-09-26 0000038725-05-000102 — 8.01, 9.01
- 2005-08-02 0000038725-05-000091 — 1.01, 9.01
- 2005-07-27 0000038725-05-000082 — 1.01, 5.02, 9.01
- 2005-07-15 0000038725-05-000076 — 2.02, 9.01
- 2005-06-29 0000038725-05-000074 — 5.02, 9.01
- 2005-05-05 0000038725-05-000057 — 5.02, 9.01
- 2005-04-18 0000038725-05-000048 — 2.02, 9.01
- 2005-03-07 0000038725-05-000043 — 1.01, 9.01
- 2005-02-16 0000038725-05-000032 — 8.01
- 2005-01-31 0000038725-05-000002 — 2.02, 9.01
- 2004-12-30 0000038725-04-000093 — 8.01, 9.01
- 2004-10-18 0000038725-04-000084 — 2.02, 9.01
- 2004-09-15 0000038725-04-000082 — 1.01, 2.03
- 2004-08-27 0000038725-04-000080 — 8.01, 9.01
- 2004-07-16 0000038725-04-000073 — 12, 7
- 2004-05-11 0000038725-04-000064 — 5
- 2004-04-16 0000038725-04-000046 — 7, 9
- 2004-02-02 0000038725-04-000005 — 7, 9
- 2004-01-14 0000038725-04-000002 — 5
- 2003-10-14 0000038725-03-000098 — 7, 9
- 2003-07-16 0000038725-03-000083 — 7, 9
- 2003-04-15 0000038725-03-000036 — 7, 9
- 2003-02-03 0000038725-03-000004 — 5
- 2002-02-26 0000038725-02-000005 — 5
- 2000-09-13 0000038725-00-000015 — 1
- 1999-10-19 0000895813-99-000387 — 5, 7
- 1999-09-16 0000038725-99-000025 — 1
- 1999-01-06 0000038725-99-000003 — 5
- 1998-10-09 0000038725-98-000017 — 5, 7
- 1998-09-28 0000038725-98-000015 — 5
- 1998-09-10 0000038725-98-000013 — 5
- 1997-11-13 0000038725-97-000025 — 5
- 1997-11-10 0000038725-97-000023 — 2, 7
- 1997-01-29 0000038725-97-000003 — 5
- 1995-03-27 0000038725-95-000005 — 7 — amendment, the index does not say of what

## late-filing notifications on or before 2020-08-04

- none on or before 2020-08-04

## item 2.02 — earnings release, exhibit 99.1

[0000038725-20-000168:8k_2_02:1]
EX-99.1
2
a202007288-kexhibit991.htm
EX-99.1

[0000038725-20-000168:8k_2_02:2]
Document

[0000038725-20-000168:8k_2_02:3]
Exhibit 99.1

[0000038725-20-000168:8k_2_02:4]
For Immediate Release

[0000038725-20-000168:8k_2_02:5]
For Further Information

[0000038725-20-000168:8k_2_02:6]
Refer to:  John J. Haines

[0000038725-20-000168:8k_2_02:7]
260-824-2900

[0000038725-20-000168:8k_2_02:8]
FRANKLIN ELECTRIC REPORTS SECOND

[0000038725-20-000168:8k_2_02:9]
QUARTER 2020 SALES AND EARNINGS

[0000038725-20-000168:8k_2_02:10]
Fort Wayne, IN – July 28, 2020 - Franklin Electric Co., Inc. (NASDAQ: FELE) reported second quarter 2020 GAAP fully diluted earnings per share (EPS) of $0.52, versus a GAAP fully diluted EPS in the second quarter 2019 of $0.70.  Second quarter 2020 sales were $308.3 million, compared to 2019 second quarter sales of $355.3 million.  Second quarter EPS before the impact of restructuring expenses was $0.54 compared to 2019 second quarter EPS before restructuring of $0.70 (see table below for a reconciliation of GAAP EPS to EPS before restructuring).

[0000038725-20-000168:8k_2_02:11]
Gregg Sengstack, Franklin Electric’s Chairman and Chief Executive Officer, commented:

[0000038725-20-000168:8k_2_02:12]
“Although our second quarter results were impacted negatively by the effects of the Global Pandemic, they exceeded our revised expectations.  Our Water and Distribution businesses both turned in solid results given the environment we were operating in and demonstrate the less cyclical nature of both segments.  Versus the 2019 second quarter, Distribution revenues grew by 6 percent and earnings grew by over 40 percent.  Water Systems revenues were down in total by 13 percent, but earnings were only down 4 percent versus last year, in part due to cost reductions we have implemented.  Excluding the U.S., South Africa and India, the Water Systems team posted 9 percent organic growth during the quarter.  The Water and Distribution segments both demonstrated sequential improvements as we progressed through the second quarter.  The Fueling Systems segment was negatively impacted by a reduction in the global demand for new filling stations.  Our year to date free cash flow as a percent of net income was 106 percent compared to a negative 13 percent at the end of the second quarter 2019 and our liquidity and balance sheet positions remain very strong.”

[0000038725-20-000168:8k_2_02:13]
Key Performance Indicators:

[0000038725-20-000168:8k_2_02:14]
| Earnings Before and After Restructuring |  | For the Second Quarter |  |  |  |  |  |  |
| (in millions) |  | 2020 | 2019 | Change |  |  |  |  |
| Net Income attributable to FE Co., Inc. Reported |  | $ | 24.7 |  | $ | 32.7 |  | (24) | % |  |  |  |  |
| Allocated Earnings |  | $ | (0.2) |  | $ | (0.2) |  |  |  |  |  |  |
| Earnings for EPS Calculations |  | $ | 24.5 |  | $ | 32.5 |  | (25) | % |  |  |  |  |
| Restructuring (before tax): |  | $ | 0.9 |  | $ | 0.2 |  |  |  |  |  |  |
| Restructuring, net of tax: |  | $ | 0.7 |  | $ | 0.2 |  |  |  |  |  |  |
| Earnings Before Restructuring |  | $ | 25.2 |  | $ | 32.7 |  | (23) | % |  |  |  |  |
| Earnings Per Share |  | For the Second Quarter |  |  |  |  |  |  |
| Before and After Restructuring |  | 2020 | 2019 | Change |  |  |  |  |
| (in millions except Earnings Per Share) |  |  |  |  |  |  |  |  |
| Average Fully Diluted Shares Outstanding |  | 46.5 |  | 46.7 |  | — | % |  |  |  |  |
| Fully Diluted Earnings Per Share (“EPS”) Reported |  | $ | 0.52 |  | $ | 0.70 |  | (26) | % |  |  |  |  |
| Restructuring Per Share, net of tax |  | $ | 0.02 |  | $ | — |  |  |  |  |  |  |
| Fully Diluted EPS Before Restructuring |  | $ | 0.54 |  | $ | 0.70 |  | (23) | % |  |  |  |  |

[0000038725-20-000168:8k_2_02:15]
|  | Net Sales |  |  |  |  |  |  |  |  |
| (in millions) | United States & Canada | Latin America | Europe, Middle East & Africa | Asia Pacific | Total Water | Fueling | Distribution | Other/Elims | Consolidated |
| Q2 2019 | $ | 117.9 |  | $ | 29.4 |  | $ | 39.0 |  | $ | 18.7 |  | $ | 205.0 |  | $ | 78.0 |  | $ | 87.1 |  | $ | (14.8) |  | $ | 355.3 |  |
| Q2 2020 | $ | 99.0 |  | $ | 24.2 |  | $ | 35.5 |  | $ | 19.7 |  | $ | 178.4 |  | $ | 56.0 |  | $ | 92.1 |  | $ | (18.2) |  | $ | 308.3 |  |
| Change | $ | (18.9) |  | $ | (5.2) |  | $ | (3.5) |  | $ | 1.0 |  | $ | (26.6) |  | $ | (22.0) |  | $ | 5.0 |  | $ | (3.4) |  | $ | (47.0) |  |
| % Change | (16) | % | (18) | % | (9) | % | 5 | % | (13) | % | (28) | % | 6 | % |  | (13) | % |
| Foreign currency translation | $ | (0.8) |  | $ | (7.2) |  | $ | (3.1) |  | $ | (0.5) |  | $ | (11.6) |  | $ | (0.6) |  | $ | — |  |  |  |
| % Change | (1) | % | (24) | % | (8) | % | (3) | % | (6) | % | (1) | % | — | % |  |  |
| Acquisitions | $ | 3.3 |  | $ | — |  | $ | — |  | $ | — |  | $ | 3.3 |  | $ | — |  | $ | — |  |  |  |
| Volume/Price | $ | (21.4) |  | $ | 2.0 |  | $ | (0.4) |  | $ | 1.5 |  | $ | (18.3) |  | $ | (21.4) |  | $ | 5.0 |  |  |  |
| % Change | (18) | % | 7 | % | (1) | % | 8 | % | (9) | % | (27) | % | 6 | % |  |  |

[0000038725-20-000168:8k_2_02:16]
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Second Quarter 2020 |  |  |  |  |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 28.7 |  | $ | 13.5 |  | $ | 6.8 |  | $ | (15.1) |  | $ | 33.9 |  |
| % Operating Income To Net Sales | 16.1 | % | 24.1 | % | 7.4 | % |  | 11.0 | % |
| Restructuring | $ | 0.9 |  | $ | — |  | $ | — |  | $ | — |  | $ | 0.9 |  |
| Operating Income/(Loss) Before Restructuring | $ | 29.6 |  | $ | 13.5 |  | $ | 6.8 |  | $ | (15.1) |  | $ | 34.8 |  |
| % Operating Income to Net Sales Before Restructuring | 16.6 | % | 24.1 | % | 7.4 | % |  | 11.3 | % |
| Operating Income and Margins |  |  |  |  |  |
| (in millions) | For the Second Quarter 2019 |  |  |  |  |
|  | Water | Fueling | Distribution | Other/Elims | Consolidated |
| Operating Income/(Loss) | $ | 30.9 |  | $ | 21.7 |  | $ | 4.5 |  | $ | (13.4) |  | $ | 43.7 |  |
| % Operating Income To Net Sales | 15.1 | % | 27.8 | % | 5.2 | % |  | 12.3 | % |
| Restructuring | $ | — |  | $ | — |  | $ | 0.2 |  |  | $ | 0.2 |  |
| Operating Income/(Loss) Before Restructuring | $ | 30.9 |  | $ | 21.7 |  | $ | 4.7 |  | $ | (13.4) |  | $ | 43.9 |  |
| % Operating Income to Net Sales Before Restructuring | 15.1 | % | 27.8 | % | 5.4 | % |  | 12.4 | % |

[0000038725-20-000168:8k_2_02:17]
Water Systems

[0000038725-20-000168:8k_2_02:18]
Water Systems sales in the U.S. and Canada decreased by 16 percent overall compared to the second quarter 2019, primarily due to lower sales of dewatering equipment.  Sales of dewatering equipment decreased by nearly 70 percent due to lower sales in rental channels and substantial uncertainty in oil production end markets. Sales of groundwater pumping equipment increased by 5 percent versus the second quarter 2019.  Sales of surface pumping equipment decreased by 18 percent on lower sales of both wastewater and water transfer systems as customers in this channel began to feel the impact of the Global Pandemic and lowered their own inventory levels.

[0000038725-20-000168:8k_2_02:19]
Water Systems sales in markets outside the U.S. and Canada decreased by 9 percent overall.  Foreign currency translation decreased sales by 12 percent.  Outside the U.S. and Canada, Water Systems organic sales increased by 3 percent, primarily driven by higher sales in Latin America and Asia Pacific, as well as increased sales in both Europe and the Middle East, offset by lower sales in the Africa markets.

[0000038725-20-000168:8k_2_02:20]
Water Systems operating income was $28.7 million in the second quarter 2020, compared to $30.9 million in the second quarter 2019 primarily driven by lower revenues.

[0000038725-20-000168:8k_2_02:21]
Fueling Systems

[0000038725-20-000168:8k_2_02:22]
Fueling Systems sales in the U.S. and Canada decreased by 22 percent compared to the second quarter 2019.  The decrease was in all product lines and due to declining demand for new filling stations.  Outside the U.S. and Canada, Fueling Systems revenues declined by 35 percent, driven by lower sales in Asia Pacific, primarily China.

[0000038725-20-000168:8k_2_02:23]
Fueling Systems operating income was $13.5 million in the second quarter of 2020, compared to $21.7 million in the second quarter of 2019 driven almost entirely by lower revenues.

[0000038725-20-000168:8k_2_02:24]
Distribution

[0000038725-20-000168:8k_2_02:25]
Distribution sales were a record at $92.1 million in the second quarter 2020, versus second quarter 2019 sales of $87.1 million.  The Distribution segment organic sales increased 6 percent compared to the second quarter of 2019.  More favorable weather conditions versus the second quarter last year contributed to the revenue growth.

[0000038725-20-000168:8k_2_02:26]
The Distribution segment operating income was $6.8 million in the second quarter of 2020, compared to $4.5 million in the second quarter of 2019, primarily due to higher revenues.

[0000038725-20-000168:8k_2_02:27]
Overall

[0000038725-20-000168:8k_2_02:28]
The Company’s consolidated gross profit was $107.1 million for the second quarter of 2020, a decrease from the second quarter of 2019 gross profit of $119.7 million.  The gross profit as a percentage of net sales was 34.7 percent in the second quarter of 2020 versus 33.7 percent in the second quarter of 2019 and improved primarily due to better price realization and product sales mix.

[0000038725-20-000168:8k_2_02:29]
Selling, general, and administrative (SG&A) expenses were $72.3 million in the second quarter of 2020 compared to $75.8 million in the second quarter of 2019. SG&A expenses were lower versus the prior year due to companywide efforts to lower spending in response to the impacts of the Global Pandemic and in part because of foreign currency translation.

[0000038725-20-000168:8k_2_02:30]
Liquidity

[0000038725-20-000168:8k_2_02:31]
The Company ended the second quarter of 2020 with a cash balance of $43.1 million and generated $37.6 million of free cash flow from operations during the first six months of 2020, versus a negative free cash flow in the first six months of 2019 of $(5.4) million and had total incremental borrowing capacity of $480 million at June 30, 2020.  Free Cash Flow is Net Cash Flows from Operating Activities, less net additions to property, plant, and equipment.

[0000038725-20-000168:8k_2_02:32]
Effects of the Global Pandemic

[0000038725-20-000168:8k_2_02:33]
The top priority of the Company is the health and welfare of its employees and partners around the world.  In response to the health risks posed by the Global Pandemic, the Company implemented and has been following the recommended hygiene and social distancing practices promulgated by the United States Centers for Disease Control and the World Health Organization.

[0000038725-20-000168:8k_2_02:34]
The Company’s products and services are generally viewed as essential in most jurisdictions in which the Company operates.  Effectively, all the Company’s global manufacturing and distribution operations are operating.

[0000038725-20-000168:8k_2_02:35]
The primary impacts of the Global Pandemic on the Company’s end markets continue to be a reduction of large dewatering equipment sales in the Water Systems segment; Water Systems customers “de-stocking” their inventory, particularly in the U.S. and Canada plumbing channel; and, the deferral or cancellation of the construction of new filling stations in the Fueling Systems segment.  Additionally, the strengthening of the U.S. dollar versus most international currencies has resulted in lower translations of both Net Sales and earnings from many of the Company’s businesses outside the U.S.  The Company’s financial results were also impacted negatively by government mandated closures and related customer behaviors.

[0000038725-20-000168:8k_2_02:36]
Commenting on the outlook for 2020 and the effects of the Global Pandemic, Mr. Sengstack said:

[0000038725-20-000168:8k_2_02:37]
“Our Water Systems and Distribution businesses are building momentum heading into the back half of this year, despite the ongoing impacts and uncertainty from the Global Pandemic. Our Fueling business will take longer to recover from the steep declines we experienced in the second quarter, but we believe that the third and fourth quarters’ revenue declines versus 2019 results will be sequentially reduced. Assuming there are no new government mandated restrictions in our key end markets, we estimate our full year 2020 earnings per share before restructuring charges will be between $1.75 to $1.90 and that our Free Cash Flow conversion will be between 130 and 150 percent of Net Income for the full year 2020.”

[0000038725-20-000168:8k_2_02:38]
A conference call to review earnings and other developments in the business will commence at 9:00 am ET. The second quarter 2020 earnings call will be available via a live webcast. The webcast will be available in a listen only mode by going to:

[0000038725-20-000168:8k_2_02:39]
https://edge.media-server.com/mmc/p/ukztoqq9

[0000038725-20-000168:8k_2_02:40]
If you intend to ask questions during the call, please dial in using 877.643.7158 for domestic calls and 914.495.8565 for international calls. The conference ID is: 5470627.

[0000038725-20-000168:8k_2_02:41]
A replay of the conference call will be available Tuesday, July 28, 2020 at 12:00 noon ET through noon ET on Tuesday, August 4, 2020, by dialing 855.859.2056 for domestic calls and 404.537.3406 for international calls. The replay passcode is: 5470627.

[0000038725-20-000168:8k_2_02:42]
Franklin Electric is a global leader in the production and marketing of systems and components for the movement of water and fuel. Recognized as a technical leader in its products and services, Franklin Electric serves customers around the world in residential, commercial, agricultural, industrial, municipal, and fueling applications.

[0000038725-20-000168:8k_2_02:43]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |  |  |  |  |  |  |  |  |
| CONDENSED CONSOLIDATED STATEMENTS OF INCOME |  |  |  |  |  |  |  |  |
| (Unaudited) |  |  |  |  |  |  |  |  |
| (In thousands, except per share amounts) |  |  |  |  |  |  |  |  |
|  | Second Quarter Ended |  |  |  |  | Six Months Ended |  |  |
|  | June 30, 2020 |  | June 30, 2019 |  |  | June 30, 2020 |  | June 30, 2019 |
| Net sales | $ | 308,281 |  |  | $ | 355,340 |  |  |  | $ | 575,035 |  |  | $ | 646,055 |  |
| Cost of sales | 201,159 |  |  | 235,622 |  |  |  | 377,596 |  |  | 436,831 |  |
| Gross profit | 107,122 |  |  | 119,718 |  |  |  | 197,439 |  |  | 209,224 |  |
| Selling, general, and administrative expenses | 72,314 |  |  | 75,782 |  |  |  | 147,937 |  |  | 152,081 |  |
| Restructuring expense | 875 |  |  | 245 |  |  |  | 1,748 |  |  | 1,331 |  |
| Operating income | 33,933 |  |  | 43,691 |  |  |  | 47,754 |  |  | 55,812 |  |
| Interest expense | (1,132) |  |  | (2,295) |  |  |  | (2,366) |  |  | (4,637) |  |
| Other income/(expense), net | (397) |  |  | (292) |  |  |  | (599) |  |  | (53) |  |
| Foreign exchange income/(expense) | (906) |  |  | (505) |  |  |  | 56 |  |  | 84 |  |
| Income before income taxes | 31,498 |  |  | 40,599 |  |  |  | 44,845 |  |  | 51,206 |  |
| Income tax expense | 6,696 |  |  | 7,787 |  |  |  | 9,251 |  |  | 9,267 |  |
| Net income | $ | 24,802 |  |  | $ | 32,812 |  |  |  | $ | 35,594 |  |  | $ | 41,939 |  |
| Less: Net (income)/loss attributable to noncontrolling interests | (151) |  |  | (67) |  |  |  | (300) |  |  | (138) |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 24,651 |  |  | $ | 32,745 |  |  |  | $ | 35,294 |  |  | $ | 41,801 |  |
| Income per share: |  |  |  |  |  |  |  |  |
| Basic | $ | 0.53 |  |  | $ | 0.70 |  |  |  | $ | 0.76 |  |  | $ | 0.89 |  |
| Diluted | $ | 0.52 |  |  | $ | 0.70 |  |  |  | $ | 0.75 |  |  | $ | 0.89 |  |

[0000038725-20-000168:8k_2_02:44]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |  |  |  |
| CONDENSED CONSOLIDATED BALANCE SHEETS |  |  |  |
| (Unaudited) |  |  |  |
| (In thousands) |  |  |  |
|  | June 30, 2020 |  | December 31, 2019 |
| ASSETS |  |  |  |
| Cash and equivalents | $ | 43,083 |  |  | $ | 64,405 |  |
| Receivables, net | 183,210 |  |  | 173,327 |  |
| Inventories | 299,395 |  |  | 300,246 |  |
| Other current assets | 23,653 |  |  | 29,466 |  |
| Total current assets | 549,341 |  |  | 567,444 |  |
| Property, plant, and equipment, net | 186,363 |  |  | 201,328 |  |
| Right-of-use asset, net | 27,687 |  |  | 27,621 |  |
| Goodwill and other assets | 387,941 |  |  | 398,350 |  |
| Total assets | $ | 1,151,332 |  |  | $ | 1,194,743 |  |
| LIABILITIES AND EQUITY |  |  |  |
| Accounts payable | $ | 86,767 |  |  | $ | 82,593 |  |
| Accrued expenses and other current liabilities | 72,613 |  |  | 71,454 |  |
| Current lease liability | 10,273 |  |  | 9,838 |  |
| Current maturities of long-term debt and short-term borrowings | 4,243 |  |  | 21,879 |  |
| Total current liabilities | 173,896 |  |  | 185,764 |  |
| Long-term debt | 92,489 |  |  | 93,141 |  |
| Long-term lease liability | 17,416 |  |  | 17,785 |  |
| Income taxes payable non-current | 11,965 |  |  | 11,965 |  |
| Deferred income taxes | 25,748 |  |  | 27,598 |  |
| Employee benefit plans | 36,631 |  |  | 38,288 |  |
| Other long-term liabilities | 17,938 |  |  | 21,769 |  |
| Redeemable noncontrolling interest | (262) |  |  | (236) |  |
| Total equity | 775,511 |  |  | 798,669 |  |
| Total liabilities and equity | $ | 1,151,332 |  |  | $ | 1,194,743 |  |

[0000038725-20-000168:8k_2_02:45]
| FRANKLIN ELECTRIC CO., INC. AND CONSOLIDATED SUBSIDIARIES |  |  |  |
| CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS |  |  |  |
| (Unaudited) |  |  |  |
|  | Six Months Ended |  |  |
| (In thousands) |  |  |  |
|  | June 30, 2020 |  | June 30, 2019 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 35,594 |  |  | $ | 41,939 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |
| Depreciation and amortization | 17,990 |  |  | 18,350 |  |
| Non-Cash Lease Expense | 5,283 |  |  | 5,199 |  |
| Share-based compensation | 7,015 |  |  | 5,524 |  |
| Other | 267 |  |  | 1,011 |  |
| Changes in assets and liabilities: |  |  |  |
| Receivables | (17,820) |  |  | (46,371) |  |
| Inventory | (7,520) |  |  | (35,318) |  |
| Accounts payable and accrued expenses | 8,561 |  |  | 18,637 |  |
| Operating Leases | (5,283) |  |  | (5,195) |  |
| Other | 2,914 |  |  | 369 |  |
| Net cash flows from operating activities | 47,001 |  |  | 4,145 |  |
| Cash flows from investing activities: |  |  |  |
| Additions to property, plant, and equipment | (9,445) |  |  | (10,444) |  |
| Proceeds from sale of property, plant, and equipment | 25 |  |  | 866 |  |
| Acquisitions and investments | (5,826) |  |  | (6,728) |  |
| Other investing activities | 3 |  |  | 8 |  |
| Net cash flows from investing activities | (15,243) |  |  | (16,298) |  |
| Cash flows from financing activities: |  |  |  |
| Change in debt | (17,908) |  |  | 16,814 |  |
| Proceeds from issuance of common stock | 1,520 |  |  | 1,495 |  |
| Purchases of common stock | (17,724) |  |  | (9,543) |  |
| Dividends paid | (14,446) |  |  | (13,510) |  |
| Purchase of redeemable non-controlling shares | — |  |  | (485) |  |
| Net cash flows from financing activities | (48,558) |  |  | (5,229) |  |
| Effect of exchange rate changes on cash | (4,522) |  |  | (800) |  |
| Net change in cash and equivalents | (21,322) |  |  | (18,182) |  |
| Cash and equivalents at beginning of period | 64,405 |  |  | 59,173 |  |
| Cash and equivalents at end of period | $ | 43,083 |  |  | $ | 40,991 |  |
