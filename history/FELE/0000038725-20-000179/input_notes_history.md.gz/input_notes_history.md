# FELE note change history — 0000038725-20-000107 → 0000038725-20-000179


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-08-04):
[0000038725-20-000179:note_history:1]
At June 30, 2020, the Company had $8.5 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.
  (was, 2020-05-05, similarity 0.9689):
[0000038725-20-000107:note_history:1]
At March 31, 2020, the Company had $5.2 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

- changed (2020-08-04):
[0000038725-20-000179:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended June 30, 2020, are as follows:
  (was, 2020-05-05, similarity 0.9118):
[0000038725-20-000107:note_history:2]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the first quarter ended March 31, 2020, are as follows:

- changed (2020-08-04):
[0000038725-20-000179:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2019 |  | $ | 9.1 |  |
| Accruals related to product warranties |  | 4.8 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (4.8) |  |
| Balance as of June 30, 2020 |  | $ | 9.1 |  |
  (was, 2020-05-05, similarity 0.9815):
[0000038725-20-000107:note_history:3]
| (In millions) |  |  |
| Balance as of December 31, 2019 |  | $ | 9.1 |  |
| Accruals related to product warranties |  | 2.1 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (2.5) |  |
| Balance as of March 31, 2020 |  | $ | 8.7 |  |

- changed (2020-08-04):
[0000038725-20-000179:note_history:4]
The components of the Company’s operating lease portfolio as of the second quarter and six months ended June 30, 2020 are as follows:
  (was, 2020-05-05, similarity 0.8631):
[0000038725-20-000107:note_history:4]
The components of the Company’s operating lease portfolio as of the first quarter ended March 31, 2020 are as follows:

- changed (2020-08-04):
[0000038725-20-000179:note_history:5]
| Lease Cost (in millions): | Second Quarter Ended |  | Six Months Ended |
| Operating lease cost | $ | 3.2 |  |  | $ | 5.2 |  |
| Short-term lease cost | 0.1 |  |  | 0.2 |  |
| Other Information: |  |  |  |
| Weighted-average remaining lease term |  |  | 4 years |
| Weighted-average discount rate |  |  | 3.8 | % |
  (was, 2020-05-05, similarity 0.8801):
[0000038725-20-000107:note_history:5]
| Lease Cost (in millions): |  |  |  |
| Operating lease cost |  |  | $ | 2.0 |  |
| Short-term lease cost |  |  | 0.1 |  |
| Other Information: |  |  |  |
| Weighted-average remaining lease term |  |  | 4 years |
| Weighted-average discount rate |  |  | 3.8 | % |

- changed (2020-08-04):
[0000038725-20-000179:note_history:6]
The minimum rental payments for non-cancellable operating leases as of June 30, 2020, are as follows:
  (was, 2020-05-05, similarity 0.9529):
[0000038725-20-000107:note_history:6]
The minimum rental payments for non-cancellable operating leases as of March 31, 2020, are as follows:


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-08-04):
[0000038725-20-000179:note_history:7]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2019, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 30, 2020, and for the second quarters and six months ended June 30, 2020 and June 30, 2019 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made.  Operating results for the second quarter and six months ended June 30, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2020.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2019.
  (was, 2020-05-05, similarity 0.9431):
[0000038725-20-000107:note_history:7]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2019, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of March 31, 2020, and for the first quarters ended March 31, 2020 and March 31, 2019 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made.  Operating results for the first quarter ended March 31, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2020.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2019.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-08-04):
[0000038725-20-000179:note_history:8]
| (In millions) |  | June 30, 2020 |  | December 31, 2019 |
| Tax increment financing debt |  | 18.2 |  |  | 18.7 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 1.7 |  |  | 19.0 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 1.9 |  |  | 2.3 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 96.7 |  |  | $ | 115.0 |  |
| Less: current maturities |  | (4.2) |  |  | (21.9) |  |
| Long-term debt |  | $ | 92.5 |  |  | $ | 93.1 |  |

- changed (2020-08-04):
[0000038725-20-000179:note_history:9]
Debt outstanding, excluding unamortized debt issuance costs, at June 30, 2020 matures as follows:
  (was, 2020-05-05, similarity 0.9514):
[0000038725-20-000107:note_history:9]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2020 matures as follows:

- changed (2020-08-04):
[0000038725-20-000179:note_history:10]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement"), which expires on July 30, 2021 and has an initial borrowing capacity of $250.0 million.  As of June 30, 2020, the Company has $150.0 million borrowing capacity available under the Prudential Agreement.
  (was, 2020-05-05, similarity 0.9853):
[0000038725-20-000107:note_history:10]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement"), which expires on July 30, 2021 and has an initial borrowing capacity of $250.0 million.  As of March 31, 2020, the Company has $150.0 million borrowing capacity available under the Prudential Agreement.

- changed (2020-08-04):
[0000038725-20-000179:note_history:11]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"), with a maximum aggregate borrowing capacity of $200.0 million.  On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually.  The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of June 30, 2020, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.
  (was, 2020-05-05, similarity 0.9934):
[0000038725-20-000107:note_history:11]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"), with a maximum aggregate borrowing capacity of $200.0 million.  On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually.  The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of March 31, 2020, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

- added (2020-08-04):
[0000038725-20-000179:note_history:12]
The Company maintains the Third Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement has a maturity date of October 28, 2021 and commitment amount of $300.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment

- changed (2020-08-04):
[0000038725-20-000179:note_history:13]
of $450.0 million).  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.
  (was, 2020-05-05, similarity 0.7281):
[0000038725-20-000107:note_history:13]
The Company maintains the Third Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement has a maturity date of October 28, 2021 and commitment amount of $300.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment of $450.0 million).  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

- changed (2020-08-04):
[0000038725-20-000179:note_history:14]
As of June 30, 2020, the Company had $1.7 million in outstanding borrowings which were primarily used for working capital needs, the payment of existing indebtedness and acquisitions, $4.2 million in letters of credit outstanding, and $294.1 million of available capacity under the Credit Agreement.
  (was, 2020-05-05, similarity 0.9842):
[0000038725-20-000107:note_history:14]
As of March 31, 2020, the Company had $39.0 million in outstanding borrowings which were primarily used for working capital needs, the payment of existing indebtedness and acquisitions, $4.2 million in letters of credit outstanding, and $256.8 million of available capacity under the Credit Agreement.

- changed (2020-08-04):
[0000038725-20-000179:note_history:15]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 1.00 to 3.50 and a minimum interest coverage ratio of 1.00 to 3.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of June 30, 2020.
  (was, 2020-05-05, similarity 0.9962):
[0000038725-20-000107:note_history:15]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 1.00 to 3.50 and a minimum interest coverage ratio of 1.00 to 3.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of March 31, 2020.

- removed (2020-08-04):
[0000038725-20-000107:note_history:16]
| (In millions) |  | March 31, 2020 |  | December 31, 2019 |
| Tax increment financing debt |  | 18.2 |  |  | 18.7 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 39.0 |  |  | 19.0 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 2.2 |  |  | 2.3 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 134.3 |  |  | $ | 115.0 |  |
| Less: current maturities |  | (41.7) |  |  | (21.9) |  |
| Long-term debt |  | $ | 92.6 |  |  | $ | 93.1 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-08-04):
[0000038725-20-000179:note_history:17]
| (In millions) |  | June 30, 2020 |  | December 31, 2019 |
| Tax increment financing debt |  | 18.2 |  |  | 18.7 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 1.7 |  |  | 19.0 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 1.9 |  |  | 2.3 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 96.7 |  |  | $ | 115.0 |  |
| Less: current maturities |  | (4.2) |  |  | (21.9) |  |
| Long-term debt |  | $ | 92.5 |  |  | $ | 93.1 |  |

- removed (2020-08-04):
[0000038725-20-000107:note_history:18]
| (In millions) |  | March 31, 2020 |  | December 31, 2019 |
| Tax increment financing debt |  | 18.2 |  |  | 18.7 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 39.0 |  |  | 19.0 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 2.2 |  |  | 2.3 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 134.3 |  |  | $ | 115.0 |  |
| Less: current maturities |  | (41.7) |  |  | (21.9) |  |
| Long-term debt |  | $ | 92.6 |  |  | $ | 93.1 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-08-04):
[0000038725-20-000179:note_history:19]
Debt outstanding, excluding unamortized debt issuance costs, at June 30, 2020 matures as follows:
  (was, 2020-05-05, similarity 0.9514):
[0000038725-20-000107:note_history:19]
Debt outstanding, excluding unamortized debt issuance costs, at March 31, 2020 matures as follows:
