# FELE MD&A — 0000038725-20-000179


## mdna

[0000038725-20-000179:mdna:1]
[same as prior period, unchanged from 0000038725-20-000107:mdna:1]

[0000038725-20-000179:mdna:2]
Second Quarter 2020 vs. Second Quarter 2019

[0000038725-20-000179:mdna:3]
[same as prior period, unchanged from 0000038725-20-000107:mdna:3]

[0000038725-20-000179:mdna:4]
Sales in the second quarter of 2020 decreased from the second quarter of last year. The sales decrease was primarily from lower volumes, in part created by uncertainty and general disruptions around the global pandemic as the World Health Organization categorized the spread of the novel coronavirus on March 11, 2020 (the "Global Pandemic") . The Company's consolidated gross profit was $107.1 million for the second quarter of 2020, a decrease from the prior year’s second quarter. The gross profit as a percent of net sales was 34.7 percent in the second quarter of 2020 versus 33.7 percent during the second quarter 2019 and improved primarily due to better price realization and product sales mix.

[0000038725-20-000179:mdna:5]
[same as prior period, unchanged from 0000038725-20-000107:mdna:5]

[0000038725-20-000179:mdna:6]
[same as prior period, unchanged from 0000038725-20-000107:mdna:6]

[0000038725-20-000179:mdna:7]
The Company’s products and services are generally viewed as essential in most jurisdictions in which the Company operates.  Effectively, all the Company’s global manufacturing and distribution operations are operating.

[0000038725-20-000179:mdna:8]
The primary impacts of the Global Pandemic on the Company’s end markets continue to be a reduction of large dewatering equipment sales in the Water Systems segment; Water Systems customers de-stocking their inventory, particularly in the U.S. and Canada plumbing channel; and, the deferral or cancellation of the construction of new filling stations in the Fueling Systems segment.  Additionally, the strengthening of the U.S. dollar versus most international currencies has resulted in lower translations of both Net Sales and earnings from many of the Company’s businesses outside the U.S.  The Company’s financial results were also impacted negatively by government mandated closures and related customer behaviors.

[0000038725-20-000179:mdna:9]
[same as prior period, unchanged from 0000038725-20-000107:mdna:11]

[0000038725-20-000179:mdna:10]
[same as prior period, unchanged from 0000038725-20-000107:mdna:12]

[0000038725-20-000179:mdna:11]
Net sales in the second quarter of 2020 were $308.3 million, a decrease of $47.0 million or about 13 percent compared to 2019 second quarter sales of $355.3 million.  Acquisition related sales were $3.3 million. Sales revenue decreased by $12.2 million or about 3 percent in the second quarter of 2020 due to foreign currency translation. Organic sales decreased about 10 percent compared to the second quarter of 2019.

[0000038725-20-000179:mdna:12]
|  | Net Sales |  |  |  |  |
| (In millions) | Q2 2020 |  | Q2 2019 |  | 2020 v 2019 |
| Water Systems | $ | 178.4 |  |  | $ | 205.0 |  |  | $ | (26.6) |  |
| Fueling Systems | 56.0 |  |  | 78.0 |  |  | $ | (22.0) |  |
| Distribution | 92.1 |  |  | 87.1 |  |  | $ | 5.0 |  |
| Eliminations/Other | (18.2) |  |  | (14.8) |  |  | $ | (3.4) |  |
| Consolidated | $ | 308.3 |  |  | $ | 355.3 |  |  | $ | (47.0) |  |

[0000038725-20-000179:mdna:13]
[same as prior period, unchanged from 0000038725-20-000107:mdna:15]

[0000038725-20-000179:mdna:14]
Water Systems sales were $178.4 million in the second quarter 2020, a decrease of $26.6 million or about 13 percent versus the second quarter 2019 sales of $205.0 million. Acquisition related sales were $3.3 million. Water Systems sales were reduced by $11.6 million or about 6 percent in the quarter due to foreign currency translation. Excluding acquisitions and foreign currency translation, Water Systems sales were down $18.3 million or about 9 percent compared to the second quarter 2019.

[0000038725-20-000179:mdna:15]
Water Systems sales in the U.S. and Canada were down compared to the second quarter 2019. The impact of foreign currency translation decreased sales by about 1 percent. Sales of dewatering equipment decreased by nearly 70 percent due to lower sales in rental channels and substantial uncertainty in oil production end markets. Sales of groundwater pumping equipment increased by 5 percent versus the second quarter 2019.  Sales of surface pumping equipment decreased by 18 percent on lower sales of both wastewater and water transfer systems as customers in this channel began to feel the impact of the Global Pandemic and lowered their own inventory levels.

[0000038725-20-000179:mdna:16]
Water Systems sales in markets outside the U.S. and Canada declined by 9 percent overall. The impact of foreign currency translation decreased sales by about 12 percent. Excluding the impact of foreign currency translation, Water Systems sales in markets outside the U.S. and Canada, increased by 3 percent, primarily driven by higher sales in Latin America and Asia Pacific, as well as increased sales in both Europe and the Middle East, offset by lower sales in the South African market.

[0000038725-20-000179:mdna:17]
[same as prior period, unchanged from 0000038725-20-000107:mdna:19]

[0000038725-20-000179:mdna:18]
Fueling Systems sales were $56.0 million in the second quarter 2020, a decrease of $22.0 million or about 28 percent versus the second quarter 2019 sales of $78.0 million. Fueling Systems sales decreased by $0.6 million or about 1 percent in the quarter due to foreign currency translation. Fueling Systems organic sales decreased about 27 percent compared to the second quarter of 2019.

[0000038725-20-000179:mdna:19]
Fueling Systems sales in the U.S. and Canada decreased by 22 percent compared to the second quarter 2019.  The decrease was in all product lines and due to declining demand for new filling stations.  Outside the U.S. and Canada, Fueling Systems revenues declined by 35 percent, driven by lower sales in Asia Pacific, primarily China.

[0000038725-20-000179:mdna:20]
[same as prior period, unchanged from 0000038725-20-000107:mdna:22]

[0000038725-20-000179:mdna:21]
Distribution sales were $92.1 million in the second quarter 2020, versus second quarter 2019 sales of $87.1 million.  The Distribution segment organic sales increased 6 percent compared to the second quarter of 2019.  More favorable weather conditions versus the second quarter last year contributed to the revenue growth.

[0000038725-20-000179:mdna:22]
[same as prior period, unchanged from 0000038725-20-000107:mdna:24]

[0000038725-20-000179:mdna:23]
Cost of sales as a percent of net sales for the second quarter of 2020 was 65.3 percent and 66.3 percent for the second quarter of 2019. Correspondingly, the gross profit margin was 34.7 percent and 33.7 percent for the second quarters of 2020 and 2019, respectively.  The Company's consolidated gross profit was $107.1 million for the second quarter of 2020, down $12.6 million from the gross profit of $119.7 million in the second quarter of 2019. The gross profit decrease was due to lower sales. In the second quarter, the gross profit margin percentage improvement was primarily due to better selling price realization and improved product sales mix.

[0000038725-20-000179:mdna:24]
[same as prior period, unchanged from 0000038725-20-000107:mdna:26]

[0000038725-20-000179:mdna:25]
Selling, general, and administrative (SG&A) expenses were $72.3 million in the second quarter of 2020 compared to $75.8 million in the second quarter of 2019. SG&A expenses were lower versus the prior year due to companywide efforts to lower spending in response to the impacts of the Global Pandemic and in part because of foreign currency translation.

[0000038725-20-000179:mdna:26]
[same as prior period, unchanged from 0000038725-20-000107:mdna:28]

[0000038725-20-000179:mdna:27]
Restructuring expenses for the second quarter of 2020 were $0.9 million and related to continued miscellaneous manufacturing and distribution realignment activities in the Water segment. Restructuring expenses for the second quarter of 2019 were $0.2 million and related to branch consolidations and other asset rationalizations in the Headwater distribution segment.

[0000038725-20-000179:mdna:28]
[same as prior period, unchanged from 0000038725-20-000107:mdna:31]

[0000038725-20-000179:mdna:29]
Operating income was $33.9 million in the second quarter of 2020, down $9.8 million or about 22 percent from $43.7 million in the second quarter of 2019.

[0000038725-20-000179:mdna:30]
|  |  | Operating income (loss) |  |  |  |  |
| (In millions) |  | Q2 2020 |  | Q2 2019 |  | 2020 v 2019 |
| Water Systems |  | $ | 28.7 |  |  | $ | 30.9 |  |  | $ | (2.2) |  |
| Fueling Systems |  | 13.5 |  |  | 21.7 |  |  | (8.2) |  |
| Distribution |  | 6.8 |  |  | 4.5 |  |  | 2.3 |  |
| Eliminations/Other |  | (15.1) |  |  | (13.4) |  |  | (1.7) |  |
| Consolidated |  | $ | 33.9 |  |  | $ | 43.7 |  |  | $ | (9.8) |  |

[0000038725-20-000179:mdna:31]
[same as prior period, unchanged from 0000038725-20-000107:mdna:34]

[0000038725-20-000179:mdna:32]
Water Systems operating income was $28.7 million in the second quarter 2020, down $2.2 million or 7 percent versus the second quarter 2019 and operating income margin was 16.1 percent compared to the 15.1 percent in the second quarter 2019 primarily due to product and geographic sales mix shifts.

[0000038725-20-000179:mdna:33]
[same as prior period, unchanged from 0000038725-20-000107:mdna:36]

[0000038725-20-000179:mdna:34]
Fueling Systems operating income was $13.5 million in the second quarter of 2020, down $8.2 million or about 38 percent compared to $21.7 million in the second quarter of 2019 and the second quarter operating income margin was 24.1 percent, a decrease of 370 basis points from the 27.8 percent of net sales in the second quarter of 2019. The decrease in operating income margin was primarily due to lost leverage on fixed cost from lower sales.

[0000038725-20-000179:mdna:35]
[same as prior period, unchanged from 0000038725-20-000107:mdna:38]

[0000038725-20-000179:mdna:36]
Distribution operating income was $6.8 million in the second quarter of 2020 and the second quarter operating income margin was 7.4 percent. Distribution operating income was $4.5 million in the second quarter of 2019 and the second quarter operating income margin was 5.2 percent. The increase in operating income margin is primarily related to higher revenues.

[0000038725-20-000179:mdna:37]
[same as prior period, unchanged from 0000038725-20-000107:mdna:40]

[0000038725-20-000179:mdna:38]
Operating income-Eliminations/Other is composed primarily of unallocated general and administrative expenses and inter-segment sales and profit eliminations.  The inter-segment profit elimination impact in the second quarter of 2020 versus the second quarter of 2019 was $1.1 million. General and administrative expenses were higher by $0.6 million.

[0000038725-20-000179:mdna:39]
[same as prior period, unchanged from 0000038725-20-000107:mdna:42]

[0000038725-20-000179:mdna:40]
Interest expense for the second quarter of 2020 and 2019 was $1.1 million and $2.3 million, respectively.

[0000038725-20-000179:mdna:41]
[same as prior period, unchanged from 0000038725-20-000107:mdna:44]

[0000038725-20-000179:mdna:42]
Other income or expense was a loss of $0.4 million and $0.3 million in the second quarter of 2020 and 2019, respectively.

[0000038725-20-000179:mdna:43]
[same as prior period, unchanged from 0000038725-20-000107:mdna:46]

[0000038725-20-000179:mdna:44]
Foreign currency-based transactions produced a loss for the second quarter of 2020 of $0.9 million, primarily due to the Argentinian peso relative to the U.S. dollar. Foreign currency-based transactions produced a loss for the second quarter of 2019 of $0.5 million, primarily due to the Turkish Lira relative to the U.S. dollar.

[0000038725-20-000179:mdna:45]
[same as prior period, unchanged from 0000038725-20-000107:mdna:48]

[0000038725-20-000179:mdna:46]
The provision for income taxes in the second quarter of 2020 and 2019 was $6.7 million and $7.8 million, respectively. The effective tax rate for the second quarter of 2020 was about 21 percent and, before the impact of discrete events, was about 20 percent. The effective tax rate for the second quarter of 2019 was about 19 percent and, before the impact of discrete events, was about 21 percent. The increase in the effective tax rate was primarily a result of net unfavorable discrete events recorded in the second quarter of 2020 compared to net favorable discrete events in the second quarter of 2019. Discrete events in the second quarter 2020 included tax expense for a valuation allowance on foreign deferred tax assets and withholding tax on a foreign distribution and tax benefit on the release of a foreign deferred tax liability on foreign exchange from the settlement of an intercompany loan. The tax rate as a percentage of pre-tax earnings for the full year 2020 is projected to be about 20 percent, compared to the full year 2019 tax rate of about 20 percent, both before discrete adjustments.

[0000038725-20-000179:mdna:47]
[same as prior period, unchanged from 0000038725-20-000107:mdna:50]

[0000038725-20-000179:mdna:48]
Net income for the second quarter of 2020 was $24.8 million compared to the prior year second quarter net income of $32.8 million.  Net income attributable to Franklin Electric Co., Inc. for the second quarter of 2020 was $24.7 million, or $0.52 per diluted share, compared to the prior year second quarter net income attributable to Franklin Electric Co., Inc. of $32.7 million or $0.70 per diluted share.

[0000038725-20-000179:mdna:49]
First Half of 2020 vs. First Half of 2019

[0000038725-20-000179:mdna:50]
OVERVIEW

[0000038725-20-000179:mdna:51]
Sales in the first half of 2020 were down from the same period last year.  The sales decrease was primarily from lower volumes, in part created by uncertainty and general disruptions around the Global Pandemic. The Company's consolidated gross profit was $197.4 million for the first half of 2020, a decrease of $11.8 million or about 6 percent from the first half of 2019. Diluted earnings per share in the first half of 2020 were down from the same period last year.

[0000038725-20-000179:mdna:52]
RESULTS OF OPERATIONS

[0000038725-20-000179:mdna:53]
Net Sales

[0000038725-20-000179:mdna:54]
Net sales in the first half of 2020 were $575.0 million, a decrease of $71.1 million or about 11 percent compared to 2019 first half sales of $646.1 million.  The incremental impact of sales from acquired businesses was $7.2 million. Sales revenue decreased by $20.3 million or about 3 percent in the first half of 2020 due to foreign currency translation.

[0000038725-20-000179:mdna:55]
|  | Net Sales |  |  |  |  |
| (In millions) | YTD June 30, 2020 |  | YTD June 30, 2019 |  | 2020 v 2019 |
| Water Systems | $ | 342.5 |  |  | $ | 393.4 |  |  | $ | (50.9) |  |
| Fueling Systems | 111.2 |  |  | 138.3 |  |  | $ | (27.1) |  |
| Distribution | 152.5 |  |  | 140.4 |  |  | $ | 12.1 |  |
| Eliminations/Other | (31.2) |  |  | (26.0) |  |  | $ | (5.2) |  |
| Consolidated | $ | 575.0 |  |  | $ | 646.1 |  |  | $ | (71.1) |  |

[0000038725-20-000179:mdna:56]
Net Sales-Water Systems

[0000038725-20-000179:mdna:57]
Water Systems sales were $342.5 million in the first half of 2020, a decrease of $50.9 million or about 13 percent versus the first half of 2019. The incremental impact of sales from acquired businesses was $7.2 million. Foreign currency translation changes decreased sales $19.3 million, or about 5 percent, compared to sales in the first half of 2019. The Water Systems sales change in the first half of 2020, excluding acquisitions and foreign currency translation, was a decrease of $38.8 million or about 10 percent.

[0000038725-20-000179:mdna:58]
Water Systems sales in the U.S. and Canada decreased by about 15 percent compared to the first half of 2019. The incremental impact of sales from acquired businesses was $7.2 million. Sales revenue decreased by $0.7 million in the first half of 2020 due to foreign currency translation. In the first half of 2020, sales of dewatering equipment decreased by about 60 percent due to lower sales in rental channels and substantial uncertainty in oil production end markets. Sales of groundwater pumping equipment increased by 4 percent versus the first half of 2019.  Sales of other surface pumping equipment decreased by 16 percent on lower sales of both wastewater and water transfer systems as customers in this channel began to feel the impact of the Global Pandemic and lowered their own inventory levels.

[0000038725-20-000179:mdna:59]
Water Systems sales in markets outside the U.S. and Canada decreased by about 10 percent compared to the first half of 2019. Sales revenue decreased by $18.6 million or about 10 percent in the first half of 2020 due to foreign currency translation. International Water Systems sales change in the first half of 2020, excluding foreign currency translation, was flat or less than 1 percent increase. International Water Systems sales growth in Latin America and EMENA were partially offset by lower sales in the Asia Pacific markets.

[0000038725-20-000179:mdna:60]
Net Sales-Fueling Systems

[0000038725-20-000179:mdna:61]
Fueling Systems sales were $111.2 million in the first half 2020, a decrease of $27.1 million or about 20 percent from the first half of 2019. Foreign currency translation changes decreased sales $1.0 million or about 1 percent compared to sales in the first half of 2019. The Fueling Systems sales change in the first half of 2020, excluding acquisitions and foreign currency translation, was a decrease of about 19 percent.

[0000038725-20-000179:mdna:62]
Fueling Systems sales in the U.S. and Canada declined by about 10 percent during the first half. The decrease was in all product lines and due to declining demand for new filling stations. Internationally, Fueling Systems revenues declined by about 33 percent, driven by lower sales in Asia Pacific, primarily China and India.

[0000038725-20-000179:mdna:63]
Net Sales-Distribution

[0000038725-20-000179:mdna:64]
Distribution sales were $152.5 million in the first half of 2020, versus the first half of 2019 sales of $140.4 million.  Distribution segment organic sales increased about 9 percent compared to the first half of 2019 primarily due to more favorable weather conditions versus last year.

[0000038725-20-000179:mdna:65]
Cost of Sales

[0000038725-20-000179:mdna:66]
Cost of sales as a percent of net sales for the first half of 2020 and 2019 was 65.7 percent and 67.6 percent, respectively. Correspondingly, the gross profit margin was 34.3 percent and 32.4 percent, respectively. The Company's consolidated gross profit was $197.4 million for the first half of 2020, down $11.8 million from the gross profit of $209.2 million in the first half of 2019. The gross profit decrease was primarily due to lower sales. The improvement in gross profit margin percentage is partially attributable to better selling price realization and improved product and geographic sales mix shifts.

[0000038725-20-000179:mdna:67]
Selling, General, and Administrative (“SG&A”)

[0000038725-20-000179:mdna:68]
Selling, general, and administrative expenses were $147.9 million in the first half of 2020 and decreased by $4.2 million or 3 percent in the first half of 2020 compared to $152.1 million the first half of last year. SG&A expenses were lower versus the prior year due to companywide efforts to lower spending in response to the impacts of the Global Pandemic and in part because of foreign currency translation.

[0000038725-20-000179:mdna:69]
Restructuring Expenses

[0000038725-20-000179:mdna:70]
Restructuring expenses for the first half of 2020 were $1.7 million. Restructuring expenses were $1.5 million in the Water segment and $0.1 million in the Fueling segment from continued miscellaneous manufacturing and distribution realignment activities and $0.1 in distribution related to branch consolidations and other asset rationalizations in the Headwater distribution segment. Restructuring expenses for the first half of 2019 were $1.3 million. Restructuring expenses were $0.5 million in the Water segment from continued miscellaneous manufacturing realignment activities and $0.8 in distribution related to branch consolidations and other asset rationalizations in the Headwater distribution segment.

[0000038725-20-000179:mdna:71]
Operating Income

[0000038725-20-000179:mdna:72]
Operating income was $47.8 million in the first half of 2020, down $8.0 million or about 14 percent from $55.8 million in the first half of 2019.

[0000038725-20-000179:mdna:73]
|  |  | Operating income (loss) |  |  |  |  |
| (In millions) |  | YTD June 30, 2020 |  | YTD June 30, 2019 |  | 2020 v 2019 |
| Water Systems |  | $ | 47.5 |  |  | $ | 50.1 |  |  | $ | (2.6) |  |
| Fueling Systems |  | 25.6 |  |  | 34.0 |  |  | (8.4) |  |
| Distribution |  | 4.6 |  |  | 0.2 |  |  | 4.4 |  |
| Eliminations/Other |  | (29.9) |  |  | (28.5) |  |  | (1.4) |  |
| Consolidated |  | $ | 47.8 |  |  | $ | 55.8 |  |  | $ | (8.0) |  |

[0000038725-20-000179:mdna:74]
Operating Income-Water Systems

[0000038725-20-000179:mdna:75]
Water Systems operating income was $47.5 million in the first half of 2020 compared to $50.1 million in the first half of 2019, a decrease of about 5 percent. The first half operating income margin was 13.9 percent and increased by 120 basis points compared to the first half of 2019. Operating income margin increased in Water Systems primarily due to product and geographic sales mix shifts.

[0000038725-20-000179:mdna:76]
Operating Income-Fueling Systems

[0000038725-20-000179:mdna:77]
Fueling Systems operating income was $25.6 million in the first half of 2020 compared to $34.0 million in the first half of 2019. The first half operating income margin was 23.0 percent compared to 24.6 percent of net sales in the first half of 2019, a decrease of 160 basis points. The decrease in operating income margin was primarily due to lost leverage on fixed cost from lower sales.

[0000038725-20-000179:mdna:78]
Operating Income-Distribution

[0000038725-20-000179:mdna:79]
Distribution operating income was $4.6 million in the first half of 2020 and operating income margin was 3.0 percent. Distribution operating income was $0.2 million in the first half of 2019 and operating income margin was 0.1 percent. Operating income margin increased in Distribution due to higher sales volumes.

[0000038725-20-000179:mdna:80]
Operating Income-Eliminations/Other

[0000038725-20-000179:mdna:81]
Operating income-Eliminations/Other is composed primarily of inter-segment sales and profit eliminations and unallocated general and administrative expenses.  The inter-segment profit elimination impact in the first half of 2020 versus the first half of 2019 was $0.3 million. General and administrative expenses were higher by $1.1 million or about 4 percent to last year in the first half.

[0000038725-20-000179:mdna:82]
Interest Expense

[0000038725-20-000179:mdna:83]
Interest expense for the first half of 2020 and 2019 was $2.4 million and $4.6 million, respectively.

[0000038725-20-000179:mdna:84]
Other Income or Expense

[0000038725-20-000179:mdna:85]
Other income or expense was a loss of $0.6 million in the first half of 2020. Other income or expense was a loss of $0.1 million in the first half of 2019.

[0000038725-20-000179:mdna:86]
Foreign Exchange

[0000038725-20-000179:mdna:87]
Foreign currency-based transactions for the first half of 2020 was a gain $0.1 million due to movements in several currencies relative to the U.S. dollar, none of which individually were significant. Foreign currency-based transactions for the first half of 2019 was a gain of $0.1 million due to movements in several currencies relative to the U.S. dollar, none of which individually were significant.

[0000038725-20-000179:mdna:88]
Income Taxes

[0000038725-20-000179:mdna:89]
The provision for income taxes in the first half of 2020 and 2019 was $9.3 million for both. The effective tax rate for the first half of 2020 was about 21 percent and, before the impact of discrete events, was about 20 percent. The effective tax rate in the first half of 2019 was about 18 percent and, before the impact of discrete events, was about 21 percent. The increase in the effective tax rate was primarily a result of net unfavorable discrete events recorded in the first half of 2020 compared to net favorable discrete events in the first half of 2019. The Company estimates its effective tax rate for 2020 after discrete events will be about 20 percent, or about 2 points higher than the effective tax rate of 18 percent in 2019.

[0000038725-20-000179:mdna:90]
Net Income

[0000038725-20-000179:mdna:91]
Net income for the first half of 2020 was $35.6 million compared to 2019 first half net income of $41.9 million.  Net income attributable to Franklin Electric Co., Inc. for the first half of 2020 was $35.3 million, or $0.75 per diluted share, compared to 2019 first half net income attributable to Franklin Electric Co., Inc. of $41.8 million or $0.89 per diluted share.

[0000038725-20-000179:mdna:92]
[same as prior period, unchanged from 0000038725-20-000107:mdna:52]

[0000038725-20-000179:mdna:93]
[same as prior period, unchanged from 0000038725-20-000107:mdna:53]

[0000038725-20-000179:mdna:94]
The Company's primary sources of liquidity are cash on hand, cash flows from operations, revolving credit agreements, and long-term debt funds available.  The Company believes its capital resources and liquidity position at June 30, 2020 is adequate to meet projected needs for the foreseeable future.  The Company expects that ongoing requirements for operations, capital expenditures, pension obligations, dividends, share repurchases, and debt service will be adequately funded from cash on hand, operations, and existing credit agreements.

[0000038725-20-000179:mdna:95]
As of June 30, 2020 the Company had a $300.0 million revolving credit facility.  The facility is scheduled to mature on October 28, 2021.  As of June 30, 2020, the Company had $294.1 million borrowing capacity under the Credit Agreement as $4.2 million in letters of commercial and standby letters of credit were outstanding and undrawn and $1.7 million in revolver borrowings were drawn and outstanding which were primarily used for working capital needs and the payment of existing indebtedness.

[0000038725-20-000179:mdna:96]
The Company also has other long-term debt borrowing outstanding as of June 30, 2020.  See Note 9 - Debt for additional specifics regarding these obligations and future maturities.

[0000038725-20-000179:mdna:97]
At June 30, 2020, the Company had $33.8 million of cash and cash equivalents held in foreign jurisdictions, which is intended to be used to fund foreign operations.  There is currently no need or intent to repatriate these funds in order to meet domestic funding obligations or scheduled cash distributions.

[0000038725-20-000179:mdna:98]
[same as prior period, unchanged from 0000038725-20-000107:mdna:58]

[0000038725-20-000179:mdna:99]
The following table summarizes significant sources and uses of cash and cash equivalents for the first six months of 2020 and 2019.

[0000038725-20-000179:mdna:100]
| (in millions) |  | 2020 |  | 2019 |
| Net cash flows from operating activities |  | $ | 47.0 |  |  | $ | 4.1 |  |
| Net cash flows from investing activities |  | (15.2) |  |  | (16.3) |  |
| Net cash flows from financing activities |  | (48.6) |  |  | (5.2) |  |
| Impact of exchange rates on cash and cash equivalents |  | (4.5) |  |  | (0.8) |  |
| Change in cash and cash equivalents |  | $ | (21.3) |  |  | $ | (18.2) |  |

[0000038725-20-000179:mdna:101]
[same as prior period, unchanged from 0000038725-20-000107:mdna:61]

[0000038725-20-000179:mdna:102]
[same as prior period, unchanged from 0000038725-20-000107:mdna:62]

[0000038725-20-000179:mdna:103]
Net cash provided by operating activities was $47.0 million for the six months ended June 30, 2020 compared to $4.1 million provided by operating activities for the six months ended June 30, 2019.  The increase in cash provided by operating activities was due to a decrease of approximately $46.3 million in working capital requirements, partially offset by lower net income.

[0000038725-20-000179:mdna:104]
[same as prior period, unchanged from 0000038725-20-000107:mdna:64]

[0000038725-20-000179:mdna:105]
[same as prior period, unchanged from 0000038725-20-000107:mdna:65]

[0000038725-20-000179:mdna:106]
Net cash used in investing activities was $15.2 million for the six months ended June 30, 2020 compared to $16.3 million used in investing activities for the  six months ended June 30, 2019.  The decrease in cash used in investing activities was primarily attributable to decreased acquisition activity.

[0000038725-20-000179:mdna:107]
[same as prior period, unchanged from 0000038725-20-000107:mdna:67]

[0000038725-20-000179:mdna:108]
[same as prior period, unchanged from 0000038725-20-000107:mdna:68]

[0000038725-20-000179:mdna:109]
Net cash used in financing activities was $48.6 million for the six months ended June 30, 2020 compared to $5.2 million used in financing activities for the six months ended June 30, 2019. The increase in cash used in financing activities was primarily attributable to a decrease in net debt borrowings of approximately $34.7 million and an increase of $8.2 million in common stock repurchases.

[0000038725-20-000179:mdna:110]
[same as prior period, unchanged from 0000038725-20-000107:mdna:70]
