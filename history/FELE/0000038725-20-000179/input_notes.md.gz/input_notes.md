# FELE notes — 0000038725-20-000179


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000038725-20-000179:notes:1]
CONDENSED CONSOLIDATED FINANCIAL STATEMENTSThe accompanying condensed consolidated balance sheet as of December 31, 2019, which has been derived from audited financial statements, and the unaudited interim condensed consolidated financial statements as of June 30, 2020, and for the second quarters and six months ended June 30, 2020 and June 30, 2019 have been prepared in accordance with generally accepted accounting principles for interim financial information and with the instructions to Form 10-Q and Article 10 of Regulation S-X.  Certain information and note disclosures normally included in annual financial statements prepared in accordance with generally accepted accounting principles have been condensed or omitted pursuant to those rules and regulations.  In the opinion of management, all accounting entries and adjustments (including normal, recurring adjustments) considered necessary for a fair presentation of the financial position and the results of operations for the interim periods have been made.  Operating results for the second quarter and six months ended June 30, 2020 are not necessarily indicative of the results that may be expected for the fiscal year ending December 31, 2020.  For further information, including a description of the critical accounting policies of Franklin Electric Co., Inc. (the "Company"), refer to the consolidated financial statements and notes thereto included in the Company's Annual Report on Form 10-K for the year ended December 31, 2019.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000038725-20-000179:notes:2]
ACCOUNTING PRONOUNCEMENTS
Adoption of New Accounting Standards

[0000038725-20-000179:notes:3]
In January 2017, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2017-04, Intangibles - Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.  ASU 2017-04 removes step two from the goodwill impairment test and instead requires an entity to recognize a goodwill impairment charge for the amount by which the goodwill carrying amount exceeds the reporting unit's fair value.  The ASU is effective on a prospective basis for interim and annual periods beginning after December 15, 2019 with early adoption permitted.   The Company adopted the standard effective January 1, 2020. The standard did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-20-000179:notes:4]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments, which modifies the measurement of expected credit losses on certain financial instruments, including trade receivables.  ASU 2016-13 is effective for interim and annual periods beginning after December 15, 2019 with early adoption permitted.  Amendments should be applied using a modified retrospective approach except for debt securities, which require a prospective transitions approach.  The Company adopted the standard effective January 1, 2020. The standard did not have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-20-000179:notes:5]
Accounting Standards Issued But Not Yet Adopted

[0000038725-20-000179:notes:6]
In August 2018, the FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Topic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which modifies the disclosure requirements for employers that sponsor defined benefit pension or other postretirement plans. The amendments remove disclosures that no longer are considered cost beneficial, including the estimated amounts in accumulated other comprehensive income expected to be recognized as components of net periodic expense over the next fiscal year. The amendments clarify the specific requirements of disclosures, and add disclosure requirements identified as relevant, including the reasons for significant gains and losses related to change in the benefit obligation for the period.  The ASU should be applied retrospectively and is effective for interim and annual periods beginning after December 15, 2020. The Company is still determining the date of adoption for this ASU but does not anticipate the adoption to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.

[0000038725-20-000179:notes:7]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which is expected to reduce cost and complexity related to accounting for income taxes. ASU 2019-12 eliminates the need for the Company to analyze whether certain exceptions apply and improves financial statement preparers' application of income tax-related guidance. ASU 2019-12 is effective for interim and annual periods beginning after December 15, 2020 with early adoption permitted. Amendments related to franchise taxes that are partially based on income should be applied on either a retrospective or modified retrospective basis. All other amendments should be applied on a prospective basis. The Company is still determining the date of adoption of this ASU. Adoption is not expected to have a material impact on the Company's consolidated financial position, results of operations, or cash flows.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000038725-20-000179:notes:8]
ACQUISITIONSDuring the first quarter ended March 31, 2020, the Company acquired all of the assets of a company that manufactures line shaft turbines and other adjacent product lines for a purchase price of $6.3 million after working capital adjustments.  The fair value of the assets acquired and liabilities assumed are preliminary as of June 30, 2020.  In addition, the Company has not 
presented separate results of operations since closing or combined pro forma financial information of the Company and the acquired interest since the beginning of 2020, as the results of operations for this acquisition is immaterial.

[0000038725-20-000179:notes:9]
During the third quarter ended September 30, 2019, the Company acquired 100 percent of the ownership interests of First Sales, LLC for a purchase price of approximately $15.5 million after working capital adjustments.  The acquisition was not material, and the fair value of the assets acquired and liabilities assumed are preliminary as of June 30, 2020.

[0000038725-20-000179:notes:10]
[same as prior period, unchanged from 0000038725-20-000107:notes:10]

[0000038725-20-000179:notes:11]
Transaction costs were expensed as incurred under the guidance of FASB Accounting Standards Codification Topic 805, Business Combinations and were not material for the second quarter and six months ended June 30, 2020. There were $0.1 million and $0.1 million of transaction costs included in the "Selling, general, and administrative expenses" line of the Company's condensed consolidated statements of income for the second quarter and six months ended June 30, 2019 respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0000038725-20-000179:notes:12]
[same as prior period, unchanged from 0000038725-20-000107:notes:13]

[0000038725-20-000179:notes:13]
[same as prior period, unchanged from 0000038725-20-000107:notes:14]

[0000038725-20-000179:notes:14]
[same as prior period, unchanged from 0000038725-20-000107:notes:15]

[0000038725-20-000179:notes:15]
[same as prior period, unchanged from 0000038725-20-000107:notes:16]

[0000038725-20-000179:notes:16]
As of June 30, 2020 and December 31, 2019, the assets measured at fair value on a recurring basis were as set forth in the table below:

[0000038725-20-000179:notes:17]
| (In millions) | June 30, 2020 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs(Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 4.4 |  | $ | 4.4 |  | $ | — |  | $ | — |  |
|  | December 31, 2019 | Quoted Prices in Active Markets for Identical Assets (Level 1) | Significant Other Observable Inputs (Level 2) | Significant Unobservable Inputs (Level 3) |
| Cash equivalents | $ | 4.0 |  | $ | 4.0 |  | $ | — |  | $ | — |  |

[0000038725-20-000179:notes:18]
[same as prior period, unchanged from 0000038725-20-000107:notes:19]

[0000038725-20-000179:notes:19]
The Company has no assets measured on a recurring basis classified as Level 2 or Level 3.
Total debt, including current maturities, have carrying amounts of $96.7 million and $115.0 million and estimated fair values of $105.1 million and $121.0 million as of June 30, 2020 and December 31, 2019, respectively.  In the absence of quoted prices in active markets, considerable judgment is required in developing estimates of fair value.  Estimates are not necessarily indicative of the amounts the Company could realize in a current market transaction.  In determining the fair value of its debt, the Company uses estimates based on rates currently available to the Company for debt with similar terms and remaining maturities.  Accordingly, the fair value of debt is classified as Level 2 within the valuation hierarchy.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000038725-20-000179:notes:20]
FINANCIAL INSTRUMENTSThe Company’s deferred compensation stock program is subject to variable plan accounting and, accordingly, is adjusted for changes in the Company’s stock price at the end of each reporting period.  The Company has entered into share swap transaction agreements (the "swap") to mitigate the Company’s exposure to the fluctuations in the Company's stock price.  The swap has not been designated as a hedge for accounting purposes and is cancellable with 30 days' written notice by either party.  As of June 30, 2020, the swap had a notional value based on 280,000 shares. For the second quarter and six months ended June 30, 2020, the swap resulted in a gain of $1.3 million and a loss of $1.5 million, respectively. For the second quarter and six months ended June 30, 2019, the swap resulted in a  loss of $0.9 million and a gain $1.0 million, respectively. Gains and losses resulting from the swap were primarily offset by gains and losses on the fair value of the deferred compensation stock liability. All gains or losses and expenses related to the swap are recorded in the Company's condensed consolidated statements of income within the “Selling, general, and administrative expenses” line.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000038725-20-000179:notes:21]
[same as prior period, unchanged from 0000038725-20-000107:notes:23]

[0000038725-20-000179:notes:22]
| (In millions) |  | June 30, 2020 |  |  |  | December 31, 2019 |  |  |
|  |  | Gross Carrying Amount |  | Accumulated Amortization |  | Gross Carrying Amount |  | Accumulated Amortization |
| Amortizing intangibles: |  |  |  |  |  |  |  |  |
| Patents |  | $ | 7.4 |  |  | $ | (7.1) |  |  | $ | 7.4 |  |  | $ | (7.0) |  |
| Technology |  | 7.5 |  |  | (7.0) |  |  | 7.5 |  |  | (6.8) |  |
| Customer relationships |  | 150.9 |  |  | (73.6) |  |  | 155.4 |  |  | (71.4) |  |
| Other |  | 3.7 |  |  | (2.8) |  |  | 3.8 |  |  | (2.8) |  |
| Total |  | $ | 169.5 |  |  | $ | (90.5) |  |  | $ | 174.1 |  |  | $ | (88.0) |  |
| Unamortizing intangibles: |  |  |  |  |  |  |  |  |
| Trade names |  | 42.7 |  |  | — |  |  | 45.0 |  |  | — |  |
| Total intangibles |  | $ | 212.2 |  |  | $ | (90.5) |  |  | $ | 219.1 |  |  | $ | (88.0) |  |

[0000038725-20-000179:notes:23]
Amortization expense related to intangible assets for the second quarters ended June 30, 2020 and June 30, 2019 was $2.3 million and $2.3 million, and for the six months ended June 30, 2020 and June 30, 2019, $4.7 million and $4.6 million respectively.

[0000038725-20-000179:notes:24]
[same as prior period, unchanged from 0000038725-20-000107:notes:26]

[0000038725-20-000179:notes:25]
[same as prior period, unchanged from 0000038725-20-000107:notes:27]

[0000038725-20-000179:notes:26]
The change in the carrying amount of goodwill by reportable segment for the six months ended June 30, 2020, is as follows:

[0000038725-20-000179:notes:27]
| (In millions) |  |  |  |  |  |  |  |  |
|  |  | Water Systems |  | Fueling Systems |  | Distribution |  | Consolidated |
| Balance as of December 31, 2019 |  | $ | 151.0 |  |  | $ | 67.6 |  |  | $ | 37.5 |  |  | $ | 256.1 |  |
| Acquisitions |  | 3.0 |  |  | — |  |  | — |  |  | 3.0 |  |
| Foreign currency translation |  | (2.7) |  |  | (0.2) |  |  | — |  |  | (2.9) |  |
| Balance as of June 30, 2020 |  | $ | 151.3 |  |  | $ | 67.4 |  |  | $ | 37.5 |  |  | $ | 256.2 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000038725-20-000179:notes:28]
EMPLOYEE BENEFIT PLANSDefined Benefit Plans - As of June 30, 2020, the Company maintained two domestic pension plans and three German pension plans.  The Company used a December 31, 2019 measurement date for these plans.  One of the Company's domestic pension plans covers one active management employee, while the other domestic plan covers all eligible employees (plan was frozen as of December 31, 2011).  The two domestic and three German plans collectively comprise the 'Pension Benefits' disclosure caption. 
Other Benefits - The Company's other post-retirement benefit plan provides health and life insurance to domestic employees hired prior to 1992.

[0000038725-20-000179:notes:29]
The following table sets forth the aggregated net periodic benefit cost for all pension plans for the second quarters and six months ended June 30, 2020 and June 30, 2019:

[0000038725-20-000179:notes:30]
| (In millions) | Pension Benefits |  |  |  |  |  |  |
|  | Second Quarter Ended |  |  |  | Six Months Ended |  |  |
|  | June 30, 2020 |  | June 30, 2019 |  | June 30, 2020 |  | June 30, 2019 |
| Service cost | $ | 0.2 |  |  | $ | 0.2 |  |  | $ | 0.3 |  |  | $ | 0.4 |  |
| Interest cost | 1.1 |  |  | 1.5 |  |  | 2.2 |  |  | 3.0 |  |
| Expected return on assets | (1.7) |  |  | (2.0) |  |  | (3.4) |  |  | (4.0) |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | 0.9 |  |  | 0.7 |  |  | 1.8 |  |  | 1.3 |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | 0.5 |  |  | $ | 0.4 |  |  | $ | 0.9 |  |  | $ | 0.7 |  |

[0000038725-20-000179:notes:31]
In the six months ended June 30, 2020, the Company made contributions of $0.1 million to the funded plans.  The amount of contributions to be made to the plans during the calendar year 2020 will be finalized by September 15, 2020, based upon the funding level requirements identified and year-end valuation performed at December 31, 2019.

[0000038725-20-000179:notes:32]
The following table sets forth the aggregated net periodic benefit cost for the other post-retirement benefit plan for the second quarters and six months ended June 30, 2020 and June 30, 2019:

[0000038725-20-000179:notes:33]
| (In millions) | Other Benefits |  |  |  |  |  |  |
|  | Second Quarter Ended |  |  |  | Six Months Ended |  |  |
|  | June 30, 2020 |  | June 30, 2019 |  | June 30, 2020 |  | June 30, 2019 |
| Service cost | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Interest cost | — |  |  | 0.1 |  |  | 0.1 |  |  | 0.2 |  |
| Expected return on assets | — |  |  | — |  |  | — |  |  | — |  |
| Amortization of: |  |  |  |  |  |  |  |
| Prior service cost | — |  |  | — |  |  | — |  |  | — |  |
| Actuarial loss | — |  |  | — |  |  | — |  |  | — |  |
| Settlement cost | — |  |  | — |  |  | — |  |  | — |  |
| Net periodic benefit cost | $ | — |  |  | $ | 0.1 |  |  | $ | 0.1 |  |  | $ | 0.2 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000038725-20-000179:notes:34]
INCOME TAXES
The Company’s effective tax rate from continuing operations for the six month period ended June 30, 2020 was 20.6 percent as compared to 18.1 percent for the six month period ended June 30, 2019. The effective tax rate is lower than the U.S. statutory rate of 21 percent primarily due to foreign earnings taxed at rates below the U.S. statutory rate, the recognition of the U.S. foreign-derived intangible income (FDII) provisions, and certain discrete events including excess tax benefits from share-based compensation.  For the second quarter of 2020, the effective tax rate was 21.3 percent as compared to 19.2 percent for the second quarter of 2019.  The increase in the effective tax rate was primarily a result of net unfavorable discrete events of $0.4 million recorded in the second quarter of 2020 compared to net favorable discrete events of $0.6 million in the second quarter of 2019.

[0000038725-20-000179:notes:35]
During the second quarter of 2020, the Company recorded $1.4 million of expense for a valuation allowance on deferred tax assets in foreign jurisdictions to recognize only the portion of the deferred tax assets that are more likely than not to be realized.

[0000038725-20-000179:notes:36]
In addition, the Company recorded a benefit of $1.2 million for the release of a deferred tax liability related to unrecognized foreign exchange on the settlement of an intercompany loan.  The Company also recorded $0.2 million of expense for other discrete events primarily related to foreign withholding tax on a distribution in a foreign jurisdiction.

[0000038725-20-000179:notes:37]
On March 27, 2020, President Trump signed into U.S. federal law the CARES Act, which is aimed at providing emergency assistance and health care for individuals, families, and businesses affected by the COVID-19 pandemic and generally supporting the U.S. economy. The CARES Act, among other things, includes provisions related to refundable payroll tax credits, deferment of the employer portion of social security payments, net operating loss carryback periods, modifications to the net interest deduction limitations, and technical corrections to tax depreciation methods for qualified improvement property.  The Company does not expect there to be a material impact to the consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock

[0000038725-20-000179:notes:38]
DEBT
Debt consisted of the following:

[0000038725-20-000179:notes:39]
| (In millions) |  | June 30, 2020 |  | December 31, 2019 |
| Tax increment financing debt |  | 18.2 |  |  | 18.7 |  |
| New York Life Agreement |  | 75.0 |  |  | 75.0 |  |
| Credit Agreement |  | 1.7 |  |  | 19.0 |  |
| Financing Leases |  | — |  |  | 0.1 |  |
| Foreign subsidiary debt |  | 1.9 |  |  | 2.3 |  |
| Less: unamortized debt issuance costs |  | (0.1) |  |  | (0.1) |  |
|  |  | $ | 96.7 |  |  | $ | 115.0 |  |
| Less: current maturities |  | (4.2) |  |  | (21.9) |  |
| Long-term debt |  | $ | 92.5 |  |  | $ | 93.1 |  |

[0000038725-20-000179:notes:40]
Debt outstanding, excluding unamortized debt issuance costs, at June 30, 2020 matures as follows:

[0000038725-20-000179:notes:41]
| (In millions) |  | Total |  | Year 1 |  | Year 2 |  | Year 3 |  | Year 4 |  | Year 5 |  | More Than 5 Years |
| Debt |  | $ | 96.8 |  |  | $ | 4.2 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.3 |  |  | $ | 1.4 |  |  | $ | 87.3 |  |

[0000038725-20-000179:notes:42]
Prudential Agreement

[0000038725-20-000179:notes:43]
The Company maintains the Third Amended and Restated Note Purchase and Private Shelf Agreement (the "Prudential Agreement"), which expires on July 30, 2021 and has an initial borrowing capacity of $250.0 million.  As of June 30, 2020, the Company has $150.0 million borrowing capacity available under the Prudential Agreement.

[0000038725-20-000179:notes:44]
Project Bonds

[0000038725-20-000179:notes:45]
The Company, Allen County, Indiana and certain institutional investors maintain a Bond Purchase and Loan Agreement. Under the agreement, Allen County, Indiana issued a series of Project Bonds entitled “Taxable Economic Development Bonds, Series 2012 (Franklin Electric Co., Inc. Project)." The aggregate principal amount of the Project Bonds that were issued, authenticated, and are now outstanding thereunder was limited to $25.0 million. These Project Notes ("Tax increment financing debt") bear interest at 3.6 percent per annum. Interest and principal balance of the Project Notes are due and payable by the Company directly to the institutional investors in aggregate semi-annual installments commencing on July 10, 2013, and concluding on January 10, 2033.

[0000038725-20-000179:notes:46]
New York Life Agreement

[0000038725-20-000179:notes:47]
The Company maintains an uncommitted and unsecured private shelf agreement with NYL Investors LLC, an affiliate of New York Life, and each of the undersigned holders of Notes (the "New York Life Agreement"), with a maximum aggregate borrowing capacity of $200.0 million.  On September 26, 2018, the Company issued and sold $75.0 million of fixed rate senior notes due September 26, 2025. These senior notes bear an interest rate of 4.04 percent with interest-only payments due semi-annually.  The proceeds from the issuance of the notes were used to pay off existing variable interest rate indebtedness. As of June 30, 2020, there was $125.0 million remaining borrowing capacity under the New York Life Agreement.

[0000038725-20-000179:notes:48]
Credit Agreement

[0000038725-20-000179:notes:49]
The Company maintains the Third Amended and Restated Credit Agreement (the "Credit Agreement”). The Credit Agreement has a maturity date of October 28, 2021 and commitment amount of $300.0 million. The Credit Agreement provides that the Borrowers may request an increase in the aggregate commitments by up to $150.0 million (not to exceed a total commitment

[0000038725-20-000179:notes:50]
of $450.0 million).  Under the Credit Agreement, the Borrowers are required to pay certain fees, including a facility fee of 0.100% to 0.275% (depending on the Company's leverage ratio) of the aggregate commitment, which fee is payable quarterly in arrears. Loans may be made either at (i) a Eurocurrency rate based on LIBOR plus an applicable margin of 0.75% to 1.60% (depending on the Company's leverage ratio) or (ii) an alternative base rate as defined in the Credit Agreement.

[0000038725-20-000179:notes:51]
As of June 30, 2020, the Company had $1.7 million in outstanding borrowings which were primarily used for working capital needs, the payment of existing indebtedness and acquisitions, $4.2 million in letters of credit outstanding, and $294.1 million of available capacity under the Credit Agreement.

[0000038725-20-000179:notes:52]
Covenants

[0000038725-20-000179:notes:53]
The Company’s credit agreements contain customary financial covenants. The Company’s most significant agreements and restrictive covenants are in the New York Life Agreement, the Project Bonds, the Prudential Agreement, and the Credit Agreement; each containing both affirmative and negative covenants. The affirmative covenants relate to financial statements, notices of material events, conduct of business, inspection of property, maintenance of insurance, compliance with laws and most favored lender obligations. The negative covenants include limitations on loans, advances and investments, and the granting of liens by the Company or its subsidiaries, as well as prohibitions on certain consolidations, mergers, sales and transfers of assets. The covenants also include financial requirements including a maximum leverage ratio of 1.00 to 3.50 and a minimum interest coverage ratio of 1.00 to 3.00. Cross default is applicable with the Prudential Agreement, the Project Bonds, the New York Life Agreement, and the Credit Agreement but only if the Company is defaulting on an obligation exceeding $10.0 million. The Company was in compliance with all financial covenants as of June 30, 2020.


## us-gaap:EarningsPerShareTextBlock

[0000038725-20-000179:notes:54]
[same as prior period, unchanged from 0000038725-20-000107:notes:51]

[0000038725-20-000179:notes:55]
[same as prior period, unchanged from 0000038725-20-000107:notes:52]

[0000038725-20-000179:notes:56]
[same as prior period, unchanged from 0000038725-20-000107:notes:53]

[0000038725-20-000179:notes:57]
|  | Second Quarter Ended |  |  |  | Six Months Ended |  |  |
| (In millions, except per share amounts) | June 30, 2020 |  | June 30, 2019 |  | June 30, 2020 |  | June 30, 2019 |
| Numerator: |  |  |  |  |  |  |  |
| Net income attributable to Franklin Electric Co., Inc. | $ | 24.7 |  |  | $ | 32.7 |  |  | $ | 35.3 |  |  | $ | 41.8 |  |
| Less: Earnings allocated to participating securities | 0.2 |  |  | 0.2 |  |  | 0.2 |  |  | 0.3 |  |
| Net income available to common shareholders | $ | 24.5 |  |  | $ | 32.5 |  |  | $ | 35.1 |  |  | $ | 41.5 |  |
| Denominator: |  |  |  |  |  |  |  |
| Basic weighted average common shares outstanding | 46.2 |  |  | 46.3 |  |  | 46.3 |  |  | 46.3 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |
| Non-participating employee stock options and performance awards | 0.3 |  |  | 0.4 |  |  | 0.4 |  |  | 0.4 |  |
| Diluted weighted average common shares outstanding | 46.5 |  |  | 46.7 |  |  | 46.7 |  |  | 46.7 |  |
| Basic earnings per share | $ | 0.53 |  |  | $ | 0.70 |  |  | $ | 0.76 |  |  | $ | 0.89 |  |
| Diluted earnings per share | $ | 0.52 |  |  | $ | 0.70 |  |  | $ | 0.75 |  |  | $ | 0.89 |  |

[0000038725-20-000179:notes:58]
There were 0.4 million and 0.3 million stock options outstanding for the second quarters ended June 30, 2020 and June 30, 2019, and 0.3 million and 0.2 million stock options outstanding for the six months ended June 30, 2020 and June 30, 2019 respectively, that were excluded from the computation of diluted earnings per share, as their inclusion would be anti-dilutive.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000038725-20-000179:notes:59]
EQUITY ROLL FORWARD
The schedules below set forth equity changes in the second quarters ended June 30, 2020 and June 30, 2019:

[0000038725-20-000179:notes:60]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of March 31, 2020 | $ | 4,614 |  |  | $ | 274,869 |  |  | $ | 698,917 |  |  | $ | (49,373) |  |  | $ | (177,848) |  |  | $ | 2,287 |  |  | $ | 753,466 |  |  | $ | (245) |  |
| Net income |  |  |  |  | 24,651 |  |  |  |  |  |  | 169 |  |  | 24,820 |  |  | (18) |  |
| Dividends on common stock ($0.155/share) |  |  |  |  | (7,206) |  |  |  |  |  |  |  |  | (7,206) |  |  |  |
| Common stock issued | 2 |  |  | 647 |  |  |  |  |  |  |  |  |  |  | 649 |  |  |  |
| Common stock repurchased | (2) |  |  |  |  | (741) |  |  |  |  |  |  |  |  | (743) |  |  |  |
| Share-based compensation | 4 |  |  | 2,659 |  |  |  |  |  |  |  |  |  |  | 2,663 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | (830) |  |  | (830) |  |  |  |
| Purchase of redeemable noncontrolling shares |  |  |  |  |  |  |  |  |  |  |  |  | — |  |  | — |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | 1,955 |  |  | 21 |  |  | 1,976 |  |  | 1 |  |
| Pension liability, net of tax |  |  |  |  |  |  | 716 |  |  |  |  |  |  | 716 |  |  |  |
| Balance as of June 30, 2020 | $ | 4,618 |  |  | $ | 278,175 |  |  | $ | 715,621 |  |  | $ | (48,657) |  |  | $ | (175,893) |  |  | $ | 1,647 |  |  | $ | 775,511 |  |  | $ | (262) |  |

[0000038725-20-000179:notes:61]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of March 31, 2019 | $ | 4,637 |  |  | $ | 262,002 |  |  | $ | 652,737 |  |  | $ | (48,076) |  |  | $ | (137,205) |  |  | $ | 2,097 |  |  | $ | 736,192 |  |  | $ | 408 |  |
| Net income |  |  |  |  | 32,745 |  |  |  |  |  |  | 247 |  |  | 32,992 |  |  | (180) |  |
| Dividends on common stock ($0.145/share) |  |  |  |  | (6,787) |  |  |  |  |  |  |  |  | (6,787) |  |  |  |
| Common stock issued | 1 |  |  | 243 |  |  |  |  |  |  |  |  |  |  | 244 |  |  |  |
| Common stock repurchased | (12) |  |  |  |  | (5,202) |  |  |  |  |  |  |  |  | (5,214) |  |  |  |
| Share-based compensation | 6 |  |  | 2,288 |  |  |  |  |  |  |  |  |  |  | 2,294 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | (642) |  |  | (642) |  |  |  |
| Purchase of redeemable noncontrolling shares |  |  |  |  |  |  |  |  |  |  |  |  | — |  |  | (485) |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | 1,303 |  |  | 12 |  |  | 1,315 |  |  | 47 |  |
| Pension liability, net of tax |  |  |  |  |  |  | 508 |  |  |  |  |  |  | 508 |  |  |  |
| Balance as of June 30, 2019 | $ | 4,632 |  |  | $ | 264,533 |  |  | $ | 673,493 |  |  | $ | (47,568) |  |  | $ | (135,902) |  |  | $ | 1,714 |  |  | $ | 760,902 |  |  | $ | (210) |  |

[0000038725-20-000179:notes:62]
The schedules below set forth equity changes in the six months ended June 30, 2020 and June 30, 2019:

[0000038725-20-000179:notes:63]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2019 | $ | 4,639 |  |  | $ | 269,656 |  |  | $ | 712,460 |  |  | $ | (50,089) |  |  | $ | (140,121) |  |  | $ | 2,124 |  |  | $ | 798,669 |  |  | $ | (236) |  |
| Net Income |  |  |  |  | 35,294 |  |  |  |  |  |  | 356 |  |  | 35,650 |  |  | (56) |  |
| Dividends on common stock ($0.310/share) |  |  |  |  | (14,446) |  |  |  |  |  |  |  |  | (14,446) |  |  |  |
| Common stock issued | 4 |  |  | 1,516 |  |  |  |  |  |  |  |  |  |  | 1,520 |  |  |  |
| Common stock repurchased | (37) |  |  |  |  | (17,687) |  |  |  |  |  |  |  |  | (17,724) |  |  |  |
| Share-based compensation | 12 |  |  | 7,003 |  |  |  |  |  |  |  |  |  |  | 7,015 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | (830) |  |  | (830) |  |  |  |
| Purchase of redeemable non-controlling shares |  |  |  |  |  |  |  |  |  |  |  |  | — |  |  | — |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (35,772) |  |  | (3) |  |  | (35,775) |  |  | 30 |  |
| Pension liability, net of taxes |  |  |  |  |  |  | 1,432 |  |  |  |  |  |  | 1,432 |  |  |  |
| Balance as of June 30, 2020 | $ | 4,618 |  |  | $ | 278,175 |  |  | $ | 715,621 |  |  | $ | (48,657) |  |  | $ | (175,893) |  |  | $ | 1,647 |  |  | $ | 775,511 |  |  | $ | (262) |  |

[0000038725-20-000179:notes:64]
| (In thousands) | Common Stock |  | Additional Paid in Capital |  | Retained Earnings |  | Minimum Pension Liability |  | Cumulative Translation Adjustment |  | Noncontrolling Interest |  | Total Equity |  | Redeemable Noncontrolling Interest |
| Balance as of December 31, 2018 | $ | 4,632 |  |  | $ | 257,535 |  |  | $ | 654,724 |  |  | $ | (48,585) |  |  | $ | (134,434) |  |  | $ | 1,955 |  |  | $ | 735,827 |  |  | $ | 518 |  |
| Net Income |  |  |  |  | 41,801 |  |  |  |  |  |  | 421 |  |  | 42,222 |  |  | (283) |  |
| Dividends on common stock ($0.290/share) |  |  |  |  | (13,510) |  |  |  |  |  |  |  |  | (13,510) |  |  |  |
| Common stock issued | 7 |  |  | 1,488 |  |  |  |  |  |  |  |  |  |  | 1,495 |  |  |  |
| Common stock repurchased | (21) |  |  |  |  | (9,522) |  |  |  |  |  |  |  |  | (9,543) |  |  |  |
| Share-based compensation | 14 |  |  | 5,510 |  |  |  |  |  |  |  |  |  |  | 5,524 |  |  |  |
| Noncontrolling dividend |  |  |  |  |  |  |  |  |  |  | (642) |  |  | (642) |  |  |  |
| Purchase of redeemable non-controlling shares |  |  |  |  |  |  |  |  |  |  |  |  | — |  |  | (485) |  |
| Currency translation adjustment |  |  |  |  |  |  |  |  | (1,468) |  |  | (20) |  |  | (1,488) |  |  | 40 |  |
| Pension liability, net of taxes |  |  |  |  |  |  | 1,017 |  |  |  |  |  |  | 1,017 |  |  |  |
| Balance as of June 30, 2019 | $ | 4,632 |  |  | $ | 264,533 |  |  | $ | 673,493 |  |  | $ | (47,568) |  |  | $ | (135,902) |  |  | $ | 1,714 |  |  | $ | 760,902 |  |  | $ | (210) |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000038725-20-000179:notes:65]
ACCUMULATED OTHER COMPREHENSIVE INCOME/(LOSS)
Changes in accumulated other comprehensive income/(loss) by component for the six months ended June 30, 2020 and June 30, 2019, are summarized below:

[0000038725-20-000179:notes:66]
| (In millions) |  |  |  |  |  |
| For the six months ended June 30, 2020: | Foreign Currency Translation Adjustments |  | Pension and Post-Retirement Plan Benefit Adjustments (2) |  | Total |
| Balance as of December 31, 2019 | $ | (140.2) |  |  | $ | (50.0) |  |  | $ | (190.2) |  |
| Other comprehensive income/(loss) before reclassifications | (35.8) |  |  | — |  |  | (35.8) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 1.4 |  |  | 1.4 |  |
| Net other comprehensive income/(loss) | (35.8) |  |  | 1.4 |  |  | (34.4) |  |
| Balance as of June 30, 2020 | $ | (176.0) |  |  | $ | (48.6) |  |  | $ | (224.6) |  |
| For the six months ended June 30, 2019: |  |  |  |  |  |
| Balance as of December 31, 2018 | $ | (134.5) |  |  | $ | (48.5) |  |  | $ | (183.0) |  |
| Other comprehensive income/(loss) before reclassifications | (1.4) |  |  | — |  |  | (1.4) |  |
| Amounts reclassified from accumulated other comprehensive income/(loss) (1) | — |  |  | 0.9 |  |  | 0.9 |  |
| Net other comprehensive income/(loss) | (1.4) |  |  | 0.9 |  |  | (0.5) |  |
| Balance as of June 30, 2019 | $ | (135.9) |  |  | $ | (47.6) |  |  | $ | (183.5) |  |

[0000038725-20-000179:notes:67]
[same as prior period, unchanged from 0000038725-20-000107:notes:61]

[0000038725-20-000179:notes:68]
(2) Net of tax expense of $0.4 million and $0.3 million for the six months ended June 30, 2020 and June 30, 2019, respectively.

[0000038725-20-000179:notes:69]
[same as prior period, unchanged from 0000038725-20-000107:notes:63]


## us-gaap:SegmentReportingDisclosureTextBlock

[0000038725-20-000179:notes:70]
[same as prior period, unchanged from 0000038725-20-000107:notes:64]

[0000038725-20-000179:notes:71]
[same as prior period, unchanged from 0000038725-20-000107:notes:65]

[0000038725-20-000179:notes:72]
[same as prior period, unchanged from 0000038725-20-000107:notes:66]

[0000038725-20-000179:notes:73]
|  | Second Quarter Ended |  |  |  | Six Months Ended |  |  |
| (In millions) | June 30, 2020 |  | June 30, 2019 |  | June 30, 2020 |  | June 30, 2019 |
|  | Net sales |  |  |  |  |  |  |
| Water Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | $ | 80.8 |  |  | $ | 103.1 |  |  | $ | 151.7 |  |  | $ | 189.9 |  |
| Latin America | 24.2 |  |  | 29.4 |  |  | 52.4 |  |  | 59.9 |  |
| Europe, Middle East & Africa | 35.5 |  |  | 39.0 |  |  | 73.7 |  |  | 76.7 |  |
| Asia Pacific | 19.7 |  |  | 18.7 |  |  | 33.5 |  |  | 40.9 |  |
| Intersegment sales |  |  |  |  |  |  |  |
| United States & Canada | 18.2 |  |  | 14.8 |  |  | 31.2 |  |  | 26.0 |  |
| Total sales | 178.4 |  |  | 205.0 |  |  | 342.5 |  |  | 393.4 |  |
| Distribution |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 92.1 |  |  | 87.1 |  |  | 152.5 |  |  | 140.4 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 92.1 |  |  | 87.1 |  |  | 152.5 |  |  | 140.4 |  |
| Fueling Systems |  |  |  |  |  |  |  |
| External sales |  |  |  |  |  |  |  |
| United States & Canada | 35.3 |  |  | 45.9 |  |  | 72.6 |  |  | 81.1 |  |
| All other | 20.7 |  |  | 32.1 |  |  | 38.6 |  |  | 57.2 |  |
| Intersegment sales | — |  |  | — |  |  | — |  |  | — |  |
| Total sales | 56.0 |  |  | 78.0 |  |  | 111.2 |  |  | 138.3 |  |
| Intersegment Eliminations/Other | (18.2) |  |  | (14.8) |  |  | (31.2) |  |  | (26.0) |  |
| Consolidated | $ | 308.3 |  |  | $ | 355.3 |  |  | $ | 575.0 |  |  | $ | 646.1 |  |
|  | Second Quarter Ended |  |  |  | Six Months Ended |  |  |
|  | June 30, 2020 |  | June 30, 2019 |  | June 30, 2020 |  | June 30, 2019 |
|  | Operating income/(loss) |  |  |  |  |  |  |
| Water Systems | $ | 28.7 |  |  | $ | 30.9 |  |  | $ | 47.5 |  |  | $ | 50.1 |  |
| Distribution | 6.8 |  |  | 4.5 |  |  | 4.6 |  |  | 0.2 |  |
| Fueling Systems | 13.5 |  |  | 21.7 |  |  | 25.6 |  |  | 34.0 |  |
| Intersegment Eliminations/Other | (15.1) |  |  | (13.4) |  |  | (29.9) |  |  | (28.5) |  |
| Consolidated | $ | 33.9 |  |  | $ | 43.7 |  |  | $ | 47.8 |  |  | $ | 55.8 |  |

[0000038725-20-000179:notes:74]
|  | June 30, 2020 |  | December 31, 2019 |  |  |  |  |
|  | Total assets |  |  |  |  |  |  |
| Water Systems | $ | 625.2 |  |  | $ | 658.3 |  |  |  |  |  |
| Distribution | 200.3 |  |  | 180.2 |  |  |  |  |  |
| Fueling Systems | 267.3 |  |  | 283.8 |  |  |  |  |  |
| Other | 58.5 |  |  | 72.4 |  |  |  |  |  |
| Consolidated | $ | 1,151.3 |  |  | $ | 1,194.7 |  |  |  |  |  |

[0000038725-20-000179:notes:75]
[same as prior period, unchanged from 0000038725-20-000107:notes:69]


## us-gaap:CommitmentsContingenciesAndGuaranteesTextBlock

[0000038725-20-000179:notes:76]
COMMITMENTS AND CONTINGENCIES
The Company is defending various claims and legal actions which have arisen in the ordinary course of business.  In the opinion of management, based on current knowledge of the facts and after discussion with counsel, these claims and legal actions can be defended or resolved without a material effect on the Company’s financial position, results of operations, and net cash flows.

[0000038725-20-000179:notes:77]
At June 30, 2020, the Company had $8.5 million of commitments primarily for capital expenditures and purchase of raw materials to be used in production.

[0000038725-20-000179:notes:78]
The Company provides warranties on most of its products.  The warranty terms vary but are generally two years to five years from date of manufacture or one year to five years from date of installation.  Provisions for estimated expenses related to product warranty are made at the time products are sold or when specific warranty issues are identified.  These estimates are established using historical information about the nature, frequency, and average cost of warranty claims.  The Company actively studies trends of warranty claims and takes actions to improve product quality and minimize warranty claims.  The Company believes that the warranty reserve is appropriate; however, actual claims incurred could differ from the original estimates, requiring adjustments to the reserve.

[0000038725-20-000179:notes:79]
The changes in the carrying amount of the warranty accrual, as recorded in the "Accrued expenses and other current liabilities" line of the Company's condensed consolidated balance sheet for the six months ended June 30, 2020, are as follows:

[0000038725-20-000179:notes:80]
| (In millions) |  |  |
| Balance as of December 31, 2019 |  | $ | 9.1 |  |
| Accruals related to product warranties |  | 4.8 |  |
| Additions related to acquisitions |  | — |  |
| Reductions for payments made |  | (4.8) |  |
| Balance as of June 30, 2020 |  | $ | 9.1 |  |

[0000038725-20-000179:notes:81]
The Company maintains certain warehouses, distribution centers, office space, and equipment operating leases. The Company also has lease agreements that are classified as financing. These financing leases are immaterial to the Company.

[0000038725-20-000179:notes:82]
The Company utilizes interest rates from lease agreements unless the lease agreement does not provide a readily determinable rate. In these instances, the Company utilizes its incremental borrowing rate based on the information available as of the adoption of ASU 2016-02 or at the inception of any new leases entered into thereafter when determining the present value of future lease payments.

[0000038725-20-000179:notes:83]
Some of the Company’s leases include renewal options. The Company excludes these renewal options in the expected lease term unless the Company is reasonably certain that the option will be exercised.

[0000038725-20-000179:notes:84]
The components of the Company’s operating lease portfolio as of the second quarter and six months ended June 30, 2020 are as follows:

[0000038725-20-000179:notes:85]
| Lease Cost (in millions): | Second Quarter Ended |  | Six Months Ended |
| Operating lease cost | $ | 3.2 |  |  | $ | 5.2 |  |
| Short-term lease cost | 0.1 |  |  | 0.2 |  |
| Other Information: |  |  |  |
| Weighted-average remaining lease term |  |  | 4 years |
| Weighted-average discount rate |  |  | 3.8 | % |

[0000038725-20-000179:notes:86]
The minimum rental payments for non-cancellable operating leases as of June 30, 2020, are as follows:

[0000038725-20-000179:notes:87]
| (In millions) | 2020 | 2021 | 2022 | 2023 | 2024 | Thereafter |
| Future Minimum Rental Payments | $ | 5.7 |  | $ | 9.5 |  | $ | 6.2 |  | $ | 3.9 |  | $ | 1.6 |  | $ | 2.5 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000038725-20-000179:notes:88]
[same as prior period, unchanged from 0000038725-20-000107:notes:82]

[0000038725-20-000179:notes:89]
[same as prior period, unchanged from 0000038725-20-000107:notes:83]

[0000038725-20-000179:notes:90]
[same as prior period, unchanged from 0000038725-20-000107:notes:84]

[0000038725-20-000179:notes:91]
[same as prior period, unchanged from 0000038725-20-000107:notes:85]

[0000038725-20-000179:notes:92]
[same as prior period, unchanged from 0000038725-20-000107:notes:86]

[0000038725-20-000179:notes:93]
[same as prior period, unchanged from 0000038725-20-000107:notes:87]

[0000038725-20-000179:notes:94]
[same as prior period, unchanged from 0000038725-20-000107:notes:88]

[0000038725-20-000179:notes:95]
[same as prior period, unchanged from 0000038725-20-000107:notes:89]

[0000038725-20-000179:notes:96]
[same as prior period, unchanged from 0000038725-20-000107:notes:90]

[0000038725-20-000179:notes:97]
[same as prior period, unchanged from 0000038725-20-000107:notes:91]

[0000038725-20-000179:notes:98]
The assumptions used for the Black-Scholes model to determine the fair value of options granted during the six months ended June 30, 2020 and June 30, 2019 are as follows:

[0000038725-20-000179:notes:99]
|  |  | June 30, 2020 |  | June 30, 2019 |
| Risk-free interest rate |  | 1.39 | % |  | 2.53 | % |
| Dividend yield |  | 1.04 | % |  | 1.05 | % |
| Volatility factor |  | 29.45 | % |  | 29.38 | % |
| Expected term |  | 5.5 years |  | 5.5 years |

[0000038725-20-000179:notes:100]
A summary of the Company’s outstanding stock option activity and related information for the six months ended June 30, 2020 is as follows:

[0000038725-20-000179:notes:101]
| (Shares in thousands) |  | June 30, 2020 |  |  |
| Stock Options |  | Shares |  | Weighted-Average Exercise Price |
| Outstanding at beginning of period |  | 1,262 |  |  | $ | 37.99 |  |
| Granted |  | 214 |  |  | 59.71 |  |
| Exercised |  | (43) |  |  | 34.82 |  |
| Forfeited |  | (4) |  |  | 50.13 |  |
| Outstanding at end of period |  | 1,429 |  |  | $ | 41.31 |  |
| Expected to vest after applying forfeiture rate |  | 1,427 |  |  | $ | 41.29 |  |
| Vested and exercisable at end of period |  | 958 |  |  | $ | 35.70 |  |

[0000038725-20-000179:notes:102]
A summary of the weighted-average remaining contractual term and aggregate intrinsic value as of June 30, 2020 is as follows:

[0000038725-20-000179:notes:103]
|  |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (000's) |
| Outstanding at end of period |  | 5.87 years |  | $ | 18,033 |  |
| Expected to vest after applying forfeiture rate |  | 5.86 years |  | $ | 18,027 |  |
| Vested and exercisable at end of period |  | 4.48 years |  | $ | 16,338 |  |

[0000038725-20-000179:notes:104]
The total intrinsic value of options exercised during the six months ended June 30, 2020 and June 30, 2019 was $0.9 million and $2.1 million, respectively.

[0000038725-20-000179:notes:105]
As of June 30, 2020, there was $1.6 million of total unrecognized compensation cost related to non-vested stock options granted under the stock plans.  That cost is expected to be recognized over a weighted-average period of 1.66 years.

[0000038725-20-000179:notes:106]
[same as prior period, unchanged from 0000038725-20-000107:notes:100]

[0000038725-20-000179:notes:107]
A summary of the Company’s restricted stock/stock unit award activity and related information for the six months ended June 30, 2020 is as follows:

[0000038725-20-000179:notes:108]
| (Shares in thousands) |  | June 30, 2020 |  |  |
| Restricted Stock/Stock Unit Awards |  | Shares |  | Weighted-Average Grant-Date Fair Value |
| Non-vested at beginning of period |  | 463 |  |  | $ | 42.36 |  |
| Awarded |  | 118 |  |  | 59.27 |  |
| Vested |  | (127) |  |  | 33.85 |  |
| Forfeited |  | (17) |  |  | 48.72 |  |
| Non-vested at end of period |  | 437 |  |  | $ | 49.16 |  |

[0000038725-20-000179:notes:109]
As of June 30, 2020, there was $11.1 million of total unrecognized compensation cost related to non-vested restricted stock/stock unit awards granted under the stock plans.  That cost is expected to be recognized over a weighted-average period of 1.56 years.
